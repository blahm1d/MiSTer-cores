War Gods (V Unit) - r14
RBF SHA-256: 8c6eafbb8e426091a9ea6d7460c7f4a1e3c4429a435f7f5e5b93be43a8d42076

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: wargods-wg1-r14
The compiled binary's validation status is recorded in the feed catalog.
