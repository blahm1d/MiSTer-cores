`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// One physical read burst (1..8 beats), tagged to its client until every
// response is drained and the final registered response retires. Writes are
// single beat. There is no response backpressure: one beat may arrive per clock.
// quiesce_request blocks new selection, preserves a held ISSUE command until
// physical acceptance, and drains read responses without publication. Command
// acceptance still reaches its owner. Hold until quiesced; only then reset clients.
// Downstream write visibility still requires the physical adapter's fence.
// Once selected, a validated command belongs to this mux. Live client mutation
// or a stray response poisons future admission/publication, but cannot revoke
// that command while waitrequest is high. It still accepts and drains exactly
// once. quiesced certifies drainage even with a sticky fault, not healthy reuse.
module avalon_shared_mux #(
    parameter integer CLIENTS=5
) (
    input wire clk,cold_reset,quiesce_request,
    output wire quiesced,
    input wire [CLIENTS-1:0] client_read,client_write,client_urgent,
    input wire [CLIENTS*32-1:0] client_address,
    input wire [CLIENTS*64-1:0] client_writedata,
    input wire [CLIENTS*8-1:0] client_byteenable,
    input wire [CLIENTS*4-1:0] client_burstcount,
    output reg [CLIENTS-1:0] client_waitrequest,client_readdatavalid,client_read_error,
    output wire [CLIENTS*64-1:0] client_readdata,
    output wire avm_read,avm_write,
    output wire [31:0] avm_address,
    output wire [63:0] avm_writedata,
    output wire [7:0] avm_byteenable,
    output wire [3:0] avm_burstcount,
    input wire avm_waitrequest,avm_readdatavalid,avm_read_error,
    input wire [63:0] avm_readdata,
    output reg [2:0] fault_code,
    // Forensics for the FIRST fault, latched with fault_code and sticky like it. The
    // cabinet has no instrument but the screen, and fault_code alone says "1" for two
    // very different defects. Leave unconnected where it is not displayed.
    //   9   a client offered a MALFORMED command (caught at selection)
    //   8   a client MUTATED its command before acceptance (the Avalon waitrequest rule)
    //   7   an UNEXPECTED read response arrived
    //   6:5 client index (the selected client for 9, the owner for 8 and 7)
    //   4   malformed: read AND write      3 malformed: address[2:0] != 0
    //   2   malformed: burstcount == 0     1 malformed: burstcount > 8
    //   0   malformed: write with burstcount != 1
    output reg [9:0] fault_info
);
    localparam [1:0] IDLE=0,ISSUE=1,READ_PENDING=2,RESPONSE=3;
    localparam integer OWNER_BITS=(CLIENTS<2)?1:$clog2(CLIENTS);
    reg [1:0] state;
    reg [OWNER_BITS-1:0] owner,rotation;
    reg held_read,held_write;
    reg [31:0] held_address;
    reg [63:0] held_writedata,response_data;
    reg [7:0] held_byteenable;
    reg [3:0] held_burstcount;
    reg response_error;
    reg response_valid;
    reg [3:0] beats_remaining;
    integer selected,index;
    reg selection_valid;
    wire [CLIENTS-1:0] requests=client_read|client_write;
    wire urgent_present=|(requests&client_urgent);
    wire [CLIENTS-1:0] candidates=urgent_present ? (requests&client_urgent) : requests;
    always @* begin
        selected=0;selection_valid=0;index=0;
        for(integer offset=0;offset<CLIENTS;offset=offset+1) begin
            index=integer'(rotation)+offset;
            if(index>=CLIENTS) index=index-CLIENTS;
            if(!selection_valid && candidates[index]) begin selected=index;selection_valid=1;end
        end
    end
    wire issue_enabled=state==ISSUE && !cold_reset;
    wire unchanged=client_read[owner]==held_read && client_write[owner]==held_write &&
        client_address[owner*32 +:32]==held_address &&
        client_writedata[owner*64 +:64]==held_writedata &&
        client_byteenable[owner*8 +:8]==held_byteenable &&
        client_burstcount[owner*4 +:4]==held_burstcount;
    wire [3:0] selected_beats=client_burstcount[selected*4 +:4];
    // The five malformed rules, kept apart so the first fault can name which one fired.
    wire sel_m_rw   =client_read[selected] && client_write[selected];
    wire sel_m_align=client_address[selected*32 +:3]!=0;
    wire sel_m_bc0  =selected_beats==0;
    wire sel_m_bc8  =selected_beats>8;
    wire sel_m_wbc  =client_write[selected] && selected_beats!=1;
    wire selected_malformed=sel_m_rw||sel_m_align||sel_m_bc0||sel_m_bc8||sel_m_wbc;
    // No downstream output depends on current client signals, waitrequest or
    // readdatavalid. The old same-cycle fault suppression closed a combinational
    // loop through the clients and the DDR adapter during physical synthesis.
    assign avm_read=issue_enabled && held_read;
    assign avm_write=issue_enabled && held_write;
    wire offered_read=avm_read && !avm_waitrequest;
    wire response_expected=(state==READ_PENDING && beats_remaining!=0) || offered_read;
    wire unexpected_response=avm_readdatavalid && !response_expected;
    // A registered response owns READ_PENDING/RESPONSE, never ISSUE. Its
    // publication checks only remaining owned debt; current command acceptance
    // cannot qualify an extra beat here. Keep response_expected above intact
    // for zero-latency capture and command/fault handling.
    wire owned_unexpected_response=avm_readdatavalid &&
        !(state==READ_PENDING && beats_remaining!=0);
    wire [3:0] response_debt=offered_read ? held_burstcount : beats_remaining;
    wire mutation_error=issue_enabled && !unchanged;
    wire local_error=unexpected_response || mutation_error;
    assign avm_address=held_address;
    assign avm_writedata=held_writedata;
    assign avm_byteenable=held_byteenable;
    assign avm_burstcount=held_burstcount;
    wire accepted=(avm_read || avm_write) && !avm_waitrequest;
    assign client_readdata={CLIENTS{response_data}};
    assign quiesced=!cold_reset && quiesce_request && state==IDLE && !avm_readdatavalid;
    always @* begin
        client_waitrequest={CLIENTS{1'b1}};
        client_readdatavalid=0;client_read_error=0;
        if(!cold_reset) begin
            // The old owner's physical acceptance is not canceled by poison.
            if(accepted) client_waitrequest[owner]=0;
            // Consecutive expected beats may replace this registered slot as
            // it retires. An excess beat suppresses the old slot immediately;
            // neither publication nor response validation drives a command.
            if(response_valid && fault_code==0 && !quiesce_request && !owned_unexpected_response) begin
                client_readdatavalid[owner]=1;
                client_read_error[owner]=response_error;
            end
        end
    end
    always @(posedge clk) begin
        if(cold_reset) begin
            state<=IDLE;owner<=0;rotation<=0;held_read<=0;held_write<=0;
            held_address<=0;held_writedata<=0;held_byteenable<=0;held_burstcount<=1;
            response_data<=0;response_error<=0;response_valid<=0;beats_remaining<=0;fault_code<=0;
            fault_info<=0;
        end else begin
            response_valid<=0;
            if(fault_code==0 && local_error) fault_code<=unexpected_response ? 3'd2 : 3'd1;
            // Forensics, latched with the first fault and sticky with it.
            if(fault_code==0) begin
                if(local_error)
                    fault_info<={1'b0,mutation_error,unexpected_response,2'(owner),5'd0};
                else if(state==IDLE && !quiesce_request && selection_valid && selected_malformed)
                    fault_info<={1'b1,1'b0,1'b0,2'(selected),
                                 sel_m_rw,sel_m_align,sel_m_bc0,sel_m_bc8,sel_m_wbc};
            end
            // Faults stop new selections; they do not freeze an owned physical
            // transaction. Drain an accepted read before certifying quiescence.
            case(state)
                    IDLE: if(!quiesce_request && fault_code==0 && !local_error && selection_valid) begin
                        if(selected_malformed) fault_code<=3'd1;
                        else begin
                        owner<=OWNER_BITS'(selected);
                        held_read<=client_read[selected];held_write<=client_write[selected];
                        held_address<=client_address[selected*32 +:32];
                        held_writedata<=client_writedata[selected*64 +:64];
                        held_byteenable<=client_byteenable[selected*8 +:8];
                        held_burstcount<=client_burstcount[selected*4 +:4];state<=ISSUE;
                        end
                    end
                    ISSUE: if(accepted) begin
                        rotation<=(integer'(owner)==CLIENTS-1)?0:owner+1'b1;
                        state<=held_read?READ_PENDING:IDLE;
                        if(held_read) beats_remaining<=held_burstcount;
                    end
                    RESPONSE: state<=IDLE;
                    default: begin end
            endcase
            if(avm_readdatavalid && response_expected) begin
                    beats_remaining<=response_debt-1'b1;
                    if(response_debt==1)
                        state<=(quiesce_request || fault_code!=0 || local_error)?IDLE:RESPONSE;
                    else state<=READ_PENDING;
                    if(!quiesce_request && fault_code==0 && !local_error) begin
                        response_data<=avm_readdata;response_error<=avm_read_error;response_valid<=1;
                    end
            end
        end
    end
endmodule
`default_nettype wire
