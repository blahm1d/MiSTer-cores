`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// Byte-addressed Avalon client to the stock MiSTer DDRAM port. Reads carry
// 1..8 ordered beats, writes one. One burst is outstanding; each returned beat
// uses a registered output slot that can retire and refill on the same edge.
// reset is cold initialization ONLY, after the framework has drained the port.
// Use quiesce_request for a live session reset: pending reads drain, and the
// last accepted write is followed by a same-port readback before quiesced.
// Readback relies on ordered read-after-write service by that physical port;
// simulation of this adapter does not prove cross-master ARM cache visibility.
module mister_ddram_adapter (
    input wire clk,reset,quiesce_request,
    output wire backend_quiesced,
    input wire avm_read,avm_write,
    input wire [31:0] avm_address,
    input wire [63:0] avm_writedata,
    input wire [7:0] avm_byteenable,
    input wire [3:0] avm_burstcount,
    output wire avm_waitrequest,avm_readdatavalid,
    output wire [63:0] avm_readdata,
    output wire avm_read_error,
    input wire DDRAM_BUSY,DDRAM_DOUT_READY,
    input wire [63:0] DDRAM_DOUT,
    output wire [28:0] DDRAM_ADDR,
    output wire [7:0] DDRAM_BURSTCNT,
    output wire [63:0] DDRAM_DIN,
    output wire [7:0] DDRAM_BE,
    output wire DDRAM_RD,DDRAM_WE,
    output reg [2:0] fault_code
);
    localparam [1:0] IDLE=0,READ_PENDING=1,RESPONSE=2,FENCE_PENDING=3;
    reg [1:0] state;
    reg dirty_write;
    reg [28:0] last_write_address;
    reg [63:0] response_data;
    reg response_valid;
    reg [3:0] beats_remaining;
    wire requested=avm_read || avm_write;
    wire malformed=(avm_read && avm_write) || avm_address[2:0]!=0 ||
        avm_burstcount==0 || avm_burstcount>8 || (avm_write && avm_burstcount!=1);
    wire available=!reset && fault_code==0 && state==IDLE;
    wire normal_offer=available && !quiesce_request && requested && !malformed;
    wire fence_offer=available && quiesce_request && dirty_write;
    wire offered_read=(fence_offer || (normal_offer && avm_read)) && !DDRAM_BUSY;
    wire unexpected_response=DDRAM_DOUT_READY &&
        !(((state==READ_PENDING || state==FENCE_PENDING) && beats_remaining!=0) || offered_read);
    // A registered normal response owns READ_PENDING/RESPONSE, never IDLE.
    // Publication cannot use a new command's DDRAM_BUSY/acceptance to excuse an
    // extra beat. Full offered_read validation above remains on zero-latency
    // capture, command admission and sticky fault handling (including fences).
    wire owned_unexpected_response=DDRAM_DOUT_READY &&
        !((state==READ_PENDING || state==FENCE_PENDING) && beats_remaining!=0);
    // A faulting beat cannot publish a response or admit a write on its edge.
    wire normal_command=normal_offer && !unexpected_response;
    wire fence_command=fence_offer && !unexpected_response;
    assign DDRAM_ADDR=fence_command ? last_write_address : avm_address[31:3];
    assign DDRAM_BURSTCNT=fence_command ? 8'd1 : {4'b0,avm_burstcount};
    assign DDRAM_DIN=avm_writedata;
    assign DDRAM_BE=fence_command ? 8'hff : avm_byteenable;
    assign DDRAM_RD=fence_command || (normal_command && avm_read);
    assign DDRAM_WE=normal_command && avm_write;
    assign avm_waitrequest=!available || quiesce_request || DDRAM_BUSY || unexpected_response || (requested && malformed);
    wire read_accepted=DDRAM_RD && !DDRAM_BUSY;
    wire write_accepted=DDRAM_WE && !DDRAM_BUSY;
    wire response_expected=((state==READ_PENDING || state==FENCE_PENDING) && beats_remaining!=0) || read_accepted;
    wire response_is_fence=state==FENCE_PENDING || (read_accepted && fence_command);
    wire [3:0] response_debt=read_accepted ? (fence_command ? 4'd1 : avm_burstcount) : beats_remaining;
    assign avm_readdatavalid=!reset && !quiesce_request && fault_code==0 && !owned_unexpected_response && response_valid;
    assign avm_readdata=response_data;
    // Stock DDRAM has no per-response error pin. Protocol faults use fault_code;
    // their owner must halt. Do not fabricate a successful fault completion.
    assign avm_read_error=1'b0;
    assign backend_quiesced=!reset && quiesce_request && fault_code==0 &&
                            state==IDLE && !dirty_write && !DDRAM_DOUT_READY;

    always @(posedge clk) begin
        if(reset) begin
            state<=IDLE;dirty_write<=0;last_write_address<=0;
            response_data<=0;response_valid<=0;beats_remaining<=0;fault_code<=0;
        end else begin
            response_valid<=0;
            if(fault_code==0) begin
                if(available && !quiesce_request && requested && malformed) fault_code<=3'd1;
                else if(unexpected_response) fault_code<=3'd2;
            end
            // A sticky fault prevents new commands/publication, but cannot
            // erase accepted response debt or strand a burst during drainage.
            if(state==RESPONSE) state<=IDLE;
            if(write_accepted) begin
                dirty_write<=1;last_write_address<=avm_address[31:3];
            end
            if(read_accepted) begin
                state<=fence_command ? FENCE_PENDING : READ_PENDING;
                beats_remaining<=fence_command ? 4'd1 : avm_burstcount;
            end
            // Handles delayed responses and a zero-latency acceptance/reply.
            if(DDRAM_DOUT_READY && response_expected) begin
                beats_remaining<=response_debt-1'b1;
                if(response_debt==1) begin
                    dirty_write<=0;
                    state<=(quiesce_request || response_is_fence || fault_code!=0)?IDLE:RESPONSE;
                end else state<=READ_PENDING;
                if(!quiesce_request && !response_is_fence && fault_code==0 && !unexpected_response) begin
                    response_data<=DDRAM_DOUT;response_valid<=1;
                end
            end
        end
    end
endmodule
`default_nettype wire
