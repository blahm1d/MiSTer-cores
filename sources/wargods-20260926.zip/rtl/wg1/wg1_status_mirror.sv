`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// wg1_status_mirror -- cabinet diagnostic readout for War Gods (wg1). Publishes a 24-word status block (A) plus a
// 16-word DCS2 + speed debug block (B) to HPS DDR3 so the ARM side can read where the game is (C31, IDE, I/O ASIC, DCS2) over
// SSH with busybox devmem while it runs.
// FORK of bandwidth/gm1/rtl/gm1_status_mirror.sv (md5 a3dc9302..., rtl/FORKED_FROM.md5). Compiled only under the
// QSF/sim macro WG1_DIAG_MIRROR (wg1_core.sv); the release build has no fourth DDR client and no counters.
//
// Donor audit (DESIGN-RULES.md s4):
//   * BASE 0x38700000 kept: wg1's DDR3 users are the V-unit fb 0x38100000-0x381FFFFF, texture 0x38200000-0x385FFFFF,
//     palette 0x38600000-0x3861FFFF (vunit_memory_arbiter.sv:301-303 extents, wg1_core config_*_base) and wg1_dcs2's
//     C5 window 0x39000000-0x392FFFFF. Block A 0x38700000-0x387000BF (24 x 8 B) and block B 0x38700100-0x3870017F
//     (16 x 8 B) collide with none. The address is a BYTE address on the avalon_shared_mux; mister_ddram_adapter drops
//     [2:0], and devmem reads the same physical address (proven on the cabinet by gm1_perflog.sh).
//   * donor 12/16-word block, 40 ms PERIOD, shadow capture, wheel mailbox (BASE+128): NOT inherited. PERIOD 5,000,000
//     clk = 100 ms at 50 MHz (10 publishes/s). No shadow register file: each word is sampled when it is OFFERED (a
//     publish spans 42 DDR writes, ~2-4 us); the seqlocks mark torn blocks. No mailbox.
//   * MAGIC "wg1S" = 32'h77673153 (donor "gm1S" would let the gm1 logger misparse a wg1 block); block B "wg1D".
//   * enable: tied high after por by wg1_core (the donor used all_configured) so a core that never configures is still
//     visible (loader/ROM flags are in word 3).
//
// Word i lives at BASE + 8*i. One publish = 42 writes, two independent seqlocks sharing one seq counter:
//   A: word 0 := {"wg1S", seq odd} FIRST, words 1..22, word 23 := {"wg1S", seq+1 even}, word 0 := word 23 (commit);
//   B: word 32 := {"wg1D", seq-1 odd}, words 33..46, word 47 := {"wg1D", seq even}, word 32 := word 47 (commit).
// A reader reads the closer FIRST, the data, the opener LAST, and trusts a block only when opener == closer with an
// even seq: any write overlapping its reads leaves the opener different from the closer it read first. (DONOR DEFECT,
// not inherited: gm1_status_mirror never rewrote word 0, so its "w0 == w11 and even" test can never pass.) A and B of
// one publish carry the same even seq.
// busybox devmem is slower than the block rate, so the reader reports "TORN" after a few tries rather than looping.
// Block A:
//    0 {MAGIC, seq}                                    12 {sectors_served, ide_data_reads}
//    1 wall clocks since por                           13 {img_size[31:0], ide_accesses}
//    2 C31 instructions retired (alive counter)        14 {ide_status_reads, sd_buff_wr_count}
//    3 {8'd0, retire_pc24, flags8, cpu_pc24}          15 {soundctl_w[15:0], soundstat_r[15:0], soundstat_reads}
//    4 {int0_count, presented_frames}                  16 {dcsflags16, 2'b0 dsp_pc14, dcs_control16, dcs_data_r16}
//    5 {c31_ST, c31_IE}                                17 {host_writes (SOUNDOUT -> data_w), host_reads (SOUNDIN)}
//    6 {c31_IF, c31_IOF}                               18 {host_acks, dsp_releases}
//    7 {xf1_copies, faults32}                          19 dsp instructions retired
//    8 guest_tick (H1 ticks of guest time)             20 dsp_run_clocks (clocks with dsp_running)
//    9 {ide_cmd, ide_status, ide_seccnt, ideflags8, sd_lba}   21 {dac_underruns, maindata_words_loaded}
//   10 {ide_devhead, ide_cyl_hi, ide_cyl_lo, ide_secnum, ide_cmd_count}   22 {q_engine, q_dcs} DDR client wait clocks
//   11 {sd_rd_count, sd_ack_count}                     23 {MAGIC, seq} closer
//   flags8   = {game_running, loader_done, dcs_rom_loaded, int0_seen, fault, ext_unmapped_seen, engine_halted, slave_wait}
//   faults32 = {cpu_fault8, memory_fault8, vunit_fault8, mux_fault3, adapter_fault3, sd_map_fault, dcs_cfg_unsupported}
//   ideflags = {status_seen, sd_rd, sd_wr, sd_ack, img_mounted, img_readonly, ide_wait, 1'b0}
//   dcsflags = {dcs_run, dcs_reset_io, output_full, input_empty, dcs_rom_loaded, cfg_unsupported, dsp_running, 9'd0}
// Block B (DCS2 VS-hang debug; dcs_dbg = wg1_dcs2 dbg_mirror, layout in wg1_dcs2.sv):
//   32 {"wg1D", seq}
//   33 {pm4_writes32, 8'd0, pm4_24}           PM[4] = the IRQ2 vector word (last value written to PM address 4)
//   34 {dm382d_writes32, 16'd0, dm382d16}     DM[0x382D] = IRAM word 0x02D (polling-mode flag), last value written
//   35 {irq2_takes32, 4'd0, st4, 2'd0, lt6, 3'd0, icntl5, 2'd0, imask6}   (lt = pending latches, st[2] = IRQ2 level;
//                                             irq2_takes = interrupts TAKEN at the IRQ2 vector, irq_ack indx 0)
//   36 {irq2_masked_clk32, irq2_pending_clk32} clocks the IRQ2 request (icntl[2] ? lt[2] : st[2]) was pending, and
//                                             pending while imask[5] = 0 (masked)
//   37 {2'd0, pc_min14, 2'd0, pc_max14, period_retired32}   DSP PC (sampled on retire clocks) over the LAST COMPLETED
//                                             publish period; min > max (0x3fff/0) = no instruction retired in it
//   38 {host_count32, reply_count32}          host->DCS2 data writes, DCS2->host output-latch writes (cumulative)
//   39 {h_slot3, h_slot2, h_slot1, h_slot0}   last 8 host words, ring: word n (0-based) is in slot n % 8
//   40 {h_slot7, h_slot6, h_slot5, h_slot4}
//   41 {r_slot3, r_slot2, r_slot1, r_slot0}   last 4 replies, slot n % 4
//   42 {dbc_hits32, dbc_misses32}             DRAM beat-cache lookups (engine + SPORT1 DMA)
//   43 {dbc_fills32, dbc_prefetch_fills32}    beats filled from C5 (miss fills + prefetch fills), prefetch fills
//   44 {dram_writes32, hold_fault1, hold_releases7, ide_err_events8, adj_written1, adj445c15}
//                                             DRAM word writes accepted on C5; 2026-09-25 disk-read diag: wg1_ide's
//                                             hang safety net fired (sticky), times it released a held access (late
//                                             rising edges, saturating), ERR-bit rising edges (saturating), and the
//                                             C31 RAM word 0x00445C (ADJS "Attract Mode Sounds"; MAME reads 0 = OFF)
//                                             -- written flag + low 15 bits of the last value written
//   45 {poly_commits32, page_flips32}         2026-09-25 speed: polygon commits (completed C31 reads of 0x980083 =
//                                             MAME dma_trigger_r offset 1) and display-page toggles (game frames shown)
//   46 {rbusy_clk32, hps_lat_max32}           clocks the renderer was busy or had records queued; the longest HPS
//                                             sector service in clocks (sd_rd|sd_wr rising -> sd_ack falling)
//   47 {"wg1D", seq} closer
// Period snapshot: word 37 holds the PC tracker captured on the clock a publish STARTS; the tracker restarts there
// (a retire on that clock belongs to the new period).
// IDE/I/O fields are observed at the C1 slave boundary (accept = bus_valid && bus_sync && hit && ready, CONTRACTS C1):
// ide_cmd/ide_seccnt/ide_secnum/ide_cyl_*/ide_devhead = the last value WRITTEN to task-file registers 7/2/3/4/5/6,
// ide_status = the last value READ from register 7 (DRQ = bit 3, BSY = bit 7), soundctl_w = the last I/O ASIC reg 8
// write, soundstat_r = the last reg 10 read. sd_* counts are rising edges (sd_rd, sd_ack), sectors_served = falling
// edges of sd_ack, sd_buff_wr_count = 16-bit words the HPS delivered. All counters are cumulative since por.
// Avalon rule (the mux faults on it): a command, once offered, is held unchanged until waitrequest drops.
module wg1_status_mirror #(
    parameter [31:0] BASE   = 32'h38700000,
    parameter integer PERIOD = 5_000_000          // 100 ms at 50 MHz
) (
    input  wire         clk,
    input  wire         por,
    input  wire         enable,
    // C31 / engine
    input  wire [63:0]  instructions,
    input  wire [63:0]  guest_tick,
    input  wire [23:0]  retire_pc,
    input  wire [23:0]  cpu_pc,
    input  wire [31:0]  c31_st, c31_ie, c31_if, c31_iof,
    input  wire [31:0]  int0_count,
    input  wire [31:0]  presented_frames,
    input  wire [31:0]  xf1_copies,
    input  wire [7:0]   flags,
    input  wire [31:0]  faults,
    input  wire [31:0]  md_words,
    // C1 slave bus (observed)
    input  wire         bus_valid, bus_write, bus_sync,
    input  wire [23:0]  bus_addr,
    input  wire [31:0]  bus_wdata,
    input  wire         ide_hit, ide_ready, ide_wait,
    input  wire [15:0]  ide_rdata,
    input  wire         io_hit, io_ready,
    input  wire [15:0]  io_rdata,
    // hps_io block device (observed)
    input  wire [31:0]  sd_lba,
    input  wire         sd_rd, sd_wr, sd_ack, sd_buff_wr,
    input  wire         img_mounted, img_readonly,
    input  wire [63:0]  img_size,
    // DCS2 (observed)
    input  wire         dcs_run, dcs_reset_io, dcs_output_full, dcs_input_empty, dcs_rom_loaded, dcs_cfg_unsupported,
    input  wire         dsp_running,
    input  wire         dcs_data_we, dcs_data_rd, dcs_ack_we, dsp_retire,
    input  wire [15:0]  dcs_data_w,
    input  wire [13:0]  dsp_pc,
    input  wire [15:0]  dcs_control, dcs_data_r,
    input  wire [31:0]  dac_underruns,
    input  wire [111:0] dcs_dbg,                  // wg1_dcs2 dbg_mirror (observe-only taps, layout in wg1_dcs2.sv)
    // DDR mux contention (a client offering a command while waitrequest is high)
    input  wire         eng_wait, dcs_wait,
    // speed (wg1_board perf_diag[1:0] + the display page): polygon commit pulse, renderer-occupied level
    input  wire         poly_commit, rbusy, display_page,
    // disk-read diag (2026-09-25): wg1_ide dbg_ide levels + the board's C31 RAM 0x00445C write snoop
    input  wire         ide_hold_fault, ide_late, ide_err,
    input  wire         adj_we,
    input  wire [31:0]  adj_wd,
    // mux client
    output reg          write,
    output reg  [31:0]  address,
    output reg  [63:0]  writedata,
    output wire [7:0]   byteenable,
    output wire [3:0]   burstcount,
    input  wire         waitrequest
);
    localparam [31:0] MAGIC   = 32'h77673153;     // "wg1S"
    localparam [31:0] MAGIC_D = 32'h77673144;     // "wg1D"
    localparam [5:0]  LAST_A  = 6'd23;
    localparam [5:0]  OPEN_B  = 6'd32;
    localparam [5:0]  LAST_B  = 6'd47;
    assign byteenable = 8'hff;
    assign burstcount = 4'd1;

    // ---------------- observers (cumulative since por) ----------------
    wire ide_acc = bus_valid && bus_sync && ide_hit && ide_ready;
    wire io_acc  = bus_valid && bus_sync && io_hit  && io_ready;
    reg  [63:0] wall, dsp_retired, dsp_run_clk;
    reg  [7:0]  ide_cmd, ide_status, ide_seccnt, ide_secnum, ide_cyl_lo, ide_cyl_hi, ide_devhead;
    reg         status_seen;
    reg  [31:0] ide_cmd_count, sd_rd_count, sd_ack_count, sectors_served, ide_data_reads, ide_accesses,
                ide_status_reads, sd_buff_wr_count;
    reg  [15:0] soundctl_w, soundstat_r;
    reg  [31:0] soundstat_reads, host_writes, host_reads, host_acks, dsp_releases, q_engine, q_dcs;
    reg         sd_rd_q, sd_ack_q, dsp_running_q;

    always @(posedge clk) begin
        if (por) begin
            wall <= 64'd0; dsp_retired <= 64'd0; dsp_run_clk <= 64'd0;
            ide_cmd <= 8'd0; ide_status <= 8'd0; ide_seccnt <= 8'd0; ide_secnum <= 8'd0;
            ide_cyl_lo <= 8'd0; ide_cyl_hi <= 8'd0; ide_devhead <= 8'd0; status_seen <= 1'b0;
            ide_cmd_count <= 32'd0; sd_rd_count <= 32'd0; sd_ack_count <= 32'd0; sectors_served <= 32'd0;
            ide_data_reads <= 32'd0; ide_accesses <= 32'd0; ide_status_reads <= 32'd0; sd_buff_wr_count <= 32'd0;
            soundctl_w <= 16'd0; soundstat_r <= 16'd0; soundstat_reads <= 32'd0;
            host_writes <= 32'd0; host_reads <= 32'd0; host_acks <= 32'd0; dsp_releases <= 32'd0;
            q_engine <= 32'd0; q_dcs <= 32'd0;
            sd_rd_q <= 1'b0; sd_ack_q <= 1'b0; dsp_running_q <= 1'b0;
        end else begin
            wall <= wall + 64'd1;
            sd_rd_q <= sd_rd; sd_ack_q <= sd_ack; dsp_running_q <= dsp_running;
            if (ide_acc) begin
                ide_accesses <= ide_accesses + 32'd1;
                if (bus_write) begin
                    case (bus_addr[2:0])
                        3'd2: ide_seccnt  <= bus_wdata[7:0];
                        3'd3: ide_secnum  <= bus_wdata[7:0];
                        3'd4: ide_cyl_lo  <= bus_wdata[7:0];
                        3'd5: ide_cyl_hi  <= bus_wdata[7:0];
                        3'd6: ide_devhead <= bus_wdata[7:0];
                        3'd7: begin ide_cmd <= bus_wdata[7:0]; ide_cmd_count <= ide_cmd_count + 32'd1; end
                        default: ;
                    endcase
                end else begin
                    if (bus_addr[2:0] == 3'd0) ide_data_reads <= ide_data_reads + 32'd1;
                    if (bus_addr[2:0] == 3'd7) begin
                        ide_status <= ide_rdata[7:0]; status_seen <= 1'b1;
                        ide_status_reads <= ide_status_reads + 32'd1;
                    end
                end
            end
            if (io_acc) begin
                if (bus_write && bus_addr[3:0] == 4'd8) soundctl_w <= bus_wdata[15:0];
                if (!bus_write && bus_addr[3:0] == 4'd10) begin
                    soundstat_r <= io_rdata; soundstat_reads <= soundstat_reads + 32'd1;
                end
            end
            if (sd_rd && !sd_rd_q)   sd_rd_count    <= sd_rd_count + 32'd1;
            if (sd_ack && !sd_ack_q) sd_ack_count   <= sd_ack_count + 32'd1;
            if (!sd_ack && sd_ack_q) sectors_served <= sectors_served + 32'd1;
            if (sd_buff_wr)          sd_buff_wr_count <= sd_buff_wr_count + 32'd1;
            if (dcs_data_we) host_writes <= host_writes + 32'd1;
            if (dcs_data_rd) host_reads  <= host_reads + 32'd1;
            if (dcs_ack_we)  host_acks   <= host_acks + 32'd1;
            if (dsp_running && !dsp_running_q) dsp_releases <= dsp_releases + 32'd1;
            if (dsp_running) dsp_run_clk <= dsp_run_clk + 64'd1;
            if (dsp_retire)  dsp_retired <= dsp_retired + 64'd1;
            if (eng_wait) q_engine <= q_engine + 32'd1;
            if (dcs_wait) q_dcs    <= q_dcs + 32'd1;
        end
    end

    // ---------------- block B observers (DCS2 VS-hang debug) ----------------
    wire        d_pm_we   = dcs_dbg[0];
    wire [13:0] d_pm_wa   = dcs_dbg[14:1];
    wire [23:0] d_pm_wd   = dcs_dbg[38:15];
    wire        d_ir_we   = dcs_dbg[39];
    wire [8:0]  d_ir_wa   = dcs_dbg[48:40];
    wire [15:0] d_ir_wd   = dcs_dbg[64:49];
    wire [5:0]  d_imask   = dcs_dbg[70:65];
    wire [4:0]  d_icntl   = dcs_dbg[75:71];
    wire [5:0]  d_lt      = dcs_dbg[81:76];
    wire [3:0]  d_st      = dcs_dbg[85:82];
    wire        d_ack     = dcs_dbg[86];
    wire [2:0]  d_ack_i   = dcs_dbg[89:87];
    wire        d_hit     = dcs_dbg[90];
    wire        d_miss    = dcs_dbg[91];
    wire        d_fill    = dcs_dbg[92];
    wire        d_pfill   = dcs_dbg[93];
    wire        d_dwr     = dcs_dbg[94];
    wire        d_rep_we  = dcs_dbg[95];
    wire [15:0] d_rep_wd  = dcs_dbg[111:96];
    wire        irq2_pend = d_icntl[2] ? d_lt[2] : d_st[2];
    reg  [23:0] pm4;       reg [31:0] pm4_writes;
    reg  [15:0] dm382d;    reg [31:0] dm382d_writes;
    reg  [31:0] irq2_takes, irq2_pend_clk, irq2_mask_clk;
    reg  [31:0] host_count, reply_count;
    reg  [15:0] hring [0:7];
    reg  [15:0] rring [0:3];
    reg  [31:0] dbc_hits, dbc_misses, dbc_fills, dbc_pfills, dram_writes;
    reg  [13:0] pc_lo, pc_hi, pcmin_s, pcmax_s;
    reg  [31:0] pc_cnt, pcret_s;
    wire        snap;                                  // a publish starts on this clock (publisher below)
    integer     hk;
    always @(posedge clk) begin
        if (por) begin
            pm4 <= 24'd0; pm4_writes <= 32'd0; dm382d <= 16'd0; dm382d_writes <= 32'd0;
            irq2_takes <= 32'd0; irq2_pend_clk <= 32'd0; irq2_mask_clk <= 32'd0;
            host_count <= 32'd0; reply_count <= 32'd0;
            for (hk = 0; hk < 8; hk = hk + 1) hring[hk] <= 16'd0;
            for (hk = 0; hk < 4; hk = hk + 1) rring[hk] <= 16'd0;
            dbc_hits <= 32'd0; dbc_misses <= 32'd0; dbc_fills <= 32'd0; dbc_pfills <= 32'd0; dram_writes <= 32'd0;
            pc_lo <= 14'h3fff; pc_hi <= 14'd0; pc_cnt <= 32'd0;
            pcmin_s <= 14'h3fff; pcmax_s <= 14'd0; pcret_s <= 32'd0;
        end else begin
            if (d_pm_we && d_pm_wa == 14'd4) begin pm4 <= d_pm_wd; pm4_writes <= pm4_writes + 32'd1; end
            if (d_ir_we && d_ir_wa == 9'h02d) begin dm382d <= d_ir_wd; dm382d_writes <= dm382d_writes + 32'd1; end
            if (d_ack && d_ack_i == 3'd0) irq2_takes <= irq2_takes + 32'd1;
            if (irq2_pend) irq2_pend_clk <= irq2_pend_clk + 32'd1;
            if (irq2_pend && !d_imask[5]) irq2_mask_clk <= irq2_mask_clk + 32'd1;
            if (dcs_data_we) begin hring[host_count[2:0]] <= dcs_data_w; host_count <= host_count + 32'd1; end
            if (d_rep_we) begin rring[reply_count[1:0]] <= d_rep_wd; reply_count <= reply_count + 32'd1; end
            if (d_hit)   dbc_hits    <= dbc_hits + 32'd1;
            if (d_miss)  dbc_misses  <= dbc_misses + 32'd1;
            if (d_fill)  dbc_fills   <= dbc_fills + 32'd1;
            if (d_pfill) dbc_pfills  <= dbc_pfills + 32'd1;
            if (d_dwr)   dram_writes <= dram_writes + 32'd1;
            if (snap) begin
                pcmin_s <= pc_lo; pcmax_s <= pc_hi; pcret_s <= pc_cnt;
                if (dsp_retire) begin pc_lo <= dsp_pc; pc_hi <= dsp_pc; pc_cnt <= 32'd1; end
                else begin pc_lo <= 14'h3fff; pc_hi <= 14'd0; pc_cnt <= 32'd0; end
            end else if (dsp_retire) begin
                if (dsp_pc < pc_lo) pc_lo <= dsp_pc;
                if (dsp_pc > pc_hi) pc_hi <= dsp_pc;
                pc_cnt <= pc_cnt + 32'd1;
            end
        end
    end

    wire [7:0]  ideflags = {status_seen, sd_rd, sd_wr, sd_ack, img_mounted, img_readonly, ide_wait, 1'b0};
    wire [15:0] dcsflags = {dcs_run, dcs_reset_io, dcs_output_full, dcs_input_empty, dcs_rom_loaded,
                            dcs_cfg_unsupported, dsp_running, 9'd0};

    // speed counters (cumulative since por)
    reg  [31:0] poly_commits, page_flips, rbusy_clk;
    reg         dpage_q;
    always @(posedge clk) begin
        if (por) begin poly_commits <= 32'd0; page_flips <= 32'd0; rbusy_clk <= 32'd0; dpage_q <= 1'b0; end
        else begin
            if (poly_commit) poly_commits <= poly_commits + 32'd1;
            if (display_page != dpage_q) page_flips <= page_flips + 32'd1;
            if (rbusy) rbusy_clk <= rbusy_clk + 32'd1;
            dpage_q <= display_page;
        end
    end

    // disk-read diag counters (cumulative since por)
    reg  [6:0]  hold_rel;       // wg1_ide late_r rising edges (saturating)
    reg  [7:0]  err_ev;         // wg1_ide err_r rising edges (saturating)
    reg         late_q, err_q, adj_written;
    reg  [14:0] adj_val;
    reg  [31:0] lat_cur, lat_max;
    reg         lat_run;        // a request is outstanding: sd_rd|sd_wr rose, sd_ack has not yet fallen
    always @(posedge clk) begin
        if (por) begin
            hold_rel <= 7'd0; err_ev <= 8'd0; late_q <= 1'b0; err_q <= 1'b0; adj_written <= 1'b0; adj_val <= 15'd0;
            lat_cur <= 32'd0; lat_max <= 32'd0; lat_run <= 1'b0;
        end else begin
            late_q <= ide_late; err_q <= ide_err;
            if (ide_late && !late_q && hold_rel != 7'h7f) hold_rel <= hold_rel + 7'd1;
            if (ide_err && !err_q && err_ev != 8'hff) err_ev <= err_ev + 8'd1;
            if (adj_we) begin adj_written <= 1'b1; adj_val <= adj_wd[14:0]; end
            if ((sd_rd || sd_wr) && !lat_run) begin lat_run <= 1'b1; lat_cur <= 32'd1; end
            else if (lat_run) begin
                if (!sd_ack && sd_ack_q) begin
                    lat_run <= 1'b0;
                    if (lat_cur > lat_max) lat_max <= lat_cur;
                end else if (lat_cur != 32'hffffffff) lat_cur <= lat_cur + 32'd1;
            end
        end
    end

    reg  [63:0] wv;             // word(idx) -- the live value of data word i (A 1..22, B 33..46)
    reg  [5:0]  nidx;
    always @(*) begin
        case (nidx)
            6'd1:  wv = wall;
`ifdef MUT_MIRROR_SWAP
            6'd2:  wv = guest_tick;                                     // mutant: words 2 and 8 swapped
            6'd8:  wv = instructions;
`else
            6'd2:  wv = instructions;
            6'd8:  wv = guest_tick;
`endif
            6'd3:  wv = {8'd0, retire_pc, flags, cpu_pc};
            6'd4:  wv = {int0_count, presented_frames};
            6'd5:  wv = {c31_st, c31_ie};
            6'd6:  wv = {c31_if, c31_iof};
            6'd7:  wv = {xf1_copies, faults};
            6'd9:  wv = {ide_cmd, ide_status, ide_seccnt, ideflags, sd_lba};
            6'd10: wv = {ide_devhead, ide_cyl_hi, ide_cyl_lo, ide_secnum, ide_cmd_count};
`ifdef MUT_MIRROR_SWAP_IDE
            6'd11: wv = {sd_ack_count, sd_rd_count};                    // mutant: the two halves swapped
`else
            6'd11: wv = {sd_rd_count, sd_ack_count};
`endif
            6'd12: wv = {sectors_served, ide_data_reads};
            6'd13: wv = {img_size[31:0], ide_accesses};
            6'd14: wv = {ide_status_reads, sd_buff_wr_count};
            6'd15: wv = {soundctl_w, soundstat_r, soundstat_reads};
            6'd16: wv = {dcsflags, 2'b00, dsp_pc, dcs_control, dcs_data_r};
            6'd17: wv = {host_writes, host_reads};
            6'd18: wv = {host_acks, dsp_releases};
            6'd19: wv = dsp_retired;
            6'd20: wv = dsp_run_clk;
            6'd21: wv = {dac_underruns, md_words};
            6'd22: wv = {q_engine, q_dcs};
            // ---- block B ----
            6'd33: wv = {pm4_writes, 8'd0, pm4};
            6'd34: wv = {dm382d_writes, 16'd0, dm382d};
            6'd35: wv = {irq2_takes, 4'd0, d_st, 2'd0, d_lt, 3'd0, d_icntl, 2'd0, d_imask};
            6'd36: wv = {irq2_mask_clk, irq2_pend_clk};
`ifdef MUT_MIRROR_SWAP_DCS
            6'd37: wv = {2'd0, pcmax_s, 2'd0, pcmin_s, pcret_s};        // mutant: pc_min / pc_max swapped
`else
            6'd37: wv = {2'd0, pcmin_s, 2'd0, pcmax_s, pcret_s};
`endif
            6'd38: wv = {host_count, reply_count};
            6'd39: wv = {hring[3], hring[2], hring[1], hring[0]};
            6'd40: wv = {hring[7], hring[6], hring[5], hring[4]};
            6'd41: wv = {rring[3], rring[2], rring[1], rring[0]};
            6'd42: wv = {dbc_hits, dbc_misses};
            6'd43: wv = {dbc_fills, dbc_pfills};
            6'd44: wv = {dram_writes, ide_hold_fault, hold_rel, err_ev, adj_written, adj_val};
`ifdef MUT_MIRROR_SWAP_POLY
            6'd45: wv = {page_flips, poly_commits};                      // mutant: the two halves swapped
`else
            6'd45: wv = {poly_commits, page_flips};
`endif
            6'd46: wv = {rbusy_clk, lat_max};
            default: wv = 64'd0;
        endcase
    end

    // ---------------- publisher ----------------
    reg [31:0] tick, seq;
    reg [5:0]  idx;
    reg        busy, blk_b, cmt;
    always @(*) nidx = idx + 6'd1;
    assign snap = !busy && tick == PERIOD - 1 && enable;

    always @(posedge clk) begin
        if (por) begin
            tick <= 32'd0; seq <= 32'd0; idx <= 6'd0; busy <= 1'b0; blk_b <= 1'b0; cmt <= 1'b0;
            write <= 1'b0; address <= 32'd0; writedata <= 64'd0;
        end else if (!busy) begin
            tick <= (tick == PERIOD - 1) ? 32'd0 : tick + 32'd1;
            if (snap) begin
                seq <= seq + 32'd1;                        // odd: block A being updated
                busy <= 1'b1; idx <= 6'd0; blk_b <= 1'b0; cmt <= 1'b0;
                write <= 1'b1; address <= BASE; writedata <= {MAGIC, seq + 32'd1};
            end
        end else if (write && !waitrequest) begin
            // accepted: offer the next word (the offered command never changes while waitrequest is high)
            if (blk_b && cmt) begin
                write <= 1'b0; busy <= 1'b0;
            end else if (cmt) begin                        // A committed: open B with the odd seq
                blk_b <= 1'b1; cmt <= 1'b0; idx <= OPEN_B;
                address <= BASE + {23'd0, OPEN_B, 3'd0}; writedata <= {MAGIC_D, seq - 32'd1};
            end else if (idx == LAST_A) begin
                cmt <= 1'b1;                               // commit: word 0 := the same even seq as word 23
                address <= BASE; writedata <= {MAGIC, seq};
            end else if (idx == LAST_A - 6'd1) begin
                idx <= LAST_A; seq <= seq + 32'd1;         // even: close the block
                address <= BASE + {23'd0, LAST_A, 3'd0}; writedata <= {MAGIC, seq + 32'd1};
            end else if (idx == LAST_B) begin
                cmt <= 1'b1;                               // commit: word 32 := the same even seq as word 47
                address <= BASE + {23'd0, OPEN_B, 3'd0}; writedata <= {MAGIC_D, seq};
            end else if (idx == LAST_B - 6'd1) begin
                idx <= LAST_B;                             // B closer: seq is already even
                address <= BASE + {23'd0, LAST_B, 3'd0}; writedata <= {MAGIC_D, seq};
            end else begin
                idx <= nidx;
                address <= BASE + {23'd0, nidx, 3'd0};
                writedata <= wv;
            end
        end
    end
endmodule
`default_nettype wire
