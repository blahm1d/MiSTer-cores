// SPDX-License-Identifier: GPL-2.0-or-later
// wg1_xf1_copy -- War Gods "RAM grossness": on each XF1 falling edge copy 0x20000 words fastram -> main RAM.
// Gospel (MAME 0.289):
//   midvunit.cpp:648-657  midvplus_xf1_w(data): if (m_lastval && !data) memcpy(m_ram_base, m_fastram_base, 0x20000*4);
//                         m_lastval = data.   m_lastval is never reset by machine_reset (midvunit.h:283, :101, :106-121)
//   tms320c3x 320c3x_ops.ipp:100-117 update_special: every instruction that writes IOF calls xf1_cb((IOF >> 6) & 1)
//                         when (IOF & 0x020) (I/OXF1 = output); tms320c3x.cpp:625 reset: IOF = 0, no callback.
// Measured (bandwidth/wg1/gospel/xf1/xf1_report.md, verifier CONFIRMED): exactly one falling edge per cold boot (26.571 s,
// on-chip stub 0x809806 `LDI $22,IOF`, then a jump into the copied program at 0x18000); fastram is never touched again.
// Fabric: the copy is done by this engine as a bus master in front of the C31 memory tier (so the main-RAM page cache
// stays coherent), while the CPU is held (hold = 1). MAME's memcpy takes zero guest time; the engine stalls the CPU for
// ~0.26M tier accesses once per boot and pauses guest time for it, so the game observes no difference.
// Detection: IOF comes from the core's live architectural state (snap). A change of IOF with IOF[5] set is a callback
// with value IOF[6] (a write that leaves IOF unchanged calls back with value == m_lastval, which cannot be an edge).
`default_nettype none
module wg1_xf1_copy #(
    parameter [23:0] SRC = 24'h400000,
    parameter [23:0] DST = 24'h000000,
    parameter [17:0] WORDS = 18'h20000
) (
    input  wire        clk,
    input  wire        reset,             // game reset: does NOT clear lastval (m_lastval survives machine_reset)
    input  wire        por,               // power-on: lastval = 0 (m_lastval initial value)
    input  wire [31:0] iof,               // live IOF register (core snap_state, register 24)
    input  wire        core_bus_idle,     // the core has no memory access outstanding
    output reg         hold,              // hold the CPU (and pause guest time) while copying
    output reg         busy,              // the engine owns the memory-tier bus port
    // memory-tier bus master (same handshake as the core's bus: held until ready)
    output reg         m_valid,
    output reg         m_write,
    output reg  [23:0] m_addr,
    output reg  [31:0] m_wdata,
    input  wire        m_ready,
    input  wire [31:0] m_rdata,
    output reg  [31:0] copies            // completed copies (diagnostic)
);
    reg        lastval;
    reg [31:0] iof_q;
    reg        pend;                      // a falling edge seen, waiting for the core bus to go idle
    reg [17:0] i;
    reg        rd_phase;
    wire       cb    = (iof != iof_q) && iof[5];          // callback fires with value iof[6]
    wire       fall  = cb && lastval && !iof[6];
    always @(posedge clk) begin
        if (por) begin
            lastval <= 1'b0; iof_q <= 32'd0; pend <= 1'b0; hold <= 1'b0; busy <= 1'b0; m_valid <= 1'b0;
            m_write <= 1'b0; m_addr <= 24'd0; m_wdata <= 32'd0; i <= 18'd0; rd_phase <= 1'b0; copies <= 32'd0;
        end else begin
            iof_q <= iof;
            if (reset) begin
                // machine_reset: IOF = 0 without a callback; lastval kept; no copy in flight across a reset
                pend <= 1'b0; hold <= 1'b0; busy <= 1'b0; m_valid <= 1'b0;
            end else begin
                if (cb) lastval <= iof[6];
                if (fall) begin pend <= 1'b1; hold <= 1'b1; end
                if (pend && !busy && core_bus_idle) begin
                    busy <= 1'b1; i <= 18'd0; rd_phase <= 1'b1;
                    m_valid <= 1'b1; m_write <= 1'b0; m_addr <= SRC;
                end else if (busy && m_valid && m_ready) begin
                    if (rd_phase) begin
                        rd_phase <= 1'b0; m_write <= 1'b1; m_addr <= DST + {6'd0, i}; m_wdata <= m_rdata;
                    end else if (i == WORDS - 18'd1) begin
                        m_valid <= 1'b0; busy <= 1'b0; pend <= 1'b0; hold <= 1'b0; copies <= copies + 32'd1;
                    end else begin
                        rd_phase <= 1'b1; m_write <= 1'b0; i <= i + 18'd1; m_addr <= SRC + {6'd0, i + 18'd1};
                    end
                end
            end
        end
    end
endmodule
`default_nettype wire
