// wg1_pic2.sv -- Midway serial PIC 2 (security serial number, clock, 256-byte NVRAM) behind the War Gods I/O ASIC.
// Transcribed from MAME 0.289 williams/midwayic.cpp: status_r :418-437, read :440-459, write :462-632,
// nvram_default :634-637. midway_ioasic_device IS-A midway_serial_pic2_device (:702-703); PICOUT/PICIN reach it
// through the ASIC (:1092-1093, :1222-1228).
// FORK (wg1 War Gods core, 2026-09-24) of D:/deck/fpga/cruisinusa/bandwidth/gm1/rtl/gm1_pic2.sv
// (md5 b573c40c82cdd411d8369e6c802faf71; itself a fork of zeus/zeus1/rtl/board/zk4_pic2.sv). Changes:
//   * NVRAM power-on contents = init_wargods' default (midvunit.cpp:2244-2257): 0xFF everywhere except
//     0x0e/0x2e=0x67, 0x0f/0x2f=0x32, 0x10/0x30=0x0a, 0x11/0x31=0x00, 0x12/0x32=0xaf, 0x17/0x37=0xd8, 0x18/0x38=0xe7
//     (MAME applies it when no nvram file exists: device_nvram_interface -> nvram_default :634-637).
//   * serial bytes stay the runtime input `ser` (generate_serial_data is computed in wg1_ioasic.sv).
// Time: the latch's data-ready flag expires 1 ms after a write (:472, :427); a written clock is parroted back for
// 500 ms (:559-560). Both measured in clk periods of CLK_HZ.
// Interface: pic_wr (one clk, PICOUT write, byte), pic_rd (one clk, PICIN read: returns {status, data} and applies
// status_r's side effect), rtc the clock bytes in MAME's shape (BCD sec, min, hour, weekday+1, mday, month+1,
// year-1900-yearoffs).
module wg1_pic2 #(
  parameter int          CLK_HZ = 50_000_000
) (
  input  logic        clk, rst,
  input  logic [127:0] ser,                                   // generate_serial_data bytes, byte i at [8*i +: 8]
  input  logic        pic_wr, input logic [7:0] pic_wdata,
  input  logic        pic_rd, output logic [15:0] pic_rdata,   // {7'b0, status, data} (ioasic PICIN, :1093)
  input  logic [7:0]  rtc0, rtc1, rtc2, rtc3, rtc4, rtc5, rtc6
);
  // ---------------- state ----------------
  localparam int MS = CLK_HZ / 1000;
  logic [11:0] latch;
  logic [$clog2(MS+1)-1:0] l_age; logic l_expired;                // clocks since the last write, saturating at 1 ms
  logic [7:0]  st;
  logic [4:0]  idx, tot;
  logic [7:0]  buffer [16];
  logic [7:0]  time_buf [7]; logic [2:0] tidx;
  logic        tjw; logic [$clog2(500*MS+1)-1:0] tjw_cnt;          // time_just_written, 500 ms
  logic [7:0]  nv_addr;
  logic [7:0]  rtc [7];
  assign rtc[0] = rtc0; assign rtc[1] = rtc1; assign rtc[2] = rtc2; assign rtc[3] = rtc3;
  assign rtc[4] = rtc4; assign rtc[5] = rtc5; assign rtc[6] = rtc6;
  // NVRAM: 256 x 8, one write port, registered read (M10K / MLAB shape); power-on = init_wargods default
  logic        nv_we; logic [7:0] nv_wa, nv_wd, nv_ra, nv_q;
  logic [7:0]  nvram [256];
  initial begin
    for (int i = 0; i < 256; i++) nvram[i] = 8'hFF;              // memset(default_nvram, 0xff) midvunit.cpp:2247
    nvram[8'h0e] = 8'h67; nvram[8'h2e] = 8'h67;                  // :2248
    nvram[8'h0f] = 8'h32; nvram[8'h2f] = 8'h32;                  // :2249
    nvram[8'h10] = 8'h0a; nvram[8'h30] = 8'h0a;                  // :2250
    nvram[8'h11] = 8'h00; nvram[8'h31] = 8'h00;                  // :2251
    nvram[8'h12] = 8'haf; nvram[8'h32] = 8'haf;                  // :2252
    nvram[8'h17] = 8'hd8; nvram[8'h37] = 8'hd8;                  // :2253
    nvram[8'h18] = 8'he7; nvram[8'h38] = 8'he7;                  // :2254
  end
  always_ff @(posedge clk) begin if (nv_we) nvram[nv_wa] <= nv_wd; nv_q <= nvram[nv_ra]; end
  logic        nv_fill, nv_fill2;                                 // read command: address registered, RAM read, then buffer[0]
  // the low nibble written at step 0x35 (the 0x45 step ORs the high nibble onto it, :589 / :595)
  logic [3:0]  nv_lo;
  always_ff @(posedge clk) if (pic_wr && pic_wdata[4] && st == 8'h35) nv_lo <= pic_wdata[3:0];

  assign l_expired = l_age == ($clog2(MS+1))'(MS);
  // read (:440-459) and status_r (:418-437): PICIN = read() | status_r() << 8; read() sees the latch BEFORE
  // status_r's side effect (operands evaluated left to right; checked against MAME's log by the device gate)
  always_comb begin
    logic [7:0] d;
    if (latch[11:8] != 4'd0) d = latch[7:0];
    else if (idx < tot)      d = 8'hFF;
    else                     d = 8'h00;
    pic_rdata = {7'd0, latch[11:8] != 4'd0, d};
  end

  always_ff @(posedge clk)
    if (rst) begin
      latch <= '0; l_age <= '0; st <= '0; idx <= '0; tot <= '0; tidx <= '0; tjw <= 1'b0; tjw_cnt <= '0;
      nv_addr <= '0; nv_we <= 1'b0; nv_fill <= 1'b0; nv_fill2 <= 1'b0; nv_wa <= '0; nv_wd <= '0; nv_ra <= '0;
      for (int i = 0; i < 16; i++) buffer[i] <= 8'h00;
      for (int i = 0; i < 7; i++) time_buf[i] <= 8'h00;
    end else begin
      nv_we <= 1'b0;
      if (!l_expired) l_age <= l_age + 1'b1;
      if (tjw) begin if (tjw_cnt == '0) tjw <= 1'b0; else tjw_cnt <= tjw_cnt - 1'b1; end
      nv_fill2 <= nv_fill; nv_fill <= 1'b0;
      if (nv_fill2) buffer[0] <= nv_q;                           // nv_ra set at the command edge, nv_q one edge later
      if (pic_rd) begin                                          // status_r side effect
        if (latch[11:8] != 4'd0) begin
          if (l_expired) latch <= {4'd0, latch[7:0]};
          else latch <= latch - 12'h100;
        end
      end
      if (pic_wr) begin : wr
        logic [11:0] nl; logic [3:0] cmd;
        nl = {4'h4, 4'h8, pic_wdata[3:0]};                      // (data & 0x00f) | 0x480
        latch <= nl; l_age <= '0;
        cmd = (st != 8'd0) ? st[3:0] : nl[3:0];
        if (pic_wdata[4]) begin
          case (cmd)
            4'd0: if (idx < tot) begin latch <= {4'h4, buffer[idx[3:0]]}; idx <= idx + 1'b1; end
            4'd1: if (idx < tot) begin latch <= {4'h4, buffer[idx[3:0]]}; idx <= idx + 1'b1; end
                  else begin for (int i = 0; i < 16; i++) buffer[i] <= ser[8*i +: 8]; tot <= 5'd16; idx <= '0; end
            4'd3: begin
                    idx <= '0; tot <= 5'd7;
                    for (int i = 0; i < 7; i++) buffer[i] <= tjw ? time_buf[i] : rtc[i];
                  end
            4'd4: if (st == 8'h00) begin st <= 8'h14; tidx <= '0; end
                  else if (st == 8'h14) begin time_buf[tidx] <= {4'd0, nl[3:0]}; st <= 8'h24; end
                  else if (st == 8'h24) begin
                    time_buf[tidx] <= time_buf[tidx] | {nl[3:0], 4'd0};
                    if (tidx + 1'b1 < 3'd7) begin tidx <= tidx + 1'b1; st <= 8'h14; end
                    else begin tidx <= tidx + 1'b1; tjw <= 1'b1; tjw_cnt <= ($clog2(500*MS+1))'(500 * MS); st <= 8'h00; end
                  end
            4'd5: if (st == 8'h00) st <= 8'h15;
                  else if (st == 8'h15) begin nv_addr <= {4'd0, nl[3:0]}; st <= 8'h25; end
                  else if (st == 8'h25) begin nv_addr <= nv_addr | {nl[3:0], 4'd0}; st <= 8'h35; end
                  else if (st == 8'h35) begin nv_we <= 1'b1; nv_wa <= nv_addr; nv_wd <= {4'd0, nl[3:0]}; st <= 8'h45; end
                  else if (st == 8'h45) begin nv_we <= 1'b1; nv_wa <= nv_addr; nv_wd <= {nl[3:0], nv_lo}; st <= 8'h00; end
            4'd6: if (st == 8'h00) st <= 8'h16;
                  else if (st == 8'h16) begin nv_addr <= {4'd0, nl[3:0]}; st <= 8'h26; end
                  else if (st == 8'h26) begin
                    st <= 8'h00; tot <= 5'd1; idx <= '0;
                    nv_ra <= nv_addr | {nl[3:0], 4'd0}; nv_fill <= 1'b1;   // buffer[0] = nvram[addr] next clk
                  end
            4'd8: latch <= {4'h4, ~{4'd0, cmd}};
            default: ;
          endcase
        end
      end
    end
endmodule
