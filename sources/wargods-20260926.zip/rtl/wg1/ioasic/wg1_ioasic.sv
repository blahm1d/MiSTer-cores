// wg1_ioasic.sv -- the Midway I/O ASIC of War Gods (MAME 0.289 midway_ioasic_device as midvplus configures it).
// Gospel: segamodel1/references/mame-mame0289/src/mame/williams/midwayic.cpp (register enum :660-678, device_start
// :733-783, ioasic_reset :791-800, update_ioasic_irq :803-826, ioasic_input_empty/output_full :841-860, FIFO
// :870-986, read :1007-1104, write :1132-1252) and williams/midvunit.cpp midvplus() :1233-1262: map 0x990000-0x99000f
// = read/write (:729), in ports 0-3 = DIPS / SYSTEM / IN1 / IN2 (:1245-1248), DCS2 attached (:1249), shuffle type 0
// (:1250, the identity map :738), upper 452 (:1251), yearoffs 94 (:1252); init_wargods default PIC NVRAM
// (:2244-2257, in wg1_pic2.sv); GAME() year 1995 (:2295). Inputs = INPUT_PORTS_START( wargods ) (:1046-1147).
// FORK (wg1, 2026-09-24) of D:/deck/fpga/zeus/zeus1/rtl/board/zk4_ioasic.sv (Zeus LIVE, md5
// 0a9647673634bc45384ab54160804775) re-keyed for War Gods; the serial function is from
// D:/deck/fpga/cruisinusa/bandwidth/gm1/rtl/gm1_family_io.sv (md5 see README), the PIC from gm1_pic2.sv.
// Delta vs zk4 (all MAME-cited):
//   * shuffle_default 0 on War Gods (constructor :712, midvplus sets none): m_shuffle_active starts 0 and becomes 1 on
//     the PORT0 write of 0xe2 (:1147-1155). While inactive: register writes are NOT stored (COMBINE_DATA only when
//     active, :1138-1139), so SOUNDCTL/SOUNDOUT/PICOUT act on the stale register (newreg = m_reg[offset], :1140) and
//     PORT0 reads 0x2001 (:1019-1023).
//   * INTSTAT is MAME's SNAPSHOT m_reg[14], rewritten only when update_ioasic_irq runs (:816): DCS callback level
//     changes, UARTIN read, UARTOUT write, SOUNDCTL write with bit 2 clear (fifo_reset_w(1) :1207 -> :955), INTCTL
//     write, DCS fifo_reset_w(1); a CPU write to UARTIN (COMBINE_DATA) does NOT refresh it.
//   * the ASIC sound FIFO has no writer on midvplus (fifo_w / fifo_full_w have no caller in midvunit.cpp), so
//     m_fifo_bytes == 0 and m_force_fifo_full == 0 for ever: get_fifo_status() = 0x0008 (:910-915), fifo_r() = 0
//     with no side effect (:875), and the empty-PC kludge (:892-896, :930-939) never arms. MAME-unreachable state is
//     not built (DESIGN-RULES.md s7); fifo_rd / fifo_reset_w keep their C2 meaning.
//   * the IRQ output is not wired on midvplus (no irq_handler() in midvunit.cpp): computed like m_irq_state, exported.
//   * UART: registers + loopback per :1042-1053, :1165-1187 (War Gods runs the loopback self-test once).
//   * m_auto_ack = 0 on midvplus (constructor :717, no set_auto_ack): SOUNDIN reads do not ack (:1079-1080).
// C1 bus (contracts/CONTRACTS.md): combinational hit/ready/rdata, side effects once on accept.
// C2 DCS host port: see CONTRACTS.md. dcs_reset carries reset_w's argument (SOUNDCTL bit 0, :1194): 1 = run, 0 = hold
// in reset (dcs.cpp:1456-1470). EXTRA output dcs_data_rd (one clk, SOUNDIN read): dcs.cpp data_r() :1626-1638 clears
// m_last_output_full on a host read, which the sound board needs to drive dcs_output_full; C2 has no such strobe.
// Inputs: active-high "pressed" controls, packed here into MAME's active-low port words.
module wg1_ioasic #(
  parameter int          CLK_HZ          = 50_000_000,
  parameter int          UPPER           = 452,          // midvunit.cpp:1251
  parameter int          YEAR            = 1995,         // GAME() midvunit.cpp:2295 (atoi(system().year), :75)
  parameter int          SERIAL_DIGIT    = 6,            // pic_serial_adjust default, midwayic.cpp:48
  parameter logic [7:0]  RAND12          = 8'hF2,        // machine().rand() pair (:93-94): War Gods cold-boot logs
  parameter logic [7:0]  RAND13          = 8'hBE,        //   (tools/wg_serial_golden.py: MATCH)
  parameter int          SHUFFLE_TYPE    = 0,            // midvunit.cpp:1250
  parameter bit          SHUFFLE_DEFAULT = 1'b0,         // midwayic.cpp:712 (midvplus sets none)
  parameter bit          AUTO_ACK        = 1'b0          // midwayic.cpp:717 (midvplus sets none)
) (
  input  logic        clk,
  input  logic        reset,
  // C1 -- C31 external-bus slave
  input  logic        bus_valid, bus_write, bus_sync,
  input  logic [23:0] bus_addr,
  input  logic [31:0] bus_wdata,
  output logic        hit,
  output logic        ready,
  output logic [31:0] rdata,
  output logic        guest_wait,
  // inputs (pressed = 1). DIPS = the switch word exactly as MAME's port (switch "off" = 1), midvunit.cpp:1047-1099
  input  logic [15:0] dips,
  input  logic [3:0]  coin,          // Coin 1..4
  input  logic [3:0]  start,         // 1..4 Player(s) Start
  input  logic        tilt, test_sw, service1, vol_down, vol_up, bill,   // test_sw = PORT_SERVICE_NO_TOGGLE 0x0010
  input  logic [9:0]  p1, p2,        // {b6, b5, b4, b3, b2, b1, right, left, down, up}
  input  logic [64:0] mister_rtc,    // hps_io RTC: BCD sec, min, hour, mday, month, year%100, binary weekday
  // C2 -- DCS2 host port
  output logic        dcs_reset,
  output logic        dcs_data_we,
  output logic [15:0] dcs_data_w,
  output logic        dcs_ack_we,
  output logic        dcs_data_rd,   // extra (see header)
  input  logic        fifo_rd,
  input  logic        fifo_reset_w,
  output logic [15:0] fifo_q,
  output logic [15:0] fifo_status,
  input  logic [15:0] dcs_data_r,
  input  logic [15:0] dcs_data2_r,
  input  logic [15:0] dcs_control,
  input  logic        dcs_output_full,
  input  logic        dcs_input_empty,
  output logic        irq
);
  localparam logic [3:0] PORT0 = 4'd0, UARTCTL = 4'd4, UARTOUT = 4'd5, UARTIN = 4'd6, SOUNDCTL = 4'd8,
                         SOUNDOUT = 4'd9, SOUNDSTAT = 4'd10, SOUNDIN = 4'd11, PICOUT = 4'd12, PICIN = 4'd13,
                         INTSTAT = 4'd14, INTCTL = 4'd15;
  localparam logic [15:0] FIFO_ST = 16'h0008;         // get_fifo_status() with m_fifo_bytes == 0, no force-full

  // ---------------- serial number (generate_serial_data, midwayic.cpp:73-121) ----------------
  function automatic [127:0] serial_data(input integer upper, input integer year, input integer digit,
                                         input [7:0] r12, input [7:0] r13);
    reg [127:0] v; integer sn, t, s0, s1, s2, s3, s4, s5, s6, s7, s8;
    begin
      sn = 123450 + upper * 1000000 + (digit & 15);
      s0 = (sn / 100000000) % 10; s1 = (sn / 10000000) % 10; s2 = (sn / 1000000) % 10;
      s3 = (sn / 100000) % 10;    s4 = (sn / 10000) % 10;    s5 = (sn / 1000) % 10;
      s6 = (sn / 100) % 10;       s7 = (sn / 10) % 10;       s8 = sn % 10;
      v = 128'd0;
      v[8*12 +: 8] = r12; v[8*13 +: 8] = r13;
      t = 32'h174 * (year - 1980) + 32'h1f * (12 - 1) + 11;
      v[8*10 +: 8] = t[15:8]; v[8*11 +: 8] = t[7:0];
      t = s4 + s7 * 10 + s1 * 100;
      t = (t + 5 * r13) * 32'h1bcd + 32'h1f3f0;
      v[8*7 +: 8] = t[7:0]; v[8*8 +: 8] = t[15:8]; v[8*9 +: 8] = t[23:16];
      t = s6 + s8 * 10 + s0 * 100 + s2 * 10000;
      t = (t + 2 * r13 + r12) * 32'h107f + 32'h71e259;
      v[8*3 +: 8] = t[7:0]; v[8*4 +: 8] = t[15:8]; v[8*5 +: 8] = t[23:16]; v[8*6 +: 8] = t[31:24];
      t = s5 * 10 + s3 * 100;
      t = (t + r12) * 32'h245 + 32'h3d74;
      v[8*0 +: 8] = t[7:0]; v[8*1 +: 8] = t[15:8]; v[8*2 +: 8] = t[23:16];
      serial_data = v;
    end
  endfunction
  localparam logic [127:0] SER = serial_data(UPPER, YEAR, SERIAL_DIGIT, RAND12, RAND13);

  // ---------------- shuffle maps (midwayic.cpp:736-747) ----------------
  function automatic [3:0] shuffle(input integer ty, input [3:0] o);
    reg [63:0] m;                                           // entry i at [4*i +: 4]
    begin
      case (ty)
        1: m = 64'hCDEF_0123_89AB_7654;                     // Blitz, Blitz99
        2: m = 64'hBA98_654F_EDC1_0237;                     // Carnevil
        3: m = 64'h7654_DCEF_3210_BA98;                     // Calspeed, Gauntlet Legends
        4: m = 64'h0132_BA89_7654_CDEF;                     // Mace
        5: m = 64'h465A_B987_3210_FEDC;                     // Gauntlet Dark Legacy
        6: m = 64'hFECD_BA98_3102_6547;                     // Vapor TRX
        7: m = 64'hFECD_BA98_3102_6547;                     // SF Rush: The Rock
        8: m = 64'hFEDC_98BA_7654_0321;                     // Hyperdrive
        default: m = 64'hFEDC_BA98_7654_3210;               // 0: WarGods, WG3DH, SFRush, MK4 (identity)
      endcase
      shuffle = m[4*o +: 4];
    end
  endfunction

  // ---------------- input ports (INPUT_PORTS_START( wargods ), midvunit.cpp:1101-1147; active low) ----------------
  logic [15:0] port_sys, port_in1, port_in2;
  assign port_sys = ~{bill, 2'b00, vol_up, vol_down, start[3], start[2], coin[3], coin[2], service1, start[1],
                      test_sw, tilt, start[0], coin[1], coin[0]};
  assign port_in1 = ~{1'b0, p2[4], p2[6], p2[5], p2[3], p2[2], p2[1], p2[0],
                      1'b0, p1[4], p1[6], p1[5], p1[3], p1[2], p1[1], p1[0]};
  assign port_in2 = ~{9'd0, p2[9], p2[7], p2[8], 1'b0, p1[9], p1[7], p1[8]};

  // ---------------- state ----------------
  logic [31:0] r [16];                                      // m_reg
  logic        shuf;                                        // m_shuffle_active
  logic [7:0]  sirq;                                        // m_sound_irq_state (bits 7, 6)
  logic        irq_q;                                       // m_irq_state
  logic        run_q;                                       // last reset_w() argument
  logic        fr_d;                                        // fifo_reset_w, previous clock

  wire  [3:0]  off = bus_addr[3:0];
  wire  [3:0]  a   = shuf ? shuffle(SHUFFLE_TYPE, off) : off;   // :1011 / :1134
  assign hit        = bus_addr[23:4] == 20'h99000;
  assign ready      = hit;                                   // every register answers in the same clock
  assign guest_wait = 1'b0;
  wire         acc  = bus_valid && bus_sync && ready;

  // ---------------- PIC2 ----------------
  wire  [31:0] newreg = shuf ? bus_wdata : r[a];            // :1135-1140 (full 32-bit mem_mask on the C31)
  logic [15:0] pic_q;
  wire  [3:0]  ylo = mister_rtc[43:40], yhi = mister_rtc[47:44];
  wire  [4:0]  ylo6 = {1'b0, ylo} + 5'd6;                    // year - 1900 - 94 = year%100 + 6 (BCD), :517
  wire  [7:0]  year_b = (ylo6 >= 5'd10) ? {yhi + 4'd1, ylo6[3:0] - 4'd10} : {yhi, ylo6[3:0]};
  wg1_pic2 #(.CLK_HZ(CLK_HZ)) u_pic2 (.clk(clk), .rst(reset), .ser(SER),
    .pic_wr(acc && bus_write && a == PICOUT), .pic_wdata(newreg[7:0]),        // SHUFFLE_STANDARD: no xor (:1222-1228)
    .pic_rd(acc && !bus_write && a == PICIN), .pic_rdata(pic_q),
    .rtc0(mister_rtc[7:0]), .rtc1(mister_rtc[15:8]), .rtc2(mister_rtc[23:16]),
    .rtc3({4'd0, mister_rtc[51:48] + 4'd1}),                                   // weekday + 1
    .rtc4(mister_rtc[31:24]), .rtc5(mister_rtc[39:32]), .rtc6(year_b));

  // ---------------- read (:1007-1104) ----------------
  always_comb begin
    rdata = r[a];
    case (a)
      PORT0:     rdata = shuf ? {16'd0, dips} : 32'h0000_2001;
      4'd1:      rdata = {16'd0, port_sys};
      4'd2:      rdata = {16'd0, port_in1};
      4'd3:      rdata = {16'd0, port_in2};
      SOUNDSTAT: rdata = {16'd0, (((dcs_control >> 4) ^ 16'h0040) & 16'h00c0) | (FIFO_ST & 16'h0038)
                                 | (dcs_data2_r & 16'hff00)};
      SOUNDIN:   rdata = {16'd0, dcs_data_r};
      PICIN:     rdata = {16'd0, pic_q};
      default: ;
    endcase
  end

  // irqbits (:805-814) for a given sound-irq / UARTIN state; the FIFO is always empty (0x0008)
  function automatic [15:0] irqbits(input [7:0] s, input [31:0] u);
    irqbits = 16'h2000 | {8'd0, s} | (u[15:0] & 16'h3f00) | 16'h0008 | 16'h0001;
  endfunction

  // ---------------- state update ----------------
  assign dcs_reset   = run_q;
  assign fifo_status = FIFO_ST;
  assign irq         = irq_q;

  always_ff @(posedge clk) begin
    if (reset) begin
      for (int i = 0; i < 16; i++) r[i] <= 32'd0;
      r[SOUNDCTL] <= 32'h0000_0001;                         // device_start :768
      r[INTSTAT]  <= {16'd0, irqbits(8'h80, 32'd0)};        // ioasic_reset -> update_ioasic_irq :798
      shuf <= SHUFFLE_DEFAULT; sirq <= 8'h80; irq_q <= 1'b0; run_q <= 1'b1; fr_d <= 1'b0;
      dcs_data_we <= 1'b0; dcs_data_w <= 16'd0; dcs_ack_we <= 1'b0; dcs_data_rd <= 1'b0; fifo_q <= 16'd0;
    end else begin : upd_blk
      logic [31:0] u_n, ic_n; logic [7:0] s_n; logic upd; logic [15:0] ib;
      u_n = r[UARTIN]; ic_n = r[INTCTL]; s_n = sirq; upd = 1'b0;
      dcs_data_we <= 1'b0; dcs_ack_we <= 1'b0; dcs_data_rd <= 1'b0;
      fr_d <= fifo_reset_w;
      if (fifo_rd) fifo_q <= 16'd0;                          // fifo_r() with an empty FIFO (:872-875)
      // DCS set_io_callbacks (:841-860): a level change is a callback -> update
      if (dcs_input_empty != sirq[7]) begin s_n[7] = dcs_input_empty; upd = 1'b1; end
      if (dcs_output_full != sirq[6]) begin s_n[6] = dcs_output_full; upd = 1'b1; end
      if (fifo_reset_w && !fr_d) upd = 1'b1;                 // DCS fifo_reset_w(1) -> update (:949-955)
      if (acc && !bus_write) begin
        if (a == UARTIN) begin                               // :1042-1053
          u_n = r[UARTIN] & ~32'h0000_1000;
          if (r[UARTIN][7:0] == 8'h0d) u_n = 32'h0000_300a;
          upd = 1'b1;
        end
        if (a == SOUNDIN) begin                              // :1072-1082
          dcs_data_rd <= 1'b1;
          if (AUTO_ACK) dcs_ack_we <= 1'b1;
        end
      end
      if (acc && bus_write) begin
        if (shuf) begin                                      // COMBINE_DATA only while shuffling (:1138-1139)
          r[a] <= bus_wdata;
          if (a == UARTIN) u_n = bus_wdata;
          if (a == INTCTL) ic_n = bus_wdata;
        end
        case (a)
          PORT0: if (bus_wdata == 32'h0000_00e2) begin       // :1147-1155
                   shuf <= 1'b1; ic_n = 32'd0; r[UARTCTL] <= 32'd0;
                 end
          UARTOUT: begin                                     // :1169-1186
                   if (r[UARTCTL][11]) u_n = (newreg & 32'h0000_00ff) | 32'h0000_3000;
                   else                u_n = u_n | 32'h0000_2000;
                   upd = 1'b1;
                 end
          SOUNDCTL: begin                                    // :1189-1208
                   run_q <= newreg[0];
                   if (!newreg[2]) upd = 1'b1;               // fifo_reset_w(~newreg & 4) -> update when set
                 end
          SOUNDOUT: begin dcs_data_we <= 1'b1; dcs_data_w <= newreg[15:0]; end   // :1210-1212
          SOUNDIN:  dcs_ack_we <= 1'b1;                      // :1217-1219
          INTCTL:   upd = 1'b1;                              // :1236-1246
          default: ;
        endcase
      end
      r[UARTIN] <= u_n; r[INTCTL] <= ic_n; sirq <= s_n;
      if (upd) begin                                         // update_ioasic_irq (:803-826)
        ib = irqbits(s_n, u_n);
        r[INTSTAT] <= {16'd0, ib};
        irq_q <= ic_n[0] && ((ib & ic_n[15:0] & 16'h3ffe) != 16'd0);
      end
    end
  end
endmodule
