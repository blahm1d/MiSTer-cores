`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// wg1_ddr_port.sv -- War Gods (wg1) PIPELINED share of the stock MiSTer DDRAM port. Replaces the pair
// avalon_shared_mux + mister_ddram_adapter (rtl/platform), which allow ONE transaction at a time: every read burst held
// the whole path from selection to its last registered beat, every single-beat write cost a select/issue/retire round
// trip, so the renderer's pipelined texture fills (vunit_memory_arbiter TEXTURE_FILL_DEPTH=4) and posted framebuffer
// writes were serialized behind the DDR3 latency. Measured on the seeded 1P fight (tests/run_wg1_seed.py, 2026-09-26):
// engine owned the one-transaction port 0.87-0.90M clk per 1.726M-clk main loop for 41k 4-beat reads + 176k writes, the
// renderer waited on waitrequest 1.17M clk/loop and was busy 100 % of the loop; at a cabinet-like read latency of 12 clk
// the 1024-record queue filled (qfull 0.08-0.29M clk/loop) and loops ran 1.75-1.89M clk (the cabinet's ~82 %).
//
// Contract (Avalon-MM pipelined, the stock DDRAM port: DDRAM_BUSY = waitrequest, DDRAM_DOUT_READY = readdatavalid,
// responses in command order):
//   * One registered ISSUE SLOT drives DDRAM_*. The offered command is byte-identical until DDRAM_BUSY drops (an
//     unstable offer froze gm1's attract); the slot reloads in the clock its command is accepted.
//   * A client's command is taken into the slot (client_waitrequest low for that clock) when the slot is free or is
//     being accepted this clock. Selection = urgent clients first, then round robin from the last grant (the old mux's
//     rule). Writes are single beat (posted); reads are 1..8 beats.
//   * Up to DEPTH read bursts are outstanding. A read enters the slot only while (bursts outstanding + a read in the
//     slot) < DEPTH. The owner and beat count of every accepted read are queued in order; each returned beat goes to the
//     queue head's owner through one registered response slot (client_readdatavalid[owner], client_readdata).
//   * Faults (sticky, like the pair it replaces): 1 = a malformed client command (read+write, address[2:0] != 0,
//     burstcount 0 or > 8, write burst != 1), 2 = a DDRAM beat with no outstanding read. fault_info: see the old mux.
//     A fault stops new selections; accepted reads still drain.
// Every client in wg1 keeps at most its own ordering needs: SCAN (gm1_fb_present) and DCS (dcs2_ddr_agent) have one
// read in flight; the ENGINE (vunit_memory_arbiter, FILL mode) routes responses by its own issue-order queue; the diag
// mirror / C2 recorder only write. The port serves one command per clock in order, so a client's write followed by its
// own read of the same word is read-after-write ordered by the physical port (the assumption mister_ddram_adapter made).
module wg1_ddr_port #(
    parameter integer CLIENTS = 3,
    parameter integer DEPTH   = 8          // read bursts outstanding (Zeus measured depth 8 on the DE10-Nano cabinet)
) (
    input  wire clk, cold_reset,
    input  wire [CLIENTS-1:0] client_read, client_write, client_urgent,
    input  wire [CLIENTS*32-1:0] client_address,
    input  wire [CLIENTS*64-1:0] client_writedata,
    input  wire [CLIENTS*8-1:0]  client_byteenable,
    input  wire [CLIENTS*4-1:0]  client_burstcount,
    output reg  [CLIENTS-1:0] client_waitrequest, client_readdatavalid, client_read_error,
    output wire [CLIENTS*64-1:0] client_readdata,
    input  wire        DDRAM_BUSY, DDRAM_DOUT_READY,
    input  wire [63:0] DDRAM_DOUT,
    output wire [28:0] DDRAM_ADDR,
    output wire [7:0]  DDRAM_BURSTCNT, DDRAM_BE,
    output wire [63:0] DDRAM_DIN,
    output wire        DDRAM_RD, DDRAM_WE,
    output reg  [2:0]  fault_code,
    output reg  [9:0]  fault_info,
    // observation (diag / bench): read bursts outstanding + the one in the slot
    output wire [4:0]  reads_in_flight
);
    localparam integer OB = (CLIENTS < 2) ? 1 : $clog2(CLIENTS);
    localparam integer QB = (DEPTH < 2) ? 1 : $clog2(DEPTH);
    localparam [QB:0]   DEPTH_C = DEPTH;
    localparam [QB-1:0] LASTQ   = DEPTH - 1;

    // ---- issue slot ----
    reg        s_valid, s_read;
    reg [28:0] s_addr;
    reg [63:0] s_data;
    reg [7:0]  s_be;
    reg [3:0]  s_bc;
    reg [OB-1:0] s_owner;
    assign DDRAM_RD       = s_valid && s_read;
    assign DDRAM_WE       = s_valid && !s_read;
    assign DDRAM_ADDR     = s_addr;
    assign DDRAM_BURSTCNT = {4'd0, s_bc};
    assign DDRAM_DIN      = s_data;
    assign DDRAM_BE       = s_be;
    wire phys_accept = s_valid && !DDRAM_BUSY;

    // ---- in-order read queue {owner, beats} ----
    reg [OB-1:0] q_owner [0:DEPTH-1];
    reg [3:0]    q_beats [0:DEPTH-1];
    reg [QB-1:0] q_rp, q_wp;
    reg [QB:0]   q_cnt;
    reg [3:0]    head_left;                       // beats still owed by the queue head (valid when q_cnt != 0)
    wire [QB-1:0] q_rp_nx = (q_rp == LASTQ) ? {QB{1'b0}} : q_rp + 1'b1;
    wire [QB-1:0] q_wp_nx = (q_wp == LASTQ) ? {QB{1'b0}} : q_wp + 1'b1;
    wire         q_push = phys_accept && s_read;
    wire         beat   = DDRAM_DOUT_READY;
    wire         unexpected = beat && q_cnt == '0;
    wire         head_last  = beat && q_cnt != '0 && head_left == 4'd1;
    wire [QB:0]  inflight = q_cnt + ((s_valid && s_read) ? 1'b1 : 1'b0);
    assign reads_in_flight = 5'(inflight);

    // ---- selection (urgent first, then round robin from the last grant) ----
    reg [OB-1:0] rotation;
    wire [CLIENTS-1:0] requests = client_read | client_write;
    wire urgent_present = |(requests & client_urgent);
    wire [CLIENTS-1:0] candidates = urgent_present ? (requests & client_urgent) : requests;
    integer selected, index, offset;
    reg selection_valid;
    always @* begin
        selected = 0; selection_valid = 1'b0; index = 0;
        for (offset = 0; offset < CLIENTS; offset = offset + 1) begin
            index = integer'(rotation) + offset;
            if (index >= CLIENTS) index = index - CLIENTS;
            if (!selection_valid && candidates[index]) begin selected = index; selection_valid = 1'b1; end
        end
    end
    wire [3:0] sel_bc     = client_burstcount[selected*4 +: 4];
    wire       sel_rd     = client_read[selected];
    wire       sel_m_rw    = client_read[selected] && client_write[selected];
    wire       sel_m_align = client_address[selected*32 +: 3] != 3'd0;
    wire       sel_m_bc0   = sel_bc == 4'd0;
    wire       sel_m_bc8   = sel_bc > 4'd8;
    wire       sel_m_wbc   = client_write[selected] && sel_bc != 4'd1;
    wire       sel_malformed = sel_m_rw || sel_m_align || sel_m_bc0 || sel_m_bc8 || sel_m_wbc;
    wire       slot_free  = !s_valid || phys_accept;
    wire [QB:0] q_next_cnt = q_cnt + (q_push ? 1'b1 : 1'b0) - (head_last ? 1'b1 : 1'b0);
    // read credit from REGISTERED state only (conservative by the burst retiring this clock): the queued bursts plus a
    // read still in the slot stay < DEPTH, so after the new read is queued there are at most DEPTH outstanding. Keeps
    // DDRAM_DOUT_READY out of the waitrequest path.
    wire       read_room  = inflight < DEPTH_C;
    wire       take = !cold_reset && fault_code == 3'd0 && selection_valid && !sel_malformed &&
                      slot_free && (!sel_rd || read_room);

    always @* begin
        client_waitrequest = {CLIENTS{1'b1}};
        if (take) client_waitrequest[selected] = 1'b0;
    end

    // ---- registered response ----
    reg        r_valid;
    reg [OB-1:0] r_owner;
    reg [63:0] r_data;
    assign client_readdata = {CLIENTS{r_data}};
    always @* begin
        client_readdatavalid = '0; client_read_error = '0;
        if (r_valid && fault_code == 3'd0) client_readdatavalid[r_owner] = 1'b1;
    end

    always @(posedge clk) begin
        if (cold_reset) begin
            s_valid <= 1'b0; s_read <= 1'b0; s_addr <= '0; s_data <= '0; s_be <= '0; s_bc <= 4'd1; s_owner <= '0;
            q_rp <= '0; q_wp <= '0; q_cnt <= '0; head_left <= 4'd0;
            rotation <= '0; r_valid <= 1'b0; r_owner <= '0; r_data <= '0;
            fault_code <= 3'd0; fault_info <= 10'd0;
        end else begin
            r_valid <= 1'b0;
            // slot
            if (phys_accept) s_valid <= 1'b0;
            if (take) begin
                s_valid <= 1'b1; s_read <= sel_rd; s_owner <= OB'(selected);
                s_addr  <= client_address[selected*32 + 3 +: 29];
                s_data  <= client_writedata[selected*64 +: 64];
                s_be    <= client_byteenable[selected*8 +: 8];
                s_bc    <= sel_bc;
                rotation <= (selected == CLIENTS-1) ? '0 : OB'(selected + 1);
            end
            // read queue: push the accepted read, route and count returned beats
            if (q_push) begin
                q_owner[q_wp] <= s_owner; q_beats[q_wp] <= s_bc;
                q_wp <= q_wp_nx;
            end
            if (beat && q_cnt != '0) begin
                r_valid <= 1'b1; r_owner <= q_owner[q_rp]; r_data <= DDRAM_DOUT;
                if (head_last) begin
                    q_rp <= q_rp_nx;
                    head_left <= (q_cnt > 1) ? q_beats[q_rp_nx] :
                                 (q_push ? s_bc : 4'd0);
                end else head_left <= head_left - 1'b1;
            end else if (q_cnt == '0 && q_push) head_left <= s_bc;
            q_cnt <= q_next_cnt;
            // faults (first one sticky, with forensics)
            if (fault_code == 3'd0) begin
                if (unexpected) begin
                    fault_code <= 3'd2; fault_info <= {1'b0, 1'b0, 1'b1, 2'(s_owner), 5'd0};
                end else if (selection_valid && sel_malformed) begin
                    fault_code <= 3'd1;
                    fault_info <= {1'b1, 1'b0, 1'b0, 2'(selected), sel_m_rw, sel_m_align, sel_m_bc0, sel_m_bc8, sel_m_wbc};
                end
            end
        end
    end
endmodule
`default_nettype wire
