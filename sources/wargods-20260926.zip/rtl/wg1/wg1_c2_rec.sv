// wg1_c2_rec.sv -- cabinet C2 event recorder (diagnostic only, built in every WG1_DIAG_MIRROR build unless WG1_NO_C2_REC; wg1 2026-09-25).
// Records every host<->DCS2 mailbox event and the DSP-side IRQ2-vector state machine into a DDR3 ring, read over SSH
// (diag/wg1_c2_dump.sh) and replayed into tests/vs_ladder (tools: diag/c2_ring_decode.py).
//
// Entry (64 bit): [63:60] type, [59:36] ts = fabric clock count [23:0], [35:0] payload. A MARK entry every 2^23 clocks
// carries clk[59:24] so the decoder unwraps ts; a RET entry follows each MARK with the DSP retired-instruction count.
//   1 HW    host SOUNDOUT write (data_w)          [15:0] data
//   2 HR    host SOUNDIN read (data_r)            [15:0] value read
//   3 HA    host SOUNDIN write (ack_w)            -
//   4 SCTL  I/O ASIC SOUNDCTL write (C1 accept)   [15:0] bus data            [29:16] dsp_pc
//   5 CTLW  control_w 0x994000 write (strobe)      [15:0] bus data            [29:16] dsp_pc
//   6 RUN   combined DCS run level changed        [0] new level [1] by control_w [2] by SOUNDCTL   [29:16] dsp_pc
//   7 ENG   DSP engine reset edge                 [0] 1 = assert / 0 = release  [4:1] why {reboot, dcs_rst,
//           host held, boot copy} (at the edge)   [20:5] internal-PM (0x000-0x3ff) writes since the previous ENG
//                                                  [34:21] dsp_pc
//   8 PM4   PM[4] write (boot copy or engine)     [23:0] data   [35:24] dsp_pc[11:0]
//   9 D382  DM[0x382D] write                      [15:0] data   [29:16] dsp_pc
//  10 REP   DSP reply (output latch write)        [15:0] data   [29:16] dsp_pc
//  11 DRWJ  DSP DRAM write NOT at the previous DRAM write address + 1 (a new run starts)
//                                                 [35:16] DRAM word address  [15:0] data
//  12 DRWR  the run it ends (same clock as its DRWJ) [35:14] run length (writes, saturating)  [13:0] dsp_pc now
//  14 RET   DSP retired count                     [35:0]
//  15 MARK  clock                                 [35:0] clk[59:24]
// Each source has a one-deep hold; an event arriving while its source's hold is still full is DROPPED and counted.
// Drain: fixed priority (lowest type first) into a 1024-entry FIFO, then single-beat Avalon writes (held until
// waitrequest low) into the ring. Header (HDR, every 256 entries and every 2^22 clocks):
//   HDR+0 {"C2RE", entries written [31:0]}   HDR+8 {source drops, FIFO-full drops}
`timescale 1ns/1ps
`default_nettype none
module wg1_c2_rec #(
    parameter [31:0] RING = 32'h39400000,      // 2^RING_LG2 entries x 8 B
    parameter [31:0] HDR  = 32'h393FF000,
    parameter integer RING_LG2 = 22,            // 4M entries = 32 MB: the whole cabinet session to the VS-ladder hang
    parameter integer MARK_LG2 = 23             // MARK / RET every 2^MARK_LG2 clocks (unit gate uses a short period)
) (
    input  wire         clk, por,
    input  wire         bus_valid, bus_write, bus_sync,
    input  wire [23:0]  bus_addr,
    input  wire [31:0]  bus_wdata,
    input  wire         io_hit, io_ready,
    input  wire         ctl_strobe, ctl_run,
    input  wire         dcs_reset_io, dcs_run_lvl,
    input  wire         dcs_data_we, dcs_ack_we, dcs_data_rd,
    input  wire [15:0]  dcs_data_w, dcs_data_r,
    input  wire         dsp_retire,
    input  wire [13:0]  dsp_pc,
    input  wire [111:0] dcs_dbg,            // wg1_dcs2 dbg_mirror (header of wg1_dcs2.sv)
    input  wire         eng_rst,
    input  wire [3:0]   rst_why,
    input  wire [36:0]  dramw,              // wg1_dcs2 dbg_dramw {we, word address, data}
    output reg          write,
    output reg  [31:0]  address,
    output reg  [63:0]  writedata,
    output wire [7:0]   byteenable,
    output wire [3:0]   burstcount,
    input  wire         waitrequest
);
    assign byteenable = 8'hff;
    assign burstcount = 4'd1;
    localparam integer NS = 16;
    reg [59:0] clkc; reg [35:0] ret;
    // ---- sources ----
    wire        pm_we = dcs_dbg[0];  wire [13:0] pm_wa = dcs_dbg[14:1];  wire [23:0] pm_wd = dcs_dbg[38:15];
    wire        ir_we = dcs_dbg[39]; wire [8:0]  ir_wa = dcs_dbg[48:40]; wire [15:0] ir_wd = dcs_dbg[64:49];
    wire        rep_we = dcs_dbg[95]; wire [15:0] rep_wd = dcs_dbg[111:96];
    wire        io_acc = bus_valid && bus_sync && io_hit && io_ready;
    wire        sctl_w = io_acc && bus_write && bus_addr[3:0] == 4'd8;
    reg  [15:0] ctl_wd; reg io_q, run_q, eng_q, ctl_q, iochg_q; reg [15:0] pmint;
    wire        dw_we = dramw[36]; wire [19:0] dw_a = dramw[35:16]; wire [15:0] dw_d = dramw[15:0];
    reg  [19:0] dw_next; reg [21:0] dw_run;
    always @(posedge clk) if (bus_valid && bus_write && bus_addr == 24'h994000) ctl_wd <= bus_wdata[15:0];
    reg  [NS-1:0] ev;  reg [35:0] pl [0:NS-1];
    always @(*) begin
        ev = {NS{1'b0}};
        ev[1]  = dcs_data_we;  ev[2] = dcs_data_rd; ev[3] = dcs_ack_we; ev[4] = sctl_w; ev[5] = ctl_strobe;
        ev[6]  = (dcs_run_lvl != run_q); ev[7] = (eng_rst != eng_q);
        ev[8]  = pm_we && pm_wa == 14'd4; ev[9] = ir_we && ir_wa == 9'h02d; ev[10] = rep_we;
        ev[11] = dw_we && (dw_a != dw_next); ev[12] = ev[11];
        ev[15] = (clkc[MARK_LG2-1:0] == {MARK_LG2{1'b0}}); ev[14] = ev[15];
        pl[0] = 36'd0; pl[13] = 36'd0;
        pl[11] = {dw_a, dw_d};
        pl[12] = {dw_run, dsp_pc};
        pl[1]  = {20'd0, dcs_data_w};
        pl[2]  = {20'd0, dcs_data_r};
        pl[3]  = 36'd0;
        pl[4]  = {6'd0, dsp_pc, bus_wdata[15:0]};
        pl[5]  = {6'd0, dsp_pc, ctl_wd};
        pl[6]  = {6'd0, dsp_pc, 13'd0, iochg_q, ctl_q, dcs_run_lvl};
        pl[7]  = {1'b0, dsp_pc, pmint, rst_why, eng_rst};
        pl[8]  = {dsp_pc[11:0], pm_wd};
        pl[9]  = {6'd0, dsp_pc, ir_wd};
        pl[10] = {6'd0, dsp_pc, rep_wd};
        pl[14] = ret;
        pl[15] = clkc[59:24];
    end
    // ---- holds -> FIFO ----
    reg [NS-1:0] hv; reg [59:0] hd [0:NS-1];
    reg [31:0] sdrop, fdrop;
    (* ramstyle = "M10K, no_rw_check" *) reg [63:0] fifo [0:1023];
    reg [10:0] fw, fr; wire ffull = (fw - fr) == 11'd1024; wire fempty = fw == fr;
    reg  [3:0] pick; reg pv;
    always @(*) begin
        pv = 1'b0; pick = 4'd0;
        for (int k = NS - 1; k >= 1; k--) if (hv[k]) begin pv = 1'b1; pick = k[3:0]; end
    end
    integer j;
    always @(posedge clk) begin
        if (por) begin
            clkc <= 60'd1; ret <= 36'd0; io_q <= 1'b1; run_q <= 1'b1; eng_q <= 1'b1; ctl_q <= 1'b0; iochg_q <= 1'b0;
            pmint <= 16'd0; hv <= {NS{1'b0}}; sdrop <= 32'd0; fdrop <= 32'd0; fw <= 11'd0; dw_next <= 20'd0; dw_run <= 22'd0;
        end else begin
            clkc <= clkc + 60'd1;
            if (dsp_retire) ret <= ret + 36'd1;
            io_q <= dcs_reset_io; run_q <= dcs_run_lvl; eng_q <= eng_rst;
            ctl_q <= ctl_strobe; iochg_q <= (dcs_reset_io != io_q);
            if (dw_we) begin dw_next <= dw_a + 20'd1; dw_run <= ev[11] ? 22'd1 : (dw_run == 22'h3fffff ? dw_run : dw_run + 22'd1); end
            if (ev[7]) pmint <= 16'd0;
            else if (pm_we && pm_wa < 14'h0400 && pmint != 16'hffff) pmint <= pmint + 16'd1;
            // drain one hold into the FIFO
            if (pv) begin
                if (!ffull) begin fifo[fw[9:0]] <= {pick, hd[pick]}; fw <= fw + 11'd1; end
                else fdrop <= fdrop + 32'd1;
            end
            for (j = 1; j < NS; j = j + 1) begin
                if (ev[j]) begin
                    if (hv[j] && !(pv && pick == j[3:0])) sdrop <= sdrop + 32'd1;
                    hv[j] <= 1'b1; hd[j] <= {clkc[23:0], pl[j]};
                end else if (pv && pick == j[3:0]) hv[j] <= 1'b0;
            end
        end
    end
    // ---- FIFO -> DDR ring (+ header) ----
    reg [31:0] wcount; reg [1:0] st; reg [21:0] hdr_t; reg hdr_due;
    reg [63:0] fq; reg fq_v;
`ifdef MUT_REC_ORDER
    wire [RING_LG2-1:0] slot = {wcount[RING_LG2-1:1], ~wcount[0]};   // mutant: adjacent entries swapped in the ring
`else
    wire [RING_LG2-1:0] slot = wcount[RING_LG2-1:0];
`endif
    always @(posedge clk) begin
        if (por) begin
            write <= 1'b0; address <= 32'd0; writedata <= 64'd0; wcount <= 32'd0; st <= 2'd0; hdr_t <= 22'd0;
            hdr_due <= 1'b0; fr <= 11'd0; fq_v <= 1'b0;
        end else begin
            hdr_t <= hdr_t + 22'd1;
            if (hdr_t == 22'h3fffff) hdr_due <= 1'b1;
            if (!fq_v && !fempty) begin fq <= fifo[fr[9:0]]; fq_v <= 1'b1; fr <= fr + 11'd1; end
            case (st)
                2'd0: if (hdr_due) begin
                          write <= 1'b1; address <= HDR; writedata <= {32'h43325245, wcount}; st <= 2'd2; hdr_due <= 1'b0;
                      end else if (fq_v) begin
                          write <= 1'b1; address <= RING + {slot, 3'b000};
`ifdef MUT_REC_FIELD
                          writedata <= {fq[63:60], fq[35:0], fq[59:36]};                // mutant: ts/payload swapped
`else
                          writedata <= fq;
`endif
                          fq_v <= 1'b0; st <= 2'd1;
                      end
                2'd1: if (!waitrequest) begin
                          write <= 1'b0; wcount <= wcount + 32'd1; st <= 2'd0;
                          if (wcount[7:0] == 8'hff) hdr_due <= 1'b1;
                      end
                2'd2: if (!waitrequest) begin address <= HDR + 32'd8; writedata <= {sdrop, fdrop}; st <= 2'd3; end
                2'd3: if (!waitrequest) begin write <= 1'b0; st <= 2'd0; end
            endcase
        end
    end
endmodule
`default_nettype wire
