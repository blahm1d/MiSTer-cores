// dcs2_ddr_agent.sv -- Avalon-MM single-beat master for zk4_ddr_arb3's S port (64-bit, byte address,
// ONE outstanding read, command held until accepted). Serves three internal clients, priority order:
//   (P) ROM-store WRITE stream (from the ROM loader) during download -- highest, write-only, linear.
//   (C) a generic command port: one transaction at a time (read or write), used by the boot loader,
//       ROM-window page fills, and the SRAM cache line fills / write-backs.
// Quartus-17-safe (no `inside`, no function-result slices, casez only). 50 MHz, one clock.
`default_nettype none
module dcs2_ddr_agent #(
  parameter [31:0] ROM_BASE  = 32'h3100_0000,   // sound-ROM store window (7 MiB compact stream)
  parameter [31:0] SRAM_BASE = 32'h3180_0000     // 32Kx24 SRAM backing (word*8)
) (
  input  wire        clk,
  input  wire        por,
  // Avalon-MM master (S port of zk4_ddr_arb3)
  output reg         s_read, s_write,
  output reg  [31:0] s_address,
  output reg  [63:0] s_writedata,
  output reg  [7:0]  s_byteenable,
  input  wire        s_waitrequest,
  input  wire        s_readdatavalid,
  input  wire [63:0] s_readdata,
  // (P) ROM-store write stream from the loader (16-bit words packed 4->64 here)
  input  wire        rs_valid,        // a 16-bit ROM word is offered
  input  wire [15:0] rs_data,
  output reg         rs_ready,        // accepted this cycle
  input  wire [31:0] rs_woff,         // 16-bit word offset of rs_data within the ROM store
  // (C) generic command port (boot / rom-window / cache)
  input  wire        c_req,           // pulse/hold a command
  input  wire        c_we,            // 1=write 0=read
  input  wire [31:0] c_addr,          // byte address in DDR
  input  wire [63:0] c_wdata,
  input  wire [7:0]  c_be,
  output reg         c_ack,           // command accepted (address phase done)
  output reg         c_rvalid,        // read data returned
  output reg  [63:0] c_rdata,
  // status
  output reg  [31:0] ddr_reads, ddr_writes,
  output wire        rs_idle,         // no ROM-store data buffered/in-flight (tail fully written)
  output wire        c_can_accept     // agent will latch a fresh c_* command THIS cycle if c_req
);
  // ROM-store packing: gather 4 x 16-bit into one 64-bit line at (woff & ~3).
  reg [63:0] rs_line; reg [1:0] rs_fill; reg [31:0] rs_line_woff; reg rs_line_rdy;
  // A pending ROM-store 64-bit write (has priority over c_*).
  reg        pw_pend; reg [31:0] pw_addr; reg [63:0] pw_data;

  localparam S_IDLE=2'd0, S_ADDR=2'd1, S_RWAIT=2'd2;
  reg [1:0] st;
  reg cur_is_rom;         // the in-flight transaction came from the ROM-store (P) path
  reg c_bubble;           // 1-cycle guard after a c_* write (stops re-accepting the stale held req)

  always @(posedge clk) begin
    rs_ready <= 1'b0; c_ack <= 1'b0; c_rvalid <= 1'b0; c_bubble <= 1'b0;
    if (por) begin
      s_read<=0; s_write<=0; s_address<=0; s_writedata<=0; s_byteenable<=0;
      rs_line<=0; rs_fill<=0; rs_line_woff<=0; rs_line_rdy<=0; pw_pend<=0; pw_addr<=0; pw_data<=0;
      st<=S_IDLE; cur_is_rom<=0; ddr_reads<=0; ddr_writes<=0; c_bubble<=0;
    end else begin
      // ---- (P) accept ROM words, pack 4->64 ----
      if (rs_valid && !rs_ready && !rs_line_rdy) begin
        rs_ready <= 1'b1;
        // little-endian within the 64-bit line: word k occupies bits [k*16 +: 16]
        case (rs_woff[1:0])
          2'd0: rs_line[15:0]   <= rs_data;
          2'd1: rs_line[31:16]  <= rs_data;
          2'd2: rs_line[47:32]  <= rs_data;
          default: rs_line[63:48]<= rs_data;
        endcase
        if (rs_woff[1:0]==2'd0) rs_line_woff <= rs_woff;
        if (rs_woff[1:0]==2'd3) rs_line_rdy <= 1'b1;   // line complete
        rs_fill <= rs_fill + 2'd1;
      end
      if (rs_line_rdy && !pw_pend) begin
        pw_pend <= 1'b1; pw_addr <= ROM_BASE + {rs_line_woff[28:0],1'b0}; // woff*2 bytes, aligned to 8
        pw_data <= rs_line; rs_line_rdy <= 1'b0;
      end

      // ---- Avalon master FSM (single outstanding) ----
      case (st)
        S_IDLE: begin
          if (pw_pend) begin
            s_write<=1'b1; s_read<=1'b0; s_address<={pw_addr[31:3],3'b000}; s_writedata<=pw_data;
            s_byteenable<=8'hff; cur_is_rom<=1'b1; st<=S_ADDR;
          end else if (c_req && !c_bubble) begin   // c_bubble: skip 1 cycle after a c_* write so a
            s_write<=c_we; s_read<=~c_we; s_address<={c_addr[31:3],3'b000}; s_writedata<=c_wdata;  // cache
            s_byteenable<=c_we? c_be : 8'hff; cur_is_rom<=1'b0; st<=S_ADDR;    // that still holds its (now
          end                                                                  // acked) write-back req is
        end                                                                    // not re-accepted as a
        S_ADDR: begin                                                          // spurious second write.
          if (!s_waitrequest) begin           // accepted
            if (s_write) begin
              ddr_writes<=ddr_writes+1'b1;
              if (cur_is_rom) pw_pend<=1'b0; else begin c_ack<=1'b1; c_bubble<=1'b1; end
              s_write<=1'b0; st<=S_IDLE;
            end else begin
              ddr_reads<=ddr_reads+1'b1; c_ack<=1'b1; s_read<=1'b0; st<=S_RWAIT;
            end
          end
        end
        S_RWAIT: begin
          if (s_readdatavalid) begin c_rvalid<=1'b1; c_rdata<=s_readdata; st<=S_IDLE; end
        end
        default: st<=S_IDLE;
      endcase
    end
  end
  // idle == no ROM-store data buffered anywhere: no partial line, no complete line waiting, no
  // pending write, and not currently issuing a ROM write on the bus. rom_loaded is gated on this so
  // a consumer never sees a "download done" with the tail 64-bit word(s) still in flight.
  assign rs_idle = (rs_fill==2'd0) && !rs_line_rdy && !pw_pend && !(st==S_ADDR && cur_is_rom);
  // The next c_* command is latched from the mux ONLY when the agent is idle, the ROM-store path
  // has nothing pending, and the post-write bubble is clear -- same gate the S_IDLE arm uses. The
  // parent latches the command's owner on this cycle so a later c_ack is routed to whoever OWNED the
  // in-flight command, not to whichever client's sel_* happens to be high when c_ack pulses.
  assign c_can_accept = (st==S_IDLE) && !pw_pend && !c_bubble;
endmodule
`default_nettype wire
