`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// cusa_dcs_fifo.sv -- plain single-clock synchronous FIFO for the DCS ROM loader ->
// DDR-writer hand-off. Everything in the DCS subsystem runs on the one 50 MHz core
// clock (P0019-clean: no async crossing), so no gray-coded CDC FIFO is needed -- but
// `full`/`empty` are still derived from REGISTERED pointers, never a next-pointer, to
// avoid the combinational loop that hung the bw1 cabinet
// (memory: fifo-full-from-next-pointer-is-a-comb-loop). Depth = 1<<ADDR_BITS.
module cusa_dcs_fifo #(
    parameter integer WIDTH     = 16,
    parameter integer ADDR_BITS = 9          // depth 512
) (
    input  wire                 clk,
    input  wire                 rst,
    input  wire                 wr_en,
    input  wire [WIDTH-1:0]     wr_data,
    output wire                 full,
    output wire [ADDR_BITS:0]   level,        // occupancy 0..2^ADDR_BITS
    input  wire                 rd_en,
    output wire [WIDTH-1:0]     rd_data,
    output wire                 empty
);
    localparam [ADDR_BITS:0] N = (1 << ADDR_BITS);
    (* ramstyle = "M10K" *) reg [WIDTH-1:0] mem [0:(1<<ADDR_BITS)-1];
    reg [ADDR_BITS:0] wptr, rptr;             // one guard bit above the index

    wire [ADDR_BITS:0] cnt = wptr - rptr;     // registered pointers -> loop-free
    assign full    = (cnt == N);
    assign empty   = (wptr == rptr);
    assign level   = cnt;
    assign rd_data = mem[rptr[ADDR_BITS-1:0]];

    always @(posedge clk) begin
        if (rst) begin
            wptr <= '0;
            rptr <= '0;
        end else begin
            if (wr_en && !full) begin
                mem[wptr[ADDR_BITS-1:0]] <= wr_data;
                wptr <= wptr + 1'b1;
            end
            if (rd_en && !empty)
                rptr <= rptr + 1'b1;
        end
    end
endmodule
`default_nettype wire
