// dcs2_sram_cache.sv -- direct-mapped, write-back, write-allocate cache over the DDR-backed SRAM.
// One word per line (the arb is single-beat), sized to hold the MEASURED hot set on-chip so steady
// play never misses (PLAN-DCS2-FABRIC.md: code 0x2800-0x2FFF ~1.5K words, data ~4.3K words). The
// firmware RAM-tests the whole SRAM at boot -> misses stream through DDR (slow, boot only).
//
// AREA: the data line AND the {valid,dirty,tag} metadata are M10K, using the Quartus-17 inferable
// template EXACTLY -- ONE write port per array, a REGISTERED read in the SAME clocked block, NO reset
// on the array, `ramstyle "M10K, no_rw_check"`. A power-on clear FSM walks the index writing valid=0
// through the single write port (garbage would else false-hit). No same-cycle read-during-write new
// data is relied on (no_rw_check returns old data; the FSM never reads a just-written line same cycle).
`default_nettype none
module dcs2_sram_cache #(
  parameter int AW  = 14,        // SRAM word-address width (this view)
  parameter int DW  = 16,        // data width (DM=16, PM=24)
  parameter int IDX = 12,        // index bits => (1<<IDX) cache lines
  parameter [31:0] BASE = 32'h3180_0000
) (
  input  wire            clk,
  input  wire            por,
  input  wire            req,
  input  wire            we,
  input  wire [AW-1:0]   addr,
  input  wire [DW-1:0]   wdata,
  output reg             ready,      // wg1 speed step 2: COMBINATIONAL (1-cycle-latency hit)
  output reg  [DW-1:0]   rdata,      // wg1 speed step 2: COMBINATIONAL, valid when ready
  output reg             m_req, m_we,
  output reg  [31:0]     m_addr,
  output reg  [63:0]     m_wdata,
  input  wire            m_ack,
  input  wire            m_rvalid,
  input  wire [63:0]     m_rdata,
  output reg  [31:0]     misses
);
  localparam int LINES = (1<<IDX);
  localparam int TW    = AW-IDX;
  localparam int MW    = TW+2;                 // {valid, dirty, tag}

  // ---- M10K arrays + their registered reads (single write port, single read port, same block) ----
  (* ramstyle = "M10K, no_rw_check" *) reg [DW-1:0] cdata [0:LINES-1];
  (* ramstyle = "M10K, no_rw_check" *) reg [MW-1:0] cmeta [0:LINES-1];
  reg [DW-1:0] data_q; reg [MW-1:0] meta_q;    // registered read outputs
  // write-port + read-addr controls, driven by the FSM below
  reg            cd_we, cm_we;
  reg [IDX-1:0]  cd_wa, cm_wa, rd_a;
  reg [DW-1:0]   cd_wd; reg [MW-1:0] cm_wd;
  // Read address is COMBINATIONAL so a fresh req launches the M10K read THIS cycle (data valid next
  // cycle) -- a HIT is S_IDLE -> S_CMP (2 clk), not S_IDLE -> S_RD -> S_CMP (3 clk). Under service the
  // FSM holds the address via r_idx. (wg1 speed step 1: adopted from Zeus live dcs2_sram_cache, gate-proven.)
  wire [IDX-1:0] rd_addr = (st==S_IDLE && req) ? idx : r_idx;
  always @(posedge clk) begin
    if (cd_we) cdata[cd_wa] <= cd_wd;
    data_q <= cdata[rd_addr];                   // registered read, no reset
    if (cm_we) cmeta[cm_wa] <= cm_wd;
    meta_q <= cmeta[rd_addr];
  end

  wire [IDX-1:0] idx = addr[IDX-1:0];
  wire [TW-1:0]  tag = addr[AW-1:IDX];
  wire m_valid = meta_q[MW-1];
  wire m_dirty = meta_q[MW-2];
  wire [TW-1:0] m_tag = meta_q[TW-1:0];

  localparam S_CLR=4'd0, S_IDLE=4'd1, S_RD=4'd2, S_CMP=4'd3, S_WB=4'd4, S_WBW=4'd5,
             S_FILL=4'd6, S_FILLW=4'd7, S_DONE=4'd8;
  reg [3:0]     st;
  reg [IDX:0]   clr_i;
  reg [IDX-1:0] r_idx; reg [TW-1:0] r_tag; reg r_we; reg [DW-1:0] r_wdata; reg [AW-1:0] r_addr;
  reg [DW-1:0]  fill_q;

  // wg1 speed step 2 -- BEAT-CACHE: assert ready + rdata COMBINATIONALLY the cycle the compare is valid
  // (data_q/meta_q settle one clock after the S_IDLE launch), so a HIT is a 1-cycle-latency return
  // (req -> ready next clock) instead of the extra registered-ready clock. General (any resident line),
  // M10K-neutral (same arrays). The engine/servicer already tolerate variable ready timing.
  wire cmp_hit = (st==S_CMP) && m_valid && (m_tag==r_tag);
  always @* begin
    ready = 1'b0;
    rdata = data_q;
    if (cmp_hit)         begin ready = 1'b1; rdata = r_we ? r_wdata : data_q; end
    else if (st==S_DONE) begin ready = 1'b1; rdata = r_we ? r_wdata : fill_q; end
  end

  always @(posedge clk) begin
    m_req <= m_req & ~m_ack; cd_we<=1'b0; cm_we<=1'b0;
    rd_a <= r_idx;                              // keep reading the line under service
    if (por) begin
      st<=S_CLR; clr_i<=0; m_req<=1'b0; m_we<=1'b0; misses<=0; fill_q<=0; r_idx<=0;
    end else begin
      case (st)
        S_CLR: begin
          cm_we<=1'b1; cm_wa<=clr_i[IDX-1:0]; cm_wd<={MW{1'b0}};   // valid=0 through the one write port
          if (clr_i==LINES-1) st<=S_IDLE;
          clr_i<=clr_i+1'b1;
        end
        S_IDLE: if (req) begin
          r_idx<=idx; r_tag<=tag; r_we<=we; r_wdata<=wdata; r_addr<=addr; st<=S_CMP; // comb rd_addr=idx -> data valid in S_CMP
        end
        S_RD: st<=S_CMP;                         // (retained, unused: hit path is now S_IDLE->S_CMP)
        S_CMP: begin
          if (m_valid && m_tag==r_tag) begin      // HIT (ready/rdata asserted combinationally above)
            if (r_we) begin cd_we<=1'b1; cd_wa<=r_idx; cd_wd<=r_wdata;
                            cm_we<=1'b1; cm_wa<=r_idx; cm_wd<={1'b1,1'b1,r_tag}; end
            st<=S_IDLE;
          end else begin                          // MISS
            misses<=misses+1'b1;
            if (m_valid && m_dirty) begin          // write back old line first
              m_req<=1'b1; m_we<=1'b1;
              m_addr<=BASE + ({{(32-AW){1'b0}}, m_tag, r_idx} << 3);
              m_wdata<={{(64-DW){1'b0}}, data_q};
              st<=S_WB;
            end else begin
              m_req<=1'b1; m_we<=1'b0; m_addr<=BASE + ({{(32-AW){1'b0}}, r_addr} << 3); st<=S_FILL;
            end
          end
        end
        S_WB:   if (m_ack) st<=S_WBW;
        S_WBW: begin m_req<=1'b1; m_we<=1'b0; m_addr<=BASE + ({{(32-AW){1'b0}}, r_addr} << 3); st<=S_FILL; end
        S_FILL: if (m_ack) st<=S_FILLW;
        S_FILLW: if (m_rvalid) begin
          fill_q <= m_rdata[DW-1:0];
          cd_we<=1'b1; cd_wa<=r_idx; cd_wd<= r_we ? r_wdata : m_rdata[DW-1:0];
          cm_we<=1'b1; cm_wa<=r_idx; cm_wd<={1'b1, r_we, r_tag};
          st<=S_DONE;
        end
        S_DONE: st<=S_IDLE;                       // ready/rdata asserted combinationally above
        default: st<=S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
