// wg1_dcs2.sv -- War Gods DCS2 sound board (MAME DCS2_AUDIO_2115, midvunit.cpp:1255-1261) in fabric.
// FORK of zeus1/rtl/dcs2/zk4_dcs2.sv (md5 8629bfe2dad33856a54a4f8cbfd2494e): same engine / SRAM-cache /
// DDR-agent / ROM-loader structure and the Zeus owner-latched command arbiter; RE-TRANSCRIBED for the
// RAM-based ADSP-2115 variant from MAME 0.289 src/mame/shared/dcs.cpp:
//   program map   :349-353   internal PM 0x0000-0x03ff (1K x 24, ADSP-2115; the 2104 has 512)
//   data map      :362-373   0x0400-0x0407 latches, 0x0480-0x0483 SDRC, 0x3800-0x39ff IRAM, 0x3fe0-0x3fff ctl;
//                            everything else unmapped -> 0xffff (unmap_value_high)
//   SDRC remap    :985-1037  SM_EN: PM 0x0800-0x3fff -> SRAM; DM bank0 0x0800/0x1800/0x2800 -> SRAM
//                            0x0000/0x1000/0x2000, bank1 0x1800 -> 0x3000, 0x2800 -> 0x2000, 0x0800-0x17ff
//                            unmapped; !SM_EN: 0x0800-0x3fff PM / 0x0800-0x37ff DM unmapped. Then ROM window
//                            (ROM_MS && ROM_ST!=3, base 0/0x3000/0x3400, 1K or 4K) then DRAM window (DM_ST!=0,
//                            base 0/0x3000/0x3400, 1K words, read/write). Later installs win.
//   bank pointers :954-982   RAM-based: ROM window = bootrom[(ROM_PG*4096) % len], DRAM window =
//                            sounddata[(DM_PG*1024) % words]; only updated while SM_EN.
//   2 MB DRAM     :827-833   m_sounddata_words = (2<<20)/2 = 1M 16-bit words (midvunit.cpp:1258)
//   SDRC regs     :1054-1168 (security byte, SMODE)
//   dcs_boot      :499-524   RAM-based: page = bootrom[(ROM_PG*0x1000) % len]; adsp2100.cpp:322-331
//                            load_boot_data: pagelen=(b[3]+1)*8, PM[i] = b[4i]<<16|b[4i+1]<<8|b[4i+2]
//   dcs_reset     :543-603   SDRC reset, control regs 0, latches empty, IRQs clear, boot, timer_ignore=0
//   reset_w       :1456-1471 low: dcs_reset + CPU held in reset; high: run
//   adsp_control  :1830-1953 (PROG_FLAG_DATA toggle, IDMA reads 0xffff on the 2115, SYSCONTROL bit9 reboot)
//   polling hotspot 0x3839 (midvunit.cpp:1259, dcs.cpp:875-894, 2102-2117): a MAME speed-up handler over
//                            an IRAM word; storage-equivalent to RAM -> plain IRAM here.
//   HLE transfers (dcs.cpp:858, 2138-2450) are a MAME shortcut; this board runs the real DSP transfer code.
// Boot ROM u2 (ROM_REGION16_LE 0x10000 "dcs", ROM_LOAD16_BYTE u2 32 KB, midvunit.cpp:2144-2145): DSP word
// k = {8'h00, u2[k]} (region < 4 MB is zero-filled by the ROM loader).
//
// C5 (this board's memory port, README): Avalon-MM single-beat 64-bit master, byte addresses in a window
// at MEM_BASE:  +0x000000 DRAM 2 MB (word w at byte 2w) | +0x200000 (unused since S4: PM-SRAM on chip) |
//               +0x240000 (unused since S4: DM-SRAM on chip) | +0x280000 boot ROM u2 (32 KB, byte b at b).
// SV subset: iverilog -g2012 + Quartus 17 (no inline genvars, no latching always_comb, simple-dual-port RAMs
// with registered read). One clock (clk, 50 MHz), synchronous active-high resets (por, reset).
`default_nettype none
module wg1_dcs2 #(
  parameter [31:0] MEM_BASE   = 32'h3A00_0000,
  parameter [7:0]  ROM_INDEX  = 8'd3,
  parameter integer PMC_IDX   = 12,
  parameter integer DMC_IDX   = 13,
  parameter integer PACE      = 1         // guest-time pacer (<= 16 M DSP instructions per second)
) (
  input  wire        clk,
  input  wire        por,              // power-on reset (P0022 capture domain + cold DSP)
  input  wire        reset,            // core reset: MAME machine reset -> dcs device_reset (dcs.cpp:746)
  // ---- C2 (sound side) ----
  input  wire        dcs_reset,        // level, SOUNDCTL bit 0 (high = run)
  input  wire        dcs_data_we,
  input  wire [15:0] dcs_data_w,
  input  wire        dcs_ack_we,
  input  wire        dcs_data_rd,      // SOUNDIN read strobe (data_r side effect, README C2 note)
  output wire [15:0] dcs_data_r,
  output wire [15:0] dcs_data2_r,
  output wire [15:0] dcs_control,
  output wire        dcs_output_full,
  output wire        dcs_input_empty,
  output wire        fifo_rd,
  output wire        fifo_reset_w,     // SDRC boards never call fifo_reset_w (only DSIO/Denver, dcs.cpp:1221,1330)
  input  wire [15:0] fifo_q,
  input  wire [15:0] fifo_status,
  // ---- boot ROM download (hps_io WIDE ioctl) ----
  input  wire        ioctl_download, ioctl_wr,
  input  wire [15:0] ioctl_index, ioctl_dout,
  output wire        ioctl_wait,
  // ---- C5 memory port ----
  output wire        m_read, m_write,
  output wire [31:0] m_address,
  output wire [63:0] m_writedata,
  output wire [7:0]  m_byteenable,
  input  wire        m_waitrequest, m_readdatavalid,
  input  wire [63:0] m_readdata,
  // ---- audio ----
  output wire signed [15:0] audio_l, audio_r,
  output wire        audio_ce,
  // ---- status ----
  output wire        rom_loaded,
  output wire [31:0] rom_bytes, rom_crc,
  output wire        rom_reset_during_download,
  output wire [31:0] dac_underruns,
  output wire [13:0] dsp_pc,
  output wire        cfg_unsupported,  // a DSP configuration outside the War Gods-measured set was used
  // ---- bench seams (tie 0 in the core) ----
  input  wire        gate_mode, dsp_hold, inj_tick, inj_sport0, inj_timer, inj_irq2_up, inj_irq2_dn,
  output wire        dbg_insn_start,   // the engine is at the first cycle of an instruction (pre-state valid)
  output wire        dbg_retire,
  output wire [1887:0] dbg_regs,
  output wire [3:0]  dbg_irq_state,
  output wire        dbg_boot_busy,
  output wire        dbg_at_boundary,  // dsp_hold would stall the engine now
  output wire        dbg_dm_we,        // an engine DM write is accepted this clock
  output wire [13:0] dbg_dm_addr,
  output wire [15:0] dbg_dm_wdata
`ifdef WG1_DIAG_MIRROR
  // Cabinet diag tap (wg1_status_mirror block B, rtl/wg1_status_mirror.sv): OBSERVE-ONLY copies of internal
  // write strobes / state; declared only under the diag macro, so the release port list is unchanged.
  //   [0] pm_we [14:1] pm_wa [38:15] pm_wd          the PM M10K write port (boot copy + engine)
  //   [39] iram_we [48:40] iram_wa [64:49] iram_wd  the IRAM (DM 0x3800-0x39ff) write port
  //   [70:65] imask [75:71] icntl [81:76] irq latch lt[5:0] [85:82] irq state st[3:0] (st[2] = IRQ2 level)
  //   [86] irq_ack [89:87] irq_ack_indx (0 = IRQ2)
  //   [90] beat-cache lookup hit [91] lookup miss [92] beat fill (miss or prefetch) [93] prefetch fill
  //   [94] DRAM write accepted on C5 [95] output-latch (reply) write [111:96] reply data
  , output wire [111:0] dbg_mirror
`endif
`ifdef WG1_DIAG_MIRROR
  // C2 event recorder tap (rtl/wg1_c2_rec.sv, diagnostic builds only): {eng_rst, reboot_req, dcs_rst, host held
  // (~dcs_reset), boot_busy}. Observe-only; declared only under the macro, so the release port list is unchanged.
  , output wire [4:0]  dbg_rst
  , output wire [36:0] dbg_dramw        // {DSP DRAM-window write accepted, DRAM word address [19:0], data [15:0]}
`endif
`ifdef WG1_DCS2_GATE_TAP
  // Timing-gate tap (bench only; NOT part of the synthesized/integrated port list -- guarded by a define
  // the integration flow never sets). Surfaces the SPORT1 half-buffer tick so tb_gate_b can bound the
  // tick cadence against MAME's period (dcs.cpp:2038-2039). RTL behaviour is identical either way.
  , output wire       dbg_tick_stb
  , output wire       dbg_arm           // SPORT1 armed level (first-tick-after-arm check, dcs.cpp:2039)
  , output wire       dbg_eng_rst       // DSP held in reset (pacer-ahead gate: 16 MIPS budget counts from each release)
`endif
);
  localparam [31:0] DRAM_B = MEM_BASE;
  localparam [31:0] PMS_B  = MEM_BASE + 32'h0020_0000;
  localparam [31:0] DMS_B  = MEM_BASE + 32'h0024_0000;
  localparam [31:0] ROM_B  = MEM_BASE + 32'h0028_0000;

  // ================= reset / boot sequencing =================
  reg  lvl_q;
  wire host_fall = lvl_q & ~dcs_reset;
  reg  dcs_rst;              // one-clock dcs_reset (dcs.cpp:543)
  reg  cold;                 // next engine reset is a power-on (device_start zeroes the core)
  reg  reboot_req;           // SYSCONTROL bit9 (dcs.cpp:1872-1880)
  reg  boot_go;              // run dcs_boot
  wire boot_busy;
  reg  eng_rst;
  always @(posedge clk) begin
    lvl_q   <= por ? 1'b1 : dcs_reset;
    dcs_rst <= por | reset | host_fall;
  end
  assign fifo_reset_w = 1'b0;

  // ================= engine =================
  // wg1 S4 (dcs2-next): the engine fetches over a COMBINATIONAL PM port straight into the on-chip PM M10K
  // (fixed 1-clock latency), retires with a combinational `commit`, and takes its boundary hold registered.
  wire        e_pm_rd, e_pm_wr; wire [13:0] e_pm_addr; wire [23:0] e_pm_wdata;
  wire [23:0] e_pm_rdata; reg e_pm_ready;
  wire        e_dm_rd, e_dm_wr; wire [13:0] e_dm_addr; wire [15:0] e_dm_wdata;
  wire [15:0] e_dm_rdata; wire e_dm_ready;
  wire        e_irq_take; wire [2:0] e_irq_indx;
  wire        e_i7_we; wire [13:0] e_i7_wd;
  wire        e_irq_ack; wire [2:0] e_irq_ack_indx; wire e_tx1_we; wire e_commit, e_istart, e_bnd;
  wire [1887:0] e_dbg;
  // Guest time: the DSP's timers (SPORT0, SPORT1, ADSP timer) count DSP cycles = retired instructions
  // (MAME's basis). The pacer keeps the engine at or below the ADSP-2115's 16 M instructions/s at 50 MHz:
  // +16 credit per clock, -50 per instruction; hold at an instruction boundary while the credit is negative.
  // S4c: the credit is the DSP's lag behind 16 MIPS wall time. The old 800 cap (16 instructions) FORGAVE any
  // larger lag (e.g. a C5 DRAM-write burst in the transfer ISR), so the DSP fell permanently behind real time
  // (measured 3.1279 clk/instr on the stress window; 65,535 left 3.1258). Cap 1,048,575 (~21K instructions, 1.3 ms): the
  // DSP catches up after a slow stretch; it can never run AHEAD of 16 MIPS (the hold still fires below 0).
  reg  signed [20:0] pace_credit;
  wire        pace_hold = (PACE != 0) & ~gate_mode & pace_credit[20];
  // SPORT1 TX arm / I7 side-write ordering is now inside the engine (tx_stall + i7_we boundary block).
  reg         tx1_q;
  always @(posedge clk) tx1_q <= e_tx1_we;
  dcs2_engine u_eng (
    .clk(clk), .rst(eng_rst), .ce(1'b1), .hold(dsp_hold | pace_hold),
    .pm_rd(e_pm_rd), .pm_wr(e_pm_wr), .pm_addr(e_pm_addr), .pm_wdata(e_pm_wdata),
    .pm_rdata(e_pm_rdata), .pm_ready(e_pm_ready),
    .dm_rd(e_dm_rd), .dm_wr(e_dm_wr), .dm_addr(e_dm_addr), .dm_wdata(e_dm_wdata),
    .dm_rdata(e_dm_rdata), .dm_ready(e_dm_ready),
    .irq_take(e_irq_take), .irq_indx(e_irq_indx),
    .i7_we(e_i7_we), .i7_wd(e_i7_wd), .warm_rst(~cold),
    .irq_ack(e_irq_ack), .irq_ack_indx(e_irq_ack_indx), .tx1_we(e_tx1_we),
    .seed_en(1'b0), .seed(1888'd0),
    .commit(e_commit), .istart(e_istart), .bnd(e_bnd), .dbg(e_dbg)
  );
  assign dbg_regs = e_dbg;
  assign dsp_pc   = e_dbg[13:0];
  wire insn_start = e_istart & ~eng_rst;
  wire retire     = e_commit & ~eng_rst;          // one clock per instruction (the edge that retires it)
  always @(posedge clk) begin
    // S4e (verifier finding 1): NO credit while the DSP is in reset -- the real chip is stopped, not late.
    // (The old code accrued +16/clk through boot/host reset: up to 931,744 credit = 18,636 instructions run
    // AHEAD of a 16 MIPS chip after the release.) While the bench holds the DSP (dsp_hold) no credit
    // accumulates either (clamped at 0). Gate: tb_gate_b "pacer ahead" check (AHEAD_BOUND).
`ifdef MUT_PACE_ACCRUE
    if (por || gate_mode) pace_credit <= 21'sd0;                 // mutant: the pre-S4e rule (accrues in reset)
`else
    if (por || gate_mode || eng_rst) pace_credit <= 21'sd0;
`endif
    else begin
      logic signed [21:0] c;
      c = {pace_credit[20], pace_credit} + 22'sd16 - (retire ? 22'sd50 : 22'sd0);
      if (c > 22'sd1048575) c = 22'sd1048575;                    // catch-up allowance (see above)
      if (dsp_hold && c > 22'sd0) c = 22'sd0;
      pace_credit <= c[20:0];
    end
  end
  assign dbg_insn_start = insn_start;
  assign dbg_retire     = retire;
  assign dbg_at_boundary = eng_rst | e_bnd;

  wire [13:0] i_all [0:7]; wire [13:0] m_all [0:7]; wire [13:0] l_all [0:7];
  genvar gd;
  generate for (gd = 0; gd < 8; gd = gd + 1) begin : g_dag
    assign i_all[gd] = e_dbg[(20+gd)*32 +: 14];
    assign m_all[gd] = e_dbg[(28+gd)*32 +: 14];
    assign l_all[gd] = e_dbg[(36+gd)*32 +: 14];
  end endgenerate
  wire [6:0] mstat = e_dbg[47*32 +: 7];
  wire [5:0] imask = e_dbg[49*32 +: 6];
  wire [4:0] icntl = e_dbg[50*32 +: 5];

  // ================= SDRC (dcs.cpp:222-240) =================
  reg  [15:0] sdrc0, sdrc1, sdrc2; reg [7:0] sdrc_seed;
  wire        SM_EN  = sdrc0[11];
  wire        SM_BK  = sdrc0[12];
  wire        ROM_MS = sdrc0[5];
  wire        ROM_SZ = sdrc0[4];
  wire [1:0]  ROM_ST = sdrc0[1:0];
  wire [2:0]  ROM_PG = sdrc0[9:7];
  wire [2:0]  SMODE  = sdrc0[15:13];
  wire [1:0]  DM_ST  = sdrc1[1:0];
  wire [10:0] DM_PG  = sdrc2[10:0];
  reg  [2:0]  rom_pg_q; reg [10:0] dm_pg_q;   // bank pointers: follow the regs only while SM_EN (:956)
  wire [2:0]  rom_pg_e = SM_EN ? ROM_PG : rom_pg_q;
  wire [10:0] dm_pg_e  = SM_EN ? DM_PG  : dm_pg_q;
  wire        rw_en   = ROM_MS && (ROM_ST != 2'd3);
  wire [13:0] rw_base = (ROM_ST == 2'd0) ? 14'h0000 : (ROM_ST == 2'd1) ? 14'h3000 : 14'h3400;
  wire [14:0] rw_len  = (!ROM_SZ && ROM_ST != 2'd0) ? 15'd4096 : 15'd1024;
  wire        dw_en   = (DM_ST != 2'd0);
  wire [13:0] dw_base = (DM_ST == 2'd1) ? 14'h0000 : (DM_ST == 2'd2) ? 14'h3000 : 14'h3400;

  // ================= control registers (0x3fe0-0x3fff) =================
  reg  [15:0] ctl [0:31];
  reg  [15:0] progflags;
  wire [15:0] timer_count; wire timer_ignore;

  // ================= mailbox =================
  wire        mbx_acc; wire [15:0] mbx_rdata; wire irq2_set, irq2_clr, ctl_read;
  reg         mbx_acc_r; reg mbx_we_r; reg [2:0] mbx_off_r; reg [15:0] mbx_wd_r;
  wg1_dcs2_mbx u_mbx (
    .clk(clk), .dcs_rst(dcs_rst), .por(por),
    .dcs_data_we(dcs_data_we), .dcs_data_w(dcs_data_w), .dcs_ack_we(dcs_ack_we), .dcs_data_rd(dcs_data_rd),
    .dcs_data_r(dcs_data_r), .dcs_data2_r(dcs_data2_r), .dcs_control(dcs_control),
    .dcs_output_full(dcs_output_full), .dcs_input_empty(dcs_input_empty),
    .fifo_q(fifo_q), .fifo_status(fifo_status), .fifo_rd(fifo_rd),
    .dm_acc(mbx_acc_r), .dm_we(mbx_we_r), .dm_off(mbx_off_r), .dm_wdata(mbx_wd_r), .dm_rdata(mbx_rdata),
    .ctl_read(ctl_read), .irq2_set(irq2_set), .irq2_clr(irq2_clr)
  );

  // ================= IRQ controller / SPORT0 / timer =================
  reg  sysctl_we_r, tscale_we_r, tcount_we_r, tperiod_we_r, s1ab_we_r; reg [15:0] ctl_wd_r;
  reg  [4:0] stub_ok;        // PM[0x18+k] == refresh stub word k (dcs.cpp:1760-1764)
  wire irq1_pulse;
`ifdef WG1_DIAG_MIRROR
  wire [5:0] irq_lt;         // diag tap only
`endif
  wg1_dcs2_irq u_irq (
    .clk(clk), .cpu_rst(eng_rst), .dcs_rst(dcs_rst), .gate_mode(gate_mode), .retire(retire),
    .insn_start(insn_start),
    .irq2_set(irq2_set), .irq2_clr(irq2_clr), .irq1_pulse(irq1_pulse),
    .inj_sport0(inj_sport0), .inj_timer(inj_timer), .inj_irq2_up(inj_irq2_up), .inj_irq2_dn(inj_irq2_dn),
    .sysctl_we(sysctl_we_r), .sysctl_wd(ctl_wd_r), .ctl_read(ctl_read),
    .tscale_we(tscale_we_r), .tcount_we(tcount_we_r), .tperiod_we(tperiod_we_r), .ctl_wd(ctl_wd_r),
    .tscale_q(ctl[27]), .tperiod_q(ctl[29]), .timer_ena(mstat[5]), .stub_match(&stub_ok),
    .imask(imask), .icntl(icntl), .irq_ack(e_irq_ack), .irq_ack_indx(e_irq_ack_indx),
    .irq_take(e_irq_take), .irq_indx(e_irq_indx), .irq_state_lo(dbg_irq_state),
    .timer_count(timer_count), .timer_ignore(timer_ignore)
`ifdef WG1_DIAG_MIRROR
    , .dbg_latch(irq_lt)
`endif
  );

  // ================= SPORT1 autobuffer + DACs =================
  wire        dma_rd; wire [13:0] dma_addr; reg dma_ready; reg [15:0] dma_rdata;
  wire        ireg_unsup; wire tick_stb; wire sp1_armed;
  wg1_dcs2_sport1 u_sp1 (
    .clk(clk), .por(por), .gate_mode(gate_mode), .retire(retire), .inj_tick(inj_tick),
    .sysctl_we(sysctl_we_r), .ctl_wd(ctl_wd_r), .s1ab_we(s1ab_we_r),
    .sysctl_q(ctl[31]), .s1ab_q(ctl[15]), .s1ctl_q(ctl[18]), .s1sclkdiv_q(ctl[17]),
    .tx1_we(e_tx1_we & ~tx1_q), .i_all(i_all), .m_all(m_all), .l_all(l_all),
    .i7_we(e_i7_we), .i7_wd(e_i7_wd), .irq1_pulse(irq1_pulse),
    .dma_rd(dma_rd), .dma_addr(dma_addr), .dma_ready(dma_ready), .dma_rdata(dma_rdata),
    .audio_l(audio_l), .audio_r(audio_r), .audio_ce(audio_ce), .dac_underruns(dac_underruns),
    .ireg_unsupported(ireg_unsup), .tick_stb(tick_stb), .armed_dbg(sp1_armed)
  );
`ifdef WG1_DCS2_GATE_TAP
  assign dbg_tick_stb = tick_stb;
  assign dbg_arm      = sp1_armed;
  assign dbg_eng_rst  = eng_rst;
`endif

  // ================= C5: DDR agent + ROM loader =================
  wire        rs_valid; wire [15:0] rs_data; wire rs_ready; reg [31:0] rs_woff;
  reg         c_req, c_we; reg [31:0] c_addr; reg [63:0] c_wdata; reg [7:0] c_be;
  wire        c_ack, c_rvalid; wire [63:0] c_rdata; wire [31:0] ddr_reads, ddr_writes; wire rs_idle, c_can_accept;
  dcs2_ddr_agent #(.ROM_BASE(ROM_B), .SRAM_BASE(PMS_B)) u_ddr (
    .clk(clk), .por(por),
    .s_read(m_read), .s_write(m_write), .s_address(m_address), .s_writedata(m_writedata),
    .s_byteenable(m_byteenable), .s_waitrequest(m_waitrequest),
    .s_readdatavalid(m_readdatavalid), .s_readdata(m_readdata),
    .rs_valid(rs_valid), .rs_data(rs_data), .rs_ready(rs_ready), .rs_woff(rs_woff),
    .c_req(c_req), .c_we(c_we), .c_addr(c_addr), .c_wdata(c_wdata), .c_be(c_be),
    .c_ack(c_ack), .c_rvalid(c_rvalid), .c_rdata(c_rdata),
    .ddr_reads(ddr_reads), .ddr_writes(ddr_writes), .rs_idle(rs_idle), .c_can_accept(c_can_accept)
  );
  wire ld_valid; wire [15:0] ld_data; wire ld_end; wire ld_seen; wire [31:0] ld_bytes, ld_crc, ld_acc, ld_drop;
  cusa_dcs_rom_loader #(.DCS_INDEX(ROM_INDEX), .EXPECTED_BYTES(32'h0000_8000)) u_ldr (
    .clk(clk), .por(por), .core_reset(reset),
    .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index), .ioctl_dout(ioctl_dout),
    .ioctl_wait(ioctl_wait),
    .dcs_in_valid(ld_valid), .dcs_in_data(ld_data), .dcs_in_ready(rs_ready | ~ld_valid),
    .dcs_stream_end(ld_end), .dcs_seen(ld_seen), .bytes_loaded(ld_bytes), .stream_crc(ld_crc),
    .accepted_writes(ld_acc), .dropped_writes(ld_drop), .reset_during_download(rom_reset_during_download)
  );
  assign rs_valid   = ld_valid;
  assign rs_data    = ld_data;
  assign rom_loaded = ld_end & rs_idle;
  assign rom_bytes  = ld_bytes;
  assign rom_crc    = ld_crc;
  always @(posedge clk) if (por) rs_woff <= 32'd0; else if (rs_valid && rs_ready) rs_woff <= rs_woff + 32'd1;

  // ================= S4: SRAM ON-CHIP (the DDR-backed PM/DM SRAM caches are removed) =================
  // The board's program SRAM (PM 0x0800-0x3fff when SM_EN) and data SRAM (DM view, sram_idx 0x0000-0x3fff)
  // are held in M10K outright: no tags, no misses, 1-clock registered reads. Initial content 0 (FPGA
  // configuration) = MAME value-initialised SRAM (dcs.cpp:849); never cleared by a reset (MAME neither).
  // PMS_B/DMS_B windows of C5 are no longer used (README C5 table).
  // PM array: 16K x 24 covering the whole PM space: 0x0000-0x03ff = the 2115's internal PM (dcs.cpp:349-353),
  // 0x0800-0x3fff = SRAM; 0x0400-0x07ff (and 0x0800+ while !SM_EN) are unmapped (read 0xffffff, writes dropped).
  // max_depth 8192 (synthesis only): 8Kx1 M10K slices -> a 2:1 read-data mux on the dispatch path, not 8:1
  (* ramstyle = "M10K, no_rw_check", max_depth = 8192 *) reg [23:0] pm_ram [0:16383];
  reg [23:0] pm_q; reg pmr_we; reg [13:0] pmr_wa; reg [23:0] pmr_wd;
  reg        pmi_we; reg [9:0] pmi_wa; reg [23:0] pmi_wd;          // boot-copy writes (registered)
`ifdef MUT_PM_512
  wire       pm_int_hit  = (e_pm_addr < 14'h0200);
`else
  wire       pm_int_hit  = (e_pm_addr < 14'h0400);
`endif
  wire       pm_mapped   = pm_int_hit | (SM_EN & (e_pm_addr >= 14'h0800));
  always @(*) begin                                   // one write port: boot copy (engine in reset) or engine
    pmr_we = pmi_we | (e_pm_wr & pm_mapped & ~eng_rst);
    pmr_wa = pmi_we ? {4'd0, pmi_wa} : e_pm_addr;
    pmr_wd = pmi_we ? pmi_wd : e_pm_wdata;
  end
  reg pm_um_q;
  always @(posedge clk) begin
    if (pmr_we) pm_ram[pmr_wa] <= pmr_wd;
    pm_q <= pm_ram[e_pm_addr];                        // read address = the engine's combinational port
`ifdef RDW_XMODEL
    if (pmr_we && pmr_wa == e_pm_addr) pm_q <= {$random} ^ 24'h5a5a5a;   // bench: read-during-write = garbage
`endif
    pm_um_q <= ~pm_mapped;
    e_pm_ready <= (e_pm_rd | e_pm_wr) & ~eng_rst;     // fixed 1-clock latency
  end
  assign e_pm_rdata = pm_um_q ? 24'hffffff : pm_q;
  // DM SRAM: 16K x 16 at sram_idx
  (* ramstyle = "M10K, no_rw_check", max_depth = 8192 *) reg [15:0] dm_ram [0:16383];
  reg [15:0] dm_q; reg dmr_we; reg [13:0] dmr_a; reg [15:0] dmr_wd;
  always @(posedge clk) begin
    if (dmr_we) dm_ram[dmr_a] <= dmr_wd;
    dm_q <= dm_ram[dmr_a];
`ifdef RDW_XMODEL
    if (dmr_we) dm_q <= {$random} ^ 16'hbeef;             // bench: read-during-write = garbage
`endif
  end

  // ================= C5 command arbiter: boot > direct (owner latched at accept) =========
  reg         bt_req; reg [31:0] bt_addr;                       // boot reads
  reg         dr_req, dr_we; reg [31:0] dr_addr; reg [63:0] dr_wdata; reg [7:0] dr_be;   // direct DRAM/ROM
  wire sel_bt  = bt_req;
  wire sel_dr  = ~bt_req & dr_req;
  always @(*) begin
    c_req = 1'b0; c_we = 1'b0; c_addr = 32'd0; c_wdata = 64'd0; c_be = 8'hff;
    if      (sel_bt)  begin c_req = 1'b1; c_addr = bt_addr; end
    else if (sel_dr)  begin c_req = 1'b1; c_we = dr_we;   c_addr = dr_addr;   c_wdata = dr_wdata; c_be = dr_be; end
  end
  reg [2:0] cmd_own, rd_own;         // 1 bt 4 direct
  reg c_we_own;                      // the in-flight command was a write
  always @(posedge clk) if (por) c_we_own <= 1'b0; else if (c_can_accept & c_req) c_we_own <= c_we;
  always @(posedge clk) begin
    if (por) begin cmd_own <= 3'd0; rd_own <= 3'd0; end
    else begin
      if (c_can_accept & c_req) cmd_own <= sel_bt ? 3'd1 : 3'd4;
      if (c_ack && !c_we_own) rd_own <= cmd_own; else if (c_rvalid) rd_own <= 3'd0;
    end
  end
  wire bt_ack  = (cmd_own == 3'd1) & c_ack;  wire bt_rv  = (rd_own == 3'd1) & c_rvalid;
  wire dr_ack  = (cmd_own == 3'd4) & c_ack;  wire dr_rv  = (rd_own == 3'd4) & c_rvalid;

  // ================= IRAM (512 x 16): single write port, registered read ======
  // S4: address/write controls are COMBINATIONAL from the DM access unit below (1-clock read)
  (* ramstyle = "M10K, no_rw_check" *) reg [15:0] iram [0:511];
  reg [15:0] iram_q; reg iri_we; reg [8:0] iri_wa; reg [15:0] iri_wd; reg [8:0] iri_ra;
  always @(posedge clk) begin
    if (iri_we) iram[iri_wa] <= iri_wd;
    iram_q <= iram[iri_ra];
`ifdef RDW_XMODEL
    if (iri_we && iri_wa == iri_ra) iram_q <= {$random} ^ 16'h1234;
`endif
  end

  // ================= boot FSM (dcs_boot, RAM-based) =================
  localparam B_IDLE = 3'd0, B_RD = 3'd1, B_RDW = 3'd2, B_WR0 = 3'd3, B_WR1 = 3'd4, B_DONE = 3'd5;
  reg [2:0]  b_st; reg [10:0] b_i; reg [11:0] b_len; reg b_have_len; reg [63:0] b_line; reg [2:0] b_pg;
  assign boot_busy     = (b_st != B_DONE);
  assign dbg_boot_busy = boot_busy;
  reg  boot_pm_we; reg [9:0] boot_pm_wa; reg [23:0] boot_pm_wd;
  wire [14:0] b_off = {b_pg, 12'd0} + {2'd0, b_i, 2'b00};          // byte offset of PM word b_i
  always @(posedge clk) begin
    boot_pm_we <= 1'b0;
    if (por) begin
      b_st <= B_IDLE; b_i <= 11'd0; b_have_len <= 1'b0; bt_req <= 1'b0; b_pg <= 3'd0; b_len <= 12'd0;
    end else begin
      if (bt_ack) bt_req <= 1'b0;
      if (dcs_rst || reboot_req) begin
        b_st <= B_IDLE; b_i <= 11'd0; b_have_len <= 1'b0; bt_req <= 1'b0;
        b_pg <= dcs_rst ? 3'd0 : ROM_PG;        // dcs_reset clears the SDRC first (sdrc_reset, :559)
      end else case (b_st)
        B_IDLE: if (rom_loaded) begin bt_req <= 1'b1; bt_addr <= ROM_B + {17'd0, b_off[14:3], 3'b000}; b_st <= B_RD; end
        B_RD:   if (bt_ack) b_st <= B_RDW;
        B_RDW:  if (bt_rv) begin
          b_line <= c_rdata;
          if (!b_have_len) begin b_len <= ({4'd0, c_rdata[31:24]} + 12'd1) << 3; b_have_len <= 1'b1; end
          b_st <= B_WR0;
        end
        B_WR0: begin   // word b_i (even: bytes 0..2, odd: bytes 4..6 of the beat)
          boot_pm_we <= 1'b1; boot_pm_wa <= b_i[9:0];
`ifdef MUT_BOOT_BYTE_ORDER
          boot_pm_wd <= b_i[0] ? {b_line[55:48], b_line[47:40], b_line[39:32]} : {b_line[23:16], b_line[15:8], b_line[7:0]};
`else
          boot_pm_wd <= b_i[0] ? {b_line[39:32], b_line[47:40], b_line[55:48]} : {b_line[7:0], b_line[15:8], b_line[23:16]};
`endif
          if ({1'b0, b_i} + 12'd1 >= b_len || b_i == 11'd1023) b_st <= B_DONE;
          else begin
            b_i <= b_i + 11'd1;
            b_st <= b_i[0] ? B_IDLE : B_WR0;       // next word shares the beat when b_i was even
          end
        end
        default: ;
      endcase
    end
  end
  // stub tracker: PM[0x18..0x1c] == {0c0030, 804828, 904828, 0c0020, 0a001f}
  function automatic stub_word(input [2:0] k, input [23:0] v);
    case (k) 3'd0: stub_word = (v == 24'h0c0030); 3'd1: stub_word = (v == 24'h804828);
             3'd2: stub_word = (v == 24'h904828); 3'd3: stub_word = (v == 24'h0c0020);
             default: stub_word = (v == 24'h0a001f); endcase
  endfunction
  // S4: fed from a registered copy of the PM write port (boot copy + engine writes, as pm_int's port was)
  reg stw_we; reg [13:0] stw_a; reg [23:0] stw_d;
  always @(posedge clk) begin stw_we <= pmr_we; stw_a <= pmr_wa; stw_d <= pmr_wd; end
  always @(posedge clk) begin
    if (por) stub_ok <= 5'd0;
    else if (stw_we && stw_a >= 14'h018 && stw_a <= 14'h01c) begin
      logic [13:0] k14; k14 = stw_a - 14'h018;
      stub_ok[k14[2:0]] <= stub_word(k14[2:0], stw_d);
    end
  end

  // ================= engine reset control =================
  always @(posedge clk) begin
    if (por) begin eng_rst <= 1'b1; cold <= 1'b1; end
    else begin
      eng_rst <= reset | ~dcs_reset | boot_busy | dcs_rst | reboot_req;
      if (eng_rst && !(reset | ~dcs_reset | boot_busy | dcs_rst | reboot_req)) cold <= 1'b0;
    end
  end

  // ================= PM: boot-copy write register (the array + engine port are above) ====
  always @(posedge clk) begin
    pmi_we <= boot_pm_we; pmi_wa <= boot_pm_wa; pmi_wd <= boot_pm_wd;
  end

  // ================= DM servicer (engine + SPORT1 DMA) =================
  // decode of address a (priority: DRAM window > ROM window > SRAM > static map)
  function automatic [2:0] dm_kind(input [13:0] a, input sm_en, input sm_bk, input rwe, input [13:0] rwb,
                                   input [14:0] rwl, input dwe, input [13:0] dwb);
    // 0 unmapped 1 dram 2 rom 3 sram 4 mailbox 5 sdrc 6 iram 7 ctl
    logic [14:0] a15; a15 = {1'b0, a};
    if (dwe && a >= dwb && a15 < {1'b0, dwb} + 15'h0400) dm_kind = 3'd1;
    else if (rwe && a >= rwb && a15 < {1'b0, rwb} + rwl) dm_kind = 3'd2;
    else if (sm_en && ((!sm_bk && a >= 14'h0800 && a <= 14'h37ff) || (sm_bk && a >= 14'h1800 && a <= 14'h37ff))) dm_kind = 3'd3;
    else if (a >= 14'h0400 && a <= 14'h0407) dm_kind = 3'd4;
    else if (a >= 14'h0480 && a <= 14'h0483) dm_kind = 3'd5;
    else if (a >= 14'h3800 && a <= 14'h39ff) dm_kind = 3'd6;
    else if (a >= 14'h3fe0) dm_kind = 3'd7;
    else dm_kind = 3'd0;
  endfunction
  // bank0: 0800->0000, 1800->1000, 2800->2000 (a uniform -0x800); bank1: 1800->3000 (+0x1800), 2800->2000
  function automatic [13:0] sram_idx(input sm_bk, input [13:0] a);
    if (!sm_bk || a >= 14'h2800) sram_idx = a - 14'h0800;
    else                         sram_idx = a + 14'h1800;
  endfunction

  // ---- S4 DM access unit. The engine issues ONE request pulse per access (e_dm_rd/e_dm_wr, registered in
  // the engine; e_dm_addr/e_dm_wdata stay stable until its next access). On-chip kinds (SRAM, IRAM, mailbox
  // 0x0400-0x0403, SDRC, control regs, unmapped) execute in the accept clock -- M10K/IRAM read address and
  // write enable are combinational from the accept, side-effect strobes registered exactly as the old
  // servicer's accept did -- and return data + ready the NEXT clock (fast_q). DRAM / ROM window / mailbox
  // FIFO words (0x0404-0x0407) take the old multi-phase path (dm_busy) and return a registered ready.
  // An engine request arriving while dm_busy (a slow SPORT1 DMA access) is latched (eng_wait).
  reg        dm_busy; reg [2:0] dm_k; reg dm_owner_dma; reg dm_we_l; reg [13:0] dm_a_l; reg [15:0] dm_wd_l;
  reg [1:0]  dm_ph; reg [2:0] rom_w_l;
  reg        eng_wait, eng_wait_we;
  reg        fast_q, fast_dma_q; reg [2:0] fk_q; reg poll0_q;
  reg        slow_rdy_q; reg [15:0] slow_d_q; reg dma_infl;
  // ---- S5 DRAM beat cache: 256 direct-mapped 64-bit beats (4 DRAM words each) in M10K, looked up in the
  // accept clock (combinational index -> registered read), hit/miss decided the next clock (dchk_q). Hit =
  // data + ready that clock (like the fast path); miss = the old C5 read, the returned beat is filled.
  // Coherence: the 2 MB store is written only through this unit; a DRAM write INVALIDATES its beat at the
  // write's C5 accept (after any in-flight fill -- C5 is single-outstanding, in order). Next-beat prefetch:
  // a read of beat B queues B+1 (issued when the unit and C5 are idle; a C5-bound access arriving while a
  // prefetch is in flight waits for it: c5_pend). A lookup colliding with a same-clock tag write is a miss.
  localparam integer DBI = 8;
  (* ramstyle = "M10K, no_rw_check" *) reg [63:0] dbc_data [0:(1<<DBI)-1];
  (* ramstyle = "M10K, no_rw_check" *) reg [18-DBI:0] dbc_tag [0:(1<<DBI)-1];   // {valid, beat[17:DBI]}
  reg [63:0] dbc_dq; reg [18-DBI:0] dbc_tq; reg dbc_coll_q;
  reg        dchk_q, dchk_dma_q; reg [17:0] beat_q;
  reg        dbc_clr; reg [DBI:0] dbc_ci;
  reg        c5_pend, pend_we; reg [31:0] pend_addr; reg [63:0] pend_wdata; reg [7:0] pend_be;
  reg        pf_want, pf_infl, pf_lv; reg [17:0] pf_beat, pf_beat_q, pf_last;
  reg [17:0] mbeat_q;                                   // beat of the slow DRAM access in progress
  wire       unit_busy  = dm_busy | dchk_q;
  wire eng_req    = (e_dm_rd | e_dm_wr | eng_wait) & ~eng_rst;
  wire eng_dm_new = eng_req & ~unit_busy;
  wire dma_new    = dma_rd & ~unit_busy & ~eng_req & ~dma_infl & ~dma_ready;
  wire [13:0] acc_a  = eng_dm_new ? e_dm_addr : dma_addr;
  wire        acc_we = eng_dm_new ? (eng_wait ? eng_wait_we : e_dm_wr) : 1'b0;
  wire [15:0] acc_wd = e_dm_wdata;
  wire [2:0]  acc_k  = dm_kind(acc_a, SM_EN, SM_BK, rw_en, rw_base, rw_len, dw_en, dw_base);
`ifdef MUT_DRAM_BANK
  wire [19:0] dram_w = ({1'b0, dm_pg_e, 9'd0} + {6'd0, acc_a - dw_base}) & 20'hFFFFF;
`else
  wire [19:0] dram_w = ({dm_pg_e, 10'd0} + {6'd0, acc_a - dw_base}) & 20'hFFFFF;   // % 1M words
`endif
  wire [14:0] rom_w  = ({rom_pg_e, 12'd0} + {1'b0, acc_a - rw_base}) & 15'h7FFF;    // % 32K words
  reg  [1:0]  lane;
  reg  [15:0] sdrc_rd;
  always @(*) begin
    case (acc_a[1:0])
      2'd0: sdrc_rd = sdrc0; 2'd1: sdrc_rd = sdrc1; 2'd2: sdrc_rd = sdrc2;
      default: case (SMODE)
        3'd0: sdrc_rd = 16'h5a81; 3'd1: sdrc_rd = 16'h5aa4; 3'd2: sdrc_rd = 16'h5a00 | {8'd0, sdrc_seed[5:0], 1'b0} & 16'h007e;
        3'd3: sdrc_rd = 16'h5ab9; 3'd4: sdrc_rd = 16'h5a03; 3'd5: sdrc_rd = 16'h5a69;
        3'd6: sdrc_rd = 16'h5a20; default: sdrc_rd = 16'h5aff; endcase
    endcase
  end
  reg [15:0] ctl_rd;
  always @(*) begin
    case (acc_a[4:0])
      5'h05: ctl_rd = (ctl[6] & ctl[5]) | (progflags & ~ctl[6]);     // PROG_FLAG_DATA (:1836-1843)
      5'h00: ctl_rd = 16'hffff;                                        // IDMA on a 2115 (:1845-1848)
      5'h1c: ctl_rd = timer_count;                                     // TIMER_COUNT (:1850-1854)
      default: ctl_rd = ctl[acc_a[4:0]];
    endcase
  end
  integer ci;
  // S4: comb SRAM / IRAM ports (accept clock)
  always @(*) begin
    dmr_a  = sram_idx(SM_BK, acc_a);
    dmr_wd = acc_wd;
    dmr_we = (eng_dm_new | dma_new) & (acc_k == 3'd3) & acc_we;
    iri_ra = acc_a[8:0]; iri_wa = acc_a[8:0]; iri_wd = acc_wd;
    iri_we = (eng_dm_new | dma_new) & (acc_k == 3'd6) & acc_we;
  end
  // S5 beat-cache ports: lookup index combinational at the accept; fills (miss / prefetch) and write
  // invalidations through one tag write port (+ the power-on clear walk)
  wire [DBI-1:0] dbc_ridx  = dram_w[DBI+1:2];
  wire       slow_rd_rv = dr_rv & ~pf_infl & dm_busy & (dm_k == 3'd1) & ~dm_we_l & (dm_ph == 2'd0);
  wire       pf_rv      = dr_rv & pf_infl;
  wire       inv_ack    = dr_ack & ~pf_infl & dm_busy & (dm_k == 3'd1) & dm_we_l & (dm_ph == 2'd0);
  wire [17:0] fill_beat = pf_infl ? pf_beat_q : mbeat_q;
  reg        dbc_twe, dbc_dwe; reg [DBI-1:0] dbc_twa; reg [18-DBI:0] dbc_twd;
  always @(*) begin
    dbc_dwe = slow_rd_rv | pf_rv;
    dbc_twe = dbc_clr | dbc_dwe | inv_ack;
    dbc_twa = dbc_clr ? dbc_ci[DBI-1:0] : (dbc_dwe ? fill_beat[DBI-1:0] : mbeat_q[DBI-1:0]);
`ifdef MUT_DBC_NOINVAL
    dbc_twd = dbc_dwe ? {1'b1, fill_beat[17:DBI]} : (dbc_clr ? {(19-DBI){1'b0}} : {1'b1, mbeat_q[17:DBI]});  // mutant: write keeps the stale line valid
`else
    dbc_twd = dbc_dwe ? {1'b1, fill_beat[17:DBI]} : {(19-DBI){1'b0}};
`endif
  end
  always @(posedge clk) begin
    if (dbc_dwe) dbc_data[fill_beat[DBI-1:0]] <= c_rdata;
    dbc_dq <= dbc_data[dbc_ridx];
`ifdef RDW_XMODEL
    if (dbc_dwe && fill_beat[DBI-1:0] == dbc_ridx) dbc_dq <= {$random, $random};
`endif
    if (dbc_twe) dbc_tag[dbc_twa] <= dbc_twd;
    dbc_tq <= dbc_tag[dbc_ridx];
`ifdef RDW_XMODEL
    if (dbc_twe && dbc_twa == dbc_ridx) dbc_tq <= dbc_twd;             // adversarial: the NEW tag
`endif
    dbc_coll_q <= dbc_twe & (dbc_twa == dbc_ridx);
  end
`ifdef VM_DBC_NOCOLL
  wire       dbc_hit  = (dbc_tq == {1'b1, beat_q[17:DBI]});              // verifier mutant: no collision guard
`else
  wire       dbc_hit  = (dbc_tq == {1'b1, beat_q[17:DBI]}) & ~dbc_coll_q;
`endif
`ifdef MUT_DBC_LANE
  wire [15:0] dbc_lane = dbc_dq[{~lane[1], lane[0], 4'b0000} +: 16];                   // mutant: wrong lane
`else
  wire [15:0] dbc_lane = dbc_dq[{lane, 4'b0000} +: 16];
`endif
  // fast-path read data (the clock after the accept)
  reg [15:0] fdata;
  always @(*) begin
    case (fk_q)
      3'd3: fdata = dm_q;
`ifdef MUT_POLL_OFFSET
      3'd6: fdata = poll0_q ? 16'h0000 : iram_q;
`else
      3'd6: fdata = iram_q;
`endif
      3'd4: fdata = mbx_rdata;
      default: fdata = dm_wd_l;
    endcase
  end
  assign e_dm_ready = (fast_q & ~fast_dma_q) | slow_rdy_q | (dchk_q & ~dchk_dma_q & dbc_hit);
  assign e_dm_rdata = fast_q ? fdata : (dchk_q ? dbc_lane : slow_d_q);
  wire acc_slow = ((acc_k == 3'd1) & acc_we) | (acc_k == 3'd2) | ((acc_k == 3'd4) & acc_a[2]);
  wire acc_dchk = (acc_k == 3'd1) & ~acc_we;
  // S5b: start a C5 access NOW (the unit is idle, so dr_req is free) unless a prefetch is in flight, in which
  // case it waits in pend_* (c5_pend) and is issued when the prefetch's data has returned.
  task automatic c5_start(input we, input [31:0] addr, input [63:0] wd, input [7:0] be);
    if (pf_infl) begin c5_pend <= 1'b1; pend_we <= we; pend_addr <= addr; pend_wdata <= wd; pend_be <= be; end
    else begin dr_req <= 1'b1; dr_we <= we; dr_addr <= addr; dr_wdata <= wd; dr_be <= be; end
  endtask
  always @(posedge clk) begin
    dma_ready <= 1'b0; mbx_acc_r <= 1'b0; slow_rdy_q <= 1'b0; fast_q <= 1'b0; dchk_q <= 1'b0;
    sysctl_we_r <= 1'b0; tscale_we_r <= 1'b0; tcount_we_r <= 1'b0; tperiod_we_r <= 1'b0; s1ab_we_r <= 1'b0;
    if (dr_ack) dr_req <= 1'b0;
    if (SM_EN) begin rom_pg_q <= ROM_PG; dm_pg_q <= DM_PG; end
    if (por) begin
      dm_busy <= 1'b0; dr_req <= 1'b0; reboot_req <= 1'b0; progflags <= 16'd0; eng_wait <= 1'b0; dma_infl <= 1'b0;
      c5_pend <= 1'b0; pf_want <= 1'b0; pf_infl <= 1'b0; pf_lv <= 1'b0; dbc_clr <= 1'b1; dbc_ci <= {(DBI+1){1'b0}};
      sdrc0 <= 16'd0; sdrc1 <= 16'd0; sdrc2 <= 16'd0; sdrc_seed <= 8'd0; rom_pg_q <= 3'd0; dm_pg_q <= 11'd0;
      for (ci = 0; ci < 32; ci = ci + 1) ctl[ci] <= 16'd0;
    end else begin
      if (dcs_rst) begin
        sdrc0 <= 16'd0; sdrc1 <= 16'd0; sdrc2 <= 16'd0;                 // sdrc_reset (:1040-1044)
        for (ci = 0; ci < 32; ci = ci + 1) ctl[ci] <= 16'd0;            // (:578)
      end
      reboot_req <= 1'b0;                  // one-clock pulse (set by a SYSCONTROL bit9 write below)
      // S5: beat-cache power-on clear walk (valid=0 through the one tag write port)
      if (dbc_clr) begin dbc_ci <= dbc_ci + 1'b1; if (dbc_ci == (1 << DBI) - 1) dbc_clr <= 1'b0; end
      // S5: C5 issue -- a deferred access (c5_pend) first, else a queued next-beat prefetch when all is idle
      if (c5_pend && !pf_infl && !dr_req) begin
        dr_req <= 1'b1; dr_we <= pend_we; dr_addr <= pend_addr; dr_wdata <= pend_wdata; dr_be <= pend_be; c5_pend <= 1'b0;
      end else if (pf_want && !pf_infl && !dr_req && !dm_busy && !dchk_q && !c5_pend && !(eng_dm_new || dma_new)) begin
`ifdef VM_PF_ADDR
        dr_req <= 1'b1; dr_we <= 1'b0; dr_addr <= DRAM_B + {11'd0, pf_beat + 18'd1, 3'b000}; dr_be <= 8'hff;
`else
        dr_req <= 1'b1; dr_we <= 1'b0; dr_addr <= DRAM_B + {11'd0, pf_beat, 3'b000}; dr_be <= 8'hff;
`endif
        pf_infl <= 1'b1; pf_want <= 1'b0; pf_beat_q <= pf_beat;
      end
      if (pf_rv) pf_infl <= 1'b0;                         // prefetched beat filled (dbc_dwe)
      if (inv_ack) pf_lv <= 1'b0;
      // S5: beat-cache lookup result (the clock after a DRAM read accept)
      if (dchk_q) begin
        if (dbc_hit) begin
          if (dchk_dma_q) begin dma_ready <= 1'b1; dma_rdata <= dbc_lane; end
        end else begin                                    // miss: the old C5 read (dm_k/owner/we set at accept)
          dm_busy <= 1'b1; mbeat_q <= beat_q;
          c5_start(1'b0, DRAM_B + {11'd0, beat_q, 3'b000}, 64'd0, 8'hff);
        end
`ifndef MUT_DBC_NOPF
        if (!pf_lv || (beat_q + 18'd1) != pf_last) begin
          pf_want <= 1'b1; pf_beat <= beat_q + 18'd1; pf_last <= beat_q + 18'd1; pf_lv <= 1'b1;
        end
`endif
      end
      // engine request latch (only while a slow DMA access / lookup holds the unit)
      if (eng_rst) eng_wait <= 1'b0;
`ifdef VM_EWAIT_WE
      else if ((e_dm_rd | e_dm_wr) & unit_busy) begin eng_wait <= 1'b1; eng_wait_we <= 1'b0; end   // verifier mutant
`else
      else if ((e_dm_rd | e_dm_wr) & unit_busy) begin eng_wait <= 1'b1; eng_wait_we <= e_dm_wr; end
`endif
      else if (eng_dm_new) eng_wait <= 1'b0;
      // fast-path completion for a DMA read (registered ready, as the old servicer)
      if (fast_q & fast_dma_q) begin dma_ready <= 1'b1; dma_rdata <= fdata; end
      if (dma_ready) dma_infl <= 1'b0;
      if (eng_dm_new || dma_new) begin
        dm_owner_dma <= ~eng_dm_new; dm_we_l <= acc_we; dm_a_l <= acc_a; dm_wd_l <= acc_wd; dm_k <= acc_k;
        dm_ph <= 2'd0; fk_q <= acc_k; fast_dma_q <= ~eng_dm_new; poll0_q <= (acc_a == 14'h3839);
        if (dma_new) dma_infl <= 1'b1;
        if (acc_slow) dm_busy <= 1'b1; else if (acc_dchk) dchk_q <= 1'b1; else fast_q <= 1'b1;
        dchk_dma_q <= ~eng_dm_new;
        case (acc_k)
          3'd1: begin   // DRAM window: one 16-bit word of the 2 MB store
            lane <= dram_w[1:0]; beat_q <= dram_w[19:2]; mbeat_q <= dram_w[19:2];
            if (acc_we)         // S5: write = the old C5 write, invalidates its beat at ack
              c5_start(1'b1, DRAM_B + {11'd0, dram_w[19:2], 3'b000}, {4{acc_wd}}, 8'b11 << {dram_w[1:0], 1'b0});
                                // read: beat-cache lookup (dchk_q next clock)
          end
          3'd2: begin   // ROM window (read-only): {00, u2 byte}
            if (acc_we) dm_ph <= 2'd3;
            else begin c5_start(1'b0, ROM_B + {17'd0, rom_w[14:3], 3'b000}, 64'd0, 8'hff); lane <= rom_w[1:0]; end
          end
          3'd4: begin mbx_acc_r <= 1'b1; mbx_we_r <= acc_we; mbx_off_r <= acc_a[2:0]; mbx_wd_r <= acc_wd; end
          3'd5: begin
            if (acc_we) case (acc_a[1:0])
              2'd0: sdrc0 <= acc_wd; 2'd1: sdrc1 <= acc_wd; 2'd2: sdrc2 <= acc_wd;
              default: case (SMODE)                                        // (:1134-1166)
                3'd1: sdrc_seed <= acc_wd[7:0];
                3'd3: sdrc_seed <= {sdrc_seed[6:0], 1'b1};
                3'd4: sdrc_seed <= sdrc_seed + {1'b0, sdrc_seed[7:1]};
                3'd5: sdrc_seed <= sdrc_seed ^ {sdrc_seed[6:0], 1'b1};
                3'd6: sdrc_seed <= {sdrc_seed[1] ^ sdrc_seed[3] ^ sdrc_seed[4] ^ sdrc_seed[5], sdrc_seed[7:1]};
                3'd7: sdrc_seed <= ~sdrc_seed;
                default: ;
              endcase
            endcase
            dm_wd_l <= sdrc_rd;
          end
          3'd7: begin
            if (acc_we) begin
              ctl_wd_r <= acc_wd;
              if (acc_a[4:0] == 5'h1f) begin
                sysctl_we_r <= 1'b1;
                if (acc_wd[9]) begin ctl[31] <= 16'd0; reboot_req <= 1'b1; end else ctl[31] <= acc_wd;
              end else ctl[acc_a[4:0]] <= acc_wd;
              if (acc_a[4:0] == 5'h0f) s1ab_we_r <= 1'b1;
              if (acc_a[4:0] == 5'h1b && ({8'd0, acc_wd[7:0]} != {8'd0, ctl[27][7:0]})) tscale_we_r <= 1'b1;  // (:1923-1931)
              if (acc_a[4:0] == 5'h1c) tcount_we_r <= 1'b1;
              if (acc_a[4:0] == 5'h1d && acc_wd != ctl[29]) tperiod_we_r <= 1'b1;
            end else if (acc_a[4:0] == 5'h05) progflags <= progflags ^ 16'h0006;
            dm_wd_l <= ctl_rd;
          end
          3'd3, 3'd6: ;                        // on-chip RAMs: comb ports above
          default: dm_wd_l <= 16'hffff;
        endcase
      end else if (dm_busy) begin
        case (dm_k)
          3'd1, 3'd2: begin
            if (dm_k == 3'd2 && dm_ph == 2'd3) dm_ph <= 2'd2;              // ROM write: ignored
            // S5: a prefetch's ack/data (pf_infl) never completes this access (it waits in c5_pend)
            else if (dm_we_l && dm_ph == 2'd0) begin if (dr_ack && !pf_infl && !c5_pend) dm_ph <= 2'd2; end
            else if (!dm_we_l && dm_ph == 2'd0 && dr_rv && !pf_infl && !c5_pend) begin
              dm_wd_l <= (dm_k == 3'd1) ? c_rdata[{lane, 4'b0000} +: 16] : {8'h00, c_rdata[{rom_w_l, 3'b000} +: 8]};
              dm_ph <= 2'd2;
            end
          end
          3'd4: begin if (dm_ph == 2'd0) begin dm_wd_l <= mbx_rdata; dm_ph <= 2'd1; end    // FIFO words (off[2])
                      else if (dm_ph == 2'd1) begin dm_wd_l <= fifo_q; dm_ph <= 2'd2; end end
          default: dm_ph <= 2'd2;
        endcase
        if (dm_ph == 2'd2) begin
          dm_busy <= 1'b0;
          if (dm_owner_dma) begin dma_ready <= 1'b1; dma_rdata <= dm_wd_l; end
          else begin slow_rdy_q <= 1'b1; slow_d_q <= dm_wd_l; end
        end
      end
    end
  end
  always @(posedge clk) if (eng_dm_new || dma_new) rom_w_l <= rom_w[2:0];

  // mailbox accesses complete one clock after accept; mbx_rdata is combinational on the registered
  // offset -> captured in phase 0 above (the access strobe mbx_acc_r is high on that same clock).
  assign mbx_acc = mbx_acc_r;

  assign cfg_unsupported = ireg_unsup | (rw_en & (ROM_ST == 2'd2) & ~ROM_SZ);
  assign dbg_dm_we    = eng_dm_new & acc_we;
  assign dbg_dm_addr  = e_dm_addr;
  assign dbg_dm_wdata = e_dm_wdata;
`ifdef WG1_DIAG_MIRROR
  // observe-only (header layout). The reply strobe is exactly wg1_dcs2_mbx's dsp_out latch write (por / dcs_rst win).
  assign dbg_mirror = {mbx_wd_r, mbx_acc_r & mbx_we_r & (mbx_off_r == 3'd1) & ~por & ~dcs_rst,
                       inv_ack, pf_rv, dbc_dwe, dchk_q & ~dbc_hit, dchk_q & dbc_hit,
                       e_irq_ack_indx, e_irq_ack, dbg_irq_state, irq_lt, icntl, imask,
                       iri_wd, iri_wa, iri_we, pmr_wd, pmr_wa, pmr_we};
`endif
`ifdef WG1_DIAG_MIRROR
  assign dbg_rst = {eng_rst, reboot_req, dcs_rst, ~dcs_reset, boot_busy};
  // every DSP write into the sample-DRAM window, at the DM unit accept (engine or DMA owner; DMA never writes)
  assign dbg_dramw = {(eng_dm_new | dma_new) & (acc_k == 3'd1) & acc_we, dram_w, acc_wd};
`endif
endmodule
`default_nettype wire
