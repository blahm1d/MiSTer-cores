// wg1_dcs2_sport1.sv -- DCS2 SPORT1 autobuffer (MAME's half-buffer block model), sample-rate generator
// and the two DACs. FORK of zeus1/rtl/dcs2/dcs2_autobuf.sv (md5 9c39ee6ddf73d6bd5ead24e5cae29168,
// CAL1 block autobuffer) with the War Gods differences; timer + IRQ mux moved to wg1_dcs2_irq.sv.
// Gospel MAME 0.289 src/mame/shared/dcs.cpp:
//   sound_tx_callback :2043-2094  arm on a SPORT1 TX write when SYSCONTROL bit11 and S1_AUTOBUF bit1:
//                     ireg=(AB>>9)&7, mreg=((AB>>7)&3)|(ireg&4), lreg=ireg; size=L, incs=M (saved);
//                     I[ireg] = I[ireg] & ~0xf (= ireg_base); recompute_sample_rate. Else disarm.
//   recompute_sample_rate :2014-2041  S1_CONTROL bit14: frame = 2*(SCLKDIV+1)*16*channels DSP clocks
//                     (16 MHz) = 64*(SCLKDIV+1) DSP cycles; else 31.25 kHz (512 DSP cycles). Tick period =
//                     frame * size / (2*channels*incs); no tick when incs == 0.
//   dcs_irq           :1960-1997  reg=I[ireg]; count=size/(2*incs); DAC <- DM[reg + k*incs], k<count;
//                     reg += count*incs; ibase = I[ireg] & lmask(L[ireg]) (adsp2100 get_ibase,
//                     2100ops.hxx:335-341, mask table adsp2100.cpp:1089-1106); if reg >= ibase+size:
//                     reg = ibase and pulse IRQ1; I[ireg] = reg.
//   adsp_control_w    :1882-1914  SYSCONTROL write with bit11 clear, or S1_AUTOBUF write with bit1 clear:
//                     disarm (reg_timer reset). dcs_reset does NOT touch the reg_timer (:543-603).
//   channels          :822 (2); dmadac routes :2562-2563 (dac1 = even words -> dcs out 0, dac2 = odd ->
//                     out 1); midvunit.cpp:1260-1261 route dcs out 0 -> speaker 1 (RIGHT), out 1 -> 0 (LEFT).
// Engine I-register side write: the engine only exposes I7 (dcs2_engine i7_we); War Gods programs ireg 7
// (S1_AUTOBUF 0x0F82 boot test, 0x0E82 game, g1 golden). ireg != 7 raises `ireg_unsupported`.
`default_nettype none
module wg1_dcs2_sport1 #(
  // frame length in DSP cycles (one per retired instruction, MAME's time basis for the DSP):
  parameter integer EXT_FRAME_CLK = 512,      // 31.25 kHz external sample clock @ 16 MHz (dcs.cpp:2028)
  parameter integer INT_FRAME_MUL = 64,       // 2*(SCLKDIV+1)*16 bits*2 channels DSP clocks (dcs.cpp:2022-2024)
  parameter integer FIFO_AW       = 9
) (
  input  wire        clk,
  input  wire        por,
  input  wire        gate_mode,               // bench: rate generator off, ticks injected
  input  wire        retire,                  // one DSP cycle (retired instruction)
  input  wire        inj_tick,
  // control-register writes (value = written data) and current values
  input  wire        sysctl_we, input wire [15:0] ctl_wd,
  input  wire        s1ab_we,
  input  wire [15:0] sysctl_q, s1ab_q, s1ctl_q, s1sclkdiv_q,
  input  wire        tx1_we,                  // engine wrote SPORT1 TX
  // engine DAG registers (dbg)
  input  wire [13:0] i_all [0:7],
  input  wire [13:0] m_all [0:7],
  input  wire [13:0] l_all [0:7],
  output reg         i7_we, output reg [13:0] i7_wd,
  output reg         irq1_pulse,
  // DAC DMA read port into the DM decode (lower priority than the engine)
  output reg         dma_rd, output reg [13:0] dma_addr,
  input  wire        dma_ready, input wire [15:0] dma_rdata,
  // audio
  output reg  signed [15:0] audio_l, audio_r,
  output reg         audio_ce,
  output reg  [31:0] dac_underruns,
  output reg         ireg_unsupported,
  output reg         tick_stb,
  output wire        armed_dbg          // arming level (for the wg1_dcs2 gate tap; no synthesis effect)
);
  assign armed_dbg = armed;
  wire [2:0] ab_ireg = s1ab_q[11:9];
  wire [2:0] ab_mreg = {ab_ireg[2], s1ab_q[8:7]};

  reg        armed;
  reg [2:0]  ireg;
  reg [13:0] size, incs, count, adv;         // adv = count*incs
  reg        rate_int; reg [15:0] sclk;
  // divider state (count = size / (2*incs), computed once per arm)
  reg        div_busy; reg [4:0] div_i; reg [14:0] div_rem; reg [13:0] div_q; reg [14:0] div_d;

  function automatic [13:0] lmask(input [13:0] l);
    if      (l > 14'h2000) lmask = 14'h0000; else if (l > 14'h1000) lmask = 14'h2000;
    else if (l > 14'h0800) lmask = 14'h3000; else if (l > 14'h0400) lmask = 14'h3800;
    else if (l > 14'h0200) lmask = 14'h3c00; else if (l > 14'h0100) lmask = 14'h3e00;
    else if (l > 14'h0080) lmask = 14'h3f00; else if (l > 14'h0040) lmask = 14'h3f80;
    else if (l > 14'h0020) lmask = 14'h3fc0; else if (l > 14'h0010) lmask = 14'h3fe0;
    else if (l > 14'h0008) lmask = 14'h3ff0; else if (l > 14'h0004) lmask = 14'h3ff8;
    else if (l > 14'h0002) lmask = 14'h3ffc; else if (l > 14'h0001) lmask = 14'h3ffe;
    else                   lmask = 14'h3fff;
  endfunction

  // ---- frame strobe (guest sample rate) ----
  reg [21:0] fdiv; reg frame;
  wire [21:0] frame_len = rate_int ? (INT_FRAME_MUL * ({6'd0, sclk} + 22'd1)) : EXT_FRAME_CLK;
  // ---- tick cadence: + 2*channels*incs per frame, fire when >= size ----
  reg [21:0] acc;
`ifdef MUT_ONE_CHANNEL
  wire [21:0] step = {7'd0, incs, 1'b0};      // V5: tick period uses 1 channel (period doubles, dcs.cpp:2038 2*m_channels)
`else
  wire [21:0] step = {6'd0, incs, 2'b00};
`endif
  wire cad_fire = armed && !gate_mode && frame && (incs != 14'd0) && ((acc + step) >= {8'd0, size});
  wire tick = armed && !div_busy && (cad_fire || inj_tick);

  // ---- DMA of one tick's words into the DAC FIFO ----
  reg        dma_on; reg [13:0] dma_left; reg dma_phase;   // phase 0 = even word (RIGHT), 1 = odd (LEFT)
  reg signed [15:0] pend_r;
  reg signed [15:0] fl [0:(1<<FIFO_AW)-1];
  reg signed [15:0] fr [0:(1<<FIFO_AW)-1];
  reg [FIFO_AW:0] wp, rp;

  always @(posedge clk) begin
    i7_we <= 1'b0; irq1_pulse <= 1'b0; audio_ce <= 1'b0; frame <= 1'b0; tick_stb <= 1'b0;
    if (por) begin
      armed <= 1'b0; ireg <= 3'd7; size <= 14'd0; incs <= 14'd0; count <= 14'd0; adv <= 14'd0;
      rate_int <= 1'b0; sclk <= 16'd0; div_busy <= 1'b0; acc <= 22'd0; fdiv <= 22'd0;
      dma_on <= 1'b0; dma_rd <= 1'b0; dma_left <= 14'd0; dma_phase <= 1'b0; wp <= 0; rp <= 0;
      audio_l <= 16'sd0; audio_r <= 16'sd0; dac_underruns <= 32'd0; ireg_unsupported <= 1'b0;
      div_i <= 5'd0; div_rem <= 15'd0; div_q <= 14'd0; div_d <= 15'd0; pend_r <= 16'sd0;
    end else begin
      // frame generator
      if (retire && fdiv + 22'd1 >= frame_len) begin fdiv <= 22'd0; frame <= 1'b1; end
      else if (retire) fdiv <= fdiv + 22'd1;

      // disarm (adsp_control_w) / arm (sound_tx_callback)
      if ((sysctl_we && !ctl_wd[11]) || (s1ab_we && !ctl_wd[1])) armed <= 1'b0;
      else if (tx1_we) begin
        if (sysctl_q[11] && s1ab_q[1]) begin
          armed <= 1'b1; ireg <= ab_ireg;
          size <= l_all[ab_ireg]; incs <= m_all[ab_mreg];
          rate_int <= s1ctl_q[14]; sclk <= s1sclkdiv_q;
          i7_we <= 1'b1; i7_wd <= i_all[ab_ireg] & 14'h3ff0;
          if (ab_ireg != 3'd7) ireg_unsupported <= 1'b1;
          acc <= 22'd0;
`ifndef MUT_FREE_FRAME
          // recompute_sample_rate restarts the half-buffer timer AT the arm instant: m_reg_timer->adjust(period,
          // 0, period) (dcs.cpp:2036-2040, called from sound_tx_callback :2082) -> first tick = arm + period.
          // The frame grid restarts here too (a free-running grid fired the first tick up to one frame early:
          // measured 306 DSP cycles before MAME at the War Gods upload, gate B-T op 26067).
`ifdef MUT_HALF_FRAME
          fdiv <= 22'd256;    // V1: arm restart at a half-frame phase -> first tick 256 DSP cycles early
`else
          fdiv <= 22'd0;
`endif
`endif
          // count = size / (2*(incs?incs:1)) : 15-step restoring division
          div_busy <= 1'b1; div_i <= 5'd0; div_rem <= 15'd0; div_q <= 14'd0;
          div_d <= {(m_all[ab_mreg] == 14'd0) ? 14'd1 : m_all[ab_mreg], 1'b0};
        end else armed <= 1'b0;
      end

      if (div_busy) begin
        // shift in size bits MSB first
        logic [15:0] r2;
        r2 = {div_rem, size[13 - div_i]};
        if (r2 >= {1'b0, div_d}) begin div_rem <= r2[14:0] - div_d; div_q <= {div_q[12:0], 1'b1}; end
        else begin div_rem <= r2[14:0]; div_q <= {div_q[12:0], 1'b0}; end
        if (div_i == 5'd13) div_busy <= 1'b0; else div_i <= div_i + 5'd1;
      end else if (armed) begin
        count <= div_q;
        adv   <= div_q * ((incs == 14'd0) ? 14'd1 : incs);
      end

      if (cad_fire) acc <= acc + step - {8'd0, size};
      else if (armed && !gate_mode && frame && incs != 14'd0) acc <= acc + step;

      // dcs_irq
      if (tick) begin
        logic [14:0] regp; logic [13:0] ib; logic [13:0] curi;
        tick_stb <= 1'b1;
        curi = i_all[ireg];
        regp = {1'b0, curi} + {1'b0, adv};
        ib   = curi & lmask(l_all[ireg]);
`ifdef MUT_WRAP_GT
        if (regp >  ({1'b0, ib} + {1'b0, size})) begin i7_we <= 1'b1; i7_wd <= ib; irq1_pulse <= 1'b1; end   // V4: strict wrap (dcs.cpp:1984 >=)
`else
        if (regp >= ({1'b0, ib} + {1'b0, size})) begin i7_we <= 1'b1; i7_wd <= ib; irq1_pulse <= 1'b1; end
`endif
        else begin i7_we <= 1'b1; i7_wd <= regp[13:0]; end
        if (!dma_on && count != 14'd0) begin
          dma_on <= 1'b1; dma_rd <= 1'b1; dma_addr <= curi; dma_left <= count;
        end
      end

      // DMA: one word per dma_ready; interleaved R (even) / L (odd) -> FIFO pair
      if (dma_on && dma_ready) begin
        if (!dma_phase) pend_r <= $signed(dma_rdata);
        else if (wp - rp != (1 << FIFO_AW)) begin
          fr[wp[FIFO_AW-1:0]] <= pend_r; fl[wp[FIFO_AW-1:0]] <= $signed(dma_rdata); wp <= wp + 1'b1;
        end
        dma_phase <= ~dma_phase;
        dma_addr <= dma_addr + incs;
        if (dma_left == 14'd1) begin dma_on <= 1'b0; dma_rd <= 1'b0; end
        dma_left <= dma_left - 14'd1;
      end

      // DAC: one stereo frame per frame strobe while armed
      if (frame) begin
        audio_ce <= 1'b1;
`ifdef MUT_LR_SWAP
        // mutant: even words (dac1 -> dcs out 0) played LEFT (misreads midvunit.cpp:1260-1261)
        if (wp != rp) begin audio_r <= fl[rp[FIFO_AW-1:0]]; audio_l <= fr[rp[FIFO_AW-1:0]]; rp <= rp + 1'b1; end
`else
        if (wp != rp) begin audio_l <= fl[rp[FIFO_AW-1:0]]; audio_r <= fr[rp[FIFO_AW-1:0]]; rp <= rp + 1'b1; end
`endif
        else if (armed) dac_underruns <= dac_underruns + 32'd1;
      end
    end
  end
endmodule
`default_nettype wire
