`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// cusa_dcs_rom_loader.sv -- DCS sound-ROM capture path (50 MHz clk, POWER-ON reset only, P0022).
//
// Receives the boot-time hps_io ioctl ROM stream (WIDE=1 => 16-bit ioctl_dout, ioctl_addr in bytes)
// for ioctl index DCS_INDEX (=2, the eight sound ROMs u2..u9 concatenated, 4 MiB, no interleave --
// MRA stream CRC-32 0x692a64fa). It buffers the 16-bit words in a synchronous FIFO and presents them
// as a 16-bit stream (dcs_in_valid/dcs_in_data, dcs_in_ready back-pressure) to the DDR writer, which
// packs 4->64 and stores them linearly at the DCS DDR window.
//
// P0022 (doctrine section 6): MiSTer Main holds the CORE reset high across the whole ioctl download
// (measured on the bw1 cabinet). This module therefore runs on `por` (power-on reset, a 2-FF-synced
// ~locked), NOT the core reset, so the capture path is alive while the ROM lands. `core_reset` is
// only MONITORED: a reset-independent latch records whether it was ever high during the download
// (the tell that the download would have frozen a core-reset-domained capture path). ioctl_wait is
// asserted ONLY from FIFO high-water while the stream is still open (never tied high -- tying it high
// hangs MiSTer Main: memory mister-ioctl-wait-high-hangs-main); once the full 4 MiB is captured the
// stream closes and any further offered word is dropped and counted (build-3 bw1 fix).
module cusa_dcs_rom_loader #(
    parameter [7:0]  DCS_INDEX     = 8'd2,
    parameter [31:0] EXPECTED_BYTES = 32'h0040_0000,  // 4 MiB (u2..u9, 8 x 0x80000)
    parameter integer FIFO_ADDR_BITS = 9,             // 512 x 16b
    parameter integer HIGH_WATER     = 384            // of 512
) (
    input  wire        clk,
    input  wire        por,           // power-on reset (module reset, P0022)
    input  wire        core_reset,    // core/warm reset -- MONITORED, never used as reset here
    // hps_io ioctl (WIDE=1)
    input  wire        ioctl_download,
    input  wire        ioctl_wr,
    input  wire [15:0] ioctl_index,
    input  wire [15:0] ioctl_dout,
    output wire        ioctl_wait,
    // 16-bit stream to the DDR writer
    output reg         dcs_in_valid,
    output reg  [15:0] dcs_in_data,
    input  wire        dcs_in_ready,
    output reg         dcs_stream_end,  // producer finished AND the FIFO fully drained
    // status / audit
    output reg         dcs_seen,
    output reg  [31:0] bytes_loaded,    // accepted bytes (== dcs_words*2)
    output reg  [31:0] stream_crc,      // CRC-32 of the accepted byte stream (final)
    output reg  [31:0] accepted_writes, // accepted 16-bit words
    output reg  [31:0] dropped_writes,  // 16-bit words offered but dropped
    output reg         reset_during_download
);
    function automatic [31:0] crc_byte(input [31:0] prev, input [7:0] val);
        reg [31:0] c; integer n;
        begin c = prev ^ {24'd0, val}; for (n=0;n<8;n=n+1) c = (c>>1) ^ (c[0]?32'hedb88320:32'd0); crc_byte = c; end
    endfunction

    wire is_dcs   = ioctl_download && (ioctl_index[7:0] == DCS_INDEX);
    wire dcs_open = (bytes_loaded < EXPECTED_BYTES);   // still accepting the stream

    // synchronous staging FIFO (one clock domain)
    reg          fifo_wr_en;
    reg  [15:0]  fifo_wr_data;
    wire         fifo_full;
    wire [FIFO_ADDR_BITS:0] fifo_level;
    reg          fifo_rd_en;
    wire [15:0]  fifo_rdata;
    wire         fifo_empty;
    cusa_dcs_fifo #(.WIDTH(16), .ADDR_BITS(FIFO_ADDR_BITS)) fifo (
        .clk(clk), .rst(por),
        .wr_en(fifo_wr_en), .wr_data(fifo_wr_data), .full(fifo_full), .level(fifo_level),
        .rd_en(fifo_rd_en), .rd_data(fifo_rdata), .empty(fifo_empty));

    // ioctl_wait: high-water back-pressure while the stream is open. Never tied high; releases as
    // soon as the writer drains the FIFO, and unconditionally once the full stream is captured.
    assign ioctl_wait = is_dcs && dcs_open && (fifo_full || fifo_level >= HIGH_WATER[FIFO_ADDR_BITS:0]);

    reg [31:0] crc;
    reg        dcs_dl_q;

    always @(posedge clk) begin
        fifo_wr_en <= 1'b0;
        fifo_rd_en <= 1'b0;
        if (por) begin
            dcs_seen<=1'b0; bytes_loaded<=32'd0; stream_crc<=32'd0; accepted_writes<=32'd0;
            dropped_writes<=32'd0; reset_during_download<=1'b0; dcs_stream_end<=1'b0;
            dcs_in_valid<=1'b0; dcs_in_data<=16'd0; crc<=32'hffffffff; dcs_dl_q<=1'b0;
            fifo_wr_data<=16'd0;
        end else begin
            // P0022 reset-independent audit latch (not cleared by core_reset)
            if (ioctl_download && core_reset) reset_during_download <= 1'b1;

            dcs_dl_q <= is_dcs;
            if (is_dcs) dcs_seen <= 1'b1;
            // latch the final CRC when the DCS download ends (falling edge of is_dcs)
            if (dcs_dl_q && !is_dcs) stream_crc <= crc ^ 32'hffffffff;

            // accept ioctl words into the FIFO while the stream is open
            if (ioctl_wr && is_dcs) begin
                if (dcs_open && !fifo_full) begin
                    fifo_wr_en   <= 1'b1;
                    fifo_wr_data <= ioctl_dout;
                    accepted_writes <= accepted_writes + 32'd1;
                    bytes_loaded    <= bytes_loaded + 32'd2;
                    crc <= crc_byte(crc_byte(crc, ioctl_dout[7:0]), ioctl_dout[15:8]);
                end else begin
                    dropped_writes <= dropped_writes + 32'd1;
                end
            end

            // drain the FIFO into the 16-bit stream to the DDR writer
            if (dcs_in_valid && dcs_in_ready) dcs_in_valid <= 1'b0;
            if (!dcs_in_valid && !fifo_empty && dcs_in_ready) begin
                dcs_in_valid <= 1'b1;
                dcs_in_data  <= fifo_rdata;
                fifo_rd_en   <= 1'b1;
            end

            // stream end: producer finished AND the FIFO fully drained AND no pending word
            if (dcs_seen && !is_dcs && fifo_empty && !dcs_in_valid) dcs_stream_end <= 1'b1;
        end
    end
endmodule
`default_nettype wire
