// wg1_dcs2_irq.sv -- ADSP-2115 interrupt lines/latches + priority/mask selection, the DCS2 SPORT0 1 kHz
// tick and the ADSP-2101-family timer. NET-NEW, transcribed from MAME 0.289:
//   devices/cpu/adsp2100/adsp2100.cpp (git f34f02505e3):
//     execute_set_input :1166-1172  latch on a CLEAR->ASSERT transition; state = level
//     generate_irq      :891-913    (2101 family) mask bit 0x20>>indx; clears latch[which]
//     check_irqs        :967-1000   order IRQ2(indx0) SPORT0_TX(1) SPORT0_RX(2) IRQ1(3) IRQ0(4) TIMER(5);
//                                   IRQ2/1/0 use latch when ICNTL bit (4/2/1) set, else the level;
//                                   a MASKED source does not block a lower-priority one.
//     device_reset      :661-663    every state and latch cleared on CPU reset
//     line numbers      adsp2100.h:66-73 (ADSP2115_IRQ0=0 IRQ1=1 IRQ2=2 SPORT0_RX=3 SPORT0_TX=4 TIMER=5)
//   src/mame/shared/dcs.cpp:
//     sport0_irq        :1999-2011  SPORT0_RX assert+clear, skipped if output_control was read <=5 DSP cycles ago
//     SYSCONTROL write  :1889-1904  bit12 set -> 1 kHz SPORT0 tick, first after 10 us (re-phased per write);
//                                   bit12 clear -> stop
//     timer             :1693-1803  first fire scale*(count+1) cycles after (re)start, then every scale*(period+1);
//                                   scale = (TSCALE & 0xff)+1 (:1924); IRQ = ADSP2105_TIMER (:1735-1736)
//     timer_ignore      :1750-1768  at (re)start, if PM[0x18..0x1c] is the DRAM-refresh stub the timer never fires
//                                   (sticky until dcs_reset, :596)
//   dcs_irq IRQ1 pulse :1991 pulse_input_line(IRQ1, minimum quantum): the golden shows the IRQ1 level high for
//                       exactly the first instruction after the pulse (81/81 wraps, g1 trace) -> level clears on
//                       the next retired instruction.
// Timers count RETIRED DSP instructions (MAME counts m_cpu->total_cycles(); 1 cycle per instruction on this
// core). SPORT0 counts fabric clocks (a guest-time 1 kHz, 50 MHz clk).
`default_nettype none
module wg1_dcs2_irq #(
  // SPORT0 tick in DSP cycles (16 MHz, one per retired instruction -- the basis MAME's scheduler uses for
  // the DSP; decoupled from the engine's fabric CPI): first after 10 us, then every 1 ms (dcs.cpp:1896)
  parameter integer SP0_FIRST  = 160,
  parameter integer SP0_PERIOD = 16000
) (
  input  wire        clk,
  input  wire        cpu_rst,          // CPU reset (device_reset): clears states/latches
  input  wire        dcs_rst,          // dcs_reset pulse: timer_ignore cleared, timers stopped
  input  wire        gate_mode,        // bench: internal SPORT0/timer generators off (events injected)
  input  wire        retire,           // one engine instruction retired
  input  wire        insn_start,       // an instruction's first cycle (pre-state sampled)
  // line events
  input  wire        irq2_set, irq2_clr,
  input  wire        irq1_pulse,       // dcs_irq wrap
  input  wire        inj_sport0,       // bench: SPORT0 tick at a golden instant
  input  wire        inj_timer,        // bench: timer fire at a golden instant
  input  wire        inj_irq2_up,      // bench (gate_mode): IRQ2 level rise at a golden instant
  input  wire        inj_irq2_dn,      // bench (gate_mode): IRQ2 level fall at a golden instant
                                       // (MAME queues every set_input_line through the scheduler, so its
                                       //  IRQ2 level lags the latch flags by a scheduling-dependent amount)
  // SPORT0 control
  input  wire        sysctl_we,        // DSP wrote SYSCONTROL (0x3fff)
  input  wire [15:0] sysctl_wd,
  input  wire        ctl_read,         // DSP read output_control (0x0402)
  // timer control (adsp_control writes; value = written data)
  input  wire        tscale_we, tcount_we, tperiod_we,
  input  wire [15:0] ctl_wd,
  input  wire [15:0] tscale_q, tperiod_q,    // current register values (m_control_regs)
  input  wire        timer_ena,        // MSTAT bit 5 (2100ops.hxx:74,87-88)
  input  wire        stub_match,       // PM[0x18..0x1c] == refresh stub (tracked by the board)
  // engine interface
  input  wire [5:0]  imask,
  input  wire [4:0]  icntl,
  input  wire        irq_ack,
  input  wire [2:0]  irq_ack_indx,
  output reg         irq_take,
  output reg  [2:0]  irq_indx,
  output wire [3:0]  irq_state_lo,     // m_irq_state[0..3] (the trace's IRQ0..IRQ3 fields)
  output reg  [15:0] timer_count,      // live TCOUNT (adsp_control_r TIMER_COUNT_REG)
  output reg         timer_ignore
`ifdef WG1_DIAG_MIRROR
  // observe-only cabinet diag tap (wg1_status_mirror block B); absent without the macro (port list unchanged)
  , output wire [5:0] dbg_latch        // lt: the latched (pending) interrupt bits, index = ADSP2115 line number
`endif
);
  reg [5:0] st, lt;                    // state / latch, index = ADSP2115 line number
  assign irq_state_lo = st[3:0];
`ifdef WG1_DIAG_MIRROR
  assign dbg_latch = lt;
`endif
  reg irq1_clr_pend, irq1_seen;        // clear after the first instruction that STARTED with the level high

  // ---- SPORT0 1 kHz ----
  reg        sp0_run; reg [16:0] sp0_cnt; reg [3:0] since_ctl; reg sp0_fire;
  always @(posedge clk) begin
    sp0_fire <= 1'b0;
    if (dcs_rst) begin sp0_run <= 1'b0; sp0_cnt <= 17'd0; since_ctl <= 4'd15; end
    else begin
      if (ctl_read) since_ctl <= 4'd0;
      else if (retire && since_ctl != 4'd15) since_ctl <= since_ctl + 4'd1;
      if (sysctl_we) begin
        sp0_run <= sysctl_wd[12];
        sp0_cnt <= SP0_FIRST[16:0] - 17'd1;
      end else if (sp0_run && !gate_mode && retire) begin
        if (sp0_cnt == 17'd0) begin sp0_cnt <= SP0_PERIOD[16:0] - 17'd1; sp0_fire <= 1'b1; end
        else sp0_cnt <= sp0_cnt - 17'd1;
      end
    end
  end
  // dcs.cpp:2005-2010: diff = total_cycles - output_control_cycles; fire only if diff > 5
  wire sp0_evt = (sp0_fire && since_ctl > 4'd5) || inj_sport0;

  // ---- ADSP timer ----
  wire [15:0] t_scale = {8'd0, tscale_q[7:0]} + 16'd1;
  reg  [15:0] t_div;                   // cycles left in the current count
  reg         t_armed;
  reg         tmr_fire;
  wire        t_restart = tscale_we | tcount_we | tperiod_we;
  reg         ena_q;
  always @(posedge clk) begin
    tmr_fire <= 1'b0;
    if (dcs_rst) begin timer_ignore <= 1'b0; t_armed <= 1'b0; ena_q <= 1'b0; timer_count <= 16'd0; t_div <= 16'd0; end
    else begin
      ena_q <= timer_ena;
      if (tcount_we) timer_count <= ctl_wd;
      if ((timer_ena && !ena_q) || (timer_ena && t_restart)) begin
        // reset_timer (dcs.cpp:1740-1784): the refresh-stub check only while not already ignoring;
        // an ignored timer still counts (update_timer_count, :1693-1719) but never interrupts (:1782)
        if (!timer_ignore && stub_match) timer_ignore <= 1'b1;
        t_armed <= 1'b1; t_div <= ((tscale_we ? {8'd0, ctl_wd[7:0]} + 16'd1 : t_scale)) - 16'd1;
      end else if (!timer_ena) t_armed <= 1'b0;
      else if (t_armed && retire) begin
        if (t_div != 16'd0) t_div <= t_div - 16'd1;
        else begin
          t_div <= t_scale - 16'd1;
          if (timer_count == 16'd0) begin tmr_fire <= !timer_ignore && !gate_mode; timer_count <= tperiod_q; end
          else timer_count <= timer_count - 16'd1;
        end
      end
    end
  end
  wire tmr_evt = tmr_fire || inj_timer;

  // ---- lines + latches (execute_set_input) ----
  // generate_irq clears latch[which]; indx -> which: 0->IRQ2(2) 1->SPORT0_TX(4) 2->SPORT0_RX(3) 3->IRQ1(1)
  // 4->IRQ0(0) 5->TIMER(5)
  wire i2_up = gate_mode ? inj_irq2_up : irq2_set;
  wire i2_dn = gate_mode ? inj_irq2_dn : irq2_clr;
  reg [5:0] ack_clr, set_l;
  always @(*) begin
    ack_clr = 6'd0;
    if (irq_ack) case (irq_ack_indx)
      3'd0: ack_clr[2] = 1'b1; 3'd1: ack_clr[4] = 1'b1; 3'd2: ack_clr[3] = 1'b1;
      3'd3: ack_clr[1] = 1'b1; 3'd4: ack_clr[0] = 1'b1; default: ack_clr[5] = 1'b1;
    endcase
    set_l = {tmr_evt, 1'b0, sp0_evt, i2_up & ~st[2], irq1_pulse & ~st[1], 1'b0};
  end
  always @(posedge clk) begin
    if (cpu_rst) begin st <= 6'd0; lt <= 6'd0; irq1_clr_pend <= 1'b0; irq1_seen <= 1'b0; end
    else begin
      lt <= (lt & ~ack_clr) | set_l;
      // IRQ2: host level
      if (i2_up) st[2] <= 1'b1;
      else if (i2_dn) st[2] <= 1'b0;
      // IRQ1: pulse, level visible for one instruction
      if (irq1_pulse) begin st[1] <= 1'b1; irq1_clr_pend <= 1'b1; irq1_seen <= 1'b0; end
      else if (irq1_clr_pend) begin
        if (insn_start) irq1_seen <= 1'b1;
        // S4: a 1-clock instruction starts and retires in the same clock (insn_start with retire)
`ifdef MUT_IRQ1_SAMECLK
        if (irq1_seen && retire) begin st[1] <= 1'b0; irq1_clr_pend <= 1'b0; irq1_seen <= 1'b0; end   // mutant: pre-S4 rule
`else
        if ((irq1_seen | insn_start) && retire) begin st[1] <= 1'b0; irq1_clr_pend <= 1'b0; irq1_seen <= 1'b0; end
`endif
      end
    end
  end

  // ---- check_irqs selection (combinational; the engine re-applies the mask and pushes) ----
  wire c_irq2 = icntl[2] ? lt[2] : st[2];
  wire c_irq1 = icntl[1] ? lt[1] : st[1];
  wire c_irq0 = icntl[0] ? lt[0] : st[0];
  always @(*) begin
    irq_take = 1'b1; irq_indx = 3'd0;
`ifdef MUT_IRQ_MASKBLOCK
    // mutant: a pending-but-masked source blocks every lower-priority one (misreads check_irqs' `&&`)
    if      (c_irq2) begin irq_indx = 3'd0; irq_take = imask[5]; end
    else if (lt[4])  begin irq_indx = 3'd1; irq_take = imask[4]; end
    else if (lt[3])  begin irq_indx = 3'd2; irq_take = imask[3]; end
    else if (c_irq1) begin irq_indx = 3'd3; irq_take = imask[2]; end
    else if (c_irq0) begin irq_indx = 3'd4; irq_take = imask[1]; end
    else if (lt[5])  begin irq_indx = 3'd5; irq_take = imask[0]; end
    else irq_take = 1'b0;
`else
    if      (c_irq2 && imask[5]) irq_indx = 3'd0;
    else if (lt[4]  && imask[4]) irq_indx = 3'd1;
    else if (lt[3]  && imask[3]) irq_indx = 3'd2;
    else if (c_irq1 && imask[2]) irq_indx = 3'd3;
    else if (c_irq0 && imask[1]) irq_indx = 3'd4;
    else if (lt[5]  && imask[0]) irq_indx = 3'd5;
    else irq_take = 1'b0;
`endif
  end
endmodule
`default_nettype wire
