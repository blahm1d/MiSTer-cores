// wg1_dcs2_mbx.sv -- War Gods DCS2 host<->DSP latch pair (NET-NEW, transcribed from MAME 0.289
// src/mame/shared/dcs.cpp). Host side = wg1 CONTRACTS C2 (sound side). DSP side = DM 0x0400-0x0407
// (dcs2_2115_data_map, dcs.cpp:362-369). One clock, synchronous active-high resets.
//
// Gospel (dcs.cpp):
//   latch control   : bit 11 INPUT_EMPTY, bit 10 OUTPUT_EMPTY (:174-187); control_r = m_latch_control (:1442-1453)
//   data_w          : DCS2 has m_sport0_timer -> dcs_delayed_data_w immediately (:1529-1541): IRQ2 ASSERT,
//                     input_empty_cb(0), SET_INPUT_FULL, m_input_data = data (:1503-1520).
//                     (preprocess_write = MAME's HLE transfer shortcut, :2426-2450 -- NOT hardware, not modeled)
//   ack_w           : synchronize(delayed_ack_w) -> SET_OUTPUT_EMPTY (:1607-1623)
//   data_r          : side effect output_full_cb(0) if it was 1 (auto_ack false for DCS2, :851) (:1626-1643)
//   data2_r         : m_output_control (:1677-1683)
//   DSP 0x0400 rd   : input_latch_r = m_input_data, no ack (auto_ack false) (:1555-1564)
//   DSP 0x0400 wr   : input_latch_ack_w: input_empty_cb(1), SET_INPUT_EMPTY, IRQ2 CLEAR (:1544-1552)
//   DSP 0x0401 wr   : output_latch_w -> latch_delayed_w: output_full_cb(1), SET_OUTPUT_FULL, data (:1581-1596)
//   DSP 0x0402 rw   : output_control_r / _w (:1651-1674)
//   DSP 0x0403 rd   : latch_status_r: 0x80 input full | 0x40 output empty | fifo_status & 0x38 (:1474-1486)
//   DSP 0x0404-7 rd : fifo_input_r = fifo_data_r() (ioasic fifo_r pop) (:1489-1495)
//   unmapped halves : 0x0401 rd, 0x0403 wr, 0x0404-7 wr -> map.unmap_value_high (:364) = 0xffff / ignored
//   dcs_reset       : SET_INPUT_EMPTY, SET_OUTPUT_EMPTY, input_empty_cb(1), output_full_cb(0), IRQ lines
//                     cleared (:579-590). input/output data and output_control persist.
// MAME's synchronize() deferrals are zero-guest-time in hardware: applied on the access clock.
`default_nettype none
module wg1_dcs2_mbx (
  input  wire        clk,
  input  wire        dcs_rst,        // one-clock dcs_reset pulse (por / core reset / host reset_w(0))
  input  wire        por,            // power-on: data registers to 0 (device construction)
  // ---- host side (C2) ----
  input  wire        dcs_data_we,
  input  wire [15:0] dcs_data_w,
  input  wire        dcs_ack_we,
  input  wire        dcs_data_rd,    // host read of SOUNDIN (data_r side effect; see README C2 note)
  output wire [15:0] dcs_data_r,
  output wire [15:0] dcs_data2_r,
  output wire [15:0] dcs_control,
  output reg         dcs_output_full,
  output reg         dcs_input_empty,
  input  wire [15:0] fifo_q,
  input  wire [15:0] fifo_status,
  output wire        fifo_rd,
  // ---- DSP side ----
  input  wire        dm_acc,         // one-clock strobe: a DM access to 0x0400-0x0407 is accepted now
  input  wire        dm_we,
  input  wire [2:0]  dm_off,
  input  wire [15:0] dm_wdata,
  output reg  [15:0] dm_rdata,       // combinational read value for dm_off (valid with dm_acc)
  output wire        ctl_read,       // 0x0402 read accepted (SPORT0 interlock, dcs.cpp:1671, 2005)
  // ---- to the IRQ controller ----
  output wire        irq2_set,       // IRQ2 ASSERT (host data_w)
  output wire        irq2_clr        // IRQ2 CLEAR  (DSP input_latch_ack_w)
);
  reg [15:0] in_data, out_data, out_ctrl;
  reg        in_empty, out_empty;

  assign dcs_data_r  = out_data;
  assign dcs_data2_r = out_ctrl;
`ifdef MUT_CONTROL_BITS
  assign dcs_control = {4'd0, out_empty, in_empty, 10'd0};
`else
  assign dcs_control = {4'd0, in_empty, out_empty, 10'd0};
`endif

  always @(*) begin
    case (dm_off)
      3'd0:    dm_rdata = in_data;
      3'd2:    dm_rdata = out_ctrl;
      3'd3:    dm_rdata = {8'd0, ~in_empty, out_empty, 6'd0} | (fifo_status & 16'h0038);
      3'd4, 3'd5, 3'd6, 3'd7: dm_rdata = fifo_q;
      default: dm_rdata = 16'hffff;          // 0x0401 read: unmapped
    endcase
  end

  wire dsp_ack  = dm_acc &  dm_we & (dm_off == 3'd0);
  wire dsp_out  = dm_acc &  dm_we & (dm_off == 3'd1);
  wire dsp_ctlw = dm_acc &  dm_we & (dm_off == 3'd2);
  assign ctl_read = dm_acc & ~dm_we & (dm_off == 3'd2);
  assign fifo_rd  = dm_acc & ~dm_we & dm_off[2];
  assign irq2_set = dcs_data_we;
  assign irq2_clr = dsp_ack;

  always @(posedge clk) begin
    if (por) begin
      in_data <= 16'd0; out_data <= 16'd0; out_ctrl <= 16'd0;
      in_empty <= 1'b1; out_empty <= 1'b1; dcs_input_empty <= 1'b1; dcs_output_full <= 1'b0;
    end else if (dcs_rst) begin
`ifdef MUT_RST_KEEP_OUT
      in_empty <= 1'b1; dcs_input_empty <= 1'b1; dcs_output_full <= 1'b0;   // V3: reset omits SET_OUTPUT_EMPTY (dcs.cpp:586)
`else
      in_empty <= 1'b1; out_empty <= 1'b1; dcs_input_empty <= 1'b1; dcs_output_full <= 1'b0;
`endif
    end else begin
      // host side
      if (dcs_data_we) begin in_data <= dcs_data_w; in_empty <= 1'b0; dcs_input_empty <= 1'b0; end
`ifndef MUT_OUT_ACK
      if (dcs_ack_we)  out_empty <= 1'b1;
`endif
`ifndef MUT_DATA_RD_NOCLEAR
      if (dcs_data_rd) dcs_output_full <= 1'b0;   // V2: data_r side effect output_full_cb(0) (dcs.cpp:1635-1636)
`endif
      // DSP side (a same-clock host event and DSP event on the same flag: the DSP access is later in
      // program order only if it was accepted after the host event; both on one clock -> DSP wins
      // for the flag it writes, which is the order MAME's scheduler would also produce)
      if (dsp_ack) begin in_empty <= 1'b1; dcs_input_empty <= 1'b1; end
      if (dsp_out) begin out_data <= dm_wdata; out_empty <= 1'b0; dcs_output_full <= 1'b1; end
      if (dsp_ctlw) out_ctrl <= dm_wdata;
    end
  end
endmodule
`default_nettype wire
