// wg1 FORK: copied 2026-09-24 from D:/deck/fpga/zeus/zeus1/rtl/dcs2/dcs2_engine.sv
//   (md5 abf87a87d60080b46b31d8014aa87a1e, the area-lane serial-shifter checkpoint). Changes, all marked
//   "wg1 fork": (1) i7_we latch outside the ce gate; (2) MSTAT register writes swap the register bank
//   (update_mstat, 2100ops.hxx:445/79-85 -- DONOR BUG: MSTAT=imm / MSTAT=DM(..) never swapped); (3) mode
//   control ENA/DIS TIMER bit (adsp2100.cpp:1367 -- donor omitted; War Gods firmware never executes it, gate =
//   unit/mode). Original note: the
//   i7_we side-write latch moved outside the `ce` gate (see "wg1 fork" below). ADSP-2115 = same core
//   (adsp2100.cpp:283-285, adsp2101_device family); the 1K internal PM is a board property.
// dcs2_engine.sv -- compact ADSP-2104 (ADSP-2101 family) DCS2 sound engine for MK4.
// Written BLIND from MAME 0.289 gospel (adsp2100.cpp :1176-1921 dispatch, 2100ops.hxx
// ALU/MAC/shift/DAG/stacks/condition/reg maps). NOT transcribed from the Python golden.
//
// Multi-cycle FSM, single clock + clock-enable (P0019 no async crossing):
//   S_FETCH : issue PM read @pc (bench injects interrupts before fetch)
//   S_DEC   : wait pm_ready; latch opcode; compute ALL next-state combinationally
//             (ALU/MAC/shift/flags/DAG post-modify/pc/loop/stacks/reg writes); issue mem op0
//   S_MEM   : wait *_ready; capture read0->dest; issue/capture read1 (dual 0xc0-0xff); write wait
//   commit  : one-cycle pulse; DUT state == golden "before next instruction" snapshot
// Clocked memory only. PM 24-bit + DM 16-bit ports with ready handshakes so a DDR3-backed SRAM +
// hot cache with variable/hostile latency stalls the engine on a miss (bench drives *_ready).
//
// wg1 S4 (dcs2-next, 2026-09-24): FETCH/EXECUTE OVERLAP + SEQUENTIAL PREFETCH (semantics of Zeus ckpt4o
// lanes/dcs2-area/fit/zk4_dcs2_20ns_v4o/src/dcs2_engine.sv sha256 937fc79a -- "the committing instruction
// also issues the next fetch"; re-implemented here on the wg1 fork, datapath untouched):
//   * PM port is now COMBINATIONAL (pm_rd/pm_wr/pm_addr/pm_wdata): the fetch address goes straight to the
//     board's PM M10K read address. The engine fetches CONTINUOUSLY: while an instruction dispatches from
//     pc it fetches pc+1 (sequential prediction), otherwise it (re)fetches pc. Fixed contract: pm_ready and
//     pm_rdata the cycle after the request (registered memory). An opcode is used only when the address
//     fetched last cycle equals pc (fa_q==pc); a taken branch/call/return/loop-back costs one refetch clock.
//   * S_FETCH is gone: S_DEC is the instruction boundary. In one S_DEC clock, in priority order: a pending
//     autobuffer I[7] write is applied; else an IRQ is taken (push pc, pc=vector, refetch); else the fetched
//     opcode dispatches. Non-memory instructions complete in their dispatch clock (1 clk/instr sequential).
//   * DM/PM data accesses: one request pulse each (registered), the engine waits in S_MEM for *_ready; the
//     dual 0xC0-0xFF DM and PM reads run CONCURRENTLY (separate ports; destinations are disjoint registers).
//   * `commit` is COMBINATIONAL: high in the clock whose edge retires the instruction (consumers register it,
//     so every retired-count consumer is up to date at the next instruction's dispatch clock).
//   * `hold` (bench dsp_hold / pacer) is REGISTERED (hold_q) and only gates the boundary actions (IRQ take,
//     dispatch); `istart` = dispatch clock (pre-state visible), `bnd` = at a boundary and not acting this clock.
//   * SPORT1 TX write (wreg3 0x0b): the boundary is blocked for 2 clocks (tx_stall) so the sport1 arm ->
//     i7_we -> i7_pend chain lands before the next instruction (replaces the board's sp1_hold, MAME applies
//     the I7 write inside the TX write, dcs.cpp:2075). An incoming i7_we also blocks the boundary for a clock.
`default_nettype none
module dcs2_engine (
  input  wire clk, rst, ce,
  input  wire hold,                                // boundary hold (registered inside: hold_q)
  output logic pm_rd, pm_wr, output logic [13:0] pm_addr, output logic [23:0] pm_wdata,   // COMBINATIONAL
  input  wire [23:0] pm_rdata, input wire pm_ready,
  output reg  dm_rd, dm_wr, output reg [13:0] dm_addr, output reg [15:0] dm_wdata,
  input  wire [15:0] dm_rdata, input wire dm_ready,
  input  wire irq_take, input wire [2:0] irq_indx,
  input  wire i7_we, input wire [13:0] i7_wd,      // SPORT1 autobuffer side-write of I[7] (=reg):
                                                   // MAME dcs_irq set_state_int(ADSP2100_I0+ireg,reg)
                                                   // (dcs.cpp:1995). Block advance+wrap computed by
                                                   // dcs2_autobuf; NOT a DAG +M7 step. ireg==7 (MK4).
  input  wire warm_rst,                            // reset preserves data regs/DAG/CNTR/PX/ICNTL (ADSP
                                                   // device_reset: warm self-reboot). Cold (0) clears.
  output reg  irq_ack, output reg [2:0] irq_ack_indx,  // pulse when an IRQ is TAKEN (clears latched src)
  output reg  tx1_we,                               // 1-clk pulse: DSP wrote SPORT1 TX reg (arm the
                                                   // autobuffer, sound_tx_callback offset 1 --
                                                   // wreg3 regnum 0x0b, 2100ops.hxx:452)
  input  wire seed_en, input wire [1887:0] seed,   // load architectural state at reset (fight window)
  output logic commit,                             // COMBINATIONAL: the instruction retires at this edge
  output logic istart,                             // COMBINATIONAL: an instruction dispatches this clock
  output logic bnd,                                // COMBINATIONAL: at a boundary, no boundary action this clock
  output wire [1887:0] dbg      // 59 fields x 32b, cpu_field order (bench compares, masked in C++)
);
  function automatic [31:0] sf(input [1887:0] s, input integer i); sf = s[i*32 +: 32]; endfunction
  localparam ZBIT=0,NBIT=1,VBIT=2,CBIT=3,SBIT=4,QBIT=5,MVBIT=6,SSBIT=7;
  localparam MST_BANK=0,MST_REV=1,MST_STV=2,MST_SAT=3,MST_INT=4;

  // banked datapath regs (adsp_core); [0] primary [1] alt, bs=current
  logic [15:0] ax0[2],ax1[2],ay0[2],ay1[2],ar[2],af[2],mx0[2],mx1[2],my0[2],my1[2],mf[2],si[2];
  logic [39:0] mr[2]; logic [31:0] sr[2]; logic [7:0] se[2]; logic [4:0] sb[2]; logic bs;
  logic [13:0] I[8],L[8]; logic signed [13:0] Msg[8]; logic [7:0] px;
  logic [13:0] pc,ppc,loopreg; logic loop_active; logic [3:0] loop_cond; logic [15:0] cntr;
  logic [7:0] astat,sstat; logic [6:0] mstat,mstat_prev; logic [5:0] imask; logic [4:0] icntl; logic [3:0] irq_state;
  logic [13:0] pcst[16]; logic [4:0] pcsp;
  logic [17:0] lpst[4];  logic [2:0] lpsp;
  logic [13:0] cnst[4];  logic [2:0] cnsp;
  logic [20:0] stst[4];  logic [2:0] stsp;
  localparam [7:0] ACLR_STV=~(8'h0b), ACLR_NORM=~(8'h0f);
  wire [7:0] aclr = mstat[MST_STV]?ACLR_STV:ACLR_NORM;

  function automatic [13:0] lmask_of(input [13:0] Lv);
    if(Lv>14'h2000)lmask_of=14'h0;else if(Lv>14'h1000)lmask_of=14'h2000;else if(Lv>14'h0800)lmask_of=14'h3000;
    else if(Lv>14'h0400)lmask_of=14'h3800;else if(Lv>14'h0200)lmask_of=14'h3c00;else if(Lv>14'h0100)lmask_of=14'h3e00;
    else if(Lv>14'h0080)lmask_of=14'h3f00;else if(Lv>14'h0040)lmask_of=14'h3f80;else if(Lv>14'h0020)lmask_of=14'h3fc0;
    else if(Lv>14'h0010)lmask_of=14'h3fe0;else if(Lv>14'h0008)lmask_of=14'h3ff0;else if(Lv>14'h0004)lmask_of=14'h3ff8;
    else if(Lv>14'h0002)lmask_of=14'h3ffc;else if(Lv>14'h0001)lmask_of=14'h3ffe;else lmask_of=14'h3fff;
  endfunction
  function automatic [2:0] m3(input [2:0] x); m3=x; endfunction
  function automatic [13:0] dag_next(input [13:0] iv,input signed [13:0] mv,input [13:0] lv);
`ifdef ABL_DAG
    dag_next=iv;
`else
    logic [13:0] base,nx; base=iv&lmask_of(lv); nx=(iv+mv)&14'h3fff;
    if(nx<base) nx=nx+lv; else if(nx>=(base+lv)) nx=nx-lv; dag_next=nx;
`endif
  endfunction
  function automatic [13:0] rev14(input [13:0] x); integer b; for(b=0;b<14;b=b+1) rev14[b]=x[13-b]; endfunction
  function automatic logic cond_s(input [3:0] c,input [7:0] a);
    logic az,an,av,ac,as_,mv; az=a[0];an=a[1];av=a[2];ac=a[3];as_=a[4];mv=a[6];
    case(c) 0:cond_s=az;1:cond_s=~az;2:cond_s=~((an^av)|az);3:cond_s=((an^av)|az);4:cond_s=(an^av);5:cond_s=~(an^av);
      6:cond_s=av;7:cond_s=~av;8:cond_s=ac;9:cond_s=~ac;10:cond_s=as_;11:cond_s=~as_;12:cond_s=mv;13:cond_s=~mv;
      15:cond_s=1'b1;default:cond_s=1'b0; endcase
  endfunction
  function automatic [15:0] consty(input [4:0] i);
    case(i) 0:consty=16'h0001;1:consty=16'hfffe;2:consty=16'h0002;3:consty=16'hfffd;4:consty=16'h0004;5:consty=16'hfffb;
    6:consty=16'h0008;7:consty=16'hfff7;8:consty=16'h0010;9:consty=16'hffef;10:consty=16'h0020;11:consty=16'hffdf;
    12:consty=16'h0040;13:consty=16'hffbf;14:consty=16'h0080;15:consty=16'hff7f;16:consty=16'h0100;17:consty=16'hfeff;
    18:consty=16'h0200;19:consty=16'hfdff;20:consty=16'h0400;21:consty=16'hfbff;22:consty=16'h0800;23:consty=16'hf7ff;
    24:consty=16'h1000;25:consty=16'hefff;26:consty=16'h2000;27:consty=16'hdfff;28:consty=16'h4000;29:consty=16'hbfff;
    30:consty=16'h8000;31:consty=16'h7fff; endcase
  endfunction
  function automatic integer clz(input [31:0] v); integer i; begin clz=32; for(i=31;i>=0;i=i-1) if(v[i]&&clz==32) clz=31-i; end endfunction
  function automatic integer clo(input [31:0] v); clo=clz(~v); endfunction

  function automatic [15:0] rd0(input [3:0] r);
    case(r) 0:rd0=ax0[bs];1:rd0=ax1[bs];2:rd0=mx0[bs];3:rd0=mx1[bs];4:rd0=ay0[bs];5:rd0=ay1[bs];6:rd0=my0[bs];7:rd0=my1[bs];
    8:rd0=si[bs];9:rd0={{8{se[bs][7]}},se[bs]};10:rd0=ar[bs];11:rd0=mr[bs][15:0];12:rd0=mr[bs][31:16];
    13:rd0={{8{mr[bs][39]}},mr[bs][39:32]};14:rd0=sr[bs][15:0];15:rd0=sr[bs][31:16]; endcase
  endfunction
  function automatic [15:0] rd1f(input [3:0] r);
    case(r[3:2]) 0:rd1f={2'b0,I[r[1:0]]};1:rd1f={{2{Msg[r[1:0]][13]}},Msg[r[1:0]]};default:rd1f={2'b0,L[r[1:0]]}; endcase endfunction
  function automatic [15:0] rd2f(input [3:0] r); logic [2:0] x; x={1'b1,r[1:0]};
    case(r[3:2]) 0:rd2f={2'b0,I[x]};1:rd2f={{2{Msg[x][13]}},Msg[x]};default:rd2f={2'b0,L[x]}; endcase endfunction
  function automatic [15:0] rd3f(input [3:0] r);
    case(r) 0:rd3f={8'b0,astat};1:rd3f={9'b0,mstat};2:rd3f={8'b0,sstat};3:rd3f={10'b0,imask};4:rd3f={11'b0,icntl};
    5:rd3f={2'b0,cntr[13:0]};6:rd3f={{11{sb[bs][4]}},sb[bs]};7:rd3f={8'b0,px};default:rd3f=16'h0; endcase endfunction
  function automatic [15:0] alux(input [2:0] s);
`ifdef ABL_RDMUX
    alux=16'h0;
`else
    case(s) 0:alux=ax0[bs];1:alux=ax1[bs];2:alux=ar[bs];3:alux=mr[bs][15:0];4:alux=mr[bs][31:16];5:alux={{8{mr[bs][39]}},mr[bs][39:32]};6:alux=sr[bs][15:0];7:alux=sr[bs][31:16]; endcase
`endif
 endfunction
  function automatic [15:0] aluy(input [1:0] s); `ifdef ABL_RDMUX aluy=16'h0; `else case(s) 0:aluy=ay0[bs];1:aluy=ay1[bs];2:aluy=af[bs];default:aluy=16'h0; endcase `endif endfunction
  function automatic [15:0] macx(input [2:0] s);
`ifdef ABL_RDMUX
    macx=16'h0;
`else
    case(s) 0:macx=mx0[bs];1:macx=mx1[bs];2:macx=ar[bs];3:macx=mr[bs][15:0];4:macx=mr[bs][31:16];5:macx={{8{mr[bs][39]}},mr[bs][39:32]};6:macx=sr[bs][15:0];7:macx=sr[bs][31:16]; endcase
`endif
 endfunction
  function automatic [15:0] macy(input [1:0] s); `ifdef ABL_RDMUX macy=16'h0; `else case(s) 0:macy=my0[bs];1:macy=my1[bs];2:macy=mf[bs];default:macy=16'h0; endcase `endif endfunction
  function automatic [15:0] shxf(input [2:0] s);
`ifdef ABL_RDMUX
    shxf=16'h0;
`else
    case(s) 0:shxf=si[bs];1:shxf=si[bs];2:shxf=ar[bs];3:shxf=mr[bs][15:0];4:shxf=mr[bs][31:16];5:shxf={{8{mr[bs][39]}},mr[bs][39:32]};6:shxf=sr[bs][15:0];7:shxf=sr[bs][31:16]; endcase
`endif
 endfunction

  // ---- ALU eval (returns via outputs) ----
  function automatic [23:0] alu_eval(input [23:0] op,input logic isc,input [7:0] ain,input [15:0] xop); // {astat,res16}
    logic [3:0] code; logic [16:0] x,y,r; logic [15:0] xu,yu; logic [7:0] a; logic cin;
`ifdef ABL_ALU
    alu_eval={ain,16'h0};
`else
    code=op[16:13]; xu=xop; yu=isc?consty({op[12:11],op[7:5]}):aluy(op[12:11]);
    a=ain; cin=a[CBIT]; x={1'b0,xu}; y={1'b0,yu};
    if(code==4'hf) begin  // ABS X (no `return`: Quartus-17-safe function-name assign)
      a=ain&aclr; a[SBIT]=0; r=xu[15]?(17'h0-{1'b0,xu}):{1'b0,xu};
      if(xu==16'h0)a[ZBIT]=1; if(xu==16'h8000)begin a[NBIT]=1;a[VBIT]=1;end if(xu[15])a[SBIT]=1;
      alu_eval={a,r[15:0]};
    end else begin
      a=ain&aclr;
      case(code)
        0:r=y; 1:begin r=y+1;if(yu==16'h7fff)a[VBIT]=1;else if(yu==16'hffff)a[CBIT]=1;end
        2:begin y=y+{16'b0,cin};r=x+y;end 3:r=x+y; 4:r={1'b0,(yu^16'hffff)};
        5:begin r=(17'h0-y);if(yu==16'h8000)a[VBIT]=1;if(yu==16'h0000)a[CBIT]=1;end
        6:r=x-y+{16'b0,cin}-17'h1; 7:r=x-y;
        8:begin r=y-17'h1;if(yu==16'h8000)a[VBIT]=1;else if(yu==16'h0000)a[CBIT]=1;end
        9:r=y-x; 10:r=y-x+{16'b0,cin}-17'h1; 11:r={1'b0,(xu^16'hffff)}; 12:r={1'b0,(xu&yu)}; 13:r={1'b0,(xu|yu)}; 14:r={1'b0,(xu^yu)};
        default:r=17'h0;
      endcase
      a[NBIT]=r[15]; a[ZBIT]=(r[15:0]==16'h0);
      // CALC_V = (s^d^r^(r>>1))>>13 & 4  == bit15 of (s^d^r^(r>>1)) = s[15]^d[15]^r[15]^r[16]
      case(code) 2,3:begin a[VBIT]=(x[15]^y[15]^r[15]^r[16]);a[CBIT]=r[16];end
        6,7:begin a[VBIT]=(x[15]^y[15]^r[15]^r[16]);a[CBIT]=~r[16];end
        9,10:begin a[VBIT]=(y[15]^x[15]^r[15]^r[16]);a[CBIT]=~r[16];end default:; endcase
      alu_eval={a,r[15:0]};
    end
`endif
  endfunction
  function automatic [15:0] sat_ar(input [15:0] r,input [7:0] a);
    sat_ar=(mstat[MST_SAT]&&a[VBIT])?(a[CBIT]?16'h8000:16'h7fff):r; endfunction

  // ---- MAC eval : {astat, res40} in 48 bits ----
  // task (not function-with-output; Quartus-17-safe): mv={astat,res40}
  task automatic mac_eval(input [23:0] op,input [7:0] ain,input [15:0] xop,output [47:0] mv,output logic noop);
    logic [3:0] code; logic sh,xsg,ysg; logic signed [16:0] xe,ye; logic [15:0] xu,yu;
    logic signed [33:0] prod; logic signed [63:0] tmp,acc,res; logic [8:0] ov; logic [15:0] tlo; logic [7:0] a;
`ifdef ABL_MAC
    mv={ain,40'h0}; noop=1'b1;
`else
    code=op[16:13]; sh=mstat[MST_INT]?1'b0:1'b1; a=ain; noop=0; mv={ain,40'h0};
    if(code==0)begin noop=1; end
    else begin
      xu=xop; yu=macy(op[12:11]);
      xsg=!(code==4'h6||code==4'h7||code==4'ha||code==4'hb||code==4'he||code==4'hf);
      ysg=!(code==4'h5||code==4'h7||code==4'h9||code==4'hb||code==4'hd||code==4'hf);
      xe=xsg?{xu[15],xu}:{1'b0,xu}; ye=ysg?{yu[15],yu}:{1'b0,yu};
      prod=xe*ye; tmp=$signed({{30{prod[33]}},prod})<<<sh; tmp=$signed({{32{tmp[31]}},tmp[31:0]});
      acc=$signed({{24{mr[bs][39]}},mr[bs]});
      case(code) 4'h1,4'h4,4'h5,4'h6,4'h7:res=tmp; 4'h2,4'h8,4'h9,4'ha,4'hb:res=acc+tmp;
        4'h3,4'hc,4'hd,4'he,4'hf:res=acc-tmp; default:res=tmp; endcase
      if(code==4'h1||code==4'h2||code==4'h3)begin tlo=tmp[15:0]; res=res+64'sd32768; if(tlo==16'h8000)res=res&~(64'sh10000); end
      ov=res[39:31]; a[MVBIT]=0; if(ov!=9'h000&&ov!=9'h1ff)a[MVBIT]=1;
      mv={a,res[39:0]};
    end
`endif
  endtask

  // ---- SHIFT prep (combinational): reduce every shift/NORM/EXP code to ONE variable operation
  // executed serially in S_SHIFT (mode 0 = 1-bit/clock barrel; mode 1 = serial leading-zero count).
  // NO barrels / clz encoders here -> removes the ~1,000-ALUT combinational shift datapath.
  // acc0 = pre-shift/pre-count value; amt = shift magnitude (clamped 32); dir/arith set the barrel.
  // Bit-exact with the old shift_eval; finalize (shift_fin) reproduces every code's SR/SE/SB/ASTAT.
  task automatic shift_prep(input [23:0] op,input logic imm,input [7:0] ain,input [15:0] xop,input [7:0] se_in,
      output logic mode, output [31:0] acc0, output [5:0] amt, output logic dir, output logic arith);
    logic [3:0] code; logic signed [8:0] sc; logic [15:0] xu; logic [8:0] mag;
    logic [31:0] uxs,shin,pre; logic hi_v, ar_v, inv;
    code=op[14:11]; xu=xop; mode=1'b0; acc0=32'h0; amt=6'd0; dir=1'b0; arith=1'b0; mag=9'd0;
    sc = imm ? $signed({op[7],op[7:0]}) : $signed({se_in[7],se_in});
`ifdef ABL_SHIFT
    acc0=32'h0; amt=6'd0;
`else
    if(code[3]==1'b0) begin                     // 0x0-0x7 LSHIFT / ASHIFT
      hi_v=~code[1]; ar_v=code[2];
      shin = hi_v ? {xu,16'h0} : (ar_v ? {{16{xu[15]}},xu} : {16'h0,xu});
      pre=shin; dir=(sc<0); arith=ar_v; mag = dir ? 9'(-sc) : 9'(sc);
      amt=(mag>=9'd32)?6'd32:mag[5:0]; acc0=pre; mode=1'b0;
    end else if(code[3:1]==3'b100) begin        // 0x8/0x9 NORM HI
      uxs={xu,16'h0};
      if(sc>0)begin pre=(uxs>>1)|(ain[CBIT]?32'h8000_0000:32'h0); dir=1'b1; arith=1'b1; mag=9'(sc-9'sd1); end
      else     begin pre=uxs; dir=1'b0; arith=1'b0; mag=9'(-sc); end
      amt=(mag>=9'd32)?6'd32:mag[5:0]; acc0=pre; mode=1'b0;
    end else if(code[3:1]==3'b101) begin        // 0xa/0xb NORM LO (logical)
      uxs={16'h0,xu};
      if(sc>0)begin dir=1'b1; arith=1'b0; mag=9'(sc); end
      else     begin dir=1'b0; arith=1'b0; mag=9'(-sc); end
      amt=(mag>=9'd32)?6'd32:mag[5:0]; acc0=uxs; mode=1'b0;
    end else begin                              // 0xc-0xf EXP / EXPADJ (serial leading-zero count)
      mode=1'b1;
      if(code==4'he) inv=ain[SSBIT]; else inv=xu[15];
      acc0={16'h0,(inv?~xu:xu)}; amt=6'd0; dir=1'b0; arith=1'b0;
    end
`endif
  endtask

  // ============ FSM ============
  typedef enum logic [2:0] {S_RST,S_FETCH,S_DEC,S_MEM,S_SHIFT} st_t; st_t st;
  logic [23:0] opr;
  // AREA: multi-cycle shifter state. One shared 1-bit/clock barrel (sh_mode=0) OR a serial
  // leading-zero counter (sh_mode=1) replaces the combinational 32-bit barrels + clz encoders.
  logic        sh_mode;            // 0=variable shift, 1=leading-zero count (EXP/EXPADJ)
  logic [31:0] sh_acc;             // accumulator (subject of shift/count)
  logic [5:0]  sh_amt, sh_i;       // shift target count / iterations done
  logic [6:0]  sh_clz;             // leading-zero count (0..32)
  logic        sh_dir, sh_arith;   // 0=left 1=right ; arithmetic fill on right
  logic        sh_mem;             // after shift, issue the latched mem op (S_MEM)
  logic [3:0]  sh_code;            // shift sub-code op[14:11]
  logic [7:0]  sh_ain, sh_se;      // captured astat / SE for finalize
  logic [4:0]  sh_sb;              // captured SB for EXPADJ compare
  logic [15:0] sh_xu;              // captured operand (sign bit + EXPADJ path)
  logic        sh_sror;            // OR-into-SR (code[0])
  // S4 memory-op state. DM: one registered request pulse (dm_rd/dm_wr), then wait dm_ready.
  //   PM data: pm_issue drives the (combinational) PM port for one clock with pm_daddr/pm_dw/pm_dwdata,
  //   pd_q marks the next clock's pm_ready as the data reply. Dual 0xC0-0xFF: both pending at once.
  logic       dm_pend, dm_isrd; logic [1:0] dm_grp; logic [3:0] dm_reg;
  logic       pmd_pend, pm_issue, pm_dw, pd_q, dag2_pend; logic [3:0] pm_reg; logic [13:0] pm_daddr; logic [23:0] pm_dwdata;
  logic [23:0] opx;             // opcode of a dual read in flight (DAG2 fields for the S_MEM post-modify)
  logic       i7_pend;          // SPORT1 autobuffer write pending (applied at the boundary)
  logic [13:0] i7_pv;           // pending I[7] value (from dcs2_autobuf)
  logic       hold_q;           // registered boundary hold
  logic       vslow_q;          // verifier mutant VM_SLOW only (constant 0 otherwise)
  logic       sh_nop;           // S_SHIFT clock of a false conditional shift (no effect)
  logic       irq_just;         // an IRQ was taken at this boundary: no second take before a dispatch (old S_FETCH: one take per boundary)
  logic [1:0] tx_stall;         // clocks the boundary stays blocked after a SPORT1 TX write
  logic [13:0] fa_q; logic f_q; // address fetched last clock / it was a fetch (not a PM data access)
  // combinational control
  logic take, blocked, fetch_ok, go_irq, go_disp, pm_fetch, disp_multi, s_mem_done, sh_done;
  logic [13:0] fa;

  // register-write helpers (nonblocking to current bank / index files)
  // ---- hardware stacks, MAME 0.289 2100ops.hxx:119-296 (depths adsp2100.h:298-301: PC 16, CNTR/STATUS/LOOP 4) ----
  // wg1 r12 (War Gods r11 cabinet vortex hang): a push on a FULL stack stores nothing, keeps sp and sets the OVER bit
  // (a DO on a full loop stack does NOT arm the loop); a pop on an EMPTY stack keeps sp 0 and uses entry 0. The old
  // code incremented/decremented unconditionally with 3-bit pointers over 4-entry arrays: out-of-range stores/loads
  // whose synthesized behaviour (index aliasing) differs from Verilator's, so the firmware's loop-stack overflow in
  // its polling transfer corrupted the live loop/count entries on silicon only. sstat: PC_EMPTY 01 PC_OVER 02
  // COUNT_EMPTY 04 COUNT_OVER 08 STATUS_EMPTY 10 STATUS_OVER 20 LOOP_EMPTY 40 LOOP_OVER 80 (2100ops.hxx:104-111).
  wire [13:0] pc_top = (pcsp != 5'd0) ? pcst[4'(pcsp - 5'd1)] : pcst[0];            // pc_stack_top
  task automatic pc_push(input [13:0] v);
`ifdef MUT_STK_WRAP
    pcst[pcsp[3:0]]<=v; pcsp<=pcsp+5'd1; sstat[0]<=1'b0;                            // mutant: no saturation
`else
    if(pcsp < 5'd16) begin pcst[pcsp[3:0]]<=v; pcsp<=pcsp+5'd1; sstat[0]<=1'b0; end else sstat[1]<=1'b1;
`endif
  endtask
  task automatic pc_pop();                                                          // value = pc_top (read first)
    if(pcsp != 5'd0) begin pcsp<=pcsp-5'd1; if(pcsp == 5'd1) sstat[0]<=1'b1; end
  endtask
  task automatic cn_push();
    if(cnsp < 3'd4) begin cnst[cnsp[1:0]]<=cntr[13:0]; cnsp<=cnsp+3'd1; sstat[2]<=1'b0; end else sstat[3]<=1'b1;
  endtask
  task automatic cn_pop();
    if(cnsp != 3'd0) begin cnsp<=cnsp-3'd1; if(cnsp == 3'd1) sstat[2]<=1'b1; cntr<={2'b0, cnst[2'(cnsp - 3'd1)]}; end
    else cntr<={2'b0, cnst[0]};
  endtask
  task automatic lp_push(input [17:0] v);
`ifdef MUT_STK_WRAP
    lpst[lpsp[1:0]]<=v; lpsp<=lpsp+3'd1; loopreg<=v[17:4]; loop_cond<=v[3:0]; loop_active<=1'b1; sstat[6]<=1'b0;
`else
    if(lpsp < 3'd4) begin
      lpst[lpsp[1:0]]<=v; lpsp<=lpsp+3'd1; loopreg<=v[17:4]; loop_cond<=v[3:0]; loop_active<=1'b1; sstat[6]<=1'b0;
    end else sstat[7]<=1'b1;
`endif
  endtask
  task automatic lp_pop();
    if(lpsp != 3'd0) begin
      lpsp<=lpsp-3'd1;
      if(lpsp == 3'd1) begin loopreg<=14'h3fff; loop_active<=1'b0; loop_cond<=4'd0; sstat[6]<=1'b1; end
      else begin loopreg<=lpst[2'(lpsp - 3'd2)][17:4]; loop_cond<=lpst[2'(lpsp - 3'd2)][3:0]; end
    end
  endtask
  task automatic st_push();
    if(stsp < 3'd4) begin stst[stsp[1:0]]<={mstat,imask,astat}; stsp<=stsp+3'd1; sstat[4]<=1'b0; end else sstat[5]<=1'b1;
  endtask
  task automatic st_pop();                                                          // + update_mstat bank swap
    logic [20:0] e; e = (stsp != 3'd0) ? stst[2'(stsp - 3'd1)] : stst[0];
    if(stsp != 3'd0) begin stsp<=stsp-3'd1; if(stsp == 3'd1) sstat[4]<=1'b1; end
    mstat<=e[20:14]; mstat_prev<=e[20:14]; imask<=e[13:8]; astat<=e[7:0];
    if(e[14]!=mstat[0]) bs<=~bs;
  endtask

  task automatic wreg0(input [3:0] r,input [15:0] v);
    case(r) 0:ax0[bs]<=v;1:ax1[bs]<=v;2:mx0[bs]<=v;3:mx1[bs]<=v;4:ay0[bs]<=v;5:ay1[bs]<=v;6:my0[bs]<=v;7:my1[bs]<=v;
      8:si[bs]<=v;9:se[bs]<=v[7:0];10:ar[bs]<=v;
      11:mr[bs][15:0]<=v; 12:begin mr[bs][31:16]<=v; mr[bs][39:32]<={8{v[15]}}; end 13:mr[bs][39:32]<=v[7:0];
      14:sr[bs][15:0]<=v; 15:sr[bs][31:16]<=v; endcase
  endtask
  task automatic wreg1(input [3:0] r,input [15:0] v);
    case(r[3:2]) 0:begin I[r[1:0]]<=v[13:0]; end 1:Msg[r[1:0]]<=v[13:0]; 2:L[r[1:0]]<=v[13:0]; default:; endcase
  endtask
  task automatic wreg2(input [3:0] r,input [15:0] v); logic [2:0] x; x={1'b1,r[1:0]};
    case(r[3:2]) 0:I[x]<=v[13:0]; 1:Msg[x]<=v[13:0]; 2:L[x]<=v[13:0]; default:; endcase
  endtask
  task automatic wreg3(input [3:0] r,input [15:0] v);
    case(r)
      // wg1 fork: MSTAT write = m_mstat = val & mask; update_mstat() (2100ops.hxx:445, 79-85): bank swap on bit 0
`ifdef MUT_MSTAT_NOSWAP
      0:astat<=v[7:0]; 1:begin mstat<=v[6:0]; end 3:imask<=v[5:0]; 4:icntl<=v[4:0];     // mutant = the donor behaviour
`else
      0:astat<=v[7:0]; 1:begin mstat<=v[6:0]; mstat_prev<=v[6:0]; if(v[0]!=mstat[0]) bs<=~bs; end 3:imask<=v[5:0]; 4:icntl<=v[4:0];
`endif
      5:begin cn_push(); cntr<=v[13:0]; end
      6:sb[bs]<=v[4:0]; 7:px<=v[7:0]; 13:cntr<=v[13:0];
`ifdef MUT_TXSTALL0
      11:begin tx1_we<=1'b1; end                  // mutant: no boundary block after a SPORT1 TX write
`else
      11:begin tx1_we<=1'b1; tx_stall<=2'd2; end  // 0x0b = SPORT1 TX write -> arm the autobuffer (sound_tx_callback
`endif
                                                  // offset 1); S4: block the boundary until its I7 write lands
      15:pc_push(v[13:0]);
      default:; // 0x09 sport0 tx, 0x0c IFC handled in dispatch
    endcase
  endtask


  // generate_irq (2101, adsp2100.cpp:891-913)
  task automatic do_irq(input [2:0] indx);
    if(imask[5-indx])begin
      irq_ack<=1'b1; irq_ack_indx<=indx;        // ack: subsystem clears the taken latched source
      pc_push(pc);
      st_push();
      pc<=14'h4+({11'b0,indx}<<2);
      if(icntl[4]) imask<=imask&~(6'h3f>>indx); else imask<=6'h0;
    end
  endtask

  // advance pc with loop handling (adsp2100.cpp:1204-1221 + slow_condition CE 2100ops.hxx:316)
  task automatic pc_advance();
    logic cont; logic signed [15:0] nc;
    if(!loop_active || pc!=loopreg) pc<=(pc+1)&14'h3fff;
    else begin
      if(loop_cond==4'd14) begin           // CE: slow_condition
        nc = $signed(cntr) - 16'sd1;
        if(nc > 0) begin cntr<=nc; cont=1'b1; end
        else begin cn_pop(); cont=1'b0; end
      end else cont = cond_s(loop_cond,astat);
      if(cont) pc<=pc_top;
      else begin
        lp_pop();                              // loop_stack_pop(); pc_stack_pop_val(); m_pc++
        pc_pop();
        pc<=(pc+1)&14'h3fff;
      end
    end
  endtask

  integer k;
  always_ff @(posedge clk) begin
    if(rst)begin
      st<=S_RST; dm_rd<=0;dm_wr<=0;
      loopreg<=14'h3fff;loop_active<=0;loop_cond<=0;irq_state<=0; i7_pend<=0; irq_ack<=0; tx1_we<=0;
      dm_pend<=0; pmd_pend<=0; pm_issue<=0; pd_q<=0; dag2_pend<=0; sh_mem<=0; sh_nop<=0; hold_q<=1'b0; tx_stall<=2'd0;
      f_q<=1'b0; fa_q<=14'h0; irq_just<=1'b0; vslow_q<=1'b0;
      // MAME device_reset (adsp2100.cpp:612) does NOT clear the alt-bank data regs; only a COLD reset
      // (power-on) zeroes them here. A WARM reset (self-reboot, warm_rst=1) preserves them.
      if(!warm_rst) for(k=1;k<2;k=k+1)begin ax0[k]<=0;ax1[k]<=0;ay0[k]<=0;ay1[k]<=0;ar[k]<=0;af[k]<=0;mx0[k]<=0;mx1[k]<=0;my0[k]<=0;my1[k]<=0;mf[k]<=0;si[k]<=0;mr[k]<=0;sr[k]<=0;se[k]<=0;sb[k]<=0;end
      if(seed_en) begin  // load live architectural state into bank0 (fight-window seed)
`ifndef SYNTHESIS
        pc<=sf(seed,0)[13:0]; ppc<=sf(seed,0)[13:0];
        ax0[0]<=sf(seed,1);ax1[0]<=sf(seed,2);ay0[0]<=sf(seed,3);ay1[0]<=sf(seed,4);ar[0]<=sf(seed,5);af[0]<=sf(seed,6);
        mx0[0]<=sf(seed,7);mx1[0]<=sf(seed,8);my0[0]<=sf(seed,9);my1[0]<=sf(seed,10);
        mr[0]<={sf(seed,13)[7:0],sf(seed,12)[15:0],sf(seed,11)[15:0]}; mf[0]<=sf(seed,14);
        si[0]<=sf(seed,15); se[0]<=sf(seed,16)[7:0]; sb[0]<=sf(seed,17)[4:0];
        sr[0]<={sf(seed,19)[15:0],sf(seed,18)[15:0]};
        for(k=0;k<8;k=k+1)begin I[k]<=sf(seed,20+k)[13:0]; Msg[k]<=sf(seed,28+k)[13:0]; L[k]<=sf(seed,36+k)[13:0]; end
        px<=sf(seed,44)[7:0]; cntr<=sf(seed,45)[15:0]; astat<=sf(seed,46)[7:0];
        mstat<=sf(seed,47)[6:0]; mstat_prev<=sf(seed,47)[6:0]; sstat<=sf(seed,48)[7:0];
        imask<=sf(seed,49)[5:0]; icntl<=sf(seed,50)[4:0];
        pcsp<=sf(seed,51)[4:0]; cnsp<=sf(seed,52)[2:0]; stsp<=sf(seed,53)[2:0]; lpsp<=sf(seed,54)[2:0];
        bs<=1'b0;
`endif
      end else begin
        // ALWAYS reset (MAME device_reset): PC/loops/IMASK/stacks/bank; sstat=0x55; mstat=0.
        pc<=0;ppc<=0;sstat<=8'h55;mstat<=0;mstat_prev<=0;imask<=0;bs<=0;
        pcsp<=0;lpsp<=0;cnsp<=0;stsp<=0;
        // PRESERVED by MAME device_reset (data regs, DAG I/M/L, CNTR, PX, ICNTL, ASTAT -- it only sets
        // a lazy C/V/N/Z clear mask, not astat=0). A WARM reset keeps them; COLD (power-on) zeroes them.
        if(!warm_rst) begin
          cntr<=0;icntl<=0;px<=0;astat<=0;
          for(k=0;k<8;k=k+1)begin I[k]<=0;L[k]<=0;Msg[k]<=0;end
          // r12: power-on stack contents = 0 (MAME value-initialised); an empty-stack pop reads entry 0
          for(k=0;k<16;k=k+1) pcst[k]<=0;
          for(k=0;k<4;k=k+1) begin cnst[k]<=0; lpst[k]<=0; stst[k]<=0; end
          ax0[0]<=0;ax1[0]<=0;ay0[0]<=0;ay1[0]<=0;ar[0]<=0;af[0]<=0;mx0[0]<=0;mx1[0]<=0;my0[0]<=0;my1[0]<=0;mf[0]<=0;si[0]<=0;mr[0]<=0;sr[0]<=0;se[0]<=0;sb[0]<=0;
        end
      end
    end else begin
      // wg1 fork: the autobuffer side-write is latched whether or not ce is high (the board may hold the
      // engine at an instruction boundary while a dcs_irq tick lands; dcs.cpp:1995 applies it at once).
      if(i7_we) begin i7_pend<=1'b1; i7_pv<=i7_wd; end
      if(ce)begin
      dm_rd<=0;dm_wr<=0; irq_ack<=1'b0; tx1_we<=1'b0;
      hold_q <= hold;
`ifdef VM_SLOW
      vslow_q <= go_disp || go_irq;                  // verifier mutant: +1 clk after every boundary action
`else
      vslow_q <= 1'b0;
`endif
      if(tx_stall!=2'd0) tx_stall<=tx_stall-2'd1;
      // PM port bookkeeping: what the port carried this clock (its reply arrives next clock)
      f_q <= pm_fetch; fa_q <= pm_addr; pd_q <= pm_issue; pm_issue <= 1'b0;
      case(st)
        S_RST: st<=S_DEC;                            // first fetch (pc) issued this clock
        S_DEC: begin
          // boundary. priority: autobuffer I7 write, IRQ, dispatch (go_* are combinational, below)
          if(i7_pend && !i7_we && tx_stall==2'd0) begin I[7]<=i7_pv; i7_pend<=1'b0; end
          else if(go_irq) begin do_irq(irq_indx); irq_just<=1'b1; end  // pc<=vector: refetch next clock
          else if(go_disp) begin opr<=pm_rdata; ppc<=pc; irq_just<=1'b0; dispatch(pm_rdata); end
        end
        S_MEM: begin
          // DAG2 post-modify of a dual read (issued this clock with the pre-modify I value latched in pm_daddr)
          if(dag2_pend) begin
            I[{1'b1,opx[7:6]}]<=dag_next(I[{1'b1,opx[7:6]}],Msg[{1'b1,opx[5:4]}],L[{1'b1,opx[7:6]}]);
            dag2_pend<=1'b0;
          end
          if(dm_pend && dm_ready) begin
            if(dm_isrd) case(dm_grp) 0:wreg0(dm_reg, dm_rdata); 1:wreg1(dm_reg, dm_rdata);
                                     2:wreg2(dm_reg, dm_rdata); 3:wreg3(dm_reg, dm_rdata); endcase
            dm_pend<=1'b0;
          end
`ifdef VM_PMD_NOPDQ
          if(pmd_pend && pm_ready) begin                // verifier mutant: fetch reply taken as PM data
`else
          if(pmd_pend && pm_ready && pd_q) begin
`endif
            if(!pm_dw) begin wreg0(pm_reg, pm_rdata[23:8]); px<=pm_rdata[7:0]; end
            pmd_pend<=1'b0;
          end
          if(s_mem_done) st<=S_DEC;                  // retire (commit is combinational)
        end
        S_SHIFT: begin
          // serial engine: mode 0 = 1-bit/clock variable shift; mode 1 = leading-zero count.
          if(sh_done) begin
            if(!sh_nop) shift_fin();
            sh_nop<=1'b0;
            if(sh_mem) begin  // issue the deferred DM/PM op (addr/wdata already latched in dispatch)
              if(dm_pend) begin if(dm_isrd) dm_rd<=1'b1; else dm_wr<=1'b1; end
              if(pmd_pend) pm_issue<=1'b1;
              sh_mem<=1'b0; st<=S_MEM;
            end else st<=S_DEC;
          end else if(sh_mode==1'b0) begin
            sh_acc <= sh_dir ? {(sh_arith?sh_acc[31]:1'b0), sh_acc[31:1]} : {sh_acc[30:0],1'b0};
            sh_i <= sh_i + 6'd1;
          end else begin
            sh_acc <= {sh_acc[30:0],1'b0}; sh_clz <= sh_clz + 7'd1;
          end
        end
        default: st<=S_DEC;
      endcase
      end
    end
  end

  // ===== S4 combinational control (boundary actions, retire, the PM port) =====
  // Comb chains (build-to-close): fetch_ok = f_q/pm_ready/fa_q==pc (regs, 14-bit compare ~3 LUT);
  // take = irq module latches & imask (regs, ~3-4 LUT); go_* ~2 more (register enables of the dispatch).
  // PM M10K read address: fa = (S_DEC & fetch_ok) ? pc+1 : pc, then the pm_issue mux -> ~5 LUT levels +
  // a 14-bit increment, all from registers (no memory output, no IRQ/hold terms in the chain).
  // Retire: commit = go_disp & ~disp_multi (opcode-byte decode, ~2 LUT after the PM M10K output) | ...
  always_comb begin
    logic [7:0] h;
`ifdef MUT_NO_IRQJUST
    take       = irq_take && imask[5-irq_indx];                  // mutant: a second take at the same boundary
`else
    take       = irq_take && imask[5-irq_indx] && !irq_just;     // do_irq's mask gate (0x20>>indx)
`endif
    blocked    = (tx_stall!=2'd0) || i7_pend || i7_we || vslow_q;
`ifdef MUT_FETCH_NOCHK
    fetch_ok   = f_q && pm_ready;                                // mutant: use the predicted fetch unchecked
`else
    fetch_ok   = f_q && pm_ready && (fa_q==pc);
`endif
    go_irq     = ce && (st==S_DEC) && !blocked && !hold_q && take;
    go_disp    = ce && (st==S_DEC) && !blocked && !hold_q && !take && fetch_ok;
    sh_done    = (sh_mode==1'b0) ? (sh_i>=sh_amt) : (sh_acc[31] || sh_clz>=7'd32);
`ifdef VM_PMD_NOPDQ
    s_mem_done = (!dm_pend || dm_ready) && (!pmd_pend || pm_ready);
`else
    s_mem_done = (!dm_pend || dm_ready) && (!pmd_pend || (pm_ready && pd_q));
`endif
    // multi-clock opcodes (must mirror dispatch's S_MEM/S_SHIFT arms): 0x80-0xff, 0x50-0x7f, 0x0e/0x0f,
    // 0x10-0x13. Pure opcode decode (a false 0x0e takes a no-effect S_SHIFT clock).
    h   = pm_rdata[23:16];
    disp_multi = h[7] || (h[7:6]==2'b01 && h[5:4]!=2'b00) || (h[7:1]==7'b0000111) || (h[7:2]==6'b000100);
    commit = ce && ((go_disp && !disp_multi) || (st==S_MEM && s_mem_done) || (st==S_SHIFT && sh_done && !sh_mem));
    istart = go_disp;
    bnd    = (st==S_DEC || st==S_RST) && !go_irq && !go_disp;
    // PM port: a data access (pm_issue, one clock) or else the continuous fetch
    pm_fetch = !rst && !pm_issue;
    // sequential prediction whenever a valid opcode is at the boundary (no IRQ/hold/block terms on the
    // M10K address path; a non-dispatching valid clock only costs one refetch)
    fa       = ((st==S_DEC) && fetch_ok) ? ((pc + 14'd1) & 14'h3fff) : pc;
    pm_addr  = pm_issue ? pm_daddr : fa;
    pm_rd    = pm_fetch || (pm_issue && !pm_dw);
    pm_wr    = pm_issue && pm_dw;
    pm_wdata = pm_dwdata;
  end

  // AREA: one ALU + one MAC + one shifter per instruction (results = dispatch-local av/mv/shp,
  // computed once at dispatch entry, then SELECTED per arm) instead of inlining the datapath into
  // ~7 arms. compute4/compute_c/apply_shift take the precomputed values as inputs.
  // op[18:17]: mac_mr/alu_ar/mac_mf/alu_af
  task automatic compute4(input [23:0] op, input [23:0] av, input [47:0] mv, input logic noop);
    case(op[18:17])
      2'b00:begin if(!noop)begin mr[bs]<=mv[39:0];astat<=mv[47:40];end end
      2'b01:begin ar[bs]<=sat_ar(av[15:0],av[23:16]); astat<=av[23:16]; end
      2'b10:begin if(!noop)begin mf[bs]<=mv[31:16];astat<=mv[47:40];end end
      2'b11:begin af[bs]<=av[15:0]; astat<=av[23:16]; end
    endcase
  endtask
  task automatic compute_c(input [23:0] op, input [23:0] av, input [47:0] mv, input logic noop);
    if(op[17]) begin ar[bs]<=sat_ar(av[15:0],av[23:16]); astat<=av[23:16]; end
    else begin if(!noop)begin mr[bs]<=mv[39:0];astat<=mv[47:40];end end
  endtask

  // ===== dispatch: compute next-state from opcode (called in S_DEC after pm_ready) =====
  task automatic dispatch(input [23:0] op);
    logic [7:0] h; logic [15:0] tmp16;
    logic dag_en; logic [2:0] dag_widx, dag_midx;
    logic [23:0] av; logic [47:0] mv; logic noop;                    // one ALU + one MAC result
    logic sh_pmode, sh_pdir, sh_parith; logic [31:0] sh_pacc; logic [5:0] sh_pamt; // serial-shift request (prep)
    logic [15:0] alux_v, macx_v, shxf_v;                            // shared x-operand read (change #4)
    logic cnd; logic is_ccf; logic signed [15:0] nc14;              // condition for cond'l control-flow (incl NOT-CE)
    h=op[23:16];
    // default: advance pc, no mem, commit next cycle
    pc_advance();
    // shared x-operand read (change #4): the common half (x-sel 2..7 = AR,MR0-2,SR0-1) is identical
    // across ALU/MAC/SHIFT; compute it ONCE, only the low two sources differ by unit.
    begin logic [15:0] xc; logic [2:0] xs; xs=op[10:8];
      case(xs) 3'd3:xc=mr[bs][15:0];3'd4:xc=mr[bs][31:16];3'd5:xc={{8{mr[bs][39]}},mr[bs][39:32]};
               3'd6:xc=sr[bs][15:0];3'd7:xc=sr[bs][31:16];default:xc=ar[bs]; endcase  // 2->ar
      alux_v = (xs<3'd2) ? (xs[0]?ax1[bs]:ax0[bs]) : xc;
      macx_v = (xs<3'd2) ? (xs[0]?mx1[bs]:mx0[bs]) : xc;
      shxf_v = (xs<3'd2) ? si[bs] : xc;
    end
    av=alu_eval(op,1'b0,astat,alux_v); mac_eval(op,astat,macx_v,mv,noop);  // precompute once; arms select
    shift_prep(op,(h==8'h0f),astat,shxf_v,se[bs],sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith); // serial shift request
    dag_en=1'b0; dag_widx=3'd0; dag_midx=3'd0;
    st<=S_DEC;  // S4: completes this clock (commit comb); overridden to S_MEM/S_SHIFT below when needed
    // condition for conditional CONTROL-FLOW / conditional compute ops. cond 14 = NOT CE is the
    // ADSP-21xx "slow_condition" (2100ops.hxx:304/316): --CNTR, TRUE while >0, else pop the count
    // stack and FALSE -- a stateful counter test, NOT an astat test. cond_s() covers 0-13 and 15.
    casez(h)
      8'b000110??,8'b000111??,8'b0010000?,8'b0010001?,8'b0010010?,8'b0010011?,8'h0a,8'h0b,8'h0e: is_ccf=1'b1;
      default: is_ccf=1'b0;
    endcase
    if(is_ccf && op[3:0]==4'd14) begin
      nc14 = $signed(cntr) - 16'sd1;
      if(nc14 > 0) begin cntr<=nc14; cnd=1'b1; end
      else begin cn_pop(); cnd=1'b0; end
    end else cnd = cond_s(op[3:0], astat);

`ifdef ABL_DECODE
    casez(8'h22)  // force ALU-to-AR class; measures decode+unused arms
`else
    casez(h)
`endif
      8'h00: ; // NOP
      8'h06: begin // DIVS
        logic [15:0] xo,yo,t; xo=alux(op[10:8]); yo=aluy(op[12:11]); t=xo^yo;
        astat<=(astat&~8'h20)|((t>>10)&8'h20); af[bs]<=(yo<<1)|(ay0[bs]>>15); ay0[bs]<=(ay0[bs]<<1)|(t>>15);
      end
      8'h07: begin // DIVQ
        logic [15:0] xo; logic [16:0] res; logic [15:0] t; xo=alux(op[10:8]);
        res = astat[QBIT]? ({1'b0,af[bs]}+{1'b0,xo}) : ({1'b0,af[bs]}-{1'b0,xo});
        t=res[15:0]^xo; astat<=(astat&~8'h20)|((t>>10)&8'h20);
        af[bs]<=(res[15:0]<<1)|(ay0[bs]>>15); ay0[bs]<=(ay0[bs]<<1)|(((~t)>>15)&16'h1);
      end
      8'h09: begin logic [2:0] t; t=op[4:2]; dag_en=1'b1; dag_widx=m3(t); dag_midx=m3({t[2],op[1:0]}); end // modify addr
      8'h0c: begin // mode control (2101: bits per adsp2100.cpp:1363-1373)
        logic [6:0] ms; ms=mstat;
        if(op[3])ms[6]=op[2]; if(op[13])ms[4]=op[12];                        // GO, INTEGER
`ifndef MUT_TIMER_MODE_IGNORED
        if(op[15])ms[5]=op[14];                                              // TIMER (wg1 fork: adsp2100.cpp:1367)
`endif
        if(op[5])ms[0]=op[4]; if(op[7])ms[1]=op[6]; if(op[9])ms[2]=op[8]; if(op[11])ms[3]=op[10];
        // bank swap on MST_BANK change
        if(ms[0]!=mstat[0]) bs<=~bs;
        mstat<=ms; mstat_prev<=ms;
      end
      8'h0d: begin // internal reg move
        logic [3:0] dr,srr; dr=op[7:4]; srr=op[3:0];
        case(op[11:8])
          0:wreg0(dr,rd0(srr));1:wreg0(dr,rd1f(srr));2:wreg0(dr,rd2f(srr));3:wreg0(dr,rd3f(srr));
          4:wreg1(dr,rd0(srr));5:wreg1(dr,rd1f(srr));6:wreg1(dr,rd2f(srr));7:wreg1(dr,rd3f(srr));
          8:wreg2(dr,rd0(srr));9:wreg2(dr,rd1f(srr));10:wreg2(dr,rd2f(srr));11:wreg2(dr,rd3f(srr));
          12:wreg3(dr,rd0(srr));13:wreg3(dr,rd1f(srr));14:wreg3(dr,rd2f(srr));15:wreg3(dr,rd3f(srr));
        endcase
      end
      8'h0f: shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v,astat,se[bs],sb[bs],1'b0); // shift imm
      8'b000110??: if(cnd) pc<=op[17:4]; // cond jump imm
      8'b000111??: if(cnd) begin pc_push((pc+1)&14'h3fff); pc<=op[17:4]; end // cond call
      8'b000101??: begin // DO UNTIL (gospel pushes m_pc AFTER m_pc++ => loop start = pc+1)
        lp_push(op[17:0]);
        pc_push((pc+1)&14'h3fff);
      end
      8'b0010000?: if(cnd)begin if(!noop)begin mr[bs]<=mv[39:0];astat<=mv[47:40];end end
      8'b0010001?: if(cnd)begin ar[bs]<=sat_ar(av[15:0],av[23:16]); astat<=av[23:16]; end
      8'b0010010?: if(cnd)begin if(!noop)begin mf[bs]<=mv[31:16];astat<=mv[47:40];end end
      8'b0010011?: if(cnd)begin af[bs]<=av[15:0]; astat<=av[23:16]; end
      8'b001100??: wreg0(op[3:0], {{2{op[17]}},op[17:4]});
      8'b001101??: wreg1(op[3:0], {{2{op[17]}},op[17:4]});
      8'b001110??: wreg2(op[3:0], {{2{op[17]}},op[17:4]});
      8'b001111??: wreg3(op[3:0], {{2{op[17]}},op[17:4]});
      8'b0100????: wreg0(op[3:0], op[19:4]);
      8'b100000??: begin dm_addr<=op[17:4]; dm_rd<=1; dm_isrd<=1; dm_grp<=0; dm_reg<=op[3:0]; dm_pend<=1; st<=S_MEM; end
      8'b100001??: begin dm_addr<=op[17:4]; dm_rd<=1; dm_isrd<=1; dm_grp<=1; dm_reg<=op[3:0]; dm_pend<=1; st<=S_MEM; end
      8'b100010??: begin dm_addr<=op[17:4]; dm_rd<=1; dm_isrd<=1; dm_grp<=2; dm_reg<=op[3:0]; dm_pend<=1; st<=S_MEM; end
      8'b100011??: begin dm_addr<=op[17:4]; dm_rd<=1; dm_isrd<=1; dm_grp<=3; dm_reg<=op[3:0]; dm_pend<=1; st<=S_MEM; end
      8'b100100??: begin dm_addr<=op[17:4]; dm_wdata<=rd0(op[3:0]); dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM; end
      8'b100101??: begin dm_addr<=op[17:4]; dm_wdata<=rd1f(op[3:0]); dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM; end
      8'b100110??: begin dm_addr<=op[17:4]; dm_wdata<=rd2f(op[3:0]); dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM; end
      8'b100111??: begin dm_addr<=op[17:4]; dm_wdata<=rd3f(op[3:0]); dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM; end
      // 0xAx DM(I0-3,M0-3)=data16 = data_write_dag1 (2100ops.hxx:575-597, bit reverse under MSTAT REVERSE);
      // 0xBx DM(I4-7,M4-7)=data16 = data_write_dag2 (2100ops.hxx:624-639, ireg 4+op[3:2], mreg 4+op[1:0], no
      // reverse). Gate unit/dag; its mutants: MUT_DAG2W_TO_DAG1 (the Zeus zk4-inv6 defect: store + post-modify
      // on DAG1), MUT_DAG2W_NOPOSTMOD, MUT_DAG2W_REVERSE, MUT_DAG1W_NOREV.
      8'b1010????: begin logic [1:0] ir,mrg; ir=op[3:2];mrg=op[1:0];
`ifdef MUT_DAG1W_NOREV
        dm_addr<=I[ir]; dm_wdata<=op[19:4]; dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM;
`else
        dm_addr<=(mstat[MST_REV])?rev14(I[ir]):I[ir]; dm_wdata<=op[19:4]; dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM;
`endif
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3(mrg); end
`ifdef MUT_DAG2W_TO_DAG1
      8'b1011????: begin logic [2:0] ir,mrg; ir={1'b0,op[3:2]};mrg={1'b0,op[1:0]};
`else
      8'b1011????: begin logic [2:0] ir,mrg; ir={1'b1,op[3:2]};mrg={1'b1,op[1:0]};
`endif
`ifdef MUT_DAG2W_REVERSE
        dm_addr<=(mstat[MST_REV])?rev14(I[ir]):I[ir]; dm_wdata<=op[19:4]; dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM;
`else
        dm_addr<=I[ir]; dm_wdata<=op[19:4]; dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM;
`endif
`ifndef MUT_DAG2W_NOPOSTMOD
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3(mrg);
`endif
      end
      8'h0a: if(cnd) begin // conditional return / RTI (1341-1351)
        pc<=pc_top; pc_pop();
        if(op[4]) st_pop();
      end
`ifndef MUT_STK_NOPOP
      8'h04: begin // stack control (adsp2100.cpp:1278-1287): POP PC (value dropped), POP LOOP, POP CNTR, PUSH/POP STS
        if(op[4]) pc_pop();                    // firmware 0x3408-0x340A: leaves the polling-transfer DO loop
        if(op[3]) lp_pop();
        if(op[2]) cn_pop();
        if(op[1]) begin if(op[0]) st_pop(); else st_push(); end
      end
`endif
      8'b01010???: begin // compute then PM read to reg0[op[7:4]] (DAG2, ireg=4+op[3:2])
        logic [2:0] ir; ir={1'b1,op[3:2]}; compute4(op,av,mv,noop);
        pm_daddr<=I[ir]; pm_dw<=1'b0; pm_issue<=1'b1; pm_reg<=op[7:4]; pmd_pend<=1; st<=S_MEM;
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3({1'b1,op[1:0]});
      end
      8'b01011???: begin // PM write (val<<8|px) from reg0[op[7:4]] then compute (DAG2)
        logic [2:0] ir; ir={1'b1,op[3:2]};
        pm_daddr<=I[ir]; pm_dwdata<={rd0(op[7:4]),px}; pm_dw<=1'b1; pm_issue<=1'b1; pmd_pend<=1; st<=S_MEM;
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3({1'b1,op[1:0]}); compute4(op,av,mv,noop);
      end
      8'h0b: if(cnd) begin if(op[4]) pc_push((pc+1)&14'h3fff); pc<=I[{1'b1,op[7:6]}]; end
      8'h0e: if(cnd) shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v,astat,se[bs],sb[bs],1'b0); // cond shift
             else begin sh_nop<=1'b1; sh_mode<=1'b0; sh_amt<=6'd0; sh_i<=6'd0; sh_mem<=1'b0; st<=S_SHIFT; end
             // S4: a false conditional shift still takes the S_SHIFT clock (no effect) so disp_multi stays a
             // pure opcode decode (no condition evaluation on the retire/commit path)
      8'b00101???: begin logic [15:0] t; t=rd0(op[3:0]); compute4(op,av,mv,noop); wreg0(op[7:4],t); end
      8'b01100???: begin logic [1:0] ir; ir=op[3:2]; compute4(op,av,mv,noop); // compute then DM read DAG1
        dm_addr<= mstat[MST_REV]? rev14(I[ir]):I[ir]; dm_rd<=1; dm_isrd<=1; dm_grp<=0; dm_reg<=op[7:4]; dm_pend<=1; st<=S_MEM;
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3(op[1:0]); end
      8'b01101???: begin logic [1:0] ir; ir=op[3:2]; // DM write DAG1 then compute
        dm_addr<= mstat[MST_REV]? rev14(I[ir]):I[ir]; dm_wdata<=rd0(op[7:4]); dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM;
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3(op[1:0]); compute4(op,av,mv,noop); end
      8'b01110???: begin logic [2:0] ir; ir={1'b1,op[3:2]}; compute4(op,av,mv,noop); // compute then DM read DAG2
        dm_addr<=I[ir]; dm_rd<=1; dm_isrd<=1; dm_grp<=0; dm_reg<=op[7:4]; dm_pend<=1; st<=S_MEM;
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3({1'b1,op[1:0]}); end
      8'b01111???: begin logic [2:0] ir; ir={1'b1,op[3:2]}; // DM write DAG2 then compute
        dm_addr<=I[ir]; dm_wdata<=rd0(op[7:4]); dm_wr<=1; dm_isrd<=0; dm_pend<=1; st<=S_MEM;
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3({1'b1,op[1:0]}); compute4(op,av,mv,noop); end
      8'b11??????: begin logic [1:0] ir; ir=op[3:2]; compute_c(op,av,mv,noop); // compute; DM read DAG1 -> dest; then PM read DAG2(op>>4) -> dest2
        dm_addr<= mstat[MST_REV]? rev14(I[ir]):I[ir]; dm_rd<=1; dm_isrd<=1; dm_grp<=0; dm_reg<={2'b0,op[19:18]}; dm_pend<=1; st<=S_MEM;
        dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3(op[1:0]);
        // S4: the PM read (pgm DAG2 with op>>4, ireg=4+op[7:6]) runs CONCURRENTLY with the DM read; its
        // DAG2 post-modify happens in the first S_MEM clock (dag2_pend), as the old sequential second read did.
        pm_daddr<=I[{1'b1,op[7:6]}]; pm_dw<=1'b0; pm_issue<=1'b1; pmd_pend<=1; dag2_pend<=1'b1; opx<=op;
        pm_reg<=op[23:20]-4'd8;  // pgm dest reg0 idx = hi[7:4]-8 (ay0/ay1/my0/my1)
      end
      8'h10: begin logic [15:0] t; t=rd0(op[3:0]); wreg0(op[7:4],t); // shift + internal reg move (no mem)
        shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v,astat,se[bs],sb[bs],1'b0); end
      // shift + mem (0x11-0x13): latch the mem request (strobe deferred), run shift, then S_MEM.
      8'h11: begin logic [2:0] ir; ir={1'b1,op[3:2]};   // shift + PM rw DAG2
        if(op[15]) begin pm_daddr<=I[ir]; pm_dwdata<={rd0(op[7:4]),px}; pm_dw<=1'b1; pmd_pend<=1;
                         dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3({1'b1,op[1:0]}); end
        else begin pm_daddr<=I[ir]; pm_dw<=1'b0; pm_reg<=op[7:4]; pmd_pend<=1;
                   dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3({1'b1,op[1:0]}); end
        shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v,astat,se[bs],sb[bs],1'b1);
      end
      8'h12: begin logic [1:0] ir; ir=op[3:2];           // shift + DM rw DAG1
        if(op[15]) begin dm_addr<= mstat[MST_REV]?rev14(I[ir]):I[ir]; dm_wdata<=rd0(op[7:4]); dm_isrd<=0; dm_pend<=1;
                         dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3(op[1:0]); end
        else begin dm_addr<= mstat[MST_REV]?rev14(I[ir]):I[ir]; dm_isrd<=1; dm_grp<=0; dm_reg<=op[7:4]; dm_pend<=1;
                   dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3(op[1:0]); end
        shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v,astat,se[bs],sb[bs],1'b1);
      end
      8'h13: begin logic [2:0] ir; ir={1'b1,op[3:2]};    // shift + DM rw DAG2
        if(op[15]) begin dm_addr<=I[ir]; dm_wdata<=rd0(op[7:4]); dm_isrd<=0; dm_pend<=1;
                         dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3({1'b1,op[1:0]}); end
        else begin dm_addr<=I[ir]; dm_isrd<=1; dm_grp<=0; dm_reg<=op[7:4]; dm_pend<=1;
                   dag_en=1'b1; dag_widx=m3(ir); dag_midx=m3({1'b1,op[1:0]}); end
        shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v,astat,se[bs],sb[bs],1'b1);
      end
      default: ; // remaining: 0x02/0x03/0x05/0x08 (add if bench hits)
    endcase
    // ONE shared address generator (DAG hoist): applies the selected index post-modify
    if(dag_en) I[dag_widx]<=dag_next(I[dag_widx],Msg[dag_midx],L[dag_widx]);
  endtask

  // latch a serial-shift request and enter S_SHIFT (mem_after = a DM/PM op follows, deferred)
  task automatic shift_req(input [23:0] op,input logic mode,input [31:0] acc0,input [5:0] amt,
      input logic dir,input logic arith,input [15:0] xu,input [7:0] ain,input [7:0] se_in,
      input [4:0] sb_in,input logic mem_after);
    sh_mode<=mode; sh_acc<=acc0; sh_amt<=amt; sh_dir<=dir; sh_arith<=arith; sh_i<=6'd0; sh_clz<=7'd0;
    sh_code<=op[14:11]; sh_xu<=xu; sh_ain<=ain; sh_se<=se_in; sh_sb<=sb_in; sh_sror<=op[11]; sh_mem<=mem_after;
    st<=S_SHIFT;
  endtask

  // finalize (runs at S_SHIFT completion): reproduce every shift code's SR/SE/SB/ASTAT writes
  // from the serially-computed result (sh_acc = shifted value; sh_clz = leading-zero count).
  task automatic shift_fin();
    logic [3:0] code; logic [7:0] a; logic [31:0] res; logic [15:0] xu; logic [7:0] c8;
    code=sh_code; a=sh_ain; xu=sh_xu; res=sh_acc; c8 = 8'(sh_clz) - 8'd17;   // clz-16-1
    case(code)
      4'h0,4'h1,4'h2,4'h3,4'h4,4'h5,4'h6,4'h7,4'h8,4'h9,4'ha,4'hb:
        begin sr[bs]<= sh_sror ? (sr[bs]|res) : res; astat<=a; end
      4'hc: begin a[SSBIT]=xu[15]; se[bs]<= -c8; astat<=a; end
      4'hd: begin
        if(a[VBIT]) begin se[bs]<=8'd1; a[SSBIT]=~xu[15]; end
        else begin a[SSBIT]=xu[15]; se[bs]<= -c8; end
        astat<=a; end
      4'he: begin if($signed(sh_se)==-8'sd15) se[bs]<= -(8'(sh_clz)-8'd1); astat<=a; end
      4'hf: begin if($signed({1'b0,c8}) < -$signed({{3{sh_sb[4]}},sh_sb})) sb[bs]<= -c8; astat<=a; end
      default: astat<=a;
    endcase
  endtask

  // ---- debug bus: 59 fields (cpu_field order) as 32b words ----
  wire [31:0] dw [59];
  assign dw[0]={18'b0,pc};
  assign dw[1]={16'b0,ax0[bs]}; assign dw[2]={16'b0,ax1[bs]}; assign dw[3]={16'b0,ay0[bs]}; assign dw[4]={16'b0,ay1[bs]};
  assign dw[5]={16'b0,ar[bs]};  assign dw[6]={16'b0,af[bs]};
  assign dw[7]={16'b0,mx0[bs]}; assign dw[8]={16'b0,mx1[bs]}; assign dw[9]={16'b0,my0[bs]}; assign dw[10]={16'b0,my1[bs]};
  assign dw[11]={16'b0,mr[bs][15:0]}; assign dw[12]={16'b0,mr[bs][31:16]}; assign dw[13]={24'b0,mr[bs][39:32]}; assign dw[14]={16'b0,mf[bs]};
  assign dw[15]={16'b0,si[bs]}; assign dw[16]={24'b0,se[bs]}; assign dw[17]={27'b0,sb[bs]};
  assign dw[18]={16'b0,sr[bs][15:0]}; assign dw[19]={16'b0,sr[bs][31:16]};
  genvar gi;
  generate
    for(gi=0;gi<8;gi=gi+1) begin: gI  assign dw[20+gi]={18'b0,I[gi]}; end
    for(gi=0;gi<8;gi=gi+1) begin: gM  assign dw[28+gi]={18'b0,Msg[gi]}; end
    for(gi=0;gi<8;gi=gi+1) begin: gL  assign dw[36+gi]={18'b0,L[gi]}; end
  endgenerate
  assign dw[44]={24'b0,px}; assign dw[45]={16'b0,cntr}; assign dw[46]={24'b0,astat};
  assign dw[47]={25'b0,mstat}; assign dw[48]={24'b0,sstat}; assign dw[49]={26'b0,imask}; assign dw[50]={27'b0,icntl};
  assign dw[51]={27'b0,pcsp}; assign dw[52]={29'b0,cnsp}; assign dw[53]={29'b0,stsp}; assign dw[54]={29'b0,lpsp};
  assign dw[55]={31'b0,irq_state[0]}; assign dw[56]={31'b0,irq_state[1]}; assign dw[57]={31'b0,irq_state[2]}; assign dw[58]={31'b0,irq_state[3]};
  genvar gj; generate for(gj=0;gj<59;gj=gj+1) begin: gPK assign dbg[gj*32 +: 32]=dw[gj]; end endgenerate

endmodule
`default_nettype wire
