// SPDX-License-Identifier: GPL-2.0-or-later
// wg1_ide -- the IDE hard disk War Gods sees at 0x9a0000-0x9a0007 (wg1 block M3), backed by the MiSTer hps_io block
// device (CONTRACTS.md C3).
//
// Gospel: MAME 0.289 (git f34f02505e3)
//   mame/williams/midvunit.cpp:732   map(0x9a0000,0x9a0007) ata cs0_r/cs0_w umask32(0x0000ffff): register = addr-0x9a0000,
//                                    16-bit data in bits 15:0; bits 31:16 read as the space unmap value 0
//                                    (emumem_heu.cpp:72-82; every one of the 16.6M logged reads has 31:16 = 0).
//   mame/williams/midvunit.cpp:1242  ATA_INTERFACE, IDE hard disk on slot 0 only; no irq/dmarq callbacks are wired, so
//                                    INTRQ/DMARQ/DASP are unobservable and omitted.
//   devices/machine/atahle.cpp       command_r :530, command_w :728, read_data :383, write_data :398, start/stop_busy
//                                    :419/:425, read_buffer_empty :431, write_buffer_full :447, device_reset :127,
//                                    soft_reset :147, finished_busy :171, set_features :273, clear_dma_modes :253
//   devices/machine/atastorage.cpp   lba_address :44, ide_build_identify_device :93, soft_reset :218, signature :235,
//                                    finished_command :244, next_sector :311, seek_time :380, fill_buffer :404,
//                                    finished_read :446, read_first_sector :505, process_buffer :533,
//                                    finished_write :597, process_command :660, calculate_status (IDX) :935,
//                                    timing :19-24
//   Disk: wargods_11-07-1996.chd GDDD metadata CYLS:988 HEADS:16 SECS:52 BPS:512, no IDNT tag -> IDENTIFY is
//   ide_build_identify_device() (atastorage.cpp:919-927).
//
// Commands modelled: 0x20/0x21 READ SECTORS, 0x30/0x31 WRITE SECTORS, 0xEC IDENTIFY DEVICE, 0xEF SET FEATURES (the
// four War Gods issues: 0x20 x2299, 0x30 x6, 0xEC x3, 0xEF x2 in the 147.5 s MAME log). Every other command takes
// atahle.cpp:211-217 (ERR + ABRT); for the commands MAME's mass-storage device implements beyond these (0x10 0x40 0x41
// 0x70 0x90 0x91 0xC4 0xC5 0xC6 0xC8 0xCA 0xE3 0xE4 0xE7 0xE8 0xF2 0xF6 0xF8 0xF9) that is a deliberate,
// MAME-unreachable divergence (War Gods never issues them).
//
// Time. All MAME timers are counted in guest H1 ticks (guest_ce, one C31 cycle = 40 ns of guest time, the time base of
// every C31 access in MAME: all 16.6M logged access times are multiples of 40 ns). A MAME timer of length d started at
// an access is expired for a later access at guest time t iff t >= start + d (golden replay: 0 mismatches at slack 0,
// mismatches at +-40 ns), i.e. elapsed ticks >= ceil(d / 40 ns):
//   MINIMUM_COMMAND_TIME 10 us = 250, TIME_BETWEEN_SECTORS 400 ns = 10, TIME_PER_SECTOR_WRITE 100 us = 2500,
//   DETECT_DEVICE1/DIAGNOSTIC 2 ms = 50000, seek = 32500 + ceil(81250*diff/247) (13 ms*diff/988 + 1.3 ms),
//   IDX: elapsed > 1/90 s  <=>  ticks >= 277778.
// An access presented in the same clock as a guest_ce pulse is ordered BEFORE that tick.
//
// Disk latency (hps_io) is hidden from the guest: when an access would observe a MAME timer that has expired but whose
// completion needs sector data (or a finished sector write) the HPS has not delivered yet, the access is held
// (ready low, guest_wait high: guest time pauses) until it arrives, so the C31 sees exactly MAME's values whatever the
// HPS latency. Reads are double-buffered: the next sector of a multi-sector READ is fetched while the C31 drains the
// current one. The hold lasts as long as the HPS needs: a real drive answers in milliseconds and War Gods' driver
// timeouts assume that, while a MiSTer sector service can stall for hundreds of ms (SD card / file system / a busy ARM),
// so ANY release before the data arrives would put HPS latency into guest-visible status (extra BSY polls; with a long
// enough stall the driver's own timeout, see below). Only as a hang safety net, after STALL_MAX clocks (default 10 s,
// far beyond any SD latency) of holding ONE access, the block stops holding, latches hold_fault and the C31 sees BSY
// (0xD0/0xD2) until the sector arrives -- a stuck sd_ack shows up as a status stuck at BSY with sd_rd/sd_wr high and
// sd_lba = the sector wanted (tb test T_NOACK, built with a short STALL_MAX).
// War Gods' driver (loaded code 0xD505/0xD51A, loader copy 0x18A62/0x18A76): BK = FIX(16*polls * 300.0 * 1.0737e-9),
// timeout at BK >= 5 (wait-ready) / >= 30 (wait-DRQ) = 1.04M / 6.25M status polls = ~3.8 s / ~23 s of guest time
// at MAME's 3.68 us poll period (H:/temp/wargods/diskfail). 2026-09-25: STALL_MAX was 2.5M clocks (50 ms): every
// longer HPS service turned into guest-visible BSY polling (measured: tb_ide_hps_main +drv, spikes 10-500 ms).
//
// Notes (all MAME-unreachable for War Gods, flagged in README). 8-bit data transfers (SET FEATURES 0x01) ARE
// modelled but only matrix-tested (War Gods never enables them). Reset re-initialises everything (MAME keeps task-file registers, feature, identify words and the IDX
// timer across a machine reset -- the core's reset is power-on in practice); no image -> DRDY never set, IDENTIFY
// aborts (m_can_identify_device = 0), READ/WRITE fail with ERR+BAD_SECTOR (read_sector/write_sector false);
// a read-only image fails WRITE SECTORS the same way.
`default_nettype none
module wg1_ide #(
    parameter integer STALL_MAX = 500_000_000   // hang safety net: clocks ONE access may be held for the HPS (10 s at
                                                // 50 MHz); < 2^30
) (
    input  wire        clk,
    input  wire        reset,
    input  wire        guest_ce,                // guest H1 tick (40 ns guest time); NOT in CONTRACTS C1 -- see README
    // C1 bus slave
    input  wire        bus_valid, bus_write, bus_sync,
    input  wire [23:0] bus_addr,
    input  wire [31:0] bus_wdata,
    output wire        hit,
    output wire        ready,
    output reg  [31:0] rdata,
    output wire        guest_wait,
    // C3 hps_io block device (VDNUM slot 0, WIDE=1, BLKSZ=2)
    output reg  [31:0] sd_lba,
    output reg         sd_rd,
    output reg         sd_wr,
    input  wire        sd_ack,
    input  wire [7:0]  sd_buff_addr,
    input  wire [15:0] sd_buff_dout,
    output wire [15:0] sd_buff_din,
    input  wire        sd_buff_wr,
    input  wire        img_mounted,
    input  wire        img_readonly,
    input  wire [63:0] img_size
`ifdef WG1_DIAG_MIRROR
    // observe-only (cabinet diag build): {hold_fault (sticky: the STALL_MAX safety net fired), late (an access was
    // released and the C31 now polls BSY for a sector the HPS still owes), err (status ERR bit)}
    , output wire [2:0] dbg_ide
`endif
);
    // ------------------------------------------------------------------ constants
    localparam [31:0] TOTAL_SECTORS = 32'd822016;           // 988*16*52
    localparam [27:0] T_MINCMD  = 28'd250;
    localparam [27:0] T_BETWEEN = 28'd10;
    localparam [27:0] T_WRITE   = 28'd2500;
    localparam [27:0] T_RESET   = 28'd50000;
    localparam [18:0] T_ROT     = 19'd277778;
    localparam [1:0]  P_DETECT = 2'd1, P_DIAG = 2'd2, P_COMMAND = 2'd3;
    localparam [1:0]  SL_EMPTY = 2'd0, SL_FLY = 2'd1, SL_READY = 2'd2;
    localparam [1:0]  E_IDLE = 2'd0, E_REQ = 2'd1, E_XFER = 2'd2;
    localparam [29:0] STALL_M1 = STALL_MAX - 1;

    // ------------------------------------------------------------------ helpers (pure: arguments only)
    function automatic [31:0] lba_of(input [7:0] dh, input [7:0] ch, input [7:0] cl, input [7:0] sn);
        reg [25:0] t;
        begin
            if (dh[6]) lba_of = {4'd0, dh[3:0], ch, cl, sn};                                 // atastorage.cpp:47-48
            else begin
                t = {2'b0, ch, cl, dh[3:0]} * 26'd52;                                         // ((C*16)+H)*52
                lba_of = {6'd0, t} + {24'd0, sn} - 32'd1;                                     // + S - 1 (:52)
            end
        end
    endfunction

    // next_sector (atastorage.cpp:311-354): returns {devh, cyl_hi, cyl_lo, secnum}
    function automatic [31:0] next_sec(input [7:0] dh, input [7:0] ch, input [7:0] cl, input [7:0] sn);
        reg [7:0] h, c_h, c_l, s;
        begin
            h = {4'd0, dh[3:0]}; c_h = ch; c_l = cl; s = sn + 8'd1;
            if (dh[6]) begin
                if (s == 8'd0) begin
                    c_l = cl + 8'd1;
                    if (c_l == 8'd0) begin
                        c_h = ch + 8'd1;
                        if (c_h == 8'd0) h = h + 8'd1;
                    end
                end
            end else if (s > 8'd52) begin
                s = 8'd1;
                h = h + 8'd1;
                if (h >= 8'd16) begin
                    h = 8'd0;
                    c_l = cl + 8'd1;
                    if (c_l == 8'd0) c_h = ch + 8'd1;
                end
            end
            next_sec = {({dh[7:4], 4'd0} | h), c_h, c_l, s};                                  // :351 (h may be 16)
        end
    endfunction

    // IDENTIFY DEVICE word (atastorage.cpp:93-196; 822016 sectors < both CHS/LBA limits)
    function automatic [15:0] ident_word(input [7:0] w, input [15:0] i62, input [15:0] i63, input [15:0] i88);
        begin
            case (w)
                8'd0:  ident_word = 16'h045a;
                8'd1:  ident_word = 16'd988;
                8'd3:  ident_word = 16'd16;
                8'd6:  ident_word = 16'd52;
                8'd10, 8'd11, 8'd12, 8'd13, 8'd14, 8'd15, 8'd16, 8'd17, 8'd18, 8'd19:
                       ident_word = 16'h3030;                                                 // "00000000000000000000"
                8'd22: ident_word = 16'd4;
                8'd23: ident_word = 16'h312e;                                                 // "1."
                8'd24: ident_word = 16'h3020;                                                 // "0 "
                8'd25, 8'd26: ident_word = 16'h2020;
                8'd27: ident_word = 16'h4d41;                                                 // "MAME Compressed Hard Disk"
                8'd28: ident_word = 16'h4d45;
                8'd29: ident_word = 16'h2043;
                8'd30: ident_word = 16'h6f6d;
                8'd31: ident_word = 16'h7072;
                8'd32: ident_word = 16'h6573;
                8'd33: ident_word = 16'h7365;
                8'd34: ident_word = 16'h6420;
                8'd35: ident_word = 16'h4861;
                8'd36: ident_word = 16'h7264;
                8'd37: ident_word = 16'h2044;
                8'd38: ident_word = 16'h6973;
                8'd39: ident_word = 16'h6b20;
                8'd40, 8'd41, 8'd42, 8'd43, 8'd44, 8'd45, 8'd46: ident_word = 16'h2020;
                8'd47: ident_word = 16'h8010;
                8'd49: ident_word = 16'h0f03;
                8'd51: ident_word = 16'd2;
                8'd52: ident_word = 16'd2;
                8'd53: ident_word = 16'd3;
                8'd54: ident_word = 16'd988;
                8'd55: ident_word = 16'd16;
                8'd56: ident_word = 16'd52;
                8'd57, 8'd60, 8'd100: ident_word = 16'h8b00;                                  // 822016 & 0xffff
                8'd58, 8'd61, 8'd101: ident_word = 16'h000c;                                  // 822016 >> 16
                8'd62: ident_word = i62;
                8'd63: ident_word = i63;
                8'd64: ident_word = 16'h0003;
                8'd65, 8'd66, 8'd68: ident_word = 16'h0078;
                8'd67: ident_word = 16'h014d;
                8'd88: ident_word = i88;
                default: ident_word = 16'h0000;
            endcase
        end
    endfunction

    // ------------------------------------------------------------------ state
    reg        bsy_r, drdy_r, dsc_r, drq_r, err_r;
    reg [7:0]  error_r, feature_r, secnum_r, cyl_lo_r, cyl_hi_r, devh_r, command_r;
    reg [8:0]  seccount_r;
    reg        bit8_r, single_r;
    reg [15:0] i62_r, i63_r, i88_r;
    reg [9:0]  off_r;
    reg [31:0] cur_lba_r;
    reg        cur_bank_r;
    reg [18:0] idx_el_r;
    reg        tmr_act_r, tmr_dv_r;
    reg [27:0] tmr_el_r, tmr_d_r;
    reg [1:0]  tmr_par_r;
    reg        want_v_r;
    reg [31:0] want_lba_r;
    reg [1:0]  slot_r;
    reg [31:0] slot_lba_r;
    reg        slot_bank_r;
    reg        wr_need_r, wr_done_r;
    reg [31:0] wr_lba_r, wr_done_lba_r;
    reg [1:0]  eng_r;
    reg        eng_wr_r;
    reg        late_r;
    reg [29:0] stall_r;
    reg        present_r  = 1'b0;                  // image mounted: survives core reset (power-up value 0)
    reg        readonly_r = 1'b0;

    // divider (seek time) and identify copy engines
    reg        dv_go, cp_go;                       // start pulses from the control logic (combinational)
    reg [31:0] dv_old_in, dv_new_in;
    wire       dv_done;
    wire [27:0] dv_d;
    reg        cp_act_r, cp_done_r;
    reg [7:0]  cp_idx_r;

    // ------------------------------------------------------------------ bus decode
    assign hit = (bus_addr[23:3] == 21'h134000);                        // 0x9a0000-0x9a0007
    wire [2:0]  reg_off = bus_addr[2:0];
    wire [15:0] wd16 = bus_wdata[15:0];

    // ------------------------------------------------------------------ sector buffer: 2 banks x 256 words, byte lanes
    // simple dual-port, registered read (CONTRACTS SV subset). Write priority: HPS sector data > C31 data > identify copy.
    reg [7:0]  ram_lo [0:511];
    reg [7:0]  ram_hi [0:511];
    reg [7:0]  q_lo, q_hi;
    reg [8:0]  q_addr_r;
    reg        q_stale_r;
    wire       hps_wr_now  = (eng_r == E_XFER) && !eng_wr_r && sd_ack && sd_buff_wr;
    wire       hps_sending = (eng_r != E_IDLE) && eng_wr_r;
    reg        c31_we_lo, c31_we_hi;              // from the control logic (combinational)
    reg [8:0]  c31_waddr;
    reg [15:0] c31_wdata;
    wire       cp_we = cp_act_r && !hps_wr_now && !c31_we_lo && !c31_we_hi;
    wire       we_lo = hps_wr_now || c31_we_lo || cp_we;
    wire       we_hi = hps_wr_now || c31_we_hi || cp_we;
    wire [8:0] waddr = hps_wr_now ? {slot_bank_r, sd_buff_addr} : (c31_we_lo || c31_we_hi) ? c31_waddr
                                  : {cur_bank_r, cp_idx_r};
    wire [15:0] cp_word = ident_word(cp_idx_r, i62_r, i63_r, i88_r);
    wire [15:0] wdata = hps_wr_now ? sd_buff_dout : (c31_we_lo || c31_we_hi) ? c31_wdata : cp_word;
    reg  [8:0] raddr;                              // from the control logic (combinational)
    always @(posedge clk) begin
        if (we_lo) ram_lo[waddr] <= wdata[7:0];
        if (we_hi) ram_hi[waddr] <= wdata[15:8];
        q_lo <= ram_lo[raddr];
        q_hi <= ram_hi[raddr];
        q_addr_r  <= raddr;
        q_stale_r <= (we_lo || we_hi) && (waddr == raddr);
    end
    assign sd_buff_din = {q_hi, q_lo};

    // ------------------------------------------------------------------ control: next state
    reg        bsy_n, drdy_n, dsc_n, drq_n, err_n;
    reg [7:0]  error_n, feature_n, secnum_n, cyl_lo_n, cyl_hi_n, devh_n, command_n;
    reg [8:0]  seccount_n;
    reg        bit8_n, single_n;
    reg [15:0] i62_n, i63_n, i88_n;
    reg [9:0]  off_n;
    reg [31:0] cur_lba_n;
    reg        cur_bank_n;
    reg [18:0] idx_el_n;
    reg        tmr_act_n, tmr_dv_n;
    reg [27:0] tmr_el_n, tmr_d_n;
    reg [1:0]  tmr_par_n;
    reg        want_v_n;
    reg [31:0] want_lba_n;
    reg [1:0]  slot_n;
    reg [31:0] slot_lba_n;
    reg        slot_bank_n;
    reg        wr_need_n, wr_done_n;
    reg [31:0] wr_lba_n, wr_done_lba_n;
    reg [1:0]  eng_n;
    reg        eng_wr_n;
    reg        late_n;
    reg [29:0] stall_n;
    reg [31:0] sd_lba_n;
    reg        sd_rd_n, sd_wr_n;

    // timer due / finish requirements (registered state only)
    wire        sel      = (devh_r[4] == 1'b0);
    // Timing (r4 STA, slow corners -0.172 ns): lba_of() of the task file (a x52 DSP multiply + two 32-bit adds) fed
    // fin_can -> ready -> the C31 bus-ready -> c31_core ir[] load enable in ONE 20 ns clock. The address is now a
    // register one clock behind the task file (cur_addr_r / addr_ok_r), and addr_stale_r marks the one clock after
    // any task-file / image change in which it is not yet valid. In that clock nothing may consume it: the finish
    // (fin_go) and the HPS request for a held finish wait, and any access is held (ready low, guest_wait high:
    // CONTRACTS C1 "ready ... may stay low for a multi-cycle reply", guest_wait pauses guest time), so every value
    // the C31 sees is unchanged. Task-file registers change only in fin_go or on an accepted write (see key_wr).
    reg  [31:0] cur_addr_r;
    reg         addr_ok_r, addr_stale_r;
    wire [31:0] cur_addr = cur_addr_r;
    wire        addr_ok  = addr_ok_r;
    wire        fin_due  = tmr_act_r && tmr_dv_r && (tmr_el_r >= tmr_d_r);
    wire        d_unknown = tmr_act_r && !tmr_dv_r;
    wire        is_rd_cmd = (command_r == 8'h20) || (command_r == 8'h21);
    wire        is_wr_cmd = (command_r == 8'h30) || (command_r == 8'h31);
    wire        rd_have  = (slot_r == SL_READY) && (slot_lba_r == cur_addr);
    wire        wr_have  = wr_done_r && (wr_done_lba_r == cur_addr);
    reg         fin_can;
    always @(*) begin
        fin_can = 1'b1;
        if (tmr_par_r == P_COMMAND) begin
            if (command_r == 8'hec) fin_can = !present_r || cp_done_r;
            else if (is_rd_cmd) fin_can = !addr_ok || rd_have;
            else if (is_wr_cmd) fin_can = !addr_ok || readonly_r || wr_have;
        end
    end
    wire        fin_go   = fin_due && fin_can && !addr_stale_r;
    wire        hold_fin = fin_due && (fin_can || !late_r);          // finish first, or wait for the HPS
    wire        data_rd  = !bus_write && (reg_off == 3'd0);
    wire        data_wr  = bus_write && (reg_off == 3'd0);
    wire        q_ok     = !hps_sending && (q_addr_r == {cur_bank_r, off_r[8:1]}) && !q_stale_r;
    wire        blk_data = (data_rd && !q_ok) || (data_wr && hps_wr_now);
    assign ready      = hit && !addr_stale_r && !hold_fin && !d_unknown && !blk_data;
    assign guest_wait = bus_valid && hit && !ready;
    wire        acc      = bus_valid && bus_sync && ready;
    // conservative "task file may change this clock": every devh/cyl/secnum assignment below is inside fin_go or an
    // accepted write; img_mounted changes present_r (addr_ok)
    wire        key_wr   = fin_go || (acc && bus_write) || img_mounted;
    wire [31:0] lba_now  = lba_of(devh_r, cyl_hi_r, cyl_lo_r, secnum_r);
    always @(posedge clk) begin
        cur_addr_r   <= lba_now;
        addr_ok_r    <= present_r && (lba_now < TOTAL_SECTORS);
        addr_stale_r <= reset || key_wr;
    end

    // read value (atahle.cpp:530-636); IDX per ide_hdd_device_base::calculate_status (atastorage.cpp:935)
    wire        idx_now  = (idx_el_r >= T_ROT);
    wire [7:0]  st_val   = {bsy_r, drdy_r | present_r, 1'b0, dsc_r, drq_r, 1'b0, idx_now, err_r};
    wire [15:0] dword    = bit8_r ? {8'h00, off_r[0] ? q_hi : q_lo} : {q_hi, q_lo};
    reg  [15:0] rval;
    reg         rcalc;                             // calculate_status() called (IDX side effect)
    always @(*) begin
        rval = 16'hffff; rcalc = 1'b0;
        if (sel || single_r) begin
            if (bsy_r && reg_off != 3'd0) begin
                rval  = sel ? {8'h00, st_val} : 16'h0000;
                rcalc = sel;
            end else begin
                case (reg_off)
                    3'd0: if (sel && !bsy_r && drq_r) rval = dword;
                    3'd1: rval = {8'h00, error_r};
                    3'd2: rval = {7'd0, seccount_r};
                    3'd3: rval = {8'h00, secnum_r};
                    3'd4: rval = {8'h00, cyl_lo_r};
                    3'd5: rval = {8'h00, cyl_hi_r};
                    3'd6: rval = {8'h00, devh_r};
                    default: begin rval = sel ? {8'h00, st_val} : 16'h0000; rcalc = sel; end
                endcase
            end
        end
        rdata = {16'h0000, rval};
    end

    reg         abort, bsy_eff, do_rd, do_wr;
    reg [9:0]   off_adv;
    reg [31:0]  ns;
    reg [31:0]  a_lba;
    reg         sf_ok;
    reg [2:0]   sf_m;
    reg [15:0]  sf_w;
    always @(*) begin
        bsy_n = bsy_r; drdy_n = drdy_r; dsc_n = dsc_r; drq_n = drq_r; err_n = err_r;
        error_n = error_r; feature_n = feature_r; secnum_n = secnum_r; cyl_lo_n = cyl_lo_r; cyl_hi_n = cyl_hi_r;
        devh_n = devh_r; command_n = command_r; seccount_n = seccount_r; bit8_n = bit8_r; single_n = single_r;
        i62_n = i62_r; i63_n = i63_r; i88_n = i88_r; off_n = off_r; cur_lba_n = cur_lba_r; cur_bank_n = cur_bank_r;
        tmr_act_n = tmr_act_r; tmr_dv_n = tmr_dv_r; tmr_d_n = tmr_d_r; tmr_par_n = tmr_par_r;
        want_v_n = want_v_r; want_lba_n = want_lba_r; slot_n = slot_r; slot_lba_n = slot_lba_r;
        slot_bank_n = slot_bank_r; wr_need_n = wr_need_r; wr_done_n = wr_done_r; wr_lba_n = wr_lba_r;
        wr_done_lba_n = wr_done_lba_r; eng_n = eng_r; eng_wr_n = eng_wr_r; late_n = late_r; stall_n = stall_r;
        sd_lba_n = sd_lba; sd_rd_n = sd_rd; sd_wr_n = sd_wr;
        dv_go = 1'b0; dv_old_in = 32'd0; dv_new_in = 32'd0; cp_go = 1'b0;
        c31_we_lo = 1'b0; c31_we_hi = 1'b0; c31_waddr = {cur_bank_r, off_r[8:1]}; c31_wdata = wd16;
        abort = 1'b0; bsy_eff = bsy_r; do_rd = 1'b0; do_wr = 1'b0; off_adv = 10'd0; ns = 32'd0; a_lba = 32'd0;
        sf_ok = 1'b0; sf_m = 3'd0; sf_w = 16'd0;

        // guest time
        idx_el_n = (idx_el_r >= T_ROT) ? idx_el_r : idx_el_r + {18'd0, guest_ce};
        tmr_el_n = (tmr_act_r && tmr_el_r != 28'hfffffff) ? tmr_el_r + {27'd0, guest_ce} : tmr_el_r;
        if (dv_done && tmr_act_r && !tmr_dv_r) begin tmr_d_n = dv_d; tmr_dv_n = 1'b1; end

        // ---------------- hps_io block-device engine (one request at a time)
        case (eng_r)
            E_IDLE: if (!sd_ack) begin
                if (wr_need_r) begin
                    sd_lba_n = wr_lba_r; sd_wr_n = 1'b1; eng_wr_n = 1'b1; eng_n = E_REQ;
                    if (slot_r == SL_READY) slot_n = SL_EMPTY;                  // the write may change a fetched sector
                end else if (want_v_r && !(slot_r != SL_EMPTY && slot_lba_r == want_lba_r)) begin
                    sd_lba_n = want_lba_r; sd_rd_n = 1'b1; eng_wr_n = 1'b0; eng_n = E_REQ;
                    slot_n = SL_FLY; slot_lba_n = want_lba_r; slot_bank_n = !cur_bank_r;
                end
            end
            E_REQ: if (sd_ack) begin sd_rd_n = 1'b0; sd_wr_n = 1'b0; eng_n = E_XFER; end
            default: if (!sd_ack) begin
                eng_n = E_IDLE;
                if (eng_wr_r) begin wr_need_n = 1'b0; wr_done_n = 1'b1; wr_done_lba_n = sd_lba; end
                else slot_n = SL_READY;
            end
        endcase

        // ---------------- access held on an unfinished timer: request what the finish needs; give up after STALL_MAX
        if (fin_due && !fin_can && !addr_stale_r) begin
            if (is_rd_cmd && !(want_v_r && want_lba_r == cur_addr)) begin want_v_n = 1'b1; want_lba_n = cur_addr; end
            if (is_wr_cmd && !wr_need_r && !(eng_r != E_IDLE && eng_wr_r)) begin
                wr_need_n = 1'b1; wr_lba_n = cur_addr; wr_done_n = 1'b0;
            end
            if (bus_valid && hit && !late_r) begin
                if (stall_r >= STALL_M1) late_n = 1'b1;
                else stall_n = stall_r + 30'd1;
            end
        end

        // ---------------- busy timer expiry (atahle.cpp:159 busy_tick -> finished_busy :171)
        if (fin_go) begin
            bsy_n = 1'b0; tmr_act_n = 1'b0; late_n = 1'b0; stall_n = 30'd0;
            case (tmr_par_r)
                P_DETECT: begin                                   // m_single_device = daspin clear; soft_reset()
                    single_n = 1'b1;
                    off_n = 10'd0; drq_n = 1'b0; err_n = 1'b0; drdy_n = present_r; dsc_n = 1'b1;
                    bsy_n = 1'b1; tmr_act_n = 1'b1; tmr_dv_n = 1'b1; tmr_d_n = T_RESET; tmr_par_n = P_DIAG;
                    tmr_el_n = tmr_el_r - tmr_d_r + {27'd0, guest_ce};   // chained timer starts at the expiry
                    cur_lba_n = 32'd0;
                end
                P_DIAG: begin                                     // start_diagnostic, finished_diagnostic, signature
                    error_n = present_r ? 8'h01 : 8'h00;
                    seccount_n = 9'd1; secnum_n = 8'd1; cyl_lo_n = 8'd0; cyl_hi_n = 8'd0; devh_n = 8'd0;
                end
                default: begin                                    // finished_command
                    if (command_r == 8'hec) begin
                        if (present_r) drq_n = 1'b1;
                        else begin err_n = 1'b1; error_n = 8'h00; end
                    end else if (is_rd_cmd) begin                  // finished_read (:446)
                        if (!addr_ok) begin err_n = 1'b1; error_n = 8'h80; end
                        else begin
                            cur_bank_n = slot_bank_r; slot_n = SL_EMPTY; want_v_n = 1'b0;
                            if (seccount_r != 9'd1) begin
                                ns = next_sec(devh_r, cyl_hi_r, cyl_lo_r, secnum_r);
                                devh_n = ns[31:24]; cyl_hi_n = ns[23:16]; cyl_lo_n = ns[15:8]; secnum_n = ns[7:0];
                                cur_lba_n = lba_of(ns[31:24], ns[23:16], ns[15:8], ns[7:0]);
                                want_v_n = 1'b1; want_lba_n = cur_lba_n;        // prefetch the next sector
                            end
                            drq_n = 1'b1;
                        end
                    end else if (is_wr_cmd) begin                  // finished_write (:597)
                        if (!addr_ok || readonly_r) begin err_n = 1'b1; error_n = 8'h80; end
                        else begin
                            wr_done_n = 1'b0;
                            if (seccount_r != 9'd1) begin
                                ns = next_sec(devh_r, cyl_hi_r, cyl_lo_r, secnum_r);
                                devh_n = ns[31:24]; cyl_hi_n = ns[23:16]; cyl_lo_n = ns[15:8]; secnum_n = ns[7:0];
                                cur_lba_n = lba_of(ns[31:24], ns[23:16], ns[15:8], ns[7:0]);
                            end
                            if (seccount_r != 9'd0) seccount_n = seccount_r - 9'd1;
                            if (seccount_r > 9'd1) drq_n = 1'b1;
                        end
                    end else if (command_r == 8'hef) begin         // set_features (atahle.cpp:273)
                        sf_m = seccount_r[2:0];
                        case (feature_r)
                            8'h01: begin sf_ok = 1'b1; bit8_n = 1'b1; end
                            8'h81: begin sf_ok = 1'b1; bit8_n = 1'b0; end
                            8'h66, 8'hcc, 8'h88, 8'h99, 8'haa: sf_ok = 1'b1;   // revert-to-defaults flag unobservable
                            8'h03: begin
                                case (seccount_r[7:3])
                                    5'h00: sf_ok = (sf_m <= 3'd1);
                                    5'h01: begin
                                        if (sf_m <= 3'd2) sf_ok = 1'b1;
                                        else if (sf_m <= 3'd4) begin                  // identify[64] = 0x0003
                                            sf_ok = 1'b1;
                                            i62_n = {8'h00, i62_r[7:0]}; i63_n = {8'h00, i63_r[7:0]};
                                            i88_n = {8'h00, i88_r[7:0]};
                                        end
                                    end
                                    5'h02, 5'h04, 5'h08: begin                        // set_dma_mode(62/63/88)
                                        sf_w = (seccount_r[7:3] == 5'h02) ? i62_r :
                                               (seccount_r[7:3] == 5'h04) ? i63_r : i88_r;
                                        if (sf_w[sf_m]) begin
                                            sf_ok = 1'b1;
                                            i62_n = {8'h00, i62_r[7:0]}; i63_n = {8'h00, i63_r[7:0]};
                                            i88_n = {8'h00, i88_r[7:0]};
                                            if (seccount_r[7:3] == 5'h02) i62_n = {8'h00, i62_r[7:0]} | (16'h0100 << sf_m);
                                            else if (seccount_r[7:3] == 5'h04) i63_n = {8'h00, i63_r[7:0]} | (16'h0100 << sf_m);
                                            else i88_n = {8'h00, i88_r[7:0]} | (16'h0100 << sf_m);
                                        end
                                    end
                                    default: sf_ok = 1'b0;
                                endcase
                            end
                            default: sf_ok = 1'b0;
                        endcase
                        if (!sf_ok) begin err_n = 1'b1; error_n = 8'h04; end
                    end
                end
            endcase
        end

        // ---------------- C31 access (exactly once per accept)
        if (acc && !bus_write) begin                                              // command_r (atahle.cpp:530)
            drdy_n = drdy_n | present_r;
            if (rcalc && idx_now) idx_el_n = {18'd0, guest_ce};                   // m_last_status_timer restart
            if ((sel || single_r) && reg_off == 3'd0 && sel && !bsy_r && drq_r) begin
                do_rd = 1'b1;                                                     // read_data (:383)
                off_adv = bit8_r ? 10'd1 : 10'd2;
                off_n = off_r + off_adv;
                if (off_r + off_adv >= 10'd512) begin                             // read_buffer_empty (:431)
                    off_n = 10'd0; drq_n = 1'b0;
                    if (command_r != 8'hec) begin                                 // fill_buffer (:404)
                        if (seccount_r != 9'd0) seccount_n = seccount_r - 9'd1;
                        if (seccount_r > 9'd1) begin
                            bsy_n = 1'b1; tmr_act_n = 1'b1; tmr_dv_n = 1'b1; tmr_d_n = T_BETWEEN;
                            tmr_par_n = P_COMMAND; tmr_el_n = {27'd0, guest_ce};
                        end
                    end
                end
            end
        end
        if (acc && bus_write) begin                                               // command_w (atahle.cpp:728)
            if (drq_r && reg_off != 3'd0 && (reg_off != 3'd6 || wd16 != {8'h00, devh_r})) begin
                abort = 1'b1;                                                     // stop_busy + ABRT
                bsy_n = 1'b0; tmr_act_n = 1'b0; drq_n = 1'b0; err_n = 1'b1; error_n = 8'h04;
            end
            bsy_eff = abort ? 1'b0 : bsy_r;
            if (!bsy_eff) begin
                case (reg_off)
                    3'd0: if ((sel || single_r) && sel && drq_r) begin              // write_data (:398)
                        do_wr = 1'b1;
                        if (bit8_r) begin
                            c31_we_lo = !off_r[0]; c31_we_hi = off_r[0]; c31_wdata = {wd16[7:0], wd16[7:0]};
                            off_adv = 10'd1;
                        end else begin
                            c31_we_lo = 1'b1; c31_we_hi = 1'b1; c31_wdata = wd16; off_adv = 10'd2;
                        end
                        off_n = off_r + off_adv;
                        if (off_r + off_adv >= 10'd512) begin                         // write_buffer_full (:447)
                            off_n = 10'd0; drq_n = 1'b0;
                            bsy_n = 1'b1; tmr_act_n = 1'b1; tmr_dv_n = 1'b1; tmr_d_n = T_WRITE;   // process_buffer
                            tmr_par_n = P_COMMAND; tmr_el_n = {27'd0, guest_ce};
                            if (is_wr_cmd && addr_ok && !readonly_r) begin             // start the HPS write now
                                wr_need_n = 1'b1; wr_lba_n = cur_addr; wr_done_n = 1'b0;
                            end
                        end
                    end
                    3'd1: feature_n = wd16[7:0];
                    3'd2: seccount_n = (wd16[7:0] != 8'd0) ? {1'b0, wd16[7:0]} : 9'h100;
                    3'd3: secnum_n = wd16[7:0];
                    3'd4: cyl_lo_n = wd16[7:0];
                    3'd5: cyl_hi_n = wd16[7:0];
                    3'd6: devh_n = wd16[7:0];
                    default: if (sel || command_r == 8'h90) begin
                        command_n = wd16[7:0]; off_n = 10'd0; err_n = 1'b0; error_n = 8'h00;
                        case (wd16[7:0])                                               // process_command (:660)
                            8'h20, 8'h21: begin                                        // read_first_sector (:505)
                                bsy_n = 1'b1; tmr_act_n = 1'b1; tmr_dv_n = 1'b0; tmr_par_n = P_COMMAND;
                                tmr_el_n = {27'd0, guest_ce};
                                dv_go = 1'b1; dv_old_in = cur_lba_r; dv_new_in = cur_addr;
                                cur_lba_n = cur_addr;                                  // seek_time() updates m_cur_lba
                                if (addr_ok) begin want_v_n = 1'b1; want_lba_n = cur_addr; end
                            end
                            8'h30, 8'h31: drq_n = 1'b1;
                            8'hec, 8'hef: begin
                                bsy_n = 1'b1; tmr_act_n = 1'b1; tmr_dv_n = 1'b1; tmr_d_n = T_MINCMD;
                                tmr_par_n = P_COMMAND; tmr_el_n = {27'd0, guest_ce};
                                if (wd16[7:0] == 8'hec) cp_go = 1'b1;
                            end
                            default: begin err_n = 1'b1; error_n = 8'h04; end        // atahle.cpp:211
                        endcase
                    end
                endcase
            end
        end

        raddr = hps_sending ? {cur_bank_r, sd_buff_addr} : {cur_bank_n, off_n[8:1]};
    end

    // ------------------------------------------------------------------ control: registers
    always @(posedge clk) begin
        if (img_mounted) begin present_r <= (img_size != 64'd0); readonly_r <= img_readonly; end
        if (reset) begin                                                  // device_reset (atahle.cpp:127), csel 0
            bsy_r <= 1'b1; drdy_r <= 1'b0; dsc_r <= 1'b0; drq_r <= 1'b0; err_r <= 1'b0;
            error_r <= 8'd0; feature_r <= 8'd0; secnum_r <= 8'd0; cyl_lo_r <= 8'd0; cyl_hi_r <= 8'd0; devh_r <= 8'd0;
            command_r <= 8'd0; seccount_r <= 9'd0; bit8_r <= 1'b0; single_r <= 1'b0;
            i62_r <= 16'h0007; i63_r <= 16'h0407; i88_r <= 16'h0000;
            off_r <= 10'd0; cur_lba_r <= 32'd0; cur_bank_r <= 1'b0; idx_el_r <= 19'd0;
            tmr_act_r <= 1'b1; tmr_dv_r <= 1'b1; tmr_el_r <= 28'd0; tmr_d_r <= T_RESET; tmr_par_r <= P_DETECT;
            want_v_r <= 1'b0; want_lba_r <= 32'd0; slot_r <= SL_EMPTY; slot_lba_r <= 32'd0; slot_bank_r <= 1'b1;
            wr_need_r <= 1'b0; wr_done_r <= 1'b0; wr_lba_r <= 32'd0; wr_done_lba_r <= 32'd0;
            eng_r <= E_IDLE; eng_wr_r <= 1'b0; late_r <= 1'b0; stall_r <= 30'd0;
            sd_lba <= 32'd0; sd_rd <= 1'b0; sd_wr <= 1'b0;
        end else begin
            bsy_r <= bsy_n; drdy_r <= drdy_n; dsc_r <= dsc_n; drq_r <= drq_n; err_r <= err_n;
            error_r <= error_n; feature_r <= feature_n; secnum_r <= secnum_n; cyl_lo_r <= cyl_lo_n; cyl_hi_r <= cyl_hi_n;
            devh_r <= devh_n; command_r <= command_n; seccount_r <= seccount_n; bit8_r <= bit8_n; single_r <= single_n;
            i62_r <= i62_n; i63_r <= i63_n; i88_r <= i88_n;
            off_r <= off_n; cur_lba_r <= cur_lba_n; cur_bank_r <= cur_bank_n; idx_el_r <= idx_el_n;
            tmr_act_r <= tmr_act_n; tmr_dv_r <= tmr_dv_n; tmr_el_r <= tmr_el_n; tmr_d_r <= tmr_d_n; tmr_par_r <= tmr_par_n;
            want_v_r <= want_v_n; want_lba_r <= want_lba_n; slot_r <= slot_n; slot_lba_r <= slot_lba_n;
            slot_bank_r <= slot_bank_n;
            wr_need_r <= wr_need_n; wr_done_r <= wr_done_n; wr_lba_r <= wr_lba_n; wr_done_lba_r <= wr_done_lba_n;
            eng_r <= eng_n; eng_wr_r <= eng_wr_n; late_r <= late_n; stall_r <= stall_n;
            sd_lba <= sd_lba_n; sd_rd <= sd_rd_n; sd_wr <= sd_wr_n;
        end
    end

    // hang safety net fired (sticky until reset): the HPS owed one sector for STALL_MAX clocks
    reg hold_fault_r = 1'b0;
    always @(posedge clk) begin
        if (reset) hold_fault_r <= 1'b0;
        else if (late_n && !late_r) hold_fault_r <= 1'b1;
    end
`ifdef WG1_DIAG_MIRROR
    assign dbg_ide = {hold_fault_r, late_r, err_r};
`endif

    // ------------------------------------------------------------------ identify copy into the current bank
    // (finished_command IDENTIFY copies m_identify_buffer into m_buffer, atastorage.cpp:250-257; the copy runs during
    // the 10 us BSY, when the buffer is unobservable, and the finish waits for it)
    always @(posedge clk) begin
        if (reset) begin cp_act_r <= 1'b0; cp_done_r <= 1'b0; cp_idx_r <= 8'd0; end
        else if (cp_go) begin cp_act_r <= 1'b1; cp_done_r <= 1'b0; cp_idx_r <= 8'd0; end
        else if (cp_we) begin
            cp_idx_r <= cp_idx_r + 8'd1;
            if (cp_idx_r == 8'd255) begin cp_act_r <= 1'b0; cp_done_r <= 1'b1; end
        end
    end

    // ------------------------------------------------------------------ seek time (atastorage.cpp:380-402)
    // old/new cylinder = m_cur_lba / 832 and lba / 832 as C int (only -1 is ever negative -> 0), diff = |old-new|;
    // diff 0 -> TIME_BETWEEN_SECTORS (10), else 32500 + ceil(81250*diff/247). One restoring divider, three passes.
    reg  [1:0]  dv_ph;          // 0 idle, 1 old cyl, 2 new cyl, 3 seek quotient
    reg  [5:0]  dv_it;
    reg  [39:0] dv_n;
    reg  [39:0] dv_q;
    reg  [10:0] dv_rem;
    reg  [9:0]  dv_den;
    reg  [31:0] dv_new_save;
    reg  [39:0] dv_oldc;
    reg         dv_done_r;
    reg  [27:0] dv_d_r;
    assign dv_done = dv_done_r;
    assign dv_d    = dv_d_r;
    wire [10:0] dv_trial = {dv_rem[9:0], dv_n[39]};
    wire        dv_ge    = (dv_trial >= {1'b0, dv_den});
    wire [39:0] dv_qn    = {dv_q[38:0], dv_ge};
    wire [39:0] dv_diff  = (dv_oldc > dv_qn) ? dv_oldc - dv_qn : dv_qn - dv_oldc;
    always @(posedge clk) begin
        dv_done_r <= 1'b0;
        if (reset) begin dv_ph <= 2'd0; dv_it <= 6'd0; end
        else if (dv_go) begin
            dv_ph <= 2'd1; dv_it <= 6'd0; dv_den <= 10'd832; dv_rem <= 11'd0; dv_q <= 40'd0;
            dv_n <= {8'd0, (dv_old_in == 32'hffffffff) ? 32'd0 : dv_old_in};
            dv_new_save <= dv_new_in;
        end else if (dv_ph != 2'd0) begin
            dv_rem <= dv_ge ? dv_trial - {1'b0, dv_den} : dv_trial;
            dv_q   <= dv_qn;
            dv_n   <= {dv_n[38:0], 1'b0};
            dv_it  <= dv_it + 6'd1;
            if (dv_it == 6'd39) begin
                dv_it <= 6'd0; dv_rem <= 11'd0; dv_q <= 40'd0;
                if (dv_ph == 2'd1) begin
                    dv_oldc <= dv_qn; dv_ph <= 2'd2; dv_den <= 10'd832;
                    dv_n <= {8'd0, (dv_new_save == 32'hffffffff) ? 32'd0 : dv_new_save};
                end else if (dv_ph == 2'd2) begin
                    if (dv_diff == 40'd0) begin dv_ph <= 2'd0; dv_d_r <= T_BETWEEN; dv_done_r <= 1'b1; end
                    else begin dv_ph <= 2'd3; dv_den <= 10'd247; dv_n <= dv_diff * 40'd81250 + 40'd246; end
                end else begin
                    dv_ph <= 2'd0; dv_d_r <= 28'd32500 + dv_qn[27:0]; dv_done_r <= 1'b1;
                end
            end
        end
    end
endmodule
`default_nettype wire
