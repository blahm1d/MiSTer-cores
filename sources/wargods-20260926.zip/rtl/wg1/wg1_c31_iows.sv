// wg1_c31_iows.sv -- TMS320C31 primary-bus wait states on the I/O ASIC window (wg1, 2026-09-25).
// Used by wg1_board (the shipped path) and by the VS-ladder gate bench (tests/vs_ladder), so the gate exercises the
// logic that ships.
//
// Primary bus control register 0x808064 (TMS320C3x User's Guide): SWW = bits 4:3, WTCNT = bits 7:5 (reset 0x10F8 =
// SWW 11 / WTCNT 7, c31_peripherals.sv:176). An access ends when:
//   SWW 00  external READY only                 -> ASIC_READY_H1
//   SWW 01  internal wait counter only          -> WTCNT
//   SWW 10  internal OR external (first wins)   -> min(WTCNT, ASIC_READY_H1)
//   SWW 11  internal AND external (both)        -> max(WTCNT, ASIC_READY_H1)
// War Gods programs (MAME 0.289 write log H:/temp/wargods/speed/busctl/busctl.log):
//   * u41 boot: 0x04E8 (SWW 01, WTCNT 7) at PC 0x00004D (H:/temp/wargods/m0/boot_3m.tr line 13), toggling 0x04F8/0x04E8;
//   * disk-loaded game code: 0x0400 (SWW 00, WTCNT 0 = external READY only) at PC 0x018012 (t = 26.571 s) and
//     0x00F514 (t = 26.644 s) -- the in-game setting, in force at the attract VS ladder.
// ASIC_READY_H1 -- the I/O ASIC's READY latency -- is not documented and MAME models no wait states at all
// (midvunit.cpp:307 stores the register only). It is taken as a BOUND: 7 H1, equal to the board's own boot-time
// software setting (WTCNT 7). Justification: with READY faster than ~10 DSP cycles for the host's reply->next-word
// path (>= 5 I/O ASIC accesses, CFF1-CFF6 + D01E-D022), the War Gods DCS2 program's IRQ2-vector window (PM[4] = RTI
// from 0x33A8 until 0x33EF, 10 instructions after an IRQ1 reply post at 0x31E5) swallows a host word and the sound board
// deadlocks -- the real board does not do that (cabinet r6/r7 VS-ladder hang = the zero-wait fabric host), so the real
// ASIC READY is at least that slow; 7 H1 per access gives >= 35 H1 = 22.4 DSP cycles on that path.
// One H1 = 2 clk at CLKIN 50 MHz. Guest time keeps running during the wait.
//
// Contract: io_ws_done rises once the access to the I/O ASIC (ext_valid && io_hit) has been offered for 2*waits clocks
// of ext_sync; the board gates the slave's C1 accept (bus_sync) and ext_ready with it. The counter restarts when the
// access completes (ext_ready) or is withdrawn.
`default_nettype none
module wg1_c31_iows #(
    parameter integer ASIC_READY_H1 = 7
) (
    input  wire        clk,
    input  wire        reset,
    input  wire [31:0] bus_control,   // 0x808064 as programmed
    input  wire        ext_valid,
    input  wire        io_hit,
    input  wire        ext_sync,
    input  wire        ext_ready,
    output wire        io_ws_done
);
    wire [3:0] wtcnt = {1'b0, bus_control[7:5]};
    wire [3:0] ardy  = ASIC_READY_H1[3:0];
    reg  [3:0] ws_h1;
    always @(*) begin
        case (bus_control[4:3])
            2'b00:   ws_h1 = ardy;                              // external READY only
            2'b01:   ws_h1 = wtcnt;                             // internal counter only
            2'b10:   ws_h1 = (wtcnt < ardy) ? wtcnt : ardy;     // OR: first ready
            default: ws_h1 = (wtcnt > ardy) ? wtcnt : ardy;     // AND: both ready
        endcase
    end
    reg  [4:0] cnt;
`ifdef MUT_NO_IO_WS
    assign io_ws_done = 1'b1;                                   // mutant: MAME's zero-wait bus
`else
    assign io_ws_done = cnt >= {ws_h1, 1'b0};
`endif
    always @(posedge clk) begin
        if (reset || !(ext_valid && io_hit) || ext_ready) cnt <= 5'd0;
        else if (ext_sync && !io_ws_done)                 cnt <= cnt + 5'd1;
    end
endmodule
`default_nettype wire
