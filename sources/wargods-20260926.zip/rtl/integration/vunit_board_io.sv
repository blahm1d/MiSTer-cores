// SPDX-License-Identifier: BSD-3-Clause
// Functional register behavior follows MAME midvunit.cpp (Aaron Giles),
// ADC0844 selection follows adc0844.cpp (Dirk Best). See README.md sources.
module vunit_board_io #(
    parameter integer ADC_CONVERSION_GUEST_STEPS=1000
) (
    input wire clk,reset,guest_ce,bus_ce,
    input wire req_valid,req_write,
    input wire [23:0] req_addr,
    input wire [31:0] req_wdata,
    output wire address_hit,access_supported,req_ready,
    output reg [31:0] req_rdata,
    output wire guest_memory_wait,
    input wire control_update,
    input wire [15:0] control_data,
    input wire [15:0] cabinet_in0,cabinet_in1,cabinet_switch2,cabinet_dips,
    input wire [31:0] adc_channels,
    output reg irq_int3,
    output reg cmos_protected,
    output reg [15:0] system_control,
    output reg [15:0] comm_data,
    output reg [7:0] comm_flags,
    // Stage 2 (2026-09-18): a LOWER bound on the guest ticks until the ADC conversion raises INT3 (the tick on which
    // adc_remaining steps 1 -> 0), for the guest-time gate (rtl/c31/periph/c31_guest_gate.sv); all ones when no
    // conversion is running, 0 in the clock a register access is accepted (a conversion may be starting).
    output wire [23:0] int3_event_lb
);
    wire cmos_hit=req_addr>=24'h9c0000 && req_addr<=24'h9c1fff;
    wire comm_hit=req_addr>=24'h997000 && req_addr<=24'h997008;
    assign address_hit=cmos_hit || comm_hit || req_addr==24'h995020 ||
        req_addr==24'h990000 || req_addr==24'h991030 || req_addr==24'h991050 ||
        req_addr==24'h991060 || req_addr==24'h992000 || req_addr==24'h993000;
    assign access_supported=cmos_hit || comm_hit || req_addr==24'h993000 ||
        (req_addr==24'h995020 && req_write) ||
        (!req_write && (req_addr==24'h990000 || req_addr==24'h991030 ||
         req_addr==24'h991050 || req_addr==24'h991060 || req_addr==24'h992000));

    // MAME's 8192-word view is a functional storage choice; the physical board
    // exposes narrow battery RAM lanes. Power-up all-ones; soft reset retains it.
    reg [31:0] nvram_words [0:8191];
    reg cmos_pending,cmos_reply_ready;
    reg [12:0] cmos_index;
    reg [31:0] cmos_reply;
    wire capture_cmos=req_valid && bus_ce && cmos_hit && !req_write && !cmos_pending;
    assign guest_memory_wait=!reset && (capture_cmos || (cmos_pending && !cmos_reply_ready));
    assign req_ready=!reset && bus_ce && access_supported &&
                     (!(cmos_hit && !req_write) || cmos_reply_ready);
    wire accepted=req_valid && req_ready;
    reg [3:0] adc_channel;
    reg [7:0] adc_result;
    reg [31:0] adc_remaining;
    assign int3_event_lb = accepted ? 24'd0 :
                           (adc_remaining == 32'd0) ? 24'hffffff :
                           (adc_remaining > 32'h00ffffff) ? 24'hfffffe : (adc_remaining[23:0] - 24'd1);
    initial begin
        // Constant per-loop bound stays below Quartus 17's 5000-iteration
        // elaboration guard. This remains RAM power-up data, not a reset port.
        for(integer bank=0;bank<2;bank=bank+1)
            for(integer word_index=0;word_index<4096;word_index=word_index+1)
                nvram_words[bank*4096+word_index]=32'hffffffff;
    end
    function automatic [7:0] adc_value(input [3:0] channel,input [31:0] channels);
        integer a,b,c,d,result;
        begin
            a=channels[7:0];b=channels[15:8];c=channels[23:16];d=channels[31:24];
            case(channel)
                0,8: result=255-b+a;
                1,9: result=255-a+b;
                2,10: result=255-d+c;
                3,11: result=255-c+d;
                4: result=a;5: result=b;6: result=c;7: result=d;
                12: result=255-d+a;13: result=255-d+b;14: result=255-d+c;
                default: result=0;
            endcase
            adc_value=result<0 ? 0 : result>255 ? 255 : result;
        end
    endfunction
    always @* begin
        req_rdata=0;
        if(cmos_hit) req_rdata=cmos_reply;
        else case(req_addr)
            24'h990000: req_rdata=4; // Source comparison's communications PAL status.
            // USA's offset-free MAME lr16 handlers have no unit mask: a
            // full C31 word invokes both16-bit subunits. Preserve both lanes;
            // original READIO uses the low switch half and upper DIP half.
            24'h991030: req_rdata={cabinet_in1,cabinet_in1};
            24'h991050: req_rdata={16'b0,cabinet_switch2}; // Explicit original-source fixture.
            24'h991060: req_rdata={cabinet_in0,cabinet_in0};
            24'h992000: req_rdata={cabinet_dips,cabinet_dips};
            24'h993000: req_rdata=system_control[6] ? 32'hffffffff : {adc_result,24'b0};
            // The single-cab MAME link model removes its own driven bits;
            // without a linked peer, all mapped communication reads are zero.
            default: req_rdata=0;
        endcase
    end
    always @(posedge clk) begin
        if(reset) begin
            cmos_protected<=1;system_control<=16'h00ff;
            comm_data<=0;comm_flags<=0;
            cmos_pending<=0;cmos_reply_ready<=0;cmos_index<=0;cmos_reply<=0;
            adc_channel<=15;adc_result<=255;adc_remaining<=0;irq_int3<=0;
        end else begin
            if(control_update) system_control<=control_data;
            if(capture_cmos) begin cmos_pending<=1;cmos_index<=req_addr[12:0];end
            if(cmos_pending && !cmos_reply_ready) begin
                cmos_reply<=nvram_words[cmos_index];cmos_reply_ready<=1;
            end
            if(guest_ce && adc_remaining!=0) begin
                adc_remaining<=adc_remaining-1'b1;
                if(adc_remaining==1) begin adc_result<=adc_value(adc_channel,adc_channels);irq_int3<=1;end
            end
            if(accepted) begin
                if(cmos_hit) begin
                    if(req_write && !cmos_protected) nvram_words[req_addr[12:0]]<=req_wdata;
                    if(!req_write) begin cmos_pending<=0;cmos_reply_ready<=0;end
                end else if(req_addr==24'h995020) cmos_protected<=req_wdata[11:10]!=2'b11;
                else if(req_addr==24'h993000) begin
                    if(req_write && !system_control[5]) begin
                        adc_channel<=req_wdata[27:24];irq_int3<=0;
                        adc_remaining<=ADC_CONVERSION_GUEST_STEPS<1 ? 1 : ADC_CONVERSION_GUEST_STEPS;
                    end else if(!req_write && !system_control[6]) irq_int3<=0;
                end else if(comm_hit && req_write) begin
                    if(req_addr[3:0]==0) comm_data<=req_wdata[31:16];
                    if(req_addr[3:0]==1) comm_flags<={req_wdata[31:29],5'b0};
                end
            end
        end
    end
endmodule

