`timescale 1ns/1ps
`default_nettype none
// One-credit, single-clock external-memory front end. See README.md.
// Avalon address is an aligned BYTE address. Writes and uncached reads use
// one beat; a texture miss may own a bounded read burst until all beats drain.
module vunit_memory_arbiter #(
    // Optional one-line scanout cache. Default off preserves a direct DDR
    // comparison path; CPU reads never use this cache.
    parameter integer FRAMEBUFFER_CACHE=0,
    // Optional coherent one-line renderer texture cache; CPU reads stay direct.
    parameter integer TEXTURE_CACHE=0,
    parameter integer TEXTURE_CACHE_BEATS=1,
    // Direct-mapped texture lines (1 keeps the historical single coherent line).
    parameter integer TEXTURE_CACHE_LINES=1,
    // 1: a texture hit is answered from a dedicated registered path one clock
    // after acceptance without taking the credit; misses still own the burst
    // and no new texture request is admitted while a miss is in flight, so
    // replies stay in order. 0 keeps the historical one-credit hit reply.
    parameter integer TEXTURE_FAST_HIT=0,
    // 1: renderer framebuffer writes merge into one 64-bit word buffer and
    // reach DDR as one command per word (flushed on a word change, on an
    // aliasing scanout/CPU access, or when the arbiter is otherwise idle).
    // 0 keeps one physical write per pixel.
    parameter integer FRAME_WRITE_COALESCE=0,
    // Hit-under-miss (14 September 2026): fast hits to other lines are served
    // while a miss burst is in flight; replies carry the request's tag and may
    // leave out of order, so only a tagged consumer may enable it.
    parameter integer TEXTURE_HIT_UNDER_MISS=0,
    // Pipelined texture fills (14 September 2026): up to TEXTURE_FILL_DEPTH line
    // bursts outstanding on the one DDR port, responses routed in issue order
    // between the main transaction and the fills, and a four-entry miss queue
    // that admits a miss without the credit and answers it through the fast
    // reply register once its line lands. Tagged consumers only (replies are
    // out of order by construction).
    parameter integer TEXTURE_FILL_DEPTH=0,
    // Next-line prefetch (fill mode): an accepted request whose line differs from the
    // previous request's queues the line one step beyond it in the direction of the
    // change (a span walking along u gets its next line before it arrives there).
    parameter integer TEXTURE_NEXT_LINE=0
) (
    input wire clk,reset,
    input wire config_valid,
    output wire config_ready,
    input wire [31:0] config_fb_base,config_texture_base,config_palette_base,
    input wire backend_quiesced,
    output wire backend_reset_request,
    output reg configured,
    output reg [7:0] fault_code,
    output reg [31:0] fault_address,
    output wire available_credit,physical_wait,halted,
    // Hold across the complete scanout framebuffer->palette chain. No CPU or
    // renderer transaction may enter between these reads while it is asserted.
    input wire scanout_lock,
    // Ungated state offers, independent of guest_ce and accepted valid signals.
    input wire guest_fb_offer,guest_tex_offer,
    input wire fb_valid,
    output wire fb_ready,
    input wire [18:0] fb_addr,
    input wire [15:0] fb_data,
    // Width lane: fb_data_hi is the pixel at fb_addr+1 (fb_addr even) written
    // in the same transaction; never straddles a 64-bit word.
    input wire fb_pair,
    input wire [15:0] fb_data_hi,
    input wire tex_req_valid,
    output wire tex_req_ready,
    input wire [21:0] tex_req_addr,
    // Fill-only request (TEXTURE_FAST_HIT): fetch the line, no reply, always
    // accepted (dropped when the line is cached or the credit is busy).
    input wire tex_req_prefetch,
    // Width lane: every reply also carries the byte at line offset tex_req_off2
    // of the requested 8-byte texture word (tex_rsp_data2).
    input wire [2:0] tex_req_off2,
    input wire [3:0] tex_req_tag,
    output wire tex_rsp_valid,
    input wire tex_rsp_ready,
    output wire [7:0] tex_rsp_data,
    output wire [7:0] tex_rsp_data2,
    output wire [3:0] tex_rsp_tag,
    input wire cpu_mem_req_valid,
    output wire cpu_mem_req_ready,
    input wire cpu_mem_req_write,
    input wire [1:0] cpu_mem_req_region,
    input wire [21:0] cpu_mem_req_addr,
    input wire [31:0] cpu_mem_req_wdata,
    input wire [3:0] cpu_mem_req_be,
    output wire cpu_mem_rsp_valid,
    input wire cpu_mem_rsp_ready,
    output wire [31:0] cpu_mem_rsp_rdata,
    input wire fb_read_req_valid,
    output wire fb_read_req_ready,
    input wire [18:0] fb_read_req_addr,
    output wire fb_read_rsp_valid,
    input wire fb_read_rsp_ready,
    output wire [15:0] fb_read_rsp_data,
    input wire pal_read_req_valid,
    output wire pal_read_req_ready,
    input wire [14:0] pal_read_req_addr,
    output wire pal_read_rsp_valid,
    input wire pal_read_rsp_ready,
    output wire [31:0] pal_read_rsp_data,
    output wire avm_read,avm_write,
    output wire [31:0] avm_address,
    output wire [63:0] avm_writedata,
    output wire [7:0] avm_byteenable,
    output wire [3:0] avm_burstcount,
    input wire avm_waitrequest,avm_readdatavalid,
    input wire [63:0] avm_readdata,
    input wire avm_read_error
);
    localparam [1:0] IDLE=0,COMMAND=1,READ_WAIT=2,REPLY=3;
    localparam [2:0] CPU=0,FRAME_WRITE=1,TEXTURE_READ=2,SCAN_FB=3,SCAN_PALETTE=4;
    localparam [7:0] BAD_CONFIG=1,BAD_CPU_REQUEST=2,UNEXPECTED_READ_RESPONSE=3,
                     READ_ERROR=4,BAD_SCANOUT_LOCK=5,BAD_GUEST_OFFER=6;
    reg [1:0] state;
    reg [2:0] owner,byte_lane;
    reg [1:0] read_width;
    reg command_write;
    reg [31:0] fb_base,texture_base,palette_base,command_address,reply_data;
    reg [7:0] reply_data2;reg [2:0] reply_off2;reg [3:0] reply_tag;   // second byte and tag of the credit-path texture reply
    reg [63:0] command_data;
    reg [7:0] command_be;
    reg [3:0] command_burst,read_remaining;
    localparam integer TEXTURE_INDEX_W=TEXTURE_CACHE_BEATS<2 ? 1 : $clog2(TEXTURE_CACHE_BEATS);
    localparam integer TEXTURE_LINE_BITS=$clog2(TEXTURE_CACHE_BEATS*8);
    reg [TEXTURE_INDEX_W-1:0] texture_fill_index,texture_sample_index;
    reg fb_cache_valid;
    reg [28:0] fb_cache_tag;
    reg [63:0] fb_cache_data;
    localparam integer TEXTURE_LINE_IDX_W=TEXTURE_CACHE_LINES<2 ? 1 : $clog2(TEXTURE_CACHE_LINES);
    reg texture_cache_valid[0:TEXTURE_CACHE_LINES-1];
    reg [28:0] texture_cache_tag[0:TEXTURE_CACHE_LINES-1];
    reg [63:0] texture_cache_data[0:TEXTURE_CACHE_LINES-1][0:TEXTURE_CACHE_BEATS-1];
    reg [TEXTURE_LINE_IDX_W-1:0] texture_fill_line;
    // ---- Pipelined texture fills (TEXTURE_FILL_DEPTH>0) ----
    localparam integer FILL=(TEXTURE_FILL_DEPTH>0) ? 1 : 0;
    localparam integer FS=(TEXTURE_FILL_DEPTH>0) ? TEXTURE_FILL_DEPTH : 1;   // fill slots
    localparam integer OQ=FS+1;                                              // order queue: fills plus one main read
    localparam integer MQ=4;                                                 // miss set slots
    localparam integer RAM_WORDS=TEXTURE_CACHE_LINES*TEXTURE_CACHE_BEATS;
    localparam integer RAM_AW=(RAM_WORDS<2) ? 1 : $clog2(RAM_WORDS);
    reg fs_busy[0:FS-1];reg fs_poison[0:FS-1];
    reg [TEXTURE_LINE_IDX_W-1:0] fs_line[0:FS-1];
    reg [28:0] fs_tag[0:FS-1];
    reg oq_kind[0:OQ-1];             // 0 main transaction, 1 fill
    reg [3:0] oq_slot[0:OQ-1];
    reg [3:0] oq_beats[0:OQ-1];
    reg [3:0] oq_head,oq_tail,oq_count,oq_beat;
    // Miss set: an admitted miss waits for the fill slot in mq_wait (4'hf = none) and
    // becomes ready when that slot, or a fill of its own line and tag, lands; ready
    // entries leave in any order through the lookup pipeline as deferred replies.
    reg mq_valid[0:MQ-1];reg mq_ready[0:MQ-1];
    reg [21:0] mq_addr[0:MQ-1];
    reg [2:0] mq_off2[0:MQ-1];
    reg [3:0] mq_tag[0:MQ-1];
    reg [3:0] mq_wait[0:MQ-1];
    reg [2:0] mq_count;
    // Fill-unit statistics (wrapping, read by the native observer): misses admitted,
    // misses admitted behind a fill of their own line, prefetch offers / offers found
    // present / prefetch fills issued, next-line fills issued.
    reg [15:0] st_miss,st_miss_inflight,st_pf_offer,st_pf_valid,st_pf_fill,st_nl_fill;
    // Next-line prefetch on a line change (fill mode): the previous request's line
    // offset and the predicted line (22-bit texture offset, line aligned).
    reg [21:0] nl_last_offset,nl_offset;reg nl_last_valid,nl_pending;
    // Texture line store (fill mode): block RAM. The data has one fill write port and
    // one synchronous read port shared by the request lookup and the deferred miss
    // replies; the tags are kept twice so the prefetch check has its own read port.
    // Valid bits are flops. The legacy texture_cache_data and texture_cache_tag
    // arrays are not written in this mode.
    // No read ever depends on a same-address read-during-write (stale guards below), so
    // the M10K needs no bypass logic; the attribute makes a failed inference loud.
    (* ramstyle = "M10K, no_rw_check" *) reg [63:0] tex_data_ram[0:RAM_WORDS-1];
    (* ramstyle = "M10K, no_rw_check" *) reg [28:0] tex_tag_ram[0:TEXTURE_CACHE_LINES-1];
    (* ramstyle = "M10K, no_rw_check" *) reg [28:0] tex_tag_ram_b[0:TEXTURE_CACHE_LINES-1];
    reg [63:0] tex_data_q;reg [28:0] tex_tag_q,tex_tag_qb;
    // Lookup pipeline: one item (a request, or a ready miss as a deferred reply) sits in
    // stage 1 while its line data and tag come out of the RAM; s1_stale marks a read that
    // collided with the landing of a fill on that line (re-read before deciding).
    reg s1_valid,s1_deferred,s1_stale;reg [21:0] s1_addr;reg [2:0] s1_off2;reg [3:0] s1_tag;reg [1:0] s1_mq;
    // Prefetch check: the latest engine offer and the next-line prediction are
    // candidates; one at a time has its tag read (chk_*) and, when neither present
    // nor in flight, waits for the port as pfr_* (src 1 = next line, 0 = offer).
    reg pfc_valid;reg [21:0] pfc_offset;
    reg chk_valid,chk_src,chk_stale;reg [21:0] chk_offset;
    reg pfr_valid,pfr_src;reg [21:0] pfr_offset;reg [31:0] pfr_addr;
    // Timing pass (14 September 2026, second fitter): requests enter a two-entry FIFO so
    // tex_req_ready is a flop; the fill candidate (fc_*) and the deferred-reply pick (dc_*)
    // are registered scans re-validated cheaply at use; the valid bit of the line being
    // read comes out of a register (s1_vbit, chk_vbit) beside the RAM outputs.
    reg rq_valid[0:1];reg [21:0] rq_addr[0:1];reg [2:0] rq_off2[0:1];reg [3:0] rq_tag[0:1];reg rq_head;reg [1:0] rq_count;
    reg fc_valid;reg [1:0] fc_mq;reg [TEXTURE_LINE_IDX_W-1:0] fc_line;reg [31:0] fc_addr;
    reg dc_valid;reg [1:0] dc_idx;
    reg s1_vbit,chk_vbit;
    reg cmd_tex_write;reg [TEXTURE_LINE_IDX_W-1:0] cmd_tex_line;
    wire oq_empty=(oq_count==4'd0);
    wire mq_full=(mq_count==3'(MQ));
    wire [3:0] oq_head_next=(oq_head==4'(OQ-1)) ? 4'd0 : oq_head+4'd1;
    wire [3:0] oq_tail_next=(oq_tail==4'(OQ-1)) ? 4'd0 : oq_tail+4'd1;
    function [TEXTURE_LINE_IDX_W-1:0] line_of(input [21:0] o);line_of=TEXTURE_CACHE_LINES==1 ? 0 : TEXTURE_LINE_IDX_W'(o >> TEXTURE_LINE_BITS);endfunction
    function [TEXTURE_INDEX_W-1:0] word_of(input [21:0] o);word_of=TEXTURE_CACHE_BEATS==1 ? 0 : TEXTURE_INDEX_W'(o >> 3);endfunction
    function [31:0] laddr_of(input [21:0] o);laddr_of=texture_base+{10'b0,(o >> TEXTURE_LINE_BITS) << TEXTURE_LINE_BITS};endfunction
    function [28:0] ltag_of(input [21:0] o);ltag_of=laddr_of(o) >> 3;endfunction
    wire [TEXTURE_LINE_IDX_W-1:0] s1_line=line_of(s1_addr);
    wire [28:0] s1_ltag=ltag_of(s1_addr);
    // Fill candidate: a queued miss that is not ready and waits for no slot, whose line
    // index is neither being filled nor held by a ready entry or a deferred reply in
    // flight (their data must reach the engine before the line is replaced).
    reg fill_need;reg [1:0] fill_mq;reg [3:0] fill_free;reg fill_slot_free;
    reg [TEXTURE_LINE_IDX_W-1:0] cand_line;reg cand_block;
    integer fi,fj;
    always @* begin
        fill_need=0;fill_mq=0;fill_free=0;fill_slot_free=0;cand_line=0;cand_block=0;
        for(fi=FS-1;fi>=0;fi=fi-1) if(!fs_busy[fi]) begin fill_free=fi[3:0];fill_slot_free=1;end
        for(fi=MQ-1;fi>=0;fi=fi-1) if(mq_valid[fi] && !mq_ready[fi] && mq_wait[fi]==4'hf) begin
            cand_line=line_of(mq_addr[fi]);cand_block=s1_valid && s1_deferred && s1_line==cand_line;
            for(fj=0;fj<FS;fj=fj+1) if(fs_busy[fj] && fs_line[fj]==cand_line) cand_block=1;
            for(fj=0;fj<MQ;fj=fj+1) if(mq_valid[fj] && mq_ready[fj] && line_of(mq_addr[fj])==cand_line) cand_block=1;
            if(!cand_block) begin fill_need=1;fill_mq=fi[1:0];end
        end
    end
    wire [TEXTURE_LINE_IDX_W-1:0] fill_line=line_of(mq_addr[fill_mq]);
    wire [31:0] fill_addr=laddr_of(mq_addr[fill_mq]);
    // Fast-hit reply register (TEXTURE_FAST_HIT): one registered texel, drained
    // by the renderer's tex_rsp_ready, never occupying the credit.
    reg fast_rsp_valid;
    reg [7:0] fast_rsp_data;
    reg [7:0] fast_rsp_data2;
    reg [3:0] fast_rsp_tag;
    reg fill_only;   // the owned texture burst is a prefetch: no reply, fast hits stay open
    // Framebuffer write-combining word (FRAME_WRITE_COALESCE).
    reg wc_valid;
    reg [28:0] wc_tag;
    reg [63:0] wc_data;
    reg [7:0] wc_be;
    wire [31:0] texture_byte_address=texture_base+{10'b0,tex_req_addr};
    // Align relative to the texture allocation, which is only required to be
    // eight-byte aligned. Absolute 32/64-byte rounding could read before it.
    wire [21:0] texture_line_offset=(tex_req_addr >> TEXTURE_LINE_BITS) << TEXTURE_LINE_BITS;
    wire [31:0] texture_line_address=texture_base+{10'b0,texture_line_offset};
    wire [TEXTURE_INDEX_W-1:0] texture_word_index=TEXTURE_CACHE_BEATS==1 ? 0 : TEXTURE_INDEX_W'(tex_req_addr >> 3);
    wire [TEXTURE_LINE_IDX_W-1:0] texture_line_index=TEXTURE_CACHE_LINES==1 ? 0 :
        TEXTURE_LINE_IDX_W'(tex_req_addr >> TEXTURE_LINE_BITS);
    wire texture_cache_hit=TEXTURE_CACHE && texture_cache_valid[texture_line_index] &&
                           texture_cache_tag[texture_line_index]==texture_line_address[31:3];
    wire [63:0] texture_cache_word=texture_cache_data[texture_line_index][texture_word_index];
    // Prefetch check (fill mode): an engine offer is registered (the latest wins) and
    // the next-line prediction is queued; one candidate at a time has its line tag
    // read on the second tag port, and a fill-only burst is issued unless the line is
    // valid with that tag or being filled. A queued demand miss always goes first.
    wire pf_offer=(FILL!=0) && tex_req_valid && tex_req_prefetch && guest_tex_offer;
    wire chk_start=(FILL!=0) && !chk_valid && !pfr_valid && (nl_pending || pfc_valid);
    wire chk_start_src=nl_pending;
    wire [21:0] chk_start_off=nl_pending ? nl_offset : pfc_offset;
    wire [TEXTURE_LINE_IDX_W-1:0] chk_rd_line=line_of(chk_start ? chk_start_off : chk_offset);
    wire [TEXTURE_LINE_IDX_W-1:0] chk_line=line_of(chk_offset);
    reg chk_inflight;integer ck;
    always @* begin chk_inflight=0;for(ck=0;ck<FS;ck=ck+1) if(fs_busy[ck] && fs_line[ck]==chk_line) chk_inflight=1;end
    wire chk_present=chk_vbit && (tex_tag_qb==ltag_of(chk_offset));
    wire chk_decide=chk_valid && !chk_stale;
    wire chk_drop=chk_decide && (chk_present || chk_inflight);
    wire chk_pass=chk_decide && !chk_present && !chk_inflight;
    wire [TEXTURE_LINE_IDX_W-1:0] pfr_line=line_of(pfr_offset);
    reg pfr_inflight,pfr_block;integer pk;
    always @* begin
        pfr_inflight=0;for(pk=0;pk<FS;pk=pk+1) if(fs_busy[pk] && fs_line[pk]==pfr_line) pfr_inflight=1;
        pfr_block=pfr_inflight || (s1_valid && s1_deferred && s1_line==pfr_line);
        for(pk=0;pk<MQ;pk=pk+1) if(mq_valid[pk] && mq_ready[pk] && line_of(mq_addr[pk])==pfr_line) pfr_block=1;
    end
    wire pfr_need=pfr_valid && !pfr_block;
    wire pfr_drop=pfr_valid && pfr_inflight;
    // The registered fill candidate is re-validated at use: still a waiting miss, its line
    // neither in flight nor held by a ready entry or a deferred reply.
    reg fc_inflight,fc_block;integer fk;
    always @* begin
        fc_inflight=0;for(fk=0;fk<FS;fk=fk+1) if(fs_busy[fk] && fs_line[fk]==fc_line) fc_inflight=1;
        fc_block=fc_inflight || (s1_valid && s1_deferred && s1_line==fc_line);
        for(fk=0;fk<MQ;fk=fk+1) if(mq_valid[fk] && mq_ready[fk] && line_of(mq_addr[fk])==fc_line) fc_block=1;
    end
    wire fill_ok=fc_valid && mq_valid[fc_mq] && !mq_ready[fc_mq] && mq_wait[fc_mq]==4'hf && !fc_block;
    wire fill_any=fill_ok || pfr_need;
    // A texture request accepted this clock (hit or miss, not an offer) whose line differs
    // from the previous one predicts the line beyond it in the direction of the change.
    wire lk_accept;
    // Request FIFO push (fill mode): the next-line prediction follows the push order.
    wire rq_full=(rq_count==2'd2);
    wire rq_push=(FILL!=0) && tex_req_valid && !tex_req_prefetch && guest_tex_offer && !rq_full;
    wire tex_taken=(FILL!=0) ? rq_push : (tex_req_valid && tex_req_ready && guest_tex_offer && !tex_req_prefetch);
    wire [21:0] nl_step=22'(TEXTURE_CACHE_BEATS*8);
    wire nl_change=(TEXTURE_NEXT_LINE!=0) && tex_taken && nl_last_valid && texture_line_offset!=nl_last_offset;
    wire nl_forward=texture_line_offset>nl_last_offset;
    wire [TEXTURE_LINE_IDX_W-1:0] fill_line_sel=fill_ok ? fc_line : pfr_line;
    wire [31:0] fill_addr_sel=fill_ok ? fc_addr : pfr_addr;
    // Framebuffer pixel word for the write coalescer.
    wire [31:0] fb_byte_address=fb_base+{12'b0,fb_addr,1'b0};
    wire wc_merge=FRAME_WRITE_COALESCE && wc_valid && wc_tag==fb_byte_address[31:3];
    reg [4:0] wc_age;
    wire [63:0] texture_cache_shifted=texture_cache_word >> (texture_byte_address[2:0]*8);
    wire [31:0] scan_fb_byte_address=fb_base+{12'b0,fb_read_req_addr,1'b0};
    wire fb_cache_hit=FRAMEBUFFER_CACHE && fb_cache_valid &&
                      fb_cache_tag==scan_fb_byte_address[31:3];
    wire [63:0] fb_cache_shifted=fb_cache_data >> (scan_fb_byte_address[2:0]*8);
    wire [32:0] fb_end={1'b0,config_fb_base}+33'h100000;
    wire [32:0] texture_end={1'b0,config_texture_base}+33'h400000;
    wire [32:0] palette_end={1'b0,config_palette_base}+33'h20000;
    wire valid_config=(config_fb_base[2:0]==0) && (config_texture_base[2:0]==0) &&
        (config_palette_base[2:0]==0) && fb_end<=33'h100000000 &&
        texture_end<=33'h100000000 && palette_end<=33'h100000000 &&
        (fb_end<={1'b0,config_texture_base} || texture_end<={1'b0,config_fb_base}) &&
        (fb_end<={1'b0,config_palette_base} || palette_end<={1'b0,config_fb_base}) &&
        (texture_end<={1'b0,config_palette_base} || palette_end<={1'b0,config_texture_base});
    wire healthy=configured && fault_code==0 && !reset;
    // Owned physical commands cannot be revoked by live request/response
    // checks. Keep them offered through poison until actual acceptance.
    wire command_owned=configured && !reset && state==COMMAND;
    wire offered_read=command_owned && !command_write;
    wire read_response_expected=(FILL!=0) ? (!oq_empty || (offered_read && !avm_waitrequest)) :
                                (state==READ_WAIT || (offered_read && !avm_waitrequest));
    wire unexpected_response=avm_readdatavalid && !read_response_expected;
    // A new request is validated when the credit can admit it. Its consumer
    // may derive request-valid from an earlier reply; feeding that request
    // back into the old reply's validity creates a physical combinational loop.
    wire request_protocol_error=state==IDLE &&
        (((fb_read_req_valid || pal_read_req_valid) && !scanout_lock) ||
         (fb_valid && !guest_fb_offer) || (tex_req_valid && !guest_tex_offer));
    wire protocol_error=unexpected_response || (avm_readdatavalid && avm_read_error) || request_protocol_error;
    wire publication_safe=healthy && !protocol_error;
    // Fill commands take the port whenever the main FSM is not commanding; both
    // are pushed to the order queue at acceptance, so responses route by it.
    // AVALON COMMAND STABILITY (16 September 2026): the offered fill command is
    // REGISTERED in fo_* and held byte-identical until the port accepts it.
    // avalon_shared_mux latches a selected command into held_* and raises a STICKY
    // fault_code if any offered signal changes before physical acceptance (the
    // Avalon-MM waitrequest rule); one violation kills every later DDR transaction,
    // textures and DCS alike, for good. The live candidate moves every clock --
    // fill_ok can swap fc_addr for pfr_addr, fill_any can drop, fill_free can
    // change -- and the main FSM used to capture into COMMAND underneath an
    // unaccepted fill offer, switching avm_address and avm_burstcount in the same
    // breath. Reproduced by tests/memory/tb_vunit_arbiter_avalon_stability.sv.
    reg fo_valid,fo_from_fc;
    reg [31:0] fo_addr;
    reg [TEXTURE_LINE_IDX_W-1:0] fo_line;
    reg [3:0] fo_slot;
    reg [1:0] fo_mq;
    // main_wants is the disjunction of the IDLE capture chain's conditions (assigned
    // below, beside the readys it is built from). The main FSM keeps the priority it
    // always had: a fill offer is only loaded into a clock the main FSM does not want,
    // so the two can never both take the port and fills cannot starve scanout or the
    // CPU. Once loaded, the offer is immutable until acceptance.
    wire main_wants;
    wire fill_offer_load=(FILL!=0) && !fo_valid && fill_any && fill_slot_free &&
        state!=COMMAND && publication_safe && !main_wants;
    wire fill_cmd_valid=(FILL!=0) && fo_valid;
    wire fill_accepted=fill_cmd_valid && !avm_waitrequest;
    // An outstanding offer owns the port: the main FSM must not capture underneath
    // it, so the one credit (and every ready derived from it) waits for acceptance.
    wire port_free=!fo_valid;
    wire main_accepted=command_owned && !avm_waitrequest;
    wire resp_main=avm_readdatavalid && !oq_empty && !oq_kind[oq_head];
    wire resp_fill=avm_readdatavalid && !oq_empty && oq_kind[oq_head];
    wire [3:0] resp_slot=oq_slot[oq_head];
    wire resp_last=(oq_beat+4'd1==oq_beats[oq_head]);
    wire land_ok=resp_fill && resp_last && publication_safe && !fs_poison[resp_slot];
    // Lookup pipeline (fill mode). Stage 1 holds its item until it completes: a request
    // hits (its line valid with its tag; the reply register free) or misses (a set slot
    // free); a deferred reply loads the reply register when the line is still valid
    // with its tag, otherwise the entry is refetched. Nothing is decided on a read
    // that collided with a fill landing on the line.
    wire s1_present=!s1_stale && s1_vbit && (tex_tag_q==s1_ltag);
    wire rsp_free=!fast_rsp_valid || tex_rsp_ready;
    reg s1_attach;reg [3:0] s1_attach_slot;integer sk;
    always @* begin
        s1_attach=0;s1_attach_slot=4'hf;
        for(sk=0;sk<FS;sk=sk+1) if(fs_busy[sk] && fs_line[sk]==s1_line && fs_tag[sk]==s1_ltag && !(resp_fill && resp_last && resp_slot==sk[3:0])) begin s1_attach=1;s1_attach_slot=sk[3:0];end
    end
    wire s1_land_hit=land_ok && fs_line[resp_slot]==s1_line && fs_tag[resp_slot]==s1_ltag;
    wire s1_hit=s1_valid && !s1_deferred && s1_present;
    wire s1_miss=s1_valid && !s1_deferred && !s1_stale && !s1_present;
    wire s1_dfr_ok=s1_valid && s1_deferred && s1_present;
    wire s1_dfr_stale=s1_valid && s1_deferred && !s1_stale && !s1_present;
    wire s1_reply=(s1_hit || s1_dfr_ok) && rsp_free;
    wire s1_admit=s1_miss && !mq_full;
    wire s1_done=s1_reply || s1_admit || s1_dfr_stale;
    wire can_take=(FILL!=0) && (!s1_valid || s1_done);
    reg dfr_any;reg [1:0] dfr_idx;reg [1:0] mq_free;integer dk;
    always @* begin
        dfr_any=0;dfr_idx=0;mq_free=0;
        for(dk=MQ-1;dk>=0;dk=dk-1) begin if(mq_valid[dk] && mq_ready[dk]) begin dfr_any=1;dfr_idx=dk[1:0];end if(!mq_valid[dk]) mq_free=dk[1:0];end
    end
    // The registered pick is re-validated at use; a ready entry whose line was invalidated
    // meanwhile is found stale in stage 1 and refetched there.
    wire dfr_ready=dc_valid && mq_valid[dc_idx] && mq_ready[dc_idx] && !(s1_valid && s1_deferred);
    wire dfr_want=dfr_ready;
    wire dfr_take=can_take && dfr_want;
    // A request enters stage 1 only when a set slot would be free for it as a miss, so
    // a held miss never blocks the deferred replies that free the set.
    wire mq_room=!mq_full && !(s1_admit && mq_count==3'(MQ-1));
    wire lk_ready=can_take && !dfr_want && mq_room;
    assign lk_accept=lk_ready && (rq_count!=2'd0);
    wire [21:0] rd_off=dfr_take ? mq_addr[dc_idx] : lk_accept ? rq_addr[rq_head] : s1_addr;
    wire [TEXTURE_LINE_IDX_W-1:0] rd_line=line_of(rd_off);
    wire [RAM_AW-1:0] rd_addr=RAM_AW'(rd_line*TEXTURE_CACHE_BEATS+word_of(rd_off));
    wire [RAM_AW-1:0] wr_addr=RAM_AW'(fs_line[resp_slot]*TEXTURE_CACHE_BEATS+oq_beat);
    // Store reads: registered address, no reset, no enable (the plain M10K read
    // template); the outputs are qualified by s1_valid / chk_valid, never by reset.
    // The valid bits of the two lines being read are registered beside the RAM outputs.
    always @(posedge clk) begin
        tex_data_q<=tex_data_ram[rd_addr];tex_tag_q<=tex_tag_ram[rd_line];tex_tag_qb<=tex_tag_ram_b[chk_rd_line];
        s1_vbit<=texture_cache_valid[rd_line];chk_vbit<=texture_cache_valid[chk_rd_line];
    end
    // Anything that changes a line's valid bit this clock: a fill landing, a fill issue, a
    // CPU texture write. A read of that line this clock is repeated before it is decided.
    wire cpu_tex_inval=main_accepted && command_write && owner==CPU && cmd_tex_write;
    wire touch_rd=(resp_fill && resp_last && fs_line[resp_slot]==rd_line) || (fill_accepted && fill_line_sel==rd_line) || (cpu_tex_inval && cmd_tex_line==rd_line);
    wire touch_chk=(resp_fill && resp_last && fs_line[resp_slot]==chk_rd_line) || (fill_accepted && fill_line_sel==chk_rd_line) || (cpu_tex_inval && cmd_tex_line==chk_rd_line);
    // REPLY never has a pending backend read. A live backend response here is
    // a duplicate and suppresses publication on its edge. No new client signal
    // can invalidate a response that this arbiter already owns.
    wire reply_safe=healthy && !avm_readdatavalid;
    wire idle=publication_safe && state==IDLE && port_free;
    assign halted=fault_code!=0 || (healthy && protocol_error);
    assign config_ready=!reset && !configured && fault_code==0 && backend_quiesced &&
                        state==IDLE && !avm_readdatavalid && (FILL==0 || oq_empty);
    assign backend_reset_request=reset || !configured;
    assign available_credit=idle;
    // Replies themselves do not hold this global pause: a guest-stepped texture
    // consumer must be able to take a ready reply. Its own wait covers absence.
    assign physical_wait=configured && !reset && (state==COMMAND || state==READ_WAIT);
    assign cpu_mem_req_ready=idle && !scanout_lock && !wc_alias_cpu;
    // Coalescing: a merge into the buffered word, or a fresh word, needs no
    // credit; a word change flushes the buffered word as the transaction and
    // loads the new pixel in the same clock, so it needs the idle credit.
    wire wc_accept_free=FRAME_WRITE_COALESCE && guest_fb_offer && (wc_merge || !wc_valid) && !(wc_alias_scan || wc_alias_cpu);
    assign fb_ready=FRAME_WRITE_COALESCE ?
        (wc_accept_free || (idle && !scanout_lock && !cpu_mem_req_valid && guest_fb_offer)) :
        (idle && !scanout_lock && !cpu_mem_req_valid && guest_fb_offer);
    // Fast hits take no credit: they need no texture miss in flight (replies
    // stay in order) and the reply register free or draining. In fast mode a
    // hit is only ever taken by the fast path and a miss only by the credit.
    // A prefetch burst owns the credit but produces no reply, so fast hits to
    // other lines keep flowing during it (the line being filled is invalid).
    wire texture_miss_in_flight=state!=IDLE && owner==TEXTURE_READ && !fill_only;
    // Hit-under-miss: a hit needs only the state-machine reply slot to be free
    // (its reply drains first when both are pending); the line being filled is
    // invalid during the burst, so a hit can never target it.
    wire fast_hit_ok=TEXTURE_FAST_HIT && texture_cache_hit &&
        ((FILL!=0) ? 1'b0 : TEXTURE_HIT_UNDER_MISS ? !(state==REPLY && owner==TEXTURE_READ) : !texture_miss_in_flight) &&
        (!fast_rsp_valid || tex_rsp_ready);
    wire fast_hit_accept=fast_hit_ok && tex_req_valid && guest_tex_offer && !tex_req_prefetch;
    wire prefetch_credit=TEXTURE_FAST_HIT && TEXTURE_CACHE && idle && !scanout_lock && !cpu_mem_req_valid && !guest_fb_offer;
    wire prefetch_capture=tex_req_valid && tex_req_prefetch && guest_tex_offer && !texture_cache_hit && prefetch_credit;
    assign tex_req_ready=tex_req_prefetch ? 1'b1 : (FILL!=0) ? !rq_full : TEXTURE_FAST_HIT ?
        (fast_hit_ok || (!texture_cache_hit && idle && !scanout_lock && !cpu_mem_req_valid && !guest_fb_offer)) :
        (idle && !scanout_lock && !cpu_mem_req_valid && !guest_fb_offer);
    assign pal_read_req_ready=idle && scanout_lock;
    assign fb_read_req_ready=idle && scanout_lock && !pal_read_req_valid && !wc_alias_scan;
    // Exactly the conditions of the state==IDLE capture chain below, in the same order.
    // Keep the two in step: a clock the chain captures in is a clock no fill may enter.
    // (The two cache-hit branches reply without the port; counting them only defers a
    // fill by one clock.) idle already carries publication_safe, state==IDLE and
    // port_free, so main_wants is false whenever an offer is outstanding.
    assign main_wants=idle &&
       ((FRAME_WRITE_COALESCE && wc_valid && (wc_alias_scan || wc_alias_cpu)) ||
        (pal_read_req_valid && pal_read_req_ready) ||
        (fb_read_req_valid && fb_read_req_ready) ||
        (cpu_mem_req_valid && cpu_mem_req_ready) ||
        (fb_valid && fb_ready && !FRAME_WRITE_COALESCE) ||
        (fb_valid && fb_ready && FRAME_WRITE_COALESCE && wc_valid && !wc_merge) ||
        (FILL==0 && prefetch_capture) ||
        (FILL==0 && tex_req_valid && tex_req_ready && !tex_req_prefetch &&
                    !(TEXTURE_FAST_HIT && texture_cache_hit)) ||
        (FRAME_WRITE_COALESCE && wc_valid && wc_age[4] && !fb_valid));
    assign cpu_mem_rsp_valid=reply_safe && state==REPLY && owner==CPU;
    wire tex_rsp_valid_sm=reply_safe && state==REPLY && owner==TEXTURE_READ;
    assign tex_rsp_valid=fast_rsp_valid || tex_rsp_valid_sm;
    assign fb_read_rsp_valid=reply_safe && state==REPLY && owner==SCAN_FB;
    assign pal_read_rsp_valid=reply_safe && state==REPLY && owner==SCAN_PALETTE;
    assign cpu_mem_rsp_rdata=reply_data;
    assign tex_rsp_data=fast_rsp_valid ? fast_rsp_data : reply_data[7:0];
    assign tex_rsp_data2=fast_rsp_valid ? fast_rsp_data2 : reply_data2;
    assign tex_rsp_tag=fast_rsp_valid ? fast_rsp_tag : reply_tag;
    assign fb_read_rsp_data=reply_data[15:0];
    assign pal_read_rsp_data=reply_data;
    assign avm_read=(command_owned && !command_write) || fill_cmd_valid;
    assign avm_write=command_owned && command_write;
    assign avm_address=command_owned ? command_address : fo_addr;
    assign avm_writedata=command_data;
    assign avm_byteenable=command_owned ? command_be : 8'hff;
    assign avm_burstcount=command_owned ? command_burst : 4'(TEXTURE_CACHE_BEATS);
    wire command_accepted=main_accepted;
    wire response_drained=(cpu_mem_rsp_valid && cpu_mem_rsp_ready) ||
        (tex_rsp_valid_sm && !fast_rsp_valid && tex_rsp_ready) || (fb_read_rsp_valid && fb_read_rsp_ready) ||
        (pal_read_rsp_valid && pal_read_rsp_ready);
    wire [63:0] shifted_read=avm_readdata >> (byte_lane*8);
    wire cpu_valid_region=(cpu_mem_req_region==0 && cpu_mem_req_addr[21:20]==0 &&
                          !cpu_mem_req_addr[0] && cpu_mem_req_be[3:2]==0) ||
                         (cpu_mem_req_region==1 && !cpu_mem_req_addr[0] && cpu_mem_req_be[3:2]==0) ||
                         (cpu_mem_req_region==2 && cpu_mem_req_addr[21:17]==0 && cpu_mem_req_addr[1:0]==0);
    wire [31:0] cpu_base=cpu_mem_req_region==0 ? fb_base : cpu_mem_req_region==1 ? texture_base : palette_base;
    wire [31:0] cpu_byte_address=cpu_base+{10'b0,cpu_mem_req_addr};
    // A buffered framebuffer word must reach DDR before any access that could
    // read or write the same word; the flush is ordered ahead of that access.
    wire wc_alias_scan=FRAME_WRITE_COALESCE && wc_valid && fb_read_req_valid && wc_tag==scan_fb_byte_address[31:3];
    wire wc_alias_cpu=FRAME_WRITE_COALESCE && wc_valid && cpu_mem_req_valid && wc_tag==cpu_byte_address[31:3];

    task fail(input [7:0] code,input [31:0] address);
        begin fault_code<=code;fault_address<=address;end
    endtask
    task capture(input [2:0] new_owner,input bit writing,input [31:0] byte_address,
                 input [31:0] data,input [3:0] enables,input [1:0] width);
        begin
            owner<=new_owner;command_write<=writing;read_width<=width;
            byte_lane<=byte_address[2:0];command_address<={byte_address[31:3],3'b0};
            command_data<={32'b0,data} << (byte_address[2:0]*8);
            command_be<={4'b0,enables} << byte_address[2:0];
            command_burst<=1;read_remaining<=1;texture_fill_index<=0;texture_sample_index<=0;
            state<=COMMAND;
        end
    endtask
    // A whole 64-bit word write with explicit byte enables (coalesced pixels).
    task capture_word(input [2:0] new_owner,input [31:0] byte_address,input [63:0] data,input [7:0] enables);
        begin
            owner<=new_owner;command_write<=1;read_width<=1;
            byte_lane<=0;command_address<={byte_address[31:3],3'b0};
            command_data<=data;command_be<=enables;
            command_burst<=1;read_remaining<=1;texture_fill_index<=0;texture_sample_index<=0;
            state<=COMMAND;
        end
    endtask
    always @(posedge clk) begin
        if(reset) begin
            configured<=0;fault_code<=0;fault_address<=0;state<=IDLE;
            fb_base<=0;texture_base<=0;palette_base<=0;
            owner<=0;byte_lane<=0;read_width<=0;command_write<=0;
            command_address<=0;command_data<=0;command_be<=0;reply_data<=0;
            command_burst<=1;read_remaining<=0;texture_fill_index<=0;texture_sample_index<=0;
            fb_cache_valid<=0;fb_cache_tag<=0;fb_cache_data<=0;
            for(integer line=0;line<TEXTURE_CACHE_LINES;line=line+1) begin texture_cache_valid[line]<=0;texture_cache_tag[line]<=0;end
            texture_fill_line<=0;fast_rsp_valid<=0;fast_rsp_data<=0;fill_only<=0;
            fast_rsp_data2<=0;reply_data2<=0;reply_off2<=0;fast_rsp_tag<=0;reply_tag<=0;
            for(fi=0;fi<FS;fi=fi+1) begin fs_busy[fi]<=0;fs_poison[fi]<=0;fs_line[fi]<=0;fs_tag[fi]<=0;end
            for(fi=0;fi<OQ;fi=fi+1) begin oq_kind[fi]<=0;oq_slot[fi]<=0;oq_beats[fi]<=0;end
            for(fi=0;fi<MQ;fi=fi+1) begin mq_valid[fi]<=0;mq_ready[fi]<=0;mq_wait[fi]<=4'hf;mq_addr[fi]<=0;mq_off2[fi]<=0;mq_tag[fi]<=0;end
            s1_valid<=0;s1_deferred<=0;s1_stale<=0;s1_addr<=0;s1_off2<=0;s1_tag<=0;s1_mq<=0;
            pfc_valid<=0;pfc_offset<=0;chk_valid<=0;chk_src<=0;chk_stale<=0;chk_offset<=0;pfr_valid<=0;pfr_src<=0;pfr_offset<=0;pfr_addr<=0;
            for(fi=0;fi<2;fi=fi+1) begin rq_valid[fi]<=0;rq_addr[fi]<=0;rq_off2[fi]<=0;rq_tag[fi]<=0;end
            rq_head<=0;rq_count<=0;fc_valid<=0;fc_mq<=0;fc_line<=0;fc_addr<=0;dc_valid<=0;dc_idx<=0;cmd_tex_write<=0;cmd_tex_line<=0;
            fo_valid<=0;fo_from_fc<=0;fo_addr<=0;fo_line<=0;fo_slot<=0;fo_mq<=0;
            oq_head<=0;oq_tail<=0;oq_count<=0;oq_beat<=0;mq_count<=0;
            st_miss<=0;st_miss_inflight<=0;st_pf_offer<=0;st_pf_valid<=0;st_pf_fill<=0;st_nl_fill<=0;
            nl_last_offset<=0;nl_offset<=0;nl_last_valid<=0;nl_pending<=0;
            wc_valid<=0;wc_tag<=0;wc_data<=0;wc_be<=0;wc_age<=0;
        end else if(config_valid && config_ready) begin
            fb_cache_valid<=0;for(integer line=0;line<TEXTURE_CACHE_LINES;line=line+1) texture_cache_valid[line]<=0;
            wc_valid<=0;fast_rsp_valid<=0;
            if(!valid_config) fail(BAD_CONFIG,config_fb_base);
            else begin configured<=1;fb_base<=config_fb_base;texture_base<=config_texture_base;palette_base<=config_palette_base;end
        end else if(configured) begin
            // Fast texture hit reply: loaded on acceptance, cleared when drained.
            if(TEXTURE_FAST_HIT) begin
                if((FILL!=0) && s1_reply) begin
                    fast_rsp_valid<=1;fast_rsp_data<=tex_data_q[s1_addr[2:0]*8 +: 8];fast_rsp_data2<=tex_data_q[s1_off2*8 +: 8];fast_rsp_tag<=s1_tag;
                end else if((FILL==0) && fast_hit_accept) begin fast_rsp_valid<=1;fast_rsp_data<=texture_cache_shifted[7:0];fast_rsp_data2<=texture_cache_word[tex_req_off2*8 +: 8];fast_rsp_tag<=tex_req_tag;end
                else if(fast_rsp_valid && tex_rsp_ready) fast_rsp_valid<=0;
            end
            if(FILL!=0) begin
                // Statistics.
                if(s1_admit) begin st_miss<=st_miss+16'd1;if(s1_attach) st_miss_inflight<=st_miss_inflight+16'd1;end
                if(pf_offer) st_pf_offer<=st_pf_offer+16'd1;
                if(chk_drop && !chk_src && chk_present) st_pf_valid<=st_pf_valid+16'd1;
                if(fill_offer_load && !fill_ok) begin if(pfr_src) st_nl_fill<=st_nl_fill+16'd1;else st_pf_fill<=st_pf_fill+16'd1;end
                // The offer register: latch the validated candidate, hold it until the
                // port accepts it. Every load is accepted eventually (nothing withdraws
                // it), so the candidate is consumed here and the slot bookkeeping still
                // happens at acceptance, exactly as before.
                if(fill_offer_load) begin
                    fo_valid<=1;fo_addr<=fill_addr_sel;fo_line<=fill_line_sel;
                    fo_slot<=fill_free;fo_from_fc<=fill_ok;fo_mq<=fc_mq;
                end else if(fill_accepted) fo_valid<=0;
                // Request FIFO: push at the tail, pop at the head when stage 1 takes it.
                if(rq_push) begin rq_valid[rq_head^rq_count[0]]<=1;rq_addr[rq_head^rq_count[0]]<=tex_req_addr;rq_off2[rq_head^rq_count[0]]<=tex_req_off2;rq_tag[rq_head^rq_count[0]]<=tex_req_tag;end
                if(lk_accept) begin rq_valid[rq_head]<=0;rq_head<=~rq_head;end
                rq_count<=rq_count+(rq_push ? 2'd1 : 2'd0)-(lk_accept ? 2'd1 : 2'd0);
                // Registered scans for the next clock's fill issue and deferred pick.
                fc_valid<=fill_need;fc_mq<=fill_mq;fc_line<=fill_line;fc_addr<=fill_addr;
                dc_valid<=dfr_any;dc_idx<=dfr_idx;
                // Candidates: the next-line prediction and the latest engine offer, each
                // consumed when its check starts.
                if(tex_taken) begin nl_last_offset<=texture_line_offset;nl_last_valid<=1;end
                if(nl_change && (nl_forward ? (texture_line_offset+nl_step>texture_line_offset) : (texture_line_offset>=nl_step))) begin
                    nl_offset<=nl_forward ? texture_line_offset+nl_step : texture_line_offset-nl_step;nl_pending<=1;
                end else if(chk_start && chk_start_src) nl_pending<=0;
                if(pf_offer) begin pfc_valid<=1;pfc_offset<=tex_req_addr;end
                else if(chk_start && !chk_start_src) pfc_valid<=0;
                // Check stage: second tag port, decided one clock after a clean read.
                chk_stale<=touch_chk;
                if(chk_start) begin chk_valid<=1;chk_src<=chk_start_src;chk_offset<=chk_start_off;end
                else if(chk_decide) chk_valid<=0;
                if(chk_pass) begin pfr_valid<=1;pfr_src<=chk_src;pfr_offset<=chk_offset;pfr_addr<=laddr_of(chk_offset);end
                else if((fill_offer_load && !fill_ok) || pfr_drop) pfr_valid<=0;
                // Lookup pipeline: the item entering (or held in) stage 1 has its word and
                // tag read in the store's read process above.
                s1_stale<=touch_rd;
                if(dfr_take || lk_accept) begin
                    s1_valid<=1;s1_deferred<=dfr_take;s1_addr<=rd_off;s1_mq<=dc_idx;
                    s1_off2<=dfr_take ? mq_off2[dc_idx] : rq_off2[rq_head];s1_tag<=dfr_take ? mq_tag[dc_idx] : rq_tag[rq_head];
                end else if(s1_done) s1_valid<=0;
                // Miss set: admission (ready at once when its own fill lands this clock),
                // deferred pop, refetch marks for entries whose line was invalidated.
                if(s1_admit) begin
                    mq_valid[mq_free]<=1;mq_ready[mq_free]<=s1_land_hit;mq_wait[mq_free]<=(s1_attach && !s1_land_hit) ? s1_attach_slot : 4'hf;
                    mq_addr[mq_free]<=s1_addr;mq_off2[mq_free]<=s1_off2;mq_tag[mq_free]<=s1_tag;
                end
                if(s1_reply && s1_deferred) begin mq_valid[s1_mq]<=0;mq_ready[s1_mq]<=0;end
                if(s1_dfr_stale) begin mq_ready[s1_mq]<=0;mq_wait[s1_mq]<=4'hf;end
                mq_count<=mq_count+(s1_admit ? 3'd1 : 3'd0)-((s1_reply && s1_deferred) ? 3'd1 : 3'd0);
                // Fill issue: a slot, the line index invalidated, the waiting entry attached, an order-queue entry.
                if(fill_accepted) begin
                    fs_busy[fo_slot]<=1;fs_line[fo_slot]<=fo_line;fs_tag[fo_slot]<=fo_addr[31:3];fs_poison[fo_slot]<=0;
                    texture_cache_valid[fo_line]<=0;
                    if(fo_from_fc) mq_wait[fo_mq]<=fo_slot;
                    oq_kind[oq_tail]<=1;oq_slot[oq_tail]<=fo_slot;oq_beats[oq_tail]<=4'(TEXTURE_CACHE_BEATS);oq_tail<=oq_tail_next;
                end else if(main_accepted && !command_write) begin
                    oq_kind[oq_tail]<=0;oq_slot[oq_tail]<=0;oq_beats[oq_tail]<=command_burst;oq_tail<=oq_tail_next;
                end
                // Fill beats land in the slot's line; the last beat validates it unless poisoned
                // and wakes the entries waiting for the slot or for that line and tag.
                if(resp_fill) begin
                    tex_data_ram[wr_addr]<=avm_readdata;
                    if(resp_last) begin
                        if(land_ok) begin
                            texture_cache_valid[fs_line[resp_slot]]<=1;
                            tex_tag_ram[fs_line[resp_slot]]<=fs_tag[resp_slot];tex_tag_ram_b[fs_line[resp_slot]]<=fs_tag[resp_slot];
                            for(fi=0;fi<MQ;fi=fi+1)
                                if(mq_valid[fi] && !mq_ready[fi] && (mq_wait[fi]==resp_slot ||
                                   (mq_wait[fi]==4'hf && line_of(mq_addr[fi])==fs_line[resp_slot] && ltag_of(mq_addr[fi])==fs_tag[resp_slot])))
                                    begin mq_ready[fi]<=1;mq_wait[fi]<=4'hf;end
                        end else for(fi=0;fi<MQ;fi=fi+1) if(mq_valid[fi] && mq_wait[fi]==resp_slot) mq_wait[fi]<=4'hf;
                        fs_busy[resp_slot]<=0;
                    end
                end
                if(avm_readdatavalid && !oq_empty) begin
                    if(resp_last) begin oq_head<=oq_head_next;oq_beat<=0;end else oq_beat<=oq_beat+4'd1;
                end
                oq_count<=oq_count+((fill_accepted || (main_accepted && !command_write)) ? 4'd1 : 4'd0)-((avm_readdatavalid && !oq_empty && resp_last) ? 4'd1 : 4'd0);
                // An accepted CPU write poisons any fill in flight that overlaps it and
                // invalidates the line index it maps to (refetched on the next touch).
                if(main_accepted && command_write && owner==CPU) begin
                    for(fi=0;fi<FS;fi=fi+1) if(fs_busy[fi] && command_address[31:3]>=fs_tag[fi] && command_address[31:3]<fs_tag[fi]+29'(TEXTURE_CACHE_BEATS)) fs_poison[fi]<=1;
                    if(cmd_tex_write) texture_cache_valid[cmd_tex_line]<=0;
                end
            end
            // Write coalescer: every accepted pixel merges into the buffered word
            // or (re)loads it; the credit-taking flushes in the IDLE chain below
            // never coincide with an acceptance (fb_ready excludes them).
            if(FRAME_WRITE_COALESCE) begin
                if(fb_valid && fb_ready) begin
                    if(wc_merge) begin
                        wc_age<=0;
                        if(fb_pair) begin wc_data[fb_byte_address[2]*32 +: 32]<={fb_data_hi,fb_data};wc_be[fb_byte_address[2]*4 +: 4]<=4'hf;end
                        else begin wc_data[fb_byte_address[2:0]*8 +: 16]<=fb_data;wc_be[fb_byte_address[2:0] +: 2]<=2'b11;end
                    end else begin
                        wc_valid<=1;wc_tag<=fb_byte_address[31:3];wc_age<=0;
                        wc_data<=(fb_pair ? {32'b0,fb_data_hi,fb_data} : {48'b0,fb_data}) << (fb_byte_address[2:0]*8);
                        wc_be<=(fb_pair ? 8'h0f : 8'h03) << fb_byte_address[2:0];
                    end
                end else if(wc_valid && !wc_age[4]) wc_age<=wc_age+5'd1;
            end
            if(healthy) begin
            if(unexpected_response)
                fail(UNEXPECTED_READ_RESPONSE,command_address);
            else if(avm_readdatavalid && avm_read_error) fail(READ_ERROR,command_address);
            else if(state==IDLE && (fb_read_req_valid || pal_read_req_valid) && !scanout_lock)
                fail(BAD_SCANOUT_LOCK,command_address);
            else if(state==IDLE && ((fb_valid && !guest_fb_offer) || (tex_req_valid && !guest_tex_offer)))
                fail(BAD_GUEST_OFFER,command_address);
            end
            if(state==IDLE && publication_safe) begin
                // A registered fill offer owns the port until acceptance. The credit
                // (idle) already holds every request ready low, but the two coalescer
                // flushes below are reached without it, so guard the whole chain.
                if(!port_free) begin end
                else if(FRAME_WRITE_COALESCE && wc_valid && (wc_alias_scan || wc_alias_cpu)) begin
                    // Ordered flush ahead of an aliasing scanout or CPU access.
                    capture_word(FRAME_WRITE,{wc_tag,3'b0},wc_data,wc_be);wc_valid<=0;
                end
                else if(pal_read_req_valid && pal_read_req_ready)
                    capture(SCAN_PALETTE,0,palette_base+{15'b0,pal_read_req_addr,2'b0},0,15,2);
                else if(fb_read_req_valid && fb_read_req_ready) begin
                    if(fb_cache_hit) begin
                        // Preserve the same one-credit reply/backpressure and
                        // scanout lock; a hit only removes the physical read.
                        owner<=SCAN_FB;reply_data<={16'b0,fb_cache_shifted[15:0]};state<=REPLY;
                        command_address<={scan_fb_byte_address[31:3],3'b0};
                    end else begin
                        capture(SCAN_FB,0,scan_fb_byte_address,0,3,1);
                        // Every cached byte must have been requested. Avalon
                        // does not guarantee disabled read lanes are meaningful.
                        if(FRAMEBUFFER_CACHE) command_be<=8'hff;
                    end
                end
                else if(cpu_mem_req_valid && cpu_mem_req_ready) begin
                    if(!cpu_valid_region) fail(BAD_CPU_REQUEST,cpu_byte_address);
                    else begin
                        cmd_tex_write<=cpu_mem_req_write && (cpu_mem_req_region==2'd1);cmd_tex_line<=line_of(cpu_mem_req_addr[21:0]);
                        capture(CPU,cpu_mem_req_write,cpu_byte_address,cpu_mem_req_wdata,cpu_mem_req_be,
                                cpu_mem_req_region==2 ? 2 : 1);
                    end
                end else if(fb_valid && fb_ready && !FRAME_WRITE_COALESCE)
                    capture(FRAME_WRITE,1,fb_base+{12'b0,fb_addr,1'b0},fb_pair ? {fb_data_hi,fb_data} : {16'b0,fb_data},fb_pair ? 4'hf : 4'h3,1);
                else if(fb_valid && fb_ready && FRAME_WRITE_COALESCE && wc_valid && !wc_merge)
                    // Word change: the buffered word becomes the transaction; the
                    // new pixel is loaded below in the same clock.
                    capture_word(FRAME_WRITE,{wc_tag,3'b0},wc_data,wc_be);
                else if(FILL==0 && prefetch_capture) begin
                    // Fill-only burst for the requested line; nothing is replied.
                    capture(TEXTURE_READ,0,texture_byte_address,0,1,0);
                    command_be<=8'hff;command_address<=texture_line_address;
                    command_burst<=4'(TEXTURE_CACHE_BEATS);read_remaining<=4'(TEXTURE_CACHE_BEATS);
                    texture_sample_index<=texture_word_index;
                    texture_cache_valid[texture_line_index]<=0;texture_fill_line<=texture_line_index;
                    fill_only<=1;
                end
                else if(FILL==0 && tex_req_valid && tex_req_ready && !tex_req_prefetch && !(TEXTURE_FAST_HIT && texture_cache_hit)) begin
                    reply_off2<=tex_req_off2;reply_tag<=tex_req_tag;
                    // The guest already authorized this sample. A hit uses the
                    // same owned reply slot, so no extra sample or guest edge
                    // is admitted and all existing arbitration stays intact.
                    // (In fast mode a hit is answered by the fast path only;
                    // taking it here too would produce a second reply and hold
                    // the credit: the deadlock found in the native model.)
                    if(texture_cache_hit) begin
                        owner<=TEXTURE_READ;reply_data<={24'b0,texture_cache_shifted[7:0]};reply_data2<=texture_cache_word[tex_req_off2*8 +: 8];state<=REPLY;
                        command_address<={texture_byte_address[31:3],3'b0};
                    end else begin
                        capture(TEXTURE_READ,0,texture_byte_address,0,1,0);
                        // Read all bytes before caching neighbors. Disabled
                        // Avalon read lanes are not required to contain data.
                        if(TEXTURE_CACHE) begin
                            command_be<=8'hff;command_address<=texture_line_address;
                            command_burst<=4'(TEXTURE_CACHE_BEATS);read_remaining<=4'(TEXTURE_CACHE_BEATS);
                            texture_sample_index<=texture_word_index;
                            texture_cache_valid[texture_line_index]<=0;texture_fill_line<=texture_line_index;
                        end
                        fill_only<=0;
                    end
                end else if(FRAME_WRITE_COALESCE && wc_valid && wc_age[4] && !fb_valid) begin
                    // Nothing else wants the credit and the word has aged: flush.
                    capture_word(FRAME_WRITE,{wc_tag,3'b0},wc_data,wc_be);wc_valid<=0;
                end
            end else if((FILL!=0) ? resp_main : (avm_readdatavalid && read_response_expected)) begin
                if(publication_safe) begin
                if(owner!=TEXTURE_READ || !TEXTURE_CACHE || texture_fill_index==texture_sample_index) begin
                    reply_data<=read_width==0 ? {24'b0,shifted_read[7:0]} :
                                read_width==1 ? {16'b0,shifted_read[15:0]} : shifted_read[31:0];
                    reply_data2<=avm_readdata[reply_off2*8 +: 8];
                end
                if(FRAMEBUFFER_CACHE && owner==SCAN_FB) begin
                    fb_cache_valid<=1;fb_cache_tag<=command_address[31:3];fb_cache_data<=avm_readdata;
                end
                if(TEXTURE_CACHE && owner==TEXTURE_READ) begin
                    texture_cache_data[texture_fill_line][texture_fill_index]<=avm_readdata;
                    if(read_remaining==1) begin
                        texture_cache_valid[texture_fill_line]<=1;texture_cache_tag[texture_fill_line]<=command_address[31:3];
                    end
                end
                end
                // Poison suppresses publication, but it cannot forgive the
                // rest of an accepted physical burst. Keep the credit owned.
                read_remaining<=read_remaining-1'b1;
                if(read_remaining==1) begin state<=(publication_safe && !fill_only) ? REPLY : IDLE;fill_only<=0;end
                else begin state<=READ_WAIT;texture_fill_index<=texture_fill_index+1'b1;end
            end else if(command_accepted) begin
                if(!command_write) state<=READ_WAIT;
                else begin
                    // Write-through coherence occurs only when the physical
                    // write is accepted, never at frontend admission. Absolute
                    // tags plus validated disjoint regions prevent aliases.
                    // Nonmatching writes retain the useful scanout line.
                    if(publication_safe && FRAMEBUFFER_CACHE && fb_cache_valid && fb_cache_tag==command_address[31:3])
                        for(integer lane=0;lane<8;lane=lane+1)
                            if(command_be[lane]) fb_cache_data[lane*8 +: 8]<=command_data[lane*8 +: 8];
                    // Only authoritative accepted CPU writes can change cached
                    // texture bytes. Validated disjoint regions and full tags
                    // prevent framebuffer/palette aliases or early visibility.
                    if(publication_safe && TEXTURE_CACHE && owner==CPU && FILL==0)
                        for(integer line=0;line<TEXTURE_CACHE_LINES;line=line+1)
                            if(texture_cache_valid[line])
                                for(integer word_index=0;word_index<TEXTURE_CACHE_BEATS;word_index=word_index+1)
                                    if(command_address[31:3]==texture_cache_tag[line]+29'(word_index))
                                        for(integer texture_lane=0;texture_lane<8;texture_lane=texture_lane+1)
                                            if(command_be[texture_lane])
                                                texture_cache_data[line][word_index][texture_lane*8 +: 8]<=command_data[texture_lane*8 +: 8];
                    if(publication_safe && owner==CPU) begin reply_data<=0;state<=REPLY;end
                    else state<=IDLE;
                end
            end else if(state==REPLY && (response_drained || !publication_safe)) state<=IDLE;
        end
    end
`ifndef SYNTHESIS
    initial if(TEXTURE_CACHE_BEATS!=1 && TEXTURE_CACHE_BEATS!=2 &&
               TEXTURE_CACHE_BEATS!=4 && TEXTURE_CACHE_BEATS!=8)
        $fatal(1,"Texture cache requires 1, 2, 4 or 8 beats");
`endif
endmodule
`default_nettype wire
