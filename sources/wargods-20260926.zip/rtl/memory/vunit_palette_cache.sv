`timescale 1ns/1ps
`default_nettype none
// RGB555 scanout mirror only. Full 32-bit CPU palette reads remain in DDR.
// One synchronous 32768 x 16 array stores {valid, RGB555}: 524288 bits.
// Reset scrubs one entry per fabric clock; it does not reset the RAM contents
// in parallel. The caller stalls guest/MMIO until initialized is asserted.
// All writes are COMMITTED DDR CPU writes and must be ordered outside lookup.
// Reset also requires the miss backend to flush old untagged responses.
module vunit_palette_cache (
    input wire clk,reset,
    output reg initialized,
    output reg fault,
    input wire write_valid,
    input wire [14:0] write_addr,
    input wire [31:0] write_data,
    input wire [3:0] write_be,
    input wire req_valid,
    output wire req_ready,
    input wire [14:0] req_addr,
    output wire rsp_valid,
    input wire rsp_ready,
    output wire [31:0] rsp_data,
    output wire miss_req_valid,
    input wire miss_req_ready,
    output wire [14:0] miss_req_addr,
    input wire miss_rsp_valid,
    output wire miss_rsp_ready,
    input wire [31:0] miss_rsp_data
);
    localparam [2:0] IDLE=0,LOOKUP=1,MISS_REQUEST=2,MISS_RESPONSE=3,RESPONSE=4;
    reg [2:0] state;
    reg [15:0] entries [0:32767];
    reg [14:0] scrub_index,lookup_address;
    reg [15:0] lookup_ram_word;
    reg lookup_seen;
    // Preserve reset-visible output data outside the RAM read register.
    wire [15:0] lookup_word = lookup_seen ? lookup_ram_word : 16'b0;
    reg [14:0] saved_rgb;
    // Suppress publication on the faulting edge as well as after the sticky
    // fault registers. An illegal writer/late reply cannot retire an old hit.
    wire protocol_error=(write_valid && (!initialized || state!=IDLE)) ||
                        (miss_rsp_valid && (!initialized || state!=MISS_RESPONSE));
    wire healthy=initialized && !reset && !fault && !protocol_error;
    assign req_ready=healthy && state==IDLE && !write_valid;
    assign rsp_valid=healthy && ((state==LOOKUP && lookup_word[15]) || state==RESPONSE);
    assign rsp_data={17'b0,(state==LOOKUP ? lookup_word[14:0] : saved_rgb)};
    assign miss_req_valid=healthy && state==MISS_REQUEST;
    assign miss_req_addr=lookup_address;
    assign miss_rsp_ready=healthy && state==MISS_RESPONSE;

    // One explicit arbitrated RAM write port. Scrub retains its original
    // priority even after a protocol fault before initialization completes.
    reg ram_write_enable;
    reg [14:0] ram_write_address;
    reg [15:0] ram_write_data;
    wire ram_read_enable = req_valid && req_ready;
    always @* begin
        ram_write_enable=0;ram_write_address=0;ram_write_data=0;
        if(!reset) begin
            if(!initialized) begin
                ram_write_enable=1;ram_write_address=scrub_index;
            end else if(!fault && !protocol_error) begin
                if(write_valid && |write_be[1:0]) begin
                    ram_write_enable=1;ram_write_address=write_addr;
                    // Full low-word snoops populate; partial low writes invalidate.
                    if(write_be[1:0]==2'b11) ram_write_data={1'b1,write_data[14:0]};
                end else if(state==MISS_RESPONSE && miss_rsp_valid) begin
                    ram_write_enable=1;ram_write_address=lookup_address;
                    ram_write_data={1'b1,miss_rsp_data[14:0]};
                end
            end
        end
    end
    // No reset or alternate assignments on array storage or its read register.
    // Upper-only/zero-enable snoops still block req_ready exactly as before.
    always @(posedge clk) begin
        if(ram_write_enable) entries[ram_write_address]<=ram_write_data;
        if(ram_read_enable) lookup_ram_word<=entries[req_addr];
    end
    always @(posedge clk) begin
        if(reset) lookup_seen<=0;
        else if(ram_read_enable) lookup_seen<=1;
    end

    always @(posedge clk) begin
        if(reset) begin
            initialized<=0;fault<=0;scrub_index<=0;state<=IDLE;
            lookup_address<=0;saved_rgb<=0;
        end else if(!initialized) begin
            if(scrub_index==15'h7fff) initialized<=1;
            else scrub_index<=scrub_index+1'b1;
            if(write_valid || miss_rsp_valid) fault<=1;
        end else if(!fault) begin
            if((write_valid && state!=IDLE) || (miss_rsp_valid && state!=MISS_RESPONSE)) fault<=1;
            else begin
                case(state)
                    IDLE: if(req_valid && req_ready) begin
                        lookup_address<=req_addr;state<=LOOKUP;
                    end
                    LOOKUP: if(!lookup_word[15]) state<=MISS_REQUEST;
                            else if(rsp_ready) state<=IDLE;
                    MISS_REQUEST: if(miss_req_ready) state<=MISS_RESPONSE;
                    MISS_RESPONSE: if(miss_rsp_valid) begin
                        saved_rgb<=miss_rsp_data[14:0];state<=RESPONSE;
                    end
                    RESPONSE: if(rsp_ready) state<=IDLE;
                    default: state<=IDLE;
                endcase
            end
        end
    end
endmodule
`default_nettype wire
