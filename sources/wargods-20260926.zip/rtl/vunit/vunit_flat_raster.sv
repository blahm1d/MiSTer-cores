// SPDX-License-Identifier: BSD-3-Clause
// MAME-faithful V-unit polygon renderer (flat and textured quads).
//
// Behavioural gospel, MAME c662f9ca1900ed7462dc4fe8d338a98e8e4ce3c3:
//   src/mame/williams/midvunit_v.cpp process_dma_queue    vertex = int16 + 0.5f,
//       texture parameters byte * 65536 + 32768, callback choice by word0 bits
//       0x300 (textured) and 0xc00 (transparent / masked / invalid -> flat);
//   src/mame/williams/midvunit_v.cpp make_vertices_inclusive  +0.001f on right
//       and bottom endpoints with equal-vertex skipping;
//   src/devices/video/poly.h render_polygon<4, ParamCount>   min/max vertex,
//       forward and backward edge chains skipping horizontal edges, left/right
//       chain choice, per-scanline chain walk, round_coordinate, swap, clip,
//       float parameter setup (all IEEE single precision);
//   src/mame/williams/midvunit_v.cpp render_flat / render_tex / render_textrans /
//       render_textransmask  int32 truncation of the span parameters, integer
//       stepping, dither parity, and the render_flat memset path for colour 0
//       that writes one word past the span (and one word at x = 0 on an empty
//       extent, because poly.h invokes the callback for every extent).
// The Python transcription scripts/mame_vunit_golden.py is the independent
// oracle for this module (matrix cross-diff and the pinned MAME fixtures).
//
// Structure: one fabric-time FSM over a pool of pipelined single-precision units
// (v19, 14 September 2026: three two-stage adders, three two-stage multipliers, two
// two-stage coordinate rounders, operands registered at issue, results three clocks
// later) and a restoring reciprocal (RECIP_STEPS bits per clock). Every calculation state asserts
// guest_calculation_wait (private fabric time, guest paused); pixel and texture
// handshakes keep the historical DRAW / TEX_REQ / TEX_RSP / TEX_WRITE contract
// and the PRIVATE_TEXTURE_SERVICE profile. Shapes are never rejected; the only
// rejection left is a texture base beyond the 22-bit texture window
// (reject_pulse[0]). The start_dither_phase input is retained for the port
// contract but MAME's dither parity is fixed: pixels with (x ^ y) even.
module vunit_flat_raster #(
    parameter integer WIDTH = 512,
    parameter integer HEIGHT = 400,
    // 0: legacy four guest service edges; 1: authorize once then finish the
    // texture transaction physically under whole-guest/MMIO pause;
    // 2: private pixel service: one guest edge accepts the quad, then every
    // sample, texture transaction and framebuffer write runs on fabric clocks
    // under guest_calculation_wait (the whole quad is private fabric time).
    parameter integer PRIVATE_TEXTURE_SERVICE = 0
) (
    input  wire         clk,
    input  wire         reset,
    input  wire         guest_ce,
    input  wire         start_valid,
    output wire         start_ready,
    input  wire [239:0]  start_words,
    input  wire         start_page,
    input  wire         start_dither_phase,
    output wire         busy,
    output reg  [1:0]   reject_pulse,
    output wire         fb_valid,
    input  wire         fb_ready,
    output wire [18:0]   fb_addr,
    output wire [15:0]   fb_data,
    output wire         tex_req_valid,
    input  wire         tex_req_ready,
    output wire [21:0]   tex_req_addr,
    output wire         tex_req_prefetch,   // fill-only line request (profile 2 pipeline)
    input  wire         tex_rsp_valid,
    output wire         tex_rsp_ready,
    input  wire [7:0]    tex_rsp_data,
    // Width lane (two pixels per clock, profile 2): a framebuffer transaction
    // may carry the pixel at fb_addr+1 too (fb_addr even), and a texture request
    // may ask for a second byte of the same 8-byte texture word.
    output wire         fb_pair,
    output wire [15:0]   fb_data_hi,
    output wire         tex_req_pair,
    output wire [2:0]    tex_req_off2,
    input  wire [7:0]    tex_rsp_data2,
    // Hit-under-miss (v11): a texture request carries its FIFO slot as a tag and
    // the reply returns it, so replies may come back out of order.
    output wire [3:0]    tex_req_tag,
    input  wire [3:0]    tex_rsp_tag,
    output wire         guest_memory_wait,
    output wire         guest_calculation_wait,
    output wire         guest_fb_offer,
    output wire         guest_tex_offer,
    // Observation only (gm1 r11 render-budget page): {setup FSM active, a row buffered, span attribution}. The span
    // attribution is the pipeline's own classification in profile 2 (42 waiting for a texel, 43 waiting for the
    // framebuffer, 41 waiting for texture request admission, 40 flowing, 0 idle) and sstate otherwise.
    // Leave unconnected where not displayed; it drives no logic here.
    output wire [7:0]   render_attr
);
    // ------------------------------------------------------------------
    // IEEE-754 single precision helpers (round to nearest even).
    // Subnormal inputs read as zero and subnormal results flush to zero: the
    // renderer's operands never reach that range and the golden model would
    // expose any divergence. Infinities arise only from 1/0 on a zero-width
    // span whose pixels are never drawn.
    // ------------------------------------------------------------------
    function automatic [4:0] fp_clz27(input [26:0] v);
        integer i; reg found;
        begin
            fp_clz27 = 5'd27; found = 0;
            for (i = 26; i >= 0; i = i - 1)
                if (!found && v[i]) begin fp_clz27 = 5'd26 - i[4:0]; found = 1; end
        end
    endfunction
    function automatic fp_is_zero(input [31:0] a);
        fp_is_zero = (a[30:23] == 8'd0);
    endfunction
    function automatic [31:0] fp_add(input [31:0] a, input [31:0] b);
        reg [31:0] x, y; reg swap, sx, sy;
        reg [7:0] ex, ey; reg [9:0] er;
        reg [23:0] mx, my;
        reg [26:0] big, small_raw, small_al;
        reg [27:0] sum;
        reg [7:0] sh;
        reg sticky, sticky_c, round_up;
        reg [4:0] lz;
        reg [24:0] mant;
        begin
            swap = (a[30:0] < b[30:0]);
            x = swap ? b : a; y = swap ? a : b;
            sx = x[31]; sy = y[31]; ex = x[30:23]; ey = y[30:23];
            mx = (ex != 0) ? {1'b1, x[22:0]} : 24'd0;
            my = (ey != 0) ? {1'b1, y[22:0]} : 24'd0;
            if (ex == 8'hff) fp_add = x;
            else if (my == 0) begin
                if (mx == 0) fp_add = {(sx & sy), 31'd0};
                else fp_add = x;
            end else begin
                sh = ex - ey;
                big = {mx, 3'b000};
                small_raw = {my, 3'b000};
                if (sh >= 8'd27) begin small_al = 27'd0; sticky = 1'b1; end
                else begin
                    small_al = small_raw >> sh;
                    sticky = ((small_raw & ((27'd1 << sh) - 27'd1)) != 27'd0);
                end
                small_al[0] = small_al[0] | sticky;
                if (sx == sy) sum = {1'b0, big} + {1'b0, small_al};
                else sum = {1'b0, big} - {1'b0, small_al};
                er = {2'b00, ex};
                if (sum == 28'd0) fp_add = 32'd0;
                else begin
                    if (sum[27]) begin
                        sticky_c = sum[0];
                        sum = {1'b0, sum[27:1]};
                        sum[0] = sum[0] | sticky_c;
                        er = er + 10'd1;
                    end else begin
                        lz = fp_clz27(sum[26:0]);
                        sum = sum << lz;
                        er = er - {5'd0, lz};
                    end
                    round_up = sum[2] & (sum[1] | sum[0] | sum[3]);
                    mant = {1'b0, sum[26:3]} + {24'd0, round_up};
                    if (mant[24]) begin mant = mant >> 1; er = er + 10'd1; end
                    if (er[9] || er == 10'd0) fp_add = {sx, 31'd0};
                    else if (er >= 10'd255) fp_add = {sx, 8'hff, 23'd0};
                    else fp_add = {sx, er[7:0], mant[22:0]};
                end
            end
        end
    endfunction
    function automatic [31:0] fp_sub(input [31:0] a, input [31:0] b);
        fp_sub = fp_add(a, {~b[31], b[30:0]});
    endfunction
    // v19: the same adder in two stages. Stage 1 (up to the mantissa sum): record
    // {mode[1:0], val[31:0], sx, er[9:0], sum[27:0]}; mode 1 carries a finished value.
    function automatic [72:0] fp_add_s1(input [31:0] a, input [31:0] b);
        reg [31:0] x, y; reg swap, sx, sy;
        reg [7:0] ex, ey;
        reg [23:0] mx, my;
        reg [26:0] big, small_raw, small_al;
        reg [53:0] wide;
        reg [27:0] sum;
        reg [7:0] sh;
        reg sticky;
        begin
            swap = (a[30:0] < b[30:0]);
            x = swap ? b : a; y = swap ? a : b;
            sx = x[31]; sy = y[31]; ex = x[30:23]; ey = y[30:23];
            mx = (ex != 0) ? {1'b1, x[22:0]} : 24'd0;
            my = (ey != 0) ? {1'b1, y[22:0]} : 24'd0;
            sum = 28'd0; sticky = 1'b0; small_al = 27'd0; wide = 54'd0;
            if (ex == 8'hff) fp_add_s1 = {2'd1, x, sx, 10'd0, 28'd0};
            else if (my == 0) begin
                if (mx == 0) fp_add_s1 = {2'd1, {(sx & sy), 31'd0}, sx, 10'd0, 28'd0};
                else fp_add_s1 = {2'd1, x, sx, 10'd0, 28'd0};
            end else begin
                sh = ex - ey;
                big = {mx, 3'b000};
                small_raw = {my, 3'b000};
                if (sh >= 8'd27) begin small_al = 27'd0; sticky = 1'b1; end
                else begin
                    // one double-width shift: the shifted-out bits are the sticky
                    wide = {small_raw, 27'd0} >> sh;
                    small_al = wide[53:27];
                    sticky = (wide[26:0] != 27'd0);
                end
                small_al[0] = small_al[0] | sticky;
                if (sx == sy) sum = {1'b0, big} + {1'b0, small_al};
                else sum = {1'b0, big} - {1'b0, small_al};
                fp_add_s1 = {2'd0, 32'd0, sx, {2'b00, ex}, sum};
            end
        end
    endfunction
    function automatic [31:0] fp_add_s2(input [72:0] r);
        reg [1:0] mode; reg [31:0] val; reg sx; reg [9:0] er; reg [27:0] sum;
        reg sticky_c, round_up; reg [4:0] lz; reg [24:0] mant;
        begin
            mode = r[72:71]; val = r[70:39]; sx = r[38]; er = r[37:28]; sum = r[27:0];
            if (mode == 2'd1) fp_add_s2 = val;
            else if (sum == 28'd0) fp_add_s2 = 32'd0;
            else begin
                if (sum[27]) begin
                    sticky_c = sum[0];
                    sum = {1'b0, sum[27:1]};
                    sum[0] = sum[0] | sticky_c;
                    er = er + 10'd1;
                end else begin
                    lz = fp_clz27(sum[26:0]);
                    sum = sum << lz;
                    er = er - {5'd0, lz};
                end
                round_up = sum[2] & (sum[1] | sum[0] | sum[3]);
                mant = {1'b0, sum[26:3]} + {24'd0, round_up};
                if (mant[24]) begin mant = mant >> 1; er = er + 10'd1; end
                if (er[9] || er == 10'd0) fp_add_s2 = {sx, 31'd0};
                else if (er >= 10'd255) fp_add_s2 = {sx, 8'hff, 23'd0};
                else fp_add_s2 = {sx, er[7:0], mant[22:0]};
            end
        end
    endfunction
    function automatic [31:0] fp_mul(input [31:0] a, input [31:0] b);
        reg sa, sb, sr; reg [7:0] ea, eb; reg [23:0] ma, mb;
        reg [47:0] prod; reg [9:0] er; reg [26:0] ext; reg sticky, round_up; reg [24:0] mant;
        begin
            sa = a[31]; sb = b[31]; sr = sa ^ sb; ea = a[30:23]; eb = b[30:23];
            ma = (ea != 0) ? {1'b1, a[22:0]} : 24'd0;
            mb = (eb != 0) ? {1'b1, b[22:0]} : 24'd0;
            if (ea == 8'hff || eb == 8'hff) fp_mul = {sr, 8'hff, 23'd0};
            else if (ma == 0 || mb == 0) fp_mul = {sr, 31'd0};
            else begin
                prod = ma * mb;
                er = {2'b00, ea} + {2'b00, eb} - 10'd127;
                if (prod[47]) begin ext = prod[47:21]; sticky = (prod[20:0] != 21'd0); er = er + 10'd1; end
                else begin ext = prod[46:20]; sticky = (prod[19:0] != 20'd0); end
                round_up = ext[2] & (ext[1] | sticky | ext[3]);
                mant = {1'b0, ext[26:3]} + {24'd0, round_up};
                if (mant[24]) begin mant = mant >> 1; er = er + 10'd1; end
                if (er[9] || er == 10'd0) fp_mul = {sr, 31'd0};
                else if (er >= 10'd255) fp_mul = {sr, 8'hff, 23'd0};
                else fp_mul = {sr, er[7:0], mant[22:0]};
            end
        end
    endfunction
    // v19: the multiplier in two stages: {mode[1:0], val[31:0], sr, er[9:0], prod[47:0]}.
    function automatic [92:0] fp_mul_s1(input [31:0] a, input [31:0] b);
        reg sa, sb, sr; reg [7:0] ea, eb; reg [23:0] ma, mb; reg [47:0] prod; reg [9:0] er;
        begin
            sa = a[31]; sb = b[31]; sr = sa ^ sb; ea = a[30:23]; eb = b[30:23];
            ma = (ea != 0) ? {1'b1, a[22:0]} : 24'd0;
            mb = (eb != 0) ? {1'b1, b[22:0]} : 24'd0;
            prod = ma * mb;
            er = {2'b00, ea} + {2'b00, eb} - 10'd127;
            if (ea == 8'hff || eb == 8'hff) fp_mul_s1 = {2'd1, {sr, 8'hff, 23'd0}, sr, 10'd0, 48'd0};
            else if (ma == 0 || mb == 0) fp_mul_s1 = {2'd1, {sr, 31'd0}, sr, 10'd0, 48'd0};
            else fp_mul_s1 = {2'd0, 32'd0, sr, er, prod};
        end
    endfunction
    function automatic [31:0] fp_mul_s2(input [92:0] r);
        reg [1:0] mode; reg [31:0] val; reg sr; reg [9:0] er; reg [47:0] prod;
        reg [26:0] ext; reg sticky, round_up; reg [24:0] mant;
        begin
            mode = r[92:91]; val = r[90:59]; sr = r[58]; er = r[57:48]; prod = r[47:0];
            if (mode == 2'd1) fp_mul_s2 = val;
            else begin
                if (prod[47]) begin ext = prod[47:21]; sticky = (prod[20:0] != 21'd0); er = er + 10'd1; end
                else begin ext = prod[46:20]; sticky = (prod[19:0] != 20'd0); end
                round_up = ext[2] & (ext[1] | sticky | ext[3]);
                mant = {1'b0, ext[26:3]} + {24'd0, round_up};
                if (mant[24]) begin mant = mant >> 1; er = er + 10'd1; end
                if (er[9] || er == 10'd0) fp_mul_s2 = {sr, 31'd0};
                else if (er >= 10'd255) fp_mul_s2 = {sr, 8'hff, 23'd0};
                else fp_mul_s2 = {sr, er[7:0], mant[22:0]};
            end
        end
    endfunction
    function automatic fp_lt(input [31:0] a, input [31:0] b);
        reg za, zb;
        begin
            za = fp_is_zero(a); zb = fp_is_zero(b);
            if (a[30:23] == 8'hff && a[22:0] != 0) fp_lt = 1'b0;
            else if (b[30:23] == 8'hff && b[22:0] != 0) fp_lt = 1'b0;
            else if (za && zb) fp_lt = 1'b0;
            else if (za) fp_lt = ~b[31];
            else if (zb) fp_lt = a[31];
            else if (a[31] != b[31]) fp_lt = a[31];
            else if (!a[31]) fp_lt = (a[30:0] < b[30:0]);
            else fp_lt = (a[30:0] > b[30:0]);
        end
    endfunction
    function automatic fp_gt(input [31:0] a, input [31:0] b);
        fp_gt = fp_lt(b, a);
    endfunction
    // poly.h round_coordinate: floor(value) + (value - floor(value) > 0.5).
    function automatic signed [31:0] fp_round_coordinate(input [31:0] v);
        reg s; reg signed [9:0] e; reg [23:0] m; reg [31:0] ipart; reg [23:0] frac, lowmask; reg frac_nz, topbit, gt;
        integer shift; reg signed [31:0] fl;
        begin
            s = v[31]; e = $signed({2'b00, v[30:23]}) - 10'sd127; m = {1'b1, v[22:0]};
            if (v[30:23] == 8'd0) fp_round_coordinate = 32'sd0;
            else if (v[30:23] == 8'hff) fp_round_coordinate = s ? -32'sd2147483648 : 32'sd2147483647;
            else if (e < 0) begin
                topbit = (e == -10'sd1);
                gt = s ? !topbit : (topbit && (v[22:0] != 23'd0));
                fl = s ? -32'sd1 : 32'sd0;
                fp_round_coordinate = fl + (gt ? 32'sd1 : 32'sd0);
            end else if (e <= 10'sd22) begin
                shift = 23 - e;
                ipart = {8'd0, m} >> shift;
                lowmask = (24'd1 << shift) - 24'd1;
                frac = m & lowmask;
                frac_nz = (frac != 24'd0);
                topbit = frac[shift - 1];
                gt = s ? (frac_nz && !topbit) : (topbit && ((frac & ((24'd1 << (shift - 1)) - 24'd1)) != 24'd0));
                fl = s ? (-$signed({1'b0, ipart}) - (frac_nz ? 32'sd1 : 32'sd0)) : $signed({1'b0, ipart});
                fp_round_coordinate = fl + (gt ? 32'sd1 : 32'sd0);
            end else if (e <= 10'sd30) begin
                ipart = {8'd0, m} << (e - 23);
                fp_round_coordinate = s ? -$signed({1'b0, ipart}) : $signed({1'b0, ipart});
            end else fp_round_coordinate = s ? -32'sd2147483648 : 32'sd2147483647;
        end
    endfunction
    // v19: round_coordinate in two stages. Stage 1 classifies the exponent, finishes every
    // case except 0 <= e <= 22, and for that case shifts {m, 24'b0} right by 23 - e in one
    // double-width shift (integer part above, the shifted-out fraction bits below, the
    // top fraction bit at [23]); stage 2 forms the rounding decision from those bits.
    // Record: {mode[1:0], val[31:0], s, ipart[23:0], frac[23:0]}; mode 3 carries a value.
    function automatic [82:0] fp_round_s1(input [31:0] v);
        reg s; reg signed [9:0] e; reg [23:0] m; reg [31:0] ipart; reg topbit, gt; integer shift;
        reg signed [31:0] fl; reg [47:0] wide;
        begin
            s = v[31]; e = $signed({2'b00, v[30:23]}) - 10'sd127; m = {1'b1, v[22:0]}; wide = 48'd0; ipart = 32'd0;
            if (v[30:23] == 8'd0) fp_round_s1 = {2'd3, 32'sd0, s, 24'd0, 24'd0};
            else if (v[30:23] == 8'hff) fp_round_s1 = {2'd3, (s ? -32'sd2147483648 : 32'sd2147483647), s, 24'd0, 24'd0};
            else if (e < 0) begin
                topbit = (e == -10'sd1);
                gt = s ? !topbit : (topbit && (v[22:0] != 23'd0));
                fl = s ? -32'sd1 : 32'sd0;
                fl = fl + (gt ? 32'sd1 : 32'sd0);
                fp_round_s1 = {2'd3, fl, s, 24'd0, 24'd0};
            end else if (e <= 10'sd22) begin
                shift = 23 - e;
                wide = {m, 24'd0} >> shift;
                fp_round_s1 = {2'd0, 32'd0, s, wide[47:24], wide[23:0]};
            end else if (e <= 10'sd30) begin
                ipart = {8'd0, m} << (e - 23);
                fl = s ? -$signed({1'b0, ipart}) : $signed({1'b0, ipart});   // 32-bit result as in the original
                fp_round_s1 = {2'd3, fl, s, 24'd0, 24'd0};
            end else begin
                fl = s ? -32'sd2147483648 : 32'sd2147483647;
                fp_round_s1 = {2'd3, fl, s, 24'd0, 24'd0};
            end
        end
    endfunction
    function automatic signed [31:0] fp_round_s2(input [82:0] r);
        reg [1:0] mode; reg [31:0] val; reg s; reg [23:0] ipart, frac; reg frac_nz, topbit, low_nz, gt; reg signed [31:0] fl;
        begin
            mode = r[82:81]; val = r[80:49]; s = r[48]; ipart = r[47:24]; frac = r[23:0];
            if (mode == 2'd3) fp_round_s2 = $signed(val);
            else begin
                frac_nz = (frac != 24'd0);
                topbit = frac[23];
                low_nz = (frac[22:0] != 23'd0);
                gt = s ? (frac_nz && !topbit) : (topbit && low_nz);
                fl = s ? (-$signed({8'd0, ipart}) - (frac_nz ? 32'sd1 : 32'sd0)) : $signed({8'd0, ipart});
                fp_round_s2 = fl + (gt ? 32'sd1 : 32'sd0);
            end
        end
    endfunction
    // C++ float -> int32_t truncation; out of range / inf / nan give INT32_MIN
    // like MAME's x86-64 build.
    function automatic signed [31:0] fp_trunc_int32(input [31:0] v);
        reg s; reg signed [9:0] e; reg [23:0] m; reg [31:0] ipart;
        begin
            s = v[31]; e = $signed({2'b00, v[30:23]}) - 10'sd127; m = {1'b1, v[22:0]};
            if (v[30:23] == 8'd0 || e < 0) fp_trunc_int32 = 32'sd0;
            else if (v[30:23] == 8'hff || e >= 10'sd31) fp_trunc_int32 = -32'sd2147483648;
            else if (e <= 10'sd23) begin
                ipart = {8'd0, m} >> (23 - e);
                fp_trunc_int32 = s ? -$signed({1'b0, ipart}) : $signed({1'b0, ipart});
            end else begin
                ipart = {8'd0, m} << (e - 23);
                fp_trunc_int32 = s ? -$signed({1'b0, ipart}) : $signed({1'b0, ipart});
            end
        end
    endfunction
    // Exact (n + 0.5) for a signed integer with |n| < 2^24.
    function automatic [31:0] fp_from_half(input signed [31:0] n);
        reg s; reg [25:0] mag2; reg [4:0] p; integer i; reg found; reg [48:0] shifted;
        begin
            s = n[31];
            mag2 = s ? (~{n[24:0], 1'b1} + 26'd1) : {n[24:0], 1'b1};
            p = 5'd0; found = 0;
            for (i = 25; i >= 0; i = i - 1) if (!found && mag2[i]) begin p = i[4:0]; found = 1; end
            shifted = {23'd0, mag2} << (5'd23 - p);
            fp_from_half = {s, 8'd126 + {3'd0, p}, shifted[22:0]};
        end
    endfunction
    // Exact conversion of an unsigned integer below 2^24.
    function automatic [31:0] fp_from_uint24(input [23:0] n);
        reg [4:0] p; integer i; reg found; reg [46:0] shifted;
        begin
            p = 5'd0; found = 0;
            for (i = 23; i >= 0; i = i - 1) if (!found && n[i]) begin p = i[4:0]; found = 1; end
            shifted = {23'd0, n} << (5'd23 - p);
            fp_from_uint24 = (n == 24'd0) ? 32'd0 : {1'b0, 8'd127 + {3'd0, p}, shifted[22:0]};
        end
    endfunction

    localparam [31:0] FP_ONE = 32'h3F800000;
    localparam [31:0] FP_EPS = 32'h3A83126F;   // 0.001f

    // ------------------------------------------------------------------
    // States
    // ------------------------------------------------------------------
    // v19: the pipelined units add wait and collect states; the codes freed by v15/v17
    // (11-14, 21, 24, 25, 27-33, 35) and 46-59 carry them. 39-43 stay the span FSM's.
    localparam [5:0] IDLE=0, PREP=1, INCL_X=2, INCL_Y=3, MINMAX=4, ROWS=5,
                     CH_LOOP=6, E_DY=7, E_RECIP=8, E_DX=9, E_DXDY=10, INCL_W=11, INCL_W2=12,
                     E_DY_W=13, E_DY_W2=14, E_STORE=15, LR=16, SCAN=17, ADV_L=18, ADV_R=19,
                     X_LDY=20, E_DX_W=21, X_SX1=22, X_SX2=23, E_DX_C=24, E_DXDY_W=25, X_ROUND=26,
                     E_DXDY_W2=27, E_DXDY_C=28, ROWS_W=29, ROWS_W2=30, ROWS_C=31, X_LDY_W=32, X_LDY_W2=33,
                     P_DP2=34, X_SX1B=35, P_ST2=36, P_ST3=37, P_TRUNC=38, PIX_INIT=39,
                     DRAW=40, TEX_REQ=41, TEX_RSP=42, TEX_WRITE=43, NEXT_ROW=44, ROW_EMIT=45,
                     X_SX1C=46, X_SX2B=47, X_SX2C=48, X_RD1=49, X_RD2=50, X_RD3=51, X_RD4=52,
                     P_DP1=53, P_DP2_W=54, P_DP2_W2=55, P_ST2_W=56, P_ST2_W2=57, P_ST3_W=58, P_ST3_W2=59,
                     INCL_C=60, E_DX_W2=61,
                     SPAN_IDLE=0;
    reg [5:0] state;

    // Command
    reg page, dither, textured, mode_trans, mode_mask;
    reg [15:0] pixdata, texbase;
    reg signed [15:0] vxi [0:3];
    reg signed [15:0] vyi [0:3];
    reg [15:0] uvw [0:3];
    reg [31:0] vx [0:3];
    reg [31:0] vy [0:3];
    reg [31:0] vp0 [0:3];
    reg [31:0] vp1 [0:3];
    reg [3:0] rmask, bmask, eqmask;
    reg [1:0] vi, minv, maxv;
    reg [1:0] effv [0:3];
    reg [9:0] minyclip, maxyclip;
    // Edge chains: slots 0..nf-1 forward, nf..nf+nb-1 backward.
    reg [1:0] e_v1 [0:3];
    reg [1:0] e_v2 [0:3];
    reg [31:0] e_dxdy [0:3];
    reg [31:0] e_dpdy0 [0:3];
    reg [31:0] e_dpdy1 [0:3];
    reg [2:0] nf, nb, ns;
    reg chain_back;
    reg [1:0] curv, cur_v2;
    reg fwd_left;
    reg [1:0] li, ri;
    // Scanline temporaries
    reg [9:0] curscan;
    reg [31:0] fully, ldy, rdy, t, t2, startx, stopx, ooy, oox, lparam, rparam;
    // Parallel per-row setup: right-side extent temp and the second texture
    // parameter's temporaries, so both parameters and both extents are computed
    // in the same states (identical operations, half the states).
    reg [31:0] t_r, ta0, ta1, tb0, tb1, lparam1, rparam1;
    reg [31:0] tp0, tp1;   // edge parameter differences (v15)
    reg [31:0] dpdx [0:1];
    reg [31:0] pstart [0:1];
    reg pidx;
    reg [9:0] ix_start, ix_stop, px, pend;
    reg signed [31:0] u, v, dudx, dvdx;
    reg [7:0] sampled_texel;
    // Row-ahead pipeline: the setup FSM (state) emits each finished row into a
    // one-entry buffer (b_*); the span FSM (sstate) draws the buffered row from
    // its own copies (s_*) while the setup FSM already computes the next row or
    // accepts the next quad. Arithmetic is unchanged; only the schedule moves.
    reg [5:0] sstate /*verilator public_flat_rd*/;   // profile 2: observer attribution only
    reg row_valid;
    reg signed [31:0] r_u, r_v, r_dudx, r_dvdx;
    reg signed [31:0] pr_u, pr_v; reg have_prev;   // previous row's first texel (row-ahead prefetch)
    // Row-pipelined setup (v17): the pending row's parameter inputs, copied from the
    // extent registers when the extent stream moves on to the next row.
    reg [31:0] p_startx, p_lparam, p_lparam1, p_da0, p_da1, x_da0, x_da1;
    reg [31:0] p_ixf, xdiff;   // v19: row-start float and stopx - startx, registered ahead of use
    reg signed [31:0] istartx_r, istopx_r;   // v19: rounded extents (from the rounder units)
    reg [9:0] p_ix_start, p_ix_stop, p_scan;
    reg p_pending, p_oox_valid, x_ahead, x_done;
    // Prefetch sequencer (v14): latched at the row hand-off, drained on free port clocks.
    // v16 offers in priority order: [0] row after next, [1] its next line along u,
    // [2] next row, [3] its next line, [4] this row's next line (first row only).
    reg [4:0] sp_pending;
    reg signed [31:0] sp_u0, sp_v0, sp_u1, sp_v1, sp_u2, sp_v2, sp_step;
    reg [15:0] sp_texbase;
    reg [9:0] b_ix_start, b_ix_stop, b_row;
    reg signed [31:0] b_u, b_v, b_dudx, b_dvdx;
    reg b_textured, b_dither, b_mode_trans, b_mode_mask, b_page;
    reg [15:0] b_pixdata, b_texbase;
    reg [9:0] s_ix_start, s_ix_stop, s_row;
    reg s_textured, s_dither, s_mode_trans, s_mode_mask, s_page;
    reg [15:0] s_pixdata, s_texbase;
    // Width (14 September 2026): the front issues an aligned pair of pixels per
    // clock when it can; see lane_pair below. Arithmetic per pixel is unchanged.
    // Profile 2 pipelined span: the front stage (p_active, the s_*/px/pend/u/v
    // registers above) issues one entry per clock into a sixteen-entry FIFO
    // (v11: tagged replies, so a miss holds up only its own entry while hits to
    // other lines keep landing); the retire stage writes each pixel as its texel returns (flat pixels
    // pass through the same FIFO so framebuffer writes keep polygon order).
    reg p_active, p_init;
    reg [4:0] q_count;
    reg [3:0] q_wr, q_rd;
    reg [9:0] q_x [0:15];
    reg [9:0] q_row [0:15];
    reg [15:0] q_pixdata [0:15];
    reg q_page [0:15];
    reg q_trans [0:15];
    reg q_mask [0:15];
    reg q_textured [0:15];
    // Replies are accepted as soon as they arrive, into the entry named by their
    // tag (v11; before that the oldest textured entry without a texel); flat
    // entries are born with their slot valid. The
    // head then writes when its slot is valid, so a texture reply is never held
    // back by the framebuffer path (that hold was a deadlock against the arbiter:
    // reply parked in the skid, credit held in REPLY, word-change flush waiting
    // for the credit, head waiting for the flush).
    reg [7:0] q_texel [0:15];
    reg q_texel_valid [0:15];
    // Width: an entry may carry the pixel at q_x+1 as well (same row, page,
    // colour and flags); its texel arrives in the same reply as lane 0's.
    reg q_pair [0:15];
    reg [7:0] q_texel1 [0:15];
    // (The oldest-entry reply search of v5-v10 is gone: the tag names the slot.)
    // Reciprocal unit (1.0 / x): restoring division of the unit mantissa.
    // Quotient bits per clock of the restoring reciprocal (4 = radix-16: seven
    // clocks for the 25 bits; the fit review may lower it if the chained
    // compare-subtracts miss timing, the bit sequence does not change).
    localparam integer RECIP_STEPS = 3;   // v19: three bits per clock (five did not close at 50 MHz)
    // v19 unit pool: operands registered at issue (fa_a/fa_b, fm_a/fm_b, rd_in), stage-1
    // records the next clock, results the clock after; a state that issues at clock c
    // reads the result at c + 3 (issue, wait, wait, use).
    reg [31:0] fa_a [0:2]; reg [31:0] fa_b [0:2]; reg [72:0] fa_s1 [0:2]; reg [31:0] fa_out [0:2];
    reg [31:0] fm_a [0:2]; reg [31:0] fm_b [0:2]; reg [92:0] fm_s1 [0:2]; reg [31:0] fm_out [0:2];
    reg [31:0] rd_in [0:1]; reg [82:0] rd_s1 [0:1]; reg signed [31:0] rd_out [0:1];
    integer fu;
    always @(posedge clk) begin
        for (fu = 0; fu < 3; fu = fu + 1) begin
            fa_s1[fu] <= fp_add_s1(fa_a[fu], fa_b[fu]); fa_out[fu] <= fp_add_s2(fa_s1[fu]);
            fm_s1[fu] <= fp_mul_s1(fm_a[fu], fm_b[fu]); fm_out[fu] <= fp_mul_s2(fm_s1[fu]);
        end
        for (fu = 0; fu < 2; fu = fu + 1) begin
            rd_s1[fu] <= fp_round_s1(rd_in[fu]); rd_out[fu] <= fp_round_s2(rd_s1[fu]);
        end
    end
    // issue helpers: subtraction is an add of the negated operand, as in fp_sub
    task fa_issue(input integer k, input [31:0] a, input [31:0] b); begin fa_a[k] <= a; fa_b[k] <= b; end endtask
    task fa_issue_sub(input integer k, input [31:0] a, input [31:0] b); begin fa_a[k] <= a; fa_b[k] <= {~b[31], b[30:0]}; end endtask
    task fm_issue(input integer k, input [31:0] a, input [31:0] b); begin fm_a[k] <= a; fm_b[k] <= b; end endtask
    reg recip_busy; reg [4:0] recip_count; reg [24:0] recip_rem; reg [25:0] recip_q;
    reg [23:0] recip_mb; reg [9:0] recip_exp; reg recip_sign, recip_special; reg [31:0] recip_special_value;

    integer j;

    // ------------------------------------------------------------------
    // Combinational helpers
    // ------------------------------------------------------------------
    wire [2:0] lbase = fwd_left ? 3'd0 : nf;
    wire [2:0] rbase = fwd_left ? nf : 3'd0;
    wire [2:0] lcount = fwd_left ? nf : nb;
    wire [2:0] rcount = fwd_left ? nb : nf;
    wire [1:0] lslot = lbase[1:0] + li;
    wire [1:0] rslot = rbase[1:0] + ri;
    wire [1:0] l_v1 = e_v1[lslot], l_v2 = e_v2[lslot];
    wire [1:0] r_v1 = e_v1[rslot], r_v2 = e_v2[rslot];
    wire [31:0] maxvy = vy[maxv];
    wire adv_l = fp_gt(fully, vy[l_v2]) && fp_lt(fully, maxvy) && ({1'b0, li} + 3'd1 < lcount);
    wire adv_r = fp_gt(fully, vy[r_v2]) && fp_lt(fully, maxvy) && ({1'b0, ri} + 3'd1 < rcount);
    // v19: the extents are rounded by the rounder units into istartx_r / istopx_r
    wire signed [31:0] ix_lo = (istartx_r > istopx_r) ? istopx_r : istartx_r;
    wire signed [31:0] ix_hi = (istartx_r > istopx_r) ? istartx_r : istopx_r;
    wire signed [31:0] ix_lo_c = (ix_lo < 0) ? 32'sd0 : ix_lo;
    wire signed [31:0] ix_hi_c = (ix_hi > WIDTH) ? WIDTH : ix_hi;
    wire span_empty = (ix_lo_c >= ix_hi_c);
    wire signed [31:0] rows_min = rd_out[0];   // v19: rounded in ROWS, read in ROWS_C
    wire signed [31:0] rows_max = rd_out[1];
    wire signed [31:0] rows_min_c = (rows_min < 0) ? 32'sd0 : rows_min;
    wire signed [31:0] rows_max_c = (rows_max > HEIGHT) ? HEIGHT : rows_max;
    wire recip_ready = !recip_busy;
    wire [24:0] recip_mant_r = {1'b0, recip_q[25:2]} + {24'd0, (recip_q[1] & (recip_q[0] | (recip_rem != 25'd0) | recip_q[2]))};
    wire [9:0] recip_exp_r = recip_exp + (recip_mant_r[24] ? 10'd1 : 10'd0);
    wire [31:0] recip_value = recip_special ? recip_special_value :
        {recip_sign, recip_exp_r[7:0], recip_mant_r[24] ? recip_mant_r[23:1] : recip_mant_r[22:0]};
    wire texture_skip = (s_mode_trans || s_mode_mask) && (sampled_texel == 8'd0);
    wire signed [31:0] tex_index = $signed({v[31:8]} & 32'h0000ff00) + (u >>> 16);
    wire [31:0] tex_address = {8'd0, s_texbase, 8'd0} + tex_index;
    wire pixel_pending = (px < pend);
    // Width: the second lane is the golden's next pixel (u + dudx, v + dvdx). Two
    // pixels form one entry when they are an aligned pair (even x, both inside
    // the span, no dither stepping) and, when textured, their texels sit in the
    // same 8-byte texture word so one request returns both bytes.
    wire signed [31:0] u1 = u + dudx;
    wire signed [31:0] v1 = v + dvdx;
    wire signed [31:0] tex_index1 = $signed({v1[31:8]} & 32'h0000ff00) + (u1 >>> 16);
    wire [31:0] tex_address1 = {8'd0, s_texbase, 8'd0} + tex_index1;
    wire lane_pair_geom = (PRIVATE_TEXTURE_SERVICE == 2) && !s_dither && !px[0] && ((px + 10'd1) < pend);
    wire lane_pair = lane_pair_geom && (!s_textured || (tex_address1[21:3] == tex_address[21:3]));
    // Texture prefetch (profile 2): the line sixteen pixels ahead along the span
    // is requested fill-only once per line so the arbiter fills it while hits
    // to the current line keep flowing.
    // Row-ahead texture prefetch (v13): the setup FSM offers a fill-only request
    // for the line of the row's first texel at the hand-off (ROW_EMIT) and, one
    // clock later (NEXT_ROW), for the predicted first texel of the next row
    // (2 x current - previous: exact between vertices, the edge step per row is
    // constant). The arbiter's fill unit fetches lines that are neither valid
    // nor in flight, demand misses first; nothing is replied. Each offer takes
    // the request port for one clock.
    wire signed [31:0] u_pred = (r_u <<< 1) - pr_u;
    wire signed [31:0] v_pred = (r_v <<< 1) - pr_v;
    // v14: the sequencer offers up to three lines per row, only on clocks the span
    // front does not use the request port, so it never stalls the front.
    wire p_tex_req_raw = !reset && p_active && pixel_pending && s_textured && !q_full;
    wire sp_valid = (PRIVATE_TEXTURE_SERVICE == 2) && !reset && (sp_pending != 5'd0) && !p_tex_req_raw;
    wire [2:0] sp_sel = sp_pending[0] ? 3'd0 : sp_pending[1] ? 3'd1 : sp_pending[2] ? 3'd2 : sp_pending[3] ? 3'd3 : 3'd4;
    wire signed [31:0] sp_u = (sp_sel == 3'd0) ? sp_u2 : (sp_sel == 3'd1) ? (sp_u2 + sp_step) :
                              (sp_sel == 3'd2) ? sp_u1 : (sp_sel == 3'd3) ? (sp_u1 + sp_step) : (sp_u0 + sp_step);
    wire signed [31:0] sp_v = (sp_sel == 3'd0 || sp_sel == 3'd1) ? sp_v2 : (sp_sel == 3'd4) ? sp_v0 : sp_v1;
    wire signed [31:0] sp_index = $signed({sp_v[31:8]} & 32'h0000ff00) + (sp_u >>> 16);
    wire [31:0] sp_addr = {8'd0, sp_texbase, 8'd0} + sp_index;
    wire [8:0] row_addr = (px[9] ? s_row[8:0] + 9'd1 : s_row[8:0]);
    wire texture_address_supported = (start_words[239:238] == 2'b00);

    // Profile 2 pipelined span wires: FIFO head, retire decisions, front issue.
    localparam PIPE = (PRIVATE_TEXTURE_SERVICE == 2);
    wire q_empty = (q_count == 5'd0);
    wire q_full = (q_count == 5'd16);
    wire head_tex = q_textured[q_rd];
    wire head_ready = !q_empty && q_texel_valid[q_rd];
    // Each lane skips on its own texel (transparent / masked zero); the entry
    // writes both lanes as one pair, one lane alone, or nothing.
    wire head_masked = head_tex && (q_trans[q_rd] || q_mask[q_rd]);
    wire lane0_write = !(head_masked && (q_texel[q_rd] == 8'd0));
    wire lane1_write = q_pair[q_rd] && !(head_masked && (q_texel1[q_rd] == 8'd0));
    wire head_skip = !lane0_write && !lane1_write;
    wire [8:0] p_row_addr = (q_x[q_rd][9] ? q_row[q_rd][8:0] + 9'd1 : q_row[q_rd][8:0]);
    wire p_fb_valid = !reset && head_ready && !head_skip;
    wire [15:0] p_value0 = head_tex ? (q_mask[q_rd] ? q_pixdata[q_rd] : q_pixdata[q_rd] + {8'd0, q_texel[q_rd]}) : q_pixdata[q_rd];
    wire [15:0] p_value1 = head_tex ? (q_mask[q_rd] ? q_pixdata[q_rd] : q_pixdata[q_rd] + {8'd0, q_texel1[q_rd]}) : q_pixdata[q_rd];
    wire [15:0] p_fb_data = lane0_write ? p_value0 : p_value1;
    wire [9:0] p_fb_x = lane0_write ? q_x[q_rd] : (q_x[q_rd] + 10'd1);
    wire p_tex_req_valid = p_tex_req_raw;   // the sequencer yields to the front
    wire p_issue = p_active && pixel_pending && !q_full && (!s_textured || tex_req_ready);
    wire p_tex_rsp_ready = !reset;   // every reply has its slot (the tag); nothing is held back
    wire p_reply = tex_rsp_valid && p_tex_rsp_ready;
    wire p_pop = head_ready && (head_skip || fb_ready);
    wire p_busy = p_active || p_init || !q_empty;
    // Attribution for the observer (sstate is otherwise unused in profile 2):
    // 42 waiting for a texel, 43 waiting for the framebuffer, 41 waiting for
    // request admission, 40 pipeline flowing, 0 idle.
    wire [5:0] p_attr = (!q_empty && head_tex && !q_texel_valid[q_rd]) ? TEX_RSP :
                        (p_fb_valid && !fb_ready) ? TEX_WRITE :
                        (p_tex_req_valid && !tex_req_ready) ? TEX_REQ :
                        p_busy ? DRAW : SPAN_IDLE;
    assign busy = (state != IDLE) || row_valid || (PIPE ? p_busy : (sstate != SPAN_IDLE));
    assign render_attr = {(state != IDLE), row_valid, (PIPE ? p_attr : sstate)};
    // Profiles 0/1: private calculation = setup FSM active, a row waiting in the
    // buffer, the span's PIX_INIT step, and (profile 1) the texture transaction.
    assign guest_calculation_wait = PIPE ? busy :
        ((state != IDLE) || row_valid || (sstate == PIX_INIT) ||
         ((PRIVATE_TEXTURE_SERVICE != 0) && ((sstate == TEX_REQ) || (sstate == TEX_RSP) || (sstate == TEX_WRITE))));
    assign start_ready = guest_ce && !reset && (state == IDLE);
    assign guest_fb_offer = PIPE ? p_fb_valid :
                            (((sstate == DRAW) && !s_textured && pixel_pending) ||
                             ((sstate == TEX_WRITE) && !texture_skip));
    assign guest_tex_offer = PIPE ? (p_tex_req_valid || sp_valid) : (sstate == TEX_REQ);
    assign fb_valid = PIPE ? p_fb_valid : (!reset && guest_fb_offer &&
        (guest_ce || (PRIVATE_TEXTURE_SERVICE && sstate == TEX_WRITE)));
    assign fb_addr = PIPE ? {q_page[q_rd], p_row_addr, p_fb_x[8:0]} : {s_page, row_addr, px[8:0]};
    assign fb_data = PIPE ? p_fb_data :
                     ((sstate == TEX_WRITE) ? (s_mode_mask ? s_pixdata : s_pixdata + {8'd0, sampled_texel}) : s_pixdata);
    assign fb_pair = PIPE && p_fb_valid && lane0_write && lane1_write;
    assign fb_data_hi = PIPE ? p_value1 : 16'd0;
    assign tex_req_pair = PIPE && p_tex_req_valid && lane_pair;
    assign tex_req_off2 = PIPE ? tex_address1[2:0] : 3'd0;
    assign tex_req_tag = PIPE ? q_wr : 4'd0;
    assign tex_req_valid = PIPE ? (p_tex_req_valid || sp_valid) : (!reset && guest_tex_offer && (guest_ce || PRIVATE_TEXTURE_SERVICE));
    assign tex_req_addr = (PIPE && sp_valid) ? sp_addr[21:0] : tex_address[21:0];
    assign tex_req_prefetch = PIPE && sp_valid;
    assign tex_rsp_ready = PIPE ? p_tex_rsp_ready : (!reset && (sstate == TEX_RSP) && (guest_ce || PRIVATE_TEXTURE_SERVICE));
    assign guest_memory_wait = PIPE ?
        ((p_tex_req_valid && !tex_req_ready) || (p_fb_valid && !fb_ready) || (!q_empty && head_tex && !tex_rsp_valid)) :
        (((sstate == DRAW) && !s_textured && pixel_pending && !fb_ready) ||
         ((sstate == TEX_WRITE) && !texture_skip && !fb_ready) ||
         ((sstate == TEX_REQ) && !tex_req_ready) ||
         ((sstate == TEX_RSP) && !tex_rsp_valid));

    task begin_recip(input [31:0] x, input [5:0] destination);
        reg [23:0] mb;
        begin
            mb = {1'b1, x[22:0]};
            recip_sign <= x[31];
            recip_busy <= 1'b1;
            recip_special <= 1'b0;
            if (x[30:23] == 8'd0) begin
                recip_special <= 1'b1; recip_special_value <= {x[31], 8'hff, 23'd0}; recip_count <= 5'd25;
            end else if (x[30:23] == 8'hff) begin
                recip_special <= 1'b1; recip_special_value <= {x[31], 31'd0}; recip_count <= 5'd25;
            end else if (x[22:0] == 23'd0) begin
                recip_q <= 26'h2000000; recip_rem <= 25'd0; recip_mb <= mb;
                recip_exp <= 10'd254 - {2'b00, x[30:23]}; recip_count <= 5'd25;
            end else begin
                recip_q <= 26'd1; recip_rem <= 25'h1000000 - {1'b0, mb}; recip_mb <= mb;
                recip_exp <= 10'd253 - {2'b00, x[30:23]}; recip_count <= 5'd0;
            end
            state <= destination;
        end
    endtask

    always @(posedge clk) begin
        if (reset) begin
            state <= IDLE; reject_pulse <= 0;
            page <= 0; dither <= 0; textured <= 0; mode_trans <= 0; mode_mask <= 0;
            pixdata <= 0; texbase <= 0;
            rmask <= 0; bmask <= 0; eqmask <= 0; vi <= 0; minv <= 0; maxv <= 0;
            minyclip <= 0; maxyclip <= 0; nf <= 0; nb <= 0; ns <= 0; chain_back <= 0; curv <= 0; cur_v2 <= 0;
            fwd_left <= 0; li <= 0; ri <= 0; curscan <= 0;
            fully <= 0; ldy <= 0; rdy <= 0; t <= 0; t2 <= 0; startx <= 0; stopx <= 0; ooy <= 0; oox <= 0;
            lparam <= 0; rparam <= 0; pidx <= 0; ix_start <= 0; ix_stop <= 0; px <= 0; pend <= 0;
            t_r <= 0; ta0 <= 0; ta1 <= 0; tb0 <= 0; tb1 <= 0; lparam1 <= 0; rparam1 <= 0;
            u <= 0; v <= 0; dudx <= 0; dvdx <= 0; sampled_texel <= 0;
            sstate <= SPAN_IDLE; row_valid <= 0; r_u <= 0; r_v <= 0; r_dudx <= 0; r_dvdx <= 0;
            b_ix_start <= 0; b_ix_stop <= 0; b_row <= 0; b_u <= 0; b_v <= 0; b_dudx <= 0; b_dvdx <= 0;
            b_textured <= 0; b_dither <= 0; b_mode_trans <= 0; b_mode_mask <= 0; b_page <= 0; b_pixdata <= 0; b_texbase <= 0;
            s_ix_start <= 0; s_ix_stop <= 0; s_row <= 0;
            s_textured <= 0; s_dither <= 0; s_mode_trans <= 0; s_mode_mask <= 0; s_page <= 0; s_pixdata <= 0; s_texbase <= 0;
            p_active <= 0; p_init <= 0; q_count <= 0; q_wr <= 0; q_rd <= 0; pr_u <= 0; pr_v <= 0; have_prev <= 0;
            p_startx <= 0; p_lparam <= 0; p_lparam1 <= 0; p_da0 <= 0; p_da1 <= 0; x_da0 <= 0; x_da1 <= 0;
            p_ixf <= 0; xdiff <= 0; istartx_r <= 0; istopx_r <= 0;
            for (j = 0; j < 3; j = j + 1) begin fa_a[j] <= 0; fa_b[j] <= 0; fm_a[j] <= 0; fm_b[j] <= 0; end
            rd_in[0] <= 0; rd_in[1] <= 0;
            p_ix_start <= 0; p_ix_stop <= 0; p_scan <= 0; p_pending <= 0; p_oox_valid <= 0; x_ahead <= 0; x_done <= 0;
            sp_pending <= 0; sp_u0 <= 0; sp_v0 <= 0; sp_u1 <= 0; sp_v1 <= 0; sp_u2 <= 0; sp_v2 <= 0; sp_step <= 0; sp_texbase <= 0;
            for (j = 0; j < 16; j = j + 1) begin
                q_x[j] <= 0; q_row[j] <= 0; q_pixdata[j] <= 0; q_page[j] <= 0; q_trans[j] <= 0; q_mask[j] <= 0; q_textured[j] <= 0;
                q_texel[j] <= 0; q_texel_valid[j] <= 0; q_pair[j] <= 0; q_texel1[j] <= 0;
            end
            recip_busy <= 0; recip_count <= 0; recip_rem <= 0; recip_q <= 0; recip_mb <= 0; recip_exp <= 0;
            recip_sign <= 0; recip_special <= 0; recip_special_value <= 0;
            for (j = 0; j < 4; j = j + 1) begin
                vxi[j] <= 0; vyi[j] <= 0; uvw[j] <= 0; vx[j] <= 0; vy[j] <= 0; vp0[j] <= 0; vp1[j] <= 0; effv[j] <= 0;
                e_v1[j] <= 0; e_v2[j] <= 0; e_dxdy[j] <= 0; e_dpdy0[j] <= 0; e_dpdy1[j] <= 0;
            end
            dpdx[0] <= 0; dpdx[1] <= 0; pstart[0] <= 0; pstart[1] <= 0;
        end else begin
            if (guest_ce) reject_pulse <= 0;
            // Reciprocal iterations run on every fabric clock while busy.
            if (recip_busy) begin : recip_step
                // Restoring division, RECIP_STEPS quotient bits per clock: the same
                // bit sequence as the one-bit loop (bit-identical result), fewer
                // bits on the last clock, and busy clears with the 25th bit so the
                // consumer sees the value one clock later. Special and exact cases
                // enter with the count already at 25 and finish on this clock.
                reg [25:0] rem_s; reg [25:0] q_s; reg [4:0] cnt_s; integer k;
                rem_s = {1'b0, recip_rem}; q_s = recip_q; cnt_s = recip_count;
                for (k = 0; k < RECIP_STEPS; k = k + 1) begin
                    if (cnt_s != 5'd25) begin
                        rem_s = {rem_s[24:0], 1'b0};
                        if (rem_s >= {2'b00, recip_mb}) begin rem_s = rem_s - {2'b00, recip_mb}; q_s = {q_s[24:0], 1'b1}; end
                        else q_s = {q_s[24:0], 1'b0};
                        cnt_s = cnt_s + 5'd1;
                    end
                end
                recip_rem <= rem_s[24:0]; recip_q <= q_s; recip_count <= cnt_s;
                if (cnt_s == 5'd25) recip_busy <= 1'b0;
            end
            case (state)
                IDLE: if (guest_ce && start_valid) begin
                    have_prev <= 1'b0;   // first row of a polygon has no predecessor to predict from
                    for (j = 0; j < 4; j = j + 1) begin
                        vxi[j] <= start_words[(2+j*2)*16 +: 16];
                        vyi[j] <= start_words[(3+j*2)*16 +: 16];
                        uvw[j] <= start_words[(10+j)*16 +: 16];
                    end
                    page <= start_page;
                    dither <= start_words[13];
                    texbase <= start_words[224 +: 16];
                    textured <= (start_words[9:8] == 2'b01);
                    // midvunit_v.cpp process_dma_queue callback selection.
                    if (start_words[9:8] == 2'b01) begin
                        case (start_words[11:10])
                            2'b00: begin mode_trans <= 0; mode_mask <= 0; pixdata <= start_words[16 +: 16]; end
                            2'b10: begin mode_trans <= 1; mode_mask <= 0; pixdata <= start_words[16 +: 16]; end
                            2'b11: begin mode_trans <= 0; mode_mask <= 1; pixdata <= start_words[16 +: 16] + {8'd0, start_words[7:0]}; end
                            default: begin mode_trans <= 0; mode_mask <= 0; textured <= 0; pixdata <= start_words[16 +: 16] + {8'd0, start_words[7:0]}; end
                        endcase
                    end else begin
                        mode_trans <= 0; mode_mask <= 0; pixdata <= start_words[16 +: 16] + {8'd0, start_words[7:0]};
                    end
                    if ((start_words[9:8] == 2'b01) && (start_words[11:10] != 2'b01) && !texture_address_supported) begin
                        reject_pulse[0] <= 1'b1;
                        state <= IDLE;
                    end else state <= PREP;
                end
                PREP: begin
                    // Vertex floats (int16 + 0.5, exact), texture parameters (exact),
                    // and the inclusion masks computed on the +0.5 positions.
                    for (j = 0; j < 4; j = j + 1) begin
                        vx[j] <= fp_from_half({{16{vxi[j][15]}}, vxi[j]});
                        vy[j] <= fp_from_half({{16{vyi[j][15]}}, vyi[j]});
                        vp0[j] <= fp_from_uint24({uvw[j][7:0], 16'h8000});
                        vp1[j] <= fp_from_uint24({uvw[j][15:8], 16'h8000});
                    end
                    for (j = 0; j < 4; j = j + 1) begin
                        eqmask[j] <= (vyi[(j+1)&3] == vyi[j]) && (vxi[(j+1)&3] == vxi[j]);
                        rmask[j] <= (vyi[(j+1)&3] > vyi[j]) || ((vyi[(j+1)&3] == vyi[j]) && (vxi[(j+1)&3] < vxi[j]));
                        bmask[j] <= (vxi[(j+1)&3] < vxi[j]) || ((vxi[(j+1)&3] == vxi[j]) && (vyi[(j+1)&3] < vyi[j]));
                    end
                    vi <= 0;
                    state <= INCL_X;
                end
                INCL_X: begin
                    // effective vertex: skip vertices equal to their successor (up to three hops)
                    if (eqmask == 4'hf) state <= MINMAX;
                    else begin
                        effv[vi] <= !eqmask[vi] ? vi : !eqmask[vi+2'd1] ? vi+2'd1 : !eqmask[vi+2'd2] ? vi+2'd2 : vi+2'd3;
                        state <= INCL_Y;
                    end
                    if (eqmask == 4'hf) vi <= 0;
                end
                INCL_Y: begin
                    fa_issue(0, vx[vi], FP_EPS); fa_issue(1, vy[vi], FP_EPS);
                    state <= INCL_W;
                end
                INCL_W: state <= INCL_W2;
                INCL_W2: state <= INCL_C;
                INCL_C: begin
                    if (rmask[effv[vi]]) vx[vi] <= fa_out[0];
                    if (bmask[effv[vi]]) vy[vi] <= fa_out[1];
                    vi <= vi + 2'd1;
                    state <= (vi == 2'd3) ? MINMAX : INCL_X;
                    if (vi == 2'd3) begin minv <= 0; maxv <= 0; end
                end
                MINMAX: begin
                    // poly.h: strict less for min, else-if strict greater for max, in vertex order.
                    if (vi == 2'd0) begin vi <= 2'd1; minv <= 0; maxv <= 0; end
                    else begin
                        if (fp_lt(vy[vi], vy[minv])) minv <= vi;
                        else if (fp_gt(vy[vi], vy[maxv])) maxv <= vi;
                        vi <= vi + 2'd1;
                        if (vi == 2'd3) state <= ROWS;
                    end
                end
                ROWS: begin rd_in[0] <= vy[minv]; rd_in[1] <= vy[maxv]; state <= ROWS_W; end
                ROWS_W: state <= ROWS_W2;
                ROWS_W2: state <= ROWS_C;
                ROWS_C: begin
                    minyclip <= rows_min_c[9:0];
                    maxyclip <= rows_max_c[9:0];
                    if (rows_max_c - rows_min_c <= 0) state <= IDLE;
                    else begin
                        ns <= 0; nf <= 0; nb <= 0; chain_back <= 0; curv <= minv;
                        state <= CH_LOOP;
                    end
                end
                CH_LOOP: begin
                    if (curv == maxv) begin
                        if (!chain_back) begin chain_back <= 1; curv <= minv; end
                        else state <= LR;
                    end else begin
                        cur_v2 <= chain_back ? (curv - 2'd1) : (curv + 2'd1);
                        state <= E_DY;
                    end
                end
                E_DY: begin fa_issue_sub(0, vy[cur_v2], vy[curv]); state <= E_DY_W; end
                E_DY_W: state <= E_DY_W2;
                E_DY_W2: state <= E_RECIP;
                E_RECIP: begin
                    t <= fa_out[0];
                    if (fp_is_zero(fa_out[0])) begin curv <= cur_v2; state <= CH_LOOP; end  // horizontal: skipped
                    else begin
                        e_v1[ns[1:0]] <= curv; e_v2[ns[1:0]] <= cur_v2;
                        begin_recip(fa_out[0], E_DX);
                    end
                end
                // v15/v19: the three edge differences during the reciprocal wait, the three
                // slopes through the multipliers.
                E_DX: begin
                    fa_issue_sub(0, vx[cur_v2], vx[curv]);
                    fa_issue_sub(1, vp0[cur_v2], vp0[curv]); fa_issue_sub(2, vp1[cur_v2], vp1[curv]);
                    state <= E_DX_W;
                end
                E_DX_W: state <= E_DX_W2;
                E_DX_W2: state <= E_DX_C;
                E_DX_C: begin
                    t2 <= fa_out[0]; tp0 <= fa_out[1]; tp1 <= fa_out[2];
                    if (recip_ready) begin ooy <= recip_value; state <= E_DXDY; end
                end
                E_DXDY: begin
                    fm_issue(0, t2, ooy); fm_issue(1, tp0, ooy); fm_issue(2, tp1, ooy);
                    state <= E_DXDY_W;
                end
                E_DXDY_W: state <= E_DXDY_W2;
                E_DXDY_W2: state <= E_DXDY_C;
                E_DXDY_C: begin
                    e_dxdy[ns[1:0]] <= fm_out[0];
                    if (textured) begin e_dpdy0[ns[1:0]] <= fm_out[1]; e_dpdy1[ns[1:0]] <= fm_out[2]; end
                    state <= E_STORE;
                end
                E_STORE: begin
                    ns <= ns + 3'd1;
                    if (chain_back) nb <= nb + 3'd1; else nf <= nf + 3'd1;
                    curv <= cur_v2;
                    state <= CH_LOOP;
                end
                LR: begin
                    // fedgelist[0] is slot 0, bedgelist[0] is slot nf.
                    fwd_left <= (e_v1[0] == e_v1[nf[1:0]]) ? fp_lt(e_dxdy[0], e_dxdy[nf[1:0]]) :
                                fp_lt(vx[e_v1[0]], vx[e_v1[nf[1:0]]]);
                    curscan <= minyclip; li <= 0; ri <= 0;
                    p_pending <= 0; p_oox_valid <= 0; x_ahead <= 0; x_done <= 0;
                    state <= SCAN;
                end
                SCAN: begin
                    if (curscan >= maxyclip) begin
                        // epilogue: the last row's parameters are still pending
                        x_done <= 1'b1; state <= (textured && p_pending) ? P_DP1 : IDLE;
                    end
                    else begin
                        fully <= fp_from_half({22'd0, curscan});
                        state <= ADV_L;
                    end
                end
                ADV_L: begin
                    if (adv_l) li <= li + 2'd1;
                    else state <= ADV_R;
                end
                ADV_R: begin
                    if (adv_r) ri <= ri + 2'd1;
                    else state <= X_LDY;
                end
                // Per-row setup, both extents and both texture parameters in the
                // same states (the same float operations as before, half the states);
                // the extent reciprocal starts at X_ROUND and is consumed at P_DP2.
                // Per-row setup (v19 schedule of the v15/v17 operations): the extents and
                // the texture parameters go through the unit pool three at a time; every
                // operand is the register (or unit output) the single-cycle version read.
                X_LDY: begin fa_issue_sub(0, fully, vy[l_v1]); fa_issue_sub(1, fully, vy[r_v1]); state <= X_LDY_W; end
                X_LDY_W: state <= X_LDY_W2;
                X_LDY_W2: state <= X_SX1;
                X_SX1: begin
                    ldy <= fa_out[0]; rdy <= fa_out[1];
                    fm_issue(0, fa_out[0], e_dxdy[lslot]); fm_issue(1, fa_out[1], e_dxdy[rslot]); fm_issue(2, fa_out[0], e_dpdy0[lslot]);
                    state <= X_SX1B;
                end
                X_SX1B: begin
                    fm_issue(0, ldy, e_dpdy1[lslot]); fm_issue(1, rdy, e_dpdy0[rslot]); fm_issue(2, rdy, e_dpdy1[rslot]);
                    state <= X_SX1C;
                end
                X_SX1C: state <= X_SX2;
                X_SX2: begin
                    // t, t_r, ta0 arrive: the three sums that need them
                    t <= fm_out[0]; t_r <= fm_out[1]; ta0 <= fm_out[2];
                    fa_issue(0, vx[l_v1], fm_out[0]); fa_issue(1, vx[r_v1], fm_out[1]); fa_issue(2, vp0[l_v1], fm_out[2]);
                    state <= X_SX2B;
                end
                X_SX2B: begin
                    // ta1, tb0, tb1 arrive: the other three sums
                    ta1 <= fm_out[0]; tb0 <= fm_out[1]; tb1 <= fm_out[2];
                    fa_issue(0, vp1[l_v1], fm_out[0]); fa_issue(1, vp0[r_v1], fm_out[1]); fa_issue(2, vp1[r_v1], fm_out[2]);
                    state <= X_SX2C;
                end
                X_SX2C: state <= X_RD1;
                X_RD1: begin
                    // startx, stopx, lparam arrive: round the extents, start stopx - startx
                    startx <= fa_out[0]; stopx <= fa_out[1]; lparam <= fa_out[2];
                    rd_in[0] <= fa_out[0]; rd_in[1] <= fa_out[1];
                    fa_issue_sub(2, fa_out[1], fa_out[0]);
                    state <= X_RD2;
                end
                X_RD2: begin
                    // lparam1, rparam, rparam1 arrive: the parameter differences
                    lparam1 <= fa_out[0]; rparam <= fa_out[1]; rparam1 <= fa_out[2];
                    fa_issue_sub(0, fa_out[1], lparam); fa_issue_sub(1, fa_out[2], fa_out[0]);
                    state <= X_RD3;
                end
                X_RD3: state <= X_RD4;
                X_RD4: begin
                    istartx_r <= rd_out[0]; istopx_r <= rd_out[1]; xdiff <= fa_out[2];
                    state <= X_ROUND;
                end
                // v17: X_ROUND of row N+1 captures row N's reciprocal (started at row N's
                // X_ROUND), starts row N+1's, and hands over to row N's parameter states; the
                // first row of a polygon only starts its reciprocal and lets the extent stream run on.
                X_ROUND: if (!(textured && p_pending) || recip_ready) begin
                    ix_start <= span_empty ? 10'd0 : ix_lo_c[9:0];
                    ix_stop <= span_empty ? 10'd0 : ix_hi_c[9:0];
                    pidx <= 0;
                    x_da0 <= fa_out[0]; x_da1 <= fa_out[1];
                    if (textured && p_pending) begin
                        oox <= recip_value; p_oox_valid <= 1'b1; x_ahead <= 1'b1;
                        begin_recip(xdiff, P_DP1);
                    end else if (textured) begin
                        p_startx <= startx; p_lparam <= lparam; p_lparam1 <= lparam1;
                        p_da0 <= fa_out[0]; p_da1 <= fa_out[1];
                        p_ix_start <= span_empty ? 10'd0 : ix_lo_c[9:0]; p_ix_stop <= span_empty ? 10'd0 : ix_hi_c[9:0];
                        p_scan <= curscan; p_pending <= 1'b1; p_oox_valid <= 1'b0;
                        begin_recip(xdiff, NEXT_ROW);
                    end else begin
                        p_ix_start <= span_empty ? 10'd0 : ix_lo_c[9:0]; p_ix_stop <= span_empty ? 10'd0 : ix_hi_c[9:0];
                        p_scan <= curscan; p_pending <= 1'b1;
                        state <= ROW_EMIT;
                    end
                end
                // Pending row parameters: the row-start float in its own state, then the
                // two products and the start offset together, then the two products and the
                // two sums of the span start.
                P_DP1: begin p_ixf <= fp_from_half({22'd0, p_ix_start}); state <= P_DP2; end
                P_DP2: if (p_oox_valid || recip_ready) begin
                    fm_issue(0, p_da0, p_oox_valid ? oox : recip_value);
                    fm_issue(1, p_da1, p_oox_valid ? oox : recip_value);
                    if (!p_oox_valid) oox <= recip_value;
                    fa_issue_sub(0, p_ixf, p_startx);
                    state <= P_DP2_W;
                end
                P_DP2_W: state <= P_DP2_W2;
                P_DP2_W2: state <= P_ST2;
                P_ST2: begin
                    dpdx[0] <= fm_out[0]; dpdx[1] <= fm_out[1]; t <= fa_out[0];
                    fm_issue(0, fa_out[0], fm_out[0]); fm_issue(1, fa_out[0], fm_out[1]);
                    state <= P_ST2_W;
                end
                P_ST2_W: state <= P_ST2_W2;
                P_ST2_W2: state <= P_ST3;
                P_ST3: begin
                    tb0 <= fm_out[0]; tb1 <= fm_out[1];
                    fa_issue(0, p_lparam, fm_out[0]); fa_issue(1, p_lparam1, fm_out[1]);
                    state <= P_ST3_W;
                end
                P_ST3_W: state <= P_ST3_W2;
                P_ST3_W2: state <= P_TRUNC;
                P_TRUNC: begin
                    pstart[0] <= fa_out[0]; pstart[1] <= fa_out[1];
                    r_u <= fp_trunc_int32(fa_out[0]);
                    r_v <= fp_trunc_int32(fa_out[1]);
                    r_dudx <= fp_trunc_int32(dpdx[0]);
                    r_dvdx <= fp_trunc_int32(dpdx[1]);
                    state <= ROW_EMIT;
                end
                ROW_EMIT: if (!row_valid) begin
                    // Hand the finished row to the span FSM; the next row's setup
                    // (or the next quad's acceptance) proceeds while it is drawn.
                    b_ix_start <= p_ix_start; b_ix_stop <= p_ix_stop; b_row <= p_scan;
                    b_u <= r_u; b_v <= r_v; b_dudx <= r_dudx; b_dvdx <= r_dvdx;
                    b_textured <= textured; b_dither <= dither; b_pixdata <= pixdata;
                    b_mode_trans <= mode_trans; b_mode_mask <= mode_mask; b_texbase <= texbase; b_page <= page;
                    row_valid <= 1'b1;
                    // Prefetch sequencer: this row's next line along u, the predicted next
                    // row's first line and its next line (the latter two once a previous
                    // row exists to predict from).
                    if (textured) begin
                        sp_u0 <= r_u; sp_v0 <= r_v; sp_u1 <= u_pred; sp_v1 <= v_pred; sp_texbase <= texbase;
                        sp_u2 <= u_pred + (r_u - pr_u); sp_v2 <= v_pred + (r_v - pr_v);   // two rows ahead
                        sp_step <= r_dudx[31] ? -32'sd2097152 : 32'sd2097152;   // 32 texels in 16.16
                        sp_pending <= have_prev ? 5'b01111 : 5'b10000;
                    end
                    pr_u <= r_u; pr_v <= r_v; have_prev <= textured;
                    if (textured && x_ahead) begin
                        // the row computed ahead becomes the pending row
                        p_startx <= startx; p_lparam <= lparam; p_lparam1 <= lparam1; p_da0 <= x_da0; p_da1 <= x_da1;
                        p_ix_start <= ix_start; p_ix_stop <= ix_stop; p_scan <= curscan; p_pending <= 1'b1; p_oox_valid <= 1'b0;
                    end else p_pending <= 1'b0;
                    x_ahead <= 1'b0;
                    state <= x_done ? IDLE : NEXT_ROW;
                end
                NEXT_ROW: begin
                    curscan <= curscan + 10'd1;
                    state <= SCAN;
                end
                default: state <= IDLE;
            endcase
            // Span FSM (profiles 0/1): draws the buffered row with the guest-edge
            // contract. In profile 2 the pipelined span below replaces it and
            // sstate only carries the observer's attribution.
            if (!PIPE) case (sstate)
                SPAN_IDLE: if (row_valid) begin
                    s_ix_start <= b_ix_start; s_ix_stop <= b_ix_stop; s_row <= b_row;
                    u <= b_u; v <= b_v; dudx <= b_dudx; dvdx <= b_dvdx;
                    s_textured <= b_textured; s_dither <= b_dither; s_pixdata <= b_pixdata;
                    s_mode_trans <= b_mode_trans; s_mode_mask <= b_mode_mask; s_texbase <= b_texbase; s_page <= b_page;
                    row_valid <= 1'b0;
                    sstate <= PIX_INIT;
                end
                PIX_INIT: begin
                    // render_flat / render_tex entry: dither parity adjustment,
                    // doubled parameter steps, and the colour-0 memset extent.
                    if (s_dither && ((s_row[0] ^ s_ix_start[0]) == 1'b1)) begin
                        px <= s_ix_start + 10'd1;
                        u <= u + dudx; v <= v + dvdx;
                    end else px <= s_ix_start;
                    if (s_dither) begin dudx <= dudx <<< 1; dvdx <= dvdx <<< 1; end
                    if (!s_textured && (s_pixdata == 16'd0) && !s_dither) pend <= s_ix_stop + 10'd1;
                    else pend <= s_ix_stop;
                    sstate <= DRAW;
                end
                DRAW: begin
                    if (!pixel_pending) sstate <= SPAN_IDLE;
                    else if (guest_ce || (PRIVATE_TEXTURE_SERVICE == 2)) begin
                        if (s_textured) sstate <= TEX_REQ;
                        else if (fb_ready) px <= px + (s_dither ? 10'd2 : 10'd1);
                    end
                end
                TEX_REQ: if (guest_ce || PRIVATE_TEXTURE_SERVICE) begin
                    if (tex_req_ready) sstate <= TEX_RSP;
                end
                TEX_RSP: if (guest_ce || PRIVATE_TEXTURE_SERVICE) begin
                    if (tex_rsp_valid) begin
                        sampled_texel <= tex_rsp_data;
                        sstate <= TEX_WRITE;
                    end
                end
                TEX_WRITE: if (guest_ce || PRIVATE_TEXTURE_SERVICE) begin
                    if (texture_skip || fb_ready) begin
                        px <= px + (s_dither ? 10'd2 : 10'd1);
                        u <= u + dudx; v <= v + dvdx;
                        sstate <= DRAW;
                    end
                end
                default: sstate <= SPAN_IDLE;
            endcase
            if (PIPE) begin
                sstate <= p_attr;
                // Retire: the head leaves the FIFO when its pixel is written or skipped.
                if (p_pop) q_rd <= q_rd + 4'd1;
                // (a hand-off in the same clock reloads sp_pending; its assignment above wins by
                // being guarded here, so a fresh row's offers are never dropped)
                if (sp_valid && !((state == ROW_EMIT) && !row_valid && textured)) sp_pending <= sp_pending & ~(5'b00001 << sp_sel);
                // Reply lands in the oldest textured entry still without a texel.
                if (p_reply) begin q_texel[tex_rsp_tag] <= tex_rsp_data; q_texel1[tex_rsp_tag] <= tex_rsp_data2; q_texel_valid[tex_rsp_tag] <= 1'b1; end
                // Front: take a row, initialise it (dither parity, doubled steps,
                // colour-0 memset extent), then issue one pixel per clock.
                if (!p_active && !p_init) begin
                    if (row_valid) begin
                        s_ix_start <= b_ix_start; s_ix_stop <= b_ix_stop; s_row <= b_row;
                        u <= b_u; v <= b_v; dudx <= b_dudx; dvdx <= b_dvdx;
                        s_textured <= b_textured; s_dither <= b_dither; s_pixdata <= b_pixdata;
                        s_mode_trans <= b_mode_trans; s_mode_mask <= b_mode_mask; s_texbase <= b_texbase; s_page <= b_page;
                        row_valid <= 1'b0;
                        p_init <= 1'b1;
                    end
                end else if (p_init) begin
                    if (s_dither && ((s_row[0] ^ s_ix_start[0]) == 1'b1)) begin
                        px <= s_ix_start + 10'd1;
                        u <= u + dudx; v <= v + dvdx;
                    end else px <= s_ix_start;
                    if (s_dither) begin dudx <= dudx <<< 1; dvdx <= dvdx <<< 1; end
                    if (!s_textured && (s_pixdata == 16'd0) && !s_dither) pend <= s_ix_stop + 10'd1;
                    else pend <= s_ix_stop;
                    p_init <= 1'b0; p_active <= 1'b1;
                end else if (p_active) begin
                    if (!pixel_pending) p_active <= 1'b0;
                    else if (p_issue) begin
                        q_x[q_wr] <= px; q_row[q_wr] <= s_row; q_page[q_wr] <= s_page; q_pixdata[q_wr] <= s_pixdata;
                        q_trans[q_wr] <= s_mode_trans; q_mask[q_wr] <= s_mode_mask; q_textured[q_wr] <= s_textured;
                        q_pair[q_wr] <= lane_pair;
                        q_texel[q_wr] <= 8'd0; q_texel1[q_wr] <= 8'd0; q_texel_valid[q_wr] <= !s_textured;
                        q_wr <= q_wr + 4'd1;
                        px <= px + ((s_dither || lane_pair) ? 10'd2 : 10'd1);
                        u <= lane_pair ? (u1 + dudx) : (u + dudx);
                        v <= lane_pair ? (v1 + dvdx) : (v + dvdx);
                    end
                end
                q_count <= q_count + (p_issue ? 5'd1 : 5'd0) - (p_pop ? 5'd1 : 5'd0);
            end
        end
    end
endmodule
