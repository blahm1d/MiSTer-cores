// SPDX-License-Identifier: BSD-3-Clause
// Functional CRT register/raster profile. See README.md for unqualified phase,
// inclusive-count, sync-composition and oscillator relationships.
module vunit_raster #(
    parameter integer IRQ_PULSE_GUEST_STEPS = 1
) (
    input wire clk, reset, guest_ce, video_ce,
    input wire counter_reset,
    input wire wr_valid,
    input wire [3:0] wr_index,
    input wire [15:0] wr_data,
    output reg [9:0] raster_x,
    output reg [8:0] raster_y,
    output wire raster_de,
    output wire hsync, vsync, csync,
    output wire pixel_event, frame_event,
    output wire irq_int0,
    // Stage 2 (2026-09-18): a LOWER bound on the guest ticks until the pixel event that raises INT0, for the guest-time
    // gate (rtl/c31/periph/c31_guest_gate.sv). 0 = imminent or unknown (the gate then waits for exact time).
    output reg [23:0] int0_event_lb,
    output reg fault_sticky
);
    reg [15:0] control [0:11];
    reg divide_phase;
    reg [31:0] irq_remaining;
    wire [9:0] htotal = control[6][9:0];
    wire [8:0] vtotal = control[11][8:0];
    // Blank END may equal total (War Gods writes 0x98002A = 0x98002B = 0x1B0, MAME 0.289 wargods watchpoint log
    // 2026-09-24): MAME's visarea is (total + start - end) % total (midvunit_v.cpp video_control_w), well defined for
    // end == total, and its scanline timer never depends on the blanking registers. Requiring end < total left the
    // War Gods raster unconfigured -> no pixel events -> no INT0 ever (the POST vblank wait 0x0073 then times out).
    wire configured = (htotal != 0) && (vtotal != 0) &&
        (control[2][9:0] < htotal) && (control[5][9:0] <= htotal) &&
        (control[7][8:0] < vtotal) && (control[10][8:0] <= vtotal);
    // MAME visible extent: (total + blank_start - blank_end) % total + 1.
    // With blank_start < total and blank_end <= total the span lies in [0, 2*total), so one conditional
    // subtraction replaces general modulo/division hardware.
    wire [10:0] hspan = {1'b0,htotal}+{1'b0,control[2][9:0]}-{1'b0,control[5][9:0]};
    wire [9:0] vspan = {1'b0,vtotal}+{1'b0,control[7][8:0]}-{1'b0,control[10][8:0]};
    wire [10:0] visible_width = ((hspan >= htotal) ? hspan-htotal : hspan)+1'b1;
    wire [9:0] visible_height = ((vspan >= vtotal) ? vspan-vtotal : vspan)+1'b1;
    wire raw_hsync = (control[3][9:0] <= control[4][9:0]) ?
        ((raster_x >= control[3][9:0]) && (raster_x < control[4][9:0])) :
        ((raster_x >= control[3][9:0]) || (raster_x < control[4][9:0]));
    wire raw_vsync = (control[8][8:0] <= control[9][8:0]) ?
        ((raster_y >= control[8][8:0]) && (raster_y < control[9][8:0])) :
        ((raster_y >= control[8][8:0]) || (raster_y < control[9][8:0]));
    assign csync = (raw_hsync | raw_vsync) ^ control[0][10];
    assign hsync = control[0][13] ? csync : (raw_hsync ^ control[0][11]);
    assign vsync = control[0][14] ? csync : (raw_vsync ^ control[0][12]);
    assign raster_de = configured && (raster_x < visible_width) && (raster_y < visible_height);
    assign pixel_event = !reset && !counter_reset && guest_ce && video_ce && configured &&
                         (!control[0][15] || divide_phase);
    assign frame_event = pixel_event && (raster_x >= htotal-1'b1) && (raster_y >= vtotal-1'b1);
    assign irq_int0 = irq_remaining != 0;
    wire [9:0] next_line = (raster_y >= vtotal-1'b1) ? 10'd0 : {1'b0,raster_y}+1'b1;

    // ---- stage 2: distance to the next INT0, in pixel events (a lower bound on guest ticks) ----
    // INT0 is raised by the pixel event of the last pixel of line L = control[0][8:0] (the event where next_line ==
    // L + 1, below), so the pixel events still to come, that one included, are ((L - y) mod vtotal) * htotal +
    // (htotal - x). Every pixel event needs a guest tick (guest_ce), so that count bounds the ticks from below; a
    // half-rate raster (control[0][15]) only needs more. No INT0 is ever raised when L + 1 >= vtotal (next_line wraps
    // to 0) or the raster is unconfigured. Two register stages: the position they used can be two pixels stale (one
    // pixel event per clock at most), so the output is lowered by LB_DEPTH, and it reads 0 for LB_DEPTH clocks after
    // any control write or counter reset (the stale value could describe the old schedule).
    localparam integer LB_DEPTH = 3;
    wire [8:0] irq_line = control[0][8:0];
    wire int0_possible = configured && ({1'b0,irq_line} + 10'd1 < {1'b0,vtotal});
    reg [9:0] lb_lines, lb_pixels, lb_htotal;
    reg lb_possible;
    reg [1:0] lb_quiet;
    reg [20:0] lb_count;
    always @(posedge clk) begin
        lb_lines    <= (raster_y <= irq_line) ? {1'b0, irq_line - raster_y} : {1'b0, irq_line} + {1'b0, vtotal} - {1'b0, raster_y};
        lb_pixels   <= htotal - raster_x;
        lb_htotal   <= htotal;
        lb_possible <= int0_possible;
        lb_count    <= lb_lines * lb_htotal + {11'd0, lb_pixels};
        if (reset || wr_valid || counter_reset) lb_quiet <= 2'd3;
        else if (lb_quiet != 2'd0) lb_quiet <= lb_quiet - 2'd1;
        if (reset || wr_valid || counter_reset || lb_quiet != 2'd0) int0_event_lb <= 24'd0;
        else if (!lb_possible) int0_event_lb <= 24'hffffff;
        else int0_event_lb <= (lb_count > LB_DEPTH) ? {3'd0, lb_count - LB_DEPTH[20:0]} : 24'd0;
    end
    integer j;
    always @(posedge clk) begin
        if (reset) begin
            for (j=0;j<12;j=j+1) control[j] <= 0;
            raster_x <= 0; raster_y <= 0; divide_phase <= 0;
            irq_remaining <= 0; fault_sticky <= 0;
        end else begin
            if (wr_valid) begin
                if (wr_index == 0) begin
                    control[0] <= wr_data;
                    if (wr_data[9]) fault_sticky <= 1;
                end else if (wr_index < 7) control[wr_index] <= {6'b0,wr_data[9:0]};
                else if (wr_index < 12) control[wr_index] <= {7'b0,wr_data[8:0]};
                else fault_sticky <= 1;
            end
            if (guest_ce) begin
                if (irq_remaining != 0) irq_remaining <= irq_remaining-1'b1;
                if (video_ce) divide_phase <= control[0][15] ? !divide_phase : 1'b0;
                if (pixel_event) begin
                    if (raster_x >= htotal-1'b1) begin
                        raster_x <= 0;
                        raster_y <= next_line[8:0];
                        if (next_line == {1'b0,control[0][8:0]}+1'b1)
                            irq_remaining <= IRQ_PULSE_GUEST_STEPS;
                    end else raster_x <= raster_x+1'b1;
                end
            end
            if (counter_reset) begin
                raster_x <= 0; raster_y <= 0; divide_phase <= 0; irq_remaining <= 0;
            end
        end
    end
endmodule
