// SPDX-License-Identifier: BSD-3-Clause
// Coherent native-raster pixel capture from external framebuffer and palette.
// RGB_PROFILE=0: MAME 5:5:5; =1: low24 RGB hypothesis from original source.
// This module has one pixel of buffering, not a physical presentation surface.
module vunit_scanout #(
    parameter integer RGB_PROFILE=0
) (
    input wire clk, reset,
    input wire pixel_event, frame_event,
    input wire [63:0] pixel_tick,
    input wire [9:0] raster_x,
    input wire [8:0] raster_y,
    input wire raster_de, hsync, vsync, csync, display_page,
    input wire [31:0] palette_epoch,
    output wire fb_read_req_valid,
    input wire fb_read_req_ready,
    output wire [18:0] fb_read_req_addr,
    input wire fb_read_rsp_valid,
    output wire fb_read_rsp_ready,
    input wire [15:0] fb_read_rsp_data,
    output wire pal_read_req_valid,
    input wire pal_read_req_ready,
    output wire [14:0] pal_read_req_addr,
    input wire pal_read_rsp_valid,
    output wire pal_read_rsp_ready,
    input wire [31:0] pal_read_rsp_data,
    output wire rgb_valid,
    input wire rgb_ready,
    output reg [23:0] rgb_data,
    output reg [9:0] rgb_x,
    output reg [8:0] rgb_y,
    output reg rgb_de, rgb_hsync, rgb_vsync, rgb_csync, rgb_page, rgb_frame_end,
    output reg [31:0] rgb_palette_epoch, rgb_frame_sequence,
    output reg [63:0] rgb_tick,
    // Optional physical consumer deadline. When asserted, this edge must accept
    // one ready RGB sample. Tie low for elastic capture, not native-rate proof.
    input wire deadline_event,
    output wire scanout_memory_wait,
    output wire halted,
    output reg [2:0] fault_sticky,
    output reg [63:0] fault_tick
);
    localparam [2:0] IDLE=0, FB_REQUEST=1, FB_RESPONSE=2,
                     PAL_REQUEST=3, PAL_RESPONSE=4, OUTPUT_PIXEL=5, HALT=6;
    reg [2:0] state;
    reg [14:0] palette_index;
    reg [31:0] frame_sequence;
    wire output_accept = !reset && (state==OUTPUT_PIXEL) && rgb_ready;
    wire can_capture = (state==IDLE) || output_accept;
    assign halted = state==HALT;
    assign fb_read_req_valid = !reset && (state==FB_REQUEST);
    assign fb_read_req_addr = {rgb_page,rgb_y,rgb_x[8:0]};
    assign fb_read_rsp_ready = !reset && (state==FB_RESPONSE);
    assign pal_read_req_valid = !reset && (state==PAL_REQUEST);
    assign pal_read_req_addr = palette_index;
    assign pal_read_rsp_ready = !reset && (state==PAL_RESPONSE);
    assign rgb_valid = !reset && (state==OUTPUT_PIXEL);
    assign scanout_memory_wait = (state!=IDLE) && !output_accept;

    // Payload storage is private while rgb_valid is low. Retire/clear the
    // old RGB word using local ownership, independently of guest pixel_event.
    // A same-edge fault still takes priority in the unchanged state machine,
    // so a speculative palette load during a fault cannot publish a sample.
    always @(posedge clk) begin
        if(reset) rgb_data<=0;
        else if(state==IDLE || output_accept) rgb_data<=0;
        else if(state==PAL_RESPONSE && pal_read_rsp_valid) begin
            if(RGB_PROFILE==0)
                rgb_data<={pal_read_rsp_data[14:10],pal_read_rsp_data[14:12],
                           pal_read_rsp_data[9:5],pal_read_rsp_data[9:7],
                           pal_read_rsp_data[4:0],pal_read_rsp_data[4:2]};
            else rgb_data<=pal_read_rsp_data[23:0];
        end
    end

    always @(posedge clk) begin
        if(reset) begin
            state<=IDLE;palette_index<=0;frame_sequence<=0;
            rgb_x<=0;rgb_y<=0;rgb_de<=0;rgb_hsync<=0;rgb_vsync<=0;rgb_csync<=0;
            rgb_page<=0;rgb_frame_end<=0;rgb_palette_epoch<=0;rgb_frame_sequence<=0;rgb_tick<=0;
            fault_sticky<=0;fault_tick<=0;
        end else if(state!=HALT) begin
            // Reject loss/reordering before touching another external transaction.
            if(pixel_event && !can_capture) begin
                fault_sticky[0]<=1;fault_tick<=pixel_tick;state<=HALT;
            end else if(deadline_event && !output_accept) begin
                fault_sticky[1]<=1;fault_tick<=(state==IDLE)?pixel_tick:rgb_tick;state<=HALT;
            end else if(pixel_event && raster_de && raster_x[9]) begin
                fault_sticky[2]<=1;fault_tick<=pixel_tick;state<=HALT;
            end else begin
                case(state)
                    FB_REQUEST: if(fb_read_req_ready) state<=FB_RESPONSE;
                    FB_RESPONSE: if(fb_read_rsp_valid) begin
                        palette_index<=fb_read_rsp_data[14:0];state<=PAL_REQUEST;
                    end
                    PAL_REQUEST: if(pal_read_req_ready) state<=PAL_RESPONSE;
                    PAL_RESPONSE: if(pal_read_rsp_valid) begin
                        state<=OUTPUT_PIXEL;
                    end
                    OUTPUT_PIXEL: if(rgb_ready) state<=IDLE;
                    default: begin end
                endcase
                if(pixel_event && can_capture) begin
                    rgb_x<=raster_x;rgb_y<=raster_y;rgb_de<=raster_de;
                    rgb_hsync<=hsync;rgb_vsync<=vsync;rgb_csync<=csync;
                    rgb_page<=display_page;rgb_palette_epoch<=palette_epoch;rgb_tick<=pixel_tick;
                    rgb_frame_sequence<=frame_sequence;rgb_frame_end<=frame_event;
                    if(frame_event) frame_sequence<=frame_sequence+1'b1;
                    state<=raster_de?FB_REQUEST:OUTPUT_PIXEL;
                end
            end
        end
    end
endmodule
