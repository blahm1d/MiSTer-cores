// SPDX-License-Identifier: BSD-3-Clause
// C31 word-addressed CPU windows to an external byte-addressed memory service.
// Palette storage as a 32-bit word is an explicit prototype hypothesis.
// Reset requires the external service to cancel the matching transaction epoch.
module vunit_cpu_memory #(
    parameter integer FACTORED_CAPTURE_WAIT=0
) (
    input  wire        clk,
    input  wire        reset,
    input  wire        bus_ce,
    input  wire        req_valid,
    // Optional address-independent admission for the IDLE wait predicate.
    // The caller must prove equivalence after address_hit qualification.
    input  wire        capture_wait_intent,
    output wire        req_ready,
    input  wire        req_write,
    input  wire [23:0] req_addr,
    input  wire [31:0] req_wdata,
    output wire [31:0] req_rdata,
    output wire        mem_req_valid,
    input  wire        mem_req_ready,
    output reg         mem_req_write,
    output reg  [1:0]  mem_req_region,
    output reg  [21:0] mem_req_addr,
    output reg  [31:0] mem_req_wdata,
    output reg  [3:0]  mem_req_be,
    input  wire        mem_rsp_valid,
    output wire        mem_rsp_ready,
    input  wire [31:0] mem_rsp_rdata,
    output wire        busy,
    output wire        guest_memory_wait
);
    localparam [1:0] IDLE=0, REQUEST=1, RESPONSE=2, REPLY=3;
    reg [1:0] state;
    reg narrow_reply;
    reg [31:0] saved_reply;

    wire framebuffer_hit = (req_addr >= 24'h900000) && (req_addr <= 24'h97ffff);
    wire texture_hit = (req_addr >= 24'ha00000) && (req_addr <= 24'hbfffff);
    wire palette_hit = (req_addr >= 24'h9e0000) && (req_addr <= 24'h9e7fff);
    wire address_hit = framebuffer_hit || texture_hit || palette_hit;

    // This is a completion-style CPU interface: the initial request is captured
    // while ready is low, and its eventual ready pulse retires that same request.
    // The caller holds valid until completion; payload changes cannot alter it.
    assign req_ready = !reset && bus_ce && (state == REPLY);
    assign req_rdata = saved_reply;
    assign mem_req_valid = !reset && (state == REQUEST);
    assign mem_rsp_ready = !reset && (state == RESPONSE);
    assign busy = (state != IDLE);
    wire wait_capture_admitted = FACTORED_CAPTURE_WAIT ? capture_wait_intent : (req_valid && bus_ce);
    assign guest_memory_wait = (state == REQUEST) || (state == RESPONSE) ||
        ((state == IDLE) && wait_capture_admitted && address_hit && !reset);

    always @(posedge clk) begin
        if (reset) begin
            state <= IDLE;
            narrow_reply <= 0;
            saved_reply <= 0;
            mem_req_write <= 0;
            mem_req_region <= 0;
            mem_req_addr <= 0;
            mem_req_wdata <= 0;
            mem_req_be <= 0;
        end else begin
            case (state)
                IDLE: if (req_valid && bus_ce && address_hit) begin
                    mem_req_write <= req_write;
                    narrow_reply <= !palette_hit;
                    mem_req_wdata <= palette_hit ? req_wdata : {16'b0,req_wdata[15:0]};
                    mem_req_be <= palette_hit ? 4'b1111 : 4'b0011;
                    if (framebuffer_hit) begin
                        mem_req_region <= 0;
                        mem_req_addr <= {2'b0,req_addr[18:0],1'b0};
                    end else if (texture_hit) begin
                        mem_req_region <= 1;
                        mem_req_addr <= {req_addr[20:0],1'b0};
                    end else begin
                        mem_req_region <= 2;
                        mem_req_addr <= {5'b0,req_addr[14:0],2'b0};
                    end
                    state <= REQUEST;
                end
                REQUEST: if (mem_req_ready) state <= RESPONSE;
                RESPONSE: if (mem_rsp_valid) begin
                    saved_reply <= narrow_reply ? {16'b0,mem_rsp_rdata[15:0]} : mem_rsp_rdata;
                    state <= REPLY;
                end
                REPLY: if (req_valid && bus_ce) state <= IDLE;
                default: state <= IDLE;
            endcase
        end
    end
endmodule
