`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_fb_present.sv -- direct framebuffer presentation for the Cruis'n master core (gm1).
//
// Shows the V-unit's displayed page exactly as MAME's screen_update builds its bitmap (midvunit_v.cpp:544-579):
//   base   = (page_control & 1) ? videoram word 0x40000 : 0            (:559)
//   pixel  = m_videoram[base + y * 512 + x] & 0x7fff                   (:571-576) -> a palette index
//   colour = the palette pen of that index (paletteram_w, :505-510: pal5bit of RGB555)
// It reads the framebuffer page in DDR3 one line ahead of a fixed real-time raster, in bursts, into two block-RAM line
// banks, and looks every pixel up in gm1_palette_ram. NOTHING HERE WAITS ON GUEST TIME AND NOTHING HERE STOPS IT.
//
// Why (docs/PLAN-A1D-PIPELINE-20260917.md section 000, bandwidth/gm1/RESUME.md 2026-09-18): the hybrid-era path it
// replaces -- vunit_scanout (one pixel of buffering, a framebuffer read and a palette read per pixel IN GUEST TIME) ->
// vunit_presentation (captures each native frame into an RGB32 DDR3 surface with single-beat writes, then refuses new
// pixels until the real-time side swaps surfaces at its vblank) -> vunit_surface_scanout (reads the RGB32 surface back)
// -- froze the whole virtual board on every pixel, every capture write and every surface swap
// (gm1_engine.sv board_guest_run <- scanout_memory_wait), and crossed DDR3 three times per displayed pixel (16-bit
// read + 32-bit write + 32-bit read, ~116 MB/s at 57.9 Hz). This path reads 16 bits per displayed pixel once (~24 MB/s).
//
// Deliberate, display-only differences from the captured native raster (never guest-visible: the guest cannot read
// any of this): the page is latched once per OUTPUT frame at its vertical blank (a flip shows from the next output
// frame, never mid-frame), and a line reflects the framebuffer when it was fetched, one line ahead.
//
// The line-bank fetch engine (generations, bank ownership, burst accounting, catch-up) is forked from
// rtl/presentation/vunit_surface_scanout.sv, which shipped on the cabinet from gm1 r4; its RGB32 surface became the
// 16-bit framebuffer page (four pixels per 64-bit beat) and a palette stage was added.
module gm1_fb_present #(
    parameter integer WIDTH=512, HEIGHT=400, H_TOTAL=666, V_TOTAL=432,
    parameter integer H_SYNC_START=526, H_SYNC_END=551, V_SYNC_START=401, V_SYNC_END=404,
    parameter integer PIXEL_DIVIDER=3, BURST_BEATS=8,
    parameter [31:0]  LINE_BYTES=32'd1024,      // 512 16-bit pixels per videoram row (midvunit_v.cpp:576)
    parameter [31:0]  PAGE_BYTES=32'h00080000   // page 1 at videoram word 0x40000 (midvunit_v.cpp:559)
) (
    input  wire        clk, reset,
    input  wire        enable,                  // DDR3 path configured and the game running
    input  wire [31:0] fb_base,                 // byte address of videoram word 0 in DDR3
    input  wire        display_page,            // V-unit page_control bit 0
    // After the guest releases our scanned page, defer its reuse until output vblank.
    output wire        protect_page,
    output reg         protected_page,
    // palette (gm1_palette_ram registered read port)
    output reg  [14:0] pal_addr,
    input  wire [15:0] pal_word,                // {valid, RGB555}
    // Avalon read master (a DDR3 mux client)
    output wire        scan_read,
    output wire [31:0] scan_address,
    output wire [7:0]  scan_byteenable,
    output wire [3:0]  scan_burstcount,
    input  wire        scan_waitrequest, scan_readdatavalid,
    input  wire [63:0] scan_readdata,
    input  wire        scan_read_error,
    // video
    output reg         video_ce, video_de, video_hsync, video_vsync,
    output reg  [7:0]  video_r, video_g, video_b,
    // status
    output reg  [63:0] underrun_pixels, physical_frames,
    output reg  [7:0]  scan_fault
);
    localparam integer LINE_BEATS = WIDTH / 4;
    localparam integer BEAT_W  = LINE_BEATS < 2 ? 1 : $clog2(LINE_BEATS);
    localparam integer COUNT_W = $clog2(LINE_BEATS + 1);
    localparam integer DIV_W   = PIXEL_DIVIDER < 2 ? 1 : $clog2(PIXEL_DIVIDER);

    reg [DIV_W-1:0] divider_phase;
    reg [9:0] raster_x;
    reg [8:0] raster_y;
    wire pixel_due    = divider_phase == PIXEL_DIVIDER - 1;
    wire active_pixel = raster_x < WIDTH && raster_y < HEIGHT;
    wire blank_entry  = pixel_due && raster_x == 0 && raster_y == HEIGHT;
    reg  [31:0] front_base, stream_generation;
    reg page_released;
    assign protect_page = enable && (page_released || display_page != protected_page);

    (* ramstyle = "M10K, no_rw_check" *) reg [63:0] line0 [0:LINE_BEATS-1];
    (* ramstyle = "M10K, no_rw_check" *) reg [63:0] line1 [0:LINE_BEATS-1];
    reg [1:0]  bank_owned, bank_complete;
    reg [8:0]  bank_line0, bank_line1;
    reg [31:0] bank_generation0, bank_generation1;
    reg        fill_active, fill_bank;
    reg [8:0]  fill_line;
    reg [COUNT_W-1:0] fill_count;
    reg [9:0]  next_line;
    // Horizontal blank makes the previous line reusable. Vertical blank starts line zero; blank_entry invalidates
    // all banks and advances the generation.
    wire [9:0] needed_line = raster_y >= HEIGHT ? 10'd0 :
        (raster_x >= WIDTH ? {1'b0, raster_y} + 10'd1 : {1'b0, raster_y});
    wire [9:0] issue_line = next_line < needed_line ? needed_line : next_line;
    wire issue_bank = issue_line[0];
    wire issue_bank_free = issue_bank ?
        (!bank_owned[1] || bank_generation1 != stream_generation || {1'b0, bank_line1} < needed_line) :
        (!bank_owned[0] || bank_generation0 != stream_generation || {1'b0, bank_line0} < needed_line);
    wire [COUNT_W:0] remaining_line = LINE_BEATS - fill_count;
    wire [3:0] new_burstcount = remaining_line < BURST_BEATS ? remaining_line[3:0] : BURST_BEATS[3:0];

    reg        command_valid, command_bank;
    reg [31:0] command_address, command_generation;
    reg [8:0]  command_line;
    reg [BEAT_W-1:0] command_offset;
    reg [3:0]  command_count;
    reg [3:0]  responses_left;
    reg        pending_bank;
    reg [31:0] pending_generation;
    reg [8:0]  pending_line;
    reg [BEAT_W-1:0] pending_offset;
    wire read_pending        = responses_left != 0;
    wire offered_read        = !reset && enable && command_valid;
    wire command_accept      = offered_read && !scan_waitrequest;
    wire response_expected   = read_pending || command_accept;
    wire unexpected_response = scan_readdatavalid && !response_expected;
    wire error_response      = scan_readdatavalid && scan_read_error;
    wire protocol_error      = unexpected_response || error_response;
    wire publication_safe    = enable && scan_fault == 0 && !protocol_error;
    wire scan_idle           = !command_valid && !read_pending;
    assign scan_read       = offered_read;
    assign scan_address    = command_address;
    assign scan_byteenable = 8'hff;
    assign scan_burstcount = command_count;
    wire response_bank = read_pending ? pending_bank : command_bank;
    wire [31:0] response_generation = read_pending ? pending_generation : command_generation;
    wire [8:0]  response_line   = read_pending ? pending_line : command_line;
    wire [BEAT_W-1:0] response_offset = read_pending ? pending_offset : command_offset;
    // An offer reserves every consecutive slot in one bank before acceptance. Old/late responses drain but cannot
    // complete or overwrite a live line.
    wire store_response = publication_safe && scan_readdatavalid && response_expected && !blank_entry &&
        fill_active && response_generation == stream_generation && response_bank == fill_bank &&
        response_line == fill_line && {1'b0, response_line} >= needed_line &&
        response_offset == fill_count && fill_count < LINE_BEATS;

    // Line-bank read of the coordinate the next pixel edge publishes (valid from the first clock of that pixel).
    wire [9:0] read_x = pixel_due ? (raster_x == H_TOTAL - 1 ? 10'd0 : raster_x + 10'd1) : raster_x;
    wire [8:0] read_y = (pixel_due && raster_x == H_TOTAL - 1) ?
        (raster_y == V_TOTAL - 1 ? 9'd0 : raster_y + 9'd1) : raster_y;
    wire [BEAT_W-1:0] read_offset = read_x < WIDTH ? read_x[BEAT_W+1:2] : {BEAT_W{1'b0}};
    reg [63:0] line_q0, line_q1;
    reg [1:0]  line_q_valid;
    reg [8:0]  line_q_y;
    reg [BEAT_W-1:0] line_q_offset;
    reg [31:0] line_q_generation;
    always @(posedge clk) begin
        line_q0 <= line0[read_offset];
        line_q1 <= line1[read_offset];
        if (store_response && !reset) begin
            if (response_bank) line1[response_offset] <= scan_readdata;
            else               line0[response_offset] <= scan_readdata;
        end
    end
    wire [63:0] selected_beat = raster_y[0] ? line_q1 : line_q0;
    // Little-endian beat: pixel 4k+i at bits [16i+15:16i] (byte address = pixel index * 2).
    wire [15:0] selected_pixel = selected_beat[{raster_x[1:0], 4'd0} +: 16];
    wire pixel_available = publication_safe && line_q_valid[raster_y[0]] &&
        line_q_generation == stream_generation && line_q_y == raster_y && line_q_offset == raster_x[BEAT_W+1:2];

    // Palette stage. Pixel x's line word is in line_q from the pixel's first clock (phase 0); pal_addr registers it
    // on the next edge and gm1_palette_ram answers one edge later, so pal_word holds x's pen in phase 2, which is the
    // publishing phase when PIXEL_DIVIDER == 3 (the $fatal below requires >= 3). pixel_available is re-evaluated in
    // the publishing phase: line_q still holds x there (read_x only advances on the publishing clock).
    always @(posedge clk) pal_addr <= selected_pixel[14:0];   // & 0x7fff (midvunit_v.cpp:575)
    wire [14:0] pen = pal_word[14:0];

    always @(posedge clk) begin
        if (reset) begin
            divider_phase <= 0; raster_x <= 0; raster_y <= HEIGHT[8:0];
            video_ce <= 0; video_de <= 0; video_hsync <= 1; video_vsync <= 1;
            video_r <= 0; video_g <= 0; video_b <= 0;
            underrun_pixels <= 0; physical_frames <= 0;
            protected_page <= 0; page_released <= 0;
            front_base <= 0; stream_generation <= 0; next_line <= 0; bank_owned <= 0; bank_complete <= 0;
            bank_line0 <= 0; bank_line1 <= 0; bank_generation0 <= 0; bank_generation1 <= 0;
            fill_active <= 0; fill_bank <= 0; fill_line <= 0; fill_count <= 0;
            command_valid <= 0; command_bank <= 0; command_address <= 0; command_generation <= 0;
            command_line <= 0; command_offset <= 0; command_count <= 0; responses_left <= 0;
            pending_bank <= 0; pending_generation <= 0; pending_line <= 0; pending_offset <= 0;
            line_q_valid <= 0; line_q_y <= 0; line_q_offset <= 0; line_q_generation <= 0; scan_fault <= 0;
        end else begin
            line_q_y <= read_y; line_q_offset <= read_offset; line_q_generation <= stream_generation;
            line_q_valid[0] <= bank_complete[0] && bank_generation0 == stream_generation && bank_line0 == read_y;
            line_q_valid[1] <= bank_complete[1] && bank_generation1 == stream_generation && bank_line1 == read_y;
            // Raster and sync never wait for memory, configuration or the guest.
            video_ce <= pixel_due;
            if (pixel_due) begin
                divider_phase <= 0; video_de <= active_pixel;
                video_hsync <= !(raster_x >= H_SYNC_START && raster_x < H_SYNC_END);
                video_vsync <= !(raster_y >= V_SYNC_START && raster_y < V_SYNC_END);
                video_r <= 0; video_g <= 0; video_b <= 0;
                if (active_pixel) begin
                    if (pixel_available) begin
                        if (pal_word[15]) begin   // pal5bit: {v[4:0], v[4:2]} per channel
                            video_r <= {pen[14:10], pen[14:12]};
                            video_g <= {pen[9:5],   pen[9:7]};
                            video_b <= {pen[4:0],   pen[4:2]};
                        end                       // an entry the CPU never wrote is black (MAME's zeroed palette)
                    end else if (enable) underrun_pixels <= underrun_pixels + 64'd1;
                end
                if (raster_x == H_TOTAL - 1) begin
                    raster_x <= 0;
                    if (raster_y == V_TOTAL - 1) begin raster_y <= 0; physical_frames <= physical_frames + 64'd1; end
                    else raster_y <= raster_y + 9'd1;
                end else raster_x <= raster_x + 10'd1;
            end else divider_phase <= divider_phase + 1'b1;

            if (display_page != protected_page) page_released <= 1;
            if (blank_entry) begin
                protected_page <= display_page; page_released <= 0;
                // One page per output frame: latch the displayed page for the frame that starts after this blank.
                front_base <= fb_base + (display_page ? PAGE_BYTES : 32'd0);
                stream_generation <= stream_generation + 32'd1; next_line <= 0;
                bank_owned <= 0; bank_complete <= 0; fill_active <= 0; fill_count <= 0; line_q_valid <= 0;
            end else begin
                if (store_response) begin
                    fill_count <= fill_count + 1'b1;
                    if (fill_count == LINE_BEATS - 1) begin
                        bank_complete[response_bank] <= 1'b1; fill_active <= 0;
                    end
                end
                // Expired partial lines are abandoned only after all burst responses drain. Catch up to the live
                // raster, never replay it.
                if (scan_idle && fill_active && {1'b0, fill_line} < needed_line) begin
                    fill_active <= 0; bank_owned[fill_bank] <= 0; bank_complete[fill_bank] <= 0; fill_count <= 0;
                end
                if (publication_safe && scan_idle) begin
                    if (!fill_active && issue_line < HEIGHT && issue_bank_free) begin
                        fill_active <= 1; fill_bank <= issue_bank; fill_line <= issue_line[8:0]; fill_count <= 0;
                        next_line <= issue_line + 1'b1; bank_owned[issue_bank] <= 1'b1; bank_complete[issue_bank] <= 1'b0;
                        if (issue_bank) begin bank_line1 <= issue_line[8:0]; bank_generation1 <= stream_generation; end
                        else            begin bank_line0 <= issue_line[8:0]; bank_generation0 <= stream_generation; end
                    end else if (fill_active && {1'b0, fill_line} >= needed_line && fill_count < LINE_BEATS) begin
                        command_valid <= 1;
                        command_address <= front_base + fill_line * LINE_BYTES + ({{(32-COUNT_W){1'b0}}, fill_count} << 3);
                        command_bank <= fill_bank; command_line <= fill_line; command_generation <= stream_generation;
                        command_offset <= fill_count[BEAT_W-1:0]; command_count <= new_burstcount;
                    end
                end
            end
            // Transport accounting continues through late generations and faults.
            if (scan_readdatavalid && read_pending) begin
                responses_left <= responses_left - 1'b1; pending_offset <= pending_offset + 1'b1;
            end
            if (command_accept) begin
                command_valid <= 0; pending_bank <= command_bank; pending_line <= command_line;
                pending_generation <= command_generation;
                responses_left <= command_count - (scan_readdatavalid ? 4'd1 : 4'd0);
                pending_offset <= command_offset + (scan_readdatavalid ? 1'b1 : 1'b0);
            end
            if (protocol_error && scan_fault == 0) scan_fault <= unexpected_response ? 8'd1 : 8'd2;
        end
    end
`ifndef SYNTHESIS
    initial begin
        if (WIDTH < 4 || WIDTH > 512 || WIDTH % 4 || HEIGHT < 1 || HEIGHT > 511 ||
            H_TOTAL <= WIDTH || H_TOTAL > 1024 || V_TOTAL <= HEIGHT || V_TOTAL > 512 ||
            H_SYNC_START < WIDTH || H_SYNC_END <= H_SYNC_START || H_SYNC_END > H_TOTAL ||
            V_SYNC_START < HEIGHT || V_SYNC_END <= V_SYNC_START || V_SYNC_END > V_TOTAL ||
            PIXEL_DIVIDER < 3 || BURST_BEATS < 1 || BURST_BEATS > 8)
            $fatal(1, "gm1_fb_present: unsupported geometry, divider (>= 3) or burst size");
    end
`endif
endmodule
// Gate only unaccepted framebuffer writes. Read/texture/palette traffic and already
// owned DDR transactions retain their original handshake and ordering.
module gm1_fb_write_guard (
    input wire protect_page, protected_page,
    input wire fb_valid, input wire [18:0] fb_addr,
    input wire memory_fb_ready,
    output wire memory_fb_valid, fb_ready,
    input wire cpu_valid, cpu_write, input wire [1:0] cpu_region,
    input wire [21:0] cpu_addr, input wire memory_cpu_ready,
    output wire memory_cpu_valid, cpu_ready
);
    wire block_fb = protect_page && fb_addr[18] == protected_page;
    wire block_cpu = protect_page && cpu_write && cpu_region == 0 &&
                     cpu_addr[21:20] == 0 && cpu_addr[19] == protected_page;
    assign memory_fb_valid = fb_valid && !block_fb;
    assign fb_ready = memory_fb_ready && !block_fb;
    assign memory_cpu_valid = cpu_valid && !block_cpu;
    assign cpu_ready = memory_cpu_ready && !block_cpu;
endmodule
`default_nettype wire
