`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_palette_ram.sv -- the V-unit palette as the display sees it: 32,768 x {valid, RGB555} in block RAM (524,288 bits),
// one write port for committed CPU palette writes and one REGISTERED read port for the direct framebuffer presenter
// (gm1_fb_present), one lookup per clock, fixed one-clock latency.
//
// Forked from rtl/memory/vunit_palette_cache.sv (same storage, same write semantics) without its lookup FSM and DDR3
// miss path. Why no miss path: an entry is valid once the CPU has written it, and every CPU palette write is snooped
// here (palette_write_commit). An entry the CPU never wrote reads as black, which is MAME's value: the palette RAM is
// zero-initialised and pens are only set by paletteram_w (midvunit_v.cpp:505-510, set_pen_color on write). The C31 has
// no byte addressing, so its palette writes are full words; a partial low-word write (never issued by the C31) still
// invalidates, exactly as the cache did, and then reads as black instead of fetching DDR3.
//
// Reset scrubs one entry per clock (32,768 clocks); `initialized` gates the guest bus exactly as before.
module gm1_palette_ram (
    input  wire        clk, reset,
    output reg         initialized,
    input  wire        write_valid,
    input  wire [14:0] write_addr,
    input  wire [31:0] write_data,
    input  wire [3:0]  write_be,
    input  wire [14:0] rd_addr,
    output reg  [15:0] rd_word          // {valid, RGB555} of rd_addr as of the previous clock
);
    (* ramstyle = "M10K, no_rw_check" *) reg [15:0] entries [0:32767];
    reg [14:0] scrub_index;
    reg        we;
    reg [14:0] wa;
    reg [15:0] wd;
    always @* begin
        we = 1'b0; wa = 15'd0; wd = 16'd0;
        if (!reset) begin
            if (!initialized) begin
                we = 1'b1; wa = scrub_index;
            end else if (write_valid && |write_be[1:0]) begin
                we = 1'b1; wa = write_addr;
                // Full low-word writes populate; partial low writes invalidate (vunit_palette_cache.sv semantics).
                if (write_be[1:0] == 2'b11) wd = {1'b1, write_data[14:0]};
            end
        end
    end
    always @(posedge clk) begin
        if (we) entries[wa] <= wd;
        rd_word <= entries[rd_addr];
    end
    always @(posedge clk) begin
        if (reset) begin
            initialized <= 1'b0; scrub_index <= 15'd0;
        end else if (!initialized) begin
            if (scrub_index == 15'h7fff) initialized <= 1'b1;
            else scrub_index <= scrub_index + 15'd1;
        end
    end
endmodule
`default_nettype wire
