// SPDX-License-Identifier: GPL-2.0-or-later
// gm1_dedither -- smart de-dither of the game's 50% black mesh panels (Cruis'n gm1 r22, 2026-09-23).
// The V-unit draws translucent panels (race-start flag girl, HUD map) as a 1-pixel black checkerboard (DMA_DITHER,
// midvunit_v.cpp render_flat); the arcade CRT merged the dots, a sharp TV shows a grid. Like the Genesis core's "smart
// de-dither", only true checkerboard pixels are blended: black(x) differs from BOTH horizontal neighbours AND from the
// pixel above; everything else (lines, text, edges) passes pixel-exact. Semantics defined by the independent golden
// bandwidth/gm1/dither/dedither_golden.py (gate check_dedither.py):
//   nb  = black(x) ? avg(p[x-1], p[x+1]) : p[x];   out = nb * K >> 8   K: 0 MAME 128, 1 SOFT 187, 2 DARK 90; 3 RAW = off
// Pixel stream = gm1_fb_present's (one pixel per ce; ce is at least 3 clocks apart, which the 1-clock-registered previous-
// line RAM read relies on). Output is the input delayed by exactly two ce, syncs delayed identically.
`default_nettype none
module gm1_dedither (
    input  wire        clk,
    input  wire        ce,
    input  wire [1:0]  mode,
    input  wire        de_i, hs_i, vs_i,
    input  wire [7:0]  r_i, g_i, b_i,
    output reg         de_o, hs_o, vs_o,
    output reg  [7:0]  r_o, g_o, b_o
);
    reg [23:0] w0, w1, w2;             // w0 newest (x+1), w1 centre (x), w2 left (x-1)
    reg        d0, d1, d2;             // DE of each
    reg        h0, h1, v0, v1;         // syncs aligned with w0 / w1
    reg [9:0]  xin, x0, x1;            // visible-pixel index of the input / w0 / w1
    // previous-line "was black" bits (1 x 1024, simple dual port, registered read)
    reg        lb [0:1023];
    reg [9:0]  rd_addr;
    reg        lb_q;
    integer i;
    initial for (i = 0; i < 1024; i = i + 1) lb[i] = 1'b0;
    always @(posedge clk) lb_q <= lb[rd_addr];
    wire bk0 = (w0 == 24'd0), bk1 = (w1 == 24'd0), bk2 = (w2 == 24'd0);
    wire blend = (mode != 2'd3) && d0 && d1 && d2 && (bk1 != bk2) && (bk1 != bk0) && (bk1 != lb_q);
    wire [8:0] sr = {1'b0, w2[23:16]} + {1'b0, w0[23:16]};
    wire [8:0] sg = {1'b0, w2[15:8]}  + {1'b0, w0[15:8]};
    wire [8:0] sb = {1'b0, w2[7:0]}   + {1'b0, w0[7:0]};
    wire [7:0] nr = bk1 ? sr[8:1] : w1[23:16];
    wire [7:0] ng = bk1 ? sg[8:1] : w1[15:8];
    wire [7:0] nbb = bk1 ? sb[8:1] : w1[7:0];
    wire [7:0] k = (mode == 2'd0) ? 8'd128 : (mode == 2'd1) ? 8'd187 : 8'd90;
    wire [15:0] pr = nr * k, pg = ng * k, pb = nbb * k;
    always @(posedge clk) begin
        if (ce) begin
            // output the centre pixel (w1) with the window as it stands before this shift
            de_o <= d1; hs_o <= h1; vs_o <= v1;
            if (blend) begin r_o <= pr[15:8]; g_o <= pg[15:8]; b_o <= pb[15:8]; end
            else       begin r_o <= w1[23:16]; g_o <= w1[15:8]; b_o <= w1[7:0]; end
            if (d1) lb[x1] <= bk1;                       // this line's state for the next line (after its use)
            // shift
            w2 <= w1; d2 <= d1;
            w1 <= w0; d1 <= d0; h1 <= h0; v1 <= v0; x1 <= x0;
            w0 <= {r_i, g_i, b_i}; d0 <= de_i; h0 <= hs_i; v0 <= vs_i; x0 <= xin;
            rd_addr <= x0;                                // w0 becomes the centre at the next ce: fetch its bit now
            xin <= de_i ? xin + 10'd1 : 10'd0;
        end
    end
    initial begin w0 = 0; w1 = 0; w2 = 0; d0 = 0; d1 = 0; d2 = 0; h0 = 0; h1 = 0; v0 = 0; v1 = 0; xin = 0; x0 = 0; x1 = 0;
                  rd_addr = 0; lb_q = 0; de_o = 0; hs_o = 0; vs_o = 0; r_o = 0; g_o = 0; b_o = 0; end
endmodule
`default_nettype wire
