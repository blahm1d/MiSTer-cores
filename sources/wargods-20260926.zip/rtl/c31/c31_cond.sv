// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 condition-code evaluation unit (Cruis'n USA fabric core).
//
// Blind transcription of the pinned MAME condition machinery:
//   ipp = references/snapshots/mamedev--mame/c662f9ca.../src/devices/cpu/tms320c3x/320c3x_ops.ipp
//   - condition-code bit positions C_LO..C_ZUF ....... ipp:131-149
//   - const uint32_t condition_table[0x80] ............ ipp:151-281
//   - bool condition(int which) = table[ST&0x7f]>>(which&31)&1 . ipp:303-306
//
// Behaviour: taken = (condition_table[flags] >> cond) & 1, where
//   flags = ST & 0x7F = {LUF,LV,UF,N,Z,V,C} (bit6..bit0), ipp:305, and
//   cond  = the 5-bit opcode condition field (which & 31), the bit index.
//
// The 128-entry table is transcribed as 32 "core" flag patterns (the
// {UF,N,Z,V,C}-dependent terms) combined with the four LV/LUF variants
// selected by flags[6:5] exactly as ipp lays the table out in four blocks
// of 32 (ipp lines 153-184 / 185-216 / 217-248 / 249-280). This is a
// verbatim factoring of the gospel data, NOT a re-derivation of the
// condition algebra; the exhaustive cross-diff gate (all 32 codes x 128
// flag patterns) proves every stored bit against the independent golden.
//
// REGOUT=0: pure combinational (single-LUT/M10K-ROM lookup).
// REGOUT=1: output registered on clk (one-cycle latency).

module c31_cond #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic [4:0]  cond,   // opcode condition field (which & 31)
    input  logic [6:0]  flags,  // ST & 0x7F  {LUF,LV,UF,N,Z,V,C}
    output logic        taken
);
    // Condition-code bit MASKS (ipp:131-149). Value = 1 << <bit position>.
    localparam logic [20:0] C_LO   = 21'd1 << 1;
    localparam logic [20:0] C_LS   = 21'd1 << 2;
    localparam logic [20:0] C_HI   = 21'd1 << 3;
    localparam logic [20:0] C_HS   = 21'd1 << 4;
    localparam logic [20:0] C_EQ   = 21'd1 << 5;
    localparam logic [20:0] C_NE   = 21'd1 << 6;
    localparam logic [20:0] C_LT   = 21'd1 << 7;
    localparam logic [20:0] C_LE   = 21'd1 << 8;
    localparam logic [20:0] C_GT   = 21'd1 << 9;
    localparam logic [20:0] C_GE   = 21'd1 << 10;
    localparam logic [20:0] C_NV   = 21'd1 << 12;
    localparam logic [20:0] C_V    = 21'd1 << 13;
    localparam logic [20:0] C_NUF  = 21'd1 << 14;
    localparam logic [20:0] C_UF   = 21'd1 << 15;
    localparam logic [20:0] C_NLV  = 21'd1 << 16;
    localparam logic [20:0] C_LV   = 21'd1 << 17;
    localparam logic [20:0] C_NLUF = 21'd1 << 18;
    localparam logic [20:0] C_LUF  = 21'd1 << 19;
    localparam logic [20:0] C_ZUF  = 21'd1 << 20;

    logic [20:0] core [0:31];
    logic [31:0] table_rom [0:127];   // upper 11 bits stay 0 so cond 21..31 read 0
    integer i;
    initial begin
        // 32 core patterns, indexed by {UF,N,Z,V,C} = i[4:0] (ipp:153-184
        // stripped of the NLV/NLUF terms that the block loop re-inserts).
        core[ 0] = 21'd1 | C_HI | C_HS | C_NE | C_GT | C_GE | C_NV | C_NUF;
        core[ 1] = 21'd1 | C_LO | C_LS | C_NE | C_GT | C_GE | C_NV | C_NUF;
        core[ 2] = 21'd1 | C_HI | C_HS | C_NE | C_GT | C_GE | C_V  | C_NUF;
        core[ 3] = 21'd1 | C_LO | C_LS | C_NE | C_GT | C_GE | C_V  | C_NUF;
        core[ 4] = 21'd1 | C_LS | C_HS | C_EQ | C_LE | C_GE | C_NV | C_NUF | C_ZUF;
        core[ 5] = 21'd1 | C_LO | C_LS | C_EQ | C_LE | C_GE | C_NV | C_NUF | C_ZUF;
        core[ 6] = 21'd1 | C_LS | C_HS | C_EQ | C_LE | C_GE | C_V  | C_NUF | C_ZUF;
        core[ 7] = 21'd1 | C_LO | C_LS | C_EQ | C_LE | C_GE | C_V  | C_NUF | C_ZUF;
        core[ 8] = 21'd1 | C_HI | C_HS | C_NE | C_LT | C_LE | C_NV | C_NUF;
        core[ 9] = 21'd1 | C_LO | C_LS | C_NE | C_LT | C_LE | C_NV | C_NUF;
        core[10] = 21'd1 | C_HI | C_HS | C_NE | C_LT | C_LE | C_V  | C_NUF;
        core[11] = 21'd1 | C_LO | C_LS | C_NE | C_LT | C_LE | C_V  | C_NUF;
        core[12] = 21'd1 | C_LS | C_HS | C_EQ | C_LT | C_LE | C_NV | C_NUF | C_ZUF;
        core[13] = 21'd1 | C_LO | C_LS | C_EQ | C_LT | C_LE | C_NV | C_NUF | C_ZUF;
        core[14] = 21'd1 | C_LS | C_HS | C_EQ | C_LT | C_LE | C_V  | C_NUF | C_ZUF;
        core[15] = 21'd1 | C_LO | C_LS | C_EQ | C_LT | C_LE | C_V  | C_NUF | C_ZUF;
        core[16] = 21'd1 | C_HI | C_HS | C_NE | C_GT | C_GE | C_NV | C_UF  | C_ZUF;
        core[17] = 21'd1 | C_LO | C_LS | C_NE | C_GT | C_GE | C_NV | C_UF  | C_ZUF;
        core[18] = 21'd1 | C_HI | C_HS | C_NE | C_GT | C_GE | C_V  | C_UF  | C_ZUF;
        core[19] = 21'd1 | C_LO | C_LS | C_NE | C_GT | C_GE | C_V  | C_UF  | C_ZUF;
        core[20] = 21'd1 | C_LS | C_HS | C_EQ | C_LE | C_GE | C_NV | C_UF  | C_ZUF;
        core[21] = 21'd1 | C_LO | C_LS | C_EQ | C_LE | C_GE | C_NV | C_UF  | C_ZUF;
        core[22] = 21'd1 | C_LS | C_HS | C_EQ | C_LE | C_GE | C_V  | C_UF  | C_ZUF;
        core[23] = 21'd1 | C_LO | C_LS | C_EQ | C_LE | C_GE | C_V  | C_UF  | C_ZUF;
        core[24] = 21'd1 | C_HI | C_HS | C_NE | C_LT | C_LE | C_NV | C_UF  | C_ZUF;
        core[25] = 21'd1 | C_LO | C_LS | C_NE | C_LT | C_LE | C_NV | C_UF  | C_ZUF;
        core[26] = 21'd1 | C_HI | C_HS | C_NE | C_LT | C_LE | C_V  | C_UF  | C_ZUF;
        core[27] = 21'd1 | C_LO | C_LS | C_NE | C_LT | C_LE | C_V  | C_UF  | C_ZUF;
        core[28] = 21'd1 | C_LS | C_HS | C_EQ | C_LT | C_LE | C_NV | C_UF  | C_ZUF;
        core[29] = 21'd1 | C_LO | C_LS | C_EQ | C_LT | C_LE | C_NV | C_UF  | C_ZUF;
        core[30] = 21'd1 | C_LS | C_HS | C_EQ | C_LT | C_LE | C_V  | C_UF  | C_ZUF;
        core[31] = 21'd1 | C_LO | C_LS | C_EQ | C_LT | C_LE | C_V  | C_UF  | C_ZUF;
        // Expand into all 128 entries: bit5=LV, bit6=LUF (ipp four-block layout).
        for (i = 0; i < 128; i = i + 1)
            table_rom[i] = {11'd0, core[i & 5'h1f]
                         | (i[5] ? C_LV  : C_NLV)
                         | (i[6] ? C_LUF : C_NLUF)};
    end

    logic taken_c;
    logic [31:0] entry;
    always_comb begin
        entry   = table_rom[flags];
        taken_c = entry[cond];   // cond in 21..31 selects a 0 bit -> not taken
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) taken <= taken_c;
    end else begin : g_comb
        assign taken = taken_c;
    end endgenerate
endmodule
