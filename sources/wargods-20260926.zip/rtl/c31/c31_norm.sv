// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 float normalize (NORM / norm, USE_FP=0).
// Blind transcription of ipp:831-873 (.../tms320c3x/320c3x_ops.ipp).
//
// exp==-128 or man==0 -> result {0,-128}, and UF|LUF iff man!=0. Else shift
// left by leading zeros (man>0) or leading ones (man<0), exp-=cnt; underflow
// (exp<=-128) -> {0,-128}, UF|LUF. The stored mantissa is NOT implicit-bit
// toggled (set_mantissa(man) directly). OR_NZF sets N/Z.
//
// NOTE on man==0xffffffff: MAME uses int32_t man and `man <<= cnt` with
// cnt=countl_one=32 (C++ UB). The golden (g++/x86) MEASURABLY yields 0 for
// man<<32 (not the count-masked no-op), so this unit uses the full 6-bit count
// (man<<32 = 0 in Verilog). The directed vector man=0xffffffff exercises it and
// the cross-diff against the golden confirms the resolution.

module c31_norm #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic [31:0] man,
    input  logic [7:0]  exp,
    input  logic [15:0] st_in,
    output logic [31:0] dman,
    output logic [7:0]  dexp,
    output logic [15:0] st_out
);
    `include "c31_lzc.svh"
    localparam logic [15:0] ZFLAG = 16'h0004;
    localparam logic [15:0] NFLAG = 16'h0008;
    localparam logic [15:0] UFFLAG = 16'h0010;
    localparam logic [15:0] LUFFLAG= 16'h0040;
    localparam logic [15:0] CLR_NZVUF = 16'h001E;

    logic [31:0] dman_c;
    logic [7:0]  dexp_c;
    logic        set_uf;
    logic [5:0]  cnt;
    logic signed [15:0] exp2;
    always_comb begin
        set_uf = 1'b0;
        cnt    = 6'd0;
        exp2   = {{8{exp[7]}}, exp};
        if (exp == 8'h80 || man == 32'd0) begin
            // ipp:840-841 set (0,-128) but ipp:870-871 (outside the if/else)
            // overwrite dst with the UNCHANGED local man/exp; only the UF|LUF
            // side effect (man!=0) survives. Transcribe that exact behaviour.
            dman_c = man; dexp_c = exp;
            if (man != 32'd0) set_uf = 1'b1;
        end else begin
            if (!man[31]) cnt = clz32(man);       // man > 0
            else          cnt = clo32(man);       // man < 0 (man==0xffffffff -> cnt=32)
            // The golden's `int32 man <<= cnt` with cnt=32 yields 0 (measured),
            // so use the full 6-bit count: man<<32 = 0 in Verilog.
            dman_c = man << cnt[5:0];
            exp2   = {{8{exp[7]}}, exp} - $signed({10'd0, cnt});
            if (exp2 <= -16'sd128) begin
                dman_c = 32'd0; exp2 = -16'sd128; set_uf = 1'b1;
            end
            dexp_c = exp2[7:0];
        end
    end

    logic [15:0] st_c;
    always_comb begin
        st_c = (st_in & ~CLR_NZVUF)
             | (dman_c[31] ? NFLAG : 16'd0)
             | ((dexp_c == 8'h80) ? ZFLAG : 16'd0)
             | (set_uf ? (UFFLAG | LUFFLAG) : 16'd0);
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin dman <= dman_c; dexp <= dexp_c; st_out <= st_c; end
    end else begin : g_comb
        assign dman = dman_c; assign dexp = dexp_c; assign st_out = st_c;
    end endgenerate
endmodule
