// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 float add / subtract (ADDF/SUBF, USE_FP=0). is_sub selects SUBF.
// Blind transcription of ipp:515-621 (addf) and ipp:633-736 (subf)
// (.../tms320c3x/320c3x_ops.ipp). The 3-operand and parallel forms reuse the
// same helper; only operand routing differs.
//
// PIPELINE (default TWOSTAGE=1): the datapath is split at the pre-normalise
// boundary so a pipeline register sits AFTER alignment+add and BEFORE
// renormalisation:
//   Stage 1 = zero-operand shortcuts, exponent compare, align the smaller
//             mantissa by the exponent difference (variable right shift),
//             and the 33-bit signed add/subtract.
//   Stage 2 = renormalise (leading-zero/one count + variable left shift or a
//             single right shift), underflow/overflow clamp, flag generation.
// This boundary was chosen because the two most expensive variable shifters -
// the align shifter (stage 1) and the normalise shifter (stage 2) - land in
// different stages, balancing the combinational depth into two ~half paths so
// each fits a 20 ns clock (see rtl/c31/README.md). Results are identical for
// TWOSTAGE 0 or 1; only latency changes (TWOSTAGE + REGOUT clocks).
//
// Float add and float multiply are separate modules (this and c31_mpyf) so
// MPYF3 || ADDF3 can instantiate both in the same instruction.

module c31_addsubf #(
    parameter bit REGOUT   = 1'b0,
    parameter bit TWOSTAGE = 1'b1     // default: pipelined (align+add | normalise)
) (
    input  logic        clk,
    input  logic        is_sub,
    input  logic [31:0] s1man,
    input  logic [7:0]  s1exp,
    input  logic [31:0] s2man,
    input  logic [7:0]  s2exp,
    input  logic [15:0] st_in,
    output logic [31:0] dman,
    output logic [7:0]  dexp,
    output logic [15:0] st_out
);
    `include "c31_lzc.svh"
    localparam logic [15:0] VFLAG  = 16'h0002;
    localparam logic [15:0] ZFLAG  = 16'h0004;
    localparam logic [15:0] NFLAG  = 16'h0008;
    localparam logic [15:0] UFFLAG = 16'h0010;
    localparam logic [15:0] LVFLAG = 16'h0020;
    localparam logic [15:0] LUFFLAG= 16'h0040;
    localparam logic [15:0] CLR_NZVUF = 16'h001E;

    // ---------------- Stage 1: align + add ----------------
    logic               s1_done_c, s1_issub_c;
    logic [31:0]        s1_edman_c;
    logic [7:0]         s1_edexp_c;
    logic signed [63:0] s1_man_c;
    logic signed [15:0] s1_exp_c;
    logic [15:0]        s1_st_c;
    always_comb begin
        logic signed [63:0] m1, m2;
        logic signed [15:0] cntv;
        s1_done_c = 1'b0; s1_edman_c = 32'd0; s1_edexp_c = 8'd0;
        s1_man_c = 64'sd0; s1_exp_c = 16'sd0;
        s1_issub_c = is_sub; s1_st_c = st_in;
        m1 = 64'sd0; m2 = 64'sd0; cntv = 16'sd0;

        if (!is_sub && s1exp == 8'h80) begin
            s1_edman_c = s2man; s1_edexp_c = s2exp; s1_done_c = 1'b1;
        end
        if (!s1_done_c && s2exp == 8'h80) begin
            s1_edman_c = s1man; s1_edexp_c = s1exp; s1_done_c = 1'b1;
        end
        if (!s1_done_c) begin
            m1 = $signed({{32{s1man[31]}}, s1man} ^ 64'h0000_0000_8000_0000);
            m2 = $signed({{32{s2man[31]}}, s2man} ^ 64'h0000_0000_8000_0000);
            if ($signed(s1exp) > $signed(s2exp)) begin
                s1_exp_c = $signed(s1exp);
                cntv     = $signed(s1exp) - $signed(s2exp);
                if (cntv >= 16'sd32) begin
                    s1_edman_c = s1man; s1_edexp_c = s1exp; s1_done_c = 1'b1;
                end else begin
                    m2 = m2 >>> cntv[5:0];
                end
            end else begin
                s1_exp_c = $signed(s2exp);
                cntv     = $signed(s2exp) - $signed(s1exp);
                if (cntv >= 16'sd32) begin
                    if (!is_sub) begin
                        s1_edman_c = s2man; s1_edexp_c = s2exp; s1_done_c = 1'b1;
                    end else begin
                        if ((s2man & 32'h7fff_ffff) != 32'd0) begin
                            s1_edman_c = (~s2man) + 32'd1; s1_edexp_c = s2exp;
                        end else begin
                            s1_edman_c = s2man ^ 32'h8000_0000;
                            s1_edexp_c = (s2man == 32'd0) ? (s2exp - 8'd1) : (s2exp + 8'd1);
                        end
                        s1_done_c = 1'b1;
                    end
                end else begin
                    m1 = m1 >>> cntv[5:0];
                end
            end
            if (!s1_done_c) s1_man_c = is_sub ? (m1 - m2) : (m1 + m2);
        end
    end

    // ---------------- pipeline register (mid) ----------------
    logic               s1_done, s1_issub;
    logic [31:0]        s1_edman;
    logic [7:0]         s1_edexp;
    logic signed [63:0] s1_man;
    logic signed [15:0] s1_exp;
    logic [15:0]        s1_st;
    generate if (TWOSTAGE) begin : g_mid
        always_ff @(posedge clk) begin
            s1_done<=s1_done_c; s1_issub<=s1_issub_c; s1_edman<=s1_edman_c;
            s1_edexp<=s1_edexp_c; s1_man<=s1_man_c; s1_exp<=s1_exp_c; s1_st<=s1_st_c;
        end
    end else begin : g_nomid
        always_comb begin
            s1_done=s1_done_c; s1_issub=s1_issub_c; s1_edman=s1_edman_c;
            s1_edexp=s1_edexp_c; s1_man=s1_man_c; s1_exp=s1_exp_c; s1_st=s1_st_c;
        end
    end endgenerate

    // ---------------- Stage 2: normalise + flags ----------------
    logic [31:0] dman_c; logic [7:0] dexp_c; logic [15:0] st_c;
    always_comb begin
        logic signed [63:0] man64;
        logic signed [15:0] expv;
        logic [5:0] ncnt;
        logic uf_v, ov_v;
        uf_v = 1'b0; ov_v = 1'b0; ncnt = 6'd0;
        man64 = s1_man; expv = s1_exp;
        if (s1_done) begin
            dman_c = s1_edman; dexp_c = s1_edexp;
        end else begin
            if (man64 == 64'sd0 || expv == -16'sd128) begin
                expv = -16'sd128; man64 = 64'sh8000_0000;
            end else if (man64 >= 64'sh1_0000_0000 || man64 < -64'sh1_0000_0000) begin
                man64 = man64 >>> 1; expv = expv + 16'sd1;
            end else if (man64 < 64'sh8000_0000 && man64 >= -64'sh8000_0000) begin
                if (man64 > 64'sd0) ncnt = clz32(man64[31:0]);
                else                ncnt = clo32(man64[31:0]);
                man64 = man64 <<< ncnt;
                expv  = expv - $signed({10'd0, ncnt});
            end
            if (expv <= -16'sd128) begin
                if (s1_issub) begin
                    if (man64 != 64'sd0 || expv < -16'sd128) uf_v = 1'b1;
                end else begin
                    uf_v = 1'b1;
                end
                man64 = 64'sh8000_0000; expv = -16'sd128;
            end else if (expv > 16'sd127) begin
                man64 = (man64 < 64'sd0) ? 64'sd0 : 64'h0000_0000_ffff_ffff;
                expv  = 16'sd127; ov_v = 1'b1;
            end
            dman_c = man64[31:0] ^ 32'h8000_0000;
            dexp_c = expv[7:0];
        end
        st_c = (s1_st & ~CLR_NZVUF)
             | (uf_v ? (UFFLAG | LUFFLAG) : 16'd0)
             | (ov_v ? (VFLAG  | LVFLAG)  : 16'd0)
             | (dman_c[31] ? NFLAG : 16'd0)
             | ((dexp_c == 8'h80) ? ZFLAG : 16'd0);
    end

    // ---------------- output register ----------------
    generate if (REGOUT) begin : g_out
        always_ff @(posedge clk) begin dman <= dman_c; dexp <= dexp_c; st_out <= st_c; end
    end else begin : g_comb
        assign dman = dman_c; assign dexp = dexp_c; assign st_out = st_c;
    end endgenerate
endmodule
