// SPDX-License-Identifier: BSD-3-Clause
// c31_pacer -- guest-time rate controller (BRIEF decision 2). Caps guest time at
// real time (at most 1 H1 per 2 fabric clocks on average) with bounded catch-up of
// one frame, and maintains `now` (cumulative guest H1) for the timers/DCS events.
//
// Credit is carried in HALF-H1 units: every clock that real time advances, credit
// gains 1 (== half an H1 of budget); emitting one guest H1 costs 2. So the steady
// rate is 1 H1 / 2 clocks. Credit is capped at 2*CATCHUP_H1, so after a stall the
// burst of catch-up H1 above the real rate is bounded to CATCHUP_H1 (one frame).
//
//  - mem_stall (SDRAM cache miss etc.): real time passes, guest is paused (step_req
//    low), so credit accrues and is spent as catch-up when the stall clears.
//  - render_stall (V-unit READY stall / full queue): real-board behaviour; credit
//    does NOT accrue, so the lost time is a genuine frame drop, never caught up.
//
// Quartus rules: always_comb defaults; no latch; no initial.
`default_nettype none
module c31_pacer #(
   parameter integer NOW_BITS    = 48,
   parameter integer CREDIT_BITS = 42,
   parameter [39:0]  CATCHUP_H1  = 40'd862900   // one race iteration (BRIEF section 2)
)(
   input  wire                    clk,
   input  wire                    ce,
   input  wire                    rst,
   input  wire                    step_req,      // core has a guest H1 to emit this clock
   input  wire                    mem_stall,     // memory-tier pause (accrue catch-up)
   input  wire                    render_stall,  // V-unit READY stall (no catch-up)
   output logic                   guest_tick_en, // 1 == one guest H1 advances this clock
   output logic [NOW_BITS-1:0]    now,
   output logic [CREDIT_BITS-1:0] credit_dbg
);
   localparam [CREDIT_BITS-1:0] CAP = {CATCHUP_H1, 1'b0};   // 2 * CATCHUP_H1 (half-H1 units)

   logic [CREDIT_BITS-1:0] credit;
   wire have_budget = (credit >= CREDIT_BITS'(2));

   logic [CREDIT_BITS-1:0] after_accrue, next_credit;
   always_comb begin
      guest_tick_en = step_req && have_budget && !render_stall;
      // accrue one half-H1 of real-time budget unless a render stall holds the frame
      if (!render_stall) begin
         after_accrue = (credit + CREDIT_BITS'(1) > CAP) ? CAP : credit + CREDIT_BITS'(1);
      end else begin
         after_accrue = credit;
      end
      // spend two half-H1 on an emitted guest H1 (post-accrue >= 2, so no underflow)
      next_credit = guest_tick_en ? (after_accrue - CREDIT_BITS'(2)) : after_accrue;
   end

   always_ff @(posedge clk) begin
      if (rst) begin
         credit <= '0; now <= '0;
      end else if (ce) begin
         credit <= next_credit;
         if (guest_tick_en) now <= now + 1'b1;
      end
   end
   assign credit_dbg = credit;
endmodule
`default_nettype wire
