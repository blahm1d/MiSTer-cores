// SPDX-License-Identifier: BSD-3-Clause
// c31_peripherals -- Cruis'n USA fabric C31 peripheral registers, transcribed blind
// from pinned MAME midvunit.cpp and the in-tree golden models:
//   two C31 timers   0x808020/24/28 (t0), 0x808030/34/38 (t1)
//                    per runtime/timing/c31_timer.hpp: counter read = elapsed H1
//                    since the last GO (bit 0x40), scaled by the DRIVER-WIDE rate
//                    (bit 0x200 -> 25 MHz -> counts=ticks; else 10 MHz -> (2t)/5),
//                    clamped at 1e9; period reads back; no timer interrupt.
//   bus control      0x808064          stored, read back (midvunit.cpp:307 ignores it
//                    for timing); reset value 0x10f8 (runtime cusa_machine golden).
//   system control   0x994000 (w)      dcs_reset = bit 1 (midvunit.cpp:238), driven
//                    on every write as a timestamped DCS event.
//   wheel latch      0x995000 (rw)     runtime/machine/wheel_latch.hpp (motor=latch 4,
//                    lamps=latch 5); read returns 0.
//   DCS data latch   0x9a0000 (w)      sound_w -> data & 0xff (midvunit.cpp:268), a
//                    timestamped DCS event.
// `now` (cumulative guest H1) comes from c31_pacer; timer reads and DCS events use it.
//
// Handshake: valid/ready. Writes complete in the cycle valid is high. Register/period
// reads (control, period, bus control, and the read-as-0 windows) have 1-clock latency.
// A timer COUNTER read (0x808024 / 0x808034) needs the divide-free 10 MHz reciprocal,
// which does not close at 50 MHz as a single combinational cone (measured -7.454 ns
// setup slack, slow -40C; the 32x32 0xCCCCCCCD product dominates). It is computed in a
// 3-STAGE PIPELINE and bus_ready is held low until the registered result is valid:
//   stage 1  elapsed ticks (now - go) with the 2.5e9 and 1e9 clamps
//   stage 2  the 0xCCCCCCCD reciprocal PRODUCT (isolated so the DSP multiply is a full
//            clock reg-to-reg)
//   stage 3  the 2*floor(t/5) + (t%5>=3) CORRECTION and the final 1e9 clamp
// => added read latency: a counter read takes 3 clocks (was 1); other reads stay 1.
// The core holds the request until ready and presents no new transaction meanwhile
// (single outstanding, c31_core.sv:23-50), and guest time is FROZEN while the core waits
// on a read: `now` advances only on an emitted guest H1 (c31_pacer.sv:40,56) and a
// stalled core emits none, so `now` (and go/rate/started, which change only on writes)
// is stable across the wait. The pipeline is fed the LAUNCH-cycle `now`, i.e. MAME's
// elapsed-at-access instant (c31_timer.hpp:48). Value-identical to c31_timer.hpp; the
// golden keeps the exact (2*ticks)/5, so RTL and golden stay independent (blind
// cross-diff, s5). Quartus rules: always_comb defaults on every output; no latch; no
// initial.
`default_nettype none
module c31_peripherals #(
   parameter integer NOW_BITS = 48
)(
   input  wire                 clk,
   input  wire                 ce,
   input  wire                 rst,

   // bus slave (only its own windows are routed here at integration)
   input  wire                 bus_valid,
   input  wire                 bus_write,
   input  wire [23:0]          bus_addr,
   input  wire [31:0]          bus_wdata,
   output logic                bus_ready,
   output logic [31:0]         bus_rdata,

   input  wire [NOW_BITS-1:0]  now,          // guest H1 count from the pacer

   // DCS event producer (into the fabric DCS; each event carries the guest tick)
   output logic [7:0]          dcs_data,
   output logic                dcs_data_valid,
   output logic [NOW_BITS-1:0] dcs_data_tick,
   output logic                dcs_reset,
   output logic                dcs_reset_strobe,
   output logic [NOW_BITS-1:0] dcs_reset_tick,

   // wheel board latch outputs
   output logic [7:0]          wheel_motor,
   output logic [7:0]          wheel_lamps,
   output logic [7:0]          wheel_sound_bus,

   // memory/bus control store
   output logic [31:0]         bus_control
);
   // ---- address decode ----
   wire [6:0] ctl_off = bus_addr[6:0];
   wire is_ctl   = (bus_addr[23:7] == 17'h10100);          // 0x808000-0x80807f
   wire is_t0c   = is_ctl && (ctl_off == 7'h20);
   wire is_t0cnt = is_ctl && (ctl_off == 7'h24);
   wire is_t0per = is_ctl && (ctl_off == 7'h28);
   wire is_t1c   = is_ctl && (ctl_off == 7'h30);
   wire is_t1cnt = is_ctl && (ctl_off == 7'h34);
   wire is_t1per = is_ctl && (ctl_off == 7'h38);
   wire is_busc  = is_ctl && (ctl_off == 7'h64);
   wire is_sysc  = (bus_addr == 24'h994000);               // control_w
   wire is_wheel = (bus_addr == 24'h995000);               // wheel_board_rw
   wire is_snd   = (bus_addr == 24'h9a0000);               // sound_w (DCS data)
   wire is_cnt   = is_t0cnt || is_t1cnt;                   // needs the elapsed pipeline

   // ---- timer state (counter register is never read back, so not stored) ----
   logic [31:0]         t0_ctl, t0_per, t1_ctl, t1_per;
   logic [NOW_BITS-1:0] t0_go, t1_go;
   logic                t0_started, t1_started;
   logic [1:0]          rate_code;   // 0 unset, 1 = 25 MHz, 2 = 10 MHz

   // ---- wheel latch state (runtime/machine/wheel_latch.hpp) ----
   logic [31:0] wheel_last;
   logic [3:0]  wheel_addr;
   logic [7:0]  wheel_lat [0:7];
   // effective address of THIS write (address_ is updated before the latch use)
   wire         wheel_addr_load = bus_wdata[11] && !wheel_last[11];
   wire [3:0]   wheel_eff_addr  = wheel_addr_load ? bus_wdata[3:0] : wheel_addr;
   assign wheel_motor = wheel_lat[4];
   assign wheel_lamps = wheel_lat[5];

   // ---- cheap (single-cycle) read value: register/period read-backs, else 0 ----
   logic [31:0] rd_cheap;
   always_comb begin
      rd_cheap = 32'd0;
      if      (is_t0c)   rd_cheap = t0_ctl;
      else if (is_t0per) rd_cheap = t0_per;
      else if (is_t1c)   rd_cheap = t1_ctl;
      else if (is_t1per) rd_cheap = t1_per;
      else if (is_busc)  rd_cheap = bus_control;
      // is_t0cnt/is_t1cnt: pipelined below.  is_sysc/is_wheel/is_snd: read as 0.
   end

   // ---- stage 1 (launch): elapsed ticks and the 2.5e9 / 1e9 clamps ----
   // Selected from the counter being read; sampled at the launch cycle (now is frozen
   // for the read wait, see the header). Value-identical to c31_timer.hpp elapsed_counts.
   wire                 launch_started = is_t1cnt ? t1_started : t0_started;
   wire [NOW_BITS-1:0]  launch_go      = is_t1cnt ? t1_go      : t0_go;
   logic [63:0] l_base, l_nowx, l_ticks;
   logic [31:0] l_tc;      // ticks pre-clamped to 2.5e9 (< 2^32) for the reciprocal
   logic [29:0] l_cnt25;   // 25 MHz result = min(ticks, 1e9) (1e9 < 2^30)
   always_comb begin
      l_base  = 64'd0; if (launch_started) l_base = {{(64-NOW_BITS){1'b0}}, launch_go};
      l_nowx  = {{(64-NOW_BITS){1'b0}}, now};
      l_ticks = (l_nowx >= l_base) ? (l_nowx - l_base) : 64'd0;
      l_tc    = (l_ticks >  64'd2500000000) ? 32'd2500000000 : l_ticks[31:0];
      l_cnt25 = (l_ticks >  64'd1000000000) ? 30'd1000000000 : l_ticks[29:0];
   end

   // ---- pipeline registers ----
   logic [31:0] s1_tc;    logic [29:0] s1_cnt25;  logic [1:0] s1_rate;
   logic [63:0] s2_prod;  logic [31:0] s2_tc;     logic [29:0] s2_cnt25;  logic [1:0] s2_rate;
   logic [31:0] s3_result;
   logic [31:0] cheap_q;

   // ---- stage 3 combinational: floor(2*tc/5) correction, rate select, 1e9 clamp ----
   //   floor(tc/5) = (tc * 0xCCCCCCCD) >> 34   (exact for tc < 2^32)
   //   floor(2*tc/5) = 2*floor(tc/5) + (tc%5 >= 3)
   logic [31:0] q5_w, r5_w;
   logic [63:0] counts10_w;
   logic [31:0] cnt10_w, result3_w;
   always_comb begin
      q5_w       = s2_prod[63:34];                             // floor(tc/5)
      r5_w       = s2_tc - ((q5_w << 2) + q5_w);               // tc - 5*q5 = tc % 5 (0..4)
      counts10_w = ({32'd0, q5_w} << 1) + ((r5_w >= 32'd3) ? 64'd1 : 64'd0); // floor(2t/5)
      cnt10_w    = (counts10_w > 64'd1000000000) ? 32'd1000000000 : counts10_w[31:0];
      result3_w  = (s2_rate == 2'd1) ? {2'd0, s2_cnt25} :      // 25 MHz: min(ticks,1e9)
                   (s2_rate == 2'd2) ? cnt10_w         :       // 10 MHz: min(floor(2t/5),1e9)
                                       32'd0;                  // unset
   end

   // ---- handshake FSM ----
   // P_IDLE : accept a transaction; writes ack same cycle.
   // P_CHEAP: present the 1-clock register/period read.
   // P_CNT1/2/3 : the counter pipeline; ready + registered result asserted in P_CNT3.
   localparam [2:0] P_IDLE=3'd0, P_CHEAP=3'd1, P_CNT1=3'd2, P_CNT2=3'd3, P_CNT3=3'd4;
   logic [2:0] pstate;
   always_comb begin
      bus_ready = 1'b0;
      bus_rdata = 32'd0;
      unique case (pstate)
         P_IDLE:  bus_ready = bus_valid && bus_write;          // writes complete same cycle
         P_CHEAP: begin bus_ready = 1'b1; bus_rdata = cheap_q;   end
         P_CNT3:  begin bus_ready = 1'b1; bus_rdata = s3_result; end
         default: ;                                            // P_CNT1/P_CNT2: not ready
      endcase
   end

   integer wi;
   always_ff @(posedge clk) begin
      if (rst) begin
         t0_ctl<=0; t0_per<=0; t1_ctl<=0; t1_per<=0;
         t0_go<=0; t1_go<=0; t0_started<=0; t1_started<=0; rate_code<=2'd0;
         bus_control<=32'h10f8;
         wheel_last<=0; wheel_addr<=0; wheel_sound_bus<=8'd0;
         for (wi=0; wi<8; wi=wi+1) wheel_lat[wi]<=8'd0;
         pstate<=P_IDLE; cheap_q<=32'd0;
         s1_tc<=0; s1_cnt25<=0; s1_rate<=2'd0;
         s2_prod<=0; s2_tc<=0; s2_cnt25<=0; s2_rate<=2'd0;
         s3_result<=32'd0;
      end else if (ce) begin
         unique case (pstate)
            P_IDLE: begin
               if (bus_valid && !bus_write) begin
                  if (is_cnt) begin
                     // stage 1 latch (launch-cycle now/go/rate)
                     s1_tc    <= l_tc;
                     s1_cnt25 <= l_cnt25;
                     s1_rate  <= rate_code;
                     pstate   <= P_CNT1;
                  end else begin
                     cheap_q  <= rd_cheap;
                     pstate   <= P_CHEAP;
                  end
               end else if (bus_valid && bus_write) begin
                  // ---- timer control writes ----
                  if (is_t0c) begin
                     t0_ctl <= bus_wdata;
                     if (bus_wdata[6]) begin t0_go <= now; t0_started <= 1'b1; end   // bit 0x40 = GO
                     rate_code <= bus_wdata[9] ? 2'd1 : 2'd2;                         // bit 0x200
                  end
                  if (is_t0per) t0_per <= bus_wdata;
                  if (is_t1c) begin
                     t1_ctl <= bus_wdata;
                     if (bus_wdata[6]) begin t1_go <= now; t1_started <= 1'b1; end
                     rate_code <= bus_wdata[9] ? 2'd1 : 2'd2;
                  end
                  if (is_t1per) t1_per <= bus_wdata;
                  if (is_busc)  bus_control <= bus_wdata;

                  // ---- wheel latch (wheel_latch.hpp) ----
                  if (is_wheel) begin
                     wheel_last <= bus_wdata;
                     if (wheel_addr_load) wheel_addr <= bus_wdata[3:0];
                     if (!bus_wdata[9]) begin
                        wheel_sound_bus <= bus_wdata[7:0];                            // !(data&0x200): DCS bus
                     end else if (bus_wdata[10]) begin
                        ; // (data&0x400): no latch
                     end else if (wheel_eff_addr[3]) begin
                        ; // Galil (address&8) unimplemented: ignore (golden throws; not exercised)
                     end else begin
                        wheel_lat[wheel_eff_addr[2:0]] <= bus_wdata[7:0];
                     end
                  end
               end
            end
            P_CHEAP: pstate <= P_IDLE;
            P_CNT1: begin
               // stage 2: the 0xCCCCCCCD reciprocal product, isolated (DSP full clock)
               s2_prod  <= {32'd0, s1_tc} * 64'h00000000CCCCCCCD;   // tc * ceil(2^34/5)
               s2_tc    <= s1_tc;
               s2_cnt25 <= s1_cnt25;
               s2_rate  <= s1_rate;
               pstate   <= P_CNT2;
            end
            P_CNT2: begin
               // stage 3: correction + clamp -> registered result
               s3_result <= result3_w;
               pstate    <= P_CNT3;
            end
            P_CNT3: pstate <= P_IDLE;
            default: pstate <= P_IDLE;
         endcase
      end
   end

   // ---- DCS event producer (strobe every relevant write; carries `now`) ----
   always_ff @(posedge clk) begin
      if (rst) begin
         dcs_data<=8'd0; dcs_data_valid<=1'b0; dcs_data_tick<=0;
         dcs_reset<=1'b0; dcs_reset_strobe<=1'b0; dcs_reset_tick<=0;
      end else if (ce) begin
         dcs_data_valid   <= 1'b0;
         dcs_reset_strobe <= 1'b0;
         if (pstate == P_IDLE && bus_valid && bus_write) begin
            if (is_snd) begin                       // 0x9a0000 sound_w -> data & 0xff
               dcs_data       <= bus_wdata[7:0];
               dcs_data_valid <= 1'b1;
               dcs_data_tick  <= now;
            end
            if (is_sysc) begin                      // 0x994000 control_w -> reset_w(bit 1)
               dcs_reset        <= bus_wdata[1];
               dcs_reset_strobe <= 1'b1;
               dcs_reset_tick   <= now;
            end
         end
      end
   end
endmodule
`default_nettype wire
