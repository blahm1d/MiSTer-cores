// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 indirect effective-address unit (Cruis'n USA fabric core).
//
// Blind transcription of the pinned MAME indirect-mode table:
//   ipp = .../tms320c3x/320c3x_ops.ipp
//   - mod00_d..mod07_d   (8-bit displacement) ............ ipp:885-947
//   - mod00_1..mod07_1   (implied displacement 1) ........ ipp:952-1008
//   - mod08..mod0f       (IR0 index) .................... ipp:1013-1075
//   - mod10..mod17       (IR1 index) .................... ipp:1080-1142
//   - mod18 (*ARn, no modify) .......................... ipp:1147-1151
//   - mod19 unimplemented (bit-reversed) ............... ipp:1153-1157
//   - modillegal (modes 0x1A-0x1F) ..................... ipp:1159-1163, table 6352-6353
//   - m_bkmask maintenance (BK rounded up to a mask) .... ipp:104-107
//   - DIRECT(op)=((DP&0xff)<<16)|uint16(op) ............. ipp:35
//
// Address register selection AR = AR0 + (ar&7) is done by the caller; this
// unit takes the selected AR value directly. The mode index is op[7:3]
// ((o>>3)&31), the displacement is (uint8_t)op, and the caller picks the
// _d (8-bit disp) vs _1 (implied 1) class via disp_is_one (modes 0x00-0x07;
// the IR0/IR1 and *ARn modes ignore the displacement, exactly as the shared
// s_indirect_d / s_indirect_1 table entries do, ipp:6344-6367).
//
// ea is the 24-bit value the mod function returns (the address bus is 24
// bits; access() masks with 0xffffff, ipp/c31.cpp:94). ar_out is the full
// 32-bit updated AR; ar_we is high only for the write-back modes. For a
// non-write-back mode ar_out==ar_in and ar_we=0, so a caller may write
// ar_out whenever ar_we. mode 0x19 asserts unimpl; 0x1A-0x1F assert
// illegal_mode; both leave ea=0, ar_out=ar_in, ar_we=0.
//
// REGOUT selects a registered (1-cycle) output stage.

module c31_ea #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic [4:0]  mode,        // op[7:3]
    input  logic        disp_is_one, // 1 => implied disp 1 (_1), 0 => disp8 (_d)
    input  logic [7:0]  disp8,       // (uint8_t)op
    input  logic [31:0] ar_in,       // selected AR value
    input  logic [31:0] ir0,
    input  logic [31:0] ir1,
    input  logic [31:0] bk,          // block-size register
    input  logic [31:0] bkmask,      // m_bkmask (BK rounded up to power-of-two mask)
    // Direct-addressing helper (independent of the indirect path).
    input  logic [7:0]  dp,          // DP & 0xff
    input  logic [15:0] op_low,      // uint16(op)
    output logic [23:0] ea,
    output logic [31:0] ar_out,
    output logic        ar_we,
    output logic        unimpl,
    output logic        illegal_mode,
    output logic [23:0] direct_addr
);
    // Delta to add/subtract: displacement for modes 0x00-0x07, else the index reg.
    logic [31:0] delta;
    always_comb begin
        unique case (mode[4:3])
            2'd0:    delta = disp_is_one ? 32'd1 : {24'd0, disp8};
            2'd1:    delta = ir0;
            2'd2:    delta = ir1;
            default: delta = 32'd0;               // 0x18-0x1F: no delta used
        endcase
    end

    // Circular (BK modulo) results, per ipp:927-947 / 1055-1075 / 1122-1142.
    logic [31:0] masked, circ_add_sum, circ_add_res, circ_sub_diff, circ_sub_res;
    always_comb begin
        masked        = ar_in & bkmask;
        // add: temp = (ar&bkmask)+delta; if ((uint32)temp >= (uint32)bk) temp -= bk;
        circ_add_sum  = masked + delta;
        if (circ_add_sum >= bk)  circ_add_sum = circ_add_sum - bk; // unsigned compare
        circ_add_res  = (ar_in & ~bkmask) | (circ_add_sum & bkmask);
        // sub: temp = (ar&bkmask)-delta; if (temp < 0) temp += bk;  (signed test)
        circ_sub_diff = masked - delta;
        if (circ_sub_diff[31]) circ_sub_diff = circ_sub_diff + bk;  // signed <0 => bit31
        circ_sub_res  = (ar_in & ~bkmask) | (circ_sub_diff & bkmask);
    end

    logic [31:0] ea32_c, ar_out_c;
    logic        ar_we_c, unimpl_c, illegal_c;
    always_comb begin
        ea32_c    = ar_in;
        ar_out_c  = ar_in;
        ar_we_c   = 1'b0;
        unimpl_c  = 1'b0;
        illegal_c = 1'b0;
        if (mode <= 5'h17) begin
            // Regular arithmetic modes 0x00-0x17, operation = mode[2:0].
            unique case (mode[2:0])
                3'd0: begin ea32_c = ar_in + delta;                                end // *+ (no wb)
                3'd1: begin ea32_c = ar_in - delta;                                end // *- (no wb)
                3'd2: begin ar_out_c = ar_in + delta; ea32_c = ar_out_c; ar_we_c=1;end // pre ++
                3'd3: begin ar_out_c = ar_in - delta; ea32_c = ar_out_c; ar_we_c=1;end // pre --
                3'd4: begin ea32_c = ar_in; ar_out_c = ar_in + delta;   ar_we_c=1;end // post ++
                3'd5: begin ea32_c = ar_in; ar_out_c = ar_in - delta;   ar_we_c=1;end // post --
                3'd6: begin ea32_c = ar_in; ar_out_c = circ_add_res;    ar_we_c=1;end // post ++%
                3'd7: begin ea32_c = ar_in; ar_out_c = circ_sub_res;    ar_we_c=1;end // post --%
            endcase
        end else if (mode == 5'h18) begin
            ea32_c = ar_in;                        // *ARn, no modify
        end else if (mode == 5'h19) begin
            unimpl_c = 1'b1;                        // bit-reversed: unimplemented
            ea32_c   = 32'd0;
        end else begin
            illegal_c = 1'b1;                      // 0x1A-0x1F: illegal
            ea32_c    = 32'd0;
        end
    end

    logic [23:0] ea_c, direct_c;
    always_comb begin
        ea_c     = ea32_c[23:0];
        direct_c = {dp, op_low};
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin
            ea           <= ea_c;
            ar_out       <= ar_out_c;
            ar_we        <= ar_we_c;
            unimpl       <= unimpl_c;
            illegal_mode <= illegal_c;
            direct_addr  <= direct_c;
        end
    end else begin : g_comb
        assign ea           = ea_c;
        assign ar_out       = ar_out_c;
        assign ar_we        = ar_we_c;
        assign unimpl       = unimpl_c;
        assign illegal_mode = illegal_c;
        assign direct_addr  = direct_c;
    end endgenerate
endmodule
