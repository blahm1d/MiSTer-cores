// SPDX-License-Identifier: BSD-3-Clause
// c31_memory (P3 wrapper) -- drop-in for the C2 c31_memory: SAME module name, parameters and ports (held-until-ready
// core bus). Internally c31_bus_adapter + c31_memory_p3 with the fetch port tied off, so a held master sees the C2
// timing exactly; a pipelined core instantiates c31_memory_p3 directly. docs/PLAN-A1D-PIPELINE-20260917.md section 0.
`default_nettype none
module c31_memory #(
   parameter integer NUM_MAIN_PAGES = 128,   // ladder rung 3c
   parameter integer NUM_ROM_PAGES  = 16,    // ladder rung 1b
   parameter integer CMOS_WORDS     = 8192,
   parameter integer CMOS_ABITS     = 13
)(
   input  wire        clk,
   input  wire        ce,
   input  wire        rst,

   input  wire        bus_valid,
   input  wire        bus_write,
   input  wire [23:0] bus_addr,
   input  wire [31:0] bus_wdata,
   output logic       bus_ready,
   output logic [31:0] bus_rdata,
   output logic       guest_pause,

   output logic        sd_req,
   output logic sd_burst,
   output logic        sd_we,
   output logic [23:0] sd_addr,
   output logic [31:0] sd_wdata,
   input  wire         sd_ack,
   input  wire [31:0]  sd_rdata,

   output logic        ext_valid,
   output logic        ext_write,
   output logic [23:0] ext_addr,
   output logic [31:0] ext_wdata,
   input  wire         ext_ready,
   input  wire [31:0]  ext_rdata,

   output logic        nvram_protected,
   output logic [63:0] stat_main_hits, stat_main_misses,
   output logic [63:0] stat_rom_hits,  stat_rom_misses,
   output logic [63:0] stat_pause_clocks
);
   logic        p_req_valid, p_req_accept, p_rsp_valid;
   logic [31:0] p_rsp_rdata;
   logic        f_accept_unused, f_rsp_valid_unused;
   logic [31:0] f_rdata_unused;
   logic [63:0] f_acc_unused, f_rej_unused, f_stale_unused;

   c31_bus_adapter u_adapt (
      .clk(clk), .ce(ce), .rst(rst),
      .core_valid(bus_valid), .core_write(bus_write), .core_ready(bus_ready), .core_rdata(bus_rdata),
      .req_valid(p_req_valid), .req_accept(p_req_accept), .rsp_valid(p_rsp_valid), .rsp_rdata(p_rsp_rdata));

   c31_memory_p3 #(.NUM_MAIN_PAGES(NUM_MAIN_PAGES), .NUM_ROM_PAGES(NUM_ROM_PAGES),
                   .CMOS_WORDS(CMOS_WORDS), .CMOS_ABITS(CMOS_ABITS)) u_p3 (
      .clk(clk), .ce(ce), .rst(rst),
      .req_valid(p_req_valid), .req_write(bus_write), .req_fetch(1'b0), .req_addr(bus_addr), .req_wdata(bus_wdata),
      .req_accept(p_req_accept), .rsp_valid(p_rsp_valid), .rsp_rdata(p_rsp_rdata), .guest_pause(guest_pause),
      .f_valid(1'b0), .f_addr(24'd0), .f_accept(f_accept_unused), .f_rsp_valid(f_rsp_valid_unused), .f_rdata(f_rdata_unused),
      .sd_burst(sd_burst), .sd_req(sd_req), .sd_we(sd_we), .sd_addr(sd_addr), .sd_wdata(sd_wdata), .sd_ack(sd_ack), .sd_rdata(sd_rdata),
      .ext_valid(ext_valid), .ext_write(ext_write), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
      .ext_ready(ext_ready), .ext_rdata(ext_rdata),
      .nvram_protected(nvram_protected),
      .stat_main_hits(stat_main_hits), .stat_main_misses(stat_main_misses),
      .stat_rom_hits(stat_rom_hits), .stat_rom_misses(stat_rom_misses), .stat_pause_clocks(stat_pause_clocks),
      .stat_fetch_accepts(f_acc_unused), .stat_fetch_rejects(f_rej_unused), .stat_fetch_stale(f_stale_unused));
endmodule
`default_nettype wire
