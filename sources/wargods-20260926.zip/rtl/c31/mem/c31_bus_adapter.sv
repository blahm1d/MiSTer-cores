// SPDX-License-Identifier: BSD-3-Clause
// c31_bus_adapter -- connects a HELD-UNTIL-READY master (the gated serial c31_core, the C2 memory bench) to the
// request/response port of c31_memory_p2 with IDENTICAL clock timing:
//   write          : core_ready in the accept clock (as before: a write completed in its ready clock)
//   fast read      : accepted in clock t, answered at t+1 -> core_ready at t+1 (as before: lookup, then ready)
//   slow read      : accept and response coincide -> core_ready in that clock (as before)
// While a fast read is outstanding the held request is masked from the port, so the tier never sees the held
// copy as a second request. A master that holds valid until ready therefore produces exactly the old access
// stream and the old clocks; the G2 clock count is the neutrality proof (docs/PLAN-A1D-PIPELINE-20260917.md
// section 0, landing step 2).
`default_nettype none
module c31_bus_adapter (
   input  wire        clk,
   input  wire        ce,
   input  wire        rst,
   // held-until-ready master
   input  wire        core_valid,
   input  wire        core_write,
   output logic       core_ready,
   output logic [31:0] core_rdata,
   // request/response slave
   output logic       req_valid,
   input  wire        req_accept,
   input  wire        rsp_valid,
   input  wire [31:0] rsp_rdata
);
   logic waiting;   // a read was accepted without its response; the answer comes on a later clock
   always_ff @(posedge clk) begin
      if (rst) waiting <= 1'b0;
      else if (ce) begin
         if (!waiting) begin
            if (core_valid && req_accept && !core_write && !rsp_valid) waiting <= 1'b1;
         end else if (rsp_valid) begin
            waiting <= 1'b0;
         end
      end
   end
   always_comb begin
      req_valid  = core_valid && !waiting;
      core_ready = waiting ? rsp_valid : (core_valid && req_accept && (core_write || rsp_valid));
      core_rdata = rsp_rdata;
   end
endmodule
`default_nettype wire
