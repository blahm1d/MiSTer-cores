//
// c31_sdram_backing.sv -- 32-bit <-> 16-bit backing adapter for the C31 memory tier. Instantiates
// the forked open-page burst controller (c31_sdram_burst) and turns the memory tier's SDRAM port
// into board-SDRAM transactions:
//   * burst read  (c_burst & !c_we): one open-page burst of BURST_HALFWORDS 16-bit words; pairs
//     consecutive halfwords (col 0 = word.lo, col 1 = word.hi, ...) into WORDS 32-bit words and
//     streams them out on c_dvalid/c_bdata in order. This is a 256-word page fill.
//   * single write (c_we):     two 16-bit writes (lo at c_baddr, hi at c_baddr+2), then c_ack.
//   * single read  (else):     two 16-bit reads,  assembled into c_rdata, then c_ack.
// BYTE-ADDRESSED: c_baddr is the SDRAM byte address (word aligned, c_baddr[1:0]=0). The CALLER
// (integration layer) maps the C31 word regions (main/fast/rom/cmos) into physical SDRAM and
// supplies the byte address; a 256-word page is 1024 contiguous bytes = 512 halfwords in one SDRAM
// row (c31_sdram_burst [C31-1] decomposition), so the fill is a single open page.
//
// 32-bit word layout in SDRAM: word[15:0] at byte b, word[31:16] at byte b+2 (little-endian half
// order), consistent between write and read/burst so the fill returns what was stored.
//
// The controller's edge-triggered we/rd get ONE-CYCLE pulses (a held level would give no second
// edge for the high halfword). The command bundle is exposed for one-stage pin registration outside
// this module (PIN_LAT=2 total, as on the bw1 cabinet build and in tb_sdram_burst).
`timescale 1ns/1ps
`default_nettype none
module c31_sdram_backing #(
   parameter integer WORDS           = 256,          // 32-bit words per page burst
   parameter integer BURST_HALFWORDS = 512           // = WORDS*2 (16-bit words the controller reads)
)(
   input  wire         clk,
   input  wire         init,       // power-on reset to the controller (POR domain)

   // ---- memory-tier side (32-bit) ----
   input  wire         c_req,      // level: hold until c_ack (single) or c_busy falls (burst)
   input  wire         c_we,       // single write
   input  wire         c_burst,    // burst read (WORDS words); ignored if c_we
   input  wire [24:0]  c_baddr,    // SDRAM byte address (word aligned)
   input  wire [31:0]  c_wdata,
   output logic        c_ack,      // 1-cycle: single read/write complete
   output logic [31:0] c_rdata,    // valid with c_ack on a single read
   output logic        c_dvalid,   // 1-cycle per 32-bit burst word (in order)
   output logic [31:0] c_bdata,
   output logic        c_busy,

   // ---- SDRAM command bundle (registered one stage outside) ----
   input  wire [15:0] i_dq,
   output wire [15:0] o_dq_out,
   output wire        o_dq_oe,
   output wire [12:0] o_A,
   output wire        o_dqml,
   output wire        o_dqmh,
   output wire [1:0]  o_BA,
   output wire        o_ncs,
   output wire        o_nwe,
   output wire        o_nras,
   output wire        o_ncas,
   output wire        o_cke
);
   // ---- controller (one-cycle-pulsed we/rd, registered addr/din) ----
   logic        ctl_we, ctl_rd;
   logic        brd_hold;                // burst request HELD until the controller accepts (burst_busy);
   wire         ctl_brd = brd_hold;      // a 1-cycle pulse can be missed if the controller is refreshing.
   logic [24:0] ctl_addr, ctl_baddr;
   logic [15:0] ctl_din;
   wire  [15:0] ctl_dout;
   wire         ctl_ready;
   wire         ctl_bdvalid;
   wire  [15:0] ctl_bdout;
   wire         ctl_bbusy;

   c31_sdram_burst #(.PIN_LAT(2)) ctl (
      .init(init), .clk(clk),
      .i_dq(i_dq), .o_dq_out(o_dq_out), .o_dq_oe(o_dq_oe),
      .o_A(o_A), .o_dqml(o_dqml), .o_dqmh(o_dqmh), .o_BA(o_BA),
      .o_ncs(o_ncs), .o_nwe(o_nwe), .o_nras(o_nras), .o_ncas(o_ncas), .o_cke(o_cke),
      .wtbt(2'b11), .addr(ctl_addr), .dout(ctl_dout), .din(ctl_din),
      .we(ctl_we), .rd(ctl_rd), .ready(ctl_ready),
      .burst_rd(ctl_brd), .burst_addr(ctl_baddr), .burst_len(BURST_HALFWORDS[9:0]),
      .burst_dvalid(ctl_bdvalid), .burst_dout(ctl_bdout), .burst_busy(ctl_bbusy));

   localparam [3:0] A_IDLE=0, A_WLO=1, A_WLOW=2, A_WHI=3, A_WHIW=4,
                    A_RLO=5, A_RLOW=6, A_RHI=7, A_RHIW=8, A_BURST=9, A_ACK=10;
   logic [3:0]  st;
   logic [15:0] lo_lat, hi_lat;
   logic        bhalf;                 // 0 = next burst halfword is low, 1 = high
   logic [9:0]  wcount;                // 32-bit words emitted this burst
   logic        ready_d;               // ctl_ready rising-edge detect

   assign c_busy = (st != A_IDLE);

   always_comb begin
      c_ack = 1'b0; c_rdata = {hi_lat, lo_lat};
      c_dvalid = (st == A_BURST) && ctl_bdvalid && bhalf;    // emit a word when the high half arrives
      c_bdata  = {ctl_bdout, lo_lat};
      if (st == A_ACK) c_ack = 1'b1;
   end

   always_ff @(posedge clk) begin
      // default: no pulse
      ctl_we <= 1'b0; ctl_rd <= 1'b0;
      if (init) begin
         st <= A_IDLE; lo_lat <= 16'd0; hi_lat <= 16'd0; bhalf <= 1'b0; ready_d <= 1'b1;
         ctl_addr <= 25'd0; ctl_din <= 16'd0; ctl_baddr <= 25'd0; wcount <= 10'd0; brd_hold <= 1'b0;
      end else begin
         ready_d <= ctl_ready;
         case (st)
            A_IDLE: if (c_req) begin
               if (c_we) begin
                  ctl_we <= 1'b1; ctl_addr <= c_baddr; ctl_din <= c_wdata[15:0]; st <= A_WLOW;
               end else if (c_burst) begin
                  brd_hold <= 1'b1; ctl_baddr <= c_baddr; bhalf <= 1'b0; wcount <= 10'd0; st <= A_BURST;
               end else begin
                  ctl_rd <= 1'b1; ctl_addr <= c_baddr; st <= A_RLOW;
               end
            end
            // single write: lo pulsed on entry; wait ready; pulse hi; wait ready; ack
            A_WLOW: if (ctl_ready && !ready_d) begin
                       ctl_we <= 1'b1; ctl_addr <= c_baddr + 25'd2; ctl_din <= c_wdata[31:16]; st <= A_WHIW;
                    end
            A_WHIW: if (ctl_ready && !ready_d) st <= A_ACK;
            // single read: lo pulsed on entry; latch dout; pulse hi; latch; ack
            A_RLOW: if (ctl_ready && !ready_d) begin
                       lo_lat <= ctl_dout; ctl_rd <= 1'b1; ctl_addr <= c_baddr + 25'd2; st <= A_RHIW;
                    end
            A_RHIW: if (ctl_ready && !ready_d) begin hi_lat <= ctl_dout; st <= A_ACK; end
            // burst read: pair halfwords into 32-bit words (lo then hi)
            A_BURST: begin
               if (ctl_bbusy) brd_hold <= 1'b0;                // controller accepted the burst; stop requesting
               if (ctl_bdvalid) begin
                  if (!bhalf) lo_lat <= ctl_bdout;             // low half latched
                  else        wcount <= wcount + 10'd1;        // high half: a full 32-bit word emitted
                  bhalf <= ~bhalf;
               end
               if (wcount == WORDS[9:0]) st <= A_IDLE;         // all WORDS words emitted
            end
            A_ACK: st <= A_IDLE;
            default: st <= A_IDLE;
         endcase
      end
   end
endmodule
`default_nettype wire
