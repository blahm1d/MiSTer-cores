// SPDX-License-Identifier: BSD-3-Clause
// c31_memory_fp -- the P3 memory tier with its FETCH PORT exposed, for the stage-4 lookahead core
// (docs/PLAN-STAGE4-LOOKAHEAD.md). The same two gated modules as the P3 drop-in wrapper c31_memory.sv
// (c31_bus_adapter + c31_memory_p3, gate build/c31-memp3-20260917T045533005801Z), unchanged, with two differences:
//   * req_fetch = bus_fetch: the core's data-port fetches install their page in the fetch port's page map (the P3
//     contract: "a map miss: the master fetches through the data port instead, with req_fetch=1");
//   * the fetch port f_* is wired to the core instead of tied off.
// With f_valid held low and bus_fetch = 0 this is exactly c31_memory.sv.
`default_nettype none
module c31_memory_fp #(
   parameter integer READ_OVERLAP = 0,
   parameter integer NUM_MAIN_PAGES = 128,   // ladder rung 3c
   parameter integer NUM_ROM_PAGES  = 16,    // ladder rung 1b
   parameter integer CMOS_WORDS     = 8192,
   parameter integer CMOS_ABITS     = 13
)(
   input  wire        clk,
   input  wire        ce,
   input  wire        rst,

   // held-until-ready data port (the serial back end)
   input wire read_ahead_valid,
   input wire [23:0] read_ahead_addr,
   input  wire        bus_valid,
   input  wire        bus_write,
   input  wire        bus_fetch,       // this data-port read is an instruction fetch
   input  wire [23:0] bus_addr,
   input  wire [31:0] bus_wdata,
   output logic       bus_ready,
   output logic [31:0] bus_rdata,
   output logic       guest_pause,

   // read-only fetch port (the lookahead front end): accept is combinational, the word arrives the next clock
   input  wire        f_valid,
   input  wire [23:0] f_addr,
   output logic       f_accept,
   output logic       f_rsp_valid,
   output logic [31:0] f_rdata,

   output logic        sd_req,
   output logic sd_burst,
   output logic        sd_we,
   output logic [23:0] sd_addr,
   output logic [31:0] sd_wdata,
   input  wire         sd_ack,
   input  wire [31:0]  sd_rdata,

   output logic        ext_valid,
   output logic        ext_write,
   output logic [23:0] ext_addr,
   output logic [31:0] ext_wdata,
   input  wire         ext_ready,
   input  wire [31:0]  ext_rdata,

   output logic        nvram_protected,
   output logic [63:0] stat_main_hits, stat_main_misses,
   output logic [63:0] stat_rom_hits,  stat_rom_misses,
   output logic [63:0] stat_pause_clocks,
   output logic [63:0] stat_fetch_accepts, stat_fetch_rejects, stat_fetch_stale
);
   logic        p_req_valid, p_req_accept, p_rsp_valid;
   logic [31:0] p_rsp_rdata;

   logic waiting, saved_valid;
   logic [31:0] saved_data;
   wire start_read = READ_OVERLAP != 0 && read_ahead_valid && !bus_valid && !waiting && !saved_valid;
   wire advance_read = READ_OVERLAP != 0 && read_ahead_valid && bus_valid &&
                       waiting && p_rsp_valid && !saved_valid;
   wire [23:0] next_addr = (start_read || advance_read) ? read_ahead_addr : bus_addr;
   always_comb begin
      p_req_valid = start_read || advance_read || (bus_valid && !waiting && !saved_valid);
      bus_ready = saved_valid || (waiting ? p_rsp_valid :
                  (bus_valid && p_req_accept && (bus_write || p_rsp_valid)));
      bus_rdata = saved_valid ? saved_data : p_rsp_rdata;
   end
   always_ff @(posedge clk) begin
      if (rst) begin waiting <= 0; saved_valid <= 0; saved_data <= 0; end
      else if (ce) begin
         if (saved_valid && bus_valid) saved_valid <= 0;
         if (start_read) begin
            waiting <= p_req_accept && !p_rsp_valid;
            if (p_req_accept && p_rsp_valid) begin saved_valid <= 1; saved_data <= p_rsp_rdata; end
         end else if (advance_read) waiting <= p_req_accept;
         else if (waiting && p_rsp_valid) waiting <= 0;
         else if (!waiting && !saved_valid && bus_valid && p_req_accept && !bus_write && !p_rsp_valid) waiting <= 1;
      end
   end

   c31_memory_p3 #(.NUM_MAIN_PAGES(NUM_MAIN_PAGES), .NUM_ROM_PAGES(NUM_ROM_PAGES),
                   .CMOS_WORDS(CMOS_WORDS), .CMOS_ABITS(CMOS_ABITS)) u_p3 (
      .clk(clk), .ce(ce), .rst(rst),
      .req_valid(p_req_valid), .req_write(bus_write && !advance_read && !start_read), .req_fetch(bus_fetch && !bus_write && !advance_read && !start_read), .req_addr(next_addr),
      .req_wdata(bus_wdata),
      .req_accept(p_req_accept), .rsp_valid(p_rsp_valid), .rsp_rdata(p_rsp_rdata), .guest_pause(guest_pause),
      .f_valid(f_valid), .f_addr(f_addr), .f_accept(f_accept), .f_rsp_valid(f_rsp_valid), .f_rdata(f_rdata),
      .sd_burst(sd_burst), .sd_req(sd_req), .sd_we(sd_we), .sd_addr(sd_addr), .sd_wdata(sd_wdata), .sd_ack(sd_ack), .sd_rdata(sd_rdata),
      .ext_valid(ext_valid), .ext_write(ext_write), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
      .ext_ready(ext_ready), .ext_rdata(ext_rdata),
      .nvram_protected(nvram_protected),
      .stat_main_hits(stat_main_hits), .stat_main_misses(stat_main_misses),
      .stat_rom_hits(stat_rom_hits), .stat_rom_misses(stat_rom_misses), .stat_pause_clocks(stat_pause_clocks),
      .stat_fetch_accepts(stat_fetch_accepts), .stat_fetch_rejects(stat_fetch_rejects),
      .stat_fetch_stale(stat_fetch_stale));
endmodule
`default_nettype wire
