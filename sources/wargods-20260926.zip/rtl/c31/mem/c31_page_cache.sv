// SPDX-License-Identifier: BSD-3-Clause
// c31_page_cache (P3) -- the P2 request/response page cache (bandwidth/a1d/rtl/mem_p2, gate
// build/c31-memp2-20260917T024715224345Z) plus an optional read-only FETCH PORT (A1d plan section 0, step 3).
//
// Data port (unchanged from P2): req_valid/req_write/req_addr/req_wdata held until req_accept; a write completes at
// accept; a read hit is answered on the next clock (rsp_valid, rsp_fast) and a NEW request may be looked up in that
// answer clock; a filled miss answers in S_HOLDRD (accept + response). What a read RETURNS is the flat region
// backing store (MAME crusnusa map, midvunit.cpp:668 main RAM `.ram()`, :693 ROM `.rom()`).
//
// Fetch port (FETCH_PORT=1; the main-RAM instance -- every executed PC is main or internal RAM, CENSUS.md):
//   f_valid/f_addr   a fetch request this clock (speculative-safe: no side effects, may be abandoned)
//   f_hit            combinational: the page is in the FETCH PAGE MAP, so the word is read from M10K port B this clock
//                    and presented next clock on f_rdata. No hit -> the master fetches through the data port instead.
//   f_rdata          the word read on the previous clock
//   f_stale          the previous clock's port-B read collided with a data-port write to the SAME word (mixed-port
//                    read-during-write is don't-care on the M10K, no_rw_check): the answer must be discarded
//   req_fetch        tags a data-port read as a fetch fallback: when it is answered from a resident page, that page is
//                    installed in the map (so the next fetch of the page goes through the fetch port)
// Page map: FETCH_MAP entries {page, slot}, move-to-front on a fetch hit and on install. A 4-entry map misses 0.17 % /
// 0.20 % of race / attract fetches (bandwidth/a1d/fetch_pagemap_model.py). SAFETY: the map names a SLOT; a slot changes
// page only by a fill, and every entry naming the slot is removed in the clock the fill starts, before its first word
// is written. The data port's own tags/valid bits are untouched, so the data port behaves exactly as in P2.
//
// Page store: port A (data) and port B (fetch) of one true-dual-port M10K, written only through port A with the Altera
// new-data template (memory quartus-true-dual-port-needs-new-data-template). Port A's single address is the write
// address in a write clock and the read address otherwise; no clock needs both (one request per clock; fill writes
// never coincide with a data read whose answer is used).
`default_nettype none
module c31_page_cache #(
   parameter integer ADDR_BITS     = 24,
   parameter integer PAGE_WORDS    = 256,
   parameter integer OFFS_BITS     = 8,
   parameter integer NUM_PAGES     = 172,
   parameter [23:0]  BASE          = 24'h000000,
   parameter integer PAGE_NUM_BITS = 9,
   parameter bit     WRITABLE      = 1'b1,
   parameter bit     FETCH_PORT    = 1'b0,
   parameter integer FETCH_MAP     = 4,
   // 2026-09-22 ladder rung 4b-cache: 0 = fully associative (global CLOCK); else WAYS-way set-associative, set =
   // page[SET_BITS-1:0], slot = {set, way}, per-set CLOCK. NUM_PAGES and WAYS must be powers of two when WAYS != 0.
   parameter integer WAYS          = 0,
   // wg1 2026-09-25 speed step 2: posted-write FIFO depth (1 = the donor's single posted write, unchanged). Writes are
   // accepted while the FIFO is not full; a read MISS still waits until it is EMPTY (all posted writes reach SDRAM
   // before any fill reads it), and a resident-page write updates the M10K at accept as before, so read-after-write
   // order is unchanged. Drain order = accept order.
   parameter integer PW_DEPTH      = 1
)(
   input  wire                  clk,
   input  wire                  ce,
   input  wire                  rst,

   input  wire                  req_valid,
   input  wire                  req_write,
   input  wire                  req_fetch,
   input  wire [ADDR_BITS-1:0]  req_addr,
   input  wire [31:0]           req_wdata,
   output logic                 req_accept,
   output logic                 rsp_valid,
   output logic                 rsp_fast,
   output logic [31:0]          rsp_rdata,
   output logic                 busy_pause,

   input  wire                  f_valid,
   input  wire [ADDR_BITS-1:0]  f_addr,
   output logic                 f_hit,
   output logic [31:0]          f_rdata,
   output logic                 f_stale,

   output logic                 sd_req,
   output logic                 sd_burst,
   output logic                 sd_we,
   output logic [ADDR_BITS-1:0] sd_addr,
   output logic [31:0]          sd_wdata,
   input  wire                  sd_ack,
   input  wire [31:0]           sd_rdata,

   output logic [63:0]          stat_hits,
   output logic [63:0]          stat_misses,
   output logic [63:0]          stat_pause_clocks
);
   localparam integer MEM_DEPTH = NUM_PAGES * PAGE_WORDS;
   localparam integer SLOT_BITS = (NUM_PAGES <= 1) ? 1 : $clog2(NUM_PAGES);
   localparam integer MEMA_BITS = SLOT_BITS + OFFS_BITS;
   localparam [OFFS_BITS-1:0] LAST_WORD = PAGE_WORDS - 1;   // 255; burst wraps after it
   localparam [SLOT_BITS-1:0] LAST_SLOT = NUM_PAGES - 1;
   localparam bit     INDEXED  = (WAYS != 0) && (WAYS < NUM_PAGES);
   localparam integer NWAYS    = INDEXED ? WAYS : 1;
   localparam integer NSETS    = INDEXED ? NUM_PAGES / WAYS : 1;
   localparam integer WAY_BITS = (NWAYS <= 1) ? 1 : $clog2(NWAYS);
   localparam integer SET_BITS = (NSETS <= 1) ? 1 : $clog2(NSETS);
   initial if (INDEXED && ((1 << WAY_BITS) != WAYS || (1 << SET_BITS) != NSETS || SET_BITS + WAY_BITS != SLOT_BITS))
      $fatal(1, "c31_page_cache: WAYS=%0d NUM_PAGES=%0d must be powers of two", WAYS, NUM_PAGES);

   // ---- page store: true-dual-port M10K (port A data R/W, port B fetch R) ----
   logic [MEMA_BITS-1:0]  mem_raddr, mem_waddr, f_mem_addr;
   logic                  mem_we;
   logic [31:0]           mem_wdata, mem_rdata;
   wire  [MEMA_BITS-1:0]  addr_a = mem_we ? mem_waddr : mem_raddr;
   generate
      if (FETCH_PORT) begin : g_tdp
         (* ramstyle = "M10K, no_rw_check" *) logic [31:0] mem [0:MEM_DEPTH-1];
         always_ff @(posedge clk) begin
            if (mem_we) begin mem[addr_a] <= mem_wdata; mem_rdata <= mem_wdata; end
            else        mem_rdata <= mem[addr_a];
         end
         always_ff @(posedge clk) f_rdata <= mem[f_mem_addr];
      end else begin : g_sdp
         logic [31:0] mem [0:MEM_DEPTH-1];
         always_ff @(posedge clk) begin
            if (mem_we) mem[mem_waddr] <= mem_wdata;
            mem_rdata <= mem[mem_raddr];
         end
         assign f_rdata = 32'd0;
      end
   endgenerate

   // tags / valid / use-bit (flip-flops, parallel compare)
   logic                     valid [0:NUM_PAGES-1];
   logic                     use_b [0:NUM_PAGES-1];
   logic [PAGE_NUM_BITS-1:0] tag   [0:NUM_PAGES-1];
   logic [SLOT_BITS-1:0]     clk_ptr;

   wire [ADDR_BITS-1:0]      rel      = req_addr - BASE;
   wire [PAGE_NUM_BITS-1:0]  req_page = rel[OFFS_BITS +: PAGE_NUM_BITS];
   wire [OFFS_BITS-1:0]      req_offs = req_addr[OFFS_BITS-1:0];

   logic                  hit;
   logic [SLOT_BITS-1:0]  hit_slot;
   integer                ci;
   // set index of the request (INDEXED only; unused otherwise)
   wire [SET_BITS-1:0]    req_set = SET_BITS'(req_page);
   always_comb begin
      hit = 1'b0; hit_slot = '0;
      if (INDEXED) begin
         for (ci = 0; ci < NWAYS; ci = ci + 1)
            if (valid[{req_set, WAY_BITS'(ci)}] && tag[{req_set, WAY_BITS'(ci)}] == req_page) begin
               hit = 1'b1; hit_slot = {req_set, WAY_BITS'(ci)};
            end
      end else begin
         for (ci = 0; ci < NUM_PAGES; ci = ci + 1)
            if (valid[ci] && tag[ci] == req_page) begin hit = 1'b1; hit_slot = SLOT_BITS'(ci); end
      end
   end

   logic                  have_invalid;
   logic [SLOT_BITS-1:0]  invalid_slot;
   integer                vi;
   always_comb begin
      have_invalid = 1'b0; invalid_slot = '0;
      if (INDEXED) begin
         for (vi = NWAYS-1; vi >= 0; vi = vi - 1)
            if (!valid[{req_set, WAY_BITS'(vi)}]) begin have_invalid = 1'b1; invalid_slot = {req_set, WAY_BITS'(vi)}; end
      end else begin
         for (vi = NUM_PAGES-1; vi >= 0; vi = vi - 1)
            if (!valid[vi]) begin have_invalid = 1'b1; invalid_slot = SLOT_BITS'(vi); end
      end
   end

   // CLOCK victim candidate. Fully associative: the global clk_ptr. INDEXED: {set of cur_page, vic_way}, where vic_way is
   // loaded from the set's pointer (set_ptr) when the miss enters S_VICTIM and written back when the victim is taken.
   logic [WAY_BITS-1:0]   vic_way;
   logic [WAY_BITS-1:0]   set_ptr [0:NSETS-1];
   wire  [SET_BITS-1:0]   cur_set  = SET_BITS'(cur_page);
   wire  [SLOT_BITS-1:0]  vic_slot = INDEXED ? SLOT_BITS'({cur_set, vic_way}) : clk_ptr;

   // request classification
   wire read_req  = req_valid && !req_write;
   wire write_req = req_valid &&  req_write;
   wire read_hit  = read_req && hit;
   wire read_miss = read_req && !hit;

   // PW_DEPTH-deep posted write FIFO (write-through to SDRAM), drained in the background, head first
   localparam integer PWB = (PW_DEPTH <= 1) ? 1 : $clog2(PW_DEPTH);
   logic [ADDR_BITS-1:0]  pw_a [0:PW_DEPTH-1];
   logic [31:0]           pw_d [0:PW_DEPTH-1];
   logic [PWB-1:0]        pw_rp, pw_wp;
   logic [PWB:0]          pw_cnt;
   wire                   pw_valid = pw_cnt != '0;                          // something to drain
   wire                   pw_full  = pw_cnt == (PWB+1)'(PW_DEPTH);          // no room for a new write
   wire [ADDR_BITS-1:0]   pw_addr  = pw_a[pw_rp];
   wire [31:0]            pw_data  = pw_d[pw_rp];
   function automatic [PWB-1:0] pw_next(input [PWB-1:0] x);
      pw_next = (x == PWB'(PW_DEPTH - 1)) ? '0 : x + 1'b1;
   endfunction

   localparam [2:0] S_IDLE=3'd0, S_RD1=3'd1, S_VICTIM=3'd2, S_FILL=3'd3,
                    S_FILLGAP=3'd4, S_FILLRD=3'd5, S_HOLDRD=3'd6;
   logic [2:0]               state;
   logic fill_served, fill_fetch;
   logic fill_hit_pending;
   // The controller wraps its 9-bit halfword column inside the open row.
   // Count 256 returned words separately from their rotated page offsets.
   wire [OFFS_BITS-1:0] fill_offs = cur_offs + burst;
   wire [OFFS_BITS-1:0] fill_distance = req_offs - cur_offs;
   wire fill_prefix = req_page == cur_page && fill_distance < burst;
   wire fill_resident = hit && hit_slot != cur_slot;
   wire fill_hit_accept = state == S_FILL && fill_served && read_req && !sd_ack && (fill_prefix || fill_resident);
   logic [OFFS_BITS-1:0]     burst;
   logic [SLOT_BITS-1:0]     cur_slot;
   logic [PAGE_NUM_BITS-1:0] cur_page;
   logic [OFFS_BITS-1:0]     cur_offs;

   wire take_new = (state == S_IDLE) || (state == S_RD1);
   wire drain_ok = pw_valid && (state == S_IDLE || state == S_RD1);

   always_comb begin
      req_accept = 1'b0; rsp_valid = 1'b0; rsp_fast = 1'b0; rsp_rdata = 32'd0; busy_pause = 1'b0;
      sd_req = 1'b0; sd_we = 1'b0; sd_burst = 1'b0; sd_addr = '0; sd_wdata = 32'd0;
      mem_we = 1'b0; mem_waddr = '0; mem_wdata = 32'd0;
      mem_raddr = {cur_slot, cur_offs};
      if (drain_ok) begin
         sd_req = 1'b1; sd_we = 1'b1; sd_addr = pw_addr; sd_wdata = pw_data;
      end
      if (fill_hit_pending) begin rsp_valid = 1'b1; rsp_fast = 1'b1; rsp_rdata = mem_rdata; end
      if (state == S_RD1) begin rsp_valid = 1'b1; rsp_fast = 1'b1; rsp_rdata = mem_rdata; end
      if (take_new) begin
         mem_raddr = {hit_slot, req_offs};
         if (read_hit) begin
            req_accept = 1'b1;
         end else if (write_req) begin
            if (WRITABLE) begin
               if (pw_full) begin
                  busy_pause = 1'b1;
               end else begin
                  req_accept = 1'b1;
                  if (hit) begin
                     mem_we = 1'b1; mem_waddr = {hit_slot, req_offs}; mem_wdata = req_wdata;
                  end
               end
            end else begin
               req_accept = 1'b1;                 // ROM write: accept, no effect
            end
         end else if (read_miss) begin
            if (pw_valid) busy_pause = 1'b1;      // drain the pending write BEFORE filling
            else          busy_pause = 1'b1;      // miss: fill starts next cycle
         end
      end
      unique case (state)
         S_VICTIM: busy_pause = 1'b1;
         S_FILL: begin
            busy_pause = req_valid;
            // The original demand beat depends only on captured fill state.
            // Later words return through the synchronous RAM once written; never
            // feed a live request into the response that may advance that request.
            if (sd_ack && !fill_hit_pending && !fill_served && burst == 0) begin
               req_accept = 1'b1; rsp_valid = 1'b1; rsp_rdata = sd_rdata;
            end
            if (fill_hit_accept) begin
               req_accept = 1'b1;
               mem_raddr = {fill_prefix ? cur_slot : hit_slot, req_offs};
            end
            sd_req = 1'b1; sd_we = 1'b0; sd_burst = 1'b1;
            sd_addr = BASE + {cur_page, cur_offs};
            if (sd_ack) begin
               mem_we = 1'b1; mem_waddr = {cur_slot, fill_offs}; mem_wdata = sd_rdata;
            end
         end
         S_FILLGAP: busy_pause = 1'b1;
         S_FILLRD:  begin busy_pause = 1'b1; mem_raddr = {cur_slot, cur_offs}; end
         S_HOLDRD: begin busy_pause = req_valid; end
         default: ;
      endcase
   end

   // ================= fetch page map =================
   localparam integer FK = (FETCH_MAP < 1) ? 1 : FETCH_MAP;
   logic                     fm_valid [0:FK-1];
   logic [PAGE_NUM_BITS-1:0] fm_page  [0:FK-1];
   logic [SLOT_BITS-1:0]     fm_slot  [0:FK-1];

   wire [ADDR_BITS-1:0]      f_rel  = f_addr - BASE;
   wire [PAGE_NUM_BITS-1:0]  f_page = f_rel[OFFS_BITS +: PAGE_NUM_BITS];
   wire [OFFS_BITS-1:0]      f_offs = f_addr[OFFS_BITS-1:0];
   // the fetch address must lie inside this cache's region (BASE .. BASE + 2^(PAGE_NUM_BITS+OFFS_BITS) - 1)
   wire                      f_in_region = (f_addr >= BASE) && ((f_rel >> (PAGE_NUM_BITS + OFFS_BITS)) == '0);

   logic                  fm_hit;
   logic [SLOT_BITS-1:0]  fm_hit_slot;
   integer                fi;
   integer                fm_hit_idx;
   always_comb begin
      fm_hit = 1'b0; fm_hit_slot = '0; fm_hit_idx = 0;
      for (fi = FK-1; fi >= 0; fi = fi - 1)
         if (fm_valid[fi] && fm_page[fi] == f_page) begin fm_hit = 1'b1; fm_hit_slot = fm_slot[fi]; fm_hit_idx = fi; end
   end
   // a fill that starts THIS clock takes over cur-slot-to-be; the entry naming it must not serve this clock's fetch
   wire                  fill_start_victim  = (state == S_VICTIM) && !use_b[vic_slot];
   wire                  fill_start_invalid = take_new && read_miss && !pw_valid && have_invalid;
   wire [SLOT_BITS-1:0]  fill_start_slot    = fill_start_victim ? vic_slot : invalid_slot;
   wire                  fill_start         = fill_start_victim || fill_start_invalid;

   wire in_fill = (state == S_FILL) || (state == S_FILLGAP) || (state == S_FILLRD) || (state == S_HOLDRD);
   wire [OFFS_BITS-1:0] f_fill_distance = f_offs - cur_offs;
   wire f_partial_hit = state == S_FILL && f_page == cur_page && f_fill_distance < burst;
   always_comb begin
      f_hit = FETCH_PORT && f_valid && f_in_region && (f_partial_hit || (fm_hit &&
              !(fill_start && fm_hit_slot == fill_start_slot) &&     // a fill takes this slot over now
              !(in_fill && fm_hit_slot == cur_slot)));                 // the slot being filled (belt and braces)
      f_mem_addr = {f_partial_hit ? cur_slot : fm_hit_slot, f_offs};
   end

   // install: a fetch-tagged data read answered from a resident page (fast hit accept, or the filled miss in S_HOLDRD)
   wire                      inst_hit  = take_new && read_hit && req_fetch;
   wire                      inst_fill = (state == S_HOLDRD) && fill_fetch;
   // 2026-09-22 ladder rung 4a': the install is REGISTERED and applied one clock later (see the fmi_q_* block below),
   // so the data-port tag compare / hit no longer chains into the fetch-map move-to-front in the same clock
   // (worst path of rungs 3b and 4a: EA adder -> tag compare -> hit -> fm_install -> mtf -> fm_valid).
   wire                      fm_install_now = FETCH_PORT && (inst_hit || inst_fill);
   wire [PAGE_NUM_BITS-1:0]  inst_page_now  = inst_hit ? req_page : cur_page;
   wire [SLOT_BITS-1:0]      inst_slot_now  = inst_hit ? hit_slot : cur_slot;
   logic                     fmi_q_v;
   logic [PAGE_NUM_BITS-1:0] fmi_q_page;
   logic [SLOT_BITS-1:0]     fmi_q_slot;
   always_ff @(posedge clk) begin
      if (rst) begin fmi_q_v <= 1'b0; fmi_q_page <= '0; fmi_q_slot <= '0; end
      else if (ce) begin fmi_q_v <= fm_install_now; fmi_q_page <= inst_page_now; fmi_q_slot <= inst_slot_now; end
   end
   wire                      fm_install = fmi_q_v;
   wire [PAGE_NUM_BITS-1:0]  inst_page  = fmi_q_page;
   wire [SLOT_BITS-1:0]      inst_slot  = fmi_q_slot;
   logic                     inst_present;
   integer                   inst_idx, pi;
   always_comb begin
      inst_present = 1'b0; inst_idx = FK-1;
      for (pi = FK-1; pi >= 0; pi = pi - 1)
         if (fm_valid[pi] && fm_page[pi] == inst_page) begin inst_present = 1'b1; inst_idx = pi; end
   end

   // next map: one move-to-front operation (install: the page's existing entry or the last one makes room; fetch hit:
   // the hit entry), THEN every entry naming a slot whose fill starts this clock is removed
   logic                     nm_valid [0:FK-1];
   logic [PAGE_NUM_BITS-1:0] nm_page  [0:FK-1];
   logic [SLOT_BITS-1:0]     nm_slot  [0:FK-1];
   integer                   mtf_idx, ni;
   logic                     mtf_en;
   logic [PAGE_NUM_BITS-1:0] mtf_page;
   logic [SLOT_BITS-1:0]     mtf_slot;
   always_comb begin
      mtf_en = 1'b0; mtf_idx = 0; mtf_page = '0; mtf_slot = '0;
      if (fm_install) begin
         mtf_en = 1'b1; mtf_idx = inst_present ? inst_idx : FK-1; mtf_page = inst_page; mtf_slot = inst_slot;
      end else if (f_hit && !f_partial_hit) begin
         mtf_en = 1'b1; mtf_idx = fm_hit_idx; mtf_page = fm_page[fm_hit_idx]; mtf_slot = fm_slot[fm_hit_idx];
      end
      // Keep entry zero outside the shift loop: Quartus elaborates ni-1 even
      // when a run-time condition makes that branch unreachable at ni == 0.
      nm_valid[0] = fm_valid[0]; nm_page[0] = fm_page[0]; nm_slot[0] = fm_slot[0];
      if (mtf_en) begin
         nm_valid[0] = 1'b1; nm_page[0] = mtf_page; nm_slot[0] = mtf_slot;
      end
      for (ni = 1; ni < FK; ni = ni + 1) begin
         if (mtf_en && ni <= mtf_idx) begin
            nm_valid[ni] = fm_valid[ni-1]; nm_page[ni] = fm_page[ni-1]; nm_slot[ni] = fm_slot[ni-1];
         end else begin
            nm_valid[ni] = fm_valid[ni]; nm_page[ni] = fm_page[ni]; nm_slot[ni] = fm_slot[ni];
         end
      end
      for (ni = 0; ni < FK; ni = ni + 1) begin
         if (fill_start && nm_slot[ni] == fill_start_slot) nm_valid[ni] = 1'b0;
      end
   end

   // collision: a data-port write this clock to the word the fetch port reads this clock
   logic f_collide;
   always_comb f_collide = f_hit && mem_we && (mem_waddr == f_mem_addr);

   integer mk;
   always_ff @(posedge clk) begin
      if (rst) begin
         for (mk = 0; mk < FK; mk = mk + 1) begin fm_valid[mk] <= 1'b0; fm_page[mk] <= '0; fm_slot[mk] <= '0; end
         f_stale <= 1'b0;
      end else if (ce && FETCH_PORT) begin
         f_stale <= f_collide;
         for (mk = 0; mk < FK; mk = mk + 1) begin
            fm_valid[mk] <= nm_valid[mk]; fm_page[mk] <= nm_page[mk]; fm_slot[mk] <= nm_slot[mk];
         end
      end
   end

   integer k;
   always_ff @(posedge clk) begin
      if (rst) begin
         for (k = 0; k < NUM_PAGES; k = k + 1) begin valid[k] <= 1'b0; use_b[k] <= 1'b0; end
         fill_served <= 0; fill_fetch <= 0; fill_hit_pending <= 0;
         clk_ptr <= '0; state <= S_IDLE; burst <= '0; vic_way <= '0;
         for (k = 0; k < NSETS; k = k + 1) set_ptr[k] <= '0;
         pw_rp <= '0; pw_wp <= '0; pw_cnt <= '0;
         stat_hits <= 64'd0; stat_misses <= 64'd0; stat_pause_clocks <= 64'd0;
      end else if (ce) begin
         fill_hit_pending <= fill_hit_accept;
         // 2026-09-22 ladder rung 3: invalidate the victim the clock its fill starts (the 9/20 page-cache repair: with
         // hit-under-fill a request must never hit the old tag of a slot that is being refilled).
         if (fill_start) valid[fill_start_slot] <= 1'b0;
         if (f_hit && f_partial_hit) fill_fetch <= 1;
         if (state == S_FILL && fill_served && read_req && req_accept) begin
            stat_hits <= stat_hits + 1'b1;
            if (fill_resident) use_b[hit_slot] <= 1'b1;
            if (req_fetch && req_page == cur_page) fill_fetch <= 1;
         end
         if (busy_pause) stat_pause_clocks <= stat_pause_clocks + 64'd1;
         begin : pw_update
            logic pw_pop, pw_push;
            pw_pop  = drain_ok && sd_ack;
            pw_push = take_new && !read_hit && write_req && WRITABLE && !pw_full;
            if (pw_pop)  pw_rp <= pw_next(pw_rp);
            if (pw_push) begin pw_a[pw_wp] <= req_addr; pw_d[pw_wp] <= req_wdata; pw_wp <= pw_next(pw_wp); end
            pw_cnt <= pw_cnt + (pw_push ? 1'b1 : 1'b0) - (pw_pop ? 1'b1 : 1'b0);
         end
         if (take_new) begin
            if (read_hit) begin
               cur_slot  <= hit_slot;
               cur_offs  <= req_offs;
               use_b[hit_slot] <= 1'b1;
               stat_hits <= stat_hits + 64'd1;
               state     <= S_RD1;
            end else if (write_req && WRITABLE && !pw_full) begin
               use_b[hit_slot] <= hit ? 1'b1 : use_b[hit_slot];
               stat_hits   <= stat_hits   + (hit ? 64'd1 : 64'd0);
               stat_misses <= stat_misses + (hit ? 64'd0 : 64'd1);
               state     <= S_IDLE;
            end else if (read_miss && !pw_valid) begin
               fill_served <= 0; fill_fetch <= req_fetch;
               cur_page    <= req_page;
               cur_offs    <= req_offs;
               stat_misses <= stat_misses + 64'd1;
               burst       <= '0;
               vic_way     <= set_ptr[req_set];
               if (have_invalid) begin cur_slot <= invalid_slot; state <= S_FILL; end
               else                                              state <= S_VICTIM;
            end else begin
               state <= S_IDLE;
            end
         end else begin
            unique case (state)
               S_VICTIM: begin
                  if (!use_b[vic_slot]) begin
                     cur_slot <= vic_slot;
                     if (INDEXED) set_ptr[cur_set] <= vic_way + 1'b1;
                     else         clk_ptr <= (clk_ptr == LAST_SLOT) ? '0 : clk_ptr + 1'b1;
                     state    <= S_FILL;
                  end else begin
                     use_b[vic_slot] <= 1'b0;
                     if (INDEXED) vic_way <= vic_way + 1'b1;
                     else         clk_ptr <= (clk_ptr == LAST_SLOT) ? '0 : clk_ptr + 1'b1;
                  end
               end
               S_FILL: begin
                  if (sd_ack) begin
                     if (burst == 0) fill_served <= 1;
                     if (burst == LAST_WORD) begin
                        valid[cur_slot] <= 1'b1;
                        tag[cur_slot]   <= cur_page;
                        use_b[cur_slot] <= 1'b1;
                        state <= S_FILLRD;
                     end else begin
                        state <= S_FILL;
                     end
                     burst <= burst + 1'b1;
                  end
               end
               S_FILLGAP: state <= S_FILL;
               S_FILLRD:  state <= S_HOLDRD;
               S_HOLDRD:  state <= S_IDLE;
               default:   state <= S_IDLE;
            endcase
         end
      end
   end
endmodule
`default_nettype wire
