// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 float round to nearest (RND, USE_FP=0).
// Blind transcription of the RND macro ipp:2588-2608 (via rnd_reg which
// copies src to dst first) (.../tms320c3x/320c3x_ops.ipp).
//
// CLR_NVUF clears N,V,UF (NOT Z, NOT C). Signed man<0x7fffff80 -> round with
// mask 0xffffff00, keep exp. Else if exp<127 -> round with mask 0x7fffff00,
// exp+1. Else -> man 0x7fffff00, V|LV. OR_NUF sets N and (if exp==-128)
// UF|LUF; the overflow branch sets neither N nor UF.

module c31_rnd #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic [31:0] man,
    input  logic [7:0]  exp,
    input  logic [15:0] st_in,
    output logic [31:0] dman,
    output logic [7:0]  dexp,
    output logic [15:0] st_out
);
    localparam logic [15:0] VFLAG = 16'h0002;
    localparam logic [15:0] NFLAG = 16'h0008;
    localparam logic [15:0] UFFLAG = 16'h0010;
    localparam logic [15:0] LVFLAG = 16'h0020;
    localparam logic [15:0] LUFFLAG= 16'h0040;
    localparam logic [15:0] CLR_NVUF = NFLAG | VFLAG | UFFLAG; // 0x1A

    logic [31:0] dman_c;
    logic [7:0]  dexp_c;
    logic        ovf, use_nuf;
    always_comb begin
        dman_c  = man;      // rnd_reg copies src -> dst
        dexp_c  = exp;
        ovf     = 1'b0;
        use_nuf = 1'b0;
        if ($signed(man) < 32'sh7fff_ff80) begin
            dman_c  = (man + 32'h80) & 32'hffff_ff00;
            use_nuf = 1'b1;
        end else if ($signed(exp) < 8'sd127) begin
            dman_c  = (man + 32'h80) & 32'h7fff_ff00;
            dexp_c  = exp + 8'd1;
            use_nuf = 1'b1;
        end else begin
            dman_c  = 32'h7fff_ff00;
            ovf     = 1'b1;
        end
    end

    logic [15:0] st_c;
    always_comb begin
        st_c = st_in & ~CLR_NVUF;
        if (use_nuf) begin
            st_c = st_c
                 | (dman_c[31] ? NFLAG : 16'd0)
                 | ((dexp_c == 8'h80) ? (UFFLAG | LUFFLAG) : 16'd0);
        end
        if (ovf) st_c = st_c | (VFLAG | LVFLAG);
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin dman <= dman_c; dexp <= dexp_c; st_out <= st_c; end
    end else begin : g_comb
        assign dman = dman_c; assign dexp = dexp_c; assign st_out = st_c;
    end endgenerate
endmodule
