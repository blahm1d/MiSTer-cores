// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 integer multiply MPYI: 24x24 signed, low 32 bits, OVM saturation.
//
// Blind transcription of the pinned MAME macro:
//   ipp = .../tms320c3x/320c3x_ops.ipp
//   - #define MPYI(dreg,src1,src2) ............... ipp:2231-2247
//   - mul_32x32(sext(src1,24),sext(src2,24)) ..... ipp:2233, c31.cpp:11-16
//   The 3-operand MPYI3 (ipp:6459) reuses the same macro; only operand
//   routing differs, so this unit serves both (caller selects src1/src2).
//
// The operands are the low 24 bits of the source registers, sign-extended
// from bit 23 (util::sext(x,24)); the 48-bit signed product's low 32 bits are
// the result, or the OVM saturation limit when OVM is set and the product is
// out of int32 range. N/Z come from the low 32 bits of the UNSATURATED
// product (OR_NZ((uint32_t)_res)), so they can differ from the written
// (saturated) value; V and LV set together on out-of-range. Flags update only
// when the destination is R0-R7 (dreg_lt8).
//
// The multiply is written as one signed 24x24 product so Quartus infers a
// single DSP block (Cyclone V 27x27 signed mode).
//
// REGOUT selects a registered (1-cycle) output stage.

module c31_mpyi #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic        ovm,        // ST & OVMFLAG
    input  logic        dreg_lt8,   // destination R0-R7 -> update flags
    input  logic [23:0] src1,       // low 24 bits of operand 1
    input  logic [23:0] src2,       // low 24 bits of operand 2
    input  logic [15:0] st_in,
    output logic [31:0] result,
    output logic [15:0] st_out
);
    localparam logic [15:0] VFLAG = 16'h0002;
    localparam logic [15:0] ZFLAG = 16'h0004;
    localparam logic [15:0] NFLAG = 16'h0008;
    localparam logic [15:0] UFFLAG= 16'h0010;
    localparam logic [15:0] LVFLAG= 16'h0020;
    localparam logic [15:0] CLR_NZVUF = NFLAG | ZFLAG | VFLAG | UFFLAG; // 0x1E

    // Signed 24x24 -> 48-bit product (one DSP block).
    logic signed [47:0] prod;
    always_comb prod = $signed(src1) * $signed(src2);

    logic overflow;
    logic [31:0] res_c;
    logic [15:0] st_c;
    always_comb begin
        overflow = (prod > 48'sd2147483647) || (prod < -48'sd2147483648);
        if (!ovm || !overflow) res_c = prod[31:0];
        else                   res_c = prod[47] ? 32'h8000_0000 : 32'h7fff_ffff;

        if (dreg_lt8)
            st_c = (st_in & ~CLR_NZVUF)
                 | (prod[31] ? NFLAG : 16'd0)                 // N from low-32 product
                 | ((prod[31:0] == 32'd0) ? ZFLAG : 16'd0)    // Z from low-32 product
                 | (overflow ? (VFLAG | LVFLAG) : 16'd0);
        else
            st_c = st_in;
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin
            result <= res_c;
            st_out <= st_c;
        end
    end else begin : g_comb
        assign result = res_c;
        assign st_out = st_c;
    end endgenerate
endmodule
