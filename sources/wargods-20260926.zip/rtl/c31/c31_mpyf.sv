// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 float multiply (MPYF / mpyf, USE_FP=0).
// Blind transcription of ipp:748-820 (.../tms320c3x/320c3x_ops.ipp).
//
// PIPELINE (default TWOSTAGE=1): split at the pre-normalise boundary:
//   Stage 1 = zero-operand shortcut, mantissa unpack to 1.1.23, the 24x24
//             signed product (one DSP block), exponent add, and the 46->31
//             truncation (>>15).
//   Stage 2 = renormalise (>=2.0 up to twice; <-2.0 once), underflow/overflow
//             clamp, flag generation.
// The mid register lands right after the DSP product (the >>15 is a wire
// shift), which is the classic place to register a hard multiplier for Fmax,
// and keeps the normalise/flag logic in its own clock. Results are identical
// for TWOSTAGE 0 or 1; only latency changes (TWOSTAGE + REGOUT clocks).
//
// Separate module from c31_addsubf so MPYF3 || ADDF3 uses both concurrently.

module c31_mpyf #(
    parameter bit REGOUT   = 1'b0,
    parameter bit TWOSTAGE = 1'b1     // default: pipelined (multiply | normalise)
) (
    input  logic        clk,
    input  logic [31:0] s1man,
    input  logic [7:0]  s1exp,
    input  logic [31:0] s2man,
    input  logic [7:0]  s2exp,
    input  logic [15:0] st_in,
    output logic [31:0] dman,
    output logic [7:0]  dexp,
    output logic [15:0] st_out
);
    localparam logic [15:0] VFLAG  = 16'h0002;
    localparam logic [15:0] ZFLAG  = 16'h0004;
    localparam logic [15:0] NFLAG  = 16'h0008;
    localparam logic [15:0] UFFLAG = 16'h0010;
    localparam logic [15:0] LVFLAG = 16'h0020;
    localparam logic [15:0] LUFFLAG= 16'h0040;
    localparam logic [15:0] CLR_NZVUF = 16'h001E;

    // ---------------- Stage 1: unpack + 24x24 multiply + >>15 ----------------
    logic               s1_done_c;
    logic signed [63:0] s1_man_c;
    logic signed [15:0] s1_exp_c;
    logic [15:0]        s1_st_c;
    always_comb begin
        logic signed [31:0] m1_32, m2_32;
        logic signed [63:0] prod;
        s1_done_c = 1'b0; s1_man_c = 64'sd0; s1_exp_c = 16'sd0; s1_st_c = st_in;
        m1_32 = 32'sd0; m2_32 = 32'sd0; prod = 64'sd0;
        if (s1exp == 8'h80 || s2exp == 8'h80) begin
            s1_done_c = 1'b1;
        end else begin
            m1_32 = ($signed(s1man) >>> 8) ^ 32'sh0080_0000;   // 1.1.23
            m2_32 = ($signed(s2man) >>> 8) ^ 32'sh0080_0000;
            prod  = $signed({{32{m1_32[31]}}, m1_32}) * $signed({{32{m2_32[31]}}, m2_32});
            s1_exp_c = $signed(s1exp) + $signed(s2exp);
            s1_man_c = prod >>> 15;                            // 1.2.46 -> 1.2.31
        end
    end

    // ---------------- pipeline register (mid) ----------------
    logic               s1_done;
    logic signed [63:0] s1_man;
    logic signed [15:0] s1_exp;
    logic [15:0]        s1_st;
    generate if (TWOSTAGE) begin : g_mid
        always_ff @(posedge clk) begin
            s1_done<=s1_done_c; s1_man<=s1_man_c; s1_exp<=s1_exp_c; s1_st<=s1_st_c;
        end
    end else begin : g_nomid
        always_comb begin
            s1_done=s1_done_c; s1_man=s1_man_c; s1_exp=s1_exp_c; s1_st=s1_st_c;
        end
    end endgenerate

    // ---------------- Stage 2: normalise + flags ----------------
    logic [31:0] dman_c; logic [7:0] dexp_c; logic [15:0] st_c;
    always_comb begin
        logic signed [63:0] man64;
        logic signed [15:0] expv;
        logic uf_v, ov_v;
        uf_v = 1'b0; ov_v = 1'b0;
        man64 = s1_man; expv = s1_exp;
        if (s1_done) begin
            dman_c = 32'd0; dexp_c = 8'h80;
        end else begin
            if (man64 == 64'sd0) begin
                expv = -16'sd128; man64 = 64'sh8000_0000;
            end else if (man64 >= 64'sh1_0000_0000) begin
                man64 = man64 >>> 1; expv = expv + 16'sd1;
                if (man64 >= 64'sh1_0000_0000) begin
                    man64 = man64 >>> 1; expv = expv + 16'sd1;
                end
            end else if (man64 < -64'sh1_0000_0000) begin
                man64 = man64 >>> 1; expv = expv + 16'sd1;
            end
            if (expv <= -16'sd128) begin
                man64 = 64'sh8000_0000; expv = -16'sd128; uf_v = 1'b1;
            end else if (expv > 16'sd127) begin
                man64 = (man64 < 64'sd0) ? 64'sd0 : 64'h0000_0000_ffff_ffff;
                expv  = 16'sd127; ov_v = 1'b1;
            end
            dman_c = man64[31:0] ^ 32'h8000_0000;
            dexp_c = expv[7:0];
        end
        st_c = (s1_st & ~CLR_NZVUF)
             | (uf_v ? (UFFLAG | LUFFLAG) : 16'd0)
             | (ov_v ? (VFLAG  | LVFLAG)  : 16'd0)
             | (dman_c[31] ? NFLAG : 16'd0)
             | ((dexp_c == 8'h80) ? ZFLAG : 16'd0);
    end

    // ---------------- output register ----------------
    generate if (REGOUT) begin : g_out
        always_ff @(posedge clk) begin dman <= dman_c; dexp <= dexp_c; st_out <= st_c; end
    end else begin : g_comb
        assign dman = dman_c; assign dexp = dexp_c; assign st_out = st_c;
    end endgenerate
endmodule
