// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 float-to-integer conversion (FIX / float2int, USE_FP=0).
// Blind transcription of ipp:440-465 (.../tms320c3x/320c3x_ops.ipp).
//
// shift = 31 - exponent. shift<=0 -> saturate int32 range and (if setflags)
// V|LV. shift>31 -> man>>31 (arithmetic: 0 or -1). Else (man>>shift) with the
// bit (31-shift) toggled. Result overwrites the mantissa only (exponent
// untouched by MAME); flags update only when setflags (dest R0-R7).

module c31_float2int #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic [31:0] man,
    input  logic [7:0]  exp,
    input  logic        setflags,
    input  logic [15:0] st_in,
    output logic [31:0] result,
    output logic [15:0] st_out
);
    localparam logic [15:0] VFLAG = 16'h0002;
    localparam logic [15:0] ZFLAG = 16'h0004;
    localparam logic [15:0] NFLAG = 16'h0008;
    localparam logic [15:0] LVFLAG= 16'h0020;
    localparam logic [15:0] CLR_NZVUF = 16'h001E;

    logic signed [15:0] shift;
    logic signed [31:0] sar;                    // arithmetic-shift result (self-determined signed)
    logic [31:0] res_c;
    logic        ovf;
    always_comb begin
        shift = 16'sd31 - {{8{exp[7]}}, exp};   // 31 - (signed exp)
        ovf   = (shift <= 16'sd0);
        // Compute the arithmetic right shift in a signed context BEFORE the XOR:
        // nesting $signed(man)>>>n inside the unsigned XOR would demote it to a
        // logical shift (context-determined signedness).
        sar = $signed(man) >>> shift[4:0];
        if (ovf)
            res_c = man[31] ? 32'h8000_0000 : 32'h7fff_ffff;
        else if (shift > 16'sd31)
            res_c = {32{man[31]}};              // man >> 31 (arithmetic: 0 or -1)
        else
            res_c = sar ^ (32'd1 << (5'd31 - shift[4:0]));   // toggle bit (31-shift)
    end

    logic [15:0] st_c;
    always_comb begin
        if (setflags)
            st_c = (st_in & ~CLR_NZVUF)
                 | (res_c[31] ? NFLAG : 16'd0)
                 | ((res_c == 32'd0) ? ZFLAG : 16'd0)
                 | (ovf ? (VFLAG | LVFLAG) : 16'd0);
        else
            st_c = st_in;
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin result <= res_c; st_out <= st_c; end
    end else begin : g_comb
        assign result = res_c; assign st_out = st_c;
    end endgenerate
endmodule
