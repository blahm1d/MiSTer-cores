// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 float absolute value (ABSF, USE_FP=0).
// Blind transcription of the ABSF macro ipp:1405-1433
// (.../tms320c3x/320c3x_ops.ipp).
//
// Copy src to dst, then: exp==-128 -> man 0. man<0: if man!=0x80000000 ->
// -man; else if exp==127 -> V|LV and man 0x7fffffff; else exp+1, man 0.
// man>=0 keeps the copy. OR_NZF sets N/Z.

module c31_absf #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic [31:0] man,
    input  logic [7:0]  exp,
    input  logic [15:0] st_in,
    output logic [31:0] dman,
    output logic [7:0]  dexp,
    output logic [15:0] st_out
);
    localparam logic [15:0] VFLAG = 16'h0002;
    localparam logic [15:0] ZFLAG = 16'h0004;
    localparam logic [15:0] NFLAG = 16'h0008;
    localparam logic [15:0] LVFLAG= 16'h0020;
    localparam logic [15:0] CLR_NZVUF = 16'h001E;

    logic [31:0] dman_c;
    logic [7:0]  dexp_c;
    logic        ovf;
    always_comb begin
        dman_c = man;                 // m_r[dreg] = m_r[sreg]
        dexp_c = exp;
        ovf    = 1'b0;
        if (exp == 8'h80) begin
            dman_c = 32'd0;
        end else if (man[31]) begin   // man < 0
            if (man != 32'h8000_0000) begin
                dman_c = (~man) + 32'd1;      // -man
            end else if (exp == 8'd127) begin
                ovf    = 1'b1;
                dman_c = 32'h7fff_ffff;
            end else begin
                dexp_c = exp + 8'd1;
                dman_c = 32'd0;
            end
        end
    end

    logic [15:0] st_c;
    always_comb begin
        st_c = (st_in & ~CLR_NZVUF)
             | (dman_c[31] ? NFLAG : 16'd0)
             | ((dexp_c == 8'h80) ? ZFLAG : 16'd0)
             | (ovf ? (VFLAG | LVFLAG) : 16'd0);
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin dman <= dman_c; dexp <= dexp_c; st_out <= st_c; end
    end else begin : g_comb
        assign dman = dman_c; assign dexp = dexp_c; assign st_out = st_c;
    end endgenerate
endmodule
