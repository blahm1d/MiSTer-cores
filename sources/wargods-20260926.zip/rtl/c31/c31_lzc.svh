// SPDX-License-Identifier: BSD-3-Clause
// Shared leading-zero / leading-one counters for the C31 float units.
// Match std::countl_zero / std::countl_one on a uint32_t (0 -> 32).
// ipp uses these at 376-415 (int2float), 515-736 (addf/subf), 748-820
// (mpyf), 831-873 (norm). `include this INSIDE a module body.
function automatic [5:0] clz32(input logic [31:0] v);
    integer k; logic done;
    begin
        clz32 = 6'd32; done = 1'b0;
        for (k = 31; k >= 0; k = k - 1)
            if (!done && v[k]) begin clz32 = 6'd31 - k[5:0]; done = 1'b1; end
    end
endfunction

function automatic [5:0] clo32(input logic [31:0] v);
    integer k; logic done;
    begin
        clo32 = 6'd32; done = 1'b0;
        for (k = 31; k >= 0; k = k - 1)
            if (!done && !v[k]) begin clo32 = 6'd31 - k[5:0]; done = 1'b1; end
    end
endfunction
