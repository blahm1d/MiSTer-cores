// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 float format conversions LONG2FP / FP2LONG / SHORT2FP.
// Blind transcription of the pinned macros ipp:28-33
// (.../tms320c3x/320c3x_ops.ipp). Pure repacks, no flags.
//
//   LONG2FP(v):  man = v<<8;                exp = (int32)v >> 24
//   FP2LONG:     long = (exp<<24) | ((uint32)man >> 8)
//   SHORT2FP(v): if uint16(v)==0x8000 -> man=0, exp=-128
//                else man = v<<20;          exp = (int16)v >> 12

// 32-bit memory word -> 40-bit float.
module c31_long2fp #(parameter bit REGOUT = 1'b0) (
    input  logic        clk,
    input  logic [31:0] long_in,
    output logic [31:0] man,
    output logic [7:0]  exp
);
    logic [31:0] man_c; logic [7:0] exp_c;
    always_comb begin
        man_c = {long_in[23:0], 8'd0};   // v << 8
        exp_c = long_in[31:24];          // (int32)v >> 24 (stored int8)
    end
    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin man <= man_c; exp <= exp_c; end
    end else begin : g_comb
        assign man = man_c; assign exp = exp_c;
    end endgenerate
endmodule

// 40-bit float -> 32-bit memory word.
module c31_fp2long #(parameter bit REGOUT = 1'b0) (
    input  logic        clk,
    input  logic [31:0] man,
    input  logic [7:0]  exp,
    output logic [31:0] long_out
);
    logic [31:0] long_c;
    always_comb long_c = {exp, man[31:8]};   // (exp<<24) | (man>>8)
    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) long_out <= long_c;
    end else begin : g_comb
        assign long_out = long_c;
    end endgenerate
endmodule

// 16-bit short float -> 40-bit float.
module c31_short2fp #(parameter bit REGOUT = 1'b0) (
    input  logic        clk,
    input  logic [15:0] short_in,
    output logic [31:0] man,
    output logic [7:0]  exp
);
    logic [31:0] man_c; logic [7:0] exp_c;
    always_comb begin
        if (short_in == 16'h8000) begin
            man_c = 32'd0; exp_c = 8'h80;              // canonical zero, exp -128
        end else begin
            man_c = {short_in[11:0], 20'd0};           // v << 20
            exp_c = {{4{short_in[15]}}, short_in[15:12]}; // (int16)v >> 12
        end
    end
    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin man <= man_c; exp <= exp_c; end
    end else begin : g_comb
        assign man = man_c; assign exp = exp_c;
    end endgenerate
endmodule
