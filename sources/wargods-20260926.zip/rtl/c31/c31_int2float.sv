// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 integer-to-float conversion (FLOAT / int2float, USE_FP=0).
// Blind transcription of ipp:376-415 (.../tms320c3x/320c3x_ops.ipp).
//
// in_int = srcdst.mantissa() (the integer). Produces the 40-bit float
// {man,exp} and N/Z (never over/underflows -> V/UF cleared, not set).
// Special cases: 0 -> exp -128; -1 -> man 0, exp -1. Otherwise count
// leading zeros (positive) or ones (negative), shift, exp=31-cnt, then
// toggle the implicit bit man^0x80000000. OR_NZF reads the STORED mantissa.

module c31_int2float #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic [31:0] in_int,
    input  logic [15:0] st_in,
    output logic [31:0] man,
    output logic [7:0]  exp,
    output logic [15:0] st_out
);
    `include "c31_lzc.svh"
    localparam logic [15:0] ZFLAG = 16'h0004;
    localparam logic [15:0] NFLAG = 16'h0008;
    localparam logic [15:0] CLR_NZVUF = 16'h001E;

    logic [31:0] man_c;
    logic signed [8:0] exp_c;   // -128..30 fits
    logic [5:0] cnt;
    always_comb begin
        cnt = 6'd0;
        if (in_int == 32'd0) begin
            man_c = 32'h8000_0000; exp_c = -9'sd128;
        end else if (in_int == 32'hffff_ffff) begin
            man_c = 32'd0;         exp_c = -9'sd1;
        end else if (!in_int[31]) begin           // positive
            cnt   = clz32(in_int);
            man_c = in_int << cnt[4:0];
            exp_c = 9'sd31 - $signed({3'd0, cnt});
        end else begin                             // negative (not -1)
            cnt   = clo32(in_int);
            man_c = in_int << cnt[4:0];
            exp_c = 9'sd31 - $signed({3'd0, cnt});
        end
        man_c = man_c ^ 32'h8000_0000;             // store: toggle implicit bit
    end

    logic [31:0] man_r;
    logic [7:0]  exp_r;
    logic [15:0] st_r;
    always_comb begin
        man_r = man_c;
        exp_r = exp_c[7:0];
        st_r  = (st_in & ~CLR_NZVUF)
              | (man_c[31] ? NFLAG : 16'd0)
              | ((exp_c == -9'sd128) ? ZFLAG : 16'd0);
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin man <= man_r; exp <= exp_r; st_out <= st_r; end
    end else begin : g_comb
        assign man = man_r; assign exp = exp_r; assign st_out = st_r;
    end endgenerate
endmodule
