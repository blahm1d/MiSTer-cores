// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 float negate (NEGF / negf, USE_FP=0).
// Blind transcription of ipp:477-502 (.../tms320c3x/320c3x_ops.ipp).
//
// exp==-128 -> result 0 exp -128. Else if (man & 0x7fffffff)!=0 -> negate
// mantissa, keep exp. Else (man is 0 or 0x80000000) toggle implicit bit and
// adjust exp by -1 (man==0) or +1 (man==0x80000000, wraps int8). Sets N/Z
// only (never V/UF).

module c31_negf #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic [31:0] man,
    input  logic [7:0]  exp,
    input  logic [15:0] st_in,
    output logic [31:0] dman,
    output logic [7:0]  dexp,
    output logic [15:0] st_out
);
    localparam logic [15:0] ZFLAG = 16'h0004;
    localparam logic [15:0] NFLAG = 16'h0008;
    localparam logic [15:0] CLR_NZVUF = 16'h001E;

    logic [31:0] dman_c;
    logic [7:0]  dexp_c;
    always_comb begin
        if (exp == 8'h80) begin                       // exponent == -128
            dman_c = 32'd0;             dexp_c = 8'h80;
        end else if ((man & 32'h7fff_ffff) != 32'd0) begin
            dman_c = (~man) + 32'd1;    dexp_c = exp;  // -man
        end else begin
            dman_c = man ^ 32'h8000_0000;
            dexp_c = (man == 32'd0) ? (exp - 8'd1) : (exp + 8'd1); // int8 wrap
        end
    end

    logic [15:0] st_c;
    always_comb begin
        st_c = (st_in & ~CLR_NZVUF)
             | (dman_c[31] ? NFLAG : 16'd0)
             | ((dexp_c == 8'h80) ? ZFLAG : 16'd0);
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin dman <= dman_c; dexp <= dexp_c; st_out <= st_c; end
    end else begin : g_comb
        assign dman = dman_c; assign dexp = dexp_c; assign st_out = st_c;
    end endgenerate
endmodule
