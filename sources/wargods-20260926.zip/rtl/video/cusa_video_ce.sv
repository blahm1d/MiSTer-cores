// SPDX-License-Identifier: BSD-3-Clause
`timescale 1ns/1ps
// Nominal USA video/C31-H1 ratio: 16 2/3 MHz / 25 MHz = 2/3.
// This generates H1-quantized enables, not physical 60 ns pixel edges.
// Phase advances on accepted guest steps only. See README.md for evidence.
module cusa_video_ce #(
    parameter integer NUMERATOR = 2,
    parameter integer DENOMINATOR = 3,
    parameter integer INITIAL_PHASE = 0
) (
    input wire clk,
    input wire reset,
    input wire guest_step,
    output wire video_ce
);
    localparam integer PHASE_BITS = (DENOMINATOR > 1) ? $clog2(DENOMINATOR) : 1;
    localparam [PHASE_BITS:0] NUM = NUMERATOR;
    localparam [PHASE_BITS:0] DEN = DENOMINATOR;
    reg [PHASE_BITS-1:0] phase;
    wire [PHASE_BITS:0] next_sum = {1'b0,phase} + NUM;
    wire emit = next_sum >= DEN;
    assign video_ce = !reset && guest_step && emit;

    always @(posedge clk) begin
        if (reset) phase <= INITIAL_PHASE;
        else if (guest_step) begin
            if (emit) phase <= next_sum-DEN;
            else phase <= next_sum;
        end
    end

`ifndef SYNTHESIS
    initial begin
        if (NUMERATOR < 1 || DENOMINATOR < 1 || NUMERATOR > DENOMINATOR ||
            INITIAL_PHASE < 0 || INITIAL_PHASE >= DENOMINATOR)
            $fatal(1,"Unsupported video ratio/initial phase");
    end
`endif
endmodule
