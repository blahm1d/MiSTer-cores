// SPDX-License-Identifier: BSD-3-Clause
// bw1_pll.sv -- core-owned Cyclone V PLL for bw1. TWO outputs from one VCO (related clocks, STA-timed):
//   outclk_0 = 50 MHz / 0 ps     -> the ONE core clock: DDRAM path, sequencer, mailbox/word-mover, HDMI,
//                                   ioctl capture AND the SDRAM controller, B1 probe and SDRAM test engine
//                                   (docs/DIRECTION-20260915.md decision 5: the final core runs its SDRAM on
//                                   the 50 MHz core clock, so bw1 measures exactly that).
//   outclk_1 = 50 MHz / -3515 ps -> phase-advanced sibling forwarded to the SDRAM_CLK pin by a plain fabric
//                                   assign (donor pattern, Arcade-TUnit.sv:51). -3515 ps is the donor's
//                                   cabinet-proven value on this DE10 SDRAM board; quartus/bw1.sdc times the
//                                   pin relationship and the STA report is the authority on its margin.
// History: build 1 (2026-09-15 ~03:15 UTC) ran the SDRAM controller on a third, 100 MHz output and failed
// SDRAM_DQ capture timing by -15.6 ns (review/VERIFY.md BLOCKER-1).
// altera_pll "direct" mode lets the tool pick the VCO. Same primitive interface as cusa_pll.sv.
// NOTE: an Intel primitive; not simulable by iverilog -- the testbenches drive bw1_core's clocks directly.
module bw1_pll(input wire refclk, rst, output wire outclk_0, outclk_1, locked);
    bw1_pll_i pll_inst(.refclk(refclk),.rst(rst),.outclk_0(outclk_0),.outclk_1(outclk_1),.locked(locked));
endmodule
module bw1_pll_i(input wire refclk, rst, output wire outclk_0, outclk_1, locked);
    wire [1:0] oc;
    assign outclk_0=oc[0]; assign outclk_1=oc[1];
    altera_pll #(.fractional_vco_multiplier("false"),.reference_clock_frequency("50.0 MHz"),
        .operation_mode("direct"),.number_of_clocks(2),
        .output_clock_frequency0("50.000000 MHz"),.phase_shift0("0 ps"),.duty_cycle0(50),
        .output_clock_frequency1("50.000000 MHz"),.phase_shift1("-3515 ps"),.duty_cycle1(50),
        .pll_type("General"),.pll_subtype("General"))
    altera_pll_i(.rst(rst),.outclk(oc),.locked(locked),.fboutclk(),.fbclk(1'b0),.refclk(refclk));
endmodule
