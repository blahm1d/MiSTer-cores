# wg1.sdc -- War Gods master core (wg1). The framework sys/sys_top.sdc owns the board clocks, derive_pll_clocks
# and the cross-framework clock groups. Everything in the core runs on the one 50 MHz core clock with clock
# enables (P0019); the shipped platform adds no core exception. This file adds exactly ONE proven set:
#   1. the board-SDRAM pin constraints of bandwidth/bw1/quartus/bw1.sdc == bandwidth/gm1/quartus/gm1.sdc section 1
#      (cabinet-proven on gm1/bw1, unchanged): general[0] = outclk_0 = 50 MHz core clock; general[1] = outclk_1 =
#      50 MHz, -3515 ps, forwarded to SDRAM_CLK.
# Names carrying [N] are never double-quoted (Tcl substitution), and no constraint uses get_clocks on a PLL output:
# this file is read before sys_top.sdc derives the PLL clocks (memory mister-sdc-read-order-pll-clocks).
#
# DELIBERATELY NOT PORTED from gm1.sdc: its "section 2" DCS clock-enable multicycle. It targeted adsp2105_packed,
# which gm1 clocked with a real divided clock enable. wg1's DCS2 engine (dcs2_engine, ADSP-2115) runs at the FULL
# core rate -- its ce = ~((dsp_hold|pace_hold|sp1_hold)&at_bnd) (wg1_dcs2.sv:148) is high on consecutive clocks in
# normal operation, so a setup-multicycle-2 on those registers would be UNSOUND (it would relax a path the hardware
# clocks every cycle). If the DCS2 misses timing it is a real path to PIPELINE, not to waive with a multicycle
# (DESIGN-RULES.md s5, memory build-to-close-predict-timing-from-structure). Flag for the main session at first fit.

# ---- 1. board SDRAM (bw1.sdc / gm1.sdc section 1) ----
create_generated_clock -name SDRAM_CLK \
  -source [get_pins -compatibility_mode {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}] \
  [get_ports {SDRAM_CLK}]
set_input_delay -clock SDRAM_CLK -max 6.0 [get_ports {SDRAM_DQ[*]}]
set_input_delay -clock SDRAM_CLK -min 2.5 [get_ports {SDRAM_DQ[*]}]
set_output_delay -clock SDRAM_CLK -max 1.5  [get_ports {SDRAM_A[*] SDRAM_BA[*] SDRAM_DQ[*] SDRAM_DQML SDRAM_DQMH SDRAM_CKE SDRAM_nCS SDRAM_nRAS SDRAM_nCAS SDRAM_nWE}]
set_output_delay -clock SDRAM_CLK -min -0.8 [get_ports {SDRAM_A[*] SDRAM_BA[*] SDRAM_DQ[*] SDRAM_DQML SDRAM_DQMH SDRAM_CKE SDRAM_nCS SDRAM_nRAS SDRAM_nCAS SDRAM_nWE}]
# Read capture: SDRAM_CLK is phase-advanced, so data launched by an SDRAM_CLK edge is captured one core-clock period
# after the nearest following edge: setup multicycle 2, applied by node (wg1_sdram.sv keeps bw1's register name).
set_multicycle_path -setup -end -from [get_ports {SDRAM_DQ[*]}] -to [get_registers {*|SDRAM_DQ_in_q[*]}] 2
