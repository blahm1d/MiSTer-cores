#!/usr/bin/env bash
# Assemble an immutable Quartus snapshot for the wg1 (War Gods) master core and print the submit command. Copies the
# pinned framework sys/ (read-only), the wg1 quartus files, the wg1 RTL (core + net-new ioasic/ide/dcs2), the C31
# (rtl/c31), the wg1 memory tier (bandwidth/wg1/rtl/mem), the V-unit video / DDR plumbing, the two shared gm1
# presentation files and the cabinet-proven bw1 PLL, records SHA-256 of every copied source, and freezes a fresh
# build id. Does NOT run Quartus and does NOT submit (the main session holds the veto). Run
# bandwidth/wg1/review/preflight_wg1.py on the printed snapshot before submitting.
#
# --diag  CABINET DIAGNOSTIC variant: after the source record is written, appends
#         set_global_assignment -name VERILOG_MACRO "WG1_DIAG_MIRROR=1"
#         to the SNAPSHOT wg1.qsf only (the project QSF stays release-clean), which instantiates rtl/wg1_status_mirror.sv
#         (status block -> DDR3 0x38700000, read with diag/wg1_diag_remote.sh). Snapshot dir wg1-quartus-diag-<UTC>.
#         Preflight it with:  preflight_wg1.py <snapshot quartus dir> --diag   (needs a run_wg1_sim.py --diag-mirror
#         receipt: MATCHED_ALL + WG1_MIRROR PASS on the same sources).
set -Eeuo pipefail
DIAG=0
if [ "${1:-}" = "--diag" ]; then DIAG=1; elif [ -n "${1:-}" ]; then echo "usage: prepare.sh [--diag]" >&2; exit 2; fi
ROOT=/d/deck/fpga/cruisinusa
L=$ROOT/bandwidth/wg1
STAMP=$(date -u +%Y%m%dT%H%M%S%NZ)
if [ "$DIAG" = 1 ]; then TOP=$ROOT/build/wg1-quartus-diag-$STAMP; else TOP=$ROOT/build/wg1-quartus-$STAMP; fi
SNAP=$TOP/source
Q=$SNAP/quartus
mkdir -p "$Q" \
         "$SNAP"/rtl/wg1/ioasic "$SNAP"/rtl/wg1/ide "$SNAP"/rtl/wg1/dcs2 \
         "$SNAP"/rtl/c31/mem/sdram "$SNAP"/rtl/c31/periph \
         "$SNAP"/rtl/vunit "$SNAP"/rtl/memory "$SNAP"/rtl/integration "$SNAP"/rtl/video "$SNAP"/rtl/platform \
         "$SNAP"/rtl/gm1 "$SNAP"/rtl/bw1
# quartus dir: SDC, QSF, QPF, files.qip, scripts, MRA, tcl reports, review scripts. The emu wrapper is a quartus-dir
# source (files.qip references $wg1_quartus_root/wg1_emu.sv).
cp "$L"/quartus/*.sdc "$L"/quartus/*.qsf "$L"/quartus/*.qpf "$L"/quartus/*.qip \
   "$L"/quartus/*.sh "$L"/quartus/*.mra "$L"/quartus/*.tcl "$Q"/
cp "$L"/rtl/wg1_emu.sv "$Q"/
cp "$L"/review/sta_audit_wg1.py "$Q"/
cp "$L"/review/assembly_gate_wg1.py "$Q"/
# wg1 core RTL (everything in rtl/ except the emu wrapper, which went to quartus/)
for f in "$L"/rtl/*.sv; do [ "$(basename "$f")" = wg1_emu.sv ] || cp "$f" "$SNAP/rtl/wg1"/; done
# net-new War Gods blocks
cp "$L"/ioasic/rtl/*.sv "$SNAP/rtl/wg1/ioasic"/
cp "$L"/ide/rtl/*.sv    "$SNAP/rtl/wg1/ide"/
cp "$L"/dcs2/rtl/*.sv   "$SNAP/rtl/wg1/dcs2"/
# C31 core + include, plus the wg1 memory tier (bandwidth/wg1/rtl/mem = the P3 tier this core booted on in M4)
cp "$ROOT"/rtl/c31/*.sv "$ROOT"/rtl/c31/*.svh "$SNAP/rtl/c31"/
cp "$L"/rtl/mem/*.sv "$SNAP/rtl/c31/mem"/
cp "$ROOT"/rtl/c31/mem/sdram/*.sv "$SNAP/rtl/c31/mem/sdram"/
cp "$ROOT"/rtl/c31/periph/*.sv "$SNAP/rtl/c31/periph"/
# V-unit video, DDR mux/adapter, board I/O, video CE
cp "$ROOT"/rtl/vunit/*.sv "$SNAP/rtl/vunit"/
cp "$ROOT"/rtl/memory/*.sv "$SNAP/rtl/memory"/
cp "$ROOT"/rtl/integration/vunit_board_io.sv "$SNAP/rtl/integration"/
cp "$ROOT"/rtl/video/cusa_video_ce.sv "$SNAP/rtl/video"/
cp "$ROOT"/rtl/platform/avalon_shared_mux.sv "$ROOT"/rtl/platform/mister_ddram_adapter.sv "$SNAP/rtl/platform"/
# shared gm1 presentation (as-is), and the cabinet-proven bw1 PLL
cp "$ROOT"/bandwidth/gm1/rtl/gm1_palette_ram.sv "$ROOT"/bandwidth/gm1/rtl/gm1_fb_present.sv "$ROOT"/bandwidth/gm1/rtl/gm1_dedither.sv "$SNAP/rtl/gm1"/
cp "$ROOT"/bandwidth/bw1/rtl/core/bw1_pll.sv "$SNAP/rtl/bw1"/
cp -r "$ROOT"/platform/mister/sys "$Q"/sys
BID=$(printf 'a9520001%08x%08x%08x' $(( (RANDOM<<16)^RANDOM )) $(date -u +%s) $(( (RANDOM<<16)^RANDOM )))
printf "// wg1 frozen build id for %s\n\`define CUSA_ENGINEERING_BUILD_ID 128'h%s\n" "$STAMP" "$BID" > "$Q"/cusa_build_identity.svh
(cd "$SNAP" && find rtl quartus -type f ! -path 'quartus/sys/*' | sort | xargs sha256sum) > "$TOP/SOURCE.sha256"
if [ "$DIAG" = 1 ]; then
  # after the record: SOURCE.sha256 keeps the project QSF hash; preflight --diag checks the ONLY QSF delta is this line
  printf '\n# CABINET DIAGNOSTIC BUILD (prepare.sh --diag): wg1_status_mirror -> DDR3 0x38700000\nset_global_assignment -name VERILOG_MACRO "WG1_DIAG_MIRROR=1"\n' >> "$Q"/wg1.qsf
  echo "DIAG variant: WG1_DIAG_MIRROR=1 appended to the snapshot wg1.qsf"
fi
chmod +x "$Q"/run_fit.sh "$Q"/submit.sh "$Q"/prepare.sh 2>/dev/null || true
echo "Snapshot:  $Q"
echo "Build id:  0x$BID"
echo "wg1_core:  $(sha256sum "$SNAP/rtl/wg1/wg1_core.sv" | cut -c1-64)"
echo "PREFLIGHT (main session, before submit):"
echo "  C:/Python314/python.exe $L/review/preflight_wg1.py $(cygpath -w "$Q" 2>/dev/null || echo "$Q")$([ "$DIAG" = 1 ] && echo " --diag")"
echo "SUBMIT (main session only, after preflight):"
echo "  bash.exe $Q/submit.sh"
echo "Expected RBF on success:  $Q/output_files/wg1.rbf"
