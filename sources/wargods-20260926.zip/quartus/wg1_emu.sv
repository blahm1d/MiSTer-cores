// SPDX-License-Identifier: GPL-2.0-or-later
// wg1_emu.sv -- MiSTer emu wrapper for the War Gods core (wg1). FORK of bandwidth/gm1/rtl/gm1_emu.sv, re-keyed for
// War Gods: the Cruis'n steering cabinet (wheel/pedal ADC, motor, rumble, gear shifter, family game-select) is GONE;
// controls are 2 players x (8-way stick + 6 buttons) into the Midway I/O ASIC input words per midvunit.cpp
// INPUT_PORTS_START(wargods) (:1046-1148), plus coin/start/test/service/tilt/bill/volume. The program store is the
// IDE hard disk, mounted through the hps_io sd_* block device (VDNUM=1, WIDE=1, BLKSZ=2 -> 512-byte sectors) from an
// OSD image slot. Sound is STEREO (DCS2/ADSP-2115). P0019 (one 50 MHz core clock + clock-enable, no async crossing)
// and P0022 (power-on reset = 2-FF-synced ~locked, gates the ROM/disk capture paths) are kept from the donor.
//
// NOTE (main session): this wrapper needs a Quartus elaboration pass (the hps_io array ports sd_lba[VDNUM] etc.);
// it is NOT part of the M4 whole-board sim (tests/tb_wg1.sv drives wg1_core directly). Build veto is the main session's.
`include "cusa_build_identity.svh"
module emu (
    `include "sys/emu_ports.vh"
);
    localparam CONF_STR = {
        "WarGods;;",
        "-;",
        // War Gods hard disk image (raw .img of wargods_11-07-1996.chd). SC0 = REMEMBERED mount: Main stores the path in
        // config/<setname>.s0 and re-mounts it before the MRA ROM load (Main user_io.cpp parse_config 'S','C'), the same
        // scheme the Killer Instinct core uses (config/kinst2.s0 -> games/kinst2/kinst2.img). A plain S0 is never
        // auto-mounted under an MRA (the boot.vhd auto-mount runs only on the non-arcade path) -> DISK NOT RESPONDING.
        "SC0,IMG,Mount Disk;",
        "R0,Reset;",
        "-;",
        // r14: Audio Gain on status[11:10] (wg1_audio_gain.sv; OSD default = first label = +12 dB, as MK4 / Invasion)
        // and the Cruis'n dither option on status[7:6] (gm1_dedither.sv in wg1_core; labels + default as gm1).
        // status[4] stays reserved for the resolution DIP below.
        "O67,Dither,MAME,Soft,Dark,Raw;",
        "O[11:10],Audio Gain,+12 dB,0 dB,+6 dB,+18 dB;",
        // DIP SW1:1 CRT Type / Resolution (midvunit.cpp:1048-1050; SW1:1=1 Medium/24kHz default, 0 Standard/15kHz)
        // is deliberately NOT exposed as an OSD option (r13 decision -- see the r13 README section). Re-measured on
        // MAME 0.289 (gospel/crt15k): Standard Res programs 528x290 total / 400x256 visible, INT0 line 257; Medium
        // programs 666x432 / 512x400, INT0 line 401. MAME derives both from the SAME 16.667 MHz pixel clock
        // (midvunit_v.cpp:446-459), so Standard Res runs at 31.57 kHz / 108.8 Hz (~1.9x fast); MAME does NOT model the
        // real board's dual-res VIDCLK/2. wg1's raster (vunit_raster) already follows the programmed tuple MAME-exactly,
        // but the fixed 512x400 scanout (gm1_fb_present) does not, so the DIP alone would give a 400x256 corner image
        // at ~1.9x speed -- not sane. A real 15 kHz picture needs a forked DIP-selected scanout profile plus the
        // flagged (MAME-unmodelled) dual-res raster halving -- not bounded on this yet-unfit core. dips stays Medium.
        "-;",
        // 6 buttons per player + system. Button order matches midvunit.cpp wargods IN1/IN2 (b1..b6).
        "J1,B1,B2,B3,B4,B5,B6,Start,Coin,Test,Service;",
        "V,wg1-r14"
    };
    wire clk_sys, clk_sdram_pin, pll_locked;
    wire [127:0] status;
    wire [1:0]  buttons;
    wire [31:0] joystick_0, joystick_1;
    tri [35:0] ext_bus;
    assign ext_bus[32]=1'b0;
    assign ext_bus[15:0]=16'b0;
    tri [21:0] gamma_bus;
    assign gamma_bus[21]=1'b0;

    wire        ioctl_download, ioctl_wr;
    wire [26:0] ioctl_addr;
    wire [15:0] ioctl_dout;
    wire [15:0] ioctl_index;
    wire        ioctl_wait;
    wire [64:0] mister_rtc;

    // ---- IDE disk via the hps_io block device (VDNUM=1) ----
    wire [31:0] sd_lba_core;
    wire        sd_rd_core, sd_wr_core;
    wire        sd_ack;
    wire [15:0] sd_buff_dout;      // HPS -> core (sector data on reads)
    wire [15:0] sd_buff_din_core;  // core -> HPS (sector data on writes)
    wire [12:0] sd_buff_addr;      // hps_io drives [AW:0]=[12:0] in WIDE mode; only [7:0] used for a 512 B sector
    wire        sd_buff_wr;
    wire        img_mounted, img_readonly;
    wire [63:0] img_size;

    wire [31:0] sd_lba[1];   assign sd_lba[0] = sd_lba_core;
    wire  [5:0] sd_blk_cnt[1]; assign sd_blk_cnt[0] = 6'd0;    // one 512 B sector per request
    wire [15:0] sd_buff_din[1]; assign sd_buff_din[0] = sd_buff_din_core;
    wire        sd_rd, sd_wr, sd_ack_v;
    assign sd_rd = sd_rd_core; assign sd_wr = sd_wr_core;

    hps_io #(.CONF_STR(CONF_STR), .WIDE(1), .VDNUM(1), .BLKSZ(2)) hps_io (
        .clk_sys(clk_sys),.RTC(mister_rtc),.HPS_BUS(HPS_BUS),.EXT_BUS(ext_bus),.gamma_bus(gamma_bus),
        .joystick_0(joystick_0),.joystick_1(joystick_1),
        .ps2_kbd_clk_in(1'b1),.ps2_kbd_data_in(1'b1),.ps2_mouse_clk_in(1'b1),.ps2_mouse_data_in(1'b1),
        .ps2_kbd_led_status(3'd0),.ps2_kbd_led_use(3'd0),
        .status(status),.buttons(buttons),.status_menumask(16'b0),
        .status_in(128'b0),.status_set(1'b0),.info_req(1'b0),.info(8'b0),
        .video_rotated(1'b0),.new_vmode(1'b0),
        .ioctl_download(ioctl_download),.ioctl_index(ioctl_index),.ioctl_wr(ioctl_wr),
        .ioctl_addr(ioctl_addr),.ioctl_dout(ioctl_dout),.ioctl_wait(ioctl_wait),
        // block device (disk)
        .sd_lba(sd_lba),.sd_blk_cnt(sd_blk_cnt),.sd_rd(sd_rd),.sd_wr(sd_wr),.sd_ack(sd_ack),
        .sd_buff_addr(sd_buff_addr),.sd_buff_dout(sd_buff_dout),.sd_buff_din(sd_buff_din),.sd_buff_wr(sd_buff_wr),
        .img_mounted(img_mounted),.img_readonly(img_readonly),.img_size(img_size)
    );

    bw1_pll pll (.refclk(CLK_50M),.rst(1'b0),.outclk_0(clk_sys),.outclk_1(clk_sdram_pin),.locked(pll_locked));

    // Power-on reset (P0022): 2-FF synced ~locked on the one core clock (used by the ROM/disk capture paths).
    (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS" *)
    reg [2:0] por50_pipe=3'b111;
    always @(posedge clk_sys or negedge pll_locked) if(!pll_locked) por50_pipe<=3'b111; else por50_pipe<={por50_pipe[1:0],1'b0};
    wire por50 = por50_pipe[2];
    wire core_reset = RESET || buttons[1] || status[0];   // status[0] = OSD R0 Reset

    // ---- controls: 2 players, 8-way stick + 6 buttons, active-high "pressed" into the I/O ASIC ----
    // MiSTer joystick bits: [0]=right [1]=left [2]=down [3]=up [4]=B1 [5]=B2 [6]=B3 [7]=B4 [8]=B5 [9]=B6
    //                       [10]=Start [11]=Coin [12]=Test [13]=Service
    // I/O ASIC pN[9:0] = {b6,b5,b4,b3,b2,b1, right,left,down,up} (wg1_ioasic port).
    wire [9:0] p1 = {joystick_0[9:4], joystick_0[0], joystick_0[1], joystick_0[2], joystick_0[3]};
    wire [9:0] p2 = {joystick_1[9:4], joystick_1[0], joystick_1[1], joystick_1[2], joystick_1[3]};
    wire [3:0] coin  = {2'b00, joystick_1[11], joystick_0[11]};   // coin2, coin1
    wire [3:0] start = {2'b00, joystick_1[10], joystick_0[10]};   // start2, start1
    wire test_sw  = joystick_0[12] | joystick_1[12];
    wire service1 = joystick_0[13] | joystick_1[13];
    wire [15:0] dips = 16'hffff;   // wargods MAME default (all DIP defaults set; SW2:8 test=off, coinage USA-1)

    assign ADC_BUS='z;
    assign USER_OUT='1;
    assign {UART_RTS,UART_TXD,UART_DTR}=0;
    assign {SD_SCK,SD_MOSI,SD_CS}='z;
    `ifdef MISTER_DUAL_SDRAM
    assign {SDRAM2_DQ,SDRAM2_A,SDRAM2_BA,SDRAM2_CLK,SDRAM2_nWE,SDRAM2_nCAS,SDRAM2_nRAS,SDRAM2_nCS}='z;
    `endif
    `ifdef MISTER_FB
    assign {FB_EN,FB_FORMAT,FB_WIDTH,FB_HEIGHT,FB_BASE,FB_STRIDE}=0;
    assign FB_FORCE_BLANK=1;
      `ifdef MISTER_FB_PALETTE
      assign {FB_PAL_CLK,FB_PAL_ADDR,FB_PAL_DOUT,FB_PAL_WR}=0;
      `endif
    `endif
    assign VIDEO_ARX=13'd4; assign VIDEO_ARY=13'd3;
    assign {VGA_SL,VGA_F1,VGA_SCALER,VGA_DISABLE}=0;
    assign {HDMI_FREEZE,HDMI_BLACKOUT,HDMI_BOB_DEINT}=0;
    assign CLK_VIDEO=clk_sys;
    assign DDRAM_CLK=clk_sys;
    assign SDRAM_CLK=clk_sdram_pin;

    wire [7:0] r,g,b; wire ce,de,hs,vs; wire fault;
    wire signed [15:0] audio_l, audio_r; wire audio_ce;
    wg1_core core (
        .clk(clk_sys),.por(por50),.core_reset(core_reset),
        .ioctl_download(ioctl_download),.ioctl_wr(ioctl_wr),.ioctl_addr(ioctl_addr),.ioctl_dout(ioctl_dout),
        .ioctl_index(ioctl_index),.ioctl_wait(ioctl_wait),
        .mister_rtc(mister_rtc),
        .DDRAM_BUSY(DDRAM_BUSY),.DDRAM_DOUT_READY(DDRAM_DOUT_READY),.DDRAM_DOUT(DDRAM_DOUT),
        .DDRAM_ADDR(DDRAM_ADDR),.DDRAM_BURSTCNT(DDRAM_BURSTCNT),.DDRAM_BE(DDRAM_BE),
        .DDRAM_DIN(DDRAM_DIN),.DDRAM_RD(DDRAM_RD),.DDRAM_WE(DDRAM_WE),
        .SDRAM_DQ(SDRAM_DQ),.SDRAM_A(SDRAM_A),.SDRAM_BA(SDRAM_BA),.SDRAM_DQML(SDRAM_DQML),.SDRAM_DQMH(SDRAM_DQMH),
        .SDRAM_nCS(SDRAM_nCS),.SDRAM_nCAS(SDRAM_nCAS),.SDRAM_nRAS(SDRAM_nRAS),.SDRAM_nWE(SDRAM_nWE),.SDRAM_CKE(SDRAM_CKE),
        .sd_lba(sd_lba_core),.sd_rd(sd_rd_core),.sd_wr(sd_wr_core),.sd_ack(sd_ack),
        .sd_buff_addr(sd_buff_addr[7:0]),.sd_buff_dout(sd_buff_dout),.sd_buff_din(sd_buff_din_core),.sd_buff_wr(sd_buff_wr),
        .img_mounted(img_mounted),.img_readonly(img_readonly),.img_size(img_size),
        .dips(dips),.coin(coin),.start(start),
        .tilt(1'b0),.test_sw(test_sw),.service1(service1),.vol_down(1'b0),.vol_up(1'b0),.bill(1'b0),
        .p1(p1),.p2(p2),.dither_mode(status[7:6]),
        .audio_l(audio_l),.audio_r(audio_r),.audio_ce(audio_ce),
        .vga_ce(ce),.vga_de(de),.vga_hs(hs),.vga_vs(vs),.vga_r(r),.vga_g(g),.vga_b(b),.fault(fault),
        .loader_done(),.dcs_rom_loaded(),.game_running(),.instructions(),.cpu_pc(),.presented_frames(),.boot_pc_o());

    assign CE_PIXEL=ce; assign VGA_DE=de; assign VGA_HS=hs; assign VGA_VS=vs;
    assign VGA_R=r; assign VGA_G=g; assign VGA_B=b;
    // r14 OSD Audio Gain (wg1_audio_gain.sv, borrowed as-is from the Zeus core) on status[11:10]: the DCS2 DAC words
    // are MAME's level; x1/x2/x4/x8 with saturation, one register stage, straight to the pins. There is no audio filter
    // in the wg1 chain (the inherited, unwired O3 Sound filter entry was removed in r14; status[3] is
    // unused), so the order is the Zeus one: DAC -> gain -> AUDIO_L/R.
    // OSD entry s -> gain code: s = 0 is AUDIO_GAIN_DEFAULT (+12 dB), s = 1..3 the remaining codes ascending.
    localparam [1:0] AUDIO_GAIN_DEFAULT = 2'd2;   // 0 = 0 dB, 1 = +6, 2 = +12, 3 = +18 dB
    wire [1:0] gain_osd = status[11:10];
    wire [1:0] gain_code = (gain_osd == 2'd0) ? AUDIO_GAIN_DEFAULT :
                           (gain_osd - 2'd1 >= AUDIO_GAIN_DEFAULT) ? gain_osd : gain_osd - 2'd1;
    wire signed [15:0] audio_gl, audio_gr;
    wg1_audio_gain u_gain (.clk(clk_sys), .code(gain_code), .in_l(audio_l), .in_r(audio_r), .out_l(audio_gl), .out_r(audio_gr));
    assign AUDIO_L=audio_gl; assign AUDIO_R=audio_gr; assign AUDIO_MIX=0; assign AUDIO_S=1;
    assign {LED_DISK,LED_POWER,BUTTONS}=0;
    assign LED_USER=fault;
endmodule
