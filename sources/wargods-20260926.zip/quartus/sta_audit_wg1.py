"""Strict four-corner timing audit of a wg1 (War Gods) fit. Forked from bandwidth/gm1/review/sta_audit_gm1.py.

usage: C:\\Python314\\python.exe D:\\deck\\fpga\\cruisinusa\\bandwidth\\wg1\\review\\sta_audit_wg1.py <snapshot quartus dir> [out.json]
Reads output_files/wg1.fit.rpt, wg1.sta.rpt, wg1.map.rpt and sdram_io_timing.txt (quartus/sdram_io_report.tcl) and
writes output_files/sta_audit.json: area, every clock's worst setup/hold/recovery/removal/minimum-pulse-width slack at
every corner, the SDRAM pin-path slacks, and a verdict. FAIL on any negative slack at any corner in any class, any
unparsed section, any wg1.sdc constraint TimeQuest ignored (Warnings 332174 / 332049), or any combinational loop
(Warning 332125 or map-report loop cells). Never reports a number it did not parse.

NOTE vs gm1: wg1.sdc has NO DCS clock-enable multicycle (wg1's DCS2 engine runs at the full core rate -- see wg1.sdc),
so the gm1 audit's DCS-multicycle-applied check is deliberately dropped. Adding it back would demand a constraint the
wg1 SDC intentionally omits.
"""
from pathlib import Path
import json
import re
import sys

REV = 'wg1'
CORNERS = ('Slow 1100mV 100C', 'Slow 1100mV -40C', 'Fast 1100mV 100C', 'Fast 1100mV -40C')
KINDS = ('Setup', 'Hold', 'Recovery', 'Removal', 'Minimum Pulse Width')


def grab(pattern, text):
    m = re.search(pattern, text)
    return int(m.group(1).replace(',', '')) if m else None


def summary_rows(sta, corner, kind):
    block = re.search(r'; %s Model %s Summary\s*;.*?\n((?:[;+].*\n)+)' % (re.escape(corner), re.escape(kind)), sta)
    rows = []
    if block:
        for line in block.group(1).splitlines():
            m = re.match(r'^;\s*(.+?)\s*;\s*(-?[0-9.]+)\s*;\s*(-?[0-9.]+)\s*;', line)
            if m and m.group(1) != 'Clock':
                rows.append({'clock': m.group(1), 'slack_ns': float(m.group(2)), 'tns_ns': float(m.group(3))})
    return rows if block else None


def sdram_paths(text):
    sections = []
    for sec in re.split(r'(?=^-+\n; Command Info ;)', text, flags=re.M):
        pm = re.search(r'-panel_name\s+(\S+)', sec)
        if not pm:
            continue
        found = re.search(r'Found (\d+) \w+ paths \((\d+) violated\)\.\s+Worst case slack is (-?[0-9.]+)', sec)
        sections.append({'panel': pm.group(1), 'paths_found': int(found.group(1)) if found else None,
                         'violated': int(found.group(2)) if found else None,
                         'worst_slack_ns': float(found.group(3)) if found else None})
    return sections


def main():
    qdir = Path(sys.argv[1])
    out = qdir / 'output_files'
    fit = (out / ('%s.fit.rpt' % REV)).read_text(encoding='utf-8', errors='replace')
    sta = (out / ('%s.sta.rpt' % REV)).read_text(encoding='utf-8', errors='replace')
    res = {'schema': 'wg1-sta-audit-v1', 'project': str(qdir),
           'alm': grab(r'Logic utilization \(in ALMs\)\s*;\s*([0-9,]+)', fit),
           'registers': grab(r'Total registers\s*;\s*([0-9,]+)', fit),
           'ram_blocks': grab(r'Total RAM Blocks\s*;\s*([0-9,]+)', fit),
           'dsp': grab(r'Total DSP Blocks\s*;\s*([0-9,]+)', fit),
           'corners': {}, 'violations': [], 'unparsed': []}
    for corner in CORNERS:
        res['corners'][corner] = {}
        for kind in KINDS:
            rows = summary_rows(sta, corner, kind)
            if not rows:
                if kind in ('Setup', 'Hold'):
                    res['unparsed'].append('%s %s' % (corner, kind))
                continue
            res['corners'][corner][kind] = rows
            for r in rows:
                if r['slack_ns'] < 0:
                    res['violations'].append('%s %s %s %.3f ns' % (corner, kind, r['clock'], r['slack_ns']))
                if r['tns_ns'] != 0:
                    res['violations'].append('%s %s %s nonzero TNS %.3f ns' % (corner, kind, r['clock'], r['tns_ns']))
    ignored = [ln.strip() for ln in sta.splitlines() if re.search(r'Warning \((332174|332049)\).*wg1\.sdc', ln)]
    res['ignored_wg1_sdc_constraints'] = ignored
    if ignored:
        res['violations'].append('wg1.sdc constraints ignored by TimeQuest: %d warning line(s)' % len(ignored))
    loops = [ln.strip() for ln in (fit + '\n' + sta).splitlines() if re.search(r'Warning \(332125\)', ln)]
    res['combinational_loop_warnings'] = loops
    if loops:
        res['violations'].append('combinational loop warning(s) from the fitter/TimeQuest: %d line(s)' % len(loops))
    map_path = out / ('%s.map.rpt' % REV)
    if map_path.exists():
        m = re.search(r'Number of logic cells representing combinational loops\s*;\s*([0-9,]+)',
                      map_path.read_text(encoding='utf-8', errors='replace'))
        res['map_combinational_loop_cells'] = int(m.group(1).replace(',', '')) if m else 0
        if res['map_combinational_loop_cells']:
            res['violations'].append('map report: %d logic cell(s) representing combinational loops'
                                     % res['map_combinational_loop_cells'])
    else:
        res['unparsed'].append('%s.map.rpt missing' % REV)
    io_path = out / 'sdram_io_timing.txt'
    if io_path.exists():
        res['sdram_io'] = sdram_paths(io_path.read_text(encoding='utf-8', errors='replace'))
        for s in res['sdram_io']:
            if s['worst_slack_ns'] is None:
                res['unparsed'].append('SDRAM %s slack' % s['panel'])
            elif s['worst_slack_ns'] < 0:
                res['violations'].append('SDRAM %s %.3f ns' % (s['panel'], s['worst_slack_ns']))
        if not res['sdram_io']:
            res['unparsed'].append('sdram_io_timing.txt sections')
    else:
        res['unparsed'].append('sdram_io_timing.txt missing')
    for field in ('alm', 'registers', 'ram_blocks', 'dsp'):
        if res[field] is None:
            res['unparsed'].append('fit area field: ' + field)
    res['result'] = 'FAIL' if (res['violations'] or res['unparsed']) else 'PASS'
    out_json = Path(sys.argv[2]) if len(sys.argv) > 2 else out / 'sta_audit.json'
    out_json.write_text(json.dumps(res, indent=1) + '\n', encoding='utf-8')
    print(json.dumps({k: res[k] for k in ('alm', 'ram_blocks', 'dsp', 'violations', 'unparsed', 'result')}, indent=1))
    return 0 if res['result'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
