#!/usr/bin/env bash
# Enter the shared Quartus FIFO with the wg1 (War Gods) master core fit. The MAIN SESSION holds the build veto.
# Mirrors bandwidth/gm1/quartus/submit.sh (guardian v9: FPGA_QUARTUS_SIMULATOR_WORKERS deliberately NOT exported).
set -Eeuo pipefail
export MSYS2_ARG_CONV_EXCL="*"
HERE="$(cd "$(dirname "$0")" && pwd)"   # the prepared snapshot's quartus dir
FIFO=/d/deck/fpga/shared_quartus_fifo.sh
QBIN=/c/intelFPGA_lite/17.0/quartus/bin64
hash() { sha256sum -- "$1" | awk '{print tolower($1)}'; }
RUNNER="$HERE/run_fit.sh"
mkdir -p /d/deck/fpga/cruisinusa/build/wg1-fit-logs
exec /c/Program\ Files/Git/bin/bash.exe "$FIFO" \
  --tag cruisinusa:wg1_master --cwd "$HERE" --log /d/deck/fpga/cruisinusa/build/wg1-fit-logs/wg1 \
  --command-sha256 "$(hash "$RUNNER")" \
  --expect-first-worker quartus_map \
  --expect-first-worker-path 'C:\intelFPGA_lite\17.0\quartus\bin64\quartus_map.exe' \
  --expect-first-worker-sha256 "$(hash "$QBIN/quartus_map.exe")" \
  -- "$RUNNER"
