#!/usr/bin/env bash
# make_wargods_img.sh -- extract the War Gods IDE hard disk from its MAME CHD to a RAW sector image the MiSTer wg1
# core mounts through the OSD "Mount Disk" slot (hps_io VDNUM=1 WIDE=1 BLKSZ=2 -> wg1_ide). The MRA delivers only the
# two EPROMs (u41 index 1, u2 index 2); the disk is a separate block device an MRA cannot carry (see DISK_README.md).
#
# usage: bash make_wargods_img.sh [CHD] [OUT.img]
#   CHD default: V:/mame/MAME 0.288/wargods/wargods_11-07-1996.chd  (the set the M0 golden + census were built on)
#   OUT default: ./wargods.img
# Needs chdman on PATH (MAME tools; here /c/ProgramData/chocolatey/bin/chdman). Produces a ~420 MiB raw image
# (822,016 x 512-byte sectors, CHS 988/16/52). chdman extracthd emits a headerless raw image = exactly the sector
# stream wg1_ide reads by LBA; no VHD/partition wrapper.
set -Eeuo pipefail
CHD="${1:-V:/mame/MAME 0.288/wargods/wargods_11-07-1996.chd}"
OUT="${2:-./wargods.img}"
CHDMAN="${CHDMAN:-$(command -v chdman || echo /c/ProgramData/chocolatey/bin/chdman)}"
[ -x "$CHDMAN" ] || { echo "chdman not found (set CHDMAN=/path/to/chdman)"; exit 2; }
[ -f "$CHD" ]    || { echo "CHD not found: $CHD"; exit 2; }
echo "chdman extracthd: $CHD -> $OUT"
"$CHDMAN" extracthd -i "$CHD" -o "$OUT" -f
SZ=$(stat -c %s "$OUT" 2>/dev/null || wc -c < "$OUT")
echo "raw image: $OUT  bytes=$SZ  sectors=$(( SZ / 512 ))"
echo "sha256: $(sha256sum "$OUT" | cut -c1-64)"
echo
echo "INSTALL (on the MiSTer SD card):"
echo "  1. copy $OUT to  /media/fat/games/WarGods/wargods.img   (create the folder if absent)"
echo "  2. load the War Gods core (Arcade > WarGods.mra)"
echo "  3. OSD (F12) > Mount Disk > browse to wargods.img"
echo "  The disk is NOT auto-mounted by the MRA; mount it from the OSD (the core keeps running once mounted)."
