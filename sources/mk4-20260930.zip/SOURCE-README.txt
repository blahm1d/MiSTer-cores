Mortal Kombat 4 (Zeus 1) - v9 fighter lighting and timing closure
RBF SHA-256: dceda52210d0bcf4941dc4df22f2c98bb5cad9eacd95bdcadf655ac6da0562d6

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: mk4-lighting-v9-scaler-tns-20260930
The compiled binary's validation status is recorded in the feed catalog.
