#!/usr/bin/env bash
set -Eeuo pipefail
export MSYS2_ARG_CONV_EXCL="*"
cd "/d/deck/fpga/zeus/zeus1/build/mk4-lighting-v9-scaler-tns-20260930/source/quartus"
QBIN=/c/intelFPGA_lite/17.0/quartus/bin64
phase=map
trap 'rc=$?; printf "exit=%s\nlast_phase=%s\nfinished_utc=%s\n" "$rc" "$phase" "$(date -u +%FT%TZ)" > ../../terminal-receipt.txt' EXIT
echo "The next controlled worker in this ticket is the pinned Quartus executable."
"$QBIN/quartus_map.exe" zk4
phase=scaler_map_gate
"C:/Python314/python.exe" ../../scaler_map_gate.py output_files/zk4.map.rpt | tee ../../scaler-map-verdict.txt
phase=fit
"$QBIN/quartus_fit.exe" zk4
phase=sta
"$QBIN/quartus_sta.exe" zk4
phase=path_report
"$QBIN/quartus_sta.exe" -t "D:/deck/fpga/zeus/zeus1/build/mk4-lighting-v9-scaler-tns-20260930/paths.tcl" > ../../closure-paths.txt 2>&1
phase=timing_gate
"C:/Python314/python.exe" ../../timing_gate.py output_files | tee ../../sta-verdict.txt
phase=assembly
"$QBIN/quartus_asm.exe" zk4
sha256sum output_files/zk4.rbf > ../../rbf-sha256.txt
phase=complete
echo MK4_LIGHTING_V9_SCALER_TNS_BUILD_COMPLETE
