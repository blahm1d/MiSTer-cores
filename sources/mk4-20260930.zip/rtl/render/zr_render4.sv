// zr_render4.sv -- the Zeus 1 (MK4) RENDERER as one block: front end v5 -> setup v9 -> pixel pipe v9, glue in M10K (stream
// buffer, extent FIFO, object queue: zr_rfifo / zr_sdp). zr_render3 was the same chain with flop glue and setups v6-v8.
// CPU register writes in; wave RAM traffic out. Gate: tb_zr_render.cpp replays the capture's CPU writes and compares
// wave RAM 1 (both frame buffers) and the render buffer's on-chip depth against MAME's frame dumps -- end to end,
// the whole renderer against MAME, with no golden model in the loop.
//
// The glue is a record parser on the front end's output stream (zr1 --fronttap format):
//   RB  (render base)  -> applied once every earlier polygon's extents have reached the pixel pipe
//   CLR (clear)        -> the pixel pipe's clear, same ordering rule
//   QUD (quad)         -> the object is queued, the four vertices + cliprect start the setup engine
//   HWW / HRD          -> nothing here: the front end already did the wave RAM access
//   DBQ (debug quad)   -> not supported (MK4 never draws one; zr1 REACH debug_quads = 0 on every capture): sticky flag
// Objects travel beside the setup engine, not through it: setup holds up to three polygons (front stage + two slots),
// so a 4-deep object queue pops at each polygon's last extent (setup's ext_last). A polygon the y clip removes produces
// no extents: setup pulses `rejected` while it is still in the front stage, i.e. it is the newest queued object, so
// the queue drops its TAIL.
module zr_render4 import fp32_pkg::*; #(parameter int SB_AW = 9, parameter int EQ_AW = 4, parameter int OQ_AW = 5) (
  input  logic        clk,
  input  logic        rst,
  // CPU side (zeus_w)
  input  logic        wr_valid,
  output logic        wr_ready,
  input  logic [9:0]  wr_off,
  input  logic [31:0] wr_data,
  input  logic [9:0]  rd_off,
  output logic [31:0] rd_data,
  // front end's wave RAM port (models, host access): pipelined, in-order responses
  output logic        fm_req, fm_we, fm_ram, output logic [20:0] fm_blk, output logic [3:0] fm_lanes,
  output logic [63:0] fm_wdata, input logic fm_gnt, input logic fm_rvalid, input logic [63:0] fm_rdata,
  // pixel pipe's wave RAM ports
  output logic        w0_req, output logic [20:0] w0_line, input logic w0_gnt, input logic w0_rvalid, input logic [63:0] w0_data,
  output logic        cw_valid, input logic cw_ready, output logic [31:0] cw_addr, cw_data, output logic [1:0] cw_mask,
  output logic        cr_req, output logic [31:0] cr_addr, input logic cr_gnt, input logic cr_rvalid, input logic [15:0] cr_data,
  // initial render base (the seed's register 0x84, as the front end would have emitted it)
  input  logic [31:0] rb_init,
  input  logic [16:0] dbg_daddr, output logic [15:0] dbg_ddata,
  output logic [31:0] rb_now,
  output logic        idle,
  output logic        unsupported,              // sticky: a DBQ record arrived
`ifdef ZR_SEED
  input  logic        sd_we, input logic [3:0] sd_sel, input logic [9:0] sd_idx, input logic [31:0] sd_data,
  output logic [31:0] dbg_state [20],
  output logic [31:0] st_cen [21],              // per-block census for the testbench (sim only)
`endif
  output logic [31:0] st_quads, st_polys, st_rejected, st_extents,
  // coupling census: every block fits a frame alone (front 70 %, setup 51 %, pixel 55 %) but the chain measured ~990 K
  // clocks per 882 K frame, so these count where the blocks wait on each other
  output logic [31:0] st_clk, st_wsetup, st_wdrain, st_extstall, st_pixstarve, st_frontwait
);
  // census counters count only when ZR_CENSUS is defined (every simulation runner); synthesis removes them
`ifdef ZR_CENSUS
  localparam logic [31:0] CEN = 32'd1;
`else
  localparam logic [31:0] CEN = 32'd0;
`endif
  // ================= front end =================
  logic f_valid, f_ready, f_idle; logic [31:0] f_word;
  logic fo_v, fo_r; logic [31:0] fo_w; logic [SB_AW:0] sb_cnt;           // the front end's raw output (v2: into the stream buffer)
  logic [31:0] f_q, f_c, f_e, f_x, f_b, f_m, f_t, f_z, f_p, f_o, f_d;
  zr_front5 u_front (.clk, .rst, .lighting_disable(1'b0), .wr_valid, .wr_ready, .wr_off, .wr_data, .rd_off, .rd_data,
    .m_req(fm_req), .m_we(fm_we), .m_ram(fm_ram), .m_blk(fm_blk), .m_lanes(fm_lanes), .m_wdata(fm_wdata),
    .m_gnt(fm_gnt), .m_rvalid(fm_rvalid), .m_rdata(fm_rdata), .o_valid(fo_v), .o_ready(fo_r), .o_word(fo_w),
    .idle(f_idle),
`ifdef ZR_SEED
    .sd_we, .sd_sel, .sd_idx, .sd_data, .dbg_state,
`endif
    .st_quads(f_q), .st_culled(f_c), .st_emitted(f_e), .st_exc(f_x), .st_busy(f_b),
    .st_mem(f_m), .st_tr(f_t), .st_zc(f_z), .st_proj(f_p), .st_emit(f_o), .st_dec(f_d));

  // ================= v2: stream buffer, front end -> parser =================
  // Measured on v1: a quad waited for setup's front stage 42 % of the time, and that stall ran straight back into the
  // front end and the CPU. 2**SB_AW words (~12 quads at 512) let the front end keep producing while setup is busy.

  zr_rfifo #(32, SB_AW) u_sb (.clk, .rst, .in_valid(fo_v), .in_ready(fo_r), .in_data(fo_w),
    .out_valid(f_valid), .out_ready(f_ready), .out_data(f_word), .empty());

  // ================= setup engine =================
  logic s_start, s_in_ready, s_idle, s_rejected, s_ev, s_er, s_exc, s_last, s_hazard;
  logic [31:0] s_vin [4][6]; logic signed [31:0] s_clip [4];
  logic signed [31:0] s_scan; logic signed [15:0] s_sx, s_ex; logic [31:0] s_st [4], s_dp [4];
  logic [31:0] s_c0, s_c1, s_c2, s_c3;
  zr_setup9 u_setup (.clk, .rst, .start(s_start), .in_ready(s_in_ready), .vin(s_vin),
    .clip_min_x(s_clip[0]), .clip_max_x(s_clip[1]), .clip_min_y(s_clip[2]), .clip_max_y(s_clip[3]),
    .idle(s_idle), .rejected(s_rejected), .ext_valid(s_ev), .ext_ready(s_er), .ext_scan(s_scan),
    .ext_startx(s_sx), .ext_stopx(s_ex), .ext_start(s_st), .ext_dpdx(s_dp), .ext_exc(s_exc), .ext_last(s_last),
    .hazard(s_hazard), .st_clk(s_c0), .st_fe(s_c1), .st_a(s_c2), .st_b(s_c3));

  // ================= object queue (v4: M10K) =================
  // v3 kept 2**OQ_AW object records (245 bits each) in flops with a combinational read -- ~7.8 K registers that no block
  // fit counted. v4: a simple-dual-port RAM. The head's record is read with the pop folded into the address (the clock
  // a polygon's last extent is taken, the RAM already reads the NEXT slot), so the pixel pipe sees no bubble; a push
  // into the slot being read in the same clock (the queue was empty, or its only entry is leaving) is forwarded.
  typedef struct packed {
    logic [31:0] ctrl, alpha, blend, texbase, palbase;
    logic [15:0] solid, trans, texw, voff; logic signed [15:0] zoff;
    logic dtest, dwrite; logic [2:0] texfmt;
  } obj_t;
  logic [OQ_AW-1:0] oq_w, oq_r; logic [OQ_AW:0] oq_n;
  obj_t cur;                                             // the object being assembled from a QUD record
  obj_t head, oq_q, bp_d; logic bp_v;
  logic oq_push, oq_pop, oq_drop; logic [OQ_AW-1:0] oq_wslot, oq_ra;
  always_comb begin
    oq_push = s_start; oq_pop = p_ev && p_er && e_out.last; oq_drop = s_rejected;
    oq_wslot = oq_drop ? oq_w - 1'b1 : oq_w;
    oq_ra = oq_pop ? oq_r + 1'b1 : oq_r;
  end
  zr_sdp #($bits(obj_t), OQ_AW) u_oq (.clk, .we(oq_push), .waddr(oq_wslot), .wdata(cur), .raddr(oq_ra), .rdata(oq_q));
  always_ff @(posedge clk) begin bp_v <= oq_push && oq_wslot == oq_ra; bp_d <= cur; end
  assign head = bp_v ? bp_d : oq_q;

  // ================= v2: extent FIFO, setup -> pixel pipe =================
  // Measured on v1: the pixel pipe was STARVED 62 % of the time while setup waited on it 27 % -- burstiness with no
  // buffer (setup emits a polygon's extents in a burst; the pixel pipe drains them at a rate set by extent length).
  // Objects now pop when the PIXEL PIPE takes a polygon's last extent, so the object queue also covers every polygon
  // with extents waiting in this FIFO.
  typedef struct packed { logic signed [31:0] scan; logic signed [15:0] sx, ex; logic [2:0][31:0] st, dp; logic last; } ext_t;   // v4: intensity (3) is the MK4 constant
  ext_t e_in, e_out; logic e_ov, e_or; logic eq_empty;
  always_comb begin
    e_in.scan = s_scan; e_in.sx = s_sx; e_in.ex = s_ex; e_in.last = s_last;
    for (int k = 0; k < 3; k++) begin e_in.st[k] = s_st[k]; e_in.dp[k] = s_dp[k]; end
  end
  logic [31:0] e_st [4], e_dp [4];
  always_comb begin for (int k = 0; k < 3; k++) begin e_st[k] = e_out.st[k]; e_dp[k] = e_out.dp[k]; end e_st[3] = '0; e_dp[3] = '0; end
  zr_rfifo #($bits(ext_t), EQ_AW) u_eq (.clk, .rst, .in_valid(s_ev), .in_ready(s_er), .in_data(e_in),
    .out_valid(e_ov), .out_ready(e_or), .out_data(e_out), .empty(eq_empty));

  // ================= pixel pipe =================
  logic p_ev, p_er, p_cv, p_cr, p_idle; logic [31:0] rb;
  logic [31:0] p_ml, p_pl, p_sc, p_px, p_pf;
  assign p_ev = e_ov && (oq_n != 0);
  assign e_or = p_er && (oq_n != 0);
  zr_pixel9 u_pixel (.clk, .rst, .ext_valid(p_ev), .ext_ready(p_er), .scan(e_out.scan), .startx(e_out.sx), .stopx(e_out.ex),
    .p_start(e_st), .p_dpdx(e_dp), .o_ctrl(head.ctrl), .o_alpha(head.alpha), .o_blend(head.blend),
    .o_solid(head.solid), .o_trans(head.trans), .o_texw(head.texw), .o_voff(head.voff), .o_zoff(head.zoff),
    .o_dtest(head.dtest), .o_dwrite(head.dwrite), .o_texfmt(head.texfmt), .o_texbase(head.texbase),
    .o_palbase(head.palbase), .rb_base(rb), .clr_valid(p_cv), .clr_ready(p_cr),
    .w0_req, .w0_line, .w0_gnt, .w0_rvalid, .w0_data, .cw_valid, .cw_ready, .cw_addr, .cw_data, .cw_mask,
    .cr_req, .cr_addr, .cr_gnt, .cr_rvalid, .cr_data, .dbg_daddr, .dbg_ddata, .idle(p_idle),
    .st_miss_lines(p_ml), .st_pal_loads(p_pl), .st_stall_clocks(p_sc), .st_pixels(p_px), .st_pf_lines(p_pf));
  assign rb_now = rb;
`ifdef ZR_SEED
  // census: front phases, setup phases, pixel-pipe stall sources (cr = destination read, w0 = texture/palette line)
  logic [31:0] c_cr, c_w0, c_pbusy, c_fbusy;
  always_ff @(posedge clk)
    if (rst) begin c_cr <= 0; c_w0 <= 0; c_pbusy <= 0; c_fbusy <= 0; end
    else begin
      if (cr_req) c_cr <= c_cr + 1; if (w0_req) c_w0 <= c_w0 + 1;
      if (!p_idle) c_pbusy <= c_pbusy + 1; if (!f_idle) c_fbusy <= c_fbusy + 1;
    end
  assign st_cen = '{f_q, f_b, f_m, f_t, f_z, f_p, f_o, f_d, s_c0, s_c1, s_c2, s_c3,
                    p_ml, p_pl, p_sc, p_px, c_cr, c_w0, c_pbusy, c_fbusy, p_pf};
`endif

  // ================= record parser =================
  typedef enum logic [2:0] { R_TAG, R_BODY, R_WAITDRAIN, R_CLR, R_START } rst_t;
  rst_t rs; logic [31:0] tag, rbv; logic [5:0] wi, wn; logic [1:0] vi; logic [2:0] fi;   // vertex / field of a QUD float
  logic drained; assign drained = s_idle && (oq_n == 0) && !s_start && eq_empty;
  assign f_ready = (rs == R_TAG) || (rs == R_BODY);
  assign s_start = (rs == R_START) && s_in_ready && (oq_n != (OQ_AW+1)'(2**OQ_AW));
  assign p_cv = (rs == R_CLR);
  assign idle = (rs == R_TAG) && f_idle && drained && p_idle && !f_valid;

  // record lengths (words after the tag)
  function automatic logic [5:0] body_len(input logic [31:0] t);
    case (t)
      32'h52423031: return 6'd1;   // RB
      32'h434C5231: return 6'd4;   // CLR
      32'h51554431: return 6'd41;  // QUD
      32'h44425131: return 6'd13;  // DBQ
      32'h48575731: return 6'd5;   // HWW
      32'h48524431: return 6'd4;   // HRD
      default:      return 6'd0;
    endcase
  endfunction

  always_ff @(posedge clk) begin
    if (rst) begin
      rs <= R_TAG; oq_w <= '0; oq_r <= '0; oq_n <= '0; rb <= rb_init; unsupported <= 1'b0;
      st_quads <= 0; st_polys <= 0; st_rejected <= 0; st_extents <= 0;
      st_clk <= 0; st_wsetup <= 0; st_wdrain <= 0; st_extstall <= 0; st_pixstarve <= 0; st_frontwait <= 0;
    end else begin
      st_clk <= st_clk + CEN;
      if (rs == R_START && !s_start) st_wsetup <= st_wsetup + CEN;           // a quad waits for setup's front stage
      if (rs == R_WAITDRAIN || rs == R_CLR) st_wdrain <= st_wdrain + CEN;     // RB / CLR wait for the pipe to drain
      if (s_ev && !s_er) st_extstall <= st_extstall + CEN;                   // setup waits: the extent FIFO is full
      if (p_er && !e_ov) st_pixstarve <= st_pixstarve + CEN;                  // the pixel pipe waits for extents
      if (!wr_ready) st_frontwait <= st_frontwait + CEN;                      // the CPU waits for the front end
      case (rs)
        R_TAG: if (f_valid) begin
          tag <= f_word; wi <= '0; wn <= body_len(f_word);
          if (f_word == 32'h44425131) unsupported <= 1'b1;
          rs <= (body_len(f_word) == 0) ? R_TAG : R_BODY;
        end
        R_BODY: if (f_valid) begin
          // capture the words this block uses
          if (tag == 32'h52423031 && wi == 0) rbv <= f_word;
          if (tag == 32'h51554431) case (wi)
            6'd0:  cur.ctrl <= f_word;     6'd1:  cur.solid <= f_word[15:0];  6'd2:  cur.zoff <= f_word[15:0];
            6'd3:  cur.trans <= f_word[15:0]; 6'd4: cur.texw <= f_word[15:0]; 6'd5: cur.voff <= f_word[15:0];
            6'd6:  cur.alpha <= f_word;    6'd7:  cur.blend <= f_word;       6'd8:  cur.dtest <= f_word[0];
            6'd9:  cur.dwrite <= f_word[0]; 6'd10: cur.texfmt <= f_word[2:0]; 6'd11: cur.texbase <= f_word;
            6'd12: cur.palbase <= f_word;
            6'd13, 6'd14, 6'd15: s_clip[2'(wi - 6'd13)] <= f_word;
            6'd16: begin s_clip[3] <= f_word; vi <= '0; fi <= '0; end
            default: begin                                         // words 17..40: vertex vi, field fi
              s_vin[vi][fi] <= f_word;
              if (fi == 3'd5) begin fi <= '0; vi <= vi + 2'd1; end else fi <= fi + 3'd1;
            end
          endcase
          wi <= wi + 6'd1;
          if (wi == wn - 6'd1) begin
            case (tag)
              32'h52423031, 32'h434C5231: rs <= R_WAITDRAIN;    // order after every earlier polygon
              32'h51554431: rs <= R_START;
              default: rs <= R_TAG;
            endcase
          end
        end
        R_WAITDRAIN: if (drained && p_idle) begin
          if (tag == 32'h52423031) begin rb <= rbv; rs <= R_TAG; end else rs <= R_CLR;
        end
        R_CLR: if (p_cr) rs <= R_TAG;                            // the pixel pipe accepted the clear
        R_START: if (s_start) begin st_quads <= st_quads + CEN; rs <= R_TAG; end
        default: rs <= R_TAG;
      endcase
      // queue bookkeeping, all in one place: push (a quad starts setup), pop (its last extent reached the pixel pipe),
      // drop the TAIL (setup rejected the newest polygon). A drop and a push can share a clock -- setup pulses
      // `rejected` as its front stage goes idle, which is exactly when it can accept the next quad -- and then the
      // new object takes the freed slot.
      begin : oqb                                        // (the RAM write + read-ahead are in the object-queue block)
        oq_w <= oq_w + OQ_AW'(oq_push) - OQ_AW'(oq_drop);
        if (oq_drop) st_rejected <= st_rejected + CEN;
        if (oq_pop) begin oq_r <= oq_r + 1'b1; st_polys <= st_polys + CEN; end
        oq_n <= oq_n + (OQ_AW+1)'(oq_push) - (OQ_AW+1)'(oq_pop) - (OQ_AW+1)'(oq_drop);
        if (p_ev && p_er) st_extents <= st_extents + CEN;
      end
    end
  end
endmodule
