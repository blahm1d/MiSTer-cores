// dcs2_engine.sv -- compact ADSP-2104 (ADSP-2101 family) DCS2 sound engine for MK4.
// Written BLIND from MAME 0.289 gospel (adsp2100.cpp :1176-1921 dispatch, 2100ops.hxx
// ALU/MAC/shift/DAG/stacks/condition/reg maps). NOT transcribed from the Python golden.
//
// Multi-cycle FSM, single clock + clock-enable (P0019 no async crossing):
//   S_FETCH : issue PM read @pc (bench injects interrupts before fetch)
//   S_DEC   : wait pm_ready; latch opcode; compute ALL next-state combinationally
//             (ALU/MAC/shift/flags/DAG post-modify/pc/loop/stacks/reg writes); issue mem op0
//   S_MEM   : wait *_ready; capture read0->dest; issue/capture read1 (dual 0xc0-0xff); write wait
//   commit  : one-cycle pulse; DUT state == golden "before next instruction" snapshot
// Clocked memory only. PM 24-bit + DM 16-bit ports with ready handshakes so a DDR3-backed SRAM +
// hot cache with variable/hostile latency stalls the engine on a miss (bench drives *_ready).
`default_nettype none
module dcs2_engine (
  input  wire clk, rst, ce,
  output reg  pm_rd, pm_wr, output reg [13:0] pm_addr, output reg [23:0] pm_wdata,
  input  wire [23:0] pm_rdata, input wire pm_ready,
  output reg  dm_rd, dm_wr, output reg [13:0] dm_addr, output reg [15:0] dm_wdata,
  input  wire [15:0] dm_rdata, input wire dm_ready,
  input  wire irq_take, input wire [2:0] irq_indx,
  input  wire pace_hold,                           // real-time pacer (zk4_dcs2): 1 = do not START the next
                                                   // instruction this clock (opcode is cached, no fetch in
                                                   // flight). 0 (default, unit benches) = free-run.
  input  wire i7_we, input wire [13:0] i7_wd,      // SPORT1 autobuffer side-write of I[7] (=reg):
                                                   // MAME dcs_irq set_state_int(ADSP2100_I0+ireg,reg)
                                                   // (dcs.cpp:1995). Block advance+wrap computed by
                                                   // dcs2_autobuf; NOT a DAG +M7 step. ireg==7 (MK4).
  input  wire warm_rst,                            // reset preserves data regs/DAG/CNTR/PX/ICNTL (ADSP
                                                   // device_reset: warm self-reboot). Cold (0) clears.
  output reg  irq_ack, output reg [2:0] irq_ack_indx,  // pulse when an IRQ is TAKEN (clears latched src)
  output reg  ifc_we, output reg [15:0] ifc_val,     // 1-clk pulse: DSP wrote IFC (wreg3 0x0c, 2100ops.hxx:453-490):
                                                   // the interrupt latches live in dcs2_autobuf, which applies it
  output reg  tx1_we,                               // 1-clk pulse: DSP wrote SPORT1 TX reg (arm the
                                                   // autobuffer, sound_tx_callback offset 1 --
                                                   // wreg3 regnum 0x0b, 2100ops.hxx:452)
  input  wire seed_en, input wire [1887:0] seed,   // load architectural state at reset (fight window)
  output reg  commit,
  // autobuffer side port (synthesis path): zk4/autobuf drive the selected DAG indices, engine returns
  // the values from the DAG MLABs. Replaces the all-8 e_dbg[20..43] fan-out consumed in synthesis.
  input  wire [2:0] ab_ireg, input wire [2:0] ab_mreg, input wire [2:0] ab_lreg,
  output wire [13:0] ab_i, output wire [13:0] ab_m, output wire [13:0] ab_l,
  output wire [13:0] ab_i7, output wire [13:0] ab_pc, output wire [6:0] ab_mstat,
  output wire ab_icntl2,                           // ICNTL bit2: IRQ2 edge(1)/level(0) sensitivity (adsp2100.cpp:972)
  output wire [5:0] ab_imask,                      // IMASK (source enables, 0x20>>indx; adsp2100.cpp:894)
  // SAFETY NET (audit 2026-09-23): sticky flag + first PC/top-byte of any UNDECODED opcode that fell
  // to the NOP default (excl 0x01 IO / 0x08 reserved, legit no-ops on the 2104). zk4 mirrors these.
  output reg  undec_seen, output reg [13:0] undec_pc, output reg [7:0] undec_op,
  output wire [1887:0] dbg      // 59 fields x 32b, cpu_field order (bench compares, masked in C++)
);
  function automatic [31:0] sf(input [1887:0] s, input integer i); sf = s[i*32 +: 32]; endfunction
  localparam ZBIT=0,NBIT=1,VBIT=2,CBIT=3,SBIT=4,QBIT=5,MVBIT=6,SSBIT=7;
  localparam MST_BANK=0,MST_REV=1,MST_STV=2,MST_SAT=3,MST_INT=4;

  // banked datapath regs (adsp_core); [0] primary [1] alt, bs=current
  logic [15:0] ax0[2],ax1[2],ay0[2],ay1[2],ar[2],af[2],mx0[2],mx1[2],my0[2],my1[2],mf[2],si[2];
  logic [39:0] mr[2]; logic [31:0] sr[2]; logic [7:0] se[2]; logic [4:0] sb[2]; logic bs;
  // AREA: DAG register files in async-read MLAB (LUT-RAM), not flops. Single funnelled write port
  // each (I_we/I_wa/I_wd ...), combinational reads (functional + autobuffer side port + I7), cold
  // power-on clear SEQUENCE (warm reset preserves). ramstyle hints Quartus to MLAB.
  // ckpt2-v2: one MLAB copy per distinct read address (all copies written by the same funnelled port).
  //   _dag: address-gen + dag_next + 0x0b (via dag_widx/dag_midx)  _du: dual 2nd read
  //   _r1: rd1f (r[1:0])  _r2: rd2f ({1,r[1:0]})  _ab: autobuffer side port.  I7 = shadow register.
  // ckpt3-v3d: 3 MLAB copies per array. _dag: address-gen + dag_next + 0x0b + DUAL 2nd read (dual uses
  // a module-level dag_widx/dag_midx set in S_MEM). _rf: rd1f/rd2f merged, read at module-level rf_ra.
  // _ab: autobuffer side port. I7 = shadow register.
  (* ramstyle="MLAB, no_rw_check" *) logic [13:0] I_dag[8],I_rf[8],I_ab[8];
  (* ramstyle="MLAB, no_rw_check" *) logic [13:0] L_dag[8],L_rf[8],L_ab[8];
  (* ramstyle="MLAB, no_rw_check" *) logic signed [13:0] M_dag[8],M_rf[8],M_ab[8];
  // Cache the circular-buffer base mask at the same write edge as L. The
  // program-RAM -> opcode -> DAG read -> postmodify path must not also derive
  // this mask from L. Cold clear and every L write share this funnel; warm
  // reset preserves both. No instruction or memory-interface latency changes.
  (* ramstyle="MLAB, no_rw_check" *) logic [13:0] L_mask_dag[8];
  logic [13:0] i7_q;                      // I[7] shadow register (autobuffer pointer, read every tick)
  logic [2:0] dag_widx, dag_midx;         // module-level: DAG read index (dispatch pre-decode; S_MEM dual)
  logic [2:0] rf_ra;                      // module-level: reg-file (rd1f/rd2f merged) read index
  logic [7:0] px;
  logic       I_we,L_we,M_we; logic [2:0] I_wa,L_wa,M_wa; logic [13:0] I_wd,L_wd; logic signed [13:0] M_wd;
  logic [3:0] clr_cnt; logic clr_busy;   // cold power-on clear sequence (writes 0 to I/L/Msg[0..7])
  logic [13:0] pc,ppc,loopreg; logic loop_active; logic [3:0] loop_cond; logic [15:0] cntr;
  logic [7:0] astat,sstat; logic [6:0] mstat,mstat_prev; logic [5:0] imask; logic [4:0] icntl; logic [3:0] irq_state;
  // inv-area E1 (sound-area E1 rebased onto the dcs2-stack engine): the four hardware stacks in MLAB (LUT-RAM) instead
  // of flops. Every push writes at the CURRENT pointer and every stack has ONE read address (pc/cn/st: top =
  // pointer-1, or entry 0 when empty; lp: pointer-2), so each stack is a single-write / single-async-read MLAB. The
  // pushes are funnelled (ps_we/ps_wd ...: blocking, last assignment in code order wins, as the nonblocking writes they
  // replace) into ONE write statement per stack after dispatch. Same clock, same address, same data: schedule-identical.
  // The saturation guard (a push on a FULL stack stores nothing) lives in the push task, which sets the funnel only
  // when the push stores.
  (* ramstyle="MLAB, no_rw_check" *) logic [13:0] pcst[16]; logic [4:0] pcsp;
  (* ramstyle="MLAB, no_rw_check" *) logic [17:0] lpst[4];  logic [2:0] lpsp;
  (* ramstyle="MLAB, no_rw_check" *) logic [13:0] cnst[4];  logic [2:0] cnsp;
  (* ramstyle="MLAB, no_rw_check" *) logic [20:0] stst[4];  logic [2:0] stsp;
  logic ps_we, ss_we, cs_we, ls_we; logic [13:0] ps_wd, cs_wd; logic [20:0] ss_wd; logic [17:0] ls_wd;
`ifdef SIM_STACK_INIT
  // power-on stack CONTENTS = 0 (MAME device_start memset, adsp2100.cpp:183-186; device_reset does not clear them):
  // an empty-stack pop reads entry 0. Silicon: registers power up 0; Verilator zero-initialises. Only X-propagating
  // simulators (iverilog unit gate) need this; never compiled into Quartus (no reset loop -> no flop/MLAB change).
  initial begin for(int q=0;q<16;q++) pcst[q]=14'h0; for(int q=0;q<4;q++) begin lpst[q]=18'h0; cnst[q]=14'h0; stst[q]=21'h0; end end
`endif
  localparam [7:0] ACLR_STV=~(8'h0b), ACLR_NORM=~(8'h0f);
  wire [7:0] aclr = mstat[MST_STV]?ACLR_STV:ACLR_NORM;

  function automatic [13:0] lmask_of(input [13:0] Lv);
    if(Lv>14'h2000)lmask_of=14'h0;else if(Lv>14'h1000)lmask_of=14'h2000;else if(Lv>14'h0800)lmask_of=14'h3000;
    else if(Lv>14'h0400)lmask_of=14'h3800;else if(Lv>14'h0200)lmask_of=14'h3c00;else if(Lv>14'h0100)lmask_of=14'h3e00;
    else if(Lv>14'h0080)lmask_of=14'h3f00;else if(Lv>14'h0040)lmask_of=14'h3f80;else if(Lv>14'h0020)lmask_of=14'h3fc0;
    else if(Lv>14'h0010)lmask_of=14'h3fe0;else if(Lv>14'h0008)lmask_of=14'h3ff0;else if(Lv>14'h0004)lmask_of=14'h3ff8;
    else if(Lv>14'h0002)lmask_of=14'h3ffc;else if(Lv>14'h0001)lmask_of=14'h3ffe;else lmask_of=14'h3fff;
  endfunction
  function automatic [2:0] m3(input [2:0] x); m3=x; endfunction
  function automatic [13:0] dag_next(input [13:0] iv,input signed [13:0] mv,input [13:0] lv,input [13:0] lm);
`ifdef ABL_DAG
    dag_next=iv;
`else
    logic [13:0] base,nx; base=iv&lm; nx=(iv+mv)&14'h3fff;
    if(nx<base) nx=nx+lv; else if(nx>=(base+lv)) nx=nx-lv; dag_next=nx;
`endif
  endfunction
  function automatic [13:0] rev14(input [13:0] x); integer b; for(b=0;b<14;b=b+1) rev14[b]=x[13-b]; endfunction
  function automatic logic cond_s(input [3:0] c,input [7:0] a);
    logic az,an,av,ac,as_,mv; az=a[0];an=a[1];av=a[2];ac=a[3];as_=a[4];mv=a[6];
    case(c) 0:cond_s=az;1:cond_s=~az;2:cond_s=~((an^av)|az);3:cond_s=((an^av)|az);4:cond_s=(an^av);5:cond_s=~(an^av);
      6:cond_s=av;7:cond_s=~av;8:cond_s=ac;9:cond_s=~ac;10:cond_s=as_;11:cond_s=~as_;12:cond_s=mv;13:cond_s=~mv;
      15:cond_s=1'b1;default:cond_s=1'b0; endcase
  endfunction
  function automatic [15:0] consty(input [4:0] i);
    case(i) 0:consty=16'h0001;1:consty=16'hfffe;2:consty=16'h0002;3:consty=16'hfffd;4:consty=16'h0004;5:consty=16'hfffb;
    6:consty=16'h0008;7:consty=16'hfff7;8:consty=16'h0010;9:consty=16'hffef;10:consty=16'h0020;11:consty=16'hffdf;
    12:consty=16'h0040;13:consty=16'hffbf;14:consty=16'h0080;15:consty=16'hff7f;16:consty=16'h0100;17:consty=16'hfeff;
    18:consty=16'h0200;19:consty=16'hfdff;20:consty=16'h0400;21:consty=16'hfbff;22:consty=16'h0800;23:consty=16'hf7ff;
    24:consty=16'h1000;25:consty=16'hefff;26:consty=16'h2000;27:consty=16'hdfff;28:consty=16'h4000;29:consty=16'hbfff;
    30:consty=16'h8000;31:consty=16'h7fff; endcase
  endfunction
  function automatic integer clz(input [31:0] v); integer i; begin clz=32; for(i=31;i>=0;i=i-1) if(v[i]&&clz==32) clz=31-i; end endfunction
  function automatic integer clo(input [31:0] v); clo=clz(~v); endfunction

  function automatic [15:0] rd0(input [3:0] r);
    case(r) 0:rd0=ax0[bs];1:rd0=ax1[bs];2:rd0=mx0[bs];3:rd0=mx1[bs];4:rd0=ay0[bs];5:rd0=ay1[bs];6:rd0=my0[bs];7:rd0=my1[bs];
    8:rd0=si[bs];9:rd0={{8{se[bs][7]}},se[bs]};10:rd0=ar[bs];11:rd0=mr[bs][15:0];12:rd0=mr[bs][31:16];
    13:rd0={{8{mr[bs][39]}},mr[bs][39:32]};14:rd0=sr[bs][15:0];15:rd0=sr[bs][31:16]; endcase
  endfunction
  // rd1f/rd2f merged: both read the single _rf copy at module-level rf_ra (rf_ra encodes r[1:0] for
  // rd1f, {1,r[1:0]} for rd2f -- set in dispatch). Only r[3:2] (the I/Msg/L select) differs by call.
  function automatic [15:0] rdrf(input [3:0] r);
    case(r[3:2]) 0:rdrf={2'b0,I_rf[rf_ra]};1:rdrf={{2{M_rf[rf_ra][13]}},M_rf[rf_ra]};default:rdrf={2'b0,L_rf[rf_ra]}; endcase endfunction
  function automatic [15:0] rd3f(input [3:0] r);
    case(r) 0:rd3f={8'b0,astat};1:rd3f={9'b0,mstat};2:rd3f={8'b0,sstat};3:rd3f={10'b0,imask};4:rd3f={11'b0,icntl};
    5:rd3f={2'b0,cntr[13:0]};6:rd3f={{11{sb[bs][4]}},sb[bs]};7:rd3f={8'b0,px};default:rd3f=16'h0; endcase endfunction
  function automatic [15:0] alux(input [2:0] s);
`ifdef ABL_RDMUX
    alux=16'h0;
`else
    case(s) 0:alux=ax0[bs];1:alux=ax1[bs];2:alux=ar[bs];3:alux=mr[bs][15:0];4:alux=mr[bs][31:16];5:alux={{8{mr[bs][39]}},mr[bs][39:32]};6:alux=sr[bs][15:0];7:alux=sr[bs][31:16]; endcase
`endif
 endfunction
  function automatic [15:0] aluy(input [1:0] s); `ifdef ABL_RDMUX aluy=16'h0; `else case(s) 0:aluy=ay0[bs];1:aluy=ay1[bs];2:aluy=af[bs];default:aluy=16'h0; endcase `endif endfunction
  function automatic [15:0] macx(input [2:0] s);
`ifdef ABL_RDMUX
    macx=16'h0;
`else
    case(s) 0:macx=mx0[bs];1:macx=mx1[bs];2:macx=ar[bs];3:macx=mr[bs][15:0];4:macx=mr[bs][31:16];5:macx={{8{mr[bs][39]}},mr[bs][39:32]};6:macx=sr[bs][15:0];7:macx=sr[bs][31:16]; endcase
`endif
 endfunction
  function automatic [15:0] macy(input [1:0] s); `ifdef ABL_RDMUX macy=16'h0; `else case(s) 0:macy=my0[bs];1:macy=my1[bs];2:macy=mf[bs];default:macy=16'h0; endcase `endif endfunction
  function automatic [15:0] shxf(input [2:0] s);
`ifdef ABL_RDMUX
    shxf=16'h0;
`else
    case(s) 0:shxf=si[bs];1:shxf=si[bs];2:shxf=ar[bs];3:shxf=mr[bs][15:0];4:shxf=mr[bs][31:16];5:shxf={{8{mr[bs][39]}},mr[bs][39:32]};6:shxf=sr[bs][15:0];7:shxf=sr[bs][31:16]; endcase
`endif
 endfunction

  // ---- ALU eval (returns via outputs) ----
  function automatic [23:0] alu_eval(input [23:0] op,input [7:0] ain,input [15:0] xop,input [15:0] yop); // {astat,res16}
    logic [3:0] code; logic [16:0] x,y,r; logic [15:0] xu,yu; logic [7:0] a; logic cin;
`ifdef ABL_ALU
    alu_eval={ain,16'h0};
`else
    code=op[16:13]; xu=xop; yu=yop;   // operands pre-read into xreg/yreg (ckpt3-v3)
    a=ain; cin=a[CBIT]; x={1'b0,xu}; y={1'b0,yu};
    if(code==4'hf) begin  // ABS X (no `return`: Quartus-17-safe function-name assign)
      a=ain&aclr; a[SBIT]=0; r=xu[15]?(17'h0-{1'b0,xu}):{1'b0,xu};
      if(xu==16'h0)a[ZBIT]=1; if(xu==16'h8000)begin a[NBIT]=1;a[VBIT]=1;end if(xu[15])a[SBIT]=1;
      alu_eval={a,r[15:0]};
    end else begin
      a=ain&aclr;
      case(code)
        0:r=y; 1:begin r=y+1;if(yu==16'h7fff)a[VBIT]=1;else if(yu==16'hffff)a[CBIT]=1;end
        2:begin y=y+{16'b0,cin};r=x+y;end 3:r=x+y; 4:r={1'b0,(yu^16'hffff)};
        5:begin r=(17'h0-y);if(yu==16'h8000)a[VBIT]=1;if(yu==16'h0000)a[CBIT]=1;end
        6:r=x-y+{16'b0,cin}-17'h1; 7:r=x-y;
        8:begin r=y-17'h1;if(yu==16'h8000)a[VBIT]=1;else if(yu==16'h0000)a[CBIT]=1;end
        9:r=y-x; 10:r=y-x+{16'b0,cin}-17'h1; 11:r={1'b0,(xu^16'hffff)}; 12:r={1'b0,(xu&yu)}; 13:r={1'b0,(xu|yu)}; 14:r={1'b0,(xu^yu)};
        default:r=17'h0;
      endcase
      a[NBIT]=r[15]; a[ZBIT]=(r[15:0]==16'h0);
      // CALC_V = (s^d^r^(r>>1))>>13 & 4  == bit15 of (s^d^r^(r>>1)) = s[15]^d[15]^r[15]^r[16]
      case(code) 2,3:begin a[VBIT]=(x[15]^y[15]^r[15]^r[16]);a[CBIT]=r[16];end
        6,7:begin a[VBIT]=(x[15]^y[15]^r[15]^r[16]);a[CBIT]=~r[16];end
        9,10:begin a[VBIT]=(y[15]^x[15]^r[15]^r[16]);a[CBIT]=~r[16];end default:; endcase
      alu_eval={a,r[15:0]};
    end
`endif
  endfunction
  function automatic [15:0] sat_ar(input [15:0] r,input [7:0] a);
    sat_ar=(mstat[MST_SAT]&&a[VBIT])?(a[CBIT]?16'h8000:16'h7fff):r; endfunction

  // ---- MAC eval : {astat, res40} in 48 bits ----
  // task (not function-with-output; Quartus-17-safe): mv={astat,res40}
  task automatic mac_eval(input [23:0] op,input [7:0] ain,input [15:0] xop,input [15:0] yop,output [47:0] mv,output logic noop);
    logic [3:0] code; logic sh,xsg,ysg; logic signed [16:0] xe,ye; logic [15:0] xu,yu;
    logic signed [33:0] prod; logic signed [63:0] tmp,acc,res; logic [8:0] ov; logic [15:0] tlo; logic [7:0] a;
`ifdef ABL_MAC
    mv={ain,40'h0}; noop=1'b1;
`else
    code=op[16:13]; sh=mstat[MST_INT]?1'b0:1'b1; a=ain; noop=0; mv={ain,40'h0};
    if(code==0)begin noop=1; end
    else begin
      xu=xop; yu=yop;   // operands pre-read into xreg/yreg (ckpt3-v3)
      xsg=!(code==4'h6||code==4'h7||code==4'ha||code==4'hb||code==4'he||code==4'hf);
      ysg=!(code==4'h5||code==4'h7||code==4'h9||code==4'hb||code==4'hd||code==4'hf);
      xe=xsg?{xu[15],xu}:{1'b0,xu}; ye=ysg?{yu[15],yu}:{1'b0,yu};
      prod=xe*ye; tmp=$signed({{30{prod[33]}},prod})<<<sh; tmp=$signed({{32{tmp[31]}},tmp[31:0]});
      acc=$signed({{24{mr[bs][39]}},mr[bs]});
      case(code) 4'h1,4'h4,4'h5,4'h6,4'h7:res=tmp; 4'h2,4'h8,4'h9,4'ha,4'hb:res=acc+tmp;
        4'h3,4'hc,4'hd,4'he,4'hf:res=acc-tmp; default:res=tmp; endcase
      if(code==4'h1||code==4'h2||code==4'h3)begin tlo=tmp[15:0]; res=res+64'sd32768; if(tlo==16'h8000)res=res&~(64'sh10000); end
      ov=res[39:31]; a[MVBIT]=0; if(ov!=9'h000&&ov!=9'h1ff)a[MVBIT]=1;
      mv={a,res[39:0]};
    end
`endif
  endtask

  // ---- SHIFT prep (combinational): reduce every shift/NORM/EXP code to ONE variable operation
  // executed serially in S_SHIFT (mode 0 = 1-bit/clock barrel; mode 1 = serial leading-zero count).
  // NO barrels / clz encoders here -> removes the ~1,000-ALUT combinational shift datapath.
  // acc0 = pre-shift/pre-count value; amt = shift magnitude (clamped 32); dir/arith set the barrel.
  // Bit-exact with the old shift_eval; finalize (shift_fin) reproduces every code's SR/SE/SB/ASTAT.
  task automatic shift_prep(input [23:0] op,input logic imm,input [7:0] ain,input [15:0] xop,input [7:0] se_in,
      output logic mode, output [31:0] acc0, output [5:0] amt, output logic dir, output logic arith);
    logic [3:0] code; logic signed [8:0] sc; logic [15:0] xu; logic [8:0] mag;
    logic [31:0] uxs,shin,pre; logic hi_v, ar_v, inv;
    code=op[14:11]; xu=xop; mode=1'b0; acc0=32'h0; amt=6'd0; dir=1'b0; arith=1'b0; mag=9'd0;
    sc = imm ? $signed({op[7],op[7:0]}) : $signed({se_in[7],se_in});
`ifdef ABL_SHIFT
    acc0=32'h0; amt=6'd0;
`else
    if(code[3]==1'b0) begin                     // 0x0-0x7 LSHIFT / ASHIFT
      hi_v=~code[1]; ar_v=code[2];
      shin = hi_v ? {xu,16'h0} : (ar_v ? {{16{xu[15]}},xu} : {16'h0,xu});
      pre=shin; dir=(sc<0); arith=ar_v; mag = dir ? 9'(-sc) : 9'(sc);
      amt=(mag>=9'd32)?6'd32:mag[5:0]; acc0=pre; mode=1'b0;
    end else if(code[3:1]==3'b100) begin        // 0x8/0x9 NORM HI
      uxs={xu,16'h0};
      if(sc>0)begin pre=(uxs>>1)|(ain[CBIT]?32'h8000_0000:32'h0); dir=1'b1; arith=1'b1; mag=9'(sc-9'sd1); end
      else     begin pre=uxs; dir=1'b0; arith=1'b0; mag=9'(-sc); end
      amt=(mag>=9'd32)?6'd32:mag[5:0]; acc0=pre; mode=1'b0;
    end else if(code[3:1]==3'b101) begin        // 0xa/0xb NORM LO (logical)
      uxs={16'h0,xu};
      if(sc>0)begin dir=1'b1; arith=1'b0; mag=9'(sc); end
      else     begin dir=1'b0; arith=1'b0; mag=9'(-sc); end
      amt=(mag>=9'd32)?6'd32:mag[5:0]; acc0=uxs; mode=1'b0;
    end else begin                              // 0xc-0xf EXP / EXPADJ (serial leading-zero count)
      mode=1'b1;
      if(code==4'he) inv=ain[SSBIT]; else inv=xu[15];
      acc0={16'h0,(inv?~xu:xu)}; amt=6'd0; dir=1'b0; arith=1'b0;
    end
`endif
  endtask

  // ============ FSM ============
  typedef enum logic [2:0] {S_RST,S_FETCH,S_DEC,S_MEM,S_SHIFT,S_EXEC} st_t; st_t st;
  // ckpt3-v3: two-clock operand read. S_DEC pre-reads ALU/MAC x/y into xreg/yreg (one shared x-mux +
  // one y-mux); S_EXEC computes av/mv ONCE (single alu_eval+mac_eval, fed only by xreg/yreg) then
  // dispatches. av/mv/noop are module-level so the datapath is instantiated exactly ONCE (in S_EXEC),
  // never duplicated at the S_DEC dispatch site. +1 clock on compute ops only.
  logic [15:0] xreg, yreg;
  logic [23:0] opr;
  // ckpt4o (fetch/execute overlap): dispatch computes the successor pc COMBINATIONALLY (npc) and, at
  // the commit edge, ALSO issues the fetch for it (pm_rd@npc) -> the separate S_FETCH cycle is folded
  // into the prior instruction's commit. Straight-line/branch/mem/shift all issue their successor
  // fetch when they commit; S_DEC then decodes it next clock. commit_now (module-level, set by
  // dispatch/shift_req) selects commit+overlapped-fetch (1) vs enter S_MEM/S_SHIFT (0). irq_lat
  // blocks a double IRQ redirect while irq_take is held across the vector fetch (the bench holds it
  // until the ISR opcode is served). S_FETCH is now ONLY the power-on/seed prime (entered once).
  logic [13:0] npc;                 // next-pc (blocking within dispatch); pc<=npc once at dispatch tail
  logic        commit_now;          // 1 => commit + overlapped fetch @npc ; 0 => S_MEM/S_SHIFT (no fetch)
  logic        irq_lat;             // IRQ redirect taken for this boundary (blocks re-fire)
  logic        selfrep;             // self-loop: re-execute cached opr without a fetch (npc==ppc)
  // AREA: multi-cycle shifter state. One shared 1-bit/clock barrel (sh_mode=0) OR a serial
  // leading-zero counter (sh_mode=1) replaces the combinational 32-bit barrels + clz encoders.
  logic        sh_mode;            // 0=variable shift, 1=leading-zero count (EXP/EXPADJ)
  logic [31:0] sh_acc;             // accumulator (subject of shift/count)
  logic [5:0]  sh_amt, sh_i;       // shift target count / iterations done
  logic [6:0]  sh_clz;             // leading-zero count (0..32)
  logic        sh_dir, sh_arith;   // 0=left 1=right ; arithmetic fill on right
  logic        sh_mem;             // after shift, issue the latched mem op (S_MEM)
  logic [3:0]  sh_code;            // shift sub-code op[14:11] (sror = sh_code[0])
  logic        sh_xu15;            // captured operand sign bit (only bit used by finalize)
  // NOTE: astat/se[bs]/sb[bs] are NOT latched -- they are STABLE across S_SHIFT (a shift op writes
  // them only at finalize), so finalize reads them live. Saves sh_ain/sh_se/sh_sb/sh_sror registers.
  // pending read: dest group/reg; second read for dual (group0)
  logic       r_pend, r_ispm, r2_pend; logic [1:0] r_grp; logic [3:0] r_reg, r2_reg;
  logic       w_pend, w_ispm;   // pending write wait
  logic       diagl;
  logic       i7_pend;          // SPORT1 autobuffer write pending (applied atomically at S_FETCH)
  logic [13:0] i7_pv;           // pending I[7] value (from dcs2_autobuf)

  // register-write helpers (nonblocking to current bank / index files)
  // sound-area: wreg0 FUNNELLED (blocking w0_we/w0_r/w0_v, applied by ONE case statement at the end of the clocked
  // block). At most one wreg0 runs per clock (S_MEM's read-back, or one dispatch arm), and in every arm it was the LAST
  // write to its target in that clock (0x28-0x2f: compute4 before wreg0; MR1/MR2 partial writes after a MAC's MR write),
  // so applying it last keeps every final value. Each data register now has one register-move source instead of one
  // per call site (rd0v / rdrf / rd3f / immediates / PM / DM read data).
  logic w0_we; logic [3:0] w0_r; logic [15:0] w0_v;
  task automatic wreg0(input [3:0] r,input [15:0] v);
`ifndef SYNTHESIS
    if(w0_we && w0_r != r) $fatal(1, "inv-area E3: two wreg0 targets in one clock (%0d then %0d) -- funnel would drop one", w0_r, r);
`endif
    w0_we=1'b1; w0_r=r; w0_v=v;
  endtask
  task automatic wreg0_apply(input [3:0] r,input [15:0] v);
    case(r) 0:ax0[bs]<=v;1:ax1[bs]<=v;2:mx0[bs]<=v;3:mx1[bs]<=v;4:ay0[bs]<=v;5:ay1[bs]<=v;6:my0[bs]<=v;7:my1[bs]<=v;
      8:si[bs]<=v;9:se[bs]<=v[7:0];10:ar[bs]<=v;
      11:mr[bs][15:0]<=v; 12:begin mr[bs][31:16]<=v; mr[bs][39:32]<={8{v[15]}}; end 13:mr[bs][39:32]<=v[7:0];
      14:sr[bs][15:0]<=v; 15:sr[bs][31:16]<=v; endcase
  endtask
  task automatic wreg1(input [3:0] r,input [15:0] v);   // funnel to single write port (blocking)
    case(r[3:2]) 0:begin I_we=1'b1;I_wa=r[1:0];I_wd=v[13:0]; end
                 1:begin M_we=1'b1;M_wa=r[1:0];M_wd=v[13:0]; end
                 2:begin L_we=1'b1;L_wa=r[1:0];L_wd=v[13:0]; end default:; endcase
  endtask
  task automatic wreg2(input [3:0] r,input [15:0] v); logic [2:0] x; x={1'b1,r[1:0]};
    case(r[3:2]) 0:begin I_we=1'b1;I_wa=x;I_wd=v[13:0]; end
                 1:begin M_we=1'b1;M_wa=x;M_wd=v[13:0]; end
                 2:begin L_we=1'b1;L_wa=x;L_wd=v[13:0]; end default:; endcase
  endtask
  // ---- hardware stacks, MAME 0.289 2100ops.hxx:119-296 (depths adsp2100.h:298-301: PC 16, CNTR/STATUS/LOOP 4) ----
  // dcs2-stack lane (port of the War Gods wg1 r12 fix, D:/deck/fpga/cruisinusa/bandwidth/wg1/dcs2/rtl/dcs2_engine.sv):
  // a push on a FULL stack stores nothing, keeps sp and sets the OVER bit (a DO on a full loop stack does NOT arm the
  // loop: m_loop/m_loop_condition are only written inside loop_stack_push); a pop on an EMPTY stack keeps sp 0 and
  // uses entry 0. The old code incremented/decremented unconditionally with 3/5-bit pointers over 4/16-entry arrays
  // (out-of-range stores/loads: Verilator vs synthesized index aliasing differ). sstat bits (2100ops.hxx:104-111):
  // PC_EMPTY 01 PC_OVER 02 COUNT_EMPTY 04 COUNT_OVER 08 STATUS_EMPTY 10 STATUS_OVER 20 LOOP_EMPTY 40 LOOP_OVER 80.
  // MUT_STK_WRAP (verifier mutant) = the pre-fix pointer behaviour for pc/loop pushes.
  // one read address per stack (inv-area E1): the empty-stack case selects the ADDRESS 0, not a second read port
  wire [3:0]  pc_ra = (pcsp != 5'd0) ? 4'(pcsp - 5'd1) : 4'd0;
  wire [13:0] pc_top = pcst[pc_ra];                                                  // pc_stack_top (2100ops.hxx:119-125)
  wire [1:0]  cn_ra = (cnsp != 3'd0) ? 2'(cnsp - 3'd1) : 2'd0;
  wire [13:0] cn_top = cnst[cn_ra];
  wire [1:0]  st_ra = (stsp != 3'd0) ? 2'(stsp - 3'd1) : 2'd0;
  wire [20:0] st_top = stst[st_ra];
  wire [17:0] lp_nxt = lpst[2'(lpsp - 3'd2)];                                        // the entry below the top
  task automatic pc_push(input [13:0] v);                                           // pc_stack_push(_val) :135-157
`ifdef MUT_STK_WRAP
    ps_we=1'b1; ps_wd=v; pcsp<=pcsp+5'd1; sstat[0]<=1'b0;
`else
    if(pcsp < 5'd16) begin ps_we=1'b1; ps_wd=v; pcsp<=pcsp+5'd1; sstat[0]<=1'b0; end else sstat[1]<=1'b1;
`endif
  endtask
  task automatic pc_pop();                                                          // pc_stack_pop(_val) :159-179
    if(pcsp != 5'd0) begin pcsp<=pcsp-5'd1; if(pcsp == 5'd1) sstat[0]<=1'b1; end   // value = pc_top (read first)
  endtask
  task automatic cn_push();                                                         // cntr_stack_push :195-205
    if(cnsp < 3'd4) begin cs_we=1'b1; cs_wd=cntr[13:0]; cnsp<=cnsp+3'd1; sstat[2]<=1'b0; end else sstat[3]<=1'b1;
  endtask
  task automatic cn_pop();                                                          // cntr_stack_pop :207-216
    if(cnsp != 3'd0) begin cnsp<=cnsp-3'd1; if(cnsp == 3'd1) sstat[2]<=1'b1; end
    cntr<={2'b0, cn_top};                                                           // empty: entry 0 (cn_ra = 0)
  endtask
  task automatic lp_push(input [17:0] v);                                           // loop_stack_push :232-244
`ifdef MUT_STK_WRAP
    ls_we=1'b1; ls_wd=v; lpsp<=lpsp+3'd1; loopreg<=v[17:4]; loop_cond<=v[3:0]; loop_active<=1'b1; sstat[6]<=1'b0;
`else
    if(lpsp < 3'd4) begin
      ls_we=1'b1; ls_wd=v; lpsp<=lpsp+3'd1; loopreg<=v[17:4]; loop_cond<=v[3:0]; loop_active<=1'b1; sstat[6]<=1'b0;
    end else sstat[7]<=1'b1;
`endif
  endtask
  task automatic lp_pop();                                                          // loop_stack_pop :246-263
    if(lpsp != 3'd0) begin
      lpsp<=lpsp-3'd1;
      if(lpsp == 3'd1) begin loopreg<=14'h3fff; loop_active<=1'b0; loop_cond<=4'd0; sstat[6]<=1'b1; end
      else begin loopreg<=lp_nxt[17:4]; loop_cond<=lp_nxt[3:0]; end
    end
  endtask
  task automatic st_push();                                                         // stat_stack_push :270-281
    if(stsp < 3'd4) begin ss_we=1'b1; ss_wd={mstat,imask,astat}; stsp<=stsp+3'd1; sstat[4]<=1'b0; end else sstat[5]<=1'b1;
  endtask
  task automatic st_pop();                                                          // stat_stack_pop :283-296
    logic [20:0] e; e = st_top;                                                     // (+ update_mstat bank swap)
    if(stsp != 3'd0) begin stsp<=stsp-3'd1; if(stsp == 3'd1) sstat[4]<=1'b1; end
    mstat<=e[20:14]; mstat_prev<=e[20:14]; imask<=e[13:8]; astat<=e[7:0];
    if(e[14]!=mstat[0]) bs<=~bs;
  endtask

  task automatic wreg3(input [3:0] r,input [15:0] v);
    case(r)
      0:astat<=v[7:0]; 1:begin mstat<=v[6:0]; mstat_prev<=v[6:0]; if(v[0]!=mstat[0]) bs<=~bs; end /* MSTAT write: update_mstat bank swap, 2100ops.hxx:445,79-85 */ 3:imask<=v[5:0]; 4:icntl<=v[4:0];
      5:begin cn_push(); cntr<=v[13:0]; end                    // 2100ops.hxx:448 cntr_stack_push(); m_cntr = val
      6:sb[bs]<=v[4:0]; 7:px<=v[7:0]; 13:cntr<=v[13:0];
      11:tx1_we<=1'b1;  // 0x0b = SPORT1 TX write -> arm the autobuffer (sound_tx_callback offset 1)
      12:begin ifc_we<=1'b1; ifc_val<=v; end                   // 0x0c = IFC: clear / force interrupt latches (autobuf)
      15:pc_push(v[13:0]);                                      // 2100ops.hxx:492 pc_stack_push_val
      default:; // 0x09 sport0 tx
    endcase
  endtask


  // generate_irq (2101, adsp2100.cpp:891-913)
  task automatic do_irq(input [2:0] indx);
    if(imask[5-indx])begin
      irq_ack<=1'b1; irq_ack_indx<=indx;        // ack: subsystem clears the taken latched source
      pc_push(pc);                              // adsp2100.cpp:901-902 pc_stack_push(); stat_stack_push()
      st_push();
      pc<=14'h4+({11'b0,indx}<<2);
      if(icntl[4]) imask<=imask&~(6'h3f>>indx); else imask<=6'h0;
    end
  endtask

  // advance pc with loop handling (adsp2100.cpp:1204-1221 + slow_condition CE 2100ops.hxx:316)
  // ckpt4o: sets the module-level npc (blocking) instead of pc<= so dispatch can issue the overlapped
  // fetch @npc; branch arms override npc (blocking); pc<=npc happens once at the dispatch tail. Loop
  // stack side-effects (cntr/cnsp/lpsp/pcsp/loopreg/sstat) stay nonblocking, unchanged.
  task automatic pc_advance();
    logic cont; logic signed [15:0] nc;
    if(!loop_active || pc!=loopreg) npc = (pc+1)&14'h3fff;
    else begin
      if(loop_cond==4'd14) begin           // CE: slow_condition
        nc = $signed(cntr) - 16'sd1;
        if(nc > 0) begin cntr<=nc; cont=1'b1; end
        else begin cn_pop(); cont=1'b0; end
      end else cont = cond_s(loop_cond,astat);
      if(cont) npc = pc_top;                   // adsp2100.cpp:1212 m_pc = pc_stack_top()
      else begin
        lp_pop();                              // adsp2100.cpp:1217-1219 loop_stack_pop(); pc_stack_pop_val(); m_pc++
        pc_pop();
        npc = (pc+1)&14'h3fff;
      end
    end
  endtask

  integer k;
  always_ff @(posedge clk) begin
    if(rst)begin
      st<=S_RST; commit<=0; pm_rd<=0;pm_wr<=0;dm_rd<=0;dm_wr<=0; undec_seen<=1'b0;
      loopreg<=14'h3fff;loop_active<=0;loop_cond<=0;irq_state<=0; r_pend<=0;r2_pend<=0;w_pend<=0; i7_pend<=0; irq_ack<=0; tx1_we<=0; ifc_we<=0; ifc_val<=16'd0; irq_lat<=1'b0; selfrep<=1'b0;
      // cold power-on: run a clear SEQUENCE in S_RST (MLAB has no async reset). WARM/seed: preserve/load.
      clr_busy<=(!warm_rst)&&(!seed_en); clr_cnt<=4'd0;
      // MAME device_reset (adsp2100.cpp:612) does NOT clear the alt-bank data regs; only a COLD reset
      // (power-on) zeroes them here. A WARM reset (self-reboot, warm_rst=1) preserves them.
      if(!warm_rst) for(k=1;k<2;k=k+1)begin ax0[k]<=0;ax1[k]<=0;ay0[k]<=0;ay1[k]<=0;ar[k]<=0;af[k]<=0;mx0[k]<=0;mx1[k]<=0;my0[k]<=0;my1[k]<=0;mf[k]<=0;si[k]<=0;mr[k]<=0;sr[k]<=0;se[k]<=0;sb[k]<=0;end
      if(seed_en) begin  // load live architectural state into bank0 (fight-window seed)
`ifndef SYNTHESIS
        pc<=sf(seed,0)[13:0]; ppc<=sf(seed,0)[13:0];
        ax0[0]<=sf(seed,1);ax1[0]<=sf(seed,2);ay0[0]<=sf(seed,3);ay1[0]<=sf(seed,4);ar[0]<=sf(seed,5);af[0]<=sf(seed,6);
        mx0[0]<=sf(seed,7);mx1[0]<=sf(seed,8);my0[0]<=sf(seed,9);my1[0]<=sf(seed,10);
        mr[0]<={sf(seed,13)[7:0],sf(seed,12)[15:0],sf(seed,11)[15:0]}; mf[0]<=sf(seed,14);
        si[0]<=sf(seed,15); se[0]<=sf(seed,16)[7:0]; sb[0]<=sf(seed,17)[4:0];
        sr[0]<={sf(seed,19)[15:0],sf(seed,18)[15:0]};
        for(k=0;k<8;k=k+1)begin  // sim seed: load every MLAB copy + I7 shadow (ifndef SYNTHESIS)
          I_dag[k]<=sf(seed,20+k)[13:0]; I_rf[k]<=sf(seed,20+k)[13:0]; I_ab[k]<=sf(seed,20+k)[13:0];
          M_dag[k]<=sf(seed,28+k)[13:0]; M_rf[k]<=sf(seed,28+k)[13:0]; M_ab[k]<=sf(seed,28+k)[13:0];
          L_dag[k]<=sf(seed,36+k)[13:0]; L_rf[k]<=sf(seed,36+k)[13:0]; L_ab[k]<=sf(seed,36+k)[13:0];
          L_mask_dag[k]<=lmask_of(sf(seed,36+k)[13:0]);
          if(k==7) i7_q<=sf(seed,27)[13:0]; end
        px<=sf(seed,44)[7:0]; cntr<=sf(seed,45)[15:0]; astat<=sf(seed,46)[7:0];
        mstat<=sf(seed,47)[6:0]; mstat_prev<=sf(seed,47)[6:0]; sstat<=sf(seed,48)[7:0];
        imask<=sf(seed,49)[5:0]; icntl<=sf(seed,50)[4:0];
        pcsp<=sf(seed,51)[4:0]; cnsp<=sf(seed,52)[2:0]; stsp<=sf(seed,53)[2:0]; lpsp<=sf(seed,54)[2:0];
        bs<=1'b0;
`endif
      end else begin
        // ALWAYS reset (MAME device_reset): PC/loops/IMASK/stacks/bank; sstat=0x55; mstat=0.
        pc<=0;ppc<=0;sstat<=8'h55;mstat<=0;mstat_prev<=0;imask<=0;bs<=0;
        pcsp<=0;lpsp<=0;cnsp<=0;stsp<=0;
        // PRESERVED by MAME device_reset (data regs, DAG I/M/L, CNTR, PX, ICNTL, ASTAT -- it only sets
        // a lazy C/V/N/Z clear mask, not astat=0). A WARM reset keeps them; COLD (power-on) zeroes them.
        if(!warm_rst) begin
          cntr<=0;icntl<=0;px<=0;astat<=0;
          // I/L/Msg cleared by the S_RST clear sequence (MLAB), not a reset loop (would infer flops).
          ax0[0]<=0;ax1[0]<=0;ay0[0]<=0;ay1[0]<=0;ar[0]<=0;af[0]<=0;mx0[0]<=0;mx1[0]<=0;my0[0]<=0;my1[0]<=0;mf[0]<=0;si[0]<=0;mr[0]<=0;sr[0]<=0;se[0]<=0;sb[0]<=0;
        end
      end
    end else if(ce)begin
      // ckpt3-v3c: dispatch is called from EXACTLY ONE site (below) to avoid duplicating the whole
      // decode/writeback case. State muxes its inputs: S_EXEC (compute) supplies opr+av/mv; S_DEC
      // non-compute supplies pm_rdata+0. do_disp gates the single call.
      logic do_disp; logic [23:0] disp_op; logic [23:0] disp_av; logic [47:0] disp_mv; logic disp_noop;
      commit<=0; pm_rd<=0;pm_wr<=0;dm_rd<=0;dm_wr<=0; irq_ack<=1'b0; tx1_we<=1'b0; ifc_we<=1'b0;
      I_we=1'b0; L_we=1'b0; M_we=1'b0;   // funnel write-enable defaults (blocking; single write below)
      ps_we=1'b0; ss_we=1'b0; cs_we=1'b0; ls_we=1'b0; ps_wd='0; ss_wd='0; cs_wd='0; ls_wd='0;   // stack funnels
      w0_we=1'b0; w0_r='0; w0_v='0;                                                            // wreg0 funnel
      do_disp=1'b0; disp_op=opr; disp_av=24'h0; disp_mv=48'h0; disp_noop=1'b0;
      if(i7_we) begin i7_pend<=1'b1; i7_pv<=i7_wd; end  // latch the autobuffer write (async to FSM)
      case(st)
        S_RST: begin
          if(clr_busy) begin                 // cold clear sequence: write 0 to I/L/Msg[0..7]
            I_we=1'b1;I_wa=clr_cnt[2:0];I_wd=14'h0;
            L_we=1'b1;L_wa=clr_cnt[2:0];L_wd=14'h0;
            M_we=1'b1;M_wa=clr_cnt[2:0];M_wd=14'sh0;
            if(clr_cnt==4'd7) begin clr_busy<=1'b0; st<=S_FETCH; end else clr_cnt<=clr_cnt+4'd1;
          end else st<=S_FETCH;
        end
        S_FETCH: begin
          // ckpt4o: S_FETCH is now ONLY the one-time power-on/seed prime. The primed instruction never
          // takes an IRQ (boot instr0 = reset; fight-seed instr0 irq=-1), and S_DEC catches every IRQ
          // anyway -> no do_irq here. This keeps do_irq to a SINGLE call site (S_DEC), so its stack/
          // imask write logic is not inlined twice (area trim; behaviour identical, gate-verified).
          if(i7_pend && !i7_we) begin I_we=1'b1;I_wa=3'd7;I_wd=i7_pv; i7_pend<=1'b0; end  // autobuffer I[7] apply
          pm_addr<=pc; pm_rd<=1; ppc<=pc; st<=S_DEC;
        end
        S_DEC: begin
          // ckpt4o: unified overlapped-decode state. The fetch was already issued at the prior
          // instruction's commit (pm_rd@npc). IRQ: the prior commit prefetched the SEQUENTIAL/branch
          // successor (the return address); if a maskable IRQ is pending we DISCARD that fetch and
          // redirect to the vector (do_irq pushes pc = the return address). irq_lat prevents a second
          // redirect while irq_take is held across the vector fetch.
          // self-loop fast path: when npc==ppc the successor IS this same instruction; re-execute the
          // cached opcode (op_in=opr) with NO fetch (rdy implied) -> pm_rd stays low. Bit-exact (the
          // opcode at that address is unchanged) and CPI 1 for delay/spin loops.
          logic take; logic [13:0] vec; logic [23:0] op_in; logic rdy;
          op_in = selfrep ? opr : pm_rdata;
          rdy   = selfrep | pm_ready;
          // ckpt4o_fix: take the IRQ only once the overlapped successor fetch has RETURNED (rdy). Taking
          // it while that fetch is still in flight re-points pm_addr at the vector, but the servicer has
          // already accepted the discarded fetch: its pm_ready (and the M10K/pmc data of the OLD address)
          // lands in the next S_DEC and is consumed as the VECTOR opcode (pc=vec) -> the ISR's JUMP is
          // replaced by the return-address instruction. Waiting for rdy leaves nothing in flight when
          // the vector fetch is issued. Same instruction boundary as before (behaviour unchanged).
          take = irq_take && imask[5-irq_indx] && !irq_lat && rdy;   // matches do_irq's mask gate
          if(take) begin
            do_irq(irq_indx); vec = 14'h4 + ({11'b0,irq_indx}<<2);
            pm_addr<=vec; pm_rd<=1; ppc<=vec; irq_lat<=1'b1; selfrep<=1'b0;
          end else if(!rdy) begin pm_addr<=pc; pm_rd<=1; end   // PM stall: hold the fetch @pc
          else if(pace_hold) begin
            // real-time pace hold at the instruction boundary: cache the returned opcode and wait with
            // NO fetch in flight (same mechanism as the self-loop path: selfrep -> op_in=opr, rdy=1).
            // pc/ppc still name this instruction, so an IRQ taken while held pushes the right address.
            // irq_lat is left as-is (a held vector opcode must not be re-vectored).
            opr<=op_in; selfrep<=1'b1;
          end else begin
            irq_lat<=1'b0; selfrep<=1'b0;
            opr<=op_in;
            // ckpt3-v3: pre-read ALU/MAC x/y into xreg/yreg (ONE shared x-mux + ONE y-mux; isMac picks
            // ax/ay vs mx/my; high half AR/MR/SR shared). y==3 -> 0 (matches aluy/macy).
            begin
              logic [7:0] hh; logic [2:0] xs; logic [1:0] ys; logic isMac; logic [15:0] xc;
              hh=op_in[23:16]; xs=op_in[10:8]; ys=op_in[12:11];
              isMac=(hh==8'h06||hh==8'h07)?1'b0:~op_in[17];
              case(xs) 3'd3:xc=mr[bs][15:0];3'd4:xc=mr[bs][31:16];3'd5:xc={{8{mr[bs][39]}},mr[bs][39:32]};
                       3'd6:xc=sr[bs][15:0];3'd7:xc=sr[bs][31:16];default:xc=ar[bs]; endcase
              xreg <= (xs<3'd2) ? (isMac ? (xs[0]?mx1[bs]:mx0[bs]) : (xs[0]?ax1[bs]:ax0[bs])) : xc;
              if(isMac) yreg <= (ys==2'd0) ? my0[bs] : (ys==2'd1) ? my1[bs] : (ys==2'd2) ? mf[bs] : 16'h0;
              else      yreg <= (ys==2'd0) ? ay0[bs] : (ys==2'd1) ? ay1[bs] : (ys==2'd2) ? af[bs] : 16'h0;
            end
            // compute-class ops (alu_eval/mac_eval or DIVS/DIVQ) defer one clock to S_EXEC, where the
            // SINGLE datapath instance runs on xreg/yreg. Others dispatch now (no operand read needed).
            if( op_in[23:16]==8'h06 || op_in[23:16]==8'h07 ||
                op_in[23:20]==4'h2 || op_in[23:20]==4'h5 || op_in[23:20]==4'h6 ||
                op_in[23:20]==4'h7 || op_in[23:22]==2'b11 )
              st<=S_EXEC;
            else begin do_disp=1'b1; disp_op=op_in; end  // non-compute: dispatch below (av/mv=0)
          end
        end
        S_EXEC: begin  // single ALU + single MAC instance, fed only by xreg/yreg; dispatched below
          disp_op=opr; disp_av=alu_eval(opr,astat,xreg,yreg);
          mac_eval(opr,astat,xreg,yreg,disp_mv,disp_noop); do_disp=1'b1;
        end
        S_MEM: begin
          if(w_pend) begin
            if(w_ispm? pm_ready: dm_ready) begin w_pend<=0; commit<=1; st<=S_DEC; pm_addr<=pc; pm_rd<=1; ppc<=pc; end
            else begin
              if(w_ispm)begin pm_wr<=1;pm_addr<=pm_addr;pm_wdata<=pm_wdata;end
              else begin dm_wr<=1;dm_addr<=dm_addr;dm_wdata<=dm_wdata;end
            end
          end else if(r_pend) begin
            if(r_ispm? pm_ready: dm_ready) begin
              case(r_grp) 0:wreg0(r_reg, r_ispm? pm_rdata[23:8]:dm_rdata);
                          1:wreg1(r_reg, dm_rdata); 2:wreg2(r_reg, dm_rdata); 3:wreg3(r_reg, dm_rdata); endcase
              if(r_ispm) px<=pm_rdata[7:0];
              r_pend<=0;
              if(r2_pend) begin  // dual 0xc0-0xff second read = pgm DAG2 with op>>4 (ireg=4+op[7:6])
                dag_widx={1'b1,opr[7:6]}; dag_midx={1'b1,opr[5:4]};  // v3d: reuse the _dag copy (state-selected index)
                pm_addr<=I_dag[dag_widx]; pm_rd<=1; r_ispm<=1; r_pend<=1; r2_pend<=0;
                r_grp<=0; r_reg<=r2_reg;
                I_we=1'b1; I_wa=dag_widx; I_wd=dag_next(I_dag[dag_widx],M_dag[dag_midx],L_dag[dag_widx],L_mask_dag[dag_widx]);
              end else begin commit<=1; st<=S_DEC; pm_addr<=pc; pm_rd<=1; ppc<=pc; end
            end else begin if(r_ispm)begin pm_rd<=1;pm_addr<=pm_addr;end else begin dm_rd<=1;dm_addr<=dm_addr;end end
          end else begin commit<=1; st<=S_DEC; pm_addr<=pc; pm_rd<=1; ppc<=pc; end
        end
        S_SHIFT: begin
          // serial engine: mode 0 = 1-bit/clock variable shift; mode 1 = leading-zero count.
          if(sh_mode==1'b0 ? (sh_i>=sh_amt) : (sh_acc[31] || sh_clz>=7'd32)) begin
            shift_fin();
            if(sh_mem) begin  // issue the deferred DM/PM op (addr/wdata already latched in dispatch)
              if(w_pend) begin if(w_ispm) pm_wr<=1; else dm_wr<=1; end
              else if(r_pend) begin if(r_ispm) pm_rd<=1; else dm_rd<=1; end
              st<=S_MEM;
            end else begin commit<=1; st<=S_DEC; pm_addr<=pc; pm_rd<=1; ppc<=pc; end
          end else if(sh_mode==1'b0) begin
            // radix-4 serial shift (real-time pacing: MAME charges 1 cycle per shift, 3.125 clk budget):
            // 4 bits/clock while >= 4 remain, then 1 bit/clock. Same result as 1-bit steps (composition).
            if((sh_amt - sh_i) >= 6'd4) begin
              sh_acc <= sh_dir ? {{4{sh_arith & sh_acc[31]}}, sh_acc[31:4]} : {sh_acc[27:0],4'b0};
              sh_i <= sh_i + 6'd4;
            end else begin
              sh_acc <= sh_dir ? {(sh_arith?sh_acc[31]:1'b0), sh_acc[31:1]} : {sh_acc[30:0],1'b0};
              sh_i <= sh_i + 6'd1;
            end
          end else begin
            // leading-zero count, 4 per clock while the top nibble is all zero (cannot skip a leading 1)
            if(sh_acc[31:28]==4'h0 && sh_clz <= 7'd28) begin sh_acc <= {sh_acc[27:0],4'b0}; sh_clz <= sh_clz + 7'd4; end
            else begin sh_acc <= {sh_acc[30:0],1'b0}; sh_clz <= sh_clz + 7'd1; end
          end
        end
        default: st<=S_FETCH;
      endcase
      if(do_disp) dispatch(disp_op, disp_av, disp_mv, disp_noop);  // ckpt3-v3c: SINGLE dispatch call site
      // AREA: single funnelled write fanned out to every read-copy (+ I7 shadow) -> textbook MLABs.
      if(I_we) begin I_dag[I_wa]<=I_wd; I_rf[I_wa]<=I_wd; I_ab[I_wa]<=I_wd; if(I_wa==3'd7) i7_q<=I_wd; end
      if(L_we) begin L_mask_dag[L_wa]<=lmask_of(L_wd); L_dag[L_wa]<=L_wd; L_rf[L_wa]<=L_wd; L_ab[L_wa]<=L_wd; end
      if(M_we) begin M_dag[M_wa]<=M_wd; M_rf[M_wa]<=M_wd; M_ab[M_wa]<=M_wd; end
      if(w0_we) wreg0_apply(w0_r, w0_v);   // sound-area: the funnelled register move, last write of the clock
      // inv-area E1: the single stack write ports (current pointers); the push tasks set a funnel only when the push
      // stores (full stack: nothing stored, OVER bit set), so no guard is needed here.
      if(ps_we) pcst[pcsp[3:0]]<=ps_wd;
      if(ss_we) stst[stsp[1:0]]<=ss_wd;
      if(cs_we) cnst[cnsp[1:0]]<=cs_wd;
      if(ls_we) lpst[lpsp[1:0]]<=ls_wd;
    end
  end

  // AREA: one ALU + one MAC + one shifter per instruction (results = dispatch-local av/mv/shp,
  // computed once at dispatch entry, then SELECTED per arm) instead of inlining the datapath into
  // ~7 arms. compute4/compute_c/apply_shift take the precomputed values as inputs.
  // op[18:17]: mac_mr/alu_ar/mac_mf/alu_af
  task automatic compute4(input [23:0] op, input [23:0] av, input [47:0] mv, input logic noop);
    case(op[18:17])
      2'b00:begin if(!noop)begin mr[bs]<=mv[39:0];astat<=mv[47:40];end end
      2'b01:begin ar[bs]<=sat_ar(av[15:0],av[23:16]); astat<=av[23:16]; end
      2'b10:begin if(!noop)begin mf[bs]<=mv[31:16];astat<=mv[47:40];end end
      2'b11:begin af[bs]<=av[15:0]; astat<=av[23:16]; end
    endcase
  endtask
  task automatic compute_c(input [23:0] op, input [23:0] av, input [47:0] mv, input logic noop);
    if(op[17]) begin ar[bs]<=sat_ar(av[15:0],av[23:16]); astat<=av[23:16]; end
    else begin if(!noop)begin mr[bs]<=mv[39:0];astat<=mv[47:40];end end
  endtask

  // ===== dispatch: compute next-state from opcode. av/mv/noop are the SINGLE datapath results
  // (computed once in S_EXEC for compute ops; 0 for non-compute ops dispatched from S_DEC). =====
  task automatic dispatch(input [23:0] op, input [23:0] av, input [47:0] mv, input logic noop);
    logic [7:0] h; logic [15:0] tmp16; logic [15:0] rd0v;
    logic dag_en;   // dag_widx/dag_midx are module-level (v3d)
    logic sh_pmode, sh_pdir, sh_parith; logic [31:0] sh_pacc; logic [5:0] sh_pamt; // serial-shift request (prep)
    logic [15:0] shxf_v;                                            // shift x-operand read (shift stays 1-clock)
    logic cnd; logic is_ccf; logic signed [15:0] nc14;              // condition for cond'l control-flow (incl NOT-CE)
    h=op[23:16];
    // sound-area: ONE rd0 read mux per instruction (was one per distinct argument: op[3:0] for 0x0d / 0x9x / 0x28-0x2f /
    // 0x10, op[7:4] for the register-to-memory arms 0x58-0x5f / 0x68-0x6f / 0x78-0x7f / 0x11-0x13). No instruction
    // reads rd0 at both indices, so selecting the index by opcode class first is the same value in every arm.
    rd0v = rd0((h[7:4]==4'h5 || h[7:4]==4'h6 || h[7:4]==4'h7 || h==8'h11 || h==8'h12 || h==8'h13) ? op[7:4] : op[3:0]);
    // default: advance pc, no mem, commit next cycle
    pc_advance();
    // shift x-operand read (low sources differ; high half AR/MR/SR shared). ALU/MAC operands are
    // pre-read into xreg/yreg in S_DEC and av/mv computed ONCE in S_EXEC (module-level; not here).
    begin logic [15:0] xc; logic [2:0] xs; xs=op[10:8];
      case(xs) 3'd3:xc=mr[bs][15:0];3'd4:xc=mr[bs][31:16];3'd5:xc={{8{mr[bs][39]}},mr[bs][39:32]};
               3'd6:xc=sr[bs][15:0];3'd7:xc=sr[bs][31:16];default:xc=ar[bs]; endcase  // 2->ar
      shxf_v = (xs<3'd2) ? si[bs] : xc;
    end
    shift_prep(op,(h==8'h0f),astat,shxf_v,se[bs],sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith); // serial shift request
    dag_en=1'b0; dag_midx=3'd0;
    // ckpt2-v2: pre-decode the DAG read index (ONE signal) so I_dag/L_dag/M_dag read at a single
    // address. DAG2 (0x5x/0x7x/0xbx/0x11/0x13) uses {1,op[3:2]}; 0x09 op[4:2]; 0x0b {1,op[7:6]};
    // DAG1 (0xa/0x6x/0xc-f/0x12) op[3:2]. dag_en (per-arm) still triggers the post-modify write.
    if(h==8'h09) begin dag_widx=op[4:2]; dag_midx={op[4],op[1:0]}; end
    else if(h==8'h0b) begin dag_widx={1'b1,op[7:6]}; dag_midx=3'd0; end
    // zk4-inv6: + 0xBx "DM(I4-7,M4-7) = data16" (data_write_dag2, 2100ops.hxx:624-627: ireg 4+op[3:2], mreg 4+op[1:0]);
    // it fell to the DAG1 default (I0-3/M0-3): Invasion's host-command queue store at 0x38A0 wrote DM(I2) and left I6
    // unmodified -> command queue pointer off by one per packet -> every sound command rejected (reply 0xEEEE), silence.
    // MK4's sound program never executes 0xBx.
    else if(h[7:4]==4'h5||h[7:4]==4'h7||h[7:4]==4'hb||h==8'h11||h==8'h13)
      begin dag_widx={1'b1,op[3:2]}; dag_midx={1'b1,op[1:0]}; end
    else begin dag_widx=op[3:2]; dag_midx=op[1:0]; end
    // v3d: reg-file read index for rdrf (merged rd1f/rd2f). 0x0d picks rd1f/rd2f via op[9] (01 vs 10);
    // 0x95/0x96 via h[1]. rd1f -> {0,op[1:0]}, rd2f -> {1,op[1:0]}.
    rf_ra = (h==8'h0d) ? {op[9],op[1:0]} : {h[3],op[1:0]};  // 0x9x: rd1f=0x94-97(h[3]=0), rd2f=0x98-9b(h[3]=1)
    r_pend<=0; r2_pend<=0; w_pend<=0;
    commit_now=1'b1;  // ckpt4o default: commit + overlapped fetch @npc; mem/shift arms set commit_now=0 -> S_MEM/S_SHIFT
    // condition for conditional CONTROL-FLOW / conditional compute ops. cond 14 = NOT CE is the
    // ADSP-21xx "slow_condition" (2100ops.hxx:304/316): --CNTR, TRUE while >0, else pop the count
    // stack and FALSE -- a stateful counter test, NOT an astat test. cond_s() covers 0-13 and 15.
    casez(h)
      8'b000110??,8'b000111??,8'b0010000?,8'b0010001?,8'b0010010?,8'b0010011?,8'h0a,8'h0b,8'h0e: is_ccf=1'b1;
      default: is_ccf=1'b0;
    endcase
    if(is_ccf && op[3:0]==4'd14) begin
      nc14 = $signed(cntr) - 16'sd1;
      if(nc14 > 0) begin cntr<=nc14; cnd=1'b1; end
      else begin cn_pop(); cnd=1'b0; end      // slow_condition 2100ops.hxx:316-323
    end else cnd = cond_s(op[3:0], astat);

`ifdef ABL_DECODE
    casez(8'h22)  // force ALU-to-AR class; measures decode+unused arms
`else
    casez(h)
`endif
      8'h00: ; // NOP
      8'h06: begin // DIVS
        logic [15:0] xo,yo,t; xo=xreg; yo=yreg; t=xo^yo;
        astat<=(astat&~8'h20)|((t>>10)&8'h20); af[bs]<=(yo<<1)|(ay0[bs]>>15); ay0[bs]<=(ay0[bs]<<1)|(t>>15);
      end
      8'h07: begin // DIVQ
        logic [15:0] xo; logic [16:0] res; logic [15:0] t; xo=xreg;
        res = astat[QBIT]? ({1'b0,af[bs]}+{1'b0,xo}) : ({1'b0,af[bs]}-{1'b0,xo});
        t=res[15:0]^xo; astat<=(astat&~8'h20)|((t>>10)&8'h20);
        af[bs]<=(res[15:0]<<1)|(ay0[bs]>>15); ay0[bs]<=(ay0[bs]<<1)|(((~t)>>15)&16'h1);
      end
      8'h09: begin logic [2:0] t; t=op[4:2]; dag_en=1'b1; end // modify addr
      8'h0c: begin // mode control (2101: bits per adsp2100.cpp:1363-1373)
        logic [6:0] ms; ms=mstat;
        if(op[3])ms[6]=op[2]; if(op[13])ms[4]=op[12]; if(op[15])ms[5]=op[14]; // GO, INTEGER, TIMER (adsp2100.cpp:1365-1367)
        if(op[5])ms[0]=op[4]; if(op[7])ms[1]=op[6]; if(op[9])ms[2]=op[8]; if(op[11])ms[3]=op[10];
        // bank swap on MST_BANK change
        if(ms[0]!=mstat[0]) bs<=~bs;
        mstat<=ms; mstat_prev<=ms;
      end
      8'h0d: begin // internal reg move
        logic [3:0] dr,srr; dr=op[7:4]; srr=op[3:0];
        case(op[11:8])
          0:wreg0(dr,rd0v);1:wreg0(dr,rdrf(srr));2:wreg0(dr,rdrf(srr));3:wreg0(dr,rd3f(srr));
          4:wreg1(dr,rd0v);5:wreg1(dr,rdrf(srr));6:wreg1(dr,rdrf(srr));7:wreg1(dr,rd3f(srr));
          8:wreg2(dr,rd0v);9:wreg2(dr,rdrf(srr));10:wreg2(dr,rdrf(srr));11:wreg2(dr,rd3f(srr));
          12:wreg3(dr,rd0v);13:wreg3(dr,rdrf(srr));14:wreg3(dr,rdrf(srr));15:wreg3(dr,rd3f(srr));
        endcase
      end
      8'h0f: shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v[15],1'b0); // shift imm
      8'b000110??: if(cnd) npc = op[17:4]; // cond jump imm
      8'b000111??: if(cnd) begin pc_push((pc+1)&14'h3fff); npc = op[17:4]; end // cond call (adsp2100.cpp:1465-1471)
      8'b000101??: begin // DO UNTIL (adsp2100.cpp:1450-1454; gospel pushes m_pc AFTER m_pc++ => loop start = pc+1)
        lp_push(op[17:0]);                     // full loop stack: LOOP_OVER, loop NOT armed
        pc_push((pc+1)&14'h3fff);
      end
      8'h04: begin // stack control (adsp2100.cpp:1278-1287): POP PC (value dropped), POP LOOP, POP CNTR, PUSH/POP STS
        if(op[4]) pc_pop();
        if(op[3]) lp_pop();
        if(op[2]) cn_pop();
        if(op[1]) begin if(op[0]) st_pop(); else st_push(); end
      end
      8'b0010000?: if(cnd)begin if(!noop)begin mr[bs]<=mv[39:0];astat<=mv[47:40];end end
      8'b0010001?: if(cnd)begin ar[bs]<=sat_ar(av[15:0],av[23:16]); astat<=av[23:16]; end
      8'b0010010?: if(cnd)begin if(!noop)begin mf[bs]<=mv[31:16];astat<=mv[47:40];end end
      8'b0010011?: if(cnd)begin af[bs]<=av[15:0]; astat<=av[23:16]; end
      8'b001100??: wreg0(op[3:0], {{2{op[17]}},op[17:4]});
      8'b001101??: wreg1(op[3:0], {{2{op[17]}},op[17:4]});
      8'b001110??: wreg2(op[3:0], {{2{op[17]}},op[17:4]});
      8'b001111??: wreg3(op[3:0], {{2{op[17]}},op[17:4]});
      8'b0100????: wreg0(op[3:0], op[19:4]);
      8'b100000??: begin dm_addr<=op[17:4]; dm_rd<=1; r_ispm<=0; r_grp<=0; r_reg<=op[3:0]; r_pend<=1; commit_now=1'b0; st<=S_MEM; end
      8'b100001??: begin dm_addr<=op[17:4]; dm_rd<=1; r_ispm<=0; r_grp<=1; r_reg<=op[3:0]; r_pend<=1; commit_now=1'b0; st<=S_MEM; end
      8'b100010??: begin dm_addr<=op[17:4]; dm_rd<=1; r_ispm<=0; r_grp<=2; r_reg<=op[3:0]; r_pend<=1; commit_now=1'b0; st<=S_MEM; end
      8'b100011??: begin dm_addr<=op[17:4]; dm_rd<=1; r_ispm<=0; r_grp<=3; r_reg<=op[3:0]; r_pend<=1; commit_now=1'b0; st<=S_MEM; end
      8'b100100??: begin dm_addr<=op[17:4]; dm_wdata<=rd0v; dm_wr<=1; w_ispm<=0; w_pend<=1; commit_now=1'b0; st<=S_MEM; end
      8'b100101??: begin dm_addr<=op[17:4]; dm_wdata<=rdrf(op[3:0]); dm_wr<=1; w_ispm<=0; w_pend<=1; commit_now=1'b0; st<=S_MEM; end
      8'b100110??: begin dm_addr<=op[17:4]; dm_wdata<=rdrf(op[3:0]); dm_wr<=1; w_ispm<=0; w_pend<=1; commit_now=1'b0; st<=S_MEM; end
      8'b100111??: begin dm_addr<=op[17:4]; dm_wdata<=rd3f(op[3:0]); dm_wr<=1; w_ispm<=0; w_pend<=1; commit_now=1'b0; st<=S_MEM; end
      8'b1010????: begin logic [1:0] ir,mrg; ir=op[3:2];mrg=op[1:0];
        dm_addr<=(mstat[MST_REV])?rev14(I_dag[dag_widx]):I_dag[dag_widx]; dm_wdata<=op[19:4]; dm_wr<=1; w_ispm<=0; w_pend<=1; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1; end
      8'b1011????: begin logic [2:0] ir,mrg; ir={1'b1,op[3:2]};mrg={1'b1,op[1:0]};
        dm_addr<=I_dag[dag_widx]; dm_wdata<=op[19:4]; dm_wr<=1; w_ispm<=0; w_pend<=1; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1; end
      8'h0a: if(cnd) begin // conditional return / RTI (1341-1351)
        npc = pc_top; pc_pop();               // pc_stack_pop(): empty -> entry 0, sp stays 0
        if(op[4]) st_pop();                   // RTI: stat_stack_pop() (+ update_mstat bank swap)
      end
      8'b01010???: begin // compute then PM read to reg0[op[7:4]] (DAG2, ireg=4+op[3:2])
        logic [2:0] ir; ir={1'b1,op[3:2]}; compute4(op,av,mv,noop);
        pm_addr<=I_dag[dag_widx]; pm_rd<=1; r_ispm<=1; r_grp<=0; r_reg<=op[7:4]; r_pend<=1; r2_pend<=0; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1;
      end
      8'b01011???: begin // PM write (val<<8|px) from reg0[op[7:4]] then compute (DAG2)
        logic [2:0] ir; ir={1'b1,op[3:2]};
        pm_addr<=I_dag[dag_widx]; pm_wdata<={rd0v,px}; pm_wr<=1; w_ispm<=1; w_pend<=1; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1; compute4(op,av,mv,noop);
      end
      8'h0b: if(cnd) begin if(op[4]) pc_push((pc+1)&14'h3fff); npc = I_dag[dag_widx]; end  // adsp2100.cpp:1352-1360
      8'h0e: if(cnd) shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v[15],1'b0); // cond shift
      8'b00101???: begin logic [15:0] t; t=rd0v; compute4(op,av,mv,noop); wreg0(op[7:4],t); end
      8'b01100???: begin logic [1:0] ir; ir=op[3:2]; compute4(op,av,mv,noop); // compute then DM read DAG1
        dm_addr<= mstat[MST_REV]? rev14(I_dag[dag_widx]):I_dag[dag_widx]; dm_rd<=1; r_ispm<=0; r_grp<=0; r_reg<=op[7:4]; r_pend<=1; r2_pend<=0; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1; end
      8'b01101???: begin logic [1:0] ir; ir=op[3:2]; // DM write DAG1 then compute
        dm_addr<= mstat[MST_REV]? rev14(I_dag[dag_widx]):I_dag[dag_widx]; dm_wdata<=rd0v; dm_wr<=1; w_ispm<=0; w_pend<=1; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1; compute4(op,av,mv,noop); end
      8'b01110???: begin logic [2:0] ir; ir={1'b1,op[3:2]}; compute4(op,av,mv,noop); // compute then DM read DAG2
        dm_addr<=I_dag[dag_widx]; dm_rd<=1; r_ispm<=0; r_grp<=0; r_reg<=op[7:4]; r_pend<=1; r2_pend<=0; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1; end
      8'b01111???: begin logic [2:0] ir; ir={1'b1,op[3:2]}; // DM write DAG2 then compute
        dm_addr<=I_dag[dag_widx]; dm_wdata<=rd0v; dm_wr<=1; w_ispm<=0; w_pend<=1; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1; compute4(op,av,mv,noop); end
      8'b11??????: begin logic [1:0] ir; ir=op[3:2]; compute_c(op,av,mv,noop); // compute; DM read DAG1 -> dest; then PM read DAG2(op>>4) -> dest2
        dm_addr<= mstat[MST_REV]? rev14(I_dag[dag_widx]):I_dag[dag_widx]; dm_rd<=1; r_ispm<=0; r_grp<=0; r_reg<={2'b0,op[19:18]}; r_pend<=1; commit_now=1'b0; st<=S_MEM;
        dag_en=1'b1;
        r2_pend<=1; r2_reg<=op[23:20]-4'd8;  // pgm dest reg0 idx = hi[7:4]-8 (ay0/ay1/my0/my1)
      end
      8'h10: begin logic [15:0] t; t=rd0v; wreg0(op[7:4],t); // shift + internal reg move (no mem)
        shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v[15],1'b0); end
      // shift + mem (0x11-0x13): latch the mem request (strobe deferred), run shift, then S_MEM.
      8'h11: begin logic [2:0] ir; ir={1'b1,op[3:2]};   // shift + PM rw DAG2
        if(op[15]) begin pm_addr<=I_dag[dag_widx]; pm_wdata<={rd0v,px}; w_ispm<=1; w_pend<=1;
                         dag_en=1'b1; end
        else begin pm_addr<=I_dag[dag_widx]; r_ispm<=1;r_grp<=0;r_reg<=op[7:4];r_pend<=1;r2_pend<=0;
                   dag_en=1'b1; end
        shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v[15],1'b1);
      end
      8'h12: begin logic [1:0] ir; ir=op[3:2];           // shift + DM rw DAG1
        if(op[15]) begin dm_addr<= mstat[MST_REV]?rev14(I_dag[dag_widx]):I_dag[dag_widx]; dm_wdata<=rd0v; w_ispm<=0;w_pend<=1;
                         dag_en=1'b1; end
        else begin dm_addr<= mstat[MST_REV]?rev14(I_dag[dag_widx]):I_dag[dag_widx]; r_ispm<=0;r_grp<=0;r_reg<=op[7:4];r_pend<=1;r2_pend<=0;
                   dag_en=1'b1; end
        shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v[15],1'b1);
      end
      8'h13: begin logic [2:0] ir; ir={1'b1,op[3:2]};    // shift + DM rw DAG2
        if(op[15]) begin dm_addr<=I_dag[dag_widx]; dm_wdata<=rd0v; w_ispm<=0;w_pend<=1;
                         dag_en=1'b1; end
        else begin dm_addr<=I_dag[dag_widx]; r_ispm<=0;r_grp<=0;r_reg<=op[7:4];r_pend<=1;r2_pend<=0;
                   dag_en=1'b1; end
        shift_req(op,sh_pmode,sh_pacc,sh_pamt,sh_pdir,sh_parith,shxf_v[15],1'b1);
      end
      8'h05: if(astat[MVBIT]) mr[bs] <= mr[bs][39] ? {8'hff,16'h8000,16'h0000} : {8'h00,16'h7fff,16'hffff};
             // SAT MR (adsp2100.cpp:1289): IF MV, saturate MR. Latent (MV=0 in all traces); safety fix.
      default:  // audit safety net: record any UNDECODED opcode (0x02/0x03 or unknown; 0x04 decoded since dcs2-stack).
        if(h!=8'h01 && h!=8'h08 && !undec_seen) begin undec_seen<=1'b1; undec_pc<=ppc; undec_op<=h; end
    endcase
    // ONE shared address generator (DAG hoist): applies the selected index post-modify
    if(dag_en) begin I_we=1'b1; I_wa=dag_widx; I_wd=dag_next(I_dag[dag_widx],M_dag[dag_midx],L_dag[dag_widx],L_mask_dag[dag_widx]); end
    // ckpt4o commit tail: advance pc once (npc), then either commit + issue the overlapped fetch @npc
    // (folds away the old separate S_FETCH cycle), OR -- if an autobuffer I[7] write is pending -- fall
    // to the S_FETCH prime so the single I write-port serves i7 in a cycle of its own (no collision
    // with this instruction's DAG post-modify). mem/shift arms leave commit_now=0 and keep st<=S_MEM/
    // S_SHIFT; their successor fetch is issued at S_MEM/S_SHIFT completion.
    pc<=npc;
    if(commit_now) begin
      commit<=1'b1;
      // Drop the overlapped fetch (use the S_FETCH prime, pm_rd low for one cycle) when:
      //  - an autobuffer I[7] write is pending (single I write-port), OR
      //  - the successor fetch is the SAME address as this instruction (npc==ppc): a JUMP $ spin-wait
      //    or a 1-instruction non-memory DO-loop. Holding pm_rd high across a same-address refetch
      //    hangs the integrated PM servicer's same-address guard (zk4_dcs2 pm_sv, re-armed only when
      //    pm_rd idles). +1 cycle, only on self-repeating fetches. DM/PM-data loop bodies idle pm_rd
      //    during their data phase, so they re-arm the guard naturally and stay overlapped.
      if(i7_pend) st<=S_FETCH;                                       // autobuffer write pending: prime path
      else if(npc==ppc) begin st<=S_DEC; selfrep<=1'b1; end          // self-loop (JUMP $ / 1-insn loop):
                                                                     // re-execute the cached opcode, NO
                                                                     // re-fetch (pm_rd stays low) -> no
                                                                     // hang on the integrated PM servicer
                                                                     // same-address guard, and CPI 1.
      else begin st<=S_DEC; pm_addr<=npc; pm_rd<=1'b1; ppc<=npc; end // overlap: fetch the successor now
    end
  endtask

  // latch a serial-shift request and enter S_SHIFT (mem_after = a DM/PM op follows, deferred).
  // Only the operand sign bit is latched; astat/se/sb are read live at finalize (stable during shift).
  task automatic shift_req(input [23:0] op,input logic mode,input [31:0] acc0,input [5:0] amt,
      input logic dir,input logic arith,input logic xu15,input logic mem_after);
    sh_mode<=mode; sh_acc<=acc0; sh_amt<=amt; sh_dir<=dir; sh_arith<=arith; sh_i<=6'd0; sh_clz<=7'd0;
    sh_code<=op[14:11]; sh_xu15<=xu15; sh_mem<=mem_after;
    st<=S_SHIFT; commit_now=1'b0;
  endtask

  // finalize (runs at S_SHIFT completion): reproduce every shift code's SR/SE/SB/ASTAT writes
  // from the serially-computed result (sh_acc = shifted value; sh_clz = leading-zero count).
  // Reads astat/se[bs]/sb[bs] LIVE (unchanged since dispatch); sror = sh_code[0].
  task automatic shift_fin();
    logic [3:0] code; logic [7:0] a; logic [31:0] res; logic xu15; logic [7:0] c8;
    code=sh_code; a=astat; xu15=sh_xu15; res=sh_acc; c8 = 8'(sh_clz) - 8'd17;   // clz-16-1
    case(code)
      4'h0,4'h1,4'h2,4'h3,4'h4,4'h5,4'h6,4'h7,4'h8,4'h9,4'ha,4'hb:
        begin sr[bs]<= sh_code[0] ? (sr[bs]|res) : res; astat<=a; end
      4'hc: begin a[SSBIT]=xu15; se[bs]<= -c8; astat<=a; end
      4'hd: begin
        if(a[VBIT]) begin se[bs]<=8'd1; a[SSBIT]=~xu15; end
        else begin a[SSBIT]=xu15; se[bs]<= -c8; end
        astat<=a; end
      4'he: begin if($signed(se[bs])==-8'sd15) se[bs]<= -(8'(sh_clz)-8'd1); astat<=a; end
      4'hf: begin if($signed({1'b0,c8}) < -$signed({{3{sb[bs][4]}},sb[bs]})) sb[bs]<= -c8; astat<=a; end
      default: astat<=a;
    endcase
  endtask

  // ---- debug bus: 59 fields (cpu_field order) as 32b words ----
  wire [31:0] dw [59];
  assign dw[0]={18'b0,pc};
  assign dw[1]={16'b0,ax0[bs]}; assign dw[2]={16'b0,ax1[bs]}; assign dw[3]={16'b0,ay0[bs]}; assign dw[4]={16'b0,ay1[bs]};
  assign dw[5]={16'b0,ar[bs]};  assign dw[6]={16'b0,af[bs]};
  assign dw[7]={16'b0,mx0[bs]}; assign dw[8]={16'b0,mx1[bs]}; assign dw[9]={16'b0,my0[bs]}; assign dw[10]={16'b0,my1[bs]};
  assign dw[11]={16'b0,mr[bs][15:0]}; assign dw[12]={16'b0,mr[bs][31:16]}; assign dw[13]={24'b0,mr[bs][39:32]}; assign dw[14]={16'b0,mf[bs]};
  assign dw[15]={16'b0,si[bs]}; assign dw[16]={24'b0,se[bs]}; assign dw[17]={27'b0,sb[bs]};
  assign dw[18]={16'b0,sr[bs][15:0]}; assign dw[19]={16'b0,sr[bs][31:16]};
  genvar gi;
  generate
`ifndef SYNTHESIS
    // SIM ONLY: full I/M/L fan-out for the engine gates. In SYNTHESIS these are MLABs and the
    // all-8 fan-out (8 read ports each) is dropped; zk4_dcs2 uses the ab_* side port instead.
    for(gi=0;gi<8;gi=gi+1) begin: gI  assign dw[20+gi]={18'b0,I_dag[gi]}; end
    for(gi=0;gi<8;gi=gi+1) begin: gM  assign dw[28+gi]={18'b0,M_dag[gi]}; end
    for(gi=0;gi<8;gi=gi+1) begin: gL  assign dw[36+gi]={18'b0,L_dag[gi]}; end
`else
    for(gi=0;gi<8;gi=gi+1) begin: gI  assign dw[20+gi]=32'b0; end
    for(gi=0;gi<8;gi=gi+1) begin: gM  assign dw[28+gi]=32'b0; end
    for(gi=0;gi<8;gi=gi+1) begin: gL  assign dw[36+gi]=32'b0; end
`endif
  endgenerate
  // autobuffer side port: the SPORT1-selected I/M/L (indices from the autobuf) + pc/mstat/I7.
  // ONE async read port each on the DAG MLABs -- replaces the all-8 e_dbg fan-out in synthesis.
  assign ab_i = I_ab[ab_ireg];  assign ab_m = M_ab[ab_mreg];  assign ab_l = L_ab[ab_lreg];
  assign ab_i7 = i7_q;  assign ab_pc = pc;  assign ab_mstat = mstat;  assign ab_icntl2 = icntl[2]; assign ab_imask = imask;
  assign dw[44]={24'b0,px}; assign dw[45]={16'b0,cntr}; assign dw[46]={24'b0,astat};
  assign dw[47]={25'b0,mstat}; assign dw[48]={24'b0,sstat}; assign dw[49]={26'b0,imask}; assign dw[50]={27'b0,icntl};
  assign dw[51]={27'b0,pcsp}; assign dw[52]={29'b0,cnsp}; assign dw[53]={29'b0,stsp}; assign dw[54]={29'b0,lpsp};
  assign dw[55]={31'b0,irq_state[0]}; assign dw[56]={31'b0,irq_state[1]}; assign dw[57]={31'b0,irq_state[2]}; assign dw[58]={31'b0,irq_state[3]};
  genvar gj; generate for(gj=0;gj<59;gj=gj+1) begin: gPK assign dbg[gj*32 +: 32]=dw[gj]; end endgenerate

endmodule
`default_nettype wire
