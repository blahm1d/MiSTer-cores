# rtl/cpu — the Zeus C32 CPU, borrowed AS-IS from the Cruis'n fabric C31 (CLAUDE.md s4)

Source (2026-09-23): `D:/deck/fpga/cruisinusa/build/gm1-quartus-20260923T023130332994500Z/source/rtl/c31` — the
Cruis'n LIVE core (c31_core.sv 1afe781b), the one in their shipping gm1 builds (39,012 ALM = 93 %, 50 MHz, cabinet).
Copied byte-identical; sha256 below. Do not edit here without re-running the Zeus Z1 gate (core/regress_mk4.sh).

Why it replaced the 2026-09-21 copy (c31_core.sv 7a2e69bc, from the experimental Cruis'n build
c31-core-20260921T204842, unit_ahead / REGOUT-ce forwarding forms Cruis'n never adopted): MK4 fit A (zk4 snapshot
20260923T053808) did NOT fit (41,502 ALM = 99 %); that CPU was 12,915 ALM / 17,917 ALUTs integrated vs 10,184 / 13,339
for this one in gm1. Measured on MK4 fight7000 THROUGH the MK4 tier (core/run_zc2.sh --fast): this core 4.149 clk/instr,
6,112,369 instructions bit-exact vs MAME; the old copy 3.846. ~8 % slower CPU, CPU work ~43 % of a frame (was ~40 %).
Speed-stage params (LOOKAHEAD/FUSE/BTB/LDSKIP/EARLY_EA) are threaded to zk4_core / zc2_top as CPU_*; measured on the old
copy (unit quartus_map ALUTs, zeus1/area/cpu_*): all on 16,394, BTB off -1.1K, all off -4.5K but 8.44 clk/instr.

## Fork audit (inherited donor constants)

- Address predicates hardcode the V-unit map (c31_core.sv `fpe_fast_c` ~1424 and the first-read fast-region checks):
  RAM <= 0x01FFFF, 0x400000-0x41FFFF, internal 0x809800-0x809FFF, ROM >= 0xC00000. On the Zeus map every one of
  those ranges is side-effect-free (RAM / RAM / unmapped / banked ROM), so they are CORRECTNESS-SAFE; they only
  under-cover Zeus's fast regions (RAM 0x20000-0x3FFFF, 0x420000-0x43FFFF, internal 0x87FE00, ROM 0xA00000). PERFORMANCE
  item for later, parameterise with a re-gate.
- C32-only ISA behaviour (MAME tms320c3x.cpp:843, 956; 320c3x_ops.ipp:5681): trap vector base = (IF>>16)<<8, and
  ST bit 14 edge-mode external interrupts. NOT in this core. Measured unexercised in the traced game phases
  (census/vunit-c31-as-zeus-donor-20260918.md); the Z1 gate will show if boot needs them.
- Reset: the core resets to pc 0 in S_PRO and does NOT read the reset vector; the bench/board must load_en with
  pc = RAM[0] (MAME: tms320c3x device_reset m_pc = RMEM(0), after midzeus machine_reset shifts word 0 left).

```
fe3bfca34b0b50831946d5d9a16cba2eff1997a5642324ec3ae4195f3d0909a1 *c31_absf.sv
0a3316abd7347a4e551aa203886a708e1a9d1ab7d09591ad73ac1823cc3afc7f *c31_addsubf.sv
9018a1a4867bc36a2d1dd6bb2c4e675d22ab3ca0fec34c5bbd4afd23fa9692ef *c31_cond.sv
1afe781b53f8e6b2c477c30c7557488a80f3b2b5d8e15923bba04708e3779328 *c31_core.sv
4b8250eec16e824f15862be52fe80b3dcf58b58cf04af6d3863fbb5e96f6516c *c31_ea.sv
4e2dfbd508d3740e053456142143d794aeb1a9809b6bc237bd082a576c34de60 *c31_fconv.sv
e101f351a9b53ae22a528dcae4da0823edfd9778e43f42db125b4d96973bf1cd *c31_float2int.sv
35c4fd9a79c111a6f1421097fce8028958176e85a2d1194a27e17ce7afded97d *c31_int2float.sv
4e751c10b98dca17e43ea2be7b76e705c6ddd2ab855f4e66757f7bc786009758 *c31_mpyf.sv
4de16581380a389d6b1bea4489fdda1831bff4f0355b8893f91b3c1febeffb32 *c31_mpyi.sv
76dd3dcdf0f371a3f76555e7bd8f8dcf32f15826f1c647a31f096f709902cad9 *c31_negf.sv
dd79d1494696aaecde5e49025b4f93e2ebf540d5f9332cfdd69178fb454b204b *c31_norm.sv
fc4c342721a8e845a4127a8b88aa43c0c9726b26d373b0acb381628a5dc1f0cb *c31_rnd.sv
f7ee5517bdd0e683fa907be5738f885a7ee26204e89cb6314c5c295bf79170ec *c31_shift.sv
040638393308739f1aa420341b6ea10ea89d9981422e870554e03912c9467975 *c31_lzc.svh
```

## Local changes after the borrow

- zk4-s8 (2026-09-27, lanes/scorp): an ILLEGAL opcode decodes as a 1-cycle NOP (c31_core.sv, decode_word end). MAME
  illegal() (320c3x_ops.ipp:72-79) has no effect after execute_one burn_cycle(1) + pc++ (:88-97); the borrowed core sent it
  to S_FAULT, whose post=pre retire re-fetched the same word forever. MK4 executes the data word 0x31000000 at 0x010EF2 in
  Scorpion's teleport punch (cabinet freeze). Gates: core/regress_mk4_scorp.sh, core/tests/illegal/run_illegal.sh (+ mutants).
  The Cruis'n source (cruisinusa/rtl/c31/c31_core.sv:568, :1860, :2144) still has the S_FAULT path.
