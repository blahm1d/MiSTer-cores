// zr_rsys_syn.sv -- synthesis wrapper of zr_rsys (renderer + memsys + DDR gateway) for the standalone unit fit; the
// seed / census ports exist only under ZR_SEED. No logic.
module zr_rsys_syn (
  input  logic        clk, rst,
  input  logic        wr_valid, output logic wr_ready, input logic [9:0] wr_off, input logic [31:0] wr_data,
  input  logic [9:0]  rd_off, output logic [31:0] rd_data,
  input  logic [31:0] rb_init,
  input  logic [16:0] dbg_daddr, output logic [15:0] dbg_ddata,
  output logic [31:0] rb_now,
  output logic        idle, unsupported, fault,
  input  logic        sc_req, input logic [19:0] sc_word, input logic [5:0] sc_beats, output logic sc_gnt,
  output logic        sc_rvalid, output logic sc_rlast, output logic [63:0] sc_rdata,
  output logic        av_read, av_write, output logic [28:0] av_address, output logic [7:0] av_burstcount,
  output logic [63:0] av_writedata, output logic [7:0] av_byteenable,
  input  logic        av_waitrequest, av_readdatavalid, input logic [63:0] av_readdata,
  output logic [31:0] st_quads, st_polys, st_rejected, st_extents,
  output logic [31:0] st_clk, st_wsetup, st_wdrain, st_extstall, st_pixstarve, st_frontwait
);
  zr_rsys u (.lighting_disable(1'b0), .*);
endmodule
