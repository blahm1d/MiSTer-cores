// SPDX-License-Identifier: GPL-2.0-or-later
// zk4_emu.sv -- MiSTer emu wrapper for the MK4 (Midway Zeus 1) core, forked from the Cruis'n USA master core's
// cruisinusa/bandwidth/gm1/quartus/gm1_emu.sv (the cabinet-proven platform: bw1_pll 50 MHz core clock plus a
// -3515 ps sibling for SDRAM_CLK, P0022 power-on reset, hps_io ioctl WIDE=1, DDRAM and board SDRAM on the core clock).
//
// Controls follow MAME 0.289 midzeus.cpp INPUT_PORTS_START( mk4 ) (all active low):
//   DIPS    0x0001 coinage source (dipswitch), 0x003e coinage USA-1 (0x0030 = free play), 0x0080 test switch,
//           0x0100 fatalities, 0x0200 blood; unused bits high
//   SYSTEM  coin1 0x0001, coin2 0x0002, start1 0x0004, tilt 0x0008, service mode (test) 0x0010, start2 0x0020,
//           service1 0x0040, volume down 0x0800 / up 0x1000 (J1 Vol Down / Vol Up), others high
//   IN1     P1 up/down/left/right 0x0001-0x0008, high punch 0x0010, block 0x0020, high kick 0x0040; P2 the same << 8
//   IN2     P1 low punch 0x0001, low kick 0x0002, run 0x0004; P2 the same << 4
// RTC: hps_io's BCD clock -> the PIC2 clock bytes MAME builds (midwayic.cpp:511-517: sec, min, hour, weekday+1, mday,
// month+1, year-1900-yearoffs with yearoffs 94): MiSTer's month is already 1-12; year byte = BCD(yy + 6) for 20yy.
// hps_io RTC bytes (Main_MiSTer user_io.cpp:1072-1079): BCD sec, min, hour, mday, month 1-12, tm_year % 100; byte 6 =
// tm_wday 0-6 BINARY (Sunday 0) -> MAME's make_bcd(weekday + 1) = byte 6 + 1.
// Sound: silent in this build (DCS2 stand-in, zk4_dcs_stub); DCS2 on the ARM or in fabric is a later decision.
module emu (
    `include "sys/emu_ports.vh"
);
    // ---- OSD Audio Gain DEFAULT, both games: THE ONE PLACE to change it (0 = 0 dB, 1 = +6, 2 = +12, 3 = +18 dB).
    // OSD status[11:10] = 0 selects the default; the OSD list shows the default first, then the others ascending.
    // User decision 2026-09-26: +12 dB for MK4 and Invasion.
`ifndef ZK4_AUDIO_GAIN_DEFAULT
`define ZK4_AUDIO_GAIN_DEFAULT 2
`endif
    localparam [1:0] AUDIO_GAIN_DEFAULT = `ZK4_AUDIO_GAIN_DEFAULT;
    localparam AUDIO_GAIN_OSD = (AUDIO_GAIN_DEFAULT == 2'd0) ? "O[11:10],Audio Gain,0 dB,+6 dB,+12 dB,+18 dB;" :
                                (AUDIO_GAIN_DEFAULT == 2'd1) ? "O[11:10],Audio Gain,+6 dB,0 dB,+12 dB,+18 dB;" :
                                (AUDIO_GAIN_DEFAULT == 2'd2) ? "O[11:10],Audio Gain,+12 dB,0 dB,+6 dB,+18 dB;" :
                                                               "O[11:10],Audio Gain,+18 dB,0 dB,+6 dB,+12 dB;";
    // ZK4_DIAG (undefined by default, user decision 2026-09-26): the status screen / status mirror / bank-1 DDR
    // diagnostic hardware in zk4_top AND the OSD Status screen (O5) / Status page (O[9:7]) entries exist only with it.
`ifdef ZK4_GAME_INVASION
    // Invasion: The Abductors (invasnab, MAME 0.289 midzeus.cpp INPUT_PORTS_START( invasn ) :1033-1130): two lightguns
    // (GUNX/GUNY 1/2, TRIGGER bits 0/1), SYSTEM as MK4, IN1 / IN2 unused. DIPS: coinage (free play 0x0030), 0x0080 test
    // switch, 0x0200 Show Blood (On = 1). Gun sources and the Sinden border / crosshair follow the Revolution X core.
    localparam CONF_STR = {
        "INVASION;;",
        "-;",
        "P1,Guns;",
        "P1O[33:32],P1 Gun,L-Analog/USB Gun/Sinden,Mouse,D-Pad;",
        "P1O[35:34],P2 Gun,L-Analog/USB Gun/Sinden,Mouse,D-Pad;",
        "P1O[36],Sinden Border,Off,On;",
        "P1O[38:37],Border Width,4 px,10 px,20 px;",
        "P1O[39],Gun Crosshair,On,Off;",
        "P1O[41:40],Cursor Players,P1+P2,P1 Only,P2 Only;",
        "-;",
        "O1,Show Blood,On,Off;",
        "O3,Free Play,Off,On;",
        "O4,Test Switch (DIP),Off,On;",
`ifdef ZK4_DIAG
        "O5,Status screen,Off,On;",
        "O79,Status page,Health,CPU,Render,DDR3,Sound;",
`endif
        "-;",
        AUDIO_GAIN_OSD,
        "-;",
        "T6,Save Settings (CMOS);",
        "R0,Reset;",
        "-;",
        "J1,Trigger,Reload,Start,Coin,Test,Service,Vol Down,Vol Up;",
        "V,zk4-inv9"
    };
`else
    localparam CONF_STR = {
        "MK4;;",
        "-;",
        "O1,Blood,On,Off;",
        "O2,Fatalities,On,Off;",
        "O3,Free Play,Off,On;",
        "O4,Test Switch (DIP),Off,On;",
`ifdef ZK4_DIAG
        "O5,Status screen,Off,On;",
        "O79,Status page,Health,CPU,Render,DDR3,Sound;",
`endif
        "-;",
        AUDIO_GAIN_OSD,
        "-;",
        "T6,Save Settings (CMOS);",
        "R0,Reset;",
        "-;",
        "J1,High Punch,Block,High Kick,Low Punch,Low Kick,Run,Start,Coin,Test,Service,Vol Down,Vol Up,Lighting Toggle;",
        "V,zk4-s8"
    };
`endif
    wire clk_sys, clk_sdram_pin, pll_locked;
    wire [127:0] status;
    wire [1:0]  buttons;
    wire [31:0] joystick_0, joystick_1;
    wire [64:0] RTC;
    tri [35:0] ext_bus;
    assign ext_bus[32]=1'b0;
    assign ext_bus[15:0]=16'b0;
    tri [21:0] gamma_bus;
    assign gamma_bus[21]=1'b0;
    wire        ioctl_download, ioctl_wr;
    wire [26:0] ioctl_addr;
    wire [15:0] ioctl_dout;
    wire [15:0] ioctl_index;
    wire        ioctl_wait;
    wire [15:0] ioctl_din;
    // CMOS save: explicit OSD action (the game rewrites CMOS during play, so an automatic dirty-save would loop --
    // the Exidy 440 / Gladiator policy); one upload request per press
    reg nv_save = 1'b0, nv_save_d = 1'b0;
    always @(posedge clk_sys) begin nv_save_d <= status[6]; nv_save <= status[6] && !nv_save_d; end
`ifdef ZK4_GAME_INVASION
    wire [15:0] analog_0, analog_1;                           // MiSTer left analog = every absolute gun (USB gun / Sinden)
    wire [24:0] ps2_mouse;
`endif
    hps_io #(.CONF_STR(CONF_STR), .WIDE(1)) hps_io (
        .clk_sys(clk_sys),.HPS_BUS(HPS_BUS),.EXT_BUS(ext_bus),.gamma_bus(gamma_bus),
        .joystick_0(joystick_0),.joystick_1(joystick_1),
`ifdef ZK4_GAME_INVASION
        .joystick_l_analog_0(analog_0),.joystick_l_analog_1(analog_1),.ps2_mouse(ps2_mouse),
`endif
        .joystick_0_rumble(16'd0),.joystick_1_rumble(16'd0),.joystick_2_rumble(16'd0),
        .joystick_3_rumble(16'd0),.joystick_4_rumble(16'd0),.joystick_5_rumble(16'd0),
        .ps2_kbd_clk_in(1'b1),.ps2_kbd_data_in(1'b1),.ps2_mouse_clk_in(1'b1),.ps2_mouse_data_in(1'b1),
        .ps2_kbd_led_status(3'd0),.ps2_kbd_led_use(3'd0),
        .sd_rd(1'b0),.sd_wr(1'b0),
        .status(status),.buttons(buttons),.status_menumask(16'b0),
        .status_in(128'b0),.status_set(1'b0),.info_req(1'b0),.info(8'b0),
        .video_rotated(1'b0),.new_vmode(1'b0),
        .RTC(RTC),
        .ioctl_download(ioctl_download),.ioctl_index(ioctl_index),.ioctl_wr(ioctl_wr),
        .ioctl_addr(ioctl_addr),.ioctl_dout(ioctl_dout),.ioctl_wait(ioctl_wait),
        .ioctl_upload_req(nv_save),.ioctl_upload_index(8'd2),.ioctl_din(ioctl_din)
    );
    bw1_pll pll (.refclk(CLK_50M),.rst(1'b0),.outclk_0(clk_sys),.outclk_1(clk_sdram_pin),.locked(pll_locked));
    // Power-on reset (P0022): 2-FF synced ~locked on the one core clock; the ROM capture path and the SDRAM
    // controller use it.
    (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS" *)
    reg [2:0] por50_pipe=3'b111;
    always @(posedge clk_sys or negedge pll_locked) if(!pll_locked) por50_pipe<=3'b111; else por50_pipe<={por50_pipe[1:0],1'b0};
    wire por50 = por50_pipe[2];
    wire core_reset = RESET || buttons[1] || status[0];

    wire lighting_disable;
`ifdef ZK4_GAME_INVASION
    assign lighting_disable = 1'b0;
`else
    // Appended J1 button 13 (joy[16]); existing gameplay mappings keep their positions.
    zk4_lighting_toggle u_lighting_toggle (.clk(clk_sys), .rst(por50 || core_reset),
        .pressed({joystick_1[16], joystick_0[16]}), .lighting_disable);
`endif

`ifdef ZK4_GAME_INVASION
    // ---- Invasion controls (MiSTer joystick: [0] right [1] left [2] down [3] up; J1 buttons from [4]:
    //      4 Trigger, 5 Reload, 6 Start, 7 Coin, 8 Test, 9 Service, 10 Vol Down, 11 Vol Up) ----
    wire p1_start = joystick_0[6], p2_start = joystick_1[6];
    wire coin1 = joystick_0[7], coin2 = joystick_1[7];
    wire test_btn = joystick_0[8] | joystick_1[8], service_btn = joystick_0[9] | joystick_1[9];
    wire vol_down = joystick_0[10] | joystick_1[10], vol_up = joystick_0[11] | joystick_1[11];
    //   SYSTEM (invasn = mk4 layout): 0 coin1, 1 coin2, 2 start1, 4 service mode = Test, 5 start2, 6 service1,
    //   11 volume down, 12 volume up; IN1 / IN2 unused (0xFFFF)
    wire [15:0] sys_in = 16'hffff & ~{3'd0, vol_up, vol_down, 4'd0, service_btn, p2_start, test_btn, 1'b0, p1_start, coin2, coin1};
    wire [15:0] in1 = 16'hffff, in2 = 16'hffff;
    //   DIPS: Show Blood 0x0200 cleared when status[1] (Off), test switch 0x0080 when status[4], free play = coinage
    //   0x003e -> 0x0030 when status[3]
    wire [15:0] dips = 16'hffff & ~(status[1] ? 16'h0200 : 16'h0) & ~(status[4] ? 16'h0080 : 16'h0)
                                & ~(status[3] ? 16'h000e : 16'h0);
    // guns: sources per player (OSD 33:32 / 35:34), trigger / reload buttons, mouse; ports + crosshair (zk4_gun_input)
    wire [7:0] gun_x [2], gun_y [2]; wire [1:0] gun_trig; wire [8:0] gun_cx [2], gun_cy [2];
    wire [15:0] g_an [2]; assign g_an[0] = analog_0; assign g_an[1] = analog_1;
    wire [3:0]  g_dir [2]; assign g_dir[0] = joystick_0[3:0]; assign g_dir[1] = joystick_1[3:0];
    wire [1:0]  g_src [2]; assign g_src[0] = status[33:32]; assign g_src[1] = status[35:34];
    zk4_gun_input u_guns (.clk(clk_sys), .rst(core_reset), .vs(VGA_VS), .analog(g_an), .dir(g_dir), .src(g_src),
        .fire_btn({joystick_1[4], joystick_0[4]}), .reload_btn({joystick_1[5], joystick_0[5]}), .ps2_mouse(ps2_mouse),
        .gun_x(gun_x), .gun_y(gun_y), .trigger(gun_trig), .cx(gun_cx), .cy(gun_cy));
    // overlay: Sinden border width 4 / 10 / 20 px (OSD 38:37), crosshair on unless OSD 39, cursor players (OSD 41:40)
    wire [8:0] gun_bw = (status[38:37] == 2'd1) ? 9'd10 : (status[38:37] == 2'd2) ? 9'd20 : 9'd4;
    wire [1:0] gun_xen = status[39] ? 2'b00 : (status[41:40] == 2'd1) ? 2'b01 : (status[41:40] == 2'd2) ? 2'b10 : 2'b11;
`else
    // ---- controls (MiSTer joystick: [0] right [1] left [2] down [3] up, buttons from [4]) ----
    wire [15:0] in1 =16'hffff & ~{1'b0, joystick_1[6], joystick_1[5], joystick_1[4], joystick_1[0], joystick_1[1], joystick_1[2], joystick_1[3],
                                   1'b0, joystick_0[6], joystick_0[5], joystick_0[4], joystick_0[0], joystick_0[1], joystick_0[2], joystick_0[3]};
    //   IN1 bit order per player: 0 up, 1 down, 2 left, 3 right, 4 high punch (J1 button 1 = joy[4]),
    //   5 block (joy[5]), 6 high kick (joy[6])
    wire [15:0] in2 = 16'hffff & ~{9'd0, joystick_1[9], joystick_1[8], joystick_1[7], 1'b0, joystick_0[9], joystick_0[8], joystick_0[7]};
    //   IN2 per player: 0 low punch (joy[7]), 1 low kick (joy[8]), 2 run (joy[9]); P2 at bits 4-6
    wire p1_start = joystick_0[10], p2_start = joystick_1[10];
    wire coin1 = joystick_0[11], coin2 = joystick_1[11];
    wire test_btn = joystick_0[12] | joystick_1[12], service_btn = joystick_0[13] | joystick_1[13];
    wire vol_down = joystick_0[14] | joystick_1[14], vol_up = joystick_0[15] | joystick_1[15];
    //   SYSTEM: 0 coin1, 1 coin2, 2 start1, 3 tilt (never), 4 service mode = Test, 5 start2, 6 service1,
    //           11 volume down (0x0800), 12 volume up (0x1000) (midzeus.cpp mk4 SYSTEM IPT_VOLUME_DOWN / _UP)
    wire [15:0] sys_in = 16'hffff & ~{3'd0, vol_up, vol_down, 4'd0, service_btn, p2_start, test_btn, 1'b0, p1_start, coin2, coin1};
    //   DIPS: blood 0x0200 cleared when status[1] (Off), fatalities 0x0100 when status[2], test switch 0x0080 when
    //   status[4]; free play = coinage 0x003e -> 0x0030 (clear 0x000e) when status[3]
    wire [15:0] dips = 16'hffff & ~(status[1] ? 16'h0200 : 16'h0) & ~(status[2] ? 16'h0100 : 16'h0)
                                & ~(status[4] ? 16'h0080 : 16'h0) & ~(status[3] ? 16'h000e : 16'h0);
`endif

    // ---- RTC -> PIC2 clock bytes (MAME shape) ----
    function automatic [7:0] bcd_add6(input [7:0] b);        // BCD(yy) -> BCD(yy + 6), yy < 94
        reg [7:0] bin;
        begin bin = b[7:4] * 8'd10 + b[3:0] + 8'd6; bcd_add6 = {bin / 8'd10, 4'b0} | (bin % 8'd10); end
    endfunction
    wire [7:0] rtc_bytes [7];
    assign rtc_bytes[0] = RTC[7:0];   assign rtc_bytes[1] = RTC[15:8];  assign rtc_bytes[2] = RTC[23:16];
    assign rtc_bytes[3] = RTC[55:48] + 8'd1; assign rtc_bytes[4] = RTC[31:24]; assign rtc_bytes[5] = RTC[39:32];
    assign rtc_bytes[6] = bcd_add6(RTC[47:40]);
    wire [15:0] ports [4];
    assign ports[0] = dips; assign ports[1] = sys_in; assign ports[2] = in1; assign ports[3] = in2;

    assign ADC_BUS='z;
    assign USER_OUT='1;
    assign {UART_RTS,UART_TXD,UART_DTR}=0;
    assign {SD_SCK,SD_MOSI,SD_CS}='z;
    `ifdef MISTER_DUAL_SDRAM
    assign {SDRAM2_DQ,SDRAM2_A,SDRAM2_BA,SDRAM2_CLK,SDRAM2_nWE,SDRAM2_nCAS,SDRAM2_nRAS,SDRAM2_nCS}='z;
    `endif
    `ifdef MISTER_FB
    assign {FB_EN,FB_FORMAT,FB_WIDTH,FB_HEIGHT,FB_BASE,FB_STRIDE}=0;
    assign FB_FORCE_BLANK=1;
      `ifdef MISTER_FB_PALETTE
      assign {FB_PAL_CLK,FB_PAL_ADDR,FB_PAL_DOUT,FB_PAL_WR}=0;
      `endif
    `endif
    assign VIDEO_ARX=13'd4; assign VIDEO_ARY=13'd3;
    assign {VGA_SL,VGA_F1,VGA_SCALER,VGA_DISABLE}=0;
    assign {HDMI_FREEZE,HDMI_BLACKOUT,HDMI_BOB_DEINT}=0;
    assign CLK_VIDEO=clk_sys;
    assign DDRAM_CLK=clk_sys;
    assign SDRAM_CLK=clk_sdram_pin;

    wire [7:0] r,g,b; wire ce,de,hs,vs; wire loader_done, map_fault, render_fault; wire [7:0] cpu_fault;
`ifdef ZK4_CPU_NOBTB
    localparam int CPU_BTB = 0;          // area probe: CPU branch-target buffer off (QSF macro via prepare VARIANT)
`else
    localparam int CPU_BTB = 1;
`endif
`ifdef ZK4_DCS_FABRIC
    localparam bit DCS_FABRIC = 1'b1;   // fit B: the fabric DCS2 sound board (QSF macro via prepare VARIANT)
`else
    localparam bit DCS_FABRIC = 1'b0;
`endif
`ifdef ZK4_DCS_SHADOW
    localparam bit DCS_SHADOW = 1'b1;   // FIT B MEASUREMENT build only (QSF macro); never a cabinet build
`else
    localparam bit DCS_SHADOW = 1'b0;
`endif
    wire signed [15:0] audio_l, audio_r;
    zk4_top #(.DCS_SHADOW(DCS_SHADOW), .CPU_BTB(CPU_BTB), .DCS_FABRIC(DCS_FABRIC)) core (
        .lighting_disable,
`ifdef ZK4_DIAG
        .clk(clk_sys),.por(por50),.core_reset(core_reset),.show_status(status[5]),.status_page(status[9:7]),
`else
        .clk(clk_sys),.por(por50),.core_reset(core_reset),.show_status(1'b0),.status_page(3'd0),   // no diag hardware
`endif
        .ioctl_download(ioctl_download),.ioctl_wr(ioctl_wr),.ioctl_addr(ioctl_addr),.ioctl_dout(ioctl_dout),
        .ioctl_index(ioctl_index),.ioctl_wait(ioctl_wait),.ioctl_din(ioctl_din),
        .SDRAM_DQ(SDRAM_DQ),.SDRAM_A(SDRAM_A),.SDRAM_BA(SDRAM_BA),.SDRAM_DQML(SDRAM_DQML),.SDRAM_DQMH(SDRAM_DQMH),
        .SDRAM_nCS(SDRAM_nCS),.SDRAM_nCAS(SDRAM_nCAS),.SDRAM_nRAS(SDRAM_nRAS),.SDRAM_nWE(SDRAM_nWE),.SDRAM_CKE(SDRAM_CKE),
        .DDRAM_BUSY(DDRAM_BUSY),.DDRAM_DOUT_READY(DDRAM_DOUT_READY),.DDRAM_DOUT(DDRAM_DOUT),
        .DDRAM_ADDR(DDRAM_ADDR),.DDRAM_BURSTCNT(DDRAM_BURSTCNT),.DDRAM_BE(DDRAM_BE),
        .DDRAM_DIN(DDRAM_DIN),.DDRAM_RD(DDRAM_RD),.DDRAM_WE(DDRAM_WE),
        .in_port(ports),.rtc(rtc_bytes),
`ifdef ZK4_GAME_INVASION
        .gun_xin(gun_x),.gun_yin(gun_y),.gun_trigger(gun_trig),.gun_cx(gun_cx),.gun_cy(gun_cy),.gun_cross_en(gun_xen),
        .gun_border_en(status[36]),.gun_border_w(gun_bw),
`endif
        .ce_pix(ce),.hs(hs),.vs(vs),.de(de),.r(r),.g(g),.b(b),
        .loader_done(loader_done),.sdram_map_fault(map_fault),.cpu_pc(),.cpu_fault(cpu_fault),.render_fault(render_fault),
        .audio_l(audio_l),.audio_r(audio_r));

    assign CE_PIXEL=ce; assign VGA_DE=de; assign VGA_HS=hs; assign VGA_VS=vs;
    assign VGA_R=r; assign VGA_G=g; assign VGA_B=b;
    // OSD Audio Gain (zk4_audio_gain.sv), both games on status[11:10]: the DAC words are MAME's level; x1/x2/x4/x8 with
    // saturation. OSD entry s -> gain code: s = 0 is AUDIO_GAIN_DEFAULT, s = 1..3 the remaining codes ascending.
    wire [1:0] gain_osd = status[11:10];
    wire [1:0] gain_code = (gain_osd == 2'd0) ? AUDIO_GAIN_DEFAULT :
                           (gain_osd - 2'd1 >= AUDIO_GAIN_DEFAULT) ? gain_osd : gain_osd - 2'd1;
    wire signed [15:0] audio_gl, audio_gr;
    zk4_audio_gain u_gain (.clk(clk_sys), .code(gain_code), .in_l(audio_l), .in_r(audio_r), .out_l(audio_gl), .out_r(audio_gr));
    assign AUDIO_L=audio_gl; assign AUDIO_R=audio_gr; assign AUDIO_MIX=0; assign AUDIO_S=1;   // 0 unless DCS_SHADOW
    assign {LED_DISK,LED_POWER,BUTTONS}=0;
    assign LED_USER=(cpu_fault != 8'd0) | render_fault | map_fault;
endmodule
