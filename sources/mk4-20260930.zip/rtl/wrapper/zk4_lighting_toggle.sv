// SPDX-License-Identifier: GPL-2.0-or-later
// One lighting toggle per new press from either player's mapped button.
// A held button at reset must be released before it can toggle lighting.
module zk4_lighting_toggle (
  input  logic       clk, rst,
  input  logic [1:0] pressed,
  output logic       lighting_disable
);
  logic [1:0] held;
  always_ff @(posedge clk) begin
    held <= pressed;
    if (rst) lighting_disable <= 1'b0;
    else if (|(pressed & ~held)) lighting_disable <= ~lighting_disable;
  end
endmodule
