Cruis'n USA - 09/25 release
RBF SHA-256: 3eb932e65159fcf2bb4eca4b1bd9c88d8a440a26c6c27a1b12eb1e98666425ee

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: source
The compiled binary's validation status is recorded in the feed catalog.
