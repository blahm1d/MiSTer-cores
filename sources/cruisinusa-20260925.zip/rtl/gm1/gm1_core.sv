`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_core.sv -- Cruis'n USA master core (gm1): the whole game in fabric on one 50 MHz clock, no ARM.
//
// Forked from rtl/platform/cusa_platform_core.sv without the physical mailbox, the PCM ring and the diagnostics
// publisher. One avalon_shared_mux shares the MiSTer DDRAM port (mister_ddram_adapter) between four clients:
//   ENGINE  gm1_engine (V-unit framebuffer, textures, palette)        REGION_BASE + 0x100000 / 0x200000 / 0x600000
//   CAPTURE idle since r12 (was vunit_presentation surface writes to REGION_BASE + 0x700000 / 0x800000)
//   SCAN    gm1_fb_present: the displayed framebuffer page, 8-beat line bursts (urgent; r12, was the RGB32 surface)
//   DCS     cusa_dcs_subsystem ROM store and ROM reads (urgent)      DCS_DDR_BASE (4 MiB)
// Offsets are the physical_mailbox_pkg MB_* values the hybrid shipped with.
//
// ROM delivery (MRA): index 1 maindata -> gm1_loader -> board SDRAM (gm1_sdram); index 2 DCS ROMs ->
// cusa_dcs_subsystem -> DDR. Both capture paths run on the power-on reset (P0022). The game (engine reset) starts
// once both have landed; the engine and presentation are then configured, and guest time starts.
// Warm (OSD) reset is not acted on in v1: resetting the engine while it has DDR traffic in flight could wedge the
// shared mux, which the hybrid needed a drain-and-fence sequence for. A core reload from the menu is a full restart.
//
// Status screen (bw1_hdmi_status, shown until the first game frame is presented, or while `show_status`):
//   1 maindata stream seen               8 first V-unit video interrupt (INT0)
//   2 maindata complete (10 MiB, CRC)    9 first game frame presented
//   3 no dropped maindata halfwords     10 DCS run set by the game
//   4 SDRAM loaded (boot copy, CMOS,    11 no C31 fault, no unmapped C31 access
//     fast RAM), no SDRAM map fault     12 no V-unit, memory or scanout fault
//   5 DCS ROM in DDR, CRC and drops ok  13 no DDR mux or adapter fault
//   6 engine and presentation configured
//   7 C31 running
// Meter: recent audio peak. Bottom bar (after the first frame): green when bars 11-13 pass.
module gm1_core #(
    parameter [31:0] REGION_BASE      = 32'h38000000,
    parameter [31:0] DCS_DDR_BASE     = 32'h39000000,
    parameter [31:0] DCS_EXPECTED_CRC = 32'h692a64fa,
    parameter [31:0] MD_EXPECTED_CRC  = 32'h3d41eabf,   // zlib CRC-32 of the 10 MiB maindata stream (measured)
    parameter integer WIDTH=512, HEIGHT=400, H_TOTAL=666, V_TOTAL=432,
    parameter integer H_SYNC_START=526, H_SYNC_END=551, V_SYNC_START=401, V_SYNC_END=404,
    parameter integer PIXEL_DIVIDER=3,
    parameter integer DAC_PERIOD=1600               // 50e6 / 31,250 Hz
) (
    input  wire        clk,
    input  wire        por,
    input  wire        core_reset,                  // monitored by the capture audits only (see header)

    input  wire        ioctl_download,
    input  wire        ioctl_wr,
    input  wire [26:0] ioctl_addr,
    input  wire [15:0] ioctl_dout,
    input  wire [15:0] ioctl_index,
    input  wire        ioctl_upload,       // r23 NVRAM save (hps_io upload of MRA <nvram index="3">)
    output wire [15:0] ioctl_din,
    input  wire        nvram_save,         // OSD "Save NVRAM" trigger bit
    output wire        nvram_upload_req,
    output wire        nvram_dirty,
    output reg  [1:0]  game,               // r24 family: 0 Cruis'n USA, 1 Cruis'n World, 2 Off Road Challenge (MRA index 4)
    input  wire [64:0] mister_rtc,         // hps_io RTC (PIC2 clock)
    output wire        ioctl_wait,

    input  wire        DDRAM_BUSY,
    input  wire        DDRAM_DOUT_READY,
    input  wire [63:0] DDRAM_DOUT,
    output wire [28:0] DDRAM_ADDR,
    output wire [7:0]  DDRAM_BURSTCNT,
    output wire [7:0]  DDRAM_BE,
    output wire [63:0] DDRAM_DIN,
    output wire        DDRAM_RD,
    output wire        DDRAM_WE,

    inout  wire [15:0] SDRAM_DQ,
    output wire [12:0] SDRAM_A,
    output wire [1:0]  SDRAM_BA,
    output wire        SDRAM_DQML, SDRAM_DQMH,
    output wire        SDRAM_nCS, SDRAM_nCAS, SDRAM_nRAS, SDRAM_nWE, SDRAM_CKE,

    input  wire [15:0] cabinet_in0, cabinet_in1, cabinet_switch2, cabinet_dips,
    input  wire [31:0] adc_channels,
    input  wire        show_status,
    input  wire [1:0]  rumble_intensity,   // r21: 0 off, 1 low, 2 medium, 3 high
    input  wire [1:0]  dither_mode,        // r22: 0 MAME, 1 Soft, 2 Dark, 3 Raw (gm1_dedither.sv)
    output wire [15:0] rumble,             // r21: {large, small} for hps_io joystick_0_rumble
    input  wire [1:0]  status_page,        // 0 health rows (r7 layout), 1 interrupts / TEST (r10), 2 render, 3 DDR3 (r11)
    input  wire [1:0]  test_src_seen,      // r10: sticky {Test button pressed, OSD Send ENTER pulsed} (gm1_emu.sv)

    output wire signed [15:0] audio,
    output wire        audio_ce,

    output wire        vga_ce, vga_de, vga_hs, vga_vs,
    output wire [7:0]  vga_r, vga_g, vga_b,
    output wire        fault,

    // observability (simulation and the status screen)
    output wire        loader_done,
    output wire        dcs_rom_loaded,
    output wire        game_running,
    output wire [63:0] instructions,
    output wire [23:0] cpu_pc,
    output wire [31:0] presented_frames,
    // CMOS seed (MRA index 3): the bench asserts a complete seed, the cabinet build ignores these
    output wire [31:0] cmos_seed_words_o,
    output wire [31:0] cmos_seed_dropped_o,
    output wire        cmos_seed_ok_o
);
    // ================= ROM capture: maindata -> SDRAM =================
    wire        md_wait, md_seen, md_closed, md_size_ok;
    wire        l_req, l_ack;
    wire [24:0] l_baddr;
    wire [31:0] l_wdata, md_words, md_crc, md_dropped;
    // STICKY IN0 for the diagnostic row: a bit latches low the first time that button is pressed and
    // stays low. The OSD ENTER pulse is 500 ms and the only remote instrument is a screenshot capped
    // at 1 Hz, so a live view can miss it entirely -- as it did on 2026-09-16. Sticky makes "did this
    // input EVER reach the core" answerable from a screenshot taken at any later time.
    // r7 (2026-09-16): rows A and E now SPLIT BAR 12. Bar 12 (video_ok) ORs together five
    // separate conditions -- engine_halted, memory_fault, scanout_fault, vunit_fault and
    // presentation_halted -- so when it goes red the bar cannot say which one fired, and on the
    // cabinet that costs a whole trip. The rule this cost us in r6: when a bar aggregates N
    // conditions, spend the diagnostic row SPLITTING THAT, not testing a side hypothesis.
    //   DIAG A = {memory_fault[7:0], vunit_fault[7:0]}
    //   DIAG E = {engine_halted, presentation_halted, ext_unmapped, unimpl,
    //             scanout_fault[2:0], presentation_fault[7:0], sd_map_fault}
    // The DDR forensics row moves out: bar 13 still reports any DDR mux/adapter fault, row A read
    // all-dim on every r5/r6 cabinet sample, and the Avalon stability defect it was built for is
    // fixed and confirmed on silicon. Restore it from git if a DDR fault ever returns.
    // Column 0 is bit 15, so each row reads left to right as a binary number off a screenshot.
    //   A 15..8  memory_fault[7:0]  vunit_memory_arbiter fault_code: 1 BAD_CONFIG, 2 BAD_CPU_REQUEST,
    //                               3 UNEXPECTED_READ_RESPONSE, 4 READ_ERROR, 5 BAD_SCANOUT_LOCK,
    //                               6 BAD_GUEST_OFFER (rtl/memory/vunit_memory_arbiter.sv:110)
    //   A  7..0  vunit_fault[7:0]   the V-unit board's own fault code
    // All dim on row A = neither the memory arbiter nor the V-unit faulted.
    wire [15:0] video_fault_a = {memory_fault, vunit_fault};

    // DIAG D: a SAMPLED copy of the C31 program counter, refreshed about three times a second
    // (2^24 clocks at 50 MHz). A screenshot is capped at one per second, so a live PC would be an
    // unreadable blur; holding one sample makes each screenshot a clean point, and successive
    // screenshots scatter across whatever loop the CPU is in. That is how a screen that is BLACK
    // but still RUNNING (frames and instructions advancing, no fault) gets diagnosed: the PC says
    // what it is waiting on. One LSB = 256 C31 words.
    reg [15:0] pc_sample;
    reg [23:0] pc_div;
    always @(posedge clk) begin
        if (por) begin pc_sample <= 16'd0; pc_div <= 24'd0; end
        else begin
            pc_div <= pc_div + 24'd1;
            if (pc_div == 24'd0) pc_sample <= cpu_pc[23:8];
        end
    end

    wire [31:0] cmos_seed_words, cmos_seed_dropped;
    wire        cmos_seed_ok;
    assign cmos_seed_words_o   = cmos_seed_words;
    assign cmos_seed_dropped_o = cmos_seed_dropped;
    assign cmos_seed_ok_o      = cmos_seed_ok;
    wire [23:0] boot_pc;

    // r24 family core: the game id is MRA <rom index="4"><part>NN</part></rom>, sent first (first halfword, low byte). No
    // index 4 = 0 = Cruis'n USA (the shipped USA MRA stays valid). Power-on domain, like both ROM captures (P0022).
    always @(posedge clk)
        if (por) game <= 2'd0;
        else if (ioctl_download && ioctl_wr && ioctl_index[7:0] == 8'd4 && ioctl_addr == 27'd0) game <= ioctl_dout[1:0];

    gm1_loader u_loader (
        .clk(clk), .por(por), .core_reset(core_reset),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index), .ioctl_dout(ioctl_dout),
        .ioctl_wait(md_wait),
        .l_req(l_req), .l_baddr(l_baddr), .l_wdata(l_wdata), .l_ack(l_ack),
        .done(loader_done), .boot_pc(boot_pc), .words_loaded(md_words), .stream_crc(md_crc),
        .dropped_halfwords(md_dropped), .stream_seen(md_seen), .stream_closed(md_closed), .size_ok(md_size_ok),
        .reset_during_download(),
        .seed_words(cmos_seed_words), .seed_dropped(cmos_seed_dropped), .seed_complete(cmos_seed_ok)
    );

    wire        sd_req, sd_we, sd_burst, sd_ack, sd_map_fault;
    wire [23:0] sd_addr;
    wire [31:0] sd_wdata, sd_rdata;

    // r23 NVRAM: BRAM copy of CMOS for the save upload (gm1_cmos_shadow.sv). Every CMOS write is mirrored: loader
    // writes to SDRAM byte 0x1100000-0x1107fff (seed, saved-NVRAM stream, all-ones fill) and C31 writes to word
    // 0x9c0000-0x9c1fff (gm1_sdram map_word), each counted once at its ack.
    wire [12:0] cmos_alt_addr; wire [31:0] cmos_alt_q;   // r24: Cruis'n World bit_data_r reads CMOS via the shadow
    gm1_cmos_shadow u_cmos_shadow (.clk(clk), .reset(por),
        .l_req(l_req), .l_ack(l_ack), .l_baddr(l_baddr), .l_wdata(l_wdata),
        .sd_req(sd_req), .sd_we(sd_we), .sd_ack(sd_ack), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .ioctl_upload(ioctl_upload && ioctl_index[7:0] == 8'd3), .ioctl_addr(ioctl_addr), .ioctl_din(ioctl_din),
        .save_trigger(nvram_save), .upload_req(nvram_upload_req), .dirty(nvram_dirty),
        .alt_rd_addr(cmos_alt_addr), .alt_rd_q(cmos_alt_q));
    gm1_sdram u_sdram (
        .clk(clk), .por(por), .loader_owns(!loader_done),
        .l_req(l_req), .l_baddr(l_baddr), .l_wdata(l_wdata), .l_ack(l_ack),
        .sd_req(sd_req), .sd_we(sd_we), .sd_burst(sd_burst), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sd_ack), .sd_rdata(sd_rdata), .map_fault(sd_map_fault),
        .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA), .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH),
        .SDRAM_nCS(SDRAM_nCS), .SDRAM_nCAS(SDRAM_nCAS), .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE)
    );

    // ================= game reset and configuration =================
    reg  game_reset, initializing;
    wire engine_configured;
    wire all_configured = engine_configured;   // r12: gm1_fb_present needs no configuration handshake
    always @(posedge clk) begin
        if (por) begin
            game_reset <= 1'b1; initializing <= 1'b1;
        end else begin
            game_reset <= !(loader_done && dcs_rom_loaded);
            if (game_reset) initializing <= 1'b1;
            else if (all_configured) initializing <= 1'b0;
        end
    end
    wire config_valid = initializing && !game_reset;
    wire config_safe  = initializing;
    assign game_running = !game_reset && !initializing;

    // ================= DDR mux + adapter =================
    localparam integer CLIENTS = 4;
    localparam integer ENGINE = 0, CAPTURE = 1, SCAN = 2, DCS = 3;
    wire [CLIENTS-1:0]    cr, cw, cv, ce, cwait;
    wire [CLIENTS*32-1:0] ca;
    wire [CLIENTS*64-1:0] cd, rd;
    wire [CLIENTS*8-1:0]  cb;
    wire [CLIENTS*4-1:0]  cc;
    wire        ar, aw, awaitrequest, avalid, aerror;
    wire [31:0] aa;
    wire [63:0] ad, ard;
    wire [7:0]  ab;
    wire [3:0]  ac;
    wire [2:0]  mux_fault, adapter_fault;
    wire [9:0]  mux_info;

    avalon_shared_mux #(.CLIENTS(CLIENTS)) shared_mux (
        .clk(clk), .cold_reset(por), .quiesce_request(1'b0), .quiesced(),
        .client_read(cr), .client_write(cw), .client_urgent(4'b1100),
        .client_address(ca), .client_writedata(cd), .client_byteenable(cb), .client_burstcount(cc),
        .client_waitrequest(cwait), .client_readdatavalid(cv), .client_read_error(ce), .client_readdata(rd),
        .avm_read(ar), .avm_write(aw), .avm_address(aa), .avm_writedata(ad), .avm_byteenable(ab), .avm_burstcount(ac),
        .avm_waitrequest(awaitrequest), .avm_readdatavalid(avalid), .avm_readdata(ard), .avm_read_error(aerror),
        .fault_code(mux_fault), .fault_info(mux_info));
    mister_ddram_adapter ddram_adapter (
        .clk(clk), .reset(por), .quiesce_request(1'b0), .backend_quiesced(),
        .avm_read(ar), .avm_write(aw), .avm_address(aa), .avm_writedata(ad), .avm_byteenable(ab), .avm_burstcount(ac),
        .avm_waitrequest(awaitrequest), .avm_readdatavalid(avalid), .avm_readdata(ard), .avm_read_error(aerror),
        .DDRAM_BUSY(DDRAM_BUSY), .DDRAM_DOUT_READY(DDRAM_DOUT_READY), .DDRAM_DOUT(DDRAM_DOUT),
        .DDRAM_ADDR(DDRAM_ADDR), .DDRAM_BURSTCNT(DDRAM_BURSTCNT), .DDRAM_DIN(DDRAM_DIN), .DDRAM_BE(DDRAM_BE),
        .DDRAM_RD(DDRAM_RD), .DDRAM_WE(DDRAM_WE), .fault_code(adapter_fault));

    // ================= engine =================
    wire        dcs_latch_we, dcs_run;
    wire [7:0]  dcs_latch_data;
    wire [63:0] guest_tick;
    wire        engine_halted, ext_unmapped_seen, int0_seen, game_display_page;
    wire [7:0]  memory_fault, vunit_fault, cpu_fault;
    wire [2:0]  scanout_fault = 3'd0;      // r12: the native scanout is gone; the status field is kept for the decoder
    wire [14:0] present_pal_addr;
    wire [15:0] present_pal_word;
    wire [79:0] irq_diag;                  // r10 status page 2 (gm1_board.sv)
    wire [95:0] render_diag;               // r11 status page 3 (gm1_board.sv)
    wire [255:0] perf_diag;                // 2026-09-23 race-speed counters (gm1_board.sv, status mirror words 11..14)
    wire         rumble_pos_we, rumble_mode_we;   // r21 rumble snoops
    wire         wheel_board_we;                  // r23 FFB: C31 write to 0x995000
    wire  [7:0]  wheel_motor; wire wheel_motor_we;
    wire [31:0]  rumble_data;

    wire protect_page, protected_page;
    gm1_engine engine (
        .clk(clk), .reset(game_reset), .guest_run_enable(game_running), .boot_pc(boot_pc),
        .sd_req(sd_req), .sd_we(sd_we), .sd_burst(sd_burst), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sd_ack), .sd_rdata(sd_rdata),
        .cabinet_in0(cabinet_in0), .cabinet_in1(cabinet_in1), .cabinet_switch2(cabinet_switch2),
        .cabinet_dips(cabinet_dips), .adc_channels(adc_channels),
        .dcs_latch_we(dcs_latch_we), .dcs_latch_data(dcs_latch_data), .dcs_run(dcs_run),
        .config_valid(config_valid), .config_ready(),
        .config_fb_base(REGION_BASE + 32'h00100000), .config_texture_base(REGION_BASE + 32'h00200000),
        .config_palette_base(REGION_BASE + 32'h00600000),
        .backend_quiesced(config_safe), .backend_reset_request(), .memory_configured(engine_configured),
        .avm_read(cr[ENGINE]), .avm_write(cw[ENGINE]), .avm_address(ca[ENGINE*32+:32]), .avm_writedata(cd[ENGINE*64+:64]),
        .avm_byteenable(cb[ENGINE*8+:8]), .avm_burstcount(cc[ENGINE*4+:4]),
        .avm_waitrequest(cwait[ENGINE]), .avm_readdatavalid(cv[ENGINE]), .avm_readdata(rd[ENGINE*64+:64]),
        .avm_read_error(ce[ENGINE]),
        .protect_page(protect_page), .protected_page(protected_page),
        .present_pal_addr(present_pal_addr), .present_pal_word(present_pal_word), .native_frames(presented_frames),
        .halted(engine_halted), .memory_fault(memory_fault), .memory_fault_address(),
        .vunit_fault(vunit_fault), .cpu_fault(cpu_fault), .cpu_pc(cpu_pc), .instructions(instructions),
        .guest_tick(guest_tick), .ext_unmapped_seen(ext_unmapped_seen), .int0_seen(int0_seen),
        .display_page(game_display_page), .irq_diag(irq_diag), .render_diag(render_diag), .perf_diag(perf_diag),
        .rumble_pos_we(rumble_pos_we), .rumble_mode_we(rumble_mode_we), .wheel_board_we(wheel_board_we), .rumble_data(rumble_data),
        .game(game), .mister_rtc(mister_rtc), .cmos_alt_addr(cmos_alt_addr), .cmos_alt_q(cmos_alt_q)
    );

    // ================= presentation (physical video) =================
    wire        pres_ce, pres_de, pres_hs, pres_vs;
    wire [7:0]  pres_r, pres_g, pres_b;
    wire [7:0]  presentation_fault;
    wire        presentation_halted = presentation_fault != 8'd0;
    // r12: the displayed V-unit page straight from DDR3 on real time (gm1_fb_present header). It replaces
    // vunit_scanout + vunit_presentation (capture into an RGB32 surface) + vunit_surface_scanout. The CAPTURE mux client
    // is idle; SCAN (urgent) now carries 16-bit framebuffer line bursts.
    gm1_fb_present #(.WIDTH(WIDTH), .HEIGHT(HEIGHT), .H_TOTAL(H_TOTAL), .V_TOTAL(V_TOTAL),
        .H_SYNC_START(H_SYNC_START), .H_SYNC_END(H_SYNC_END), .V_SYNC_START(V_SYNC_START), .V_SYNC_END(V_SYNC_END),
        .PIXEL_DIVIDER(PIXEL_DIVIDER), .BURST_BEATS(8)) presentation (
        .clk(clk), .reset(game_reset), .enable(game_running),
        .fb_base(REGION_BASE + 32'h00100000), .display_page(game_display_page),
        .protect_page(protect_page), .protected_page(protected_page),
        .pal_addr(present_pal_addr), .pal_word(present_pal_word),
        .scan_read(cr[SCAN]), .scan_address(ca[SCAN*32+:32]), .scan_byteenable(cb[SCAN*8+:8]), .scan_burstcount(cc[SCAN*4+:4]),
        .scan_waitrequest(cwait[SCAN]), .scan_readdatavalid(cv[SCAN]), .scan_readdata(rd[SCAN*64+:64]), .scan_read_error(ce[SCAN]),
        .video_ce(pres_ce), .video_de(pres_de), .video_hsync(pres_hs), .video_vsync(pres_vs),
        .video_r(pres_r), .video_g(pres_g), .video_b(pres_b),
        .underrun_pixels(), .physical_frames(), .scan_fault(presentation_fault));
    // 2026-09-22 ladder rung 3: the CAPTURE client now carries gm1_status_mirror (instantiated below, after the DDR3
    // wait counters it publishes): write-only, single beat, non-urgent (client_urgent bit 1 = 0).
    assign cr[CAPTURE] = 1'b0;
    assign cw[SCAN] = 1'b0; assign cd[SCAN*64+:64] = 64'd0;

    // ================= DCS sound board =================
    reg  [10:0] dac_div;
    wire        dac_ce = (dac_div == 11'd0);
    always @(posedge clk) begin
        if (por) dac_div <= 11'd0;
        else dac_div <= (dac_div == DAC_PERIOD[10:0] - 11'd1) ? 11'd0 : dac_div + 11'd1;
    end
    wire        dcs_wait, dcs_unimpl;
    wire [31:0] dcs_bytes, dcs_crc, dcs_dropped, dcs_misses, dcs_underruns, dcs_host_waits, dcs_host_overflow;
    cusa_dcs_subsystem #(.DCS_DDR_BASE(DCS_DDR_BASE)) dcs (
        .clk(clk), .por(por), .core_reset(game_reset), .dac_ce_31250(dac_ce),
        .dcs_latch_we(dcs_latch_we), .dcs_latch_data(dcs_latch_data), .dcs_run(dcs_run),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index), .ioctl_dout(ioctl_dout),
        .ioctl_wait(dcs_wait),
        .client_read(cr[DCS]), .client_write(cw[DCS]), .client_address(ca[DCS*32+:32]), .client_writedata(cd[DCS*64+:64]),
        .client_byteenable(cb[DCS*8+:8]), .client_burstcount(cc[DCS*4+:4]), .client_waitrequest(cwait[DCS]),
        .client_readdatavalid(cv[DCS]), .client_readdata(rd[DCS*64+:64]), .client_read_error(ce[DCS]),
        .audio(audio), .audio_ce(audio_ce),
        .rom_loaded(dcs_rom_loaded), .bytes_loaded(dcs_bytes), .stream_crc(dcs_crc), .dropped_bytes(dcs_dropped),
        .ddr_misses(dcs_misses), .dac_underruns(dcs_underruns), .host_waits(dcs_host_waits),
        .host_overflow(dcs_host_overflow), .reset_during_download(),
        .dbg_adsp_pc(), .dbg_adsp_valid(), .dbg_adsp_unimpl(dcs_unimpl));
    assign ioctl_wait = md_wait || dcs_wait;

    // DIAG E: the rest of bar 12, plus the two sticky flags that gate bar 11. Reading left to
    // right (column 0 = bit 15):
    //   15 engine_halted        14 presentation_halted   13 ext_unmapped_seen   12 unimpl_seen
    //   11..9 scanout_fault[2:0]                         8..1 presentation_fault[7:0]
    //   0  sd_map_fault
    // engine_halted is the one that stops the guest, which is why a halt freezes instructions,
    // frames AND the DIAG D program counter all at once.

    // ================= status =================
    reg        dcs_run_seen, unimpl_seen, mux_fault_seen;
    reg [63:0] heartbeat;
    reg [15:0] peak, peak_hold;
    reg [13:0] win;
    wire [15:0] mag = audio[15] ? ((audio == 16'sh8000) ? 16'h7fff : (~audio + 16'd1)) : audio;
    always @(posedge clk) begin
        if (por) begin
            dcs_run_seen <= 1'b0; unimpl_seen <= 1'b0; mux_fault_seen <= 1'b0; heartbeat <= 64'd0;
            peak <= 16'd0; peak_hold <= 16'd0; win <= 14'd0;
        end else begin
            heartbeat <= heartbeat + 64'd1;
            if (dcs_run) dcs_run_seen <= 1'b1;
            if (dcs_unimpl) unimpl_seen <= 1'b1;
            if (mux_fault != 3'd0 || adapter_fault != 3'd0) mux_fault_seen <= 1'b1;
            if (audio_ce) begin
                win <= win + 14'd1;
                if (win == 14'd0) begin peak_hold <= peak; peak <= mag; end
                else if (mag > peak) peak <= mag;
            end
        end
    end
    wire running    = instructions != 64'd0;
    wire first_frame = presented_frames != 32'd0;
    wire cpu_ok     = cpu_fault == 8'd0 && !ext_unmapped_seen;
    wire video_ok   = !engine_halted && memory_fault == 8'd0 && scanout_fault == 3'd0 && vunit_fault == 8'd0 &&
                      !presentation_halted;
    wire dcs_ok     = dcs_rom_loaded && dcs_crc == DCS_EXPECTED_CRC && dcs_dropped == 32'd0;
    wire [15:0] done_mask = {2'b00,
        /*13*/ 1'b1, /*12*/ all_configured, /*11*/ running, /*10*/ dcs_run_seen, /* 9*/ first_frame,
        /* 8*/ int0_seen, /* 7*/ running, /* 6*/ all_configured, /* 5*/ dcs_rom_loaded, /* 4*/ loader_done,
        /* 3*/ md_closed, /* 2*/ md_closed, /* 1*/ md_seen, 1'b0};
    wire [15:0] pass_mask = {2'b00,
        /*13*/ !mux_fault_seen, /*12*/ video_ok, /*11*/ cpu_ok && !unimpl_seen, /*10*/ dcs_run_seen,
        /* 9*/ first_frame, /* 8*/ int0_seen, /* 7*/ running, /* 6*/ all_configured, /* 5*/ dcs_ok,
        /* 4*/ loader_done && !sd_map_fault, /* 3*/ md_dropped == 32'd0,
        /* 2*/ md_size_ok && ((md_crc ^ 32'hffffffff) == MD_EXPECTED_CRC), /* 1*/ md_seen, 1'b0};
    reg [7:0] cur_test;
    integer k;
    always @* begin
        cur_test = 8'd0;
        for (k = 13; k >= 1; k = k - 1)
            if (!done_mask[k]) cur_test = k[7:0];
    end
    wire [7:0] meter_mb = (peak_hold >= 16'd8192) ? 8'd128 : (peak_hold >= 16'd2048) ? 8'd64 :
                          (peak_hold >= 16'd256) ? 8'd32 : 8'd0;
    wire [15:0] video_fault_e = {engine_halted, presentation_halted, ext_unmapped_seen, unimpl_seen,
                                 scanout_fault, presentation_fault, sd_map_fault};
    // gm1_hdmi_status adds three 16-bit diagnostic rows to the bw1 screen: the DDR fault
    // forensics (decoded above), presented_frames and instructions (so speed and liveness are
    // readable from a screenshot -- the cabinet has no other instrument, MiSTer grabs every
    // input device exclusively so nothing on the ARM side can observe the core).
    // r10 STATUS PAGE 2 (OSD "Status page: Interrupts"), same row positions, decoded by
    // scripts/read_gm1_diag.py --rev r10 --page irq:
    //   A  INT0 pulses raised by the V-unit raster [15:0]
    //   D  INT0 entries taken (C31 vector reads at 0x000001) [15:0]  -- A and D advance together when no pulse is lost
    //   B  INT3 pulses raised minus INT3 entries taken [15:0]         -- steady when no ADC interrupt is lost
    //   C  {Test button seen, OSD Send ENTER seen, GIE, IE0, IE3, IF0, IF3, 0, SWITCH1 reads with TEST low [7:0]}
    //   E  the first SWITCH1 (0x991060) value read with TEST low      -- what the game saw when it entered diagnostics
    wire [15:0] p2_c = {test_src_seen, irq_diag[29:16]};
    // r11 STATUS PAGE 3, render budget (OSD "Status page: Render"; read_gm1_diag.py --rev r11 --page render). Every row
    // is a clock count in 65,536-clock units (1.31 ms at 50 MHz), wrapping after 85.9 s: difference two screenshots taken
    // less than a minute apart and divide by 50 MHz x the interval for a share of wall time.
    //   A  CPU enabled (core_ce)                 D  CPU held by the renderer (guest ticks stopped)
    //   B  ... of which polygon setup active     C  ... of which a texel wait (DDR3)      E  ... of which a framebuffer write wait (DDR3)
    // r11 STATUS PAGE 4, DDR3 port (OSD "Status page: DDR3"; --page ddr3), same units:
    //   A  ENGINE client waiting (texels, framebuffer, palette, CPU video RAM)
    //   D  SCAN client waiting (HDMI surface reads, urgent)     B  CAPTURE client waiting (presentation surface writes)
    //   C  CPU held on V-unit / board I/O memory access         E  DDRAM_BUSY from the HPS side
    reg [31:0] q_engine, q_scan, q_capture, q_busy;
    always @(posedge clk) begin
        if (por) begin q_engine <= 32'd0; q_scan <= 32'd0; q_capture <= 32'd0; q_busy <= 32'd0; end
        else begin
            if ((cr[ENGINE]  || cw[ENGINE])  && cwait[ENGINE])  q_engine  <= q_engine  + 32'd1;
            if ((cr[SCAN]    || cw[SCAN])    && cwait[SCAN])    q_scan    <= q_scan    + 32'd1;
            if ((cr[CAPTURE] || cw[CAPTURE]) && cwait[CAPTURE]) q_capture <= q_capture + 32'd1;
            if (DDRAM_BUSY) q_busy <= q_busy + 32'd1;
        end
    end
    // 2026-09-22 ladder rung 3: every status-page counter, published to DDR3 0x38700000 (REGION_BASE + 0x700000, the old
    // capture surface) every 40 ms as a 12-word seqlock block, so the ARM side can log while the user plays
    // (bandwidth/gm1/ladder/diag_mirror/: unit gate check_status_mirror.py, MiSTer logger gm1_perflog.sh).
    // 2026-09-25 r28 area relief: the full block is DIAGNOSTIC-only (QSF macro GM1_DIAG_MIRROR, added to a snapshot
    // by quartus/prepare.sh --diag; sim: run_gm1_sim.py --diag-mirror). A release build publishes only the wheel
    // mailbox the shipping gm1_ffb daemon reads (gm1_wheel_mailbox.sv: same address, words and seq behaviour, gate
    // ladder/diag_mirror/check_wheel_mailbox.py); the counters above then have no consumer and synthesis drops them.
`ifdef GM1_DIAG_MIRROR
    gm1_status_mirror #(.BASE(REGION_BASE + 32'h00700000)) status_mirror (
        .clk(clk), .por(por), .enable(all_configured),
        .instructions(instructions), .presented_frames(presented_frames), .pc_sample(pc_sample),
        .video_fault_a(video_fault_a), .video_fault_e(video_fault_e), .irq_diag(irq_diag), .render_diag(render_diag),
        .perf_diag(perf_diag), .dcs_underruns(dcs_underruns), .dcs_misses(dcs_misses),
        .dcs_host_waits(dcs_host_waits), .dcs_host_overflow(dcs_host_overflow), .q_engine(q_engine), .q_scan(q_scan), .q_capture(q_capture), .q_busy(q_busy),
        .wheel_motor_we(wheel_motor_we), .wheel_motor(wheel_motor),
        .write(cw[CAPTURE]), .address(ca[CAPTURE*32+:32]), .writedata(cd[CAPTURE*64+:64]),
        .byteenable(cb[CAPTURE*8+:8]), .burstcount(cc[CAPTURE*4+:4]), .waitrequest(cwait[CAPTURE]));
`else
    gm1_wheel_mailbox #(.BASE(REGION_BASE + 32'h00700000)) status_mirror (
        .clk(clk), .por(por), .enable(all_configured),
        .wheel_motor_we(wheel_motor_we), .wheel_motor(wheel_motor),
        .write(cw[CAPTURE]), .address(ca[CAPTURE*32+:32]), .writedata(cd[CAPTURE*64+:64]),
        .byteenable(cb[CAPTURE*8+:8]), .burstcount(cc[CAPTURE*4+:4]), .waitrequest(cwait[CAPTURE]));
`endif
    // 2026-09-23 r18 (user: "Remove the visual counters and also the menus on the OSD but keep the loggers"): the
    // gm1_hdmi_status screen and its diagnostic rows are gone; HDMI is the game presentation from power-on (its raster is
    // free-running real time). The DDR3 status mirror above carries every counter to the ARM logger.
    reg use_game_video;    // "first game frame presented" (kept for the sim bench tap)
    always @(posedge clk) begin
        if (por) use_game_video <= 1'b0;
        else use_game_video <= first_frame;
    end
    // 2026-09-23 r22: smart de-dither of the 50% black mesh panels (gm1_dedither.sv, gate
    // bandwidth/gm1/dither/check_dedither.py). Output = presentation stream delayed two ce; RAW = pixel-exact.
    assign vga_ce = pres_ce;
    gm1_dedither u_dedither (.clk(clk), .ce(pres_ce), .mode(dither_mode),
        .de_i(pres_de), .hs_i(pres_hs), .vs_i(pres_vs), .r_i(pres_r), .g_i(pres_g), .b_i(pres_b),
        .de_o(vga_de), .hs_o(vga_hs), .vs_o(vga_vs), .r_o(vga_r), .g_o(vga_g), .b_o(vga_b));
    assign fault  = mux_fault_seen || !cpu_ok || !video_ok || unimpl_seen || sd_map_fault;

    // 2026-09-23 r21: gamepad rumble from the game's own force-feedback intent (gm1_rumble.sv, gate
    // bandwidth/gm1/rumble/check_rumble.py). 60 Hz real-time tick (833,333 clocks at 50 MHz).
    reg [19:0] rumble_div;
    always @(posedge clk) rumble_div <= (por || rumble_div == 20'd833332) ? 20'd0 : rumble_div + 20'd1;
    // r23 FFB wheels: the wheel board motor latch (MAME wheel_board_w), published to the ARM through the status mirror
    gm1_wheel_motor u_wheel_motor (.clk(clk), .reset(game_reset), .we_in(wheel_board_we), .data_in(rumble_data),
        .motor(wheel_motor), .motor_we(wheel_motor_we));
    gm1_rumble u_rumble (.clk(clk), .reset(game_reset), .tick(rumble_div == 20'd0), .intensity(rumble_intensity),
        .pos_we_in(rumble_pos_we && game == 2'd0), .pos_data_in(rumble_data), .mode_we_in(rumble_mode_we && game == 2'd0), .mode_data_in(rumble_data[3:0]),
        .snd_we_in(dcs_latch_we), .snd_byte_in(dcs_latch_data), .gas_in(adc_channels[15:8]),
        // r26: World / Off Road rumble from the engine command 55 E0 a b + the wheel-motor torque (rumble_golden.py)
        .family(game != 2'd0), .tq_we_in(wheel_motor_we && game != 2'd0), .tq_in(wheel_motor), .wheel_in(adc_channels[7:0]),
        .rumble(rumble));
endmodule
`default_nettype wire
