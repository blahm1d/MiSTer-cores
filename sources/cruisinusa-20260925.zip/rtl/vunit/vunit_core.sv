// SPDX-License-Identifier: BSD-3-Clause
// Behavioral evidence and license: README.md / LICENSE in this directory.
// This is a single-clock, guest_ce-stepped functional prototype, NOT ASIC timing.
module vunit_core #(
    parameter integer QUEUE_DEPTH = 270,
    parameter integer WIDTH = 512,
    parameter integer HEIGHT = 400,
    parameter integer PRIVATE_TEXTURE_SERVICE = 0,
    // REGISTER_VIEW: 0 = shipped physical-status reads (entry counter, queue
    // nonempty/busy/full bits) and dequeue-time page/dither; 1 = the values
    // MAME's handlers return (midvunit_v.cpp:381-428) plus per-record page/dither
    // latched at commit. Default 0 reproduces shipped behaviour bit-for-bit.
    parameter integer REGISTER_VIEW = 0
) (
    input  wire         clk,
    input  wire         reset,
    input  wire         guest_ce,
    input  wire         bus_ce,
    input  wire         req_valid,
    output reg          req_ready,
    input  wire         req_write,
    input  wire [23:0]   req_addr,
    input  wire [31:0]   req_wdata,
    output reg  [31:0]   req_rdata,
    output wire         fb_valid,
    input  wire         fb_ready,
    output wire [18:0]   fb_addr,
    output wire [15:0]   fb_data,
    output wire         fb_pair,
    output wire [15:0]   fb_data_hi,
    output wire         tex_req_valid,
    input  wire         tex_req_ready,
    output wire [21:0]   tex_req_addr,
    output wire         tex_req_prefetch,
    input  wire         tex_rsp_valid,
    output wire         tex_rsp_ready,
    input  wire [7:0]    tex_rsp_data,
    output wire         tex_req_pair,
    output wire [2:0]    tex_req_off2,
    input  wire [7:0]    tex_rsp_data2,
    output wire [3:0]    tex_req_tag,
    input  wire [3:0]    tex_rsp_tag,
    output wire         display_page,
    output wire         write_page,
    output wire         queue_nonempty,
    output wire         renderer_busy,
    output wire         queue_full,
    output wire         guest_memory_wait,
    output wire         guest_calculation_wait,
    output wire         guest_fb_offer,
    output wire         guest_tex_offer,
    output reg  [7:0]    fault_sticky,
    // Saturating counts of behaviour MAME tolerates that we used to fault on. Non-zero is NOT an
    // error; it is how often the lenient path was taken. Leave unconnected where not displayed.
    output wire [7:0]    lenient_count,
    // Observation only: the renderer's wait attribution (vunit_flat_raster render_attr). Leave unconnected if unused.
    output wire [7:0]    render_attr
);
    localparam integer PTR_BITS = (QUEUE_DEPTH < 2) ? 1 : $clog2(QUEUE_DEPTH);
    reg [239:0] queue_mem [0:QUEUE_DEPTH-1];
    reg [239:0] staging;
    reg [239:0] head_words;
    reg head_valid;
    // Per-record render state latched at commit. MAME reads m_page_control at
    // process_dma_queue time (midvunit_v.cpp:352 write page = bit 2; the record's
    // own flags word bit 13 is the dither enable and is already staged); this
    // slice's renderer additionally takes dma_setup bit 7 as its dither-phase
    // select. Latching both here means a page/dither register write between commit
    // and render start cannot alter an already-queued record (REGISTER_VIEW=1).
    reg [1:0] queue_meta [0:QUEUE_DEPTH-1];  // {dither_phase=dma_setup[7], write_page=dma_setup[2]}
    reg [1:0] head_meta;
    reg [3:0] stage_words;
    // Leniency counters. These replaced fatal fault bits that fired on behaviour MAME accepts or
    // ignores (docs/AUDIT-OVERSTRICT-FAULTS-20260916.md). They saturate at 255 so a busy counter
    // cannot wrap into looking clean, and they exist so the information is not lost: a halt gives
    // one bit and stops the game, a counter says HOW OFTEN and lets the game keep running.
    //   lenient_short -- commit triggers with an incomplete staging buffer
    //   lenient_drop  -- staging writes past the end of the buffer (MAME drops them)
    //   lenient_reg   -- video-register writes whose value we do not model
    reg [7:0] lenient_short, lenient_drop, lenient_reg;
    // One 8-bit summary for the diagnostic row: saturating sum of the three.
    wire [9:0] lenient_sum = {2'b0, lenient_short} + {2'b0, lenient_drop} + {2'b0, lenient_reg};
    assign lenient_count = (lenient_sum > 10'd255) ? 8'hff : lenient_sum[7:0];
    reg [PTR_BITS-1:0] read_ptr, write_ptr;
    reg [15:0] queue_count, entry_counter, fifo_limit;
    reg [15:0] dma_setup, fifo_control;
    reg [7:0] system_control;
    wire [15:0] effective_limit = (fifo_limit == 0) ? 16'd1 :
        ((fifo_limit > QUEUE_DEPTH) ? QUEUE_DEPTH : fifo_limit);
    wire accepted = req_valid && req_ready;
    wire fifo_storage_reset = accepted && req_write &&
                             (req_addr == 24'h994000) && !req_wdata[0];
    wire counter_reset = accepted && req_write && (req_addr == 24'h980080) &&
                         fifo_control[1] && !req_wdata[1];
    wire commit_request = accepted && !req_write && (req_addr == 24'h980083);
    // MAME processes the DMA queue UNCONDITIONALLY on the trigger read: dma_trigger_r
    // (midvunit_v.cpp:388) calls process_dma_queue() and resets m_dma_data_index, with no check that
    // the staging buffer was filled and no enable gate. It also never CLEARS m_dma_data[], so a short
    // entry reuses the previous entry's upper words -- `staging` is likewise only cleared at reset,
    // so that stale-data behaviour already matches. Requiring 15 words and system_control[0] here,
    // and faulting otherwise, halted the engine on legal game behaviour (the 2026-09-16 cabinet halt:
    // vunit_fault=0x02 at 2,829 frames). See docs/AUDIT-OVERSTRICT-FAULTS-20260916.md.
    wire commit_entry = commit_request;
    wire commit_short = commit_request && (stage_words != 15);
    wire renderer_ready;
    wire [1:0] renderer_reject;
    wire start_valid = head_valid && (queue_count != 0) && fifo_control[3] &&
                       system_control[0] && !fifo_storage_reset;
    wire dequeue = start_valid && renderer_ready;

    assign queue_nonempty = queue_count != 0;
    assign queue_full = queue_count >= effective_limit;
    assign display_page = dma_setup[0];
    assign write_page = dma_setup[2];

    always @* begin
        req_ready = bus_ce && !reset;
        req_rdata = 0;
        if (!req_write) begin
            if (REGISTER_VIEW != 0) begin
                // MAME handler values (midvunit_v.cpp:381-428, midvunit.cpp:673-685):
                //   0x980000 dma_queue_entries_r -> always 0
                //   0x980082,0x980083 dma_trigger_r -> always 0 (0x980083 still
                //     commits as a side effect below; its return is discarded)
                //   0x980040 page_control_r -> the page-control word as written
                //   0x980041 (unmapped), 0x980080 (noprw), 0x994000 (write-only)
                //     -> open-bus 0
                // The physical entry counter and the queue nonempty/busy/full bits
                // are NEVER exposed to the CPU in this view.
                case (req_addr)
                    24'h980040: req_rdata = {16'b0,dma_setup};
                    default:    req_rdata = 32'b0;
                endcase
            end else begin
                case (req_addr)
                    24'h980000: req_rdata = {16'b0,entry_counter};
                    24'h980040: req_rdata = {16'b0,dma_setup};
                    24'h980041: req_rdata = {16'b0,fifo_limit};
                    24'h980080: req_rdata = {16'b0,fifo_control};
                    24'h994000: req_rdata = {24'b0,system_control};
                    24'h980082,24'h980083:
                        req_rdata = {28'b0,dequeue,queue_full,renderer_busy,queue_nonempty};
                    default: req_rdata = 0;
                endcase
            end
            // Full physical queue at a commit read: the only CPU-visible effect is
            // a stall (req_ready low), never a status value. Same barrier in both
            // views; hybrid_vunit_top treats this as a settled guest boundary so
            // the renderer can dequeue and free a slot.
            // Now that every trigger commits, the full-queue stall must cover every trigger too,
            // not just the 15-word ones -- otherwise a short commit could overrun the queue.
            if ((req_addr == 24'h980083) && queue_full)
                req_ready = 0;
        end
    end

    vunit_flat_raster #(.WIDTH(WIDTH), .HEIGHT(HEIGHT),
        .PRIVATE_TEXTURE_SERVICE(PRIVATE_TEXTURE_SERVICE)) renderer (
        .clk(clk), .reset(reset), .guest_ce(guest_ce),
        .start_valid(start_valid), .start_ready(renderer_ready),
        .start_words(head_words),
        // REGISTER_VIEW=1: draw with the page/dither committed with this record,
        // not the live register (which the CPU may have rewritten since). =0: the
        // shipped dequeue-time snapshot of the live register.
        .start_page((REGISTER_VIEW != 0) ? head_meta[0] : dma_setup[2]),
        .start_dither_phase((REGISTER_VIEW != 0) ? head_meta[1] : dma_setup[7]),
        .busy(renderer_busy),
        .reject_pulse(renderer_reject),
        .fb_valid(fb_valid), .fb_ready(fb_ready), .fb_addr(fb_addr), .fb_data(fb_data), .fb_pair(fb_pair), .fb_data_hi(fb_data_hi),
        .tex_req_valid(tex_req_valid), .tex_req_ready(tex_req_ready), .tex_req_addr(tex_req_addr), .tex_req_prefetch(tex_req_prefetch),
        .tex_rsp_valid(tex_rsp_valid), .tex_rsp_ready(tex_rsp_ready), .tex_rsp_data(tex_rsp_data),
        .tex_req_pair(tex_req_pair), .tex_req_off2(tex_req_off2), .tex_rsp_data2(tex_rsp_data2),
        .tex_req_tag(tex_req_tag), .tex_rsp_tag(tex_rsp_tag),
        .guest_memory_wait(guest_memory_wait),
        .guest_calculation_wait(guest_calculation_wait),
        .guest_fb_offer(guest_fb_offer),.guest_tex_offer(guest_tex_offer),
        .render_attr(render_attr)
    );

    always @(posedge clk) begin
        if (reset) begin
            staging <= 0; stage_words <= 0;
            head_valid <= 0; head_words <= 0; head_meta <= 0;
            read_ptr <= 0; write_ptr <= 0; queue_count <= 0; entry_counter <= 0;
            fifo_limit <= 270; dma_setup <= 0; fifo_control <= 0;
            system_control <= 8'hff; fault_sticky <= 0;
            lenient_short <= 0; lenient_drop <= 0; lenient_reg <= 0;
        end else if (guest_ce || bus_ce) begin
            if (guest_ce && renderer_reject[0]) fault_sticky[2] <= 1;
            if (guest_ce && renderer_reject[1]) fault_sticky[3] <= 1;
            // Synchronous RAM read enables block-RAM inference. A prefetched head
            // remains part of the queue until the renderer accepts it.
            if (guest_ce && !head_valid && (queue_count != 0)) begin
                head_words <= queue_mem[read_ptr];
                head_meta <= queue_meta[read_ptr];
                head_valid <= 1;
            end
            if (accepted && req_write) begin
                case (req_addr)
                    24'h600000: begin
                        // dma_queue_w (midvunit_v.cpp:372): `if (m_dma_data_index < 16)
                        // m_dma_data[m_dma_data_index++] = data;` -- a word past the end is SILENTLY
                        // DROPPED and there is no system_control gate. Faulting here halted the game.
                        // (Our staging is 15 words where MAME's buffer is 16; a 16th word is dropped
                        // rather than stored. The renderer reads only the low words, but that is a
                        // known small divergence -- see the audit doc.)
                        if (stage_words != 15) begin
                            staging[stage_words*16 +: 16] <= req_wdata[15:0];
                            stage_words <= stage_words + 1'b1;
                        end else if (lenient_drop != 8'hff) lenient_drop <= lenient_drop + 8'd1;
                    end
                    // page_control_w (midvunit_v.cpp:411) tracks a display-page change and STORES the
                    // value; it validates nothing. 0x980041 is not in MAME's address map at all, and
                    // 0x980080 is map(...).noprw() -- reads and writes fully ignored (midvunit.cpp:677).
                    // All three previously raised fatal faults on values the hardware simply accepts
                    // or discards. Counted now, not fatal.
                    24'h980040: begin
                        dma_setup <= req_wdata[15:0];
                        if ((req_wdata[15:0] & 16'hff7a) != 16'h0200 && lenient_reg != 8'hff)
                            lenient_reg <= lenient_reg + 8'd1;
                    end
                    24'h980041: begin
                        fifo_limit <= req_wdata[15:0];
                        if (((req_wdata[15:0] == 0) || (req_wdata[15:0] > QUEUE_DEPTH))
                            && lenient_reg != 8'hff) lenient_reg <= lenient_reg + 8'd1;
                    end
                    24'h980080: begin
                        fifo_control <= req_wdata[15:0];
                        // CRT counter-reset bit 0 is consumed by vunit_board.
                        if ((req_wdata[2] || (req_wdata[15:4] != 0)) && lenient_reg != 8'hff)
                            lenient_reg <= lenient_reg + 8'd1;
                    end
                    24'h994000: system_control <= req_wdata[7:0];
                    default: fault_sticky[6] <= 1;
                endcase
            end else if (accepted && !req_write) begin
                case (req_addr)
                    24'h980000,24'h980040,24'h980041,24'h980080,
                    24'h980082,24'h980083,24'h994000: begin end
                    default: fault_sticky[6] <= 1;
                endcase
            end
            if (commit_request) begin
                stage_words <= 0;                       // MAME: m_dma_data_index = 0 (data kept)
                if (commit_short && lenient_short != 8'hff) lenient_short <= lenient_short + 8'd1;
            end
            if (commit_entry) begin
                queue_mem[write_ptr] <= staging;
                // MAME latches m_page_control at the trigger read (this same cycle:
                // one bus access per cycle, so dma_setup holds its last-written
                // value here). Bit 2 = write page, bit 7 = dither-phase select.
                queue_meta[write_ptr] <= {dma_setup[7], dma_setup[2]};
                write_ptr <= (write_ptr == QUEUE_DEPTH-1) ? 0 : write_ptr + 1'b1;
            end
            if (dequeue) begin
                read_ptr <= (read_ptr == QUEUE_DEPTH-1) ? 0 : read_ptr + 1'b1;
                head_valid <= 0;
            end
            case ({commit_entry,dequeue})
                2'b10: queue_count <= queue_count + 1'b1;
                2'b01: queue_count <= queue_count - 1'b1;
                default: begin end
            endcase
            case ({commit_entry,dequeue})
                2'b10: entry_counter <= entry_counter + 1'b1;
                2'b01: if (entry_counter != 0) entry_counter <= entry_counter - 1'b1;
                default: begin end
            endcase
            // A counter strobe is explicitly not a FIFO storage reset.
            if (counter_reset) entry_counter <= 0;
            // FIFO pin reset discards queued/staged words, not the active draw.
            // Mid-draw effects are an unqualified prototype policy; software drains first.
            if (fifo_storage_reset) begin
                read_ptr <= 0; write_ptr <= 0; queue_count <= 0; stage_words <= 0;
                head_valid <= 0;
            end
        end
    end
endmodule
