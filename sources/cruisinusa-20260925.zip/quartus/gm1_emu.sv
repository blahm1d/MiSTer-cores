// SPDX-License-Identifier: GPL-2.0-or-later
// gm1_emu.sv -- MiSTer emu wrapper for the Cruis'n USA master core (gm1), forked from bandwidth/bw1/quartus/bw1_emu.sv
// (the cabinet-proven platform: bw1_pll 50 MHz core clock plus a -3515 ps sibling for SDRAM_CLK, P0022 power-on reset,
// hps_io ioctl WIDE=1, DDRAM and board SDRAM on the core clock) and bandwidth/dcs1/quartus/dcs1_emu.sv (DCS audio).
//
// Controls follow MAME midvunit.cpp INPUT_PORTS (midvunit, crusnusa; pinned 0.289 copy
// segamodel1/references/mame-mame0289/src/mame/williams/midvunit.cpp:737-798):
//   IN0 (active low)  coin1 0x0001, start 0x0004, test 0x0010, service 0x0040,
//                     gears 4/3/2/1 = 0x0400/0x0800/0x1000/0x2000
//   IN1 (active low)  radio 0x0002, views 1/2/3 = 0x0010/0x0020/0x0040; bits 7-15 read 0 (no motion board)
//   WHEEL  0x80 centre, 0x10-0xf0      ACCEL / BRAKE  0x00 released, 0xff pressed
//   DSW    0xf9fe (MAME defaults: master, upright, motion off, USA-8 coinage)
// Shifter: MAME's default "Buttons (sticky)" behaviour with sequential Shift Up / Shift Down buttons: the selected gear
// stays engaged; the core starts in 1st gear. Steering: left stick X. r25 pad map (user): RT Gas, LT Brake, RB/LB Shift
// Up/Down, X/Y/B View 1/2/3, A Radio, Back Coin, Start Start, d-pad up/down Volume, left Test, right Service.
`include "cusa_build_identity.svh"
module emu (
    `include "sys/emu_ports.vh"
);
    localparam CONF_STR = {
        "CruisinUSA;;",
        "-;",
        "O2,Send ENTER,Off,On;",
        "T8,Save NVRAM;",                     // r23: also saved by Main's Save settings, and automatically on OSD open after CMOS changed
        "O3,Sound filter,Arcade,Off;",
        "O67,Dither,MAME,Soft,Dark,Raw;",     // r22: translucent black mesh panels (gm1_dedither.sv); Raw = arcade framebuffer
        "O45,Rumble,High,Medium,Low,Off;",   // r21: gamepad rumble from the game's force-feedback intent (gm1_rumble.sv)   // 2026-09-23: TL084 output-stage model (gm1_tl084_lpf.sv); Off = raw DAC
        "-;",
        "J1,Gas,Brake,Shift Up,Shift Down,View 1,View 2,View 3,Radio,Coin,Start;",
        "jn,None,None,R,L,Y,X,A,B,Select,Start;",   // r25 default pad map (see the controls block)
        // Bump this on EVERY revision. It read gm1-master-r2 on r3 and r4, which cost time
        // identifying what was actually running on the cabinet (see the 2026-09-16 handoff).
        "V,gm1-master-r28"
    };
    wire clk_sys, clk_sdram_pin, pll_locked;
    wire [15:0] rumble_core;                       // r21 gm1_rumble output (clk_sys domain)
    wire [15:0] rumble_q = rumble_core;
    wire [127:0] status;
    wire [1:0]  buttons;
    wire [31:0] joystick_0;
    wire [15:0] joystick_l_analog_0, joystick_r_analog_0;
    tri [35:0] ext_bus;
    assign ext_bus[32]=1'b0;
    assign ext_bus[15:0]=16'b0;
    tri [21:0] gamma_bus;
    assign gamma_bus[21]=1'b0;

    wire        ioctl_download, ioctl_wr;
    wire [26:0] ioctl_addr;
    wire [15:0] ioctl_dout;
    wire [15:0] ioctl_index;
    wire        ioctl_wait;
    wire        ioctl_upload, nvram_upload_req, nvram_dirty;   // r23 NVRAM save (gm1_cmos_shadow.sv)
    wire [15:0] ioctl_din;

    wire [64:0] mister_rtc;                         // r24: PIC2 clock for Cruis'n World / Off Road Challenge
    hps_io #(.CONF_STR(CONF_STR), .WIDE(1)) hps_io (
        .clk_sys(clk_sys),.RTC(mister_rtc),.HPS_BUS(HPS_BUS),.EXT_BUS(ext_bus),.gamma_bus(gamma_bus),
        .joystick_0(joystick_0),.joystick_l_analog_0(joystick_l_analog_0),.joystick_r_analog_0(joystick_r_analog_0),
        .joystick_0_rumble(rumble_q),.joystick_1_rumble(16'd0),.joystick_2_rumble(16'd0),
        .joystick_3_rumble(16'd0),.joystick_4_rumble(16'd0),.joystick_5_rumble(16'd0),
        .ps2_kbd_clk_in(1'b1),.ps2_kbd_data_in(1'b1),.ps2_mouse_clk_in(1'b1),.ps2_mouse_data_in(1'b1),
        .ps2_kbd_led_status(3'd0),.ps2_kbd_led_use(3'd0),
        .sd_rd(1'b0),.sd_wr(1'b0),
        .status(status),.buttons(buttons),.status_menumask(16'b0),
        .status_in(128'b0),.status_set(1'b0),.info_req(1'b0),.info(8'b0),
        .video_rotated(1'b0),.new_vmode(1'b0),
        .ioctl_download(ioctl_download),.ioctl_index(ioctl_index),.ioctl_wr(ioctl_wr),
        .ioctl_addr(ioctl_addr),.ioctl_dout(ioctl_dout),.ioctl_wait(ioctl_wait),
        .ioctl_upload(ioctl_upload),.ioctl_upload_req(nvram_upload_req),.ioctl_upload_index(8'd3),.ioctl_din(ioctl_din)
    );

    bw1_pll pll (.refclk(CLK_50M),.rst(1'b0),.outclk_0(clk_sys),.outclk_1(clk_sdram_pin),.locked(pll_locked));

    // Power-on reset (P0022): 2-FF synced ~locked on the one core clock; both ROM capture paths and the SDRAM
    // controller use it.
    (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS" *)
    reg [2:0] por50_pipe=3'b111;
    always @(posedge clk_sys or negedge pll_locked) if(!pll_locked) por50_pipe<=3'b111; else por50_pipe<={por50_pipe[1:0],1'b0};
    wire por50 = por50_pipe[2];
    wire core_reset = RESET || status[0] || buttons[1];

    // ---- controls ----
    wire joy_right = joystick_0[0], joy_left = joystick_0[1];
    wire joy_down  = joystick_0[2], joy_up   = joystick_0[3];   // diagnostic-menu VOLUME_DOWN / VOLUME_UP
    wire b_gas = joystick_0[4], b_brake = joystick_0[5], b_up = joystick_0[6], b_down = joystick_0[7];
    wire b_v1 = joystick_0[8], b_v2 = joystick_0[9], b_v3 = joystick_0[10], b_radio = joystick_0[11];
    wire b_coin = joystick_0[12], b_start = joystick_0[13];
    // r25 (user layout): d-pad left = Test (Enter), right = Service, up / down = Volume Up / Down. Main also reports the
    // left stick as d-pad directions, so each fires only while the stick is centred on that axis.
    wire signed [7:0] sx = joystick_l_analog_0[7:0], sy = joystick_l_analog_0[15:8];
    wire x_centred = (sx > -8'sd40) && (sx < 8'sd40), y_centred = (sy > -8'sd40) && (sy < 8'sd40);
    wire b_test = joy_left && x_centred, b_service = joy_right && x_centred;
    wire b_volup = joy_up && y_centred, b_voldn = joy_down && y_centred;

    reg [1:0] gear;              // 0..3 = 1st..4th
    reg       up_q, down_q;
    always @(posedge clk_sys) begin
        if (por50) begin gear <= 2'd0; up_q <= 1'b0; down_q <= 1'b0; end
        else begin
            up_q <= b_up; down_q <= b_down;
            if (b_up && !up_q && gear != 2'd3) gear <= gear + 2'd1;
            else if (b_down && !down_q && gear != 2'd0) gear <= gear - 2'd1;
        end
    end
    // ENTER from the OSD. IN0 bit 4 is the Test switch, which is what the game calls ENTER
    // (midvunit.cpp:751, PORT_NAME("Enter") ... // Test switch). The cold-boot calibration screen
    // demands it on every power-on because CMOS does not persist, and it is the 11th entry in the
    // J1 list -- past the end of what fits on a normal pad, which is what blocked the first cabinet
    // run. Toggling the OSD item in EITHER direction emits one press, so it can never latch stuck.
    // 500 ms of wall time is ~7 guest frames at this core's quarter speed, so the game cannot miss
    // it between input polls.
    reg        osd_enter_q;
    reg [25:0] enter_hold;
    always @(posedge clk_sys) begin
        if (por50) begin osd_enter_q <= status[2]; enter_hold <= 26'd0; end
        else begin
            osd_enter_q <= status[2];
            if (status[2] != osd_enter_q)  enter_hold <= 26'd25_000_000;   // 500 ms at 50 MHz
            else if (enter_hold != 26'd0)  enter_hold <= enter_hold - 26'd1;
        end
    end
    wire osd_enter = (enter_hold != 26'd0);

    // r10: which source ever asserted IN0 bit 4 (TEST/Enter). On r7 and r9 pressing START kicked the game into its
    // diagnostics, which the original source does on a TEST edge (CUSA.ASM:975-979, 1068-1082). Sticky until the
    // core is reloaded, shown on status page 2 row C (bits 15, 14).
    reg test_btn_seen, osd_enter_seen;
    always @(posedge clk_sys) begin
        if (por50) begin test_btn_seen <= 1'b0; osd_enter_seen <= 1'b0; end
        else begin
            if (b_test)    test_btn_seen  <= 1'b1;
            if (osd_enter) osd_enter_seen <= 1'b1;
        end
    end

    // r24 family core: game id captured by gm1_core from MRA index 4 (0 = Cruis'n USA when absent)
    wire [1:0] game_id;
    wire [15:0] dips = (game_id == 2'd1) ? 16'hf9ec : (game_id == 2'd2) ? 16'hfffd : 16'hf9fe;
    reg [15:0] in0, in1;
    always @* begin
        in0 = 16'hffff;
        in0[0]  = ~b_coin;
        in0[2]  = ~b_start;
        in0[4]  = ~(b_test | osd_enter);
        in0[6]  = ~b_service;
        // IN0 bit 9 = VOLUME_UP, bit 8 = VOLUME_DOWN (midvunit.cpp:754-755). On a Midway service
        // panel that pair is what walks the game's DIAGNOSTIC MENU -- its own screen says "USE
        // UP/DOWN TO SELECT FUNCTION / ENTER TO ACTIVATE", and Enter is the Test switch on bit 4.
        // They were unmapped until 2026-09-16, so the menu could be entered (Test) but never
        // navigated, which stranded the user in it on the cabinet. The d-pad up/down are free --
        // steering uses left/right and the analog stick -- so they cost two LUTs and unlock the
        // game's own CPU BOARD TEST, SOUND BOARD TEST and MONITOR TEST as diagnostics.
        in0[9]  = ~b_volup;
        in0[8]  = ~b_voldn;
        in0[13] = ~(gear == 2'd0);
        in0[12] = ~(gear == 2'd1);
        in0[11] = ~(gear == 2'd2);
        in0[10] = ~(gear == 2'd3);
        in1 = (game_id == 2'd0) ? 16'h007f : 16'hffff;
        in1[1] = ~b_radio;
        in1[4] = ~b_v1;
        in1[5] = ~b_v2;
        in1[6] = ~b_v3;
    end

    function automatic [7:0] clamp_wheel(input signed [9:0] v);
        clamp_wheel = (v < 10'sd16) ? 8'h10 : (v > 10'sd240) ? 8'hf0 : v[7:0];
    endfunction
    // 2026-09-23: DEAD ZONE. Deflection <= 32 of 127 reads as released (MAME's IPT_PEDAL rests at 0x00): a sideways
    // steering motion always carries a little Y, and without the dead zone that leaked into ACCEL and selected the track
    // on first boot. Above the dead zone: (d - 32) * 11 / 4 (shift, no divider), clamped to 0xfe (full at d >= 125).
    function automatic [7:0] pedal(input signed [7:0] axis, input up);   // stick deflection -> 0x00..0xfe
        reg signed [8:0] d;
        reg [11:0] s;
        begin
            d = up ? -{axis[7], axis} : {axis[7], axis};
            if (d <= 9'sd32) pedal = 8'h00;
            else begin
                s = (({3'd0, d} - 12'd32) * 12'd11) >> 2;
                pedal = (s >= 12'd254) ? 8'hfe : s[7:0];
            end
        end
    endfunction
    wire signed [7:0] lx = joystick_l_analog_0[7:0];
    wire signed [7:0] ly = joystick_l_analog_0[15:8];
    wire signed [7:0] ry = joystick_r_analog_0[15:8];
    wire [7:0] wheel_analog = clamp_wheel(10'sd128 + {{2{lx[7]}}, lx});
    wire       stick_centred = (lx > -8'sd16) && (lx < 8'sd16);
    wire [7:0] wheel = wheel_analog;   // r25: d-pad left / right are Test / Service now (no d-pad full lock)
    // 2026-09-23: pedals from the Gas / Brake inputs ONLY. Stick Y used to drive ACCEL / BRAKE too (pedal(), kept below
    // unused for reference); a hard sideways steer leaked throttle and auto-selected the car / track (cabinet: the stick
    // selects, the d-pad does not), and the right stick Y is Shift Up / Down in the user's map, so shifting leaked gas.
    wire [7:0] accel = b_gas   ? 8'hff : 8'h00;
    wire [7:0] brake = b_brake ? 8'hff : 8'h00;

    assign ADC_BUS='z;
    assign USER_OUT='1;
    assign {UART_RTS,UART_TXD,UART_DTR}=0;
    assign {SD_SCK,SD_MOSI,SD_CS}='z;
    `ifdef MISTER_DUAL_SDRAM
    assign {SDRAM2_DQ,SDRAM2_A,SDRAM2_BA,SDRAM2_CLK,SDRAM2_nWE,SDRAM2_nCAS,SDRAM2_nRAS,SDRAM2_nCS}='z;
    `endif
    `ifdef MISTER_FB
    assign {FB_EN,FB_FORMAT,FB_WIDTH,FB_HEIGHT,FB_BASE,FB_STRIDE}=0;
    assign FB_FORCE_BLANK=1;
      `ifdef MISTER_FB_PALETTE
      assign {FB_PAL_CLK,FB_PAL_ADDR,FB_PAL_DOUT,FB_PAL_WR}=0;
      `endif
    `endif
    assign VIDEO_ARX=13'd4; assign VIDEO_ARY=13'd3;
    assign {VGA_SL,VGA_F1,VGA_SCALER,VGA_DISABLE}=0;
    assign {HDMI_FREEZE,HDMI_BLACKOUT,HDMI_BOB_DEINT}=0;
    assign CLK_VIDEO=clk_sys;
    assign DDRAM_CLK=clk_sys;
    assign SDRAM_CLK=clk_sdram_pin;

    wire [7:0] r,g,b; wire ce,de,hs,vs; wire fault;
    wire signed [15:0] dcs_audio; wire dcs_audio_ce;
    gm1_core core (
        .clk(clk_sys),.por(por50),.core_reset(core_reset),
        .ioctl_download(ioctl_download),.ioctl_wr(ioctl_wr),.ioctl_addr(ioctl_addr),.ioctl_dout(ioctl_dout),
        .ioctl_index(ioctl_index),.ioctl_wait(ioctl_wait),
        .ioctl_upload(ioctl_upload),.ioctl_din(ioctl_din),.nvram_save(status[8]),.nvram_upload_req(nvram_upload_req),.nvram_dirty(nvram_dirty),
        .game(game_id),.mister_rtc(mister_rtc),
        .DDRAM_BUSY(DDRAM_BUSY),.DDRAM_DOUT_READY(DDRAM_DOUT_READY),.DDRAM_DOUT(DDRAM_DOUT),
        .DDRAM_ADDR(DDRAM_ADDR),.DDRAM_BURSTCNT(DDRAM_BURSTCNT),.DDRAM_BE(DDRAM_BE),
        .DDRAM_DIN(DDRAM_DIN),.DDRAM_RD(DDRAM_RD),.DDRAM_WE(DDRAM_WE),
        .SDRAM_DQ(SDRAM_DQ),.SDRAM_A(SDRAM_A),.SDRAM_BA(SDRAM_BA),.SDRAM_DQML(SDRAM_DQML),.SDRAM_DQMH(SDRAM_DQMH),
        .SDRAM_nCS(SDRAM_nCS),.SDRAM_nCAS(SDRAM_nCAS),.SDRAM_nRAS(SDRAM_nRAS),.SDRAM_nWE(SDRAM_nWE),.SDRAM_CKE(SDRAM_CKE),
        .cabinet_in0(in0),.cabinet_in1(in1),.cabinet_switch2(16'h0008),.cabinet_dips(dips),
        .adc_channels({8'h00, brake, accel, wheel}),
        .show_status(1'b0), .status_page(2'b00), .rumble_intensity(2'd3 - status[5:4]), .dither_mode(status[7:6]), .rumble(rumble_core), .test_src_seen({test_btn_seen, osd_enter_seen}),
        .audio(dcs_audio),.audio_ce(dcs_audio_ce),
        .vga_ce(ce),.vga_de(de),.vga_hs(hs),.vga_vs(vs),.vga_r(r),.vga_g(g),.vga_b(b),.fault(fault),
        .loader_done(),.dcs_rom_loaded(),.game_running(),.instructions(),.cpu_pc(),.presented_frames());

    // 2026-09-23 r19: the board's DAC -> TL084 filter stage, modelled (gm1_tl084_lpf.sv; ASSUMED 10 kHz Butterworth until
    // the V-unit R/C values are known). Holds each 31.25 kHz sample for the framework's audio path. OSD "Sound filter:
    // Off" (status[3]) bypasses it (raw DAC samples, as before r19).
    wire signed [15:0] sample_q;
    gm1_tl084_lpf u_tl084 (.clk(clk_sys), .reset(por50), .bypass(status[3]), .in_ce(dcs_audio_ce), .in_sample(dcs_audio),
                           .out_ce(), .out_sample(sample_q));

    assign CE_PIXEL=ce; assign VGA_DE=de; assign VGA_HS=hs; assign VGA_VS=vs;
    assign VGA_R=r; assign VGA_G=g; assign VGA_B=b;
    assign AUDIO_L=sample_q; assign AUDIO_R=sample_q; assign AUDIO_MIX=0; assign AUDIO_S=1;
    assign {LED_DISK,LED_POWER,BUTTONS}=0;
    assign LED_USER=fault;
endmodule
