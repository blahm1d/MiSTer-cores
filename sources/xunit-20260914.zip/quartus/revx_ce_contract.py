"""Source-pinned /3 CPU CE contract; no synthesis or simulation is launched.

The JSON records individually reviewed non-reset CE-held assignments. Names
alone never establish eligibility: all contributing sources must match their
reviewed identities, and generated Tcl must match this renderer exactly.
"""
import hashlib
import json
import re
from pathlib import Path

MANIFEST = "quartus/revx_cpu_ce.json"
COLLECTOR = "quartus/revx_cpu_ce.tcl"
SDC = "quartus/revx.sdc"
CE_RULES = [
    "source quartus/revx_cpu_ce.tcl",
    "set revx_ce_contract [revx_ce::collect]",
    "set revx_ce_registers [dict get $revx_ce_contract ce]",
    "set_multicycle_path -setup 3 -from $revx_ce_registers -to $revx_ce_registers",
    "set_multicycle_path -hold 2 -from $revx_ce_registers -to $revx_ce_registers",
    "set revx_launch_regs [get_registers {*tms34010_mem_if:u_mif|a_q* "
    "*tms34010_mem_if:u_mif|sz_q* *tms34010_mem_if:u_mif|we_q* "
    "*tms34010_mem_if:u_mif|srt_q* "
    "*tms34010_mem_if:u_mif|f_q* "
    "*tms34010_mem_if:u_mif|p_addr0* *tms34010_mem_if:u_mif|p_addr1* "
    "*tms34010_mem_if:u_mif|p_be0* *tms34010_mem_if:u_mif|p_be1* "
    "*tms34010_mem_if:u_mif|p_wsh0* *tms34010_mem_if:u_mif|p_wsh1* "
    "*tms34010_mem_if:u_mif|p_nmask0* *tms34010_mem_if:u_mif|p_nmask1* "
    "*tms34010_mem_if:u_mif|p_rmw* *tms34010_mem_if:u_mif|p_straddle* "
    "*tms34010_io_write_boundary:u_io_write_boundary|wr_valid "
    "*tms34010_io_write_boundary:u_io_write_boundary|wr_status_guard "
    "*tms34010_core:u_cpu|io_rdata_req_valid_q *tms34010_core:u_cpu|setcdp_we_q "
    "*tms34010_core:u_cpu|setcdp_convdp_q*}]",
    "if {[get_collection_size $revx_launch_regs] == 0} { error \"REVX_SDC no launch registers\" }",
    "set_multicycle_path -setup 3 -from $revx_ce_registers -to $revx_launch_regs",
    "set_multicycle_path -hold 2 -from $revx_ce_registers -to $revx_launch_regs",
    "set revx_launch_io_read [get_registers {*tms34010_core:u_cpu|io_rdata_req_valid_q}]",
    "if {[get_collection_size $revx_launch_io_read] == 0} { error \"REVX_SDC no io-read launch register\" }",
    "set_multicycle_path -setup 3 -from $revx_launch_io_read -to $revx_ce_registers",
    "set_multicycle_path -hold 2 -from $revx_launch_io_read -to $revx_ce_registers",
]
REQUIRED_FAMILIES = {"", "tms34010_pc:u_pc", "tms34010_regfile:u_regfile",
                     "tms34010_status_reg:u_status_reg",
                     "tms34010_io_cpu_config:u_io_cpu_config",
                     "tms34010_io_cpu_status:u_io_cpu_status"}


def validate_sdc(text):
    # Deliberately require this small explicit block, rather than accepting
    # arbitrary Tcl as an equivalent hold repair. No subsequent override is
    # permitted in the RevX SDC. Chassis SDC identity is checked separately.
    active = [line.strip() for line in text.splitlines()
              if line.strip() and not line.lstrip().startswith("#")]
    if active[-len(CE_RULES):] != CE_RULES:
        raise ValueError("CPU CE setup3/hold2 collector binding or exact rule sequence changed")
    # Exactly six multicycle commands: the CE<->CE pair, the CE-core -> LAUNCH
    # destination pair (u_mif + I/O command boundaries), and the io-read launch
    # SOURCE -> CE-core pair (io_rdata_req_valid_q -> move_mem_cmd_wdata_q). No
    # other relaxation (io_regs, response/bus FSM, video, synchronizers) may appear.
    expected_mcp = [line for line in CE_RULES if "set_multicycle_path" in line]
    if [line for line in active if "set_multicycle_path" in line] != expected_mcp:
        raise ValueError("unexpected CPU SDC multicycle command or override")
    if sum("revx_cpu_ce.tcl" in line for line in active) != 1:
        raise ValueError("CPU CE collector source binding is not unique")
    if sum("revx_launch_regs" in line for line in active) != 4:
        raise ValueError("CE launch-destination binding changed")
    if sum("revx_launch_io_read" in line for line in active) != 4:
        raise ValueError("io-read launch-source binding changed")


def classify_member(contract, name):
    """Independently decode fitted names; unknown CPU atoms fail closed."""
    marker = "tms34010_core:u_cpu|"
    if name.count(marker) != 1:
        raise ValueError(f"malformed fitted CPU register: {name}")
    relative = name.split(marker, 1)[1]
    hierarchy, _, leaf = relative.rpartition("|")
    # Physical-synthesis register aliases (a duplicated, retimed or output-terminal
    # copy of a reviewed register) inherit their origin's CE classification. Strip
    # the tool-appended trailing tokens from the LEAF before splitting stem/selector,
    # repeatedly, so a composed/chained alias reduces to its origin name. The tokens
    # are ~DUPLICATE(_n) (tilde-prefixed), _OTERM<digits>/_ITERM<digits> and _NEW_REG<digits>
    # (physical-synthesis 'Retimed Register' names; 186 _NEW_REG under u_cpu in 1fc583ce fit.rpt,
    # incl. compound io_rdata_req_q[0]_NEW_REG5957_OTERM8936)
    # (underscore-prefixed). Stripping pre-split is required: on a no-selector
    # (1-bit) register the underscore token would otherwise be absorbed into the
    # greedy stem match and never removed. Confirmed forms at 1fc583ce:
    # wr_mask[6]_OTERM1481 (fit.rpt:4301, a Retimed Register that killed the STA),
    # wr_mask[6]_OTERM1481~DUPLICATE (fit.rpt:9426), and ..._OTERM<n>_OTERM<m>
    # chains. Only these tokens are stripped; every other spelling fails closed.
    base_leaf = leaf
    while True:
        stripped = re.sub(r"(?:~DUPLICATE(?:_[0-9]+)?|_OTERM[0-9]+|_ITERM[0-9]+|_NEW_REG[0-9]+)$",
                          "", base_leaf, flags=re.I)
        if stripped == base_leaf:
            break
        base_leaf = stripped
    match = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*)(.*)", base_leaf)
    if not match:
        raise ValueError(f"unknown fitted CPU register spelling: {name}")
    stem, base_suffix = match.groups()
    live_io = relative.startswith("tms34010_io_regs:u_io_regs|")
    family = contract["families"].get(hierarchy)
    state_aliases = family.get("state_aliases", {}).get(stem, []) if family else []
    if (not re.fullmatch(r"(\[[0-9]+\])*", base_suffix)
            and base_suffix not in ["." + alias for alias in state_aliases] and not live_io):
        raise ValueError(f"unclassified fitted CPU alias: {name}")
    if family and stem in family["stems"]:
        return ["ce", hierarchy, stem]
    if ((not hierarchy and stem in contract["full_rate_local"])
            or hierarchy == "tms34010_io_write_boundary:u_io_write_boundary" or live_io):
        return ["full", hierarchy, stem]
    raise ValueError(f"unreviewed fitted CPU register: {name}")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def render_tcl(contract):
    definitions = ["# Generated from revx_cpu_ce.json by revx_ce_contract.py; verified before map.",
                   "namespace eval revx_ce {", "  variable families [dict create \\"]
    items = list(contract["families"].items())
    for index, (hierarchy, family) in enumerate(items):
        ending = " \\" if index < len(items) - 1 else "]"
        definitions.append("    {" + hierarchy + "} {" + " ".join(family["stems"]) + "}" + ending)
    definitions += ["  variable full_local {" + " ".join(contract["full_rate_local"]) + "}",
                    "  variable state_aliases [dict create]"]
    for hierarchy, family in items:
        for stem, aliases in family.get("state_aliases", {}).items():
            definitions.append("  dict set state_aliases {" + hierarchy + "|" + stem + "} {"
                               + " ".join(aliases) + "}")
    definitions += ["}"]
    return "\n".join(definitions) + '\n' + r'''
proc revx_ce::resolve_names {label names} {
    # foreach_in_collection yields object IDs (reg_123), not collections.
    # Resolve the reviewed full-name list once, then prove exact membership;
    # never pass those object IDs to add/remove_from_collection as filters.
    # Quartus 17 natural-bus naming is on by default: do not double-escape
    # literal array brackets. Every duplicate is explicitly in names already.
    set collection [get_registers -no_duplicates -nowarn $names]
    set resolved [list]
    foreach_in_collection reg $collection {
        lappend resolved [get_node_info -name $reg]
    }
    if {[lsort -unique $names] ne [lsort -unique $resolved] ||
        [llength $names] != [get_collection_size $collection]} {
        error "RevX CE: name resolution changed $label membership"
    }
    return $collection
}
proc revx_ce::collect {} {
    variable families
    variable full_local
    variable state_aliases
    set cpu [get_registers -nowarn {*tms34010_core:u_cpu|*}]
    if {[get_collection_size $cpu] == 0} { error "RevX CE: missing actual CPU" }
    set ce_names [list]
    set full_names [list]
    set members [list]
    set counts [dict create]
    set marker {tms34010_core:u_cpu|}
    foreach_in_collection reg $cpu {
        set name [get_node_info -name $reg]
        set offset [string first $marker $name]
        if {$offset < 0} { error "RevX CE: malformed CPU register $name" }
        set relative [string range $name [expr {$offset + [string length $marker]}] end]
        set parts [split $relative {|}]
        set hierarchy [join [lrange $parts 0 end-1] {|}]
        set leaf [lindex $parts end]
        # Bit/array selectors and recognized duplicates retain their source
        # stem. Dot-state labels must occur in that exact stem's map-proven
        # state encoding table; numeric dots are not generally allowed.
        # Physical-synthesis register aliases inherit their origin's CE
        # classification: strip the tool-appended trailing tokens (~DUPLICATE(_n),
        # _OTERM<digits>, _ITERM<digits>) a duplicated/retimed/output-terminal copy
        # carries, from the LEAF before splitting stem/selector, repeatedly so a
        # composed/chained alias reduces to its origin name. Stripping pre-split is
        # required: on a no-selector (1-bit) register the underscore token would
        # otherwise be absorbed into the greedy stem match (wr_mask[6]_OTERM1481~DUPLICATE
        # at 1fc583ce fit.rpt:9426; _OTERM<n>_OTERM<m> chains). Every other spelling
        # fails closed below. Loop terminates: each strip shortens the string.
        set base_leaf $leaf
        while {[regsub -nocase {(~DUPLICATE(_[0-9]+)?|_OTERM[0-9]+|_ITERM[0-9]+|_NEW_REG[0-9]+)$} $base_leaf {} base_leaf]} {}
        if {![regexp {^([A-Za-z_][A-Za-z0-9_]*)(.*)$} $base_leaf -> stem base_suffix]} {
            error "RevX CE: unknown register spelling $name"
        }
        set alias_ok [regexp {^(\[[0-9]+\])*$} $base_suffix]
        set state_key "${hierarchy}|${stem}"
        if {[string index $base_suffix 0] eq "." && [dict exists $state_aliases $state_key]} {
            set alias_ok [expr {[lsearch -exact [dict get $state_aliases $state_key] \
                                       [string range $base_suffix 1 end]] >= 0}]
        }
        if {!$alias_ok} {
            # Full-rate child logic can contain tool-specific RAM/shift atoms;
            # it remains outside the exception regardless of its spelling.
            if {![string match {tms34010_io_regs:u_io_regs|*} $relative]} {
                error "RevX CE: unclassified alias $name"
            }
        }
        set kind full
        if {[dict exists $families $hierarchy] &&
            [lsearch -exact [dict get $families $hierarchy] $stem] >= 0} {
            set kind ce
            lappend ce_names $name
            dict incr counts $hierarchy
        } elseif {($hierarchy eq "" && [lsearch -exact $full_local $stem] >= 0) ||
                  $hierarchy eq "tms34010_io_write_boundary:u_io_write_boundary" ||
                  [string match {tms34010_io_regs:u_io_regs|*} $relative]} {
            lappend full_names $name
        } else {
            error "RevX CE: register has no reviewed eligibility or exclusion: $name"
        }
        lappend members [list $kind $hierarchy $stem $name]
    }
    foreach hierarchy [list {} {tms34010_pc:u_pc} {tms34010_regfile:u_regfile} \
                        {tms34010_status_reg:u_status_reg} \
                        {tms34010_io_cpu_config:u_io_cpu_config} \
                        {tms34010_io_cpu_status:u_io_cpu_status}] {
        if {![dict exists $counts $hierarchy] || [dict get $counts $hierarchy] == 0} {
            error "RevX CE: required architectural family absent: $hierarchy"
        }
    }
    if {[llength $full_names] == 0} { error "RevX CE: missing full-rate boundary exclusions" }
    set ce [revx_ce::resolve_names ce $ce_names]
    set full [revx_ce::resolve_names full $full_names]
    if {[get_collection_size $ce] + [get_collection_size $full] != [get_collection_size $cpu]} {
        error "RevX CE: incomplete/overlapping fitted membership"
    }
    set outside [remove_from_collection [get_registers {*}] $ce]
    return [dict create ce $ce full $full outside $outside members $members counts $counts]
}
'''


def validate(root):
    root = Path(root).resolve()
    contract = json.loads((root / MANIFEST).read_text(encoding="utf-8"))
    if contract.get("schema") != "revx-cpu-ce/v1" or contract.get("cycles") != 3:
        raise ValueError("unknown CPU CE source contract")
    for relative, proof in contract["sources"].items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or digest(path) != proof["sha256"]:
            raise ValueError(f"CPU CE reviewed source changed: {relative}")
    if (root / COLLECTOR).read_text(encoding="utf-8") != render_tcl(contract):
        raise ValueError("CPU CE collector differs from positive manifest renderer")
    validate_sdc((root / SDC).read_text(encoding="utf-8"))
    if len(contract["families"]) != 10 or contract["full_rate_local"] != [
            "io_rdata_req_valid_q", "wvp_set_q", "setcdp_we_q", "setcdp_convdp_q"]:
        raise ValueError("CPU CE manifest family/exclusion coverage changed")
    for hierarchy, family in contract["families"].items():
        stems = family["stems"]
        if not stems or len(set(stems)) != len(stems) or family["source"] not in contract["sources"]:
            raise ValueError(f"invalid CPU CE family {hierarchy}")
        for stem, aliases in family.get("state_aliases", {}).items():
            if (stem not in stems or not aliases or len(aliases) != len(set(aliases))
                    or any(not re.fullmatch(r"[01]+|[A-Za-z_][A-Za-z0-9_]*", alias) for alias in aliases)):
                raise ValueError(f"invalid CPU CE state alias family {hierarchy}|{stem}")
    return {"schema": contract["schema"], "manifest_sha256": digest(root / MANIFEST),
            "collector_sha256": digest(root / COLLECTOR), "sources": contract["sources"],
            "sdc_sha256": digest(root / SDC), "exact_sdc_rules": CE_RULES,
            "hold_pair_proof": "exact-source-pinned-setup3-hold2-same-positive-endpoints",
            "fitted_state_alias_proof": contract["fitted_state_alias_proof"],
            "families": {name: len(data["stems"]) for name, data in contract["families"].items()},
            "cycles": 3, "qualification": "reviewed-source-contract-only"}
