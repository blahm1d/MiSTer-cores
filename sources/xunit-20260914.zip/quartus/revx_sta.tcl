# Fitted collection/CPU contract audit, inside the same physical FIFO ticket.
set fh [open receipts/constraints.tsv w]
proc emit {args} { global fh; puts $fh [join $args "\t"]; flush $fh }
proc require_count {label coll minimum} {
    set n [get_collection_size $coll]
    emit collection $label $n
    if {$n < $minimum} { error "required collection $label is empty/small ($n)" }
    return $coll
}
proc clean_field {value} {
    regsub -all {[\t\r\n]} $value { } value
    return $value
}
proc dump_paths {corner slug scope kind limit from_regs to_regs to_clock} {
    set options [list -$kind -npaths $limit -nworst 1]
    if {$scope eq "cpu"} {
        lappend options -from $from_regs -to $to_regs
    } else {
        lappend options -to_clock $to_clock
    }
    set paths [get_timing_paths {*}$options]
    set count [get_collection_size $paths]
    if {$count == 0} { error "missing diagnostic paths: $corner $scope $kind" }
    set relative "reports/revx_${slug}_${scope}_${kind}.rpt"
    report_timing {*}$options -detail full_path -show_routing -file $relative
    emit path_report $corner $scope $kind $count $relative
    set rank 0
    foreach_in_collection p $paths {
        incr rank
        set source [clean_field [get_node_info -name [get_path_info -from $p]]]
        set target [clean_field [get_node_info -name [get_path_info -to $p]]]
        emit path $corner $scope $kind $rank [get_path_info -slack $p] \
            [get_path_info -data_delay $p] [get_path_info -num_logic_levels $p] $source $target
    }
}
proc audit_ce_paths {corner label sources targets expected_end} {
    set paths [get_timing_paths -setup -from $sources -to $targets -npaths 500 -nworst 1]
    set count [get_collection_size $paths]
    if {$count == 0} { error "empty required directed CE audit: $corner $label" }
    set mismatches 0
    foreach_in_collection p $paths {
        set sm [get_path_info -setup_start_multicycle $p]
        set em [get_path_info -setup_end_multicycle $p]
        emit ce_path $corner $label $sm $em [get_path_info -slack $p] \
            [clean_field [get_node_info -name [get_path_info -from $p]]] \
            [clean_field [get_node_info -name [get_path_info -to $p]]]
        if {$sm != 1 || $em != $expected_end} { incr mismatches }
    }
    emit ce_audit $corner $label $count 1 $expected_end $mismatches
    if {$mismatches != 0} { error "wrong directed CE exception: $corner $label" }
}
# The hard-HPS proxy has no launch clock, so Quartus 17 emits no setup/hold
# timing objects even with the explicit 20/0 SDC allocation. Measure actual
# longest/shortest physical paths instead. These are transport margins, never
# synthetic STA slack. The endpoint-only census must retain exactly one pair.
proc audit_hps_sda_transport {corner slug expected_source endpoint} {
    set expected_names {}
    foreach_in_collection node $expected_source { lappend expected_names [get_node_info -name $node] }
    if {$expected_names ne {hdmi_i2c~FF_4791}} { error "REVX_PIN SDA proxy identity drift $expected_names" }
    foreach kind {max min} {
        set options [list -to $endpoint -pairs_only -npaths 32 -nworst 32]
        if {$kind eq "min"} { lappend options -min_path }
        set paths [get_path {*}$options]
        set count [get_collection_size $paths]
        if {$count != 1} { error "REVX_PIN SDA physical pair coverage $corner $kind count=$count" }
        set relative "reports/revx_${slug}_hps_sda_transport_${kind}.rpt"
        report_path {*}$options -show_routing -file $relative
        emit pin_transport_report $corner $kind $count $relative
        foreach_in_collection p $paths {
            set source_node [get_path_info -from $p]
            set source [clean_field [get_node_info -name $source_node]]
            set target [clean_field [get_node_info -name [get_path_info -to $p]]]
            if {$source ne "hdmi_i2c~FF_4791" || $target ne "HDMI_I2C_SDA"} {
                error "REVX_PIN unexpected SDA physical fan-in $source -> $target"
            }
            set cell [get_node_info -cell $source_node]
            set cell_name [get_cell_info -name $cell]
            set cell_type [get_cell_info -wysiwyg_type $cell]
            set clock_edges [llength [get_node_info -clock_edges $source_node]]
            if {[get_node_info -type $source_node] ne "reg" || $cell_name ne "hdmi_i2c" ||
                $cell_type ne "cyclonev_hps_interface_peripheral_i2c" || $clock_edges != 0} {
                error "REVX_PIN changed SDA hard-HPS physical source"
            }
            set via_out_data 0
            foreach_in_collection point [get_path_info -arrival_points $p] {
                set node [get_point_info -node $point]
                if {$node ne "" && [get_node_info -name $node] eq "hdmi_i2c|out_data"} {
                    set via_out_data 1
                }
            }
            if {!$via_out_data} { error "REVX_PIN SDA physical route misses hard out_data pin" }
            emit pin_transport_source $corner $kind $source $cell_name $cell_type $clock_edges $via_out_data
            # get_path exposes physical delay; required time and slack are not
            # meaningful on these objects and must not be requested or emitted.
            set delay [get_path_info -arrival_time $p]
            set data [get_path_info -data_delay $p]
            set minimum 0.0
            set maximum 20.0
            set margin [expr {$kind eq "max" ? $maximum-$delay : $delay-$minimum}]
            if {$delay < $minimum || $delay > $maximum || $data < 0.0 ||
                abs($delay-$data) > 0.002 || $margin < 0.0} {
                error "REVX_PIN failing SDA physical transport $corner $kind delay=$delay margin=$margin"
            }
            emit pin_transport $corner $kind $source $target $delay $data $minimum $maximum $margin
        }
        # get_path ignores timing cuts, so even a hidden physical fan-in is
        # still measured and rejected above. This is a physical pair census.
        emit pin_transport_coverage $corner $kind $count 1
    }
}


if {[catch {
    project_open -revision Arcade-RevX -error_on_incompatible_database Arcade-RevX
    create_timing_netlist -no_report
    read_sdc
    update_timing_netlist
    set sysclk [require_count core_clock [get_clocks {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}] 1]
    foreach_in_collection c $sysclk {
        set period [get_clock_info -period $c]
        emit period core_clock $period
        if {abs($period - 12.5) > 0.001} { error "expected 80 MHz core clock; period=$period" }
    }
    require_count sdram_clock [get_clocks {SDRAM_CLK}] 1
    require_count sdram_dq [get_ports {SDRAM_DQ[*]}] 16
    # The removed arc* exception was for HPS-programmed custom-aspect banks.
    # Their consumers require VIDEO_ARY=0, which this RevX wrapper never emits.
    foreach bank {arc1x arc1y arc2x arc2y} {
        set registers [get_registers -nowarn "${bank}*"]
        set count [get_collection_size $registers]
        emit absent $bank $count
        if {$count != 0} { error "custom-aspect bank $bank unexpectedly retained ($count)" }
    }
    # Identical 4:3/16:9 selector bits can merge into either aspect bank.
    # Record each bank, but require the existing combined control to survive.
    set aspect_total 0
    foreach bank {arx ary} {
        set count [get_collection_size [get_registers -nowarn "${bank}*"]]
        emit aspect_bank $bank $count
        incr aspect_total $count
    }
    if {$aspect_total == 0} { error "all standard aspect selector keepers disappeared" }
    set cpu [require_count cpu [get_registers {*tms34010_core:u_cpu|*}] 1]
    # read_sdc used the same positive collector to apply the two-cycle rule.
    set ce [dict get $revx_ce_contract ce]
    set full [dict get $revx_ce_contract full]
    set outside [dict get $revx_ce_contract outside]
    require_count cpu_ce $ce 1
    require_count cpu_full_rate $full 1
    foreach member [dict get $revx_ce_contract members] { emit ce_member {*}$member }
    dict for {family stems} $revx_ce::families {
        set count 0
        if {[dict exists [dict get $revx_ce_contract counts] $family]} {
            set count [dict get [dict get $revx_ce_contract counts] $family]
        }
        emit ce_family $family $count
    }
    if {![info exists revx_pin_collection_counts]} { error "missing RevX pin collections" }
    dict for {label count} $revx_pin_collection_counts { emit pin_collection $label $count }
    report_clocks -file reports/revx_clocks.rpt
    check_timing -file reports/revx_check_timing.rpt
    report_ucp -file reports/revx_unconstrained.rpt
    # Capture the measured CPU and full core-clock cones at all four required
    # corners in this same ticket, so pipeline work needs no report-only replay.
    set wanted [list {Slow 1100mV 100C Model} {Slow 1100mV -40C Model} \
                     {Fast 1100mV 100C Model} {Fast 1100mV -40C Model}]
    set seen [list]
    foreach_in_collection op [get_available_operating_conditions -all] {
        set corner [get_operating_conditions_info $op -display_name]
        if {[lsearch -exact $wanted $corner] < 0} { continue }
        if {[lsearch -exact $seen $corner] >= 0} { error "duplicate operating corner $corner" }
        lappend seen $corner
        set_operating_conditions $op
        update_timing_netlist
        # 2026-09-07: expectations follow the contract (cycles=4, Wolf recipe). The LAUNCH
        # registers (revx.sdc $revx_launch_regs = u_mif a_q/sz_q/we_q/srt_q/wd_q + the u_mif
        # per-beat bus precomputes p_addr0/1 p_be0/1 p_wsh0/1 p_nmask0/1 p_rmw p_straddle + the I/O
        # command boundaries wr_valid/wr_status_guard + io_rdata_req_valid_q + setcdp_we_q/
        # setcdp_convdp_q) are CE->launch multicycle DESTINATIONS and are audited on their own,
        # so they are removed from the ce_to_full single-cycle sample. io_rdata_req_valid_q is
        # ALSO a single-source CE launch SOURCE ($revx_launch_io_read) into the CE core
        # (io_rdata_req_valid_q -> move_mem_cmd_wdata_q, em==4), so it is removed from the plain
        # full->ce single-cycle sample and audited in its own launch_to_ce direction. Cycle count
        # parsed from the SDC's own ce->ce rule (the SDC text is contract-validated).
        set sdc_text [read [open quartus/revx.sdc r]]
        if {![regexp {set_multicycle_path -setup (\d+) -from \$revx_ce_registers -to \$revx_ce_registers} $sdc_text -> revx_ce_cycles]} { error "revx.sdc ce->ce setup rule not found" }
        if {![info exists revx_launch_regs]} { error "revx.sdc did not export revx_launch_regs" }
        if {![info exists revx_launch_io_read]} { error "revx.sdc did not export revx_launch_io_read" }
        set outside_nolaunch [remove_from_collection $outside $revx_launch_regs]
        set full_nolaunch_src [remove_from_collection $outside $revx_launch_io_read]
        audit_ce_paths $corner ce_to_ce $ce $ce $revx_ce_cycles
        audit_ce_paths $corner ce_to_launch $ce $revx_launch_regs $revx_ce_cycles
        audit_ce_paths $corner launch_to_ce $revx_launch_io_read $ce $revx_ce_cycles
        audit_ce_paths $corner ce_to_full $ce $outside_nolaunch 1
        audit_ce_paths $corner full_to_ce $full_nolaunch_src $ce 1
        audit_ce_paths $corner cpu_full_to_full $full $full 1
        set slug [string tolower $corner]
        regsub -all {[^a-z0-9]+} $slug {_} slug
        set slug [string trim $slug {_}]
        audit_hps_sda_transport $corner $slug $revx_pin_hps_sda_proxy $revx_pin_hps_sda
        dump_paths $corner $slug cpu setup 30 $cpu $cpu $sysclk
        dump_paths $corner $slug cpu hold 10 $cpu $cpu $sysclk
        dump_paths $corner $slug core setup 30 $cpu $cpu $sysclk
        dump_paths $corner $slug hdmi setup 30 $cpu $cpu $revx_pin_hdmi
        dump_paths $corner $slug hdmi hold 10 $cpu $cpu $revx_pin_hdmi
    }
    if {[llength $seen] != 4} { error "required four diagnostic corners; saw $seen" }
    emit result PASS
    project_close
} message]} {
    emit error $message
    emit result FAIL
    close $fh
    qexit -error
}
close $fh
qexit -success
