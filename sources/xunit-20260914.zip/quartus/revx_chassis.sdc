# revx_chassis.sdc -- chassis/peripheral timing exceptions for Revolution X, kept OUTSIDE
# quartus/revx.sdc because the CPU CE contract validator rejects any multicycle command it
# did not generate. Each rule is the donor's proven, cabinet-shipped constraint with the
# 2026-09-07 measurement that motivated restoring it (attempt e285102e worst-path report,
# build_syn/diag_copies/worst_diag_20260907T090736Z_e285102e/reports/).

# ---- SDRAM read-data capture (wolf-crt/rtl/sdram.sdc:21-24; jtframe's MiSTer SDRAM rule) --
# The controller registers DQ on the clk_sys edge AFTER the SDRAM_CLK edge that launched it
# (MT48LC16M16 CAS2 tAC 6.0 ns + pin/route exceed one 12.5 ns cycle). Measured without it:
# SDRAM_DQ[9] -> sdram_phy|dout[9] = -10.412 ns slow / -7.217 ns fast against a 3.515 ns
# relationship -- identical at both corners, i.e. a constraint, not logic.
set_multicycle_path -setup -end \
  -rise_from [get_clocks {SDRAM_CLK}] \
  -rise_to [get_clocks {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}] 2
# Paired hold exception (check_timing 'partial_multicycle' was fatal in attempt 18d48600
# without it): keep the hold check on the launch edge, the standard pairing for a
# setup -end 2 read-capture rule.
set_multicycle_path -hold -end \
  -rise_from [get_clocks {SDRAM_CLK}] \
  -rise_to [get_clocks {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}] 1

# ---- DCS2K ADSP-2105 clock enable (tunit/Arcade-TUnit_MiSTer/rtl/tunit.sdc:505-520) ------
# revx_dcs2k drives the ADSP core on core_ce = 1-in-2 (revx_dcs2k.sv:77,96: core_phase toggles
# every clk_sys). The T-unit rule, verbatim with the RevX instance names: the external-response
# catcher, dac_ce and pm_we stay full-rate and are excluded; DCS-boundary crossings stay
# single-cycle. Measured without it: ram WRITE_ENABLE_REG -> mac_pipe_r -7.635 ns,
# mstat -> sbb -7.274 ns (slow).
set revx_dcs_ce_regs [get_registers -nowarn {*revx_adsp2105:cpu|*}]
set revx_dcs_full_rate_regs [get_registers -nowarn {*revx_adsp2105:cpu|revx_dcs_mem:u_mem|ext_rsp_valid *revx_adsp2105:cpu|revx_dcs_mem:u_mem|ext_rsp_q[*] *revx_adsp2105:cpu|dac_ce *revx_adsp2105:cpu|pm_we}]
if {[get_collection_size $revx_dcs_full_rate_regs] != 0} {
  set revx_dcs_ce_regs [remove_from_collection $revx_dcs_ce_regs $revx_dcs_full_rate_regs]
}
if {[get_collection_size $revx_dcs_ce_regs] == 0} {
  post_message -type error "RevX DCS clock-enable timing collection is empty (instance name drift?)"
} else {
  post_message -type info "RevX DCS multicycle covers [get_collection_size $revx_dcs_ce_regs] registers"
  set_multicycle_path -setup 2 -from $revx_dcs_ce_regs -to $revx_dcs_ce_regs
  set_multicycle_path -hold  1 -from $revx_dcs_ce_regs -to $revx_dcs_ce_regs
}

# ---- HDMI PLL-reconfig internal reset -> vendor Fmax-capture flop (hold only) -------------
# Measured 2026-09-07 attempt 26a87263, Fast 1100mV -40C hold: pll_cfg_hdmi|self_reset|local_reset
# -> cyclonev_pll ... PLL_RECONFIG~FMAX_CAP_FF, slack -0.048 ns (0.272 ns data, 0 relationship).
# Absent in attempt 18d48600 with the same sources = placement noise on a synthetic register the
# reconfig megafunction inserts only to model its Fmax cap (not a functional flop). Hold-only
# exception on exactly that pair; setup stays timed. Holds are otherwise never waived.
set revx_pllcfg_rst [get_registers -nowarn {*pll_cfg_hdmi*self_reset*local_reset*}]
set revx_pllcfg_cap [get_registers -nowarn {*PLL_RECONFIG~FMAX_CAP_FF*}]
if {[get_collection_size $revx_pllcfg_rst] > 0 && [get_collection_size $revx_pllcfg_cap] > 0} {
  set_false_path -hold -from $revx_pllcfg_rst -to $revx_pllcfg_cap
}

set ::revx_pin_collection_counts [dict create]
# ---- Board pin contracts, 2026-09-12 -------------------------------------------
# See docs/REVX-PIN-CONTRACT-20260912.md for protocol evidence, budget allocations,
# firmware assumptions and explicit limits of qualification. This section does
# not alter internal CPU, DMA, scaler or SDRAM timing relationships.
proc revx_pin_require {label collection expected} {
  set actual [get_collection_size $collection]
  if {$actual != $expected} {
    set observed {}
    catch {
      foreach_in_collection node $collection {
        lappend observed [get_node_info -name $node]
      }
    }
    error "REVX_PIN $label count=$actual expected=$expected nodes=$observed"
  }
  global revx_pin_collection_counts
  if {[dict exists $revx_pin_collection_counts $label]} {
    error "REVX_PIN duplicate collection label $label"
  }
  dict set revx_pin_collection_counts $label $actual
  return $collection
}

set revx_pin_core_name {emu|pll|pll_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}
set revx_pin_hdmi_name {pll_hdmi|pll_hdmi_inst|altera_pll_i|cyclonev_pll|counter[0].output_counter|divclk}
set revx_pin_audio_name {pll_audio|pll_audio_inst|altera_pll_i|general[0].gpll~PLL_OUTPUT_COUNTER|divclk}
set revx_pin_core [revx_pin_require core_clock [get_clocks $revx_pin_core_name] 1]
set revx_pin_hdmi [revx_pin_require hdmi_clock [get_clocks $revx_pin_hdmi_name] 1]
set revx_pin_audio [revx_pin_require audio_clock [get_clocks $revx_pin_audio_name] 1]
set revx_pin_core_src [revx_pin_require core_pin [get_pins -compatibility_mode $revx_pin_core_name] 1]
set revx_pin_hdmi_src [revx_pin_require hdmi_pin [get_pins -compatibility_mode $revx_pin_hdmi_name] 1]
set revx_pin_audio_src [revx_pin_require audio_pin [get_pins -compatibility_mode $revx_pin_audio_name] 1]

# altddio_out datain_h=0, datain_l=1: TimeQuest needs explicit -invert.
# Both clock-mux modes are analyzed; no case analysis disables either mode.
set revx_pin_txclk [revx_pin_require hdmi_tx_clock [get_ports {HDMI_TX_CLK}] 1]
create_generated_clock -name REVX_TX_DIRECT -source $revx_pin_core_src \
  -master_clock $revx_pin_core -divide_by 1 -invert $revx_pin_txclk
create_generated_clock -name REVX_TX_SCALER -source $revx_pin_hdmi_src \
  -master_clock $revx_pin_hdmi -divide_by 1 -invert -add $revx_pin_txclk
set revx_pin_direct_group [get_clocks [list $revx_pin_core_name REVX_TX_DIRECT]]
set revx_pin_scaler_group [get_clocks [list $revx_pin_hdmi_name REVX_TX_SCALER]]
revx_pin_require hdmi_direct_group $revx_pin_direct_group 2
revx_pin_require hdmi_scaler_group $revx_pin_scaler_group 2
set_clock_groups -exclusive -group $revx_pin_direct_group -group $revx_pin_scaler_group
set revx_pin_video [revx_pin_require hdmi_video [get_ports {HDMI_TX_D[*] HDMI_TX_DE HDMI_TX_HS HDMI_TX_VS}] 27]
# ADV7513: tSU=1.8 ns, tH=1.3 ns. Allocate another 0.2 ns each for board skew.
# Assumes transmitter register 0xBA=0x60 (zero programmable input-clock delay).
set_output_delay -clock REVX_TX_DIRECT -max 2.0 $revx_pin_video
set_output_delay -clock REVX_TX_DIRECT -min -1.5 $revx_pin_video
set_output_delay -clock REVX_TX_SCALER -max 2.0 -add_delay $revx_pin_video
set_output_delay -clock REVX_TX_SCALER -min -1.5 -add_delay $revx_pin_video

set revx_pin_mclk [revx_pin_require hdmi_audio_master [get_ports {HDMI_MCLK}] 1]
create_generated_clock -name REVX_AUDIO_MCLK -source $revx_pin_audio_src \
  -master_clock $revx_pin_audio -divide_by 1 $revx_pin_mclk

# I2S has >=80 ns source-level edge separation in the bounded protocol test.
# Bound EACH output's clock-to-pin transport to [0,20] ns, including clock
# network latency. This is normal TimeQuest max/min delay, NOT datapath_only.
# At most 20 ns differential transport leaves >=60 ns before external skew,
# against the ADV7513's 2 ns setup/hold requirement. USER_IO aliases are timed
# only from the audio clock; unrelated alternate functions are not waived.
set revx_pin_i2s [revx_pin_require i2s_outputs [get_ports {HDMI_I2S HDMI_LRCLK HDMI_SCLK USER_IO[2] USER_IO[4] USER_IO[5]}] 6]
set_max_delay -from $revx_pin_audio -to $revx_pin_i2s 20.0
set_min_delay -from $revx_pin_audio -to $revx_pin_i2s 0.0
set revx_pin_spdif [revx_pin_require spdif_output [get_ports {SDCD_SPDIF}] 1]
set_max_delay -from $revx_pin_audio -to $revx_pin_spdif 20.0
set_min_delay -from $revx_pin_audio -to $revx_pin_spdif 0.0

# Soft MCP23009 master: 300 kHz, >=1660 ns SCL low. Budget 20 ns each for
# output/input transport, 900 ns slave ACK delay, 300 ns rise and 20 ns margin.
# Capture registers are explicitly enumerated; no internal I2C path is waived.
set revx_pin_i2c_clk [revx_pin_require expander_clock [get_clocks {FPGA_CLK2_50}] 1]
set revx_pin_i2c_out [revx_pin_require expander_outputs [get_ports {IO_SCL IO_SDA}] 2]
set revx_pin_i2c_in [revx_pin_require expander_input [get_ports {IO_SDA}] 1]
# Source uses five GPIO bits, but the mapped register names do not retain the
# source's [7:3] indexing. Collect the whole receive family, never guessed bit
# aliases. The first mapped attempt measured five data members plus ACK.
set revx_pin_i2c_rx [revx_pin_require expander_receivers [get_registers {*mcp23009:mcp23009|i2c:i2c|ACK *mcp23009:mcp23009|i2c:i2c|rdata[*]}] 6]
foreach_in_collection node $revx_pin_i2c_rx {
  post_message -type info "REVX_PIN expander_receiver [get_node_info -name $node]"
}
set_max_delay -from $revx_pin_i2c_clk -to $revx_pin_i2c_out 20.0
set_min_delay -from $revx_pin_i2c_clk -to $revx_pin_i2c_out 0.0
set_max_delay -from $revx_pin_i2c_in -to $revx_pin_i2c_rx 20.0
set_min_delay -from $revx_pin_i2c_in -to $revx_pin_i2c_rx 0.0

# HDMI configuration is HPS hard I2C, NOT the soft MCP master. Only the fabric
# segments between hard-macro boundary pins and package pins are bounded here.
# HPS firmware/controller timing remains an explicit platform assumption.
set revx_pin_hps_scl_src [revx_pin_require hps_i2c_scl [get_pins -compatibility_mode {hdmi_i2c|out_clk}] 1]
set revx_pin_hps_sda_src [revx_pin_require hps_i2c_sda_out [get_pins -compatibility_mode {hdmi_i2c|out_data}] 1]
set revx_pin_hps_sda_dst [revx_pin_require hps_i2c_sda_in [get_pins -compatibility_mode {hdmi_i2c|sda}] 1]
set revx_pin_hps_scl_dst [revx_pin_require hps_i2c_scl_in [get_pins -compatibility_mode {hdmi_i2c|scl}] 1]
set revx_pin_hps_scl [revx_pin_require hdmi_i2c_scl_port [get_ports {HDMI_I2C_SCL}] 1]
set revx_pin_hps_sda [revx_pin_require hdmi_i2c_sda_port [get_ports {HDMI_I2C_SDA}] 1]
set_max_delay -from $revx_pin_hps_scl_src -to $revx_pin_hps_scl 20.0
set_min_delay -from $revx_pin_hps_scl_src -to $revx_pin_hps_scl 0.0
set_max_delay -from $revx_pin_hps_sda_src -to $revx_pin_hps_sda 20.0
set_min_delay -from $revx_pin_hps_sda_src -to $revx_pin_hps_sda 0.0
set_max_delay -from $revx_pin_hps_sda -to $revx_pin_hps_sda_dst 20.0
set_min_delay -from $revx_pin_hps_sda -to $revx_pin_hps_sda_dst 0.0
set_max_delay -from $revx_pin_hps_scl -to $revx_pin_hps_scl_dst 20.0
set_min_delay -from $revx_pin_hps_scl -to $revx_pin_hps_scl_dst 0.0

# In analog-video mode these shared connector outputs have no synchronous
# receiver. Bound propagation instead of blanket-false-pathing the ports.
# The -from clocks restrict this rule to the core/scaler video functions;
# HPS spi_sck paths retain their existing constraints. This also measures the
# SDRAM-named optimized sync alias without presuming its name proves function.
set revx_pin_analog [revx_pin_require analog_connector [get_ports {SDIO_CLK SDIO_CMD SDIO_DAT[*] SD_SPI_CS}] 7]
set_max_delay -from $revx_pin_core -to $revx_pin_analog 20.0
set_min_delay -from $revx_pin_core -to $revx_pin_analog 0.0
set_max_delay -from $revx_pin_hdmi -to $revx_pin_analog 20.0
set_min_delay -from $revx_pin_hdmi -to $revx_pin_analog 0.0

# Asynchronous physical indicators, not synchronous receiver data. Card detect
# is a static selection input during a transaction; hot-plug CDC is NOT proven.
# Direction matters: the input exception does not waive the SPDIF output path.
set revx_pin_leds [revx_pin_require status_leds [get_ports {LED[0] LED[2] LED[6]}] 3]
set_false_path -to $revx_pin_leds
# Card-detect input controls only these six analog/SD mux outputs. The active
# SPDIF output and any new card-detect fanout are outside this exception.
set revx_pin_card_input [revx_pin_require card_detect_input [get_ports {SDCD_SPDIF}] 1]
set revx_pin_card_mux [revx_pin_require card_detect_mux_outputs [get_ports {SDIO_CLK SDIO_CMD SDIO_DAT[*]}] 6]
set_false_path -from $revx_pin_card_input -to $revx_pin_card_mux

# Exact mapped hard-HPS output timing proxy, witnessed in three frozen fits.
# Quartus 17 gives this clockless proxy no setup/hold timing objects.
# revx_sta.tcl enforces the same 20/0 allocation on physical max/min
# paths at all four corners; their margin is not reported as STA slack.
# The out_data primitive pin matches but does not cover this timing startpoint.
# Do not invent a proxy clock or false-path it. Allocation is FPGA transport only.
set revx_pin_hps_sda_proxy [revx_pin_require hps_sda_output_proxy [get_registers -nowarn {hdmi_i2c~FF_4791}] 1]
set_max_delay -from $revx_pin_hps_sda_proxy -to $revx_pin_hps_sda 20.0
set_min_delay -from $revx_pin_hps_sda_proxy -to $revx_pin_hps_sda 0.0
