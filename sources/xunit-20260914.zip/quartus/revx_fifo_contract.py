"""RevX bindings to the established shared FIFO; this module never queues work."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

FIFO = Path("D:/deck/fpga/shared_quartus_fifo.sh")
FIFO_SHA = "657764B76F7E86C442873E73984635CE68F555DA03BFF3BA8FC55E564D416E08"
MAP_PATH = "C:/intelFPGA_lite/17.0/quartus/bin64/quartus_map.exe"
MAP_SHA = "3DFB729AF88E2EF6217EC6EA0DBAD305485814B84B46610A1CFD41EFF5DBCD45"
# RESUME-ASM first worker (2026-09-10): asm-only resume tickets on an existing fit db.
ASM_PATH = "C:/intelFPGA_lite/17.0/quartus/bin64/quartus_asm.exe"
ASM_SHA = "F49DBD0C9659AEA524E013B65F69C612B87D715256E904B10C8D7BEFF32FF6CF"
BASH = "C:/Program Files/Git/bin/bash.exe"
BASH_SHA = "FB991BEB09C6C77F343A05A09842867688609DF062A7BB00C719C90371C9348D"
NOTIFY_SHA = "7BB0FE4B1A304E2177737BE5830E461A1A2B59FE13D16DFF23C2678A82347793"
GUARD_SHA = "F27192CBB8477475CF61432AE8823695C3C5F05747F58D5B7905A521EF0C8C72"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest().upper()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def fields(text):
    result = {}
    for line in text.splitlines():
        key, separator, value = line.partition("=")
        require(separator and key and key not in result, "malformed/duplicate FIFO field")
        result[key] = value
    return result


def native_path(value):
    if value.startswith("/"):
        value = subprocess.run(["cygpath", "-am", value], capture_output=True, text=True,
                               check=True).stdout.strip()
    return Path(value).resolve()


def posix_path(path):
    return subprocess.run(["cygpath", "-au", str(path)], capture_output=True, text=True,
                          check=True).stdout.strip()


def norm(value):
    return value.replace("\\", "/").lower()


def launcher_identity():
    require(sha(FIFO) == FIFO_SHA, "shared FIFO differs from reviewed launcher")
    return {"path": str(FIFO), "sha256": FIFO_SHA}


def check_owner(owner, run, ready, run_posix):
    """Same owner/ready/command/first-worker bindings as Model 1 r65."""
    require(ready.get("fifo_launcher") == {"path": str(FIFO), "sha256": FIFO_SHA},
            "ready receipt lacks reviewed FIFO identity")
    pid = owner.get("pid", "")
    require(re.fullmatch(r"[1-9][0-9]*", pid), "invalid FIFO owner PID")
    session = f"revx:{run.name}:{pid}"
    # RESUME-ASM (2026-09-10): a ticket whose ready.json carries resume_asm re-runs
    # ONLY signoff+asm on the existing fit db -- its first controlled worker is
    # quartus_asm, not quartus_map.  Both worker identities are reviewed pins.
    resume = bool(ready.get("resume_asm"))
    fw_name, fw_sha, fw_path = ("quartus_asm", ASM_SHA, ASM_PATH) if resume else \
                               ("quartus_map", MAP_SHA, MAP_PATH)
    required = {
        "format": "shared-quartus-fifo-v4-phase-aware-job-object-pinned",
        "session": session, "cwd": run_posix, "phase_aware": "0",
        "ready_receipt": run_posix + "/ready.json",
        "ready_receipt_sha256": sha(run / "ready.json"),
        "command_argv0": run_posix + "/quartus/build_revx.sh",
        "command_sha256": sha(run / "quartus/build_revx.sh"),
        "launcher_snapshot_sha256": FIFO_SHA,
        "expected_first_worker": fw_name, "expected_first_worker_sha256": fw_sha,
        "notifier": "/tmp/fpga_quartus.notifier-snapshots/" + NOTIFY_SHA.lower() + ".sh",
        "notifier_sha256": NOTIFY_SHA,
        "job_guard_sha256": GUARD_SHA, "payload_bash_sha256": BASH_SHA,
    }
    for key, value in required.items():
        observed = owner.get(key, "")
        if key.endswith("sha256"):
            observed = observed.upper()
        require(observed == value, f"FIFO owner {key} mismatch")
    require(norm(owner.get("expected_first_worker_path", "")) == norm(fw_path),
            "FIFO owner first-worker executable mismatch")
    require(norm(owner.get("command_path_win", "")) == norm(str(run / "quartus/build_revx.sh")),
            "FIFO owner payload path mismatch")
    require(re.fullmatch(r"[1-9][0-9]*\." + re.escape(session) + r"\." + pid,
                         owner.get("ticket", "")), "FIFO ticket/session/PID mismatch")
    safe = re.sub(r"[^A-Za-z0-9_.-]", "_", session)
    queue = run_posix + "/queue." + safe
    require(owner.get("status") == queue + "/status" and
            owner.get("job_guard_status") == queue + "/job-guard.json", "FIFO local receipt paths mismatch")
    require(owner.get("central_result") == "/tmp/fpga_quartus.queue/results/" + safe + ".result/status",
            "FIFO central receipt path mismatch")
    return safe


def bind_owner(run):
    run = Path(run).resolve()
    ready = json.loads((run / "ready.json").read_text(encoding="utf-8"))
    launcher_identity()
    owner_posix = os.environ.get("FPGA_QUARTUS_OWNER_FILE_POSIX", "")
    require(owner_posix == "/tmp/fpga_quartus.lock/owner", "not under the canonical FIFO owner")
    path = native_path(owner_posix)
    require(native_path(os.environ.get("FPGA_QUARTUS_OWNER_FILE_WIN", "")) == path,
            "FIFO native/POSIX owner identity mismatch")
    data = path.read_bytes()
    owner = fields(data.decode("utf-8"))
    check_owner(owner, run, ready, posix_path(run))
    require(sha(native_path(owner["launcher_snapshot"])) == FIFO_SHA, "active FIFO snapshot changed")
    require(path.read_bytes() == data, "FIFO owner changed during binding")
    with (run / "receipts/fifo_owner_at_start.txt").open("xb") as output:
        output.write(data)
    print("Live FIFO owner, prepared inputs, payload, launcher and first worker bound")


def check_terminal(owner, status, guard, code):
    require(status.get("session") == owner["session"] and status.get("ticket") == owner["ticket"],
            "terminal FIFO status owner/ticket mismatch")
    require(status.get("cwd") == owner["cwd"] and status.get("status") == owner["status"],
            "terminal FIFO status path mismatch")
    require(status.get("exit_code") == str(code) and
            status.get("verdict") == ("OK" if code == 0 else "FAILED"), "terminal FIFO exit mismatch")
    require(guard.get("schema") == "shared-quartus-job-watchdog/v3" and guard.get("state") == "closed",
            "guardian not in known closed state")
    for key in ("terminal", "job_query_ok", "job_empty_proven", "containment_empty", "telemetry_complete",
                "command_verified", "helper_verified", "bash_verified", "parent_verified",
                "expected_first_worker_verified", "global_opposite_family_scan_complete"):
        require(guard.get(key) is True, f"guardian {key} is not true")
    require(guard.get("active_processes") == 0 and guard.get("result_code") == code,
            "guardian active process/exit mismatch")
    require(guard.get("mixed_worker_families") is False and guard.get("phase_aware") is False,
            "unexpected guardian worker-family/phase contract")
    for key, value in (("session", owner["session"]), ("command_sha256", owner["command_sha256"]),
                       ("command_observed_sha256", owner["command_sha256"]),
                       ("helper_sha256", GUARD_SHA), ("helper_observed_sha256", GUARD_SHA),
                       ("bash_sha256", BASH_SHA), ("bash_observed_sha256", BASH_SHA)):
        require(str(guard.get(key, "")).upper() == value.upper(), f"guardian {key} mismatch")
    # First-worker identity: match the ticket's declared worker (quartus_map for a
    # fresh attempt, quartus_asm for a resume-asm ticket) against its reviewed pin.
    fw_name = owner["expected_first_worker"]
    fw_sha = {"quartus_map": MAP_SHA, "quartus_asm": ASM_SHA}.get(fw_name)
    require(fw_sha is not None, "owner first worker is not a reviewed executable")
    for key, value in (("expected_first_worker_sha256", fw_sha),
                       ("expected_first_worker_observed_sha256", fw_sha),
                       ("first_worker", fw_name), ("expected_first_worker", fw_name)):
        require(str(guard.get(key, "")).upper() == value.upper(), f"guardian {key} mismatch")
    fw_path = {"quartus_map": MAP_PATH, "quartus_asm": ASM_PATH}[fw_name]
    require(norm(guard.get("first_worker_path", "")) == norm(fw_path), "guardian first-worker path mismatch")
    require(norm(guard.get("command_path", "")) == norm(owner["command_path_win"]), "guardian payload path mismatch")
    require(guard.get("parent_pid") == int(owner["winpid"]) and
            guard.get("parent_creation_filetime") == owner["creation_filetime"], "guardian launcher lifetime mismatch")


def collect_fifo(run, code):
    """Only called after the shared launcher returns and releases its ticket."""
    run = Path(run).resolve()
    proof = {"schema": "revx-fifo-evidence/v1", "result": "FAIL", "errors": [], "fifo_exit": code,
             "files": {}, "owner_path": "receipts/fifo_owner_at_start.txt",
             "released_owner_path": "receipts/fifo_released_owner.txt",
             "central_status_path": "receipts/fifo_central_status.txt",
             "ticket_absence_path": "receipts/fifo_ticket_absence.txt"}
    try:
        owner_path = run / proof["owner_path"]
        owner = fields(owner_path.read_text(encoding="utf-8"))
        safe = check_owner(owner, run, json.loads((run / "ready.json").read_text(encoding="utf-8")), posix_path(run))
        queue = run / ("queue." + safe)
        require([p for p in run.glob("queue.*") if p.is_dir()] == [queue], "nonunique FIFO attempt directory")
        proof.update({"session": owner["session"], "ticket": owner["ticket"],
                      "guard_path": queue.name + "/job-guard.json", "status_path": queue.name + "/status"})
        central = native_path(owner["central_result"])
        for source, relative in ((central, proof["central_status_path"]),
                                 (central.parent / "released-lock/owner", proof["released_owner_path"])):
            with (run / relative).open("xb") as output:
                output.write(source.read_bytes())
        require(owner_path.read_bytes() == (run / proof["released_owner_path"]).read_bytes(),
                "released owner differs from exact starting owner")
        require((queue / "status").read_bytes() == (run / proof["central_status_path"]).read_bytes(),
                "central/local FIFO terminal status differs")
        status = fields((queue / "status").read_text(encoding="utf-8"))
        guard = json.loads((queue / "job-guard.json").read_text(encoding="utf-8"))
        check_terminal(owner, status, guard, code)
        proof["first_worker"] = guard["first_worker"]
        proof["guard_empty"] = True
        require(sha(BASH) == BASH_SHA and sha(native_path(owner["notifier"])) == NOTIFY_SHA,
                "read-only ticket verifier tool identity changed")
        result = subprocess.run([BASH, "--noprofile", "--norc", owner["notifier"], "holds", owner["session"]],
                                capture_output=True, text=True)
        text = result.stdout + result.stderr
        (run / proof["ticket_absence_path"]).write_text(text, encoding="utf-8")
        require(result.returncode == 1 and text.startswith("NO TICKET for '" + owner["session"] + "' --"),
                "own FIFO ticket deletion not verified")
        proof["ticket_absence_verified"] = True
        if code == 0:
            proof["result"] = "PASS"
        else:
            proof["errors"].append(f"physical FIFO command failed with exit {code}")
    except Exception as exc:
        proof["errors"].append(str(exc))
    for key, relative in list(proof.items()):
        if key.endswith("_path") and isinstance(relative, str) and (run / relative).is_file():
            proof["files"][relative] = sha(run / relative)
    for queue in run.glob("queue.*"):
        if queue.is_dir():
            for path in queue.iterdir():
                if path.is_file():
                    proof["files"][path.relative_to(run).as_posix()] = sha(path)
    with (run / "receipts/fifo_evidence.json").open("x", encoding="utf-8") as output:
        json.dump(proof, output, indent=2)
        output.write("\n")
    return proof
