//============================================================================
//  Arcade: Revolution X (Midway X-unit, TMS34020) for MiSTer -- emu wrapper
//
//  Open TMS34020 X-unit core.  This emu wraps rtl/revx/revx_top.sv (the synthesizable
//  X-unit core: 34020 + X-unit memory backends + palette + scanout, P0019 cpu_ce +
//  P0022 capture reset baked in) in the standard Template_MiSTer chassis.  Forked from
//  the Wolf/SmashTV emu (Arcade-SmashTV.sv); the Wolf/UMK3-specific game branches,
//  DCS_ONLY_TEST harness and EJB injector are removed.
//
//  First hardware DIAG: real SDRAM pins, native CPU raster/scanout, CPU peripheral
//  bus and DCS UART host are connected. Cabinet behavior and throughput remain
//  unqualified; the overlay reports actual loader and peripheral observations.
//
//  GPL. No ROM data distributed.
//============================================================================
module emu
(
	input         CLK_50M,
	input         RESET,
	inout  [48:0] HPS_BUS,

	output        CLK_VIDEO,
	output        CE_PIXEL,
	output [12:0] VIDEO_ARX,
	output [12:0] VIDEO_ARY,

	output  [7:0] VGA_R,
	output  [7:0] VGA_G,
	output  [7:0] VGA_B,
	output        VGA_HS,
	output        VGA_VS,
	output        VGA_DE,
	output        VGA_F1,
	output [1:0]  VGA_SL,
	output        VGA_SCALER,
	output        VGA_DISABLE,

	input  [11:0] HDMI_WIDTH,
	input  [11:0] HDMI_HEIGHT,
	output        HDMI_FREEZE,
	output        HDMI_BLACKOUT,
	output        HDMI_BOB_DEINT,

	output        FB_EN,
	output  [4:0] FB_FORMAT,
	output [11:0] FB_WIDTH,
	output [11:0] FB_HEIGHT,
	output [31:0] FB_BASE,
	output [13:0] FB_STRIDE,
	input         FB_VBL,
	input         FB_LL,
	output        FB_FORCE_BLANK,

	output        FB_PAL_CLK,
	output  [7:0] FB_PAL_ADDR,
	output [23:0] FB_PAL_DOUT,
	input  [23:0] FB_PAL_DIN,
	output        FB_PAL_WR,

	output        LED_USER,
	output  [1:0] LED_POWER,
	output  [1:0] LED_DISK,

	output  [1:0] BUTTONS,

	input         CLK_AUDIO,
	output [15:0] AUDIO_L,
	output [15:0] AUDIO_R,
	output        AUDIO_S,
	output  [1:0] AUDIO_MIX,

	inout   [3:0] ADC_BUS,

	output        SD_SCK,
	output        SD_MOSI,
	input         SD_MISO,
	output        SD_CS,
	input         SD_CD,

	output        DDRAM_CLK,
	input         DDRAM_BUSY,
	output  [7:0] DDRAM_BURSTCNT,
	output [28:0] DDRAM_ADDR,
	input  [63:0] DDRAM_DOUT,
	input         DDRAM_DOUT_READY,
	output        DDRAM_RD,
	output [63:0] DDRAM_DIN,
	output  [7:0] DDRAM_BE,
	output        DDRAM_WE,

	output        SDRAM_CLK,
	output        SDRAM_CKE,
	output [12:0] SDRAM_A,
	output  [1:0] SDRAM_BA,
	inout  [15:0] SDRAM_DQ,
	output        SDRAM_DQML,
	output        SDRAM_DQMH,
	output        SDRAM_nCS,
	output        SDRAM_nCAS,
	output        SDRAM_nRAS,
	output        SDRAM_nWE,

	input         UART_CTS,
	output        UART_RTS,
	input         UART_RXD,
	output        UART_TXD,
	output        UART_DTR,
	input         UART_DSR,

	input   [6:0] USER_IN,
	output  [6:0] USER_OUT,

	input         OSD_STATUS
);

// ---- unused chassis features -------------------------------------------------
assign VGA_F1 = 0;
assign VGA_SCALER = 0;
assign VGA_DISABLE = 0;
assign HDMI_FREEZE = 0;
assign HDMI_BLACKOUT = 0;
assign HDMI_BOB_DEINT = 0;
assign FB_FORCE_BLANK = 0;
assign {FB_EN, FB_FORMAT, FB_WIDTH, FB_HEIGHT, FB_BASE, FB_STRIDE} = 0;
assign {FB_PAL_CLK, FB_PAL_ADDR, FB_PAL_DOUT, FB_PAL_WR} = 0;
assign DDRAM_CLK = clk_sys;
assign {SD_SCK, SD_MOSI, SD_CS} = 'Z;
assign {UART_RTS, UART_TXD, UART_DTR} = 0;
assign USER_OUT = '1;
assign LED_DISK  = {1'b1, revx_rst_during_dl};   // sticky: core reset overlapped a download (P0022 tell)
assign LED_POWER = 0;
assign LED_USER  = ioctl_download | scan_underflow | dma_overflow;
assign BUTTONS   = 0;

// Revolution X is a horizontal 4:3 shooter.
assign VIDEO_ARX = status[1] ? 12'd16 : 12'd4;
assign VIDEO_ARY = status[1] ? 12'd9  : 12'd3;

assign AUDIO_S   = 1;              // revx_dcs2k emits signed PCM
assign AUDIO_MIX = 0;

assign SDRAM_CLK = clk_sdram;

`include "build_id.v"
localparam CONF_STR = {
	"A.Revolution X;;",
	"O1,Aspect Ratio,4:3,16:9;",
	"O3,Direct Video,Off,On;",
	"O46,Scandoubler Fx,None,HQ2x,CRT 25%,CRT 50%,CRT 75%;",
	"-;",
	"DIP;",
	"-;",
	"TE,Save NVRAM;",
	"TF,Clear NVRAM;",
	"-;",
	// Three light guns (DONOR-DECISION s.3): gun N X/Y from joystick_l_analog N-1, ADC = 0x80-x / 0x80+y.
	"P2,Guns;",
	"P2O[37:36],P1 Gun,L-Analog/USB Gun/Sinden,Mouse,D-Pad;",
	"P2O[39:38],P2 Gun,L-Analog/USB Gun/Sinden,Mouse,D-Pad;",
	"P2O[41:40],P3 Gun,L-Analog/USB Gun/Sinden,Mouse,D-Pad;",
	"P2O[42],Sinden Borders,Off,On;",
	"P2O[43],Gun Crosshair,Off,On;",
	"P2O[45:44],Gun Sensitivity,Normal,High,Low,Lowest;",
	"P2O[47:46],Cursor Players,P1 Only,P1+P2,All Three;",
	"-;",
	"P3,Audio;",
	"P3O[51:48],Music Volume,100%,87.5%,75%,62.5%,50%,37.5%,25%,12.5%,Mute;",
	"P3O[55:52],SFX Volume,100%,87.5%,75%,62.5%,50%,37.5%,25%,12.5%,Mute;",
	"-;",
	"R0,Reset;",
	"J1,Trigger,Action,Start,Coin,P2 Trigger,P2 Action;",
	"jn,A,B,Start,Select;",
	"V,v",`BUILD_DATE
};

////////////////////////////////////////////////////////////////////////////////
// CLOCKS -- clk_sys/clk_sdram = 80 MHz; clk_snd = 12 MHz; clk_cpu = 24 MHz (legacy port)
////////////////////////////////////////////////////////////////////////////////
wire clk_sys, clk_sdram, clk_snd, clk_cpu;
wire locked;

pll pll
(
	.rst(RESET),
	.refclk(CLK_50M),
	.outclk_0(clk_sys),      // 80 MHz
	.outclk_1(clk_sdram),    // 80 MHz, phase-shifted for the SDRAM chip
	.outclk_2(clk_snd),      // 12 MHz
	.outclk_3(clk_cpu),      // 24 MHz (legacy)
	.locked(locked)
);

// pixel-clock enable: 80 MHz / 10 = 8 MHz (X-unit pixel clock, AUDIT.md s.2)
reg [3:0] cediv = 0;
wire ce_pix = (cediv == 4'd0);
always @(posedge clk_sys) cediv <= (cediv == 4'd9) ? 4'd0 : cediv + 4'd1;

// P0019: the 34020 runs on clk_sys with a /3 clock-enable (~26.7 MHz-equivalent pace).
// MAME 0.289 tms34010.h:1010 makes one '020 architectural cycle = clocks/4 (100 ns at the
// real 40 MHz); the /4 rate (20 MHz) measured 0.76 MIPS on silicon and was too slow for the
// game's frame budget (TIMER lockup, handoff 2026-09-08).  /3 is the sanctioned step
// (CPU-internal 16.58 ns fits; the two u_mif launch paths 35.69/36.65 ns fit the 37.5 ns
// setup-3 window, per the /3 analysis in HANDOFF-REVX-TOTAL-20260908.md s.4) and keeps
// every CPU-launched value a 3-clk multicycle destination (setup 3/hold 2).
// 2-bit counter, initialized; cpu_ce pulses on phase 0 (one system edge in three).
reg [1:0] cpu_ce_div = 2'd0;
always @(posedge clk_sys) cpu_ce_div <= (cpu_ce_div == 2'd2) ? 2'd0 : cpu_ce_div + 2'd1;
wire cpu_ce = (cpu_ce_div == 2'd0);

// DAC sample enable for the DCS board: 80 MHz / 2560 = 31.25 kHz.
reg [11:0] dac_div = 0;
wire dac_ce_31250 = (dac_div == 12'd0);
always @(posedge clk_sys) dac_div <= (dac_div == 12'd2559) ? 12'd0 : dac_div + 12'd1;

////////////////////////////////////////////////////////////////////////////////
// HPS IO
////////////////////////////////////////////////////////////////////////////////
wire  [1:0] buttons;
wire [127:0] status;
wire        forced_scandoubler;
wire [21:0] gamma_bus;
wire        direct_video;

wire [24:0] ioctl_addr;
wire  [7:0] ioctl_dout;
wire        ioctl_wr;
wire        ioctl_download;
wire        ioctl_upload;
wire        ioctl_upload_req;
wire  [7:0] ioctl_index;
wire  [7:0] ioctl_din;

wire [15:0] joystick_0, joystick_1, joystick_2, joystick_3;
wire [15:0] joystick_l_analog_0, joystick_l_analog_1, joystick_l_analog_2;

hps_io #(.CONF_STR(CONF_STR)) hps_io
(
	.clk_sys(clk_sys),
	.HPS_BUS(HPS_BUS),

	.buttons(buttons),
	.status(status),
	.status_menumask(direct_video),
	.forced_scandoubler(forced_scandoubler),
	.gamma_bus(gamma_bus),
	.direct_video(direct_video),

	.ioctl_addr(ioctl_addr),
	.ioctl_dout(ioctl_dout),
	.ioctl_wr(ioctl_wr),
	.ioctl_wait(revx_dl_wait),          // revx_loader aggregate backpressure (prog/gfx/DCS)
	.ioctl_download(ioctl_download),
	.ioctl_upload(ioctl_upload),
	.ioctl_upload_req(ioctl_upload_req),
	.ioctl_upload_index(8'd4),          // CMOS/nvram (index 4)
	.ioctl_din(ioctl_din),
	.ioctl_index(ioctl_index),

	.joystick_0(joystick_0),
	.joystick_1(joystick_1),
	.joystick_2(joystick_2),
	.joystick_3(joystick_3),
	.joystick_l_analog_0(joystick_l_analog_0),
	.joystick_l_analog_1(joystick_l_analog_1),
	.joystick_l_analog_2(joystick_l_analog_2)
);

// MRA <switches> DSW word (index 254) -- consumed by revx_memsys on the CPU I/O bus (frontier d).
reg [7:0] sw[2];
initial begin sw[0]=8'hbe; sw[1]=8'hf7; end
always @(posedge clk_sys)
	if (ioctl_wr && (ioctl_index == 254) && !ioctl_addr[24:1]) sw[ioctl_addr[0]] <= ioctl_dout;

////////////////////////////////////////////////////////////////////////////////
// RESET / power-on (P0022)
////////////////////////////////////////////////////////////////////////////////
wire reset = RESET | status[0] | buttons[1] | ~locked;

////////////////////////////////////////////////////////////////////////////////
// VIDEO -- native 34020 raster once programmed, fixed boot-audit raster beforehand.
////////////////////////////////////////////////////////////////////////////////
localparam int HTOTAL=506, VTOTAL=289;
reg [9:0] hc = 0, vc = 0;
always @(posedge clk_sys) if (ce_pix) begin
  if (hc==HTOTAL-1) begin hc<=0; vc<=(vc==VTOTAL-1)?10'd0:vc+10'd1; end
  else hc<=hc+10'd1;
end
wire [15:0] video_hcount, video_vcount, video_heblnk, video_hsblnk, video_veblnk, video_vsblnk;
wire video_hs, video_vs, video_hb, video_vb, video_ready;
wire [15:0] disp_row, disp_col;
wire disp_enable;
wire [17:0] scan_addr;
wire scan_rd, scan_ack, scan_underflow, scan_ce, scan_pixel_miss;
wire [15:0] scan_data, scan_pal_data;
wire [14:0] scan_pal_idx;
wire [7:0] scan_r, scan_g, scan_b;
wire scan_de;
wire sdram_ready;
// REVX_CPU_RESET_BEGIN
// CPU registers reset on every clk_sys edge, including the inactive CE phase.
// Measure the reset-release hold in cpu_ce edges: shift the 4-bit hold only on
// cpu_ce, so core_reset stays asserted for FOUR CE edges (/3 = 150 ns) after the
// raw request clears. Even a one-edge raw pulse then gives the CE-gated reset
// values several full clocks to settle before the first enabled CPU capture.
// The loader's POR-only capture domain is separate.
wire core_reset_raw = reset | ioctl_download | ~sdram_ready;
reg [3:0] core_reset_hold = 4'hf;
always @(posedge clk_sys) begin
  if (core_reset_raw)   core_reset_hold <= 4'hf;
  else if (cpu_ce)      core_reset_hold <= {core_reset_hold[2:0], 1'b0};
end
wire core_reset = core_reset_raw | (|core_reset_hold);
// REVX_CPU_RESET_END

// ---- DIAG v3 SDRAM lane self-test: one-shot arm/hold (kept OUT of the extracted CPU-reset
//      block above so run_revx_cpu_reset.sh's guard stays exact).  Armed on the download-complete
//      edge (falling ioctl_download), it holds the CPU (revx_top) in reset until the on-chip
//      self-test finishes, so the SDRAM word path is exercised BEFORE the CPU's first fetch.  It
//      is a power-on one-shot (cleared by ~locked; never re-armed once done). ----
wire        revx_st_done;
reg         revx_st_hold = 1'b0;
reg         ioctl_dl_q   = 1'b0;
always @(posedge clk_sys) begin
  ioctl_dl_q <= ioctl_download;
  if (~locked)                                            revx_st_hold <= 1'b0; // power-on: unarmed
  else if (ioctl_dl_q & ~ioctl_download & ~revx_st_done)  revx_st_hold <= 1'b1; // download done -> run
  else if (revx_st_done)                                  revx_st_hold <= 1'b0; // self-test done -> release
end
// b4469096 timing hygiene: core_reset_cpu feeds revx_top's whole-board reset (very high fanout).
// Register it on clk_sys so the fanout net is a flop output rather than a wide combinational OR
// cone.  Power-on value = asserted (CPU held from reset); the CPU is held through the entire
// download + self-test window, so one extra clk_sys of reset latency at the release edge is
// harmless.  Kept OUTSIDE the extracted REVX_CPU_RESET block above so run_revx_cpu_reset.sh's
// guard stays exact.  (The b4469096 worst path measured on the shared FIFO was NOT this net --
// it was sdram_phy dout_late; this is the instructed high-fanout-reset hygiene, done alongside.)
reg core_reset_cpu = 1'b1;                          // power-on: asserted
always @(posedge clk_sys) core_reset_cpu <= core_reset | revx_st_hold; // revx_top held through the self-test window
revx_scanout u_scanout (
	.clk(clk_sys), .rst(core_reset | ~video_ready), .ce_pix(ce_pix), .ce_out(scan_ce),
	.disp_enable(disp_enable),
  .hcount(video_hcount), .vcount(video_vcount),
  .heblnk(video_heblnk), .hsblnk(video_hsblnk),
  .veblnk(video_veblnk), .vsblnk(video_vsblnk),
  .rowaddr(disp_row), .coladdr(disp_col),
  .s_rd(scan_rd), .s_addr(scan_addr), .s_data(scan_data), .s_ack(scan_ack),
  .pal_idx(scan_pal_idx), .pal_rgb(scan_pal_data[14:0]),
  .r(scan_r), .g(scan_g), .b(scan_b), .de(scan_de), .hs(), .vs(), .underflow(scan_underflow),
  .diag_pixel_miss(scan_pixel_miss));
// Align true CPU sync/blank outputs with scanout's registered line and palette reads.
reg [3:0] video_timing_q=4'hf, video_timing_qq=4'hf;
always @(posedge clk_sys) begin
  if (ce_pix) video_timing_q <= {video_hs,video_vs,video_hb,video_vb};
  video_timing_qq <= video_timing_q;
end
wire out_ce = video_ready ? scan_ce : ce_pix;
wire base_de = video_ready ? scan_de : ((hc>=101)&&(hc<501)&&(vc>=20)&&(vc<274));
wire base_hb = video_ready ? video_timing_qq[1] : ((hc<101)||(hc>=501));
wire base_vb = video_ready ? video_timing_qq[0] : ((vc<20)||(vc>=274));
wire base_hs = video_ready ? video_timing_qq[3] : (hc<40);
wire base_vs = video_ready ? video_timing_qq[2] : (vc<8);
wire [7:0] base_r = video_ready && disp_enable ? scan_r : 8'd0;
wire [7:0] base_g = video_ready && disp_enable ? scan_g : 8'd0;
wire [7:0] base_b = video_ready && disp_enable ? scan_b : 8'd0;

// ---- guns: analog -> ADC feed + crosshair/border overlay (always instantiated) ----
wire [7:0] an0, an1, an2, an3, an4, an5;
wire [23:0] gun_rgb;
// Visibility selection only: existing bit 43 remains the master Off/On switch.
// New unset bits default to P1; this does not infer who is playing or gate ADCs.
wire [2:0] gun_cursor_mask = (status[47:46] == 2'd0) ? 3'b001 :
                             (status[47:46] == 2'd1) ? 3'b011 : 3'b111;
revx_guns u_guns (
	.clk(clk_sys), .rst(reset),
	.joystick_l_analog_0(joystick_l_analog_0),
	.joystick_l_analog_1(joystick_l_analog_1),
	.joystick_l_analog_2(joystick_l_analog_2),
	// per-player aim source (P2O[37:36]/[39:38]/[41:40]: 0=L-Analog/USB/Sinden, 1=Mouse, 2=D-Pad)
	// + the player's d-pad (raw joystick[3:0] = {up,down,left,right}) for the D-Pad integrator.
	.gun1_src(status[37:36]), .gun2_src(status[39:38]), .gun3_src(status[41:40]),
	.gun1_joy(joystick_0[3:0]), .gun2_joy(joystick_1[3:0]), .gun3_joy(joystick_2[3:0]),
	.an0(an0), .an1(an1), .an2(an2), .an3(an3), .an4(an4), .an5(an5),
	.pxl_cen(out_ce), .hs(base_hs), .vs(base_vs), .de(base_de),
	.gun_en({3{status[43]}} & gun_cursor_mask), .border_en(status[42]), .crosshair_en(status[43]),
	.rgb_in({base_r, base_g, base_b}), .rgb_out(gun_rgb),
	.raster_x(), .raster_y());

// ---- gameplay observer; historical boot snapshots are disabled below ----
wire revx_rst_during_dl, revx_dl_ready, revx_dl_wait;
wire [15:0] dcs_control;
wire [7:0] dcs_response, dcs_host_data;
wire dcs_host_write, dcs_host_read, dcs_board_reset, dcs_output_full, dcs_lint1;

wire [7:0] av_r, av_g, av_b; wire av_hs, av_vs, av_hb, av_vb, av_de;
`ifdef REVX_DIAG_BOOT
// Keep the established build-variant macro, but retire its boot/postcal panel.
// This lower-corner view leaves the game's top HUD untouched. ENV-disabled
// native pixels are counted in the first 64 rows (44-line score band in GXSYS.H).
wire [447:0] revx_video_values;
wire video_diag_accept, video_diag_dpyst_valid;
wire [31:0] video_diag_pc, video_diag_dpyst_value;
wire diag_line_active = video_ready &&
  video_vcount >= video_veblnk && video_vcount < video_vsblnk;
wire diag_line_visible = diag_line_active && disp_enable;
wire [15:0] diag_active_y = video_vcount-video_veblnk;
wire [31:0] diag_fulladdr = {disp_row,disp_col} >> 3;
revx_video_diag_counters u_video_diag_counters (
  .clk(clk_sys), .rst(core_reset_cpu),
  .frame_tick(video_ready && ce_pix && video_hcount==0 && video_vcount==video_vsblnk),
  .first_visible(diag_line_visible && ce_pix && video_hcount==0 && video_vcount==video_veblnk),
  .visible(diag_line_visible),
  .hud_disabled(diag_line_active && !disp_enable && ce_pix && diag_active_y<16'd64 &&
    video_hcount>=video_heblnk && video_hcount<video_hsblnk),
  .active_y(diag_active_y), .row_base(diag_fulladdr[17:0] & 18'h3fe00),
  .pixel_miss(scan_pixel_miss), .scan_req(scan_burst_req), .scan_ack(scan_burst_ack),
  .vram_word_commit(vd_wr && vd_ack && vd_count == 3'd1),
  .vram_chunk_commit((wb_req && wb_ack) || (vd_wr && vd_ack && vd_count > 3'd1)),
  .vram_chunk_count(vd_wr && vd_ack ? {4'd0,vd_count} : wb_count),
  .gfx_beat(gfx_ddr_dready), .dma_busy(dma_busy),
  .src_wait(dma_diag_src_wait), .fb_wait(dma_diag_fb_wait),
  .blit_done(dma_diag_blit_done),
  .cpu_accept(video_diag_accept), .cpu_pc(video_diag_pc),
  .dpyst_value(video_diag_dpyst_value), .dpyst_valid(video_diag_dpyst_valid),
  .values(revx_video_values));
revx_video_diag_overlay u_diag (
    .clk(clk_sys), .ce_pix(out_ce), .rst(reset),
    .values(revx_video_values),
	.g_r(gun_rgb[23:16]), .g_g(gun_rgb[15:8]), .g_b(gun_rgb[7:0]),
	.g_hs(base_hs), .g_vs(base_vs), .g_hb(base_hb), .g_vb(base_vb), .g_de(base_de),
	.vid_r(av_r), .vid_g(av_g), .vid_b(av_b),
	.hsync(av_hs), .vsync(av_vs), .hblank(av_hb), .vblank(av_vb), .de(av_de));
`else
assign {av_r, av_g, av_b} = gun_rgb;
assign av_hs = base_hs; assign av_vs = base_vs; assign av_hb = base_hb; assign av_vb = base_vb; assign av_de = base_de;
`endif

arcade_video #(.WIDTH(512), .DW(24)) arcade_video
(
	.clk_video(clk_sys),
	.ce_pix(out_ce),
	.RGB_in({av_r, av_g, av_b}),
	.HBlank(av_hb),
	.VBlank(av_vb),
	.HSync(av_hs),
	.VSync(av_vs),

	.CLK_VIDEO(CLK_VIDEO),
	.CE_PIXEL(CE_PIXEL),
	.VGA_R(VGA_R),
	.VGA_G(VGA_G),
	.VGA_B(VGA_B),
	.VGA_HS(VGA_HS),
	.VGA_VS(VGA_VS),
	.VGA_DE(VGA_DE),
	.VGA_SL(VGA_SL),

	.fx(status[6:4]),
	.forced_scandoubler(forced_scandoubler),
	.gamma_bus(gamma_bus)
);

////////////////////////////////////////////////////////////////////////////////
// CORE -- revx_top (real TMS34020 default) + loader + backends
////////////////////////////////////////////////////////////////////////////////
// Physical memory partition (16-bit word addresses, 8 MiB / one MT48 bank, SD_AW=22):
// RAM 0x000000..0fffff (2 MiB, midxunit.cpp:511), ROM 100000..1fffff (2 MiB), canonical
// 16-bit VRAM pixels 200000..27ffff.  CPU data/color views, DMA and scanout share this one
// store.  RAM was previously 1 MiB (0..07ffff) which aliased the code copy dest 0x20800000
// onto the 0x20000000 scratch and hung the boot (see revx_backends header + THIS commit).
wire [20:0] sd_addr; wire [15:0] sd_din; wire [1:0] sd_be; wire sd_rd,sd_wr; wire [15:0] sd_dout; wire sd_ack;
wire [18:0] vd_addr; wire [15:0] vd_din; wire [1:0] vd_be;
wire vd_rd,vd_wr; wire [15:0] vd_dout; wire vd_ack;
wire [2:0] vd_count; wire [63:0] vd_words; wire vd_reverse;
wire wb_req, wb_ack;
wire [18:0] wb_addr;
wire [6:0] wb_count;
wire [1023:0] wb_data;
wire rb_req, rb_ack;
wire [20:0] rb_addr;
wire [4:0] rb_count;
wire [255:0] rb_dout;
`ifdef REVX_VRAM_LB
wire vlb_rb_req, vlb_rb_ack;
wire [18:0] vlb_rb_addr;
wire [4:0] vlb_rb_count;
wire [255:0] vlb_rb_dout;
// phys rb mux: the CPU fetch/data fills (21-bit space) win over the vlb fill
// (canonical VRAM words + the 0x200000 chip base). Both are CPU stalls.
wire prb_req, prb_ack;
wire [21:0] prb_addr;
wire [4:0] prb_count;
wire [255:0] prb_dout;
revx_read_chunk_mux #(.AW(22)) u_vram_chunk_mux (
  .clk(clk_sys), .rst(core_reset_cpu),
  .a_req(rb_req), .a_addr({1'b0,rb_addr}), .a_count(rb_count),
  .a_data(rb_dout), .a_ack(rb_ack),
  .b_req(vlb_rb_req), .b_addr(22'h200000 + {3'd0,vlb_rb_addr}),
  .b_count(vlb_rb_count), .b_data(vlb_rb_dout), .b_ack(vlb_rb_ack),
  .req(prb_req), .addr(prb_addr), .count(prb_count), .data(prb_dout), .ack(prb_ack));
`endif
`ifdef REVX_BLMOVE_BURST
wire wb2_req, wb2_ack;
wire [20:0] wb2_addr;
wire [4:0] wb2_count;
wire [255:0] wb2_data;
`endif
wire scan_burst_req, scan_burst_ack;
wire [17:0] scan_burst_addr;
wire [255:0] scan_burst_data;
revx_scan_word_cache u_scan_words (
  .clk(clk_sys), .rst(core_reset | ~video_ready),
  .req(scan_rd), .addr(scan_addr), .data(scan_data), .ack(scan_ack),
  .burst_req(scan_burst_req), .burst_addr(scan_burst_addr),
  .burst_ack(scan_burst_ack), .burst_data(scan_burst_data));
revx_sdram_phys #(.SD_AW(22), .SCAN_BURST(1'b1)) u_sdram (
  .clk(clk_sys),
  .s_addr(22'h200000+{4'd0,scan_burst_addr}), .s_rd(scan_burst_req), .s_dout(), .s_ack(scan_burst_ack),
  .s_chunk_dout(scan_burst_data),
  .a_addr({1'b0,sd_addr}), .a_din(sd_din), .a_be(sd_be), .a_rd(sd_rd), .a_wr(sd_wr), .a_dout(sd_dout), .a_ack(sd_ack),
  .vd_addr(22'h200000+{3'd0,vd_addr}), .vd_din(vd_din), .vd_be(vd_be), .vd_rd(vd_rd), .vd_wr(vd_wr), .vd_dout(vd_dout), .vd_ack(vd_ack),
  .vd_count(vd_count), .vd_words(vd_words), .vd_reverse(vd_reverse),
  .vc_addr(22'd0), .vc_din(16'd0), .vc_be(2'd0), .vc_rd(1'b0), .vc_wr(1'b0), .vc_dout(), .vc_ack(),
  .wb_req(wb_req), .wb_addr(22'h200000+{3'd0,wb_addr}),
  .wb_count(wb_count), .wb_data(wb_data), .wb_ack(wb_ack),
`ifdef REVX_VRAM_LB
  .rb_req(prb_req), .rb_addr(prb_addr), .rb_count(prb_count), .rb_dout(prb_dout), .rb_ack(prb_ack),
`else
  .rb_req(rb_req), .rb_addr({1'b0,rb_addr}), .rb_count(rb_count), .rb_dout(rb_dout), .rb_ack(rb_ack),
`endif
`ifdef REVX_BLMOVE_BURST
  .wb2_req(wb2_req), .wb2_addr({1'b0,wb2_addr}), .wb2_count(wb2_count), .wb2_data(wb2_data), .wb2_ack(wb2_ack),
`endif
  .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA),
  .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH), .SDRAM_nCS(SDRAM_nCS),
  .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nCAS(SDRAM_nCAS), .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE),
  .ready(sdram_ready),
  .st_arm(revx_st_hold), .st_done(revx_st_done),
  .st_t1_lo(), .st_t1_hi(), .st_t2_got(), .st_t3_got1(), .st_t3_got2(),
  .st_t4_refresh(), .st_status());

wire dma_reg_we; wire [3:0] dma_reg_addr; wire [15:0] dma_reg_wdata;
wire [2:0] dma_reg_pair; wire [31:0] dma_pair_rdata;
wire [15:0] dma_palette;
wire dma_irq, dma_busy, dma_overflow;
wire dma_diag_src_wait, dma_diag_fb_wait, dma_diag_blit_done;
wire [8:0] dma_diag_q_highwater;
wire dma_pixel_req,dma_pixel_ack; wire [18:0] dma_pixel_addr; wire [15:0] dma_pixel_data;
wire [2:0] dma_pixel_count; wire [63:0] dma_pixel_words; wire dma_pixel_reverse;
wire dma_mem_req,dma_mem_we,dma_mem_ack; wire [31:0] dma_mem_addr,dma_mem_wdata,dma_mem_rdata; wire [3:0] dma_mem_be;
revx_dma_bus #(.FB_GROUP_MAX(4)) u_dma_bus (
  .clk(clk_sys), .rst(core_reset), .reg_we(dma_reg_we), .reg_addr(dma_reg_addr), .reg_wdata(dma_reg_wdata),
  .reg_pair(dma_reg_pair), .reg_pair_rdata(dma_pair_rdata), .irq(dma_irq), .busy(dma_busy), .overflow(dma_overflow),
  .dma_palette(dma_palette),
  .diag_src_wait(dma_diag_src_wait), .diag_fb_wait(dma_diag_fb_wait),
  .diag_blit_done(dma_diag_blit_done), .diag_q_highwater(dma_diag_q_highwater),
  .mem_req(dma_mem_req), .mem_we(dma_mem_we), .mem_addr(dma_mem_addr), .mem_wdata(dma_mem_wdata), .mem_be(dma_mem_be),
  .mem_ack(dma_mem_ack), .mem_rdata(dma_mem_rdata),
  .pixel_req(dma_pixel_req), .pixel_addr(dma_pixel_addr), .pixel_data(dma_pixel_data), .pixel_ack(dma_pixel_ack),
  .pixel_count(dma_pixel_count), .pixel_words(dma_pixel_words), .pixel_reverse(dma_pixel_reverse));
// Input bits follow MAME 0.289 midxunit.cpp:539-571; original buttons stay at 4..7.
// P1 slots 8/9 are P2 Trigger/Action aliases (MRA defaults L/R) for calibration.
// Preserve the real P2 controller; either source can assert its active-low input.
wire [31:0] in0 = ~((32'(joystick_0[4])<<4) | (32'(joystick_0[5])<<5) |
                       (32'(joystick_1[4] | joystick_0[8])<<12) |
                       (32'(joystick_1[5] | joystick_0[9])<<13));
wire [31:0] in1 = ~((32'(joystick_2[4])<<4) | (32'(joystick_2[5])<<5));
wire [31:0] in2 = ~((32'(joystick_0[7])<<0) | (32'(joystick_1[7])<<1) |
                       (32'(joystick_0[6])<<2) | (32'(joystick_1[6])<<5) |
                       (32'(joystick_2[7])<<7) | (32'(joystick_2[6])<<9));

// gfx DDR3 master (revx_top) + DCS DDR3 master (wolf_dcs_ddr_top) share DDRAM_* via wolf_ddr3_arb.
wire [28:0] gfx_ddr_addr;  wire [7:0] gfx_ddr_burst; wire gfx_ddr_rd, gfx_ddr_we;
wire [63:0] gfx_ddr_din;   wire [7:0] gfx_ddr_be;    wire gfx_ddr_busy; wire [63:0] gfx_ddr_dout; wire gfx_ddr_dready;
wire [28:0] dcs_ddr_addr;  wire [7:0] dcs_ddr_burst; wire dcs_ddr_rd, dcs_ddr_we;
wire [63:0] dcs_ddr_din;   wire [7:0] dcs_ddr_be;    wire dcs_ddr_busy; wire [63:0] dcs_ddr_dout; wire dcs_ddr_dready;

// DCS sound-ROM download (revx_loader -> wolf_dcs_ddr_top)
wire        dcs_dl_wr;  wire [22:0] dcs_dl_addr; wire [7:0] dcs_dl_data; wire dcs_dl_ack; wire dcs_dl_busy;
// DCS ADSP cache-fill port (revx_dcs2k -> wolf_dcs_ddr_top)
wire        dcs_rom_req; wire [19:0] dcs_rom_addr; wire dcs_rom_rdy; wire [63:0] dcs_rom_q;

reg  rst_pon_m = 1'b1, sdram_por = 1'b1;
always @(posedge clk_sys) begin rst_pon_m <= ~locked; sdram_por <= rst_pon_m; end

revx_top #(.SD_AW(21), .VSD_AW(19), .ROM_SDBASE(21'h100000), .RESET_PC(32'hFFFDE000),
  .SRT_WRITE_CHUNKS(1'b1), .POSTCAL_DIAG(1'b0), .QUIET_BOOT_DIAG(1'b1)) revx_top (
	.clk(clk_sys), .reset(core_reset_cpu), .pll_locked(locked), .cpu_ce(cpu_ce),

	.ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index),
	.ioctl_addr(ioctl_addr), .ioctl_dout(ioctl_dout), .dl_ready(revx_dl_ready), .dl_wait(revx_dl_wait),
	.ioctl_upload(ioctl_upload), .ioctl_din(ioctl_din), .ioctl_upload_req(ioctl_upload_req),
	.manual_save(status[14]), .clear_nvram(status[15]),
	.dcs_dl_wr(dcs_dl_wr), .dcs_dl_addr(dcs_dl_addr), .dcs_dl_data(dcs_dl_data), .dcs_dl_ack(dcs_dl_ack),
	.profile_byte(), .profile_valid(),

    .dbg_rst_during_dl(revx_rst_during_dl),
    .dbg_postcal_early(), .dbg_postcal_final(),
`ifdef REVX_DIAG_BOOT
    .cpu_pc(video_diag_pc), .diag_opcode_accept(video_diag_accept),
    .diag_dpyst_value(video_diag_dpyst_value), .diag_dpyst_valid(video_diag_dpyst_valid),
`endif

	.dma_irq(dma_irq),
  .ce_pix(ce_pix), .in0(in0), .in1(in1), .in2(in2), .dsw({16'hffff,sw[1],sw[0]}),
  .an0(an0), .an1(an1), .an2(an2), .an3(an3), .an4(an4), .an5(an5),
  .dcs_ctrl(dcs_control), .dcs_data_in(dcs_response), .dcs_output_full(dcs_output_full),
  .dcs_data_w(dcs_host_write), .dcs_data_o(dcs_host_data), .dcs_data_rd(dcs_host_read),
  .dcs_reset(dcs_board_reset), .dcs_lint1(dcs_lint1),
  .sysctrl0(), .sysctrl1(), .cmos_write_enable(), .gun_recoil(), .gun_led(), .watchdog_kick(),
  .dma_reg_we(dma_reg_we), .dma_reg_addr(dma_reg_addr), .dma_reg_wdata(dma_reg_wdata),
  .dma_reg_pair(dma_reg_pair), .dma_pair_rdata(dma_pair_rdata),
  .dma_palette(dma_palette),
  .dma_pixel_req(dma_pixel_req), .dma_pixel_addr(dma_pixel_addr), .dma_pixel_data(dma_pixel_data), .dma_pixel_ack(dma_pixel_ack),
  .dma_pixel_count(dma_pixel_count), .dma_pixel_words(dma_pixel_words), .dma_pixel_reverse(dma_pixel_reverse),
  .dma_mem_req(dma_mem_req), .dma_mem_we(dma_mem_we), .dma_mem_addr(dma_mem_addr),
  .dma_mem_wdata(dma_mem_wdata), .dma_mem_be(dma_mem_be), .dma_mem_ack(dma_mem_ack), .dma_mem_rdata(dma_mem_rdata),
  .pal_rd_idx(scan_pal_idx), .pal_rd_data(scan_pal_data),
  .disp_row(disp_row), .disp_col(disp_col), .disp_enable(disp_enable),
  .video_hcount(video_hcount), .video_vcount(video_vcount),
  .video_heblnk(video_heblnk), .video_hsblnk(video_hsblnk), .video_veblnk(video_veblnk), .video_vsblnk(video_vsblnk),
  .video_hs(video_hs), .video_vs(video_vs), .video_hb(video_hb), .video_vb(video_vb), .video_ready(video_ready),
	.cmd_req(1'b0), .cmd_we(1'b0), .cmd_addr(32'd0), .cmd_be(4'hf), .cmd_wdata(32'd0),
	.cmd_rdata(), .cmd_done(),                                         // real CPU drives the bus; cmd unused
	.scan_start(1'b0), .scan_rowaddr(16'd0), .scan_coladdr(16'd0),
	.scan_pixel(), .scan_done(),                                       // legacy one-shot scan test port unused


	.sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
	.sd_dout(sd_dout), .sd_ack(sd_ack),
	.vd_addr(vd_addr), .vd_din(vd_din), .vd_be(vd_be), .vd_rd(vd_rd), .vd_wr(vd_wr),
	.vd_dout(vd_dout), .vd_ack(vd_ack),
  .vd_count(vd_count), .vd_words(vd_words), .vd_reverse(vd_reverse),
			.wb_req(wb_req), .wb_addr(wb_addr), .wb_count(wb_count), .wb_data(wb_data), .wb_ack(wb_ack),
			.rb_req(rb_req), .rb_addr(rb_addr), .rb_count(rb_count), .rb_dout(rb_dout), .rb_ack(rb_ack),
		`ifdef REVX_VRAM_LB
			.vlb_rb_req(vlb_rb_req), .vlb_rb_addr(vlb_rb_addr), .vlb_rb_count(vlb_rb_count),
			.vlb_rb_dout(vlb_rb_dout), .vlb_rb_ack(vlb_rb_ack),
		`endif
	`ifdef REVX_BLMOVE_BURST
		.wb2_req(wb2_req), .wb2_addr(wb2_addr), .wb2_count(wb2_count), .wb2_data(wb2_data), .wb2_ack(wb2_ack),
	`endif
	.vc_addr(), .vc_din(), .vc_be(), .vc_rd(), .vc_wr(),
	.vc_dout(16'd0), .vc_ack(1'b0),
	.gfx_ddram_addr(gfx_ddr_addr), .gfx_ddram_burstcnt(gfx_ddr_burst), .gfx_ddram_rd(gfx_ddr_rd),
	.gfx_ddram_we(gfx_ddr_we), .gfx_ddram_din(gfx_ddr_din), .gfx_ddram_be(gfx_ddr_be),
	.gfx_ddram_busy(gfx_ddr_busy), .gfx_ddram_dout(gfx_ddr_dout), .gfx_ddram_dout_ready(gfx_ddr_dready));

// ---- DDR3 arbiter: A = DCS (latency-sensitive cache fill), B = gfx (bulk) ----
wolf_ddr3_arb u_ddr3_arb (
	.clk(clk_sys), .b_allow(1'b1),
	.a_addr(dcs_ddr_addr), .a_burstcnt(dcs_ddr_burst), .a_rd(dcs_ddr_rd), .a_we(dcs_ddr_we),
	.a_din(dcs_ddr_din), .a_be(dcs_ddr_be), .a_busy(dcs_ddr_busy),
	.a_dout(dcs_ddr_dout), .a_dout_ready(dcs_ddr_dready),
	.b_addr(gfx_ddr_addr), .b_burstcnt(gfx_ddr_burst), .b_rd(gfx_ddr_rd), .b_we(gfx_ddr_we),
	.b_din(gfx_ddr_din), .b_be(gfx_ddr_be), .b_busy(gfx_ddr_busy),
	.b_dout(gfx_ddr_dout), .b_dout_ready(gfx_ddr_dready),
	.ddram_addr(DDRAM_ADDR), .ddram_burstcnt(DDRAM_BURSTCNT), .ddram_rd(DDRAM_RD), .ddram_we(DDRAM_WE),
	.ddram_din(DDRAM_DIN), .ddram_be(DDRAM_BE), .ddram_busy(DDRAM_BUSY),
	.ddram_dout(DDRAM_DOUT), .ddram_dout_ready(DDRAM_DOUT_READY));

// ---- DCS sound-ROM DDR3 backend + DCS-2K core ----
// RevX downloads eight 512 KiB chips densely; the ADSP retains 1 MiB slots.
wolf_dcs_ddr_top #(.PACKED_512K(1'b1)) u_dcs_ddr (
	.clk(clk_sys), .sdram_por(sdram_por),
	.dl_wr(dcs_dl_wr), .dl_addr(dcs_dl_addr), .dl_data(dcs_dl_data), .dl_ack(dcs_dl_ack), .dl_busy(dcs_dl_busy),
	.rom_req(dcs_rom_req), .rom_addr(dcs_rom_addr), .rom_rdy(dcs_rom_rdy), .rom_q(dcs_rom_q),
	.ddram_addr(dcs_ddr_addr), .ddram_burstcnt(dcs_ddr_burst), .ddram_rd(dcs_ddr_rd), .ddram_we(dcs_ddr_we),
	.ddram_din(dcs_ddr_din), .ddram_be(dcs_ddr_be), .ddram_busy(dcs_ddr_busy),
	.ddram_dout(dcs_ddr_dout), .ddram_dout_ready(dcs_ddr_dready));

wire signed [15:0] dcs_audio; wire dcs_audio_ce;
revx_dcs2k #(.UART_HOST(1), .MIXER_GAIN(1)) u_dcs2k (
	.clk(clk_sys), .rst(core_reset | dcs_board_reset), .dac_ce_31250(dac_ce_31250),
  .music_attenuation(status[51:48]), .sfx_attenuation(status[55:52]),
  .cpu_status_rd(1'b0), .cpu_data_rd(dcs_host_read), .cpu_data_wr(dcs_host_write), .cpu_data_offset(1'b1),
  .cpu_wdata({8'd0,dcs_host_data}), .cpu_byte_en(2'b01), .cpu_status_rdata(), .cpu_data_rdata(),
  .uart_control(dcs_control), .uart_response(dcs_response), .uart_output_full(dcs_output_full),
	.rom_req(dcs_rom_req), .rom_addr(dcs_rom_addr), .rom_ready(dcs_rom_rdy), .rom_rdata(dcs_rom_q),
	.audio(dcs_audio), .audio_ce(dcs_audio_ce), .audio_underrun(), .audio_overrun(),
	.adsp_pc(), .adsp_valid(), .adsp_unimplemented());

wolf_audio_guard u_audio_guard (
	.clk(clk_sys),
	.hold_zero(reset | ioctl_download),   // silent through reset + download; DCS internal reset mutes the rest
	.audio_l_in(dcs_audio), .audio_r_in(dcs_audio),
	.audio_l_out(AUDIO_L), .audio_r_out(AUDIO_R));

endmodule
