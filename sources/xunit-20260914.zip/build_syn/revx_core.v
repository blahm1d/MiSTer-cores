`default_nettype none
`default_nettype wire
`default_nettype none
`default_nettype wire
`default_nettype none
module tms34010_alu (
	op,
	a,
	b,
	cin,
	result,
	flags
);
	reg _sv2v_0;
	input wire [3:0] op;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] a;
	input wire [31:0] b;
	input wire cin;
	output reg [31:0] result;
	output reg [3:0] flags;
	wire [tms34010_pkg_DATA_WIDTH:0] add_ext;
	wire [tms34010_pkg_DATA_WIDTH:0] sub_ext;
	wire [31:0] not_b;
	wire add_cin;
	wire sub_cin;
	assign not_b = ~b;
	assign add_cin = (op == 4'd1 ? cin : 1'b0);
	assign sub_cin = (op == 4'd3 ? !cin : 1'b1);
	assign add_ext = ({1'b0, a} + {1'b0, b}) + {{tms34010_pkg_DATA_WIDTH {1'b0}}, add_cin};
	assign sub_ext = ({1'b0, a} + {1'b0, not_b}) + {{tms34010_pkg_DATA_WIDTH {1'b0}}, sub_cin};
	wire [31:0] add_result;
	wire [31:0] sub_result;
	wire [31:0] neg_result;
	wire [tms34010_pkg_DATA_WIDTH:0] neg_ext;
	wire [31:0] not_a;
	assign add_result = add_ext[31:0];
	assign sub_result = sub_ext[31:0];
	assign not_a = ~a;
	assign neg_ext = ({1'b0, {tms34010_pkg_DATA_WIDTH {1'b0}}} + {1'b0, not_a}) + 33'd1;
	assign neg_result = neg_ext[31:0];
	always @(*) begin
		if (_sv2v_0)
			;
		result = 1'sb0;
		flags[3] = 1'b0;
		flags[2] = 1'b0;
		flags[1] = 1'b0;
		flags[0] = 1'b0;
		(* full_case, parallel_case *)
		case (op)
			4'd0, 4'd1: begin
				result = add_result;
				flags[3] = add_result[31];
				flags[1] = add_result == {32 {1'sb0}};
				flags[2] = not_a < b;
				flags[0] = (a[31] == b[31]) && (add_result[31] != a[31]);
			end
			4'd2, 4'd3, 4'd4: begin
				result = sub_result;
				flags[3] = sub_result[31];
				flags[1] = sub_result == {32 {1'sb0}};
				flags[2] = b > a;
				flags[0] = (a[31] != b[31]) && (sub_result[31] != a[31]);
			end
			4'd10: begin
				result = neg_result;
				flags[3] = neg_result[31];
				flags[1] = neg_result == {32 {1'sb0}};
				flags[2] = !neg_ext[tms34010_pkg_DATA_WIDTH];
				flags[0] = a[31] && neg_result[31];
			end
			4'd5: begin
				result = a & b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd6: begin
				result = a & ~b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd7: begin
				result = a | b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd8: begin
				result = a ^ b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd9: begin
				result = ~a;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd11: begin
				result = a;
				flags[3] = a[31];
				flags[1] = a == {32 {1'sb0}};
			end
			4'd12: begin
				result = b;
				flags[3] = b[31];
				flags[1] = b == {32 {1'sb0}};
			end
			4'd13: begin
				result = (neg_result[31] ? a : neg_result);
				flags[3] = neg_result[31];
				flags[1] = a == {32 {1'sb0}};
				flags[2] = 1'b0;
				flags[0] = a == 32'h80000000;
			end
			default:
				;
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_blmove (
	clk,
	rst,
	ce,
	start,
	s_bit,
	d_bit,
	src_in,
	dst_in,
	bits_in,
	b0_o,
	b2_o,
	b7_o,
	align_err_o,
	busy_o,
	done_o,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	brb_req,
	brb_addr,
	brb_count,
	brb_dout,
	brb_ack,
	bwb_req,
	bwb_addr,
	bwb_count,
	bwb_data,
	bwb_ack,
	burst_ok_in
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire ce;
	input wire start;
	input wire s_bit;
	input wire d_bit;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] src_in;
	input wire [31:0] dst_in;
	input wire [31:0] bits_in;
	output wire [31:0] b0_o;
	output wire [31:0] b2_o;
	output wire [31:0] b7_o;
	output wire align_err_o;
	output wire busy_o;
	output reg done_o;
	output reg mem_req;
	output reg mem_we;
	output reg [31:0] mem_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	output reg [5:0] mem_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	output reg [31:0] mem_wdata;
	input wire [31:0] mem_rdata;
	input wire mem_ack;
	output reg brb_req;
	output reg [31:0] brb_addr;
	output reg [4:0] brb_count;
	input wire [255:0] brb_dout;
	input wire brb_ack;
	output reg bwb_req;
	output reg [31:0] bwb_addr;
	output reg [4:0] bwb_count;
	output reg [255:0] bwb_data;
	input wire bwb_ack;
	input wire burst_ok_in;
	reg [3:0] st_q;
	reg [3:0] st_d;
	reg [31:0] src_q;
	reg [31:0] dst_q;
	reg [31:0] bits_q;
	reg [31:0] word_q;
	reg align_q;
	reg [255:0] chunk_q;
	wire [31:0] burst_distance = dst_q - src_q;
	function automatic signed [31:0] sv2v_cast_DEBC9_signed;
		input reg signed [31:0] inp;
		sv2v_cast_DEBC9_signed = inp;
	endfunction
	wire burst_safe = (((((burst_ok_in && (bits_q >= sv2v_cast_DEBC9_signed(256))) && (src_q[3:0] == 0)) && (dst_q[3:0] == 0)) && (src_q[12:4] <= 9'd496)) && (dst_q[12:4] <= 9'd496)) && !((dst_q > src_q) && (burst_distance < sv2v_cast_DEBC9_signed(256)));
	wire [5:0] tail_sz = bits_q[5:0];
	localparam [0:0] TAIL_EN = 1'b1;
	localparam [0:0] BURST_ASCEND = 1'b1;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		st_d = st_q;
		mem_req = 1'b0;
		mem_we = 1'b0;
		mem_addr = 1'sb0;
		mem_size = 1'sb0;
		mem_wdata = 1'sb0;
		brb_req = 1'b0;
		brb_addr = src_q;
		brb_count = 1'sb0;
		bwb_req = 1'b0;
		bwb_addr = dst_q;
		bwb_count = 1'sb0;
		bwb_data = 1'sb0;
		(* full_case, parallel_case *)
		case (st_q)
			4'd0:
				if (start)
					st_d = (bits_in >= sv2v_cast_DEBC9_signed(16) ? 4'd8 : (bits_in != {32 {1'sb0}} ? 4'd3 : 4'd5));
			4'd1: begin
				mem_req = 1'b1;
				mem_we = 1'b0;
				mem_addr = src_q;
				mem_size = sv2v_cast_13C0F_signed(16);
				if (mem_ack)
					st_d = 4'd2;
			end
			4'd2: begin
				mem_req = 1'b1;
				mem_we = 1'b1;
				mem_addr = dst_q;
				mem_size = sv2v_cast_13C0F_signed(16);
				mem_wdata = word_q;
				if (mem_ack) begin
					if ((bits_q - sv2v_cast_DEBC9_signed(16)) >= sv2v_cast_DEBC9_signed(16))
						st_d = 4'd8;
					else if ((bits_q - sv2v_cast_DEBC9_signed(16)) >= sv2v_cast_DEBC9_signed(16))
						st_d = 4'd1;
					else if (TAIL_EN && ((bits_q - sv2v_cast_DEBC9_signed(16)) != {32 {1'sb0}}))
						st_d = 4'd3;
					else
						st_d = 4'd5;
				end
			end
			4'd8: st_d = (burst_safe ? 4'd6 : 4'd1);
			4'd6: begin
				brb_req = 1'b1;
				brb_addr = src_q;
				brb_count = 5'd16;
				if (brb_ack)
					st_d = 4'd7;
			end
			4'd7: begin
				bwb_req = 1'b1;
				bwb_addr = dst_q;
				bwb_count = 5'd16;
				bwb_data = (BURST_ASCEND ? chunk_q : {chunk_q[15:0], chunk_q[31:16], chunk_q[47:32], chunk_q[63:48], chunk_q[79:64], chunk_q[95:80], chunk_q[111:96], chunk_q[127:112], chunk_q[143:128], chunk_q[159:144], chunk_q[175:160], chunk_q[191:176], chunk_q[207:192], chunk_q[223:208], chunk_q[239:224], chunk_q[255:240]});
				if (bwb_ack) begin
					if ((bits_q - sv2v_cast_DEBC9_signed(256)) >= sv2v_cast_DEBC9_signed(16))
						st_d = 4'd8;
					else if (TAIL_EN && ((bits_q - sv2v_cast_DEBC9_signed(256)) != {32 {1'sb0}}))
						st_d = 4'd3;
					else
						st_d = 4'd5;
				end
			end
			4'd3: begin
				mem_req = 1'b1;
				mem_we = 1'b0;
				mem_addr = src_q;
				mem_size = tail_sz;
				if (mem_ack)
					st_d = 4'd4;
			end
			4'd4: begin
				mem_req = 1'b1;
				mem_we = 1'b1;
				mem_addr = dst_q;
				mem_size = tail_sz;
				mem_wdata = word_q;
				if (mem_ack)
					st_d = 4'd5;
			end
			4'd5: st_d = 4'd0;
			default: st_d = 4'd0;
		endcase
	end
	always @(posedge clk)
		if ((ce !== 1'b0) || rst) begin
			if (rst) begin
				st_q <= 4'd0;
				src_q <= 1'sb0;
				dst_q <= 1'sb0;
				bits_q <= 1'sb0;
				word_q <= 1'sb0;
				align_q <= 1'b0;
				done_o <= 1'b0;
			end
			else begin
				done_o <= 1'b0;
				if ((st_q == 4'd0) && start) begin
					src_q <= src_in;
					dst_q <= dst_in;
					bits_q <= bits_in;
					align_q <= (!s_bit && (src_in[3:0] != 4'h0)) || (!d_bit && (dst_in[3:0] != 4'h0));
				end
				if ((st_q == 4'd1) && mem_ack)
					word_q <= mem_rdata;
				if ((st_q == 4'd3) && mem_ack)
					word_q <= mem_rdata;
				if ((st_q == 4'd6) && brb_ack)
					chunk_q <= brb_dout;
				if ((st_q == 4'd7) && bwb_ack) begin
					src_q <= src_q + sv2v_cast_DEBC9_signed(256);
					dst_q <= dst_q + sv2v_cast_DEBC9_signed(256);
					bits_q <= bits_q - sv2v_cast_DEBC9_signed(256);
				end
				if ((st_q == 4'd2) && mem_ack) begin
					src_q <= src_q + sv2v_cast_DEBC9_signed(16);
					dst_q <= dst_q + sv2v_cast_DEBC9_signed(16);
					bits_q <= bits_q - sv2v_cast_DEBC9_signed(16);
				end
				if ((st_q == 4'd4) && mem_ack) begin
					src_q <= src_q + {26'd0, tail_sz};
					dst_q <= dst_q + {26'd0, tail_sz};
					bits_q <= 1'sb0;
				end
				if (st_q == 4'd5)
					done_o <= 1'b1;
				st_q <= st_d;
			end
		end
	assign b0_o = src_q;
	assign b2_o = dst_q;
	assign b7_o = bits_q;
	assign align_err_o = align_q;
	assign busy_o = st_q != 4'd0;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_conv020 (
	conv_data,
	conv_value
);
	localparam [0:0] tms34010_pkg_IS_34020 = 1'b1;
	parameter [0:0] P_IS_34020 = tms34010_pkg_IS_34020;
	input wire [15:0] conv_data;
	output wire [31:0] conv_value;
	wire [15:0] data_eff;
	assign data_eff = conv_data;
	function automatic [31:0] tms34010_pkg_conv020_decode;
		input reg [15:0] data;
		reg [4:0] n0;
		reg [4:0] n1;
		begin
			n0 = ~data & 5'h1f;
			n1 = ~(data >> 8) & 5'h1f;
			if (|(data & 16'h001f)) begin
				if (|(data & 16'h1f00))
					tms34010_pkg_conv020_decode = (32'd1 << n0) + (32'd1 << n1);
				else
					tms34010_pkg_conv020_decode = 32'd1 << n0;
			end
			else
				tms34010_pkg_conv020_decode = {16'h0000, data};
		end
	endfunction
	assign conv_value = tms34010_pkg_conv020_decode(data_eff);
endmodule
`default_nettype wire
`default_nettype none
module tms34010_core (
	clk,
	ce_cpu,
	ce_pix,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_srt,
	fetch_access_o,
	mem_rdata,
	mem_ack,
	blmove_brb_req,
	blmove_brb_addr,
	blmove_brb_count,
	blmove_brb_dout,
	blmove_brb_ack,
	blmove_bwb_req,
	blmove_bwb_addr,
	blmove_bwb_count,
	blmove_bwb_data,
	blmove_bwb_ack,
	blmove_burst_ok,
	state_o,
	pc_o,
	instr_word_o,
	illegal_opcode_o,
	instruction_start_o,
	instruction_retire_o,
	instruction_cycles_o,
	instruction_cycles_valid_o,
	instruction_class_o,
	dpystrt_o,
	dbg_dpyst_value_o,
	dbg_dpyst_valid_o,
	dpyctl_o,
	dpytap_o,
	dpyadr_o,
	display_row_o,
	display_col_o,
	display_yoffset_o,
	display_enable_o,
	display_blank_o,
	vblank_start_o,
	timing_start_o,
	lint1_in,
	lint2_in,
	video_hcount_o,
	video_vcount_o,
	video_heblnk_o,
	video_hsblnk_o,
	video_veblnk_o,
	video_vsblnk_o,
	video_hs_o,
	video_vs_o,
	video_hb_o,
	video_vb_o,
	video_ready_o,
	dbg_int_entry_o,
	dbg_int_pc_o,
	dbg_int_vec_addr_o,
	dbg_int_vec_value_o,
	dbg_intpend_o,
	dbg_intenb_o,
	dbg_disp_int_o,
	dbg_st_ie_o,
	dbg_int_return_o,
	dbg_int_begin_o
);
	reg _sv2v_0;
	input wire clk;
	input wire ce_cpu;
	input wire ce_pix;
	input wire rst;
	output reg mem_req;
	output wire mem_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	output reg [31:0] mem_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	output reg [5:0] mem_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	output reg [31:0] mem_wdata;
	output reg mem_srt;
	output wire fetch_access_o;
	input wire [31:0] mem_rdata;
	input wire mem_ack;
	output wire blmove_brb_req;
	output wire [31:0] blmove_brb_addr;
	output wire [4:0] blmove_brb_count;
	input wire [255:0] blmove_brb_dout;
	input wire blmove_brb_ack;
	output wire blmove_bwb_req;
	output wire [31:0] blmove_bwb_addr;
	output wire [4:0] blmove_bwb_count;
	output wire [255:0] blmove_bwb_data;
	input wire blmove_bwb_ack;
	input wire blmove_burst_ok;
	output wire [5:0] state_o;
	output wire [31:0] pc_o;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	output wire [15:0] instr_word_o;
	output wire illegal_opcode_o;
	output reg instruction_start_o;
	output reg instruction_retire_o;
	output wire [15:0] instruction_cycles_o;
	output wire instruction_cycles_valid_o;
	output wire [6:0] instruction_class_o;
	output wire [15:0] dpystrt_o;
	output wire [31:0] dbg_dpyst_value_o;
	output wire dbg_dpyst_valid_o;
	output wire [15:0] dpyctl_o;
	output wire [15:0] dpytap_o;
	output wire [15:0] dpyadr_o;
	output wire [15:0] display_row_o;
	output wire [15:0] display_col_o;
	output wire [1:0] display_yoffset_o;
	output wire display_enable_o;
	output wire display_blank_o;
	output wire vblank_start_o;
	output wire timing_start_o;
	input wire lint1_in;
	input wire lint2_in;
	output wire [15:0] video_hcount_o;
	output wire [15:0] video_vcount_o;
	output wire [15:0] video_heblnk_o;
	output wire [15:0] video_hsblnk_o;
	output wire [15:0] video_veblnk_o;
	output wire [15:0] video_vsblnk_o;
	output wire video_hs_o;
	output wire video_vs_o;
	output wire video_hb_o;
	output wire video_vb_o;
	output wire video_ready_o;
	output wire dbg_int_entry_o;
	output wire [31:0] dbg_int_pc_o;
	output wire [31:0] dbg_int_vec_addr_o;
	output wire [31:0] dbg_int_vec_value_o;
	output wire [15:0] dbg_intpend_o;
	output wire [15:0] dbg_intenb_o;
	output wire dbg_disp_int_o;
	output wire dbg_st_ie_o;
	output wire dbg_int_return_o;
	output wire dbg_int_begin_o;
	reg pblt_w2_q;
	reg pblt_w1_q;
	wire pblt_array_hit;
	reg [1:0] drav_w_q;
	reg drav_inside_q;
	reg line_last_inside_q;
	reg line_aborted_q;
	wire line_win_en;
	wire [31:0] rf_rs1_data;
	wire [31:0] rf_rs2_data;
	wire [31:0] rf_rs3_data;
	wire [31:0] rf_mm_data;
	wire [31:0] rf_wstart_data;
	wire [31:0] rf_wend_data;
	wire is_fill;
	wire fill_is_xy;
	wire is_pblt;
	wire is_drav;
	wire is_line;
	wire pixt_rmw;
	reg [31:0] pix_dest_q;
	wire pixt_xy_win;
	reg pixt_inside_q;
	reg [4:0] pix_xy_xsh;
	wire [31:0] pix_xy_dst_linear;
	wire is_mpy;
	wire mpy_signed;
	wire mpy_rd_even;
	wire is_div;
	wire is_divu;
	wire is_modu;
	wire is_divs;
	wire is_mods;
	wire div_signed_ovf;
	wire div_v;
	wire is_pair_wb;
	wire pair_second_pass;
	reg pair_wb_step;
	wire [15:0] io_psize;
	wire [15:0] io_convdp;
	wire [15:0] io_convsp;
	wire [15:0] io_control;
	wire [15:0] io_pmask;
	wire [15:0] io_dpyctl;
	wire [15:0] io_dpyctl_cpu;
	assign dpyctl_o = io_dpyctl;
	wire [15:0] io_psize_live;
	wire [15:0] io_convdp_live;
	wire [15:0] io_convsp_live;
	wire [15:0] io_control_live;
	wire [15:0] io_pmask_live;
	wire wvp_set_comb;
	reg wvp_set_q;
	wire [31:0] mem_rdata_eff;
	reg int_push_q;
	localparam [31:0] SRT_ROW_WORDS = 1024;
	localparam [31:0] SRT_IDX_W = 11;
	wire srt_active;
	wire srt_enter;
	wire fill_srt_active;
	wire fill_srt_enter;
	reg srt_fill_q;
	reg [10:0] srt_idx;
	reg srt_wr_phase;
	reg [31:0] srt_word_base;
	wire srt_last;
	wire [31:0] srt_bit_addr;
	reg [15:0] srt_buf [0:1023];
	reg [15:0] srt_rdata_q;
	wire srt_buf_we;
	reg [31:0] fill_srt_row_start_q;
	reg [31:0] fill_srt_word_addr_q;
	reg [31:0] fill_srt_span_bits_q;
	reg [17:0] fill_srt_words_left_q;
	reg [15:0] fill_srt_rows_left_q;
	wire [32:0] fill_srt_span_bits;
	wire [32:0] fill_srt_first_words_wide;
	wire [32:0] fill_srt_next_words_wide;
	wire [31:0] fill_srt_next_row_start;
	wire [17:0] fill_srt_first_words;
	wire [17:0] fill_srt_next_words;
	wire fill_srt_transfer_last;
	function automatic [31:0] ppop_apply;
		input reg [31:0] src;
		input reg [31:0] dest;
		input reg [4:0] ppop;
		input reg [31:0] fmask;
		reg [31:0] sp;
		reg [31:0] dp;
		reg [31:0] addsum;
		begin
			sp = src & fmask;
			dp = dest & fmask;
			addsum = dp + sp;
			(* full_case, parallel_case *)
			case (ppop)
				5'h00: ppop_apply = src;
				5'h01: ppop_apply = src & dest;
				5'h02: ppop_apply = src & ~dest;
				5'h03: ppop_apply = 1'sb0;
				5'h04: ppop_apply = src | ~dest;
				5'h05: ppop_apply = ~(src ^ dest);
				5'h06: ppop_apply = ~dest;
				5'h07: ppop_apply = ~(src | dest);
				5'h08: ppop_apply = src | dest;
				5'h09: ppop_apply = dest;
				5'h0a: ppop_apply = src ^ dest;
				5'h0b: ppop_apply = ~src & dest;
				5'h0c: ppop_apply = 1'sb1;
				5'h0d: ppop_apply = ~src | dest;
				5'h0e: ppop_apply = ~(src & dest);
				5'h0f: ppop_apply = ~src;
				5'h10: ppop_apply = addsum;
				5'h11: ppop_apply = (addsum > fmask ? fmask : addsum);
				5'h12: ppop_apply = dp - sp;
				5'h13: ppop_apply = (dp >= sp ? dp - sp : {32 {1'sb0}});
				5'h14: ppop_apply = (dp >= sp ? dp : sp);
				5'h15: ppop_apply = (dp <= sp ? dp : sp);
				default: ppop_apply = src;
			endcase
		end
	endfunction
	reg pc_advance_en;
	reg pc_load_en;
	reg [31:0] pc_load_value;
	wire [31:0] pc_value;
	localparam [5:0] tms34010_pkg_INSTR_WORD_BITS = 6'd16;
	localparam [31:0] tms34010_pkg_PC_ADVANCE_WIDTH = 8;
	function automatic [7:0] sv2v_cast_4E301;
		input reg [7:0] inp;
		sv2v_cast_4E301 = inp;
	endfunction
	tms34010_pc u_pc(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.load_en(pc_load_en),
		.load_value(pc_load_value),
		.advance_en(pc_advance_en),
		.advance_amount(sv2v_cast_4E301(tms34010_pkg_INSTR_WORD_BITS)),
		.pc_o(pc_value)
	);
	reg [5:0] state_q;
	reg [5:0] state_d;
	reg [3:0] dsjs_delay_q;
	reg prev_wb_nop_q;
	reg instruction_active_q;
	reg timing_interrupt_q;
	reg interrupt_timing_start;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				state_q <= 6'd0;
				instruction_active_q <= 1'b0;
				timing_interrupt_q <= 1'b0;
			end
			else begin
				state_q <= state_d;
				if (instruction_retire_o) begin
					instruction_active_q <= 1'b0;
					timing_interrupt_q <= 1'b0;
				end
				else if (instruction_start_o) begin
					instruction_active_q <= 1'b1;
					timing_interrupt_q <= interrupt_timing_start;
				end
			end
		end
	always @(*) begin
		if (_sv2v_0)
			;
		interrupt_timing_start = (ce_cpu && (state_q == 6'd1)) && ((state_d == 6'd18) || (state_d == 6'd19));
		instruction_start_o = (ce_cpu && (state_q == 6'd1)) && (((state_d == 6'd2) || (state_d == 6'd18)) || (state_d == 6'd19));
		instruction_retire_o = ((ce_cpu && instruction_active_q) && (state_q != 6'd1)) && (state_d == 6'd1);
	end
	assign fetch_access_o = mem_req && ((((((state_q == 6'd38) || (state_q == 6'd1)) || (state_q == 6'd3)) || (state_q == 6'd4)) || (state_q == 6'd39)) || (state_q == 6'd40));
	reg [15:0] instr_word_q;
	wire [52:0] decoded;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				instr_word_q <= 1'sb0;
			else if ((state_q == 6'd1) && mem_ack)
				instr_word_q <= mem_rdata_eff[15:0];
		end
	tms34010_decode u_decode(
		.instr(instr_word_q),
		.decoded(decoded)
	);
	reg illegal_q;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				illegal_q <= 1'b0;
			else if ((state_q == 6'd2) && decoded[52])
				illegal_q <= 1'b1;
		end
	wire [31:0] branch_target_short;
	wire signed [15:0] disp_signed_12;
	assign disp_signed_12 = $signed({instr_word_q[7:0], 4'h0});
	function automatic signed [31:0] sv2v_cast_DEBC9_signed;
		input reg signed [31:0] inp;
		sv2v_cast_DEBC9_signed = inp;
	endfunction
	assign branch_target_short = pc_value + sv2v_cast_DEBC9_signed(disp_signed_12);
	reg [15:0] imm_lo_q;
	reg [15:0] imm_hi_q;
	reg [15:0] imm2_lo_q;
	reg [15:0] imm2_hi_q;
	wire [31:0] imm2_32 = {imm2_hi_q, imm2_lo_q};
	wire is_mv_abs_m2m = decoded[51-:7] == 7'd99;
	wire is_mv_off_m2m = decoded[51-:7] == 7'd100;
	wire is_mv_off_ni = decoded[51-:7] == 7'd101;
	wire is_mv_abs_ni = decoded[51-:7] == 7'd102;
	wire [31:0] imm2_off_sext = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {imm2_lo_q[15]}}, imm2_lo_q};
	wire [31:0] branch_target_long;
	wire signed [19:0] disp_signed_20;
	assign disp_signed_20 = $signed({imm_lo_q, 4'h0});
	assign branch_target_long = pc_value + sv2v_cast_DEBC9_signed(disp_signed_20);
	wire [31:0] branch_target_jacc;
	assign branch_target_jacc = {imm_hi_q, imm_lo_q[15:4], 4'h0};
	wire [31:0] branch_target_dsjs;
	wire signed [9:0] dsjs_disp_bits;
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	assign dsjs_disp_bits = (instr_word_q[10] ? -sv2v_cast_10_signed($signed({1'b0, instr_word_q[9:5], 4'h0})) : sv2v_cast_10_signed($signed({1'b0, instr_word_q[9:5], 4'h0})));
	assign branch_target_dsjs = pc_value + sv2v_cast_DEBC9_signed(dsjs_disp_bits);
	reg [1:0] mem_op_step;
	reg [31:0] popped_st_q;
	reg [31:0] popped_pc_q;
	reg [31:0] move_data_q;
	reg [31:0] mv_load_data_q;
	wire trap_skip_push;
	assign trap_skip_push = (decoded[51-:7] == 7'd71) && (decoded[23-:5] == 5'd0);
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				mem_op_step <= 2'd0;
				popped_st_q <= 1'sb0;
				popped_pc_q <= 1'sb0;
				move_data_q <= 1'sb0;
				pix_dest_q <= 1'sb0;
			end
			else if ((state_q == 6'd6) && mem_ack) begin
				if ((decoded[51-:7] == 7'd76) && (mem_op_step == 2'd0))
					move_data_q <= mem_rdata_eff;
				if (((((decoded[51-:7] == 7'd99) || (decoded[51-:7] == 7'd100)) || (decoded[51-:7] == 7'd101)) || (decoded[51-:7] == 7'd102)) && (mem_op_step == 2'd0))
					move_data_q <= mem_rdata_eff;
				if (((decoded[51-:7] == 7'd74) && pixt_rmw) && (mem_op_step == 2'd0))
					pix_dest_q <= mem_rdata_eff;
				if (decoded[51-:7] == 7'd70) begin
					if (mem_op_step == 2'd0)
						popped_st_q <= mem_rdata_eff;
					if (mem_op_step == 2'd1)
						popped_pc_q <= mem_rdata_eff;
				end
				if (decoded[51-:7] == 7'd71) begin
					if (trap_skip_push) begin
						if (mem_op_step == 2'd0)
							popped_pc_q <= mem_rdata_eff;
					end
					else if (mem_op_step == 2'd2)
						popped_pc_q <= mem_rdata_eff;
				end
				(* full_case, parallel_case *)
				case (decoded[51-:7])
					7'd70: mem_op_step <= (mem_op_step == 2'd1 ? 2'd0 : mem_op_step + 2'd1);
					7'd71: mem_op_step <= (trap_skip_push || (mem_op_step == 2'd2) ? 2'd0 : mem_op_step + 2'd1);
					7'd76, 7'd99, 7'd100, 7'd101, 7'd102: mem_op_step <= (mem_op_step == 2'd1 ? 2'd0 : mem_op_step + 2'd1);
					7'd74: mem_op_step <= (pixt_rmw && (mem_op_step == 2'd0) ? 2'd1 : 2'd0);
					default: mem_op_step <= 2'd0;
				endcase
			end
			else if ((state_q == 6'd19) && mem_ack) begin
				popped_pc_q <= mem_rdata_eff;
				mem_op_step <= 2'd0;
			end
			else if (state_q != 6'd6)
				mem_op_step <= 2'd0;
		end
	reg [31:0] fill_dptch_q;
	reg [31:0] fill_color_q;
	reg [31:0] fill_daddr_raw_q;
	reg [15:0] fill_dx_q;
	reg [15:0] fill_dy_q;
	reg [31:0] fill_addr_q;
	reg [31:0] fill_row_base_q;
	reg [15:0] fill_x_q;
	reg [15:0] fill_y_q;
	wire [31:0] fill_psize_ext;
	wire fill_row_end;
	wire fill_done;
	function automatic [31:0] sv2v_cast_DEBC9;
		input reg [31:0] inp;
		sv2v_cast_DEBC9 = inp;
	endfunction
	assign fill_psize_ext = sv2v_cast_DEBC9(io_psize[5:0]);
	assign fill_row_end = fill_x_q == (fill_dx_q - 16'd1);
	assign fill_done = fill_row_end && (fill_y_q == (fill_dy_q - 16'd1));
	wire [4:0] fill_xy_yshift;
	wire [31:0] fill_xy_linear;
	wire [31:0] fill_start;
	assign fill_xy_yshift = 5'd31 - io_convdp[4:0];
	assign fill_xy_linear = (({{16 {fill_daddr_raw_q[31]}}, fill_daddr_raw_q[31:16]} << fill_xy_yshift) | ({16'b0000000000000000, fill_daddr_raw_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign fill_start = (fill_is_xy ? fill_xy_linear : fill_daddr_raw_q);
	reg fill_substep_q;
	reg [31:0] fill_dest_q;
	wire [31:0] fill_pixel_mask;
	wire [31:0] fill_pmask_field;
	wire [31:0] fill_processed;
	wire [31:0] fill_merged;
	wire fill_transp;
	reg [31:0] fill_wstart_q;
	reg [31:0] fill_wend_q;
	reg fill_win_en_q;
	reg fill_w2_q;
	wire [15:0] fill_px;
	wire [15:0] fill_py;
	wire fill_in_window;
	wire fill_clip_out;
	assign fill_px = fill_daddr_raw_q[15:0] + fill_x_q;
	assign fill_py = fill_daddr_raw_q[31:16] + fill_y_q;
	assign fill_in_window = (((fill_px >= fill_wstart_q[15:0]) && (fill_px <= fill_wend_q[15:0])) && (fill_py >= fill_wstart_q[31:16])) && (fill_py <= fill_wend_q[31:16]);
	assign fill_clip_out = fill_win_en_q && !fill_in_window;
	wire fill_array_inside;
	wire [15:0] fill_arr_x0;
	wire [15:0] fill_arr_y0;
	wire [15:0] fill_arr_x1;
	wire [15:0] fill_arr_y1;
	assign fill_arr_x0 = fill_daddr_raw_q[15:0];
	assign fill_arr_y0 = fill_daddr_raw_q[31:16];
	assign fill_arr_x1 = (fill_arr_x0 + fill_dx_q) - 16'd1;
	assign fill_arr_y1 = (fill_arr_y0 + fill_dy_q) - 16'd1;
	assign fill_array_inside = (((fill_arr_x0 >= rf_wstart_data[15:0]) && (fill_arr_x1 <= rf_wend_data[15:0])) && (fill_arr_y0 >= rf_wstart_data[31:16])) && (fill_arr_y1 <= rf_wend_data[31:16]);
	reg fill_w1_q;
	wire fill_array_hit;
	assign fill_array_hit = !((((fill_arr_x1 < fill_wstart_q[15:0]) || (fill_arr_x0 > fill_wend_q[15:0])) || (fill_arr_y1 < fill_wstart_q[31:16])) || (fill_arr_y0 > fill_wend_q[31:16]));
	wire fill_win_flag_wb;
	wire fill_win_violation;
	wire drav_win_wb;
	assign drav_win_wb = ((state_q == 6'd7) && is_drav) && (drav_w_q != 2'd0);
	wire line_win_wb;
	assign line_win_wb = (state_q == 6'd33) && line_win_en;
	wire pixt_win_wb;
	localparam [31:0] tms34010_pkg_CTRL_W_HI = 7;
	localparam [31:0] tms34010_pkg_CTRL_W_LO = 6;
	assign pixt_win_wb = ((state_q == 6'd7) && (instr_word_q[15:9] == 7'b1111000)) && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] != 2'd0);
	assign fill_win_violation = ((((((state_q == 6'd23) || (state_q == 6'd24)) || ((state_q == 6'd25) && !fill_array_hit)) || ((state_q == 6'd26) && !pblt_array_hit)) || (drav_win_wb && !drav_inside_q)) || (line_win_wb && !line_last_inside_q)) || (pixt_win_wb && !pixt_inside_q);
	assign fill_win_flag_wb = ((((((((state_q == 6'd23) || ((state_q == 6'd11) && fill_w2_q)) || (state_q == 6'd24)) || ((state_q == 6'd15) && pblt_w2_q)) || (state_q == 6'd25)) || (state_q == 6'd26)) || drav_win_wb) || line_win_wb) || pixt_win_wb;
	assign wvp_set_comb = ((((((state_q == 6'd23) || (state_q == 6'd24)) || ((state_q == 6'd25) && fill_array_hit)) || ((state_q == 6'd26) && pblt_array_hit)) || (drav_win_wb && (((drav_w_q == 2'd1) && drav_inside_q) || ((drav_w_q == 2'd2) && !drav_inside_q)))) || (line_win_wb && line_aborted_q)) || (pixt_win_wb && (((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1) && pixt_inside_q) || ((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2) && !pixt_inside_q)));
	always @(posedge clk)
		if (rst)
			wvp_set_q <= 1'b0;
		else
			wvp_set_q <= (ce_cpu !== 1'b0) && wvp_set_comb;
	assign fill_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign fill_pmask_field = {{16 {1'b0}}, io_pmask} & fill_pixel_mask;
	reg [31:0] pblt_dst_pix_q;
	wire [31:0] pblt_pixel_mask;
	wire [31:0] pblt_src_eff;
	reg [31:0] drav_dest_q;
	reg [31:0] drav_pixel_mask;
	reg [31:0] line_color_q;
	reg [31:0] line_dest_q;
	wire [31:0] line_pixel_mask;
	wire [31:0] mv_fmask;
	reg [31:0] ppop_sh_src;
	reg [31:0] ppop_sh_dest;
	reg [31:0] ppop_sh_fmask;
	wire [31:0] ppop_sh_out;
	always @(*) begin
		if (_sv2v_0)
			;
		ppop_sh_src = 1'sb0;
		ppop_sh_dest = 1'sb0;
		ppop_sh_fmask = 1'sb0;
		(* full_case, parallel_case *)
		case (state_q)
			6'd10: begin
				ppop_sh_src = fill_color_q;
				ppop_sh_dest = fill_dest_q;
				ppop_sh_fmask = fill_pixel_mask;
			end
			6'd13: begin
				ppop_sh_src = pblt_src_eff;
				ppop_sh_dest = pblt_dst_pix_q;
				ppop_sh_fmask = pblt_pixel_mask;
			end
			6'd32: begin
				ppop_sh_src = line_color_q;
				ppop_sh_dest = line_dest_q;
				ppop_sh_fmask = line_pixel_mask;
			end
			default:
				;
		endcase
	end
	localparam [31:0] tms34010_pkg_CTRL_PPOP_HI = 14;
	localparam [31:0] tms34010_pkg_CTRL_PPOP_LO = 10;
	assign ppop_sh_out = ppop_apply(ppop_sh_src, ppop_sh_dest, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], ppop_sh_fmask);
	assign fill_processed = ppop_sh_out;
	localparam [31:0] tms34010_pkg_CTRL_T_BIT = 5;
	assign fill_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((fill_processed & fill_pixel_mask) == {32 {1'sb0}});
	assign fill_merged = (fill_transp || fill_clip_out ? fill_dest_q : (fill_processed & ~fill_pmask_field) | (fill_dest_q & fill_pmask_field));
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				fill_dptch_q <= 1'sb0;
				fill_color_q <= 1'sb0;
				fill_daddr_raw_q <= 1'sb0;
				fill_dx_q <= 1'sb0;
				fill_dy_q <= 1'sb0;
				fill_addr_q <= 1'sb0;
				fill_row_base_q <= 1'sb0;
				fill_x_q <= 1'sb0;
				fill_y_q <= 1'sb0;
				fill_substep_q <= 1'b0;
				fill_dest_q <= 1'sb0;
				fill_wstart_q <= 1'sb0;
				fill_wend_q <= 1'sb0;
				fill_win_en_q <= 1'b0;
				fill_w2_q <= 1'b0;
				fill_w1_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_fill) begin
					fill_daddr_raw_q <= rf_rs1_data;
					fill_dptch_q <= rf_rs2_data;
					fill_dx_q <= rf_rs3_data[15:0];
					fill_dy_q <= rf_rs3_data[31:16];
					fill_x_q <= 16'd0;
					fill_y_q <= 16'd0;
					fill_win_en_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd3);
					fill_w2_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2);
					fill_w1_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1);
				end
				if (state_q == 6'd21) begin
					fill_wstart_q <= rf_wstart_data;
					fill_wend_q <= rf_wend_data;
				end
				if (state_q == 6'd9) begin
					fill_color_q <= rf_rs1_data;
					fill_addr_q <= fill_start;
					fill_row_base_q <= fill_start;
					fill_substep_q <= 1'b0;
				end
				if ((state_q == 6'd10) && mem_ack) begin
					fill_substep_q <= ~fill_substep_q;
					if (!fill_substep_q)
						fill_dest_q <= mem_rdata_eff;
					else begin
						fill_addr_q <= fill_addr_q + fill_psize_ext;
						if (fill_row_end && !fill_done) begin
							fill_y_q <= fill_y_q + 16'd1;
							fill_row_base_q <= fill_row_base_q + fill_dptch_q;
							fill_addr_q <= fill_row_base_q + fill_dptch_q;
							fill_x_q <= 16'd0;
						end
						else if (!fill_done)
							fill_x_q <= fill_x_q + 16'd1;
					end
				end
				if ((((((state_q == 6'd42) && srt_fill_q) && srt_wr_phase) && mem_ack) && srt_last) && (fill_srt_words_left_q == 18'd1)) begin
					if (fill_srt_rows_left_q > 16'd1)
						fill_addr_q <= fill_srt_next_row_start;
					else
						fill_addr_q <= fill_srt_row_start_q + fill_srt_span_bits_q;
				end
			end
		end
	reg [31:0] pblt_sptch_q;
	reg [31:0] pblt_dptch_q;
	reg [15:0] pblt_dx_q;
	reg [15:0] pblt_dy_q;
	reg [31:0] pblt_src_addr_q;
	reg [31:0] pblt_dst_addr_q;
	reg [31:0] pblt_src_row_q;
	reg [31:0] pblt_dst_row_q;
	reg [15:0] pblt_x_q;
	reg [15:0] pblt_y_q;
	reg [1:0] pblt_substep_q;
	reg [31:0] pblt_src_pix_q;
	wire [31:0] pblt_psize_ext;
	wire [31:0] pblt_pmask_field;
	wire [31:0] pblt_processed;
	wire [31:0] pblt_merged;
	wire pblt_row_end;
	wire pblt_done;
	wire pblt_transp;
	reg [31:0] pblt_color0_q;
	reg [31:0] pblt_color1_q;
	wire [31:0] pblt_src_step;
	assign pblt_psize_ext = sv2v_cast_DEBC9(io_psize[5:0]);
	assign pblt_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign pblt_pmask_field = {{16 {1'b0}}, io_pmask} & pblt_pixel_mask;
	assign pblt_row_end = pblt_x_q == (pblt_dx_q - 16'd1);
	assign pblt_done = pblt_row_end && (pblt_y_q == (pblt_dy_q - 16'd1));
	assign pblt_src_eff = (decoded[0] ? (pblt_src_pix_q[0] ? pblt_color1_q : pblt_color0_q) : pblt_src_pix_q);
	assign pblt_src_step = (decoded[0] ? 32'd1 : pblt_psize_ext);
	assign pblt_processed = ppop_sh_out;
	assign pblt_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((pblt_processed & pblt_pixel_mask) == {32 {1'sb0}});
	reg [31:0] pblt_dst_xy_raw_q;
	reg [31:0] pblt_wstart_q;
	reg [31:0] pblt_wend_q;
	reg pblt_win_en_q;
	wire [15:0] pblt_px;
	wire [15:0] pblt_py;
	wire pblt_in_window;
	wire pblt_clip_out;
	assign pblt_px = pblt_dst_xy_raw_q[15:0] + pblt_x_q;
	assign pblt_py = pblt_dst_xy_raw_q[31:16] + pblt_y_q;
	assign pblt_in_window = (((pblt_px >= pblt_wstart_q[15:0]) && (pblt_px <= pblt_wend_q[15:0])) && (pblt_py >= pblt_wstart_q[31:16])) && (pblt_py <= pblt_wend_q[31:16]);
	assign pblt_clip_out = pblt_win_en_q && !pblt_in_window;
	wire pblt_array_inside;
	wire [15:0] pblt_arr_x0;
	wire [15:0] pblt_arr_y0;
	wire [15:0] pblt_arr_x1;
	wire [15:0] pblt_arr_y1;
	assign pblt_arr_x0 = pblt_dst_xy_raw_q[15:0];
	assign pblt_arr_y0 = pblt_dst_xy_raw_q[31:16];
	assign pblt_arr_x1 = (pblt_arr_x0 + pblt_dx_q) - 16'd1;
	assign pblt_arr_y1 = (pblt_arr_y0 + pblt_dy_q) - 16'd1;
	assign pblt_array_inside = (((pblt_arr_x0 >= rf_wstart_data[15:0]) && (pblt_arr_x1 <= rf_wend_data[15:0])) && (pblt_arr_y0 >= rf_wstart_data[31:16])) && (pblt_arr_y1 <= rf_wend_data[31:16]);
	assign pblt_array_hit = !((((pblt_arr_x1 < pblt_wstart_q[15:0]) || (pblt_arr_x0 > pblt_wend_q[15:0])) || (pblt_arr_y1 < pblt_wstart_q[31:16])) || (pblt_arr_y0 > pblt_wend_q[31:16]));
	assign pblt_merged = (pblt_transp || pblt_clip_out ? pblt_dst_pix_q : (pblt_processed & ~pblt_pmask_field) | (pblt_dst_pix_q & pblt_pmask_field));
	wire [31:0] pblt_src_conv;
	wire [31:0] pblt_dst_conv;
	assign pblt_src_conv = (({{16 {pblt_src_addr_q[31]}}, pblt_src_addr_q[31:16]} << (5'd31 - io_convsp[4:0])) | ({16'b0000000000000000, pblt_src_addr_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign pblt_dst_conv = (({{16 {pblt_dst_addr_q[31]}}, pblt_dst_addr_q[31:16]} << (5'd31 - io_convdp[4:0])) | ({16'b0000000000000000, pblt_dst_addr_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				pblt_sptch_q <= 1'sb0;
				pblt_dptch_q <= 1'sb0;
				pblt_dx_q <= 1'sb0;
				pblt_dy_q <= 1'sb0;
				pblt_src_addr_q <= 1'sb0;
				pblt_dst_addr_q <= 1'sb0;
				pblt_src_row_q <= 1'sb0;
				pblt_dst_row_q <= 1'sb0;
				pblt_x_q <= 1'sb0;
				pblt_y_q <= 1'sb0;
				pblt_substep_q <= 2'd0;
				pblt_src_pix_q <= 1'sb0;
				pblt_dst_pix_q <= 1'sb0;
				pblt_color0_q <= 1'sb0;
				pblt_color1_q <= 1'sb0;
				pblt_dst_xy_raw_q <= 1'sb0;
				pblt_wstart_q <= 1'sb0;
				pblt_wend_q <= 1'sb0;
				pblt_win_en_q <= 1'b0;
				pblt_w2_q <= 1'b0;
				pblt_w1_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_pblt) begin
					pblt_src_addr_q <= rf_rs1_data;
					pblt_src_row_q <= rf_rs1_data;
					pblt_dst_addr_q <= rf_rs2_data;
					pblt_dst_row_q <= rf_rs2_data;
					pblt_dst_xy_raw_q <= rf_rs2_data;
					pblt_dx_q <= rf_rs3_data[15:0];
					pblt_dy_q <= rf_rs3_data[31:16];
					pblt_x_q <= 16'd0;
					pblt_y_q <= 16'd0;
					pblt_substep_q <= 2'd0;
					pblt_win_en_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd3);
					pblt_w2_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2);
					pblt_w1_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1);
				end
				if (state_q == 6'd22) begin
					pblt_wstart_q <= rf_wstart_data;
					pblt_wend_q <= rf_wend_data;
				end
				if (state_q == 6'd12) begin
					pblt_sptch_q <= rf_rs1_data;
					pblt_dptch_q <= rf_rs2_data;
					if (decoded[2]) begin
						pblt_src_addr_q <= pblt_src_conv;
						pblt_src_row_q <= pblt_src_conv;
					end
					if (decoded[1]) begin
						pblt_dst_addr_q <= pblt_dst_conv;
						pblt_dst_row_q <= pblt_dst_conv;
					end
				end
				if (state_q == 6'd16) begin
					pblt_color0_q <= rf_rs1_data;
					pblt_color1_q <= rf_rs2_data;
				end
				if ((state_q == 6'd13) && mem_ack) begin
					if (pblt_substep_q == 2'd0) begin
						pblt_src_pix_q <= mem_rdata_eff;
						pblt_substep_q <= 2'd1;
					end
					else if (pblt_substep_q == 2'd1) begin
						pblt_dst_pix_q <= mem_rdata_eff;
						pblt_substep_q <= 2'd2;
					end
					else begin
						pblt_substep_q <= 2'd0;
						pblt_src_addr_q <= pblt_src_addr_q + pblt_src_step;
						pblt_dst_addr_q <= pblt_dst_addr_q + pblt_psize_ext;
						if (pblt_done) begin
							pblt_src_addr_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_addr_q <= pblt_dst_row_q + pblt_dptch_q;
						end
						else if (pblt_row_end) begin
							pblt_y_q <= pblt_y_q + 16'd1;
							pblt_src_row_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_row_q <= pblt_dst_row_q + pblt_dptch_q;
							pblt_src_addr_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_addr_q <= pblt_dst_row_q + pblt_dptch_q;
							pblt_x_q <= 16'd0;
						end
						else
							pblt_x_q <= pblt_x_q + 16'd1;
					end
				end
			end
		end
	reg [31:0] drav_rd_q;
	reg [31:0] drav_rs_q;
	reg [31:0] drav_linear_q;
	reg [1:0] drav_phase_q;
	reg [31:0] drav_color_q;
	reg [31:0] drav_processed_q;
	reg [31:0] drav_cmd_wdata_q;
	reg [31:0] drav_pmask_q;
	reg [4:0] drav_ppop_q;
	reg drav_transparent_q;
	reg drav_srt_q;
	reg [5:0] drav_cmd_size_q;
	reg drav_cmd_valid_q;
	reg drav_cmd_we_q;
	reg drav_cmd_srt_q;
	wire drav_in_window;
	wire drav_draw;
	assign drav_in_window = (((drav_rd_q[15:0] >= rf_wstart_data[15:0]) && (drav_rd_q[15:0] <= rf_wend_data[15:0])) && (drav_rd_q[31:16] >= rf_wstart_data[31:16])) && (drav_rd_q[31:16] <= rf_wend_data[31:16]);
	assign drav_draw = (drav_w_q == 2'd0) || (((drav_w_q == 2'd2) || (drav_w_q == 2'd3)) && drav_inside_q);
	wire [31:0] drav_pmask_field;
	wire [31:0] drav_processed;
	wire [31:0] drav_merged;
	wire drav_transp;
	wire [31:0] drav_advance;
	assign drav_pmask_field = drav_pmask_q & drav_pixel_mask;
	assign drav_processed = ppop_apply(drav_color_q, drav_dest_q, drav_ppop_q, drav_pixel_mask);
	assign drav_transp = drav_transparent_q && ((drav_processed_q & drav_pixel_mask) == {32 {1'sb0}});
	assign drav_merged = (drav_transp ? drav_dest_q : (drav_processed_q & ~drav_pmask_field) | (drav_dest_q & drav_pmask_field));
	assign drav_advance = {drav_rd_q[31:16] + drav_rs_q[31:16], drav_rd_q[15:0] + drav_rs_q[15:0]};
	wire srt_on = io_dpyctl_cpu[11];
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				drav_rd_q <= 1'sb0;
				drav_rs_q <= 1'sb0;
				drav_linear_q <= 1'sb0;
				drav_dest_q <= 1'sb0;
				drav_phase_q <= 2'd0;
				drav_color_q <= 1'sb0;
				drav_processed_q <= 1'sb0;
				drav_pixel_mask <= 1'sb0;
				drav_pmask_q <= 1'sb0;
				drav_ppop_q <= 1'sb0;
				drav_transparent_q <= 1'b0;
				drav_srt_q <= 1'b0;
				drav_cmd_valid_q <= 1'b0;
				drav_cmd_we_q <= 1'b0;
				drav_cmd_srt_q <= 1'b0;
				drav_cmd_size_q <= 1'sb0;
				drav_cmd_wdata_q <= 1'sb0;
				drav_w_q <= 2'd0;
				drav_inside_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_drav) begin
					drav_rd_q <= rf_rs2_data;
					drav_rs_q <= rf_rs1_data;
					drav_linear_q <= pix_xy_dst_linear;
					drav_phase_q <= 2'd0;
					drav_pixel_mask <= (32'd1 << io_psize[5:0]) - 32'd1;
					drav_pmask_q <= {{16 {1'b0}}, io_pmask};
					drav_ppop_q <= io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO];
					drav_transparent_q <= io_control[tms34010_pkg_CTRL_T_BIT];
					drav_srt_q <= srt_on;
					drav_cmd_valid_q <= 1'b1;
					drav_cmd_we_q <= 1'b0;
					drav_cmd_srt_q <= 1'b0;
					drav_cmd_size_q <= io_psize[5:0];
					drav_cmd_wdata_q <= 1'sb0;
					drav_w_q <= io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO];
				end
				if (state_q == 6'd28) begin
					drav_inside_q <= drav_in_window;
					if (!(((drav_w_q == 2'd2) || (drav_w_q == 2'd3)) && drav_in_window))
						drav_cmd_valid_q <= 1'b0;
				end
				if (state_q == 6'd27)
					case (drav_phase_q)
						2'd0:
							if (mem_ack) begin
								drav_color_q <= rf_rs1_data;
								drav_dest_q <= mem_rdata_eff;
								drav_cmd_valid_q <= 1'b0;
								drav_phase_q <= 2'd1;
							end
						2'd1: begin
							drav_processed_q <= drav_processed;
							drav_phase_q <= 2'd2;
						end
						2'd2: begin
							drav_cmd_wdata_q <= drav_merged;
							drav_cmd_we_q <= 1'b1;
							drav_cmd_srt_q <= drav_srt_q;
							drav_cmd_valid_q <= 1'b1;
							drav_phase_q <= 2'd3;
						end
						2'd3:
							if (mem_ack) begin
								drav_cmd_valid_q <= 1'b0;
								drav_phase_q <= 2'd0;
							end
						default: drav_phase_q <= 2'd0;
					endcase
			end
		end
	reg [31:0] line_d_q;
	reg [31:0] line_count_q;
	reg [31:0] line_initial_count_q;
	reg [31:0] line_inc1_q;
	reg [31:0] line_inc2_q;
	reg [31:0] line_offset_q;
	reg [31:0] line_daddr_q;
	reg [15:0] line_b_q;
	reg [15:0] line_a_q;
	reg line_substep_q;
	wire [31:0] line_linear;
	assign line_linear = (({{16 {line_daddr_q[31]}}, line_daddr_q[31:16]} << (5'd31 - io_convdp[4:0])) | ({16'b0000000000000000, line_daddr_q[15:0]} << pix_xy_xsh)) + line_offset_q;
	wire [31:0] line_pmask_field;
	wire [31:0] line_processed;
	wire [31:0] line_merged;
	wire line_transp;
	assign line_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign line_pmask_field = {{16 {1'b0}}, io_pmask} & line_pixel_mask;
	assign line_processed = ppop_sh_out;
	assign line_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((line_processed & line_pixel_mask) == {32 {1'sb0}});
	reg [31:0] line_wstart_q;
	reg [31:0] line_wend_q;
	wire [1:0] line_w_mode;
	wire line_in_window;
	wire line_draw_pixel;
	wire line_clip_out;
	wire line_abort;
	assign line_w_mode = io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO];
	assign line_win_en = line_w_mode != 2'd0;
	assign line_in_window = (((line_daddr_q[15:0] >= line_wstart_q[15:0]) && (line_daddr_q[15:0] <= line_wend_q[15:0])) && (line_daddr_q[31:16] >= line_wstart_q[31:16])) && (line_daddr_q[31:16] <= line_wend_q[31:16]);
	assign line_draw_pixel = (line_w_mode == 2'd1 ? !line_in_window : line_in_window);
	assign line_clip_out = line_win_en && !line_draw_pixel;
	assign line_abort = ((line_w_mode == 2'd1) && line_in_window) || ((line_w_mode == 2'd2) && !line_in_window);
	assign line_merged = (line_transp || line_clip_out ? line_dest_q : (line_processed & ~line_pmask_field) | (line_dest_q & line_pmask_field));
	wire line_branch;
	wire [31:0] line_2b;
	wire [31:0] line_2a;
	wire [31:0] line_d_next;
	wire [31:0] line_daddr_next;
	wire [31:0] line_count_next;
	assign line_branch = (instr_word_q[7] ? !line_d_q[31] : !line_d_q[31] && (line_d_q != {32 {1'sb0}}));
	assign line_2b = {16'b0000000000000000, line_b_q} << 1;
	assign line_2a = {16'b0000000000000000, line_a_q} << 1;
	assign line_d_next = (line_branch ? (line_d_q + line_2b) - line_2a : line_d_q + line_2b);
	assign line_daddr_next = (line_branch ? {line_daddr_q[31:16] + line_inc1_q[31:16], line_daddr_q[15:0] + line_inc1_q[15:0]} : {line_daddr_q[31:16] + line_inc2_q[31:16], line_daddr_q[15:0] + line_inc2_q[15:0]});
	assign line_count_next = line_count_q - 32'd1;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				line_d_q <= 1'sb0;
				line_count_q <= 1'sb0;
				line_initial_count_q <= 1'sb0;
				line_inc1_q <= 1'sb0;
				line_inc2_q <= 1'sb0;
				line_offset_q <= 1'sb0;
				line_daddr_q <= 1'sb0;
				line_color_q <= 1'sb0;
				line_dest_q <= 1'sb0;
				line_b_q <= 1'sb0;
				line_a_q <= 1'sb0;
				line_substep_q <= 1'b0;
				line_wstart_q <= 1'sb0;
				line_wend_q <= 1'sb0;
				line_last_inside_q <= 1'b0;
				line_aborted_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_line)
					line_aborted_q <= 1'b0;
				if (state_q == 6'd36) begin
					line_wstart_q <= rf_wstart_data;
					line_wend_q <= rf_wend_data;
				end
				if (state_q == 6'd29) begin
					line_d_q <= rf_rs1_data;
					line_b_q <= rf_rs2_data[31:16];
					line_a_q <= rf_rs2_data[15:0];
					line_count_q <= rf_rs3_data;
					line_initial_count_q <= rf_rs3_data;
				end
				if (state_q == 6'd30) begin
					line_inc1_q <= rf_rs1_data;
					line_inc2_q <= rf_rs2_data;
					line_offset_q <= rf_rs3_data;
				end
				if (state_q == 6'd31) begin
					line_daddr_q <= rf_rs1_data;
					line_color_q <= rf_rs2_data;
					line_substep_q <= 1'b0;
				end
				if ((state_q == 6'd32) && mem_ack) begin
					line_substep_q <= ~line_substep_q;
					if (!line_substep_q)
						line_dest_q <= mem_rdata_eff;
					else begin
						line_last_inside_q <= line_in_window;
						if (line_abort)
							line_aborted_q <= 1'b1;
						line_d_q <= line_d_next;
						line_daddr_q <= line_daddr_next;
						line_count_q <= line_count_next;
					end
				end
			end
		end
	reg [31:0] mm_rp_q;
	reg [15:0] mm_mask_q;
	wire [15:0] mm_mask_after_current;
	reg [3:0] mm_iter_idx;
	reg [3:0] mm_issue_iter_idx;
	wire [3:0] mm_reg_idx;
	wire [3:0] mm_issue_reg_idx;
	wire mm_mask_will_be_empty;
	wire is_mmtm;
	wire is_mmfm;
	wire is_mm;
	reg mm_mem_cmd_valid_q;
	reg mm_mem_cmd_we_q;
	reg [31:0] mm_mem_cmd_addr_q;
	reg [31:0] mm_mem_cmd_wdata_q;
	wire [31:0] mm_issue_addr;
	wire [31:0] mm_pop_next_rp;
	assign is_mmtm = decoded[51-:7] == 7'd72;
	assign is_mmfm = decoded[51-:7] == 7'd73;
	assign is_mm = is_mmtm || is_mmfm;
	function automatic [3:0] highest_set_idx16;
		input reg [15:0] mask;
		reg [7:0] h8;
		reg [3:0] h4;
		reg [1:0] h2;
		reg [3:0] r;
		begin
			r[3] = |mask[15:8];
			h8 = (r[3] ? mask[15:8] : mask[7:0]);
			r[2] = |h8[7:4];
			h4 = (r[2] ? h8[7:4] : h8[3:0]);
			r[1] = |h4[3:2];
			h2 = (r[1] ? h4[3:2] : h4[1:0]);
			r[0] = h2[1];
			highest_set_idx16 = r;
		end
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		mm_iter_idx = highest_set_idx16(mm_mask_q);
	end
	assign mm_mask_after_current = mm_mask_q & ~(16'd1 << mm_iter_idx);
	always @(*) begin : sv2v_autoblock_1
		reg [15:0] issue_mask;
		if (_sv2v_0)
			;
		issue_mask = mm_mask_q;
		if ((state_q == 6'd5) && is_mm)
			issue_mask = imm_lo_q;
		else if ((state_q == 6'd6) && is_mm)
			issue_mask = mm_mask_after_current;
		mm_issue_iter_idx = highest_set_idx16(issue_mask);
	end
	assign mm_reg_idx = (is_mmtm ? 4'd15 - mm_iter_idx : mm_iter_idx);
	assign mm_issue_reg_idx = (is_mmtm ? 4'd15 - mm_issue_iter_idx : mm_issue_iter_idx);
	assign mm_mask_will_be_empty = (mm_mask_q & ~(16'd1 << mm_iter_idx)) == 16'd0;
	localparam [31:0] tms34010_pkg_WORD_BIT_SIZE = sv2v_cast_DEBC9(tms34010_pkg_DATA_WIDTH);
	assign mm_pop_next_rp = (mm_iter_idx == decoded[43-:4] ? mem_rdata_eff : mm_rp_q) + tms34010_pkg_WORD_BIT_SIZE;
	assign mm_issue_addr = (state_q == 6'd5 ? (is_mmtm ? rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE : rf_rs2_data) : (is_mmtm ? mm_rp_q - tms34010_pkg_WORD_BIT_SIZE : mm_pop_next_rp));
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				mm_mem_cmd_valid_q <= 1'b0;
				mm_mem_cmd_we_q <= 1'b0;
				mm_mem_cmd_addr_q <= 1'sb0;
				mm_mem_cmd_wdata_q <= 1'sb0;
			end
			else if ((state_q == 6'd5) && is_mm) begin
				mm_mem_cmd_valid_q <= imm_lo_q != 16'd0;
				mm_mem_cmd_we_q <= is_mmtm;
				mm_mem_cmd_addr_q <= mm_issue_addr;
				mm_mem_cmd_wdata_q <= (is_mmtm ? (mm_issue_reg_idx == decoded[43-:4] ? mm_issue_addr : rf_mm_data) : {32 {1'sb0}});
			end
			else if (((state_q == 6'd6) && is_mm) && mem_ack) begin
				if (mm_mask_will_be_empty)
					mm_mem_cmd_valid_q <= 1'b0;
				else begin
					mm_mem_cmd_valid_q <= 1'b1;
					mm_mem_cmd_we_q <= is_mmtm;
					mm_mem_cmd_addr_q <= mm_issue_addr;
					mm_mem_cmd_wdata_q <= (is_mmtm ? (mm_issue_reg_idx == decoded[43-:4] ? mm_issue_addr : rf_mm_data) : {32 {1'sb0}});
				end
			end
		end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				mm_rp_q <= 1'sb0;
				mm_mask_q <= 1'sb0;
			end
			else if (((state_q == 6'd5) && (state_d == 6'd6)) && is_mm) begin
				mm_rp_q <= (is_mmtm ? rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE : rf_rs2_data);
				mm_mask_q <= imm_lo_q;
			end
			else if (((state_q == 6'd6) && is_mm) && mem_ack) begin
				mm_mask_q[mm_iter_idx] <= 1'b0;
				if (is_mmfm)
					mm_rp_q <= mm_pop_next_rp;
				else if (!mm_mask_will_be_empty)
					mm_rp_q <= mm_rp_q - tms34010_pkg_WORD_BIT_SIZE;
			end
		end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				imm_lo_q <= 1'sb0;
				imm_hi_q <= 1'sb0;
			end
			else begin
				if ((state_q == 6'd3) && mem_ack)
					imm_lo_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd4) && mem_ack)
					imm_hi_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd39) && mem_ack)
					imm2_lo_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd40) && mem_ack)
					imm2_hi_q <= mem_rdata_eff[15:0];
			end
		end
	wire rf_rs1_file;
	wire [3:0] rf_rs1_idx;
	wire rf_rs2_file;
	wire [3:0] rf_rs2_idx;
	wire rf_rs3_file;
	wire [3:0] rf_rs3_idx;
	wire rf_wr_en;
	wire rf_wr_file;
	wire [3:0] rf_wr_idx;
	reg [31:0] rf_wr_data;
	wire [31:0] rf_sp;
	wire [3:0] alu_op;
	reg [31:0] alu_a;
	reg [31:0] alu_b;
	wire alu_cin;
	wire [31:0] alu_result;
	wire [3:0] alu_flags;
	wire st_flag_update_en;
	wire st_write_en;
	reg [31:0] st_write_data;
	wire [31:0] st_value;
	wire st_n;
	wire st_c;
	wire st_z;
	wire st_v;
	wire [31:0] shifter_result;
	wire [3:0] shifter_flags;
	reg [31:0] imm32;
	always @(*) begin
		if (_sv2v_0)
			;
		if (decoded[33])
			imm32 = {imm_hi_q, imm_lo_q};
		else if (decoded[32])
			imm32 = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {imm_lo_q[15]}}, imm_lo_q};
		else
			imm32 = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {1'b0}}, imm_lo_q};
	end
	assign is_fill = (decoded[51-:7] == 7'd94) || (decoded[51-:7] == 7'd95);
	assign fill_is_xy = decoded[51-:7] == 7'd95;
	assign is_pblt = decoded[51-:7] == 7'd96;
	assign is_drav = decoded[51-:7] == 7'd97;
	assign is_line = decoded[51-:7] == 7'd98;
	wire line_rd_b;
	assign line_rd_b = is_line && (((state_q == 6'd29) || (state_q == 6'd30)) || (state_q == 6'd31));
	localparam [0:0] tms34010_pkg_IS_34020 = 1'b1;
	wire is_blmove = tms34010_pkg_IS_34020 && (decoded[51-:7] == 7'd107);
	wire blmove_rd_b = is_blmove && (state_q == 6'd45);
	wire blmove_start;
	wire [31:0] blmove_b0_o;
	wire [31:0] blmove_b2_o;
	wire [31:0] blmove_b7_o;
	wire blmove_align_err;
	wire blmove_busy;
	wire blmove_done;
	wire blmove_mem_req;
	wire blmove_mem_we;
	wire [31:0] blmove_mem_addr;
	wire [5:0] blmove_mem_size;
	wire [31:0] blmove_mem_wdata;
	reg [31:0] blmove_bits_q;
	reg blmove_align_err_q;
	assign blmove_start = state_q == 6'd45;
	tms34010_blmove u_blmove(
		.clk(clk),
		.ce(ce_cpu),
		.rst(rst),
		.start(blmove_start),
		.s_bit(instr_word_q[1]),
		.d_bit(instr_word_q[0]),
		.src_in(rf_rs1_data),
		.dst_in(rf_rs2_data),
		.bits_in(rf_rs3_data),
		.b0_o(blmove_b0_o),
		.b2_o(blmove_b2_o),
		.b7_o(blmove_b7_o),
		.align_err_o(blmove_align_err),
		.busy_o(blmove_busy),
		.done_o(blmove_done),
		.mem_req(blmove_mem_req),
		.mem_we(blmove_mem_we),
		.mem_addr(blmove_mem_addr),
		.mem_size(blmove_mem_size),
		.mem_wdata(blmove_mem_wdata),
		.mem_rdata(mem_rdata_eff),
		.mem_ack(mem_ack),
		.brb_req(blmove_brb_req),
		.brb_addr(blmove_brb_addr),
		.brb_count(blmove_brb_count),
		.brb_dout(blmove_brb_dout),
		.brb_ack(blmove_brb_ack),
		.bwb_req(blmove_bwb_req),
		.bwb_addr(blmove_bwb_addr),
		.bwb_count(blmove_bwb_count),
		.bwb_data(blmove_bwb_data),
		.bwb_ack(blmove_bwb_ack),
		.burst_ok_in(blmove_burst_ok)
	);
	wire [31:0] blmove_cyc_full;
	wire [15:0] blmove_cycles;
	assign blmove_cyc_full = ((blmove_bits_q >> 4) << 1) + (|blmove_bits_q[3:0] ? 32'd2 : 32'd0);
	assign blmove_cycles = (|blmove_cyc_full[31:16] ? 16'hffff : blmove_cyc_full[15:0]);
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				blmove_bits_q <= 1'sb0;
				blmove_align_err_q <= 1'b0;
			end
			else if (blmove_start) begin
				blmove_bits_q <= rf_rs3_data;
				blmove_align_err_q <= 1'b0;
			end
			else if ((state_q == 6'd46) && blmove_align_err)
				blmove_align_err_q <= 1'b1;
		end
	assign rf_rs1_file = (line_rd_b || blmove_rd_b ? 1'b1 : (state_q == 6'd27 ? 1'b1 : (is_fill || is_pblt ? 1'b1 : (decoded[51-:7] == 7'd30 ? decoded[35] : decoded[44]))));
	localparam [3:0] tms34010_pkg_B_COLOR0_IDX = 4'd8;
	localparam [3:0] tms34010_pkg_B_COLOR1_IDX = 4'd9;
	localparam [3:0] tms34010_pkg_B_DADDR_IDX = 4'd2;
	localparam [3:0] tms34010_pkg_B_INC1_IDX = 4'd11;
	localparam [3:0] tms34010_pkg_B_SADDR_IDX = 4'd0;
	localparam [3:0] tms34010_pkg_B_SPTCH_IDX = 4'd1;
	assign rf_rs1_idx = (is_fill ? (state_q == 6'd9 ? tms34010_pkg_B_COLOR1_IDX : tms34010_pkg_B_DADDR_IDX) : (is_pblt ? (state_q == 6'd16 ? tms34010_pkg_B_COLOR0_IDX : (state_q == 6'd12 ? tms34010_pkg_B_SPTCH_IDX : tms34010_pkg_B_SADDR_IDX)) : (state_q == 6'd27 ? tms34010_pkg_B_COLOR1_IDX : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_SADDR_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_INC1_IDX : (is_line && (state_q == 6'd31) ? tms34010_pkg_B_DADDR_IDX : (blmove_rd_b ? tms34010_pkg_B_SADDR_IDX : decoded[39-:4])))))));
	assign rf_rs2_file = (((line_rd_b || blmove_rd_b) || is_fill) || is_pblt ? 1'b1 : decoded[44]);
	localparam [3:0] tms34010_pkg_B_DPTCH_IDX = 4'd3;
	localparam [3:0] tms34010_pkg_B_DYDX_IDX = 4'd7;
	localparam [3:0] tms34010_pkg_B_INC2_IDX = 4'd12;
	assign rf_rs2_idx = (is_fill ? tms34010_pkg_B_DPTCH_IDX : (is_pblt ? (state_q == 6'd16 ? tms34010_pkg_B_COLOR1_IDX : (state_q == 6'd12 ? tms34010_pkg_B_DPTCH_IDX : tms34010_pkg_B_DADDR_IDX)) : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_DYDX_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_INC2_IDX : (is_line && (state_q == 6'd31) ? tms34010_pkg_B_COLOR1_IDX : (blmove_rd_b ? tms34010_pkg_B_DADDR_IDX : decoded[43-:4]))))));
	assign rf_rs3_file = ((decoded[51-:7] == 7'd89) || (decoded[51-:7] == 7'd91) ? decoded[44] : 1'b1);
	localparam [3:0] tms34010_pkg_B_COUNT_IDX = 4'd10;
	localparam [3:0] tms34010_pkg_B_OFFSET_IDX = 4'd4;
	localparam [3:0] tms34010_pkg_CPW_WEND_IDX = 4'd6;
	assign rf_rs3_idx = ((decoded[51-:7] == 7'd89) || (decoded[51-:7] == 7'd91) ? decoded[43-:4] + 4'd1 : (is_fill ? (state_q == 6'd9 ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_B_DYDX_IDX) : (is_pblt ? (state_q == 6'd12 ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_B_DYDX_IDX) : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_COUNT_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_OFFSET_IDX : (blmove_rd_b ? tms34010_pkg_B_DYDX_IDX : (((decoded[51-:7] == 7'd93) || decoded[3]) || is_drav ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_CPW_WEND_IDX)))))));
	wire rf_mm_file = decoded[44];
	wire [3:0] rf_mm_idx = mm_issue_reg_idx;
	reg dsj_precondition;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd36, 7'd40: dsj_precondition = 1'b1;
			7'd37: dsj_precondition = st_z;
			7'd38: dsj_precondition = !st_z;
			default: dsj_precondition = 1'b1;
		endcase
	end
	wire dsj_rd_nonzero;
	assign dsj_rd_nonzero = alu_result != {32 {1'sb0}};
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				dsjs_delay_q <= 4'd0;
				prev_wb_nop_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd7) && !pair_second_pass)
					prev_wb_nop_q <= decoded[51-:7] == 7'd31;
				if (((state_q == 6'd7) && (decoded[51-:7] == 7'd40)) && prev_wb_nop_q)
					dsjs_delay_q <= (dsj_rd_nonzero ? 4'd4 : 4'd9);
				else if ((state_q == 6'd43) && (dsjs_delay_q != 4'd0))
					dsjs_delay_q <= dsjs_delay_q - 4'd1;
			end
		end
	wire mmfm_mem_phase;
	wire mmfm_pop_wr;
	assign mmfm_mem_phase = (state_q == 6'd6) && is_mmfm;
	assign mmfm_pop_wr = mmfm_mem_phase && mem_ack;
	wire is_mv_store;
	wire is_mv_load;
	wire mv_postinc;
	wire mv_predec;
	wire mv_incdec;
	wire [31:0] mv_ptr;
	wire [31:0] mv_addr;
	wire [31:0] mv_ptr_new;
	wire mv_load_ptr_phase;
	wire mv_load_ptr_wr;
	assign is_mv_store = decoded[51-:7] == 7'd74;
	assign is_mv_load = decoded[51-:7] == 7'd75;
	assign mv_postinc = decoded[7-:2] == 2'b01;
	assign mv_predec = decoded[7-:2] == 2'b10;
	assign mv_incdec = mv_postinc || mv_predec;
	assign mv_ptr = ((is_mv_store || is_mv_off_ni) || is_mv_abs_ni ? rf_rs2_data : rf_rs1_data);
	assign mv_load_ptr_phase = ((state_q == 6'd6) && is_mv_load) && mv_incdec;
	assign mv_load_ptr_wr = mv_load_ptr_phase && mem_ack;
	wire [4:0] mv_fs_raw;
	wire [5:0] mv_fs;
	wire mv_fe;
	wire [31:0] mv_fs_ext;
	reg [31:0] mv_load_data;
	localparam [31:0] tms34010_pkg_ST_FS0_HI = 4;
	localparam [31:0] tms34010_pkg_ST_FS0_LO = 0;
	localparam [31:0] tms34010_pkg_ST_FS1_HI = 10;
	localparam [31:0] tms34010_pkg_ST_FS1_LO = 6;
	assign mv_fs_raw = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [5:0] sv2v_cast_13C0F;
		input reg [5:0] inp;
		sv2v_cast_13C0F = inp;
	endfunction
	assign mv_fs = (decoded[5] ? sv2v_cast_13C0F_signed(8) : (decoded[4] ? io_psize[5:0] : (mv_fs_raw == 5'd0 ? sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH) : {1'b0, mv_fs_raw})));
	localparam [31:0] tms34010_pkg_ST_FE0_BIT = 5;
	localparam [31:0] tms34010_pkg_ST_FE1_BIT = 11;
	assign mv_fe = (decoded[5] ? 1'b1 : (decoded[4] ? 1'b0 : (instr_word_q[9] ? st_value[tms34010_pkg_ST_FE1_BIT] : st_value[tms34010_pkg_ST_FE0_BIT])));
	assign mv_fs_ext = sv2v_cast_DEBC9(mv_fs);
	assign mv_fmask = (mv_fs >= sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH) ? {32 {1'sb1}} : (32'd1 << mv_fs) - 32'd1);
	always @(*) begin
		if (_sv2v_0)
			;
		if (mv_fs >= sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH))
			mv_load_data = mem_rdata_eff;
		else if (mv_fe && mem_rdata_eff[mv_fs - 6'd1])
			mv_load_data = mem_rdata_eff | ~mv_fmask;
		else
			mv_load_data = mem_rdata_eff & mv_fmask;
	end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				mv_load_data_q <= 1'sb0;
			else if (((state_q == 6'd6) && mem_ack) && (((decoded[51-:7] == 7'd75) || (decoded[51-:7] == 7'd78)) || (decoded[51-:7] == 7'd80)))
				mv_load_data_q <= mv_load_data;
			else if (((state_q == 6'd41) && mem_ack) && (srt_idx == {11 {1'sb0}}))
				mv_load_data_q <= {{16 {1'b0}}, mem_rdata_eff[15:0]};
		end
	assign srt_active = ((io_dpyctl_cpu[11] && decoded[4]) && !decoded[3]) && (is_mv_load || is_mv_store);
	assign srt_enter = (state_q == 6'd5) && srt_active;
	assign fill_srt_active = io_dpyctl_cpu[11] && is_fill;
	assign fill_srt_enter = (((state_q == 6'd9) && fill_srt_active) && (fill_dx_q != 16'd0)) && (fill_dy_q != 16'd0);
	function automatic [10:0] sv2v_cast_8D9A8;
		input reg [10:0] inp;
		sv2v_cast_8D9A8 = inp;
	endfunction
	assign srt_last = srt_idx == sv2v_cast_8D9A8(1023);
	assign srt_bit_addr = (srt_word_base + {{tms34010_pkg_DATA_WIDTH - SRT_IDX_W {1'b0}}, srt_idx}) << 4;
	assign srt_buf_we = (state_q == 6'd41) && mem_ack;
	assign fill_srt_span_bits = {17'd0, fill_dx_q} << (io_psize[4:0] == 5'd0 ? 5'd5 : pix_xy_xsh);
	assign fill_srt_first_words_wide = (({29'd0, fill_start[3:0]} + fill_srt_span_bits) + 33'd15) >> 4;
	assign fill_srt_first_words = fill_srt_first_words_wide[17:0];
	assign fill_srt_next_row_start = fill_srt_row_start_q + fill_dptch_q;
	assign fill_srt_next_words_wide = (({29'd0, fill_srt_next_row_start[3:0]} + {1'b0, fill_srt_span_bits_q}) + 33'd15) >> 4;
	assign fill_srt_next_words = fill_srt_next_words_wide[17:0];
	assign fill_srt_transfer_last = ((srt_fill_q && srt_last) && (fill_srt_words_left_q == 18'd1)) && (fill_srt_rows_left_q == 16'd1);
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (srt_buf_we)
				srt_buf[srt_idx[9:0]] <= mem_rdata_eff[15:0];
			srt_rdata_q <= srt_buf[srt_idx[9:0]];
		end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				srt_idx <= 1'sb0;
				srt_wr_phase <= 1'b0;
				srt_word_base <= 1'sb0;
				srt_fill_q <= 1'b0;
				fill_srt_row_start_q <= 1'sb0;
				fill_srt_word_addr_q <= 1'sb0;
				fill_srt_span_bits_q <= 1'sb0;
				fill_srt_words_left_q <= 1'sb0;
				fill_srt_rows_left_q <= 1'sb0;
			end
			else if (srt_enter) begin
				srt_idx <= 1'sb0;
				srt_wr_phase <= 1'b0;
				srt_fill_q <= 1'b0;
				srt_word_base <= mv_ptr >> 3;
			end
			else if (fill_srt_enter) begin
				srt_idx <= 1'sb0;
				srt_wr_phase <= 1'b0;
				srt_fill_q <= 1'b1;
				fill_srt_row_start_q <= fill_start;
				fill_srt_word_addr_q <= fill_start & 32'hfffffff0;
				fill_srt_span_bits_q <= fill_srt_span_bits[31:0];
				fill_srt_words_left_q <= fill_srt_first_words;
				fill_srt_rows_left_q <= fill_dy_q;
				srt_word_base <= (fill_start & 32'hfffffff0) >> 3;
			end
			else if (state_q == 6'd41) begin
				if (mem_ack)
					srt_idx <= srt_idx + 1'b1;
			end
			else if (state_q == 6'd42) begin
				if (!srt_wr_phase)
					srt_wr_phase <= 1'b1;
				else if (mem_ack) begin
					srt_wr_phase <= 1'b0;
					if (srt_fill_q && srt_last) begin
						if (fill_srt_words_left_q > 18'd1) begin
							srt_idx <= 1'sb0;
							fill_srt_words_left_q <= fill_srt_words_left_q - 1'b1;
							fill_srt_word_addr_q <= fill_srt_word_addr_q + 32'd16;
							srt_word_base <= (fill_srt_word_addr_q + 32'd16) >> 3;
						end
						else if (fill_srt_rows_left_q > 16'd1) begin
							srt_idx <= 1'sb0;
							fill_srt_rows_left_q <= fill_srt_rows_left_q - 1'b1;
							fill_srt_row_start_q <= fill_srt_next_row_start;
							fill_srt_word_addr_q <= fill_srt_next_row_start & 32'hfffffff0;
							fill_srt_words_left_q <= fill_srt_next_words;
							srt_word_base <= (fill_srt_next_row_start & 32'hfffffff0) >> 3;
						end
						else begin
							srt_idx <= srt_idx + 1'b1;
							srt_fill_q <= 1'b0;
						end
					end
					else
						srt_idx <= srt_idx + 1'b1;
				end
			end
		end
	wire [31:0] pixt_pmask_field;
	reg move_mem_cmd_class;
	reg move_mem_cmd_valid_q;
	reg move_mem_cmd_we_q;
	reg [31:0] move_mem_cmd_addr_q;
	reg [5:0] move_mem_cmd_size_q;
	reg [31:0] move_mem_cmd_wdata_q;
	wire [31:0] pixt_processed_ack;
	wire pixt_transp_ack;
	wire [31:0] pixt_merged_ack;
	assign pixt_rmw = decoded[4] && is_mv_store;
	assign pixt_pmask_field = {{16 {1'b0}}, io_pmask} & mv_fmask;
	reg [31:0] pixt_wstart_q;
	reg [31:0] pixt_wend_q;
	reg [31:0] pixt_ptr_q;
	wire pixt_in_window;
	wire pixt_clip_out;
	reg pixt_clip_out_q;
	assign pixt_xy_win = (pixt_rmw && decoded[3]) && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] != 2'd0);
	assign pixt_in_window = (((mv_ptr[15:0] >= pixt_wstart_q[15:0]) && (mv_ptr[15:0] <= pixt_wend_q[15:0])) && (mv_ptr[31:16] >= pixt_wstart_q[31:16])) && (mv_ptr[31:16] <= pixt_wend_q[31:16]);
	assign pixt_clip_out = pixt_xy_win && ((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1) || !pixt_in_window);
	assign pixt_processed_ack = ppop_apply(move_mem_cmd_wdata_q, mem_rdata_eff, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], mv_fmask);
	assign pixt_transp_ack = io_control[tms34010_pkg_CTRL_T_BIT] && ((pixt_processed_ack & mv_fmask) == {32 {1'sb0}});
	assign pixt_merged_ack = (pixt_transp_ack || pixt_clip_out_q ? mem_rdata_eff : (pixt_processed_ack & ~pixt_pmask_field) | (mem_rdata_eff & pixt_pmask_field));
	wire [31:0] pixt_processed_wr;
	wire pixt_transp_wr;
	wire [31:0] pixt_merged_wr;
	assign pixt_processed_wr = ppop_apply(move_mem_cmd_wdata_q, pix_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], mv_fmask);
	assign pixt_transp_wr = io_control[tms34010_pkg_CTRL_T_BIT] && ((pixt_processed_wr & mv_fmask) == {32 {1'sb0}});
	assign pixt_merged_wr = (pixt_transp_wr || pixt_clip_out_q ? pix_dest_q : (pixt_processed_wr & ~pixt_pmask_field) | (pix_dest_q & pixt_pmask_field));
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				pixt_wstart_q <= 1'sb0;
				pixt_wend_q <= 1'sb0;
				pixt_ptr_q <= 1'sb0;
				pixt_inside_q <= 1'b0;
				pixt_clip_out_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && pixt_rmw)
					pixt_ptr_q <= mv_ptr;
				if (state_q == 6'd37) begin
					pixt_wstart_q <= rf_wstart_data;
					pixt_wend_q <= rf_wend_data;
					pixt_clip_out_q <= (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1) || !((((pixt_ptr_q[15:0] >= rf_wstart_data[15:0]) && (pixt_ptr_q[15:0] <= rf_wend_data[15:0])) && (pixt_ptr_q[31:16] >= rf_wstart_data[31:16])) && (pixt_ptr_q[31:16] <= rf_wend_data[31:16]));
				end
				if ((((state_q == 6'd6) && pixt_rmw) && (mem_op_step == 2'd1)) && mem_ack)
					pixt_inside_q <= pixt_in_window;
			end
		end
	wire [15:0] pix_xy_conv;
	wire [4:0] pix_xy_yshift;
	wire [31:0] pix_xy_linear;
	assign pix_xy_conv = (is_mv_store ? io_convdp : io_convsp);
	assign pix_xy_yshift = 5'd31 - pix_xy_conv[4:0];
	localparam [4:0] tms34010_pkg_PIXELSHIFT_32 = 5'd5;
	localparam [15:0] tms34010_pkg_PSIZE_32BPP = 16'h0020;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (io_psize[4:0])
			5'd1: pix_xy_xsh = 5'd0;
			5'd2: pix_xy_xsh = 5'd1;
			5'd4: pix_xy_xsh = 5'd2;
			5'd8: pix_xy_xsh = 5'd3;
			5'd16: pix_xy_xsh = 5'd4;
			default: pix_xy_xsh = 5'd0;
		endcase
		if (tms34010_pkg_IS_34020 && (io_psize == tms34010_pkg_PSIZE_32BPP))
			pix_xy_xsh = tms34010_pkg_PIXELSHIFT_32;
	end
	assign pix_xy_linear = (({{16 {mv_ptr[31]}}, mv_ptr[31:16]} << pix_xy_yshift) | ({16'b0000000000000000, mv_ptr[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign mv_addr = (decoded[3] ? pix_xy_linear : (mv_predec ? mv_ptr - mv_fs_ext : mv_ptr));
	assign mv_ptr_new = (mv_predec ? mv_ptr - mv_fs_ext : mv_ptr + mv_fs_ext);
	wire [4:0] pix_xy_dst_yshift;
	assign pix_xy_dst_yshift = 5'd31 - io_convdp[4:0];
	assign pix_xy_dst_linear = (({{16 {rf_rs2_data[31]}}, rf_rs2_data[31:16]} << pix_xy_dst_yshift) | ({16'b0000000000000000, rf_rs2_data[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	wire is_mv_m2m;
	wire m2m_same_reg;
	wire m2m_src_phase;
	wire m2m_src_wr;
	wire [31:0] m2m_src_addr;
	wire [31:0] m2m_dst_addr;
	wire [31:0] m2m_src_new;
	wire [31:0] m2m_dst_new;
	assign is_mv_m2m = decoded[51-:7] == 7'd76;
	assign m2m_same_reg = decoded[39-:4] == decoded[43-:4];
	assign m2m_src_addr = (decoded[3] ? pix_xy_linear : (mv_predec ? rf_rs1_data - mv_fs_ext : rf_rs1_data));
	assign m2m_dst_addr = (decoded[3] ? pix_xy_dst_linear : (mv_predec ? rf_rs2_data - mv_fs_ext : rf_rs2_data));
	assign m2m_src_new = (mv_predec ? rf_rs1_data - mv_fs_ext : rf_rs1_data + mv_fs_ext);
	assign m2m_dst_new = (mv_predec ? rf_rs2_data - mv_fs_ext : rf_rs2_data + mv_fs_ext);
	assign m2m_src_phase = (((state_q == 6'd6) && is_mv_m2m) && mv_incdec) && (mem_op_step == 2'd0);
	assign m2m_src_wr = m2m_src_phase && mem_ack;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd74, 7'd75, 7'd79, 7'd80, 7'd77, 7'd78, 7'd76, 7'd99, 7'd100, 7'd101, 7'd102: move_mem_cmd_class = 1'b1;
			default: move_mem_cmd_class = 1'b0;
		endcase
	end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				move_mem_cmd_valid_q <= 1'b0;
				move_mem_cmd_we_q <= 1'b0;
				move_mem_cmd_addr_q <= 1'sb0;
				move_mem_cmd_size_q <= 1'sb0;
				move_mem_cmd_wdata_q <= 1'sb0;
			end
			else if ((state_q == 6'd5) && move_mem_cmd_class) begin
				move_mem_cmd_valid_q <= 1'b1;
				move_mem_cmd_size_q <= mv_fs;
				(* full_case, parallel_case *)
				case (decoded[51-:7])
					7'd74: begin
						move_mem_cmd_we_q <= !pixt_rmw;
						move_mem_cmd_addr_q <= mv_addr;
						move_mem_cmd_wdata_q <= (mv_predec && (decoded[39-:4] == decoded[43-:4]) ? mv_ptr_new : rf_rs1_data);
					end
					7'd75: begin
						move_mem_cmd_we_q <= 1'b0;
						move_mem_cmd_addr_q <= mv_addr;
						move_mem_cmd_wdata_q <= 1'sb0;
					end
					7'd79: begin
						move_mem_cmd_we_q <= 1'b1;
						move_mem_cmd_addr_q <= rf_rs2_data + imm32;
						move_mem_cmd_wdata_q <= rf_rs1_data;
					end
					7'd80: begin
						move_mem_cmd_we_q <= 1'b0;
						move_mem_cmd_addr_q <= rf_rs1_data + imm32;
						move_mem_cmd_wdata_q <= 1'sb0;
					end
					7'd77: begin
						move_mem_cmd_we_q <= 1'b1;
						move_mem_cmd_addr_q <= imm32;
						move_mem_cmd_wdata_q <= rf_rs1_data;
					end
					7'd78: begin
						move_mem_cmd_we_q <= 1'b0;
						move_mem_cmd_addr_q <= imm32;
						move_mem_cmd_wdata_q <= 1'sb0;
					end
					7'd76: begin
						move_mem_cmd_we_q <= 1'b0;
						move_mem_cmd_addr_q <= m2m_src_addr;
						move_mem_cmd_wdata_q <= 1'sb0;
					end
					7'd99: begin
						move_mem_cmd_we_q <= 1'b0;
						move_mem_cmd_addr_q <= imm32;
						move_mem_cmd_wdata_q <= 1'sb0;
					end
					default: begin
						move_mem_cmd_we_q <= 1'b0;
						move_mem_cmd_addr_q <= rf_rs1_data + imm32;
						move_mem_cmd_wdata_q <= 1'sb0;
					end
				endcase
			end
			else if (move_mem_cmd_valid_q && mem_ack)
				(* full_case, parallel_case *)
				case (decoded[51-:7])
					7'd74:
						if (pixt_rmw && (mem_op_step == 2'd0))
							move_mem_cmd_we_q <= 1'b1;
						else
							move_mem_cmd_valid_q <= 1'b0;
					7'd76:
						if (mem_op_step == 2'd0) begin
							move_mem_cmd_we_q <= 1'b1;
							if (m2m_same_reg && mv_incdec)
								move_mem_cmd_addr_q <= (mv_predec ? m2m_src_new - mv_fs_ext : m2m_src_new);
							else
								move_mem_cmd_addr_q <= m2m_dst_addr;
							move_mem_cmd_wdata_q <= mem_rdata_eff;
						end
						else
							move_mem_cmd_valid_q <= 1'b0;
					7'd99:
						if (mem_op_step == 2'd0) begin
							move_mem_cmd_we_q <= 1'b1;
							move_mem_cmd_addr_q <= imm2_32;
							move_mem_cmd_wdata_q <= mem_rdata_eff;
						end
						else
							move_mem_cmd_valid_q <= 1'b0;
					7'd100:
						if (mem_op_step == 2'd0) begin
							move_mem_cmd_we_q <= 1'b1;
							move_mem_cmd_addr_q <= rf_rs2_data + imm2_off_sext;
							move_mem_cmd_wdata_q <= mem_rdata_eff;
						end
						else
							move_mem_cmd_valid_q <= 1'b0;
					7'd101:
						if (mem_op_step == 2'd0) begin
							move_mem_cmd_we_q <= 1'b1;
							move_mem_cmd_addr_q <= rf_rs2_data;
							move_mem_cmd_wdata_q <= mem_rdata_eff;
						end
						else
							move_mem_cmd_valid_q <= 1'b0;
					default: move_mem_cmd_valid_q <= 1'b0;
				endcase
		end
	wire fill_wb;
	wire pblt_wb_saddr;
	wire pblt_wb_daddr;
	wire graphics_wb;
	assign fill_wb = state_q == 6'd11;
	assign pblt_wb_saddr = state_q == 6'd14;
	assign pblt_wb_daddr = state_q == 6'd15;
	wire line_wb_d;
	wire line_wb_daddr;
	wire line_wb_count;
	wire line_wb;
	assign line_wb_d = state_q == 6'd33;
	assign line_wb_daddr = state_q == 6'd34;
	assign line_wb_count = state_q == 6'd35;
	assign line_wb = (line_wb_d || line_wb_daddr) || line_wb_count;
	assign graphics_wb = ((fill_wb || pblt_wb_saddr) || pblt_wb_daddr) || line_wb;
	wire blmove_wb_b0;
	wire blmove_wb_b2;
	wire blmove_wb_b7;
	wire blmove_wb;
	assign blmove_wb_b0 = state_q == 6'd47;
	assign blmove_wb_b2 = state_q == 6'd48;
	assign blmove_wb_b7 = state_q == 6'd49;
	assign blmove_wb = (blmove_wb_b0 || blmove_wb_b2) || blmove_wb_b7;
	wire int_sp_wb;
	assign int_sp_wb = (state_q == 6'd20) && int_push_q;
	assign rf_wr_en = ((((((((((state_q == 6'd7) && decoded[14]) && dsj_precondition) && !(is_mm && (imm_lo_q == 16'd0))) && !(is_div && div_v)) || mmfm_pop_wr) || mv_load_ptr_wr) || m2m_src_wr) || graphics_wb) || blmove_wb) || int_sp_wb;
	assign rf_wr_file = (int_sp_wb ? 1'b0 : (graphics_wb || blmove_wb ? 1'b1 : decoded[44]));
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	assign rf_wr_idx = (int_sp_wb ? tms34010_pkg_REG_SP_IDX : (blmove_wb_b0 ? tms34010_pkg_B_SADDR_IDX : (blmove_wb_b2 ? tms34010_pkg_B_DADDR_IDX : (blmove_wb_b7 ? tms34010_pkg_B_DYDX_IDX : (line_wb_count ? tms34010_pkg_B_COUNT_IDX : ((fill_wb || pblt_wb_daddr) || line_wb_daddr ? tms34010_pkg_B_DADDR_IDX : (pblt_wb_saddr || line_wb_d ? tms34010_pkg_B_SADDR_IDX : (mmfm_mem_phase ? mm_iter_idx : (mv_load_ptr_phase || m2m_src_phase ? decoded[39-:4] : ((is_mpy || is_div) && pair_wb_step ? decoded[43-:4] + 4'd1 : decoded[43-:4]))))))))));
	wire [4:0] exgf_cur_fs;
	wire exgf_cur_fe;
	wire [31:0] exgf_new_rd;
	reg [31:0] exgf_new_st;
	assign exgf_cur_fs = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	assign exgf_cur_fe = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FE1_BIT] : st_value[tms34010_pkg_ST_FE0_BIT]);
	assign exgf_new_rd = {{26 {1'b0}}, exgf_cur_fe, exgf_cur_fs};
	always @(*) begin
		if (_sv2v_0)
			;
		exgf_new_st = st_value;
		if (instr_word_q[9]) begin
			exgf_new_st[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] = rf_rs2_data[4:0];
			exgf_new_st[tms34010_pkg_ST_FE1_BIT] = rf_rs2_data[5];
		end
		else begin
			exgf_new_st[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO] = rf_rs2_data[4:0];
			exgf_new_st[tms34010_pkg_ST_FE0_BIT] = rf_rs2_data[5];
		end
	end
	wire [15:0] xy_rs_x;
	wire [15:0] xy_rs_y;
	wire [15:0] xy_rd_x;
	wire [15:0] xy_rd_y;
	wire [15:0] xy_x_add;
	wire [15:0] xy_y_add;
	wire [15:0] xy_x_sub;
	wire [15:0] xy_y_sub;
	wire [31:0] addxy_result;
	wire [31:0] subxy_result;
	wire [3:0] addxy_flags;
	wire [3:0] subxy_flags;
	assign xy_rs_x = rf_rs1_data[15:0];
	assign xy_rs_y = rf_rs1_data[31:16];
	assign xy_rd_x = rf_rs2_data[15:0];
	assign xy_rd_y = rf_rs2_data[31:16];
	assign xy_x_add = xy_rd_x + xy_rs_x;
	assign xy_y_add = xy_rd_y + xy_rs_y;
	assign xy_x_sub = xy_rd_x - xy_rs_x;
	assign xy_y_sub = xy_rd_y - xy_rs_y;
	assign addxy_result = {xy_y_add, xy_x_add};
	assign subxy_result = {xy_y_sub, xy_x_sub};
	assign addxy_flags = {xy_x_add == 16'd0, xy_y_add[15], xy_y_add == 16'd0, xy_x_add[15]};
	assign subxy_flags = {xy_x_sub == 16'd0, $signed(xy_rs_y) > $signed(xy_rd_y), xy_y_sub == 16'd0, $signed(xy_rs_x) > $signed(xy_rd_x)};
	wire [3:0] cmpxy_flags;
	assign cmpxy_flags = {xy_x_sub == 16'd0, xy_y_sub[15], xy_y_sub == 16'd0, xy_x_sub[15]};
	wire [15:0] addxyi_x;
	wire [15:0] addxyi_y;
	wire [31:0] addxyi_result;
	wire [3:0] addxyi_flags;
	assign addxyi_x = xy_rd_x + imm32[15:0];
	assign addxyi_y = xy_rd_y + imm32[31:16];
	assign addxyi_result = {addxyi_y, addxyi_x};
	assign addxyi_flags = {addxyi_x == 16'd0, addxyi_y[15], addxyi_y == 16'd0, addxyi_x[15]};
	wire [4:0] rpix_pshift;
	wire [31:0] rpix_result;
	function automatic [4:0] tms34010_pkg_psize_pixelshift;
		input reg [15:0] psize;
		input reg is_34020;
		(* full_case, parallel_case *)
		case (psize)
			16'h0001: tms34010_pkg_psize_pixelshift = 5'd0;
			16'h0002: tms34010_pkg_psize_pixelshift = 5'd1;
			16'h0004: tms34010_pkg_psize_pixelshift = 5'd2;
			16'h0008: tms34010_pkg_psize_pixelshift = 5'd3;
			16'h0010: tms34010_pkg_psize_pixelshift = 5'd4;
			16'h0020: tms34010_pkg_psize_pixelshift = (is_34020 ? tms34010_pkg_PIXELSHIFT_32 : 5'd0);
			default: tms34010_pkg_psize_pixelshift = 5'd0;
		endcase
	endfunction
	assign rpix_pshift = tms34010_pkg_psize_pixelshift(io_psize, tms34010_pkg_IS_34020);
	function automatic [31:0] tms34010_pkg_rpix_replicate;
		input reg [31:0] v_in;
		input reg [4:0] pshift;
		reg [31:0] v;
		begin
			v = v_in;
			(* full_case, parallel_case *)
			case (pshift)
				5'd0: v = (v[0] ? 32'hffffffff : 32'h00000000);
				5'd1: begin
					v = v & 32'h00000003;
					v = v | (v << 2);
					v = v | (v << 4);
					v = v | (v << 8);
					v = v | (v << 16);
				end
				5'd2: begin
					v = v & 32'h0000000f;
					v = v | (v << 4);
					v = v | (v << 8);
					v = v | (v << 16);
				end
				5'd3: begin
					v = v & 32'h000000ff;
					v = v | (v << 8);
					v = v | (v << 16);
				end
				5'd4: begin
					v = v & 32'h0000ffff;
					v = v | (v << 16);
				end
				5'd5: v = v;
				default: v = v;
			endcase
			tms34010_pkg_rpix_replicate = v;
		end
	endfunction
	assign rpix_result = tms34010_pkg_rpix_replicate(rf_rs2_data, rpix_pshift);
	wire [17:0] setcdp_res;
	wire [1:0] setcdp_cls;
	wire [15:0] setcdp_convdp_val;
	function automatic signed [5:0] sv2v_cast_6_signed;
		input reg signed [5:0] inp;
		sv2v_cast_6_signed = inp;
	endfunction
	function automatic [5:0] tms34010_pkg_tms_bit_width32;
		input reg [31:0] x;
		integer b;
		reg [5:0] w;
		begin
			w = 6'd0;
			for (b = 0; b < 32; b = b + 1)
				if (x[b])
					w = sv2v_cast_6_signed(b + 1);
			tms34010_pkg_tms_bit_width32 = w;
		end
	endfunction
	function automatic [5:0] tms34010_pkg_tms_popcount32;
		input reg [31:0] x;
		integer b;
		reg [5:0] c;
		begin
			c = 6'd0;
			for (b = 0; b < 32; b = b + 1)
				c = c + {5'd0, x[b]};
			tms34010_pkg_tms_popcount32 = c;
		end
	endfunction
	function automatic [17:0] tms34010_pkg_setcdp_result;
		input reg [31:0] dptch;
		reg [5:0] pc;
		reg [5:0] v1;
		reg [5:0] v2;
		reg [15:0] cdp;
		reg [1:0] cls;
		begin
			pc = tms34010_pkg_tms_popcount32(dptch);
			v1 = tms34010_pkg_tms_bit_width32(dptch);
			v2 = tms34010_pkg_tms_bit_width32(dptch & ~(32'd1 << (v1 - 6'd1)));
			if ((dptch[0] == 1'b0) && (pc == 6'd1)) begin
				cdp = {10'd0, v1};
				cls = 2'd0;
			end
			else if ((dptch[0] == 1'b0) && (pc == 6'd2)) begin
				cdp = {10'd0, v2} | ({10'd0, v1} << 8);
				cls = 2'd1;
			end
			else begin
				cdp = 16'd0;
				cls = 2'd2;
			end
			tms34010_pkg_setcdp_result = {cls, cdp};
		end
	endfunction
	assign setcdp_res = tms34010_pkg_setcdp_result(rf_rs2_data);
	assign setcdp_cls = setcdp_res[17:16];
	assign setcdp_convdp_val = setcdp_res[15:0];
	wire setcdp_we;
	assign setcdp_we = (state_q == 6'd7) && (decoded[51-:7] == 7'd106);
	reg setcdp_we_q;
	reg [15:0] setcdp_convdp_q;
	always @(posedge clk)
		if (rst) begin
			setcdp_we_q <= 1'b0;
			setcdp_convdp_q <= 1'sb0;
		end
		else begin
			setcdp_we_q <= 1'b0;
			if ((ce_cpu !== 1'b0) && setcdp_we) begin
				setcdp_we_q <= 1'b1;
				setcdp_convdp_q <= setcdp_convdp_val;
			end
		end
	wire [15:0] cpw_pt_x;
	wire [15:0] cpw_pt_y;
	wire [15:0] cpw_ws_x;
	wire [15:0] cpw_ws_y;
	wire [15:0] cpw_we_x;
	wire [15:0] cpw_we_y;
	wire cpw_b5;
	wire cpw_b6;
	wire cpw_b7;
	wire cpw_b8;
	wire [31:0] cpw_result;
	wire [3:0] cpw_flags;
	assign cpw_pt_x = rf_rs1_data[15:0];
	assign cpw_pt_y = rf_rs1_data[31:16];
	assign cpw_ws_x = rf_wstart_data[15:0];
	assign cpw_ws_y = rf_wstart_data[31:16];
	assign cpw_we_x = rf_wend_data[15:0];
	assign cpw_we_y = rf_wend_data[31:16];
	assign cpw_b5 = $signed(cpw_ws_x) > $signed(cpw_pt_x);
	assign cpw_b6 = $signed(cpw_pt_x) > $signed(cpw_we_x);
	assign cpw_b7 = $signed(cpw_ws_y) > $signed(cpw_pt_y);
	assign cpw_b8 = $signed(cpw_pt_y) > $signed(cpw_we_y);
	assign cpw_result = {{23 {1'b0}}, cpw_b8, cpw_b7, cpw_b6, cpw_b5, 5'b00000};
	assign cpw_flags = {3'b000, ((cpw_b5 | cpw_b6) | cpw_b7) | cpw_b8};
	wire [4:0] cvxyl_ydp_shift;
	reg [4:0] cvxyl_xsh;
	wire [31:0] cvxyl_ypart;
	wire [31:0] cvxyl_xpart;
	wire [31:0] cvxyl_result;
	assign cvxyl_ydp_shift = 5'd31 - io_convdp[4:0];
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (io_psize[4:0])
			5'd1: cvxyl_xsh = 5'd0;
			5'd2: cvxyl_xsh = 5'd1;
			5'd4: cvxyl_xsh = 5'd2;
			5'd8: cvxyl_xsh = 5'd3;
			5'd16: cvxyl_xsh = 5'd4;
			default: cvxyl_xsh = 5'd0;
		endcase
		if (tms34010_pkg_IS_34020 && (io_psize == tms34010_pkg_PSIZE_32BPP))
			cvxyl_xsh = tms34010_pkg_PIXELSHIFT_32;
	end
	assign cvxyl_ypart = {{16 {rf_rs1_data[31]}}, rf_rs1_data[31:16]} << cvxyl_ydp_shift;
	assign cvxyl_xpart = {16'b0000000000000000, rf_rs1_data[15:0]} << cvxyl_xsh;
	assign cvxyl_result = (cvxyl_ypart | cvxyl_xpart) + rf_rs3_data;
	wire signed [63:0] mpy_sprod;
	wire [63:0] mpy_uprod;
	wire [63:0] mpy_product;
	reg [63:0] mpy_product_q;
	assign is_mpy = (decoded[51-:7] == 7'd87) || (decoded[51-:7] == 7'd88);
	assign mpy_signed = decoded[51-:7] == 7'd87;
	assign mpy_rd_even = decoded[40] == 1'b0;
	wire [4:0] mpy_fs1;
	wire [31:0] mpy_fmask;
	reg [31:0] mpy_rs_field;
	assign mpy_fs1 = st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO];
	assign mpy_fmask = (32'd1 << mpy_fs1) - 32'd1;
	always @(*) begin
		if (_sv2v_0)
			;
		if (mpy_fs1 == 5'd0)
			mpy_rs_field = rf_rs1_data;
		else if (mpy_signed && rf_rs1_data[mpy_fs1 - 5'd1])
			mpy_rs_field = (rf_rs1_data & mpy_fmask) | ~mpy_fmask;
		else
			mpy_rs_field = rf_rs1_data & mpy_fmask;
	end
	assign mpy_sprod = $signed(rf_rs2_data) * $signed(mpy_rs_field);
	assign mpy_uprod = rf_rs2_data * mpy_rs_field;
	assign mpy_product = (mpy_signed ? $unsigned(mpy_sprod) : mpy_uprod);
	wire is_signed_div;
	wire is_div_mod;
	wire div_rd_even;
	wire div_use_pair;
	reg [63:0] div_dividend;
	wire [31:0] div_divisor;
	wire [31:0] div_quotient;
	wire [31:0] div_remainder;
	wire div_start;
	wire div_busy;
	wire div_done;
	wire div_overflow;
	assign is_divu = decoded[51-:7] == 7'd89;
	assign is_modu = decoded[51-:7] == 7'd90;
	assign is_divs = decoded[51-:7] == 7'd91;
	assign is_mods = decoded[51-:7] == 7'd92;
	assign is_div = ((is_divu || is_modu) || is_divs) || is_mods;
	assign is_signed_div = is_divs || is_mods;
	assign is_div_mod = is_modu || is_mods;
	assign div_rd_even = decoded[40] == 1'b0;
	assign div_use_pair = (is_divu || is_divs) && div_rd_even;
	wire div_dvd_sign;
	wire div_dvs_sign;
	wire div_result_neg;
	reg div_dvd_sign_q;
	reg div_dvs_sign_q;
	assign div_dvd_sign = is_signed_div && rf_rs2_data[31];
	assign div_dvs_sign = is_signed_div && rf_rs1_data[31];
	assign div_result_neg = div_dvd_sign_q ^ div_dvs_sign_q;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				div_dvd_sign_q <= 1'b0;
				div_dvs_sign_q <= 1'b0;
			end
			else if ((state_q == 6'd5) && is_div) begin
				div_dvd_sign_q <= div_dvd_sign;
				div_dvs_sign_q <= div_dvs_sign;
			end
		end
	wire [31:0] rd_abs;
	wire [63:0] raw64;
	wire [63:0] abs64;
	assign rd_abs = (rf_rs2_data[31] ? ~rf_rs2_data + 1'b1 : rf_rs2_data);
	assign raw64 = {rf_rs2_data, rf_rs3_data};
	assign abs64 = (rf_rs2_data[31] ? ~raw64 + 1'b1 : raw64);
	always @(*) begin
		if (_sv2v_0)
			;
		if (!is_signed_div)
			div_dividend = (div_use_pair ? raw64 : {{tms34010_pkg_DATA_WIDTH {1'b0}}, rf_rs2_data});
		else if (div_use_pair)
			div_dividend = abs64;
		else
			div_dividend = {{tms34010_pkg_DATA_WIDTH {1'b0}}, rd_abs};
	end
	assign div_divisor = (div_dvs_sign ? ~rf_rs1_data + 1'b1 : rf_rs1_data);
	assign div_start = (state_q == 6'd5) && is_div;
	tms34010_divider u_divider(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.start(div_start),
		.dividend(div_dividend),
		.divisor(div_divisor),
		.busy(div_busy),
		.done(div_done),
		.quotient(div_quotient),
		.remainder(div_remainder),
		.overflow(div_overflow)
	);
	wire [31:0] div_quot_out;
	wire [31:0] div_rem_out;
	wire [31:0] div_result_main;
	assign div_quot_out = (div_result_neg ? ~div_quotient + 1'b1 : div_quotient);
	assign div_rem_out = (div_dvd_sign_q ? ~div_remainder + 1'b1 : div_remainder);
	assign div_result_main = (is_div_mod ? div_rem_out : div_quot_out);
	assign div_signed_ovf = div_overflow || (is_signed_div && (div_result_neg ? div_quotient[31] && (div_quotient[30:0] != {31 {1'sb0}}) : div_quotient[31]));
	assign div_v = (is_signed_div ? div_signed_ovf : div_overflow);
	assign is_pair_wb = (is_mpy && mpy_rd_even) || (div_use_pair && !div_v);
	assign pair_second_pass = is_pair_wb && (pair_wb_step == 1'b0);
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				mpy_product_q <= 1'sb0;
				pair_wb_step <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_mpy)
					mpy_product_q <= mpy_product;
				if (state_q == 6'd7)
					pair_wb_step <= (pair_second_pass ? 1'b1 : 1'b0);
				else
					pair_wb_step <= 1'b0;
			end
		end
	wire [4:0] fs_selected;
	reg [31:0] field_mask;
	reg field_msb;
	reg [31:0] sext_result;
	reg [31:0] zext_result;
	assign fs_selected = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	always @(*) begin
		if (_sv2v_0)
			;
		if (fs_selected == 5'd0) begin
			field_mask = 1'sb1;
			field_msb = rf_rs2_data[31];
			sext_result = rf_rs2_data;
			zext_result = rf_rs2_data;
		end
		else begin
			field_mask = (32'd1 << fs_selected) - 32'd1;
			field_msb = rf_rs2_data[fs_selected - 5'd1];
			sext_result = (field_msb ? (rf_rs2_data & field_mask) | ~field_mask : rf_rs2_data & field_mask);
			zext_result = rf_rs2_data & field_mask;
		end
	end
	reg [4:0] lmo_bit_pos;
	reg [31:0] lmo_result;
	function automatic signed [4:0] sv2v_cast_5_signed;
		input reg signed [4:0] inp;
		sv2v_cast_5_signed = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		lmo_bit_pos = 5'd0;
		begin : sv2v_autoblock_2
			reg signed [31:0] i;
			for (i = 0; i < tms34010_pkg_DATA_WIDTH; i = i + 1)
				if (rf_rs1_data[i])
					lmo_bit_pos = sv2v_cast_5_signed(i);
		end
		if (rf_rs1_data == {32 {1'sb0}})
			lmo_result = 1'sb0;
		else
			lmo_result = {{27 {1'b0}}, ~lmo_bit_pos};
	end
	localparam [31:0] tms34010_pkg_REV_VALUE = 32'h00000008;
	localparam [31:0] tms34010_pkg_WORD_BIT_SIZE_2 = sv2v_cast_DEBC9(64);
	always @(*) begin
		if (_sv2v_0)
			;
		if (int_sp_wb)
			rf_wr_data = rf_sp - tms34010_pkg_WORD_BIT_SIZE_2;
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd81: rf_wr_data = {rf_rs2_data[31:16], rf_rs1_data[15:0]};
				7'd82: rf_wr_data = {rf_rs1_data[31:16], rf_rs2_data[15:0]};
				7'd83: rf_wr_data = addxy_result;
				7'd84: rf_wr_data = subxy_result;
				7'd97: rf_wr_data = drav_advance;
				7'd86: rf_wr_data = cpw_result;
				7'd87, 7'd88: rf_wr_data = (mpy_rd_even ? (pair_wb_step ? mpy_product_q[31:0] : mpy_product_q[63:32]) : mpy_product_q[31:0]);
				7'd89, 7'd91: rf_wr_data = (div_rd_even && pair_wb_step ? div_rem_out : div_quot_out);
				7'd90, 7'd92: rf_wr_data = div_rem_out;
				7'd47: rf_wr_data = st_value;
				7'd72: rf_wr_data = mm_rp_q;
				7'd73: rf_wr_data = (mmfm_mem_phase ? mem_rdata_eff : mm_rp_q);
				7'd74: rf_wr_data = mv_ptr_new;
				7'd101: rf_wr_data = mv_ptr_new;
				7'd102: rf_wr_data = mv_ptr_new;
				7'd75: rf_wr_data = (mv_load_ptr_phase ? mv_ptr_new : mv_load_data_q);
				7'd76: rf_wr_data = (m2m_src_phase ? m2m_src_new : m2m_dst_new);
				7'd78, 7'd80: rf_wr_data = mv_load_data_q;
				7'd93: rf_wr_data = cvxyl_result;
				7'd94: rf_wr_data = fill_addr_q;
				7'd95: rf_wr_data = {fill_daddr_raw_q[31:16] + fill_dy_q, fill_daddr_raw_q[15:0]};
				7'd96: rf_wr_data = (pblt_wb_saddr ? pblt_src_addr_q : (decoded[1] ? {pblt_dst_xy_raw_q[31:16] + pblt_dy_q, pblt_dst_xy_raw_q[15:0]} : pblt_dst_addr_q));
				7'd98: rf_wr_data = (line_wb_d ? line_d_q : (line_wb_daddr ? line_daddr_q : line_count_q));
				7'd54, 7'd55: rf_wr_data = pc_value;
				7'd56: rf_wr_data = tms34010_pkg_REV_VALUE;
				7'd57: rf_wr_data = lmo_result;
				7'd59: rf_wr_data = sext_result;
				7'd60: rf_wr_data = zext_result;
				7'd61: rf_wr_data = exgf_new_rd;
				7'd103: rf_wr_data = rpix_result;
				7'd105: rf_wr_data = addxyi_result;
				7'd107: rf_wr_data = (blmove_wb_b0 ? blmove_b0_o : (blmove_wb_b2 ? blmove_b2_o : blmove_b7_o));
				default: rf_wr_data = (decoded[24] ? shifter_result : alu_result);
			endcase
	end
	assign alu_op = decoded[31-:4];
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd5, 7'd33, 7'd7, 7'd10, 7'd12, 7'd13, 7'd104, 7'd14, 7'd15, 7'd41, 7'd16, 7'd17, 7'd18, 7'd24, 7'd25, 7'd26, 7'd27, 7'd28, 7'd29, 7'd36, 7'd37, 7'd38, 7'd40, 7'd43, 7'd44: alu_a = rf_rs2_data;
			7'd42: alu_a = 1'sb0;
			7'd64, 7'd65, 7'd66, 7'd68, 7'd69, 7'd67, 7'd70, 7'd71: alu_a = rf_rs2_data;
			default: alu_a = rf_rs1_data;
		endcase
	end
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd17, 7'd18, 7'd25, 7'd26: alu_b = ~imm32;
			7'd1, 7'd2, 7'd16, 7'd24, 7'd27, 7'd28, 7'd29: alu_b = imm32;
			7'd3, 7'd12, 7'd13, 7'd104: alu_b = (decoded[23-:5] == 5'd0 ? 32'd32 : {{27 {1'b0}}, decoded[23-:5]});
			7'd36, 7'd37, 7'd38, 7'd40: alu_b = {{27 {1'b0}}, decoded[23-:5]};
			7'd43: alu_b = 32'd1 << decoded[23-:5];
			7'd44: alu_b = 32'd1 << rf_rs1_data[4:0];
			7'd64, 7'd65, 7'd66, 7'd68, 7'd69: alu_b = tms34010_pkg_WORD_BIT_SIZE;
			7'd67: alu_b = tms34010_pkg_WORD_BIT_SIZE + ({{27 {1'b0}}, decoded[23-:5]} << 4);
			7'd70: alu_b = tms34010_pkg_WORD_BIT_SIZE_2;
			7'd71: alu_b = (trap_skip_push ? 32'd0 : tms34010_pkg_WORD_BIT_SIZE_2);
			7'd5, 7'd33, 7'd7, 7'd10: alu_b = rf_rs1_data;
			default: alu_b = rf_rs2_data;
		endcase
	end
	assign alu_cin = st_c;
	wire mmtm020_n_wb = (tms34010_pkg_IS_34020 && (decoded[51-:7] == 7'd72)) && (state_q == 6'd7);
	assign st_flag_update_en = (((state_q == 6'd7) && decoded[13]) || mmtm020_n_wb) || fill_win_flag_wb;
	reg [31:0] setf_new_st;
	always @(*) begin
		if (_sv2v_0)
			;
		setf_new_st = st_value;
		if (instr_word_q[9]) begin
			setf_new_st[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] = instr_word_q[4:0];
			setf_new_st[tms34010_pkg_ST_FE1_BIT] = instr_word_q[5];
		end
		else begin
			setf_new_st[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO] = instr_word_q[4:0];
			setf_new_st[tms34010_pkg_ST_FE0_BIT] = instr_word_q[5];
		end
	end
	assign st_write_en = ((state_q == 6'd7) && ((((((((decoded[51-:7] == 7'd48) || (decoded[51-:7] == 7'd58)) || (decoded[51-:7] == 7'd61)) || (decoded[51-:7] == 7'd62)) || (decoded[51-:7] == 7'd63)) || (decoded[51-:7] == 7'd65)) || (decoded[51-:7] == 7'd70)) || (decoded[51-:7] == 7'd71))) || ((state_q == 6'd20) && int_push_q);
	localparam [31:0] tms34010_pkg_ST_IE_BIT = 21;
	localparam [31:0] tms34010_pkg_ST_RESET_VALUE = 32'h00000010;
	always @(*) begin
		if (_sv2v_0)
			;
		if (state_q == 6'd20)
			st_write_data = tms34010_pkg_ST_RESET_VALUE;
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd48: st_write_data = rf_rs1_data;
				7'd58: st_write_data = setf_new_st;
				7'd61: st_write_data = exgf_new_st;
				7'd62: st_write_data = st_value & ~(32'd1 << tms34010_pkg_ST_IE_BIT);
				7'd63: st_write_data = st_value | (32'd1 << tms34010_pkg_ST_IE_BIT);
				7'd65: st_write_data = mem_rdata_eff;
				7'd70: st_write_data = popped_st_q;
				7'd71: st_write_data = tms34010_pkg_ST_RESET_VALUE;
				default: st_write_data = 1'sb0;
			endcase
	end
	reg branch_taken;
	localparam [3:0] tms34010_pkg_CC_C = 4'b1000;
	localparam [3:0] tms34010_pkg_CC_EQ = 4'b1010;
	localparam [3:0] tms34010_pkg_CC_GE = 4'b0101;
	localparam [3:0] tms34010_pkg_CC_GT = 4'b0111;
	localparam [3:0] tms34010_pkg_CC_HI = 4'b0011;
	localparam [3:0] tms34010_pkg_CC_HS = 4'b1001;
	localparam [3:0] tms34010_pkg_CC_LE = 4'b0110;
	localparam [3:0] tms34010_pkg_CC_LS = 4'b0010;
	localparam [3:0] tms34010_pkg_CC_LT = 4'b0100;
	localparam [3:0] tms34010_pkg_CC_N = 4'b1110;
	localparam [3:0] tms34010_pkg_CC_NE = 4'b1011;
	localparam [3:0] tms34010_pkg_CC_NN = 4'b1111;
	localparam [3:0] tms34010_pkg_CC_NV = 4'b1101;
	localparam [3:0] tms34010_pkg_CC_P = 4'b0001;
	localparam [3:0] tms34010_pkg_CC_UC = 4'b0000;
	localparam [3:0] tms34010_pkg_CC_V = 4'b1100;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[18-:4])
			tms34010_pkg_CC_UC: branch_taken = 1'b1;
			tms34010_pkg_CC_P: branch_taken = !st_n & !st_z;
			tms34010_pkg_CC_LS: branch_taken = st_c | st_z;
			tms34010_pkg_CC_HI: branch_taken = !st_c & !st_z;
			tms34010_pkg_CC_LT: branch_taken = st_n ^ st_v;
			tms34010_pkg_CC_LE: branch_taken = (st_n ^ st_v) | st_z;
			tms34010_pkg_CC_GT: branch_taken = !(st_n ^ st_v) & !st_z;
			tms34010_pkg_CC_GE: branch_taken = !(st_n ^ st_v);
			tms34010_pkg_CC_EQ: branch_taken = st_z;
			tms34010_pkg_CC_NE: branch_taken = !st_z;
			tms34010_pkg_CC_HS: branch_taken = !st_c;
			tms34010_pkg_CC_C: branch_taken = st_c;
			tms34010_pkg_CC_V: branch_taken = st_v;
			tms34010_pkg_CC_NV: branch_taken = !st_v;
			tms34010_pkg_CC_N: branch_taken = st_n;
			tms34010_pkg_CC_NN: branch_taken = !st_n;
			default: branch_taken = 1'b0;
		endcase
	end
	always @(*) begin
		if (_sv2v_0)
			;
		pc_load_en = 1'b0;
		pc_load_value = 1'sb0;
		if (state_q == 6'd7)
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd11:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_short;
					end
				7'd34:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_long;
					end
				7'd35: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs1_data[31:4], 4'h0};
				end
				7'd55: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs2_data[31:4], 4'h0};
				end
				7'd36, 7'd37, 7'd38:
					if (dsj_precondition && dsj_rd_nonzero) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_long;
					end
				7'd39:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_jacc;
					end
				7'd40:
					if (dsj_rd_nonzero) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_dsjs;
					end
				7'd66: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs1_data[31:4], 4'h0};
				end
				7'd68: begin
					pc_load_en = 1'b1;
					pc_load_value = branch_target_jacc;
				end
				7'd69: begin
					pc_load_en = 1'b1;
					pc_load_value = branch_target_long;
				end
				7'd67: begin
					pc_load_en = 1'b1;
					pc_load_value = mem_rdata_eff;
				end
				7'd70: begin
					pc_load_en = 1'b1;
					pc_load_value = popped_pc_q;
				end
				7'd71: begin
					pc_load_en = 1'b1;
					pc_load_value = popped_pc_q;
				end
				default:
					;
			endcase
		else if (state_q == 6'd20) begin
			pc_load_en = 1'b1;
			pc_load_value = popped_pc_q;
		end
		else if ((state_q == 6'd38) && mem_ack) begin
			pc_load_en = 1'b1;
			pc_load_value = mem_rdata_eff;
		end
	end
	tms34010_regfile u_regfile(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.rs1_file(rf_rs1_file),
		.rs1_idx(rf_rs1_idx),
		.rs1_data(rf_rs1_data),
		.rs2_file(rf_rs2_file),
		.rs2_idx(rf_rs2_idx),
		.rs2_data(rf_rs2_data),
		.rs3_file(rf_rs3_file),
		.rs3_idx(rf_rs3_idx),
		.rs3_data(rf_rs3_data),
		.rs4_file(rf_mm_file),
		.rs4_idx(rf_mm_idx),
		.rs4_data(rf_mm_data),
		.wstart_data(rf_wstart_data),
		.wend_data(rf_wend_data),
		.wr_en(rf_wr_en),
		.wr_file(rf_wr_file),
		.wr_idx(rf_wr_idx),
		.wr_data(rf_wr_data),
		.sp_o(rf_sp)
	);
	wire io_is_io;
	wire [15:0] io_rdata16;
	wire [15:0] io_rdata_cpu16;
	wire [31:0] io_display_pair_rdata;
	wire [15:0] io_intenb;
	wire [15:0] io_intpend;
	wire [15:0] io_hstctlh;
	wire [15:0] io_intenb_live;
	wire [15:0] io_intpend_live;
	wire [15:0] io_hstctlh_live;
	wire nmi_clear;
	reg mem_we_int;
	wire io_wr_valid;
	wire [31:0] io_wr_addr;
	wire [15:0] io_wr_data;
	wire [5:0] io_wr_size;
	wire [15:0] io_wr_mask;
	wire [15:0] io_wr_data_sh;
	wire io_wr_status_guard;
	wire [15:0] io_wr_display_hi;
	wire io_wr_display_pair;
	tms34010_io_write_boundary u_io_write_boundary(
		.clk(clk),
		.rst(rst),
		.ce_cpu(ce_cpu),
		.req(mem_req),
		.we(mem_we_int),
		.is_io(io_is_io),
		.ack(mem_ack),
		.addr(mem_addr),
		.wdata(mem_wdata[15:0]),
		.wdata_hi(mem_wdata[31:16]),
		.size(mem_size),
		.wr_valid(io_wr_valid),
		.wr_addr(io_wr_addr),
		.wr_data(io_wr_data),
		.wr_size(io_wr_size),
		.wr_mask(io_wr_mask),
		.wr_data_sh(io_wr_data_sh),
		.wr_display_hi(io_wr_display_hi),
		.wr_display_pair(io_wr_display_pair),
		.wr_status_guard(io_wr_status_guard)
	);
	tms34010_io_regs u_io_regs(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.req(io_wr_valid),
		.we(1'b1),
		.addr(io_wr_addr),
		.wdata(io_wr_data),
		.wr_size(io_wr_size),
		.wr_mask(io_wr_mask),
		.wr_data_sh(io_wr_data_sh),
		.wr_pre_valid(1'b1),
		.status_guard(io_wr_status_guard),
		.wr_display_hi(io_wr_display_hi),
		.wr_display_pair(io_wr_display_pair),
		.raddr(mem_addr),
		.setcdp_we(setcdp_we_q),
		.setcdp_convdp(setcdp_convdp_q),
		.rdata(io_rdata16),
		.display_pair_rdata(io_display_pair_rdata),
		.is_io(io_is_io),
		.psize_o(io_psize_live),
		.convdp_o(io_convdp_live),
		.convsp_o(io_convsp_live),
		.control_o(io_control_live),
		.pmask_o(io_pmask_live),
		.intenb_o(io_intenb_live),
		.intpend_o(io_intpend_live),
		.dpyctl_o(io_dpyctl),
		.dpystrt_o(dpystrt_o),
		.dbg_dpyst_value_o(dbg_dpyst_value_o),
		.dbg_dpyst_valid_o(dbg_dpyst_valid_o),
		.dpytap_o(dpytap_o),
		.dpyadr_o(dpyadr_o),
		.display_row_o(display_row_o),
		.display_col_o(display_col_o),
		.display_yoffset_o(display_yoffset_o),
		.display_enable_o(display_enable_o),
		.display_blank_o(display_blank_o),
		.vblank_start_o(vblank_start_o),
		.hstctlh_o(io_hstctlh_live),
		.timing_start_o(timing_start_o),
		.nmi_clear(nmi_clear),
		.wvp_set(wvp_set_q),
		.lint1_in(lint1_in),
		.lint2_in(lint2_in),
		.video_hcount_o(video_hcount_o),
		.video_vcount_o(video_vcount_o),
		.video_heblnk_o(video_heblnk_o),
		.video_hsblnk_o(video_hsblnk_o),
		.video_veblnk_o(video_veblnk_o),
		.video_vsblnk_o(video_vsblnk_o),
		.video_hs_o(video_hs_o),
		.video_vs_o(video_vs_o),
		.video_hb_o(video_hb_o),
		.video_vb_o(video_vb_o),
		.video_ready_o(video_ready_o)
	);
	tms34010_io_cpu_config u_io_cpu_config(
		.clk(clk),
		.rst(rst),
		.ce_cpu(ce_cpu),
		.req(mem_req),
		.we(mem_we_int),
		.is_io(io_is_io),
		.ack(mem_ack),
		.addr(mem_addr),
		.wdata(mem_wdata[15:0]),
		.size(mem_size),
		.live_psize(io_psize_live),
		.live_convdp(io_convdp_live),
		.live_convsp(io_convsp_live),
		.live_control(io_control_live),
		.live_pmask(io_pmask_live),
		.live_dpyctl(io_dpyctl),
		.psize(io_psize),
		.convdp(io_convdp),
		.convsp(io_convsp),
		.control(io_control),
		.pmask(io_pmask),
		.dpyctl(io_dpyctl_cpu)
	);
	tms34010_io_cpu_status u_io_cpu_status(
		.clk(clk),
		.rst(rst),
		.ce_cpu(ce_cpu),
		.req(mem_req),
		.we(mem_we_int),
		.is_io(io_is_io),
		.ack(mem_ack),
		.addr(mem_addr),
		.wdata(mem_wdata[15:0]),
		.size(mem_size),
		.live_intenb(io_intenb_live),
		.live_intpend(io_intpend_live),
		.live_hstctlh(io_hstctlh_live),
		.nmi_clear(nmi_clear),
		.intenb(io_intenb),
		.intpend(io_intpend),
		.hstctlh(io_hstctlh)
	);
	tms34010_io_cpu_read_mux u_io_cpu_read_mux(
		.is_io(io_is_io),
		.addr(mem_addr),
		.live_rdata(io_rdata16),
		.psize(io_psize),
		.convdp(io_convdp),
		.convsp(io_convsp),
		.control(io_control),
		.pmask(io_pmask),
		.intenb(io_intenb),
		.intpend(io_intpend),
		.hstctlh(io_hstctlh),
		.cpu_rdata(io_rdata_cpu16)
	);
	wire int_req;
	wire [31:0] int_vector;
	tms34010_int_ctrl u_int_ctrl(
		.intpend(io_intpend),
		.intenb(io_intenb),
		.ie(st_value[tms34010_pkg_ST_IE_BIT]),
		.int_req(int_req),
		.int_vector(int_vector)
	);
	wire nmi_req;
	wire nmi_nmim;
	localparam [31:0] tms34010_pkg_HSTCTL_NMI_BIT = 8;
	assign nmi_req = io_hstctlh[tms34010_pkg_HSTCTL_NMI_BIT];
	localparam [31:0] tms34010_pkg_HSTCTL_NMIM_BIT = 9;
	assign nmi_nmim = io_hstctlh[tms34010_pkg_HSTCTL_NMIM_BIT];
	wire int_take;
	assign int_take = nmi_req || int_req;
	reg fetch_inflight_q;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				fetch_inflight_q <= 1'b0;
			else if (((state_q == 6'd1) && mem_req) && !mem_ack)
				fetch_inflight_q <= 1'b1;
			else if (mem_ack || (state_q != 6'd1))
				fetch_inflight_q <= 1'b0;
		end
	reg [31:0] int_vec_q;
	reg int_is_nmi_q;
	localparam [31:0] tms34010_pkg_INT_VEC_NMI = 32'hfffffee0;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				int_vec_q <= 1'sb0;
				int_is_nmi_q <= 1'b0;
				int_push_q <= 1'b0;
			end
			else if ((state_q == 6'd1) && int_take) begin
				int_vec_q <= (nmi_req ? tms34010_pkg_INT_VEC_NMI : int_vector);
				int_is_nmi_q <= nmi_req;
				int_push_q <= (nmi_req ? !nmi_nmim : 1'b1);
			end
		end
	assign nmi_clear = (state_q == 6'd20) && int_is_nmi_q;
	assign mem_we = mem_we_int && !io_is_io;
	reg [31:0] io_rdata_q;
	reg io_is_io_q;
	reg [31:0] io_rdata_req_q;
	reg io_rdata_req_valid_q;
	function automatic tms34010_pkg_io020_display_pair;
		input reg [31:0] a;
		tms34010_pkg_io020_display_pair = tms34010_pkg_IS_34020 && (((a == 32'hc0000200) || (a == 32'hc0000220)) || (a == 32'hc0000240));
	endfunction
	always @(posedge clk)
		if (rst) begin
			io_rdata_req_q <= 1'sb0;
			io_rdata_req_valid_q <= 1'b0;
		end
		else if ((ce_cpu !== 1'b0) && !(mem_req && io_is_io))
			io_rdata_req_valid_q <= 1'b0;
		else if ((ce_cpu !== 1'b0) && mem_ack)
			io_rdata_req_valid_q <= 1'b0;
		else if ((ce_cpu !== 1'b0) && !io_rdata_req_valid_q) begin
			io_rdata_req_q <= (tms34010_pkg_io020_display_pair(mem_addr) && (mem_size == sv2v_cast_13C0F_signed(32)) ? io_display_pair_rdata : {16'd0, io_rdata_cpu16 >> mem_addr[3:0]});
			io_rdata_req_valid_q <= 1'b1;
		end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				io_rdata_q <= 1'sb0;
				io_is_io_q <= 1'b0;
			end
			else if (mem_req && mem_ack) begin
				io_rdata_q <= io_rdata_req_q;
				io_is_io_q <= io_is_io;
			end
		end
	assign mem_rdata_eff = (mem_req ? (io_rdata_req_valid_q ? io_rdata_req_q : mem_rdata) : (io_is_io_q ? io_rdata_q : mem_rdata));
	tms34010_alu u_alu(
		.op(alu_op),
		.a(alu_a),
		.b(alu_b),
		.cin(alu_cin),
		.result(alu_result),
		.flags(alu_flags)
	);
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	reg [4:0] shifter_amount;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd49, 7'd50, 7'd53: shifter_amount = rf_rs1_data[4:0];
			7'd51, 7'd52: shifter_amount = ~rf_rs1_data[4:0] + {{4 {1'b0}}, 1'b1};
			7'd21, 7'd22: shifter_amount = ~decoded[23-:5] + {{4 {1'b0}}, 1'b1};
			default: shifter_amount = decoded[23-:5];
		endcase
	end
	tms34010_shifter u_shifter(
		.op(decoded[27-:3]),
		.a(rf_rs2_data),
		.amount(shifter_amount),
		.result(shifter_result),
		.flags(shifter_flags)
	);
	reg [3:0] flag_input;
	always @(*) begin
		if (_sv2v_0)
			;
		if (fill_win_flag_wb)
			flag_input = {3'b000, fill_win_violation};
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd46: flag_input = 4'b0100;
				7'd45: flag_input = 4'b0000;
				7'd42: flag_input = {alu_result[31], alu_result != 1'b0, alu_result == 1'b0, alu_result == 32'h80000000};
				7'd57: flag_input = {2'b00, rf_rs1_data == 1'b0, 1'b0};
				7'd59: flag_input = {sext_result[31], 1'b0, sext_result == 1'b0, 1'b0};
				7'd60: flag_input = {2'b00, zext_result == 1'b0, 1'b0};
				7'd72: flag_input = {~rf_rs2_data[31], 3'b000};
				7'd75, 7'd78, 7'd80: flag_input = {mv_load_data_q[31], 1'b0, mv_load_data_q == 1'b0, decoded[4] && (mv_load_data_q != 1'b0)};
				7'd83: flag_input = addxy_flags;
				7'd105: flag_input = addxyi_flags;
				7'd84: flag_input = subxy_flags;
				7'd85: flag_input = cmpxy_flags;
				7'd86: flag_input = cpw_flags;
				7'd87, 7'd88: flag_input = {mpy_product_q[63], 1'b0, mpy_product_q == 64'd0, 1'b0};
				7'd89, 7'd91, 7'd90, 7'd92: flag_input = {(is_signed_div && !div_v) && div_result_main[31], 1'b0, !div_v && (div_result_main == 1'b0), div_v};
				default: flag_input = (decoded[24] ? shifter_flags : alu_flags);
			endcase
	end
	reg [3:0] effective_flag_mask;
	always @(*) begin
		if (_sv2v_0)
			;
		effective_flag_mask = decoded[12-:4];
		if (mmtm020_n_wb)
			effective_flag_mask = 4'b1000;
		if (fill_win_flag_wb)
			effective_flag_mask = 4'b0001;
	end
	tms34010_status_reg u_status_reg(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.flag_update_en(st_flag_update_en),
		.flags_in(flag_input),
		.flag_update_mask(effective_flag_mask),
		.st_write_en(st_write_en),
		.st_write_data(st_write_data),
		.st_o(st_value),
		.n_o(st_n),
		.c_o(st_c),
		.z_o(st_z),
		.v_o(st_v)
	);
	reg [4:0] cycle_reg_list_count;
	wire [15:0] cycle_budget;
	wire cycle_budget_valid;
	localparam [5:0] GFX_RETIRE_STATE = 6'd44;
	reg gfx_timing_start;
	wire gfx_timing_busy;
	wire gfx_timing_done;
	wire [31:0] gfx_timing_cycles;
	wire gfx_timing_overflow;
	reg [31:0] gfx_timing_saddr_raw_q;
	reg [31:0] gfx_timing_daddr_raw_q;
	reg [31:0] gfx_timing_offset_q;
	reg [31:0] gfx_timing_saddr;
	reg [31:0] gfx_timing_daddr;
	reg [31:0] gfx_timing_dydx;
	reg [31:0] gfx_timing_sptch;
	reg [31:0] gfx_timing_dptch;
	reg [31:0] gfx_timing_offset;
	reg [31:0] gfx_timing_wstart;
	reg [31:0] gfx_timing_wend;
	reg gfx_timing_is_fill;
	reg gfx_timing_is_binary;
	reg gfx_timing_src_xy;
	reg gfx_timing_dst_xy;
	reg gfx_timing_fits_16;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				gfx_timing_saddr_raw_q <= 32'd0;
				gfx_timing_daddr_raw_q <= 32'd0;
				gfx_timing_offset_q <= 32'd0;
			end
			else begin
				if ((state_q == 6'd5) && is_pblt) begin
					gfx_timing_saddr_raw_q <= rf_rs1_data;
					gfx_timing_daddr_raw_q <= rf_rs2_data;
				end
				else if ((state_q == 6'd5) && is_fill) begin
					gfx_timing_saddr_raw_q <= 32'd0;
					gfx_timing_daddr_raw_q <= rf_rs1_data;
				end
				if ((state_q == 6'd9) || (state_q == 6'd12))
					gfx_timing_offset_q <= rf_rs3_data;
			end
		end
	always @(*) begin
		if (_sv2v_0)
			;
		gfx_timing_start = ((((state_q == 6'd9) && (!fill_is_xy || (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd0))) || (state_q == 6'd21)) || ((state_q == 6'd12) && (!decoded[1] || (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd0)))) || (state_q == 6'd22);
		gfx_timing_is_fill = is_fill;
		gfx_timing_is_binary = is_pblt && decoded[0];
		gfx_timing_src_xy = is_pblt && decoded[2];
		gfx_timing_dst_xy = (is_fill ? fill_is_xy : is_pblt && decoded[1]);
		gfx_timing_saddr = gfx_timing_saddr_raw_q;
		gfx_timing_daddr = gfx_timing_daddr_raw_q;
		gfx_timing_dydx = (is_fill ? {fill_dy_q, fill_dx_q} : {pblt_dy_q, pblt_dx_q});
		if (state_q == 6'd9) begin
			gfx_timing_sptch = 32'd0;
			gfx_timing_dptch = rf_rs2_data;
			gfx_timing_offset = rf_rs3_data;
		end
		else if (state_q == 6'd12) begin
			gfx_timing_sptch = rf_rs1_data;
			gfx_timing_dptch = rf_rs2_data;
			gfx_timing_offset = rf_rs3_data;
		end
		else begin
			gfx_timing_sptch = pblt_sptch_q;
			gfx_timing_dptch = (is_fill ? fill_dptch_q : pblt_dptch_q);
			gfx_timing_offset = gfx_timing_offset_q;
		end
		gfx_timing_wstart = ((state_q == 6'd21) || (state_q == 6'd22) ? rf_rs1_data : 32'd0);
		gfx_timing_wend = ((state_q == 6'd21) || (state_q == 6'd22) ? rf_rs2_data : 32'd0);
		gfx_timing_fits_16 = (gfx_timing_done && !gfx_timing_overflow) && (gfx_timing_cycles[31:16] == 16'd0);
	end
	tms34010_gfx_cycle_counter u_gfx_cycle_counter(
		.clk(clk),
		.rst(rst),
		.ce(ce_cpu),
		.start(gfx_timing_start),
		.is_fill(gfx_timing_is_fill),
		.is_binary(gfx_timing_is_binary),
		.src_xy(gfx_timing_src_xy),
		.dst_xy(gfx_timing_dst_xy),
		.saddr(gfx_timing_saddr),
		.daddr(gfx_timing_daddr),
		.dydx(gfx_timing_dydx),
		.sptch(gfx_timing_sptch),
		.dptch(gfx_timing_dptch),
		.offset(gfx_timing_offset),
		.wstart(gfx_timing_wstart),
		.wend(gfx_timing_wend),
		.convsp(io_convsp),
		.convdp(io_convdp),
		.psize(io_psize),
		.control(io_control),
		.busy(gfx_timing_busy),
		.done(gfx_timing_done),
		.cycles(gfx_timing_cycles),
		.overflow(gfx_timing_overflow)
	);
	always @(*) begin
		if (_sv2v_0)
			;
		cycle_reg_list_count = (((((((((((((({4'd0, imm_lo_q[0]} + {4'd0, imm_lo_q[1]}) + {4'd0, imm_lo_q[2]}) + {4'd0, imm_lo_q[3]}) + {4'd0, imm_lo_q[4]}) + {4'd0, imm_lo_q[5]}) + {4'd0, imm_lo_q[6]}) + {4'd0, imm_lo_q[7]}) + {4'd0, imm_lo_q[8]}) + {4'd0, imm_lo_q[9]}) + {4'd0, imm_lo_q[10]}) + {4'd0, imm_lo_q[11]}) + {4'd0, imm_lo_q[12]}) + {4'd0, imm_lo_q[13]}) + {4'd0, imm_lo_q[14]}) + {4'd0, imm_lo_q[15]};
	end
	tms34010_cycle_budget u_cycle_budget(
		.iclass(decoded[51-:7]),
		.instr_word(instr_word_q),
		.branch_taken(branch_taken),
		.dsj_precondition(dsj_precondition),
		.dsj_rd_nonzero(dsj_rd_nonzero),
		.reg_list_count(cycle_reg_list_count),
		.move_mode(decoded[7-:2]),
		.force_byte(decoded[5]),
		.force_pixel(decoded[4]),
		.xy_addr(decoded[3]),
		.rd_odd(decoded[40]),
		.line_count(line_initial_count_q),
		.gfx_cycles(gfx_timing_cycles[15:0]),
		.gfx_cycles_valid(gfx_timing_fits_16),
		.pixelshift(rpix_pshift),
		.setcdp_class(setcdp_cls),
		.blmove_cycles_in(blmove_cycles),
		.cycles(cycle_budget),
		.valid(cycle_budget_valid)
	);
	assign instruction_cycles_o = (timing_interrupt_q ? 16'd16 : cycle_budget);
	assign instruction_cycles_valid_o = (timing_interrupt_q ? 1'b1 : cycle_budget_valid);
	localparam [5:0] tms34010_pkg_MEM_SIZE_32 = sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH);
	localparam [31:0] tms34010_pkg_TRAP_VECTOR_BASE = 32'hffffffe0;
	always @(*) begin
		if (_sv2v_0)
			;
		state_d = state_q;
		mem_req = 1'b0;
		mem_we_int = 1'b0;
		mem_addr = 1'sb0;
		mem_size = 1'sb0;
		mem_wdata = 1'sb0;
		mem_srt = 1'b0;
		pc_advance_en = 1'b0;
		(* full_case, parallel_case *)
		case (state_q)
			6'd0: state_d = 6'd38;
			6'd38: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = tms34010_pkg_TRAP_VECTOR_BASE;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				if (mem_ack)
					state_d = 6'd1;
			end
			6'd1:
				if (int_take && !fetch_inflight_q)
					state_d = (nmi_req && nmi_nmim ? 6'd19 : 6'd18);
				else begin
					mem_req = 1'b1;
					mem_we_int = 1'b0;
					mem_addr = pc_value;
					mem_size = tms34010_pkg_INSTR_WORD_BITS;
					if (mem_ack) begin
						state_d = 6'd2;
						pc_advance_en = 1'b1;
					end
				end
			6'd18: begin
				mem_req = 1'b1;
				mem_we_int = 1'b1;
				mem_addr = rf_sp - tms34010_pkg_WORD_BIT_SIZE;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				mem_wdata = pc_value;
				if (mem_ack)
					state_d = 6'd17;
			end
			6'd17: begin
				mem_req = 1'b1;
				mem_we_int = 1'b1;
				mem_addr = rf_sp - tms34010_pkg_WORD_BIT_SIZE_2;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				mem_wdata = st_value;
				if (mem_ack)
					state_d = 6'd19;
			end
			6'd19: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = int_vec_q;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				if (mem_ack)
					state_d = 6'd20;
			end
			6'd20: state_d = 6'd1;
			6'd2:
				if (decoded[33])
					state_d = 6'd3;
				else if (decoded[34])
					state_d = 6'd3;
				else
					state_d = 6'd5;
			6'd3: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (decoded[33] ? 6'd4 : (is_mv_off_m2m ? 6'd39 : 6'd5));
				end
			end
			6'd4: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (is_mv_abs_m2m ? 6'd39 : 6'd5);
				end
			end
			6'd39: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (is_mv_off_m2m ? 6'd5 : 6'd40);
				end
			end
			6'd40: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = 6'd5;
				end
			end
			6'd5:
				if (is_div)
					state_d = 6'd8;
				else if (is_fill)
					state_d = 6'd9;
				else if (is_pblt)
					state_d = 6'd12;
				else if (is_drav)
					state_d = (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] != 2'd0 ? 6'd28 : 6'd27);
				else if (is_line)
					state_d = 6'd29;
				else if (is_blmove)
					state_d = 6'd45;
				else if (pixt_xy_win)
					state_d = 6'd37;
				else if (is_mm && (imm_lo_q == 16'd0))
					state_d = 6'd7;
				else
					state_d = (decoded[8] ? 6'd6 : 6'd7);
			6'd8: state_d = (div_done ? 6'd7 : 6'd8);
			6'd9: state_d = (((fill_dx_q[15] || fill_dy_q[15]) || (fill_dx_q == 16'd0)) || (fill_dy_q == 16'd0) ? GFX_RETIRE_STATE : ((fill_win_en_q || fill_w2_q) || fill_w1_q ? 6'd21 : 6'd10));
			6'd21: state_d = (fill_w1_q ? 6'd25 : (fill_w2_q && !fill_array_inside ? 6'd23 : 6'd10));
			6'd23: state_d = GFX_RETIRE_STATE;
			6'd25: state_d = GFX_RETIRE_STATE;
			6'd28: state_d = (((drav_w_q == 2'd2) || (drav_w_q == 2'd3)) && drav_in_window ? 6'd27 : 6'd7);
			6'd37: state_d = 6'd6;
			6'd27: begin
				mem_req = drav_cmd_valid_q;
				mem_addr = drav_linear_q;
				mem_size = drav_cmd_size_q;
				mem_we_int = drav_cmd_we_q;
				mem_wdata = drav_cmd_wdata_q;
				mem_srt = drav_cmd_srt_q;
				if (mem_ack && (drav_phase_q == 2'd3))
					state_d = 6'd7;
				else
					state_d = 6'd27;
			end
			6'd29: state_d = 6'd30;
			6'd30: state_d = 6'd31;
			6'd31: state_d = (line_count_q == {32 {1'sb0}} ? 6'd33 : (line_win_en ? 6'd36 : 6'd32));
			6'd36: state_d = 6'd32;
			6'd32: begin
				mem_req = 1'b1;
				mem_addr = line_linear;
				mem_size = io_psize[5:0];
				if (!line_substep_q)
					mem_we_int = 1'b0;
				else begin
					mem_we_int = 1'b1;
					mem_wdata = line_merged;
				end
				if ((mem_ack && line_substep_q) && ((line_count_q == 32'd1) || line_abort))
					state_d = 6'd33;
				else
					state_d = 6'd32;
			end
			6'd33: state_d = 6'd34;
			6'd34: state_d = 6'd35;
			6'd35: state_d = 6'd1;
			6'd45: state_d = 6'd46;
			6'd46: begin
				mem_req = blmove_mem_req;
				mem_we_int = blmove_mem_we;
				mem_addr = blmove_mem_addr;
				mem_size = blmove_mem_size;
				mem_wdata = blmove_mem_wdata;
				state_d = (blmove_done ? 6'd47 : 6'd46);
			end
			6'd47: state_d = 6'd48;
			6'd48: state_d = 6'd49;
			6'd49: state_d = 6'd1;
			6'd10: begin
				mem_req = 1'b1;
				mem_addr = fill_addr_q;
				mem_size = io_psize[5:0];
				if (!fill_substep_q)
					mem_we_int = 1'b0;
				else begin
					mem_we_int = 1'b1;
					mem_wdata = fill_merged;
					mem_srt = srt_on;
				end
				if ((mem_ack && fill_substep_q) && fill_done)
					state_d = 6'd11;
				else
					state_d = 6'd10;
			end
			6'd11: state_d = GFX_RETIRE_STATE;
			6'd12: state_d = (((pblt_dx_q[15] || pblt_dy_q[15]) || (pblt_dx_q == 16'd0)) || (pblt_dy_q == 16'd0) ? GFX_RETIRE_STATE : (decoded[0] ? 6'd16 : ((pblt_win_en_q || pblt_w2_q) || pblt_w1_q ? 6'd22 : 6'd13)));
			6'd16: state_d = ((pblt_win_en_q || pblt_w2_q) || pblt_w1_q ? 6'd22 : 6'd13);
			6'd22: state_d = (pblt_w1_q ? 6'd26 : (pblt_w2_q && !pblt_array_inside ? 6'd24 : 6'd13));
			6'd24: state_d = GFX_RETIRE_STATE;
			6'd26: state_d = GFX_RETIRE_STATE;
			6'd13: begin
				mem_req = 1'b1;
				mem_size = io_psize[5:0];
				(* full_case, parallel_case *)
				case (pblt_substep_q)
					2'd0: begin
						mem_we_int = 1'b0;
						mem_addr = pblt_src_addr_q;
						if (decoded[0])
							mem_size = sv2v_cast_13C0F_signed(1);
					end
					2'd1: begin
						mem_we_int = 1'b0;
						mem_addr = pblt_dst_addr_q;
					end
					default: begin
						mem_we_int = 1'b1;
						mem_addr = pblt_dst_addr_q;
						mem_wdata = pblt_merged;
					end
				endcase
				if ((mem_ack && (pblt_substep_q == 2'd2)) && pblt_done)
					state_d = 6'd14;
				else
					state_d = 6'd13;
			end
			6'd14: state_d = 6'd15;
			6'd15: state_d = GFX_RETIRE_STATE;
			6'd44: state_d = (gfx_timing_done ? 6'd1 : 6'd44);
			6'd41: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = srt_bit_addr;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack && srt_last)
					state_d = 6'd7;
			end
			6'd42:
				if (srt_wr_phase) begin
					mem_req = 1'b1;
					mem_we_int = 1'b1;
					mem_addr = srt_bit_addr;
					mem_size = tms34010_pkg_INSTR_WORD_BITS;
					mem_wdata = {{16 {1'b0}}, srt_rdata_q};
					if (mem_ack && srt_last)
						state_d = (srt_fill_q ? (fill_srt_transfer_last ? 6'd11 : 6'd42) : 6'd7);
				end
			6'd6: begin
				(* full_case, parallel_case *)
				case (decoded[51-:7])
					7'd64: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = alu_result;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = st_value;
					end
					7'd65: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = rf_rs2_data;
						mem_size = tms34010_pkg_MEM_SIZE_32;
					end
					7'd66, 7'd68, 7'd69: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = alu_result;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = pc_value;
					end
					7'd67: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = rf_rs2_data;
						mem_size = tms34010_pkg_MEM_SIZE_32;
					end
					7'd70: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_addr = (mem_op_step == 2'd0 ? rf_rs2_data : rf_rs2_data + tms34010_pkg_WORD_BIT_SIZE);
					end
					7'd71: begin
						mem_req = 1'b1;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						if (trap_skip_push) begin
							mem_we_int = 1'b0;
							mem_addr = tms34010_pkg_TRAP_VECTOR_BASE;
						end
						else
							(* full_case, parallel_case *)
							case (mem_op_step)
								2'd0: begin
									mem_we_int = 1'b1;
									mem_addr = rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE;
									mem_wdata = pc_value;
								end
								2'd1: begin
									mem_we_int = 1'b1;
									mem_addr = rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE_2;
									mem_wdata = st_value;
								end
								default: begin
									mem_we_int = 1'b0;
									mem_addr = tms34010_pkg_TRAP_VECTOR_BASE - ({{27 {1'b0}}, decoded[23-:5]} << 5);
								end
							endcase
					end
					7'd72: begin
						mem_req = mm_mem_cmd_valid_q;
						mem_we_int = mm_mem_cmd_we_q;
						mem_addr = mm_mem_cmd_addr_q;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = mm_mem_cmd_wdata_q;
					end
					7'd73: begin
						mem_req = mm_mem_cmd_valid_q;
						mem_we_int = mm_mem_cmd_we_q;
						mem_addr = mm_mem_cmd_addr_q;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = mm_mem_cmd_wdata_q;
					end
					7'd74: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = (pixt_rmw && move_mem_cmd_we_q ? pixt_merged_wr : move_mem_cmd_wdata_q);
						mem_srt = (decoded[4] && mem_we_int) && srt_on;
					end
					7'd75: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
						mem_srt = decoded[4] && srt_on;
					end
					7'd79: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
					end
					7'd80: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
					end
					7'd77: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
					end
					7'd78: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
					end
					7'd76: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
						mem_srt = decoded[4] && srt_on;
					end
					7'd99: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
					end
					7'd101: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
					end
					7'd102: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = rf_rs2_data;
							mem_wdata = move_data_q;
						end
					end
					7'd100: begin
						mem_req = move_mem_cmd_valid_q;
						mem_we_int = move_mem_cmd_we_q;
						mem_addr = move_mem_cmd_addr_q;
						mem_size = move_mem_cmd_size_q;
						mem_wdata = move_mem_cmd_wdata_q;
					end
					default:
						;
				endcase
				if (mem_ack)
					(* full_case, parallel_case *)
					case (decoded[51-:7])
						7'd70:
							if (mem_op_step == 2'd1)
								state_d = 6'd7;
						7'd71:
							if (trap_skip_push || (mem_op_step == 2'd2))
								state_d = 6'd7;
						7'd72, 7'd73:
							if (mm_mask_will_be_empty)
								state_d = 6'd7;
						7'd76, 7'd99, 7'd100, 7'd101, 7'd102:
							if (mem_op_step == 2'd1)
								state_d = 6'd7;
						7'd74:
							if (!pixt_rmw || (mem_op_step == 2'd1))
								state_d = 6'd7;
						default: state_d = 6'd7;
					endcase
			end
			6'd7: state_d = (pair_second_pass ? 6'd7 : ((decoded[51-:7] == 7'd40) && prev_wb_nop_q ? 6'd43 : 6'd1));
			6'd43: state_d = (dsjs_delay_q == 4'd0 ? 6'd1 : 6'd43);
			default: state_d = 6'd0;
		endcase
	end
	assign state_o = state_q;
	assign pc_o = pc_value;
	assign dbg_int_return_o = (ce_cpu && (state_q == 6'd7)) && (decoded[51-:7] == 7'd70);
	assign dbg_int_begin_o = interrupt_timing_start;
	assign instr_word_o = instr_word_q;
	assign illegal_opcode_o = illegal_q;
	assign instruction_class_o = decoded[51-:7];
	assign dbg_int_entry_o = ce_cpu && (state_q == 6'd20);
	assign dbg_int_pc_o = pc_value;
	assign dbg_int_vec_addr_o = int_vec_q;
	assign dbg_int_vec_value_o = popped_pc_q;
	assign dbg_intpend_o = io_intpend;
	assign dbg_intenb_o = io_intenb;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	assign dbg_disp_int_o = io_intpend_live[tms34010_pkg_INT_DI_BIT];
	assign dbg_st_ie_o = st_value[tms34010_pkg_ST_IE_BIT];
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_cycle_budget (
	iclass,
	instr_word,
	branch_taken,
	dsj_precondition,
	dsj_rd_nonzero,
	reg_list_count,
	move_mode,
	force_byte,
	force_pixel,
	xy_addr,
	rd_odd,
	line_count,
	gfx_cycles,
	gfx_cycles_valid,
	pixelshift,
	setcdp_class,
	blmove_cycles_in,
	cycles,
	valid
);
	reg _sv2v_0;
	input wire [6:0] iclass;
	input wire [15:0] instr_word;
	input wire branch_taken;
	input wire dsj_precondition;
	input wire dsj_rd_nonzero;
	input wire [4:0] reg_list_count;
	input wire [1:0] move_mode;
	input wire force_byte;
	input wire force_pixel;
	input wire xy_addr;
	input wire rd_odd;
	input wire [31:0] line_count;
	input wire [15:0] gfx_cycles;
	input wire gfx_cycles_valid;
	input wire [4:0] pixelshift;
	input wire [1:0] setcdp_class;
	input wire [15:0] blmove_cycles_in;
	output reg [15:0] cycles;
	output reg valid;
	reg [15:0] line_cycles;
	always @(*) begin
		if (_sv2v_0)
			;
		if (|line_count[31:15])
			line_cycles = 16'hffff;
		else
			line_cycles = {line_count[14:0], 1'b0};
		cycles = 16'd1;
		valid = 1'b1;
		(* full_case, parallel_case *)
		case (iclass)
			7'd0: cycles = 16'd16;
			7'd1, 7'd16, 7'd17, 7'd18: cycles = 16'd2;
			7'd2, 7'd24, 7'd25, 7'd26, 7'd27, 7'd28, 7'd29: cycles = 16'd3;
			7'd11: cycles = (branch_taken ? 16'd2 : 16'd1);
			7'd34: cycles = (branch_taken ? 16'd3 : 16'd2);
			7'd39: cycles = (branch_taken ? 16'd3 : 16'd4);
			7'd35, 7'd55, 7'd44, 7'd64: cycles = 16'd2;
			7'd36, 7'd37, 7'd38: cycles = (dsj_precondition && dsj_rd_nonzero ? 16'd3 : 16'd2);
			7'd40: cycles = (dsj_rd_nonzero ? 16'd2 : 16'd3);
			7'd19, 7'd49, 7'd48, 7'd62, 7'd63, 7'd66, 7'd69, 7'd93: cycles = 16'd3;
			7'd58: cycles = (instr_word[9] ? 16'd2 : 16'd1);
			7'd59: cycles = 16'd3;
			7'd60: cycles = 16'd1;
			7'd65: cycles = 16'd8;
			7'd67: cycles = 16'd7;
			7'd68: cycles = 16'd4;
			7'd70: cycles = 16'd11;
			7'd71: cycles = 16'd16;
			7'd72: cycles = 16'd2 + ({11'd0, reg_list_count} << 2);
			7'd73: cycles = 16'd3 + ({11'd0, reg_list_count} << 2);
			7'd74:
				if (force_pixel)
					cycles = (xy_addr ? 16'd4 : 16'd2);
				else if (force_byte)
					cycles = 16'd1;
				else
					cycles = (move_mode == 2'b00 ? 16'd1 : 16'd2);
			7'd75:
				if (force_pixel)
					cycles = (xy_addr ? 16'd6 : 16'd4);
				else if (force_byte)
					cycles = 16'd3;
				else
					cycles = (move_mode == 2'b00 ? 16'd3 : 16'd4);
			7'd76:
				if (force_pixel)
					cycles = (xy_addr ? 16'd7 : 16'd4);
				else if (force_byte)
					cycles = 16'd3;
				else
					cycles = (move_mode == 2'b00 ? 16'd3 : 16'd4);
			7'd77: cycles = (force_byte ? 16'd1 : 16'd3);
			7'd78: cycles = 16'd5;
			7'd79: cycles = 16'd3;
			7'd80: cycles = 16'd5;
			7'd99: cycles = 16'd7;
			7'd100: cycles = 16'd5;
			7'd101, 7'd102: cycles = 16'd5;
			7'd87: cycles = 16'd20;
			7'd88: cycles = 16'd21;
			7'd89: cycles = 16'd37;
			7'd90: cycles = 16'd35;
			7'd91: cycles = (rd_odd ? 16'd39 : 16'd40);
			7'd92: cycles = 16'd40;
			7'd94, 7'd95, 7'd96: begin
				cycles = gfx_cycles;
				valid = gfx_cycles_valid;
			end
			7'd97: cycles = 16'd4;
			7'd98: cycles = line_cycles;
			7'd3, 7'd4, 7'd5, 7'd6, 7'd7, 7'd8, 7'd9, 7'd10, 7'd12, 7'd13, 7'd14, 7'd15, 7'd20, 7'd21, 7'd22, 7'd23, 7'd30, 7'd31, 7'd32, 7'd33, 7'd41, 7'd42, 7'd43, 7'd45, 7'd46, 7'd47, 7'd50, 7'd51, 7'd52, 7'd53, 7'd54, 7'd56, 7'd57, 7'd61, 7'd81, 7'd82, 7'd83, 7'd84, 7'd85, 7'd86: cycles = 16'd1;
			7'd103:
				(* full_case, parallel_case *)
				case (pixelshift)
					5'd0: cycles = 16'd8;
					5'd1: cycles = 16'd7;
					5'd2: cycles = 16'd6;
					5'd3: cycles = 16'd5;
					5'd4: cycles = 16'd4;
					5'd5: cycles = 16'd2;
					default: cycles = 16'd8;
				endcase
			7'd106:
				(* full_case, parallel_case *)
				case (setcdp_class)
					2'd0: cycles = 16'd4;
					2'd1: cycles = 16'd6;
					2'd2: cycles = 16'd3;
					default: cycles = 16'd3;
				endcase
			7'd107: cycles = blmove_cycles_in;
			default: begin
				cycles = 16'd1;
				valid = 1'b0;
			end
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_decode (
	instr,
	decoded
);
	reg _sv2v_0;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	input wire [15:0] instr;
	output reg [52:0] decoded;
	wire [9:0] top10;
	wire [6:0] top7;
	wire [5:0] top6;
	assign top10 = instr[15:6];
	assign top7 = instr[15:9];
	assign top6 = instr[15:10];
	localparam [9:0] MOVI_TOP10 = 10'b0000100111;
	localparam [5:0] MOVK_TOP6 = 6'b000110;
	localparam [5:0] ADDK_TOP6 = 6'b000100;
	localparam [5:0] SUBK_TOP6 = 6'b000101;
	localparam [8:0] UNARY_TOP9 = 9'b000000111;
	localparam [10:0] ADDI_IW_TOP11 = 11'b00001011000;
	localparam [10:0] SUBI_IW_TOP11 = 11'b00001011111;
	localparam [10:0] CMPI_IW_TOP11 = 11'b00001011010;
	localparam [5:0] SLA_K_TOP6 = 6'b001000;
	localparam [5:0] SLL_K_TOP6 = 6'b001001;
	localparam [5:0] SRA_K_TOP6 = 6'b001010;
	localparam [5:0] SRL_K_TOP6 = 6'b001011;
	localparam [5:0] RL_K_TOP6 = 6'b001100;
	localparam [10:0] ADDI_IL_TOP11 = 11'b00001011001;
	localparam [10:0] CMPI_IL_TOP11 = 11'b00001011011;
	localparam [10:0] ANDI_IL_TOP11 = 11'b00001011100;
	localparam [10:0] ORI_IL_TOP11 = 11'b00001011101;
	localparam [10:0] XORI_IL_TOP11 = 11'b00001011110;
	localparam [10:0] SUBI_IL_TOP11 = 11'b00001101000;
	localparam [5:0] MOVE_RR_TOP6 = 6'b010011;
	localparam [5:0] MOVE_STORE_TOP6 = 6'b100000;
	localparam [5:0] MOVE_LOAD_TOP6 = 6'b100001;
	localparam [5:0] MOVE_M2M_TOP6 = 6'b100010;
	localparam [5:0] MOVE_M2M_POSTINC_TOP6 = 6'b100110;
	localparam [5:0] MOVE_M2M_PREDEC_TOP6 = 6'b101010;
	localparam [5:0] MOVE_OFF_STORE_TOP6 = 6'b101100;
	localparam [5:0] MOVE_OFF_LOAD_TOP6 = 6'b101101;
	localparam [5:0] MOVE_OFF_M2M_TOP6 = 6'b101110;
	localparam [5:0] MOVE_OFF_NI_TOP6 = 6'b110100;
	localparam [5:0] MOVE_ABS_NI_TOP6 = 6'b110101;
	localparam [5:0] MOVE_STORE_POSTINC_TOP6 = 6'b100100;
	localparam [5:0] MOVE_LOAD_POSTINC_TOP6 = 6'b100101;
	localparam [5:0] MOVE_STORE_PREDEC_TOP6 = 6'b101000;
	localparam [5:0] MOVE_LOAD_PREDEC_TOP6 = 6'b101001;
	localparam [6:0] MOVB_STORE_TOP7 = 7'b1000110;
	localparam [6:0] MOVB_LOAD_TOP7 = 7'b1000111;
	localparam [6:0] MOVB_M2M_TOP7 = 7'b1001110;
	localparam [6:0] MOVB_OFF_STORE_TOP7 = 7'b1010110;
	localparam [6:0] MOVB_OFF_LOAD_TOP7 = 7'b1010111;
	localparam [6:0] MOVB_OFF_M2M_TOP7 = 7'b1011110;
	localparam [6:0] PIXT_STORE_TOP7 = 7'b1111100;
	localparam [6:0] PIXT_LOAD_TOP7 = 7'b1111101;
	localparam [6:0] PIXT_M2M_TOP7 = 7'b1111110;
	localparam [6:0] PIXT_XY_STORE_TOP7 = 7'b1111000;
	localparam [6:0] PIXT_XY_LOAD_TOP7 = 7'b1111001;
	localparam [6:0] PIXT_XY_M2M_TOP7 = 7'b1111010;
	localparam [6:0] MOVX_TOP7 = 7'b1110110;
	localparam [6:0] MOVY_TOP7 = 7'b1110111;
	localparam [6:0] CVXYL_TOP7 = 7'b1110100;
	localparam [6:0] ADDXY_TOP7 = 7'b1110000;
	localparam [6:0] SUBXY_TOP7 = 7'b1110001;
	localparam [6:0] DRAV_TOP7 = 7'b1111011;
	localparam [6:0] CMPXY_TOP7 = 7'b1110010;
	localparam [6:0] CPW_TOP7 = 7'b1110011;
	localparam [6:0] MPYS_TOP7 = 7'b0101110;
	localparam [6:0] MPYU_TOP7 = 7'b0101111;
	localparam [6:0] DIVU_TOP7 = 7'b0101101;
	localparam [6:0] MODU_TOP7 = 7'b0110111;
	localparam [6:0] DIVS_TOP7 = 7'b0101100;
	localparam [6:0] MODS_TOP7 = 7'b0110110;
	localparam [6:0] ADD_RR_TOP7 = 7'b0100000;
	localparam [6:0] ADDC_RR_TOP7 = 7'b0100001;
	localparam [6:0] SUB_RR_TOP7 = 7'b0100010;
	localparam [6:0] SUBB_RR_TOP7 = 7'b0100011;
	localparam [6:0] AND_RR_TOP7 = 7'b0101000;
	localparam [6:0] ANDN_RR_TOP7 = 7'b0101001;
	localparam [6:0] OR_RR_TOP7 = 7'b0101010;
	localparam [6:0] XOR_RR_TOP7 = 7'b0101011;
	localparam [6:0] CMP_RR_TOP7 = 7'b0100100;
	localparam [15:0] PUSHST_OPCODE = 16'h01e0;
	localparam [15:0] POPST_OPCODE = 16'h01c0;
	localparam [10:0] CALL_RS_TOP11 = 11'b00001001001;
	localparam [15:0] RETI_OPCODE = 16'h0940;
	localparam [10:0] TRAP_TOP11 = 11'b00001001000;
	localparam [10:0] MMTM_TOP11 = 11'b00001001100;
	localparam [10:0] MMFM_TOP11 = 11'b00001001101;
	localparam [15:0] CALLA_OPCODE = 16'h0d5f;
	localparam [15:0] CALLR_OPCODE = 16'h0d3f;
	localparam [10:0] RETS_TOP11 = 11'b00001001011;
	localparam [15:0] DINT_OPCODE = 16'h0360;
	localparam [15:0] EINT_OPCODE = 16'h0d60;
	localparam [5:0] EXGF_TOP6 = 6'b110101;
	localparam [5:0] SETF_TOP6 = 6'b000001;
	localparam [6:0] LMO_RR_TOP7 = 7'b0110101;
	localparam [6:0] SLA_RR_TOP7 = 7'b0110000;
	localparam [6:0] SLL_RR_TOP7 = 7'b0110001;
	localparam [6:0] SRA_RR_TOP7 = 7'b0110010;
	localparam [6:0] SRL_RR_TOP7 = 7'b0110011;
	localparam [6:0] RL_RR_TOP7 = 7'b0110100;
	localparam [3:0] JRCC_TOP4 = 4'b1100;
	localparam [15:0] NOP_OPCODE = 16'h0300;
	localparam [10:0] JUMP_RS_TOP11 = 11'b00000001011;
	localparam [10:0] DSJ_TOP11 = 11'b00001101100;
	localparam [10:0] DSJEQ_TOP11 = 11'b00001101101;
	localparam [10:0] DSJNE_TOP11 = 11'b00001101110;
	localparam [15:0] CLRC_OPCODE = 16'h0320;
	localparam [15:0] SETC_OPCODE = 16'h0de0;
	localparam [10:0] GETST_TOP11 = 11'b00000001100;
	localparam [10:0] PUTST_TOP11 = 11'b00000001101;
	localparam [10:0] GETPC_TOP11 = 11'b00000001010;
	localparam [10:0] EXGPC_TOP11 = 11'b00000001001;
	localparam [10:0] REV_TOP11 = 11'b00000000001;
	localparam [5:0] BTST_K_TOP6 = 6'b000111;
	localparam [6:0] BTST_RR_TOP7 = 7'b0100101;
	localparam [4:0] DSJS_TOP5 = 5'b00111;
	wire [3:0] rs_idx_from_instr;
	assign rs_idx_from_instr = instr[8:5];
	wire [10:0] top11;
	assign top11 = instr[15:5];
	wire reg_file_from_instr;
	wire [3:0] reg_idx_from_instr;
	assign reg_file_from_instr = instr[4];
	assign reg_idx_from_instr = instr[3:0];
	localparam [3:0] tms34010_pkg_B_DPTCH_IDX = 4'd3;
	localparam [3:0] tms34010_pkg_B_SADDR_IDX = 4'd0;
	localparam [3:0] tms34010_pkg_CC_C = 4'b1000;
	localparam [3:0] tms34010_pkg_CC_EQ = 4'b1010;
	localparam [3:0] tms34010_pkg_CC_GE = 4'b0101;
	localparam [3:0] tms34010_pkg_CC_GT = 4'b0111;
	localparam [3:0] tms34010_pkg_CC_HI = 4'b0011;
	localparam [3:0] tms34010_pkg_CC_HS = 4'b1001;
	localparam [3:0] tms34010_pkg_CC_LE = 4'b0110;
	localparam [3:0] tms34010_pkg_CC_LS = 4'b0010;
	localparam [3:0] tms34010_pkg_CC_LT = 4'b0100;
	localparam [3:0] tms34010_pkg_CC_N = 4'b1110;
	localparam [3:0] tms34010_pkg_CC_NE = 4'b1011;
	localparam [3:0] tms34010_pkg_CC_NN = 4'b1111;
	localparam [3:0] tms34010_pkg_CC_NV = 4'b1101;
	localparam [3:0] tms34010_pkg_CC_P = 4'b0001;
	localparam [3:0] tms34010_pkg_CC_UC = 4'b0000;
	localparam [3:0] tms34010_pkg_CC_V = 4'b1100;
	localparam [0:0] tms34010_pkg_IS_34020 = 1'b1;
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	always @(*) begin
		if (_sv2v_0)
			;
		decoded[52] = 1'b1;
		decoded[51-:7] = 7'd0;
		decoded[44] = 1'b0;
		decoded[43-:4] = 1'sb0;
		decoded[39-:4] = 1'sb0;
		decoded[34] = 1'b0;
		decoded[33] = 1'b0;
		decoded[32] = 1'b0;
		decoded[31-:4] = 4'd11;
		decoded[35] = reg_file_from_instr;
		decoded[7-:2] = 2'b00;
		decoded[5] = 1'b0;
		decoded[4] = 1'b0;
		decoded[3] = 1'b0;
		decoded[2] = 1'b0;
		decoded[1] = 1'b0;
		decoded[0] = 1'b0;
		decoded[27-:3] = 3'd0;
		decoded[24] = 1'b0;
		decoded[23-:5] = 1'sb0;
		decoded[18-:4] = 1'sb0;
		decoded[14] = 1'b0;
		decoded[13] = 1'b0;
		decoded[12-:4] = 4'b1111;
		decoded[8] = 1'b0;
		if ((top10 == MOVI_TOP10) && (instr[5] == 1'b0)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[33] = 1'b0;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if ((top10 == MOVI_TOP10) && (instr[5] == 1'b1)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd2;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b0;
			decoded[33] = 1'b1;
			decoded[32] = 1'b0;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top6 == MOVK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd3;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[34] = 1'b0;
			decoded[33] = 1'b0;
			decoded[32] = 1'b0;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == ADDK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd12;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top6 == SUBK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd13;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == ADDI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd16;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == SUBI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd17;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == CMPI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd18;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top11 == ADDI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd24;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == SUBI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd25;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == CMPI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd26;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top11 == ANDI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd27;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd6;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top11 == ORI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd28;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd7;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top11 == XORI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd29;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd8;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top6 == MOVE_RR_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd30;
			decoded[35] = reg_file_from_instr;
			decoded[44] = (instr[9] ? ~instr[4] : reg_file_from_instr);
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd11;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == MOVX_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd81;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd82;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == CVXYL_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd93;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == ADDXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd83;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUBXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd84;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == DRAV_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd97;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[8] = 1'b1;
		end
		if ((instr[15:8] == 8'hdf) && (instr[6:0] == 7'h1a)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd98;
			decoded[14] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == CMPXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd85;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top7 == MPYS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd87;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1010;
		end
		if (top7 == MPYU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd88;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == DIVU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd89;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0011;
		end
		if (top7 == MODU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd90;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0011;
		end
		if (top7 == DIVS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd91;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == MODS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd92;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == CPW_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd86;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
		end
		if (top6 == MOVE_STORE_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top6 == MOVE_LOAD_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top6 == MOVE_OFF_STORE_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd79;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_OFF_LOAD_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd80;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top6 == MOVE_OFF_M2M_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd100;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_OFF_NI_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd101;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[7-:2] = 2'b01;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if ((top6 == MOVE_ABS_NI_TOP6) && (instr[8:5] == 4'b0000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd102;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[7-:2] = 2'b01;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_M2M_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_M2M_POSTINC_TOP6) || (top6 == MOVE_M2M_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_M2M_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_STORE_POSTINC_TOP6) || (top6 == MOVE_STORE_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_STORE_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_LOAD_POSTINC_TOP6) || (top6 == MOVE_LOAD_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_LOAD_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top6 == SLA_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd19;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd1;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top6 == SLL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd20;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd0;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top6 == SRA_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd21;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd3;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1110;
		end
		if (top6 == SRL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd22;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd2;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top6 == RL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd23;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd4;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (instr[15:7] == UNARY_TOP9)
			case (instr[6:5])
				2'b00: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd41;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd13;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
					decoded[12-:4] = 4'b1011;
				end
				2'b01: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd14;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd10;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
				end
				2'b10: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd42;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd3;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
				end
				2'b11: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd15;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd9;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
					decoded[12-:4] = 4'b0010;
				end
				default:
					;
			endcase
		if (top7 == SLA_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd49;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd1;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SLL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd50;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd0;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == SRA_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd51;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd3;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1110;
		end
		if (top7 == SRL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd52;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd2;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == RL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd53;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd4;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == LMO_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd57;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:6] == 2'b01)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd58;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd59;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b001)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd60;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b100)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd77;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b101)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd78;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b110)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd99;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVB_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_OFF_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd100;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVB_OFF_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd79;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVB_OFF_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd80;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if ((((instr[15:10] == SETF_TOP6) && !instr[9]) && instr[8]) && (instr[7:5] == 3'b111)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd77;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if ((((instr[15:10] == SETF_TOP6) && instr[9]) && instr[8]) && (instr[7:5] == 3'b111)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd78;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == PIXT_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (((instr[15:10] == EXGF_TOP6) && instr[8]) && (instr[7:5] == 3'b000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd61;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (instr == DINT_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd62;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == EINT_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd63;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == PUSHST_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd64;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == POPST_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd65;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == CALL_RS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd66;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == RETS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd67;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[23-:5] = instr[4:0];
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == CALLA_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd68;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[33] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == CALLR_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd69;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[34] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == RETI_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd70;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == TRAP_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd71;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[23-:5] = instr[4:0];
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == MMTM_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd72;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[34] = 1'b1;
			decoded[8] = 1'b1;
		end
		if (top11 == MMFM_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd73;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[34] = 1'b1;
			decoded[8] = 1'b1;
		end
		if (top7 == ADD_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd4;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == ADDC_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd32;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUB_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd5;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUBB_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd33;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd3;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == AND_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd6;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == ANDN_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd7;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd6;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == OR_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd8;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd7;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == XOR_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd9;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd8;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == CMP_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd10;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if ((((instr[15:12] == JRCC_TOP4) && (instr[7:0] != 8'h00)) && (instr[7:0] != 8'h80)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd11;
			decoded[18-:4] = instr[11:8];
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:12] == JRCC_TOP4) && (instr[7:0] == 8'h00)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd34;
			decoded[18-:4] = instr[11:8];
			decoded[34] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == NOP_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd31;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == 16'h0fc0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd94;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0fe0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd95;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f00) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f20) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f40) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[2] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f60) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[2] = 1'b1;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f80) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[0] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0fa0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[0] = 1'b1;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (top11 == JUMP_RS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd35;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((top11 == DSJ_TOP11) || (top11 == DSJEQ_TOP11)) || (top11 == DSJNE_TOP11)) begin
			decoded[52] = 1'b0;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = 5'd1;
			decoded[31-:4] = 4'd2;
			decoded[34] = 1'b1;
			decoded[32] = 1'b0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			(* full_case, parallel_case *)
			case (top11)
				DSJ_TOP11: decoded[51-:7] = 7'd36;
				DSJEQ_TOP11: decoded[51-:7] = 7'd37;
				DSJNE_TOP11: decoded[51-:7] = 7'd38;
				default: decoded[51-:7] = 7'd0;
			endcase
		end
		if (((instr[15:12] == JRCC_TOP4) && (instr[7:0] == 8'h80)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd39;
			decoded[18-:4] = instr[11:8];
			decoded[33] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr[15:11] == DSJS_TOP5) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd40;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = 5'd1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == BTST_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd43;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = ~instr[9:5];
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (instr == CLRC_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd45;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0100;
		end
		if (instr == SETC_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd46;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0100;
		end
		if (top11 == GETST_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd47;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == PUTST_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd48;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top11 == GETPC_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd54;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == EXGPC_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd55;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == REV_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd56;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == BTST_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd44;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (tms34010_pkg_IS_34020 && (instr[15:5] == 11'b00000010100)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd103;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (tms34010_pkg_IS_34020 && (instr[15:10] == 6'b001101)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd104;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (tms34010_pkg_IS_34020 && (instr[15:5] == 11'b00001100000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd105;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (tms34010_pkg_IS_34020 && (instr == 16'h0273)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd106;
			decoded[44] = 1'b1;
			decoded[43-:4] = tms34010_pkg_B_DPTCH_IDX;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (tms34010_pkg_IS_34020 && (instr[15:2] == 14'b00000000111100)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd107;
			decoded[44] = 1'b1;
			decoded[43-:4] = tms34010_pkg_B_SADDR_IDX;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_divider (
	clk,
	ce_cpu,
	rst,
	start,
	dividend,
	divisor,
	busy,
	done,
	quotient,
	remainder,
	overflow
);
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire start;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [63:0] dividend;
	input wire [31:0] divisor;
	output wire busy;
	output wire done;
	output wire [31:0] quotient;
	output wire [31:0] remainder;
	output wire overflow;
	reg [1:0] st_q;
	reg [tms34010_pkg_DATA_WIDTH:0] rem_q;
	reg [31:0] quot_q;
	reg [31:0] dvd_lo_q;
	reg [31:0] divisor_q;
	reg ovf_q;
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	reg [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] iter_q;
	wire [tms34010_pkg_DATA_WIDTH:0] shifted;
	wire [tms34010_pkg_DATA_WIDTH:0] divisor_ext;
	assign divisor_ext = {1'b0, divisor_q};
	assign shifted = {rem_q[31:0], dvd_lo_q[31]};
	wire start_overflow;
	assign start_overflow = (divisor == {32 {1'sb0}}) || (dividend[63:tms34010_pkg_DATA_WIDTH] >= divisor);
	function automatic [5:0] sv2v_cast_287E4;
		input reg [5:0] inp;
		sv2v_cast_287E4 = inp;
	endfunction
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				st_q <= 2'd0;
				rem_q <= 1'sb0;
				quot_q <= 1'sb0;
				dvd_lo_q <= 1'sb0;
				divisor_q <= 1'sb0;
				ovf_q <= 1'b0;
				iter_q <= 1'sb0;
			end
			else
				(* full_case, parallel_case *)
				case (st_q)
					2'd0:
						if (start) begin
							divisor_q <= divisor;
							ovf_q <= start_overflow;
							rem_q <= {1'b0, dividend[63:tms34010_pkg_DATA_WIDTH]};
							dvd_lo_q <= dividend[31:0];
							quot_q <= 1'sb0;
							iter_q <= 1'sb0;
							st_q <= (start_overflow ? 2'd2 : 2'd1);
						end
					2'd1: begin
						if (shifted >= divisor_ext) begin
							rem_q <= shifted - divisor_ext;
							quot_q <= {quot_q[30:0], 1'b1};
						end
						else begin
							rem_q <= shifted;
							quot_q <= {quot_q[30:0], 1'b0};
						end
						dvd_lo_q <= {dvd_lo_q[30:0], 1'b0};
						iter_q <= iter_q + 1'b1;
						if (iter_q == sv2v_cast_287E4(31))
							st_q <= 2'd2;
					end
					2'd2: st_q <= 2'd0;
					default: st_q <= 2'd0;
				endcase
		end
	assign busy = st_q != 2'd0;
	assign done = st_q == 2'd2;
	assign quotient = quot_q;
	assign remainder = rem_q[31:0];
	assign overflow = ovf_q;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_gfx_cycle_counter (
	clk,
	rst,
	ce,
	start,
	is_fill,
	is_binary,
	src_xy,
	dst_xy,
	saddr,
	daddr,
	dydx,
	sptch,
	dptch,
	offset,
	wstart,
	wend,
	convsp,
	convdp,
	psize,
	control,
	busy,
	done,
	cycles,
	overflow
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire ce;
	input wire start;
	input wire is_fill;
	input wire is_binary;
	input wire src_xy;
	input wire dst_xy;
	input wire [31:0] saddr;
	input wire [31:0] daddr;
	input wire [31:0] dydx;
	input wire [31:0] sptch;
	input wire [31:0] dptch;
	input wire [31:0] offset;
	input wire [31:0] wstart;
	input wire [31:0] wend;
	input wire [15:0] convsp;
	input wire [15:0] convdp;
	input wire [15:0] psize;
	input wire [15:0] control;
	output reg busy;
	output reg done;
	output reg [31:0] cycles;
	output reg overflow;
	localparam [31:0] CTRL_T_BIT = 5;
	localparam [31:0] CTRL_W_LO = 6;
	localparam [31:0] CTRL_W_HI = 7;
	localparam [31:0] CTRL_PBH_BIT = 8;
	localparam [31:0] CTRL_PBV_BIT = 9;
	localparam [31:0] CTRL_ROP_LO = 10;
	localparam [31:0] CTRL_ROP_HI = 14;
	reg [1:0] state_q;
	reg [39:0] acc_q;
	reg [15:0] rows_left_q;
	reg [15:0] dx_q;
	reg [31:0] src_addr_q;
	reg [31:0] dst_addr_q;
	reg [31:0] sptch_q;
	reg [31:0] dptch_q;
	reg [4:0] bpp_shift_q;
	reg [3:0] op_timing_q;
	reg fill_q;
	reg binary_q;
	reg reverse_q;
	reg yreverse_q;
	reg needs_dest_q;
	function automatic [4:0] mame_bpp_shift;
		input reg [4:0] psize_low;
		if (psize_low[4])
			mame_bpp_shift = 5'd4;
		else if (psize_low[3])
			mame_bpp_shift = 5'd3;
		else if (psize_low[2])
			mame_bpp_shift = 5'd2;
		else if (psize_low[1])
			mame_bpp_shift = 5'd1;
		else
			mame_bpp_shift = 5'd0;
	endfunction
	function automatic [4:0] mame_pixel_shift;
		input reg [4:0] psize_low;
		(* full_case, parallel_case *)
		case (psize_low)
			5'd1: mame_pixel_shift = 5'd0;
			5'd2: mame_pixel_shift = 5'd1;
			5'd4: mame_pixel_shift = 5'd2;
			5'd8: mame_pixel_shift = 5'd3;
			5'd16: mame_pixel_shift = 5'd4;
			default: mame_pixel_shift = 5'd0;
		endcase
	endfunction
	function automatic [3:0] mame_rop_timing;
		input reg [4:0] rop;
		input reg transparency;
		reg [3:0] base;
		begin
			(* full_case, parallel_case *)
			case (rop)
				5'd0, 5'd22, 5'd23, 5'd24, 5'd25, 5'd26, 5'd27, 5'd28, 5'd29, 5'd30, 5'd31: base = 4'd2;
				5'd17, 5'd18, 5'd20, 5'd21: base = 4'd5;
				5'd19: base = 4'd6;
				default: base = 4'd4;
			endcase
			mame_rop_timing = base + (transparency ? 4'd2 : 4'd0);
		end
	endfunction
	function automatic [39:0] mul_small;
		input reg [39:0] value;
		input reg [3:0] factor;
		(* full_case, parallel_case *)
		case (factor)
			4'd0: mul_small = 40'd0;
			4'd1: mul_small = value;
			4'd2: mul_small = value << 1;
			4'd3: mul_small = (value << 1) + value;
			4'd4: mul_small = value << 2;
			4'd5: mul_small = (value << 2) + value;
			4'd6: mul_small = (value << 2) + (value << 1);
			4'd7: mul_small = ((value << 2) + (value << 1)) + value;
			4'd8: mul_small = value << 3;
			4'd9: mul_small = (value << 3) + value;
			4'd10: mul_small = (value << 3) + (value << 1);
			default: mul_small = 40'd0;
		endcase
	endfunction
	function automatic [31:0] xy_to_linear;
		input reg [31:0] xy;
		input reg [31:0] base_offset;
		input reg [15:0] conv;
		input reg [4:0] pixel_shift;
		reg signed [63:0] sx;
		reg signed [63:0] sy;
		reg signed [63:0] soff;
		reg signed [63:0] result;
		reg [4:0] conv_shift;
		begin
			sx = {{48 {xy[15]}}, xy[15:0]};
			sy = {{48 {xy[31]}}, xy[31:16]};
			soff = {{32 {base_offset[31]}}, base_offset};
			conv_shift = 5'd31 - conv[4:0];
			result = (soff + (sy <<< conv_shift)) + (sx <<< pixel_shift);
			xy_to_linear = result[31:0];
		end
	endfunction
	reg [4:0] calc_bpp_shift;
	reg [4:0] calc_pixel_shift;
	reg [4:0] calc_convsp_shift;
	reg [4:0] calc_convdp_shift;
	reg [4:0] calc_rop;
	reg [3:0] calc_op_timing;
	reg [1:0] calc_wmode;
	reg calc_transparency;
	reg calc_needs_dest;
	reg calc_any_xy;
	reg calc_active;
	reg signed [32:0] calc_dx_orig;
	reg signed [32:0] calc_dy_orig;
	reg signed [32:0] calc_sx_orig;
	reg signed [32:0] calc_sy_orig;
	reg signed [32:0] calc_ex;
	reg signed [32:0] calc_ey;
	reg signed [32:0] calc_sx;
	reg signed [32:0] calc_sy;
	reg signed [32:0] calc_dx;
	reg signed [32:0] calc_dy;
	reg signed [32:0] calc_wsx;
	reg signed [32:0] calc_wsy;
	reg signed [32:0] calc_wex;
	reg signed [32:0] calc_wey;
	reg signed [32:0] calc_diff;
	reg [31:0] calc_src_addr;
	reg [31:0] calc_dst_addr;
	reg [31:0] calc_dst_xy;
	reg [31:0] calc_bpp_mask;
	reg [63:0] calc_addr_delta;
	reg [39:0] calc_base_cycles;
	reg [15:0] calc_rows;
	reg [15:0] calc_dx_u;
	always @(*) begin
		if (_sv2v_0)
			;
		calc_bpp_shift = mame_bpp_shift(psize[4:0]);
		calc_pixel_shift = mame_pixel_shift(psize[4:0]);
		calc_convsp_shift = 5'd31 - convsp[4:0];
		calc_convdp_shift = 5'd31 - convdp[4:0];
		calc_rop = control[CTRL_ROP_HI:CTRL_ROP_LO];
		calc_wmode = control[CTRL_W_HI:CTRL_W_LO];
		calc_transparency = control[CTRL_T_BIT];
		calc_op_timing = mame_rop_timing(calc_rop, calc_transparency);
		calc_needs_dest = (calc_rop != 5'd0) || calc_transparency;
		calc_any_xy = src_xy || dst_xy;
		calc_dx_orig = {{17 {dydx[15]}}, dydx[15:0]};
		calc_dy_orig = {{17 {dydx[31]}}, dydx[31:16]};
		calc_sx_orig = {{17 {daddr[15]}}, daddr[15:0]};
		calc_sy_orig = {{17 {daddr[31]}}, daddr[31:16]};
		calc_wsx = {{17 {wstart[15]}}, wstart[15:0]};
		calc_wsy = {{17 {wstart[31]}}, wstart[31:16]};
		calc_wex = {{17 {wend[15]}}, wend[15:0]};
		calc_wey = {{17 {wend[31]}}, wend[31:16]};
		calc_sx = calc_sx_orig;
		calc_sy = calc_sy_orig;
		calc_ex = (calc_sx_orig + calc_dx_orig) - 33'sd1;
		calc_ey = (calc_sy_orig + calc_dy_orig) - 33'sd1;
		calc_dx = calc_dx_orig;
		calc_dy = calc_dy_orig;
		calc_diff = 33'sd0;
		calc_src_addr = (src_xy ? xy_to_linear(saddr, offset, convsp, calc_pixel_shift) : saddr);
		calc_dst_addr = daddr;
		calc_dst_xy = daddr;
		calc_addr_delta = 64'd0;
		if (!is_fill && !is_binary)
			calc_base_cycles = 40'd7 + (src_xy ? 40'd2 : 40'd0);
		else
			calc_base_cycles = 40'd4;
		if (dst_xy) begin
			if (!is_fill && !is_binary)
				calc_base_cycles = (calc_base_cycles + 40'd2) + (src_xy ? 40'd1 : 40'd0);
			else
				calc_base_cycles = calc_base_cycles + 40'd2;
			if (calc_wmode != 2'd0) begin
				calc_base_cycles = calc_base_cycles + 40'd3;
				calc_diff = calc_wsx - calc_sx;
				if (calc_diff > 33'sd0) begin
					if (!is_fill) begin
						calc_addr_delta = {{31 {1'b0}}, calc_diff} << (is_binary ? 5'd0 : calc_bpp_shift);
						calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
					end
					calc_sx = calc_sx + calc_diff;
				end
				calc_diff = calc_ex - calc_wex;
				if (calc_diff > 33'sd0)
					calc_ex = calc_ex - calc_diff;
				calc_diff = calc_wsy - calc_sy;
				if (calc_diff > 33'sd0) begin
					if (!is_fill) begin
						calc_addr_delta = {{31 {1'b0}}, calc_diff} << calc_convsp_shift;
						calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
					end
					calc_sy = calc_sy + calc_diff;
				end
				calc_diff = calc_ey - calc_wey;
				if (calc_diff > 33'sd0)
					calc_ey = calc_ey - calc_diff;
				calc_dx = (calc_ex - calc_sx) + 33'sd1;
				calc_dy = (calc_ey - calc_sy) + 33'sd1;
				if ((calc_dx_orig != calc_dx) || (calc_dy_orig != calc_dy)) begin
					if ((calc_sx_orig != calc_sx) || (calc_sy_orig != calc_sy))
						calc_base_cycles = calc_base_cycles + 40'd11;
					else
						calc_base_cycles = calc_base_cycles + 40'd3;
				end
				else if ((calc_sx_orig != calc_sx) || (calc_sy_orig != calc_sy))
					calc_base_cycles = calc_base_cycles + 40'd7;
			end
			calc_dst_xy = {calc_sy[15:0], calc_sx[15:0]};
			calc_dst_addr = xy_to_linear(calc_dst_xy, offset, convdp, calc_pixel_shift);
		end
		calc_bpp_mask = (32'd1 << calc_bpp_shift) - 32'd1;
		calc_dst_addr = calc_dst_addr & ~calc_bpp_mask;
		if ((!is_fill && !is_binary) && control[CTRL_PBH_BIT])
			calc_src_addr = calc_src_addr & ~calc_bpp_mask;
		calc_active = ((calc_dx > 33'sd0) && (calc_dy > 33'sd0)) && !(dst_xy && (calc_wmode == 2'd1));
		calc_rows = calc_dy[15:0];
		calc_dx_u = calc_dx[15:0];
		if ((((calc_active && !is_fill) && !is_binary) && control[CTRL_PBH_BIT]) && calc_any_xy) begin
			calc_addr_delta = {{31 {1'b0}}, calc_dx} << calc_bpp_shift;
			calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
			calc_dst_addr = calc_dst_addr + calc_addr_delta[31:0];
		end
		if ((((calc_active && !is_fill) && !is_binary) && control[CTRL_PBV_BIT]) && calc_any_xy) begin
			calc_addr_delta = {{31 {1'b0}}, calc_dy - 33'sd1} << calc_convsp_shift;
			calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
			calc_addr_delta = {{31 {1'b0}}, calc_dy - 33'sd1} << calc_convdp_shift;
			calc_dst_addr = calc_dst_addr + calc_addr_delta[31:0];
		end
		if (calc_active && is_fill)
			calc_base_cycles = calc_base_cycles + 40'd2;
		else if (calc_active && is_binary)
			calc_base_cycles = calc_base_cycles + 40'd2;
	end
	reg [31:0] row_total_bits;
	reg [31:0] row_dst_span;
	reg [31:0] row_src_span;
	reg [31:0] row_dst_words;
	reg [31:0] row_src_words;
	reg [31:0] row_dest_reads;
	reg [31:0] row_readwrites;
	reg [31:0] row_reverse_start;
	reg row_left_partial;
	reg row_right_partial;
	reg [3:0] row_extra_timing;
	reg [39:0] row_cycles;
	reg [39:0] row_sum;
	always @(*) begin
		if (_sv2v_0)
			;
		row_total_bits = {16'd0, dx_q} << bpp_shift_q;
		row_dst_span = {28'd0, dst_addr_q[3:0]} + row_total_bits;
		row_src_span = 32'd0;
		row_dst_words = (row_dst_span + 32'd15) >> 4;
		row_src_words = (row_dst_words << bpp_shift_q) >> 4;
		row_dest_reads = 32'd0;
		row_readwrites = 32'd0;
		row_reverse_start = dst_addr_q - row_total_bits;
		row_left_partial = 1'b0;
		row_right_partial = 1'b0;
		row_extra_timing = op_timing_q - 4'd2;
		row_cycles = 40'd0;
		if (fill_q)
			row_cycles = mul_small({8'd0, row_dst_words}, op_timing_q);
		else if (binary_q)
			row_cycles = mul_small({8'd0, row_dst_words}, op_timing_q) + ({8'd0, row_src_words} << 1);
		else if (reverse_q) begin
			row_dst_span = {28'd0, row_reverse_start[3:0]} + row_total_bits;
			row_dst_words = (row_dst_span + 32'd15) >> 4;
			row_cycles = mul_small({8'd0, row_dst_words}, op_timing_q + 4'd2) + 40'd2;
		end
		else begin
			row_dst_span = {28'd0, dst_addr_q[3:0]} + row_total_bits;
			row_src_span = {28'd0, src_addr_q[3:0]} + row_total_bits;
			row_dst_words = (row_dst_span + 32'd15) >> 4;
			row_src_words = (row_src_span + 32'd15) >> 4;
			row_left_partial = dst_addr_q[3:0] != 4'd0;
			row_right_partial = row_dst_span[3:0] != 4'd0;
			if (needs_dest_q)
				row_dest_reads = row_dst_words + (row_right_partial ? 32'd1 : 32'd0);
			else
				row_dest_reads = (row_left_partial ? 32'd1 : 32'd0) + (row_right_partial ? 32'd1 : 32'd0);
			row_readwrites = (row_src_words + row_dst_words) + row_dest_reads;
			row_cycles = ({8'd0, row_readwrites} << 1) + mul_small({24'd0, dx_q}, row_extra_timing);
		end
		row_sum = acc_q + row_cycles;
	end
	always @(posedge clk)
		if (rst) begin
			state_q <= 2'd0;
			acc_q <= 40'd0;
			rows_left_q <= 16'd0;
			dx_q <= 16'd0;
			src_addr_q <= 32'd0;
			dst_addr_q <= 32'd0;
			sptch_q <= 32'd0;
			dptch_q <= 32'd0;
			bpp_shift_q <= 5'd0;
			op_timing_q <= 4'd2;
			fill_q <= 1'b0;
			binary_q <= 1'b0;
			reverse_q <= 1'b0;
			yreverse_q <= 1'b0;
			needs_dest_q <= 1'b0;
			busy <= 1'b0;
			done <= 1'b0;
			cycles <= 32'd0;
			overflow <= 1'b0;
		end
		else if (ce !== 1'b0) begin
			if (start) begin
				acc_q <= calc_base_cycles;
				rows_left_q <= calc_rows;
				dx_q <= calc_dx_u;
				src_addr_q <= calc_src_addr;
				dst_addr_q <= calc_dst_addr;
				sptch_q <= sptch;
				dptch_q <= dptch;
				bpp_shift_q <= calc_bpp_shift;
				op_timing_q <= calc_op_timing;
				fill_q <= is_fill;
				binary_q <= is_binary;
				reverse_q <= (!is_fill && !is_binary) && control[CTRL_PBH_BIT];
				yreverse_q <= (!is_fill && !is_binary) && control[CTRL_PBV_BIT];
				needs_dest_q <= calc_needs_dest;
				done <= 1'b0;
				overflow <= 1'b0;
				if (calc_active) begin
					state_q <= 2'd1;
					busy <= 1'b1;
				end
				else begin
					state_q <= 2'd2;
					busy <= 1'b0;
					done <= 1'b1;
					overflow <= |calc_base_cycles[39:32];
					cycles <= (|calc_base_cycles[39:32] ? 32'hffffffff : calc_base_cycles[31:0]);
				end
			end
			else
				(* full_case, parallel_case *)
				case (state_q)
					2'd1: begin
						acc_q <= row_sum;
						if (rows_left_q == 16'd1) begin
							state_q <= 2'd2;
							busy <= 1'b0;
							done <= 1'b1;
							overflow <= |row_sum[39:32];
							cycles <= (|row_sum[39:32] ? 32'hffffffff : row_sum[31:0]);
						end
						else begin
							rows_left_q <= rows_left_q - 16'd1;
							if (!fill_q && !binary_q) begin
								if (yreverse_q) begin
									src_addr_q <= src_addr_q - sptch_q;
									dst_addr_q <= dst_addr_q - dptch_q;
								end
								else begin
									src_addr_q <= src_addr_q + sptch_q;
									dst_addr_q <= dst_addr_q + dptch_q;
								end
							end
						end
					end
					2'd0, 2'd2: busy <= 1'b0;
					default: begin
						state_q <= 2'd0;
						busy <= 1'b0;
						done <= 1'b0;
					end
				endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_int_ctrl (
	intpend,
	intenb,
	ie,
	int_req,
	int_vector
);
	reg _sv2v_0;
	input wire [15:0] intpend;
	input wire [15:0] intenb;
	input wire ie;
	output wire int_req;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	output reg [31:0] int_vector;
	wire [15:0] active;
	assign active = intpend & intenb;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	localparam [31:0] tms34010_pkg_INT_HI_BIT = 9;
	localparam [31:0] tms34010_pkg_INT_WV_BIT = 11;
	localparam [31:0] tms34010_pkg_INT_X1_BIT = 1;
	localparam [31:0] tms34010_pkg_INT_X2_BIT = 2;
	assign int_req = ie && ((((active[tms34010_pkg_INT_HI_BIT] || active[tms34010_pkg_INT_DI_BIT]) || active[tms34010_pkg_INT_WV_BIT]) || active[tms34010_pkg_INT_X1_BIT]) || active[tms34010_pkg_INT_X2_BIT]);
	localparam [31:0] tms34010_pkg_INT_VEC_DI = 32'hfffffea0;
	localparam [31:0] tms34010_pkg_INT_VEC_HI = 32'hfffffec0;
	localparam [31:0] tms34010_pkg_INT_VEC_WV = 32'hfffffe80;
	localparam [31:0] tms34010_pkg_INT_VEC_X1 = 32'hffffffc0;
	localparam [31:0] tms34010_pkg_INT_VEC_X2 = 32'hffffffa0;
	always @(*) begin
		if (_sv2v_0)
			;
		if (active[tms34010_pkg_INT_HI_BIT])
			int_vector = tms34010_pkg_INT_VEC_HI;
		else if (active[tms34010_pkg_INT_DI_BIT])
			int_vector = tms34010_pkg_INT_VEC_DI;
		else if (active[tms34010_pkg_INT_WV_BIT])
			int_vector = tms34010_pkg_INT_VEC_WV;
		else if (active[tms34010_pkg_INT_X1_BIT])
			int_vector = tms34010_pkg_INT_VEC_X1;
		else if (active[tms34010_pkg_INT_X2_BIT])
			int_vector = tms34010_pkg_INT_VEC_X2;
		else
			int_vector = tms34010_pkg_INT_VEC_HI;
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_mem_be (
	a_bitaddr,
	op_dword,
	wdata,
	r0_word,
	r1_word,
	t0_valid,
	t0_addr32,
	t0_be,
	t0_wdata,
	t1_valid,
	t1_addr32,
	t1_be,
	t1_wdata,
	rdata
);
	reg _sv2v_0;
	localparam [0:0] tms34010_pkg_IS_34020 = 1'b1;
	parameter [0:0] P_IS_34020 = tms34010_pkg_IS_34020;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] a_bitaddr;
	input wire op_dword;
	input wire [31:0] wdata;
	input wire [31:0] r0_word;
	input wire [31:0] r1_word;
	output reg t0_valid;
	output reg [31:0] t0_addr32;
	output reg [3:0] t0_be;
	output reg [31:0] t0_wdata;
	output reg t1_valid;
	output reg [31:0] t1_addr32;
	output reg [3:0] t1_be;
	output reg [31:0] t1_wdata;
	output reg [31:0] rdata;
	wire [31:0] word32base;
	wire half;
	function automatic [31:0] sv2v_cast_DEBC9;
		input reg [31:0] inp;
		sv2v_cast_DEBC9 = inp;
	endfunction
	assign word32base = a_bitaddr & ~sv2v_cast_DEBC9('h1f);
	assign half = a_bitaddr[4];
	always @(*) begin
		if (_sv2v_0)
			;
		t0_valid = 1'b1;
		t0_addr32 = word32base;
		t0_be = 4'b0000;
		t0_wdata = 32'h00000000;
		t1_valid = 1'b0;
		t1_addr32 = word32base + sv2v_cast_DEBC9('h20);
		t1_be = 4'b0000;
		t1_wdata = 32'h00000000;
		rdata = 32'h00000000;
		if (P_IS_34020) begin
			if (!op_dword) begin
				t0_addr32 = word32base;
				if (half) begin
					t0_be = 4'b1100;
					t0_wdata = {wdata[15:0], 16'h0000};
					rdata = {16'h0000, r0_word[31:16]};
				end
				else begin
					t0_be = 4'b0011;
					t0_wdata = {16'h0000, wdata[15:0]};
					rdata = {16'h0000, r0_word[15:0]};
				end
			end
			else if (!half) begin
				t0_addr32 = word32base;
				t0_be = 4'b1111;
				t0_wdata = wdata;
				rdata = r0_word;
			end
			else begin
				t0_addr32 = word32base;
				t0_be = 4'b1100;
				t0_wdata = {wdata[15:0], 16'h0000};
				t1_valid = 1'b1;
				t1_addr32 = word32base + sv2v_cast_DEBC9('h20);
				t1_be = 4'b0011;
				t1_wdata = {16'h0000, wdata[31:16]};
				rdata = {r1_word[15:0], r0_word[31:16]};
			end
		end
		else begin
			t0_addr32 = a_bitaddr & ~sv2v_cast_DEBC9('hf);
			t0_be = 4'b0011;
			t0_wdata = {16'h0000, wdata[15:0]};
			if (!op_dword)
				rdata = {16'h0000, r0_word[15:0]};
			else begin
				t1_valid = 1'b1;
				t1_addr32 = (a_bitaddr & ~sv2v_cast_DEBC9('hf)) + sv2v_cast_DEBC9('h10);
				t1_be = 4'b0011;
				t1_wdata = {16'h0000, wdata[31:16]};
				rdata = {r1_word[15:0], r0_word[15:0]};
			end
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_mem_if (
	clk,
	rst,
	ce_cpu,
	core_req,
	core_we,
	core_addr,
	core_size,
	core_wdata,
	core_srt,
	core_fetch,
	core_rdata,
	core_ack,
	bus_req,
	bus_we,
	bus_addr,
	bus_be,
	bus_wdata,
	bus_srt,
	bus_fetch,
	bus_rdata,
	bus_ack
);
	reg _sv2v_0;
	localparam [0:0] tms34010_pkg_IS_34020 = 1'b1;
	parameter [0:0] P_IS_34020 = tms34010_pkg_IS_34020;
	input wire clk;
	input wire rst;
	input wire ce_cpu;
	input wire core_req;
	input wire core_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] core_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	input wire [5:0] core_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] core_wdata;
	input wire core_srt;
	input wire core_fetch;
	output reg [31:0] core_rdata;
	output reg core_ack;
	output reg bus_req;
	output reg bus_we;
	output reg [31:0] bus_addr;
	output reg [3:0] bus_be;
	output reg [31:0] bus_wdata;
	output reg bus_srt;
	output wire bus_fetch;
	input wire [31:0] bus_rdata;
	input wire bus_ack;
	reg [31:0] a_q;
	reg [5:0] sz_q;
	reg we_q;
	reg f_q;
	assign bus_fetch = f_q;
	reg srt_q;
	reg [31:0] wd_q;
	wire [4:0] boff;
	wire [63:0] size_mask;
	assign boff = a_q[4:0];
	assign size_mask = (sz_q == 6'd0 ? 64'd0 : (64'd1 << sz_q) - 64'd1);
	wire [31:0] n_word0;
	wire [31:0] n_word1;
	wire [4:0] n_boff;
	wire [6:0] n_span;
	wire n_straddle;
	wire [63:0] n_size_mask;
	wire [63:0] n_fieldmask;
	wire [63:0] n_wdata_sh;
	reg [3:0] n_be0;
	reg [3:0] n_be1;
	reg [63:0] n_be_full;
	wire n_rmw;
	assign n_boff = core_addr[4:0];
	function automatic [31:0] sv2v_cast_DEBC9;
		input reg [31:0] inp;
		sv2v_cast_DEBC9 = inp;
	endfunction
	assign n_word0 = core_addr & ~sv2v_cast_DEBC9('h1f);
	assign n_word1 = n_word0 + sv2v_cast_DEBC9('h20);
	assign n_span = {2'b00, n_boff} + {1'b0, core_size};
	assign n_straddle = n_span > 7'd32;
	assign n_size_mask = (core_size == 6'd0 ? 64'd0 : (64'd1 << core_size) - 64'd1);
	assign n_fieldmask = n_size_mask << n_boff;
	assign n_wdata_sh = ((P_IS_34020 && (core_addr[3:0] == 4'd0)) && ((core_size == 6'd16) || (core_size == 6'd32)) ? (n_boff[4] ? {2 {core_wdata[15:0], core_wdata[31:16]}} : {32'd0, core_wdata}) : ({32'd0, core_wdata} << n_boff) & n_fieldmask);
	always @(*) begin : sv2v_autoblock_1
		integer k;
		if (_sv2v_0)
			;
		n_be0 = 4'b0000;
		n_be1 = 4'b0000;
		for (k = 0; k < 4; k = k + 1)
			begin
				if (|n_fieldmask[8 * k+:8])
					n_be0[k] = 1'b1;
				if (|n_fieldmask[32 + (8 * k)+:8])
					n_be1[k] = 1'b1;
			end
	end
	always @(*) begin : sv2v_autoblock_2
		integer k;
		if (_sv2v_0)
			;
		n_be_full = 64'd0;
		for (k = 0; k < 4; k = k + 1)
			begin
				if (n_be0[k])
					n_be_full[8 * k+:8] = 8'hff;
				if (n_be1[k])
					n_be_full[32 + (8 * k)+:8] = 8'hff;
			end
	end
	assign n_rmw = n_be_full != n_fieldmask;
	reg [31:0] p_addr0;
	reg [31:0] p_addr1;
	reg [3:0] p_be0;
	reg [3:0] p_be1;
	reg [31:0] p_wsh0;
	reg [31:0] p_wsh1;
	reg [31:0] p_nmask0;
	reg [31:0] p_nmask1;
	reg p_rmw;
	reg p_straddle;
	wire leaf_t0_valid;
	wire leaf_t1_valid;
	wire [31:0] leaf_t0_addr;
	wire [31:0] leaf_t1_addr;
	wire [3:0] leaf_t0_be;
	wire [3:0] leaf_t1_be;
	wire [31:0] leaf_t0_wd;
	wire [31:0] leaf_t1_wd;
	wire [31:0] leaf_rdata;
	tms34010_mem_be #(.P_IS_34020(1'b1)) u_leaf(
		.a_bitaddr(a_q),
		.op_dword(sz_q > 6'd16),
		.wdata(wd_q),
		.r0_word(32'h00000000),
		.r1_word(32'h00000000),
		.t0_valid(leaf_t0_valid),
		.t0_addr32(leaf_t0_addr),
		.t0_be(leaf_t0_be),
		.t0_wdata(leaf_t0_wd),
		.t1_valid(leaf_t1_valid),
		.t1_addr32(leaf_t1_addr),
		.t1_be(leaf_t1_be),
		.t1_wdata(leaf_t1_wd),
		.rdata(leaf_rdata)
	);
	reg [31:0] rd0_q;
	reg [31:0] rd1_q;
	wire [63:0] win;
	assign win = {rd1_q, rd0_q};
	wire [63:0] extracted;
	assign extracted = (win >> boff) & size_mask;
	reg [2:0] st_q;
	reg [2:0] st_d;
	always @(*) begin
		if (_sv2v_0)
			;
		st_d = st_q;
		bus_req = 1'b0;
		bus_we = 1'b0;
		bus_addr = p_addr0;
		bus_be = 4'b0000;
		bus_wdata = 32'h00000000;
		bus_srt = srt_q;
		(* full_case, parallel_case *)
		case (st_q)
			3'd0:
				if ((core_req && !core_ack) && (ce_cpu !== 1'b0))
					st_d = 3'd1;
			3'd1:
				if (we_q && !p_rmw)
					st_d = 3'd4;
				else
					st_d = 3'd2;
			3'd2: begin
				bus_req = 1'b1;
				bus_we = 1'b0;
				bus_addr = p_addr0;
				bus_be = (((P_IS_34020 && !we_q) && (sz_q == 6'd16)) && (a_q[3:0] == 4'd0) ? p_be0 : 4'b1111);
				if (bus_ack)
					st_d = (p_straddle ? 3'd3 : (we_q ? 3'd4 : 3'd6));
			end
			3'd3: begin
				bus_req = 1'b1;
				bus_we = 1'b0;
				bus_addr = p_addr1;
				bus_be = 4'b1111;
				if (bus_ack)
					st_d = (we_q ? 3'd4 : 3'd6);
			end
			3'd4: begin
				bus_req = 1'b1;
				bus_we = 1'b1;
				bus_addr = p_addr0;
				bus_be = p_be0;
				bus_wdata = (p_rmw ? (rd0_q & p_nmask0) | p_wsh0 : p_wsh0);
				if (bus_ack)
					st_d = (p_straddle && (p_be1 != 4'b0000) ? 3'd5 : 3'd6);
			end
			3'd5: begin
				bus_req = 1'b1;
				bus_we = 1'b1;
				bus_addr = p_addr1;
				bus_be = p_be1;
				bus_wdata = (p_rmw ? (rd1_q & p_nmask1) | p_wsh1 : p_wsh1);
				if (bus_ack)
					st_d = 3'd6;
			end
			3'd6: st_d = 3'd0;
			default: st_d = 3'd0;
		endcase
	end
	always @(posedge clk)
		if (rst) begin
			st_q <= 3'd0;
			a_q <= 1'sb0;
			sz_q <= 1'sb0;
			we_q <= 1'b0;
			f_q <= 1'b0;
			srt_q <= 1'b0;
			wd_q <= 1'sb0;
			rd0_q <= 1'sb0;
			rd1_q <= 1'sb0;
			core_ack <= 1'b0;
			core_rdata <= 1'sb0;
			p_addr0 <= 1'sb0;
			p_addr1 <= 1'sb0;
			p_be0 <= 4'b0000;
			p_be1 <= 4'b0000;
			p_wsh0 <= 1'sb0;
			p_wsh1 <= 1'sb0;
			p_nmask0 <= 1'sb0;
			p_nmask1 <= 1'sb0;
			p_rmw <= 1'b0;
			p_straddle <= 1'b0;
		end
		else begin
			if (core_ack && (ce_cpu !== 1'b0))
				core_ack <= 1'b0;
			if ((((st_q == 3'd0) && core_req) && !core_ack) && (ce_cpu !== 1'b0)) begin
				a_q <= core_addr;
				sz_q <= core_size;
				we_q <= core_we;
				f_q <= core_fetch;
				srt_q <= core_srt;
				wd_q <= core_wdata;
				p_addr0 <= n_word0;
				p_addr1 <= n_word1;
				p_be0 <= n_be0;
				p_be1 <= n_be1;
				p_rmw <= n_rmw;
				p_straddle <= n_straddle;
				p_wsh0 <= n_wdata_sh[31:0];
				p_wsh1 <= n_wdata_sh[63:32];
				p_nmask0 <= ~n_fieldmask[31:0];
				p_nmask1 <= ~n_fieldmask[63:32];
			end
			if ((st_q == 3'd2) && bus_ack)
				rd0_q <= bus_rdata;
			if ((st_q == 3'd3) && bus_ack)
				rd1_q <= bus_rdata;
			if (st_q == 3'd6) begin
				core_ack <= 1'b1;
				core_rdata <= (we_q ? {32 {1'sb0}} : {extracted[31:0]});
			end
			st_q <= st_d;
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_pc (
	clk,
	ce_cpu,
	rst,
	load_en,
	load_value,
	advance_en,
	advance_amount,
	pc_o
);
	reg _sv2v_0;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	localparam [31:0] tms34010_pkg_RESET_PC = 1'sb0;
	parameter [31:0] RESET_VALUE = tms34010_pkg_RESET_PC;
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire load_en;
	input wire [31:0] load_value;
	input wire advance_en;
	localparam [31:0] tms34010_pkg_PC_ADVANCE_WIDTH = 8;
	input wire [7:0] advance_amount;
	output wire [31:0] pc_o;
	reg [31:0] pc_q;
	reg [31:0] pc_d;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				pc_q <= RESET_VALUE;
			else
				pc_q <= pc_d;
		end
	wire [31:0] advance_ext;
	assign advance_ext = {{tms34010_pkg_ADDR_WIDTH - tms34010_pkg_PC_ADVANCE_WIDTH {1'b0}}, advance_amount};
	always @(*) begin
		if (_sv2v_0)
			;
		pc_d = pc_q;
		if (load_en)
			pc_d = load_value;
		else if (advance_en)
			pc_d = pc_q + advance_ext;
	end
	assign pc_o = pc_q;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_regfile (
	clk,
	ce_cpu,
	rst,
	rs1_file,
	rs1_idx,
	rs1_data,
	rs2_file,
	rs2_idx,
	rs2_data,
	rs3_file,
	rs3_idx,
	rs3_data,
	rs4_file,
	rs4_idx,
	rs4_data,
	wstart_data,
	wend_data,
	wr_en,
	wr_file,
	wr_idx,
	wr_data,
	sp_o
);
	reg _sv2v_0;
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire rs1_file;
	input wire [3:0] rs1_idx;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	output reg [31:0] rs1_data;
	input wire rs2_file;
	input wire [3:0] rs2_idx;
	output reg [31:0] rs2_data;
	input wire rs3_file;
	input wire [3:0] rs3_idx;
	output reg [31:0] rs3_data;
	input wire rs4_file;
	input wire [3:0] rs4_idx;
	output reg [31:0] rs4_data;
	output wire [31:0] wstart_data;
	output wire [31:0] wend_data;
	input wire wr_en;
	input wire wr_file;
	input wire [3:0] wr_idx;
	input wire [31:0] wr_data;
	output wire [31:0] sp_o;
	reg [31:0] a_regs [0:14];
	reg [31:0] b_regs [0:14];
	reg [31:0] sp_q;
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs1_idx == tms34010_pkg_REG_SP_IDX)
			rs1_data = sp_q;
		else if (rs1_file == 1'b1)
			rs1_data = b_regs[rs1_idx];
		else
			rs1_data = a_regs[rs1_idx];
	end
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs2_idx == tms34010_pkg_REG_SP_IDX)
			rs2_data = sp_q;
		else if (rs2_file == 1'b1)
			rs2_data = b_regs[rs2_idx];
		else
			rs2_data = a_regs[rs2_idx];
	end
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs3_idx == tms34010_pkg_REG_SP_IDX)
			rs3_data = sp_q;
		else if (rs3_file == 1'b1)
			rs3_data = b_regs[rs3_idx];
		else
			rs3_data = a_regs[rs3_idx];
	end
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs4_idx == tms34010_pkg_REG_SP_IDX)
			rs4_data = sp_q;
		else if (rs4_file == 1'b1)
			rs4_data = b_regs[rs4_idx];
		else
			rs4_data = a_regs[rs4_idx];
	end
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst) begin
				begin : sv2v_autoblock_1
					reg [31:0] i;
					for (i = 0; i < 15; i = i + 1)
						a_regs[i] <= 1'sb0;
				end
				begin : sv2v_autoblock_2
					reg [31:0] i;
					for (i = 0; i < 15; i = i + 1)
						b_regs[i] <= 1'sb0;
				end
				sp_q <= 1'sb0;
			end
			else if (wr_en) begin
				if (wr_idx == tms34010_pkg_REG_SP_IDX)
					sp_q <= wr_data;
				else if (wr_file == 1'b1)
					b_regs[wr_idx] <= wr_data;
				else
					a_regs[wr_idx] <= wr_data;
			end
		end
	assign sp_o = sp_q;
	localparam [3:0] tms34010_pkg_CPW_WSTART_IDX = 4'd5;
	assign wstart_data = b_regs[tms34010_pkg_CPW_WSTART_IDX];
	localparam [3:0] tms34010_pkg_CPW_WEND_IDX = 4'd6;
	assign wend_data = b_regs[tms34010_pkg_CPW_WEND_IDX];
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_shifter (
	op,
	a,
	amount,
	result,
	flags
);
	reg _sv2v_0;
	input wire [2:0] op;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] a;
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	input wire [4:0] amount;
	output reg [31:0] result;
	output reg [3:0] flags;
	wire [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] amount_w6;
	wire [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] complement_w6;
	assign amount_w6 = {1'b0, amount};
	assign complement_w6 = 6'd32 - amount_w6;
	wire [4:0] left_carry_idx;
	wire [4:0] right_carry_idx;
	assign left_carry_idx = complement_w6[4:0];
	assign right_carry_idx = amount - 5'd1;
	wire [31:0] left;
	wire [31:0] right_l;
	wire signed [31:0] right_a;
	wire [31:0] right_comp;
	wire [31:0] left_comp;
	assign left = a << amount;
	assign right_l = a >> amount;
	assign right_a = $signed(a) >>> amount;
	assign right_comp = a >> complement_w6;
	assign left_comp = a << complement_w6;
	wire [31:0] sla_v_mask;
	wire [31:0] sla_v_res2;
	assign sla_v_mask = (32'hffffffff << (6'd31 - amount_w6)) & 32'h7fffffff;
	assign sla_v_res2 = (a[31] ? a ^ sla_v_mask : a);
	always @(*) begin
		if (_sv2v_0)
			;
		result = a;
		flags[3] = a[31];
		flags[2] = 1'b0;
		flags[1] = a == {32 {1'sb0}};
		flags[0] = 1'b0;
		if (amount != {5 {1'sb0}}) begin
			(* full_case, parallel_case *)
			case (op)
				3'd0: begin
					result = left;
					flags[2] = a[left_carry_idx];
				end
				3'd1: begin
					result = left;
					flags[2] = a[left_carry_idx];
					flags[0] = |(sla_v_res2 & sla_v_mask);
				end
				3'd2: begin
					result = right_l;
					flags[2] = a[right_carry_idx];
				end
				3'd3: begin
					result = right_a;
					flags[2] = a[right_carry_idx];
				end
				3'd4: begin
					result = left | right_comp;
					flags[2] = a[left_carry_idx];
				end
				3'd5: begin
					result = right_l | left_comp;
					flags[2] = a[right_carry_idx];
				end
				default:
					;
			endcase
			flags[3] = result[31];
			flags[1] = result == {32 {1'sb0}};
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_status_reg (
	clk,
	ce_cpu,
	rst,
	flag_update_en,
	flags_in,
	flag_update_mask,
	st_write_en,
	st_write_data,
	st_o,
	n_o,
	c_o,
	z_o,
	v_o
);
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire flag_update_en;
	input wire [3:0] flags_in;
	input wire [3:0] flag_update_mask;
	input wire st_write_en;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] st_write_data;
	output wire [31:0] st_o;
	output wire n_o;
	output wire c_o;
	output wire z_o;
	output wire v_o;
	reg [31:0] st_q;
	localparam [31:0] tms34010_pkg_ST_C_BIT = 30;
	localparam [31:0] tms34010_pkg_ST_N_BIT = 31;
	localparam [31:0] tms34010_pkg_ST_RESET_VALUE = 32'h00000010;
	localparam [31:0] tms34010_pkg_ST_V_BIT = 28;
	localparam [31:0] tms34010_pkg_ST_Z_BIT = 29;
	always @(posedge clk)
		if ((ce_cpu !== 1'b0) || rst) begin
			if (rst)
				st_q <= tms34010_pkg_ST_RESET_VALUE;
			else if (st_write_en)
				st_q <= st_write_data;
			else if (flag_update_en) begin
				if (flag_update_mask[3])
					st_q[tms34010_pkg_ST_N_BIT] <= flags_in[3];
				if (flag_update_mask[2])
					st_q[tms34010_pkg_ST_C_BIT] <= flags_in[2];
				if (flag_update_mask[1])
					st_q[tms34010_pkg_ST_Z_BIT] <= flags_in[1];
				if (flag_update_mask[0])
					st_q[tms34010_pkg_ST_V_BIT] <= flags_in[0];
			end
		end
	assign st_o = st_q;
	assign n_o = st_q[tms34010_pkg_ST_N_BIT];
	assign c_o = st_q[tms34010_pkg_ST_C_BIT];
	assign z_o = st_q[tms34010_pkg_ST_Z_BIT];
	assign v_o = st_q[tms34010_pkg_ST_V_BIT];
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_cpu_config (
	clk,
	rst,
	ce_cpu,
	req,
	we,
	is_io,
	ack,
	addr,
	wdata,
	size,
	live_psize,
	live_convdp,
	live_convsp,
	live_control,
	live_pmask,
	live_dpyctl,
	psize,
	convdp,
	convsp,
	control,
	pmask,
	dpyctl
);
	input wire clk;
	input wire rst;
	input wire ce_cpu;
	input wire req;
	input wire we;
	input wire is_io;
	input wire ack;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [15:0] wdata;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	input wire [5:0] size;
	input wire [15:0] live_psize;
	input wire [15:0] live_convdp;
	input wire [15:0] live_convsp;
	input wire [15:0] live_control;
	input wire [15:0] live_pmask;
	input wire [15:0] live_dpyctl;
	output reg [15:0] psize;
	output reg [15:0] convdp;
	output reg [15:0] convsp;
	output reg [15:0] control;
	output reg [15:0] pmask;
	output reg [15:0] dpyctl;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] wr_idx = addr[8:4];
	wire config_write = ((((ce_cpu !== 1'b0) && req) && we) && is_io) && ack;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_mask;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [31:0] base;
		begin
			base = (fsize >= sv2v_cast_13C0F_signed(16) ? 32'h0000ffff : (32'd1 << fsize) - 32'd1);
			tms34010_pkg_io_field_mask = sv2v_cast_16((base << bit_off) & 32'h0000ffff);
		end
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_merge;
		input reg [15:0] current;
		input reg [15:0] wdata;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [15:0] m;
		begin
			m = tms34010_pkg_io_field_mask(bit_off, fsize);
			tms34010_pkg_io_field_merge = (current & ~m) | ((wdata << bit_off) & m);
		end
	endfunction
	wire [15:0] psize_m = tms34010_pkg_io_field_merge(psize, wdata, addr[3:0], size);
	wire [15:0] convdp_m = tms34010_pkg_io_field_merge(convdp, wdata, addr[3:0], size);
	wire [15:0] convsp_m = tms34010_pkg_io_field_merge(convsp, wdata, addr[3:0], size);
	wire [15:0] control_m = tms34010_pkg_io_field_merge(control, wdata, addr[3:0], size);
	wire [15:0] pmask_m = tms34010_pkg_io_field_merge(pmask, wdata, addr[3:0], size);
	wire [15:0] dpyctl_m = tms34010_pkg_io_field_merge(dpyctl, wdata, addr[3:0], size);
	localparam [4:0] tms34010_pkg_IO_IDX_CONTROL = 5'h0b;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVDP = 5'h14;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVSP = 5'h13;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYCTL = 5'h08;
	localparam [4:0] tms34010_pkg_IO_IDX_PMASK = 5'h16;
	localparam [4:0] tms34010_pkg_IO_IDX_PSIZE = 5'h15;
	always @(posedge clk)
		if (rst) begin
			psize <= 16'h0000;
			convdp <= 16'h0000;
			convsp <= 16'h0000;
			control <= 16'h0000;
			pmask <= 16'h0000;
			dpyctl <= 16'h0000;
		end
		else if (config_write)
			(* full_case, parallel_case *)
			case (wr_idx)
				tms34010_pkg_IO_IDX_PSIZE: psize <= psize_m;
				tms34010_pkg_IO_IDX_CONVDP: convdp <= convdp_m;
				tms34010_pkg_IO_IDX_CONVSP: convsp <= convsp_m;
				tms34010_pkg_IO_IDX_CONTROL: control <= control_m;
				tms34010_pkg_IO_IDX_PMASK: pmask <= pmask_m;
				tms34010_pkg_IO_IDX_DPYCTL: dpyctl <= dpyctl_m;
				default:
					;
			endcase
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_cpu_read_mux (
	is_io,
	addr,
	live_rdata,
	psize,
	convdp,
	convsp,
	control,
	pmask,
	intenb,
	intpend,
	hstctlh,
	cpu_rdata
);
	reg _sv2v_0;
	input wire is_io;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [15:0] live_rdata;
	input wire [15:0] psize;
	input wire [15:0] convdp;
	input wire [15:0] convsp;
	input wire [15:0] control;
	input wire [15:0] pmask;
	input wire [15:0] intenb;
	input wire [15:0] intpend;
	input wire [15:0] hstctlh;
	output reg [15:0] cpu_rdata;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] rd_idx = addr[8:4];
	localparam [4:0] tms34010_pkg_IO_IDX_CONTROL = 5'h0b;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVDP = 5'h14;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVSP = 5'h13;
	localparam [4:0] tms34010_pkg_IO_IDX_HSTCTLH = 5'h10;
	localparam [4:0] tms34010_pkg_IO_IDX_INTENB = 5'h11;
	localparam [4:0] tms34010_pkg_IO_IDX_INTPEND = 5'h12;
	localparam [4:0] tms34010_pkg_IO_IDX_PMASK = 5'h16;
	localparam [4:0] tms34010_pkg_IO_IDX_PSIZE = 5'h15;
	always @(*) begin
		if (_sv2v_0)
			;
		cpu_rdata = live_rdata;
		if (is_io)
			case (rd_idx)
				tms34010_pkg_IO_IDX_PSIZE: cpu_rdata = psize;
				tms34010_pkg_IO_IDX_CONVDP: cpu_rdata = convdp;
				tms34010_pkg_IO_IDX_CONVSP: cpu_rdata = convsp;
				tms34010_pkg_IO_IDX_CONTROL: cpu_rdata = control;
				tms34010_pkg_IO_IDX_PMASK: cpu_rdata = pmask;
				tms34010_pkg_IO_IDX_INTENB: cpu_rdata = intenb;
				tms34010_pkg_IO_IDX_INTPEND: cpu_rdata = intpend;
				tms34010_pkg_IO_IDX_HSTCTLH: cpu_rdata = hstctlh;
				default:
					;
			endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_cpu_status (
	clk,
	rst,
	ce_cpu,
	req,
	we,
	is_io,
	ack,
	addr,
	wdata,
	size,
	live_intenb,
	live_intpend,
	live_hstctlh,
	nmi_clear,
	intenb,
	intpend,
	hstctlh
);
	input wire clk;
	input wire rst;
	input wire ce_cpu;
	input wire req;
	input wire we;
	input wire is_io;
	input wire ack;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [15:0] wdata;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	input wire [5:0] size;
	input wire [15:0] live_intenb;
	input wire [15:0] live_intpend;
	input wire [15:0] live_hstctlh;
	input wire nmi_clear;
	output reg [15:0] intenb;
	output reg [15:0] intpend;
	output reg [15:0] hstctlh;
	reg intenb_write_bridge;
	reg intpend_write_bridge;
	reg hstctlh_write_bridge;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] wr_idx = addr[8:4];
	wire status_write = ((((ce_cpu !== 1'b0) && req) && we) && is_io) && ack;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_mask;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [31:0] base;
		begin
			base = (fsize >= sv2v_cast_13C0F_signed(16) ? 32'h0000ffff : (32'd1 << fsize) - 32'd1);
			tms34010_pkg_io_field_mask = sv2v_cast_16((base << bit_off) & 32'h0000ffff);
		end
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_merge;
		input reg [15:0] current;
		input reg [15:0] wdata;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [15:0] m;
		begin
			m = tms34010_pkg_io_field_mask(bit_off, fsize);
			tms34010_pkg_io_field_merge = (current & ~m) | ((wdata << bit_off) & m);
		end
	endfunction
	wire [15:0] intenb_merged = tms34010_pkg_io_field_merge(intenb, wdata, addr[3:0], size);
	wire [15:0] intpend_merged = tms34010_pkg_io_field_merge(intpend, wdata, addr[3:0], size);
	wire [15:0] hstctlh_merged = tms34010_pkg_io_field_merge(hstctlh, wdata, addr[3:0], size);
	localparam [31:0] tms34010_pkg_HSTCTL_NMI_BIT = 8;
	localparam [4:0] tms34010_pkg_IO_IDX_HSTCTLH = 5'h10;
	localparam [4:0] tms34010_pkg_IO_IDX_INTENB = 5'h11;
	localparam [4:0] tms34010_pkg_IO_IDX_INTPEND = 5'h12;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	localparam [31:0] tms34010_pkg_INT_WV_BIT = 11;
	localparam [15:0] tms34010_pkg_INTPEND_W0C_MASK = (16'h0001 << tms34010_pkg_INT_DI_BIT) | (16'h0001 << tms34010_pkg_INT_WV_BIT);
	function automatic [15:0] tms34010_pkg_intpend_apply_cpu_write;
		input reg [15:0] current;
		input reg [15:0] wdata;
		tms34010_pkg_intpend_apply_cpu_write = current & (wdata | ~tms34010_pkg_INTPEND_W0C_MASK);
	endfunction
	always @(posedge clk)
		if (rst) begin
			intenb <= 16'h0000;
			intpend <= 16'h0000;
			hstctlh <= 16'h0000;
			intenb_write_bridge <= 1'b0;
			intpend_write_bridge <= 1'b0;
			hstctlh_write_bridge <= 1'b0;
		end
		else if (ce_cpu !== 1'b0) begin
			if (status_write && (wr_idx == tms34010_pkg_IO_IDX_INTENB)) begin
				intenb <= intenb_merged;
				intenb_write_bridge <= 1'b1;
			end
			else if (intenb_write_bridge)
				intenb_write_bridge <= 1'b0;
			else begin
				intenb <= live_intenb;
				intenb_write_bridge <= 1'b0;
			end
			if (status_write && (wr_idx == tms34010_pkg_IO_IDX_INTPEND)) begin
				intpend <= tms34010_pkg_intpend_apply_cpu_write(intpend, intpend_merged);
				intpend_write_bridge <= 1'b1;
			end
			else if (intpend_write_bridge)
				intpend_write_bridge <= 1'b0;
			else begin
				intpend <= live_intpend;
				intpend_write_bridge <= 1'b0;
			end
			if (status_write && (wr_idx == tms34010_pkg_IO_IDX_HSTCTLH)) begin
				hstctlh <= hstctlh_merged;
				hstctlh_write_bridge <= 1'b1;
			end
			else if (hstctlh_write_bridge)
				hstctlh_write_bridge <= 1'b0;
			else begin
				hstctlh <= live_hstctlh;
				hstctlh_write_bridge <= 1'b0;
			end
			if (nmi_clear)
				hstctlh[tms34010_pkg_HSTCTL_NMI_BIT] <= 1'b0;
		end
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_regs (
	clk,
	rst,
	req,
	we,
	addr,
	wdata,
	wr_size,
	wr_mask,
	wr_data_sh,
	wr_pre_valid,
	status_guard,
	wr_display_hi,
	wr_display_pair,
	setcdp_we,
	setcdp_convdp,
	raddr,
	ce_pix,
	rdata,
	display_pair_rdata,
	is_io,
	psize_o,
	convdp_o,
	convsp_o,
	control_o,
	pmask_o,
	intenb_o,
	intpend_o,
	dpyctl_o,
	dpystrt_o,
	dbg_dpyst_value_o,
	dbg_dpyst_valid_o,
	dpytap_o,
	dpyadr_o,
	display_row_o,
	display_col_o,
	display_yoffset_o,
	display_enable_o,
	display_blank_o,
	vblank_start_o,
	hstctlh_o,
	timing_start_o,
	nmi_clear,
	wvp_set,
	lint1_in,
	lint2_in,
	video_hcount_o,
	video_vcount_o,
	video_heblnk_o,
	video_hsblnk_o,
	video_veblnk_o,
	video_vsblnk_o,
	video_hs_o,
	video_vs_o,
	video_hb_o,
	video_vb_o,
	video_ready_o
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [15:0] wdata;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	input wire [5:0] wr_size;
	input wire [15:0] wr_mask;
	input wire [15:0] wr_data_sh;
	input wire wr_pre_valid;
	input wire status_guard;
	input wire [15:0] wr_display_hi;
	input wire wr_display_pair;
	input wire setcdp_we;
	input wire [15:0] setcdp_convdp;
	input wire [31:0] raddr;
	input wire ce_pix;
	output wire [15:0] rdata;
	output reg [31:0] display_pair_rdata;
	output wire is_io;
	output wire [15:0] psize_o;
	output wire [15:0] convdp_o;
	output wire [15:0] convsp_o;
	output wire [15:0] control_o;
	output wire [15:0] pmask_o;
	output wire [15:0] intenb_o;
	output wire [15:0] intpend_o;
	output wire [15:0] dpyctl_o;
	output wire [15:0] dpystrt_o;
	output wire [31:0] dbg_dpyst_value_o;
	output reg dbg_dpyst_valid_o;
	output wire [15:0] dpytap_o;
	output wire [15:0] dpyadr_o;
	output wire [15:0] display_row_o;
	output wire [15:0] display_col_o;
	output wire [1:0] display_yoffset_o;
	output wire display_enable_o;
	output wire display_blank_o;
	output wire vblank_start_o;
	output wire [15:0] hstctlh_o;
	output reg timing_start_o;
	input wire nmi_clear;
	input wire wvp_set;
	input wire lint1_in;
	input wire lint2_in;
	output wire [15:0] video_hcount_o;
	output wire [15:0] video_vcount_o;
	output wire [15:0] video_heblnk_o;
	output wire [15:0] video_hsblnk_o;
	output wire [15:0] video_veblnk_o;
	output wire [15:0] video_vsblnk_o;
	output wire video_hs_o;
	output wire video_vs_o;
	output wire video_hb_o;
	output wire video_vb_o;
	output wire video_ready_o;
	localparam [0:0] tms34010_pkg_IS_34020 = 1'b1;
	localparam [0:0] M020 = tms34010_pkg_IS_34020;
	localparam [31:0] tms34010_pkg_IO_REG_COUNT = 32;
	localparam [31:0] IO_N = (M020 ? 64 : tms34010_pkg_IO_REG_COUNT);
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	localparam [31:0] IO_IW = (M020 ? 6 : tms34010_pkg_IO_REG_IDX_W);
	localparam [4:0] tms34010_pkg_IO_IDX_HESYNC = 5'h00;
	localparam [31:0] RX_HESYNC = (M020 ? 1 : tms34010_pkg_IO_IDX_HESYNC);
	localparam [4:0] tms34010_pkg_IO_IDX_HEBLNK = 5'h01;
	localparam [31:0] RX_HEBLNK = (M020 ? 3 : tms34010_pkg_IO_IDX_HEBLNK);
	localparam [4:0] tms34010_pkg_IO_IDX_HSBLNK = 5'h02;
	localparam [31:0] RX_HSBLNK = (M020 ? 5 : tms34010_pkg_IO_IDX_HSBLNK);
	localparam [4:0] tms34010_pkg_IO_IDX_HTOTAL = 5'h03;
	localparam [31:0] RX_HTOTAL = (M020 ? 7 : tms34010_pkg_IO_IDX_HTOTAL);
	localparam [4:0] tms34010_pkg_IO_IDX_VESYNC = 5'h04;
	localparam [31:0] RX_VESYNC = (M020 ? 0 : tms34010_pkg_IO_IDX_VESYNC);
	localparam [4:0] tms34010_pkg_IO_IDX_VEBLNK = 5'h05;
	localparam [31:0] RX_VEBLNK = (M020 ? 2 : tms34010_pkg_IO_IDX_VEBLNK);
	localparam [4:0] tms34010_pkg_IO_IDX_VSBLNK = 5'h06;
	localparam [31:0] RX_VSBLNK = (M020 ? 4 : tms34010_pkg_IO_IDX_VSBLNK);
	localparam [4:0] tms34010_pkg_IO_IDX_VTOTAL = 5'h07;
	localparam [31:0] RX_VTOTAL = (M020 ? 6 : tms34010_pkg_IO_IDX_VTOTAL);
	localparam [4:0] tms34010_pkg_IO_IDX_DPYCTL = 5'h08;
	localparam [31:0] RX_DPYCTL = tms34010_pkg_IO_IDX_DPYCTL;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYSTRT = 5'h09;
	localparam [31:0] RX_DPYSTRT = tms34010_pkg_IO_IDX_DPYSTRT;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYINT = 5'h0a;
	localparam [31:0] RX_DPYINT = tms34010_pkg_IO_IDX_DPYINT;
	localparam [4:0] tms34010_pkg_IO_IDX_CONTROL = 5'h0b;
	localparam [31:0] RX_CONTROL = tms34010_pkg_IO_IDX_CONTROL;
	localparam [4:0] tms34010_pkg_IO_IDX_HSTCTLH = 5'h10;
	localparam [31:0] RX_HSTCTLH = tms34010_pkg_IO_IDX_HSTCTLH;
	localparam [4:0] tms34010_pkg_IO_IDX_INTENB = 5'h11;
	localparam [31:0] RX_INTENB = tms34010_pkg_IO_IDX_INTENB;
	localparam [4:0] tms34010_pkg_IO_IDX_INTPEND = 5'h12;
	localparam [31:0] RX_INTPEND = tms34010_pkg_IO_IDX_INTPEND;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVSP = 5'h13;
	localparam [31:0] RX_CONVSP = tms34010_pkg_IO_IDX_CONVSP;
	localparam [4:0] tms34010_pkg_IO_IDX_CONVDP = 5'h14;
	localparam [31:0] RX_CONVDP = tms34010_pkg_IO_IDX_CONVDP;
	localparam [4:0] tms34010_pkg_IO_IDX_PSIZE = 5'h15;
	localparam [31:0] RX_PSIZE = tms34010_pkg_IO_IDX_PSIZE;
	localparam [4:0] tms34010_pkg_IO_IDX_PMASK = 5'h16;
	localparam [31:0] RX_PMASK = (M020 ? 22 : tms34010_pkg_IO_IDX_PMASK);
	localparam [4:0] tms34010_pkg_IO_IDX_DPYTAP = 5'h1b;
	localparam [31:0] RX_DPYTAP = (M020 ? 27 : tms34010_pkg_IO_IDX_DPYTAP);
	localparam [4:0] tms34010_pkg_IO_IDX_VCOUNT = 5'h1d;
	localparam [31:0] RX_VCOUNT = (M020 ? 28 : tms34010_pkg_IO_IDX_VCOUNT);
	localparam [4:0] tms34010_pkg_IO_IDX_HCOUNT = 5'h1c;
	localparam [31:0] RX_HCOUNT = (M020 ? 29 : tms34010_pkg_IO_IDX_HCOUNT);
	localparam [4:0] tms34010_pkg_IO_IDX_DPYADR = 5'h1e;
	localparam [31:0] RX_DPYADR = (M020 ? 30 : tms34010_pkg_IO_IDX_DPYADR);
	localparam [31:0] RX_CONTROL2 = (M020 ? 25 : 0);
	localparam [31:0] RX_DPYSTL = (M020 ? 32 : 0);
	localparam [31:0] RX_DPYSTH = (M020 ? 33 : 0);
	localparam [31:0] RX_DPYNXL = (M020 ? 34 : 0);
	localparam [31:0] RX_DPYNXH = (M020 ? 35 : 0);
	localparam [31:0] RX_DINCL = (M020 ? 36 : 0);
	localparam [31:0] RX_DINCH = (M020 ? 37 : 0);
	wire [IO_IW - 1:0] rd_idx;
	wire [IO_IW - 1:0] wr_idx;
	wire wr_is_io;
	assign is_io = (raddr[31:30] == 2'b11) && (raddr[29:IO_IW + 4] == {(29 >= (IO_IW + 4) ? 30 - (IO_IW + 4) : IO_IW - 24) * 1 {1'sb0}});
	assign rd_idx = raddr[IO_IW + 3:4];
	assign wr_is_io = (addr[31:30] == 2'b11) && (addr[29:IO_IW + 4] == {(29 >= (IO_IW + 4) ? 30 - (IO_IW + 4) : IO_IW - 24) * 1 {1'sb0}});
	assign wr_idx = addr[IO_IW + 3:4];
	reg [15:0] io_reg [0:IO_N - 1];
	wire [15:0] wr_merged;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_mask;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [31:0] base;
		begin
			base = (fsize >= sv2v_cast_13C0F_signed(16) ? 32'h0000ffff : (32'd1 << fsize) - 32'd1);
			tms34010_pkg_io_field_mask = sv2v_cast_16((base << bit_off) & 32'h0000ffff);
		end
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_merge;
		input reg [15:0] current;
		input reg [15:0] wdata;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [15:0] m;
		begin
			m = tms34010_pkg_io_field_mask(bit_off, fsize);
			tms34010_pkg_io_field_merge = (current & ~m) | ((wdata << bit_off) & m);
		end
	endfunction
	assign wr_merged = (wr_pre_valid === 1'b1 ? (io_reg[wr_idx] & ~wr_mask) | wr_data_sh : tms34010_pkg_io_field_merge(io_reg[wr_idx], wdata, addr[3:0], wr_size));
	wire timing_start_req;
	assign timing_start_req = (((((!rst && req) && we) && wr_is_io) && (wr_idx == RX_HTOTAL)) && (io_reg[RX_HTOTAL] == 16'd0)) && (wr_merged != 16'd0);
	always @(posedge clk)
		if (rst)
			timing_start_o <= 1'b0;
		else
			timing_start_o <= timing_start_req;
	wire dpyint_pulse;
	wire dpyint_event;
	wire video_line_advance;
	(* preserve *) reg dpyint_event_q;
	(* preserve *) reg wvp_set_q;
	(* preserve *) reg nmi_clear_q;
	reg video_ready_q;
	wire [15:0] vid_hcount;
	wire [15:0] vid_vcount;
	wire vid_hs_unused;
	wire vid_vs_unused;
	wire vid_hb_unused;
	wire vid_vb_unused;
	wire vid_bl_unused;
	tms34010_video u_video(
		.clk(clk),
		.rst(rst),
		.timing_start(timing_start_o),
		.ce(ce_pix),
		.hesync(io_reg[RX_HESYNC]),
		.heblnk(io_reg[RX_HEBLNK]),
		.hsblnk(io_reg[RX_HSBLNK]),
		.htotal(io_reg[RX_HTOTAL]),
		.vesync(io_reg[RX_VESYNC]),
		.veblnk(io_reg[RX_VEBLNK]),
		.vsblnk(io_reg[RX_VSBLNK]),
		.vtotal(io_reg[RX_VTOTAL]),
		.dpyint(io_reg[RX_DPYINT]),
		.hcount(vid_hcount),
		.vcount(vid_vcount),
		.hsync(vid_hs_unused),
		.vsync(vid_vs_unused),
		.hblank(vid_hb_unused),
		.vblank(vid_vb_unused),
		.blank(vid_bl_unused),
		.dpyint_pulse(dpyint_pulse),
		.line_advance(video_line_advance),
		.vblank_start(vblank_start_o)
	);
	assign video_hcount_o = vid_hcount;
	assign video_vcount_o = vid_vcount;
	assign video_heblnk_o = io_reg[RX_HEBLNK];
	assign video_hsblnk_o = io_reg[RX_HSBLNK];
	assign video_veblnk_o = io_reg[RX_VEBLNK];
	assign video_vsblnk_o = io_reg[RX_VSBLNK];
	assign video_hs_o = vid_hs_unused;
	assign video_vs_o = vid_vs_unused;
	assign video_hb_o = vid_hb_unused;
	assign video_vb_o = vid_vb_unused;
	assign video_ready_o = video_ready_q;
	assign dpyint_event = (dpyint_pulse && (io_reg[RX_VTOTAL] != 16'h0000)) && io_reg[RX_DPYCTL][15];
	wire lint1_lvl;
	wire lint2_lvl;
	assign lint1_lvl = lint1_in === 1'b1;
	assign lint2_lvl = lint2_in === 1'b1;
	localparam [31:0] tms34010_pkg_INT_X1_BIT = 1;
	localparam [31:0] tms34010_pkg_INT_X2_BIT = 2;
	function automatic [4:0] sv2v_cast_7548C;
		input reg [4:0] inp;
		sv2v_cast_7548C = inp;
	endfunction
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	assign rdata = (!is_io ? 16'h0000 : (rd_idx == RX_VCOUNT ? vid_vcount : (rd_idx == RX_HCOUNT ? vid_hcount : (rd_idx == sv2v_cast_32(sv2v_cast_7548C(5'h12)) ? (io_reg[rd_idx] | (sv2v_cast_16(lint1_lvl) << tms34010_pkg_INT_X1_BIT)) | (sv2v_cast_16(lint2_lvl) << tms34010_pkg_INT_X2_BIT) : io_reg[rd_idx]))));
	always @(*) begin
		if (_sv2v_0)
			;
		display_pair_rdata = 32'd0;
		if (M020)
			case (raddr)
				32'hc0000200: display_pair_rdata = {io_reg[RX_DPYSTH], io_reg[RX_DPYSTL]};
				32'hc0000220: display_pair_rdata = {io_reg[RX_DPYNXH], io_reg[RX_DPYNXL]};
				32'hc0000240: display_pair_rdata = {io_reg[RX_DINCH], io_reg[RX_DINCL]};
				default:
					;
			endcase
	end
	assign psize_o = io_reg[RX_PSIZE];
	assign convdp_o = io_reg[RX_CONVDP];
	assign convsp_o = io_reg[RX_CONVSP];
	assign control_o = io_reg[RX_CONTROL];
	assign pmask_o = io_reg[RX_PMASK];
	assign intenb_o = io_reg[RX_INTENB];
	assign dpyctl_o = io_reg[RX_DPYCTL];
	assign dpystrt_o = io_reg[RX_DPYSTRT];
	assign dbg_dpyst_value_o = (M020 ? {io_reg[RX_DPYSTH], io_reg[RX_DPYSTL]} : 32'd0);
	always @(posedge clk)
		if (rst)
			dbg_dpyst_valid_o <= 1'b0;
		else if (((((M020 && req) && we) && wr_is_io) && (wr_display_pair === 1'b1)) && (addr == 32'hc0000200))
			dbg_dpyst_valid_o <= 1'b1;
	assign dpytap_o = io_reg[RX_DPYTAP];
	assign dpyadr_o = io_reg[RX_DPYADR];
	assign display_enable_o = io_reg[RX_DPYCTL][15];
	assign display_blank_o = io_reg[RX_HEBLNK] >= io_reg[RX_HSBLNK];
	wire [15:0] display_dpyadr;
	assign display_dpyadr = (io_reg[sv2v_cast_32(sv2v_cast_7548C(5'h08))][10] ? io_reg[RX_DPYADR] : io_reg[RX_DPYADR] ^ 16'hfffc);
	assign display_row_o = (M020 ? io_reg[RX_DPYNXH] : display_dpyadr >> 4);
	assign display_col_o = (M020 ? io_reg[RX_DPYNXL] & 16'hffe0 : ((display_dpyadr & 16'h007c) << 4) | (io_reg[RX_DPYTAP] & 16'h3fff));
	assign display_yoffset_o = (M020 ? 2'd0 : (io_reg[RX_DPYSTRT] - io_reg[RX_DPYADR]) & 16'h0003);
	assign intpend_o = (io_reg[RX_INTPEND] | (sv2v_cast_16(lint1_lvl) << tms34010_pkg_INT_X1_BIT)) | (sv2v_cast_16(lint2_lvl) << tms34010_pkg_INT_X2_BIT);
	assign hstctlh_o = io_reg[RX_HSTCTLH];
	wire [31:0] dpynx_cur;
	wire [31:0] dinc_cur;
	wire [31:0] dpynx_step;
	wire [31:0] dpynx_next;
	assign dpynx_cur = {io_reg[RX_DPYNXH], io_reg[RX_DPYNXL]};
	assign dinc_cur = {io_reg[RX_DINCH], io_reg[RX_DINCL]};
	assign dpynx_step = (dpynx_cur & 32'hffffffe0) | ((dpynx_cur + dinc_cur) & 32'h0000001f);
	assign dpynx_next = ((dpynx_step & 32'h0000001f) == 32'h00000000 ? dpynx_step + (dinc_cur & 32'hffffffe0) : dpynx_step);
	localparam [31:0] tms34010_pkg_HSTCTL_NMI_BIT = 8;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	localparam [31:0] tms34010_pkg_INT_WV_BIT = 11;
	localparam [15:0] tms34010_pkg_INTPEND_W0C_MASK = (16'h0001 << tms34010_pkg_INT_DI_BIT) | (16'h0001 << tms34010_pkg_INT_WV_BIT);
	function automatic [15:0] tms34010_pkg_intpend_apply_cpu_write;
		input reg [15:0] current;
		input reg [15:0] wdata;
		tms34010_pkg_intpend_apply_cpu_write = current & (wdata | ~tms34010_pkg_INTPEND_W0C_MASK);
	endfunction
	always @(posedge clk)
		if (rst) begin
			begin : sv2v_autoblock_1
				reg signed [31:0] i;
				for (i = 0; i < IO_N; i = i + 1)
					io_reg[i] <= 16'h0000;
			end
			dpyint_event_q <= 1'b0;
			wvp_set_q <= 1'b0;
			nmi_clear_q <= 1'b0;
			video_ready_q <= 1'b0;
		end
		else begin
			dpyint_event_q <= dpyint_event;
			wvp_set_q <= wvp_set === 1'b1;
			nmi_clear_q <= nmi_clear === 1'b1;
			video_ready_q <= (io_reg[RX_HTOTAL] != 0) && (io_reg[RX_VTOTAL] != 0);
			if ((req && we) && wr_is_io) begin
				if (wr_idx == RX_INTPEND)
					io_reg[wr_idx] <= tms34010_pkg_intpend_apply_cpu_write(io_reg[wr_idx], wr_merged);
				else
					io_reg[wr_idx] <= wr_merged;
				if (M020 && (wr_display_pair === 1'b1))
					case (addr)
						32'hc0000200: io_reg[RX_DPYSTH] <= wr_display_hi;
						32'hc0000220: io_reg[RX_DPYNXH] <= wr_display_hi;
						32'hc0000240: io_reg[RX_DINCH] <= wr_display_hi;
						default:
							;
					endcase
			end
			if ((((M020 && req) && we) && wr_is_io) && ((wr_idx == RX_CONTROL) || (wr_idx == RX_CONTROL2))) begin
				io_reg[RX_CONTROL] <= wr_merged;
				io_reg[RX_CONTROL2] <= wr_merged;
			end
			if (((req && we) && wr_is_io) && (status_guard === 1'b1)) begin
				if (wr_idx == RX_INTPEND) begin
					if (wvp_set_q)
						io_reg[RX_INTPEND][tms34010_pkg_INT_WV_BIT] <= 1'b1;
					if (dpyint_event_q)
						io_reg[RX_INTPEND][tms34010_pkg_INT_DI_BIT] <= 1'b1;
				end
				if ((wr_idx == RX_HSTCTLH) && nmi_clear_q)
					io_reg[RX_HSTCTLH][tms34010_pkg_HSTCTL_NMI_BIT] <= 1'b0;
			end
			if (nmi_clear === 1'b1)
				io_reg[RX_HSTCTLH][tms34010_pkg_HSTCTL_NMI_BIT] <= 1'b0;
			if (wvp_set === 1'b1)
				io_reg[RX_INTPEND][tms34010_pkg_INT_WV_BIT] <= 1'b1;
			if (dpyint_event)
				io_reg[RX_INTPEND][tms34010_pkg_INT_DI_BIT] <= 1'b1;
			if (setcdp_we === 1'b1)
				io_reg[RX_CONVDP] <= setcdp_convdp;
			if (!M020) begin
				if (!(((req && we) && wr_is_io) && (wr_idx == RX_DPYADR))) begin
					if (vblank_start_o)
						io_reg[RX_DPYADR] <= io_reg[RX_DPYSTRT];
					else if ((video_line_advance && (vid_vcount >= io_reg[RX_VEBLNK])) && (vid_vcount < io_reg[RX_VSBLNK])) begin
						if (io_reg[RX_DPYADR][1:0] == 2'b00)
							io_reg[RX_DPYADR] <= ((io_reg[RX_DPYADR] & 16'hfffc) - (io_reg[RX_DPYCTL] & 16'h03fc)) | (io_reg[RX_DPYSTRT] & 16'h0003);
						else
							io_reg[RX_DPYADR] <= (io_reg[RX_DPYADR] & 16'hfffc) | ((io_reg[RX_DPYADR] - 16'd1) & 16'h0003);
					end
				end
			end
			else if (!(((req && we) && wr_is_io) && ((wr_idx == RX_DPYNXL) || (wr_idx == RX_DPYNXH)))) begin
				if (vblank_start_o) begin
					io_reg[RX_DPYNXL] <= io_reg[RX_DPYSTL] & 16'hffe0;
					io_reg[RX_DPYNXH] <= io_reg[RX_DPYSTH];
				end
				else if ((video_line_advance && (vid_vcount >= io_reg[RX_VEBLNK])) && (vid_vcount < io_reg[RX_VSBLNK])) begin
					io_reg[RX_DPYNXL] <= dpynx_next[15:0];
					io_reg[RX_DPYNXH] <= dpynx_next[31:16];
				end
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_write_boundary (
	clk,
	rst,
	ce_cpu,
	req,
	we,
	is_io,
	ack,
	addr,
	wdata,
	wdata_hi,
	size,
	wr_valid,
	wr_addr,
	wr_data,
	wr_size,
	wr_mask,
	wr_data_sh,
	wr_display_hi,
	wr_display_pair,
	wr_status_guard
);
	input wire clk;
	input wire rst;
	input wire ce_cpu;
	input wire req;
	input wire we;
	input wire is_io;
	input wire ack;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	input wire [15:0] wdata;
	input wire [15:0] wdata_hi;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	input wire [5:0] size;
	output reg wr_valid;
	output reg [31:0] wr_addr;
	output reg [15:0] wr_data;
	output reg [5:0] wr_size;
	output reg [15:0] wr_mask;
	output reg [15:0] wr_data_sh;
	output reg [15:0] wr_display_hi;
	output reg wr_display_pair;
	(* preserve *) output reg wr_status_guard;
	localparam [0:0] tms34010_pkg_IS_34020 = 1'b1;
	function automatic tms34010_pkg_io020_display_pair;
		input reg [31:0] a;
		tms34010_pkg_io020_display_pair = tms34010_pkg_IS_34020 && (((a == 32'hc0000200) || (a == 32'hc0000220)) || (a == 32'hc0000240));
	endfunction
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	function automatic [15:0] tms34010_pkg_io_field_mask;
		input reg [3:0] bit_off;
		input reg [5:0] fsize;
		reg [31:0] base;
		begin
			base = (fsize >= sv2v_cast_13C0F_signed(16) ? 32'h0000ffff : (32'd1 << fsize) - 32'd1);
			tms34010_pkg_io_field_mask = sv2v_cast_16((base << bit_off) & 32'h0000ffff);
		end
	endfunction
	always @(posedge clk)
		if (rst) begin
			wr_valid <= 1'b0;
			wr_addr <= 1'sb0;
			wr_data <= 1'sb0;
			wr_size <= 1'sb0;
			wr_mask <= 1'sb0;
			wr_data_sh <= 1'sb0;
			wr_display_hi <= 1'sb0;
			wr_display_pair <= 1'b0;
			wr_status_guard <= 1'b0;
		end
		else begin
			wr_valid <= 1'b0;
			wr_status_guard <= 1'b0;
			if (((((ce_cpu !== 1'b0) && req) && we) && is_io) && ack) begin
				wr_valid <= 1'b1;
				wr_addr <= addr;
				wr_data <= wdata;
				wr_size <= size;
				wr_display_hi <= wdata_hi;
				wr_display_pair <= tms34010_pkg_io020_display_pair(addr) && (size == sv2v_cast_13C0F_signed(32));
				wr_mask <= tms34010_pkg_io_field_mask(addr[3:0], size);
				wr_data_sh <= (wdata << addr[3:0]) & tms34010_pkg_io_field_mask(addr[3:0], size);
				wr_status_guard <= 1'b1;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module tms34010_refresh (
	clk,
	rst,
	rr,
	refresh_row,
	refresh_req
);
	input wire clk;
	input wire rst;
	input wire [1:0] rr;
	output wire [7:0] refresh_row;
	output wire refresh_req;
	wire enabled;
	wire [6:0] interval;
	assign enabled = (rr == 2'b00) || (rr == 2'b01);
	assign interval = (rr == 2'b01 ? 7'd63 : 7'd31);
	reg [6:0] presc_q;
	reg [7:0] refresh_row_q;
	assign refresh_req = enabled && (presc_q == interval);
	assign refresh_row = refresh_row_q;
	always @(posedge clk)
		if (rst) begin
			presc_q <= 7'd0;
			refresh_row_q <= 8'd0;
		end
		else if (enabled) begin
			if (presc_q == interval) begin
				presc_q <= 7'd0;
				refresh_row_q <= refresh_row_q + 8'd1;
			end
			else
				presc_q <= presc_q + 7'd1;
		end
endmodule
`default_nettype wire
`default_nettype none
module tms34010_video (
	clk,
	rst,
	timing_start,
	ce,
	hesync,
	heblnk,
	hsblnk,
	htotal,
	vesync,
	veblnk,
	vsblnk,
	vtotal,
	dpyint,
	hcount,
	vcount,
	hsync,
	vsync,
	hblank,
	vblank,
	blank,
	dpyint_pulse,
	line_advance,
	vblank_start
);
	input wire clk;
	input wire rst;
	input wire timing_start;
	input wire ce;
	input wire [15:0] hesync;
	input wire [15:0] heblnk;
	input wire [15:0] hsblnk;
	input wire [15:0] htotal;
	input wire [15:0] vesync;
	input wire [15:0] veblnk;
	input wire [15:0] vsblnk;
	input wire [15:0] vtotal;
	input wire [15:0] dpyint;
	output reg [15:0] hcount;
	output reg [15:0] vcount;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire blank;
	output wire dpyint_pulse;
	output wire line_advance;
	output wire vblank_start;
	wire hwrap;
	assign hwrap = hcount == htotal;
	wire [15:0] vcount_next;
	assign vcount_next = (vcount == vtotal ? 16'd0 : vcount + 16'd1);
	wire ce_eff;
	assign ce_eff = (ce === 1'b0 ? 1'b0 : 1'b1);
	wire timing_start_eff;
	assign timing_start_eff = timing_start === 1'b1;
	assign line_advance = (((ce_eff && hwrap) && !timing_start_eff) && (htotal != 16'd0)) && (vtotal != 16'd0);
	assign vblank_start = line_advance && (vcount_next == vsblnk);
	always @(posedge clk)
		if (rst || timing_start_eff) begin
			hcount <= 16'd0;
			vcount <= 16'd0;
		end
		else if (ce_eff) begin
			if (hwrap) begin
				hcount <= 16'd0;
				if (vcount == vtotal)
					vcount <= 16'd0;
				else
					vcount <= vcount + 16'd1;
			end
			else
				hcount <= hcount + 16'd1;
		end
	assign hsync = hcount < hesync;
	assign vsync = vcount < vesync;
	assign hblank = (hcount < heblnk) || (hcount >= hsblnk);
	assign vblank = (vcount < veblnk) || (vcount >= vsblnk);
	assign blank = hblank || vblank;
	wire dpyint_arrival;
	wire [15:0] dpyint_arrival_vcount;
	assign dpyint_arrival = (hsblnk == 16'd0 ? hwrap : hcount == (hsblnk - 16'd1));
	assign dpyint_arrival_vcount = ((hsblnk == 16'd0) && hwrap ? (vcount == vtotal ? 16'd0 : vcount + 16'd1) : vcount);
	assign dpyint_pulse = (ce_eff && dpyint_arrival) && (dpyint_arrival_vcount == dpyint);
endmodule
`default_nettype wire
`default_nettype none
module revx_loader (
	clk,
	por,
	core_rst,
	ioctl_download,
	ioctl_wr,
	ioctl_index,
	ioctl_addr,
	ioctl_dout,
	dl_wr,
	dl_addr,
	dl_din,
	dl_be,
	dl_ack,
	gfx_dl_wr,
	gfx_dl_addr,
	gfx_dl_data,
	gfx_dl_ack,
	dcs_dl_wr,
	dcs_dl_addr,
	dcs_dl_data,
	dcs_dl_ack,
	pic_rd_addr,
	pic_rd_data,
	profile_byte,
	profile_valid,
	dl_wait,
	dl_ready,
	acc_prog,
	acc_gfx,
	acc_dcs,
	acc_pic,
	acc_nvram,
	acc_profile,
	drop_prog,
	drop_gfx,
	drop_dcs,
	drop_pic,
	rst_during_dl,
	smp_prog_addr,
	smp_prog_din,
	smp_prog_be,
	smp_gfx_addr,
	smp_gfx_data,
	smp_dcs_addr,
	smp_dcs_data
);
	parameter signed [31:0] SD_AW = 21;
	parameter [SD_AW - 1:0] ROM_SDBASE = 21'h100000;
	parameter [24:0] PROG_BASE = 25'h0000000;
	parameter [24:0] PROG_BYTES = 25'h0200000;
	parameter [24:0] GFX_BASE = 25'h0200000;
	parameter [24:0] GFX_BYTES = 25'h0e00000;
	parameter [24:0] DCS_BASE = 25'h1000000;
	parameter [24:0] DCS_BYTES = 25'h0400000;
	parameter [24:0] PIC_BASE = 25'h1400000;
	parameter [24:0] PIC_BYTES = 25'h0002000;
	parameter [7:0] MAIN_INDEX = 8'd0;
	parameter [7:0] PROFILE_INDEX = 8'd3;
	parameter [7:0] NVRAM_INDEX = 8'd4;
	input wire clk;
	input wire por;
	input wire core_rst;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [7:0] ioctl_index;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output reg dl_wr;
	output reg [SD_AW - 1:0] dl_addr;
	output reg [15:0] dl_din;
	output reg [1:0] dl_be;
	input wire dl_ack;
	output reg gfx_dl_wr;
	output reg [24:0] gfx_dl_addr;
	output reg [7:0] gfx_dl_data;
	input wire gfx_dl_ack;
	output reg dcs_dl_wr;
	output reg [22:0] dcs_dl_addr;
	output reg [7:0] dcs_dl_data;
	input wire dcs_dl_ack;
	input wire [12:0] pic_rd_addr;
	output wire [7:0] pic_rd_data;
	output reg [7:0] profile_byte;
	output reg profile_valid;
	output wire dl_wait;
	output wire dl_ready;
	output reg [31:0] acc_prog;
	output reg [31:0] acc_gfx;
	output reg [31:0] acc_dcs;
	output reg [31:0] acc_pic;
	output reg [31:0] acc_nvram;
	output reg [31:0] acc_profile;
	output reg [31:0] drop_prog;
	output reg [31:0] drop_gfx;
	output reg [31:0] drop_dcs;
	output reg [31:0] drop_pic;
	output reg rst_during_dl;
	output reg [SD_AW - 1:0] smp_prog_addr;
	output reg [15:0] smp_prog_din;
	output reg [1:0] smp_prog_be;
	output reg [24:0] smp_gfx_addr;
	output reg [7:0] smp_gfx_data;
	output reg [22:0] smp_dcs_addr;
	output reg [7:0] smp_dcs_data;
	wire cap_rst = por;
	wire is_main = ioctl_download & (ioctl_index == MAIN_INDEX);
	wire is_profile = ioctl_download & (ioctl_index == PROFILE_INDEX);
	wire is_nvram = ioctl_download & (ioctl_index == NVRAM_INDEX);
	wire sel_prog = (is_main & (ioctl_addr >= PROG_BASE)) & (ioctl_addr < (PROG_BASE + PROG_BYTES));
	wire sel_gfx = (is_main & (ioctl_addr >= GFX_BASE)) & (ioctl_addr < (GFX_BASE + GFX_BYTES));
	wire sel_dcs = (is_main & (ioctl_addr >= DCS_BASE)) & (ioctl_addr < (DCS_BASE + DCS_BYTES));
	wire sel_pic = (is_main & (ioctl_addr >= PIC_BASE)) & (ioctl_addr < (PIC_BASE + PIC_BYTES));
	wire [24:0] prog_baddr = ioctl_addr - PROG_BASE;
	wire [24:0] gfx_baddr = ioctl_addr - GFX_BASE;
	wire [24:0] dcs_baddr = ioctl_addr - DCS_BASE;
	wire [24:0] pic_baddr = ioctl_addr - PIC_BASE;
	wire [SD_AW - 1:0] prog_word = ROM_SDBASE + prog_baddr[SD_AW:1];
	reg ioctl_wr_d;
	wire wr_edge = ioctl_wr & ~ioctl_wr_d;
	reg prog_busy;
	reg gfx_busy;
	reg dcs_busy;
	assign dl_wait = (prog_busy | gfx_busy) | dcs_busy;
	assign dl_ready = ~dl_wait;
	reg [7:0] prog_hold_data;
	reg [SD_AW - 1:0] prog_hold_addr;
	reg prog_hold_valid;
	reg ioctl_dl_d;
	revx_palram #(
		.DW(8),
		.AW(13)
	) u_pic(
		.clk(clk),
		.we_a((!cap_rst && wr_edge) && sel_pic),
		.addr_a(pic_baddr[12:0]),
		.wd_a(ioctl_dout),
		.rd_a(),
		.addr_b(pic_rd_addr),
		.rd_b(pic_rd_data)
	);
	always @(posedge clk)
		if (cap_rst) begin
			ioctl_wr_d <= 1'b0;
			ioctl_dl_d <= 1'b0;
			dl_wr <= 1'b0;
			gfx_dl_wr <= 1'b0;
			dcs_dl_wr <= 1'b0;
			prog_busy <= 1'b0;
			gfx_busy <= 1'b0;
			dcs_busy <= 1'b0;
			prog_hold_data <= 8'd0;
			prog_hold_addr <= 1'sb0;
			prog_hold_valid <= 1'b0;
			profile_byte <= 8'd0;
			profile_valid <= 1'b0;
			acc_prog <= 0;
			acc_gfx <= 0;
			acc_dcs <= 0;
			acc_pic <= 0;
			acc_nvram <= 0;
			acc_profile <= 0;
			drop_prog <= 0;
			drop_gfx <= 0;
			drop_dcs <= 0;
			drop_pic <= 0;
			rst_during_dl <= 1'b0;
			smp_prog_addr <= 1'sb0;
			smp_prog_din <= 1'sb0;
			smp_prog_be <= 1'sb0;
			smp_gfx_addr <= 1'sb0;
			smp_gfx_data <= 1'sb0;
			smp_dcs_addr <= 1'sb0;
			smp_dcs_data <= 1'sb0;
		end
		else begin
			ioctl_wr_d <= ioctl_wr;
			ioctl_dl_d <= ioctl_download;
			if (ioctl_download & core_rst)
				rst_during_dl <= 1'b1;
			if (prog_busy) begin
				if (dl_ack) begin
					dl_wr <= 1'b0;
					prog_busy <= 1'b0;
				end
			end
			else begin
				dl_wr <= 1'b0;
				if (wr_edge & sel_prog) begin
					acc_prog <= acc_prog + 1;
					if (!prog_baddr[0]) begin
						prog_hold_data <= ioctl_dout;
						prog_hold_addr <= prog_word;
						prog_hold_valid <= 1'b1;
					end
					else begin
						dl_din <= {ioctl_dout, prog_hold_data};
						smp_prog_din <= {ioctl_dout, prog_hold_data};
						dl_addr <= prog_word;
						dl_be <= 2'b11;
						dl_wr <= 1'b1;
						prog_busy <= 1'b1;
						prog_hold_valid <= 1'b0;
						smp_prog_addr <= prog_word;
						smp_prog_be <= 2'b11;
					end
				end
				else if ((prog_hold_valid & ioctl_dl_d) & ~ioctl_download) begin
					dl_addr <= prog_hold_addr;
					dl_din <= {prog_hold_data, prog_hold_data};
					dl_be <= 2'b01;
					dl_wr <= 1'b1;
					prog_busy <= 1'b1;
					prog_hold_valid <= 1'b0;
					smp_prog_addr <= prog_hold_addr;
					smp_prog_din <= {prog_hold_data, prog_hold_data};
					smp_prog_be <= 2'b01;
				end
			end
			if ((wr_edge & sel_prog) & prog_busy)
				drop_prog <= drop_prog + 1;
			if (gfx_busy) begin
				if (gfx_dl_ack) begin
					gfx_dl_wr <= 1'b0;
					gfx_busy <= 1'b0;
				end
			end
			else begin
				gfx_dl_wr <= 1'b0;
				if (wr_edge & sel_gfx) begin
					gfx_dl_addr <= gfx_baddr;
					gfx_dl_data <= ioctl_dout;
					gfx_dl_wr <= 1'b1;
					gfx_busy <= 1'b1;
					acc_gfx <= acc_gfx + 1;
					smp_gfx_addr <= gfx_baddr;
					smp_gfx_data <= ioctl_dout;
				end
			end
			if ((wr_edge & sel_gfx) & gfx_busy)
				drop_gfx <= drop_gfx + 1;
			if (dcs_busy) begin
				if (dcs_dl_ack) begin
					dcs_dl_wr <= 1'b0;
					dcs_busy <= 1'b0;
				end
			end
			else begin
				dcs_dl_wr <= 1'b0;
				if (wr_edge & sel_dcs) begin
					dcs_dl_addr <= dcs_baddr[22:0];
					dcs_dl_data <= ioctl_dout;
					dcs_dl_wr <= 1'b1;
					dcs_busy <= 1'b1;
					acc_dcs <= acc_dcs + 1;
					smp_dcs_addr <= dcs_baddr[22:0];
					smp_dcs_data <= ioctl_dout;
				end
			end
			if ((wr_edge & sel_dcs) & dcs_busy)
				drop_dcs <= drop_dcs + 1;
			if (wr_edge & sel_pic)
				acc_pic <= acc_pic + 1;
			if ((wr_edge & is_profile) & (ioctl_addr == 25'd0)) begin
				profile_byte <= ioctl_dout;
				profile_valid <= 1'b1;
				acc_profile <= acc_profile + 1;
			end
			if (wr_edge & is_nvram)
				acc_nvram <= acc_nvram + 1;
		end
endmodule
`default_nettype wire
`default_nettype none
module revx_word_sdram (
	clk,
	rst,
	req,
	we,
	waddr,
	be,
	wd,
	rdata,
	done,
	active,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack
);
	parameter signed [31:0] WORDS = 32'h00040000;
	parameter signed [31:0] SD_AW = 21;
	parameter [SD_AW - 1:0] BASE = 1'sb0;
	parameter [0:0] READ_ONLY = 1'b0;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	input wire [26:0] waddr;
	input wire [3:0] be;
	input wire [31:0] wd;
	output wire [31:0] rdata;
	output reg done;
	output wire active;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	localparam [0:0] REVX_SDRAM_RMW_PARTIAL = 1'b1;
	reg we_l;
	reg [26:0] wi;
	reg [3:0] be_l;
	reg [31:0] wd_l;
	reg [15:0] rmw_dat;
	wire [27:0] w2 = {wi, 1'b0};
	wire [SD_AW - 1:0] a_lo = BASE + w2[SD_AW - 1:0];
	wire [SD_AW - 1:0] a_hi = (BASE + w2[SD_AW - 1:0]) + 1'b1;
	reg [15:0] o_lo;
	reg [15:0] o_hi;
	reg [2:0] st;
	assign active = st != 3'd0;
	assign rdata = {o_hi, o_lo};
	wire wr_lo = we_l & |be_l[1:0];
	wire wr_hi = we_l & |be_l[3:2];
	wire part_lo = (we_l & (be_l[1:0] != 2'b00)) & (be_l[1:0] != 2'b11);
	wire part_hi = (we_l & (be_l[3:2] != 2'b00)) & (be_l[3:2] != 2'b11);
	always @(posedge clk)
		if (rst) begin
			st <= 3'd0;
			done <= 1'b0;
			sd_rd <= 1'b0;
			sd_wr <= 1'b0;
			o_lo <= 16'h0000;
			o_hi <= 16'h0000;
		end
		else begin
			done <= 1'b0;
			case (st)
				3'd0: begin
					sd_rd <= 1'b0;
					sd_wr <= 1'b0;
					if (req) begin
						we_l <= we & ~READ_ONLY;
						wi <= waddr;
						be_l <= be;
						wd_l <= wd;
						o_lo <= 16'h0000;
						o_hi <= 16'h0000;
						st <= 3'd1;
					end
				end
				3'd1:
					if (we_l && !wr_lo) begin
						sd_wr <= 1'b0;
						st <= 3'd3;
					end
					else if (sd_ack) begin
						if (!we_l) begin
							o_lo <= sd_dout;
							st <= 3'd3;
						end
						else if (REVX_SDRAM_RMW_PARTIAL && part_lo) begin
							rmw_dat <= {(be_l[1] ? wd_l[15:8] : sd_dout[15:8]), (be_l[0] ? wd_l[7:0] : sd_dout[7:0])};
							st <= 3'd2;
						end
						else
							st <= 3'd3;
						sd_rd <= 1'b0;
						sd_wr <= 1'b0;
					end
					else begin
						sd_addr <= a_lo;
						if (!we_l) begin
							sd_be <= 2'b00;
							sd_rd <= 1'b1;
						end
						else if (REVX_SDRAM_RMW_PARTIAL && part_lo) begin
							sd_be <= 2'b00;
							sd_rd <= 1'b1;
						end
						else begin
							sd_din <= wd_l[15:0];
							sd_be <= be_l[1:0];
							sd_wr <= 1'b1;
						end
					end
				3'd2:
					if (sd_ack) begin
						sd_wr <= 1'b0;
						st <= 3'd3;
					end
					else begin
						sd_addr <= a_lo;
						sd_din <= rmw_dat;
						sd_be <= 2'b11;
						sd_wr <= 1'b1;
					end
				3'd3:
					if (we_l && !wr_hi) begin
						sd_wr <= 1'b0;
						st <= 3'd5;
					end
					else if (sd_ack) begin
						if (!we_l) begin
							o_hi <= sd_dout;
							st <= 3'd5;
						end
						else if (REVX_SDRAM_RMW_PARTIAL && part_hi) begin
							rmw_dat <= {(be_l[3] ? wd_l[31:24] : sd_dout[15:8]), (be_l[2] ? wd_l[23:16] : sd_dout[7:0])};
							st <= 3'd4;
						end
						else
							st <= 3'd5;
						sd_rd <= 1'b0;
						sd_wr <= 1'b0;
					end
					else begin
						sd_addr <= a_hi;
						if (!we_l) begin
							sd_be <= 2'b00;
							sd_rd <= 1'b1;
						end
						else if (REVX_SDRAM_RMW_PARTIAL && part_hi) begin
							sd_be <= 2'b00;
							sd_rd <= 1'b1;
						end
						else begin
							sd_din <= wd_l[31:16];
							sd_be <= be_l[3:2];
							sd_wr <= 1'b1;
						end
					end
				3'd4:
					if (sd_ack) begin
						sd_wr <= 1'b0;
						st <= 3'd5;
					end
					else begin
						sd_addr <= a_hi;
						sd_din <= rmw_dat;
						sd_be <= 2'b11;
						sd_wr <= 1'b1;
					end
				3'd5: begin
					done <= 1'b1;
					st <= 3'd0;
				end
				default: st <= 3'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module revx_vram_write_mux (
	clk,
	rst,
	cpu_reserve,
	cpu_addr,
	cpu_data,
	cpu_be,
	cpu_rd,
	cpu_wr,
	cpu_ack,
	dma_req,
	dma_addr,
	dma_data,
	dma_count,
	dma_words,
	dma_reverse,
	dma_ack,
	dma_claimed,
	addr,
	data,
	be,
	rd,
	wr,
	ack,
	count,
	words,
	reverse
);
	parameter signed [31:0] AW = 19;
	input wire clk;
	input wire rst;
	input wire cpu_reserve;
	input wire [AW - 1:0] cpu_addr;
	input wire [15:0] cpu_data;
	input wire [1:0] cpu_be;
	input wire cpu_rd;
	input wire cpu_wr;
	output wire cpu_ack;
	input wire dma_req;
	input wire [AW - 1:0] dma_addr;
	input wire [15:0] dma_data;
	input wire [2:0] dma_count;
	input wire [63:0] dma_words;
	input wire dma_reverse;
	output wire dma_ack;
	output wire dma_claimed;
	output wire [AW - 1:0] addr;
	output wire [15:0] data;
	output wire [1:0] be;
	output wire rd;
	output wire wr;
	input wire ack;
	output wire [2:0] count;
	output wire [63:0] words;
	output wire reverse;
	reg [1:0] state;
	reg dma_seen;
	reg [AW - 1:0] dma_addr_q;
	reg [15:0] dma_data_q;
	reg [2:0] dma_count_q;
	reg [63:0] dma_words_q;
	reg dma_reverse_q;
	wire dma_group = ((dma_count === 3'd2) || (dma_count === 3'd3)) || (dma_count === 3'd4);
	assign count = (state == 2'd2 ? dma_count_q : 3'd1);
	assign words = (state == 2'd2 ? dma_words_q : {48'd0, cpu_data});
	assign reverse = (state == 2'd2) && dma_reverse_q;
	assign addr = (state == 2'd2 ? dma_addr_q : cpu_addr);
	assign data = (state == 2'd2 ? dma_data_q : cpu_data);
	assign be = (state == 2'd2 ? 2'b11 : cpu_be);
	assign rd = (state == 2'd1) && cpu_rd;
	assign wr = ((state == 2'd1) && cpu_wr) || (state == 2'd2);
	assign cpu_ack = (state == 2'd1) && ack;
	assign dma_ack = (state == 2'd2) && ack;
	assign dma_claimed = state == 2'd2;
	always @(posedge clk)
		if (rst) begin
			state <= 2'd0;
			dma_seen <= 1'b0;
			dma_addr_q <= 1'sb0;
			dma_data_q <= 1'sb0;
			dma_count_q <= 1;
			dma_words_q <= 0;
			dma_reverse_q <= 0;
		end
		else begin
			if (!dma_req)
				dma_seen <= 1'b0;
			case (state)
				2'd0:
					if (!ack) begin
						if (cpu_rd || cpu_wr)
							state <= 2'd1;
						else if ((dma_req && !dma_seen) && !cpu_reserve) begin
							dma_addr_q <= dma_addr;
							dma_data_q <= dma_data;
							dma_count_q <= (dma_group ? dma_count : 3'd1);
							dma_words_q <= (dma_group ? dma_words : {48'd0, dma_data});
							dma_reverse_q <= dma_group && (dma_reverse === 1'b1);
							dma_seen <= 1'b1;
							state <= 2'd2;
						end
					end
				2'd1, 2'd2:
					if (ack)
						state <= 2'd3;
				2'd3:
					if (!ack)
						state <= 2'd0;
				default: state <= 2'd0;
			endcase
		end
endmodule
module revx_read_chunk_mux (
	clk,
	rst,
	a_req,
	a_addr,
	a_count,
	a_data,
	a_ack,
	b_req,
	b_addr,
	b_count,
	b_data,
	b_ack,
	req,
	addr,
	count,
	data,
	ack
);
	parameter signed [31:0] AW = 22;
	input wire clk;
	input wire rst;
	input wire a_req;
	input wire [AW - 1:0] a_addr;
	input wire [4:0] a_count;
	output wire [255:0] a_data;
	output wire a_ack;
	input wire b_req;
	input wire [AW - 1:0] b_addr;
	input wire [4:0] b_count;
	output wire [255:0] b_data;
	output wire b_ack;
	output wire req;
	output reg [AW - 1:0] addr;
	output reg [4:0] count;
	input wire [255:0] data;
	input wire ack;
	reg [1:0] state;
	assign req = (state == 2'd1) || (state == 2'd2);
	assign a_ack = ack && (state == 2'd1);
	assign b_ack = ack && (state == 2'd2);
	assign a_data = data;
	assign b_data = data;
	always @(posedge clk)
		if (rst) begin
			state <= 2'd0;
			addr <= 1'sb0;
			count <= 1'sb0;
		end
		else
			case (state)
				2'd0:
					if (!ack) begin
						if (a_req === 1'b1) begin
							state <= 2'd1;
							addr <= a_addr;
							count <= a_count;
						end
						else if (b_req === 1'b1) begin
							state <= 2'd2;
							addr <= b_addr;
							count <= b_count;
						end
					end
				2'd1, 2'd2:
					if (ack)
						state <= 2'd3;
				2'd3:
					if (!ack)
						state <= 2'd0;
				default: state <= 2'd0;
			endcase
endmodule
module revx_chunk_mailbox (
	clk,
	rst,
	cpu_req,
	cpu_addr,
	cpu_count,
	cpu_wdata,
	cpu_ack,
	cpu_rdata,
	req,
	addr,
	count,
	wdata,
	ack,
	rdata
);
	parameter signed [31:0] AW = 21;
	input wire clk;
	input wire rst;
	input wire cpu_req;
	input wire [AW - 1:0] cpu_addr;
	input wire [4:0] cpu_count;
	input wire [255:0] cpu_wdata;
	output wire cpu_ack;
	output reg [255:0] cpu_rdata;
	output wire req;
	output reg [AW - 1:0] addr;
	output reg [4:0] count;
	output reg [255:0] wdata;
	input wire ack;
	input wire [255:0] rdata;
	reg [1:0] state;
	assign req = state == 2'd1;
	assign cpu_ack = state == 2'd2;
	always @(posedge clk)
		if (rst) begin
			state <= 2'd0;
			addr <= 1'sb0;
			count <= 1'sb0;
			wdata <= 1'sb0;
			cpu_rdata <= 1'sb0;
		end
		else
			case (state)
				2'd0:
					if (cpu_req && !ack) begin
						addr <= cpu_addr;
						count <= cpu_count;
						wdata <= cpu_wdata;
						state <= 2'd1;
					end
				2'd1:
					if (ack) begin
						cpu_rdata <= rdata;
						state <= 2'd2;
					end
				2'd2:
					if (!cpu_req)
						state <= 2'd0;
				default: state <= 2'd0;
			endcase
endmodule
module revx_sdram_arb (
	clk,
	rst,
	s_addr,
	s_rd,
	s_dout,
	s_ack,
	s_chunk_dout,
	a_addr,
	a_din,
	a_be,
	a_rd,
	a_wr,
	a_dout,
	a_ack,
	b_addr,
	b_din,
	b_be,
	b_rd,
	b_wr,
	b_dout,
	b_ack,
	vd_addr,
	vd_din,
	vd_be,
	vd_rd,
	vd_wr,
	vd_dout,
	vd_ack,
	vd_count,
	vd_words,
	vd_reverse,
	vc_addr,
	vc_din,
	vc_be,
	vc_rd,
	vc_wr,
	vc_dout,
	vc_ack,
	dl_addr,
	dl_din,
	dl_be,
	dl_wr,
	dl_ack,
	wb_req,
	wb_addr,
	wb_count,
	wb_data,
	wb_ack,
	wb2_req,
	wb2_addr,
	wb2_count,
	wb2_data,
	wb2_ack,
	rb_req,
	rb_addr,
	rb_count,
	rb_dout,
	rb_ack,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack,
	sd_write_chunk,
	sd_write_reverse,
	sd_read_chunk,
	sd_chunk_count,
	sd_chunk_data,
	sd_chunk_dout
);
	reg _sv2v_0;
	parameter signed [31:0] SD_AW = 21;
	parameter [0:0] S_READ_CHUNK = 1'b0;
	input wire clk;
	input wire rst;
	input wire [SD_AW - 1:0] s_addr;
	input wire s_rd;
	output wire [15:0] s_dout;
	output wire s_ack;
	output wire [255:0] s_chunk_dout;
	input wire [SD_AW - 1:0] a_addr;
	input wire [15:0] a_din;
	input wire [1:0] a_be;
	input wire a_rd;
	input wire a_wr;
	output wire [15:0] a_dout;
	output wire a_ack;
	input wire [SD_AW - 1:0] b_addr;
	input wire [15:0] b_din;
	input wire [1:0] b_be;
	input wire b_rd;
	input wire b_wr;
	output wire [15:0] b_dout;
	output wire b_ack;
	input wire [SD_AW - 1:0] vd_addr;
	input wire [15:0] vd_din;
	input wire [1:0] vd_be;
	input wire vd_rd;
	input wire vd_wr;
	output wire [15:0] vd_dout;
	output wire vd_ack;
	input wire [2:0] vd_count;
	input wire [63:0] vd_words;
	input wire vd_reverse;
	input wire [SD_AW - 1:0] vc_addr;
	input wire [15:0] vc_din;
	input wire [1:0] vc_be;
	input wire vc_rd;
	input wire vc_wr;
	output wire [15:0] vc_dout;
	output wire vc_ack;
	input wire [SD_AW - 1:0] dl_addr;
	input wire [15:0] dl_din;
	input wire [1:0] dl_be;
	input wire dl_wr;
	output wire dl_ack;
	input wire wb_req;
	input wire [SD_AW - 1:0] wb_addr;
	input wire [6:0] wb_count;
	input wire [1023:0] wb_data;
	output wire wb_ack;
	input wire wb2_req;
	input wire [SD_AW - 1:0] wb2_addr;
	input wire [4:0] wb2_count;
	input wire [255:0] wb2_data;
	output wire wb2_ack;
	input wire rb_req;
	input wire [SD_AW - 1:0] rb_addr;
	input wire [4:0] rb_count;
	output wire [255:0] rb_dout;
	output wire rb_ack;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	output reg sd_write_chunk;
	output reg sd_write_reverse;
	output reg sd_read_chunk;
	output reg [6:0] sd_chunk_count;
	output reg [1023:0] sd_chunk_data;
	input wire [255:0] sd_chunk_dout;
	reg [3:0] grant;
	wire s_req = s_rd;
	wire a_req = a_rd | a_wr;
	wire b_req = b_rd | b_wr;
	wire vd_req = vd_rd | vd_wr;
	wire vc_req = vc_rd | vc_wr;
	wire dl_req = dl_wr;
	wire wb_request = wb_req === 1'b1;
	wire rb_request = rb_req === 1'b1;
	wire wb2_request = wb2_req === 1'b1;
	reg [3:0] nxt;
	always @(*) begin
		if (_sv2v_0)
			;
		nxt = 4'd0;
		if (dl_req)
			nxt = 4'd1;
		else if (s_req)
			nxt = 4'd2;
		else if (rb_request)
			nxt = 4'd3;
		else if (a_req)
			nxt = 4'd4;
		else if (b_req)
			nxt = 4'd5;
		else if (vd_req)
			nxt = 4'd6;
		else if (vc_req)
			nxt = 4'd7;
		else if (wb_request)
			nxt = 4'd8;
		else if (wb2_request)
			nxt = 4'd9;
	end
	always @(posedge clk)
		if (rst)
			grant <= 4'd0;
		else if (grant == 4'd0)
			grant <= nxt;
		else if (sd_ack)
			grant <= 4'd0;
	always @(*) begin
		if (_sv2v_0)
			;
		sd_addr = 1'sb0;
		sd_din = 1'sb0;
		sd_be = 2'b00;
		sd_rd = 1'b0;
		sd_wr = 1'b0;
		sd_write_reverse = 1'b0;
		sd_write_chunk = 1'b0;
		sd_read_chunk = 1'b0;
		sd_chunk_count = 0;
		sd_chunk_data = 0;
		(* full_case, parallel_case *)
		case (grant)
			4'd1: begin
				sd_addr = dl_addr;
				sd_din = dl_din;
				sd_be = dl_be;
				sd_wr = dl_wr;
			end
			4'd2: begin
				sd_addr = s_addr;
				sd_be = 2'b00;
				sd_rd = s_rd;
				if (S_READ_CHUNK) begin
					sd_read_chunk = 1'b1;
					sd_chunk_count = 5'd16;
				end
			end
			4'd3: begin
				sd_addr = rb_addr;
				sd_be = 2'b00;
				sd_rd = rb_request;
				sd_read_chunk = 1'b1;
				sd_chunk_count = rb_count;
			end
			4'd4: begin
				sd_addr = a_addr;
				sd_din = a_din;
				sd_be = a_be;
				sd_rd = a_rd;
				sd_wr = a_wr;
			end
			4'd5: begin
				sd_addr = b_addr;
				sd_din = b_din;
				sd_be = b_be;
				sd_rd = b_rd;
				sd_wr = b_wr;
			end
			4'd6: begin
				sd_addr = vd_addr;
				sd_din = vd_din;
				sd_be = vd_be;
				sd_rd = vd_rd;
				sd_wr = vd_wr;
				if ((vd_wr && (vd_be == 2'b11)) && (((vd_count === 3'd2) || (vd_count === 3'd3)) || (vd_count === 3'd4))) begin
					sd_write_chunk = 1'b1;
					sd_chunk_count = {4'd0, vd_count};
					sd_chunk_data = {960'd0, vd_words};
					sd_write_reverse = vd_reverse === 1'b1;
				end
			end
			4'd7: begin
				sd_addr = vc_addr;
				sd_din = vc_din;
				sd_be = vc_be;
				sd_rd = vc_rd;
				sd_wr = vc_wr;
			end
			4'd8: begin
				sd_addr = wb_addr;
				sd_din = wb_data[15:0];
				sd_be = 2'b11;
				sd_wr = wb_request;
				sd_write_chunk = 1'b1;
				sd_chunk_count = wb_count;
				sd_chunk_data = wb_data;
			end
			4'd9: begin
				sd_addr = wb2_addr;
				sd_din = wb2_data[15:0];
				sd_be = 2'b11;
				sd_wr = wb2_request;
				sd_write_chunk = 1'b1;
				sd_chunk_count = wb2_count;
				sd_chunk_data = wb2_data;
			end
			default:
				;
		endcase
	end
	assign s_dout = sd_dout;
	assign s_chunk_dout = sd_chunk_dout;
	assign a_dout = sd_dout;
	assign b_dout = sd_dout;
	assign vd_dout = sd_dout;
	assign vc_dout = sd_dout;
	assign rb_dout = sd_chunk_dout;
	assign s_ack = (grant == 4'd2) & sd_ack;
	assign a_ack = (grant == 4'd4) & sd_ack;
	assign b_ack = (grant == 4'd5) & sd_ack;
	assign vd_ack = (grant == 4'd6) & sd_ack;
	assign vc_ack = (grant == 4'd7) & sd_ack;
	assign dl_ack = (grant == 4'd1) & sd_ack;
	assign wb_ack = (grant == 4'd8) & sd_ack;
	assign wb2_ack = (grant == 4'd9) & sd_ack;
	assign rb_ack = (grant == 4'd3) & sd_ack;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module revx_sdram_phys (
	clk,
	s_addr,
	s_rd,
	s_dout,
	s_ack,
	s_chunk_dout,
	a_addr,
	a_din,
	a_be,
	a_rd,
	a_wr,
	a_dout,
	a_ack,
	vd_addr,
	vd_din,
	vd_be,
	vd_rd,
	vd_wr,
	vd_dout,
	vd_ack,
	vd_count,
	vd_words,
	vd_reverse,
	vc_addr,
	vc_din,
	vc_be,
	vc_rd,
	vc_wr,
	vc_dout,
	vc_ack,
	wb_req,
	wb_addr,
	wb_count,
	wb_data,
	wb_ack,
	wb2_req,
	wb2_addr,
	wb2_count,
	wb2_data,
	wb2_ack,
	rb_req,
	rb_addr,
	rb_count,
	rb_dout,
	rb_ack,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	ready,
	st_arm,
	st_done,
	st_t1_lo,
	st_t1_hi,
	st_t2_got,
	st_t3_got1,
	st_t3_got2,
	st_t4_refresh,
	st_status
);
	parameter signed [31:0] SD_AW = 21;
	parameter signed [31:0] PWRUP = 20000;
	parameter [0:0] SCAN_BURST = 1'b0;
	input wire clk;
	input wire [SD_AW - 1:0] s_addr;
	input wire s_rd;
	output wire [15:0] s_dout;
	output wire s_ack;
	output wire [255:0] s_chunk_dout;
	input wire [SD_AW - 1:0] a_addr;
	input wire [15:0] a_din;
	input wire [1:0] a_be;
	input wire a_rd;
	input wire a_wr;
	output wire [15:0] a_dout;
	output wire a_ack;
	input wire [SD_AW - 1:0] vd_addr;
	input wire [15:0] vd_din;
	input wire [1:0] vd_be;
	input wire vd_rd;
	input wire vd_wr;
	output wire [15:0] vd_dout;
	output wire vd_ack;
	input wire [2:0] vd_count;
	input wire [63:0] vd_words;
	input wire vd_reverse;
	input wire [SD_AW - 1:0] vc_addr;
	input wire [15:0] vc_din;
	input wire [1:0] vc_be;
	input wire vc_rd;
	input wire vc_wr;
	output wire [15:0] vc_dout;
	output wire vc_ack;
	input wire wb_req;
	input wire [SD_AW - 1:0] wb_addr;
	input wire [6:0] wb_count;
	input wire [1023:0] wb_data;
	output wire wb_ack;
	input wire wb2_req;
	input wire [SD_AW - 1:0] wb2_addr;
	input wire [4:0] wb2_count;
	input wire [255:0] wb2_data;
	output wire wb2_ack;
	input wire rb_req;
	input wire [SD_AW - 1:0] rb_addr;
	input wire [4:0] rb_count;
	output wire [255:0] rb_dout;
	output wire rb_ack;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output wire ready;
	input wire st_arm;
	output wire st_done;
	output wire [15:0] st_t1_lo;
	output wire [15:0] st_t1_hi;
	output wire [15:0] st_t2_got;
	output wire [15:0] st_t3_got1;
	output wire [15:0] st_t3_got2;
	output wire [15:0] st_t4_refresh;
	output wire [4:0] st_status;
	wire [SD_AW - 1:0] w_addr;
	wire [15:0] w_din;
	wire [15:0] w_dout;
	wire [1:0] w_be;
	wire w_rd;
	wire w_wr;
	wire w_ack;
	wire w_write_chunk;
	wire w_write_reverse;
	wire w_read_chunk;
	wire [6:0] w_chunk_count;
	wire [1023:0] w_chunk_data;
	wire [255:0] w_chunk_dout;
	reg [3:0] boot = 4'd0;
	always @(posedge clk)
		if (boot != 4'hf)
			boot <= boot + 4'd1;
	wire init_ph = boot == 4'd4;
	wire arb_rst = boot < 4'd6;
	revx_sdram_arb #(
		.SD_AW(SD_AW),
		.S_READ_CHUNK(SCAN_BURST)
	) u_arb(
		.clk(clk),
		.rst(arb_rst),
		.s_addr(s_addr),
		.s_rd(s_rd),
		.s_dout(s_dout),
		.s_ack(s_ack),
		.s_chunk_dout(s_chunk_dout),
		.a_addr(a_addr),
		.a_din(a_din),
		.a_be(a_be),
		.a_rd(a_rd),
		.a_wr(a_wr),
		.a_dout(a_dout),
		.a_ack(a_ack),
		.b_addr({SD_AW {1'b0}}),
		.b_din(16'd0),
		.b_be(2'd0),
		.b_rd(1'b0),
		.b_wr(1'b0),
		.b_dout(),
		.b_ack(),
		.vd_addr(vd_addr),
		.vd_din(vd_din),
		.vd_be(vd_be),
		.vd_rd(vd_rd),
		.vd_wr(vd_wr),
		.vd_dout(vd_dout),
		.vd_ack(vd_ack),
		.vd_count(vd_count),
		.vd_words(vd_words),
		.vd_reverse(vd_reverse),
		.vc_addr(vc_addr),
		.vc_din(vc_din),
		.vc_be(vc_be),
		.vc_rd(vc_rd),
		.vc_wr(vc_wr),
		.vc_dout(vc_dout),
		.vc_ack(vc_ack),
		.dl_addr({SD_AW {1'b0}}),
		.dl_din(16'd0),
		.dl_be(2'd0),
		.dl_wr(1'b0),
		.dl_ack(),
		.wb_req(wb_req),
		.wb_addr(wb_addr),
		.wb_count(wb_count),
		.wb_data(wb_data),
		.wb_ack(wb_ack),
		.wb2_req(wb2_req),
		.wb2_addr(wb2_addr),
		.wb2_count(wb2_count),
		.wb2_data(wb2_data),
		.wb2_ack(wb2_ack),
		.rb_req(rb_req),
		.rb_addr(rb_addr),
		.rb_count(rb_count),
		.rb_dout(rb_dout),
		.rb_ack(rb_ack),
		.sd_addr(w_addr),
		.sd_din(w_din),
		.sd_be(w_be),
		.sd_rd(w_rd),
		.sd_wr(w_wr),
		.sd_dout(w_dout),
		.sd_ack(w_ack),
		.sd_write_chunk(w_write_chunk),
		.sd_read_chunk(w_read_chunk),
		.sd_write_reverse(w_write_reverse),
		.sd_chunk_count(w_chunk_count),
		.sd_chunk_data(w_chunk_data),
		.sd_chunk_dout(w_chunk_dout)
	);
	wire [24:0] st_maddr;
	wire [15:0] st_mdin;
	wire [1:0] st_mbe;
	wire st_mrd;
	wire st_mwr;
	wire st_busy;
	wire st_m_dqm_early;
	wire [15:0] p_dout;
	wire p_ack;
	wire st_por = boot != 4'hf;
	revx_sdram_selftest u_selftest(
		.clk(clk),
		.rst(st_por),
		.arm(st_arm),
		.ready(ready),
		.m_addr(st_maddr),
		.m_din(st_mdin),
		.m_be(st_mbe),
		.m_rd(st_mrd),
		.m_wr(st_mwr),
		.m_dqm_early(st_m_dqm_early),
		.m_dout(p_dout),
		.m_ack((st_busy ? p_ack : 1'b0)),
		.busy(st_busy),
		.t1_lo(st_t1_lo),
		.t1_hi(st_t1_hi),
		.t2_got(st_t2_got),
		.t3_got1(st_t3_got1),
		.t3_got2(st_t3_got2),
		.t4_after_refresh(st_t4_refresh),
		.status(st_status),
		.done(st_done)
	);
	wire [24:0] p_addr = (st_busy ? st_maddr : {{25 - SD_AW {1'b0}}, w_addr});
	wire [15:0] p_din = (st_busy ? st_mdin : w_din);
	wire [1:0] p_be = (st_busy ? st_mbe : w_be);
	wire p_rd = (st_busy ? st_mrd : w_rd);
	wire p_wr = (st_busy ? st_mwr : w_wr);
	wire p_dqm_early = (st_busy ? st_m_dqm_early : 1'b0);
	assign w_dout = p_dout;
	assign w_ack = (st_busy ? 1'b0 : p_ack);
	sdram_phy #(
		.CLK_MHZ(80),
		.RASCAS(3),
		.CAS(2),
		.TRP(3),
		.TRFC(9),
		.REFRESH_IV(600),
		.PWRUP(PWRUP)
	) u_phy(
		.clk(clk),
		.init(init_ph),
		.addr(p_addr),
		.din(p_din),
		.be(p_be),
		.dqm_early(p_dqm_early),
		.rd(p_rd),
		.wr(p_wr),
		.dout(p_dout),
		.ack(p_ack),
		.ready(ready),
		.write_reverse(!st_busy && w_write_reverse),
		.write_chunk(!st_busy && w_write_chunk),
		.chunk_count(w_chunk_count),
		.chunk_data(w_chunk_data),
		.read_chunk(!st_busy && w_read_chunk),
		.chunk_dout(w_chunk_dout),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
endmodule
`default_nettype wire
`default_nettype none
module revx_dma_bus (
	clk,
	rst,
	reg_we,
	reg_addr,
	reg_wdata,
	reg_pair,
	reg_pair_rdata,
	dma_palette,
	irq,
	busy,
	overflow,
	diag_src_wait,
	diag_fb_wait,
	diag_blit_done,
	diag_q_highwater,
	mem_req,
	mem_we,
	mem_addr,
	mem_wdata,
	mem_be,
	mem_ack,
	mem_rdata,
	pixel_req,
	pixel_addr,
	pixel_data,
	pixel_count,
	pixel_words,
	pixel_reverse,
	pixel_ack
);
	parameter integer FB_GROUP_MAX = 1;
	input wire clk;
	input wire rst;
	input wire reg_we;
	input wire [3:0] reg_addr;
	input wire [15:0] reg_wdata;
	input wire [2:0] reg_pair;
	output wire [31:0] reg_pair_rdata;
	output wire [15:0] dma_palette;
	output wire irq;
	output wire busy;
	output wire overflow;
	output wire diag_src_wait;
	output wire diag_fb_wait;
	output wire diag_blit_done;
	output wire [8:0] diag_q_highwater;
	output wire mem_req;
	output wire mem_we;
	output wire [31:0] mem_addr;
	output wire [31:0] mem_wdata;
	output wire [3:0] mem_be;
	input wire mem_ack;
	input wire [31:0] mem_rdata;
	output wire pixel_req;
	output wire [18:0] pixel_addr;
	output wire [15:0] pixel_data;
	output wire [2:0] pixel_count;
	output wire [63:0] pixel_words;
	output wire pixel_reverse;
	input wire pixel_ack;
	wire src_req;
	wire src_ack;
	wire fb_we;
	wire fb_ack;
	wire [31:0] src_addr;
	wire [7:0] src_data;
	wire [18:0] fb_addr;
	wire [15:0] fb_data;
	wire [2:0] fb_count;
	wire [63:0] fb_words;
	wire fb_reverse;
	assign diag_src_wait = src_req && !src_ack;
	assign diag_fb_wait = fb_we && !fb_ack;
	wolf_dma #(.FB_GROUP_MAX(FB_GROUP_MAX)) u_dma(
		.clk(clk),
		.rst(rst),
		.reg_we(reg_we),
		.reg_addr(reg_addr),
		.reg_wdata(reg_wdata),
		.reg_rdata(),
		.reg_pair_addr(reg_pair),
		.reg_pair_rdata(reg_pair_rdata),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_active(),
		.src_stream(),
		.src_data(src_data),
		.src_ack(src_ack),
		.fb_we(fb_we),
		.fb_addr(fb_addr),
		.fb_wdata(fb_data),
		.fb_ack(fb_ack),
		.fb_count(fb_count),
		.fb_words(fb_words),
		.fb_reverse(fb_reverse),
		.wr_busy(1'b0),
		.busy(busy),
		.blit_irq(irq),
		.dma_palette(dma_palette),
		.dbg_q_overflow(overflow),
		.dbg_q_highwater(diag_q_highwater),
		.dbg_exec_done(diag_blit_done)
	);
	revx_dma_word_bridge u_bus(
		.clk(clk),
		.rst(rst),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.fb_we(fb_we),
		.fb_addr(fb_addr),
		.fb_data(fb_data),
		.fb_ack(fb_ack),
		.fb_count(fb_count),
		.fb_words(fb_words),
		.fb_reverse(fb_reverse),
		.mem_req(mem_req),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_wdata(mem_wdata),
		.mem_be(mem_be),
		.mem_ack(mem_ack),
		.mem_rdata(mem_rdata),
		.pixel_req(pixel_req),
		.pixel_addr(pixel_addr),
		.pixel_data(pixel_data),
		.pixel_ack(pixel_ack),
		.pixel_count(pixel_count),
		.pixel_words(pixel_words),
		.pixel_reverse(pixel_reverse)
	);
endmodule
module revx_dma_word_bridge (
	clk,
	rst,
	src_req,
	src_addr,
	src_data,
	src_ack,
	fb_we,
	fb_addr,
	fb_data,
	fb_count,
	fb_words,
	fb_reverse,
	fb_ack,
	mem_req,
	mem_we,
	mem_addr,
	mem_wdata,
	mem_be,
	mem_ack,
	mem_rdata,
	pixel_req,
	pixel_addr,
	pixel_data,
	pixel_count,
	pixel_words,
	pixel_reverse,
	pixel_ack
);
	input wire clk;
	input wire rst;
	input wire src_req;
	input wire [31:0] src_addr;
	output reg [7:0] src_data;
	output reg src_ack;
	input wire fb_we;
	input wire [18:0] fb_addr;
	input wire [15:0] fb_data;
	input wire [2:0] fb_count;
	input wire [63:0] fb_words;
	input wire fb_reverse;
	output reg fb_ack;
	output reg mem_req;
	output wire mem_we;
	output reg [31:0] mem_addr;
	output wire [31:0] mem_wdata;
	output wire [3:0] mem_be;
	input wire mem_ack;
	input wire [31:0] mem_rdata;
	output reg pixel_req;
	output reg [18:0] pixel_addr;
	output reg [15:0] pixel_data;
	output reg [2:0] pixel_count;
	output reg [63:0] pixel_words;
	output reg pixel_reverse;
	input wire pixel_ack;
	wire fb_group = ((fb_count === 3'd2) || (fb_count === 3'd3)) || (fb_count === 3'd4);
	reg [1:0] state;
	reg [1:0] write_state;
	reg [1:0] byte_l;
	reg cache_valid;
	reg [21:0] cache_tag;
	reg [31:0] cache_word;
	wire [31:0] mapped_src_addr = 32'hf8000000 + {7'd0, src_addr[23:2], 5'd0};
	wire cache_hit = ((cache_valid && (cache_tag == src_addr[23:2])) && (mapped_src_addr[31:24] >= 8'hf8)) && (mapped_src_addr[31:24] <= 8'hfe);
	assign mem_we = 1'b0;
	assign mem_wdata = 32'd0;
	assign mem_be = 4'hf;
	function automatic [7:0] sv2v_cast_8;
		input reg [7:0] inp;
		sv2v_cast_8 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			state <= 2'd0;
			write_state <= 2'd0;
			mem_req <= 0;
			mem_addr <= 0;
			byte_l <= 0;
			pixel_req <= 0;
			pixel_addr <= 0;
			pixel_data <= 0;
			pixel_count <= 1;
			pixel_words <= 0;
			pixel_reverse <= 0;
			src_ack <= 0;
			fb_ack <= 0;
			src_data <= 0;
			cache_valid <= 0;
			cache_tag <= 0;
			cache_word <= 0;
		end
		else begin
			src_ack <= 0;
			fb_ack <= 0;
			case (state)
				2'd0:
					if (src_req) begin
						byte_l <= src_addr[1:0];
						if (cache_hit) begin
							src_data <= sv2v_cast_8(cache_word >> {src_addr[1:0], 3'b000});
							state <= 2'd2;
						end
						else begin
							mem_addr <= mapped_src_addr;
							mem_req <= 1;
							state <= 2'd1;
						end
					end
				2'd1:
					if (mem_ack) begin
						if ((mem_addr[31:24] >= 8'hf8) && (mem_addr[31:24] <= 8'hfe)) begin
							cache_valid <= 1;
							cache_tag <= mem_addr[26:5];
							cache_word <= mem_rdata;
						end
						mem_req <= 0;
						src_data <= sv2v_cast_8(mem_rdata >> {byte_l, 3'b000});
						state <= 2'd2;
					end
				2'd2: begin
					src_ack <= 1;
					state <= 2'd3;
				end
				2'd3: state <= 2'd0;
				default: state <= 2'd0;
			endcase
			case (write_state)
				2'd0:
					if (fb_we) begin
						pixel_req <= 1;
						pixel_addr <= fb_addr;
						pixel_data <= fb_data;
						pixel_count <= (fb_group ? fb_count : 3'd1);
						pixel_words <= (fb_group ? fb_words : {48'd0, fb_data});
						pixel_reverse <= fb_group && (fb_reverse === 1'b1);
						write_state <= 2'd1;
					end
				2'd1:
					if (pixel_ack) begin
						pixel_req <= 0;
						write_state <= 2'd2;
					end
				2'd2: begin
					fb_ack <= 1;
					write_state <= 2'd3;
				end
				2'd3: write_state <= 2'd0;
				default: write_state <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module revx_palram (
	clk,
	we_a,
	addr_a,
	wd_a,
	rd_a,
	addr_b,
	rd_b
);
	parameter signed [31:0] DW = 16;
	parameter signed [31:0] AW = 15;
	parameter [0:0] USE_FWD = 1'b1;
	input wire clk;
	input wire we_a;
	input wire [AW - 1:0] addr_a;
	input wire [DW - 1:0] wd_a;
	output reg [DW - 1:0] rd_a;
	input wire [AW - 1:0] addr_b;
	output wire [DW - 1:0] rd_b;
	localparam signed [31:0] DEPTH = 1 << AW;
	(* ramstyle = "no_rw_check, M10K" *) reg [DW - 1:0] mem [0:DEPTH - 1];
	reg we_a_q;
	reg [AW - 1:0] addr_a_q;
	reg [DW - 1:0] wd_a_q;
	always @(posedge clk) begin
		we_a_q <= we_a;
		addr_a_q <= addr_a;
		wd_a_q <= wd_a;
	end
	always @(posedge clk)
		if (we_a_q)
			mem[addr_a_q] <= wd_a_q;
		else
			rd_a <= mem[addr_a];
	reg [DW - 1:0] rd_b_mem;
	reg fwd_hit_q;
	reg [DW - 1:0] fwd_data_q;
	always @(posedge clk) begin
		rd_b_mem <= mem[addr_b];
		fwd_hit_q <= (USE_FWD && we_a_q) && (addr_a_q == addr_b);
		fwd_data_q <= wd_a_q;
	end
	assign rd_b = (fwd_hit_q ? fwd_data_q : rd_b_mem);
endmodule
`default_nettype wire
`default_nettype none
module revx_vram_view (
	clk,
	rst,
	req,
	we,
	raw_mode,
	color_mode,
	srt_mode,
	addr,
	wdata,
	be,
	palette,
	dma_snoop_we,
	dma_snoop_addr,
	rdata,
	done,
	active,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack,
	wb_req,
	wb_addr,
	wb_count,
	wb_data,
	wb_ack,
	vlb_rb_req,
	vlb_rb_addr,
	vlb_rb_count,
	vlb_rb_dout,
	vlb_rb_ack
);
	reg _sv2v_0;
	parameter signed [31:0] SD_AW = 19;
	parameter [0:0] SRT_WRITE_CHUNKS = 1'b0;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	input wire raw_mode;
	input wire color_mode;
	input wire srt_mode;
	input wire [31:0] addr;
	input wire [31:0] wdata;
	input wire [3:0] be;
	input wire [15:0] palette;
	input wire dma_snoop_we;
	input wire [18:0] dma_snoop_addr;
	output reg [31:0] rdata;
	output reg done;
	output wire active;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	output reg wb_req;
	output reg [SD_AW - 1:0] wb_addr;
	output reg [6:0] wb_count;
	output reg [1023:0] wb_data;
	input wire wb_ack;
	output wire vlb_rb_req;
	output wire [SD_AW - 1:0] vlb_rb_addr;
	output wire [4:0] vlb_rb_count;
	input wire [255:0] vlb_rb_dout;
	input wire vlb_rb_ack;
	reg [3:0] state;
	reg we_q;
	reg raw_q;
	reg color_q;
	reg srt_q;
	reg [18:0] base_q;
	reg [31:0] data_q;
	reg [15:0] palette_q;
	reg [3:0] be_q;
	reg [1:0] lane_q;
	(* ramstyle = "no_rw_check, M10K" *) reg [15:0] srt_buf [0:1023];
	reg [9:0] srt_idx;
	reg [15:0] srt_data_q;
	wire [18:0] srt_pixel = base_q + {9'd0, srt_idx};
	localparam signed [31:0] SRT_LENGTH = 1024;
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	wire srt_last = srt_idx == sv2v_cast_10_signed(1023);
	reg [9:0] chunk_read_idx;
	reg [6:0] chunk_gather_idx;
	wire [9:0] srt_read_idx = (SRT_WRITE_CHUNKS ? chunk_read_idx : srt_idx);
	function automatic signed [10:0] sv2v_cast_11_signed;
		input reg signed [10:0] inp;
		sv2v_cast_11_signed = inp;
	endfunction
	function automatic [6:0] length_at;
		input reg [10:0] index;
		reg [8:0] column;
		reg [10:0] remain;
		reg [5:0] row_words;
		reg row_short;
		reg tail_short;
		begin
			column = base_q[8:0] + index[8:0];
			remain = sv2v_cast_11_signed(SRT_LENGTH) - index;
			row_words = 6'd0 - column[5:0];
			row_short = &column[8:6] && |column[5:0];
			tail_short = remain[10:6] == 5'd0;
			if (row_short && (!tail_short || (row_words < remain[5:0])))
				length_at = {1'b0, row_words};
			else if (tail_short)
				length_at = {1'b0, remain[5:0]};
			else
				length_at = 7'd64;
		end
	endfunction
	wire [6:0] chunk_length = length_at({1'b0, srt_idx});
	wire [5:0] second_row_words = 6'd0 - base_q[5:0];
	wire [6:0] second_chunk_length = ((base_q[8:6] == 3'd6) && |base_q[5:0] ? {1'b0, second_row_words} : 7'd64);
	wire [10:0] chunk_next = {1'b0, srt_idx} + {4'd0, wb_count};
	reg [1023:0] next_data;
	reg [1023:0] prefix_data;
	reg [10:0] next_start;
	reg [6:0] next_count;
	reg [6:0] next_gather;
	reg [1:0] next_phase;
	reg next_valid;
	reg prefix_valid;
	reg srt_rb_req;
	reg [SD_AW - 1:0] srt_rb_addr;
	reg [4:0] srt_rb_count;
	reg [4:0] srt_rb_drain;
	reg [255:0] srt_rb_data;
	reg srt_rb_draining;
	localparam [0:0] SRT_READ_BURSTS = 1;
	wire srt_rb_ack = vlb_rb_ack;
	wire [255:0] srt_rb_payload = vlb_rb_dout;
	wire [15:0] srt_in_word = (srt_rb_draining ? srt_rb_data[15:0] : sd_dout);
	wire srt_store = ((state == 4'd7) && !we_q) && (srt_rb_draining || (!SRT_READ_BURSTS && sd_ack));
	always @(posedge clk) begin
		if (srt_store)
			srt_buf[srt_idx] <= srt_in_word;
		srt_data_q <= srt_buf[srt_read_idx];
	end
	task automatic start_next;
		input reg [10:0] index;
		input reg [6:0] count;
		begin
			next_start <= index;
			next_count <= count;
			next_gather <= 0;
			chunk_read_idx <= index[9:0];
			next_phase <= 1;
			next_valid <= 0;
		end
	endtask
	wire [1:0] pixel_lane = base_q[1:0] + lane_q;
	wire [18:0] pixel = {base_q[18:2], pixel_lane};
	wire last_lane = (raw_q ? lane_q == 2'd1 : lane_q == 2'd3);
	wire [1:0] raw_be = (lane_q[0] ? be_q[3:2] : be_q[1:0]);
	wire [7:0] cpu_byte = data_q[8 * lane_q+:8];
	wire [7:0] color_byte = (pixel[0] ? palette_q[15:8] : palette_q[7:0]);
	assign active = state != 4'd0;
	localparam signed [31:0] VLB_SET_BITS = 7;
	(* ramstyle = "no_rw_check, M10K" *) reg [15:0] vlb_mem [0:4095];
	reg vlb_valid [0:1][0:127];
	reg [7:0] vlb_tag [0:1][0:127];
	reg [127:0] vlb_lru;
	wire [6:0] vlb_set = pixel[10:4];
	wire [7:0] vlb_ntag = pixel[18:11];
	wire vlb_hit0 = vlb_valid[0][vlb_set] && (vlb_tag[0][vlb_set] == vlb_ntag);
	wire vlb_hit1 = vlb_valid[1][vlb_set] && (vlb_tag[1][vlb_set] == vlb_ntag);
	wire vlb_hit = vlb_hit0 || vlb_hit1;
	wire [11:0] vlb_ridx = {vlb_hit1, vlb_set, pixel[3:0]};
	reg [15:0] vlb_word_q;
	always @(posedge clk) vlb_word_q <= vlb_mem[vlb_ridx];
	reg vlb_fill_req;
	reg vlb_fill_way;
	reg [6:0] vlb_fill_set;
	reg [18:0] vlb_fill_line;
	reg vlb_draining;
	reg vlb_fill_dirty;
	reg [3:0] vlb_drain_k;
	reg [255:0] vlb_fill_data;
	wire [11:0] vlb_waddr = {vlb_fill_way, vlb_fill_set, vlb_drain_k};
	function automatic [SD_AW - 1:0] sv2v_cast_9C70E;
		input reg [SD_AW - 1:0] inp;
		sv2v_cast_9C70E = inp;
	endfunction
	wire [SD_AW - 1:0] vlb_fill_addr = sv2v_cast_9C70E(vlb_fill_line);
	wire vlb_victim = (!vlb_valid[0][vlb_set] ? 1'b0 : (!vlb_valid[1][vlb_set] ? 1'b1 : ~vlb_lru[vlb_set]));
	wire [18:0] write_pixel = (state == 4'd6 ? srt_pixel : pixel);
	wire [6:0] write_set = write_pixel[10:4];
	wire [6:0] wb_start_set = wb_addr[10:4];
	wire [10:0] wb_end_addr = (wb_addr[10:0] + {{4 {1'b0}}, wb_count}) - 1'b1;
	wire [6:0] wb_end_set = wb_end_addr[10:4];
	wire dma_snoop = dma_snoop_we === 1'b1;
	wire [6:0] dma_snoop_set = dma_snoop_addr[10:4];
	assign vlb_rb_req = vlb_fill_req || srt_rb_req;
	assign vlb_rb_addr = (srt_rb_req ? srt_rb_addr : vlb_fill_addr);
	assign vlb_rb_count = (srt_rb_req ? srt_rb_count : 5'd16);
	function automatic [6:0] sv2v_cast_7;
		input reg [6:0] inp;
		sv2v_cast_7 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			begin : sv2v_autoblock_1
				reg signed [31:0] w;
				for (w = 0; w < 2; w = w + 1)
					begin : sv2v_autoblock_2
						reg signed [31:0] s;
						for (s = 0; s < 128; s = s + 1)
							vlb_valid[w][s] <= 1'b0;
					end
			end
			vlb_lru <= 1'sb0;
			vlb_fill_req <= 1'b0;
			vlb_draining <= 1'b0;
			vlb_drain_k <= 4'd0;
			vlb_fill_way <= 0;
			vlb_fill_set <= 1'sb0;
			vlb_fill_line <= 1'sb0;
			vlb_fill_dirty <= 1'b0;
		end
		else begin
			if ((((state == 4'd1) && we_q) && (raw_q ? |raw_be : be_q[lane_q])) || ((state == 4'd6) && we_q)) begin
				vlb_valid[0][write_set] <= 1'b0;
				vlb_valid[1][write_set] <= 1'b0;
			end
			if ((state == 4'd11) && wb_ack) begin : sv2v_autoblock_3
				integer k;
				for (k = 0; k < 5; k = k + 1)
					if (k <= ((({7'd0, wb_addr[3:0]} + {4'd0, wb_count}) - 1) >> 4)) begin
						vlb_valid[0][sv2v_cast_7(wb_start_set + k)] <= 0;
						vlb_valid[1][sv2v_cast_7(wb_start_set + k)] <= 0;
					end
			end
			if (vlb_fill_req && vlb_rb_ack) begin
				vlb_fill_req <= 1'b0;
				vlb_draining <= 1'b1;
				vlb_drain_k <= 4'd0;
				vlb_fill_data <= vlb_rb_dout;
			end
			else if (vlb_draining) begin
				vlb_mem[vlb_waddr] <= vlb_fill_data[15:0];
				vlb_fill_data <= {16'd0, vlb_fill_data[255:16]};
				if (vlb_drain_k == 4'd15) begin
					vlb_tag[vlb_fill_way][vlb_fill_set] <= vlb_fill_line[18:11];
					vlb_valid[vlb_fill_way][vlb_fill_set] <= !vlb_fill_dirty;
					vlb_lru[vlb_fill_set] <= vlb_fill_way;
					vlb_draining <= 1'b0;
				end
				else
					vlb_drain_k <= vlb_drain_k + 1'b1;
			end
			if (state == 4'd13)
				vlb_lru[vlb_set] <= vlb_hit1;
			if ((((((state == 4'd1) && !we_q) && !srt_q) && !vlb_hit) && !vlb_fill_req) && !vlb_draining) begin
				vlb_fill_req <= 1'b1;
				vlb_fill_set <= vlb_set;
				vlb_fill_line <= {pixel[18:4], 4'd0};
				vlb_fill_way <= vlb_victim;
				vlb_fill_dirty <= 1'b0;
			end
			if (vlb_fill_req)
				vlb_valid[vlb_fill_way][vlb_fill_set] <= 1'b0;
			if (dma_snoop) begin
				vlb_valid[0][dma_snoop_set] <= 1'b0;
				vlb_valid[1][dma_snoop_set] <= 1'b0;
				if ((vlb_fill_req || vlb_draining) && (dma_snoop_set == vlb_fill_set))
					vlb_fill_dirty <= 1'b1;
			end
		end
	function automatic [4:0] sv2v_cast_5;
		input reg [4:0] inp;
		sv2v_cast_5 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			state <= 4'd0;
			done <= 0;
			rdata <= 0;
			sd_rd <= 0;
			sd_wr <= 0;
			sd_addr <= 0;
			sd_din <= 0;
			sd_be <= 0;
			we_q <= 0;
			raw_q <= 0;
			color_q <= 0;
			srt_q <= 0;
			base_q <= 0;
			srt_idx <= 0;
			chunk_read_idx <= 0;
			chunk_gather_idx <= 0;
			next_data <= 0;
			prefix_data <= 0;
			next_start <= 0;
			next_count <= 0;
			next_gather <= 0;
			next_phase <= 0;
			next_valid <= 0;
			prefix_valid <= 0;
			srt_rb_req <= 0;
			srt_rb_addr <= 0;
			srt_rb_count <= 0;
			srt_rb_drain <= 0;
			srt_rb_data <= 0;
			srt_rb_draining <= 0;
			wb_req <= 0;
			wb_addr <= 0;
			wb_count <= 0;
			wb_data <= 0;
			data_q <= 0;
			palette_q <= 0;
			be_q <= 0;
			lane_q <= 0;
		end
		else begin
			done <= 0;
			if (srt_store && (srt_idx < 64))
				prefix_data[16 * srt_idx[5:0]+:16] <= srt_in_word;
			if (next_phase == 1) begin
				chunk_read_idx <= next_start[9:0] + 1'b1;
				next_phase <= 2;
			end
			else if (next_phase == 2) begin
				next_data[16 * next_gather[5:0]+:16] <= srt_data_q;
				if ((next_gather + 1'b1) == next_count) begin
					next_valid <= 1;
					next_phase <= 0;
				end
				else begin
					next_gather <= next_gather + 1'b1;
					chunk_read_idx <= chunk_read_idx + 1'b1;
				end
			end
			case (state)
				4'd0:
					if (req && !done) begin
						we_q <= we;
						raw_q <= raw_mode;
						color_q <= color_mode;
						base_q <= (raw_mode ? {addr[22:5], 1'b0} : {addr[21:5], 2'b00});
						data_q <= wdata;
						palette_q <= palette;
						be_q <= be;
						lane_q <= 0;
						rdata <= 0;
						state <= 4'd1;
						srt_q <= 1'b0;
						if (srt_mode === 1'b1) begin
							srt_q <= 1'b1;
							srt_idx <= 0;
							state <= 4'd5;
							next_phase <= 0;
							next_valid <= 0;
							if (!we)
								prefix_valid <= 0;
							base_q <= addr[21:3];
						end
					end
				4'd1:
					if (we_q && !(raw_q ? |raw_be : be_q[lane_q])) begin
						if (last_lane)
							state <= 4'd4;
						else
							lane_q <= lane_q + 1'b1;
					end
					else begin
						sd_addr <= sv2v_cast_9C70E(pixel);
						if (raw_q) begin
							sd_din <= (lane_q[0] ? data_q[31:16] : data_q[15:0]);
							sd_be <= raw_be;
						end
						else if (color_q) begin
							sd_din <= {cpu_byte, 8'd0};
							sd_be <= 2'b10;
						end
						else begin
							sd_din <= {color_byte, cpu_byte};
							sd_be <= 2'b11;
						end
						if (!we_q && !srt_q)
							state <= (vlb_hit ? 4'd13 : 4'd14);
						else begin
							sd_rd <= !we_q;
							sd_wr <= we_q;
							state <= 4'd2;
						end
					end
				4'd14:
					if ((!vlb_fill_req && !vlb_draining) && !vlb_rb_ack)
						state <= 4'd1;
				4'd13: begin
					if (raw_q)
						rdata[16 * lane_q[0]+:16] <= vlb_word_q;
					else
						rdata[8 * lane_q+:8] <= (color_q ? vlb_word_q[15:8] : vlb_word_q[7:0]);
					if (last_lane)
						state <= 4'd4;
					else begin
						lane_q <= lane_q + 1'b1;
						state <= 4'd3;
					end
				end
				4'd2:
					if (sd_ack) begin
						sd_rd <= 0;
						sd_wr <= 0;
						if (!we_q) begin
							if (raw_q)
								rdata[16 * lane_q[0]+:16] <= sd_dout;
							else
								rdata[8 * lane_q+:8] <= (color_q ? sd_dout[15:8] : sd_dout[7:0]);
						end
						if (last_lane)
							state <= 4'd4;
						else begin
							lane_q <= lane_q + 1'b1;
							state <= 4'd3;
						end
					end
				4'd3:
					if (!sd_ack)
						state <= (srt_q ? 4'd5 : 4'd1);
				4'd5:
					if (SRT_WRITE_CHUNKS && we_q)
						state <= 4'd8;
					else if (SRT_READ_BURSTS && !we_q) begin
						srt_rb_addr <= sv2v_cast_9C70E(srt_pixel);
						srt_rb_count <= (length_at({1'b0, srt_idx}) < 16 ? sv2v_cast_5(length_at({1'b0, srt_idx})) : 5'd16);
						srt_rb_req <= 1;
						srt_rb_draining <= 0;
						state <= 4'd7;
					end
					else
						state <= 4'd6;
				4'd6: begin
					sd_addr <= sv2v_cast_9C70E(srt_pixel);
					sd_din <= srt_data_q;
					sd_be <= 2'b11;
					sd_rd <= !we_q;
					sd_wr <= we_q;
					state <= 4'd7;
				end
				4'd7:
					if (SRT_READ_BURSTS && !we_q) begin
						if (srt_rb_req && srt_rb_ack) begin
							srt_rb_data <= srt_rb_payload;
							srt_rb_req <= 0;
							srt_rb_draining <= 1;
							srt_rb_drain <= 0;
						end
						else if (srt_rb_draining) begin
							if (srt_idx == 0)
								rdata <= {16'd0, srt_in_word};
							srt_rb_data <= {16'd0, srt_rb_data[255:16]};
							if (srt_last) begin
								srt_rb_draining <= 0;
								prefix_valid <= 1;
								state <= 4'd4;
							end
							else begin
								srt_idx <= srt_idx + 1'b1;
								srt_rb_drain <= srt_rb_drain + 1'b1;
								if ((srt_rb_drain + 1'b1) == srt_rb_count) begin
									srt_rb_draining <= 0;
									state <= 4'd3;
								end
							end
						end
					end
					else if (sd_ack) begin
						sd_rd <= 0;
						sd_wr <= 0;
						if (!we_q && (srt_idx == 0))
							rdata <= {16'd0, sd_dout};
						if (srt_last) begin
							prefix_valid <= !we_q;
							state <= 4'd4;
						end
						else begin
							srt_idx <= srt_idx + 1'b1;
							state <= 4'd3;
						end
					end
				4'd8: begin
					wb_addr <= sv2v_cast_9C70E(srt_pixel);
					wb_count <= chunk_length;
					if ((srt_idx == 0) && prefix_valid) begin
						wb_data <= prefix_data;
						wb_req <= 1;
						state <= 4'd11;
						if (chunk_length < SRT_LENGTH)
							start_next({4'd0, chunk_length}, second_chunk_length);
					end
					else begin
						chunk_read_idx <= srt_idx;
						chunk_gather_idx <= 0;
						state <= 4'd9;
					end
				end
				4'd9: begin
					chunk_read_idx <= srt_idx + 1'b1;
					state <= 4'd10;
				end
				4'd10: begin
					wb_data[16 * chunk_gather_idx[5:0]+:16] <= srt_data_q;
					if ((chunk_gather_idx + 1'b1) == wb_count) begin
						wb_req <= 1;
						state <= 4'd11;
						if (chunk_next < SRT_LENGTH)
							start_next(chunk_next, length_at(chunk_next));
					end
					else begin
						chunk_gather_idx <= chunk_gather_idx + 1'b1;
						chunk_read_idx <= chunk_read_idx + 1'b1;
					end
				end
				4'd11:
					if (wb_ack) begin
						wb_req <= 0;
						if (chunk_next == SRT_LENGTH)
							state <= 4'd4;
						else begin
							srt_idx <= chunk_next[9:0];
							state <= 4'd12;
						end
					end
				4'd12:
					if (!wb_ack && next_valid) begin
						wb_addr <= sv2v_cast_9C70E(base_q + next_start);
						wb_count <= next_count;
						wb_data <= next_data;
						wb_req <= 1;
						state <= 4'd11;
						next_valid <= 0;
						if ((next_start + next_count) < SRT_LENGTH)
							start_next(next_start + next_count, length_at(next_start + next_count));
					end
				4'd4: begin
					done <= 1;
					state <= 4'd0;
				end
				default: state <= 4'd0;
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module revx_backends (
	clk,
	rst,
	rst_pon,
	mem_req,
	mem_we,
	mem_addr,
	mem_be,
	mem_wdata,
	mem_raw_vram,
	mem_srt,
	mem_fetch,
	dma_palette,
	dma_vram_snoop_we,
	dma_vram_snoop_addr,
	mem_rdata,
	mem_ack,
	bulk_ram_wr,
	bulk_ram_addr,
	dl_wr,
	dl_addr,
	dl_din,
	dl_be,
	dl_ack,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack,
	vd_addr,
	vd_din,
	vd_be,
	vd_rd,
	vd_wr,
	vd_dout,
	vd_ack,
	wb_req,
	wb_addr,
	wb_count,
	wb_data,
	wb_ack,
	vlb_rb_req,
	vlb_rb_addr,
	vlb_rb_count,
	vlb_rb_dout,
	vlb_rb_ack,
	rb_req,
	rb_addr,
	rb_count,
	rb_dout,
	rb_ack,
	vc_addr,
	vc_din,
	vc_be,
	vc_rd,
	vc_wr,
	vc_dout,
	vc_ack,
	gfx_ddram_addr,
	gfx_ddram_burstcnt,
	gfx_ddram_rd,
	gfx_ddram_we,
	gfx_ddram_din,
	gfx_ddram_be,
	gfx_ddram_busy,
	gfx_ddram_dout,
	gfx_ddram_dout_ready,
	gfx_dl_wr,
	gfx_dl_addr,
	gfx_dl_data,
	gfx_dl_ack,
	gfx_dl_idle,
	ioctl_download,
	ioctl_upload,
	ioctl_wr,
	ioctl_index,
	ioctl_addr,
	ioctl_dout,
	ioctl_din,
	ioctl_upload_req,
	manual_save,
	clear_nvram
);
	reg _sv2v_0;
	parameter signed [31:0] SD_AW = 21;
	parameter signed [31:0] VSD_AW = 19;
	parameter [0:0] SRT_WRITE_CHUNKS = 1'b0;
	parameter [SD_AW - 1:0] RAM_SDBASE = 21'h000000;
	parameter [SD_AW - 1:0] ROM_SDBASE = 21'h100000;
	input wire clk;
	input wire rst;
	input wire rst_pon;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [3:0] mem_be;
	input wire [31:0] mem_wdata;
	input wire mem_raw_vram;
	input wire mem_srt;
	input wire mem_fetch;
	input wire [15:0] dma_palette;
	input wire dma_vram_snoop_we;
	input wire [18:0] dma_vram_snoop_addr;
	output wire [31:0] mem_rdata;
	output reg mem_ack;
	input wire bulk_ram_wr;
	input wire [31:0] bulk_ram_addr;
	input wire dl_wr;
	input wire [SD_AW - 1:0] dl_addr;
	input wire [15:0] dl_din;
	input wire [1:0] dl_be;
	output wire dl_ack;
	output wire [SD_AW - 1:0] sd_addr;
	output wire [15:0] sd_din;
	output wire [1:0] sd_be;
	output wire sd_rd;
	output wire sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	output wire [VSD_AW - 1:0] vd_addr;
	output wire [15:0] vd_din;
	output wire [1:0] vd_be;
	output wire vd_rd;
	output wire vd_wr;
	input wire [15:0] vd_dout;
	input wire vd_ack;
	output wire wb_req;
	output wire [VSD_AW - 1:0] wb_addr;
	output wire [6:0] wb_count;
	output wire [1023:0] wb_data;
	input wire wb_ack;
	output wire vlb_rb_req;
	output wire [VSD_AW - 1:0] vlb_rb_addr;
	output wire [4:0] vlb_rb_count;
	input wire [255:0] vlb_rb_dout;
	input wire vlb_rb_ack;
	output reg rb_req;
	output reg [SD_AW - 1:0] rb_addr;
	output reg [4:0] rb_count;
	input wire [255:0] rb_dout;
	input wire rb_ack;
	output wire [VSD_AW - 1:0] vc_addr;
	output wire [15:0] vc_din;
	output wire [1:0] vc_be;
	output wire vc_rd;
	output wire vc_wr;
	input wire [15:0] vc_dout;
	input wire vc_ack;
	output wire [28:0] gfx_ddram_addr;
	output wire [7:0] gfx_ddram_burstcnt;
	output wire gfx_ddram_rd;
	output wire gfx_ddram_we;
	output wire [63:0] gfx_ddram_din;
	output wire [7:0] gfx_ddram_be;
	input wire gfx_ddram_busy;
	input wire [63:0] gfx_ddram_dout;
	input wire gfx_ddram_dout_ready;
	input wire gfx_dl_wr;
	input wire [24:0] gfx_dl_addr;
	input wire [7:0] gfx_dl_data;
	output wire gfx_dl_ack;
	output wire gfx_dl_idle;
	input wire ioctl_download;
	input wire ioctl_upload;
	input wire ioctl_wr;
	input wire [7:0] ioctl_index;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output wire [7:0] ioctl_din;
	output wire ioctl_upload_req;
	input wire manual_save;
	input wire clear_nvram;
	localparam [2:0] R_NONE = 0;
	localparam [2:0] R_VRAMD = 1;
	localparam [2:0] R_VRAMC = 2;
	localparam [2:0] R_RAM = 3;
	localparam [2:0] R_CMOS = 4;
	localparam [2:0] R_GFX = 5;
	localparam [2:0] R_ROM = 6;
	reg [2:0] region;
	reg [31:0] q_addr;
	reg q_raw_vram;
	always @(*) begin
		if (_sv2v_0)
			;
		region = R_NONE;
		if (q_raw_vram && (q_addr[31:23] == 9'd0))
			region = R_VRAMD;
		else if (q_addr[31:22] == 10'd0)
			region = R_VRAMD;
		else if (q_addr[31:22] == 10'd2)
			region = R_VRAMC;
		else if (q_addr[31:24] == 8'h20)
			region = R_RAM;
		else if (q_addr[31:18] == (32'ha0440000 >> 18))
			region = R_CMOS;
		else if ((q_addr[31:24] >= 8'hf8) && (q_addr[31:24] <= 8'hfe))
			region = R_GFX;
		else if (q_addr[31:24] == 8'hff)
			region = R_ROM;
	end
	reg q_we;
	reg [31:0] q_wdata;
	reg [3:0] q_be;
	reg q_srt;
	reg q_fetch;
	reg [15:0] q_dma_palette;
	wire [12:0] cmos_idx = q_addr[17:5];
	wire [26:0] gfx_off = {q_addr[31:24] - 8'hf8, q_addr[23:0]};
	wire [23:0] gfx_baddr = gfx_off[26:3];
	reg ram_req;
	reg rom_req;
	reg vd_req;
	wire ram_done;
	wire rom_done;
	wire vd_done;
	wire [31:0] ram_rdata;
	wire [31:0] rom_rdata;
	wire [31:0] vd_rdata;
	localparam signed [31:0] LB_LINE_CW = 8;
	localparam signed [31:0] LB_OFF_BITS = 3;
	localparam signed [31:0] LB_SET_BITS = 7;
	localparam [19:0] LB_ROM_CWA_BASE = 20'h80000;
	localparam signed [31:0] LB_TAG_BITS = 10;
	reg bulk_invalidate_q;
	reg [6:0] bulk_set_q;
	reg [6:0] bulk_next_set_q;
	always @(posedge clk)
		if (rst) begin
			bulk_invalidate_q <= 0;
			bulk_set_q <= 1'sb0;
			bulk_next_set_q <= 1'sb0;
		end
		else begin
			bulk_invalidate_q <= bulk_ram_wr === 1'b1;
			bulk_set_q <= bulk_ram_addr[14:8];
			bulk_next_set_q <= bulk_ram_addr[14:8] + 7'd1;
		end
	reg [19:0] lb_line_cwa;
	reg [2:0] fill_k;
	reg lb_is_rom;
	reg lb_filling;
	reg [255:0] rb_shift;
	wire [19:0] fill_cwa = lb_line_cwa + {{17 {1'b0}}, fill_k};
	wire [19:0] fill_rom_cwa = fill_cwa - LB_ROM_CWA_BASE;
	wire [26:0] ram_waddr = (lb_filling ? {8'd0, fill_cwa[18:0]} : {8'd0, q_addr[23:5]});
	wire [26:0] rom_waddr = (lb_filling ? {8'd0, fill_rom_cwa[18:0]} : {8'd0, q_addr[23:5]});
	wire [SD_AW - 1:0] a_addr;
	wire [SD_AW - 1:0] b_addr;
	wire [15:0] a_din;
	wire [15:0] b_din;
	wire [1:0] a_be;
	wire [1:0] b_be;
	wire a_rd;
	wire a_wr;
	wire b_rd;
	wire b_wr;
	wire [15:0] a_dout;
	wire [15:0] b_dout;
	wire a_ack;
	wire b_ack;
	revx_word_sdram #(
		.WORDS(32'h00080000),
		.SD_AW(SD_AW),
		.BASE(RAM_SDBASE),
		.READ_ONLY(1'b0)
	) u_ram(
		.clk(clk),
		.rst(rst),
		.req(ram_req),
		.we(q_we),
		.waddr(ram_waddr),
		.be(q_be),
		.wd(q_wdata),
		.rdata(ram_rdata),
		.done(ram_done),
		.active(),
		.sd_addr(a_addr),
		.sd_din(a_din),
		.sd_be(a_be),
		.sd_rd(a_rd),
		.sd_wr(a_wr),
		.sd_dout(a_dout),
		.sd_ack(a_ack)
	);
	revx_word_sdram #(
		.WORDS(32'h00080000),
		.SD_AW(SD_AW),
		.BASE(ROM_SDBASE),
		.READ_ONLY(1'b1)
	) u_rom(
		.clk(clk),
		.rst(rst),
		.req(rom_req),
		.we(1'b0),
		.waddr(rom_waddr),
		.be(4'hf),
		.wd(32'd0),
		.rdata(rom_rdata),
		.done(rom_done),
		.active(),
		.sd_addr(b_addr),
		.sd_din(b_din),
		.sd_be(b_be),
		.sd_rd(b_rd),
		.sd_wr(b_wr),
		.sd_dout(b_dout),
		.sd_ack(b_ack)
	);
	revx_sdram_arb #(.SD_AW(SD_AW)) u_arb(
		.clk(clk),
		.rst(rst_pon),
		.s_addr({SD_AW {1'b0}}),
		.s_rd(1'b0),
		.s_dout(),
		.s_ack(),
		.a_addr(a_addr),
		.a_din(a_din),
		.a_be(a_be),
		.a_rd(a_rd),
		.a_wr(a_wr),
		.a_dout(a_dout),
		.a_ack(a_ack),
		.b_addr(b_addr),
		.b_din(b_din),
		.b_be(b_be),
		.b_rd(b_rd),
		.b_wr(b_wr),
		.b_dout(b_dout),
		.b_ack(b_ack),
		.vd_addr({SD_AW {1'b0}}),
		.vd_din(16'd0),
		.vd_be(2'd0),
		.vd_rd(1'b0),
		.vd_wr(1'b0),
		.vd_dout(),
		.vd_ack(),
		.vc_addr({SD_AW {1'b0}}),
		.vc_din(16'd0),
		.vc_be(2'd0),
		.vc_rd(1'b0),
		.vc_wr(1'b0),
		.vc_dout(),
		.vc_ack(),
		.dl_addr(dl_addr),
		.dl_din(dl_din),
		.dl_be(dl_be),
		.dl_wr(dl_wr),
		.dl_ack(dl_ack),
		.wb_req(1'b0),
		.wb_addr({SD_AW {1'b0}}),
		.wb_count(7'd0),
		.wb_data(1024'd0),
		.wb_ack(),
		.rb_req(1'b0),
		.rb_addr({SD_AW {1'b0}}),
		.rb_count(5'd0),
		.rb_dout(),
		.rb_ack(),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack),
		.sd_write_chunk(),
		.sd_read_chunk(),
		.sd_chunk_count(),
		.sd_chunk_data(),
		.sd_chunk_dout(256'd0)
	);
	revx_vram_view #(
		.SD_AW(VSD_AW),
		.SRT_WRITE_CHUNKS(SRT_WRITE_CHUNKS)
	) u_vram(
		.clk(clk),
		.rst(rst),
		.req(vd_req),
		.we(q_we),
		.addr(q_addr),
		.be(q_be),
		.raw_mode(q_raw_vram),
		.srt_mode(q_srt),
		.color_mode(q_addr[23]),
		.palette(q_dma_palette),
		.dma_snoop_we(dma_vram_snoop_we),
		.dma_snoop_addr(dma_vram_snoop_addr),
		.wdata(q_wdata),
		.rdata(vd_rdata),
		.done(vd_done),
		.active(),
		.sd_addr(vd_addr),
		.sd_din(vd_din),
		.sd_be(vd_be),
		.sd_rd(vd_rd),
		.sd_wr(vd_wr),
		.sd_dout(vd_dout),
		.sd_ack(vd_ack),
		.wb_req(wb_req),
		.wb_addr(wb_addr),
		.wb_count(wb_count),
		.wb_data(wb_data),
		.wb_ack(wb_ack),
		.vlb_rb_req(vlb_rb_req),
		.vlb_rb_addr(vlb_rb_addr),
		.vlb_rb_count(vlb_rb_count),
		.vlb_rb_dout(vlb_rb_dout),
		.vlb_rb_ack(vlb_rb_ack)
	);
	assign vc_addr = 1'sb0;
	assign vc_din = 1'sb0;
	assign vc_be = 1'sb0;
	assign vc_rd = 1'b0;
	assign vc_wr = 1'b0;
	wire cg_ack;
	wire [7:0] cg_data;
	reg cgw_req;
	wire cgw_ack;
	wire [21:0] cgw_beat;
	wire [63:0] cgw_data;
	wolf_gfx_ddr_top #(
		.USE_STREAM_HINT(1'b0),
		.L2_ENABLE(1'b1)
	) u_gfx(
		.clk(clk),
		.rst(rst),
		.sdram_por(rst_pon),
		.src_req(1'b0),
		.src_addr(32'd0),
		.src_active(1'b0),
		.src_stream(1'b0),
		.src_data(),
		.src_ack(),
		.dcs_safe(),
		.cg_req(1'b0),
		.cg_addr(26'd0),
		.cg_data(cg_data),
		.cg_ack(cg_ack),
		.cgw_req(cgw_req),
		.cgw_beat(cgw_beat),
		.cgw_data(cgw_data),
		.cgw_ack(cgw_ack),
		.dl_wr(gfx_dl_wr),
		.dl_addr(gfx_dl_addr),
		.dl_data(gfx_dl_data),
		.dl_ack(gfx_dl_ack),
		.dl_idle(gfx_dl_idle),
		.dbg_wbeats(),
		.dbg_srd(),
		.dbg_cgrd(),
		.ddram_addr(gfx_ddram_addr),
		.ddram_burstcnt(gfx_ddram_burstcnt),
		.ddram_rd(gfx_ddram_rd),
		.ddram_we(gfx_ddram_we),
		.ddram_din(gfx_ddram_din),
		.ddram_be(gfx_ddram_be),
		.ddram_busy(gfx_ddram_busy),
		.ddram_dout(gfx_ddram_dout),
		.ddram_dout_ready(gfx_ddram_dout_ready)
	);
	wire nvram_ext_en;
	wire nvram_ext_wr;
	wire [15:0] nvram_ext_addr;
	wire [7:0] nvram_ext_wdata;
	wire [7:0] nvram_ext_rdata;
	wire nvram_busy;
	wire nvram_dirty;
	wire cmos_quiesce;
	reg cpu_cmos_wr;
	reg [12:0] cmos_wa;
	reg [7:0] cmos_wd;
	wire [7:0] cpu_cmos_rdata;
	wolf_nvram_bridge #(
		.NVRAM_BYTES(8192),
		.NVRAM_INDEX(8'd4)
	) u_nv(
		.clk(clk),
		.rst_pon(rst_pon),
		.ioctl_download(ioctl_download),
		.ioctl_upload(ioctl_upload),
		.ioctl_wr(ioctl_wr),
		.ioctl_index(ioctl_index),
		.ioctl_addr(ioctl_addr),
		.ioctl_dout(ioctl_dout),
		.ioctl_din(ioctl_din),
		.ioctl_upload_req(ioctl_upload_req),
		.manual_save(manual_save),
		.clear_nvram(clear_nvram),
		.cpu_write_pulse(cpu_cmos_wr),
		.cmos_cpu_busy(1'b0),
		.cmos_quiesce(cmos_quiesce),
		.nvram_ext_en(nvram_ext_en),
		.nvram_ext_wr(nvram_ext_wr),
		.nvram_ext_addr(nvram_ext_addr),
		.nvram_ext_wdata(nvram_ext_wdata),
		.nvram_ext_rdata(nvram_ext_rdata),
		.nvram_busy(nvram_busy),
		.nvram_dirty(nvram_dirty)
	);
	wire cmos_bwr = nvram_ext_en && nvram_ext_wr;
	wire cmos_awe = cmos_bwr || cpu_cmos_wr;
	wire [12:0] cmos_aaddr = (cmos_bwr ? nvram_ext_addr[12:0] : (cpu_cmos_wr ? cmos_wa : nvram_ext_addr[12:0]));
	wire [7:0] cmos_awd = (cmos_bwr ? nvram_ext_wdata : cmos_wd);
	revx_palram #(
		.DW(8),
		.AW(13)
	) u_cmos(
		.clk(clk),
		.we_a(cmos_awe),
		.addr_a(cmos_aaddr),
		.wd_a(cmos_awd),
		.rd_a(nvram_ext_rdata),
		.addr_b(cmos_idx),
		.rd_b(cpu_cmos_rdata)
	);
	reg [3:0] cs;
	reg gfx_phase;
	reg [63:0] gfx_b0_q;
	reg [31:0] rdata_q;
	assign mem_rdata = rdata_q;
	assign cgw_beat = {1'b0, gfx_baddr[23:3]} + {21'd0, gfx_phase};
	wire gfx_cross = gfx_baddr[2:0] > 3'd4;
	function automatic [31:0] gfx_assemble;
		input [127:0] win;
		input [3:0] off;
		reg [31:0] w;
		begin
			w = win[off * 8+:32];
			gfx_assemble = w;
		end
	endfunction
	reg [9:0] lb_tag_st [0:1][0:127];
	reg lb_valid [0:1][0:127];
	reg lb_lru [0:127];
	reg lb_way;
	reg lb_which;
	reg [6:0] lb_set;
	reg [2:0] lb_off;
	reg [9:0] lb_tag;
	reg w_lv_hit0;
	reg w_lv_hit1;
	wire lv_is_rom = q_addr[31:24] == 8'hff;
	wire [19:0] lv_cwa = {lv_is_rom, q_addr[23:5]};
	wire [2:0] lv_off = lv_cwa[2:0];
	wire [6:0] lv_set = lv_cwa[(LB_OFF_BITS + LB_SET_BITS) - 1:LB_OFF_BITS];
	wire [9:0] lv_tag = lv_cwa[19:LB_OFF_BITS + LB_SET_BITS];
	wire lv_hit0 = lb_valid[0][lv_set] && (lb_tag_st[0][lv_set] == lv_tag);
	wire lv_hit1 = lb_valid[1][lv_set] && (lb_tag_st[1][lv_set] == lv_tag);
	wire lv_victim = (!lb_valid[0][lv_set] ? 1'b0 : (!lb_valid[1][lv_set] ? 1'b1 : lb_lru[lv_set]));
	reg lb_we;
	reg [31:0] lb_wdata;
	reg [2:0] lb_wslot;
	wire [10:0] lb_waddr = {lb_way, lb_set, lb_wslot};
	wire [10:0] lb_raddr = {lb_way, lb_set, lb_off};
	reg [31:0] lb_rdata;
	(* ramstyle = "no_rw_check, M10K" *) reg [31:0] lb_mem [0:2047];
	always @(posedge clk) begin
		if (lb_we)
			lb_mem[lb_waddr] <= lb_wdata;
		lb_rdata <= lb_mem[lb_raddr];
	end
	reg [9:0] dlb_tag_st [0:1][0:127];
	reg dlb_valid [0:1][0:127];
	reg dlb_lru [0:127];
	reg dlb_way;
	reg [31:0] dlb_rdata;
	reg dlb_we;
	reg dlb_upd_valid;
	reg dlb_upd_way;
	reg dlb_upd_we;
	reg [6:0] dlb_upd_set;
	reg [2:0] dlb_upd_off;
	reg q_full_word;
	reg w_dlv_hit0;
	reg w_dlv_hit1;
	wire dlv_hit0 = dlb_valid[0][lv_set] && (dlb_tag_st[0][lv_set] == lv_tag);
	wire dlv_hit1 = dlb_valid[1][lv_set] && (dlb_tag_st[1][lv_set] == lv_tag);
	wire dlv_victim = (!dlb_valid[0][lv_set] ? 1'b0 : (!dlb_valid[1][lv_set] ? 1'b1 : dlb_lru[lv_set]));
	wire [10:0] dlb_waddr = (dlb_upd_we ? {dlb_upd_way, dlb_upd_set, dlb_upd_off} : {dlb_way, lb_set, lb_wslot});
	wire [31:0] dlb_wdata_eff = (dlb_upd_we ? q_wdata : lb_wdata);
	wire dlb_we_eff = dlb_we | dlb_upd_we;
	wire [3:0] dlb_wbe_eff = (dlb_upd_we ? q_be : 4'hf);
	wire [10:0] dlb_raddr = {dlb_way, lb_set, lb_off};
	(* ramstyle = "no_rw_check, M10K" *) reg [31:0] dlb_mem [0:2047];
	always @(posedge clk) begin
		begin : sv2v_autoblock_1
			integer byte_lane;
			for (byte_lane = 0; byte_lane < 4; byte_lane = byte_lane + 1)
				if (dlb_we_eff && dlb_wbe_eff[byte_lane])
					dlb_mem[dlb_waddr][byte_lane * 8+:8] <= dlb_wdata_eff[byte_lane * 8+:8];
		end
		dlb_rdata <= dlb_mem[dlb_raddr];
	end
	wire use_dlb = !q_fetch;
	always @(posedge clk)
		if (rst) begin
			cs <= 4'd0;
			mem_ack <= 1'b0;
			ram_req <= 1'b0;
			rom_req <= 1'b0;
			vd_req <= 1'b0;
			rb_req <= 1'b0;
			q_raw_vram <= 1'b0;
			q_srt <= 1'b0;
			q_dma_palette <= 1'sb0;
			q_we <= 1'b0;
			q_addr <= 1'sb0;
			q_be <= 1'sb0;
			q_wdata <= 1'sb0;
			q_fetch <= 1'b1;
			cgw_req <= 1'b0;
			cpu_cmos_wr <= 1'b0;
			gfx_phase <= 1'b0;
			gfx_b0_q <= 64'd0;
			rdata_q <= 32'd0;
			lb_filling <= 1'b0;
			lb_we <= 1'b0;
			fill_k <= 1'sb0;
			lb_wslot <= 1'sb0;
			lb_way <= 1'b0;
			lb_is_rom <= 1'b0;
			lb_line_cwa <= 20'd0;
			w_lv_hit0 <= 1'b0;
			w_lv_hit1 <= 1'b0;
			begin : sv2v_autoblock_2
				reg signed [31:0] w;
				for (w = 0; w < 2; w = w + 1)
					begin : sv2v_autoblock_3
						reg signed [31:0] s;
						for (s = 0; s < 128; s = s + 1)
							lb_valid[w][s] <= 1'b0;
					end
			end
			begin : sv2v_autoblock_4
				reg signed [31:0] s;
				for (s = 0; s < 128; s = s + 1)
					lb_lru[s] <= 1'b0;
			end
			dlb_we <= 1'b0;
			dlb_upd_we <= 1'b0;
			dlb_upd_valid <= 1'b0;
			dlb_way <= 1'b0;
			lb_which <= 1'b0;
			begin : sv2v_autoblock_5
				reg signed [31:0] w;
				for (w = 0; w < 2; w = w + 1)
					begin : sv2v_autoblock_6
						reg signed [31:0] s;
						for (s = 0; s < 128; s = s + 1)
							dlb_valid[w][s] <= 1'b0;
					end
			end
			begin : sv2v_autoblock_7
				reg signed [31:0] s;
				for (s = 0; s < 128; s = s + 1)
					dlb_lru[s] <= 1'b0;
			end
		end
		else begin
			mem_ack <= 1'b0;
			ram_req <= 1'b0;
			rom_req <= 1'b0;
			vd_req <= 1'b0;
			rb_req <= 1'b0;
			cpu_cmos_wr <= 1'b0;
			lb_we <= 1'b0;
			dlb_we <= 1'b0;
			dlb_upd_we <= 1'b0;
			case (cs)
				4'd0:
					if (mem_req && !mem_ack) begin
						q_we <= mem_we;
						q_addr <= mem_addr;
						q_be <= mem_be;
						q_wdata <= mem_wdata;
						q_raw_vram <= mem_raw_vram === 1'b1;
						q_srt <= mem_srt === 1'b1;
						q_dma_palette <= dma_palette;
						q_fetch <= mem_fetch !== 1'b0;
						cs <= 4'd12;
					end
				4'd12:
					(* full_case, parallel_case *)
					case (region)
						R_RAM:
							if (q_we) begin
								lb_set <= lv_set;
								w_lv_hit0 <= lv_hit0;
								w_lv_hit1 <= lv_hit1;
								q_full_word <= q_be == 4'b1111;
								w_dlv_hit0 <= dlv_hit0;
								w_dlv_hit1 <= dlv_hit1;
								lb_off <= lv_off;
								ram_req <= 1'b1;
								cs <= 4'd1;
							end
							else begin
								lb_set <= lv_set;
								lb_off <= lv_off;
								lb_tag <= lv_tag;
								lb_is_rom <= 1'b0;
								lb_line_cwa <= {lv_cwa[19:LB_OFF_BITS], {LB_OFF_BITS {1'b0}}};
								if (use_dlb) begin
									lb_which <= 1'b1;
									if (dlv_hit0 || dlv_hit1) begin
										dlb_way <= dlv_hit1;
										cs <= 4'd9;
									end
									else begin
										dlb_way <= dlv_victim;
										fill_k <= 1'sb0;
										lb_filling <= 1'b1;
										cs <= 4'd6;
									end
								end
								else begin
									lb_which <= 1'b0;
									if (lv_hit0 || lv_hit1) begin
										lb_way <= lv_hit1;
										cs <= 4'd9;
									end
									else begin
										lb_way <= lv_victim;
										fill_k <= 1'sb0;
										lb_filling <= 1'b1;
										cs <= 4'd6;
									end
								end
							end
						R_ROM:
							if (q_we) begin
								rom_req <= 1'b1;
								cs <= 4'd1;
							end
							else begin
								lb_set <= lv_set;
								lb_off <= lv_off;
								lb_tag <= lv_tag;
								lb_is_rom <= 1'b1;
								lb_line_cwa <= {lv_cwa[19:LB_OFF_BITS], {LB_OFF_BITS {1'b0}}};
								if (use_dlb) begin
									lb_which <= 1'b1;
									if (dlv_hit0 || dlv_hit1) begin
										dlb_way <= dlv_hit1;
										cs <= 4'd9;
									end
									else begin
										dlb_way <= dlv_victim;
										fill_k <= 1'sb0;
										lb_filling <= 1'b1;
										cs <= 4'd6;
									end
								end
								else begin
									lb_which <= 1'b0;
									if (lv_hit0 || lv_hit1) begin
										lb_way <= lv_hit1;
										cs <= 4'd9;
									end
									else begin
										lb_way <= lv_victim;
										fill_k <= 1'sb0;
										lb_filling <= 1'b1;
										cs <= 4'd6;
									end
								end
							end
						R_VRAMD: begin
							vd_req <= 1'b1;
							cs <= 4'd1;
						end
						R_VRAMC: begin
							vd_req <= 1'b1;
							cs <= 4'd1;
						end
						R_CMOS: begin
							if ((q_we && q_be[0]) && !cmos_quiesce) begin
								cpu_cmos_wr <= 1'b1;
								cmos_wa <= cmos_idx;
								cmos_wd <= q_wdata[7:0];
							end
							cs <= (q_we ? 4'd5 : 4'd4);
						end
						R_GFX: begin
							gfx_phase <= 1'b0;
							cgw_req <= 1'b1;
							cs <= 4'd2;
						end
						default: begin
							rdata_q <= 32'd0;
							cs <= 4'd5;
						end
					endcase
				4'd1:
					if (ram_done) begin
						rdata_q <= ram_rdata;
						if (q_we) begin
							if (w_lv_hit0)
								lb_valid[0][lb_set] <= 1'b0;
							if (w_lv_hit1)
								lb_valid[1][lb_set] <= 1'b0;
						end
						if (q_we) begin
							dlb_upd_valid <= w_dlv_hit0 || w_dlv_hit1;
							dlb_upd_way <= w_dlv_hit1;
							dlb_upd_set <= lb_set;
							dlb_upd_off <= lb_off;
						end
						else if (q_we) begin
							if (w_dlv_hit0)
								dlb_valid[0][lb_set] <= 1'b0;
							if (w_dlv_hit1)
								dlb_valid[1][lb_set] <= 1'b0;
						end
						cs <= 4'd5;
					end
					else if (rom_done) begin
						rdata_q <= rom_rdata;
						cs <= 4'd5;
					end
					else if (vd_done) begin
						rdata_q <= vd_rdata;
						cs <= 4'd5;
					end
				4'd6: begin
					rb_req <= 1'b1;
					rb_count <= 5'd16;
					rb_addr <= (lb_is_rom ? ROM_SDBASE + (({1'b0, lb_line_cwa} - {1'b0, LB_ROM_CWA_BASE}) << 1) : RAM_SDBASE + ({1'b0, lb_line_cwa} << 1));
					cs <= 4'd7;
				end
				4'd7: begin
					rb_req <= 1'b1;
					if (rb_ack) begin
						rb_req <= 1'b0;
						rb_shift <= rb_dout;
						fill_k <= 1'sb0;
						cs <= 4'd8;
					end
				end
				4'd8: begin
					if (lb_which)
						dlb_we <= 1'b1;
					else
						lb_we <= 1'b1;
					lb_wslot <= fill_k;
					lb_wdata <= rb_shift[31:0];
					rb_shift <= {16'd0, rb_shift[255:32]};
					if (fill_k == 7) begin
						if (lb_which) begin
							dlb_tag_st[dlb_way][lb_set] <= lb_tag;
							dlb_valid[dlb_way][lb_set] <= 1'b1;
							dlb_lru[lb_set] <= ~dlb_way;
						end
						else begin
							lb_tag_st[lb_way][lb_set] <= lb_tag;
							lb_valid[lb_way][lb_set] <= 1'b1;
							lb_lru[lb_set] <= ~lb_way;
						end
						lb_filling <= 1'b0;
						cs <= 4'd11;
					end
					else
						fill_k <= fill_k + 1'b1;
				end
				4'd11: cs <= 4'd9;
				4'd9: begin
					if (lb_which)
						dlb_lru[lb_set] <= ~dlb_way;
					else
						lb_lru[lb_set] <= ~lb_way;
					cs <= 4'd10;
				end
				4'd10: begin
					rdata_q <= (lb_which ? dlb_rdata : lb_rdata);
					cs <= 4'd5;
				end
				4'd2:
					if (cgw_ack) begin
						cgw_req <= 1'b0;
						gfx_b0_q <= cgw_data;
						if (gfx_cross) begin
							gfx_phase <= 1'b1;
							cs <= 4'd3;
						end
						else begin
							rdata_q <= gfx_assemble({64'd0, cgw_data}, {1'b0, gfx_baddr[2:0]});
							cs <= 4'd5;
						end
					end
				4'd3:
					if (!cgw_req && !cgw_ack)
						cgw_req <= 1'b1;
					else if (cgw_ack) begin
						cgw_req <= 1'b0;
						rdata_q <= gfx_assemble({cgw_data, gfx_b0_q}, {1'b0, gfx_baddr[2:0]});
						cs <= 4'd5;
					end
				4'd4: begin
					rdata_q <= {24'd0, cpu_cmos_rdata};
					cs <= 4'd5;
				end
				4'd5: begin
					dlb_upd_we <= dlb_upd_valid;
					dlb_upd_valid <= 1'b0;
					mem_ack <= 1'b1;
					cs <= 4'd0;
				end
				default: cs <= 4'd0;
			endcase
			if (bulk_invalidate_q) begin
				lb_valid[0][bulk_set_q] <= 1'b0;
				lb_valid[1][bulk_set_q] <= 1'b0;
				lb_valid[0][bulk_next_set_q] <= 1'b0;
				lb_valid[1][bulk_next_set_q] <= 1'b0;
				dlb_valid[0][bulk_set_q] <= 1'b0;
				dlb_valid[1][bulk_set_q] <= 1'b0;
				dlb_valid[0][bulk_next_set_q] <= 1'b0;
				dlb_valid[1][bulk_next_set_q] <= 1'b0;
			end
		end
	wire _unused = &{1'b0, nvram_busy, nvram_dirty, cmos_quiesce};
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module revx_cpu_bfm (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_be,
	mem_wdata,
	mem_rdata,
	mem_ack,
	int0,
	cmd_req,
	cmd_we,
	cmd_addr,
	cmd_be,
	cmd_wdata,
	cmd_rdata,
	cmd_done,
	reset_pc,
	int0_seen
);
	parameter [31:0] RESET_PC = 32'hfffde010;
	input wire clk;
	input wire rst;
	output reg mem_req;
	output reg mem_we;
	output reg [31:0] mem_addr;
	output reg [3:0] mem_be;
	output reg [31:0] mem_wdata;
	input wire [31:0] mem_rdata;
	input wire mem_ack;
	input wire int0;
	input wire cmd_req;
	input wire cmd_we;
	input wire [31:0] cmd_addr;
	input wire [3:0] cmd_be;
	input wire [31:0] cmd_wdata;
	output reg [31:0] cmd_rdata;
	output reg cmd_done;
	output wire [31:0] reset_pc;
	output reg int0_seen;
	assign reset_pc = RESET_PC;
	reg [1:0] st;
	always @(posedge clk)
		if (rst) begin
			st <= 2'd0;
			mem_req <= 1'b0;
			mem_we <= 1'b0;
			cmd_done <= 1'b0;
			cmd_rdata <= 32'd0;
			int0_seen <= 1'b0;
			mem_addr <= RESET_PC;
			mem_be <= 4'hf;
		end
		else begin
			cmd_done <= 1'b0;
			if (int0)
				int0_seen <= 1'b1;
			case (st)
				2'd0:
					if (cmd_req) begin
						mem_addr <= cmd_addr;
						mem_we <= cmd_we;
						mem_be <= cmd_be;
						mem_wdata <= cmd_wdata;
						mem_req <= 1'b1;
						st <= 2'd2;
					end
				2'd2:
					if (mem_ack) begin
						mem_req <= 1'b0;
						cmd_rdata <= mem_rdata;
						cmd_done <= 1'b1;
						st <= 2'd0;
					end
				default: st <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module revx_top (
	clk,
	reset,
	pll_locked,
	cpu_ce,
	ioctl_download,
	ioctl_wr,
	ioctl_index,
	ioctl_addr,
	ioctl_dout,
	dl_ready,
	dl_wait,
	ioctl_upload,
	ioctl_din,
	ioctl_upload_req,
	manual_save,
	clear_nvram,
	dcs_dl_wr,
	dcs_dl_addr,
	dcs_dl_data,
	dcs_dl_ack,
	profile_byte,
	profile_valid,
	dbg_acc_prog,
	dbg_acc_gfx,
	dbg_acc_dcs,
	dbg_drop_any,
	dbg_rst_during_dl,
	dbg_last_fetch_addr,
	dbg_last_fetch_data,
	dbg_culprit_pc,
	dbg_target_pc,
	dbg_last_good_pc,
	dbg_culprit_instr,
	dbg_derail_captured,
	dbg_int_pc,
	dbg_int_vec_addr,
	dbg_int_vec_value,
	dbg_int_count,
	dbg_int_captured,
	dbg_intpend,
	dbg_intenb,
	dbg_disp_int,
	dbg_st_ie,
	dbg_foreground_pc,
	dbg_timers,
	dbg_process_ptr,
	dbg_watch_status,
	dbg_postcal_early,
	dbg_postcal_final,
	dma_irq,
	cmd_req,
	cmd_we,
	cmd_addr,
	cmd_be,
	cmd_wdata,
	cmd_rdata,
	cmd_done,
	scan_start,
	scan_rowaddr,
	scan_coladdr,
	scan_pixel,
	scan_done,
	reset_pc,
	int0_seen,
	cpu_pc,
	cpu_retire,
	cpu_instr,
	diag_dpyst_value,
	diag_dpyst_valid,
	diag_opcode_accept,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack,
	vd_addr,
	vd_din,
	vd_be,
	vd_rd,
	vd_wr,
	vd_dout,
	vd_ack,
	vd_count,
	vd_words,
	vd_reverse,
	wb_req,
	wb_addr,
	wb_count,
	wb_data,
	wb_ack,
	wb2_req,
	wb2_addr,
	wb2_count,
	wb2_data,
	wb2_ack,
	rb_req,
	rb_addr,
	rb_count,
	rb_dout,
	rb_ack,
	vlb_rb_req,
	vlb_rb_addr,
	vlb_rb_count,
	vlb_rb_dout,
	vlb_rb_ack,
	vc_addr,
	vc_din,
	vc_be,
	vc_rd,
	vc_wr,
	vc_dout,
	vc_ack,
	gfx_ddram_addr,
	gfx_ddram_burstcnt,
	gfx_ddram_rd,
	gfx_ddram_we,
	gfx_ddram_din,
	gfx_ddram_be,
	gfx_ddram_busy,
	gfx_ddram_dout,
	gfx_ddram_dout_ready,
	ce_pix,
	in0,
	in1,
	in2,
	dsw,
	an0,
	an1,
	an2,
	an3,
	an4,
	an5,
	dcs_ctrl,
	dcs_data_in,
	dcs_output_full,
	dcs_data_w,
	dcs_data_o,
	dcs_data_rd,
	dcs_reset,
	dcs_lint1,
	sysctrl0,
	sysctrl1,
	cmos_write_enable,
	gun_recoil,
	gun_led,
	watchdog_kick,
	dma_reg_we,
	dma_reg_addr,
	dma_reg_wdata,
	dma_reg_pair,
	dma_pair_rdata,
	dma_palette,
	dma_pixel_req,
	dma_pixel_addr,
	dma_pixel_data,
	dma_pixel_count,
	dma_pixel_words,
	dma_pixel_reverse,
	dma_pixel_ack,
	dma_mem_req,
	dma_mem_we,
	dma_mem_addr,
	dma_mem_wdata,
	dma_mem_be,
	dma_mem_ack,
	dma_mem_rdata,
	pal_rd_idx,
	pal_rd_data,
	disp_row,
	disp_col,
	disp_enable,
	video_hcount,
	video_vcount,
	video_heblnk,
	video_hsblnk,
	video_veblnk,
	video_vsblnk,
	video_hs,
	video_vs,
	video_hb,
	video_vb,
	video_ready,
	dbg_pic_status,
	dbg_uart_last,
	dbg_adc_chan,
	dbg_adc_last
);
	parameter signed [31:0] SD_AW = 21;
	parameter signed [31:0] VSD_AW = 19;
	parameter [0:0] SRT_WRITE_CHUNKS = 1'b0;
	parameter [0:0] POSTCAL_DIAG = 1'b0;
	parameter [0:0] QUIET_BOOT_DIAG = 1'b0;
	parameter [SD_AW - 1:0] ROM_SDBASE = 21'h100000;
	parameter [31:0] RESET_PC = 32'hfffde000;
	parameter signed [31:0] PROG_BYTES = 32'h00200000;
	input wire clk;
	input wire reset;
	input wire pll_locked;
	input wire cpu_ce;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [7:0] ioctl_index;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output wire dl_ready;
	output wire dl_wait;
	input wire ioctl_upload;
	output wire [7:0] ioctl_din;
	output wire ioctl_upload_req;
	input wire manual_save;
	input wire clear_nvram;
	output wire dcs_dl_wr;
	output wire [22:0] dcs_dl_addr;
	output wire [7:0] dcs_dl_data;
	input wire dcs_dl_ack;
	output wire [7:0] profile_byte;
	output wire profile_valid;
	output wire [31:0] dbg_acc_prog;
	output wire [31:0] dbg_acc_gfx;
	output wire [31:0] dbg_acc_dcs;
	output wire [7:0] dbg_drop_any;
	output wire dbg_rst_during_dl;
	output reg [31:0] dbg_last_fetch_addr;
	output reg [31:0] dbg_last_fetch_data;
	output wire [31:0] dbg_culprit_pc;
	output wire [31:0] dbg_target_pc;
	output wire [31:0] dbg_last_good_pc;
	output wire [15:0] dbg_culprit_instr;
	output wire dbg_derail_captured;
	output wire [31:0] dbg_int_pc;
	output wire [31:0] dbg_int_vec_addr;
	output wire [31:0] dbg_int_vec_value;
	output wire [7:0] dbg_int_count;
	output wire dbg_int_captured;
	output wire [15:0] dbg_intpend;
	output wire [15:0] dbg_intenb;
	output wire dbg_disp_int;
	output wire dbg_st_ie;
	output wire [31:0] dbg_foreground_pc;
	output wire [31:0] dbg_timers;
	output wire [31:0] dbg_process_ptr;
	output wire [31:0] dbg_watch_status;
	output wire [287:0] dbg_postcal_early;
	output wire [287:0] dbg_postcal_final;
	input wire dma_irq;
	input wire cmd_req;
	input wire cmd_we;
	input wire [31:0] cmd_addr;
	input wire [3:0] cmd_be;
	input wire [31:0] cmd_wdata;
	output wire [31:0] cmd_rdata;
	output wire cmd_done;
	input wire scan_start;
	input wire [15:0] scan_rowaddr;
	input wire [15:0] scan_coladdr;
	output reg [14:0] scan_pixel;
	output reg scan_done;
	output wire [31:0] reset_pc;
	output reg int0_seen;
	output wire [31:0] cpu_pc;
	output wire cpu_retire;
	output wire [15:0] cpu_instr;
	output wire [31:0] diag_dpyst_value;
	output wire diag_dpyst_valid;
	output wire diag_opcode_accept;
	output wire [SD_AW - 1:0] sd_addr;
	output wire [15:0] sd_din;
	output wire [1:0] sd_be;
	output wire sd_rd;
	output wire sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	output wire [VSD_AW - 1:0] vd_addr;
	output wire [15:0] vd_din;
	output wire [1:0] vd_be;
	output wire vd_rd;
	output wire vd_wr;
	input wire [15:0] vd_dout;
	input wire vd_ack;
	output wire [2:0] vd_count;
	output wire [63:0] vd_words;
	output wire vd_reverse;
	output wire wb_req;
	output wire [VSD_AW - 1:0] wb_addr;
	output wire [6:0] wb_count;
	output wire [1023:0] wb_data;
	input wire wb_ack;
	output wire wb2_req;
	output wire [SD_AW - 1:0] wb2_addr;
	output wire [4:0] wb2_count;
	output wire [255:0] wb2_data;
	input wire wb2_ack;
	output wire rb_req;
	output wire [SD_AW - 1:0] rb_addr;
	output wire [4:0] rb_count;
	input wire [255:0] rb_dout;
	input wire rb_ack;
	output wire vlb_rb_req;
	output wire [VSD_AW - 1:0] vlb_rb_addr;
	output wire [4:0] vlb_rb_count;
	input wire [255:0] vlb_rb_dout;
	input wire vlb_rb_ack;
	output wire [VSD_AW - 1:0] vc_addr;
	output wire [15:0] vc_din;
	output wire [1:0] vc_be;
	output wire vc_rd;
	output wire vc_wr;
	input wire [15:0] vc_dout;
	input wire vc_ack;
	output wire [28:0] gfx_ddram_addr;
	output wire [7:0] gfx_ddram_burstcnt;
	output wire gfx_ddram_rd;
	output wire gfx_ddram_we;
	output wire [63:0] gfx_ddram_din;
	output wire [7:0] gfx_ddram_be;
	input wire gfx_ddram_busy;
	input wire [63:0] gfx_ddram_dout;
	input wire gfx_ddram_dout_ready;
	input wire ce_pix;
	input wire [31:0] in0;
	input wire [31:0] in1;
	input wire [31:0] in2;
	input wire [31:0] dsw;
	input wire [7:0] an0;
	input wire [7:0] an1;
	input wire [7:0] an2;
	input wire [7:0] an3;
	input wire [7:0] an4;
	input wire [7:0] an5;
	input wire [15:0] dcs_ctrl;
	input wire [7:0] dcs_data_in;
	input wire dcs_output_full;
	output wire dcs_data_w;
	output wire [7:0] dcs_data_o;
	output wire dcs_data_rd;
	output wire dcs_reset;
	output wire dcs_lint1;
	output wire [3:0] sysctrl0;
	output wire [3:0] sysctrl1;
	output wire cmos_write_enable;
	output wire [2:0] gun_recoil;
	output wire [2:0] gun_led;
	output wire watchdog_kick;
	output wire dma_reg_we;
	output wire [3:0] dma_reg_addr;
	output wire [15:0] dma_reg_wdata;
	output wire [2:0] dma_reg_pair;
	input wire [31:0] dma_pair_rdata;
	input wire [15:0] dma_palette;
	input wire dma_pixel_req;
	input wire [18:0] dma_pixel_addr;
	input wire [15:0] dma_pixel_data;
	input wire [2:0] dma_pixel_count;
	input wire [63:0] dma_pixel_words;
	input wire dma_pixel_reverse;
	output wire dma_pixel_ack;
	input wire dma_mem_req;
	input wire dma_mem_we;
	input wire [31:0] dma_mem_addr;
	input wire [31:0] dma_mem_wdata;
	input wire [3:0] dma_mem_be;
	output wire dma_mem_ack;
	output wire [31:0] dma_mem_rdata;
	input wire [14:0] pal_rd_idx;
	output wire [15:0] pal_rd_data;
	output wire [15:0] disp_row;
	output wire [15:0] disp_col;
	output wire disp_enable;
	output wire [15:0] video_hcount;
	output wire [15:0] video_vcount;
	output wire [15:0] video_heblnk;
	output wire [15:0] video_hsblnk;
	output wire [15:0] video_veblnk;
	output wire [15:0] video_vsblnk;
	output wire video_hs;
	output wire video_vs;
	output wire video_hb;
	output wire video_vb;
	output wire video_ready;
	output wire dbg_pic_status;
	output wire [7:0] dbg_uart_last;
	output wire [7:0] dbg_adc_chan;
	output wire [7:0] dbg_adc_last;
	reg por_ff1;
	reg por_ff2;
	wire por;
	always @(posedge clk) begin
		por_ff1 <= ~pll_locked;
		por_ff2 <= por_ff1;
	end
	assign por = por_ff2;
	wire c_req;
	wire c_we;
	wire c_ack;
	wire c_srt;
	wire c_fetch;
	wire [31:0] c_addr;
	wire [31:0] c_wdata;
	wire [31:0] c_rdata;
	wire [3:0] c_be;
	wire [15:0] core_disp_row;
	wire [15:0] core_disp_col;
	wire core_disp_en;
	wire cdbg_int_entry;
	wire [31:0] cdbg_int_pc;
	wire [31:0] cdbg_int_vec_addr;
	wire [31:0] cdbg_int_vec_value;
	wire [15:0] cdbg_intpend;
	wire [15:0] cdbg_intenb;
	wire cdbg_disp_int;
	wire cdbg_st_ie;
	wire postcal_irq_begin;
	wire postcal_irq_return;
	wire be_rb_req;
	wire be_rb_ack;
	wire [SD_AW - 1:0] be_rb_addr;
	wire [4:0] be_rb_count;
	wire [255:0] be_rb_dout;
	wire be_vlb_rb_req;
	wire be_vlb_rb_ack;
	wire [VSD_AW - 1:0] be_vlb_rb_addr;
	wire [4:0] be_vlb_rb_count;
	wire [255:0] be_vlb_rb_dout;
	assign vlb_rb_req = be_vlb_rb_req;
	assign vlb_rb_addr = be_vlb_rb_addr;
	assign vlb_rb_count = be_vlb_rb_count;
	assign be_vlb_rb_dout = vlb_rb_dout;
	assign be_vlb_rb_ack = vlb_rb_ack;
	wire core_lint2 = dcs_lint1;
	wire k_req;
	wire k_we;
	wire k_srt;
	wire k_ack;
	wire k_fetch;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	wire [31:0] k_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	wire [5:0] k_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	wire [31:0] k_wdata;
	wire [31:0] k_rdata;
	wire [31:0] k_pc;
	wire k_retire;
	wire blm_brb_req;
	wire blm_brb_ack;
	wire blm_bwb_req;
	wire blm_bwb_ack;
	wire [31:0] blm_brb_addr;
	wire [31:0] blm_bwb_addr;
	wire [4:0] blm_brb_count;
	wire [4:0] blm_bwb_count;
	wire [255:0] blm_brb_dout;
	wire [255:0] blm_bwb_data;
	wire blm_burst_ok;
	wire blm_src_ram = blm_brb_addr[31:24] == 8'h20;
	wire blm_src_rom = blm_brb_addr[31:24] == 8'hff;
	wire blm_dst_ram = blm_bwb_addr[31:24] == 8'h20;
	assign blm_burst_ok = (blm_src_ram | blm_src_rom) & blm_dst_ram;
	wire [SD_AW - 1:0] blm_rd_word = (blm_src_rom ? ROM_SDBASE + {17'd0, (blm_brb_addr[23:0] - 24'h000000) >> 4} : {17'd0, blm_brb_addr[23:0] >> 4});
	wire [SD_AW - 1:0] blm_wr_word = {17'd0, blm_bwb_addr[23:0] >> 4};
	wire blm_read_req;
	wire blm_read_ack;
	wire [SD_AW - 1:0] blm_read_addr;
	wire [4:0] blm_read_count;
	wire [255:0] blm_read_data;
	revx_chunk_mailbox #(.AW(SD_AW)) u_blm_read_mailbox(
		.clk(clk),
		.rst(reset),
		.cpu_req(blm_brb_req),
		.cpu_addr(blm_rd_word),
		.cpu_count(blm_brb_count),
		.cpu_wdata(256'd0),
		.cpu_ack(blm_brb_ack),
		.cpu_rdata(blm_brb_dout),
		.req(blm_read_req),
		.addr(blm_read_addr),
		.count(blm_read_count),
		.wdata(),
		.ack(blm_read_ack),
		.rdata(blm_read_data)
	);
	revx_read_chunk_mux #(.AW(SD_AW)) u_cpu_chunk_mux(
		.clk(clk),
		.rst(reset),
		.a_req(be_rb_req),
		.a_addr(be_rb_addr),
		.a_count(be_rb_count),
		.a_data(be_rb_dout),
		.a_ack(be_rb_ack),
		.b_req(blm_read_req),
		.b_addr(blm_read_addr),
		.b_count(blm_read_count),
		.b_data(blm_read_data),
		.b_ack(blm_read_ack),
		.req(rb_req),
		.addr(rb_addr),
		.count(rb_count),
		.data(rb_dout),
		.ack(rb_ack)
	);
	revx_chunk_mailbox #(.AW(SD_AW)) u_blm_write_mailbox(
		.clk(clk),
		.rst(reset),
		.cpu_req(blm_bwb_req),
		.cpu_addr(blm_wr_word),
		.cpu_count(blm_bwb_count),
		.cpu_wdata(blm_bwb_data),
		.cpu_ack(blm_bwb_ack),
		.cpu_rdata(),
		.req(wb2_req),
		.addr(wb2_addr),
		.count(wb2_count),
		.wdata(wb2_data),
		.ack(wb2_ack),
		.rdata(256'd0)
	);
	wire core_ce_pix = ce_pix;
	tms34010_core u_cpu(
		.clk(clk),
		.ce_cpu(cpu_ce),
		.ce_pix(core_ce_pix),
		.rst(reset),
		.mem_req(k_req),
		.mem_we(k_we),
		.mem_addr(k_addr),
		.mem_size(k_size),
		.mem_wdata(k_wdata),
		.mem_srt(k_srt),
		.fetch_access_o(k_fetch),
		.mem_rdata(k_rdata),
		.mem_ack(k_ack),
		.pc_o(k_pc),
		.instruction_start_o(k_retire),
		.instr_word_o(cpu_instr),
		.dbg_dpyst_value_o(diag_dpyst_value),
		.dbg_dpyst_valid_o(diag_dpyst_valid),
		.display_row_o(core_disp_row),
		.display_col_o(core_disp_col),
		.display_enable_o(core_disp_en),
		.lint1_in(dma_irq),
		.lint2_in(core_lint2),
		.dbg_int_entry_o(cdbg_int_entry),
		.dbg_int_pc_o(cdbg_int_pc),
		.dbg_int_vec_addr_o(cdbg_int_vec_addr),
		.dbg_int_vec_value_o(cdbg_int_vec_value),
		.dbg_intpend_o(cdbg_intpend),
		.dbg_intenb_o(cdbg_intenb),
		.dbg_disp_int_o(cdbg_disp_int),
		.dbg_st_ie_o(cdbg_st_ie),
		.dbg_int_return_o(postcal_irq_return),
		.dbg_int_begin_o(postcal_irq_begin),
		.blmove_brb_req(blm_brb_req),
		.blmove_brb_addr(blm_brb_addr),
		.blmove_brb_count(blm_brb_count),
		.blmove_brb_dout(blm_brb_dout),
		.blmove_brb_ack(blm_brb_ack),
		.blmove_bwb_req(blm_bwb_req),
		.blmove_bwb_addr(blm_bwb_addr),
		.blmove_bwb_count(blm_bwb_count),
		.blmove_bwb_data(blm_bwb_data),
		.blmove_bwb_ack(blm_bwb_ack),
		.blmove_burst_ok(blm_burst_ok),
		.video_hcount_o(video_hcount),
		.video_vcount_o(video_vcount),
		.video_heblnk_o(video_heblnk),
		.video_hsblnk_o(video_hsblnk),
		.video_veblnk_o(video_veblnk),
		.video_vsblnk_o(video_vsblnk),
		.video_hs_o(video_hs),
		.video_vs_o(video_vs),
		.video_hb_o(video_hb),
		.video_vb_o(video_vb),
		.video_ready_o(video_ready)
	);
	tms34010_mem_if #(.P_IS_34020(1'b1)) u_mif(
		.clk(clk),
		.rst(reset),
		.ce_cpu(cpu_ce),
		.core_req(k_req),
		.core_we(k_we),
		.core_addr(k_addr),
		.core_size(k_size),
		.core_wdata(k_wdata),
		.core_srt(k_srt),
		.core_fetch(k_fetch),
		.core_rdata(k_rdata),
		.core_ack(k_ack),
		.bus_req(c_req),
		.bus_we(c_we),
		.bus_addr(c_addr),
		.bus_be(c_be),
		.bus_wdata(c_wdata),
		.bus_srt(c_srt),
		.bus_fetch(c_fetch),
		.bus_rdata(c_rdata),
		.bus_ack(c_ack)
	);
	assign cpu_pc = k_pc;
	assign cpu_retire = k_retire;
	assign diag_opcode_accept = k_retire && !postcal_irq_begin;
	assign reset_pc = RESET_PC;
	assign cmd_rdata = 32'd0;
	assign cmd_done = 1'b0;
	always @(posedge clk)
		if (reset)
			int0_seen <= 1'b0;
		else if (dma_irq)
			int0_seen <= 1'b1;
	wire [31:0] scan_full = (({16'd0, scan_rowaddr} << 16) | {16'd0, scan_coladdr}) >> 3;
	wire [14:0] scan_i0 = scan_full[14:0] & 15'h7fff;
	reg s_active;
	reg s_req;
	wire [31:0] s_addr;
	reg s_half;
	reg [15:0] scan_word;
	reg [2:0] sc;
	wire m_req;
	wire m_we;
	wire m_ack;
	wire [31:0] m_addr;
	wire [31:0] m_wdata;
	wire [31:0] m_rdata;
	wire [3:0] m_be;
	assign m_req = (s_active ? s_req : c_req);
	assign m_we = (s_active ? 1'b0 : c_we);
	assign m_addr = (s_active ? s_addr : c_addr);
	assign m_be = (s_active ? 4'hf : c_be);
	assign m_wdata = (s_active ? 32'd0 : c_wdata);
	assign c_ack = m_ack & ~s_active;
	assign c_rdata = m_rdata;
	wire is_pal = m_addr[31:20] == 12'ha08;
	wire [14:0] pal_idx = m_addr[19:5];
	reg pal_ack;
	reg pal_rd_wait;
	wire [15:0] pal_rd_a;
	wire [15:0] pal_rd_b;
	wire [14:0] pal_addr_b = (s_active ? scan_word[14:0] : pal_rd_idx);
	wire pal_we_a = (((((!reset && m_req) && is_pal) && m_we) && m_be[0]) && !pal_ack) && !pal_rd_wait;
	revx_palram #(
		.DW(16),
		.AW(15)
	) u_pal(
		.clk(clk),
		.we_a(pal_we_a),
		.addr_a(pal_idx),
		.wd_a(m_wdata[15:0]),
		.rd_a(pal_rd_a),
		.addr_b(pal_addr_b),
		.rd_b(pal_rd_b)
	);
	wire is_io = ((((((m_addr[31:28] == 4'h4) && (m_addr[27:0] >= 28'h0800000)) | (m_addr[31:5] == (32'h60400000 >> 5))) | (m_addr[31:8] == 24'h60c000)) | (m_addr[31:5] == (32'h80800000 >> 5))) | (m_addr[31:8] == 24'h80c000)) | ((m_addr[31:24] == 8'hc0) && ((m_addr[23:20] == 4'h8) || (m_addr[23:20] == 4'hc)));
	wire [31:0] io_rdata;
	wire io_ack;
	wire io_cmos_we_unused;
	wire b_req;
	wire [31:0] b_rdata;
	wire b_ack;
	wire dl_wr_o;
	wire [SD_AW - 1:0] dl_addr_o;
	wire [15:0] dl_din_o;
	wire [1:0] dl_be_o;
	wire dl_ack;
	wire lgfx_wr;
	wire [24:0] lgfx_addr;
	wire [7:0] lgfx_data;
	wire bgfx_ack;
	wire bgfx_idle;
	wire [12:0] lpic_rd_addr;
	wire [7:0] lpic_rd_data;
	wire cpu_b_req = (m_req & ~is_pal) & ~is_io;
	wire be_we;
	wire [31:0] be_addr;
	wire [31:0] be_wdata;
	wire [3:0] be_be;
	wire be_fetch;
	wire be_raw_vram;
	wire be_srt;
	wire [15:0] be_dma_palette;
	wire cpu_b_ack;
	wire [VSD_AW - 1:0] be_vd_addr;
	wire [15:0] be_vd_din;
	wire [1:0] be_vd_be;
	wire be_vd_rd;
	wire be_vd_wr;
	wire be_vd_ack;
	wire dma_direct_ack;
	wire [18:0] dma_direct_pixel;
	wire dma_direct = dma_pixel_req === 1'b1;
	assign dma_direct_pixel = dma_pixel_addr;
	reg [1:0] be_owner;
	wire dma_pixel_claimed;
	wire cpu_vram = (m_addr[31:22] == 0) || (m_addr[31:22] == 2);
	wire cpu_new_vram_claim = (((((be_owner == 0) && !b_ack) && !(dma_mem_req === 1'b1)) && cpu_b_req) && cpu_vram) && !dma_pixel_claimed;
	always @(posedge clk)
		if (reset)
			be_owner <= 0;
		else if ((be_owner != 0) && b_ack)
			be_owner <= 0;
		else if ((be_owner == 0) && !b_ack) begin
			if (dma_mem_req === 1'b1)
				be_owner <= 2;
			else if (cpu_b_req && (!cpu_vram || !dma_pixel_claimed))
				be_owner <= 1;
		end
	assign b_req = (be_owner == 1 ? cpu_b_req : (be_owner == 2 ? dma_mem_req : 1'b0));
	assign be_we = (be_owner == 2 ? dma_mem_we : m_we);
	assign be_addr = (be_owner == 2 ? dma_mem_addr : m_addr);
	assign be_wdata = (be_owner == 2 ? dma_mem_wdata : m_wdata);
	assign be_be = (be_owner == 2 ? dma_mem_be : m_be);
	assign be_raw_vram = (be_owner == 2 ? dma_mem_addr[31:23] == 0 : s_active);
	assign be_srt = ((be_owner == 1) && !s_active) && c_srt;
	assign be_fetch = (be_owner == 1 ? c_fetch : 1'b0);
	assign be_dma_palette = dma_palette;
	assign cpu_b_ack = b_ack && (be_owner == 1);
	assign dma_mem_ack = b_ack && (be_owner == 2);
	assign dma_pixel_ack = dma_direct_ack;
	assign dma_mem_rdata = b_rdata;
	function automatic [VSD_AW - 1:0] sv2v_cast_8110B;
		input reg [VSD_AW - 1:0] inp;
		sv2v_cast_8110B = inp;
	endfunction
	revx_vram_write_mux #(.AW(VSD_AW)) u_dma_vram_port(
		.clk(clk),
		.rst(reset),
		.cpu_reserve(((be_owner == 1) && cpu_vram) || cpu_new_vram_claim),
		.dma_claimed(dma_pixel_claimed),
		.cpu_addr(be_vd_addr),
		.cpu_data(be_vd_din),
		.cpu_be(be_vd_be),
		.cpu_rd(be_vd_rd),
		.cpu_wr(be_vd_wr),
		.cpu_ack(be_vd_ack),
		.dma_req(dma_direct),
		.dma_addr(sv2v_cast_8110B(dma_direct_pixel)),
		.dma_data(dma_pixel_data),
		.dma_count(dma_pixel_count),
		.dma_words(dma_pixel_words),
		.dma_reverse(dma_pixel_reverse),
		.dma_ack(dma_direct_ack),
		.addr(vd_addr),
		.data(vd_din),
		.be(vd_be),
		.rd(vd_rd),
		.wr(vd_wr),
		.ack(vd_ack),
		.count(vd_count),
		.words(vd_words),
		.reverse(vd_reverse)
	);
	revx_backends #(
		.SD_AW(SD_AW),
		.VSD_AW(VSD_AW),
		.ROM_SDBASE(ROM_SDBASE),
		.SRT_WRITE_CHUNKS(SRT_WRITE_CHUNKS)
	) u_be(
		.clk(clk),
		.rst(reset),
		.rst_pon(por),
		.mem_req(b_req),
		.mem_we(be_we),
		.mem_addr(be_addr),
		.mem_be(be_be),
		.mem_wdata(be_wdata),
		.mem_raw_vram(be_raw_vram),
		.mem_srt(be_srt),
		.mem_fetch(be_fetch),
		.dma_palette(be_dma_palette),
		.dma_vram_snoop_we(dma_direct_ack),
		.dma_vram_snoop_addr(dma_direct_pixel),
		.mem_rdata(b_rdata),
		.mem_ack(b_ack),
		.bulk_ram_wr(wb2_req),
		.bulk_ram_addr({8'h20, wb2_addr[19:0], 4'd0}),
		.dl_wr(dl_wr_o),
		.dl_addr(dl_addr_o),
		.dl_din(dl_din_o),
		.dl_be(dl_be_o),
		.dl_ack(dl_ack),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack),
		.vd_addr(be_vd_addr),
		.vd_din(be_vd_din),
		.vd_be(be_vd_be),
		.vd_rd(be_vd_rd),
		.vd_wr(be_vd_wr),
		.vd_dout(vd_dout),
		.vd_ack(be_vd_ack),
		.wb_req(wb_req),
		.wb_addr(wb_addr),
		.wb_count(wb_count),
		.wb_data(wb_data),
		.wb_ack(wb_ack),
		.rb_req(be_rb_req),
		.rb_addr(be_rb_addr),
		.rb_count(be_rb_count),
		.rb_dout(be_rb_dout),
		.rb_ack(be_rb_ack),
		.vlb_rb_req(be_vlb_rb_req),
		.vlb_rb_addr(be_vlb_rb_addr),
		.vlb_rb_count(be_vlb_rb_count),
		.vlb_rb_dout(be_vlb_rb_dout),
		.vlb_rb_ack(be_vlb_rb_ack),
		.vc_addr(vc_addr),
		.vc_din(vc_din),
		.vc_be(vc_be),
		.vc_rd(vc_rd),
		.vc_wr(vc_wr),
		.vc_dout(vc_dout),
		.vc_ack(vc_ack),
		.gfx_ddram_addr(gfx_ddram_addr),
		.gfx_ddram_burstcnt(gfx_ddram_burstcnt),
		.gfx_ddram_rd(gfx_ddram_rd),
		.gfx_ddram_we(gfx_ddram_we),
		.gfx_ddram_din(gfx_ddram_din),
		.gfx_ddram_be(gfx_ddram_be),
		.gfx_ddram_busy(gfx_ddram_busy),
		.gfx_ddram_dout(gfx_ddram_dout),
		.gfx_ddram_dout_ready(gfx_ddram_dout_ready),
		.gfx_dl_wr(lgfx_wr),
		.gfx_dl_addr(lgfx_addr),
		.gfx_dl_data(lgfx_data),
		.gfx_dl_ack(bgfx_ack),
		.gfx_dl_idle(bgfx_idle),
		.ioctl_download(ioctl_download),
		.ioctl_upload(ioctl_upload),
		.ioctl_wr(ioctl_wr),
		.ioctl_index(ioctl_index),
		.ioctl_addr(ioctl_addr),
		.ioctl_dout(ioctl_dout),
		.ioctl_din(ioctl_din),
		.ioctl_upload_req(ioctl_upload_req),
		.manual_save(manual_save),
		.clear_nvram(clear_nvram)
	);
	assign m_ack = (is_pal ? pal_ack : (is_io ? io_ack : cpu_b_ack));
	assign m_rdata = (is_pal ? {16'd0, pal_rd_a} : (is_io ? io_rdata : b_rdata));
	revx_memsys #(
		.IO_ONLY(1),
		.EXTERNAL_DMA(1)
	) u_periph(
		.clk(clk),
		.rst(reset),
		.mem_req(m_req & is_io),
		.mem_we(m_we),
		.mem_addr(m_addr),
		.mem_be(m_be),
		.mem_wdata(m_wdata),
		.mem_rdata(io_rdata),
		.mem_ack(io_ack),
		.in0(in0),
		.in1(in1),
		.in2(in2),
		.dsw(dsw),
		.an0(an0),
		.an1(an1),
		.an2(an2),
		.an3(an3),
		.an4(an4),
		.an5(an5),
		.dcs_ctrl(dcs_ctrl),
		.dcs_data_in(dcs_data_in),
		.dcs_output_full(dcs_output_full),
		.dcs_data_w(dcs_data_w),
		.dcs_data_o(dcs_data_o),
		.dcs_data_rd(dcs_data_rd),
		.dcs_reset(dcs_reset),
		.lint1(dcs_lint1),
		.sysctrl0(sysctrl0),
		.sysctrl1(sysctrl1),
		.cmos_write_enable(cmos_write_enable),
		.gun_recoil(gun_recoil),
		.gun_led(gun_led),
		.watchdog_kick(watchdog_kick),
		.dbg_pic_status(dbg_pic_status),
		.dbg_uart_last(dbg_uart_last),
		.dbg_adc_chan(dbg_adc_chan),
		.dbg_adc_last(dbg_adc_last),
		.dma_reg_we(dma_reg_we),
		.dma_reg_addr(dma_reg_addr),
		.dma_reg_wdata(dma_reg_wdata),
		.dma_reg_pair(dma_reg_pair),
		.dma_pair_rdata(dma_pair_rdata),
		.gfx_rd(),
		.gfx_baddr(),
		.gfx_rdata(32'd0),
		.rom_rd(),
		.rom_waddr(),
		.rom_rdata(32'd0)
	);
	assign pal_rd_data = pal_rd_b;
	assign disp_row = core_disp_row;
	assign disp_col = core_disp_col;
	assign disp_enable = core_disp_en;
	always @(posedge clk)
		if (reset) begin
			pal_ack <= 1'b0;
			pal_rd_wait <= 1'b0;
		end
		else begin
			pal_ack <= 1'b0;
			pal_rd_wait <= 1'b0;
			if (pal_rd_wait)
				pal_ack <= 1'b1;
			else if ((m_req & is_pal) & ~pal_ack) begin
				if (m_we)
					pal_ack <= 1'b1;
				else
					pal_rd_wait <= 1'b1;
			end
		end
	assign s_addr = {13'd0, scan_i0[14:1], 5'd0};
	always @(posedge clk)
		if (reset) begin
			sc <= 3'd0;
			s_active <= 1'b0;
			s_req <= 1'b0;
			scan_done <= 1'b0;
			scan_pixel <= 15'd0;
		end
		else begin
			scan_done <= 1'b0;
			case (sc)
				3'd0:
					if (scan_start) begin
						s_half <= scan_i0[0];
						s_active <= 1'b1;
						s_req <= 1'b1;
						sc <= 3'd1;
					end
				3'd1: begin
					s_req <= 1'b1;
					if (m_ack) begin
						s_req <= 1'b0;
						scan_word <= (s_half ? m_rdata[31:16] : m_rdata[15:0]);
						sc <= 3'd2;
					end
				end
				3'd2: sc <= 3'd3;
				3'd3: begin
					scan_pixel <= pal_rd_b[14:0];
					s_active <= 1'b0;
					scan_done <= 1'b1;
					sc <= 3'd4;
				end
				3'd4: sc <= 3'd0;
				default: sc <= 3'd0;
			endcase
		end
	wire [31:0] drop_prog;
	wire [31:0] drop_gfx;
	wire [31:0] drop_dcs;
	wire [31:0] drop_pic;
	revx_loader #(
		.SD_AW(SD_AW),
		.ROM_SDBASE(ROM_SDBASE)
	) u_loader(
		.clk(clk),
		.por(por),
		.core_rst(reset),
		.ioctl_download(ioctl_download),
		.ioctl_wr(ioctl_wr),
		.ioctl_index(ioctl_index),
		.ioctl_addr(ioctl_addr),
		.ioctl_dout(ioctl_dout),
		.dl_wr(dl_wr_o),
		.dl_addr(dl_addr_o),
		.dl_din(dl_din_o),
		.dl_be(dl_be_o),
		.dl_ack(dl_ack),
		.gfx_dl_wr(lgfx_wr),
		.gfx_dl_addr(lgfx_addr),
		.gfx_dl_data(lgfx_data),
		.gfx_dl_ack(bgfx_ack),
		.dcs_dl_wr(dcs_dl_wr),
		.dcs_dl_addr(dcs_dl_addr),
		.dcs_dl_data(dcs_dl_data),
		.dcs_dl_ack(dcs_dl_ack),
		.pic_rd_addr(lpic_rd_addr),
		.pic_rd_data(lpic_rd_data),
		.profile_byte(profile_byte),
		.profile_valid(profile_valid),
		.dl_wait(dl_wait),
		.dl_ready(dl_ready),
		.acc_prog(dbg_acc_prog),
		.acc_gfx(dbg_acc_gfx),
		.acc_dcs(dbg_acc_dcs),
		.acc_pic(),
		.acc_nvram(),
		.acc_profile(),
		.drop_prog(drop_prog),
		.drop_gfx(drop_gfx),
		.drop_dcs(drop_dcs),
		.drop_pic(drop_pic),
		.rst_during_dl(dbg_rst_during_dl),
		.smp_prog_addr(),
		.smp_prog_din(),
		.smp_prog_be(),
		.smp_gfx_addr(),
		.smp_gfx_data(),
		.smp_dcs_addr(),
		.smp_dcs_data()
	);
	assign dbg_drop_any = {4'd0, |drop_pic, |drop_dcs, |drop_gfx, |drop_prog};
	assign lpic_rd_addr = 13'd0;
	always @(posedge clk)
		if (reset) begin
			dbg_last_fetch_addr <= 32'd0;
			dbg_last_fetch_data <= 32'd0;
		end
		else if ((c_req & ~c_we) & c_ack) begin
			dbg_last_fetch_addr <= c_addr;
			dbg_last_fetch_data <= c_rdata;
		end
	generate
		if (QUIET_BOOT_DIAG) begin : g_no_boot_diag
			assign dbg_postcal_early = 0;
			assign dbg_postcal_final = 0;
			assign dbg_foreground_pc = 0;
			assign dbg_timers = 0;
			assign dbg_process_ptr = 0;
			assign dbg_watch_status = 0;
			assign dbg_culprit_pc = 0;
			assign dbg_culprit_instr = 0;
			assign dbg_target_pc = 0;
			assign dbg_last_good_pc = 0;
			assign dbg_derail_captured = 0;
			assign dbg_int_pc = 0;
			assign dbg_int_vec_addr = 0;
			assign dbg_int_vec_value = 0;
			assign dbg_int_count = 0;
			assign dbg_int_captured = 0;
		end
		else if (POSTCAL_DIAG) begin : g_postcal_diag
			revx_postcal_capture u_capture(
				.clk(clk),
				.rst(reset),
				.cpu_accept(cpu_retire),
				.cpu_pc(cpu_pc),
				.irq_entry(postcal_irq_begin),
				.irq_return(postcal_irq_return),
				.bus_req(c_req),
				.bus_we(c_we),
				.bus_ack(c_ack),
				.bus_fetch(c_fetch),
				.bus_addr(c_addr),
				.bus_wdata(c_wdata),
				.bus_rdata(c_rdata),
				.bus_be(c_be),
				.early_sample(dbg_postcal_early),
				.final_sample(dbg_postcal_final)
			);
			assign dbg_foreground_pc = 0;
			assign dbg_timers = 0;
			assign dbg_process_ptr = 0;
			assign dbg_watch_status = 0;
			assign dbg_culprit_pc = 0;
			assign dbg_culprit_instr = 0;
			assign dbg_target_pc = 0;
			assign dbg_last_good_pc = 0;
			assign dbg_derail_captured = 0;
			assign dbg_int_pc = 0;
			assign dbg_int_vec_addr = 0;
			assign dbg_int_vec_value = 0;
			assign dbg_int_count = 0;
			assign dbg_int_captured = 0;
		end
		else begin : g_legacy_diag
			assign dbg_postcal_early = 0;
			assign dbg_postcal_final = 0;
			revx_timer_capture u_timer_capture(
				.clk(clk),
				.rst(reset),
				.cpu_retire(cpu_retire),
				.cpu_pc(cpu_pc),
				.bus_req(c_req),
				.bus_we(c_we),
				.bus_ack(c_ack),
				.bus_addr(c_addr),
				.bus_wdata(c_wdata),
				.bus_be(c_be),
				.foreground_pc(dbg_foreground_pc),
				.timers(dbg_timers),
				.process_ptr(dbg_process_ptr),
				.watch_status(dbg_watch_status)
			);
			revx_derail_capture u_derail(
				.clk(clk),
				.rst(reset),
				.cpu_retire(cpu_retire),
				.cpu_pc(cpu_pc),
				.cpu_instr(cpu_instr),
				.int_entry(cdbg_int_entry),
				.int_pc(cdbg_int_pc),
				.int_vec_addr(cdbg_int_vec_addr),
				.int_vec_value(cdbg_int_vec_value),
				.culprit_pc(dbg_culprit_pc),
				.culprit_instr(dbg_culprit_instr),
				.target_pc(dbg_target_pc),
				.last_good_pc(dbg_last_good_pc),
				.derail_captured(dbg_derail_captured),
				.int_interrupted_pc(dbg_int_pc),
				.int_vec_addr_q(dbg_int_vec_addr),
				.int_vec_value_q(dbg_int_vec_value),
				.int_count(dbg_int_count),
				.int_captured(dbg_int_captured)
			);
		end
	endgenerate
	assign dbg_intpend = cdbg_intpend;
	assign dbg_intenb = cdbg_intenb;
	assign dbg_disp_int = cdbg_disp_int;
	assign dbg_st_ie = cdbg_st_ie;
endmodule
`default_nettype wire
module revx_dcs_mem (
	clk,
	rst,
	core_ce,
	rom_req,
	rom_boot,
	rom_addr,
	rom_rdy,
	rom_q,
	ext_req,
	ext_addr,
	ext_rdy,
	ext_q
);
	parameter DDR_LATENCY = 8;
	parameter PF_LINES = 512;
	parameter EXT_ROM = 1;
	parameter CORE_CE_EN = 0;
	input wire clk;
	input wire rst;
	input wire core_ce;
	input wire rom_req;
	input wire rom_boot;
	input wire [22:0] rom_addr;
	output wire rom_rdy;
	output wire [7:0] rom_q;
	output wire ext_req;
	output wire [19:0] ext_addr;
	input wire ext_rdy;
	input wire [63:0] ext_q;
	function [7:0] rom_byte;
		input [22:0] idx;
		rom_byte = idx[7:0];
	endfunction
	localparam IDXW = $clog2(PF_LINES);
	localparam TAGW = 20 - IDXW;
	(* ramstyle = "M10K" *) reg [63:0] pf_data [0:PF_LINES - 1];
	(* ramstyle = "M10K" *) reg [TAGW - 1:0] pf_tag [0:PF_LINES - 1];
	reg pf_valid [0:PF_LINES - 1];
	localparam [2:0] R_IDLE = 3'd0;
	localparam [2:0] R_ADDR = 3'd1;
	localparam [2:0] R_LOOK = 3'd2;
	localparam [2:0] R_FILL = 3'd3;
	localparam [2:0] R_SERVE = 3'd4;
	reg [2:0] rstate = R_IDLE;
	reg [22:0] srv_addr;
	reg srv_boot;
	reg [7:0] srv_byte;
	reg [15:0] ddr_cnt;
	reg [63:0] ddr_beat;
	integer k;
	integer romfd;
	reg [63:0] pfd_q;
	reg [TAGW - 1:0] pft_q;
	reg pfv_q;
	reg ext_rsp_valid;
	reg [63:0] ext_rsp_q;
	wire mem_ce = (CORE_CE_EN != 0 ? core_ce : 1'b1);
	wire [IDXW - 1:0] req_idx = rom_addr[3+:IDXW];
	wire [TAGW - 1:0] req_tag = rom_addr[22-:TAGW];
	wire [IDXW - 1:0] srv_idx = srv_addr[3+:IDXW];
	wire [TAGW - 1:0] srv_tag = srv_addr[22-:TAGW];
	assign ext_req = ((EXT_ROM != 0) && (rstate == R_FILL)) && !ext_rsp_valid;
	assign ext_addr = srv_addr[22:3];
	assign rom_rdy = ((rstate == R_SERVE) && rom_req) && (rom_addr == srv_addr);
	assign rom_q = srv_byte;
	always @(posedge clk)
		if (mem_ce) begin
			pfd_q <= pf_data[srv_idx];
			pft_q <= pf_tag[srv_idx];
			pfv_q <= pf_valid[srv_idx];
		end
	always @(posedge clk)
		if (rst) begin
			ext_rsp_valid <= 1'b0;
			ext_rsp_q <= 64'd0;
		end
		else if ((((EXT_ROM != 0) && ext_rdy) && (rstate == R_FILL)) && !ext_rsp_valid) begin
			ext_rsp_valid <= 1'b1;
			ext_rsp_q <= ext_q;
		end
		else if ((mem_ce && (rstate == R_FILL)) && ext_rsp_valid)
			ext_rsp_valid <= 1'b0;
	integer pf_hits_w = 0;
	integer pf_miss_w = 0;
	integer pf_hits_b = 0;
	integer pf_miss_b = 0;
	function [63:0] ddr_beat_fn;
		input [22:0] a;
		integer bi;
		for (bi = 0; bi < 8; bi = bi + 1)
			ddr_beat_fn[8 * bi+:8] = rom_byte({a[22:3], 3'b000} + bi[22:0]);
	endfunction
	always @(posedge clk)
		if (rst) begin
			rstate <= R_IDLE;
			ddr_cnt <= 16'd0;
			for (k = 0; k < PF_LINES; k = k + 1)
				pf_valid[k] <= 1'b0;
		end
		else if (mem_ce)
			case (rstate)
				R_IDLE:
					if (rom_req) begin
						srv_addr <= rom_addr;
						srv_boot <= rom_boot;
						rstate <= R_ADDR;
					end
				R_ADDR: rstate <= R_LOOK;
				R_LOOK:
					if (pfv_q && (pft_q == srv_tag)) begin
						srv_byte <= pfd_q[8 * srv_addr[2:0]+:8];
						rstate <= R_SERVE;
					end
					else begin
						if (EXT_ROM == 0)
							ddr_cnt <= DDR_LATENCY[15:0];
						rstate <= R_FILL;
					end
				R_FILL:
					if (((EXT_ROM == 0) && (ddr_cnt <= 16'd1)) || ((EXT_ROM != 0) && ext_rsp_valid)) begin
						ddr_beat = (EXT_ROM != 0 ? ext_rsp_q : ddr_beat_fn(srv_addr));
						pf_data[srv_idx] <= ddr_beat;
						pf_tag[srv_idx] <= srv_tag;
						pf_valid[srv_idx] <= 1'b1;
						srv_byte <= ddr_beat[8 * srv_addr[2:0]+:8];
						rstate <= R_SERVE;
					end
					else if (EXT_ROM == 0)
						ddr_cnt <= ddr_cnt - 16'd1;
				R_SERVE:
					if (!rom_req)
						rstate <= R_IDLE;
					else if (rom_addr != srv_addr) begin
						srv_addr <= rom_addr;
						srv_boot <= rom_boot;
						rstate <= R_ADDR;
					end
			endcase
endmodule
module revx_adsp2105 (
	clk,
	rst,
	core_ce,
	host_rst,
	music_attenuation,
	sfx_attenuation,
	host_cmd_w,
	host_cmd_data,
	host_status_r,
	host_response_r,
	host_resp_rd,
	rom_ddr_req,
	rom_ddr_addr,
	rom_ddr_rdy,
	rom_ddr_q,
	dac_ce_in,
	o_ppc,
	o_valid,
	o_unimpl,
	dac_sample,
	dac_ce,
	audio_underrun,
	audio_overrun
);
	reg _sv2v_0;
	parameter PMFILE = "pm.hex";
	parameter RD_LATENCY = 1;
	parameter DDR_LATENCY = 8;
	parameter PF_LINES = 512;
	parameter DCS_2K = 1;
	parameter DCS_UART = 0;
	parameter REVX_MIXER_GAIN = 0;
	parameter EXT_ROM = 1;
	parameter PRELOAD_PM = 0;
	parameter CORE_CE_EN = 0;
	input wire clk;
	input wire rst;
	input wire core_ce;
	input wire host_rst;
	input wire [3:0] music_attenuation;
	input wire [3:0] sfx_attenuation;
	input wire host_cmd_w;
	input wire [15:0] host_cmd_data;
	output wire [15:0] host_status_r;
	output wire [15:0] host_response_r;
	input wire host_resp_rd;
	output wire rom_ddr_req;
	output wire [19:0] rom_ddr_addr;
	input wire rom_ddr_rdy;
	input wire [63:0] rom_ddr_q;
	input wire dac_ce_in;
	output reg [13:0] o_ppc;
	output reg o_valid;
	output reg o_unimpl;
	output reg [15:0] dac_sample;
	output reg dac_ce;
	output reg audio_underrun;
	output reg audio_overrun;
	reg [15:0] gr [0:31];
	wire cpu_ce = (CORE_CE_EN != 0 ? core_ce : 1'b1);
	reg [15:0] iR [0:7];
	reg [15:0] mR [0:7];
	reg [15:0] lR [0:7];
	reg [13:0] baseR [0:7];
	reg [13:0] lmask [0:7];
	reg [15:0] astat;
	reg [15:0] mstat;
	reg [15:0] sstat;
	reg [15:0] imask;
	reg [15:0] icntl;
	reg [15:0] px;
	reg flagout;
	reg fl0;
	reg fl1;
	reg fl2;
	reg idle_cpu;
	reg [15:0] afb [0:1];
	reg [15:0] mfb [0:1];
	reg [15:0] sbb [0:1];
	reg [15:0] mrzb [0:1];
	wire bnk = mstat[0];
	reg [13:0] cntr;
	reg [10:0] data_bank;
	(* ramstyle = "M10K" *) reg [23:0] pm [0:16383];
	(* ramstyle = "M10K" *) reg [23:0] pm2 [0:16383];
	(* ramstyle = "M10K" *) reg [15:0] dm [0:16383];
	reg pm_we;
	reg [13:0] pm_wa;
	reg [23:0] pm_wd;
	function [13:0] pm_phys_addr;
		input [13:0] a;
		if (((DCS_2K != 0) && (a >= 14'h0800)) && (a <= 14'h1fff))
			pm_phys_addr = 14'h0800 | {3'b000, a[10:0]};
		else
			pm_phys_addr = a;
	endfunction
	function [13:0] dm_alias_phys_addr;
		input [13:0] a;
		if (DCS_2K != 0)
			dm_alias_phys_addr = 14'h0800 | {3'b000, a[10:0]};
		else
			dm_alias_phys_addr = pm_phys_addr(a);
	endfunction
	reg [13:0] pc;
	wire [13:0] fetch_addr = pm_phys_addr(pc);
	reg [23:0] fetch_r;
	wire [23:0] fetch_q = fetch_r;
	wire [13:0] pmb_addr;
	reg [23:0] pmb_q;
	wire [13:0] dm_addr;
	reg [15:0] dm_q;
	always @(posedge clk)
		if (cpu_ce) begin
			fetch_r <= pm[fetch_addr];
			pmb_q <= pm2[pmb_addr];
			dm_q <= dm[dm_addr];
		end
	wire rom_req;
	wire [22:0] rom_addr;
	wire rom_rdy;
	wire [7:0] rom_q;
	reg boot_active;
	reg [11:0] boot_idx;
	reg [11:0] boot_plen;
	reg [10:0] boot_bank;
	reg [1:0] boot_phase;
	reg [7:0] boot_b0;
	reg [7:0] boot_b1;
	revx_dcs_mem #(
		.DDR_LATENCY(DDR_LATENCY),
		.PF_LINES(PF_LINES),
		.EXT_ROM(EXT_ROM),
		.CORE_CE_EN(CORE_CE_EN)
	) u_mem(
		.clk(clk),
		.rst(rst),
		.core_ce(cpu_ce),
		.rom_req(rom_req),
		.rom_boot(boot_active),
		.rom_addr(rom_addr),
		.rom_rdy(rom_rdy),
		.rom_q(rom_q),
		.ext_req(rom_ddr_req),
		.ext_addr(rom_ddr_addr),
		.ext_rdy(rom_ddr_rdy),
		.ext_q(rom_ddr_q)
	);
	function [7:0] snd_byte;
		input [22:0] idx;
		snd_byte = 8'hff;
	endfunction
	localparam [2:0] S_BOOT = 3'd0;
	localparam [2:0] S_FETCH = 3'd1;
	localparam [2:0] S_DECODE = 3'd2;
	localparam [2:0] S_DRAIN = 3'd3;
	localparam [2:0] S_DIV = 3'd4;
	localparam [2:0] S_ROM = 3'd5;
	localparam [2:0] S_MEM = 3'd6;
	localparam [2:0] S_EXEC = 3'd7;
	reg [2:0] state;
	reg [13:0] loop_end [0:3];
	reg [3:0] loop_cond [0:3];
	reg [2:0] loop_sp;
	reg [13:0] pc_stack [0:15];
	reg [4:0] pc_sp;
	reg [13:0] cntr_stack [0:3];
	reg [2:0] cntr_sp;
	reg host_rst_r;
	reg reboot_pending;
	reg [10:0] reboot_bank;
	reg [15:0] stat_mstat [0:3];
	reg [15:0] stat_imask [0:3];
	reg [15:0] stat_astat [0:3];
	reg [2:0] stat_sp;
	reg [8:0] tim_scale;
	reg [15:0] tim_count;
	reg [15:0] tim_period;
	reg [8:0] tim_scale_cnt;
	reg tim_irq_latch;
	reg ab_active;
	reg [2:0] ab_ireg;
	reg [15:0] ab_base;
	reg [15:0] ab_size;
	reg [15:0] ab_incs;
	reg [15:0] dac_slot_ctr;
	reg dac_slot_go;
	reg drain_idle_only;
	reg [15:0] ab_cfg;
	integer ab_ir;
	integer ab_mr;
	integer ab_lr;
	integer ab_cnt;
	integer ab_reg;
	reg [15:0] input_data;
	reg irq2_line;
	reg irq2_latch;
	reg [15:0] latch_control;
	reg [15:0] output_data;
	assign host_status_r = latch_control;
	assign host_response_r = output_data;
	reg irq1_pulse;
	integer ab_i;
	reg [15:0] ab_smp;
	(* ramstyle = "no_rw_check, M10K" *) reg [15:0] dac_emit_burst [0:511];
	reg [9:0] dac_burst_len;
	reg [8:0] dac_play_idx;
	reg dac_play_active;
	reg audio_started;
	localparam [13:0] NO_LOOP = 14'h3fff;
	reg [15:0] ctl_s1_autobuf;
	reg [15:0] ctl_syscontrol;
	localparam [2:0] RG_DM = 3'd0;
	localparam [2:0] RG_ALIAS = 3'd1;
	localparam [2:0] RG_BANK = 3'd2;
	localparam [2:0] RG_LATCH = 3'd3;
	localparam [2:0] RG_OPEN = 3'd4;
	function [2:0] dm_region;
		input [15:0] a;
		if (DCS_2K != 0) begin
			if (a <= 16'h1fff)
				dm_region = RG_ALIAS;
			else if ((a >= 16'h2000) && (a <= 16'h2fff))
				dm_region = RG_BANK;
			else if ((DCS_UART && (a == 16'h3403)) || ((!DCS_UART && (a >= 16'h3400)) && (a <= 16'h37ff)))
				dm_region = RG_LATCH;
			else if (((a >= 16'h3800) && (a <= 16'h39ff)) || ((a >= 16'h3fe0) && (a <= 16'h3fff)))
				dm_region = RG_DM;
			else
				dm_region = RG_OPEN;
		end
		else if ((a >= 16'h0800) && (a <= 16'h1fff))
			dm_region = RG_ALIAS;
		else if ((a >= 16'h2000) && (a <= 16'h2fff))
			dm_region = RG_BANK;
		else if ((a >= 16'h3400) && (a <= 16'h3403))
			dm_region = RG_LATCH;
		else
			dm_region = RG_DM;
	endfunction
	reg pre_dm_rd;
	reg pre_dm_wr;
	reg pre_pm_rd;
	reg [15:0] pre_addr;
	reg [13:0] pre_pm_addr;
	function [13:0] rev14;
		input [13:0] a;
		integer j;
		for (j = 0; j < 14; j = j + 1)
			rev14[j] = a[13 - j];
	endfunction
	function [15:0] dag_addr;
		input [2:0] w;
		if (!w[2] && mstat[1])
			dag_addr = {2'b00, rev14(iR[w][13:0])};
		else
			dag_addr = iR[w];
	endfunction
	always @(*) begin
		pre_dm_rd = 1'b0;
		pre_dm_wr = 1'b0;
		pre_pm_rd = 1'b0;
		pre_addr = 16'h0000;
		pre_pm_addr = 14'h0000;
		casez (fetch_q[23:16])
			8'h11:
				if (!fetch_q[15]) begin
					pre_pm_rd = 1'b1;
					pre_pm_addr = iR[{1'b1, fetch_q[3:2]}][13:0];
				end
			8'h12, 8'h13: begin
				pre_addr = dag_addr({fetch_q[16], fetch_q[3:2]});
				if (fetch_q[15])
					pre_dm_wr = 1'b1;
				else
					pre_dm_rd = 1'b1;
			end
			8'b0101zzzz:
				if (!fetch_q[19]) begin
					pre_pm_rd = 1'b1;
					pre_pm_addr = iR[{1'b1, fetch_q[3:2]}][13:0];
				end
			8'b011zzzzz: begin
				pre_addr = dag_addr({fetch_q[20], fetch_q[3:2]});
				if (fetch_q[19])
					pre_dm_wr = 1'b1;
				else
					pre_dm_rd = 1'b1;
			end
			8'b100zzzzz: begin
				pre_addr = {2'b00, fetch_q[17:4]};
				if (fetch_q[20])
					pre_dm_wr = 1'b1;
				else
					pre_dm_rd = 1'b1;
			end
			8'b101zzzzz: begin
				pre_addr = dag_addr({fetch_q[20], fetch_q[3:2]});
				pre_dm_wr = 1'b1;
			end
			8'b11zzzzzz: begin
				pre_dm_rd = 1'b1;
				pre_addr = dag_addr({1'b0, fetch_q[3:2]});
				pre_pm_rd = 1'b1;
				pre_pm_addr = iR[{1'b1, fetch_q[7:6]}][13:0];
			end
			default:
				;
		endcase
	end
	wire [2:0] pre_region = dm_region(pre_addr);
	wire pre_bank_rd = pre_dm_rd && (pre_region == RG_BANK);
	wire [1:0] mem_need = ((((pre_dm_rd && (pre_region != RG_LATCH)) && (pre_region != RG_BANK)) || (pre_dm_wr && (pre_region == RG_ALIAS))) || pre_pm_rd ? 2'd1 : 2'd0);
	reg [23:0] op_r;
	reg [15:0] ea_addr_r;
	reg [13:0] pm_addr_r;
	reg pm_rd_r;
	reg bank_rd_r;
	reg tx1_r;
	reg [1:0] mem_need_r;
	wire pre_tx1_wr = ((((fetch_q[23:16] == 8'h0d) && (fetch_q[11:10] == 2'd3)) && (fetch_q[7:4] == 4'hb)) || (((fetch_q[23:20] == 4'h3) && (fetch_q[19:18] == 2'd3)) && (fetch_q[3:0] == 4'hb))) || ((((fetch_q[23:21] == 3'b100) && !fetch_q[20]) && (fetch_q[19:18] == 2'd3)) && (fetch_q[3:0] == 4'hb));
	wire [2:0] pre_ab_lr = ctl_s1_autobuf[11:9];
	wire [2:0] pre_ab_mr = {ctl_s1_autobuf[11], ctl_s1_autobuf[8:7]};
	wire [15:0] pre_ab_incs = (mR[pre_ab_mr] == 16'h0000 ? 16'h0001 : mR[pre_ab_mr]);
	reg div_done;
	reg [4:0] div_i;
	reg [15:0] div_q;
	reg [15:0] div_nd;
	reg [16:0] div_rem;
	reg [16:0] div_v;
	reg [17:0] div_t;
	reg [15:0] ab_drain_cnt;
	reg dr_done;
	integer dr_idx;
	integer dr_acc;
	integer dr_cnt;
	reg [2:0] dr_region;
	reg [22:0] dr_rom_a;
	reg [15:0] dr_smp;
	wire drain_pend = ab_active && dac_slot_go;
	wire [31:0] dr_cur = (dr_idx == 0 ? {16'h0000, iR[ab_ireg]} : dr_acc);
	wire [13:0] pmb_logical_addr = (state == S_DRAIN ? dr_cur[13:0] : (pm_rd_r ? pm_addr_r : ea_addr_r[13:0]));
	wire pmb_dm_alias = (state == S_DRAIN ? dr_region == RG_ALIAS : !pm_rd_r && (dm_region(ea_addr_r) == RG_ALIAS));
	assign pmb_addr = (pmb_dm_alias ? dm_alias_phys_addr(pmb_logical_addr) : pm_phys_addr(pmb_logical_addr));
	assign dm_addr = (state == S_DRAIN ? dr_cur[13:0] : ea_addr_r[13:0]);
	wire [23:0] boot_rom_base = {13'h0000, boot_bank} << 12;
	wire [23:0] boot_rom_addr24 = (boot_phase == 2'd0 ? boot_rom_base + 24'd3 : (boot_rom_base + ({12'h000, boot_idx} << 2)) + {22'h000000, boot_phase - 2'd1});
	assign rom_addr = (boot_active ? boot_rom_addr24[22:0] : (state == S_DECODE ? {data_bank, 12'h000} + {11'h000, pre_addr[11:0]} : {data_bank, 12'h000} + {11'h000, ea_addr_r[11:0]}));
	assign rom_req = (boot_active | ((state == S_DECODE) && pre_bank_rd)) | ((((((state == S_DRAIN) || (state == S_DIV)) || (state == S_ROM)) || (state == S_MEM)) || (state == S_EXEC)) && bank_rd_r);
	function automatic integer cond_true;
		input [3:0] c;
		reg az;
		reg an;
		reg av;
		reg ac;
		reg as;
		reg mv;
		begin
			az = astat[0];
			an = astat[1];
			av = astat[2];
			ac = astat[3];
			as = astat[4];
			mv = astat[6];
			case (c)
				4'h0: cond_true = az;
				4'h1: cond_true = !az;
				4'h2: cond_true = !((an ^ av) | az);
				4'h3: cond_true = (an ^ av) | az;
				4'h4: cond_true = an ^ av;
				4'h5: cond_true = !(an ^ av);
				4'h6: cond_true = av;
				4'h7: cond_true = !av;
				4'h8: cond_true = ac;
				4'h9: cond_true = !ac;
				4'ha: cond_true = as;
				4'hb: cond_true = !as;
				4'hc: cond_true = mv;
				4'hd: cond_true = !mv;
				4'he: cond_true = 1'bx;
				4'hf: cond_true = 1'b1;
			endcase
		end
	endfunction
	task automatic cond_eval;
		input [3:0] c;
		output reg ct;
		if (c == 4'hf)
			ct = 1'b1;
		else if (c == 4'he) begin
			if (($signed({1'b0, cntr}) - 1) > 0) begin
				cntr <= cntr - 1'b1;
				ct = 1'b1;
			end
			else begin
				if (cntr_sp != 0) begin
					cntr <= cntr_stack[cntr_sp - 1];
					cntr_sp <= cntr_sp - 1'b1;
					if (cntr_sp == 1)
						sstat <= sstat | 16'h0004;
				end
				else
					cntr <= cntr_stack[0];
				ct = 1'b0;
			end
		end
		else
			ct = (cond_true(c) ? 1'b1 : 1'b0);
	endtask
	function [13:0] mask_fn;
		input [13:0] l;
		if (l > 14'h2000)
			mask_fn = 14'h0000;
		else if (l > 14'h1000)
			mask_fn = 14'h2000;
		else if (l > 14'h0800)
			mask_fn = 14'h3000;
		else if (l > 14'h0400)
			mask_fn = 14'h3800;
		else if (l > 14'h0200)
			mask_fn = 14'h3c00;
		else if (l > 14'h0100)
			mask_fn = 14'h3e00;
		else if (l > 14'h0080)
			mask_fn = 14'h3f00;
		else if (l > 14'h0040)
			mask_fn = 14'h3f80;
		else if (l > 14'h0020)
			mask_fn = 14'h3fc0;
		else if (l > 14'h0010)
			mask_fn = 14'h3fe0;
		else if (l > 14'h0008)
			mask_fn = 14'h3ff0;
		else if (l > 14'h0004)
			mask_fn = 14'h3ff8;
		else if (l > 14'h0002)
			mask_fn = 14'h3ffc;
		else if (l > 14'h0001)
			mask_fn = 14'h3ffe;
		else
			mask_fn = 14'h3fff;
	endfunction
	task automatic wr_ireg;
		input [2:0] w;
		input [15:0] val;
		begin
			iR[w] <= val;
			baseR[w] <= val[13:0] & lmask[w];
		end
	endtask
	task automatic wr_lreg;
		input [2:0] w;
		input [15:0] val;
		begin
			lR[w] <= val;
			lmask[w] <= mask_fn(val[13:0]);
			baseR[w] <= iR[w][13:0] & mask_fn(val[13:0]);
		end
	endtask
	task automatic dag_modify;
		input [2:0] w;
		input [2:0] m;
		reg [13:0] i2;
		begin
			i2 = (iR[w][13:0] + mR[m][13:0]) & 14'h3fff;
			if (i2 < baseR[w])
				i2 = i2 + lR[w][13:0];
			else if (i2 >= (baseR[w] + lR[w][13:0]))
				i2 = i2 - lR[w][13:0];
			iR[w] <= {2'b00, i2};
		end
	endtask
	task automatic set_mstat;
		input [15:0] nm;
		mstat <= nm;
	endtask
	task automatic wr_reg;
		input [1:0] grp;
		input [3:0] idx;
		input [15:0] val;
		case (grp)
			2'd0:
				case (idx)
					4'h9: gr[{bnk, 4'b0000} + 9] <= {{8 {val[7]}}, val[7:0]};
					4'hc: begin
						gr[{bnk, 4'b0000} + 12] <= val;
						gr[{bnk, 4'b0000} + 13] <= {16 {val[15]}};
					end
					4'hd: gr[{bnk, 4'b0000} + 13] <= {{8 {val[7]}}, val[7:0]};
					default: gr[{bnk, 4'b0000} + idx] <= val;
				endcase
			2'd1:
				case (idx)
					4'd0, 4'd1, 4'd2, 4'd3:
						wr_ireg(idx[2:0], {2'b00, val[13:0]});
					4'd4, 4'd5, 4'd6, 4'd7: mR[idx - 4] <= {{2 {val[13]}}, val[13:0]};
					4'd8, 4'd9, 4'd10, 4'd11:
						wr_lreg(idx[2:0], {2'b00, val[13:0]});
					default:
						;
				endcase
			2'd2:
				case (idx)
					4'd0, 4'd1, 4'd2, 4'd3:
						wr_ireg(idx[2:0] + 3'd4, {2'b00, val[13:0]});
					4'd4, 4'd5, 4'd6, 4'd7: mR[idx] <= {{2 {val[13]}}, val[13:0]};
					4'd8, 4'd9, 4'd10, 4'd11:
						wr_lreg(idx[2:0] + 3'd4, {2'b00, val[13:0]});
					default:
						;
				endcase
			2'd3:
				case (idx)
					4'd0: astat <= val;
					4'd1:
						set_mstat(val);
					4'd2:
						;
					4'd3: imask <= val;
					4'd4: icntl <= val;
					4'd5: begin
						if (cntr_sp < 4) begin
							cntr_stack[cntr_sp] <= cntr;
							cntr_sp <= cntr_sp + 1'b1;
							sstat <= sstat & ~16'h0004;
						end
						else
							sstat <= sstat | 16'h0008;
						cntr <= val[13:0];
					end
					4'd6: sbb[bnk] <= val;
					4'd7: px <= val;
					4'hd: cntr <= val[13:0];
					4'hf:
						if (pc_sp < 16) begin
							pc_stack[pc_sp] <= val[13:0];
							pc_sp <= pc_sp + 1'b1;
							sstat <= sstat & ~16'h0001;
						end
						else
							sstat <= sstat | 16'h0002;
					4'hb: begin
						ab_cfg = ctl_s1_autobuf;
						if ((ctl_syscontrol & 16'h0800) && (ab_cfg & 16'h0002)) begin
							ab_ir = (ab_cfg >> 9) & 7;
							ab_mr = ((ab_cfg >> 7) & 3) | (((ab_cfg >> 9) & 7) & 4);
							ab_lr = (ab_cfg >> 9) & 7;
							iR[ab_ir] <= iR[ab_ir] & 16'hfff0;
							baseR[ab_ir] <= (iR[ab_ir][13:0] & 14'h3ff0) & lmask[ab_ir];
							ab_base <= iR[ab_ir] & 16'hfff0;
							ab_size <= lR[ab_lr];
							ab_incs <= mR[ab_mr];
							ab_ireg <= ab_ir[2:0];
							ab_cnt = div_q;
							ab_drain_cnt <= div_q;
							dac_slot_ctr <= ab_cnt[15:0];
							dac_slot_go <= 1'b0;
							ab_active <= 1'b1;
						end
					end
					default:
						;
				endcase
		endcase
	endtask
	function automatic [15:0] rd_reg;
		input [1:0] grp;
		input [3:0] idx;
		case (grp)
			2'd0: rd_reg = gr[{bnk, 4'b0000} + idx];
			2'd1:
				case (idx)
					4'd0, 4'd1, 4'd2, 4'd3: rd_reg = iR[idx];
					4'd4, 4'd5, 4'd6, 4'd7: rd_reg = mR[idx - 4];
					4'd8, 4'd9, 4'd10, 4'd11: rd_reg = lR[idx - 8];
					default: rd_reg = 16'h0000;
				endcase
			2'd2:
				case (idx)
					4'd0, 4'd1, 4'd2, 4'd3: rd_reg = iR[idx + 4];
					4'd4, 4'd5, 4'd6, 4'd7: rd_reg = mR[idx];
					4'd8, 4'd9, 4'd10, 4'd11: rd_reg = lR[idx - 4];
					default: rd_reg = 16'h0000;
				endcase
			2'd3:
				case (idx)
					4'd0: rd_reg = astat;
					4'd1: rd_reg = mstat;
					4'd2: rd_reg = sstat;
					4'd3: rd_reg = imask;
					4'd4: rd_reg = icntl;
					4'd5: rd_reg = {2'b00, cntr};
					4'd6: rd_reg = sbb[bnk];
					4'd7: rd_reg = px;
					default: rd_reg = 16'h0000;
				endcase
		endcase
	endfunction
	function [15:0] alu_xread;
		input [2:0] xi;
		case (xi)
			3'd0: alu_xread = gr[{bnk, 4'b0000} + 0];
			3'd1: alu_xread = gr[{bnk, 4'b0000} + 1];
			3'd2: alu_xread = gr[{bnk, 4'b0000} + 10];
			3'd3: alu_xread = gr[{bnk, 4'b0000} + 11];
			3'd4: alu_xread = gr[{bnk, 4'b0000} + 12];
			3'd5: alu_xread = gr[{bnk, 4'b0000} + 13];
			3'd6: alu_xread = gr[{bnk, 4'b0000} + 14];
			3'd7: alu_xread = gr[{bnk, 4'b0000} + 15];
		endcase
	endfunction
	function [15:0] alu_yread;
		input [1:0] yi;
		case (yi)
			2'd0: alu_yread = gr[{bnk, 4'b0000} + 4];
			2'd1: alu_yread = gr[{bnk, 4'b0000} + 5];
			2'd2: alu_yread = afb[bnk];
			2'd3: alu_yread = 16'h0000;
		endcase
	endfunction
	function [15:0] c_nz;
		input [15:0] a;
		input [31:0] r;
		begin
			c_nz = a;
			if ((r & 32'h0000ffff) == 0)
				c_nz = c_nz | 16'h0001;
			c_nz = c_nz | ((r >> 14) & 16'h0002);
		end
	endfunction
	function [15:0] c_v;
		input [15:0] a;
		input [31:0] s;
		input [31:0] d;
		input [31:0] r;
		c_v = a | (((((s ^ d) ^ r) ^ (r >> 1)) >> 13) & 16'h0004);
	endfunction
	function automatic [31:0] alu_eval;
		input [3:0] sub;
		input [15:0] xv;
		input [15:0] yv;
		reg [16:0] r;
		reg [15:0] astn;
		reg cin;
		reg [31:0] s32;
		reg [31:0] d32;
		reg [31:0] r32;
		begin
			cin = astat[3];
			astn = astat & ~16'h000f;
			case (sub)
				4'h0: r = {1'b0, yv};
				4'h1: r = {1'b0, yv} + 17'd1;
				4'h2: r = ({1'b0, xv} + {1'b0, yv}) + {16'h0000, cin};
				4'h3: r = {1'b0, xv} + {1'b0, yv};
				4'h4: r = {1'b0, ~yv};
				4'h5: r = 17'h00000 - {1'b0, yv};
				4'h6: r = (({1'b0, xv} - {1'b0, yv}) + {16'h0000, cin}) - 17'd1;
				4'h7: r = {1'b0, xv} - {1'b0, yv};
				4'h8: r = {1'b0, yv} - 17'd1;
				4'h9: r = {1'b0, yv} - {1'b0, xv};
				4'ha: r = (({1'b0, yv} - {1'b0, xv}) + {16'h0000, cin}) - 17'd1;
				4'hb: r = {1'b0, ~xv};
				4'hc: r = {1'b0, xv & yv};
				4'hd: r = {1'b0, xv | yv};
				4'he: r = {1'b0, xv ^ yv};
				4'hf: r = (xv[15] ? 17'h00000 - {1'b0, xv} : {1'b0, xv});
			endcase
			astn = c_nz(astn, {15'h0000, r});
			s32 = {16'h0000, xv};
			d32 = {16'h0000, yv};
			r32 = {15'h0000, r};
			case (sub)
				4'h2, 4'h3: begin
					astn = c_v(astn, s32, d32, r32);
					astn = astn | ((r32 >> 13) & 16'h0008);
				end
				4'h6, 4'h7: begin
					astn = c_v(astn, s32, d32, r32);
					astn = astn | ((~r32 >> 13) & 16'h0008);
				end
				4'h9, 4'ha: begin
					astn = c_v(astn, d32, s32, r32);
					astn = astn | ((~r32 >> 13) & 16'h0008);
				end
				4'h1:
					if (yv == 16'h7fff)
						astn = astn | 16'h0004;
					else if (yv == 16'hffff)
						astn = astn | 16'h0008;
				4'h5: begin
					if (yv == 16'h8000)
						astn = astn | 16'h0004;
					if (yv == 16'h0000)
						astn = astn | 16'h0008;
				end
				4'h8:
					if (yv == 16'h8000)
						astn = astn | 16'h0004;
					else if (yv == 16'h0000)
						astn = astn | 16'h0008;
				4'hf: begin
					astn = astat & ~16'h001f;
					if (xv == 16'h0000)
						astn = astn | 16'h0001;
					if (xv == 16'h8000)
						astn = astn | 16'h0006;
					if (xv[15])
						astn = astn | 16'h0010;
				end
				default:
					;
			endcase
			alu_eval = {astn, r[15:0]};
		end
	endfunction
	function [15:0] mac_xread;
		input [2:0] xi;
		case (xi)
			3'd0: mac_xread = gr[{bnk, 4'b0000} + 2];
			3'd1: mac_xread = gr[{bnk, 4'b0000} + 3];
			3'd2: mac_xread = gr[{bnk, 4'b0000} + 10];
			3'd3: mac_xread = gr[{bnk, 4'b0000} + 11];
			3'd4: mac_xread = gr[{bnk, 4'b0000} + 12];
			3'd5: mac_xread = gr[{bnk, 4'b0000} + 13];
			3'd6: mac_xread = gr[{bnk, 4'b0000} + 14];
			3'd7: mac_xread = gr[{bnk, 4'b0000} + 15];
		endcase
	endfunction
	function [15:0] mac_yread;
		input [1:0] yi;
		case (yi)
			2'd0: mac_yread = gr[{bnk, 4'b0000} + 6];
			2'd1: mac_yread = gr[{bnk, 4'b0000} + 7];
			2'd2: mac_yread = mfb[bnk];
			2'd3: mac_yread = 16'h0000;
		endcase
	endfunction
	function automatic [63:0] mac_r64_f;
		input [23:0] opc;
		input [3:0] sub;
		reg [15:0] xv;
		reg [15:0] yv;
		reg xs;
		reg ys;
		reg [1:0] acc;
		reg rnd;
		reg sh;
		reg signed [31:0] xe;
		reg signed [31:0] ye;
		reg signed [31:0] p32;
		reg signed [63:0] prod;
		reg signed [63:0] r;
		reg signed [63:0] mrold;
		begin
			r = 64'sh0000000000000000;
			if (sub != 4'h0) begin
				xv = mac_xread(opc[10:8]);
				yv = mac_yread(opc[12:11]);
				case (sub)
					4'h1, 4'h2, 4'h3, 4'h4, 4'h8, 4'hc: begin
						xs = 1'b1;
						ys = 1'b1;
					end
					4'h5, 4'h9, 4'hd: begin
						xs = 1'b1;
						ys = 1'b0;
					end
					4'h6, 4'ha, 4'he: begin
						xs = 1'b0;
						ys = 1'b1;
					end
					default: begin
						xs = 1'b0;
						ys = 1'b0;
					end
				endcase
				case (sub)
					4'h2, 4'h8, 4'h9, 4'ha, 4'hb: acc = 2'd1;
					4'h3, 4'hc, 4'hd, 4'he, 4'hf: acc = 2'd2;
					default: acc = 2'd0;
				endcase
				rnd = ((sub == 4'h1) || (sub == 4'h2)) || (sub == 4'h3);
				sh = ~mstat[4];
				xe = (xs ? $signed({{16 {xv[15]}}, xv}) : $signed({16'b0000000000000000, xv}));
				ye = (ys ? $signed({{16 {yv[15]}}, yv}) : $signed({16'b0000000000000000, yv}));
				p32 = xe * ye;
				if (sh)
					p32 = p32 <<< 1;
				prod = {{32 {p32[31]}}, p32};
				mrold = $signed({mrzb[bnk], gr[{bnk, 4'b0000} + 13], gr[{bnk, 4'b0000} + 12], gr[{bnk, 4'b0000} + 11]});
				case (acc)
					2'd1: r = mrold + prod;
					2'd2: r = mrold - prod;
					default: r = prod;
				endcase
				if (rnd) begin
					r = r + 64'sh0000000000008000;
					if (prod[15:0] == 16'h8000)
						r[16] = 1'b0;
				end
			end
			mac_r64_f = r;
		end
	endfunction
	reg signed [63:0] mac_r;
	reg signed [63:0] mac_pipe_r;
	reg [31:0] alu_res;
	reg [31:0] shift_res_v;
	reg [15:0] shift_se_v;
	reg [15:0] shift_sbr_v;
	reg shift_ss_v;
	reg shift_se_we;
	reg shift_ss_we;
	reg shift_sbr_we;
	integer wrlog_en = 0;
	integer wrlog_fd = 0;
	integer wrlog_cnt = 0;
	integer wrlog_word = 16'h046a;
	reg wrlog_on = 1'b0;
	task automatic shift_wb;
		input [3:0] mode;
		begin
			if (mode < 4'hc) begin
				gr[{bnk, 4'b0000} + 14] <= shift_res_v[15:0];
				gr[{bnk, 4'b0000} + 15] <= shift_res_v[31:16];
			end
			if (shift_ss_we)
				astat[7] <= shift_ss_v;
			if (shift_se_we)
				gr[{bnk, 4'b0000} + 9] <= shift_se_v;
			if (shift_sbr_we)
				sbb[bnk] <= shift_sbr_v;
		end
	endtask
	task automatic alu_wb;
		input dst_af;
		begin
			astat <= alu_res[31:16];
			if (dst_af)
				afb[bnk] <= alu_res[15:0];
			else
				gr[{bnk, 4'b0000} + 10] <= alu_res[15:0];
		end
	endtask
	task automatic mac_wb;
		input [3:0] sub;
		input dst_mf;
		if (sub != 4'h0) begin
			if (dst_mf)
				mfb[bnk] <= mac_r[31:16];
			else begin
				if ((mac_r[39:31] != 9'h000) && (mac_r[39:31] != 9'h1ff))
					astat <= astat | 16'h0040;
				else
					astat <= astat & ~16'h0040;
				gr[{bnk, 4'b0000} + 11] <= mac_r[15:0];
				gr[{bnk, 4'b0000} + 12] <= mac_r[31:16];
				gr[{bnk, 4'b0000} + 13] <= mac_r[47:32];
				mrzb[bnk] <= mac_r[63:48];
			end
		end
	endtask
	task automatic launch_boot;
		input [10:0] bank;
		begin
			boot_active <= 1'b1;
			state <= S_BOOT;
			boot_bank <= bank;
			boot_idx <= 12'h000;
			boot_plen <= 12'h000;
			boot_phase <= 2'd0;
		end
	endtask
	reg [3:0] music_gain_eighths;
	function automatic [7:0] revx_scale_volume;
		input [7:0] volume;
		input [3:0] eighths;
		reg [11:0] rounded;
		begin
			rounded = ({4'd0, volume} * {8'd0, eighths}) + 12'd4;
			revx_scale_volume = (eighths == 4'd8 ? volume : rounded[10:3]);
		end
	endfunction
	reg [3:0] sfx_gain_eighths;
	function [15:0] dm_read;
		input [15:0] addr;
		case (dm_region(addr))
			RG_ALIAS: begin
				dm_read = pmb_q[23:8];
				if (((((((REVX_MIXER_GAIN && DCS_2K) && DCS_UART) && (pc == 14'h0ab2)) && (op_r == 24'h6000e9)) && (addr >= 16'h05ff)) && (addr <= 16'h0602)) && (pmb_q[23:16] == 8'd0))
					dm_read = {8'd0, revx_scale_volume(pmb_q[15:8], (addr == 16'h05ff ? music_gain_eighths : sfx_gain_eighths))};
			end
			RG_BANK: dm_read = {8'hff, rom_q};
			RG_LATCH: dm_read = input_data;
			RG_OPEN: dm_read = 16'hffff;
			default: dm_read = (addr == 16'h3ffc ? tim_count : dm_q);
		endcase
	endfunction
	task automatic dm_load;
		input [15:0] addr;
		output reg [15:0] val;
		begin
			val = dm_read(addr);
			if (dm_region(addr) == RG_LATCH) begin
				irq2_line <= 1'b0;
				latch_control <= latch_control | 16'h0800;
			end
		end
	endtask
	task automatic dm_write;
		input [15:0] addr;
		input [15:0] val;
		if (dm_region(addr) == RG_ALIAS) begin
			pm_we = 1'b1;
			pm_wa = dm_alias_phys_addr(addr[13:0]);
			pm_wd = {val, pmb_q[7:0]};
		end
		else if ((((DCS_2K != 0) && (addr >= 16'h3000)) && (addr <= 16'h33ff)) || ((DCS_2K == 0) && (addr == 16'h3000)))
			data_bank <= val[10:0];
		else if (dm_region(addr) == RG_LATCH) begin
			output_data <= val;
			latch_control <= latch_control & ~16'h0400;
		end
		else if (dm_region(addr) == RG_DM) begin
			dm[addr[13:0]] <= val;
			if (addr == 16'h3fef)
				ctl_s1_autobuf <= val;
			if (addr == 16'h3ffb) begin
				tim_scale <= {1'b0, val[7:0]} + 9'd1;
				tim_scale_cnt <= {1'b0, val[7:0]} + 9'd1;
			end
			if (addr == 16'h3ffc) begin
				tim_count <= val;
				tim_scale_cnt <= tim_scale;
			end
			if (addr == 16'h3ffd)
				tim_period <= val;
			if (addr == 16'h3fff) begin
				ctl_syscontrol <= val;
				if (val[9]) begin
					reboot_pending <= 1'b1;
					reboot_bank <= data_bank;
				end
			end
		end
	endtask
	function automatic [3:0] revx_gain_eighths;
		input [3:0] setting;
		case (setting)
			4'd1: revx_gain_eighths = 4'd7;
			4'd2: revx_gain_eighths = 4'd6;
			4'd3: revx_gain_eighths = 4'd5;
			4'd4: revx_gain_eighths = 4'd4;
			4'd5: revx_gain_eighths = 4'd3;
			4'd6: revx_gain_eighths = 4'd2;
			4'd7: revx_gain_eighths = 4'd1;
			4'd8: revx_gain_eighths = 4'd0;
			default: revx_gain_eighths = 4'd8;
		endcase
	endfunction
	always @(posedge clk)
		if (rst) begin
			music_gain_eighths <= 4'd8;
			sfx_gain_eighths <= 4'd8;
		end
		else if (((((((REVX_MIXER_GAIN && DCS_2K) && DCS_UART) && cpu_ce) && (state == S_EXEC)) && !drain_idle_only) && (pc == 14'h0aa1)) && (op_r == 24'h345ff2)) begin
			music_gain_eighths <= revx_gain_eighths(music_attenuation);
			sfx_gain_eighths <= revx_gain_eighths(sfx_attenuation);
		end
	function [15:0] shift_xreg;
		input [2:0] xi;
		case (xi)
			3'd0: shift_xreg = gr[{bnk, 4'b0000} + 8];
			3'd1: shift_xreg = gr[{bnk, 4'b0000} + 8];
			3'd2: shift_xreg = gr[{bnk, 4'b0000} + 10];
			3'd3: shift_xreg = gr[{bnk, 4'b0000} + 11];
			3'd4: shift_xreg = gr[{bnk, 4'b0000} + 12];
			3'd5: shift_xreg = gr[{bnk, 4'b0000} + 13];
			3'd6: shift_xreg = gr[{bnk, 4'b0000} + 14];
			3'd7: shift_xreg = gr[{bnk, 4'b0000} + 15];
		endcase
	endfunction
	function automatic integer clz32;
		input [31:0] v;
		integer j;
		begin
			clz32 = 32;
			for (j = 31; j >= 0; j = j - 1)
				if (v[j] && (clz32 == 32))
					clz32 = 31 - j;
		end
	endfunction
	task automatic shift_eval;
		input [3:0] mode;
		input [2:0] xi;
		input signed [7:0] sc;
		output reg [31:0] o_res;
		output reg [15:0] o_se;
		output reg o_ss;
		output reg [15:0] o_sbr;
		output reg o_se_we;
		output reg o_ss_we;
		output reg o_sbr_we;
		reg [15:0] xr;
		reg signed [31:0] xs;
		reg [31:0] xu;
		reg [31:0] res;
		integer e;
		reg signed [15:0] sev;
		begin
			o_res = 32'h00000000;
			o_se = 16'h0000;
			o_ss = 1'b0;
			o_sbr = 16'h0000;
			o_se_we = 1'b0;
			o_ss_we = 1'b0;
			o_sbr_we = 1'b0;
			xr = shift_xreg(xi);
			res = 32'h00000000;
			case (mode)
				4'h0, 4'h1: begin
					xu = {xr, 16'h0000};
					if (sc > 0)
						res = (sc < 32 ? xu << sc : 32'h00000000);
					else
						res = (sc > -32 ? xu >> -sc : 32'h00000000);
				end
				4'h2, 4'h3: begin
					xu = {16'h0000, xr};
					if (sc > 0)
						res = (sc < 32 ? xu << sc : 32'h00000000);
					else
						res = (sc > -32 ? xu >> -sc : 32'h00000000);
				end
				4'h4, 4'h5: begin
					xs = $signed({xr, 16'h0000});
					if (sc > 0)
						res = (sc < 32 ? xs << sc : 32'h00000000);
					else
						res = (sc > -32 ? xs >>> -sc : xs >>> 31);
				end
				4'h6, 4'h7: begin
					xs = $signed({{16 {xr[15]}}, xr});
					if (sc > 0)
						res = (sc < 32 ? xs << sc : 32'h00000000);
					else
						res = (sc > -32 ? xs >>> -sc : xs >>> 31);
				end
				4'h8, 4'h9: begin
					xs = $signed({xr, 16'h0000});
					if (sc > 0) begin
						xu = {astat[3], xs[31:1]};
						res = xu >> (sc - 1);
					end
					else
						res = (sc > -32 ? xs << -sc : 32'h00000000);
				end
				4'ha, 4'hb: begin
					xu = {16'h0000, xr};
					if (sc > 0)
						res = (sc < 32 ? xu >> sc : 32'h00000000);
					else
						res = (sc > -32 ? xu << -sc : 32'h00000000);
				end
				4'hc: begin
					xs = $signed({{16 {xr[15]}}, xr});
					if (xs < 0) begin
						o_ss = 1'b1;
						o_ss_we = 1'b1;
						e = clz32(~xs) - 17;
					end
					else begin
						o_ss = 1'b0;
						o_ss_we = 1'b1;
						e = clz32(xs) - 17;
					end
					sev = -e;
					o_se = sev;
					o_se_we = 1'b1;
				end
				4'hd: begin
					xs = $signed({{16 {xr[15]}}, xr});
					if (astat[2]) begin
						sev = 16'sd1;
						o_se = sev;
						o_se_we = 1'b1;
						if (xs < 0) begin
							o_ss = 1'b0;
							o_ss_we = 1'b1;
						end
						else begin
							o_ss = 1'b1;
							o_ss_we = 1'b1;
						end
					end
					else begin
						if (xs < 0) begin
							o_ss = 1'b1;
							o_ss_we = 1'b1;
							e = clz32(~xs) - 17;
						end
						else begin
							o_ss = 1'b0;
							o_ss_we = 1'b1;
							e = clz32(xs) - 17;
						end
						sev = -e;
						o_se = sev;
						o_se_we = 1'b1;
					end
				end
				4'he:
					if ($signed(gr[{bnk, 4'b0000} + 9][7:0]) == -8'sd15) begin
						xs = $signed({{16 {xr[15]}}, xr});
						e = clz32((astat[7] ? ~xs : xs) & 32'h0000ffff) - 1;
						sev = -e;
						o_se = sev;
						o_se_we = 1'b1;
					end
				4'hf: begin
					xs = $signed({{16 {xr[15]}}, xr});
					e = clz32((xs < 0 ? ~xs : xs)) - 17;
					if (e < -$signed(sbb[bnk])) begin
						sev = -e;
						o_sbr = sev;
						o_sbr_we = 1'b1;
					end
				end
			endcase
			if (mode < 4'hc) begin
				if (mode[0])
					res = {gr[{bnk, 4'b0000} + 15], gr[{bnk, 4'b0000} + 14]} | res;
				o_res = res;
			end
		end
	endtask
	integer k;
	initial begin
		data_bank = 11'h000;
		input_data = 16'h0000;
		latch_control = 16'h0c00;
		output_data = 16'h0000;
		host_rst_r = 1'b0;
		tim_scale = 9'd1;
		tim_count = 16'h0000;
		tim_period = 16'h0000;
		tim_scale_cnt = 9'd1;
		tim_irq_latch = 1'b0;
		dac_sample = 16'h0000;
		dac_ce = 1'b0;
		dac_burst_len = 0;
		dac_play_idx = 0;
		dac_play_active = 1'b0;
		audio_started = 1'b0;
		audio_underrun = 1'b0;
		audio_overrun = 1'b0;
		boot_active = 1'b0;
		boot_idx = 12'h000;
		boot_plen = 12'h000;
		boot_bank = 11'h000;
		boot_phase = 2'd0;
		boot_b0 = 8'h00;
		boot_b1 = 8'h00;
		state = S_FETCH;
		dr_done = 1'b0;
		dr_idx = 0;
		dr_acc = 0;
		dr_cnt = 0;
		div_done = 1'b0;
		div_i = 5'd0;
		div_q = 16'h0000;
		ab_drain_cnt = 16'h0000;
		dr_region = RG_DM;
		dr_rom_a = 23'h000000;
		dr_smp = 16'h0000;
		ctl_s1_autobuf = 16'h0000;
		ctl_syscontrol = 16'h0000;
	end
	reg [23:0] op;
	reg [7:0] hi;
	reg [13:0] tgt;
	reg [1:0] grp;
	reg [3:0] ridx;
	reg [13:0] daddr;
	reg [2:0] iidx;
	reg [2:0] midx;
	reg do_loop_back;
	reg do_loop_exit;
	reg [15:0] mstat_tmp;
	reg [15:0] sstat_tmp;
	reg [15:0] dmv;
	reg [15:0] mvtmp;
	reg cflag;
	integer li;
	always @(posedge clk) begin
		dac_ce <= 1'b0;
		pm_we = 1'b0;
		if (rst) begin
			dr_done <= 1'b0;
			dr_idx <= 0;
			div_done <= 1'b0;
			div_i <= 5'd0;
			pc <= 14'h0000;
			o_valid <= 1'b0;
			o_unimpl <= 1'b0;
			o_ppc <= 14'h0000;
			dac_sample <= 16'h0000;
			dac_burst_len <= 10'd0;
			dac_play_idx <= 9'd0;
			dac_play_active <= 1'b0;
			audio_started <= 1'b0;
			audio_underrun <= 1'b0;
			audio_overrun <= 1'b0;
			loop_sp <= 0;
			pc_sp <= 0;
			cntr_sp <= 0;
			cntr <= 14'h0000;
			astat <= 0;
			mstat <= 0;
			sstat <= 16'h0055;
			imask <= 0;
			icntl <= 0;
			px <= 0;
			mac_pipe_r <= 64'sh0000000000000000;
			flagout <= 0;
			fl0 <= 0;
			fl1 <= 0;
			fl2 <= 0;
			idle_cpu <= 0;
			afb[0] <= 0;
			afb[1] <= 0;
			mfb[0] <= 0;
			mfb[1] <= 0;
			sbb[0] <= 0;
			sbb[1] <= 0;
			mrzb[0] <= 0;
			mrzb[1] <= 0;
			for (k = 0; k < 8; k = k + 1)
				begin
					iR[k] <= 0;
					mR[k] <= 0;
					lR[k] <= 0;
					baseR[k] <= 0;
					lmask[k] <= 14'h3fff;
				end
			for (k = 0; k < 32; k = k + 1)
				gr[k] <= 0;
			for (k = 0; k < 4; k = k + 1)
				loop_end[k] <= NO_LOOP;
			stat_sp <= 0;
			data_bank <= 11'h000;
			reboot_pending <= 1'b0;
			launch_boot(11'h000);
			latch_control <= 16'h0c00;
			output_data <= 16'h0000;
			ab_active <= 1'b0;
			dac_slot_ctr <= 16'h0000;
			dac_slot_go <= 1'b0;
			ab_ireg <= 3'd0;
			ab_base <= 16'h0000;
			ab_size <= 16'h0000;
			ab_incs <= 16'h0000;
			ab_drain_cnt <= 16'h0000;
			ctl_s1_autobuf <= 16'h0000;
			ctl_syscontrol <= 16'h0000;
			drain_idle_only <= 1'b0;
			irq2_line <= 1'b0;
			irq2_latch <= 1'b0;
			irq1_pulse <= 1'b0;
			host_rst_r <= 1'b0;
			tim_scale <= 9'd1;
			tim_count <= 16'h0000;
			tim_period <= 16'h0000;
			tim_scale_cnt <= 9'd1;
			tim_irq_latch <= 1'b0;
		end
		else if (cpu_ce)
			case (state)
				S_BOOT: begin
					o_valid <= 1'b0;
					if (rom_rdy)
						case (boot_phase)
							2'd0: begin
								boot_plen <= ({4'h0, rom_q} + 12'd1) << 3;
								boot_phase <= 2'd1;
							end
							2'd1: begin
								boot_b0 <= rom_q;
								boot_phase <= 2'd2;
							end
							2'd2: begin
								boot_b1 <= rom_q;
								boot_phase <= 2'd3;
							end
							2'd3: begin
								pm_we = 1'b1;
								pm_wa = {2'b00, boot_idx};
								pm_wd = {boot_b0, boot_b1, rom_q};
								boot_phase <= 2'd1;
								if ((boot_idx + 12'd1) >= boot_plen) begin
									boot_active <= 1'b0;
									state <= S_FETCH;
								end
								else
									boot_idx <= boot_idx + 12'd1;
							end
						endcase
				end
				S_FETCH: begin
					o_valid <= 1'b0;
					if (idle_cpu && drain_pend) begin
						drain_idle_only <= 1'b1;
						state <= S_DECODE;
					end
					else if (idle_cpu && !((((reboot_pending || host_rst_r) || ((icntl[2] ? irq2_latch : irq2_line) && imask[5])) || (irq1_pulse && imask[2])) || (tim_irq_latch && imask[0])))
						state <= S_FETCH;
					else begin
						idle_cpu <= 0;
						state <= S_DECODE;
					end
				end
				S_DECODE, S_DRAIN, S_DIV, S_ROM, S_MEM: begin
					o_valid <= 1'b0;
					if (reboot_pending) begin
						dr_done <= 1'b0;
						dr_idx <= 0;
						div_done <= 1'b0;
						div_i <= 5'd0;
						pc <= 14'h0000;
						o_valid <= 1'b0;
						o_unimpl <= 1'b0;
						loop_sp <= 0;
						pc_sp <= 0;
						cntr_sp <= 0;
						cntr <= 14'h0000;
						stat_sp <= 0;
						astat <= 0;
						mstat <= 0;
						sstat <= 16'h0055;
						imask <= 0;
						icntl <= 0;
						px <= 0;
						flagout <= 0;
						fl0 <= 0;
						fl1 <= 0;
						fl2 <= 0;
						idle_cpu <= 0;
						drain_idle_only <= 0;
						afb[0] <= 0;
						afb[1] <= 0;
						mfb[0] <= 0;
						mfb[1] <= 0;
						sbb[0] <= 0;
						sbb[1] <= 0;
						mrzb[0] <= 0;
						mrzb[1] <= 0;
						for (k = 0; k < 8; k = k + 1)
							begin
								iR[k] <= 0;
								mR[k] <= 0;
								lR[k] <= 0;
								baseR[k] <= 0;
								lmask[k] <= 14'h3fff;
							end
						for (k = 0; k < 32; k = k + 1)
							gr[k] <= 0;
						for (k = 0; k < 4; k = k + 1)
							loop_end[k] <= NO_LOOP;
						launch_boot(reboot_bank);
						reboot_pending <= 1'b0;
						irq2_line <= 1'b0;
						irq2_latch <= 1'b0;
						irq1_pulse <= 1'b0;
						tim_irq_latch <= 1'b0;
					end
					else if (host_rst_r) begin
						dr_done <= 1'b0;
						dr_idx <= 0;
						div_done <= 1'b0;
						div_i <= 5'd0;
						pc <= 14'h0000;
						o_valid <= 1'b0;
						o_unimpl <= 1'b0;
						loop_sp <= 0;
						pc_sp <= 0;
						cntr_sp <= 0;
						cntr <= 14'h0000;
						stat_sp <= 0;
						astat <= 0;
						mstat <= 0;
						sstat <= 16'h0055;
						imask <= 0;
						icntl <= 0;
						px <= 0;
						flagout <= 0;
						fl0 <= 0;
						fl1 <= 0;
						fl2 <= 0;
						idle_cpu <= 0;
						drain_idle_only <= 0;
						afb[0] <= 0;
						afb[1] <= 0;
						mfb[0] <= 0;
						mfb[1] <= 0;
						sbb[0] <= 0;
						sbb[1] <= 0;
						mrzb[0] <= 0;
						mrzb[1] <= 0;
						for (k = 0; k < 8; k = k + 1)
							begin
								iR[k] <= 0;
								mR[k] <= 0;
								lR[k] <= 0;
								baseR[k] <= 0;
								lmask[k] <= 14'h3fff;
							end
						for (k = 0; k < 32; k = k + 1)
							gr[k] <= 0;
						for (k = 0; k < 4; k = k + 1)
							loop_end[k] <= NO_LOOP;
						data_bank <= 11'h000;
						launch_boot(11'h000);
						latch_control <= 16'h0c00;
						irq2_line <= 1'b0;
						irq2_latch <= 1'b0;
						irq1_pulse <= 1'b0;
						tim_scale <= 9'd1;
						tim_scale_cnt <= 9'd1;
						tim_irq_latch <= 1'b0;
					end
					else if ((((icntl[2] ? irq2_latch : irq2_line) && imask[5]) || (irq1_pulse && imask[2])) || (tim_irq_latch && imask[0])) begin
						state <= S_FETCH;
						dr_done <= 1'b0;
						dr_idx <= 0;
						div_done <= 1'b0;
						div_i <= 5'd0;
						sstat_tmp = sstat;
						if (pc_sp < 16) begin
							pc_stack[pc_sp] <= pc;
							pc_sp <= pc_sp + 1'b1;
							sstat_tmp = sstat_tmp & ~16'h0001;
						end
						else
							sstat_tmp = sstat_tmp | 16'h0002;
						if (stat_sp < 4) begin
							stat_mstat[stat_sp[1:0]] <= mstat;
							stat_imask[stat_sp[1:0]] <= imask;
							stat_astat[stat_sp[1:0]] <= astat;
							stat_sp <= stat_sp + 1'b1;
							sstat_tmp = sstat_tmp & ~16'h0010;
						end
						else
							sstat_tmp = sstat_tmp | 16'h0020;
						sstat <= sstat_tmp;
						if ((icntl[2] ? irq2_latch : irq2_line) && imask[5]) begin
							imask <= (icntl[4] ? imask & ~(16'h003f >> 0) : imask & ~16'h003f);
							pc <= 14'h0004;
							irq2_latch <= 1'b0;
						end
						else if (irq1_pulse && imask[2]) begin
							imask <= (icntl[4] ? imask & ~(16'h003f >> 3) : imask & ~16'h003f);
							pc <= 14'h0010;
							irq1_pulse <= 1'b0;
						end
						else begin
							imask <= (icntl[4] ? imask & ~(16'h003f >> 5) : imask & ~16'h003f);
							pc <= 14'h0018;
							tim_irq_latch <= 1'b0;
						end
						o_valid <= 1'b0;
					end
					else
						case (state)
							S_DECODE: begin
								op_r <= fetch_q;
								mac_pipe_r <= mac_r64_f(fetch_q, fetch_q[16:13]);
								ea_addr_r <= pre_addr;
								pm_addr_r <= pre_pm_addr;
								pm_rd_r <= pre_pm_rd;
								bank_rd_r <= pre_bank_rd;
								tx1_r <= pre_tx1_wr;
								mem_need_r <= mem_need;
								if (drain_pend && !dr_done)
									state <= S_DRAIN;
								else if (pre_tx1_wr && !div_done)
									state <= S_DIV;
								else if (pre_bank_rd && !rom_rdy)
									state <= S_ROM;
								else if (mem_need != 2'd0)
									state <= S_MEM;
								else
									state <= S_EXEC;
							end
							S_DRAIN: begin
								o_valid <= 1'b0;
								if (dr_idx == 0)
									dr_cnt = ab_drain_cnt;
								if ((dr_idx > 0) && (dr_idx <= dr_cnt)) begin
									case (dr_region)
										RG_ALIAS: dr_smp = pmb_q[23:8];
										RG_BANK: dr_smp = {8'hff, snd_byte(dr_rom_a)};
										RG_LATCH: dr_smp = input_data;
										RG_OPEN: dr_smp = 16'hffff;
										default: dr_smp = dm_q;
									endcase
									dac_emit_burst[dr_idx - 1] <= dr_smp;
								end
								if (dr_idx < dr_cnt) begin
									dr_region <= dm_region(dr_cur[15:0]);
									dr_rom_a <= {data_bank, 12'h000} + {11'h000, dr_cur[11:0]};
									dr_acc <= dr_cur + {16'h0000, ab_incs};
									dr_idx <= dr_idx + 1;
								end
								else begin
									dr_done <= 1'b1;
									state <= (tx1_r && !div_done ? S_DIV : (bank_rd_r && !rom_rdy ? S_ROM : (mem_need_r != 2'd0 ? S_MEM : S_EXEC)));
								end
							end
							S_DIV: begin
								o_valid <= 1'b0;
								if (div_i == 5'd0) begin
									div_v <= {pre_ab_incs, 1'b0};
									div_nd <= lR[pre_ab_lr];
									div_rem <= 17'h00000;
									div_q <= 16'h0000;
									div_i <= 5'd1;
								end
								else begin
									div_t = {div_rem, div_nd[15]};
									if (div_t >= {1'b0, div_v}) begin
										div_rem <= div_t - {1'b0, div_v};
										div_q <= {div_q[14:0], 1'b1};
									end
									else begin
										div_rem <= div_t[16:0];
										div_q <= {div_q[14:0], 1'b0};
									end
									div_nd <= {div_nd[14:0], 1'b0};
									if (div_i == 5'd16) begin
										div_done <= 1'b1;
										state <= (bank_rd_r && !rom_rdy ? S_ROM : (mem_need_r != 2'd0 ? S_MEM : S_EXEC));
									end
									else
										div_i <= div_i + 5'd1;
								end
							end
							S_ROM:
								if (rom_rdy)
									state <= (mem_need_r != 2'd0 ? S_MEM : S_EXEC);
							S_MEM: state <= S_EXEC;
							default:
								;
						endcase
				end
				S_EXEC: begin
					state <= S_FETCH;
					dr_done <= 1'b0;
					dr_idx <= 0;
					div_done <= 1'b0;
					div_i <= 5'd0;
					o_ppc <= pc;
					o_valid <= !drain_idle_only;
					o_unimpl <= 1'b0;
					if (!drain_idle_only && mstat[5]) begin
						if (tim_scale_cnt <= 9'd1) begin
							tim_scale_cnt <= tim_scale;
							if (tim_count == 16'h0000) begin
								tim_count <= tim_period;
								tim_irq_latch <= 1'b1;
							end
							else
								tim_count <= tim_count - 16'h0001;
						end
						else
							tim_scale_cnt <= tim_scale_cnt - 9'd1;
					end
					if (!drain_idle_only && irq1_pulse)
						irq1_pulse <= 1'b0;
					if ((ab_active && dac_slot_go) && dr_done) begin
						ab_cnt = dr_cnt;
						ab_reg = dr_cur;
						dac_burst_len <= ab_cnt[9:0];
						if (dac_play_active)
							audio_overrun <= 1'b1;
						dac_play_idx <= 9'd0;
						dac_play_active <= ab_cnt != 0;
						audio_started <= 1'b1;
						if (ab_reg >= ({16'h0000, baseR[ab_ireg]} + ab_size)) begin
							ab_reg = {16'h0000, baseR[ab_ireg]};
							irq1_pulse <= 1'b1;
						end
						iR[ab_ireg] <= ab_reg & 16'h3fff;
						baseR[ab_ireg] <= ab_reg[13:0] & lmask[ab_ireg];
						dac_slot_go <= 1'b0;
					end
					if (!drain_idle_only) begin
						op = op_r;
						hi = op[23:16];
						mac_r = mac_pipe_r;
						alu_res = alu_eval(op[16:13], alu_xread(op[10:8]), alu_yread(op[12:11]));
						shift_eval(op[14:11], op[10:8], (hi == 8'h0f ? op[7:0] : gr[{bnk, 4'b0000} + 9][7:0]), shift_res_v, shift_se_v, shift_ss_v, shift_sbr_v, shift_se_we, shift_ss_we, shift_sbr_we);
						do_loop_back = 1'b0;
						do_loop_exit = 1'b0;
						if ((loop_sp != 0) && (pc == loop_end[loop_sp - 1])) begin
							if (loop_cond[loop_sp - 1] == 4'he) begin
								if (($signed({1'b0, cntr}) - 1) > 0) begin
									cntr <= cntr - 1'b1;
									do_loop_back = 1'b1;
								end
								else begin
									if (cntr_sp != 0) begin
										cntr <= cntr_stack[cntr_sp - 1];
										cntr_sp <= cntr_sp - 1'b1;
										if (cntr_sp == 1)
											sstat <= sstat | 16'h0004;
									end
									else
										cntr <= cntr_stack[0];
									do_loop_exit = 1'b1;
								end
							end
							else if (cond_true(loop_cond[loop_sp - 1]))
								do_loop_back = 1'b1;
							else
								do_loop_exit = 1'b1;
						end
						if (do_loop_back)
							pc <= pc_stack[pc_sp - 1];
						else if (do_loop_exit) begin
							loop_sp <= loop_sp - 1'b1;
							if (pc_sp != 0)
								pc_sp <= pc_sp - 1'b1;
							pc <= pc + 1'b1;
							sstat <= ((sstat | (loop_sp == 1 ? 16'h0040 : 16'h0000)) | (pc_sp == 1 ? 16'h0001 : 16'h0000)) | ((loop_cond[loop_sp - 1] == 4'he) && (cntr_sp == 1) ? 16'h0004 : 16'h0000);
						end
						else
							pc <= pc + 1'b1;
						case (hi)
							8'h00:
								;
							8'h01:
								;
							8'h02:
								if (op[15])
									idle_cpu <= 1'b1;
								else begin
									cond_eval(op[3:0], cflag);
									if (cflag) begin
										if (op[5])
											flagout <= 0;
										if (op[4])
											flagout <= ~flagout;
										if (op[7])
											fl0 <= 0;
										if (op[6])
											fl0 <= ~fl0;
										if (op[9])
											fl1 <= 0;
										if (op[8])
											fl1 <= ~fl1;
										if (op[11])
											fl2 <= 0;
										if (op[10])
											fl2 <= ~fl2;
									end
								end
							8'h03:
								if (!op[1]) begin
									if (op[0]) begin
										if (pc_sp < 16) begin
											pc_stack[pc_sp] <= pc + 1'b1;
											pc_sp <= pc_sp + 1'b1;
											sstat <= sstat & ~16'h0001;
										end
										else
											sstat <= sstat | 16'h0002;
									end
									pc <= {op[3:2], op[15:4]};
								end
							8'h04: begin
								sstat_tmp = sstat;
								if (op[4]) begin
									if (pc_sp > 0) begin
										pc_sp <= pc_sp - 1;
										if (pc_sp == 1)
											sstat_tmp = sstat_tmp | 16'h0001;
									end
								end
								if (op[3]) begin
									if (loop_sp > 0) begin
										loop_sp <= loop_sp - 1;
										if (loop_sp == 1)
											sstat_tmp = sstat_tmp | 16'h0040;
									end
								end
								if (op[2]) begin
									if (cntr_sp > 0) begin
										cntr <= cntr_stack[cntr_sp - 1];
										cntr_sp <= cntr_sp - 1;
										if (cntr_sp == 1)
											sstat_tmp = sstat_tmp | 16'h0004;
									end
									else
										cntr <= cntr_stack[0];
								end
								if (op[1]) begin
									if (op[0]) begin
										if (stat_sp > 0) begin
											set_mstat(stat_mstat[stat_sp[1:0] - 2'd1]);
											imask <= stat_imask[stat_sp[1:0] - 2'd1];
											astat <= stat_astat[stat_sp[1:0] - 2'd1];
											stat_sp <= stat_sp - 1;
											if (stat_sp == 1)
												sstat_tmp = sstat_tmp | 16'h0010;
										end
										else begin
											set_mstat(stat_mstat[0]);
											imask <= stat_imask[0];
											astat <= stat_astat[0];
										end
									end
									else if (stat_sp < 4) begin
										stat_mstat[stat_sp[1:0]] <= mstat;
										stat_imask[stat_sp[1:0]] <= imask;
										stat_astat[stat_sp[1:0]] <= astat;
										stat_sp <= stat_sp + 1;
										sstat_tmp = sstat_tmp & ~16'h0010;
									end
									else
										sstat_tmp = sstat_tmp | 16'h0020;
								end
								sstat <= sstat_tmp;
							end
							8'h05:
								if (astat[6]) begin
									if (gr[{bnk, 4'b0000} + 13][7]) begin
										gr[{bnk, 4'b0000} + 13] <= 16'hffff;
										gr[{bnk, 4'b0000} + 12] <= 16'h8000;
										gr[{bnk, 4'b0000} + 11] <= 16'h0000;
									end
									else begin
										gr[{bnk, 4'b0000} + 13] <= 16'h0000;
										gr[{bnk, 4'b0000} + 12] <= 16'h7fff;
										gr[{bnk, 4'b0000} + 11] <= 16'hffff;
									end
								end
							8'h06: begin
								dmv = alu_yread(op[12:11]);
								mvtmp = alu_xread(op[10:8]) ^ dmv;
								astat <= (astat & ~16'h0020) | (mvtmp[15] ? 16'h0020 : 16'h0000);
								afb[bnk] <= {dmv[14:0], gr[{bnk, 4'b0000} + 4][15]};
								gr[{bnk, 4'b0000} + 4] <= {gr[{bnk, 4'b0000} + 4][14:0], mvtmp[15]};
							end
							8'h07: begin
								if (astat[5])
									dmv = afb[bnk] + alu_xread(op[10:8]);
								else
									dmv = afb[bnk] - alu_xread(op[10:8]);
								mvtmp = dmv ^ alu_xread(op[10:8]);
								astat <= (astat & ~16'h0020) | (mvtmp[15] ? 16'h0020 : 16'h0000);
								afb[bnk] <= {dmv[14:0], gr[{bnk, 4'b0000} + 4][15]};
								gr[{bnk, 4'b0000} + 4] <= {gr[{bnk, 4'b0000} + 4][14:0], ~mvtmp[15]};
							end
							8'h09:
								dag_modify(op[4:2], {op[4], op[1:0]});
							8'h0b: begin
								cond_eval(op[3:0], cflag);
								if (cflag) begin
									if (op[4]) begin
										if (pc_sp < 16) begin
											pc_stack[pc_sp] <= pc + 1'b1;
											pc_sp <= pc_sp + 1'b1;
											sstat <= sstat & ~16'h0001;
										end
										else
											sstat <= sstat | 16'h0002;
									end
									pc <= iR[{1'b1, op[7:6]}][13:0];
								end
							end
							8'h0a: begin
								cond_eval(op[3:0], cflag);
								if (cflag) begin
									sstat_tmp = sstat;
									if (pc_sp != 0) begin
										pc <= pc_stack[pc_sp - 1];
										pc_sp <= pc_sp - 1'b1;
										if (pc_sp == 1)
											sstat_tmp = sstat_tmp | 16'h0001;
									end
									else
										pc <= pc_stack[0];
									if (op[4]) begin
										if (stat_sp != 0) begin
											set_mstat(stat_mstat[stat_sp[1:0] - 2'd1]);
											imask <= stat_imask[stat_sp[1:0] - 2'd1];
											astat <= stat_astat[stat_sp[1:0] - 2'd1];
											stat_sp <= stat_sp - 1'b1;
											if (stat_sp == 1)
												sstat_tmp = sstat_tmp | 16'h0010;
										end
										else begin
											set_mstat(stat_mstat[0]);
											imask <= stat_imask[0];
											astat <= stat_astat[0];
										end
									end
									sstat <= sstat_tmp;
								end
							end
							8'h0c: begin
								mstat_tmp = mstat;
								if (op[3])
									mstat_tmp = (mstat_tmp & ~16'h0040) | (op[2] ? 16'h0040 : 16'h0000);
								if (op[13])
									mstat_tmp = (mstat_tmp & ~16'h0010) | (op[12] ? 16'h0010 : 16'h0000);
								if (op[15])
									mstat_tmp = (mstat_tmp & ~16'h0020) | (op[14] ? 16'h0020 : 16'h0000);
								if (op[5])
									mstat_tmp = (mstat_tmp & ~16'h0001) | ((op >> 4) & 16'h0001);
								if (op[7])
									mstat_tmp = (mstat_tmp & ~16'h0002) | ((op >> 5) & 16'h0002);
								if (op[9])
									mstat_tmp = (mstat_tmp & ~16'h0004) | ((op >> 6) & 16'h0004);
								if (op[11])
									mstat_tmp = (mstat_tmp & ~16'h0008) | ((op >> 7) & 16'h0008);
								set_mstat(mstat_tmp);
							end
							8'h0d:
								wr_reg(op[11:10], op[7:4], rd_reg(op[9:8], op[3:0]));
							8'h0e: begin
								cond_eval(op[3:0], cflag);
								if (cflag)
									shift_wb(op[14:11]);
							end
							8'h0f:
								shift_wb(op[14:11]);
							8'h10: begin
								shift_wb(op[14:11]);
								wr_reg(2'd0, op[7:4], rd_reg(2'd0, op[3:0]));
							end
							8'h11: begin
								iidx = {1'b1, op[3:2]};
								midx = {1'b1, op[1:0]};
								if (op[15]) begin
									pm_we = 1'b1;
									pm_wa = iR[iidx][13:0];
									pm_wd = {rd_reg(2'd0, op[7:4]), px[7:0]};
									shift_wb(op[14:11]);
								end
								else begin
									shift_wb(op[14:11]);
									wr_reg(2'd0, op[7:4], pmb_q[23:8]);
									px <= {8'h00, pmb_q[7:0]};
								end
								dag_modify(iidx, midx);
							end
							8'h12, 8'h13: begin
								iidx = {op[16], op[3:2]};
								midx = {op[16], op[1:0]};
								if (op[15]) begin
									dm_write(dag_addr(iidx), rd_reg(2'd0, op[7:4]));
									shift_wb(op[14:11]);
								end
								else begin
									shift_wb(op[14:11]);
									dm_load(dag_addr(iidx), dmv);
									wr_reg(2'd0, op[7:4], dmv);
								end
								dag_modify(iidx, midx);
							end
							8'h14, 8'h15, 8'h16, 8'h17: begin
								sstat_tmp = sstat;
								if (loop_sp < 4) begin
									loop_end[loop_sp] <= op[17:4];
									loop_cond[loop_sp] <= op[3:0];
									loop_sp <= loop_sp + 1'b1;
									sstat_tmp = sstat_tmp & ~16'h0040;
								end
								else
									sstat_tmp = sstat_tmp | 16'h0080;
								if (pc_sp < 16) begin
									pc_stack[pc_sp] <= pc + 1'b1;
									pc_sp <= pc_sp + 1'b1;
									sstat_tmp = sstat_tmp & ~16'h0001;
								end
								else
									sstat_tmp = sstat_tmp | 16'h0002;
								sstat <= sstat_tmp;
							end
							8'h18, 8'h19, 8'h1a, 8'h1b, 8'h1c, 8'h1d, 8'h1e, 8'h1f: begin
								tgt = op[17:4];
								cond_eval(op[3:0], cflag);
								if (cflag) begin
									if (op[18]) begin
										if (pc_sp < 16) begin
											pc_stack[pc_sp] <= pc + 1'b1;
											pc_sp <= pc_sp + 1'b1;
											sstat <= sstat & ~16'h0001;
										end
										else
											sstat <= sstat | 16'h0002;
									end
									pc <= tgt;
								end
							end
							8'h20, 8'h21, 8'h22, 8'h23, 8'h24, 8'h25, 8'h26, 8'h27: begin
								cond_eval(op[3:0], cflag);
								if (cflag) begin
									if (op[17])
										alu_wb(op[18]);
									else
										mac_wb(op[16:13], op[18]);
								end
							end
							8'h28, 8'h29, 8'h2a, 8'h2b, 8'h2c, 8'h2d, 8'h2e, 8'h2f: begin
								mvtmp = rd_reg(2'd0, op[3:0]);
								if (op[17])
									alu_wb(op[18]);
								else
									mac_wb(op[16:13], op[18]);
								wr_reg(2'd0, op[7:4], mvtmp);
							end
							8'h30, 8'h31, 8'h32, 8'h33, 8'h34, 8'h35, 8'h36, 8'h37, 8'h38, 8'h39, 8'h3a, 8'h3b, 8'h3c, 8'h3d, 8'h3e, 8'h3f: begin
								grp = op[19:18];
								ridx = op[3:0];
								wr_reg(grp, ridx, {2'b00, op[17:4]});
							end
							8'h40, 8'h41, 8'h42, 8'h43, 8'h44, 8'h45, 8'h46, 8'h47, 8'h48, 8'h49, 8'h4a, 8'h4b, 8'h4c, 8'h4d, 8'h4e, 8'h4f:
								wr_reg(2'd0, op[3:0], op[19:4]);
							8'h50, 8'h51, 8'h52, 8'h53, 8'h54, 8'h55, 8'h56, 8'h57, 8'h58, 8'h59, 8'h5a, 8'h5b, 8'h5c, 8'h5d, 8'h5e, 8'h5f: begin
								if (op[17:13] != 5'h00) begin
									if (op[17])
										alu_wb(op[18]);
									else
										mac_wb(op[16:13], op[18]);
								end
								iidx = {1'b1, op[3:2]};
								midx = {1'b1, op[1:0]};
								if (op[19]) begin
									pm_we = 1'b1;
									pm_wa = iR[iidx][13:0];
									pm_wd = {rd_reg(2'd0, op[7:4]), px[7:0]};
								end
								else begin
									wr_reg(2'd0, op[7:4], pmb_q[23:8]);
									px <= {8'h00, pmb_q[7:0]};
								end
								dag_modify(iidx, midx);
							end
							8'h60, 8'h61, 8'h62, 8'h63, 8'h64, 8'h65, 8'h66, 8'h67, 8'h68, 8'h69, 8'h6a, 8'h6b, 8'h6c, 8'h6d, 8'h6e, 8'h6f, 8'h70, 8'h71, 8'h72, 8'h73, 8'h74, 8'h75, 8'h76, 8'h77, 8'h78, 8'h79, 8'h7a, 8'h7b, 8'h7c, 8'h7d, 8'h7e, 8'h7f: begin
								if (op[17:13] != 5'h00) begin
									if (op[17])
										alu_wb(op[18]);
									else
										mac_wb(op[16:13], op[18]);
								end
								iidx = {op[20], op[3:2]};
								midx = {op[20], op[1:0]};
								if (op[19])
									dm_write(dag_addr(iidx), rd_reg(2'd0, op[7:4]));
								else begin
									dm_load(dag_addr(iidx), dmv);
									wr_reg(2'd0, op[7:4], dmv);
								end
								dag_modify(iidx, midx);
							end
							8'h80, 8'h81, 8'h82, 8'h83, 8'h84, 8'h85, 8'h86, 8'h87, 8'h88, 8'h89, 8'h8a, 8'h8b, 8'h8c, 8'h8d, 8'h8e, 8'h8f, 8'h90, 8'h91, 8'h92, 8'h93, 8'h94, 8'h95, 8'h96, 8'h97, 8'h98, 8'h99, 8'h9a, 8'h9b, 8'h9c, 8'h9d, 8'h9e, 8'h9f: begin
								daddr = op[17:4];
								grp = op[19:18];
								ridx = op[3:0];
								if (op[20])
									dm_write({2'b00, daddr}, rd_reg(grp, ridx));
								else begin
									dm_load({2'b00, daddr}, dmv);
									wr_reg(grp, ridx, dmv);
								end
							end
							8'ha0, 8'ha1, 8'ha2, 8'ha3, 8'ha4, 8'ha5, 8'ha6, 8'ha7, 8'ha8, 8'ha9, 8'haa, 8'hab, 8'hac, 8'had, 8'hae, 8'haf, 8'hb0, 8'hb1, 8'hb2, 8'hb3, 8'hb4, 8'hb5, 8'hb6, 8'hb7, 8'hb8, 8'hb9, 8'hba, 8'hbb, 8'hbc, 8'hbd, 8'hbe, 8'hbf: begin
								iidx = {op[20], op[3:2]};
								midx = {op[20], op[1:0]};
								dm_write(dag_addr(iidx), op[19:4]);
								dag_modify(iidx, midx);
							end
							8'hc0, 8'hc1, 8'hc2, 8'hc3, 8'hc4, 8'hc5, 8'hc6, 8'hc7, 8'hc8, 8'hc9, 8'hca, 8'hcb, 8'hcc, 8'hcd, 8'hce, 8'hcf, 8'hd0, 8'hd1, 8'hd2, 8'hd3, 8'hd4, 8'hd5, 8'hd6, 8'hd7, 8'hd8, 8'hd9, 8'hda, 8'hdb, 8'hdc, 8'hdd, 8'hde, 8'hdf, 8'he0, 8'he1, 8'he2, 8'he3, 8'he4, 8'he5, 8'he6, 8'he7, 8'he8, 8'he9, 8'hea, 8'heb, 8'hec, 8'hed, 8'hee, 8'hef, 8'hf0, 8'hf1, 8'hf2, 8'hf3, 8'hf4, 8'hf5, 8'hf6, 8'hf7, 8'hf8, 8'hf9, 8'hfa, 8'hfb, 8'hfc, 8'hfd, 8'hfe, 8'hff: begin
								if (op[17])
									alu_wb(1'b0);
								else
									mac_wb(op[16:13], 1'b0);
								iidx = {1'b0, op[3:2]};
								midx = {1'b0, op[1:0]};
								dm_load(dag_addr(iidx), dmv);
								wr_reg(2'd0, {2'b00, op[19:18]}, dmv);
								dag_modify(iidx, midx);
								iidx = {1'b1, op[7:6]};
								midx = {1'b1, op[5:4]};
								wr_reg(2'd0, {2'b01, op[21:20]}, pmb_q[23:8]);
								px <= {8'h00, pmb_q[7:0]};
								dag_modify(iidx, midx);
							end
							default: o_unimpl <= 1'b1;
						endcase
					end
					else
						drain_idle_only <= 1'b0;
				end
			endcase
		if (!rst && cpu_ce)
			host_rst_r <= host_rst;
		if (((!rst && cpu_ce) && dac_ce_in) && ab_active) begin
			if (dac_slot_ctr <= 16'd1) begin
				dac_slot_ctr <= ab_drain_cnt;
				dac_slot_go <= 1'b1;
			end
			else
				dac_slot_ctr <= dac_slot_ctr - 16'd1;
		end
		if ((!rst && cpu_ce) && dac_ce_in) begin
			if (dac_play_active) begin
				dac_sample <= dac_emit_burst[dac_play_idx];
				dac_ce <= 1'b1;
				if (({1'b0, dac_play_idx} + 10'd1) >= dac_burst_len) begin
					dac_play_idx <= 9'd0;
					dac_play_active <= 1'b0;
				end
				else
					dac_play_idx <= dac_play_idx + 9'd1;
			end
			else if (audio_started) begin
				dac_sample <= 16'h0000;
				dac_ce <= 1'b1;
				if (dac_slot_go)
					audio_underrun <= 1'b1;
			end
		end
		if ((host_cmd_w && !rst) && cpu_ce) begin
			input_data <= host_cmd_data;
			if (!irq2_line)
				irq2_latch <= 1'b1;
			irq2_line <= 1'b1;
			latch_control <= latch_control & ~16'h0800;
		end
		if ((host_resp_rd && !rst) && cpu_ce)
			latch_control <= latch_control | 16'h0400;
		if (cpu_ce && pm_we) begin
			pm[pm_phys_addr(pm_wa)] <= pm_wd;
			pm2[pm_phys_addr(pm_wa)] <= pm_wd;
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype none
module revx_dcs2k (
	clk,
	rst,
	dac_ce_31250,
	music_attenuation,
	sfx_attenuation,
	cpu_status_rd,
	cpu_data_rd,
	cpu_data_wr,
	cpu_data_offset,
	cpu_wdata,
	cpu_byte_en,
	cpu_status_rdata,
	cpu_data_rdata,
	uart_control,
	uart_response,
	uart_output_full,
	rom_req,
	rom_addr,
	rom_ready,
	rom_rdata,
	audio,
	audio_ce,
	audio_underrun,
	audio_overrun,
	adsp_pc,
	adsp_valid,
	adsp_unimplemented
);
	parameter EXT_ROM = 1;
	parameter PF_LINES = 512;
	parameter UART_HOST = 0;
	parameter MIXER_GAIN = 0;
	input wire clk;
	input wire rst;
	input wire dac_ce_31250;
	input wire [3:0] music_attenuation;
	input wire [3:0] sfx_attenuation;
	input wire cpu_status_rd;
	input wire cpu_data_rd;
	input wire cpu_data_wr;
	input wire cpu_data_offset;
	input wire [15:0] cpu_wdata;
	input wire [1:0] cpu_byte_en;
	output wire [15:0] cpu_status_rdata;
	output wire [15:0] cpu_data_rdata;
	output wire [15:0] uart_control;
	output wire [7:0] uart_response;
	output wire uart_output_full;
	output wire rom_req;
	output wire [19:0] rom_addr;
	input wire rom_ready;
	input wire [63:0] rom_rdata;
	output wire signed [15:0] audio;
	output wire audio_ce;
	output wire audio_underrun;
	output wire audio_overrun;
	output wire [13:0] adsp_pc;
	output wire adsp_valid;
	output wire adsp_unimplemented;
	reg dcs_run;
	wire host_cmd_w;
	reg [15:0] host_cmd_data;
	wire [15:0] host_status;
	wire [15:0] host_response;
	wire host_resp_rd;
	wire [15:0] dac_sample;
	wire dac_strobe;
	wire core_ce;
	reg core_phase;
	reg host_cmd_pending;
	reg host_resp_pending;
	reg dac_pending;
	assign uart_control = host_status;
	assign uart_response = host_response[7:0];
	assign uart_output_full = ~host_status[10];
	assign cpu_status_rdata = (cpu_status_rd ? host_status >> 4 : 16'hffff);
	assign cpu_data_rdata = (cpu_data_rd ? {8'h00, host_response[7:0]} : 16'hffff);
	assign core_ce = core_phase;
	assign host_resp_rd = core_ce && host_resp_pending;
	assign host_cmd_w = core_ce && host_cmd_pending;
	assign audio = (dcs_run ? $signed(dac_sample) : 16'sd0);
	assign audio_ce = dcs_run && dac_strobe;
	always @(posedge clk)
		if (rst) begin
			dcs_run <= 1'b0;
			host_cmd_data <= 16'h0000;
			core_phase <= 1'b0;
			host_cmd_pending <= 1'b0;
			host_resp_pending <= 1'b0;
			dac_pending <= 1'b0;
		end
		else begin
			core_phase <= ~core_phase;
			if (UART_HOST)
				dcs_run <= 1'b1;
			if (!dcs_run) begin
				host_cmd_pending <= 1'b0;
				host_resp_pending <= 1'b0;
				dac_pending <= 1'b0;
			end
			else begin
				if (core_ce && host_cmd_pending)
					host_cmd_pending <= 1'b0;
				if (core_ce && host_resp_pending)
					host_resp_pending <= 1'b0;
				if (core_ce && dac_pending)
					dac_pending <= 1'b0;
				if (cpu_data_rd)
					host_resp_pending <= 1'b1;
				if (dac_ce_31250)
					dac_pending <= 1'b1;
			end
			if (cpu_data_wr && (UART_HOST || (cpu_data_offset && (cpu_byte_en == 2'b11)))) begin
				dcs_run <= (UART_HOST ? 1'b1 : cpu_wdata[8]);
				host_cmd_data <= {8'h00, cpu_wdata[7:0]};
				host_cmd_pending <= 1'b1;
			end
		end
	revx_adsp2105 #(
		.DCS_2K(1),
		.DCS_UART(UART_HOST),
		.REVX_MIXER_GAIN(MIXER_GAIN),
		.EXT_ROM(EXT_ROM),
		.PF_LINES(PF_LINES),
		.PRELOAD_PM(0),
		.CORE_CE_EN(1)
	) cpu(
		.clk(clk),
		.rst(rst || !dcs_run),
		.core_ce(core_ce),
		.host_rst(1'b0),
		.music_attenuation(music_attenuation),
		.sfx_attenuation(sfx_attenuation),
		.host_cmd_w(host_cmd_w),
		.host_cmd_data(host_cmd_data),
		.host_status_r(host_status),
		.host_response_r(host_response),
		.host_resp_rd(host_resp_rd),
		.rom_ddr_req(rom_req),
		.rom_ddr_addr(rom_addr),
		.rom_ddr_rdy(rom_ready),
		.rom_ddr_q(rom_rdata),
		.dac_ce_in(core_ce && dac_pending),
		.o_ppc(adsp_pc),
		.o_valid(adsp_valid),
		.o_unimpl(adsp_unimplemented),
		.dac_sample(dac_sample),
		.dac_ce(dac_strobe),
		.audio_underrun(audio_underrun),
		.audio_overrun(audio_overrun)
	);
endmodule
`default_nettype wire
module revx_lightgun_position (
	clk,
	rst,
	vs,
	screen_width,
	screen_height,
	rotate,
	sensitivity,
	source,
	joyana,
	joy_dir,
	mouse_dx,
	mouse_dy,
	mouse_strobe,
	gun_x,
	gun_y,
	adc_x,
	adc_y,
	gun_strobe
);
	parameter [8:0] DEFAULT_WIDTH = 9'd410;
	parameter [8:0] DEFAULT_HEIGHT = 9'd256;
	input clk;
	input rst;
	input vs;
	input [8:0] screen_width;
	input [8:0] screen_height;
	input [1:0] rotate;
	input [1:0] sensitivity;
	input [1:0] source;
	input [15:0] joyana;
	input [3:0] joy_dir;
	input [7:0] mouse_dx;
	input [7:0] mouse_dy;
	input mouse_strobe;
	output reg [8:0] gun_x;
	output reg [8:0] gun_y;
	output reg [7:0] adc_x;
	output reg [7:0] adc_y;
	output reg gun_strobe;
	localparam [8:0] DEFAULT_W = DEFAULT_WIDTH;
	localparam [8:0] DEFAULT_H = DEFAULT_HEIGHT;
	wire [8:0] width_live = (screen_width == 9'd0 ? DEFAULT_W : screen_width);
	wire [8:0] height_live = (screen_height == 9'd0 ? DEFAULT_H : screen_height);
	wire [7:0] analog_x = joyana[7:0] + 8'h80;
	wire [7:0] analog_y = joyana[15:8] + 8'h80;
	reg vs_d;
	wire vs_edge = vs & ~vs_d;
	wire joy_active = |joy_dir;
	wire joy_strobe = vs_edge && joy_active;
	reg signed [8:0] joy_step;
	always @(*)
		case (sensitivity)
			2'd1: joy_step = 9'sd9;
			2'd2: joy_step = 9'sd3;
			2'd3: joy_step = 9'sd5;
			default: joy_step = 9'sd7;
		endcase
	reg signed [8:0] mouse_raw_dx;
	reg signed [8:0] mouse_raw_dy;
	reg signed [8:0] mouse_rot_dx;
	reg signed [8:0] mouse_rot_dy;
	reg signed [8:0] joy_raw_dx;
	reg signed [8:0] joy_raw_dy;
	reg signed [8:0] joy_rot_dx;
	reg signed [8:0] joy_rot_dy;
	always @(*) begin
		mouse_raw_dx = $signed({mouse_dx[7], mouse_dx});
		mouse_raw_dy = $signed({mouse_dy[7], mouse_dy});
		joy_raw_dx = 9'sd0;
		joy_raw_dy = 9'sd0;
		if (joy_dir[0])
			joy_raw_dx = joy_step;
		if (joy_dir[1])
			joy_raw_dx = -joy_step;
		if (joy_dir[2])
			joy_raw_dy = joy_step;
		if (joy_dir[3])
			joy_raw_dy = -joy_step;
		case (rotate)
			2'b01: begin
				mouse_rot_dx = -mouse_raw_dy;
				mouse_rot_dy = mouse_raw_dx;
				joy_rot_dx = -joy_raw_dy;
				joy_rot_dy = joy_raw_dx;
			end
			2'b11: begin
				mouse_rot_dx = mouse_raw_dy;
				mouse_rot_dy = -mouse_raw_dx;
				joy_rot_dx = joy_raw_dy;
				joy_rot_dy = -joy_raw_dx;
			end
			2'b10: begin
				mouse_rot_dx = -mouse_raw_dx;
				mouse_rot_dy = -mouse_raw_dy;
				joy_rot_dx = -joy_raw_dx;
				joy_rot_dy = -joy_raw_dy;
			end
			default: begin
				mouse_rot_dx = mouse_raw_dx;
				mouse_rot_dy = mouse_raw_dy;
				joy_rot_dx = joy_raw_dx;
				joy_rot_dy = joy_raw_dy;
			end
		endcase
	end
	function automatic [8:0] clamp_position;
		input signed [10:0] value;
		input [8:0] dimension;
		reg [8:0] maximum;
		begin
			maximum = (dimension == 9'd0 ? 9'd0 : dimension - 1'b1);
			if (value < 0)
				clamp_position = 9'd0;
			else if (value > $signed({2'b00, maximum}))
				clamp_position = maximum;
			else
				clamp_position = value[8:0];
		end
	endfunction
	function automatic [7:0] position_to_adc;
		input [8:0] position;
		input [8:0] dimension;
		reg [22:0] product;
		begin
			product = position * 23'd10215;
			case (dimension)
				9'd410: position_to_adc = product[21:14];
				9'd256: position_to_adc = position[7:0];
				default: position_to_adc = 8'h80;
			endcase
		end
	endfunction
	function automatic [8:0] analog_to_position;
		input [7:0] axis;
		input [8:0] dimension;
		reg [16:0] product;
		begin
			product = axis * dimension;
			if (|product[7:0])
				analog_to_position = product[16:8];
			else
				analog_to_position = product[16:8];
		end
	endfunction
	wire [8:0] analog_pos_x = analog_to_position(analog_x, width_live);
	wire [8:0] analog_pos_y = analog_to_position(analog_y, height_live);
	wire signed [10:0] mouse_next_x_signed = $signed({1'b0, gun_x}) + {{2 {mouse_rot_dx[8]}}, mouse_rot_dx};
	wire signed [10:0] mouse_next_y_signed = $signed({1'b0, gun_y}) - {{2 {mouse_rot_dy[8]}}, mouse_rot_dy};
	wire signed [10:0] joy_next_x_signed = $signed({1'b0, gun_x}) + {{2 {joy_rot_dx[8]}}, joy_rot_dx};
	wire signed [10:0] joy_next_y_signed = $signed({1'b0, gun_y}) - {{2 {joy_rot_dy[8]}}, joy_rot_dy};
	wire [8:0] mouse_next_x = clamp_position(mouse_next_x_signed, width_live);
	wire [8:0] mouse_next_y = clamp_position(mouse_next_y_signed, height_live);
	wire [8:0] joy_next_x = clamp_position(joy_next_x_signed, width_live);
	wire [8:0] joy_next_y = clamp_position(joy_next_y_signed, height_live);
	reg relative_adc_x_pending;
	reg relative_adc_y_pending;
	always @(posedge clk)
		if (rst) begin
			adc_x <= 8'h80;
			adc_y <= 8'h80;
		end
		else if ((source == 2'd0) || (source == 2'd3)) begin
			adc_x <= analog_x;
			adc_y <= analog_y;
		end
		else begin
			if (relative_adc_x_pending)
				adc_x <= position_to_adc(gun_x, width_live);
			if (relative_adc_y_pending)
				adc_y <= position_to_adc(gun_y, height_live);
		end
	always @(posedge clk)
		if (rst) begin
			gun_x <= width_live >> 1;
			gun_y <= height_live >> 1;
			relative_adc_x_pending <= 1'b0;
			relative_adc_y_pending <= 1'b0;
			gun_strobe <= 1'b0;
			vs_d <= vs;
		end
		else begin
			gun_strobe <= 1'b0;
			vs_d <= vs;
			relative_adc_x_pending <= 1'b0;
			relative_adc_y_pending <= 1'b0;
			if ((source == 2'd1) && mouse_strobe) begin
				gun_x <= mouse_next_x;
				gun_y <= mouse_next_y;
				relative_adc_x_pending <= 1'b1;
				relative_adc_y_pending <= 1'b1;
				gun_strobe <= 1'b1;
			end
			else if ((source == 2'd0) || (source == 2'd3)) begin
				gun_x <= analog_pos_x;
				gun_y <= analog_pos_y;
				gun_strobe <= 1'b1;
			end
			else if ((source == 2'd2) && joy_strobe) begin
				gun_x <= joy_next_x;
				gun_y <= joy_next_y;
				relative_adc_x_pending <= 1'b1;
				relative_adc_y_pending <= 1'b1;
				gun_strobe <= 1'b1;
			end
			else begin
				if (gun_x >= width_live) begin
					gun_x <= width_live - 1'b1;
					relative_adc_x_pending <= 1'b1;
				end
				if (gun_y >= height_live) begin
					gun_y <= height_live - 1'b1;
					relative_adc_y_pending <= 1'b1;
				end
			end
		end
endmodule
module revx_lightgun_overlay (
	clk,
	rst,
	pxl_cen,
	hs,
	vs,
	de,
	screen_width,
	screen_height,
	gun1_x,
	gun1_y,
	gun2_x,
	gun2_y,
	gun3_x,
	gun3_y,
	gun1_en,
	gun2_en,
	gun3_en,
	border_en,
	crosshair_en,
	rgb_in,
	rgb_out,
	raster_x,
	raster_y
);
	parameter [8:0] BORDER_WIDTH = 9'd4;
	input clk;
	input rst;
	input pxl_cen;
	input hs;
	input vs;
	input de;
	input [8:0] screen_width;
	input [8:0] screen_height;
	input [8:0] gun1_x;
	input [8:0] gun1_y;
	input [8:0] gun2_x;
	input [8:0] gun2_y;
	input [8:0] gun3_x;
	input [8:0] gun3_y;
	input gun1_en;
	input gun2_en;
	input gun3_en;
	input border_en;
	input crosshair_en;
	input [23:0] rgb_in;
	output reg [23:0] rgb_out;
	output wire [8:0] raster_x;
	output wire [8:0] raster_y;
	localparam [8:0] BORDER = BORDER_WIDTH;
	reg [8:0] x;
	reg [8:0] y;
	reg de_d;
	reg hs_d;
	reg vs_d;
	reg frame_pending;
	reg have_frame_line;
	wire first_pixel = de && !de_d;
	wire [8:0] next_line = (frame_pending || !have_frame_line ? 9'd0 : (y < (screen_height - 1'b1) ? y + 1'b1 : 9'd0));
	assign raster_x = (first_pixel ? 9'd0 : x);
	assign raster_y = (first_pixel ? next_line : y);
	always @(posedge clk)
		if (rst) begin
			x <= 9'd0;
			y <= 9'd0;
			de_d <= 1'b0;
			hs_d <= hs;
			vs_d <= vs;
			frame_pending <= 1'b1;
			have_frame_line <= 1'b0;
		end
		else if (pxl_cen) begin
			vs_d <= vs;
			de_d <= de;
			hs_d <= hs;
			if (vs_d && !vs)
				frame_pending <= 1'b1;
			if (!de)
				x <= 9'd0;
			else begin
				x <= (raster_x < (screen_width - 1'b1) ? raster_x + 1'b1 : raster_x);
				if (first_pixel) begin
					y <= next_line;
					frame_pending <= 1'b0;
					have_frame_line <= 1'b1;
				end
			end
		end
	function automatic [1:0] crosshair_pixel;
		input [2:0] dx;
		input [2:0] dy;
		case (dy)
			3'd0, 3'd1, 3'd6, 3'd7:
				case (dx)
					3'd2, 3'd5: crosshair_pixel = 2'd3;
					3'd3, 3'd4: crosshair_pixel = 2'd1;
					default: crosshair_pixel = 2'd0;
				endcase
			3'd2, 3'd5:
				case (dx)
					3'd0, 3'd1, 3'd2, 3'd5, 3'd6, 3'd7: crosshair_pixel = 2'd3;
					3'd3, 3'd4: crosshair_pixel = 2'd1;
					default: crosshair_pixel = 2'd0;
				endcase
			3'd3, 3'd4:
				case (dx)
					3'd0, 3'd1, 3'd2, 3'd5, 3'd6, 3'd7: crosshair_pixel = 2'd1;
					3'd3, 3'd4: crosshair_pixel = 2'd3;
					default: crosshair_pixel = 2'd0;
				endcase
			default: crosshair_pixel = 2'd0;
		endcase
	endfunction
	wire [9:0] gun1_dx = {1'b0, raster_x} - {1'b0, gun1_x};
	wire [9:0] gun1_dy = {1'b0, raster_y} - {1'b0, gun1_y};
	wire [9:0] gun2_dx = {1'b0, raster_x} - {1'b0, gun2_x};
	wire [9:0] gun2_dy = {1'b0, raster_y} - {1'b0, gun2_y};
	wire [9:0] gun3_dx = {1'b0, raster_x} - {1'b0, gun3_x};
	wire [9:0] gun3_dy = {1'b0, raster_y} - {1'b0, gun3_y};
	wire gun1_in = (gun1_dx[9:3] == 7'd0) && (gun1_dy[9:3] == 7'd0);
	wire gun2_in = (gun2_dx[9:3] == 7'd0) && (gun2_dy[9:3] == 7'd0);
	wire gun3_in = (gun3_dx[9:3] == 7'd0) && (gun3_dy[9:3] == 7'd0);
	wire [1:0] gun1_cross = (gun1_in ? crosshair_pixel(gun1_dx[2:0], gun1_dy[2:0]) : 2'd0);
	wire [1:0] gun2_cross = (gun2_in ? crosshair_pixel(gun2_dx[2:0], gun2_dy[2:0]) : 2'd0);
	wire [1:0] gun3_cross = (gun3_in ? crosshair_pixel(gun3_dx[2:0], gun3_dy[2:0]) : 2'd0);
	wire border_pixel = (border_en && de) && ((((raster_x < BORDER) || (raster_y < BORDER)) || (raster_x >= (screen_width - BORDER))) || (raster_y >= (screen_height - BORDER)));
	always @(*) begin
		rgb_out = rgb_in;
		if (de) begin
			if (border_pixel)
				rgb_out = 24'hffffff;
			else if ((crosshair_en && gun1_en) && (gun1_cross != 2'd0))
				rgb_out = (gun1_cross == 2'd3 ? 24'hffffff : 24'h000000);
			else if ((crosshair_en && gun2_en) && (gun2_cross != 2'd0))
				rgb_out = (gun2_cross == 2'd3 ? 24'hffffff : 24'h000000);
			else if ((crosshair_en && gun3_en) && (gun3_cross != 2'd0))
				rgb_out = (gun3_cross == 2'd3 ? 24'hffffff : 24'h000000);
		end
	end
endmodule
`default_nettype none
module revx_gun_aim (
	clk,
	rst,
	source,
	analog,
	joy_dir,
	frame_tick,
	adc_x,
	adc_y,
	dpad_adc_x,
	dpad_adc_y
);
	parameter [7:0] RATE_SLOW = 8'd2;
	parameter [7:0] RATE_FAST = 8'd6;
	parameter [7:0] RAMP_FRAMES = 8'd20;
	input wire clk;
	input wire rst;
	input wire [1:0] source;
	input wire [15:0] analog;
	input wire [3:0] joy_dir;
	input wire frame_tick;
	output wire [7:0] adc_x;
	output wire [7:0] adc_y;
	output wire [7:0] dpad_adc_x;
	output wire [7:0] dpad_adc_y;
	reg [7:0] jx = 8'h80;
	reg [7:0] jy = 8'h80;
	reg [7:0] hold_cnt = 8'd0;
	wire any_dir = |joy_dir;
	wire [7:0] rate = (hold_cnt >= RAMP_FRAMES ? RATE_FAST : RATE_SLOW);
	always @(posedge clk)
		if (rst) begin
			jx <= 8'h80;
			jy <= 8'h80;
			hold_cnt <= 8'd0;
		end
		else if (frame_tick) begin
			hold_cnt <= (any_dir ? (hold_cnt >= RAMP_FRAMES ? RAMP_FRAMES : hold_cnt + 8'd1) : 8'd0);
			if (joy_dir[0] && !joy_dir[1])
				jx <= (jx <= rate ? 8'd0 : jx - rate);
			else if (joy_dir[1] && !joy_dir[0])
				jx <= (jx >= (8'd255 - rate) ? 8'd255 : jx + rate);
			if (joy_dir[3] && !joy_dir[2])
				jy <= (jy <= rate ? 8'd0 : jy - rate);
			else if (joy_dir[2] && !joy_dir[3])
				jy <= (jy >= (8'd255 - rate) ? 8'd255 : jy + rate);
		end
	wire [7:0] joy_sel_x = jx;
	wire [7:0] joy_sel_y = jy;
	assign dpad_adc_x = joy_sel_x;
	assign dpad_adc_y = joy_sel_y;
	assign adc_x = (source == 2'd2 ? joy_sel_x : 8'h80 - analog[7:0]);
	assign adc_y = (source == 2'd2 ? joy_sel_y : 8'h80 + analog[15:8]);
endmodule
module revx_guns (
	clk,
	rst,
	joystick_l_analog_0,
	joystick_l_analog_1,
	joystick_l_analog_2,
	gun1_src,
	gun2_src,
	gun3_src,
	gun1_joy,
	gun2_joy,
	gun3_joy,
	an0,
	an1,
	an2,
	an3,
	an4,
	an5,
	pxl_cen,
	hs,
	vs,
	de,
	gun_en,
	border_en,
	crosshair_en,
	rgb_in,
	rgb_out,
	raster_x,
	raster_y
);
	parameter [8:0] BORDER_WIDTH = 9'd4;
	parameter [8:0] SCREEN_W = 9'd400;
	parameter [8:0] SCREEN_H = 9'd254;
	input wire clk;
	input wire rst;
	input wire [15:0] joystick_l_analog_0;
	input wire [15:0] joystick_l_analog_1;
	input wire [15:0] joystick_l_analog_2;
	input wire [1:0] gun1_src;
	input wire [1:0] gun2_src;
	input wire [1:0] gun3_src;
	input wire [3:0] gun1_joy;
	input wire [3:0] gun2_joy;
	input wire [3:0] gun3_joy;
	output wire [7:0] an0;
	output wire [7:0] an1;
	output wire [7:0] an2;
	output wire [7:0] an3;
	output wire [7:0] an4;
	output wire [7:0] an5;
	input wire pxl_cen;
	input wire hs;
	input wire vs;
	input wire de;
	input wire [2:0] gun_en;
	input wire border_en;
	input wire crosshair_en;
	input wire [23:0] rgb_in;
	output wire [23:0] rgb_out;
	output wire [8:0] raster_x;
	output wire [8:0] raster_y;
	reg vs_d;
	always @(posedge clk)
		if (rst)
			vs_d <= vs;
		else
			vs_d <= vs;
	wire frame_tick = vs & ~vs_d;
	wire [7:0] dpad_x1;
	wire [7:0] dpad_y1;
	wire [7:0] dpad_x2;
	wire [7:0] dpad_y2;
	wire [7:0] dpad_x3;
	wire [7:0] dpad_y3;
	revx_gun_aim u_aim1(
		.clk(clk),
		.rst(rst),
		.source(gun1_src),
		.analog(joystick_l_analog_0),
		.joy_dir(gun1_joy),
		.frame_tick(frame_tick),
		.adc_x(an0),
		.adc_y(an1),
		.dpad_adc_x(dpad_x1),
		.dpad_adc_y(dpad_y1)
	);
	revx_gun_aim u_aim2(
		.clk(clk),
		.rst(rst),
		.source(gun2_src),
		.analog(joystick_l_analog_1),
		.joy_dir(gun2_joy),
		.frame_tick(frame_tick),
		.adc_x(an2),
		.adc_y(an3),
		.dpad_adc_x(dpad_x2),
		.dpad_adc_y(dpad_y2)
	);
	revx_gun_aim u_aim3(
		.clk(clk),
		.rst(rst),
		.source(gun3_src),
		.analog(joystick_l_analog_2),
		.joy_dir(gun3_joy),
		.frame_tick(frame_tick),
		.adc_x(an4),
		.adc_y(an5),
		.dpad_adc_x(dpad_x3),
		.dpad_adc_y(dpad_y3)
	);
	wire [8:0] g1x;
	wire [8:0] g1y;
	wire [8:0] g2x;
	wire [8:0] g2y;
	wire [8:0] g3x;
	wire [8:0] g3y;
	wire [7:0] unused_ax [0:2];
	wire [7:0] unused_ay [0:2];
	wire unused_gs [0:2];
	revx_lightgun_position #(
		.DEFAULT_WIDTH(SCREEN_W),
		.DEFAULT_HEIGHT(SCREEN_H)
	) u_p1(
		.clk(clk),
		.rst(rst),
		.vs(vs),
		.screen_width(SCREEN_W),
		.screen_height(SCREEN_H),
		.rotate(2'd0),
		.sensitivity(2'd0),
		.source(2'd0),
		.joyana(joystick_l_analog_0),
		.joy_dir(4'd0),
		.mouse_dx(8'd0),
		.mouse_dy(8'd0),
		.mouse_strobe(1'b0),
		.gun_x(g1x),
		.gun_y(g1y),
		.adc_x(unused_ax[0]),
		.adc_y(unused_ay[0]),
		.gun_strobe(unused_gs[0])
	);
	revx_lightgun_position #(
		.DEFAULT_WIDTH(SCREEN_W),
		.DEFAULT_HEIGHT(SCREEN_H)
	) u_p2(
		.clk(clk),
		.rst(rst),
		.vs(vs),
		.screen_width(SCREEN_W),
		.screen_height(SCREEN_H),
		.rotate(2'd0),
		.sensitivity(2'd0),
		.source(2'd0),
		.joyana(joystick_l_analog_1),
		.joy_dir(4'd0),
		.mouse_dx(8'd0),
		.mouse_dy(8'd0),
		.mouse_strobe(1'b0),
		.gun_x(g2x),
		.gun_y(g2y),
		.adc_x(unused_ax[1]),
		.adc_y(unused_ay[1]),
		.gun_strobe(unused_gs[1])
	);
	revx_lightgun_position #(
		.DEFAULT_WIDTH(SCREEN_W),
		.DEFAULT_HEIGHT(SCREEN_H)
	) u_p3(
		.clk(clk),
		.rst(rst),
		.vs(vs),
		.screen_width(SCREEN_W),
		.screen_height(SCREEN_H),
		.rotate(2'd0),
		.sensitivity(2'd0),
		.source(2'd0),
		.joyana(joystick_l_analog_2),
		.joy_dir(4'd0),
		.mouse_dx(8'd0),
		.mouse_dy(8'd0),
		.mouse_strobe(1'b0),
		.gun_x(g3x),
		.gun_y(g3y),
		.adc_x(unused_ax[2]),
		.adc_y(unused_ay[2]),
		.gun_strobe(unused_gs[2])
	);
	function automatic [8:0] adc_to_scr_x;
		input [7:0] ax;
		input [8:0] w;
		reg [17:0] p;
		reg [8:0] r;
		begin
			p = (9'd256 - {1'b0, ax}) * w;
			r = p[16:8];
			adc_to_scr_x = (r >= w ? w - 9'd1 : r);
		end
	endfunction
	function automatic [8:0] adc_to_scr_y;
		input [7:0] ay;
		input [8:0] h;
		reg [17:0] p;
		reg [8:0] r;
		begin
			p = {1'b0, ay} * h;
			r = p[16:8];
			adc_to_scr_y = (r >= h ? h - 9'd1 : r);
		end
	endfunction
	wire [8:0] cx1 = (gun1_src == 2'd2 ? adc_to_scr_x(dpad_x1, SCREEN_W) : g1x);
	wire [8:0] cy1 = (gun1_src == 2'd2 ? adc_to_scr_y(dpad_y1, SCREEN_H) : g1y);
	wire [8:0] cx2 = (gun2_src == 2'd2 ? adc_to_scr_x(dpad_x2, SCREEN_W) : g2x);
	wire [8:0] cy2 = (gun2_src == 2'd2 ? adc_to_scr_y(dpad_y2, SCREEN_H) : g2y);
	wire [8:0] cx3 = (gun3_src == 2'd2 ? adc_to_scr_x(dpad_x3, SCREEN_W) : g3x);
	wire [8:0] cy3 = (gun3_src == 2'd2 ? adc_to_scr_y(dpad_y3, SCREEN_H) : g3y);
	reg [8:0] cx1_q;
	reg [8:0] cy1_q;
	reg [8:0] cx2_q;
	reg [8:0] cy2_q;
	reg [8:0] cx3_q;
	reg [8:0] cy3_q;
	always @(posedge clk)
		if (rst) begin
			cx1_q <= 9'd0;
			cy1_q <= 9'd0;
			cx2_q <= 9'd0;
			cy2_q <= 9'd0;
			cx3_q <= 9'd0;
			cy3_q <= 9'd0;
		end
		else begin
			cx1_q <= cx1;
			cy1_q <= cy1;
			cx2_q <= cx2;
			cy2_q <= cy2;
			cx3_q <= cx3;
			cy3_q <= cy3;
		end
	revx_lightgun_overlay #(.BORDER_WIDTH(BORDER_WIDTH)) u_ovl(
		.clk(clk),
		.rst(rst),
		.pxl_cen(pxl_cen),
		.hs(hs),
		.vs(vs),
		.de(de),
		.screen_width(SCREEN_W),
		.screen_height(SCREEN_H),
		.gun1_x(cx1_q),
		.gun1_y(cy1_q),
		.gun2_x(cx2_q),
		.gun2_y(cy2_q),
		.gun3_x(cx3_q),
		.gun3_y(cy3_q),
		.gun1_en(gun_en[0]),
		.gun2_en(gun_en[1]),
		.gun3_en(gun_en[2]),
		.border_en(border_en),
		.crosshair_en(crosshair_en),
		.rgb_in(rgb_in),
		.rgb_out(rgb_out),
		.raster_x(raster_x),
		.raster_y(raster_y)
	);
endmodule
`default_nettype wire
`default_nettype none
module revx_mem (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_be,
	mem_wdata,
	mem_rdata,
	mem_ack,
	in0,
	in1,
	in2,
	dsw,
	sysctrl0,
	sysctrl1,
	dcs_reset,
	cmos_write_enable,
	gun_recoil,
	gun_led,
	watchdog_kick,
	adc_wr,
	adc_wdata,
	adc_rd,
	adc_rdata,
	adc_done,
	uart_wr,
	uart_rd,
	uart_reg,
	uart_wdata,
	uart_rdata,
	pic_cmd_we,
	pic_cmd,
	pic_clk_we,
	pic_clk,
	pic_resp_re,
	pic_data,
	pic_status,
	dma_we,
	dma_rd,
	dma_pair,
	dma_wdata,
	dma_rdata,
	gfx_rd,
	gfx_baddr,
	gfx_rdata,
	rom_rd,
	rom_waddr,
	rom_rdata,
	dbg_region
);
	reg _sv2v_0;
	parameter signed [31:0] RAM_WORDS = 32'h00001000;
	parameter signed [31:0] PAL_ENTRIES = 32'h00008000;
	parameter signed [31:0] CMOS_BYTES = 32'h00002000;
	parameter signed [31:0] VRAM_WORDS = 32'h00001000;
	parameter [0:0] IO_ONLY = 1'b0;
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [3:0] mem_be;
	input wire [31:0] mem_wdata;
	output wire [31:0] mem_rdata;
	output wire mem_ack;
	input wire [31:0] in0;
	input wire [31:0] in1;
	input wire [31:0] in2;
	input wire [31:0] dsw;
	output reg [3:0] sysctrl0;
	output reg [3:0] sysctrl1;
	output wire dcs_reset;
	output wire cmos_write_enable;
	output reg [2:0] gun_recoil;
	output reg [2:0] gun_led;
	output wire watchdog_kick;
	output wire adc_wr;
	output wire [7:0] adc_wdata;
	output wire adc_rd;
	input wire [7:0] adc_rdata;
	input wire adc_done;
	output wire uart_wr;
	output wire uart_rd;
	output wire [2:0] uart_reg;
	output wire [7:0] uart_wdata;
	input wire [7:0] uart_rdata;
	output wire pic_cmd_we;
	output wire [3:0] pic_cmd;
	output wire pic_clk_we;
	output wire pic_clk;
	output wire pic_resp_re;
	input wire [7:0] pic_data;
	input wire pic_status;
	output wire dma_we;
	output wire dma_rd;
	output wire [2:0] dma_pair;
	output wire [31:0] dma_wdata;
	input wire [31:0] dma_rdata;
	output wire gfx_rd;
	output wire [23:0] gfx_baddr;
	input wire [31:0] gfx_rdata;
	output wire rom_rd;
	output wire [18:0] rom_waddr;
	input wire [31:0] rom_rdata;
	output wire [4:0] dbg_region;
	localparam [4:0] R_NONE = 5'd0;
	localparam [4:0] R_VRAMD = 5'd1;
	localparam [4:0] R_VRAMC = 5'd2;
	localparam [4:0] R_RAM = 5'd3;
	localparam [4:0] R_SYSC = 5'd4;
	localparam [4:0] R_STATUS = 5'd5;
	localparam [4:0] R_IN0 = 5'd6;
	localparam [4:0] R_IN1 = 5'd7;
	localparam [4:0] R_IN2 = 5'd8;
	localparam [4:0] R_DSW = 5'd9;
	localparam [4:0] R_IO = 5'd10;
	localparam [4:0] R_SEC = 5'd11;
	localparam [4:0] R_ADC = 5'd12;
	localparam [4:0] R_UART = 5'd13;
	localparam [4:0] R_CMOS = 5'd14;
	localparam [4:0] R_PAL = 5'd15;
	localparam [4:0] R_DMA = 5'd16;
	localparam [4:0] R_GFX = 5'd17;
	localparam [4:0] R_ROM = 5'd18;
	reg [4:0] region;
	always @(*) begin
		if (_sv2v_0)
			;
		region = R_NONE;
		if (mem_addr[31:22] == 10'd0)
			region = R_VRAMD;
		else if (mem_addr[31:22] == 10'd2)
			region = R_VRAMC;
		else if (mem_addr[31:24] == 8'h20)
			region = R_RAM;
		else if ((mem_addr[31:28] == 4'h4) && (mem_addr[27:0] >= 28'h0800000))
			region = R_SYSC;
		else if (mem_addr[31:5] == (32'h60400000 >> 5))
			region = R_STATUS;
		else if (mem_addr[31:8] == 24'h60c000)
			(* full_case, parallel_case *)
			case (mem_addr[7:5])
				3'd0: region = R_IN0;
				3'd1: region = R_IN1;
				3'd2: region = R_IN2;
				3'd3: region = R_DSW;
				3'd7: region = R_SEC;
				default: region = R_IO;
			endcase
		else if (mem_addr[31:5] == (32'h80800000 >> 5))
			region = R_ADC;
		else if (mem_addr[31:8] == 24'h80c000)
			region = R_UART;
		else if (mem_addr[31:18] == (32'ha0440000 >> 18))
			region = R_CMOS;
		else if (mem_addr[31:20] == 12'ha08)
			region = R_PAL;
		else if ((mem_addr[31:24] == 8'hc0) && ((mem_addr[23:20] == 4'h8) || (mem_addr[23:20] == 4'hc)))
			region = R_DMA;
		else if ((mem_addr[31:24] >= 8'hf8) && (mem_addr[31:24] <= 8'hfe))
			region = R_GFX;
		else if (mem_addr[31:24] == 8'hff)
			region = R_ROM;
	end
	assign dbg_region = region;
	wire [12:0] ram_idx_r = mem_addr[17:5];
	wire [12:0] cmos_idx_r = mem_addr[17:5];
	wire [2:0] io_sel = mem_addr[7:5] - 3'd4;
	wire [14:0] pal_idx_r = mem_addr[19:5];
	wire [13:0] vram_i0_r = mem_addr[18:5];
	wire [13:0] vram_i1_r = vram_i0_r + 1'b1;
	wire [12:0] ram_idx = (IO_ONLY ? 13'd0 : ram_idx_r);
	wire [12:0] cmos_idx = (IO_ONLY ? 13'd0 : cmos_idx_r);
	wire [14:0] pal_idx = (IO_ONLY ? 15'd0 : pal_idx_r);
	wire [13:0] vram_i0 = (IO_ONLY ? 14'd0 : vram_i0_r);
	wire [13:0] vram_i1 = (IO_ONLY ? 14'd0 : vram_i1_r);
	localparam signed [31:0] RAMN = (IO_ONLY ? 1 : 8192);
	localparam signed [31:0] PALN = (IO_ONLY ? 1 : 32768);
	localparam signed [31:0] NVRN = (IO_ONLY ? 1 : 8192);
	localparam signed [31:0] VRMN = (IO_ONLY ? 1 : 16384);
	reg [31:0] ram [0:RAMN - 1];
	reg [15:0] pal [0:PALN - 1];
	reg [7:0] nvram [0:NVRN - 1];
	reg [15:0] vram [0:VRMN - 1];
	reg busy;
	reg [31:0] rdata_q;
	reg ack_q;
	reg adc_wr_s;
	reg adc_rd_s;
	reg uart_wr_s;
	reg uart_rd_s;
	reg pic_cmd_we_s;
	reg pic_clk_we_s;
	reg pic_resp_re_s;
	reg dma_we_s;
	reg dma_rd_s;
	reg gfx_rd_s;
	reg rom_rd_s;
	reg wdog_s;
	assign adc_wr = adc_wr_s;
	assign adc_rd = adc_rd_s;
	assign uart_wr = uart_wr_s;
	assign uart_rd = uart_rd_s;
	assign pic_cmd_we = pic_cmd_we_s;
	assign pic_clk_we = pic_clk_we_s;
	assign pic_resp_re = pic_resp_re_s;
	assign dma_we = dma_we_s;
	assign dma_rd = dma_rd_s;
	assign gfx_rd = gfx_rd_s;
	assign rom_rd = rom_rd_s;
	assign watchdog_kick = wdog_s;
	assign adc_wdata = mem_wdata[7:0];
	assign uart_reg = mem_addr[7:5];
	assign uart_wdata = mem_wdata[7:0];
	assign pic_cmd = mem_wdata[3:0];
	assign pic_clk = mem_wdata[1];
	assign dma_pair = mem_addr[7:5];
	assign dma_wdata = mem_wdata;
	wire [26:0] gfx_off = {mem_addr[31:24] - 8'hf8, mem_addr[23:0]};
	assign gfx_baddr = gfx_off[26:3];
	assign rom_waddr = mem_addr[23:5];
	assign mem_rdata = rdata_q;
	assign mem_ack = ack_q;
	integer i;
	always @(posedge clk) begin
		adc_wr_s <= 1'b0;
		adc_rd_s <= 1'b0;
		uart_wr_s <= 1'b0;
		uart_rd_s <= 1'b0;
		pic_cmd_we_s <= 1'b0;
		pic_clk_we_s <= 1'b0;
		pic_resp_re_s <= 1'b0;
		dma_we_s <= 1'b0;
		dma_rd_s <= 1'b0;
		gfx_rd_s <= 1'b0;
		rom_rd_s <= 1'b0;
		wdog_s <= 1'b0;
		ack_q <= 1'b0;
		if (rst) begin
			busy <= 1'b0;
			rdata_q <= 32'd0;
			sysctrl0 <= 4'd0;
			sysctrl1 <= 4'd0;
			gun_recoil <= 3'd0;
			gun_led <= 3'd0;
		end
		else if (mem_req && !busy) begin
			busy <= 1'b1;
			ack_q <= 1'b1;
			rdata_q <= 32'd0;
			if (mem_we)
				(* full_case, parallel_case *)
				case (region)
					R_VRAMD, R_VRAMC:
						if (!IO_ONLY) begin
							if (mem_be[0] || mem_be[1])
								vram[vram_i0] <= mem_wdata[15:0];
							if (mem_be[2] || mem_be[3])
								vram[vram_i1] <= mem_wdata[31:16];
						end
					R_RAM:
						if (!IO_ONLY) begin
							if (mem_be[0])
								ram[ram_idx][7:0] <= mem_wdata[7:0];
							if (mem_be[1])
								ram[ram_idx][15:8] <= mem_wdata[15:8];
							if (mem_be[2])
								ram[ram_idx][23:16] <= mem_wdata[23:16];
							if (mem_be[3])
								ram[ram_idx][31:24] <= mem_wdata[31:24];
						end
					R_SYSC:
						if (mem_be[0]) begin
							if (mem_addr[22] == 1'b0)
								sysctrl0 <= mem_wdata[3:0];
							else
								sysctrl1 <= mem_wdata[3:0];
						end
					R_STATUS: pic_clk_we_s <= mem_be[0];
					R_IO:
						if (io_sel == 3'd2)
							wdog_s <= 1'b1;
						else begin
							gun_recoil <= mem_wdata[2:0];
							gun_led <= ~mem_wdata[6:4];
						end
					R_SEC: pic_cmd_we_s <= mem_be[0];
					R_ADC: adc_wr_s <= mem_be[0];
					R_UART: uart_wr_s <= mem_be[0];
					R_CMOS:
						if (!IO_ONLY && mem_be[0])
							nvram[cmos_idx] <= mem_wdata[7:0];
					R_PAL:
						if (!IO_ONLY)
							pal[pal_idx] <= mem_wdata[15:0];
					R_DMA: dma_we_s <= 1'b1;
					default:
						;
				endcase
			else
				(* full_case, parallel_case *)
				case (region)
					R_VRAMD, R_VRAMC: rdata_q <= (IO_ONLY ? 32'd0 : {vram[vram_i1], vram[vram_i0]});
					R_RAM: rdata_q <= (IO_ONLY ? 32'd0 : ram[ram_idx]);
					R_STATUS: rdata_q <= {30'd0, pic_status, adc_done};
					R_IN0: rdata_q <= in0;
					R_IN1: rdata_q <= in1;
					R_IN2: rdata_q <= in2;
					R_DSW: rdata_q <= dsw;
					R_SEC: begin
						rdata_q <= {24'd0, pic_data};
						pic_resp_re_s <= 1'b1;
					end
					R_ADC: begin
						rdata_q <= {24'd0, adc_rdata};
						adc_rd_s <= 1'b1;
					end
					R_UART: begin
						rdata_q <= {24'd0, uart_rdata};
						uart_rd_s <= 1'b1;
					end
					R_CMOS: rdata_q <= (IO_ONLY ? 32'd0 : {24'd0, nvram[cmos_idx]});
					R_PAL: rdata_q <= (IO_ONLY ? 32'd0 : {16'd0, pal[pal_idx]});
					R_DMA: begin
						rdata_q <= dma_rdata;
						dma_rd_s <= 1'b1;
					end
					R_GFX: begin
						rdata_q <= gfx_rdata;
						gfx_rd_s <= 1'b1;
					end
					R_ROM: begin
						rdata_q <= rom_rdata;
						rom_rd_s <= 1'b1;
					end
					default: rdata_q <= 32'd0;
				endcase
		end
		else
			busy <= 1'b0;
	end
	assign dcs_reset = sysctrl1[1];
	assign cmos_write_enable = sysctrl0[2];
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module revx_memsys (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_be,
	mem_wdata,
	mem_rdata,
	mem_ack,
	in0,
	in1,
	in2,
	dsw,
	an0,
	an1,
	an2,
	an3,
	an4,
	an5,
	dcs_ctrl,
	dcs_data_in,
	dcs_output_full,
	dcs_data_w,
	dcs_data_o,
	dcs_data_rd,
	dcs_reset,
	lint1,
	sysctrl0,
	sysctrl1,
	cmos_write_enable,
	gun_recoil,
	gun_led,
	watchdog_kick,
	dbg_pic_status,
	dbg_uart_last,
	dbg_adc_chan,
	dbg_adc_last,
	dma_reg_we,
	dma_reg_addr,
	dma_reg_wdata,
	dma_reg_pair,
	dma_pair_rdata,
	gfx_rd,
	gfx_baddr,
	gfx_rdata,
	rom_rd,
	rom_waddr,
	rom_rdata
);
	parameter signed [31:0] ADC_CONV_CLKS = 16;
	parameter [0:0] IO_ONLY = 1'b0;
	parameter [0:0] EXTERNAL_DMA = 1'b0;
	parameter [127:0] PIC_RESPONSE_BYTES = 128'he89a1caff4141d1a2217478efb02c445;
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [3:0] mem_be;
	input wire [31:0] mem_wdata;
	output wire [31:0] mem_rdata;
	output wire mem_ack;
	input wire [31:0] in0;
	input wire [31:0] in1;
	input wire [31:0] in2;
	input wire [31:0] dsw;
	input wire [7:0] an0;
	input wire [7:0] an1;
	input wire [7:0] an2;
	input wire [7:0] an3;
	input wire [7:0] an4;
	input wire [7:0] an5;
	input wire [15:0] dcs_ctrl;
	input wire [7:0] dcs_data_in;
	input wire dcs_output_full;
	output wire dcs_data_w;
	output wire [7:0] dcs_data_o;
	output wire dcs_data_rd;
	output wire dcs_reset;
	output wire lint1;
	output wire [3:0] sysctrl0;
	output wire [3:0] sysctrl1;
	output wire cmos_write_enable;
	output wire [2:0] gun_recoil;
	output wire [2:0] gun_led;
	output wire watchdog_kick;
	output wire dbg_pic_status;
	output reg [7:0] dbg_uart_last;
	output reg [7:0] dbg_adc_chan;
	output reg [7:0] dbg_adc_last;
	output reg dma_reg_we;
	output reg [3:0] dma_reg_addr;
	output reg [15:0] dma_reg_wdata;
	output wire [2:0] dma_reg_pair;
	input wire [31:0] dma_pair_rdata;
	output wire gfx_rd;
	output wire [23:0] gfx_baddr;
	input wire [31:0] gfx_rdata;
	output wire rom_rd;
	output wire [18:0] rom_waddr;
	input wire [31:0] rom_rdata;
	wire m_adc_wr;
	wire m_adc_rd;
	wire [7:0] m_adc_wdata;
	wire m_uart_wr;
	wire m_uart_rd;
	wire [2:0] m_uart_reg;
	wire [7:0] m_uart_wdata;
	wire m_pic_cmd_we;
	wire m_pic_clk_we;
	wire m_pic_resp_re;
	wire [3:0] m_pic_cmd;
	wire m_pic_clk;
	wire [7:0] m_adc_rdata;
	wire [7:0] m_uart_rdata;
	wire [7:0] m_pic_data;
	wire m_adc_done;
	wire m_pic_status;
	wire m_dma_we;
	wire m_dma_rd;
	wire [2:0] m_dma_pair;
	wire [31:0] m_dma_wdata;
	wire [31:0] m_dma_rdata;
	reg pr_req;
	reg pr_we;
	reg [31:0] pr_addr;
	reg [31:0] pr_wdata;
	reg [3:0] pr_be;
	reg stg_busy;
	wire [31:0] umem_rdata;
	wire umem_ack;
	assign mem_rdata = umem_rdata;
	assign mem_ack = umem_ack;
	always @(posedge clk)
		if (rst) begin
			pr_req <= 1'b0;
			stg_busy <= 1'b0;
		end
		else begin
			pr_req <= 1'b0;
			if (!stg_busy) begin
				if (mem_req && !umem_ack) begin
					pr_req <= 1'b1;
					pr_we <= mem_we;
					pr_addr <= mem_addr;
					pr_be <= mem_be;
					pr_wdata <= mem_wdata;
					stg_busy <= 1'b1;
				end
			end
			else if (umem_ack)
				stg_busy <= 1'b0;
		end
	revx_mem #(.IO_ONLY(IO_ONLY)) u_mem(
		.clk(clk),
		.rst(rst),
		.mem_req(pr_req),
		.mem_we(pr_we),
		.mem_addr(pr_addr),
		.mem_be(pr_be),
		.mem_wdata(pr_wdata),
		.mem_rdata(umem_rdata),
		.mem_ack(umem_ack),
		.in0(in0),
		.in1(in1),
		.in2(in2),
		.dsw(dsw),
		.sysctrl0(sysctrl0),
		.sysctrl1(sysctrl1),
		.dcs_reset(dcs_reset),
		.cmos_write_enable(cmos_write_enable),
		.gun_recoil(gun_recoil),
		.gun_led(gun_led),
		.watchdog_kick(watchdog_kick),
		.adc_wr(m_adc_wr),
		.adc_wdata(m_adc_wdata),
		.adc_rd(m_adc_rd),
		.adc_rdata(m_adc_rdata),
		.adc_done(m_adc_done),
		.uart_wr(m_uart_wr),
		.uart_rd(m_uart_rd),
		.uart_reg(m_uart_reg),
		.uart_wdata(m_uart_wdata),
		.uart_rdata(m_uart_rdata),
		.pic_cmd_we(m_pic_cmd_we),
		.pic_cmd(m_pic_cmd),
		.pic_clk_we(m_pic_clk_we),
		.pic_clk(m_pic_clk),
		.pic_resp_re(m_pic_resp_re),
		.pic_data(m_pic_data),
		.pic_status(m_pic_status),
		.dma_we(m_dma_we),
		.dma_rd(m_dma_rd),
		.dma_pair(m_dma_pair),
		.dma_wdata(m_dma_wdata),
		.dma_rdata(m_dma_rdata),
		.gfx_rd(gfx_rd),
		.gfx_baddr(gfx_baddr),
		.gfx_rdata(gfx_rdata),
		.rom_rd(rom_rd),
		.rom_waddr(rom_waddr),
		.rom_rdata(rom_rdata),
		.dbg_region()
	);
	assign dbg_pic_status = m_pic_status;
	always @(posedge clk)
		if (rst) begin
			dbg_uart_last <= 0;
			dbg_adc_chan <= 0;
			dbg_adc_last <= 0;
		end
		else begin
			if (m_uart_wr && (m_uart_reg == 3))
				dbg_uart_last <= m_uart_wdata;
			if (m_uart_rd && (m_uart_reg == 3))
				dbg_uart_last <= m_uart_rdata;
			if (m_adc_wr)
				dbg_adc_chan <= m_adc_wdata;
			if (m_adc_rd)
				dbg_adc_last <= m_adc_rdata;
		end
	revx_adc0848 #(.CONV_CLKS(ADC_CONV_CLKS)) u_adc(
		.clk(clk),
		.rst(rst),
		.wr(m_adc_wr),
		.wdata(m_adc_wdata),
		.rd(m_adc_rd),
		.an0(an0),
		.an1(an1),
		.an2(an2),
		.an3(an3),
		.an4(an4),
		.an5(an5),
		.result(m_adc_rdata),
		.done(m_adc_done)
	);
	revx_uart u_uart(
		.clk(clk),
		.rst(rst),
		.uart_wr(m_uart_wr),
		.uart_rd(m_uart_rd),
		.uart_reg(m_uart_reg),
		.uart_wdata(m_uart_wdata),
		.uart_rdata(m_uart_rdata),
		.dcs_ctrl(dcs_ctrl),
		.dcs_data_in(dcs_data_in),
		.dcs_data_w(dcs_data_w),
		.dcs_data_o(dcs_data_o),
		.dcs_data_rd(dcs_data_rd),
		.dcs_output_full(dcs_output_full),
		.lint1(lint1)
	);
	revx_pic_adapter #(.RESPONSE_BYTES(PIC_RESPONSE_BYTES)) u_pic(
		.clk(clk),
		.rst(rst),
		.cmd_we(m_pic_cmd_we),
		.cmd_nibble(m_pic_cmd),
		.clk_we(m_pic_clk_we),
		.clk_bit(m_pic_clk),
		.resp_re(m_pic_resp_re),
		.pic_reset(1'b0),
		.pic_data(m_pic_data),
		.pic_status(m_pic_status)
	);
	reg [15:0] dma_shadow [0:15];
	reg wr_pending;
	reg [2:0] wr_pair;
	reg [15:0] wr_hi;
	assign dma_reg_pair = m_dma_pair;
	wire [31:0] dma_read_pair = (EXTERNAL_DMA ? dma_pair_rdata : {dma_shadow[{m_dma_pair, 1'b1}], dma_shadow[{m_dma_pair, 1'b0}]});
	assign m_dma_rdata = {(|pr_be[1:0] ? dma_read_pair[31:16] : 16'd0), dma_read_pair[15:0]};
	always @(posedge clk)
		if (rst) begin
			dma_reg_we <= 1'b0;
			wr_pending <= 1'b0;
		end
		else begin
			dma_reg_we <= 1'b0;
			if (m_dma_we) begin
				dma_reg_we <= 1'b1;
				dma_reg_addr <= {m_dma_pair, 1'b0};
				dma_reg_wdata <= m_dma_wdata[15:0];
				dma_shadow[{m_dma_pair, 1'b0}] <= m_dma_wdata[15:0];
				wr_pending <= |pr_be[1:0];
				wr_pair <= m_dma_pair;
				wr_hi <= m_dma_wdata[31:16];
			end
			else if (wr_pending) begin
				dma_reg_we <= 1'b1;
				dma_reg_addr <= {wr_pair, 1'b1};
				dma_reg_wdata <= wr_hi;
				dma_shadow[{wr_pair, 1'b1}] <= wr_hi;
				wr_pending <= 1'b0;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module revx_adc0848 (
	clk,
	rst,
	wr,
	wdata,
	rd,
	an0,
	an1,
	an2,
	an3,
	an4,
	an5,
	result,
	done
);
	reg _sv2v_0;
	parameter signed [31:0] CONV_CLKS = 16;
	input wire clk;
	input wire rst;
	input wire wr;
	input wire [7:0] wdata;
	input wire rd;
	input wire [7:0] an0;
	input wire [7:0] an1;
	input wire [7:0] an2;
	input wire [7:0] an3;
	input wire [7:0] an4;
	input wire [7:0] an5;
	output reg [7:0] result;
	output reg done;
	wire [7:0] ch1 = an0;
	wire [7:0] ch2 = an1;
	wire [7:0] ch3 = an2;
	wire [7:0] ch4 = an3;
	wire [7:0] ch5 = an4;
	wire [7:0] ch6 = an5;
	wire [7:0] ch7 = 8'hff;
	wire [7:0] ch8 = 8'hff;
	function automatic [7:0] clamp;
		input signed [10:0] v;
		if (v > 11'sd255)
			clamp = 8'hff;
		else if (v < 11'sd0)
			clamp = 8'h00;
		else
			clamp = v[7:0];
	endfunction
	function automatic [7:0] convert;
		input [4:0] chan;
		case (chan)
			5'h00, 5'h10: convert = clamp(11'sd255 - ($signed({3'b000, ch2}) - $signed({3'b000, ch1})));
			5'h01, 5'h11: convert = clamp(11'sd255 - ($signed({3'b000, ch1}) - $signed({3'b000, ch2})));
			5'h02, 5'h12: convert = clamp(11'sd255 - ($signed({3'b000, ch4}) - $signed({3'b000, ch3})));
			5'h03, 5'h13: convert = clamp(11'sd255 - ($signed({3'b000, ch3}) - $signed({3'b000, ch4})));
			5'h04, 5'h14: convert = clamp(11'sd255 - ($signed({3'b000, ch6}) - $signed({3'b000, ch5})));
			5'h05, 5'h15: convert = clamp(11'sd255 - ($signed({3'b000, ch5}) - $signed({3'b000, ch6})));
			5'h06, 5'h16: convert = clamp(11'sd255 - ($signed({3'b000, ch8}) - $signed({3'b000, ch7})));
			5'h07, 5'h17: convert = clamp(11'sd255 - ($signed({3'b000, ch7}) - $signed({3'b000, ch8})));
			5'h08: convert = ch1;
			5'h09: convert = ch2;
			5'h0a: convert = ch3;
			5'h0b: convert = ch4;
			5'h0c: convert = ch5;
			5'h0d: convert = ch6;
			5'h0e: convert = ch7;
			5'h0f: convert = ch8;
			5'h18: convert = clamp(11'sd255 - ($signed({3'b000, ch8}) - $signed({3'b000, ch1})));
			5'h19: convert = clamp(11'sd255 - ($signed({3'b000, ch8}) - $signed({3'b000, ch2})));
			5'h1a: convert = clamp(11'sd255 - ($signed({3'b000, ch8}) - $signed({3'b000, ch3})));
			5'h1b: convert = clamp(11'sd255 - ($signed({3'b000, ch8}) - $signed({3'b000, ch4})));
			5'h1c: convert = clamp(11'sd255 - ($signed({3'b000, ch8}) - $signed({3'b000, ch5})));
			5'h1d: convert = clamp(11'sd255 - ($signed({3'b000, ch8}) - $signed({3'b000, ch6})));
			5'h1e: convert = clamp(11'sd255 - ($signed({3'b000, ch8}) - $signed({3'b000, ch7})));
			default: convert = 8'h00;
		endcase
	endfunction
	reg [4:0] channel;
	reg [31:0] timer;
	reg converting;
	always @(posedge clk)
		if (rst) begin
			channel <= 5'h0f;
			result <= 8'hff;
			done <= 1'b0;
			timer <= 32'd0;
			converting <= 1'b0;
		end
		else begin
			if (wr) begin
				channel <= wdata[4:0];
				done <= 1'b0;
				timer <= CONV_CLKS[31:0];
				converting <= 1'b1;
			end
			else if (converting) begin
				if (timer <= 32'd1) begin
					converting <= 1'b0;
					result <= convert(channel);
					done <= 1'b1;
				end
				else
					timer <= timer - 32'd1;
			end
			if (rd && !wr)
				done <= 1'b0;
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module revx_uart (
	clk,
	rst,
	uart_wr,
	uart_rd,
	uart_reg,
	uart_wdata,
	uart_rdata,
	dcs_ctrl,
	dcs_data_in,
	dcs_data_w,
	dcs_data_o,
	dcs_data_rd,
	dcs_output_full,
	lint1
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire uart_wr;
	input wire uart_rd;
	input wire [2:0] uart_reg;
	input wire [7:0] uart_wdata;
	output reg [7:0] uart_rdata;
	input wire [15:0] dcs_ctrl;
	input wire [7:0] dcs_data_in;
	output wire dcs_data_w;
	output wire [7:0] dcs_data_o;
	output wire dcs_data_rd;
	input wire dcs_output_full;
	output reg lint1;
	reg [7:0] uart [0:7];
	wire loopback = uart[1] == 8'h66;
	always @(*) begin
		if (_sv2v_0)
			;
		case (uart_reg)
			3'd0: uart_rdata = 8'h13;
			3'd1: uart_rdata = (loopback ? 8'h05 : ((dcs_ctrl & 16'h0800) >> 9) | ((~dcs_ctrl & 16'h0400) >> 10));
			3'd3: uart_rdata = (loopback ? uart[3] : dcs_data_in);
			3'd5: uart_rdata = (loopback ? 8'h05 : ((dcs_ctrl & 16'h0800) >> 11) | ((~dcs_ctrl & 16'h0400) >> 8));
			default: uart_rdata = uart[uart_reg];
		endcase
	end
	assign dcs_data_w = (uart_wr && (uart_reg == 3'd3)) && !loopback;
	assign dcs_data_o = uart_wdata;
	assign dcs_data_rd = ((uart_rd && (uart_reg == 3'd3)) && !loopback) || (uart_wr && (uart_reg == 3'd5));
	integer i;
	always @(posedge clk)
		if (rst) begin
			for (i = 0; i < 8; i = i + 1)
				uart[i] <= 8'h00;
			lint1 <= 1'b0;
		end
		else begin
			if (uart_wr)
				case (uart_reg)
					3'd3:
						if (loopback)
							uart[3] <= uart_wdata;
					3'd5:
						;
					default: uart[uart_reg] <= uart_wdata;
				endcase
			if (!loopback)
				lint1 <= dcs_output_full;
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module revx_pic_adapter (
	clk,
	rst,
	cmd_we,
	cmd_nibble,
	clk_we,
	clk_bit,
	resp_re,
	pic_reset,
	pic_data,
	pic_status
);
	parameter [127:0] RESPONSE_BYTES = 128'he89a1caff4141d1a2217478efb02c445;
	input wire clk;
	input wire rst;
	input wire cmd_we;
	input wire [3:0] cmd_nibble;
	input wire clk_we;
	input wire clk_bit;
	input wire resp_re;
	input wire pic_reset;
	output wire [7:0] pic_data;
	output wire pic_status;
	function automatic [7:0] pic_byte;
		input reg [3:0] a;
		case (a)
			4'h0: pic_byte = RESPONSE_BYTES[7:0];
			4'h1: pic_byte = RESPONSE_BYTES[15:8];
			4'h2: pic_byte = RESPONSE_BYTES[23:16];
			4'h3: pic_byte = RESPONSE_BYTES[31:24];
			4'h4: pic_byte = RESPONSE_BYTES[39:32];
			4'h5: pic_byte = RESPONSE_BYTES[47:40];
			4'h6: pic_byte = RESPONSE_BYTES[55:48];
			4'h7: pic_byte = RESPONSE_BYTES[63:56];
			4'h8: pic_byte = RESPONSE_BYTES[71:64];
			4'h9: pic_byte = RESPONSE_BYTES[79:72];
			4'ha: pic_byte = RESPONSE_BYTES[87:80];
			4'hb: pic_byte = RESPONSE_BYTES[95:88];
			4'hc: pic_byte = RESPONSE_BYTES[103:96];
			4'hd: pic_byte = RESPONSE_BYTES[111:104];
			4'he: pic_byte = RESPONSE_BYTES[119:112];
			default: pic_byte = RESPONSE_BYTES[127:120];
		endcase
	endfunction
	reg [3:0] idx;
	reg stat;
	reg clk_prev;
	reg echo_command;
	always @(posedge clk)
		if (rst || pic_reset) begin
			idx <= 4'd0;
			echo_command <= 1'b0;
			stat <= 1'b0;
			clk_prev <= 1'b0;
		end
		else begin
			if (cmd_we && (cmd_nibble == 4'd0)) begin
				idx <= 4'd0;
				stat <= 1'b1;
				echo_command <= 1'b0;
			end
			if (cmd_we && (cmd_nibble == 4'hf)) begin
				echo_command <= 1'b1;
				stat <= 1'b1;
			end
			if (clk_we) begin
				clk_prev <= clk_bit;
				if (clk_bit && !clk_prev)
					stat <= 1'b0;
				else if (!clk_bit && clk_prev) begin
					stat <= 1'b1;
					if (!echo_command)
						idx <= idx + 4'd1;
				end
			end
		end
	assign pic_data = (echo_command ? 8'h0f : pic_byte(idx));
	assign pic_status = stat;
	wire _unused_resp_re = resp_re;
endmodule
`default_nettype wire
`default_nettype none
module revx_scan_word_cache (
	clk,
	rst,
	req,
	addr,
	data,
	ack,
	burst_req,
	burst_addr,
	burst_ack,
	burst_data
);
	input wire clk;
	input wire rst;
	input wire req;
	input wire [17:0] addr;
	output reg [15:0] data;
	output reg ack;
	output reg burst_req;
	output reg [17:0] burst_addr;
	input wire burst_ack;
	input wire [255:0] burst_data;
	reg [1:0] state;
	reg valid;
	reg [13:0] tag;
	reg [255:0] block_data;
	reg [17:0] request_addr;
	always @(posedge clk)
		if (rst) begin
			state <= 2'd0;
			valid <= 1'b0;
			tag <= 1'sb0;
			block_data <= 1'sb0;
			request_addr <= 1'sb0;
			data <= 1'sb0;
			ack <= 1'b0;
			burst_req <= 1'b0;
			burst_addr <= 1'sb0;
		end
		else begin
			ack <= 1'b0;
			if (!req)
				valid <= 1'b0;
			case (state)
				2'd0:
					if (req && !burst_ack) begin
						request_addr <= addr;
						if (valid && (tag == addr[17:4])) begin
							data <= block_data[16 * addr[3:0]+:16];
							ack <= 1'b1;
							state <= 2'd2;
						end
						else begin
							burst_addr <= {addr[17:4], 4'd0};
							burst_req <= 1'b1;
							state <= 2'd1;
						end
					end
				2'd1:
					if (burst_ack) begin
						burst_req <= 1'b0;
						block_data <= burst_data;
						tag <= burst_addr[17:4];
						valid <= req;
						data <= burst_data[16 * request_addr[3:0]+:16];
						ack <= 1'b1;
						state <= 2'd2;
					end
				2'd2:
					if (!req || (addr != request_addr))
						state <= 2'd0;
				default: state <= 2'd0;
			endcase
		end
endmodule
module revx_scanout (
	clk,
	rst,
	ce_pix,
	disp_enable,
	hcount,
	vcount,
	heblnk,
	hsblnk,
	veblnk,
	vsblnk,
	rowaddr,
	coladdr,
	s_rd,
	s_addr,
	s_data,
	s_ack,
	pal_idx,
	pal_rgb,
	r,
	g,
	b,
	de,
	hs,
	vs,
	ce_out,
	underflow,
	diag_pixel_miss
);
	parameter signed [31:0] MAXW = 512;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire disp_enable;
	input wire [15:0] hcount;
	input wire [15:0] vcount;
	input wire [15:0] heblnk;
	input wire [15:0] hsblnk;
	input wire [15:0] veblnk;
	input wire [15:0] vsblnk;
	input wire [15:0] rowaddr;
	input wire [15:0] coladdr;
	output wire s_rd;
	output wire [17:0] s_addr;
	input wire [15:0] s_data;
	input wire s_ack;
	output wire [14:0] pal_idx;
	input wire [14:0] pal_rgb;
	output wire [7:0] r;
	output wire [7:0] g;
	output wire [7:0] b;
	output reg de;
	output reg hs;
	output reg vs;
	output reg ce_out;
	output reg underflow;
	output wire diag_pixel_miss;
	localparam signed [31:0] CW = $clog2(MAXW);
	wire line_visible = (vcount >= veblnk) && (vcount < vsblnk);
	wire vis_px = (line_visible && (hcount >= heblnk)) && (hcount < hsblnk);
	wire [15:0] width = hsblnk - heblnk;
	wire [31:0] fulladdr32 = (({16'd0, rowaddr} << 16) | {16'd0, coladdr}) >> 3;
	wire [17:0] full18 = fulladdr32[17:0];
	wire [17:0] row_base = full18 & 18'h3fe00;
	wire [8:0] col0 = full18[8:0];
	reg [17:0] l_rowbase;
	reg [8:0] l_col0;
	reg [15:0] l_width;
	(* ramstyle = "no_rw_check, M10K" *) reg [15:0] linebuf [0:MAXW - 1];
	reg fetching;
	reg line_done;
	reg line_valid;
	reg line_expected;
	wire scan_enabled = disp_enable !== 1'b0;
	reg [CW:0] fi;
	wire [8:0] fcol = (l_col0 + fi[8:0]) & 9'h1ff;
	assign s_addr = l_rowbase | {9'd0, fcol};
	assign s_rd = fetching;
	wire hz_d;
	wire line_start = ce_pix && (hcount == 16'd0);
	wire [CW - 1:0] col = hcount - heblnk;
	wire pixel_ready = (scan_enabled && line_valid) && (line_done || ({1'b0, col} < fi));
	always @(posedge clk)
		if (rst) begin
			fetching <= 1'b0;
			line_done <= 1'b0;
			fi <= 1'sb0;
			underflow <= 1'b0;
			line_valid <= 1'b0;
			line_expected <= 1'b0;
			l_rowbase <= 1'sb0;
			l_col0 <= 1'sb0;
			l_width <= 1'sb0;
		end
		else begin
			if (line_start) begin
				line_done <= 1'b0;
				line_valid <= 1'b0;
				line_expected <= line_visible && scan_enabled;
				if ((line_visible && scan_enabled) && !fetching) begin
					l_rowbase <= row_base;
					l_col0 <= col0;
					l_width <= width;
					fi <= 1'sb0;
					fetching <= 1'b1;
					line_valid <= 1'b1;
				end
			end
			if (!scan_enabled) begin
				line_valid <= 1'b0;
				line_expected <= 1'b0;
			end
			if (fetching && s_ack) begin
				linebuf[fi[CW - 1:0]] <= s_data;
				if (!scan_enabled || ((fi + 1) >= {1'b0, l_width[CW:0]})) begin
					fetching <= 1'b0;
					line_done <= scan_enabled;
				end
				else
					fi <= fi + 1'b1;
			end
			if ((((ce_pix && vis_px) && scan_enabled) && line_expected) && !pixel_ready)
				underflow <= 1'b1;
		end
	reg [15:0] col_word;
	assign diag_pixel_miss = ((((!rst && ce_pix) && vis_px) && scan_enabled) && line_expected) && !pixel_ready;
	reg ce_q;
	reg de_q;
	reg hs_q;
	reg vs_q;
	reg ready_q;
	reg data_ready;
	always @(posedge clk)
		if (ce_pix)
			col_word <= linebuf[col];
	always @(posedge clk)
		if (rst) begin
			ce_q <= 0;
			ce_out <= 0;
			de_q <= 0;
			hs_q <= 0;
			vs_q <= 0;
			ready_q <= 0;
			de <= 0;
			hs <= 0;
			vs <= 0;
			data_ready <= 0;
		end
		else begin
			ce_q <= ce_pix;
			ce_out <= ce_q;
			if (ce_pix) begin
				de_q <= vis_px;
				ready_q <= pixel_ready;
				hs_q <= hcount < heblnk;
				vs_q <= vcount < veblnk;
			end
			if (ce_q) begin
				de <= de_q;
				hs <= hs_q;
				vs <= vs_q;
				data_ready <= ready_q;
			end
		end
	assign pal_idx = col_word[14:0];
	wire [4:0] r5 = pal_rgb[14:10];
	wire [4:0] g5 = pal_rgb[9:5];
	wire [4:0] b5 = pal_rgb[4:0];
	assign r = (de && data_ready ? {r5, r5[4:2]} : 8'd0);
	assign g = (de && data_ready ? {g5, g5[4:2]} : 8'd0);
	assign b = (de && data_ready ? {b5, b5[4:2]} : 8'd0);
	wire _u = &{1'b0, hz_d, line_done};
endmodule
`default_nettype wire
`default_nettype none
module sdram_phy (
	clk,
	init,
	addr,
	din,
	be,
	dqm_early,
	rd,
	wr,
	dout,
	ack,
	write_chunk,
	write_reverse,
	chunk_count,
	chunk_data,
	read_chunk,
	chunk_dout,
	ready,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE
);
	parameter signed [31:0] CLK_MHZ = 100;
	parameter signed [31:0] RASCAS = 3;
	parameter signed [31:0] CAS = 2;
	parameter signed [31:0] TRP = 3;
	parameter signed [31:0] TWR = 2;
	parameter signed [31:0] TRFC = 9;
	parameter signed [31:0] REFRESH_IV = 780;
	parameter signed [31:0] PWRUP = 20000;
	input wire clk;
	input wire init;
	input wire [24:0] addr;
	input wire [15:0] din;
	input wire [1:0] be;
	input wire dqm_early;
	input wire rd;
	input wire wr;
	output reg [15:0] dout;
	output reg ack;
	input wire write_chunk;
	input wire write_reverse;
	input wire [6:0] chunk_count;
	input wire [1023:0] chunk_data;
	input wire read_chunk;
	output wire [255:0] chunk_dout;
	output reg ready;
	inout wire [15:0] SDRAM_DQ;
	output reg [12:0] SDRAM_A;
	output reg [1:0] SDRAM_BA;
	output reg SDRAM_DQML;
	output reg SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	localparam [3:0] CMD_NOP = 4'b0111;
	localparam [3:0] CMD_ACTIVE = 4'b0011;
	localparam [3:0] CMD_READ = 4'b0101;
	localparam [3:0] CMD_WRITE = 4'b0100;
	localparam [3:0] CMD_PRECHARGE = 4'b0010;
	localparam [3:0] CMD_REFRESH = 4'b0001;
	localparam [3:0] CMD_LOADMODE = 4'b0000;
	localparam [12:0] MODE = {6'b000100, CAS[2:0], 4'b0000};
	localparam signed [31:0] CAP_DLY = CAS + 1;
	localparam signed [31:0] PIPE_W = CAP_DLY;
	wire [1:0] a_bank = addr[23:22];
	wire [12:0] a_row = addr[21:9];
	wire [8:0] a_col = addr[8:0];
	reg [3:0] st;
	reg [15:0] pwr_cnt;
	reg [3:0] istep;
	reg [3:0] wait_cnt;
	reg [15:0] ref_cnt;
	reg served;
	reg is_wr;
	reg chunk_l;
	reg write_reverse_l;
	reg [24:0] a_l;
	reg [5:0] chunk_idx;
	wire [8:0] write_col = (write_reverse_l ? a_l[8:0] - {3'd0, chunk_idx} : a_l[8:0] + {3'd0, chunk_idx});
	reg [6:0] chunk_count_l;
	reg [1023:0] chunk_data_l;
	wire chunk_last = ({1'b0, chunk_idx} + 7'd1) == chunk_count_l;
	reg [15:0] d_l;
	reg [1:0] be_l;
	reg dqm_early_l;
	reg [3:0] cmd;
	reg dq_oe;
	reg [15:0] dq_o;
	reg init_d;
	reg rchunk_l;
	reg [4:0] ric;
	reg rch_pause;
	reg [PIPE_W - 1:0] issue_pipe;
	reg [255:0] chunk_sh;
	reg rcap_now_q;
	reg [4:0] chunk_shift_count;
	assign chunk_dout = chunk_sh;
	assign {SDRAM_nCS, SDRAM_nRAS, SDRAM_nCAS, SDRAM_nWE} = cmd;
	assign SDRAM_CKE = 1'b1;
	assign SDRAM_DQ = (dq_oe ? dq_o : 16'hzzzz);
	wire rcap_now = issue_pipe[PIPE_W - 1];
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	localparam [8:0] READ_RESERVE = sv2v_cast_9_signed((RASCAS + TRP) + 6);
	localparam [8:0] WRITE_RESERVE = sv2v_cast_9_signed(((RASCAS + TRP) + TWR) + 4);
	wire [8:0] chunk_budget = (read_chunk === 1'b1 ? ({2'd0, chunk_count} << 1) + sv2v_cast_9_signed((RASCAS + TRP) + 6) : {2'd0, chunk_count} + sv2v_cast_9_signed(((RASCAS + TRP) + TWR) + 4));
	wire chunk_reserve_short;
	generate
		if ((READ_RESERVE <= 9'd257) && (WRITE_RESERVE <= 9'd384)) begin : g_reserve_margin
			localparam [15:0] READ_BASE = {7'd0, READ_RESERVE};
			localparam [15:0] WRITE_BASE = {7'd0, WRITE_RESERVE};
			localparam [15:0] READ_WINDOW = READ_BASE + 16'd256;
			localparam [15:0] WRITE_WINDOW = WRITE_BASE + 16'd128;
			wire [7:0] read_margin = ref_cnt[7:0] - READ_RESERVE[7:0];
			wire [6:0] write_margin = ref_cnt[6:0] - WRITE_RESERVE[6:0];
			wire write_short = (ref_cnt < WRITE_BASE) || ((ref_cnt < WRITE_WINDOW) && (chunk_count > write_margin));
			wire read_short = (ref_cnt < READ_BASE) || ((ref_cnt < READ_WINDOW) && (chunk_count > read_margin[7:1]));
			assign chunk_reserve_short = (read_chunk === 1'b1 ? read_short : write_short);
		end
		else begin : g_reserve_legacy
			assign chunk_reserve_short = ref_cnt < {7'd0, chunk_budget};
		end
	endgenerate
	wire reserve_refresh = (((rd || wr) && !served) && ((write_chunk === 1'b1) || (read_chunk === 1'b1))) && chunk_reserve_short;
	function automatic signed [3:0] sv2v_cast_4_signed;
		input reg signed [3:0] inp;
		sv2v_cast_4_signed = inp;
	endfunction
	always @(posedge clk) begin
		cmd <= CMD_NOP;
		dq_oe <= 1'b0;
		ack <= 1'b0;
		SDRAM_A <= 13'd0;
		SDRAM_BA <= 2'd0;
		SDRAM_DQML <= 1'b0;
		SDRAM_DQMH <= 1'b0;
		if (!(rd | wr))
			served <= 1'b0;
		init_d <= init;
		if (ref_cnt != 0)
			ref_cnt <= ref_cnt - 1'b1;
		issue_pipe <= {issue_pipe[PIPE_W - 2:0], 1'b0};
		if (rcap_now)
			dout <= SDRAM_DQ;
		if (rcap_now_q) begin
			chunk_sh <= {dout, chunk_sh[255:16]};
			chunk_shift_count <= chunk_shift_count + 5'd1;
		end
		else if (((rchunk_l && (st == 4'd5)) && (chunk_shift_count >= chunk_count_l)) && (chunk_shift_count < 5'd16)) begin
			chunk_sh <= {16'd0, chunk_sh[255:16]};
			chunk_shift_count <= chunk_shift_count + 5'd1;
		end
		rcap_now_q <= rcap_now;
		if (init & ~init_d) begin
			st <= 4'd0;
			pwr_cnt <= PWRUP[15:0];
			ready <= 1'b0;
		end
		else
			case (st)
				4'd0:
					if (pwr_cnt != 0)
						pwr_cnt <= pwr_cnt - 1'b1;
					else begin
						istep <= 4'd0;
						st <= 4'd1;
					end
				4'd1:
					if (wait_cnt != 0)
						wait_cnt <= wait_cnt - 1'b1;
					else
						case (istep)
							4'd0: begin
								cmd <= CMD_PRECHARGE;
								SDRAM_A <= 13'h0400;
								wait_cnt <= TRP[3:0];
								istep <= 4'd1;
							end
							4'd1: begin
								cmd <= CMD_REFRESH;
								wait_cnt <= TRFC[3:0];
								istep <= 4'd2;
							end
							4'd2: begin
								cmd <= CMD_REFRESH;
								wait_cnt <= TRFC[3:0];
								istep <= 4'd3;
							end
							4'd3: begin
								cmd <= CMD_LOADMODE;
								SDRAM_A <= MODE;
								SDRAM_BA <= 2'd0;
								wait_cnt <= 4'd3;
								istep <= 4'd4;
							end
							default: begin
								ref_cnt <= REFRESH_IV[15:0];
								st <= 4'd2;
								ready <= 1'b1;
							end
						endcase
				4'd2: begin
					SDRAM_A <= a_row;
					if ((ref_cnt == 0) || reserve_refresh) begin
						cmd <= CMD_REFRESH;
						wait_cnt <= TRFC[3:0];
						ref_cnt <= REFRESH_IV[15:0];
						st <= 4'd6;
					end
					else if ((rd | wr) & ~served) begin
						served <= 1'b1;
						a_l <= addr;
						d_l <= din;
						be_l <= be;
						is_wr <= wr;
						dqm_early_l <= dqm_early;
						chunk_l <= wr && (write_chunk === 1'b1);
						write_reverse_l <= write_reverse === 1'b1;
						rchunk_l <= !wr && (read_chunk === 1'b1);
						chunk_count_l <= chunk_count;
						chunk_data_l <= chunk_data;
						chunk_shift_count <= 5'd0;
						chunk_idx <= 0;
						ric <= 5'd0;
						rch_pause <= 1'b0;
						cmd <= CMD_ACTIVE;
						SDRAM_BA <= a_bank;
						wait_cnt <= RASCAS[3:0] - 4'd1;
						st <= 4'd3;
					end
				end
				4'd3: begin
					if (is_wr && dqm_early_l) begin
						SDRAM_DQML <= ~be_l[0];
						SDRAM_DQMH <= ~be_l[1];
					end
					if (wait_cnt != 0)
						wait_cnt <= wait_cnt - 1'b1;
					else begin
						SDRAM_BA <= a_l[23:22];
						SDRAM_A <= {4'b0010, a_l[8:0]};
						if (is_wr) begin
							cmd <= CMD_WRITE;
							dq_oe <= 1'b1;
							dq_o <= d_l;
							SDRAM_DQML <= ~be_l[0];
							SDRAM_DQMH <= ~be_l[1];
							st <= 4'd5;
							wait_cnt <= TRP[3:0];
							if (chunk_l) begin
								dq_o <= chunk_data_l[15:0];
								chunk_data_l <= {16'd0, chunk_data_l[1023:16]};
								SDRAM_DQML <= 0;
								SDRAM_DQMH <= 0;
								SDRAM_A <= {2'b00, chunk_count_l == 5'd1, 1'b0, a_l[8:0]};
								if (chunk_count_l == 5'd1)
									wait_cnt <= sv2v_cast_4_signed(TRP + TWR);
								else begin
									chunk_idx <= 1;
									st <= 4'd7;
								end
							end
						end
						else if (rchunk_l) begin
							cmd <= CMD_READ;
							SDRAM_DQML <= 1'b0;
							SDRAM_DQMH <= 1'b0;
							SDRAM_A <= {2'b00, chunk_count_l == 5'd1, 1'b0, a_l[8:0]};
							issue_pipe[0] <= 1'b1;
							ric <= 5'd1;
							rch_pause <= 1'b1;
							if (chunk_count_l == 5'd1)
								st <= 4'd5;
							else
								st <= 4'd8;
							wait_cnt <= sv2v_cast_4_signed(TRP + 2);
						end
						else begin
							cmd <= CMD_READ;
							SDRAM_DQML <= 1'b0;
							SDRAM_DQMH <= 1'b0;
							st <= 4'd4;
							wait_cnt <= CAS[3:0];
						end
					end
				end
				4'd4:
					if (wait_cnt != 0)
						wait_cnt <= wait_cnt - 1'b1;
					else begin
						dout <= SDRAM_DQ;
						ack <= 1'b1;
						st <= 4'd2;
					end
				4'd5:
					if (wait_cnt != 0)
						wait_cnt <= wait_cnt - 1'b1;
					else if (!rchunk_l || (chunk_shift_count == 5'd16)) begin
						ack <= 1'b1;
						st <= 4'd2;
					end
				4'd6:
					if (wait_cnt != 0)
						wait_cnt <= wait_cnt - 1'b1;
					else
						st <= 4'd2;
				4'd7: begin
					cmd <= CMD_WRITE;
					dq_oe <= 1'b1;
					dq_o <= chunk_data_l[15:0];
					chunk_data_l <= {16'd0, chunk_data_l[1023:16]};
					SDRAM_BA <= a_l[23:22];
					SDRAM_A <= {2'b00, chunk_last, 1'b0, write_col};
					SDRAM_DQML <= 0;
					SDRAM_DQMH <= 0;
					if (chunk_last) begin
						st <= 4'd5;
						wait_cnt <= sv2v_cast_4_signed(TRP + TWR);
					end
					else
						chunk_idx <= chunk_idx + 1'b1;
				end
				4'd8: begin
					if (!rch_pause) begin
						cmd <= CMD_READ;
						SDRAM_DQML <= 1'b0;
						SDRAM_DQMH <= 1'b0;
						SDRAM_BA <= a_l[23:22];
						SDRAM_A <= {2'b00, {1'b0, ric} == (chunk_count_l - 5'd1), 1'b0, a_l[8:0] + {4'd0, ric}};
						issue_pipe[0] <= 1'b1;
						if ({1'b0, ric} == (chunk_count_l - 5'd1)) begin
							st <= 4'd5;
							wait_cnt <= sv2v_cast_4_signed(TRP + 2);
						end
						else
							ric <= ric + 5'd1;
					end
					rch_pause <= !rch_pause;
				end
				default: st <= 4'd2;
			endcase
	end
endmodule
`default_nettype wire
`default_nettype none
module wolf_gfx_ddr_top (
	clk,
	rst,
	sdram_por,
	src_req,
	src_addr,
	src_active,
	src_stream,
	src_data,
	src_ack,
	dcs_safe,
	cg_req,
	cg_addr,
	cg_data,
	cg_ack,
	cgw_req,
	cgw_beat,
	cgw_data,
	cgw_ack,
	dl_wr,
	dl_addr,
	dl_data,
	dl_ack,
	dl_idle,
	dbg_wbeats,
	dbg_srd,
	dbg_cgrd,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready
);
	reg _sv2v_0;
	parameter [28:0] GFX_DDR_BASE = 29'h06800000;
	parameter [0:0] USE_STREAM_HINT = 1'b0;
	parameter [0:0] L2_ENABLE = 1'b1;
	parameter integer L2_LINES = 4096;
	input wire clk;
	input wire rst;
	input wire sdram_por;
	input wire src_req;
	input wire [31:0] src_addr;
	input wire src_active;
	input wire src_stream;
	output reg [7:0] src_data;
	output reg src_ack;
	output wire dcs_safe;
	input wire cg_req;
	input wire [25:0] cg_addr;
	output reg [7:0] cg_data;
	output reg cg_ack;
	input wire cgw_req;
	input wire [21:0] cgw_beat;
	output reg [63:0] cgw_data;
	output reg cgw_ack;
	input wire dl_wr;
	input wire [24:0] dl_addr;
	input wire [7:0] dl_data;
	output reg dl_ack;
	output wire dl_idle;
	output reg [25:0] dbg_wbeats;
	output reg [15:0] dbg_srd;
	output reg [15:0] dbg_cgrd;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	reg tst_rd_req;
	reg tst_wr_req;
	wire [25:0] tst_addr;
	wire [63:0] tst_wdata;
	wire [7:0] tst_burstcnt;
	wire [63:0] tst_rdata;
	wire tst_rd_valid;
	wire tst_busy;
	stv_vram_ddr_agent #(.VRAM_DDR_BASE(GFX_DDR_BASE)) u_agent(
		.clk(clk),
		.sdram_por(sdram_por),
		.tst_wr_req(tst_wr_req),
		.tst_rd_req(tst_rd_req),
		.tst_addr(tst_addr),
		.tst_wdata(tst_wdata),
		.tst_be(8'hff),
		.tst_burstcnt(tst_burstcnt),
		.tst_rdata(tst_rdata),
		.tst_rd_valid(tst_rd_valid),
		.tst_busy(tst_busy),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	localparam [7:0] WFLUSH_IDLE = 8'd64;
	reg wc_valid;
	reg [21:0] wc_beat;
	reg [7:0] wc_mask;
	reg [63:0] wc_data;
	reg [7:0] widle_cnt;
	wire [21:0] dl_beat = dl_addr[24:3];
	wire wc_same = wc_valid && (dl_beat == wc_beat);
	wire wr_taking;
	wire wflush_req = wc_valid && (((dl_wr && !dl_ack) && !wc_same) || (widle_cnt >= WFLUSH_IDLE));
	always @(posedge clk)
		if (sdram_por) begin
			wc_valid <= 1'b0;
			wc_beat <= 22'd0;
			wc_mask <= 8'd0;
			wc_data <= 64'd0;
			dl_ack <= 1'b0;
			widle_cnt <= 8'd0;
			dbg_wbeats <= 26'd0;
		end
		else begin
			dl_ack <= 1'b0;
			if (wc_valid && (widle_cnt != 8'hff))
				widle_cnt <= widle_cnt + 8'd1;
			if (wr_taking) begin
				wc_valid <= 1'b0;
				wc_mask <= 8'd0;
			end
			else if ((dl_wr && !dl_ack) && (!wc_valid || wc_same)) begin
				wc_beat <= dl_beat;
				wc_mask[dl_addr[2:0]] <= 1'b1;
				wc_data[dl_addr[2:0] * 8+:8] <= dl_data;
				wc_valid <= 1'b1;
				dl_ack <= 1'b1;
				widle_cnt <= 8'd0;
				dbg_wbeats <= dbg_wbeats + 26'd1;
			end
		end
	localparam integer PF_DEPTH = 4;
	reg [PF_DEPTH - 1:0] pf_valid;
	reg [21:0] pf_tag [0:PF_DEPTH - 1];
	reg [63:0] pf_data [0:PF_DEPTH - 1];
	reg [21:0] pf_target;
	reg [2:0] pf_left;
	reg [2:0] pf_goal;
	reg src_line_valid;
	reg [21:0] src_line_tag;
	reg [63:0] src_line_data;
	reg cg_line_valid;
	reg [21:0] cg_line_tag;
	reg [63:0] cg_line_data;
	reg cgw_line_valid;
	reg [21:0] cgw_line_tag;
	reg [63:0] cgw_line_data;
	localparam integer L2_IW = $clog2(L2_LINES);
	localparam integer L2_TW = 22 - L2_IW;
	(* ramstyle = "no_rw_check, M10K" *) reg [63:0] l2_data [0:L2_LINES - 1];
	(* ramstyle = "no_rw_check, M10K" *) reg [L2_TW - 1:0] l2_tag [0:L2_LINES - 1];
	(* ramstyle = "no_rw_check, M10K" *) reg l2_valid_mem [0:L2_LINES - 1];
	reg [63:0] l2_data_q;
	reg [L2_TW - 1:0] l2_tag_q;
	reg l2_valid_q;
	reg [21:0] l2_line_q;
	reg [L2_IW - 1:0] l2_init_idx;
	reg l2_init_done;
	reg l2_valid_we;
	reg l2_valid_wdata;
	reg [L2_IW - 1:0] l2_valid_waddr;
	reg [31:0] l2_hits;
	reg [31:0] l2_fills;
	wire src_hit = src_line_valid && (src_addr[24:3] == src_line_tag);
	reg src_pf_hit;
	reg [1:0] src_pf_slot_w;
	reg [63:0] src_pf_data_w;
	always @(*) begin
		if (_sv2v_0)
			;
		src_pf_hit = 1'b0;
		src_pf_slot_w = 2'd0;
		src_pf_data_w = 64'd0;
		begin : sv2v_autoblock_1
			reg signed [31:0] p;
			for (p = 0; p < PF_DEPTH; p = p + 1)
				if (pf_valid[p] && (src_addr[24:3] == pf_tag[p])) begin
					src_pf_hit = 1'b1;
					src_pf_slot_w = p[1:0];
					src_pf_data_w = pf_data[p];
				end
		end
	end
	wire cg_hit = cg_line_valid && (cg_addr[24:3] == cg_line_tag);
	wire cgw_hit = cgw_line_valid && (cgw_beat == cgw_line_tag);
	reg src_hit_q;
	reg cg_hit_q;
	reg [24:0] src_qaddr;
	reg [24:0] cg_qaddr;
	reg [7:0] src_byte_q;
	reg [7:0] cg_byte_q;
	reg src_pend;
	reg cg_pend;
	reg src_cool;
	reg cg_cool;
	reg src_done;
	reg cg_done;
	reg cgw_hit_q;
	reg [21:0] cgw_qbeat;
	reg [63:0] cgw_word_q;
	reg cgw_pend;
	reg cgw_cool;
	reg cgw_done;
	reg src_pf_served;
	reg [1:0] src_pf_served_slot;
	always @(posedge clk)
		if (rst) begin
			src_pend <= 1'b0;
			cg_pend <= 1'b0;
			src_cool <= 1'b0;
			cg_cool <= 1'b0;
			src_pf_served <= 1'b0;
			src_pf_served_slot <= 2'd0;
			src_hit_q <= 1'b0;
			cg_hit_q <= 1'b0;
			src_qaddr <= 25'd0;
			cg_qaddr <= 25'd0;
			src_byte_q <= 8'h00;
			cg_byte_q <= 8'h00;
			src_ack <= 1'b0;
			cg_ack <= 1'b0;
			src_data <= 8'h00;
			cg_data <= 8'h00;
			cgw_pend <= 1'b0;
			cgw_cool <= 1'b0;
			cgw_hit_q <= 1'b0;
			cgw_qbeat <= 22'd0;
			cgw_word_q <= 64'd0;
			cgw_ack <= 1'b0;
			cgw_data <= 64'd0;
			dbg_srd <= 16'd0;
			dbg_cgrd <= 16'd0;
		end
		else begin
			src_ack <= 1'b0;
			cg_ack <= 1'b0;
			cgw_ack <= 1'b0;
			src_pf_served <= 1'b0;
			src_cool <= src_ack;
			cg_cool <= cg_ack;
			cgw_cool <= cgw_ack;
			src_hit_q <= src_hit;
			cg_hit_q <= cg_hit;
			src_qaddr <= src_addr[24:0];
			cg_qaddr <= cg_addr[24:0];
			src_byte_q <= src_line_data[src_addr[2:0] * 8+:8];
			cg_byte_q <= cg_line_data[cg_addr[2:0] * 8+:8];
			cgw_hit_q <= cgw_hit;
			cgw_qbeat <= cgw_beat;
			cgw_word_q <= cgw_line_data;
			if (((!src_pend && src_req) && !src_ack) && !src_cool) begin
				if (src_hit || src_pf_hit) begin
					src_data <= (src_hit ? src_line_data[src_addr[2:0] * 8+:8] : src_pf_data_w[src_addr[2:0] * 8+:8]);
					src_ack <= 1'b1;
					src_pf_served <= src_pf_hit && !src_hit;
					src_pf_served_slot <= src_pf_slot_w;
					dbg_srd <= dbg_srd + 16'd1;
				end
				else
					src_pend <= 1'b1;
			end
			if (((!cg_pend && cg_req) && !cg_ack) && !cg_cool) begin
				if ((cg_hit && cg_hit_q) && (cg_qaddr == cg_addr[24:0])) begin
					cg_data <= cg_byte_q;
					cg_ack <= 1'b1;
					dbg_cgrd <= dbg_cgrd + 16'd1;
				end
				else if (!cg_hit)
					cg_pend <= 1'b1;
			end
			if (((!cgw_pend && cgw_req) && !cgw_ack) && !cgw_cool) begin
				if ((cgw_hit && cgw_hit_q) && (cgw_qbeat == cgw_beat)) begin
					cgw_data <= cgw_word_q;
					cgw_ack <= 1'b1;
					dbg_cgrd <= dbg_cgrd + 16'd1;
				end
				else if (!cgw_hit)
					cgw_pend <= 1'b1;
			end
			if (src_pend && src_done) begin
				src_data <= src_byte_q;
				src_ack <= 1'b1;
				src_pend <= 1'b0;
				dbg_srd <= dbg_srd + 16'd1;
			end
			if (cg_pend && cg_done) begin
				cg_data <= cg_byte_q;
				cg_ack <= 1'b1;
				cg_pend <= 1'b0;
				dbg_cgrd <= dbg_cgrd + 16'd1;
			end
			if (cgw_pend && cgw_done) begin
				cgw_data <= cgw_word_q;
				cgw_ack <= 1'b1;
				cgw_pend <= 1'b0;
				dbg_cgrd <= dbg_cgrd + 16'd1;
			end
		end
	localparam [3:0] O_IDLE = 4'd0;
	localparam [3:0] O_FRD = 4'd1;
	localparam [3:0] O_FRDW = 4'd2;
	localparam [3:0] O_FWR = 4'd3;
	localparam [3:0] O_FWW = 4'd4;
	localparam [3:0] O_RISSUE = 4'd5;
	localparam [3:0] O_RWAIT = 4'd6;
	localparam [3:0] O_GAP = 4'd7;
	localparam [3:0] O_PISSUE = 4'd8;
	localparam [3:0] O_PWAIT = 4'd9;
	localparam [3:0] O_L2CHECK = 4'd10;
	reg [3:0] ost;
	reg o_is_src;
	reg o_is_cgw;
	reg o_done_pend;
	reg [21:0] o_line;
	reg [21:0] wl_beat;
	reg [7:0] wl_mask;
	reg [63:0] wl_data;
	reg fwd_valid;
	reg [21:0] fwd_beat;
	reg [63:0] fwd_data;
	wire src_live_miss_w = (src_req && !src_hit) && !src_pf_hit;
	wire cg_live_miss_w = cg_req && !cg_hit;
	wire stream_prefetch_w = USE_STREAM_HINT && src_stream;
	reg pf_pend_hit_w;
	reg [1:0] pf_pend_slot_w;
	reg [2:0] pf_valid_count_w;
	reg [2:0] pf_valid_after_consume_w;
	reg [2:0] pf_next_goal_w;
	reg [2:0] pf_refill_after_consume_w;
	always @(*) begin
		if (_sv2v_0)
			;
		pf_pend_hit_w = 1'b0;
		pf_pend_slot_w = 2'd0;
		pf_valid_count_w = 3'd0;
		begin : sv2v_autoblock_2
			reg signed [31:0] p;
			for (p = 0; p < PF_DEPTH; p = p + 1)
				begin
					if (pf_valid[p])
						pf_valid_count_w = pf_valid_count_w + 3'd1;
					if (pf_valid[p] && (src_qaddr[24:3] == pf_tag[p])) begin
						pf_pend_hit_w = 1'b1;
						pf_pend_slot_w = p[1:0];
					end
				end
		end
		pf_valid_after_consume_w = (pf_valid_count_w != 3'd0 ? pf_valid_count_w - 3'd1 : 3'd0);
		if (stream_prefetch_w)
			pf_next_goal_w = (pf_goal < 3'd2 ? 3'd2 : 3'd4);
		else if (USE_STREAM_HINT && src_active)
			pf_next_goal_w = 3'd2;
		else
			pf_next_goal_w = 3'd1;
		if (pf_next_goal_w > pf_valid_after_consume_w)
			pf_refill_after_consume_w = pf_next_goal_w - pf_valid_after_consume_w;
		else
			pf_refill_after_consume_w = 3'd0;
	end
	assign dcs_safe = (!USE_STREAM_HINT || !src_active) || ((pf_left == 3'd0) && (pf_valid_count_w >= (src_stream ? 3'd3 : 3'd2)));
	localparam signed [31:0] SRC_IDLE_MAX = 16;
	reg [4:0] src_idle_cnt;
	always @(posedge clk)
		if (sdram_por)
			src_idle_cnt <= 5'd0;
		else if (!src_active || src_req)
			src_idle_cnt <= 5'd0;
		else if (src_idle_cnt < SRC_IDLE_MAX[4:0])
			src_idle_cnt <= src_idle_cnt + 5'd1;
	wire src_stalled_w = src_idle_cnt >= SRC_IDLE_MAX[4:0];
	wire cg_safe_w = ((!USE_STREAM_HINT || !src_active) || dcs_safe) || src_stalled_w;
	assign wr_taking = (ost == O_IDLE) && wflush_req;
	always @(*) begin
		if (_sv2v_0)
			;
		l2_valid_we = 1'b0;
		l2_valid_waddr = 1'sb0;
		l2_valid_wdata = 1'b0;
		if (L2_ENABLE && !l2_init_done) begin
			l2_valid_we = 1'b1;
			l2_valid_waddr = l2_init_idx;
		end
		else if (L2_ENABLE && wr_taking) begin
			l2_valid_we = 1'b1;
			l2_valid_waddr = wc_beat[L2_IW - 1:0];
		end
		else if ((((L2_ENABLE && l2_init_done) && (ost == O_RWAIT)) && tst_rd_valid) && o_is_src) begin
			l2_valid_we = 1'b1;
			l2_valid_waddr = o_line[L2_IW - 1:0];
			l2_valid_wdata = 1'b1;
		end
		else if (((L2_ENABLE && l2_init_done) && (ost == O_PWAIT)) && tst_rd_valid) begin
			l2_valid_we = 1'b1;
			l2_valid_waddr = pf_target[L2_IW - 1:0];
			l2_valid_wdata = 1'b1;
		end
	end
	always @(posedge clk) begin
		l2_valid_q <= l2_valid_mem[src_qaddr[3+:L2_IW]];
		l2_tag_q <= l2_tag[src_qaddr[3+:L2_IW]];
		l2_data_q <= l2_data[src_qaddr[3+:L2_IW]];
		if (!sdram_por && l2_valid_we)
			l2_valid_mem[l2_valid_waddr] <= l2_valid_wdata;
	end
	always @(posedge clk)
		if (sdram_por) begin
			ost <= O_IDLE;
			o_is_src <= 1'b0;
			o_is_cgw <= 1'b0;
			o_done_pend <= 1'b0;
			o_line <= 22'd0;
			wl_beat <= 22'd0;
			wl_mask <= 8'd0;
			wl_data <= 64'd0;
			fwd_valid <= 1'b0;
			fwd_beat <= 22'd0;
			fwd_data <= 64'd0;
			pf_valid <= 1'sb0;
			pf_target <= 22'd0;
			pf_left <= 3'd0;
			pf_goal <= 3'd1;
			l2_line_q <= 22'd0;
			l2_init_idx <= 1'sb0;
			l2_init_done <= !L2_ENABLE;
			l2_hits <= 32'd0;
			l2_fills <= 32'd0;
			begin : sv2v_autoblock_3
				reg signed [31:0] p;
				for (p = 0; p < PF_DEPTH; p = p + 1)
					begin
						pf_tag[p] <= 22'd0;
						pf_data[p] <= 64'd0;
					end
			end
			src_line_valid <= 1'b0;
			src_line_tag <= 22'd0;
			src_line_data <= 64'd0;
			cg_line_valid <= 1'b0;
			cg_line_tag <= 22'd0;
			cg_line_data <= 64'd0;
			cgw_line_valid <= 1'b0;
			cgw_line_tag <= 22'd0;
			cgw_line_data <= 64'd0;
			tst_rd_req <= 1'b0;
			tst_wr_req <= 1'b0;
			src_done <= 1'b0;
			cg_done <= 1'b0;
			cgw_done <= 1'b0;
		end
		else begin
			tst_rd_req <= 1'b0;
			tst_wr_req <= 1'b0;
			src_done <= 1'b0;
			cg_done <= 1'b0;
			cgw_done <= 1'b0;
			case (ost)
				O_IDLE:
					if (wflush_req) begin
						wl_beat <= wc_beat;
						wl_mask <= wc_mask;
						if (fwd_valid && (wc_beat == fwd_beat)) begin
							begin : sv2v_autoblock_4
								reg signed [31:0] i;
								for (i = 0; i < 8; i = i + 1)
									wl_data[8 * i+:8] <= (wc_mask[i] ? wc_data[8 * i+:8] : fwd_data[8 * i+:8]);
							end
							ost <= O_FWR;
						end
						else begin
							wl_data <= wc_data;
							ost <= O_FRD;
						end
					end
					else if (src_pf_served && pf_valid[src_pf_served_slot]) begin
						src_line_data <= pf_data[src_pf_served_slot];
						src_line_valid <= 1'b1;
						src_line_tag <= pf_tag[src_pf_served_slot];
						if (src_line_valid && (pf_tag[src_pf_served_slot] == (src_line_tag + 22'd1))) begin
							pf_valid[src_pf_served_slot] <= 1'b0;
							pf_goal <= pf_next_goal_w;
							pf_left <= pf_refill_after_consume_w;
						end
						else begin
							pf_valid <= 1'sb0;
							pf_target <= pf_tag[src_pf_served_slot] + 22'd1;
							pf_left <= 3'd1;
							pf_goal <= 3'd1;
						end
					end
					else if (src_pend && !src_done) begin
						o_is_src <= 1'b1;
						o_is_cgw <= 1'b0;
						o_line <= src_qaddr[24:3];
						if (pf_pend_hit_w) begin
							src_line_data <= pf_data[pf_pend_slot_w];
							src_line_valid <= 1'b1;
							src_line_tag <= pf_tag[pf_pend_slot_w];
							if (src_line_valid && (pf_tag[pf_pend_slot_w] == (src_line_tag + 22'd1))) begin
								pf_valid[pf_pend_slot_w] <= 1'b0;
								pf_goal <= pf_next_goal_w;
								pf_left <= pf_refill_after_consume_w;
							end
							else begin
								pf_valid <= 1'sb0;
								pf_target <= src_qaddr[24:3] + 22'd1;
								pf_left <= 3'd1;
								pf_goal <= 3'd1;
							end
							o_done_pend <= 1'b1;
							ost <= O_GAP;
						end
						else if (L2_ENABLE && l2_init_done) begin
							l2_line_q <= src_qaddr[24:3];
							ost <= O_L2CHECK;
						end
						else
							ost <= O_RISSUE;
					end
					else if ((cg_pend && !cg_done) && cg_safe_w) begin
						o_is_src <= 1'b0;
						o_is_cgw <= 1'b0;
						o_line <= cg_addr[24:3];
						ost <= O_RISSUE;
					end
					else if (cgw_pend && !cgw_done) begin
						o_is_src <= 1'b0;
						o_is_cgw <= 1'b1;
						o_line <= cgw_qbeat;
						ost <= O_RISSUE;
					end
					else if (((pf_left != 3'd0) && !src_live_miss_w) && !(cg_live_miss_w && cg_safe_w))
						ost <= O_PISSUE;
				O_FRD: begin
					tst_rd_req <= 1'b1;
					ost <= O_FRDW;
				end
				O_FRDW:
					if (tst_rd_valid) begin
						begin : sv2v_autoblock_5
							reg signed [31:0] i;
							for (i = 0; i < 8; i = i + 1)
								if (!wl_mask[i])
									wl_data[8 * i+:8] <= tst_rdata[8 * i+:8];
						end
						ost <= O_FWR;
					end
				O_FWW:
					if (!tst_busy && !tst_wr_req) begin
						fwd_valid <= 1'b1;
						fwd_beat <= wl_beat;
						fwd_data <= wl_data;
						if (src_line_valid && (wl_beat == src_line_tag))
							src_line_valid <= 1'b0;
						if (cg_line_valid && (wl_beat == cg_line_tag))
							cg_line_valid <= 1'b0;
						if (cgw_line_valid && (wl_beat == cgw_line_tag))
							cgw_line_valid <= 1'b0;
						begin : sv2v_autoblock_6
							reg signed [31:0] p;
							for (p = 0; p < PF_DEPTH; p = p + 1)
								if (pf_valid[p] && (wl_beat == pf_tag[p]))
									pf_valid[p] <= 1'b0;
						end
						ost <= O_GAP;
					end
				O_FWR: begin
					tst_wr_req <= 1'b1;
					ost <= O_FWW;
				end
				O_L2CHECK:
					if (l2_valid_q && (l2_tag_q == l2_line_q[21:L2_IW])) begin
						src_line_data <= l2_data_q;
						src_line_valid <= 1'b1;
						src_line_tag <= l2_line_q;
						l2_hits <= l2_hits + 32'd1;
						o_done_pend <= 1'b1;
						ost <= O_GAP;
					end
					else begin
						o_line <= l2_line_q;
						ost <= O_RISSUE;
					end
				O_RISSUE: begin
					tst_rd_req <= 1'b1;
					ost <= O_RWAIT;
				end
				O_RWAIT:
					if (tst_rd_valid) begin
						if (o_is_src) begin
							src_line_data <= tst_rdata;
							src_line_valid <= 1'b1;
							src_line_tag <= o_line;
							if (L2_ENABLE && l2_init_done) begin
								l2_data[o_line[L2_IW - 1:0]] <= tst_rdata;
								l2_tag[o_line[L2_IW - 1:0]] <= o_line[21:L2_IW];
								l2_fills <= l2_fills + 32'd1;
							end
							pf_valid <= 1'sb0;
							pf_target <= o_line + 22'd1;
							pf_left <= 3'd1;
							pf_goal <= 3'd1;
						end
						else if (o_is_cgw) begin
							cgw_line_data <= tst_rdata;
							cgw_line_valid <= 1'b1;
							cgw_line_tag <= o_line;
						end
						else begin
							cg_line_data <= tst_rdata;
							cg_line_valid <= 1'b1;
							cg_line_tag <= o_line;
						end
						o_done_pend <= 1'b1;
						ost <= O_GAP;
					end
				O_GAP: begin
					if (o_done_pend) begin
						if (o_is_src)
							src_done <= 1'b1;
						else if (o_is_cgw)
							cgw_done <= 1'b1;
						else
							cg_done <= 1'b1;
						o_done_pend <= 1'b0;
					end
					ost <= O_IDLE;
				end
				O_PISSUE:
					if (((wflush_req || src_pend) || src_live_miss_w) || ((cg_pend || cg_live_miss_w) && cg_safe_w))
						ost <= O_IDLE;
					else begin
						tst_rd_req <= 1'b1;
						ost <= O_PWAIT;
					end
				O_PWAIT:
					if (tst_rd_valid) begin
						if (L2_ENABLE && l2_init_done) begin
							l2_data[pf_target[L2_IW - 1:0]] <= tst_rdata;
							l2_tag[pf_target[L2_IW - 1:0]] <= pf_target[21:L2_IW];
							l2_fills <= l2_fills + 32'd1;
						end
						if (src_pend && (src_qaddr[24:3] == pf_target)) begin
							src_line_data <= tst_rdata;
							src_line_valid <= 1'b1;
							src_line_tag <= pf_target;
							pf_valid <= 1'sb0;
							pf_target <= pf_target + 22'd1;
							pf_left <= 3'd1;
							pf_goal <= 3'd1;
							o_is_src <= 1'b1;
							o_done_pend <= 1'b1;
							ost <= O_GAP;
						end
						else begin
							pf_data[pf_target[1:0]] <= tst_rdata;
							pf_tag[pf_target[1:0]] <= pf_target;
							pf_valid[pf_target[1:0]] <= 1'b1;
							pf_target <= pf_target + 22'd1;
							if (pf_left != 3'd0)
								pf_left <= pf_left - 3'd1;
							ost <= O_IDLE;
						end
					end
				default: ost <= O_IDLE;
			endcase
			if (L2_ENABLE && !l2_init_done) begin
				if (&l2_init_idx)
					l2_init_done <= 1'b1;
				else
					l2_init_idx <= l2_init_idx + {{L2_IW - 1 {1'b0}}, 1'b1};
			end
		end
	wire fsel = (((ost == O_FRD) || (ost == O_FRDW)) || (ost == O_FWR)) || (ost == O_FWW);
	wire psel = (ost == O_PISSUE) || (ost == O_PWAIT);
	assign tst_addr = (fsel ? {4'd0, wl_beat} : (psel ? {4'd0, pf_target} : {4'd0, o_line}));
	assign tst_burstcnt = 8'd1;
	assign tst_wdata = wl_data;
	assign dl_idle = (((!wc_valid && (ost == O_IDLE)) && !tst_busy) && !tst_rd_req) && !tst_wr_req;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module stv_vram_ddr_agent (
	clk,
	sdram_por,
	tst_wr_req,
	tst_rd_req,
	tst_addr,
	tst_wdata,
	tst_be,
	tst_burstcnt,
	tst_rdata,
	tst_rd_valid,
	tst_busy,
	tst_wr_done,
	tst_wr_base,
	tst_wr_count,
	tst_wr_last_data,
	tst_wnext,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready
);
	parameter [28:0] VRAM_DDR_BASE = 29'h06400000;
	input wire clk;
	input wire sdram_por;
	input wire tst_wr_req;
	input wire tst_rd_req;
	input wire [25:0] tst_addr;
	input wire [63:0] tst_wdata;
	input wire [7:0] tst_be;
	input wire [7:0] tst_burstcnt;
	output reg [63:0] tst_rdata;
	output reg tst_rd_valid;
	output reg tst_busy;
	output reg tst_wr_done;
	output reg [25:0] tst_wr_base;
	output reg [7:0] tst_wr_count;
	output reg [63:0] tst_wr_last_data;
	output wire tst_wnext;
	output reg [28:0] ddram_addr;
	output reg [7:0] ddram_burstcnt;
	output reg ddram_rd;
	output reg ddram_we;
	output wire [63:0] ddram_din;
	output reg [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	localparam ST_IDLE = 3'd0;
	localparam ST_WR = 3'd1;
	localparam ST_RD_REQ = 3'd2;
	localparam ST_RD_RCV = 3'd3;
	localparam ST_WRB = 3'd4;
	reg [2:0] state;
	reg [63:0] ddram_din_r;
	reg [7:0] beat;
	reg [7:0] bcnt;
	assign ddram_din = (state == ST_WRB ? tst_wdata : ddram_din_r);
	assign tst_wnext = (((state == ST_WRB) && ddram_we) && !ddram_busy) && (beat != (bcnt - 8'd1));
	always @(posedge clk)
		if (sdram_por) begin
			state <= ST_IDLE;
			beat <= 8'd0;
			bcnt <= 8'd1;
			ddram_addr <= 29'd0;
			ddram_burstcnt <= 8'd1;
			ddram_rd <= 1'b0;
			ddram_we <= 1'b0;
			ddram_din_r <= 64'd0;
			ddram_be <= 8'hff;
			tst_rdata <= 64'd0;
			tst_rd_valid <= 1'b0;
			tst_busy <= 1'b0;
			tst_wr_done <= 1'b0;
			tst_wr_base <= 26'd0;
			tst_wr_count <= 8'd1;
			tst_wr_last_data <= 64'd0;
		end
		else begin
			ddram_rd <= 1'b0;
			ddram_we <= 1'b0;
			tst_rd_valid <= 1'b0;
			tst_wr_done <= 1'b0;
			case (state)
				ST_IDLE:
					if (tst_wr_req) begin
						ddram_addr <= VRAM_DDR_BASE + {3'd0, tst_addr};
						ddram_be <= tst_be;
						tst_busy <= 1'b1;
						tst_wr_base <= tst_addr;
						tst_wr_count <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						if (tst_burstcnt <= 8'd1) begin
							ddram_din_r <= tst_wdata;
							ddram_burstcnt <= 8'd1;
							state <= ST_WR;
						end
						else begin
							ddram_burstcnt <= tst_burstcnt;
							bcnt <= tst_burstcnt;
							beat <= 8'd0;
							state <= ST_WRB;
						end
					end
					else if (tst_rd_req) begin
						ddram_addr <= VRAM_DDR_BASE + {3'd0, tst_addr};
						ddram_burstcnt <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						bcnt <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						beat <= 8'd0;
						ddram_rd <= 1'b1;
						tst_busy <= 1'b1;
						state <= ST_RD_REQ;
					end
				ST_WR: begin
					ddram_we <= 1'b1;
					if (ddram_we && !ddram_busy) begin
						ddram_we <= 1'b0;
						tst_busy <= 1'b0;
						state <= ST_IDLE;
						tst_wr_last_data <= ddram_din_r;
						tst_wr_done <= 1'b1;
					end
				end
				ST_WRB: begin
					ddram_we <= 1'b1;
					if (ddram_we && !ddram_busy) begin
						if (beat == (bcnt - 8'd1)) begin
							ddram_we <= 1'b0;
							tst_busy <= 1'b0;
							state <= ST_IDLE;
							tst_wr_last_data <= tst_wdata;
							tst_wr_done <= 1'b1;
						end
						beat <= beat + 8'd1;
					end
				end
				ST_RD_REQ:
					if (ddram_busy)
						ddram_rd <= 1'b1;
					else
						state <= ST_RD_RCV;
				ST_RD_RCV:
					if (ddram_dout_ready) begin
						tst_rdata <= ddram_dout;
						tst_rd_valid <= 1'b1;
						if (beat == (bcnt - 8'd1)) begin
							tst_busy <= 1'b0;
							state <= ST_IDLE;
						end
						beat <= beat + 8'd1;
					end
				default: state <= ST_IDLE;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module wolf_dcs_ddr_top (
	clk,
	sdram_por,
	dl_wr,
	dl_addr,
	dl_data,
	dl_ack,
	dl_busy,
	rom_req,
	rom_addr,
	rom_rdy,
	rom_q,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready
);
	reg _sv2v_0;
	parameter [28:0] DCS_DDR_BASE = 29'h06c00000;
	parameter [0:0] PACKED_512K = 1'b0;
	input wire clk;
	input wire sdram_por;
	input wire dl_wr;
	input wire [22:0] dl_addr;
	input wire [7:0] dl_data;
	output wire dl_ack;
	output wire dl_busy;
	input wire rom_req;
	input wire [19:0] rom_addr;
	output wire rom_rdy;
	output wire [63:0] rom_q;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	reg ag_wr_req;
	reg ag_rd_req;
	reg [25:0] ag_addr;
	reg [63:0] ag_wdata;
	wire [63:0] ag_rdata;
	wire ag_rd_valid;
	wire ag_busy;
	wire ag_wnext;
	stv_vram_ddr_agent #(.VRAM_DDR_BASE(DCS_DDR_BASE)) u_agent(
		.clk(clk),
		.sdram_por(sdram_por),
		.tst_wr_req(ag_wr_req),
		.tst_rd_req(ag_rd_req),
		.tst_addr(ag_addr),
		.tst_wdata(ag_wdata),
		.tst_be(8'hff),
		.tst_burstcnt(8'd1),
		.tst_rdata(ag_rdata),
		.tst_rd_valid(ag_rd_valid),
		.tst_busy(ag_busy),
		.tst_wnext(ag_wnext),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	reg buf_valid;
	reg wr_pending;
	reg wr_inflight;
	reg rd_inflight;
	reg rd_hole;
	reg [19:0] buf_beat;
	reg [7:0] buf_mask;
	reg [63:0] buf_data;
	wire [19:0] dl_beat = dl_addr[22:3];
	wire [7:0] dl_lane = 8'h01 << dl_addr[2:0];
	wire dl_same = buf_valid && (dl_beat == buf_beat);
	wire dl_take = (((dl_wr && !sdram_por) && !wr_pending) && !wr_inflight) && (!buf_valid || dl_same);
	wire read_start = (((!ag_busy && !wr_pending) && !wr_inflight) && rom_req) && !rd_inflight;
	wire rom_hole = PACKED_512K && rom_addr[16];
	wire [19:0] physical_rom_beat = (PACKED_512K ? {1'b0, rom_addr[19:17], rom_addr[15:0]} : rom_addr);
	assign dl_ack = dl_take;
	assign dl_busy = (buf_valid | wr_pending) | wr_inflight;
	always @(*) begin
		if (_sv2v_0)
			;
		ag_wr_req = (!ag_busy && wr_pending) && !wr_inflight;
		ag_rd_req = read_start && !rom_hole;
		if (ag_wr_req) begin
			ag_addr = {6'd0, buf_beat};
			ag_wdata = buf_data;
		end
		else begin
			ag_addr = {6'd0, physical_rom_beat};
			ag_wdata = 64'd0;
		end
	end
	assign rom_rdy = rd_inflight && (rd_hole || ag_rd_valid);
	assign rom_q = (rd_hole ? 64'hffffffffffffffff : ag_rdata);
	always @(posedge clk)
		if (sdram_por) begin
			buf_valid <= 1'b0;
			buf_beat <= 1'sb0;
			buf_mask <= 1'sb0;
			buf_data <= 1'sb0;
			wr_pending <= 1'b0;
			wr_inflight <= 1'b0;
			rd_inflight <= 1'b0;
			rd_hole <= 1'b0;
		end
		else begin
			if (ag_wr_req) begin
				wr_pending <= 1'b0;
				wr_inflight <= 1'b1;
			end
			if (read_start) begin
				rd_inflight <= 1'b1;
				rd_hole <= rom_hole;
			end
			if (rom_rdy) begin
				rd_inflight <= 1'b0;
				rd_hole <= 1'b0;
			end
			if (wr_inflight && !ag_busy) begin
				wr_inflight <= 1'b0;
				buf_valid <= 1'b0;
				buf_mask <= 1'sb0;
			end
			if (dl_take) begin
				if (!buf_valid) begin
					buf_valid <= 1'b1;
					buf_beat <= dl_beat;
					buf_mask <= dl_lane;
					buf_data <= 64'd0;
					buf_data[8 * dl_addr[2:0]+:8] <= dl_data;
					if (dl_lane == 8'hff)
						wr_pending <= 1'b1;
				end
				else begin
					buf_mask <= buf_mask | dl_lane;
					buf_data[8 * dl_addr[2:0]+:8] <= dl_data;
					if ((buf_mask | dl_lane) == 8'hff)
						wr_pending <= 1'b1;
				end
			end
			else if ((((dl_wr && buf_valid) && !wr_pending) && !wr_inflight) && (dl_beat != buf_beat))
				wr_pending <= 1'b1;
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module wolf_ddr3_arb (
	clk,
	b_allow,
	a_addr,
	a_burstcnt,
	a_rd,
	a_we,
	a_din,
	a_be,
	a_busy,
	a_dout,
	a_dout_ready,
	b_addr,
	b_burstcnt,
	b_rd,
	b_we,
	b_din,
	b_be,
	b_busy,
	b_dout,
	b_dout_ready,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready
);
	reg _sv2v_0;
	parameter [0:0] HONOR_B_ALLOW = 1'b0;
	input wire clk;
	input wire b_allow;
	input wire [28:0] a_addr;
	input wire [7:0] a_burstcnt;
	input wire a_rd;
	input wire a_we;
	input wire [63:0] a_din;
	input wire [7:0] a_be;
	output reg a_busy;
	output reg [63:0] a_dout;
	output reg a_dout_ready;
	input wire [28:0] b_addr;
	input wire [7:0] b_burstcnt;
	input wire b_rd;
	input wire b_we;
	input wire [63:0] b_din;
	input wire [7:0] b_be;
	output reg b_busy;
	output reg [63:0] b_dout;
	output reg b_dout_ready;
	output reg [28:0] ddram_addr;
	output reg [7:0] ddram_burstcnt;
	output reg ddram_rd;
	output reg ddram_we;
	output reg [63:0] ddram_din;
	output reg [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	localparam [1:0] G_NONE = 2'd0;
	localparam [1:0] G_A = 2'd1;
	localparam [1:0] G_B = 2'd2;
	reg [1:0] gnt;
	reg [7:0] beats_left;
	reg gnt_wr;
	wire a_req = a_rd | a_we;
	wire b_req = b_rd | b_we;
	wire b_eligible = !HONOR_B_ALLOW || b_allow;
	always @(posedge clk)
		case (gnt)
			G_NONE:
				if (a_req) begin
					gnt <= G_A;
					gnt_wr <= a_we;
					if (a_rd)
						beats_left <= (a_burstcnt == 8'd0 ? 8'd1 : a_burstcnt);
				end
				else if (b_req && b_eligible) begin
					gnt <= G_B;
					gnt_wr <= b_we;
					if (b_rd)
						beats_left <= (b_burstcnt == 8'd0 ? 8'd1 : b_burstcnt);
				end
			G_A:
				if (gnt_wr) begin
					if (!a_we)
						gnt <= G_NONE;
				end
				else if (ddram_dout_ready) begin
					if (beats_left <= 8'd1)
						gnt <= G_NONE;
					else
						beats_left <= beats_left - 8'd1;
				end
			G_B:
				if (gnt_wr) begin
					if (!b_we)
						gnt <= G_NONE;
				end
				else if (ddram_dout_ready) begin
					if (beats_left <= 8'd1)
						gnt <= G_NONE;
					else
						beats_left <= beats_left - 8'd1;
				end
			default: gnt <= G_NONE;
		endcase
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (gnt)
			G_A: begin
				ddram_addr = a_addr;
				ddram_burstcnt = a_burstcnt;
				ddram_rd = a_rd;
				ddram_we = a_we;
				ddram_din = a_din;
				ddram_be = a_be;
			end
			G_B: begin
				ddram_addr = b_addr;
				ddram_burstcnt = b_burstcnt;
				ddram_rd = b_rd;
				ddram_we = b_we;
				ddram_din = b_din;
				ddram_be = b_be;
			end
			default: begin
				ddram_addr = 29'd0;
				ddram_burstcnt = 8'd0;
				ddram_rd = 1'b0;
				ddram_we = 1'b0;
				ddram_din = 64'd0;
				ddram_be = 8'd0;
			end
		endcase
		a_busy = (gnt == G_A ? ddram_busy : a_req);
		a_dout = ddram_dout;
		a_dout_ready = (gnt == G_A ? ddram_dout_ready : 1'b0);
		b_busy = (gnt == G_B ? ddram_busy : b_req);
		b_dout = ddram_dout;
		b_dout_ready = (gnt == G_B ? ddram_dout_ready : 1'b0);
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module wolf_nvram_bridge (
	clk,
	rst_pon,
	ioctl_download,
	ioctl_upload,
	ioctl_wr,
	ioctl_index,
	ioctl_addr,
	ioctl_dout,
	ioctl_din,
	ioctl_upload_req,
	manual_save,
	clear_nvram,
	cpu_write_pulse,
	cmos_cpu_busy,
	cmos_quiesce,
	nvram_ext_en,
	nvram_ext_wr,
	nvram_ext_addr,
	nvram_ext_wdata,
	nvram_ext_rdata,
	nvram_busy,
	nvram_dirty
);
	parameter integer NVRAM_BYTES = 49152;
	parameter [7:0] NVRAM_INDEX = 8'd4;
	input wire clk;
	input wire rst_pon;
	input wire ioctl_download;
	input wire ioctl_upload;
	input wire ioctl_wr;
	input wire [7:0] ioctl_index;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output wire [7:0] ioctl_din;
	output wire ioctl_upload_req;
	input wire manual_save;
	input wire clear_nvram;
	input wire cpu_write_pulse;
	input wire cmos_cpu_busy;
	output wire cmos_quiesce;
	output wire nvram_ext_en;
	output wire nvram_ext_wr;
	output wire [15:0] nvram_ext_addr;
	output wire [7:0] nvram_ext_wdata;
	input wire [7:0] nvram_ext_rdata;
	output wire nvram_busy;
	output reg nvram_dirty;
	reg clearing;
	reg [15:0] clear_addr;
	reg old_clear;
	reg old_manual;
	reg old_nvram_upload;
	reg save_pending;
	wire nvram_download = ioctl_download && (ioctl_index == NVRAM_INDEX);
	wire nvram_upload = ioctl_upload && (ioctl_index == NVRAM_INDEX);
	wire nvram_addr_valid = ioctl_addr < NVRAM_BYTES;
	assign nvram_busy = nvram_download || clearing;
	assign cmos_quiesce = (save_pending || nvram_upload) || nvram_busy;
	assign nvram_ext_en = nvram_busy || nvram_upload;
	assign nvram_ext_wr = clearing || ((nvram_download && ioctl_wr) && nvram_addr_valid);
	assign nvram_ext_addr = (clearing ? clear_addr : ioctl_addr[15:0]);
	assign nvram_ext_wdata = (clearing ? 8'h00 : ioctl_dout);
	assign ioctl_din = ((ioctl_index == NVRAM_INDEX) && nvram_addr_valid ? nvram_ext_rdata : 8'h00);
	assign ioctl_upload_req = save_pending && !nvram_busy;
	wire _unused_cmos_cpu_busy = cmos_cpu_busy;
	always @(posedge clk)
		if (rst_pon) begin
			clearing <= 1'b0;
			clear_addr <= 16'd0;
			old_clear <= 1'b0;
			old_manual <= 1'b0;
			old_nvram_upload <= 1'b0;
			save_pending <= 1'b0;
			nvram_dirty <= 1'b0;
		end
		else begin
			old_clear <= clear_nvram;
			old_manual <= manual_save;
			old_nvram_upload <= nvram_upload;
			if ((clear_nvram && !old_clear) && !clearing) begin
				clearing <= 1'b1;
				clear_addr <= 16'd0;
			end
			else if (clearing) begin
				if (clear_addr == (NVRAM_BYTES - 1)) begin
					clearing <= 1'b0;
					nvram_dirty <= 1'b1;
				end
				else
					clear_addr <= clear_addr + 1'b1;
			end
			if (manual_save && !old_manual)
				save_pending <= 1'b1;
			if (nvram_upload && !old_nvram_upload) begin
				save_pending <= 1'b0;
				nvram_dirty <= 1'b0;
			end
			if ((nvram_download && ioctl_wr) && nvram_addr_valid) begin
				save_pending <= 1'b0;
				nvram_dirty <= 1'b0;
			end
			if (cpu_write_pulse)
				nvram_dirty <= 1'b1;
		end
endmodule
`default_nettype wire
`default_nettype none
module wolf_audio_guard (
	clk,
	hold_zero,
	audio_l_in,
	audio_r_in,
	audio_l_out,
	audio_r_out
);
	parameter integer CLK_HZ = 80000000;
	parameter integer SAMPLE_HZ = 31250;
	parameter integer RAMP_BITS = 12;
	input wire clk;
	input wire hold_zero;
	input wire signed [15:0] audio_l_in;
	input wire signed [15:0] audio_r_in;
	output reg signed [15:0] audio_l_out = 16'sd0;
	output reg signed [15:0] audio_r_out = 16'sd0;
	localparam integer SAMPLE_DIV = CLK_HZ / SAMPLE_HZ;
	localparam [RAMP_BITS:0] GAIN_FULL = {1'b1, {RAMP_BITS {1'b0}}};
	reg [$clog2(SAMPLE_DIV) - 1:0] sample_div = 1'sb0;
	reg [RAMP_BITS:0] gain = 1'sb0;
	wire sample_ce = sample_div == (SAMPLE_DIV - 1);
	wire signed [RAMP_BITS + 1:0] gain_signed = $signed({1'b0, gain});
	wire signed [RAMP_BITS + 17:0] product_l = audio_l_in * gain_signed;
	wire signed [RAMP_BITS + 17:0] product_r = audio_r_in * gain_signed;
	wire input_audible = (audio_l_in != 16'sd0) || (audio_r_in != 16'sd0);
	always @(posedge clk)
		if (hold_zero) begin
			sample_div <= 1'sb0;
			gain <= 1'sb0;
			audio_l_out <= 16'sd0;
			audio_r_out <= 16'sd0;
		end
		else begin
			if (sample_ce)
				sample_div <= 1'sb0;
			else
				sample_div <= sample_div + 1'b1;
			if (sample_ce) begin
				if ((gain == {(RAMP_BITS >= 0 ? RAMP_BITS + 1 : 1 - RAMP_BITS) {1'sb0}}) && !input_audible) begin
					audio_l_out <= 16'sd0;
					audio_r_out <= 16'sd0;
				end
				else if (gain != GAIN_FULL) begin
					audio_l_out <= product_l >>> RAMP_BITS;
					audio_r_out <= product_r >>> RAMP_BITS;
					gain <= gain + 1'b1;
				end
				else begin
					audio_l_out <= audio_l_in;
					audio_r_out <= audio_r_in;
				end
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module wolf_dma (
	clk,
	rst,
	reg_we,
	reg_addr,
	reg_wdata,
	reg_rdata,
	reg_pair_addr,
	reg_pair_rdata,
	src_req,
	src_addr,
	src_active,
	src_stream,
	src_data,
	src_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_count,
	fb_words,
	fb_reverse,
	fb_ack,
	wr_busy,
	busy,
	blit_irq,
	dma_palette,
	dbg_q_overflow,
	dbg_exec_done,
	dbg_q_highwater
);
	reg _sv2v_0;
	parameter [0:0] GFX_ROM_LARGE = 1'b1;
	parameter [0:0] TIMED_IRQ_PUMP = 1'b0;
	parameter [0:0] DRAIN_QUEUED_ON_STOP = 1'b0;
	parameter integer NORMAL_Q_DEPTH = 256;
	parameter integer FB_GROUP_MAX = 1;
	input wire clk;
	input wire rst;
	input wire reg_we;
	input wire [3:0] reg_addr;
	input wire [15:0] reg_wdata;
	output wire [15:0] reg_rdata;
	input wire [2:0] reg_pair_addr;
	output wire [31:0] reg_pair_rdata;
	output wire src_req;
	output wire [31:0] src_addr;
	output wire src_active;
	output wire src_stream;
	input wire [7:0] src_data;
	input wire src_ack;
	output reg fb_we;
	localparam signed [31:0] wolf_pkg_FB_ADDR_W = 19;
	output reg [18:0] fb_addr;
	output reg [15:0] fb_wdata;
	output reg [2:0] fb_count;
	output reg [63:0] fb_words;
	output reg fb_reverse;
	input wire fb_ack;
	input wire wr_busy;
	output wire busy;
	output reg blit_irq;
	output wire [15:0] dma_palette;
	output wire dbg_q_overflow;
	output wire dbg_exec_done;
	output wire [8:0] dbg_q_highwater;
	localparam [1:0] OP_SKIP = 2'd0;
	localparam [1:0] OP_COLOR = 2'd1;
	localparam [1:0] OP_COPY = 2'd2;
	localparam signed [31:0] wolf_pkg_DMA_NREGS = 18;
	reg [15:0] regf [0:17];
	reg busy_r;
	reg cadence_valid_r;
	reg [17:0] cadence_x_reload_r;
	reg [17:0] cadence_x_rem_r;
	reg [17:0] cadence_y_rem_r;
	reg [15:0] cadence_xstep_r;
	reg [15:0] cadence_ystep_r;
	reg [6:0] cadence_phase_r;
	reg halt_pending_r;
	reg walker_halted_r;
	reg paused_r;
	reg kill_pending_r;
	reg [15:0] restart_regf [0:17];
	reg restart_pending_r;
	reg setup_from_restart_r;
	localparam integer NORMAL_Q_PTR_W = $clog2(NORMAL_Q_DEPTH);
	localparam integer NORMAL_Q_CNT_W = $clog2(NORMAL_Q_DEPTH + 1);
	localparam integer NORMAL_Q_WORD_W = 288;
	(* ramstyle = "M10K, no_rw_check" *) reg [NORMAL_Q_WORD_W - 1:0] normal_q_mem [0:NORMAL_Q_DEPTH - 1];
	reg [NORMAL_Q_WORD_W - 1:0] normal_q_push_word;
	reg [NORMAL_Q_WORD_W - 1:0] normal_launch_word;
	reg [NORMAL_Q_PTR_W - 1:0] normal_q_wptr;
	reg [NORMAL_Q_PTR_W - 1:0] normal_q_rptr;
	reg [NORMAL_Q_CNT_W - 1:0] normal_q_count;
	(* preserve *) reg normal_q_overflow_r;
	(* preserve *) reg [NORMAL_Q_CNT_W - 1:0] normal_q_highwater_r;
	reg setup_from_normal_q_r;
	wire normal_q_wptr_last = normal_q_wptr == (NORMAL_Q_DEPTH - 1);
	wire normal_q_rptr_last = normal_q_rptr == (NORMAL_Q_DEPTH - 1);
	integer qi;
	localparam [4:0] wolf_pkg_DMA_COMMAND = 5'd1;
	always @(*) begin
		if (_sv2v_0)
			;
		for (qi = 0; qi < wolf_pkg_DMA_NREGS; qi = qi + 1)
			normal_q_push_word[qi * 16+:16] = regf[qi];
		normal_q_push_word[wolf_pkg_DMA_COMMAND * 16+:16] = reg_wdata;
	end
	wire [15:0] cmd_reg = regf[wolf_pkg_DMA_COMMAND];
	localparam [4:0] wolf_pkg_DMA_LRSKIP = 5'd0;
	wire [15:0] r_lrskip = regf[wolf_pkg_DMA_LRSKIP];
	localparam [4:0] wolf_pkg_DMA_OFFSETLO = 5'd2;
	wire [15:0] r_offlo = regf[wolf_pkg_DMA_OFFSETLO];
	localparam [4:0] wolf_pkg_DMA_OFFSETHI = 5'd3;
	wire [15:0] r_offhi = regf[wolf_pkg_DMA_OFFSETHI];
	localparam [4:0] wolf_pkg_DMA_XSTART = 5'd4;
	wire [15:0] r_xstart = regf[wolf_pkg_DMA_XSTART];
	localparam [4:0] wolf_pkg_DMA_YSTART = 5'd5;
	wire [15:0] r_ystart = regf[wolf_pkg_DMA_YSTART];
	localparam [4:0] wolf_pkg_DMA_WIDTH = 5'd6;
	wire [15:0] r_width = regf[wolf_pkg_DMA_WIDTH];
	localparam [4:0] wolf_pkg_DMA_HEIGHT = 5'd7;
	wire [15:0] r_height = regf[wolf_pkg_DMA_HEIGHT];
	localparam [4:0] wolf_pkg_DMA_PALETTE = 5'd8;
	wire [15:0] r_pal = regf[wolf_pkg_DMA_PALETTE];
	localparam [4:0] wolf_pkg_DMA_COLOR = 5'd9;
	wire [15:0] r_color = regf[wolf_pkg_DMA_COLOR];
	localparam [4:0] wolf_pkg_DMA_SCALE_X = 5'd10;
	wire [15:0] r_scalex = regf[wolf_pkg_DMA_SCALE_X];
	localparam [4:0] wolf_pkg_DMA_SCALE_Y = 5'd11;
	wire [15:0] r_scaley = regf[wolf_pkg_DMA_SCALE_Y];
	localparam [4:0] wolf_pkg_DMA_TOPCLIP = 5'd12;
	wire [15:0] r_top = regf[wolf_pkg_DMA_TOPCLIP];
	localparam [4:0] wolf_pkg_DMA_BOTCLIP = 5'd13;
	wire [15:0] r_bot = regf[wolf_pkg_DMA_BOTCLIP];
	localparam [4:0] wolf_pkg_DMA_LEFTCLIP = 5'd16;
	wire [15:0] r_left = regf[wolf_pkg_DMA_LEFTCLIP];
	localparam [4:0] wolf_pkg_DMA_RIGHTCLIP = 5'd17;
	wire [15:0] r_right = regf[wolf_pkg_DMA_RIGHTCLIP];
	localparam [4:0] wolf_pkg_DMA_CONFIG = 5'd15;
	wire [15:0] r_config = regf[wolf_pkg_DMA_CONFIG];
	wire cfg_bank = r_config[5];
	function automatic [4:0] wolf_pkg_dma_regmap;
		input reg bank;
		input reg [3:0] off;
		case (off)
			4'd12: wolf_pkg_dma_regmap = (bank ? wolf_pkg_DMA_TOPCLIP : wolf_pkg_DMA_LEFTCLIP);
			4'd13: wolf_pkg_dma_regmap = (bank ? wolf_pkg_DMA_BOTCLIP : wolf_pkg_DMA_RIGHTCLIP);
			default: wolf_pkg_dma_regmap = {1'b0, off};
		endcase
	endfunction
	wire [4:0] regnum_w = wolf_pkg_dma_regmap(cfg_bank, reg_addr);
	localparam signed [31:0] wolf_pkg_DMA_CMD_TRIG_BIT = 15;
	wire wdata_trig = reg_wdata[wolf_pkg_DMA_CMD_TRIG_BIT];
	wire command_w = reg_we && (regnum_w == wolf_pkg_DMA_COMMAND);
	wire trig_w = command_w && wdata_trig;
	reg timeout_stop_armed_r;
	reg [5:0] timeout_stop_age_r;
	wire stop_w_raw = command_w && !wdata_trig;
	wire timeout_stop_context_w = (DRAIN_QUEUED_ON_STOP && busy_r) && ((normal_q_count != 0) || cadence_valid_r);
	wire timeout_pair_resume_w = stop_w_raw && timeout_stop_armed_r;
	wire queued_stop_defer_w = timeout_pair_resume_w;
	wire stop_w = stop_w_raw && !timeout_pair_resume_w;
	wire resume_w = trig_w || timeout_pair_resume_w;
	wire [15:0] cadence_xstep_w = (r_scalex != 16'h0000 ? r_scalex : 16'h0100);
	wire [15:0] cadence_ystep_w = (r_scaley != 16'h0000 ? r_scaley : 16'h0100);
	wire [17:0] cadence_width_fp_w = {r_width[9:0], 8'h00};
	wire [17:0] cadence_height_fp_w = {r_height[9:0], 8'h00};
	wire cadence_nonzero_w = (cadence_width_fp_w >= {2'b00, cadence_xstep_w}) && (cadence_height_fp_w >= {2'b00, cadence_ystep_w});
	wire cadence_start_w = (TIMED_IRQ_PUMP && trig_w) && cadence_nonzero_w;
	wire [17:0] cadence_x_init_w = (cadence_width_fp_w - {2'b00, cadence_xstep_w}) + 18'd1;
	wire [17:0] cadence_y_init_w = (cadence_height_fp_w - {2'b00, cadence_ystep_w}) + 18'd1;
	wire cadence_immediate_w = (TIMED_IRQ_PUMP && trig_w) && !cadence_nonzero_w;
	wire [7:0] cadence_phase_next_w = {1'b0, cadence_phase_r} + 8'd32;
	wire cadence_pixel_tick_w = cadence_phase_next_w >= 8'd105;
	wire cadence_complete_w = (((TIMED_IRQ_PUMP && cadence_valid_r) && cadence_pixel_tick_w) && (cadence_x_rem_r <= {2'b00, cadence_xstep_r})) && (cadence_y_rem_r <= {2'b00, cadence_ystep_r});
	assign busy = busy_r;
	assign dma_palette = r_pal;
	assign dbg_q_overflow = normal_q_overflow_r;
	assign dbg_q_highwater = normal_q_highwater_r;
	wire [3:0] eff_raddr = (reg_addr == 4'd0 ? 4'd1 : reg_addr);
	wire [14:0] cmd_lo15 = cmd_reg[14:0];
	assign reg_rdata = regf[{1'b0, eff_raddr}];
	wire [3:0] pair_lo = (reg_pair_addr == 0 ? 4'd1 : {reg_pair_addr, 1'b0});
	assign reg_pair_rdata = {regf[{1'b0, reg_pair_addr, 1'b1}], regf[{1'b0, pair_lo}]};
	reg [4:0] state;
	reg [4:0] state_n;
	localparam signed [31:0] FBQ_DEPTH = 4;
	reg [18:0] fbq_addr [0:3];
	reg [15:0] fbq_data [0:3];
	reg [1:0] fbq_wptr_r;
	reg [1:0] fbq_rptr_r;
	reg [2:0] fbq_count_r;
	reg fb_writer_active_r;
	wire fbq_empty_w = fbq_count_r == 3'd0;
	wire fbq_full_w = fbq_count_r == 3'd4;
	wire fb_writer_idle_w = !fb_writer_active_r && !fb_we;
	wire local_writes_drained_w = fbq_empty_w && fb_writer_idle_w;
	wire source_wait_w = src_req;
	wire walker_boundary_w = !source_wait_w || src_ack;
	wire first_stop_w = ((((stop_w && busy_r) && !paused_r) && !halt_pending_r) && !walker_halted_r) && !kill_pending_r;
	wire second_stop_w = (stop_w && busy_r) && (((paused_r || halt_pending_r) || walker_halted_r) || kill_pending_r);
	wire halt_request_w = halt_pending_r || first_stop_w;
	wire kill_request_w = kill_pending_r || second_stop_w;
	wire stop_boundary_enter_w = (((!resume_w && !walker_halted_r) && !paused_r) && (halt_request_w || kill_request_w)) && walker_boundary_w;
	wire stop_source_advance_w = (stop_boundary_enter_w && source_wait_w) && src_ack;
	wire walker_kill_safe_w = (walker_halted_r || paused_r) || walker_boundary_w;
	wire kill_enter_w = ((!resume_w && kill_request_w) && walker_kill_safe_w) && !fb_writer_active_r;
	wire pause_enter_w = (((!trig_w && !kill_request_w) && !paused_r) && (walker_halted_r || stop_boundary_enter_w)) && local_writes_drained_w;
	wire fsm_step_w = ((!paused_r && !walker_halted_r) && !kill_enter_w) && (!stop_boundary_enter_w || stop_source_advance_w);
	reg [3:0] bpp_c;
	reg [1:0] zero_c;
	reg [1:0] nz_c;
	reg need_px_c;
	reg xflip_c;
	reg yflip_c;
	reg skip_c;
	reg scale_c;
	reg [1:0] preskip_c;
	reg [1:0] postskip_c;
	reg [15:0] xstep_c;
	reg [15:0] ystep_c;
	reg [9:0] width_c;
	reg [9:0] xpos_c;
	reg [9:0] height_c;
	reg [15:0] pal16_c;
	reg [15:0] color16_c;
	reg [8:0] topclip_c;
	reg [8:0] botclip_c;
	reg [9:0] leftclip_c;
	reg [9:0] rightclip_c;
	reg signed [31:0] startskip_c;
	reg signed [31:0] endskip_c;
	reg [31:0] offset_r;
	reg [31:0] o_r;
	reg signed [31:0] ix;
	reg signed [31:0] iy;
	reg signed [31:0] width_fp;
	reg [9:0] sx;
	reg [8:0] sy;
	reg signed [31:0] pre_r;
	reg signed [31:0] post_r;
	reg [7:0] b0_r;
	reg [7:0] b1_r;
	reg [31:0] bc_a0;
	reg [31:0] bc_a1;
	reg [7:0] bc_d0;
	reg [7:0] bc_d1;
	reg bc_v0;
	reg bc_v1;
	reg [7:0] skipval_r;
	reg [7:0] px_r;
	reg [31:0] sa_cnt;
	reg [31:0] fast_src_prefetch_addr_r;
	reg fast_src_prefetch_ready_r;
	reg fast_src_carry_r;
	reg [31:0] src_state_addr_r;
	reg src_early_valid_r;
	reg [12:0] scale_advance_r;
	reg [4:0] state_q1;
	reg drun;
	reg [5:0] dcnt;
	reg [31:0] dnum;
	reg [31:0] dden;
	reg [31:0] drem;
	reg [31:0] dquo;
	reg [31:0] txm_r;
	reg clip_gap;
	reg [13:0] rowbits_r;
	reg [8:0] tyr_r;
	reg [10:0] w2p_r;
	reg [10:0] w3p_r;
	reg [31:0] radv_r;
	reg [31:0] w2adv_r;
	reg [31:0] w3adv_r;
	wire [15:0] s_cmd = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_COMMAND * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_COMMAND] : cmd_reg));
	wire [15:0] s_lrskip = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_LRSKIP * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_LRSKIP] : r_lrskip));
	wire [15:0] s_offlo = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_OFFSETLO * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_OFFSETLO] : r_offlo));
	wire [15:0] s_offhi = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_OFFSETHI * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_OFFSETHI] : r_offhi));
	wire [15:0] s_xstart = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_XSTART * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_XSTART] : r_xstart));
	wire [15:0] s_ystart = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_YSTART * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_YSTART] : r_ystart));
	wire [15:0] s_width = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_WIDTH * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_WIDTH] : r_width));
	wire [15:0] s_height = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_HEIGHT * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_HEIGHT] : r_height));
	wire [15:0] s_pal = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_PALETTE * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_PALETTE] : r_pal));
	wire [15:0] s_color = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_COLOR * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_COLOR] : r_color));
	wire [15:0] s_scalex = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_SCALE_X * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_SCALE_X] : r_scalex));
	wire [15:0] s_scaley = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_SCALE_Y * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_SCALE_Y] : r_scaley));
	wire [15:0] s_top = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_TOPCLIP * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_TOPCLIP] : r_top));
	wire [15:0] s_bot = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_BOTCLIP * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_BOTCLIP] : r_bot));
	wire [15:0] s_left = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_LEFTCLIP * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_LEFTCLIP] : r_left));
	wire [15:0] s_right = (setup_from_normal_q_r ? normal_launch_word[wolf_pkg_DMA_RIGHTCLIP * 16+:16] : (setup_from_restart_r ? restart_regf[wolf_pkg_DMA_RIGHTCLIP] : r_right));
	wire [3:0] mode_w = s_cmd[3:0];
	wire xflip_w = s_cmd[4];
	wire yflip_w = s_cmd[5];
	wire lrsplit_w = s_cmd[6];
	wire skip_w = s_cmd[7];
	wire [1:0] preskip_w = s_cmd[9:8];
	wire [1:0] postskip_w = s_cmd[11:10];
	function automatic [3:0] wolf_pkg_dma_bpp;
		input reg [15:0] command;
		reg [2:0] b;
		begin
			b = command[14:12];
			wolf_pkg_dma_bpp = (b == 3'd0 ? 4'd8 : {1'b0, b});
		end
	endfunction
	wire [3:0] bpp_w = wolf_pkg_dma_bpp(s_cmd);
	wire [15:0] xstep_w = (s_scalex == 16'd0 ? 16'h0100 : s_scalex);
	wire [15:0] ystep_w = (s_scaley == 16'd0 ? 16'h0100 : s_scaley);
	wire scale_w = (xstep_w != 16'h0100) || (ystep_w != 16'h0100);
	reg [1:0] zero_w;
	reg [1:0] nz_w;
	always @(*) begin
		if (_sv2v_0)
			;
		case (mode_w)
			4'h1: begin
				zero_w = OP_COPY;
				nz_w = OP_SKIP;
			end
			4'h2: begin
				zero_w = OP_SKIP;
				nz_w = OP_COPY;
			end
			4'h3: begin
				zero_w = OP_COPY;
				nz_w = OP_COPY;
			end
			4'h4, 4'h5: begin
				zero_w = OP_COLOR;
				nz_w = OP_SKIP;
			end
			4'h6, 4'h7: begin
				zero_w = OP_COLOR;
				nz_w = OP_COPY;
			end
			4'h8, 4'ha: begin
				zero_w = OP_SKIP;
				nz_w = OP_COLOR;
			end
			4'h9, 4'hb: begin
				zero_w = OP_COPY;
				nz_w = OP_COLOR;
			end
			4'hc, 4'hd, 4'he, 4'hf: begin
				zero_w = OP_COLOR;
				nz_w = OP_COLOR;
			end
			default: begin
				zero_w = OP_SKIP;
				nz_w = OP_SKIP;
			end
		endcase
	end
	wire draw_none_w = mode_w == 4'h0;
	wire need_px_w = (zero_w != nz_w) || (zero_w == OP_COPY);
	wire [31:0] gfxoff0 = (mode_w == 4'hc ? 32'd0 : {s_offhi, s_offlo});
	wire [31:0] gfxoff1 = ((GFX_ROM_LARGE == 1'b0) && (gfxoff0 >= 32'h02000000) ? gfxoff0 - 32'h02000000 : gfxoff0);
	wire [31:0] gfxoff2 = (gfxoff1 >= 32'hf8000000 ? gfxoff1 - 32'hf8000000 : gfxoff1);
	wire skipdma_w = gfxoff2 >= 32'h10000000;
	wire [31:0] startskip_w = (lrsplit_w ? {24'd0, s_lrskip[7:0]} : 32'd0);
	wire [31:0] endskip_w = (lrsplit_w ? {24'd0, s_lrskip[15:8]} : {16'd0, s_lrskip});
	wire [9:0] w_width10 = s_width[9:0];
	wire [9:0] w_height10 = s_height[9:0];
	wire [9:0] w_xpos10 = s_xstart[9:0];
	wire [8:0] w_ypos9 = s_ystart[8:0];
	wire [7:0] w_color8 = s_color[7:0];
	wire [8:0] w_top9 = s_top[8:0];
	wire [8:0] w_bot9 = s_bot[8:0];
	wire [9:0] w_left10 = s_left[9:0];
	wire [9:0] w_right10 = s_right[9:0];
	wire [31:0] xstep32 = {16'd0, xstep_c};
	wire signed [31:0] xstep_s = $signed({16'd0, xstep_c});
	wire [31:0] bpp32 = {28'd0, bpp_c};
	wire [31:0] width32 = {22'd0, width_c};
	wire signed [31:0] height_fp = $signed({22'd0, height_c}) <<< 8;
	function automatic [63:0] source_byte_pair;
		input reg [31:0] bitpos;
		input reg [12:0] step_bits;
		reg [3:0] low_sum;
		reg [10:0] step_hi0;
		reg [10:0] step_hi1;
		reg [10:0] step_hi2;
		reg [29:0] upper0;
		reg [29:0] upper1;
		reg [29:0] upper2;
		reg [31:0] byte0;
		reg [31:0] byte1;
		begin
			low_sum = {1'b0, bitpos[2:0]} + {1'b0, step_bits[2:0]};
			step_hi0 = {1'b0, step_bits[12:3]};
			step_hi1 = step_hi0 + 11'd1;
			step_hi2 = step_hi0 + 11'd2;
			upper0 = {1'b0, bitpos[31:3]} + {19'd0, step_hi0};
			upper1 = {1'b0, bitpos[31:3]} + {19'd0, step_hi1};
			upper2 = {1'b0, bitpos[31:3]} + {19'd0, step_hi2};
			if (low_sum[3]) begin
				byte0 = {3'b000, upper1[28:0]};
				byte1 = {2'b00, upper2[29] ^ upper1[29], upper2[28:0]};
			end
			else begin
				byte0 = {3'b000, upper0[28:0]};
				byte1 = {2'b00, upper1[29] ^ upper0[29], upper1[28:0]};
			end
			source_byte_pair = {byte1, byte0};
		end
	endfunction
	wire [31:0] o_byte0 = {3'b000, o_r[31:3]};
	wire [31:0] o_byte1 = o_byte0 + 32'd1;
	wire [2:0] o_lo3 = o_r[2:0];
	wire [7:0] b1_eff = (((state == 5'd16) || (state == 5'd5)) || (state == 5'd23) ? src_data : b1_r);
	wire [15:0] win_now = {b1_eff, b0_r};
	wire [15:0] win_sh = win_now >> o_lo3;
	wire [7:0] byte_now = win_sh[7:0];
	wire [8:0] maskfull = (9'd1 << bpp_c) - 9'd1;
	wire px_straddle = ({2'd0, o_lo3} + {1'b0, bpp_c}) > 5'd8;
	wire hit0 = (bc_v0 && (bc_a0 == o_byte0)) || (bc_v1 && (bc_a1 == o_byte0));
	wire hit1 = (bc_v0 && (bc_a0 == o_byte1)) || (bc_v1 && (bc_a1 == o_byte1));
	wire [7:0] hitd0 = (bc_v0 && (bc_a0 == o_byte0) ? bc_d0 : bc_d1);
	wire [7:0] hitd1 = (bc_v0 && (bc_a0 == o_byte1) ? bc_d0 : bc_d1);
	wire need_f0 = !hit0;
	wire need_f1 = px_straddle && !hit1;
	wire [31:0] cur_req_addr_w = (!need_f0 && need_f1 ? o_byte1 : o_byte0);
	wire [63:0] ns_next_bytes_w = source_byte_pair(o_r, {9'd0, bpp_c});
	wire [31:0] ns_next_byte0_w = ns_next_bytes_w[31:0];
	wire [31:0] ns_next_byte1_w = ns_next_bytes_w[63:32];
	wire [2:0] ns_next_low_w = o_r[2:0] + bpp_c[2:0];
	wire ns_next_straddle_w = ({2'd0, ns_next_low_w} + {1'b0, bpp_c}) > 5'd8;
	wire ns_next_hit0_w = (bc_v0 && (bc_a0 == ns_next_byte0_w)) || (bc_v1 && (bc_a1 == ns_next_byte0_w));
	wire ns_next_hit1_w = (bc_v0 && (bc_a0 == ns_next_byte1_w)) || (bc_v1 && (bc_a1 == ns_next_byte1_w));
	wire ns_next_need0_w = !ns_next_hit0_w;
	wire ns_next_need1_w = ns_next_straddle_w && !ns_next_hit1_w;
	wire [31:0] ns_next_req_addr_w = (!ns_next_need0_w && ns_next_need1_w ? ns_next_byte1_w : ns_next_byte0_w);
	wire [7:0] pixmask = maskfull[7:0];
	wire [15:0] win_cache = {hitd1, hitd0};
	wire [7:0] px_cache = (win_cache >> o_lo3) & {8'd0, pixmask};
	wire [7:0] px_now = byte_now & pixmask;
	wire [4:0] presh_w = {3'd0, preskip_c} + 5'd8;
	wire [4:0] postsh_w = {3'd0, postskip_c} + 5'd8;
	wire [31:0] pre_fp_w = {28'd0, skipval_r[3:0]} << presh_w;
	wire [31:0] post_fp_w = {28'd0, skipval_r[7:4]} << postsh_w;
	wire [9:0] tx_skip10 = dquo[9:0];
	wire y_clip_w = (sy < topclip_c) || (sy > botclip_c);
	wire signed [31:0] ss_fp = startskip_c <<< 8;
	wire [31:0] ss_diff_w = $unsigned(ss_fp - ix);
	wire entering_skdiv = (state == 5'd6) && (state_q1 != 5'd6);
	wire entering_rpdiv = (state == 5'd10) && (state_q1 != 5'd10);
	wire xstep_unity_w = xstep_c == 16'h0100;
	wire fast_skdiv_w = entering_skdiv && xstep_unity_w;
	wire fast_rpdiv_w = entering_rpdiv && xstep_unity_w;
	wire div_go = (entering_skdiv | entering_rpdiv) && !xstep_unity_w;
	wire [31:0] div_num = (entering_skdiv ? pre_fp_w : ss_diff_w);
	wire [31:0] div_den = xstep32;
	wire div_busy = drun | div_go;
	wire signed [31:0] we_lim = $signed(width32) - endskip_c;
	wire pix_remain = ix < width_fp;
	wire in_clip = (sx >= leftclip_c) && (sx <= rightclip_c);
	wire [31:0] ix_u = $unsigned(ix);
	wire [31:0] dx_w = ((ix_u + xstep32) >> 8) - (ix_u >> 8);
	wire [12:0] scale_advance_w = {4'd0, dx_w[8:0]} * bpp_c;
	wire [63:0] sc_next_bytes_w = source_byte_pair(o_r, scale_advance_r);
	wire [31:0] sc_next_byte0_w = sc_next_bytes_w[31:0];
	wire [31:0] sc_next_byte1_w = sc_next_bytes_w[63:32];
	wire [2:0] sc_next_low_w = o_r[2:0] + scale_advance_r[2:0];
	wire sc_next_straddle_w = ({2'd0, sc_next_low_w} + {1'b0, bpp_c}) > 5'd8;
	wire sc_next_hit0_w = (bc_v0 && (bc_a0 == sc_next_byte0_w)) || (bc_v1 && (bc_a1 == sc_next_byte0_w));
	wire sc_next_hit1_w = (bc_v0 && (bc_a0 == sc_next_byte1_w)) || (bc_v1 && (bc_a1 == sc_next_byte1_w));
	wire sc_next_need0_w = !sc_next_hit0_w;
	wire sc_next_need1_w = sc_next_straddle_w && !sc_next_hit1_w;
	wire [31:0] sc_next_req_addr_w = (!sc_next_need0_w && sc_next_need1_w ? sc_next_byte1_w : sc_next_byte0_w);
	wire signed [31:0] ix_next_unity_w = ix + 32'sd256;
	wire [9:0] sx_next_unity_w = (xflip_c ? sx - 10'd1 : sx + 10'd1);
	wire next_unity_in_clip_w = (sx_next_unity_w >= leftclip_c) && (sx_next_unity_w <= rightclip_c);
	wire [28:0] prefetch_byte_plus1_w = o_r[31:3] + 29'd1;
	wire [29:0] prefetch_byte_plus2_w = {1'b0, o_r[31:3]} + 30'd2;
	wire prefetch_pointer_wrap_w = &o_r[31:3];
	wire [31:0] prefetch_next_addr_w = (o_r[2:0] == 3'd0 ? {3'b000, prefetch_byte_plus1_w} : (prefetch_pointer_wrap_w ? 32'd1 : {2'b00, prefetch_byte_plus2_w}));
	wire fast_src_prefetch_w = ((state == 5'd17) && !fbq_full_w) && fast_src_prefetch_ready_r;
	wire [31:0] fast_src_prefetch_addr_w = fast_src_prefetch_addr_r;
	wire pix_src_demand_w = ((((state == 5'd14) && pix_remain) && in_clip) && need_px_c) && (need_f0 || need_f1);
	wire [1:0] op_eff_w = (zero_c == nz_c ? zero_c : (px_r != 8'd0 ? nz_c : zero_c));
	wire do_write_w = op_eff_w != OP_SKIP;
	wire prefetch_px_complete_w = (!need_px_c || (hit0 && !need_f1)) || (src_ack && (hit0 || !need_f1));
	wire prefetch_wr_enter_w = (((((state == 5'd14) && pix_remain) && in_clip) && prefetch_px_complete_w) || (((state == 5'd15) && src_ack) && !need_f1)) || ((state == 5'd16) && src_ack);
	wire prefetch_wr_leave_w = (state == 5'd17) && (!do_write_w || !fbq_full_w);
	wire [15:0] pix_data_w = (op_eff_w == OP_COLOR ? color16_c : {8'd0, px_r} | pal16_c);
	localparam signed [31:0] wolf_pkg_FB_ROWSHIFT = 9;
	wire [18:0] fb_addr_w = ({{10 {1'b0}}, sy} << wolf_pkg_FB_ROWSHIFT) + {{9 {1'b0}}, sx};
	wire fbq_producer_step_w = ((!paused_r && !walker_halted_r) && !(((!resume_w && kill_request_w) && (!fast_src_prefetch_w || src_ack)) && !fb_writer_active_r)) && ((resume_w || !(halt_request_w || kill_request_w)) || fast_src_prefetch_w);
	wire fbq_push_w = ((fbq_producer_step_w && (state == 5'd17)) && do_write_w) && !fbq_full_w;
	wire fbq_discard_w = kill_request_w;
	wire fbq_pop_w = (!fb_writer_active_r && !fbq_empty_w) && !kill_request_w;
	reg [2:0] fbq_group_count_w;
	wire [2:0] fbq_count_with_push_w = fbq_count_r + {2'd0, fbq_push_w};
	reg [2:0] fbq_group_remaining_w;
	reg [63:0] fbq_group_words_w;
	reg fbq_group_reverse_w;
	wire [3:0] fbq_next_up_w;
	wire [3:0] fbq_next_down_w;
	wire [2:0] fbq_head_count_w [0:3];
	wire [2:0] fbq_head_remaining_w [0:3];
	wire [63:0] fbq_head_words_w [0:3];
	wire [3:0] fbq_head_reverse_w;
	genvar _gv_fg_h_1;
	generate
		for (_gv_fg_h_1 = 0; _gv_fg_h_1 < 4; _gv_fg_h_1 = _gv_fg_h_1 + 1) begin : g_fbq_head
			localparam fg_h = _gv_fg_h_1;
			localparam integer N1 = (fg_h + 1) % 4;
			localparam integer N2 = (fg_h + 2) % 4;
			localparam integer N3 = (fg_h + 3) % 4;
			wire same_line = fbq_addr[fg_h][18:4] == fbq_addr[N1][18:4];
			assign fbq_next_up_w[fg_h] = (same_line && (fbq_addr[fg_h][3:0] != 4'hf)) && (fbq_addr[N1][3:0] == (fbq_addr[fg_h][3:0] + 4'd1));
			assign fbq_next_down_w[fg_h] = (same_line && (fbq_addr[fg_h][3:0] != 4'h0)) && (fbq_addr[N1][3:0] == (fbq_addr[fg_h][3:0] - 4'd1));
			wire take2 = ((FB_GROUP_MAX >= 2) && (fbq_count_r >= 3'd2)) && (fbq_next_up_w[fg_h] || fbq_next_down_w[fg_h]);
			wire take3 = ((FB_GROUP_MAX >= 3) && (fbq_count_r >= 3'd3)) && ((fbq_next_up_w[fg_h] && fbq_next_up_w[N1]) || (fbq_next_down_w[fg_h] && fbq_next_down_w[N1]));
			wire take4 = ((FB_GROUP_MAX >= 4) && (fbq_count_r >= 3'd4)) && (((fbq_next_up_w[fg_h] && fbq_next_up_w[N1]) && fbq_next_up_w[N2]) || ((fbq_next_down_w[fg_h] && fbq_next_down_w[N1]) && fbq_next_down_w[N2]));
			assign fbq_head_count_w[fg_h] = (take4 ? 3'd4 : (take3 ? 3'd3 : (take2 ? 3'd2 : 3'd1)));
			assign fbq_head_remaining_w[fg_h] = (take4 ? fbq_count_with_push_w - 3'd4 : (take3 ? fbq_count_with_push_w - 3'd3 : (take2 ? fbq_count_with_push_w - 3'd2 : fbq_count_with_push_w - 3'd1)));
			assign fbq_head_reverse_w[fg_h] = take2 && fbq_next_down_w[fg_h];
			assign fbq_head_words_w[fg_h] = {(take4 ? fbq_data[N3] : 16'd0), (take3 ? fbq_data[N2] : 16'd0), (take2 ? fbq_data[N1] : 16'd0), fbq_data[fg_h]};
		end
	endgenerate
	always @(*) begin
		if (_sv2v_0)
			;
		case (fbq_rptr_r)
			2'd0: begin
				fbq_group_count_w = fbq_head_count_w[0];
				fbq_group_remaining_w = fbq_head_remaining_w[0];
				fbq_group_words_w = fbq_head_words_w[0];
				fbq_group_reverse_w = fbq_head_reverse_w[0];
			end
			2'd1: begin
				fbq_group_count_w = fbq_head_count_w[1];
				fbq_group_remaining_w = fbq_head_remaining_w[1];
				fbq_group_words_w = fbq_head_words_w[1];
				fbq_group_reverse_w = fbq_head_reverse_w[1];
			end
			2'd2: begin
				fbq_group_count_w = fbq_head_count_w[2];
				fbq_group_remaining_w = fbq_head_remaining_w[2];
				fbq_group_words_w = fbq_head_words_w[2];
				fbq_group_reverse_w = fbq_head_reverse_w[2];
			end
			2'd3: begin
				fbq_group_count_w = fbq_head_count_w[3];
				fbq_group_remaining_w = fbq_head_remaining_w[3];
				fbq_group_words_w = fbq_head_words_w[3];
				fbq_group_reverse_w = fbq_head_reverse_w[3];
			end
			default: begin
				fbq_group_count_w = 3'd1;
				fbq_group_remaining_w = fbq_count_with_push_w - 3'd1;
				fbq_group_words_w = 64'h000000000000xxxx;
				fbq_group_reverse_w = 1'b0;
			end
		endcase
	end
	wire [2:0] fbq_popped_w = (fbq_pop_w ? fbq_group_count_w : 3'd0);
	wire fbq_backpressure_w = ((state == 5'd17) && do_write_w) && fbq_full_w;
	wire dma_done_ready_w = local_writes_drained_w && !wr_busy;
	wire blit_retire_w = ((state == 5'd27) && dma_done_ready_w) && fsm_step_w;
	assign dbg_exec_done = blit_retire_w;
	wire normal_pop_w = ((blit_retire_w && !trig_w) && !restart_pending_r) && (normal_q_count != 0);
	wire final_done_w = ((blit_retire_w && !trig_w) && !restart_pending_r) && (normal_q_count == 0);
	wire normal_push_eligible_w = ((((trig_w && busy_r) && !kill_pending_r) && !paused_r) && !walker_halted_r) && !halt_pending_r;
	wire normal_push_w = normal_push_eligible_w && (normal_q_count < NORMAL_Q_DEPTH);
	wire normal_overflow_w = normal_push_eligible_w && (normal_q_count == NORMAL_Q_DEPTH);
	wire [31:0] iy_u = $unsigned(iy);
	wire [31:0] ty_w = ((iy_u + {16'd0, ystep_c}) >> 8) - (iy_u >> 8);
	wire signed [31:0] w2_ns = $signed(width32) - ((pre_r + post_r) >>> 8);
	wire [31:0] pre2_w = {28'd0, skipval_r[3:0]} << preskip_c;
	wire [31:0] post2_w = {28'd0, skipval_r[7:4]} << postskip_c;
	wire signed [31:0] w3_ns = ($signed(width32) - $signed(pre2_w)) - $signed(post2_w);
	always @(*) begin
		if (_sv2v_0)
			;
		state_n = state;
		case (state)
			5'd0:
				if (trig_w)
					state_n = 5'd1;
			5'd1: state_n = 5'd2;
			5'd2:
				if (skipdma_w || draw_none_w)
					state_n = 5'd27;
				else
					state_n = 5'd3;
			5'd3:
				if (iy < height_fp) begin
					if (skip_c)
						state_n = 5'd4;
					else
						state_n = 5'd9;
				end
				else
					state_n = 5'd27;
			5'd4:
				if (src_ack)
					state_n = 5'd5;
			5'd5:
				if (src_ack)
					state_n = 5'd6;
			5'd6:
				if (xstep_unity_w)
					state_n = 5'd8;
				else if (!div_busy)
					state_n = 5'd7;
			5'd7: state_n = 5'd8;
			5'd8: state_n = 5'd9;
			5'd9:
				if (y_clip_w)
					state_n = 5'd18;
				else if (ix < ss_fp)
					state_n = 5'd10;
				else
					state_n = 5'd14;
			5'd10:
				if (xstep_unity_w)
					state_n = 5'd12;
				else if (!div_busy)
					state_n = 5'd11;
			5'd11: state_n = 5'd12;
			5'd12: state_n = 5'd13;
			5'd13: state_n = 5'd14;
			5'd14:
				if (!pix_remain)
					state_n = 5'd18;
				else if (!in_clip)
					state_n = 5'd14;
				else if ((need_px_c && need_f0) && src_ack) begin
					if (need_f1)
						state_n = 5'd16;
					else
						state_n = 5'd17;
				end
				else if ((need_px_c && need_f1) && src_ack)
					state_n = 5'd17;
				else if (need_px_c && need_f0)
					state_n = 5'd15;
				else if (need_px_c && need_f1)
					state_n = 5'd16;
				else
					state_n = 5'd17;
			5'd15:
				if (src_ack) begin
					if (need_f1)
						state_n = 5'd16;
					else
						state_n = 5'd17;
				end
			5'd16:
				if (src_ack)
					state_n = 5'd17;
			5'd17:
				if (do_write_w && fbq_full_w)
					state_n = 5'd17;
				else
					state_n = 5'd14;
			5'd18: state_n = 5'd19;
			5'd19: state_n = 5'd20;
			5'd20:
				if ((scale_c && skip_c) && (tyr_r != 9'd0))
					state_n = 5'd21;
				else
					state_n = 5'd3;
			5'd21:
				if (sa_cnt == 32'd0)
					state_n = 5'd3;
				else
					state_n = 5'd22;
			5'd22:
				if (src_ack)
					state_n = 5'd23;
			5'd23:
				if (src_ack)
					state_n = 5'd24;
			5'd24: state_n = 5'd25;
			5'd25: state_n = 5'd26;
			5'd26: state_n = 5'd21;
			5'd27:
				if (!dma_done_ready_w)
					state_n = 5'd27;
				else if (trig_w)
					state_n = 5'd27;
				else if ((trig_w || restart_pending_r) || (normal_q_count != 0))
					state_n = 5'd1;
				else
					state_n = 5'd0;
			default: state_n = 5'd0;
		endcase
	end
	assign src_req = (!paused_r && !walker_halted_r) && (((((((fast_src_prefetch_w || (((fast_src_carry_r || src_early_valid_r) && (state == 5'd14)) && pix_src_demand_w)) || (state == 5'd4)) || (state == 5'd5)) || (state == 5'd15)) || (state == 5'd16)) || (state == 5'd22)) || (state == 5'd23));
	assign src_addr = (fast_src_prefetch_w ? fast_src_prefetch_addr_w : (fast_src_carry_r ? fast_src_prefetch_addr_w : src_state_addr_r));
	assign src_active = (busy_r && need_px_c) && !scale_c;
	assign src_stream = src_active && (bpp_c == 4'd8);
	wire sw_final_done_w = final_done_w && !(TIMED_IRQ_PUMP && cadence_valid_r);
	wire done_clear_w = sw_final_done_w || cadence_complete_w;
	wire [4:0] done_idx_w = wolf_pkg_DMA_COMMAND;
	wire [15:0] done_val_w = {1'b0, cmd_lo15};
	always @(posedge clk)
		if (rst) begin
			fbq_wptr_r <= 2'd0;
			fbq_rptr_r <= 2'd0;
			fbq_count_r <= 3'd0;
			fb_writer_active_r <= 1'b0;
			fb_we <= 1'b0;
			fb_addr <= 1'sb0;
			fb_wdata <= 16'd0;
			fb_count <= 3'd1;
			fb_words <= 64'd0;
			fb_reverse <= 1'b0;
		end
		else begin
			if (fb_writer_active_r) begin
				if (fb_ack) begin
					fb_writer_active_r <= 1'b0;
					fb_we <= 1'b0;
				end
			end
			else begin
				fb_we <= 1'b0;
				if (fbq_pop_w) begin
					fb_writer_active_r <= 1'b1;
					fb_we <= 1'b1;
					fb_addr <= fbq_addr[fbq_rptr_r];
					fb_wdata <= fbq_data[fbq_rptr_r];
					fb_count <= fbq_group_count_w;
					fb_words <= fbq_group_words_w;
					fb_reverse <= fbq_group_reverse_w;
				end
			end
			if (fbq_discard_w) begin
				fbq_rptr_r <= fbq_wptr_r;
				fbq_count_r <= 3'd0;
			end
			else begin
				if (fbq_push_w) begin
					fbq_addr[fbq_wptr_r] <= fb_addr_w;
					fbq_data[fbq_wptr_r] <= pix_data_w;
					fbq_wptr_r <= fbq_wptr_r + 2'd1;
				end
				if (fbq_pop_w)
					fbq_rptr_r <= fbq_rptr_r + fbq_popped_w[1:0];
				fbq_count_r <= (fbq_pop_w ? fbq_group_remaining_w : fbq_count_with_push_w);
			end
		end
	wire div_den_load_w = ((div_go && !paused_r) && !walker_halted_r) && (resume_w || !(halt_request_w || kill_request_w));
	always @(posedge clk)
		if (rst)
			dden <= 32'd0;
		else if (kill_enter_w)
			dden <= 32'd0;
		else if (div_den_load_w)
			dden <= div_den;
	always @(posedge clk)
		if (rst) begin
			state_q1 <= 5'd0;
			drun <= 1'b0;
			dcnt <= 6'd0;
			dnum <= 32'd0;
			drem <= 32'd0;
			dquo <= 32'd0;
		end
		else if (kill_enter_w) begin
			state_q1 <= 5'd0;
			drun <= 1'b0;
			dcnt <= 6'd0;
			dnum <= 32'd0;
			drem <= 32'd0;
			dquo <= 32'd0;
		end
		else if (((!paused_r && !walker_halted_r) && !stop_boundary_enter_w) && !pause_enter_w) begin
			state_q1 <= state;
			if (fast_skdiv_w) begin
				drun <= 1'b0;
				dcnt <= 6'd0;
				dquo <= pre_fp_w >> 8;
			end
			else if (fast_rpdiv_w) begin
				drun <= 1'b0;
				dcnt <= 6'd0;
				dquo <= ss_diff_w >> 8;
			end
			else if (div_go) begin
				drun <= 1'b1;
				dcnt <= 6'd32;
				dnum <= div_num;
				drem <= 32'd0;
				dquo <= 32'd0;
			end
			else if (drun) begin
				if ({drem[30:0], dnum[31]} >= dden) begin
					drem <= {drem[30:0], dnum[31]} - dden;
					dquo <= {dquo[30:0], 1'b1};
				end
				else begin
					drem <= {drem[30:0], dnum[31]};
					dquo <= {dquo[30:0], 1'b0};
				end
				dnum <= {dnum[30:0], 1'b0};
				dcnt <= dcnt - 6'd1;
				if (dcnt == 6'd1)
					drun <= 1'b0;
			end
		end
	integer i;
	always @(posedge clk)
		if (rst) begin
			state <= 5'd0;
			blit_irq <= 1'b0;
			busy_r <= 1'b0;
			cadence_valid_r <= 1'b0;
			cadence_x_reload_r <= 18'd0;
			cadence_x_rem_r <= 18'd0;
			cadence_y_rem_r <= 18'd0;
			cadence_xstep_r <= 16'h0100;
			cadence_ystep_r <= 16'h0100;
			cadence_phase_r <= 7'd0;
			timeout_stop_armed_r <= 1'b0;
			timeout_stop_age_r <= 6'd0;
			halt_pending_r <= 1'b0;
			walker_halted_r <= 1'b0;
			paused_r <= 1'b0;
			kill_pending_r <= 1'b0;
			restart_pending_r <= 1'b0;
			setup_from_restart_r <= 1'b0;
			normal_q_wptr <= 1'sb0;
			normal_q_rptr <= 1'sb0;
			normal_q_count <= 1'sb0;
			normal_q_overflow_r <= 1'b0;
			normal_q_highwater_r <= 1'sb0;
			normal_launch_word <= 1'sb0;
			setup_from_normal_q_r <= 1'b0;
			for (i = 0; i < wolf_pkg_DMA_NREGS; i = i + 1)
				begin
					regf[i] <= 16'h0000;
					restart_regf[i] <= 16'h0000;
				end
			bpp_c <= 4'd0;
			zero_c <= OP_SKIP;
			nz_c <= OP_SKIP;
			need_px_c <= 1'b0;
			xflip_c <= 1'b0;
			yflip_c <= 1'b0;
			skip_c <= 1'b0;
			scale_c <= 1'b0;
			preskip_c <= 2'd0;
			postskip_c <= 2'd0;
			xstep_c <= 16'h0100;
			ystep_c <= 16'h0100;
			width_c <= 10'd0;
			height_c <= 10'd0;
			xpos_c <= 10'd0;
			pal16_c <= 16'd0;
			color16_c <= 16'd0;
			topclip_c <= 9'd0;
			botclip_c <= 9'd0;
			leftclip_c <= 10'd0;
			rightclip_c <= 10'd0;
			startskip_c <= 32'sd0;
			endskip_c <= 32'sd0;
			offset_r <= 32'd0;
			o_r <= 32'd0;
			ix <= 32'sd0;
			iy <= 32'sd0;
			width_fp <= 32'sd0;
			clip_gap <= 1'b1;
			sx <= 10'd0;
			sy <= 9'd0;
			pre_r <= 32'sd0;
			post_r <= 32'sd0;
			b0_r <= 8'd0;
			b1_r <= 8'd0;
			skipval_r <= 8'd0;
			px_r <= 8'd0;
			fast_src_prefetch_addr_r <= 32'd0;
			fast_src_prefetch_ready_r <= 1'b0;
			fast_src_carry_r <= 1'b0;
			src_state_addr_r <= 32'd0;
			src_early_valid_r <= 1'b0;
			scale_advance_r <= 13'd0;
			bc_a0 <= 32'hffffffff;
			bc_a1 <= 32'hffffffff;
			bc_d0 <= 8'd0;
			bc_d1 <= 8'd0;
			bc_v0 <= 1'b0;
			bc_v1 <= 1'b0;
			sa_cnt <= 32'd0;
			txm_r <= 32'd0;
			rowbits_r <= 14'd0;
			tyr_r <= 9'd0;
			w2p_r <= 11'd0;
			w3p_r <= 11'd0;
			radv_r <= 32'd0;
			w2adv_r <= 32'd0;
			w3adv_r <= 32'd0;
		end
		else begin
			state <= state_n;
			if (trig_w || !busy_r) begin
				timeout_stop_armed_r <= 1'b0;
				timeout_stop_age_r <= 6'd0;
			end
			else if (timeout_pair_resume_w) begin
				timeout_stop_armed_r <= 1'b0;
				timeout_stop_age_r <= 6'd0;
			end
			else if (stop_w_raw && timeout_stop_context_w) begin
				timeout_stop_armed_r <= 1'b1;
				timeout_stop_age_r <= 6'd63;
			end
			else if (timeout_stop_armed_r) begin
				if (timeout_stop_age_r == 6'd0)
					timeout_stop_armed_r <= 1'b0;
				else
					timeout_stop_age_r <= timeout_stop_age_r - 6'd1;
			end
			if (TIMED_IRQ_PUMP && cadence_valid_r) begin
				if (cadence_pixel_tick_w) begin
					cadence_phase_r <= cadence_phase_next_w - 8'd105;
					if (cadence_x_rem_r <= {2'b00, cadence_xstep_r}) begin
						if (cadence_y_rem_r <= {2'b00, cadence_ystep_r}) begin
							cadence_valid_r <= 1'b0;
							cadence_x_rem_r <= 18'd0;
							cadence_y_rem_r <= 18'd0;
							blit_irq <= 1'b1;
						end
						else begin
							cadence_x_rem_r <= cadence_x_reload_r;
							cadence_y_rem_r <= cadence_y_rem_r - {2'b00, cadence_ystep_r};
						end
					end
					else
						cadence_x_rem_r <= cadence_x_rem_r - {2'b00, cadence_xstep_r};
				end
				else
					cadence_phase_r <= cadence_phase_next_w[6:0];
			end
			if (paused_r || walker_halted_r)
				state <= state;
			if (stop_boundary_enter_w)
				state <= (stop_source_advance_w ? state_n : state);
			if (kill_enter_w)
				state <= (restart_pending_r ? 5'd1 : 5'd0);
			if (kill_enter_w)
				fast_src_carry_r <= 1'b0;
			if (kill_enter_w)
				src_early_valid_r <= 1'b0;
			if (fsm_step_w) begin
				if (((state == 5'd14) && scale_c) && pix_remain)
					scale_advance_r <= scale_advance_w;
				if (prefetch_wr_enter_w) begin
					fast_src_prefetch_addr_r <= prefetch_next_addr_w;
					fast_src_prefetch_ready_r <= (((need_px_c && !scale_c) && (bpp_c == 4'd8)) && (ix_next_unity_w < width_fp)) && next_unity_in_clip_w;
				end
				else if (prefetch_wr_leave_w)
					fast_src_prefetch_ready_r <= 1'b0;
				if (prefetch_wr_leave_w && fast_src_prefetch_w)
					fast_src_carry_r <= 1'b1;
				if (fast_src_carry_r && src_ack)
					fast_src_carry_r <= 1'b0;
				if (state_n == 5'd9) begin
					fast_src_carry_r <= 1'b0;
					fast_src_prefetch_ready_r <= 1'b0;
				end
				if ((state == 5'd9) && (state_n == 5'd14))
					src_early_valid_r <= 1'b1;
				else if ((state == 5'd17) && (state_n == 5'd14))
					src_early_valid_r <= 1'b1;
				else if ((((state == 5'd14) && pix_remain) && !in_clip) && !clip_gap)
					src_early_valid_r <= 1'b1;
				else if ((state == 5'd12) || ((state_n == 5'd17) && (state != 5'd17)))
					src_early_valid_r <= 1'b0;
				case (state)
					5'd3:
						if ((iy < height_fp) && skip_c)
							src_state_addr_r <= {3'b000, offset_r[31:3]};
					5'd9:
						if (!y_clip_w && !(ix < ss_fp))
							src_state_addr_r <= cur_req_addr_w;
					5'd17:
						if (prefetch_wr_leave_w)
							src_state_addr_r <= (scale_c ? sc_next_req_addr_w : ns_next_req_addr_w);
					5'd14:
						if ((pix_remain && !in_clip) && !clip_gap)
							src_state_addr_r <= (scale_c ? sc_next_req_addr_w : ns_next_req_addr_w);
						else if (((pix_remain && in_clip) && need_px_c) && !fast_src_carry_r) begin
							if (need_f0 && !src_ack)
								src_state_addr_r <= o_byte0;
							else if (need_f1 && ((need_f0 && src_ack) || (!need_f0 && !src_ack)))
								src_state_addr_r <= o_byte1;
						end
					5'd4:
						if (src_ack)
							src_state_addr_r <= o_byte1;
					5'd15:
						if (src_ack && need_f1)
							src_state_addr_r <= o_byte1;
					5'd21:
						if (sa_cnt != 32'd0)
							src_state_addr_r <= o_byte0;
					5'd22:
						if (src_ack)
							src_state_addr_r <= o_byte1;
					default:
						;
				endcase
				case (state)
					5'd2: begin
						bpp_c <= bpp_w;
						zero_c <= zero_w;
						nz_c <= nz_w;
						need_px_c <= need_px_w;
						xflip_c <= xflip_w;
						yflip_c <= yflip_w;
						skip_c <= skip_w;
						scale_c <= scale_w;
						preskip_c <= preskip_w;
						postskip_c <= postskip_w;
						xstep_c <= xstep_w;
						ystep_c <= ystep_w;
						width_c <= w_width10;
						rowbits_r <= w_width10 * bpp_w;
						height_c <= w_height10;
						xpos_c <= w_xpos10;
						pal16_c <= s_pal & 16'h7f00;
						color16_c <= (s_pal & 16'h7f00) | {8'd0, w_color8};
						topclip_c <= w_top9;
						botclip_c <= w_bot9;
						leftclip_c <= w_left10;
						rightclip_c <= w_right10;
						startskip_c <= $signed(startskip_w);
						endskip_c <= $signed(endskip_w);
						offset_r <= gfxoff2;
						sy <= w_ypos9;
						iy <= 32'sd0;
						pre_r <= 32'sd0;
						post_r <= 32'sd0;
						clip_gap <= 1'b1;
					end
					5'd3:
						if (iy < height_fp) begin
							width_fp <= $signed(width32) <<< 8;
							sx <= xpos_c;
							ix <= 32'sd0;
							o_r <= offset_r;
						end
					5'd4:
						if (src_ack)
							b0_r <= src_data;
					5'd5:
						if (src_ack)
							skipval_r <= byte_now;
					5'd6:
						if (xstep_unity_w)
							txm_r <= pre_fp_w;
					5'd7: txm_r <= dquo[18:0] * xstep_c;
					5'd8: begin
						pre_r <= $signed(pre_fp_w);
						post_r <= $signed(post_fp_w);
						sx <= (xflip_c ? sx - tx_skip10 : sx + tx_skip10);
						ix <= ix + $signed(txm_r);
						width_fp <= width_fp - $signed(post_fp_w);
						o_r <= o_r + 32'd8;
					end
					5'd9:
						if (!y_clip_w) begin
							if ((width_fp >>> 8) > we_lim)
								width_fp <= we_lim <<< 8;
						end
					5'd10:
						if (xstep_unity_w)
							txm_r <= ss_diff_w;
					5'd11: txm_r <= dquo[18:0] * xstep_c;
					5'd12: begin
						ix <= ix + $signed(txm_r);
						o_r <= o_r + ((txm_r >> 8) * bpp32);
						clip_gap <= 1'b1;
					end
					5'd14: begin
						if ((pix_remain && in_clip) && need_px_c) begin
							if (hit0)
								b0_r <= hitd0;
							if (px_straddle && hit1)
								b1_r <= hitd1;
							if (!need_f0 && !need_f1)
								px_r <= px_cache;
							if (src_ack && (need_f0 || need_f1)) begin
								if (need_f0) begin
									b0_r <= src_data;
									if (!need_f1)
										px_r <= ({b1_r, src_data} >> o_lo3) & {8'd0, pixmask};
								end
								else begin
									b1_r <= src_data;
									px_r <= ({src_data, hitd0} >> o_lo3) & {8'd0, pixmask};
								end
							end
						end
						if (pix_remain && !in_clip) begin
							if (clip_gap)
								clip_gap <= 1'b0;
							else begin
								sx <= (xflip_c ? sx - 10'd1 : sx + 10'd1);
								clip_gap <= 1'b1;
								if (!scale_c) begin
									ix <= ix + 32'sd256;
									o_r <= o_r + bpp32;
								end
								else begin
									ix <= ix + xstep_s;
									o_r <= o_r + {19'd0, scale_advance_r};
								end
							end
						end
					end
					5'd15:
						if (src_ack) begin
							b0_r <= src_data;
							if (!need_f1)
								px_r <= ({b1_r, src_data} >> o_lo3) & {8'd0, pixmask};
						end
					5'd16:
						if (src_ack)
							px_r <= px_now;
					5'd17:
						if (!do_write_w || !fbq_full_w) begin
							sx <= (xflip_c ? sx - 10'd1 : sx + 10'd1);
							clip_gap <= 1'b1;
							if (!scale_c) begin
								ix <= ix + 32'sd256;
								o_r <= o_r + bpp32;
							end
							else begin
								ix <= ix + xstep_s;
								o_r <= o_r + {19'd0, scale_advance_r};
							end
						end
					5'd18: begin
						tyr_r <= ty_w[8:0];
						w2p_r <= (w2_ns > 32'sd0 ? w2_ns[10:0] : 11'd0);
					end
					5'd19: begin
						radv_r <= tyr_r * rowbits_r;
						w2adv_r <= w2p_r * bpp_c;
					end
					5'd20: begin
						sy <= (yflip_c ? sy - 9'd1 : sy + 9'd1);
						if (!scale_c) begin
							iy <= iy + 32'sd256;
							if (skip_c)
								offset_r <= (offset_r + 32'd8) + w2adv_r;
							else
								offset_r <= offset_r + {18'd0, rowbits_r};
						end
						else begin
							iy <= iy + $signed({16'd0, ystep_c});
							if (!skip_c)
								offset_r <= offset_r + radv_r;
							else if (tyr_r != 9'd0) begin
								o_r <= (offset_r + 32'd8) + w2adv_r;
								sa_cnt <= {23'd0, tyr_r} - 32'd1;
							end
						end
					end
					5'd21:
						if (sa_cnt == 32'd0)
							offset_r <= o_r;
					5'd22:
						if (src_ack)
							b0_r <= src_data;
					5'd23:
						if (src_ack)
							skipval_r <= byte_now;
					5'd24: w3p_r <= (w3_ns > 32'sd0 ? w3_ns[10:0] : 11'd0);
					5'd25: w3adv_r <= w3p_r * bpp_c;
					5'd26: begin
						o_r <= (o_r + 32'd8) + w3adv_r;
						sa_cnt <= sa_cnt - 32'd1;
					end
					5'd27:
						if (final_done_w) begin
							busy_r <= 1'b0;
							if (sw_final_done_w) begin
								blit_irq <= 1'b1;
								cadence_valid_r <= 1'b0;
								cadence_x_reload_r <= 18'd0;
								cadence_x_rem_r <= 18'd0;
								cadence_y_rem_r <= 18'd0;
								cadence_phase_r <= 7'd0;
							end
						end
					default:
						;
				endcase
			end
			if (src_req && src_ack) begin
				if (bc_v0 && (bc_a0 == src_addr))
					bc_d0 <= src_data;
				else begin
					bc_a1 <= bc_a0;
					bc_d1 <= bc_d0;
					bc_v1 <= bc_v0;
					bc_a0 <= src_addr;
					bc_d0 <= src_data;
					bc_v0 <= 1'b1;
				end
			end
			if (done_clear_w)
				regf[done_idx_w] <= done_val_w;
			if (reg_we)
				regf[regnum_w] <= reg_wdata;
			if (command_w && cadence_immediate_w)
				regf[wolf_pkg_DMA_COMMAND] <= {1'b0, reg_wdata[14:0]};
			if ((trig_w && kill_pending_r) && !restart_pending_r) begin
				for (i = 0; i < wolf_pkg_DMA_NREGS; i = i + 1)
					restart_regf[i] <= regf[i];
				restart_regf[wolf_pkg_DMA_COMMAND] <= reg_wdata;
				restart_pending_r <= 1'b1;
			end
			if (normal_push_w) begin
				normal_q_mem[normal_q_wptr] <= normal_q_push_word;
				normal_q_wptr <= (normal_q_wptr_last ? {NORMAL_Q_PTR_W {1'sb0}} : normal_q_wptr + 1'b1);
				normal_q_count <= normal_q_count + 1'b1;
				if ((normal_q_count + 1'b1) > normal_q_highwater_r)
					normal_q_highwater_r <= normal_q_count + 1'b1;
			end
			if (normal_overflow_w)
				normal_q_overflow_r <= 1'b1;
			if (command_w) begin
				blit_irq <= 1'b0;
				if (TIMED_IRQ_PUMP) begin
					cadence_valid_r <= cadence_start_w;
					cadence_x_reload_r <= (cadence_start_w ? cadence_x_init_w : 18'd0);
					cadence_x_rem_r <= (cadence_start_w ? cadence_x_init_w : 18'd0);
					cadence_y_rem_r <= (cadence_start_w ? cadence_y_init_w : 18'd0);
					cadence_xstep_r <= cadence_xstep_w;
					cadence_ystep_r <= cadence_ystep_w;
					cadence_phase_r <= 7'd0;
					if (cadence_immediate_w)
						blit_irq <= 1'b1;
				end
				if (state == 5'd0)
					busy_r <= wdata_trig;
				else if ((((((state == 5'd27) && trig_w) && !paused_r) && !halt_pending_r) && !walker_halted_r) && !kill_pending_r)
					busy_r <= 1'b1;
			end
			if (normal_pop_w) begin
				normal_launch_word <= normal_q_mem[normal_q_rptr];
				normal_q_rptr <= (normal_q_rptr_last ? {NORMAL_Q_PTR_W {1'sb0}} : normal_q_rptr + 1'b1);
				normal_q_count <= normal_q_count - 1'b1;
				setup_from_normal_q_r <= 1'b1;
				busy_r <= 1'b1;
				blit_irq <= 1'b0;
			end
			if (resume_w && !kill_pending_r) begin
				halt_pending_r <= 1'b0;
				walker_halted_r <= 1'b0;
				paused_r <= 1'b0;
				kill_pending_r <= 1'b0;
			end
			else if (kill_enter_w) begin
				halt_pending_r <= 1'b0;
				walker_halted_r <= 1'b0;
				paused_r <= 1'b0;
				kill_pending_r <= 1'b0;
				restart_pending_r <= 1'b0;
				setup_from_restart_r <= restart_pending_r;
				normal_q_wptr <= 1'sb0;
				normal_q_rptr <= 1'sb0;
				normal_q_count <= 1'sb0;
				setup_from_normal_q_r <= 1'b0;
				busy_r <= restart_pending_r;
				blit_irq <= 1'b0;
			end
			else if (pause_enter_w) begin
				halt_pending_r <= 1'b0;
				walker_halted_r <= 1'b0;
				paused_r <= 1'b1;
				kill_pending_r <= 1'b0;
			end
			else begin
				if (first_stop_w)
					halt_pending_r <= 1'b1;
				if (second_stop_w)
					kill_pending_r <= 1'b1;
				if (stop_boundary_enter_w)
					walker_halted_r <= 1'b1;
				if (!busy_r && (state == 5'd0)) begin
					halt_pending_r <= 1'b0;
					walker_halted_r <= 1'b0;
					paused_r <= 1'b0;
					kill_pending_r <= 1'b0;
					restart_pending_r <= 1'b0;
					setup_from_restart_r <= 1'b0;
					normal_q_wptr <= 1'sb0;
					normal_q_rptr <= 1'sb0;
					normal_q_count <= 1'sb0;
					setup_from_normal_q_r <= 1'b0;
				end
			end
			if (fsm_step_w && (state == 5'd2))
				setup_from_restart_r <= 1'b0;
			if (fsm_step_w && (state == 5'd2))
				setup_from_normal_q_r <= 1'b0;
		end
	initial if ((FB_GROUP_MAX < 1) || (FB_GROUP_MAX > 4)) begin
		$display("Fatal [%0t] D:\deck\fpga\revolutionx\Arcade-RevX_MiSTer\build_syn\runs\production_20260914T031045Z_b5e0266d\rtl\wolf\wolf_dma.sv:1672:49 - wolf_dma.<unnamed_block>\n msg: ", $time, "wolf_dma FB_GROUP_MAX must be 1..4");
		$finish(1);
	end
	wire sim_scaled_advance_consume_w = ((fsm_step_w && scale_c) && pix_remain) && ((((state == 5'd14) && !in_clip) && !clip_gap) || ((state == 5'd17) && (!do_write_w || !fbq_full_w)));
	always @(posedge clk)
		if ((!rst && sim_scaled_advance_consume_w) && (scale_advance_r !== scale_advance_w)) begin
			$display("Fatal [%0t] D:\deck\fpga\revolutionx\Arcade-RevX_MiSTer\build_syn\runs\production_20260914T031045Z_b5e0266d\rtl\wolf\wolf_dma.sv:1684:7 - wolf_dma.<unnamed_block>.<unnamed_block>\n msg: ", $time, "wolf_dma: scaled advance consumed without matching S_PIX capture");
			$finish(1);
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module wolf_pic (
	clk,
	rst,
	cmd_we,
	cmd_data,
	resp_re,
	reset_w,
	reset_val,
	resp_data,
	status
);
	parameter [127:0] RESPONSE_BYTES = 128'h2b1e4a0e02176c60b4082509db019af6;
	input wire clk;
	input wire rst;
	input wire cmd_we;
	input wire [7:0] cmd_data;
	input wire resp_re;
	input wire reset_w;
	input wire reset_val;
	output wire [7:0] resp_data;
	output wire status;
	function automatic [7:0] pic_byte;
		input reg [3:0] a;
		case (a)
			4'h0: pic_byte = RESPONSE_BYTES[7:0];
			4'h1: pic_byte = RESPONSE_BYTES[15:8];
			4'h2: pic_byte = RESPONSE_BYTES[23:16];
			4'h3: pic_byte = RESPONSE_BYTES[31:24];
			4'h4: pic_byte = RESPONSE_BYTES[39:32];
			4'h5: pic_byte = RESPONSE_BYTES[47:40];
			4'h6: pic_byte = RESPONSE_BYTES[55:48];
			4'h7: pic_byte = RESPONSE_BYTES[63:56];
			4'h8: pic_byte = RESPONSE_BYTES[71:64];
			4'h9: pic_byte = RESPONSE_BYTES[79:72];
			4'ha: pic_byte = RESPONSE_BYTES[87:80];
			4'hb: pic_byte = RESPONSE_BYTES[95:88];
			4'hc: pic_byte = RESPONSE_BYTES[103:96];
			4'hd: pic_byte = RESPONSE_BYTES[111:104];
			4'he: pic_byte = RESPONSE_BYTES[119:112];
			default: pic_byte = RESPONSE_BYTES[127:120];
		endcase
	endfunction
	reg [7:0] buff;
	reg [3:0] idx;
	reg stat;
	always @(posedge clk)
		if (rst) begin
			idx <= 4'd0;
			stat <= 1'b0;
			buff <= 8'd0;
		end
		else if (reset_w && reset_val) begin
			idx <= 4'd0;
			stat <= 1'b0;
			buff <= 8'd0;
		end
		else begin
			if (cmd_we) begin
				stat <= cmd_data[4];
				if (!cmd_data[4]) begin
					if (cmd_data[3:0] != 4'd0)
						buff <= {4'h0, cmd_data[3:0]};
					else begin
						buff <= pic_byte(idx);
						idx <= idx + 4'd1;
					end
				end
			end
			if (resp_re)
				stat <= 1'b1;
		end
	assign resp_data = buff;
	assign status = stat;
endmodule
`default_nettype wire
`default_nettype none
module revx_derail_capture (
	clk,
	rst,
	cpu_retire,
	cpu_pc,
	cpu_instr,
	int_entry,
	int_pc,
	int_vec_addr,
	int_vec_value,
	culprit_pc,
	culprit_instr,
	target_pc,
	last_good_pc,
	derail_captured,
	int_interrupted_pc,
	int_vec_addr_q,
	int_vec_value_q,
	int_count,
	int_captured
);
	parameter [31:0] ROM_LO = 32'hff000000;
	parameter [31:0] ROM_HI = 32'hffffffff;
	parameter [31:0] RAM_LO = 32'h20000000;
	parameter [31:0] RAM_HI = 32'h20ffffff;
	parameter [31:0] DERAIL_LO = 32'hffffe000;
	parameter [31:0] DERAIL_HI = 32'hfffffbff;
	input wire clk;
	input wire rst;
	input wire cpu_retire;
	input wire [31:0] cpu_pc;
	input wire [15:0] cpu_instr;
	input wire int_entry;
	input wire [31:0] int_pc;
	input wire [31:0] int_vec_addr;
	input wire [31:0] int_vec_value;
	output reg [31:0] culprit_pc;
	output reg [15:0] culprit_instr;
	output reg [31:0] target_pc;
	output reg [31:0] last_good_pc;
	output reg derail_captured;
	output reg [31:0] int_interrupted_pc;
	output reg [31:0] int_vec_addr_q;
	output reg [31:0] int_vec_value_q;
	output reg [7:0] int_count;
	output reg int_captured;
	wire in_rom = (cpu_pc >= ROM_LO) && (cpu_pc <= ROM_HI);
	wire in_ram = (cpu_pc >= RAM_LO) && (cpu_pc <= RAM_HI);
	wire in_derail = (cpu_pc >= DERAIL_LO) && (cpu_pc <= DERAIL_HI);
	wire bad_pc = in_derail || !(in_rom || in_ram);
	reg [31:0] prev_pc;
	reg [15:0] prev_instr;
	always @(posedge clk)
		if (rst) begin
			prev_pc <= 32'd0;
			prev_instr <= 16'd0;
			culprit_pc <= 32'd0;
			culprit_instr <= 16'd0;
			target_pc <= 32'd0;
			last_good_pc <= 32'd0;
			derail_captured <= 1'b0;
		end
		else if (cpu_retire) begin
			if (bad_pc && !derail_captured) begin
				derail_captured <= 1'b1;
				culprit_pc <= prev_pc;
				culprit_instr <= prev_instr;
				target_pc <= cpu_pc;
			end
			if (!bad_pc)
				last_good_pc <= cpu_pc;
			prev_pc <= cpu_pc;
			prev_instr <= cpu_instr;
		end
	always @(posedge clk)
		if (rst) begin
			int_interrupted_pc <= 32'd0;
			int_vec_addr_q <= 32'd0;
			int_vec_value_q <= 32'd0;
			int_count <= 8'd0;
			int_captured <= 1'b0;
		end
		else if (int_entry) begin
			if (!int_captured) begin
				int_captured <= 1'b1;
				int_interrupted_pc <= int_pc;
				int_vec_addr_q <= int_vec_addr;
				int_vec_value_q <= int_vec_value;
			end
			if (int_count != 8'hff)
				int_count <= int_count + 8'd1;
		end
endmodule
module revx_timer_capture (
	clk,
	rst,
	cpu_retire,
	cpu_pc,
	bus_req,
	bus_we,
	bus_ack,
	bus_addr,
	bus_wdata,
	bus_be,
	foreground_pc,
	timers,
	process_ptr,
	watch_status
);
	input wire clk;
	input wire rst;
	input wire cpu_retire;
	input wire [31:0] cpu_pc;
	input wire bus_req;
	input wire bus_we;
	input wire bus_ack;
	input wire [31:0] bus_addr;
	input wire [31:0] bus_wdata;
	input wire [3:0] bus_be;
	output reg [31:0] foreground_pc;
	output wire [31:0] timers;
	output reg [31:0] process_ptr;
	output wire [31:0] watch_status;
	reg write_q;
	reg accept_q;
	reg frozen;
	reg [31:0] addr_q;
	reg [31:0] data_q;
	reg [31:0] pc_q;
	reg [3:0] be_q;
	reg [15:0] timer_q;
	reg [15:0] last_timer_q;
	reg [15:0] drain_count;
	reg [11:0] seen;
	assign timers = {last_timer_q, timer_q};
	assign watch_status = {drain_count, 3'd0, frozen, seen};
	always @(posedge clk)
		if (rst) begin
			write_q <= 0;
			accept_q <= 0;
			frozen <= 0;
			addr_q <= 0;
			data_q <= 0;
			pc_q <= 0;
			be_q <= 0;
			foreground_pc <= 0;
			process_ptr <= 0;
			timer_q <= 0;
			last_timer_q <= 0;
			drain_count <= 0;
			seen <= 0;
		end
		else begin
			write_q <= (bus_req && bus_we) && bus_ack;
			addr_q <= bus_addr;
			data_q <= bus_wdata;
			be_q <= bus_be;
			accept_q <= cpu_retire;
			pc_q <= cpu_pc;
			if (accept_q && ((pc_q == 32'h20813460) || (pc_q == 32'hff813460)))
				frozen <= 1;
			if (write_q && !frozen)
				case (addr_q)
					32'h203f5ae0: begin : sv2v_autoblock_1
						integer i;
						for (i = 0; i < 4; i = i + 1)
							if (be_q[i]) begin
								foreground_pc[i * 8+:8] <= data_q[i * 8+:8];
								seen[i] <= 1;
							end
					end
					32'h20517ce0: begin
						if (be_q[2]) begin
							timer_q[7:0] <= data_q[23:16];
							seen[4] <= 1;
						end
						if (be_q[3]) begin
							timer_q[15:8] <= data_q[31:24];
							seen[5] <= 1;
						end
						if (((((be_q[3:2] == 2'b11) && (data_q[31:16] == 0)) && (timer_q != 0)) && &seen[5:4]) && (drain_count != 16'hffff))
							drain_count <= drain_count + 16'd1;
					end
					32'h20517d00: begin
						if (be_q[0]) begin
							last_timer_q[7:0] <= data_q[7:0];
							seen[6] <= 1;
						end
						if (be_q[1]) begin
							last_timer_q[15:8] <= data_q[15:8];
							seen[7] <= 1;
						end
					end
					32'h20517c60: begin : sv2v_autoblock_2
						integer i;
						for (i = 0; i < 4; i = i + 1)
							if (be_q[i]) begin
								process_ptr[i * 8+:8] <= data_q[i * 8+:8];
								seen[8 + i] <= 1;
							end
					end
					default:
						;
				endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module revx_postcal_capture (
	clk,
	rst,
	cpu_accept,
	cpu_pc,
	irq_entry,
	irq_return,
	bus_req,
	bus_we,
	bus_ack,
	bus_fetch,
	bus_addr,
	bus_wdata,
	bus_rdata,
	bus_be,
	early_sample,
	final_sample
);
	input wire clk;
	input wire rst;
	input wire cpu_accept;
	input wire [31:0] cpu_pc;
	input wire irq_entry;
	input wire irq_return;
	input wire bus_req;
	input wire bus_we;
	input wire bus_ack;
	input wire bus_fetch;
	input wire [31:0] bus_addr;
	input wire [31:0] bus_wdata;
	input wire [31:0] bus_rdata;
	input wire [3:0] bus_be;
	output reg [287:0] early_sample;
	output reg [287:0] final_sample;
	reg accept_q;
	reg entry_q;
	reg return_q;
	reg write_q;
	reg read_q;
	reg wait_q;
	reg [31:0] pc_q;
	reg [31:0] op_pc;
	reg [31:0] bus_pc_q;
	reg [31:0] addr_q;
	reg [31:0] wdata_q;
	reg [31:0] rdata_q;
	reg [3:0] be_q;
	always @(posedge clk)
		if (rst) begin
			accept_q <= 0;
			entry_q <= 0;
			return_q <= 0;
			write_q <= 0;
			read_q <= 0;
			wait_q <= 0;
			pc_q <= 0;
			op_pc <= 0;
			bus_pc_q <= 0;
			addr_q <= 0;
			wdata_q <= 0;
			rdata_q <= 0;
			be_q <= 0;
		end
		else begin
			accept_q <= cpu_accept;
			pc_q <= cpu_pc;
			entry_q <= irq_entry;
			return_q <= irq_return;
			if (cpu_accept)
				op_pc <= cpu_pc;
			bus_pc_q <= (cpu_accept ? cpu_pc : op_pc);
			write_q <= (bus_req && bus_we) && bus_ack;
			read_q <= ((bus_req && !bus_we) && bus_ack) && !bus_fetch;
			wait_q <= bus_req && !bus_ack;
			addr_q <= bus_addr;
			wdata_q <= bus_wdata;
			rdata_q <= bus_rdata;
			be_q <= bus_be;
		end
	function automatic game_pc;
		input [31:0] pc;
		game_pc = (pc[31:24] == 8'h20) || (pc[31:24] == 8'hff);
	endfunction
	reg active;
	reg frozen;
	reg early_valid;
	reg [15:0] timer;
	reg [31:0] interrupted_pc;
	reg [3:0] ip_lanes;
	reg [3:0] irq_depth;
	reg irq_fault;
	reg overflow;
	reg timer_fault;
	reg clear_fault;
	reg insert_fault;
	reg [31:0] elapsed;
	reg [31:0] irq_clocks;
	reg [31:0] foreground_wait;
	reg [15:0] allocations;
	reg [15:0] insertions;
	reg [31:0] object_base;
	reg [31:0] clear_next;
	reg [31:0] link_addr;
	reg [31:0] link_data;
	reg object_valid;
	reg link_valid;
	reg clear_active;
	reg copyr_seen;
	reg text_returned;
	reg [5:0] clear_count;
	reg [3:0] insert_mask;
	reg [1:0] link_kind;
	wire timer_write = (write_q && (addr_q == 32'h20517ce0)) && |be_q[3:2];
	wire epoch_clear = (timer_write && (be_q[3:2] == 2'b11)) && (wdata_q[31:16] == 0);
	wire foreground = (irq_depth == 0) && !entry_q;
	wire accept_game = accept_q && game_pc(pc_q);
	wire bus_game = game_pc(bus_pc_q) && foreground;
	wire fatal = accept_game && (pc_q[23:0] == 24'h813460);
	wire [15:0] flags = {active, 2'b00, &ip_lanes, clear_fault, insert_fault, irq_fault, overflow, timer_fault, object_valid, link_valid, copyr_seen, text_returned, 1'b0, link_kind};
	wire [287:0] sample = {foreground_wait, irq_clocks, elapsed, link_data, link_addr, object_base, allocations, insertions, interrupted_pc, flags, timer};
	always @(posedge clk)
		if (rst) begin
			active <= 0;
			frozen <= 0;
			early_valid <= 0;
			early_sample <= 0;
			final_sample <= 0;
			timer <= 0;
			interrupted_pc <= 0;
			ip_lanes <= 0;
			irq_depth <= 0;
			irq_fault <= 0;
			elapsed <= 0;
			irq_clocks <= 0;
			foreground_wait <= 0;
			allocations <= 0;
			insertions <= 0;
			object_base <= 0;
			clear_next <= 0;
			link_addr <= 0;
			link_data <= 0;
			link_kind <= 0;
			object_valid <= 0;
			link_valid <= 0;
			clear_active <= 0;
			clear_count <= 0;
			insert_mask <= 0;
			copyr_seen <= 0;
			text_returned <= 0;
			overflow <= 0;
			timer_fault <= 0;
			clear_fault <= 0;
			insert_fault <= 0;
		end
		else if (!frozen) begin
			case ({entry_q, return_q})
				2'b10:
					if (irq_depth != 15)
						irq_depth <= irq_depth + 1'b1;
					else
						irq_fault <= 1;
				2'b01:
					if (irq_depth != 0)
						irq_depth <= irq_depth - 1'b1;
					else
						irq_fault <= 1;
				2'b11: irq_fault <= 1;
				default:
					;
			endcase
			if (epoch_clear) begin
				active <= 1;
				early_valid <= 0;
				early_sample <= 0;
				final_sample <= 0;
				timer <= 0;
				interrupted_pc <= 0;
				ip_lanes <= 0;
				elapsed <= 0;
				irq_clocks <= 0;
				foreground_wait <= 0;
				allocations <= 0;
				insertions <= 0;
				object_base <= 0;
				clear_next <= 0;
				link_addr <= 0;
				link_data <= 0;
				link_kind <= 0;
				object_valid <= 0;
				link_valid <= 0;
				clear_active <= 0;
				clear_count <= 0;
				insert_mask <= 0;
				copyr_seen <= 0;
				text_returned <= 0;
				overflow <= 0;
				timer_fault <= 0;
				clear_fault <= 0;
				insert_fault <= 0;
			end
			else if (active) begin
				if (&elapsed)
					overflow <= 1;
				else
					elapsed <= elapsed + 1'b1;
				if (!foreground) begin
					if (&irq_clocks)
						overflow <= 1;
					else
						irq_clocks <= irq_clocks + 1'b1;
				end
				else if (wait_q) begin
					if (&foreground_wait)
						overflow <= 1;
					else
						foreground_wait <= foreground_wait + 1'b1;
				end
				if (timer_write) begin
					if (be_q[2])
						timer[7:0] <= wdata_q[23:16];
					if (be_q[3])
						timer[15:8] <= wdata_q[31:24];
					if ((be_q[3:2] != 2'b11) || (wdata_q[31:16] != (timer + 16'd1)))
						timer_fault <= 1;
				end
				if (write_q && (addr_q == 32'h203f5ae0)) begin : sv2v_autoblock_1
					integer i;
					for (i = 0; i < 4; i = i + 1)
						if (be_q[i]) begin
							interrupted_pc[i * 8+:8] <= wdata_q[i * 8+:8];
							ip_lanes[i] <= 1;
						end
				end
				if (accept_game && foreground)
					case (pc_q[23:0])
						24'h84de50: copyr_seen <= 1;
						24'h84dfa0: text_returned <= 1;
						24'h8fd920: begin
							clear_active <= 1;
							clear_count <= 0;
						end
						24'h8fdca0: begin
							if (!clear_active || (clear_count != 40))
								clear_fault <= 1;
							if (&allocations)
								overflow <= 1;
							else
								allocations <= allocations + 1'b1;
							clear_active <= 0;
						end
						24'h8fe5a0: insert_mask <= 0;
						default:
							;
					endcase
				if (write_q && bus_game)
					case (bus_pc_q[23:0])
						24'h8fdbd0, 24'h8fdbe0: begin
							if (clear_count == 0) begin
								object_base <= addr_q;
								object_valid <= 1;
							end
							else if (addr_q != clear_next)
								clear_fault <= 1;
							clear_next <= addr_q + 32'd32;
							if (((!clear_active || (be_q != 4'b1111)) || (wdata_q != 0)) || (clear_count >= 40))
								clear_fault <= 1;
							if (clear_count != 63)
								clear_count <= clear_count + 1'b1;
						end
						24'h8fe5d0: begin
							if ((insert_mask != 0) || (be_q != 15))
								insert_fault <= 1;
							insert_mask[0] <= 1;
						end
						24'h8fe5e0: begin
							if ((insert_mask != 1) || (be_q != 15))
								insert_fault <= 1;
							insert_mask[1] <= 1;
						end
						24'h8fe5f0: begin
							if ((insert_mask != 3) || (be_q != 15))
								insert_fault <= 1;
							insert_mask[2] <= 1;
						end
						24'h8fe610: begin
							if ((insert_mask != 7) || (be_q != 15))
								insert_fault <= 1;
							insert_mask[3] <= 1;
						end
						24'h8fe640: begin
							if (((insert_mask != 15) || (be_q != 4'b1100)) || (wdata_q[31:16] != 0))
								insert_fault <= 1;
							if (&insertions)
								overflow <= 1;
							else
								insertions <= insertions + 1'b1;
							insert_mask <= 0;
						end
						default:
							;
					endcase
				if (read_q && bus_game)
					case (bus_pc_q[23:0])
						24'h8fe3d0, 24'h8fe4b0: begin
							link_addr <= addr_q;
							link_data <= rdata_q;
							link_valid <= 1;
							link_kind <= 1;
						end
						24'h9025f0, 24'h902630: begin
							link_addr <= addr_q;
							link_data <= rdata_q;
							link_valid <= 1;
							link_kind <= 2;
						end
						24'h904b50, 24'h904c10: begin
							link_addr <= addr_q;
							link_data <= rdata_q;
							link_valid <= 1;
							link_kind <= 3;
						end
						default:
							;
					endcase
				if (!early_valid && (timer >= 16)) begin
					early_sample <= sample;
					early_valid <= 1;
				end
			end
			if (fatal) begin
				final_sample <= sample;
				final_sample[30] <= 1;
				frozen <= 1;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module revx_diag_boot (
	clk,
	ce_pix,
	rst,
	cpu_pc,
	cpu_retire,
	last_fetch_addr,
	last_fetch_data,
	acc_prog,
	acc_gfx,
	acc_dcs,
	drop_any,
	rst_during_dl,
	sdram_init_done,
	ddr3_init_done,
	pic_status,
	dcs_status,
	uart_last_byte,
	adc_chan,
	adc_last,
	culprit_pc,
	target_pc,
	last_good_pc,
	culprit_instr,
	derail_captured,
	int_pc,
	int_vec_addr,
	int_vec_value,
	int_count,
	int_captured,
	intpend,
	intenb,
	disp_int,
	st_ie,
	foreground_pc,
	timers,
	process_ptr,
	watch_status,
	st_t1_lo,
	st_t1_hi,
	st_t2_got,
	st_t3_got1,
	st_t3_got2,
	st_t4_refresh,
	st_status,
	postcal_early,
	postcal_final,
	g_r,
	g_g,
	g_b,
	g_hs,
	g_vs,
	g_hb,
	g_vb,
	g_de,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de
);
	reg _sv2v_0;
	parameter [0:0] SHOW_TEXT = 1'b1;
	parameter [0:0] POST_CHECKPOINTS = 1'b0;
	parameter [0:0] TIMER_WATCH = 1'b0;
	parameter [0:0] POSTCAL_WATCH = 1'b0;
	input wire clk;
	input wire ce_pix;
	input wire rst;
	input wire [31:0] cpu_pc;
	input wire cpu_retire;
	input wire [31:0] last_fetch_addr;
	input wire [31:0] last_fetch_data;
	input wire [31:0] acc_prog;
	input wire [31:0] acc_gfx;
	input wire [31:0] acc_dcs;
	input wire [7:0] drop_any;
	input wire rst_during_dl;
	input wire sdram_init_done;
	input wire ddr3_init_done;
	input wire pic_status;
	input wire [15:0] dcs_status;
	input wire [7:0] uart_last_byte;
	input wire [7:0] adc_chan;
	input wire [7:0] adc_last;
	input wire [31:0] culprit_pc;
	input wire [31:0] target_pc;
	input wire [31:0] last_good_pc;
	input wire [15:0] culprit_instr;
	input wire derail_captured;
	input wire [31:0] int_pc;
	input wire [31:0] int_vec_addr;
	input wire [31:0] int_vec_value;
	input wire [7:0] int_count;
	input wire int_captured;
	input wire [15:0] intpend;
	input wire [15:0] intenb;
	input wire disp_int;
	input wire st_ie;
	input wire [31:0] foreground_pc;
	input wire [31:0] timers;
	input wire [31:0] process_ptr;
	input wire [31:0] watch_status;
	input wire [15:0] st_t1_lo;
	input wire [15:0] st_t1_hi;
	input wire [15:0] st_t2_got;
	input wire [15:0] st_t3_got1;
	input wire [15:0] st_t3_got2;
	input wire [15:0] st_t4_refresh;
	input wire [4:0] st_status;
	input wire [287:0] postcal_early;
	input wire [287:0] postcal_final;
	input wire [7:0] g_r;
	input wire [7:0] g_g;
	input wire [7:0] g_b;
	input wire g_hs;
	input wire g_vs;
	input wire g_hb;
	input wire g_vb;
	input wire g_de;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	reg [31:0] checkpoint_pc_q;
	reg [31:0] checkpoint_last_pc;
	reg checkpoint_accept_q;
	reg [15:0] checkpoint_hit;
	reg [15:0] checkpoint_seen;
	always @(*) begin
		if (_sv2v_0)
			;
		checkpoint_hit = 16'd0;
		if ((checkpoint_pc_q[31:24] == 8'h20) || (checkpoint_pc_q[31:24] == 8'hff))
			case (checkpoint_pc_q[23:0])
				24'h8038b0: checkpoint_hit[0] = 1'b1;
				24'h804410: checkpoint_hit[1] = 1'b1;
				24'haea870: checkpoint_hit[2] = 1'b1;
				24'haeb1c0: checkpoint_hit[3] = 1'b1;
				24'haeb340: checkpoint_hit[4] = 1'b1;
				24'haf6d80: checkpoint_hit[5] = 1'b1;
				24'h804a50: checkpoint_hit[6] = 1'b1;
				24'h803900: checkpoint_hit[7] = 1'b1;
				24'h803920: checkpoint_hit[8] = 1'b1;
				24'haf1350: checkpoint_hit[9] = 1'b1;
				24'h8128a0: checkpoint_hit[10] = 1'b1;
				24'h8133f0: checkpoint_hit[11] = 1'b1;
				24'h8d9750: checkpoint_hit[12] = 1'b1;
				24'h812320: checkpoint_hit[13] = 1'b1;
				24'h8123c0: checkpoint_hit[14] = 1'b1;
				24'h813460: checkpoint_hit[15] = 1'b1;
				default:
					;
			endcase
	end
	always @(posedge clk)
		if (rst) begin
			checkpoint_pc_q <= 32'd0;
			checkpoint_accept_q <= 1'b0;
			checkpoint_seen <= 16'd0;
			checkpoint_last_pc <= 32'd0;
		end
		else begin
			checkpoint_pc_q <= cpu_pc;
			checkpoint_accept_q <= cpu_retire;
			if ((!POSTCAL_WATCH && POST_CHECKPOINTS) && checkpoint_accept_q) begin
				checkpoint_seen <= checkpoint_seen | checkpoint_hit;
				if (|(checkpoint_hit & ~checkpoint_seen) && !checkpoint_seen[15])
					checkpoint_last_pc <= checkpoint_pc_q;
			end
		end
	function automatic [7:0] hx;
		input [3:0] n;
		hx = (n < 4'ha ? 8'h30 + {4'd0, n} : (8'h41 + {4'd0, n}) - 8'd10);
	endfunction
	function automatic [4:0] glyph;
		input [7:0] ch;
		input [2:0] row;
		reg [34:0] f;
		begin
			case (ch)
				"0": f = 35'b01110100011001110101110011000101110;
				"1": f = 35'b00100011000010000100001000010001110;
				"2": f = 35'b01110100010000100010001000100011111;
				"3": f = 35'b11110000010000101110000010000111110;
				"4": f = 35'b00010001100101010010111110001000010;
				"5": f = 35'b11111100001000011110000010000111110;
				"6": f = 35'b01110100001000011110100011000101110;
				"7": f = 35'b11111000010001000100010000100001000;
				"8": f = 35'b01110100011000101110100011000101110;
				"9": f = 35'b01110100011000101111000010000101110;
				"A": f = 35'b01110100011000111111100011000110001;
				"B": f = 35'b11110100011000111110100011000111110;
				"C": f = 35'b01111100001000010000100001000001111;
				"D": f = 35'b11110100011000110001100011000111110;
				"E": f = 35'b11111100001000011110100001000011111;
				"F": f = 35'b11111100001000011110100001000010000;
				"G": f = 35'b01111100001000010111100011000101111;
				"I": f = 35'b01110001000010000100001000010001110;
				"L": f = 35'b10000100001000010000100001000011111;
				"O": f = 35'b01110100011000110001100011000101110;
				"P": f = 35'b11110100011000111110100001000010000;
				"R": f = 35'b11110100011000111110101001001010001;
				"S": f = 35'b01111100001000001110000010000111110;
				"T": f = 35'b11111001000010000100001000010000100;
				default: f = 35'd0;
			endcase
			case (row)
				3'd0: glyph = f[34:30];
				3'd1: glyph = f[29:25];
				3'd2: glyph = f[24:20];
				3'd3: glyph = f[19:15];
				3'd4: glyph = f[14:10];
				3'd5: glyph = f[9:5];
				3'd6: glyph = f[4:0];
				default: glyph = 5'd0;
			endcase
		end
	endfunction
	reg [287:0] postcal_early_q;
	reg [287:0] postcal_final_q;
	reg [31:0] cpu_pc_q;
	reg [31:0] lfa_q;
	reg [31:0] lfd_q;
	reg [31:0] acc_prog_q;
	reg [31:0] acc_gfx_q;
	reg [31:0] acc_dcs_q;
	reg [7:0] drop_any_q;
	reg [7:0] uart_last_q;
	reg [7:0] adc_chan_q;
	reg [7:0] adc_last_q;
	reg rst_dl_q;
	reg sdram_q;
	reg ddr3_q;
	reg pic_q;
	reg [15:0] dcs_status_q;
	reg [31:0] culprit_pc_q;
	reg [31:0] target_pc_q;
	reg [31:0] last_good_pc_q;
	reg [15:0] culprit_instr_q;
	reg derail_captured_q;
	reg int_captured_q;
	reg [15:0] intpend_q;
	reg [15:0] intenb_q;
	reg disp_int_q;
	reg st_ie_q;
	reg [15:0] checkpoint_seen_q;
	reg [31:0] checkpoint_last_pc_q;
	reg [31:0] foreground_pc_q;
	reg [31:0] timers_q;
	reg [31:0] process_ptr_q;
	reg [31:0] watch_status_q;
	reg [15:0] st_t1_lo_q;
	reg [15:0] st_t1_hi_q;
	reg [15:0] st_t2_got_q;
	reg [15:0] st_t3_got1_q;
	reg [15:0] st_t3_got2_q;
	reg [15:0] st_t4_refresh_q;
	reg [4:0] st_status_q;
	(* ramstyle = "logic" *) reg [7:0] gr_q;
	(* ramstyle = "logic" *) reg [7:0] gg_q;
	(* ramstyle = "logic" *) reg [7:0] gb_q;
	(* ramstyle = "logic" *) reg ghs_q;
	(* ramstyle = "logic" *) reg gvs_q;
	(* ramstyle = "logic" *) reg ghb_q;
	(* ramstyle = "logic" *) reg gvb_q;
	(* ramstyle = "logic" *) reg gde_q;
	always @(posedge clk)
		if (ce_pix) begin
			postcal_early_q <= postcal_early;
			postcal_final_q <= postcal_final;
			cpu_pc_q <= cpu_pc;
			lfa_q <= last_fetch_addr;
			lfd_q <= last_fetch_data;
			acc_prog_q <= acc_prog;
			acc_gfx_q <= acc_gfx;
			acc_dcs_q <= acc_dcs;
			drop_any_q <= drop_any;
			rst_dl_q <= rst_during_dl;
			sdram_q <= sdram_init_done;
			ddr3_q <= ddr3_init_done;
			pic_q <= pic_status;
			dcs_status_q <= dcs_status;
			uart_last_q <= uart_last_byte;
			adc_chan_q <= adc_chan;
			adc_last_q <= adc_last;
			culprit_pc_q <= culprit_pc;
			target_pc_q <= target_pc;
			last_good_pc_q <= last_good_pc;
			culprit_instr_q <= culprit_instr;
			derail_captured_q <= derail_captured;
			int_captured_q <= int_captured;
			intpend_q <= intpend;
			intenb_q <= intenb;
			disp_int_q <= disp_int;
			st_ie_q <= st_ie;
			checkpoint_seen_q <= checkpoint_seen;
			checkpoint_last_pc_q <= checkpoint_last_pc;
			foreground_pc_q <= foreground_pc;
			timers_q <= timers;
			process_ptr_q <= process_ptr;
			watch_status_q <= watch_status;
			st_t1_lo_q <= st_t1_lo;
			st_t1_hi_q <= st_t1_hi;
			st_t2_got_q <= st_t2_got;
			st_t3_got1_q <= st_t3_got1;
			st_t3_got2_q <= st_t3_got2;
			st_t4_refresh_q <= st_t4_refresh;
			st_status_q <= st_status;
			gr_q <= g_r;
			gg_q <= g_g;
			gb_q <= g_b;
			ghs_q <= g_hs;
			gvs_q <= g_vs;
			ghb_q <= g_hb;
			gvb_q <= g_vb;
			gde_q <= g_de;
		end
	reg [11:0] gx;
	reg [11:0] gy;
	reg de_q;
	reg vb_q;
	reg [23:0] frame;
	reg [31:0] pc_q;
	reg [31:0] pc_show;
	reg [31:0] retired;
	always @(posedge clk)
		if (rst) begin
			gx <= 0;
			gy <= 0;
			de_q <= 0;
			vb_q <= 0;
			frame <= 0;
			pc_q <= 0;
			pc_show <= 0;
			retired <= 0;
		end
		else begin
			if (!POSTCAL_WATCH && cpu_retire)
				retired <= retired + 32'd1;
			if (ce_pix) begin
				de_q <= gde_q;
				vb_q <= gvb_q;
				pc_q <= cpu_pc_q;
				if (gvb_q && !vb_q) begin
					gy <= 12'd0;
					gx <= 12'd0;
					frame <= frame + 24'd1;
					if (frame[4:0] == 5'd0)
						pc_show <= pc_q;
				end
				else if (gde_q)
					gx <= gx + 12'd1;
				else if (de_q && !gde_q) begin
					gx <= 12'd0;
					gy <= gy + 12'd1;
				end
			end
		end
	function automatic [31:0] rowval;
		input [4:0] r;
		reg [287:0] snap;
		if (POSTCAL_WATCH) begin
			snap = (r[4] ? postcal_final_q : postcal_early_q);
			case (r[3:0])
				0: rowval = snap[31:0];
				1: rowval = snap[63:32];
				2: rowval = snap[95:64];
				3: rowval = snap[127:96];
				4: rowval = snap[159:128];
				5: rowval = snap[191:160];
				6: rowval = snap[223:192];
				7: rowval = snap[255:224];
				8: rowval = snap[287:256];
				default: rowval = 0;
			endcase
		end
		else
			case (r[3:0])
				4'd0: rowval = pc_show;
				4'd1: rowval = (POST_CHECKPOINTS ? {16'd0, checkpoint_seen_q} : lfa_q);
				4'd2: rowval = (POST_CHECKPOINTS ? checkpoint_last_pc_q : lfd_q);
				4'd3: rowval = retired;
				4'd4: rowval = {acc_prog_q[23:8], acc_gfx_q[23:8]};
				4'd5: rowval = {acc_dcs_q[23:8], 7'd0, rst_dl_q, drop_any_q};
				4'd6: rowval = {sdram_q, ddr3_q, pic_q, 13'h0000, dcs_status_q};
				4'd7: rowval = {8'd0, adc_chan_q, uart_last_q, adc_last_q};
				4'd8: rowval = (TIMER_WATCH ? foreground_pc_q : culprit_pc_q);
				4'd9: rowval = (TIMER_WATCH ? timers_q : target_pc_q);
				4'd10: rowval = (TIMER_WATCH ? process_ptr_q : last_good_pc_q);
				4'd11: rowval = (TIMER_WATCH ? watch_status_q : {culprit_instr_q, 14'd0, int_captured_q, derail_captured_q});
				4'd12: rowval = {st_t1_hi_q, st_t1_lo_q};
				4'd13: rowval = {intpend_q, intenb_q};
				4'd14: rowval = {28'd0, disp_int_q, st_ie_q, int_captured_q, derail_captured_q};
				default: rowval = {3'd0, st_status_q, 8'd0, st_t4_refresh_q};
			endcase
	endfunction
	function automatic [15:0] rowtag;
		input [4:0] r;
		if (POSTCAL_WATCH)
			case (r[3:0])
				0: rowtag = "TC";
				1: rowtag = "IP";
				2: rowtag = "AC";
				3: rowtag = "OB";
				4: rowtag = "LA";
				5: rowtag = "LD";
				6: rowtag = "RT";
				7: rowtag = "IR";
				8: rowtag = "DR";
				default: rowtag = "  ";
			endcase
		else
			case (r[3:0])
				4'd0: rowtag = "PC";
				4'd1: rowtag = (POST_CHECKPOINTS ? "PS" : "FA");
				4'd2: rowtag = (POST_CHECKPOINTS ? "LP" : "FD");
				4'd3: rowtag = "RT";
				4'd4: rowtag = "LD";
				4'd5: rowtag = "DR";
				4'd6: rowtag = "IS";
				4'd7: rowtag = "IO";
				4'd8: rowtag = (TIMER_WATCH ? "IP" : "CP");
				4'd9: rowtag = (TIMER_WATCH ? "TC" : "TG");
				4'd10: rowtag = (TIMER_WATCH ? "PR" : "LG");
				4'd11: rowtag = (TIMER_WATCH ? "TS" : "CI");
				4'd12: rowtag = "T1";
				4'd13: rowtag = "IE";
				4'd14: rowtag = "IX";
				default: rowtag = "ST";
			endcase
	endfunction
	localparam signed [31:0] X0L = 4;
	localparam signed [31:0] X0R = 270;
	localparam signed [31:0] CW = 6;
	localparam signed [31:0] NCH = 11;
	localparam signed [31:0] COLW = NCH * CW;
	reg [3:0] yrow0;
	reg [2:0] frow0;
	reg in_band0;
	always @(*) begin
		if (_sv2v_0)
			;
		in_band0 = 1'b0;
		yrow0 = 3'd0;
		frow0 = 3'd0;
		if ((gy >= 12'd8) && (gy <= 12'd14)) begin
			yrow0 = 3'd0;
			frow0 = gy - 12'd8;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd18) && (gy <= 12'd24)) begin
			yrow0 = 3'd1;
			frow0 = gy - 12'd18;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd28) && (gy <= 12'd34)) begin
			yrow0 = 3'd2;
			frow0 = gy - 12'd28;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd38) && (gy <= 12'd44)) begin
			yrow0 = 3'd3;
			frow0 = gy - 12'd38;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd48) && (gy <= 12'd54)) begin
			yrow0 = 3'd4;
			frow0 = gy - 12'd48;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd58) && (gy <= 12'd64)) begin
			yrow0 = 3'd5;
			frow0 = gy - 12'd58;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd68) && (gy <= 12'd74)) begin
			yrow0 = 3'd6;
			frow0 = gy - 12'd68;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd78) && (gy <= 12'd84)) begin
			yrow0 = 4'd7;
			frow0 = gy - 12'd78;
			in_band0 = 1'b1;
		end
		else if ((POSTCAL_WATCH && (gy >= 12'd88)) && (gy <= 12'd94)) begin
			yrow0 = 4'd8;
			frow0 = gy - 12'd88;
			in_band0 = 1'b1;
		end
	end
	wire in_left0 = (gx >= X0L) && (gx < (X0L + COLW));
	wire in_right0 = (gx >= X0R) && (gx < (X0R + COLW));
	wire in_col0 = in_left0 || in_right0;
	wire [11:0] xoff0 = (in_right0 ? gx - X0R[11:0] : gx - X0L[11:0]);
	wire [23:0] xmul0 = xoff0 * 24'd171;
	wire [7:0] celln0 = xmul0[17:10];
	reg in_band_1;
	reg in_col_1;
	reg colsel_1;
	reg [3:0] yrow_1;
	reg [2:0] frow_1;
	reg [6:0] xoff_1;
	reg [7:0] celln_1;
	always @(posedge clk)
		if (ce_pix) begin
			in_band_1 <= in_band0;
			in_col_1 <= in_col0;
			colsel_1 <= in_right0;
			yrow_1 <= yrow0;
			frow_1 <= frow0;
			xoff_1 <= xoff0[6:0];
			celln_1 <= celln0;
		end
	wire [11:0] cellx6_1 = ({4'd0, celln_1} << 2) + ({4'd0, celln_1} << 1);
	wire [2:0] fx_1 = xoff_1 - cellx6_1[6:0];
	wire [4:0] rowidx_1 = (POSTCAL_WATCH ? {colsel_1, yrow_1} : {1'b0, colsel_1, yrow_1[2:0]});
	wire [2:0] digidx_1 = celln_1[2:0] - 3'd3;
	wire [31:0] rv_1 = rowval(rowidx_1);
	wire [15:0] tagw_1 = rowtag(rowidx_1);
	reg in_band_2;
	reg in_col_2;
	reg [2:0] frow_2;
	reg [2:0] fx_2;
	reg [2:0] digidx_2;
	reg [7:0] celln_2;
	reg [31:0] rv_2;
	reg [15:0] tagw_2;
	always @(posedge clk)
		if (ce_pix) begin
			in_band_2 <= in_band_1;
			in_col_2 <= in_col_1;
			frow_2 <= frow_1;
			fx_2 <= fx_1;
			digidx_2 <= digidx_1;
			celln_2 <= celln_1;
			rv_2 <= rv_1;
			tagw_2 <= tagw_1;
		end
	reg [3:0] nyb_2;
	reg [7:0] ch_2;
	always @(*) begin
		if (_sv2v_0)
			;
		case (digidx_2)
			3'd0: nyb_2 = rv_2[31:28];
			3'd1: nyb_2 = rv_2[27:24];
			3'd2: nyb_2 = rv_2[23:20];
			3'd3: nyb_2 = rv_2[19:16];
			3'd4: nyb_2 = rv_2[15:12];
			3'd5: nyb_2 = rv_2[11:8];
			3'd6: nyb_2 = rv_2[7:4];
			default: nyb_2 = rv_2[3:0];
		endcase
		ch_2 = (celln_2 == 8'd0 ? tagw_2[15:8] : (celln_2 == 8'd1 ? tagw_2[7:0] : (celln_2 == 8'd2 ? 8'h20 : hx(nyb_2))));
	end
	reg [7:0] ch_3;
	reg [2:0] frow_3;
	reg [2:0] fx_3;
	reg valid_3;
	always @(posedge clk)
		if (ce_pix) begin
			ch_3 <= ch_2;
			frow_3 <= frow_2;
			fx_3 <= fx_2;
			valid_3 <= in_band_2 && in_col_2;
		end
	wire [4:0] gbits_3 = glyph(ch_3, frow_3);
	wire fpix_3 = (fx_3 < 3'd5 ? gbits_3[3'd4 - fx_3] : 1'b0);
	wire glyph_on = (SHOW_TEXT && valid_3) && fpix_3;
	wire in_overlay = SHOW_TEXT && valid_3;
	(* ramstyle = "logic" *) reg [7:0] gr_d1;
	(* ramstyle = "logic" *) reg [7:0] gr_d2;
	(* ramstyle = "logic" *) reg [7:0] gr_d3;
	(* ramstyle = "logic" *) reg [7:0] gg_d1;
	(* ramstyle = "logic" *) reg [7:0] gg_d2;
	(* ramstyle = "logic" *) reg [7:0] gg_d3;
	(* ramstyle = "logic" *) reg [7:0] gb_d1;
	(* ramstyle = "logic" *) reg [7:0] gb_d2;
	(* ramstyle = "logic" *) reg [7:0] gb_d3;
	(* ramstyle = "logic" *) reg ghs_d1;
	(* ramstyle = "logic" *) reg ghs_d2;
	(* ramstyle = "logic" *) reg ghs_d3;
	(* ramstyle = "logic" *) reg gvs_d1;
	(* ramstyle = "logic" *) reg gvs_d2;
	(* ramstyle = "logic" *) reg gvs_d3;
	(* ramstyle = "logic" *) reg ghb_d1;
	(* ramstyle = "logic" *) reg ghb_d2;
	(* ramstyle = "logic" *) reg ghb_d3;
	(* ramstyle = "logic" *) reg gvb_d1;
	(* ramstyle = "logic" *) reg gvb_d2;
	(* ramstyle = "logic" *) reg gvb_d3;
	(* ramstyle = "logic" *) reg gde_d1;
	(* ramstyle = "logic" *) reg gde_d2;
	(* ramstyle = "logic" *) reg gde_d3;
	always @(posedge clk)
		if (ce_pix) begin
			gr_d1 <= gr_q;
			gr_d2 <= gr_d1;
			gr_d3 <= gr_d2;
			gg_d1 <= gg_q;
			gg_d2 <= gg_d1;
			gg_d3 <= gg_d2;
			gb_d1 <= gb_q;
			gb_d2 <= gb_d1;
			gb_d3 <= gb_d2;
			ghs_d1 <= ghs_q;
			ghs_d2 <= ghs_d1;
			ghs_d3 <= ghs_d2;
			gvs_d1 <= gvs_q;
			gvs_d2 <= gvs_d1;
			gvs_d3 <= gvs_d2;
			ghb_d1 <= ghb_q;
			ghb_d2 <= ghb_d1;
			ghb_d3 <= ghb_d2;
			gvb_d1 <= gvb_q;
			gvb_d2 <= gvb_d1;
			gvb_d3 <= gvb_d2;
			gde_d1 <= gde_q;
			gde_d2 <= gde_d1;
			gde_d3 <= gde_d2;
		end
	always @(posedge clk)
		if (ce_pix) begin
			de <= gde_d3;
			hsync <= ghs_d3;
			vsync <= gvs_d3;
			hblank <= ghb_d3;
			vblank <= gvb_d3;
			if (!gde_d3) begin
				vid_r <= 8'd0;
				vid_g <= 8'd0;
				vid_b <= 8'd0;
			end
			else if (glyph_on) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else begin
				vid_r <= gr_d3;
				vid_g <= gg_d3;
				vid_b <= gb_d3;
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module revx_video_diag_counters (
	clk,
	rst,
	frame_tick,
	first_visible,
	visible,
	hud_disabled,
	active_y,
	row_base,
	pixel_miss,
	scan_req,
	scan_ack,
	vram_word_commit,
	vram_chunk_commit,
	vram_chunk_count,
	gfx_beat,
	dma_busy,
	src_wait,
	fb_wait,
	blit_done,
	cpu_accept,
	cpu_pc,
	dpyst_value,
	dpyst_valid,
	values
);
	input wire clk;
	input wire rst;
	input wire frame_tick;
	input wire first_visible;
	input wire visible;
	input wire hud_disabled;
	input wire [15:0] active_y;
	input wire [17:0] row_base;
	input wire pixel_miss;
	input wire scan_req;
	input wire scan_ack;
	input wire vram_word_commit;
	input wire vram_chunk_commit;
	input wire [6:0] vram_chunk_count;
	input wire gfx_beat;
	input wire dma_busy;
	input wire src_wait;
	input wire fb_wait;
	input wire blit_done;
	input wire cpu_accept;
	input wire [31:0] cpu_pc;
	input wire [31:0] dpyst_value;
	input wire dpyst_valid;
	output reg [447:0] values;
	function automatic [31:0] sat32;
		input [31:0] a;
		input [6:0] b;
		reg [32:0] sum;
		begin
			sum = {1'b0, a} + {26'd0, b};
			sat32 = (sum[32] ? 32'hffffffff : sum[31:0]);
		end
	endfunction
	function automatic [15:0] inc16;
		input [15:0] a;
		inc16 = (&a ? a : a + 16'd1);
	endfunction
	reg frame_q;
	reg first_q;
	reg visible_q;
	reg disabled_q;
	reg miss_q;
	reg scan_req_q;
	reg scan_ack_q;
	reg vword_q;
	reg vchunk_q;
	reg gfx_q;
	reg busy_q;
	reg src_q;
	reg fbwait_q;
	reg done_q;
	reg accept_q;
	reg dpyvalid_q;
	reg [6:0] chunk_q;
	reg [15:0] y_q;
	reg [17:0] row_q;
	reg [31:0] pc_q;
	reg [31:0] dpydata_q;
	always @(posedge clk)
		if (rst) begin
			frame_q <= 0;
			first_q <= 0;
			visible_q <= 0;
			disabled_q <= 0;
			miss_q <= 0;
			scan_req_q <= 0;
			scan_ack_q <= 0;
			vword_q <= 0;
			vchunk_q <= 0;
			gfx_q <= 0;
			busy_q <= 0;
			src_q <= 0;
			fbwait_q <= 0;
			done_q <= 0;
			accept_q <= 0;
			dpyvalid_q <= 0;
			chunk_q <= 0;
			y_q <= 0;
			row_q <= 0;
			pc_q <= 0;
			dpydata_q <= 0;
		end
		else begin
			frame_q <= frame_tick;
			first_q <= first_visible;
			visible_q <= visible;
			disabled_q <= hud_disabled;
			miss_q <= pixel_miss;
			scan_req_q <= scan_req;
			scan_ack_q <= scan_ack;
			vword_q <= vram_word_commit;
			vchunk_q <= vram_chunk_commit;
			chunk_q <= vram_chunk_count;
			gfx_q <= gfx_beat;
			busy_q <= dma_busy;
			src_q <= src_wait;
			fbwait_q <= fb_wait;
			done_q <= blit_done;
			y_q <= active_y;
			row_q <= row_base;
			accept_q <= cpu_accept;
			pc_q <= cpu_pc;
			dpyvalid_q <= dpyst_valid;
			dpydata_q <= dpyst_value;
		end
	reg [23:0] frames;
	reg [31:0] clocks;
	reg [31:0] vwords;
	reg [31:0] gfxbeats;
	reg [31:0] srcclks;
	reg [31:0] fbclks;
	reg [31:0] blits;
	reg [31:0] misses;
	reg [31:0] disabled_pixels;
	reg [15:0] scan_bursts;
	reg [15:0] scan_age;
	reg [15:0] scan_max;
	reg [15:0] late_frames;
	reg [15:0] last_drain;
	reg [17:0] front_row;
	reg busy_d;
	reg scan_ack_d;
	reg [31:0] dpyst_shadow;
	reg [31:0] first_dpyst;
	reg dpyst_seen;
	reg first_seen;
	reg q_seen;
	reg cpu_seen;
	reg normal_seen;
	reg overload_seen;
	reg route_error;
	reg route_pending;
	reg cpu_path;
	reg [15:0] publications;
	reg [15:0] repeats;
	reg [15:0] dma_skips;
	reg [15:0] cpu_skips;
	wire [6:0] write_words = {6'd0, vword_q} + (vchunk_q ? chunk_q : 7'd0);
	always @(posedge clk)
		if (rst) begin
			frames <= 0;
			clocks <= 0;
			vwords <= 0;
			gfxbeats <= 0;
			srcclks <= 0;
			fbclks <= 0;
			blits <= 0;
			misses <= 0;
			disabled_pixels <= 0;
			scan_bursts <= 0;
			scan_age <= 0;
			scan_max <= 0;
			late_frames <= 0;
			last_drain <= 0;
			front_row <= 0;
			dpyst_shadow <= 0;
			dpyst_seen <= 0;
			first_dpyst <= 0;
			first_seen <= 0;
			publications <= 0;
			repeats <= 0;
			dma_skips <= 0;
			cpu_skips <= 0;
			q_seen <= 0;
			cpu_seen <= 0;
			normal_seen <= 0;
			overload_seen <= 0;
			route_error <= 0;
			route_pending <= 0;
			cpu_path <= 0;
			busy_d <= 0;
			scan_ack_d <= 0;
			values <= 448'd0;
			values[31:0] <= 32'hd3000000;
		end
		else begin
			busy_d <= busy_q;
			scan_ack_d <= scan_ack_q;
			clocks <= sat32(clocks, 7'd1);
			vwords <= sat32(vwords, write_words);
			if (gfx_q)
				gfxbeats <= sat32(gfxbeats, 7'd1);
			if (src_q)
				srcclks <= sat32(srcclks, 7'd1);
			if (fbwait_q)
				fbclks <= sat32(fbclks, 7'd1);
			if (done_q)
				blits <= sat32(blits, 7'd1);
			if (scan_req_q && !scan_ack_q) begin
				scan_age <= inc16(scan_age);
				if (inc16(scan_age) > scan_max)
					scan_max <= inc16(scan_age);
			end
			else
				scan_age <= 0;
			if (scan_ack_q && !scan_ack_d)
				scan_bursts <= inc16(scan_bursts);
			if (miss_q)
				misses <= sat32(misses, 7'd1);
			if (disabled_q)
				disabled_pixels <= sat32(disabled_pixels, 7'd1);
			if (first_q) begin
				front_row <= row_q;
				if (busy_q)
					late_frames <= inc16(late_frames);
			end
			if (frame_q) begin
				if (dpyvalid_q) begin
					if (first_seen && (dpydata_q == first_dpyst))
						repeats <= inc16(repeats);
					first_dpyst <= dpydata_q;
					first_seen <= 1;
				end
			end
			if (dpyvalid_q) begin
				dpyst_shadow <= dpydata_q;
				dpyst_seen <= 1;
				if (dpyst_seen && (dpydata_q != dpyst_shadow))
					publications <= inc16(publications);
			end
			if (busy_d && !busy_q)
				last_drain <= (visible_q ? y_q + 16'd1 : 16'd0);
			if (accept_q)
				case (pc_q)
					32'h20812ab0: begin
						q_seen <= 1;
						if (route_pending)
							route_error <= 1;
						route_pending <= 1;
						cpu_path <= 0;
					end
					32'h20812d60: begin
						cpu_seen <= 1;
						cpu_path <= 1;
						if (!route_pending)
							route_error <= 1;
					end
					32'h20812ed0: begin
						normal_seen <= 1;
						if (!route_pending)
							route_error <= 1;
						route_pending <= 0;
					end
					32'h20812e60: begin
						overload_seen <= 1;
						if (!route_pending)
							route_error <= 1;
						else if (cpu_path)
							cpu_skips <= inc16(cpu_skips);
						else
							dma_skips <= inc16(dma_skips);
						route_pending <= 0;
					end
					default:
						;
				endcase
			if (frame_q) begin
				frames <= frames + 24'd1;
				values[0+:32] <= {8'hd3, frames + 24'd1};
				values[32+:32] <= clocks;
				values[64+:32] <= vwords;
				values[96+:32] <= gfxbeats;
				values[128+:32] <= srcclks;
				values[160+:32] <= fbclks;
				values[192+:32] <= {scan_max, scan_bursts};
				values[224+:32] <= misses;
				values[256+:32] <= disabled_pixels;
				values[288+:32] <= blits;
				values[320+:32] <= {publications, repeats};
				values[352+:32] <= {dma_skips, cpu_skips};
				values[384+:32] <= {late_frames, last_drain};
				values[416+:32] <= {dpyst_seen, first_seen, q_seen, cpu_seen, normal_seen, overload_seen, route_error, 7'd0, front_row};
				clocks <= 1;
				vwords <= {26'd0, write_words};
				gfxbeats <= {31'd0, gfx_q};
				srcclks <= {31'd0, src_q};
				fbclks <= {31'd0, fbwait_q};
				blits <= {31'd0, done_q};
				scan_bursts <= {15'd0, scan_ack_q && !scan_ack_d};
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module revx_video_diag_overlay (
	clk,
	ce_pix,
	rst,
	values,
	g_r,
	g_g,
	g_b,
	g_hs,
	g_vs,
	g_hb,
	g_vb,
	g_de,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de
);
	reg _sv2v_0;
	parameter [0:0] SHOW_TEXT = 1'b1;
	input wire clk;
	input wire ce_pix;
	input wire rst;
	input wire [447:0] values;
	input wire [7:0] g_r;
	input wire [7:0] g_g;
	input wire [7:0] g_b;
	input wire g_hs;
	input wire g_vs;
	input wire g_hb;
	input wire g_vb;
	input wire g_de;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	function automatic [7:0] hx;
		input [3:0] n;
		hx = (n < 4'ha ? 8'h30 + {4'd0, n} : (8'h41 + {4'd0, n}) - 8'd10);
	endfunction
	function automatic [4:0] glyph;
		input [7:0] ch;
		input [2:0] row;
		reg [34:0] f;
		begin
			case (ch)
				"0": f = 35'b01110100011001110101110011000101110;
				"1": f = 35'b00100011000010000100001000010001110;
				"2": f = 35'b01110100010000100010001000100011111;
				"3": f = 35'b11110000010000101110000010000111110;
				"4": f = 35'b00010001100101010010111110001000010;
				"5": f = 35'b11111100001000011110000010000111110;
				"6": f = 35'b01110100001000011110100011000101110;
				"7": f = 35'b11111000010001000100010000100001000;
				"8": f = 35'b01110100011000101110100011000101110;
				"9": f = 35'b01110100011000101111000010000101110;
				"A": f = 35'b01110100011000111111100011000110001;
				"B": f = 35'b11110100011000111110100011000111110;
				"C": f = 35'b01111100001000010000100001000001111;
				"D": f = 35'b11110100011000110001100011000111110;
				"E": f = 35'b11111100001000011110100001000011111;
				"F": f = 35'b11111100001000011110100001000010000;
				"G": f = 35'b01111100001000010111100011000101111;
				"H": f = 35'b10001100011000111111100011000110001;
				"U": f = 35'b10001100011000110001100011000101110;
				"V": f = 35'b10001100011000110001100010101000100;
				"W": f = 35'b10001100011000110101101011010101010;
				"Q": f = 35'b01110100011000110001101011001001101;
				"I": f = 35'b01110001000010000100001000010001110;
				"K": f = 35'b10001100101010011000101001001010001;
				"L": f = 35'b10000100001000010000100001000011111;
				"O": f = 35'b01110100011000110001100011000101110;
				"P": f = 35'b11110100011000111110100001000010000;
				"R": f = 35'b11110100011000111110101001001010001;
				"S": f = 35'b01111100001000001110000010000111110;
				"T": f = 35'b11111001000010000100001000010000100;
				default: f = 35'd0;
			endcase
			case (row)
				3'd0: glyph = f[34:30];
				3'd1: glyph = f[29:25];
				3'd2: glyph = f[24:20];
				3'd3: glyph = f[19:15];
				3'd4: glyph = f[14:10];
				3'd5: glyph = f[9:5];
				3'd6: glyph = f[4:0];
				default: glyph = 5'd0;
			endcase
		end
	endfunction
	reg [447:0] values_q;
	(* ramstyle = "logic" *) reg [7:0] gr_q;
	(* ramstyle = "logic" *) reg [7:0] gg_q;
	(* ramstyle = "logic" *) reg [7:0] gb_q;
	(* ramstyle = "logic" *) reg ghs_q;
	(* ramstyle = "logic" *) reg gvs_q;
	(* ramstyle = "logic" *) reg ghb_q;
	(* ramstyle = "logic" *) reg gvb_q;
	(* ramstyle = "logic" *) reg gde_q;
	always @(posedge clk)
		if (ce_pix) begin
			values_q <= values;
			gr_q <= g_r;
			gg_q <= g_g;
			gb_q <= g_b;
			ghs_q <= g_hs;
			gvs_q <= g_vs;
			ghb_q <= g_hb;
			gvb_q <= g_vb;
			gde_q <= g_de;
		end
	reg [11:0] gx;
	reg [11:0] gy;
	reg de_q;
	reg vb_q;
	always @(posedge clk)
		if (rst) begin
			gx <= 0;
			gy <= 0;
			de_q <= 0;
			vb_q <= 0;
		end
		else if (ce_pix) begin
			de_q <= gde_q;
			vb_q <= gvb_q;
			if (gvb_q && !vb_q) begin
				gy <= 0;
				gx <= 0;
			end
			else if (gde_q)
				gx <= gx + 12'd1;
			else if (de_q && !gde_q) begin
				gx <= 0;
				gy <= gy + 12'd1;
			end
		end
	function automatic [31:0] rowval;
		input [4:0] r;
		case (r)
			5'd0: rowval = values_q[0+:32];
			5'd1: rowval = values_q[32+:32];
			5'd2: rowval = values_q[64+:32];
			5'd3: rowval = values_q[96+:32];
			5'd4: rowval = values_q[128+:32];
			5'd5: rowval = values_q[160+:32];
			5'd6: rowval = values_q[192+:32];
			5'd7: rowval = values_q[224+:32];
			5'd8: rowval = values_q[256+:32];
			5'd9: rowval = values_q[288+:32];
			5'd10: rowval = values_q[320+:32];
			5'd11: rowval = values_q[352+:32];
			5'd12: rowval = values_q[384+:32];
			5'd13: rowval = values_q[416+:32];
			default: rowval = 0;
		endcase
	endfunction
	function automatic [15:0] rowtag;
		input [4:0] r;
		case (r)
			5'd0: rowtag = "ID";
			5'd1: rowtag = "FC";
			5'd2: rowtag = "BW";
			5'd3: rowtag = "GB";
			5'd4: rowtag = "SW";
			5'd5: rowtag = "DW";
			5'd6: rowtag = "SB";
			5'd7: rowtag = "UN";
			5'd8: rowtag = "DV";
			5'd9: rowtag = "BL";
			5'd10: rowtag = "PF";
			5'd11: rowtag = "SK";
			5'd12: rowtag = "LF";
			5'd13: rowtag = "CV";
			default: rowtag = "  ";
		endcase
	endfunction
	localparam signed [31:0] X0L = 4;
	localparam signed [31:0] X0R = 270;
	localparam signed [31:0] CW = 6;
	localparam signed [31:0] NCH = 11;
	localparam signed [31:0] COLW = NCH * CW;
	reg [3:0] yrow0;
	reg [2:0] frow0;
	reg in_band0;
	always @(*) begin
		if (_sv2v_0)
			;
		in_band0 = 1'b0;
		yrow0 = 3'd0;
		frow0 = 3'd0;
		if ((gy >= 12'd146) && (gy <= 12'd152)) begin
			yrow0 = 4'd0;
			frow0 = gy - 12'd146;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd156) && (gy <= 12'd162)) begin
			yrow0 = 4'd1;
			frow0 = gy - 12'd156;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd166) && (gy <= 12'd172)) begin
			yrow0 = 4'd2;
			frow0 = gy - 12'd166;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd176) && (gy <= 12'd182)) begin
			yrow0 = 4'd3;
			frow0 = gy - 12'd176;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd186) && (gy <= 12'd192)) begin
			yrow0 = 4'd4;
			frow0 = gy - 12'd186;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd196) && (gy <= 12'd202)) begin
			yrow0 = 4'd5;
			frow0 = gy - 12'd196;
			in_band0 = 1'b1;
		end
		else if ((gy >= 12'd206) && (gy <= 12'd212)) begin
			yrow0 = 4'd6;
			frow0 = gy - 12'd206;
			in_band0 = 1'b1;
		end
	end
	wire in_left0 = (gx >= X0L) && (gx < (X0L + COLW));
	wire in_right0 = (gx >= X0R) && (gx < (X0R + COLW));
	wire in_col0 = in_left0 || in_right0;
	wire [11:0] xoff0 = (in_right0 ? gx - X0R[11:0] : gx - X0L[11:0]);
	wire [23:0] xmul0 = xoff0 * 24'd171;
	wire [7:0] celln0 = xmul0[17:10];
	reg in_band_1;
	reg in_col_1;
	reg colsel_1;
	reg [3:0] yrow_1;
	reg [2:0] frow_1;
	reg [6:0] xoff_1;
	reg [7:0] celln_1;
	always @(posedge clk)
		if (ce_pix) begin
			in_band_1 <= in_band0;
			in_col_1 <= in_col0;
			colsel_1 <= in_right0;
			yrow_1 <= yrow0;
			frow_1 <= frow0;
			xoff_1 <= xoff0[6:0];
			celln_1 <= celln0;
		end
	wire [11:0] cellx6_1 = ({4'd0, celln_1} << 2) + ({4'd0, celln_1} << 1);
	wire [2:0] fx_1 = xoff_1 - cellx6_1[6:0];
	wire [4:0] rowidx_1 = {1'b0, yrow_1} + (colsel_1 ? 5'd7 : 5'd0);
	wire [2:0] digidx_1 = celln_1[2:0] - 3'd3;
	wire [31:0] rv_1 = rowval(rowidx_1);
	wire [15:0] tagw_1 = rowtag(rowidx_1);
	reg in_band_2;
	reg in_col_2;
	reg [2:0] frow_2;
	reg [2:0] fx_2;
	reg [2:0] digidx_2;
	reg [7:0] celln_2;
	reg [31:0] rv_2;
	reg [15:0] tagw_2;
	always @(posedge clk)
		if (ce_pix) begin
			in_band_2 <= in_band_1;
			in_col_2 <= in_col_1;
			frow_2 <= frow_1;
			fx_2 <= fx_1;
			digidx_2 <= digidx_1;
			celln_2 <= celln_1;
			rv_2 <= rv_1;
			tagw_2 <= tagw_1;
		end
	reg [3:0] nyb_2;
	reg [7:0] ch_2;
	always @(*) begin
		if (_sv2v_0)
			;
		case (digidx_2)
			3'd0: nyb_2 = rv_2[31:28];
			3'd1: nyb_2 = rv_2[27:24];
			3'd2: nyb_2 = rv_2[23:20];
			3'd3: nyb_2 = rv_2[19:16];
			3'd4: nyb_2 = rv_2[15:12];
			3'd5: nyb_2 = rv_2[11:8];
			3'd6: nyb_2 = rv_2[7:4];
			default: nyb_2 = rv_2[3:0];
		endcase
		ch_2 = (celln_2 == 8'd0 ? tagw_2[15:8] : (celln_2 == 8'd1 ? tagw_2[7:0] : (celln_2 == 8'd2 ? 8'h20 : hx(nyb_2))));
	end
	reg [7:0] ch_3;
	reg [2:0] frow_3;
	reg [2:0] fx_3;
	reg valid_3;
	always @(posedge clk)
		if (ce_pix) begin
			ch_3 <= ch_2;
			frow_3 <= frow_2;
			fx_3 <= fx_2;
			valid_3 <= in_band_2 && in_col_2;
		end
	wire [4:0] gbits_3 = glyph(ch_3, frow_3);
	wire fpix_3 = (fx_3 < 3'd5 ? gbits_3[3'd4 - fx_3] : 1'b0);
	wire glyph_on = (SHOW_TEXT && valid_3) && fpix_3;
	wire in_overlay = SHOW_TEXT && valid_3;
	(* ramstyle = "logic" *) reg [7:0] gr_d1;
	(* ramstyle = "logic" *) reg [7:0] gr_d2;
	(* ramstyle = "logic" *) reg [7:0] gr_d3;
	(* ramstyle = "logic" *) reg [7:0] gg_d1;
	(* ramstyle = "logic" *) reg [7:0] gg_d2;
	(* ramstyle = "logic" *) reg [7:0] gg_d3;
	(* ramstyle = "logic" *) reg [7:0] gb_d1;
	(* ramstyle = "logic" *) reg [7:0] gb_d2;
	(* ramstyle = "logic" *) reg [7:0] gb_d3;
	(* ramstyle = "logic" *) reg ghs_d1;
	(* ramstyle = "logic" *) reg ghs_d2;
	(* ramstyle = "logic" *) reg ghs_d3;
	(* ramstyle = "logic" *) reg gvs_d1;
	(* ramstyle = "logic" *) reg gvs_d2;
	(* ramstyle = "logic" *) reg gvs_d3;
	(* ramstyle = "logic" *) reg ghb_d1;
	(* ramstyle = "logic" *) reg ghb_d2;
	(* ramstyle = "logic" *) reg ghb_d3;
	(* ramstyle = "logic" *) reg gvb_d1;
	(* ramstyle = "logic" *) reg gvb_d2;
	(* ramstyle = "logic" *) reg gvb_d3;
	(* ramstyle = "logic" *) reg gde_d1;
	(* ramstyle = "logic" *) reg gde_d2;
	(* ramstyle = "logic" *) reg gde_d3;
	always @(posedge clk)
		if (ce_pix) begin
			gr_d1 <= gr_q;
			gr_d2 <= gr_d1;
			gr_d3 <= gr_d2;
			gg_d1 <= gg_q;
			gg_d2 <= gg_d1;
			gg_d3 <= gg_d2;
			gb_d1 <= gb_q;
			gb_d2 <= gb_d1;
			gb_d3 <= gb_d2;
			ghs_d1 <= ghs_q;
			ghs_d2 <= ghs_d1;
			ghs_d3 <= ghs_d2;
			gvs_d1 <= gvs_q;
			gvs_d2 <= gvs_d1;
			gvs_d3 <= gvs_d2;
			ghb_d1 <= ghb_q;
			ghb_d2 <= ghb_d1;
			ghb_d3 <= ghb_d2;
			gvb_d1 <= gvb_q;
			gvb_d2 <= gvb_d1;
			gvb_d3 <= gvb_d2;
			gde_d1 <= gde_q;
			gde_d2 <= gde_d1;
			gde_d3 <= gde_d2;
		end
	always @(posedge clk)
		if (ce_pix) begin
			de <= gde_d3;
			hsync <= ghs_d3;
			vsync <= gvs_d3;
			hblank <= ghb_d3;
			vblank <= gvb_d3;
			if (!gde_d3) begin
				vid_r <= 8'd0;
				vid_g <= 8'd0;
				vid_b <= 8'd0;
			end
			else if (glyph_on) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else begin
				vid_r <= gr_d3;
				vid_g <= gg_d3;
				vid_b <= gb_d3;
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module revx_sdram_selftest (
	clk,
	rst,
	arm,
	ready,
	m_addr,
	m_din,
	m_be,
	m_dqm_early,
	m_rd,
	m_wr,
	m_dout,
	m_ack,
	busy,
	t1_lo,
	t1_hi,
	t2_got,
	t3_got1,
	t3_got2,
	t4_after_refresh,
	status,
	done
);
	parameter [24:0] VEC_WORD_LO = 25'h01ffffe;
	parameter [24:0] VEC_WORD_HI = 25'h01fffff;
	parameter [15:0] VEC_EXP_LO = 16'he000;
	parameter [15:0] VEC_EXP_HI = 16'hfffd;
	parameter [24:0] SCRATCH2 = 25'h0300000;
	parameter [24:0] SCRATCH3 = 25'h0300001;
	parameter [24:0] SCRATCH3X = 25'h0300002;
	parameter signed [31:0] REFRESH_WAIT = 800;
	input wire clk;
	input wire rst;
	input wire arm;
	input wire ready;
	output reg [24:0] m_addr;
	output reg [15:0] m_din;
	output reg [1:0] m_be;
	output reg m_dqm_early;
	output reg m_rd;
	output reg m_wr;
	input wire [15:0] m_dout;
	input wire m_ack;
	output reg busy;
	output reg [15:0] t1_lo;
	output reg [15:0] t1_hi;
	output reg [15:0] t2_got;
	output reg [15:0] t3_got1;
	output reg [15:0] t3_got2;
	output reg [15:0] t4_after_refresh;
	output wire [4:0] status;
	output reg done;
	reg [1:0] tx;
	reg [24:0] tx_addr;
	reg [15:0] tx_din;
	reg [1:0] tx_be;
	reg tx_we;
	reg tx_dqm_early;
	reg [15:0] tx_rdata;
	reg tx_start;
	reg tx_done;
	always @(posedge clk)
		if (rst) begin
			tx <= 2'd0;
			m_rd <= 1'b0;
			m_wr <= 1'b0;
			m_dqm_early <= 1'b0;
			tx_done <= 1'b0;
			m_addr <= 25'd0;
			m_din <= 16'd0;
			m_be <= 2'b00;
			tx_rdata <= 16'd0;
		end
		else begin
			tx_done <= 1'b0;
			case (tx)
				2'd0:
					if (tx_start) begin
						m_addr <= tx_addr;
						m_din <= tx_din;
						m_be <= tx_be;
						m_dqm_early <= tx_dqm_early & tx_we;
						m_rd <= ~tx_we;
						m_wr <= tx_we;
						tx <= 2'd1;
					end
				2'd1:
					if (m_ack) begin
						if (!tx_we)
							tx_rdata <= m_dout;
						m_rd <= 1'b0;
						m_wr <= 1'b0;
						m_dqm_early <= 1'b0;
						tx <= 2'd2;
					end
				2'd2: begin
					tx_done <= 1'b1;
					tx <= 2'd0;
				end
				default: tx <= 2'd0;
			endcase
		end
	reg [4:0] st;
	reg waiting;
	reg [15:0] refwait;
	localparam [21:0] WD_MAX = 22'h3fffff;
	reg [21:0] wd;
	always @(posedge clk)
		if (rst) begin
			st <= 5'd0;
			waiting <= 1'b0;
			tx_start <= 1'b0;
			busy <= 1'b0;
			done <= 1'b0;
			refwait <= 16'd0;
			wd <= 22'd0;
			t1_lo <= 16'd0;
			t1_hi <= 16'd0;
			t2_got <= 16'd0;
			t3_got1 <= 16'd0;
			t3_got2 <= 16'd0;
			t4_after_refresh <= 16'd0;
			tx_we <= 1'b0;
			tx_addr <= 25'd0;
			tx_din <= 16'd0;
			tx_be <= 2'b00;
			tx_dqm_early <= 1'b0;
		end
		else begin
			tx_start <= 1'b0;
			if (busy)
				wd <= wd + 22'd1;
			else
				wd <= 22'd0;
			if (busy && (wd == WD_MAX)) begin
				st <= 5'd21;
				waiting <= 1'b0;
			end
			else
				case (st)
					5'd0: begin
						busy <= 1'b0;
						if ((arm && ready) && !done) begin
							busy <= 1'b1;
							st <= 5'd1;
						end
					end
					5'd1:
						if (!waiting) begin
							tx_we <= 1'b0;
							tx_addr <= VEC_WORD_LO;
							tx_din <= 16'd0;
							tx_be <= 2'b00;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd2;
						end
					5'd2: begin
						t1_lo <= tx_rdata;
						st <= 5'd3;
					end
					5'd3:
						if (!waiting) begin
							tx_we <= 1'b0;
							tx_addr <= VEC_WORD_HI;
							tx_din <= 16'd0;
							tx_be <= 2'b00;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd4;
						end
					5'd4: begin
						t1_hi <= tx_rdata;
						st <= 5'd5;
					end
					5'd5:
						if (!waiting) begin
							tx_we <= 1'b1;
							tx_addr <= SCRATCH2;
							tx_din <= 16'h1234;
							tx_be <= 2'b11;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd6;
						end
					5'd6:
						if (!waiting) begin
							tx_we <= 1'b0;
							tx_addr <= SCRATCH2;
							tx_din <= 16'd0;
							tx_be <= 2'b00;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd7;
						end
					5'd7: begin
						t2_got <= tx_rdata;
						st <= 5'd8;
					end
					5'd8:
						if (!waiting) begin
							tx_we <= 1'b1;
							tx_addr <= SCRATCH3;
							tx_din <= 16'haaaa;
							tx_be <= 2'b01;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd9;
						end
					5'd9:
						if (!waiting) begin
							tx_we <= 1'b1;
							tx_addr <= SCRATCH3;
							tx_din <= 16'h5555;
							tx_be <= 2'b10;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd10;
						end
					5'd10:
						if (!waiting) begin
							tx_we <= 1'b0;
							tx_addr <= SCRATCH3;
							tx_din <= 16'd0;
							tx_be <= 2'b00;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd11;
						end
					5'd11: begin
						t3_got1 <= tx_rdata;
						st <= 5'd12;
					end
					5'd12:
						if (!waiting) begin
							tx_we <= 1'b1;
							tx_addr <= SCRATCH3X;
							tx_din <= 16'haaaa;
							tx_be <= 2'b01;
							tx_dqm_early <= 1'b1;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd13;
						end
					5'd13:
						if (!waiting) begin
							tx_we <= 1'b1;
							tx_addr <= SCRATCH3X;
							tx_din <= 16'h5555;
							tx_be <= 2'b10;
							tx_dqm_early <= 1'b1;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd14;
						end
					5'd14:
						if (!waiting) begin
							tx_we <= 1'b0;
							tx_addr <= SCRATCH3X;
							tx_din <= 16'd0;
							tx_be <= 2'b00;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd15;
						end
					5'd15: begin
						t3_got2 <= tx_rdata;
						st <= 5'd16;
					end
					5'd16:
						if (!waiting) begin
							tx_we <= 1'b0;
							tx_addr <= SCRATCH2;
							tx_din <= 16'd0;
							tx_be <= 2'b00;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd17;
						end
					5'd17:
						if (!waiting) begin
							tx_we <= 1'b0;
							tx_addr <= SCRATCH2;
							tx_din <= 16'd0;
							tx_be <= 2'b00;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd18;
						end
					5'd18:
						if (refwait >= REFRESH_WAIT[15:0]) begin
							refwait <= 16'd0;
							st <= 5'd19;
						end
						else
							refwait <= refwait + 16'd1;
					5'd19:
						if (!waiting) begin
							tx_we <= 1'b0;
							tx_addr <= SCRATCH2;
							tx_din <= 16'd0;
							tx_be <= 2'b00;
							tx_dqm_early <= 1'b0;
							tx_start <= 1'b1;
							waiting <= 1'b1;
						end
						else if (tx_done) begin
							waiting <= 1'b0;
							st <= 5'd20;
						end
					5'd20: begin
						t4_after_refresh <= tx_rdata;
						st <= 5'd21;
					end
					5'd21: begin
						done <= 1'b1;
						busy <= 1'b0;
						st <= 5'd0;
					end
					default: st <= 5'd0;
				endcase
		end
	wire t1_ok = (t1_lo == VEC_EXP_LO) && (t1_hi == VEC_EXP_HI);
	wire t2_ok = t2_got == 16'h1234;
	wire t3n_ok = t3_got1 == 16'h55aa;
	wire t3x_ok = t3_got2 == 16'h55aa;
	assign status = {done, t1_ok, t2_ok, t3n_ok, t3x_ok};
endmodule
`default_nettype wire
