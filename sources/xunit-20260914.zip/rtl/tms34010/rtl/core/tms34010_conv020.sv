// -----------------------------------------------------------------------------
// tms34010_conv020.sv
//
// TMS34020-DELTA step 2: the '020 CONVSP/CONVDP/CONVMP register-write decode
// (DELTA (e); MAME 0.289 tms34010.cpp:1495-1529). One combinational leaf --
// the same two-nibble decode drives all three CONV registers on the '020. The
// decoded value is the PITCH the XY->linear ops multiply Y by (MAME
// 34010ops.hxx:21-23:  y*m_conv + (x<<pixelshift) + OFFSET).
//
//   low nibble (data[4:0]) zero      -> conv = data              (raw store)
//   low set, high nibble (data[12:8]) zero -> conv = 1<<(~data&0x1f)   (pow2)
//   low set, high set                -> conv = 1<<(~data&0x1f)
//                                             + 1<<(~(data>>8)&0x1f)   (2 pow2)
//
// The '010 uses only the single power-of-two form (:1336-1342); for a
// power-of-2 pitch the '020 result is IDENTICAL, so the existing shift-based
// XY datapath is already '020-correct there. The non-power-of-2 (two-nibble)
// pitch needs a multiplier in the XY datapath -- wired in step 8 (io_regs
// remap); this leaf delivers + verifies the value.
//
// Purely combinational; default P_IS_34020 so instantiating it never perturbs
// a '010 gate (the '010 path is not wired to it).
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_conv020
  import tms34010_pkg::*;
#(
  parameter bit P_IS_34020 = IS_34020
) (
  input  wire logic [15:0] conv_data,   // value written to CONVSP/CONVDP/CONVMP
  output logic [31:0]      conv_value    // decoded pitch (m_conv*)
);

  logic [15:0] data_eff;
`ifdef MUT_CONV020_DROP_HI
  // MUTANT: drop the second (high) nibble before decoding -- a two-nibble
  // non-power-of-2 pitch collapses to the single-nibble power of two. MUST be
  // killed by the two-nibble cases in tb_020_psize32.
  assign data_eff = conv_data & 16'h00FF;
`else
  assign data_eff = conv_data;
`endif

  assign conv_value = conv020_decode(data_eff);

endmodule
`default_nettype wire
