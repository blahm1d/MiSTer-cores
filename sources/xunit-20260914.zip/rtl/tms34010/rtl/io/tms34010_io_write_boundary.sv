// -----------------------------------------------------------------------------
// tms34010_io_write_boundary.sv
//
// Registered boundary between the CE-gated TMS34010 datapath and the full-rate
// I/O register file.  The core's memory outputs are combinational functions of
// state/decode/regfile data and become stable only after a cpu_ce edge.  The
// external-memory adapter therefore accepts them on a later cpu_ce edge.  I/O
// writes must obey the same rule: capture the exact transaction only when the
// core accepts its acknowledgement, then present one full-rate-clock write
// pulse made entirely from registered command fields.
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_io_write_boundary
  import tms34010_pkg::*;
(
  input  wire logic                    clk,
  input  wire logic                    rst,
  input  wire logic                    ce_cpu,
  input  wire logic                    req,
  input  wire logic                    we,
  input  wire logic                    is_io,
  input  wire logic                    ack,
  input  wire logic [ADDR_WIDTH-1:0]   addr,
  input  wire logic [15:0]             wdata,
  input  wire logic [15:0]             wdata_hi, // 020 aligned display-pair high half only
  // Field size of the access (1..32). I/O registers are ordinary field targets;
  // the size must cross the boundary with the address and data so io_regs can
  // read-modify-write only the addressed bits.
  input  wire logic [FIELD_SIZE_WIDTH-1:0] size,

  output logic                         wr_valid,
  output logic [ADDR_WIDTH-1:0]        wr_addr,
  output logic [15:0]                  wr_data,
  output logic [FIELD_SIZE_WIDTH-1:0]  wr_size,
  // RESIDUAL-TIMING (B): precomputed field mask and pre-shifted write data.
  // io_regs' write commit becomes a short (current & ~wr_mask)|wr_data_sh merge
  // instead of the full barrel-shift io_field_merge (wr_size -> io_field_mask ->
  // io_reg was a ce_to_full single-cycle cone at -0.889 ns / 12.5 ns).  These
  // are registered on the SAME retiring cpu_ce edge as wr_addr/wr_size/wr_data
  // and held identically, so they are CE-family launch registers: the two
  // barrel shifts launch from the CE-core command registers and ride the CE
  // setup-4/hold-3 multicycle, while only the short AND/OR merge stays on the
  // io_reg write's single cycle.  wr_data_sh == ((wdata<<bit_off) & mask) and
  // wr_mask == io_field_mask(bit_off,size), so the merge is byte-identical.
  output logic [15:0]                  wr_mask,
  output logic [15:0]                  wr_data_sh,
  output logic [15:0]                  wr_display_hi,
  output logic                         wr_display_pair,
  (* preserve *)
  output logic                         wr_status_guard
);

`ifdef MUT_IO_LIVE_WRITE
  // Mutation: restore the rejected full-rate live path.  A request held while
  // waiting for ack writes on every sysclk and exposes CPU combinational logic
  // directly to io_reg[*].D.
  assign wr_valid = req && we && is_io;
  assign wr_addr  = addr;
  assign wr_data  = wdata;
  assign wr_size  = size;
  assign wr_mask    = io_field_mask(addr[3:0], size);
  assign wr_data_sh = (wdata << addr[3:0]) & io_field_mask(addr[3:0], size);
  assign wr_display_hi = wdata_hi;
  assign wr_display_pair = io020_display_pair(addr) && (size == FIELD_SIZE_WIDTH'(32));
  assign wr_status_guard = 1'b0;
`else
  // wr_valid is a one-sysclk pulse.  Address/data change only on the retiring
  // cpu_ce edge and are already stable before wr_valid is consumed by io_regs
  // on the following sysclk edge.
  always_ff @(posedge clk) begin
    if (rst) begin
      wr_valid <= 1'b0;
      wr_addr  <= '0;
      wr_data  <= '0;
      wr_size  <= '0;
      wr_mask    <= '0;
      wr_data_sh <= '0;
      wr_display_hi <= '0;
      wr_display_pair <= 1'b0;
      wr_status_guard <= 1'b0;
    end else begin
      wr_valid <= 1'b0;
      wr_status_guard <= 1'b0;
      // wr_valid/wr_status_guard are CE-qualified one-shots (the proven T-unit
      // "cpu_io_command_regs" pattern): the SET is gated on cpu_ce so the RISING
      // edge -- the only edge that carries the instr_word_q command cone -- always
      // coincides with a cpu_ce edge; the clear-to-0 every clk does NOT depend on
      // the CE-core command (it is forced 0 by ~ce_cpu), so instr_word_q ->
      // wr_valid / wr_status_guard is a valid CE-launch destination (setup 4/hold
      // 3) with no RTL change beyond this pre-existing gate.  MUT_WR_VALID_NO_CE
      // drops the CE term: at /4 the rise then lands on the off-CE edge where the
      // bench's ack first asserts, and the ce-coincidence bench fails.
      if (
`ifndef MUT_WR_VALID_NO_CE
          (ce_cpu !== 1'b0) &&
`endif
                              req && we && is_io && ack) begin
        wr_valid <= 1'b1;
        wr_addr  <= addr;
        wr_data  <= wdata;
        wr_size  <= size;
        // Both extra fields are captured on the same CE edge as wr_addr and
        // held until the next accepted command. There is no second live CPU
        // path to io_regs: two plain display halves commit from this boundary.
        wr_display_hi <= wdata_hi;
`ifdef MUT_IO020_DISPLAY_PAIR_DROP
        wr_display_pair <= 1'b0;
`else
        wr_display_pair <= io020_display_pair(addr) && (size == FIELD_SIZE_WIDTH'(32));
`endif
        // Held identically to wr_addr/wr_size (updated only on this retiring CE
        // edge), so they are CE-stable launch registers.
`ifdef MUT_IO_MASK_ZERO
        // MUTANT: zero the precomputed mask/shift -> io_regs' precomputed merge
        // becomes (current & ~0)|0 = current, so every board (wr_pre_valid=1)
        // I/O write is dropped.  MUST be killed by tb_io_write_boundary (and the
        // 020 boot smokes), which no longer see HTOTAL/PSIZE commit.
        wr_mask    <= 16'h0;
        wr_data_sh <= 16'h0;
`else
        wr_mask    <= io_field_mask(addr[3:0], size);
        wr_data_sh <= (wdata << addr[3:0]) & io_field_mask(addr[3:0], size);
`endif
        wr_status_guard <= 1'b1;
      end
    end
  end
`endif

endmodule : tms34010_io_write_boundary
`default_nettype wire
