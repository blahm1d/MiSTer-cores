// revx_guns.sv -- Revolution X three-gun input + on-screen overlay.
//
// Three player guns.  Gun N X/Y come from joystick_l_analog_{N-1} (MiSTer signed
// 8-bit per axis, 0 = centre); they feed the ADC0848 as AN0..AN5 (midxunit.cpp:
// 683-688 ch1..ch6 <- AN0..AN5).
//
// ADC conversion (DONOR-DECISION s.3 / HANDOFF "Sinden / guns"):
//   AN_x = 0x80 - x   AN_y = 0x80 + y
// WHY: MAME declares AN0/AN2/AN4 (the X axes) with PORT_REVERSE and centre 0x80
// (midxunit.cpp:621,627,633) and the game itself inverts X again in READ_ALL_POTS
// (GXCONTRL.ASM:3184-3188 BTST 0 -> NOT A1 on even/X channels).  The Y axes have no
// PORT_REVERSE (midxunit.cpp:624,630,636) => AN_y = 0x80 + y.
//
// AIM SOURCE (per player, OSD P2O[37:36]/[39:38]/[41:40]):
//   0 = L-Analog/USB Gun/Sinden : the absolute stick (default, unchanged path)
//   1 = Mouse                   : no-op for the ADC (kept absolute -- the ADC feed
//                                 has never had a relative mouse path; mouse stays
//                                 out per the task, and the crosshair stays absolute
//                                 too so the two never disagree)
//   2 = D-Pad                   : JOYSTICK AIM MODE -- revx_gun_aim integrates an ADC
//                                 position at a fixed per-frame rate from the d-pad and
//                                 HOLDS it when the stick is neutral (no centre snap),
//                                 clamped to the ADC range.  Modelled on chiller_gun.sv.
// The absolute (source != 2) ADC bytes are bit-identical to the pre-change RTL.
//
// The crosshair/border presentation reuses the Y-unit gun stack ported here
// (revx_lightgun_position x3 for the absolute/mouse screen coords, revx_lightgun_overlay
// extended to three guns).  In D-Pad mode the crosshair coordinate is derived directly
// from the integrated ADC position (single source of truth) via a constant multiply
// that reproduces the absolute mapping exactly, so the overlay tracks the game aim.
// Border width is a parameter (default 4; the cabinet Sinden setup may want ~20).
// Screen geometry defaults to GXSYS.H:32,35 (400 x 254).

`default_nettype none

// ---------------------------------------------------------------------------
// revx_gun_aim -- one gun's ADC byte pair.  Absolute passthrough or, in D-Pad
// mode, a per-frame integrator with anti-snap hold + range clamp.
//
//   joy_dir : raw MiSTer joystick[3:0] = {up, down, left, right} (bit3..bit0);
//             right/left move X, up/down move Y.
//   Polarity matches the absolute AN mapping so the cursor moves the same visual
//   direction in either mode: right decreases adc_x (clamp 0), left increases it
//   (clamp 255); up decreases adc_y (clamp 0), down increases it (clamp 255).
//   "Faster when held": the per-frame step is RATE_SLOW until a direction has been
//   held for RAMP_FRAMES frames, then RATE_FAST (fine aim on a tap, fast traversal
//   on a sustained push).  A neutral stick leaves the position untouched.
// ---------------------------------------------------------------------------
module revx_gun_aim #(
    parameter [7:0] RATE_SLOW   = 8'd2,
    parameter [7:0] RATE_FAST   = 8'd6,
    parameter [7:0] RAMP_FRAMES = 8'd20
)(
    input  logic        clk,
    input  logic        rst,
    input  logic [1:0]  source,        // 0/1/3 = absolute, 2 = D-Pad integrate
    input  logic [15:0] analog,        // {Y, X} signed, 0 = centre
    input  logic [3:0]  joy_dir,       // {up, down, left, right} raw MiSTer joystick[3:0]
    input  logic        frame_tick,    // one pulse per frame
    output logic [7:0]  adc_x,
    output logic [7:0]  adc_y,
    // Preselection D-Pad coordinates keep the OSD selector out of scaling.
    output wire  [7:0]  dpad_adc_x,
    output wire  [7:0]  dpad_adc_y
);
    logic [7:0] jx = 8'h80, jy = 8'h80;   // integrated ADC position, centre on reset
    logic [7:0] hold_cnt = 8'd0;          // frames a direction has been held

    wire        any_dir = |joy_dir;
    wire [7:0]  rate     = (hold_cnt >= RAMP_FRAMES) ? RATE_FAST : RATE_SLOW;

    always_ff @(posedge clk) begin
        if (rst) begin
            jx <= 8'h80; jy <= 8'h80; hold_cnt <= 8'd0;
        end else if (frame_tick) begin
            hold_cnt <= any_dir ? ((hold_cnt >= RAMP_FRAMES) ? RAMP_FRAMES
                                                             : hold_cnt + 8'd1)
                                : 8'd0;
            // X axis: right decreases (clamp 0), left increases (clamp 255)
            if (joy_dir[0] && !joy_dir[1])
                jx <= (jx <= rate)             ? 8'd0   : (jx - rate);
            else if (joy_dir[1] && !joy_dir[0])
                jx <= (jx >= (8'd255 - rate))  ? 8'd255 : (jx + rate);
            // Y axis: up decreases (clamp 0), down increases (clamp 255)
            if (joy_dir[3] && !joy_dir[2])
                jy <= (jy <= rate)             ? 8'd0   : (jy - rate);
            else if (joy_dir[2] && !joy_dir[3])
                jy <= (jy >= (8'd255 - rate))  ? 8'd255 : (jy + rate);
        end
        // frame_tick low: HOLD (jx/jy retain their value) -- the anti-snap property.
    end

`ifdef MUT_GUN_JOY_ABSOLUTE
    // MUTANT (gate-only): D-Pad mode follows the stick's ABSOLUTE value, so a
    // neutral stick snaps the aim back to centre -- the behaviour the user
    // rejected.  tb_revx_gun_aim's release-holds check MUST kill this.
    wire [7:0] joy_sel_x = 8'h80 - analog[7:0];
    wire [7:0] joy_sel_y = 8'h80 + analog[15:8];
`else
    wire [7:0] joy_sel_x = jx;
    wire [7:0] joy_sel_y = jy;
`endif

    assign dpad_adc_x = joy_sel_x;
    assign dpad_adc_y = joy_sel_y;
    assign adc_x = (source == 2'd2) ? joy_sel_x : (8'h80 - analog[7:0]);
    assign adc_y = (source == 2'd2) ? joy_sel_y : (8'h80 + analog[15:8]);
endmodule

module revx_guns #(
    parameter [8:0] BORDER_WIDTH = 9'd4,    // Sinden border (cab may raise to ~20)
    parameter [8:0] SCREEN_W     = 9'd400,  // GXSYS.H:32 SCREEN_WIDTH
    parameter [8:0] SCREEN_H     = 9'd254   // GXSYS.H:35 SCREEN_HEIGHT
)(
    input  logic        clk,
    input  logic        rst,

    // analog sticks: [7:0]=X (signed), [15:8]=Y (signed), 0 = centre
    input  logic [15:0] joystick_l_analog_0,   // gun1
    input  logic [15:0] joystick_l_analog_1,   // gun2
    input  logic [15:0] joystick_l_analog_2,   // gun3

    // per-player aim source + d-pad (OSD P2O[37:36]/[39:38]/[41:40]).
    // gunN_joy = raw MiSTer joystick[3:0] = {up, down, left, right}.
    input  logic [1:0]  gun1_src,
    input  logic [1:0]  gun2_src,
    input  logic [1:0]  gun3_src,
    input  logic [3:0]  gun1_joy,
    input  logic [3:0]  gun2_joy,
    input  logic [3:0]  gun3_joy,

    // ---- ADC feed (-> revx_adc0848 an0..an5) --------------------------------
    output logic [7:0]  an0,  // gun1 X = 0x80 - x
    output logic [7:0]  an1,  // gun1 Y = 0x80 + y
    output logic [7:0]  an2,  // gun2 X
    output logic [7:0]  an3,  // gun2 Y
    output logic [7:0]  an4,  // gun3 X
    output logic [7:0]  an5,  // gun3 Y

    // ---- overlay video path -------------------------------------------------
    input  logic        pxl_cen,
    input  logic        hs,
    input  logic        vs,
    input  logic        de,
    input  logic [2:0]  gun_en,        // per-gun crosshair enable
    input  logic        border_en,
    input  logic        crosshair_en,
    input  logic [23:0] rgb_in,
    output logic [23:0] rgb_out,

    // observability: raster + gun screen coords
    output logic [8:0]  raster_x,
    output logic [8:0]  raster_y
);
    // ---- one frame tick per vsync rising edge (clk domain) -------------------
    logic vs_d;
    always_ff @(posedge clk) if (rst) vs_d <= vs; else vs_d <= vs;
    wire  frame_tick = vs & ~vs_d;

    // ---- ADC bytes: absolute (0x80-x / 0x80+y) or integrated D-Pad aim -------
    wire [7:0] dpad_x1, dpad_y1, dpad_x2, dpad_y2, dpad_x3, dpad_y3;
    revx_gun_aim u_aim1 (.clk(clk), .rst(rst), .source(gun1_src),
        .analog(joystick_l_analog_0), .joy_dir(gun1_joy), .frame_tick(frame_tick),
        .adc_x(an0), .adc_y(an1),
        .dpad_adc_x(dpad_x1), .dpad_adc_y(dpad_y1));
    revx_gun_aim u_aim2 (.clk(clk), .rst(rst), .source(gun2_src),
        .analog(joystick_l_analog_1), .joy_dir(gun2_joy), .frame_tick(frame_tick),
        .adc_x(an2), .adc_y(an3),
        .dpad_adc_x(dpad_x2), .dpad_adc_y(dpad_y2));
    revx_gun_aim u_aim3 (.clk(clk), .rst(rst), .source(gun3_src),
        .analog(joystick_l_analog_2), .joy_dir(gun3_joy), .frame_tick(frame_tick),
        .adc_x(an4), .adc_y(an5),
        .dpad_adc_x(dpad_x3), .dpad_adc_y(dpad_y3));

    // ---- absolute/mouse crosshair screen coordinates (source 0/1) ------------
    logic [8:0] g1x,g1y,g2x,g2y,g3x,g3y;
    logic [7:0] unused_ax[0:2], unused_ay[0:2];
    logic       unused_gs[0:2];

    revx_lightgun_position #(.DEFAULT_WIDTH(SCREEN_W), .DEFAULT_HEIGHT(SCREEN_H)) u_p1 (
        .clk(clk),.rst(rst),.vs(vs),.screen_width(SCREEN_W),.screen_height(SCREEN_H),
        .rotate(2'd0),.sensitivity(2'd0),.source(2'd0),
        .joyana(joystick_l_analog_0),.joy_dir(4'd0),.mouse_dx(8'd0),.mouse_dy(8'd0),.mouse_strobe(1'b0),
        .gun_x(g1x),.gun_y(g1y),.adc_x(unused_ax[0]),.adc_y(unused_ay[0]),.gun_strobe(unused_gs[0]));
    revx_lightgun_position #(.DEFAULT_WIDTH(SCREEN_W), .DEFAULT_HEIGHT(SCREEN_H)) u_p2 (
        .clk(clk),.rst(rst),.vs(vs),.screen_width(SCREEN_W),.screen_height(SCREEN_H),
        .rotate(2'd0),.sensitivity(2'd0),.source(2'd0),
        .joyana(joystick_l_analog_1),.joy_dir(4'd0),.mouse_dx(8'd0),.mouse_dy(8'd0),.mouse_strobe(1'b0),
        .gun_x(g2x),.gun_y(g2y),.adc_x(unused_ax[1]),.adc_y(unused_ay[1]),.gun_strobe(unused_gs[1]));
    revx_lightgun_position #(.DEFAULT_WIDTH(SCREEN_W), .DEFAULT_HEIGHT(SCREEN_H)) u_p3 (
        .clk(clk),.rst(rst),.vs(vs),.screen_width(SCREEN_W),.screen_height(SCREEN_H),
        .rotate(2'd0),.sensitivity(2'd0),.source(2'd0),
        .joyana(joystick_l_analog_2),.joy_dir(4'd0),.mouse_dx(8'd0),.mouse_dy(8'd0),.mouse_strobe(1'b0),
        .gun_x(g3x),.gun_y(g3y),.adc_x(unused_ax[2]),.adc_y(unused_ay[2]),.gun_strobe(unused_gs[2]));

    // ---- crosshair coordinate: D-Pad mode tracks the integrated aim ----------
    // (256-adc_x)*W>>8 and adc_y*H>>8 reproduce the absolute crosshair mapping
    // exactly (analog_x = 256-AN_x, analog_y = AN_y), so there is no discontinuity
    // when the source switches and the overlay follows the game aim in D-Pad mode.
    function automatic [8:0] adc_to_scr_x(input [7:0] ax, input [8:0] w);
        logic [17:0] p; logic [8:0] r;
        begin
            p = (9'd256 - {1'b0, ax}) * w;
            r = p[16:8];
            adc_to_scr_x = (r >= w) ? (w - 9'd1) : r;
        end
    endfunction
    function automatic [8:0] adc_to_scr_y(input [7:0] ay, input [8:0] h);
        logic [17:0] p; logic [8:0] r;
        begin
            p = {1'b0, ay} * h;
            r = p[16:8];
            adc_to_scr_y = (r >= h) ? (h - 9'd1) : r;
        end
    endfunction

    // Source==2 already selects the D-Pad bytes in the ADC path. Use those
    // same bytes directly here, then select the finished screen coordinate.
    // This removes status -> ADC mux -> multiply/clamp -> coordinate register.
    // ADC output, mapping, integrator and coordinate capture edge are unchanged.
    wire [8:0] cx1 = (gun1_src == 2'd2) ? adc_to_scr_x(dpad_x1, SCREEN_W) : g1x;
    wire [8:0] cy1 = (gun1_src == 2'd2) ? adc_to_scr_y(dpad_y1, SCREEN_H) : g1y;
    wire [8:0] cx2 = (gun2_src == 2'd2) ? adc_to_scr_x(dpad_x2, SCREEN_W) : g2x;
    wire [8:0] cy2 = (gun2_src == 2'd2) ? adc_to_scr_y(dpad_y2, SCREEN_H) : g2y;
    wire [8:0] cx3 = (gun3_src == 2'd2) ? adc_to_scr_x(dpad_x3, SCREEN_W) : g3x;
    wire [8:0] cy3 = (gun3_src == 2'd2) ? adc_to_scr_y(dpad_y3, SCREEN_H) : g3y;

    // ---- register the crosshair coordinates before the overlay ---------------
    // The aim position is a per-frame value (jx/jy update only on frame_tick, and the
    // an* ADC bytes only follow them), so this one-clock pipeline is invisible to the
    // displayed crosshair.  It BREAKS the long single-cycle cone the fitter had built:
    // aim integrator (u_aim3 Add5) -> ADC byte -> adc_to_scr DSP multiply + clamp ->
    // overlay -> rgb_out -> the DIAG game-video delay RAM data-in (revx_diag_boot
    // gvb_d1 M10K), which was the 4b413b96 slow-100C setup -3.45 ns path.  The RAM data
    // input now launches from these registers, not from the aim adder through the DSP.
    logic [8:0] cx1_q, cy1_q, cx2_q, cy2_q, cx3_q, cy3_q;
    always_ff @(posedge clk) begin
        if (rst) begin cx1_q<=9'd0; cy1_q<=9'd0; cx2_q<=9'd0; cy2_q<=9'd0; cx3_q<=9'd0; cy3_q<=9'd0; end
        else     begin cx1_q<=cx1;  cy1_q<=cy1;  cx2_q<=cx2;  cy2_q<=cy2;  cx3_q<=cx3;  cy3_q<=cy3;  end
    end

    revx_lightgun_overlay #(.BORDER_WIDTH(BORDER_WIDTH)) u_ovl (
        .clk(clk),.rst(rst),.pxl_cen(pxl_cen),.hs(hs),.vs(vs),.de(de),
        .screen_width(SCREEN_W),.screen_height(SCREEN_H),
        .gun1_x(cx1_q),.gun1_y(cy1_q),.gun2_x(cx2_q),.gun2_y(cy2_q),.gun3_x(cx3_q),.gun3_y(cy3_q),
        .gun1_en(gun_en[0]),.gun2_en(gun_en[1]),.gun3_en(gun_en[2]),
        .border_en(border_en),.crosshair_en(crosshair_en),
        .rgb_in(rgb_in),.rgb_out(rgb_out),.raster_x(raster_x),.raster_y(raster_y));

endmodule

`default_nettype wire
