// revx_cpu_bfm.sv -- PLACEHOLDER TMS34020 for X-unit bring-up (Revolution X).
//
// The real 34020 (rtl/tms34010 with IS_34020) is owned by the CPU lane; this BFM stands
// in at the SAME CPU<->memory contract (HANDOFF-REVX-KICKOFF-20260906.md): a 32-bit,
// bit-addressed request/valid master (mem_req/mem_we/mem_addr[31:0]/mem_be[3:0]/
// mem_wdata -> mem_rdata/mem_ack) plus the DMA-done interrupt on input line 0
// (midxunit.cpp:650 dma_irq_cb -> inputline 0).
//
// It is driven by a simple command port so a testbench (or revx_top's bring-up sequencer)
// can script exact CPU transactions: assert cmd_req with cmd_we/cmd_addr/cmd_wdata/cmd_be;
// the BFM runs ONE mem transaction and pulses cmd_done with cmd_rdata.  On reset release it
// also latches its first autonomous fetch address = RESET_PC so a smoke test can confirm the
// reset-vector fetch is wired (int0 is observed, not acted on -- a placeholder has no ISR).

`default_nettype none
module revx_cpu_bfm #(
  parameter [31:0] RESET_PC = 32'hFFFDE010   // measured reset PC (ASSUMPTION: mame-gospel/README.md, unverified)
)(
  input  logic        clk,
  input  logic        rst,

  // CPU <-> memory contract (master)
  output logic        mem_req,
  output logic        mem_we,
  output logic [31:0] mem_addr,
  output logic  [3:0] mem_be,
  output logic [31:0] mem_wdata,
  input  logic [31:0] mem_rdata,
  input  logic        mem_ack,

  // interrupts
  input  logic        int0,          // DMA-done (level), latched for observability only

  // tb / sequencer command port (one transaction per req pulse)
  input  logic        cmd_req,
  input  logic        cmd_we,
  input  logic [31:0] cmd_addr,
  input  logic  [3:0] cmd_be,
  input  logic [31:0] cmd_wdata,
  output logic [31:0] cmd_rdata,
  output logic        cmd_done,

  // observability
  output logic [31:0] reset_pc,      // = RESET_PC (the address the CPU would first fetch)
  output logic        int0_seen      // sticky: int0 was asserted at least once
);
  assign reset_pc = RESET_PC;

  typedef enum logic [1:0] { B_IDLE, B_RUN, B_WAIT, B_DONE } st_t;
  st_t st;

  always_ff @(posedge clk) begin
    if (rst) begin
      st <= B_IDLE; mem_req <= 1'b0; mem_we <= 1'b0; cmd_done <= 1'b0;
      cmd_rdata <= 32'd0; int0_seen <= 1'b0; mem_addr <= RESET_PC; mem_be <= 4'hf;
    end else begin
      cmd_done <= 1'b0;
      if (int0) int0_seen <= 1'b1;
      case (st)
        B_IDLE: if (cmd_req) begin
          mem_addr  <= cmd_addr; mem_we <= cmd_we; mem_be <= cmd_be; mem_wdata <= cmd_wdata;
          mem_req   <= 1'b1; st <= B_WAIT;
        end
        B_WAIT: begin
          // The real CPU adapter holds its request through acknowledgment.
          // Match that contract when arbitration adds a grant cycle.
          if (mem_ack) begin mem_req <= 1'b0; cmd_rdata <= mem_rdata; cmd_done <= 1'b1; st <= B_IDLE; end
        end
        default: st <= B_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
