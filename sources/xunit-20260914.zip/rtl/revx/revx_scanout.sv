// revx_scanout.sv -- Midway X-unit (Revolution X) autonomous video scanout.
//
// BOARD lane step 3 (b).  Drives the raster from the core's video block
// (hcount/vcount from tms34010_video) + the 34020 display-register taps
// (rowaddr/coladdr = params->rowaddr/coladdr, from DPYSTRT/DPYNX/DINC), reading
// VRAM rows through the palette into the RGB path.  The address arithmetic is the
// MAME 0.289 midxunit scanline_update gospel (midtunit_v.cpp:859-866):
//
//   fulladdr = ((rowaddr << 16) | coladdr) >> 3;             // 16-bit VRAM word index
//   src      = &videoram[fulladdr & 0x3fe00];                // 512-word row base
//   for x in [heblnk, hsblnk):  pixel = src[fulladdr++ & 0x1ff] & 0x7fff;
//
// i.e. visible pixel i reads VRAM word  (fulladdr & 0x3fe00) | ((fulladdr + i) & 0x1ff)
// and the low 15 bits index the 32768-entry xRGB555 palette (midxunit.cpp:667).
//
// Model: line fetch starts in horizontal blank and may continue while already
// fetched words are displayed. Each pixel has its own readiness deadline.
// Registered line-buffer and palette reads produce RGB888 two clocks later.
// The VRAM read uses the single scanout master (s_*) that revx_sdram_arb grants at
// top priority (step 3a). A missed pixel deadline is blanked and sets underflow.
//
// MUTANT REVX_SCAN_ROW_MUT mis-derives the row addressing (>>2 instead of >>3);
// every fetched word then comes from the wrong VRAM address -> tb_revx_scanout's
// pixel-exact compare against the blind python golden FAILs.

`timescale 1ns/1ps
`default_nettype none
// Convert the scanline reader's held scalar request into aligned 16-pixel
// physical bursts. The retained block belongs only to the current scanline;
// dropping the request invalidates it, so a repeated row observes new pixels.
module revx_scan_word_cache (
  input logic clk, rst,
  input logic req,
  input logic [17:0] addr,
  output logic [15:0] data,
  output logic ack,
  output logic burst_req,
  output logic [17:0] burst_addr,
  input logic burst_ack,
  input logic [255:0] burst_data
);
  typedef enum logic [1:0] {S_IDLE, S_FILL, S_ADVANCE} state_t;
  state_t state;
  logic valid;
  logic [13:0] tag;
  logic [255:0] block_data;
  logic [17:0] request_addr;
  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE; valid <= 1'b0; tag <= '0; block_data <= '0;
      request_addr <= '0; data <= '0; ack <= 1'b0;
      burst_req <= 1'b0; burst_addr <= '0;
    end else begin
      ack <= 1'b0;
      if (!req) valid <= 1'b0;
      case (state)
        S_IDLE: if (req && !burst_ack) begin
          request_addr <= addr;
          if (valid && tag == addr[17:4]) begin
            data <= block_data[16*addr[3:0] +: 16];
            ack <= 1'b1; state <= S_ADVANCE;
          end else begin
            burst_addr <= {addr[17:4],4'd0};
            burst_req <= 1'b1; state <= S_FILL;
          end
        end
        S_FILL: if (burst_ack) begin
          burst_req <= 1'b0; block_data <= burst_data;
          tag <= burst_addr[17:4]; valid <= req;
          data <= burst_data[16*request_addr[3:0] +: 16];
          ack <= 1'b1; state <= S_ADVANCE;
        end
        // The consumer advances its address on ACK. Do not acknowledge the
        // old word twice while its held request propagates through that edge.
        S_ADVANCE: if (!req || addr != request_addr) state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule

module revx_scanout #(
  parameter int MAXW = 512      // max visible pixels per line (line-buffer depth)
)(
  input  logic        clk,
  input  logic        rst,
  input  logic        ce_pix,   // pixel-clock enable
  input  logic        disp_enable, // DPYCTL.ENV; unconnected legacy benches remain enabled

  // ---- video timing (from tms34010_video) ----
  input  logic [15:0] hcount,
  input  logic [15:0] vcount,
  input  logic [15:0] heblnk,   // first visible column
  input  logic [15:0] hsblnk,   // first blanked column (end+1)
  input  logic [15:0] veblnk,   // first visible line
  input  logic [15:0] vsblnk,   // first blanked line (end+1)

  // ---- 34020 display-register taps for the CURRENT line ----
  input  logic [15:0] rowaddr,  // params->rowaddr
  input  logic [15:0] coladdr,  // params->coladdr

  // ---- scanout VRAM read master (16-bit word) -> revx_sdram_arb S ----
  output logic        s_rd,
  output logic [17:0] s_addr,   // VRAM 16-bit word index
  input  logic [15:0] s_data,
  input  logic        s_ack,

  // ---- palette LUT (one-clock registered read): index -> xRGB555 ----
  output logic [14:0] pal_idx,
  input  logic [14:0] pal_rgb,

  // ---- RGB output ----
  output logic [7:0]  r,
  output logic [7:0]  g,
  output logic [7:0]  b,
  output logic        de,
  output logic        hs,
  output logic        vs,
  output logic        ce_out,   // downstream samples the settled RGB/timing on this enable
  output logic        underflow, // sticky: a requested visible pixel missed its deadline
  output wire         diag_pixel_miss // passive pulse at the actual pixel deadline
);
  localparam int CW = $clog2(MAXW);

  // ---- visible-region combinational flags ----
  wire line_visible = (vcount >= veblnk) && (vcount < vsblnk);
  wire vis_px       = line_visible && (hcount >= heblnk) && (hcount < hsblnk);
  wire [15:0] width = hsblnk - heblnk;

  // ---- per-line base address (MAME formula) ----
  // fulladdr = ((rowaddr<<16)|coladdr) >> 3
  wire [31:0] fulladdr32 = (({16'd0, rowaddr} << 16) | {16'd0, coladdr})
`ifdef REVX_SCAN_ROW_MUT
                           >> 2;   // MUTANT: wrong row/col shift -> wrong VRAM row
`else
                           >> 3;   // gospel (midtunit_v.cpp:861)
`endif
  wire [17:0] full18   = fulladdr32[17:0];
  wire [17:0] row_base = full18 & 18'h3fe00;   // 512-word row base
  wire [8:0]  col0     = full18[8:0];          // starting low-9 within the row

  // latched at line start (stable across the fetch)
  logic [17:0] l_rowbase;
  logic [8:0]  l_col0;
  logic [15:0] l_width;

  // ---- line buffer ----
  (* ramstyle = "no_rw_check, M10K" *) logic [15:0] linebuf [0:MAXW-1];

  // ---- fetch FSM (runs at clk, during horizontal blank) ----
  logic         fetching, line_done;
  logic         line_valid, line_expected;
  wire scan_enabled = (disp_enable !== 1'b0);
  logic [CW:0]  fi;
  // fetch address: row_base | ((col0 + fi) & 0x1ff)
  wire [8:0]    fcol = (l_col0 + fi[8:0]) & 9'h1ff;
  assign s_addr = l_rowbase | {9'd0, fcol};
  assign s_rd   = fetching;

  logic hz_d;        // hcount==0 edge detect on ce_pix
  wire  line_start = ce_pix && (hcount == 16'd0);

  always_ff @(posedge clk) begin
    if (rst) begin
      fetching <= 1'b0; line_done <= 1'b0; fi <= '0; underflow <= 1'b0;
      line_valid <= 1'b0;
      line_expected <= 1'b0;
      l_rowbase <= '0; l_col0 <= '0; l_width <= '0;
    end else begin
      // arm a fetch at the start of each visible line
      if (line_start) begin
        line_done <= 1'b0;
        line_valid <= 1'b0;
        line_expected <= line_visible && scan_enabled;
        // Never replace the payload of a read awaiting its physical ACK.
        if (line_visible && scan_enabled && !fetching) begin
          l_rowbase <= row_base; l_col0 <= col0; l_width <= width;
          fi <= '0; fetching <= 1'b1; line_valid <= 1'b1;
        end
      end
      if (!scan_enabled) begin line_valid <= 1'b0; line_expected <= 1'b0; end
      // run the fetch (req held until ack)
      if (fetching && s_ack) begin
        linebuf[fi[CW-1:0]] <= s_data;
        if (!scan_enabled || (fi + 1) >= {1'b0, l_width[CW:0]}) begin
          fetching <= 1'b0; line_done <= scan_enabled;
        end else fi <= fi + 1'b1;
      end
      // A completed prefix is enough: compare the actual requested column with
      // fetched-word count. A word arriving on this edge is not yet readable.
      if (ce_pix && vis_px && scan_enabled && line_expected && !pixel_ready)
        underflow <= 1'b1;
    end
  end

  // ---- line RAM at N, palette RAM at N+1, downstream sample at N+2 ----
  logic [15:0] col_word;
  wire  [CW-1:0] col = (hcount - heblnk);
  wire pixel_ready = scan_enabled && line_valid && (line_done || ({1'b0, col} < fi));
  assign diag_pixel_miss = !rst && ce_pix && vis_px && scan_enabled && line_expected && !pixel_ready;
  logic ce_q, de_q, hs_q, vs_q, ready_q, data_ready;
  // Keep reset out of the memory read register so Quartus recognizes M10K.
  always_ff @(posedge clk) if (ce_pix) col_word <= linebuf[col];
  always_ff @(posedge clk) begin
    if (rst) begin
      ce_q<=0; ce_out<=0; de_q<=0; hs_q<=0; vs_q<=0; ready_q<=0;
      de<=0; hs<=0; vs<=0; data_ready<=0;
    end else begin
      ce_q <= ce_pix;
      ce_out <= ce_q;
      if (ce_pix) begin
        de_q <= vis_px; ready_q <= pixel_ready;
        hs_q <= (hcount < heblnk);
        vs_q <= (vcount < veblnk);
      end
      if (ce_q) begin
        de <= de_q; hs <= hs_q; vs <= vs_q; data_ready <= ready_q;
      end
    end
  end

  assign pal_idx = col_word[14:0];             // VRAM word & 0x7fff -> palette index
  // xRGB555 -> RGB888 (5->8 bit replication)
  wire [4:0] r5 = pal_rgb[14:10];
  wire [4:0] g5 = pal_rgb[9:5];
  wire [4:0] b5 = pal_rgb[4:0];
  assign r = de && data_ready ? {r5, r5[4:2]} : 8'd0;
  assign g = de && data_ready ? {g5, g5[4:2]} : 8'd0;
  assign b = de && data_ready ? {b5, b5[4:2]} : 8'd0;

  // tie-off unused
  wire _u = &{1'b0, hz_d, line_done};
endmodule
`default_nettype wire
