// revx_mem.sv -- Midway X-unit (Revolution X) memory decode + region models.
//
// FORK of rtl/wolf/wolf_mem.sv (UMK3 Wolf-unit) re-cut for the X-unit board.
// The Wolf donor is a 16-bit TMS34010 slave; the X-unit CPU is a TMS34020 with a
// 32-bit data bus, so this fork changes (a) the bus WIDTH (16 -> 32, mem_be[3:0]
// byte enables) and (b) the region DECODE (X-unit map, midxunit.cpp:508-527).
// It is NOT the Wolf 16-bit field engine transcribed; it is a clean decode+model
// built to the RevX CPU<->memory contract (HANDOFF-REVX-KICKOFF-20260906.md sec.
// "CPU<->memory contract"): bit-addressed mem_addr[31:0], 32-bit little-endian
// word at mem_addr[31:5], byte lane b at bits[8b+7:8b] gated by mem_be[b].
//
// GROUND TRUTH (MAME 0.289):
//   src/mame/williams/midxunit.cpp:508-527  main_map (region base addresses)
//   midxunit.cpp:225-254  io_w      (offset=(offset/2)%8; case2=watchdog; default=gun out)
//   midxunit.cpp:257-266  unknown_w (offs=offset/0x40000; offs1 -> DCS reset ~data&2)
//   midxunit.cpp:282-286  status_r  ((m_pic_status<<1)|adc_int)
//   midxunit.cpp:456-472  security_r/security_w/security_clock_w (PIC taps)
//   midxunit.cpp:482-499  dma_r/dma_w (32-bit pair onto 16-bit video dma regs)
//   midtunit_v.cpp:403-413 midxunit_paletteram_w/_r (32768 xRGB555, 32-bit stride,
//                          even 16-bit offset only)
//   midtunit_v.cpp:246-251 midwunit_gfxrom_r (FLAT gfx window, NO bank select)
//   midtunit_v.cpp:281-288 midtunit_vram_data_w (DMA_PALETTE hi-byte fold)
//   GXSYS.H:40-76          SCRATCH/CMOS/COLRAM/SWITCH/SYSCTRL0/1/IROM equates
//
// Bus taps for the true external devices (ADC, UART, PIC, DMA, gfx/prog ROM) are
// surfaced as ports; revx_memsys wires them to revx_adc0848 / revx_uart /
// revx_pic_adapter / wolf_dma and the SDRAM/DDR3 gfx+ROM backend.  The RAM / CMOS
// / palette / VRAM regions are modelled here behaviorally for board bring-up (the
// SDRAM/DDR3 backend fork is the reported frontier -- see AUDIT.md).

`default_nettype none

module revx_mem #(
    // Main "scratch" RAM.  GXSYS.H:40,46 SCRATCH=0x20000000..SCRATCH_END=0x20800000
    // => 0x800000 bit-addresses = 0x100000 bytes = 1 MiB = 0x40000 32-bit words.
    // Sim/DE10 fit knob (real fix = RAM -> SDRAM, as in Wolf).
    parameter int RAM_WORDS = 32'h1000,      // 32-bit words modelled here (bring-up: small)
    parameter int PAL_ENTRIES = 32'h8000,    // 32768 xRGB555 (midxunit.cpp:667)
    parameter int CMOS_BYTES  = 32'h2000,    // 8 KiB (LH5268; midxunit.cpp:523 umask8, nvram 0x2000)
    parameter int VRAM_WORDS  = 32'h1000,    // 16-bit VRAM words modelled here (bring-up: small)
    // IO_ONLY=1: the peripheral-bus deployment (revx_top's CPU I/O path), where RAM/VRAM/PAL/CMOS
    // are served by revx_backends + the top's palette instead of this behavioral model.  Only the
    // I/O windows (SYSCTRL/status/IN/SEC/io_w/ADC/UART/DMA) are decoded; the memory-region arrays
    // shrink to 1 entry so no dead M10K is inferred (CLAUDE.md s.7).  Default 0 = full model
    // (tb_revx_mem_decode / tb_revx_memsys / tb_revx_periph_bus keep the whole behavioral model).
    parameter bit IO_ONLY = 1'b0
)(
    input  logic        clk,
    input  logic        rst,

    // ---- CPU (TMS34020) 32-bit request/valid bus, bit-addressed --------------
    input  logic        mem_req,
    input  logic        mem_we,
    input  logic [31:0] mem_addr,     // bit address
    input  logic  [3:0] mem_be,       // byte enables, lane b -> bits [8b+7:8b]
    input  logic [31:0] mem_wdata,
    output logic [31:0] mem_rdata,
    output logic        mem_ack,

    // ---- Player inputs / DIPs (ACTIVE-LOW), midxunit.cpp:515-518 -------------
    input  logic [31:0] in0,          // 0x60c00000  IN0
    input  logic [31:0] in1,          // 0x60c00020  IN1
    input  logic [31:0] in2,          // 0x60c00040  IN2
    input  logic [31:0] dsw,          // 0x60c00060  DSW

    // ---- SYSCTRL latches (unknown_w, GXSYS.H:72-73/78-97) -------------------
    output logic  [3:0] sysctrl0,     // 0x40800000 latch 0 (low nibble)
    output logic  [3:0] sysctrl1,     // 0x40c00000 latch 1 (low nibble)
    output logic        dcs_reset,    // active-HIGH DCS reset = SYSCTRL1[1] (P0020; dcs.cpp:1456-1471)
    output logic        cmos_write_enable, // SYSCTRL0[2] (CMOSENAB, GXSYS.H:90)

    // ---- io_w gun/LED/watchdog taps (midxunit.cpp:234-253) ------------------
    output logic  [2:0] gun_recoil,   // io_w default: BIT(data,0..2)
    output logic  [2:0] gun_led,      // io_w default: BIT(~data,4..6)
    output logic        watchdog_kick,// io_w case2 strobe (0x60c000c0, WDOG_BONE)

    // ---- ADC0848 taps (0x80800000, byte lane 0, midxunit.cpp:521) -----------
    output logic        adc_wr,       // conversion-start write strobe
    output logic  [7:0] adc_wdata,    // channel byte (data & 0x1f used by device)
    output logic        adc_rd,       // result read strobe (clears intr in device)
    input  logic  [7:0] adc_rdata,    // device result
    input  logic        adc_done,     // device intr (ASSERT after conversion) -> status_r[0]

    // ---- UART taps (0x80c00000, 8 regs, byte lane 0, midxunit.cpp:522) ------
    output logic        uart_wr,
    output logic        uart_rd,
    output logic  [2:0] uart_reg,     // register index (addr>>5)&7
    output logic  [7:0] uart_wdata,
    input  logic  [7:0] uart_rdata,

    // ---- Security PIC taps (midxunit.cpp:456-472, 514/520) ------------------
    output logic        pic_cmd_we,   // security_w  @0x60c000e0 : m_pic_command = data&0x0f
    output logic  [3:0] pic_cmd,      // low nibble
    output logic        pic_clk_we,   // security_clock_w @0x60400000 : m_pic_clk = bit1
    output logic        pic_clk,      // data bit1
    output logic        pic_resp_re,  // security_r  @0x60c000e0 read strobe
    input  logic  [7:0] pic_data,     // m_pic_data  -> security_r result
    input  logic        pic_status,   // m_pic_status -> status_r[1]

    // ---- DMA register window (0xc0800000 + mirror 0xc0c00000) ---------------
    //  midxunit.cpp:482-499: 32-bit access <-> two 16-bit video dma regs.
    //  revx_memsys splits dma_wdata into video regs {pair*2, pair*2+1}.
    output logic        dma_we,
    output logic        dma_rd,
    output logic  [2:0] dma_pair,     // (addr>>5)&7  -> video regs pair*2 / pair*2+1
    output logic [31:0] dma_wdata,
    input  logic [31:0] dma_rdata,

    // ---- gfx ROM read window (FLAT 16 MiB, 0xf8000000, midtunit_v.cpp:246) --
    output logic        gfx_rd,
    output logic [23:0] gfx_baddr,    // byte address = (addr-0xf8000000)>>3
    input  logic [31:0] gfx_rdata,    // little-endian pair of 16-bit gfx words

    // ---- program ROM read window (2 MiB, 0xff000000, midxunit.cpp:527) ------
    output logic        rom_rd,
    output logic [18:0] rom_waddr,    // 32-bit word index = (addr-0xff000000)>>5
    input  logic [31:0] rom_rdata,    // 32-bit interleaved (u51..u54)

    // ---- Observability: decoded region (self-checking gate hook) ------------
    output logic  [4:0] dbg_region
);

    // ------------------------------------------------------------------ region enum
    localparam logic [4:0]
        R_NONE   = 5'd0,
        R_VRAMD  = 5'd1,   // 0x00000000 vram data
        R_VRAMC  = 5'd2,   // 0x00800000 vram colour
        R_RAM    = 5'd3,   // 0x20000000 scratch
        R_SYSC   = 5'd4,   // 0x40800000 unknown_w (SYSCTRL0/1)
        R_STATUS = 5'd5,   // 0x60400000 status_r / security_clock_w
        R_IN0    = 5'd6,
        R_IN1    = 5'd7,
        R_IN2    = 5'd8,
        R_DSW    = 5'd9,
        R_IO     = 5'd10,  // 0x60c00080 io_w
        R_SEC    = 5'd11,  // 0x60c000e0 security_r/w
        R_ADC    = 5'd12,  // 0x80800000
        R_UART   = 5'd13,  // 0x80c00000
        R_CMOS   = 5'd14,  // 0xa0440000
        R_PAL    = 5'd15,  // 0xa0800000
        R_DMA    = 5'd16,  // 0xc0800000 (+mirror)
        R_GFX    = 5'd17,  // 0xf8000000
        R_ROM    = 5'd18;  // 0xff000000

    // ------------------------------------------------------------------ pure decode
    // All comparisons cite midxunit.cpp:508-527 base addresses; the map is expressed
    // in 34020 BIT addresses (ROM 0xff000000-0xffffffff = 0x1000000 bits = 2 MiB,
    // exactly the maincpu region => bit-addressed, confirmed).
    logic [4:0] region;
    always_comb begin
        region = R_NONE;
        if      (mem_addr[31:22] == 10'd0)                          region = R_VRAMD;                 // 0x000000-0x3fffff
        else if (mem_addr[31:22] == 10'd2)                          region = R_VRAMC;                 // 0x800000-0xbfffff
        else if (mem_addr[31:24] == 8'h20)                          region = R_RAM;                   // 0x20000000-0x20ffffff
        else if (mem_addr[31:28] == 4'h4 && mem_addr[27:0] >= 28'h0800000) region = R_SYSC;           // 0x40800000-0x4fffffff
        else if (mem_addr[31:5]  == (32'h60400000 >> 5))            region = R_STATUS;                // 0x60400000-0x6040001f
        else if (mem_addr[31:8]  == 24'h60c000) begin
            unique case (mem_addr[7:5])
                3'd0: region = R_IN0;   // 0x60c00000
                3'd1: region = R_IN1;   // 0x60c00020
                3'd2: region = R_IN2;   // 0x60c00040
                3'd3: region = R_DSW;   // 0x60c00060
                3'd7: region = R_SEC;   // 0x60c000e0
                default: region = R_IO; // 0x60c00080/a0/c0 (io_w sel 0/1/2)
            endcase
        end
        else if (mem_addr[31:5]  == (32'h80800000 >> 5))            region = R_ADC;                   // 0x80800000-0x8080001f
        else if (mem_addr[31:8]  == 24'h80c000)                     region = R_UART;                  // 0x80c00000-0x80c000ff
        else if (mem_addr[31:18] == (32'ha0440000 >> 18))           region = R_CMOS;                  // 0xa0440000-0xa047ffff
        else if (mem_addr[31:20] == 12'ha08)                        region = R_PAL;                   // 0xa0800000-0xa08fffff
        else if (mem_addr[31:24] == 8'hc0 &&
                 (mem_addr[23:20] == 4'h8 || mem_addr[23:20] == 4'hc)) region = R_DMA;                // 0xc0800000 + mirror 0xc0c00000
        else if (mem_addr[31:24] >= 8'hf8 && mem_addr[31:24] <= 8'hfe) region = R_GFX;                // 0xf8000000-0xfeffffff
        else if (mem_addr[31:24] == 8'hff)                          region = R_ROM;                   // 0xff000000-0xffffffff
    end
    assign dbg_region = region;

    // ------------------------------------------------------------------ addressing
    // Bring-up model array sizes (real scratch/VRAM go to SDRAM; CMOS/PAL are full):
    //   ram  8192 x32  (real scratch 0x40000 words), pal 32768 (FULL, midxunit.cpp:667),
    //   nvram 8192 (FULL, LH5268), vram 16384 x16 (real VRAM 0x40000 words).
    wire [12:0] ram_idx_r  = mem_addr[17:5];             // 32-bit word within scratch
    wire [12:0] cmos_idx_r = mem_addr[17:5];             // CMOS byte = (addr-base)>>5, byte lane 0
    wire [2:0]  io_sel   = mem_addr[7:5] - 3'd4;         // io_w: 0x80->0 0xa0->1 0xc0->2
    wire [14:0] pal_idx_r  = mem_addr[19:5];             // palette entry = (addr-base)>>5 (32-bit stride)
    // VRAM: 16-bit words.  A 32-bit CPU access spans two 16-bit words {word0, word0+1}.
    wire [13:0] vram_i0_r  = mem_addr[18:5];             // low 16-bit word
    wire [13:0] vram_i1_r  = vram_i0_r + 1'b1;
    // IO_ONLY clamps every memory-array index to 0 (those regions are unreachable when the
    // top gates mem_req to the I/O windows) so a 1-entry array suffices.
    wire [12:0] ram_idx  = IO_ONLY ? 13'd0 : ram_idx_r;
    wire [12:0] cmos_idx = IO_ONLY ? 13'd0 : cmos_idx_r;
    wire [14:0] pal_idx  = IO_ONLY ? 15'd0 : pal_idx_r;
    wire [13:0] vram_i0  = IO_ONLY ? 14'd0 : vram_i0_r;
    wire [13:0] vram_i1  = IO_ONLY ? 14'd0 : vram_i1_r;

    // ------------------------------------------------------------------ behavioral region stores (bring-up)
    localparam int RAMN = IO_ONLY ? 1 : 8192;
    localparam int PALN = IO_ONLY ? 1 : 32768;
    localparam int NVRN = IO_ONLY ? 1 : 8192;
    localparam int VRMN = IO_ONLY ? 1 : 16384;
    logic [31:0] ram   [0:RAMN-1];
    logic [15:0] pal   [0:PALN-1];
    logic  [7:0] nvram  [0:NVRN-1];
    logic [15:0] vram  [0:VRMN-1];

    // ------------------------------------------------------------------ single-cycle handshake FSM
    // idle -> (mem_req) capture+access, assert mem_ack next clk with rdata.
    logic        busy;
    logic [31:0] rdata_q;
    logic        ack_q;

    // one-shot tap strobes (asserted the cycle the access is captured)
    logic        adc_wr_s, adc_rd_s, uart_wr_s, uart_rd_s;
    logic        pic_cmd_we_s, pic_clk_we_s, pic_resp_re_s;
    logic        dma_we_s, dma_rd_s, gfx_rd_s, rom_rd_s, wdog_s;

    assign adc_wr      = adc_wr_s;
    assign adc_rd      = adc_rd_s;
    assign uart_wr     = uart_wr_s;
    assign uart_rd     = uart_rd_s;
    assign pic_cmd_we  = pic_cmd_we_s;
    assign pic_clk_we  = pic_clk_we_s;
    assign pic_resp_re = pic_resp_re_s;
    assign dma_we      = dma_we_s;
    assign dma_rd      = dma_rd_s;
    assign gfx_rd      = gfx_rd_s;
    assign rom_rd      = rom_rd_s;
    assign watchdog_kick = wdog_s;

    // combinational tap payloads (valid with the strobe)
    assign adc_wdata  = mem_wdata[7:0];
    assign uart_reg   = mem_addr[7:5];
    assign uart_wdata = mem_wdata[7:0];
    assign pic_cmd    = mem_wdata[3:0];       // security_w: data & 0x0f
    assign pic_clk    = mem_wdata[1];         // security_clock_w: BIT(data,1)
    assign dma_pair   = mem_addr[7:5];
    assign dma_wdata  = mem_wdata;
    // gfx flat byte address = (addr - 0xf8000000)>>3 (14 MiB span 0xf8..0xfe).
    wire [26:0] gfx_off = {(mem_addr[31:24] - 8'hf8), mem_addr[23:0]};
    assign gfx_baddr  = gfx_off[26:3];
    assign rom_waddr  = mem_addr[23:5];       // (addr - 0xff000000)>>5

    assign mem_rdata  = rdata_q;
    assign mem_ack    = ack_q;

    integer i;
    always_ff @(posedge clk) begin
        // default de-assert one-shots
        adc_wr_s <= 1'b0; adc_rd_s <= 1'b0; uart_wr_s <= 1'b0; uart_rd_s <= 1'b0;
        pic_cmd_we_s <= 1'b0; pic_clk_we_s <= 1'b0; pic_resp_re_s <= 1'b0;
        dma_we_s <= 1'b0; dma_rd_s <= 1'b0; gfx_rd_s <= 1'b0; rom_rd_s <= 1'b0;
        wdog_s <= 1'b0;
        ack_q <= 1'b0;

        if (rst) begin
            busy <= 1'b0; rdata_q <= 32'd0;
            sysctrl0 <= 4'd0; sysctrl1 <= 4'd0;
            gun_recoil <= 3'd0; gun_led <= 3'd0;
        end
        else if (mem_req && !busy) begin
            busy   <= 1'b1;
            ack_q  <= 1'b1;                 // ack next cycle (single wait state)
            rdata_q <= 32'd0;

            // ---- WRITES --------------------------------------------------------
            if (mem_we) begin
                unique case (region)
                    // IO_ONLY=1 (emu): VRAM/RAM/CMOS/PAL are served by revx_backends / the
                    // top's palette; those addresses are never routed to this instance (the top
                    // gates mem_req to the I/O windows), so REMOVE the write path -- otherwise
                    // the residue 1-entry arrays synthesize as full-rate write endpoints in the
                    // CPU-request cone (vram[0]/ram[0]/nvram, -2.05..-2.29 ns).  IO_ONLY is a
                    // parameter constant, so `if (!IO_ONLY)` is folded and the endpoints vanish.
                    // The full behavioral model (IO_ONLY=0) is unchanged for the decode benches.
                    R_VRAMD, R_VRAMC: if (!IO_ONLY) begin
                        // midtunit_vram_data_w (midtunit_v.cpp:281-288): low word gets a
                        // DMA_PALETTE hi-byte fold in HW; bring-up model stores CPU data.
                        if (mem_be[0] || mem_be[1]) vram[vram_i0] <= mem_wdata[15:0];
                        if (mem_be[2] || mem_be[3]) vram[vram_i1] <= mem_wdata[31:16];
                    end
                    R_RAM: if (!IO_ONLY) begin
                        if (mem_be[0]) ram[ram_idx][ 7: 0] <= mem_wdata[ 7: 0];
                        if (mem_be[1]) ram[ram_idx][15: 8] <= mem_wdata[15: 8];
                        if (mem_be[2]) ram[ram_idx][23:16] <= mem_wdata[23:16];
                        if (mem_be[3]) ram[ram_idx][31:24] <= mem_wdata[31:24];
                    end
                    R_SYSC: begin
                        // unknown_w (midxunit.cpp:257-266): offs = offset/0x40000.
                        // offs = (addr-0x40800000)>>22.  offs0 -> latch0, offs1 -> latch1.
                        if (mem_be[0]) begin
                            if (mem_addr[22] == 1'b0) sysctrl0 <= mem_wdata[3:0]; // 0x40800000
                            else                      sysctrl1 <= mem_wdata[3:0]; // 0x40c00000
                        end
                    end
                    R_STATUS: pic_clk_we_s <= mem_be[0];   // security_clock_w (bit1)
                    R_IO: begin
                        // io_w (midxunit.cpp:225-253): case2=watchdog, default=gun outputs.
                        if (io_sel == 3'd2) wdog_s <= 1'b1;
                        else begin
                            gun_recoil <= mem_wdata[2:0];
                            gun_led    <= ~mem_wdata[6:4];
                        end
                    end
                    R_SEC: pic_cmd_we_s <= mem_be[0];      // security_w (data & 0x0f)
                    R_ADC: adc_wr_s <= mem_be[0];          // conversion start
                    R_UART: uart_wr_s <= mem_be[0];
                    // CMOS write is UNCONDITIONAL (midxunit.cpp:213-216 cmos_w). The asm's
                    // CMOSENAB latch (GXSYS.H:90, asm-intent only) is NOT what the L2.0 ROM
                    // does: warm-boot trace mame-gospel/io/warm_boot_io.log shows SYSCTRL0
                    // written 0x200 then 0x000 (bit 2 never set) while 328 CMOS writes land
                    // (io/warm_umask_wp.log) and the CMOS comes up valid. A bit-2 gate would
                    // factory-reset the cabinet every boot. REVX_CMOS_ENAB_GATE_MUTANT
                    // reintroduces that gate; tb_revx_mem_decode must FAIL with it.
                    R_CMOS: if (!IO_ONLY && mem_be[0]
`ifdef REVX_CMOS_ENAB_GATE_MUTANT
                                && cmos_write_enable
`endif
                               )
                                nvram[cmos_idx] <= mem_wdata[7:0];
                    R_PAL: if (!IO_ONLY) begin
                        // midxunit_paletteram_w (midtunit_v.cpp:403-407): store ONLY the
                        // low 16 bits (the even 16-bit unit); the high 16 bits (odd unit)
                        // are DROPPED -> the neighbour entry must be untouched.
                        pal[pal_idx] <= mem_wdata[15:0];
`ifdef REVX_PAL_STRIDE_MUTANT
                        // Deliberate gospel-misread the decode gate must KILL: also latch
                        // the high half into the next entry (breaks 32-bit-stride/low-16).
                        pal[pal_idx + 1'b1] <= mem_wdata[31:16];
`endif
                    end
                    R_DMA: dma_we_s <= 1'b1;
                    default: ; // ROM/GFX/IN* writes: ignored
                endcase
            end
            // ---- READS ---------------------------------------------------------
            else begin
                unique case (region)
                    // IO_ONLY=1: memory regions are unreachable at this instance (see the write
                    // note above); return 0 so no residue array is inferred at all.
                    R_VRAMD, R_VRAMC:
                        rdata_q <= IO_ONLY ? 32'd0 : {vram[vram_i1], vram[vram_i0]};
                    R_RAM:    rdata_q <= IO_ONLY ? 32'd0 : ram[ram_idx];
                    R_STATUS: rdata_q <= {30'd0, pic_status, adc_done};   // status_r (midxunit.cpp:285)
                    R_IN0:    rdata_q <= in0;
                    R_IN1:    rdata_q <= in1;
                    R_IN2:    rdata_q <= in2;
                    R_DSW:    rdata_q <= dsw;
                    R_SEC:    begin rdata_q <= {24'd0, pic_data}; pic_resp_re_s <= 1'b1; end // security_r
                    R_ADC:    begin rdata_q <= {24'd0, adc_rdata}; adc_rd_s <= 1'b1; end
                    R_UART:   begin rdata_q <= {24'd0, uart_rdata}; uart_rd_s <= 1'b1; end
                    R_CMOS:   rdata_q <= IO_ONLY ? 32'd0 : {24'd0, nvram[cmos_idx]};
                    R_PAL:    rdata_q <= IO_ONLY ? 32'd0 : {16'd0, pal[pal_idx]};
                    R_DMA:    begin rdata_q <= dma_rdata; dma_rd_s <= 1'b1; end
                    R_GFX:    begin rdata_q <= gfx_rdata; gfx_rd_s <= 1'b1; end
                    R_ROM:    begin rdata_q <= rom_rdata; rom_rd_s <= 1'b1; end
                    default:  rdata_q <= 32'd0;
                endcase
            end
        end
        else begin
            busy <= 1'b0;   // one wait state, then idle
        end
    end

    // P0020: dcs_reset (active-HIGH) = SYSCTRL1[1].  unknown_w (midxunit.cpp:262) calls
    // m_dcs->reset_w(~data & 2); dcs.cpp:1456-1471: state==0 -> INPUT_LINE_RESET ASSERT
    // (ADSP HALTED), state!=0 -> CLEAR (ADSP RUNS).  So the SND_RESET bit is data[1]:
    //   data[1]==1 -> reset_w(~2 & 2)=reset_w(0) -> HALT  -> dcs_reset=1
    //   data[1]==0 -> reset_w(~0 & 2)=reset_w(2) -> RUN   -> dcs_reset=0
    // The boot writes 40C00000=2 (halt, PC FFFDE300) then =0 (run, PC FFFDE390)
    // (mame-gospel/io/uart_dcs_stream.txt) => the DCS ends RUNNING.  The prior
    // `~sysctrl1[1]` was the exact inverse (run-then-halt).  (SND_RESET=2, GXSYS.H:96.)
    assign dcs_reset         = sysctrl1[1];
    assign cmos_write_enable = sysctrl0[2];   // CMOSENAB (GXSYS.H:90)

`ifdef REVX_MEM_INIT_ZERO
    initial begin
        for (i = 0; i < (1<<RAW); i = i + 1) ram[i]  = 32'd0;
        for (i = 0; i < (1<<PAW); i = i + 1) pal[i]  = 16'd0;
        for (i = 0; i < (1<<CAW); i = i + 1) nvram[i] = 8'd0;
        for (i = 0; i < (1<<VAW); i = i + 1) vram[i] = 16'd0;
    end
`endif

endmodule

`default_nettype wire
