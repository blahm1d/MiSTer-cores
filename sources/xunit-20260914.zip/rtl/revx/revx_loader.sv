// revx_loader.sv -- Midway X-unit (Revolution X) ioctl DOWNLOAD demux + P0022 capture audit.
//
// Consumes the MRA's concatenated index-0 byte stream (mra/Revolution X.mra, AUDIT.md s.3)
// and routes each region to its real destination, plus the index-3 profile byte and the
// index-4 CMOS/nvram audit.  Index-0 offsets (byte addresses in the ioctl stream):
//   0x0000000..0x01FFFFF  program ROM 2 MB   -> SDRAM program window (32-bit LE interleave
//                          already in the stream); packed here to the 16-bit MT48 word bus:
//                          SDRAM word = ROM_SDBASE + (baddr>>1), byte lane = baddr[0].
//   0x0200000..0x0FFFFFF  gfx ROM     14 MB  -> DDR3 gfx path (wolf_gfx_ddr_top, flat byte addr)
//   0x1000000..0x13FFFFF  DCS sound    4 MB  -> DCS ROM DDR window (wolf_dcs_ddr_top, packed)
//   0x1400000..0x1401FFF  PIC u444     8 KB  -> a small parked BRAM (the PIC adapter uses a
//                          response table for now; captured here for the future exchange)
//   index 3               profile byte 1 B   -> profile_byte / profile_valid
//   index 4               nvram        8 KB  -> passes straight through to the nvram bridge in
//                          revx_backends; audited (acc_nvram) here only.
//
// P0022 (CLAUDE.md s.6): the WHOLE capture path is domained on the POWER-ON reset (por, a
// 2-FF-synced ~pll_locked in revx_top), NOT the core reset, so ROM lands even with the core
// reset held HIGH across the entire download.  A reset-INDEPENDENT latch (rst_during_dl)
// records "core reset was high during a download" (it survives the core reset because cap_rst
// is por only), and per-destination accepted/dropped counters give the audit-overlay tell
// (accepted==0 AND dropped==0 == the destination was never offered a write -> upstream break).
//
// MUTANT REVX_DL_CORE_RESET folds the core reset into the capture domain -> the download is
// blocked while the core reset is held -> every accepted counter stays 0 -> the loader gate
// (sim/run_revx_loader.sh) MUST FAIL, proving the P0022 domain is load-bearing.

`default_nettype none
module revx_loader #(
  parameter int SD_AW = 21,                        // shared RAM/ROM SDRAM word-addr width
  parameter [SD_AW-1:0] ROM_SDBASE = 21'h100000,   // program ROM base in the MT48 word space (after 2 MiB RAM, midxunit.cpp:511)
  parameter [24:0] PROG_BASE  = 25'h0000000,
  parameter [24:0] PROG_BYTES = 25'h0200000,       // 2 MB
  parameter [24:0] GFX_BASE   = 25'h0200000,
  parameter [24:0] GFX_BYTES  = 25'h0E00000,       // 14 MB
  parameter [24:0] DCS_BASE   = 25'h1000000,
  parameter [24:0] DCS_BYTES  = 25'h0400000,       // 4 MB
  parameter [24:0] PIC_BASE   = 25'h1400000,
  parameter [24:0] PIC_BYTES  = 25'h0002000,       // 8 KB
  parameter [7:0]  MAIN_INDEX    = 8'd0,
  parameter [7:0]  PROFILE_INDEX = 8'd3,
  parameter [7:0]  NVRAM_INDEX   = 8'd4
)(
  input  logic        clk,
  input  logic        por,        // power-on reset (P0022 capture domain)
  input  logic        core_rst,   // core reset (audited only; NEVER gates capture in the clean design)

  // ---- hps_io ioctl download stream ----
  input  logic        ioctl_download,
  input  logic        ioctl_wr,
  input  logic  [7:0] ioctl_index,
  input  logic [24:0] ioctl_addr,
  input  logic  [7:0] ioctl_dout,

  // ---- program ROM -> revx_backends SDRAM boot-load port (16-bit word-packed) ----
  output logic            dl_wr,
  output logic [SD_AW-1:0] dl_addr,
  output logic [15:0]     dl_din,
  output logic  [1:0]     dl_be,
  input  logic            dl_ack,

  // ---- gfx -> revx_backends gfx DDR3 boot-copy port (byte, flat) ----
  output logic        gfx_dl_wr,
  output logic [24:0] gfx_dl_addr,
  output logic  [7:0] gfx_dl_data,
  input  logic        gfx_dl_ack,

  // ---- DCS -> wolf_dcs_ddr_top boot-copy port (byte, packed) ----
  output logic        dcs_dl_wr,
  output logic [22:0] dcs_dl_addr,
  output logic  [7:0] dcs_dl_data,
  input  logic        dcs_dl_ack,

  // ---- PIC parked BRAM read tap (future exchange / diag) ----
  input  logic [12:0] pic_rd_addr,
  output logic  [7:0] pic_rd_data,

  // ---- profile byte (index 3) ----
  output logic  [7:0] profile_byte,
  output logic        profile_valid,

  // ---- aggregate hps backpressure ----
  output logic        dl_wait,    // -> hps_io ioctl_wait (a destination cannot accept yet)
  output logic        dl_ready,   // capture path idle

  // ---- P0022 audit ----
  output logic [31:0] acc_prog, acc_gfx, acc_dcs, acc_pic, acc_nvram, acc_profile,
  output logic [31:0] drop_prog, drop_gfx, drop_dcs, drop_pic,
  output logic        rst_during_dl,

  // ---- sample taps (last accepted per destination) for the gate ----
  output logic [SD_AW-1:0] smp_prog_addr,
  output logic [15:0]      smp_prog_din,
  output logic  [1:0]      smp_prog_be,
  output logic [24:0]      smp_gfx_addr,
  output logic  [7:0]      smp_gfx_data,
  output logic [22:0]      smp_dcs_addr,
  output logic  [7:0]      smp_dcs_data
);
  // ------------------------------------------------------------------ capture reset domain
`ifdef REVX_DL_CORE_RESET
  wire cap_rst = por | core_rst;   // MUTANT: capture on the core reset -> blocked while held
`else
  wire cap_rst = por;              // correct P0022 domain (power-on only)
`endif

  // ------------------------------------------------------------------ region classify
  wire is_main    = ioctl_download & (ioctl_index == MAIN_INDEX);
  wire is_profile = ioctl_download & (ioctl_index == PROFILE_INDEX);
  wire is_nvram   = ioctl_download & (ioctl_index == NVRAM_INDEX);
  wire sel_prog = is_main & (ioctl_addr >= PROG_BASE) & (ioctl_addr < (PROG_BASE + PROG_BYTES));
  wire sel_gfx  = is_main & (ioctl_addr >= GFX_BASE ) & (ioctl_addr < (GFX_BASE  + GFX_BYTES ));
  wire sel_dcs  = is_main & (ioctl_addr >= DCS_BASE ) & (ioctl_addr < (DCS_BASE  + DCS_BYTES ));
  wire sel_pic  = is_main & (ioctl_addr >= PIC_BASE ) & (ioctl_addr < (PIC_BASE  + PIC_BYTES ));

  // region-relative byte addresses
  wire [24:0] prog_baddr = ioctl_addr - PROG_BASE;
  wire [24:0] gfx_baddr  = ioctl_addr - GFX_BASE;
  wire [24:0] dcs_baddr  = ioctl_addr - DCS_BASE;
  wire [24:0] pic_baddr  = ioctl_addr - PIC_BASE;
  // program ROM 16-bit word-pack (32-bit LE interleave already in the stream)
  wire [SD_AW-1:0] prog_word = ROM_SDBASE + prog_baddr[SD_AW:1];

  // ------------------------------------------------------------------ write-edge detect
  logic ioctl_wr_d;
  wire  wr_edge = ioctl_wr & ~ioctl_wr_d;

  // ------------------------------------------------------------------ per-destination busy
  logic prog_busy, gfx_busy, dcs_busy;
  assign dl_wait  = prog_busy | gfx_busy | dcs_busy;
  assign dl_ready = ~dl_wait;

  // ------------------------------------------------------------------ program-ROM word assembly
  // DIAG v3 (cabinet-4 write-mask class): assemble FULL 16-bit words for the program image so the
  // download does NOT depend on the SDRAM write byte mask.  The EVEN byte is held here; the ODD
  // byte issues {odd,even} with be=11.  A dangling even byte at download end is flushed be=01.
  logic  [7:0]      prog_hold_data;
  logic [SD_AW-1:0] prog_hold_addr;
  logic             prog_hold_valid;
  logic             ioctl_dl_d;                    // download-level delay -> falling-edge detect

  // ------------------------------------------------------------------ PIC parked BRAM (8 KB)
  // The parked PIC tap follows the same one-clock read contract as the palette.
  // Storage runs independently of the core reset; only por gates capture (P0022).
  revx_palram #(.DW(8), .AW(13)) u_pic (
    .clk(clk), .we_a(!cap_rst && wr_edge && sel_pic),
    .addr_a(pic_baddr[12:0]), .wd_a(ioctl_dout), .rd_a(),
    .addr_b(pic_rd_addr), .rd_b(pic_rd_data));

  always_ff @(posedge clk) begin
    if (cap_rst) begin
      ioctl_wr_d <= 1'b0; ioctl_dl_d <= 1'b0;
      dl_wr <= 1'b0; gfx_dl_wr <= 1'b0; dcs_dl_wr <= 1'b0;
      prog_busy <= 1'b0; gfx_busy <= 1'b0; dcs_busy <= 1'b0;
      prog_hold_data <= 8'd0; prog_hold_addr <= '0; prog_hold_valid <= 1'b0;
      profile_byte <= 8'd0; profile_valid <= 1'b0;
      acc_prog <= 0; acc_gfx <= 0; acc_dcs <= 0; acc_pic <= 0; acc_nvram <= 0; acc_profile <= 0;
      drop_prog <= 0; drop_gfx <= 0; drop_dcs <= 0; drop_pic <= 0;
      rst_during_dl <= 1'b0;
      smp_prog_addr <= '0; smp_prog_din <= '0; smp_prog_be <= '0;
      smp_gfx_addr <= '0; smp_gfx_data <= '0; smp_dcs_addr <= '0; smp_dcs_data <= '0;
    end else begin
      ioctl_wr_d <= ioctl_wr;
      ioctl_dl_d <= ioctl_download;

      // reset-independent audit latch: a download overlapped the (held) core reset
      if (ioctl_download & core_rst) rst_during_dl <= 1'b1;

      // -------- program ROM: assemble FULL 16-bit words (be=11), hold dl_wr until dl_ack --------
      // EVEN byte -> hold; ODD byte -> write {odd,even} be=11; dangling even at download end -> be=01.
      if (prog_busy) begin
        if (dl_ack) begin dl_wr <= 1'b0; prog_busy <= 1'b0; end
      end else begin
        dl_wr <= 1'b0;
        if (wr_edge & sel_prog) begin
          acc_prog <= acc_prog + 1;                    // count every program BYTE (overlay-comparable)
          if (!prog_baddr[0]) begin
            prog_hold_data  <= ioctl_dout;             // even byte: hold for its word partner
            prog_hold_addr  <= prog_word;
            prog_hold_valid <= 1'b1;
          end else begin
`ifdef REVX_LOADER_LANE_SWAP
            // MUTANT: swap the byte lanes (even<->odd) -> the SDRAM word carries {even,odd}
            // instead of {odd,even} -> the loader gate's byte-stream reconstruction MUST fail.
            dl_din <= {prog_hold_data, ioctl_dout};
            smp_prog_din <= {prog_hold_data, ioctl_dout};
`else
            dl_din <= {ioctl_dout, prog_hold_data};    // {odd -> high lane, even -> low lane}
            smp_prog_din <= {ioctl_dout, prog_hold_data};
`endif
            dl_addr <= prog_word;                       // == prog_hold_addr (same word)
            dl_be   <= 2'b11;
            dl_wr   <= 1'b1; prog_busy <= 1'b1;
            prog_hold_valid <= 1'b0;
            smp_prog_addr <= prog_word; smp_prog_be <= 2'b11;
          end
        end else if (prog_hold_valid & ioctl_dl_d & ~ioctl_download) begin
          // odd-length tail: download ended with a held even byte -> flush it as a lone low-lane write.
          dl_addr <= prog_hold_addr;
          dl_din  <= {prog_hold_data, prog_hold_data};
          dl_be   <= 2'b01;
          dl_wr   <= 1'b1; prog_busy <= 1'b1;
          prog_hold_valid <= 1'b0;
          smp_prog_addr <= prog_hold_addr; smp_prog_din <= {prog_hold_data, prog_hold_data}; smp_prog_be <= 2'b01;
        end
      end
      if (wr_edge & sel_prog & prog_busy) drop_prog <= drop_prog + 1;

      // -------- gfx ROM (hold gfx_dl_wr until gfx_dl_ack) --------
      if (gfx_busy) begin
        if (gfx_dl_ack) begin gfx_dl_wr <= 1'b0; gfx_busy <= 1'b0; end
      end else begin
        gfx_dl_wr <= 1'b0;
        if (wr_edge & sel_gfx) begin
          gfx_dl_addr <= gfx_baddr; gfx_dl_data <= ioctl_dout;
          gfx_dl_wr <= 1'b1; gfx_busy <= 1'b1;
          acc_gfx <= acc_gfx + 1;
          smp_gfx_addr <= gfx_baddr; smp_gfx_data <= ioctl_dout;
        end
      end
      if (wr_edge & sel_gfx & gfx_busy) drop_gfx <= drop_gfx + 1;

      // -------- DCS ROM (hold dcs_dl_wr until dcs_dl_ack) --------
      if (dcs_busy) begin
        if (dcs_dl_ack) begin dcs_dl_wr <= 1'b0; dcs_busy <= 1'b0; end
      end else begin
        dcs_dl_wr <= 1'b0;
        if (wr_edge & sel_dcs) begin
          dcs_dl_addr <= dcs_baddr[22:0]; dcs_dl_data <= ioctl_dout;
          dcs_dl_wr <= 1'b1; dcs_busy <= 1'b1;
          acc_dcs <= acc_dcs + 1;
          smp_dcs_addr <= dcs_baddr[22:0]; smp_dcs_data <= ioctl_dout;
        end
      end
      if (wr_edge & sel_dcs & dcs_busy) drop_dcs <= drop_dcs + 1;

      // -------- PIC parked BRAM (single-cycle write, never busy) --------
      if (wr_edge & sel_pic) begin
        acc_pic <= acc_pic + 1;
      end

      // -------- profile byte (index 3, offset 0) --------
      if (wr_edge & is_profile & (ioctl_addr == 25'd0)) begin
        profile_byte <= ioctl_dout; profile_valid <= 1'b1; acc_profile <= acc_profile + 1;
      end

      // -------- nvram audit (index 4, routed by revx_backends' bridge) --------
      if (wr_edge & is_nvram) acc_nvram <= acc_nvram + 1;
    end
  end
endmodule
`default_nettype wire
