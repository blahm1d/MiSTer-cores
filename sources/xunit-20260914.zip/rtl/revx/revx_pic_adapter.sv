// revx_pic_adapter.sv -- Revolution X security PIC (PIC16C57 u444) host adapter.
//
// Behavioral implementation of the X-unit boot security commands.  The X-unit
// runs a REAL PIC16C57 (u444, midxunit.cpp:169,674-679), NOT the midway_serial_pic
// C++ model that rtl/wolf/wolf_pic.sv transcribes -- and its host protocol is
// DIFFERENT from the Wolf/T/W board (measured; see mame-gospel/io/pic_exchange.txt).
// wolf_pic makes status MIRROR the clock bit and clocks the byte out on the clock
// LOW edge; the real u444 drives status as the INVERSE of the clock (a ready/ack
// handshake) and presents the byte on the clock HIGH edge.  Wrapping wolf_pic
// therefore times out the ROM's "wait status->0" loop.  This adapter is a dedicated
// FSM; wolf_pic is left untouched (Wolf/Y-unit stay bit-identical).
//
// CPU-side taps (midxunit.cpp), driven by revx_mem:
//   security_w       @0x60C000E0 (:461-465) -> m_pic_command = data & 0x0f   (cmd_we/cmd_nibble)
//   security_clock_w @0x60400000 (:468-472) -> m_pic_clk     = BIT(data,1)   (clk_we/clk_bit)
//   security_r       @0x60C000E0 (:456-459) -> m_pic_data                    (pic_data)
//   status_r         @0x60400000 (:282-285) -> (m_pic_status<<1)|adc         (pic_status -> bit1)
//
// L2.0 PICCHECK at FFFE8B90 first writes command F and requires reply 0F at
// FFFE8EA0.  This MUST precede the command-0 exchange in the game gate.  The
// previous table-only adapter replied 45 here and failed before reading the key.
// Source intent: revolution-x/GXDTST.ASM:2433-2464; ROM CPU execution is the oracle.
// Command-0 protocol (ROM FFFDEED0-FFFE0170; capture in pic_exchange.txt):
//   * CPU writes command 0x0 once; command 0 RESETS the response pointer to byte 0.
//   * per byte: CPU raises clock (write 2) -> PIC presents table[idx], status->0;
//               CPU reads the byte; CPU lowers clock (write 0) -> status->1, idx++.
//   * 16-byte circular response (wraps mod 16).  The boot check reads exactly 16.
// The 16 bytes below are the real u444 response, captured from MAME 0.289's PIC and
// independently captured from u444.  A matching table test alone is insufficient:
// sim/run_revx_security_game.py executes PICCHECK and the ROM's complete read/decode
// routine, requiring A2=419/420 and the game's flag@2051FA80=0.

`default_nettype none

module revx_pic_adapter #(
    // Real u444 command-0 response, byte 0 in bits [7:0]
    // (45 C4 02 FB 8E 47 17 22 1A 1D 14 F4 AF 1C 9A E8).
    parameter logic [127:0] RESPONSE_BYTES =
        128'hE89A_1CAF_F414_1D1A_2217_478E_FB02_C445
)(
    input  logic       clk,
    input  logic       rst,

    // ---- X-unit host taps (from revx_mem) ----
    input  logic       cmd_we,       // security_w write strobe
    input  logic [3:0] cmd_nibble,   // security_w data & 0x0f
    input  logic       clk_we,       // security_clock_w write strobe
    input  logic       clk_bit,      // security_clock_w BIT(data,1)
    input  logic       resp_re,      // security_r read strobe (no status side effect on the real u444)
    input  logic       pic_reset,    // active-HIGH device reset (tied inactive; P0020)

    output logic [7:0] pic_data,     // -> security_r result
    output logic       pic_status    // -> status_r bit1
);
    // 16-entry response ROM, indexed mod 16.
    function automatic logic [7:0] pic_byte(input logic [3:0] a);
        case (a)
            4'h0: pic_byte = RESPONSE_BYTES[  7:  0];
            4'h1: pic_byte = RESPONSE_BYTES[ 15:  8];
            4'h2: pic_byte = RESPONSE_BYTES[ 23: 16];
            4'h3: pic_byte = RESPONSE_BYTES[ 31: 24];
            4'h4: pic_byte = RESPONSE_BYTES[ 39: 32];
            4'h5: pic_byte = RESPONSE_BYTES[ 47: 40];
            4'h6: pic_byte = RESPONSE_BYTES[ 55: 48];
            4'h7: pic_byte = RESPONSE_BYTES[ 63: 56];
            4'h8: pic_byte = RESPONSE_BYTES[ 71: 64];
            4'h9: pic_byte = RESPONSE_BYTES[ 79: 72];
            4'hA: pic_byte = RESPONSE_BYTES[ 87: 80];
            4'hB: pic_byte = RESPONSE_BYTES[ 95: 88];
            4'hC: pic_byte = RESPONSE_BYTES[103: 96];
            4'hD: pic_byte = RESPONSE_BYTES[111:104];
            4'hE: pic_byte = RESPONSE_BYTES[119:112];
            default: pic_byte = RESPONSE_BYTES[127:120];
        endcase
    endfunction

    logic [3:0] idx;        // response pointer (mod 16, 4-bit wrap)
    logic       stat;       // m_pic_status: 1 = ready/idle, 0 = byte presented
    logic       clk_prev;   // last written clock bit (edge detect)
    logic       echo_command; // command F: PICCHECK presence challenge

    always_ff @(posedge clk) begin
        if (rst || pic_reset) begin
            idx      <= 4'd0;
            echo_command <= 1'b0;
            // MAME initializes m_pic_status to zero.  FFFDE060 samples bit 30,
            // not this security bit; the old "skip security" explanation was wrong.
            stat     <= 1'b0;
            clk_prev <= 1'b0;
        end
        else begin
            // command 0 write resets the response pointer (measured; real u444).
            if (cmd_we && (cmd_nibble == 4'd0)) begin
                idx  <= 4'd0;
                stat <= 1'b1;
                echo_command <= 1'b0;
            end
`ifndef REVX_PIC_MUT_NO_ECHO
            // PICCHECK requires the command-F echo before allowing the key read.
            if (cmd_we && (cmd_nibble == 4'hf)) begin
                echo_command <= 1'b1;
                stat <= 1'b1;
            end
`endif
            // clock edges drive the ready/ack handshake.
            if (clk_we) begin
                clk_prev <= clk_bit;
                if (clk_bit && !clk_prev) begin
                    // rising edge: present table[idx], drop status (byte ready)
                    stat <= 1'b0;
                end
                else if (!clk_bit && clk_prev) begin
                    // falling edge: raise status (ready), advance to next byte
                    stat <= 1'b1;
                    if (!echo_command) idx <= idx + 4'd1;
                end
            end
        end
    end

    // table[idx] is stable across the clock-high read window (idx advances only on
    // the falling edge, after the CPU has read), so a combinational read is exact.
`ifdef REVX_PIC_MUT_GAME_ID
    // Corrupt a key byte enough to change the game's integer decode.  The older
    // byte-7 XOR-1 mutant tests byte equality but can be rounded away by the ROM.
    assign pic_data = echo_command ? 8'h0f :
                      ((idx == 4'h6) ? (pic_byte(4'h6) ^ 8'h80) : pic_byte(idx));
`elsif REVX_PIC_MUT_BYTE
    // MUTANT (wrong response byte): corrupt byte index 7 (0x22 -> 0x23).
    assign pic_data = echo_command ? 8'h0f :
                      ((idx == 4'h7) ? (pic_byte(4'h7) ^ 8'h01) : pic_byte(idx));
`else
    assign pic_data = echo_command ? 8'h0f : pic_byte(idx);
`endif

`ifdef REVX_PIC_MUT_STATUS_INV
    // MUTANT (status bit inverted): breaks the ready/ack handshake polarity.
    assign pic_status = ~stat;
`else
    assign pic_status = stat;
`endif

    // resp_re unused: the real u444 does not toggle status on a data read (measured).
    wire _unused_resp_re = resp_re;
endmodule

`default_nettype wire
