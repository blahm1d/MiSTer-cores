// revx_uart.sv -- Revolution X host-side UART (SCC2691 glue to the DCS sound board).
//
// Transcribed from MAME 0.289 src/mame/williams/midxunit.cpp:296-400:
//   uart_r  (304-371) : reg0=0x13 self-test; reg1/reg5 status; reg3 data; else raw.
//   uart_w  (374-400) : reg3 -> DCS data_w (or loopback store); reg5 -> DCS data_r
//                       reset; else store the register.
//   dcs_output_full (296-301): assert CPU LINT1 from DCS output-full ONLY when NOT
//                              in loopback (m_uart[1] != 0x66).
// Loopback is selected by writing 0x66 to register 1 (m_uart[1]==0x66), in which
// case reg3 feeds back the last byte written and the status regs report ready.
//
// Host taps come from revx_mem @0x80c00000 (8 regs, byte lane 0, midxunit.cpp:522).
// The DCS side wires to revx_dcs2k (data_w/data_r/control_r + output-full line).

`default_nettype none

module revx_uart (
    input  logic        clk,
    input  logic        rst,

    // ---- host bus taps (from revx_mem) --------------------------------------
    input  logic        uart_wr,
    input  logic        uart_rd,
    input  logic  [2:0] uart_reg,
    input  logic  [7:0] uart_wdata,
    output logic  [7:0] uart_rdata,

    // ---- DCS side -----------------------------------------------------------
    input  logic [15:0] dcs_ctrl,        // dcs.control_r()
    input  logic  [7:0] dcs_data_in,     // dcs.data_r() value (non-loopback reg3)
    output logic        dcs_data_w,      // strobe: dcs.data_w(dcs_data_o)
    output logic  [7:0] dcs_data_o,
    output logic        dcs_data_rd,     // strobe: dcs.data_r() consume/reset
    input  logic        dcs_output_full, // DCS output-full line
    output logic        lint1            // -> CPU LINT1
);
    logic [7:0] uart [0:7];              // m_uart[8]
    wire        loopback = (uart[1] == 8'h66);

    // ---- reads (uart_r) -----------------------------------------------------
    always_comb begin
        case (uart_reg)
            3'd0: uart_rdata = 8'h13;                                   // self-test
            3'd1: uart_rdata = loopback ? 8'h05
                              : (((dcs_ctrl & 16'h0800) >> 9) | ((~dcs_ctrl & 16'h0400) >> 10));
            3'd3: uart_rdata = loopback ? uart[3] : dcs_data_in;
            3'd5: uart_rdata = loopback ? 8'h05
                              : (((dcs_ctrl & 16'h0800) >> 11) | ((~dcs_ctrl & 16'h0400) >> 8));
            default: uart_rdata = uart[uart_reg];
        endcase
    end

    // ---- DCS strobes (side effects of the non-loopback data path) -----------
    assign dcs_data_w  = uart_wr && (uart_reg == 3'd3) && !loopback;    // uart_w reg3 -> data_w
    assign dcs_data_o  = uart_wdata;
    assign dcs_data_rd = (uart_rd && (uart_reg == 3'd3) && !loopback)   // uart_r reg3 -> data_r
                       || (uart_wr && (uart_reg == 3'd5));              // uart_w reg5 -> data_r reset

    // ---- writes (uart_w) + LINT1 --------------------------------------------
    integer i;
    always_ff @(posedge clk) begin
        if (rst) begin
            for (i = 0; i < 8; i = i + 1) uart[i] <= 8'h00;
            lint1 <= 1'b0;
        end
        else begin
            if (uart_wr) begin
                case (uart_reg)
                    3'd3: if (loopback) uart[3] <= uart_wdata;          // loopback store; else data_w (strobe)
                    3'd5: ;                                              // data_r reset (strobe); no store
                    default: uart[uart_reg] <= uart_wdata;
                endcase
            end
            // dcs_output_full drives LINT1 only when NOT in loopback (midxunit.cpp:299)
            if (!loopback) lint1 <= dcs_output_full;
        end
    end
endmodule

`default_nettype wire
