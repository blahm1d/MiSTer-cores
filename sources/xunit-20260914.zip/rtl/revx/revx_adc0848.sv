// revx_adc0848.sv -- ADC0848 8-bit A/D + 8-channel multiplexer (Revolution X pots).
//
// Transcribed from MAME 0.289 src/devices/machine/adc0844.cpp (the ADC0848 is the
// 8-channel variant, adc0848_device):
//   write(data)          adc0844.cpp:183-190  channel=data&0x1f; start 40us conv; intr CLEAR
//   read()               adc0844.cpp:167-172  intr CLEAR; return m_result
//   conversion_complete  adc0844.cpp:117-160  per-channel result table (0848), intr ASSERT
//   clamp(v)             adc0844.cpp:74-82    0..255 saturation
// The device is wired in midxunit.cpp:681-688: ch1..ch6 <- AN0..AN5 (ch7/ch8 float
// => the device default 0xff, adc0844.cpp:34,52).  The game READ_POT writes channel
// codes 0x08..0x0d (single-ended ch1..ch6, GXCONTRL.ASM:3253-3259/3284), so the
// single-ended path (0x08..0x0f) is the reachable one; the differential and pseudo-
// differential codes are transcribed verbatim for fidelity (never weaken the oracle).
//
// The ADC "done" (intr ASSERT) is the game's B_A2D poll bit -> status_r bit0
// (midxunit.cpp:285 (m_pic_status<<1)|m_adc_int; GXSYS.H:126 B_A2D=0).

`default_nettype none

module revx_adc0848 #(
    // Conversion latency in clk cycles (real device = 40 us; adc0844.cpp:180,189).
    // Settable so a TB can poll it quickly; the top sets the real 40us-at-clk value.
    parameter int CONV_CLKS = 16
)(
    input  logic       clk,
    input  logic       rst,

    // host bus taps (from revx_mem @0x80800000, byte lane 0)
    input  logic       wr,           // write() : latch channel, start conversion
    input  logic [7:0] wdata,        // data (channel = data & 0x1f)
    input  logic       rd,           // read()  : clears intr, returns result

    // six analog inputs (ch1..ch6 <- AN0..AN5)
    input  logic [7:0] an0,          // ch1
    input  logic [7:0] an1,          // ch2
    input  logic [7:0] an2,          // ch3
    input  logic [7:0] an3,          // ch4
    input  logic [7:0] an4,          // ch5
    input  logic [7:0] an5,          // ch6

    output logic [7:0] result,       // m_result (-> revx_mem adc_rdata)
    output logic       done          // m_adc_int (-> status_r bit0)
);
    // channel inputs (ch7/ch8 unconnected -> 0xff default, adc0844.cpp:34,52)
    wire [7:0] ch1 = an0, ch2 = an1, ch3 = an2, ch4 = an3;
    wire [7:0] ch5 = an4, ch6 = an5, ch7 = 8'hff, ch8 = 8'hff;

    // clamp(v): 0..255 saturation (adc0844.cpp:74-82)
    function automatic [7:0] clamp(input signed [10:0] v);
        if (v > 11'sd255)      clamp = 8'hff;
        else if (v < 11'sd0)   clamp = 8'h00;
        else                   clamp = v[7:0];
    endfunction

    // adc0848_device::conversion_complete (adc0844.cpp:117-160)
    function automatic [7:0] convert(input [4:0] chan);
        case (chan)
            // differential
            5'h00,5'h10: convert = clamp(11'sd255 - ($signed({3'b0,ch2}) - $signed({3'b0,ch1})));
            5'h01,5'h11: convert = clamp(11'sd255 - ($signed({3'b0,ch1}) - $signed({3'b0,ch2})));
            5'h02,5'h12: convert = clamp(11'sd255 - ($signed({3'b0,ch4}) - $signed({3'b0,ch3})));
            5'h03,5'h13: convert = clamp(11'sd255 - ($signed({3'b0,ch3}) - $signed({3'b0,ch4})));
            5'h04,5'h14: convert = clamp(11'sd255 - ($signed({3'b0,ch6}) - $signed({3'b0,ch5})));
            5'h05,5'h15: convert = clamp(11'sd255 - ($signed({3'b0,ch5}) - $signed({3'b0,ch6})));
            5'h06,5'h16: convert = clamp(11'sd255 - ($signed({3'b0,ch8}) - $signed({3'b0,ch7})));
            5'h07,5'h17: convert = clamp(11'sd255 - ($signed({3'b0,ch7}) - $signed({3'b0,ch8})));
            // single-ended (the reachable path for RevX: 0x08..0x0d)
            5'h08: convert = ch1;
            5'h09: convert = ch2;
            5'h0a: convert = ch3;
            5'h0b: convert = ch4;
            5'h0c: convert = ch5;
            5'h0d: convert = ch6;
            5'h0e: convert = ch7;
            5'h0f: convert = ch8;
            // pseudo-differential
            5'h18: convert = clamp(11'sd255 - ($signed({3'b0,ch8}) - $signed({3'b0,ch1})));
            5'h19: convert = clamp(11'sd255 - ($signed({3'b0,ch8}) - $signed({3'b0,ch2})));
            5'h1a: convert = clamp(11'sd255 - ($signed({3'b0,ch8}) - $signed({3'b0,ch3})));
            5'h1b: convert = clamp(11'sd255 - ($signed({3'b0,ch8}) - $signed({3'b0,ch4})));
            5'h1c: convert = clamp(11'sd255 - ($signed({3'b0,ch8}) - $signed({3'b0,ch5})));
            5'h1d: convert = clamp(11'sd255 - ($signed({3'b0,ch8}) - $signed({3'b0,ch6})));
            5'h1e: convert = clamp(11'sd255 - ($signed({3'b0,ch8}) - $signed({3'b0,ch7})));
            default: convert = 8'h00;   // 5'h1f undefined (adc0844.cpp:156)
        endcase
    endfunction

    logic [4:0]  channel;
    logic [31:0] timer;
    logic        converting;

    always_ff @(posedge clk) begin
        if (rst) begin
            channel <= 5'h0f; result <= 8'hff; done <= 1'b0;
            timer <= 32'd0; converting <= 1'b0;
        end
        else begin
            // write(): start conversion, clear intr (adc0844.cpp:183-190)
            if (wr) begin
                channel    <= wdata[4:0];
                done       <= 1'b0;
                timer      <= CONV_CLKS[31:0];
                converting <= 1'b1;
            end
            else if (converting) begin
                if (timer <= 32'd1) begin
                    converting <= 1'b0;
                    result     <= convert(channel);   // conversion_complete
                    done       <= 1'b1;               // intr ASSERT
                end else begin
                    timer <= timer - 32'd1;
                end
            end
            // read(): clears intr (adc0844.cpp:167-172).  Loses to a same-cycle wr.
            if (rd && !wr) done <= 1'b0;
        end
    end
endmodule

`default_nettype wire
