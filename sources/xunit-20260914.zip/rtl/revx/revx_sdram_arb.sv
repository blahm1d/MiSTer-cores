// revx_sdram_arb.sv -- Midway X-unit: share ONE 16-bit MT48 SDRAM channel between
// EVERY SDRAM requester: the video SCANOUT reader (s), the boot-load byte-stream
// writer (dl), the main-RAM word engine (a), the program-ROM word engine (b) and
// the two VRAM word engines -- data (vd) and colour (vc).  This is the "unified
// SDRAM path" of the BOARD lane step 3 (a): the X-unit has ONE MT48LC16M16 for
// program ROM + main scratch RAM + VRAM data + VRAM colour (HANDOFF "main RAM and
// program ROM ... on the SDRAM path"; VRAM/RAM/ROM all fold onto it here), fed by
// the real controller rtl/sdram/sdram.sv in synth and the behavioral sdram_model
// in sim (both honour the req-held-until-ack + edge-accept contract).
//
// Structural fork of rtl/sdram/yunit_sdram_arb.sv (grant-held, req-held-until-ack)
// -- the arbiter wolf_top.sv:731 instantiates.  PRIORITY = Wolf's proven ordering
// (yunit_sdram_arb.sv:131-139, "boot IOL > VRAM(real-time scanout) > CPU gfx/ROM >
// main RAM > blitter src ... RAM sits below scanout so it can't starve the real-time
// video"): here  DL(boot) > S(scanout) > RB(CPU fetch burst fill) > A(RAM) > B(ROM)
// > VD > VC > WB.  The SCANOUT reader therefore always beats the CPU (a/b/rb) AND the
// blitter-style VRAM writes (vd/vc/wb), so the raster never starves (task 3a).  Each
// master presents an ABSOLUTE SDRAM word address (the word engines add their region
// BASE), so the arb only muxes.
//
// PERF (RevX wide fetch lane, 2026-09-09): master RB is a held burst READ (1..16
// consecutive words, one ACTIVE in the PHY), fed by the CPU line-fill engine.  RB
// outranks the single-word A/B data engines because a fetch-fill miss stalls the
// CPU either way; finishing the fill first shortens the stall.  wb (SRT chunk
// write) and rb are never pending simultaneously (both are CPU stalls on the one
// FSM), so their relative order is unobservable; wb keeps its existing tail slot.
//
// MUTANT REVX_ARB_NO_SCAN_PRIO drops the scanout to LOWEST priority -- under a
// saturating CPU+blitter load the scanout then never wins -> its line FIFO drains
// -> the tb_revx_sdram_unified underflow check FAILS (proves scanout priority is
// load-bearing).  The arb itself is otherwise unchanged (never weakens the gate).

`timescale 1ns/1ps
`default_nettype none
// DMA framebuffer writes share only the physical VRAM word channel with CPU
// VRAM traffic. They must not occupy the CPU's RAM/ROM/cache backend while a
// pixel waits for SDRAM. Completion still means the physical write committed.
module revx_vram_write_mux #(parameter int AW = 19)(
  input logic clk, rst,
  input logic cpu_reserve,
  input logic [AW-1:0] cpu_addr,
  input logic [15:0] cpu_data,
  input logic [1:0] cpu_be,
  input logic cpu_rd, cpu_wr,
  output logic cpu_ack,
  input logic dma_req,
  input logic [AW-1:0] dma_addr,
  input logic [15:0] dma_data,
  input logic [2:0] dma_count, input logic [63:0] dma_words, input logic dma_reverse,
  output logic dma_ack,
  output logic dma_claimed,
  output logic [AW-1:0] addr,
  output logic [15:0] data,
  output logic [1:0] be,
  output logic rd, wr,
  input logic ack,
  output logic [2:0] count, output logic [63:0] words, output logic reverse
);
  typedef enum logic [1:0] {V_IDLE, V_CPU, V_DMA, V_DRAIN} state_t;
  state_t state;
  logic dma_seen;
  logic [AW-1:0] dma_addr_q;
  logic [15:0] dma_data_q;
  logic [2:0] dma_count_q; logic [63:0] dma_words_q; logic dma_reverse_q;
  wire dma_group = (dma_count === 3'd2) || (dma_count === 3'd3) || (dma_count === 3'd4);
  assign count = state == V_DMA ? dma_count_q : 3'd1;
  assign words = state == V_DMA ? dma_words_q : {48'd0,cpu_data};
  assign reverse = state == V_DMA && dma_reverse_q;
  assign addr = state == V_DMA ? dma_addr_q : cpu_addr;
  assign data = state == V_DMA ? dma_data_q : cpu_data;
  assign be = state == V_DMA ? 2'b11 : cpu_be;
  assign rd = state == V_CPU && cpu_rd;
  assign wr = (state == V_CPU && cpu_wr) || state == V_DMA;
  assign cpu_ack = state == V_CPU && ack;
  assign dma_ack = state == V_DMA && ack;
  assign dma_claimed = state == V_DMA;
  always_ff @(posedge clk) begin
    if (rst) begin
      state <= V_IDLE; dma_seen <= 1'b0;
      dma_addr_q <= '0; dma_data_q <= '0; dma_count_q <= 1; dma_words_q <= 0; dma_reverse_q <= 0;
    end else begin
      if (!dma_req) dma_seen <= 1'b0;
      case (state)
        V_IDLE: if (!ack) begin
          if (cpu_rd || cpu_wr) state <= V_CPU;
          else if (dma_req && !dma_seen && !cpu_reserve) begin
            dma_addr_q <= dma_addr; dma_data_q <= dma_data;
            dma_count_q <= dma_group ? dma_count : 3'd1;
            dma_words_q <= dma_group ? dma_words : {48'd0,dma_data};
            dma_reverse_q <= dma_group && (dma_reverse === 1'b1);
            dma_seen <= 1'b1; state <= V_DMA;
          end
        end
        V_CPU, V_DMA: if (ack) state <= V_DRAIN;
        V_DRAIN: if (!ack) state <= V_IDLE;
        default: state <= V_IDLE;
      endcase
    end
  end
endmodule

// Registered read-chunk ownership. Priority applies only when idle; a later
// high-priority request cannot steal an in-flight response from the other port.
// Payload/owner are full-rate registers. One drain cycle separates transactions.
module revx_read_chunk_mux #(parameter int AW = 22)(
  input logic clk, rst,
  input logic a_req, input logic [AW-1:0] a_addr, input logic [4:0] a_count,
  output logic [255:0] a_data, output logic a_ack,
  input logic b_req, input logic [AW-1:0] b_addr, input logic [4:0] b_count,
  output logic [255:0] b_data, output logic b_ack,
  output logic req, output logic [AW-1:0] addr, output logic [4:0] count,
  input logic [255:0] data, input logic ack
);
  typedef enum logic [1:0] { M_IDLE, M_A, M_B, M_DRAIN } mux_state_t;
  mux_state_t state;
  assign req = state == M_A || state == M_B;
  assign a_ack = ack && state == M_A;
  assign b_ack = ack && state == M_B;
  assign a_data = data;
  assign b_data = data;
  always_ff @(posedge clk) begin
    if (rst) begin state <= M_IDLE; addr <= '0; count <= '0; end
    else case (state)
      M_IDLE: if (!ack) begin
        if (a_req === 1'b1) begin
          state <= M_A; addr <= a_addr; count <= a_count;
        end else if (b_req === 1'b1) begin
          state <= M_B; addr <= b_addr; count <= b_count;
        end
      end
      M_A, M_B: if (ack) state <= M_DRAIN;
      M_DRAIN: if (!ack) state <= M_IDLE;
      default: state <= M_IDLE;
    endcase
  end
endmodule

// Full-rate completion mailbox for a CE-held request. Capture the one-clock
// memory response once, suppress reissue, and hold completion/data until the
// slow requester drops its request. No CPU multicycle exception applies here.
module revx_chunk_mailbox #(parameter int AW = 21)(
  input logic clk, rst,
  input logic cpu_req, input logic [AW-1:0] cpu_addr,
  input logic [4:0] cpu_count, input logic [255:0] cpu_wdata,
  output logic cpu_ack, output logic [255:0] cpu_rdata,
  output logic req, output logic [AW-1:0] addr,
  output logic [4:0] count, output logic [255:0] wdata,
  input logic ack, input logic [255:0] rdata
);
  typedef enum logic [1:0] { Q_IDLE, Q_WAIT, Q_DONE } mailbox_state_t;
  mailbox_state_t state;
  assign req = state == Q_WAIT;
  assign cpu_ack = state == Q_DONE;
  always_ff @(posedge clk) begin
    if (rst) begin
      state <= Q_IDLE; addr <= '0; count <= '0;
      wdata <= '0; cpu_rdata <= '0;
    end else case (state)
      Q_IDLE: if (cpu_req && !ack) begin
        addr <= cpu_addr; count <= cpu_count; wdata <= cpu_wdata;
        state <= Q_WAIT;
      end
      Q_WAIT: if (ack) begin cpu_rdata <= rdata; state <= Q_DONE; end
      Q_DONE: if (!cpu_req) state <= Q_IDLE;
      default: state <= Q_IDLE;
    endcase
  end
endmodule

module revx_sdram_arb #(
  parameter int SD_AW = 21,
  parameter bit S_READ_CHUNK = 1'b0
)(
  input  logic              clk,
  input  logic              rst,

  // ---- master S: video scanout reader (highest run-time priority) ----
  input  logic [SD_AW-1:0]  s_addr,
  input  logic              s_rd,
  output logic [15:0]       s_dout,
  output logic              s_ack,
  output logic [255:0]      s_chunk_dout,

  // ---- master A: main RAM word engine (rw) ----
  input  logic [SD_AW-1:0]  a_addr,
  input  logic [15:0]       a_din,
  input  logic [1:0]        a_be,
  input  logic              a_rd,
  input  logic              a_wr,
  output logic [15:0]       a_dout,
  output logic              a_ack,

  // ---- master B: program ROM word engine (ro) ----
  input  logic [SD_AW-1:0]  b_addr,
  input  logic [15:0]       b_din,
  input  logic [1:0]        b_be,
  input  logic              b_rd,
  input  logic              b_wr,
  output logic [15:0]       b_dout,
  output logic              b_ack,

  // ---- master VD: VRAM data word engine ----
  input  logic [SD_AW-1:0]  vd_addr,
  input  logic [15:0]       vd_din,
  input  logic [1:0]        vd_be,
  input  logic              vd_rd,
  input  logic              vd_wr,
  output logic [15:0]       vd_dout,
  output logic              vd_ack,
  input logic [2:0] vd_count, input logic [63:0] vd_words, input logic vd_reverse,

  // ---- master VC: VRAM colour word engine ----
  input  logic [SD_AW-1:0]  vc_addr,
  input  logic [15:0]       vc_din,
  input  logic [1:0]        vc_be,
  input  logic              vc_rd,
  input  logic              vc_wr,
  output logic [15:0]       vc_dout,
  output logic              vc_ack,

  // ---- boot-load byte-stream writer (ioctl download, word-packed by caller) ----
  input  logic [SD_AW-1:0]  dl_addr,
  input  logic [15:0]       dl_din,
  input  logic [1:0]        dl_be,
  input  logic              dl_wr,
  output logic              dl_ack,

  // Optional SRT write chunk (1..16 full words in one SDRAM row). Scanout
  // retains priority at each chunk boundary; all payload fields stay held.
  input logic wb_req,
  input logic [SD_AW-1:0] wb_addr,
  input logic [6:0] wb_count,
  input logic [1023:0] wb_data,
  output logic wb_ack,

`ifdef REVX_BLMOVE_BURST
  // BLMOVE write chunk (1..16 full words in one SDRAM row) -- SD-space (RAM)
  // absolute words, same shape as wb but a distinct master: the engine's
  // ROM->RAM block copies stream these while the CPU waits. Priority below wb
  // (the scanout's straddle writeback must never be blocked by a bulk copy).
  input logic wb2_req,
  input logic [SD_AW-1:0] wb2_addr,
  input logic [4:0] wb2_count,
  input logic [255:0] wb2_data,
  output logic wb2_ack,
`endif

  // PERF: CPU line-fill burst READ (1..16 consecutive words, one ACTIVE). Held
  // until rb_ack; data packed little-endian per fetch order on the ack cycle.
  input logic rb_req,
  input logic [SD_AW-1:0] rb_addr,
  input logic [4:0] rb_count,
  output logic [255:0] rb_dout,
  output logic rb_ack,

  // ---- physical single 16-bit SDRAM channel ----
  output logic [SD_AW-1:0]  sd_addr,
  output logic [15:0]       sd_din,
  output logic [1:0]        sd_be,
  output logic              sd_rd,
  output logic              sd_wr,
  input  logic [15:0]       sd_dout,
  input  logic              sd_ack,
  output logic sd_write_chunk,
  output logic sd_write_reverse,
  output logic sd_read_chunk,
  output logic [6:0] sd_chunk_count,
  output logic [1023:0] sd_chunk_data,
  input  logic [255:0] sd_chunk_dout
);
  typedef enum logic [3:0] { G_NONE, G_DL, G_S, G_RB, G_A, G_B, G_VD, G_VC, G_WB
`ifdef REVX_BLMOVE_BURST
                            , G_WB2
`endif
                           } grant_t;
  grant_t grant;

  wire s_req  = s_rd;
  wire a_req  = a_rd | a_wr;
  wire b_req  = b_rd | b_wr;
  wire vd_req = vd_rd | vd_wr;
  wire vc_req = vc_rd | vc_wr;
  wire dl_req = dl_wr;
  wire wb_request = (wb_req === 1'b1); // unconnected legacy callers are inactive
  wire rb_request = (rb_req === 1'b1);
`ifdef REVX_BLMOVE_BURST
  wire wb2_request = (wb2_req === 1'b1);
`endif

  // next-grant selection when idle (fixed priority)
  grant_t nxt;
  always_comb begin
    nxt = G_NONE;
`ifdef REVX_ARB_NO_SCAN_PRIO
    // MUTANT: scanout demoted to the LOWEST priority -> starves under load.
    if      (dl_req) nxt = G_DL;
    else if (rb_request) nxt = G_RB;
    else if (a_req)  nxt = G_A;
    else if (b_req)  nxt = G_B;
    else if (vd_req) nxt = G_VD;
    else if (vc_req) nxt = G_VC;
    else if (wb_request) nxt = G_WB;
`ifdef REVX_BLMOVE_BURST
    else if (wb2_request) nxt = G_WB2;
`endif
    else if (s_req)  nxt = G_S;
`else
    // CORRECT: boot > scanout > CPU fetch-fill (rb) > CPU(ram,rom) > blitter(vram)
    // > SRT writeback (wb) > BLMOVE write chunk (wb2).
    if      (dl_req) nxt = G_DL;
    else if (s_req)  nxt = G_S;
    else if (rb_request) nxt = G_RB;
    else if (a_req)  nxt = G_A;
    else if (b_req)  nxt = G_B;
    else if (vd_req) nxt = G_VD;
    else if (vc_req) nxt = G_VC;
    else if (wb_request) nxt = G_WB;
`ifdef REVX_BLMOVE_BURST
    else if (wb2_request) nxt = G_WB2;
`endif
`endif
  end

  // grant held until the granted access acks
  always_ff @(posedge clk) begin
    if (rst) grant <= G_NONE;
    else begin
      if (grant == G_NONE) grant <= nxt;
      else if (sd_ack)     grant <= G_NONE;   // release on completion
    end
  end

  // physical channel driven by the granted master
  always_comb begin
    sd_addr = '0; sd_din = '0; sd_be = 2'b00; sd_rd = 1'b0; sd_wr = 1'b0;
    sd_write_reverse = 1'b0;
    sd_write_chunk = 1'b0; sd_read_chunk = 1'b0; sd_chunk_count = 0; sd_chunk_data = 0;
    unique case (grant)
      G_DL: begin sd_addr = dl_addr; sd_din = dl_din; sd_be = dl_be; sd_wr = dl_wr; end
      G_S:  begin
        sd_addr = s_addr; sd_be = 2'b00; sd_rd = s_rd;
        if (S_READ_CHUNK) begin sd_read_chunk = 1'b1; sd_chunk_count = 5'd16; end
      end
      G_RB: begin
        sd_addr = rb_addr; sd_be = 2'b00; sd_rd = rb_request;
        sd_read_chunk = 1'b1; sd_chunk_count = rb_count;
      end
      G_A:  begin sd_addr = a_addr;  sd_din = a_din;  sd_be = a_be;  sd_rd = a_rd; sd_wr = a_wr; end
      G_B:  begin sd_addr = b_addr;  sd_din = b_din;  sd_be = b_be;  sd_rd = b_rd; sd_wr = b_wr; end
      G_VD: begin
        sd_addr = vd_addr; sd_din = vd_din; sd_be = vd_be; sd_rd = vd_rd; sd_wr = vd_wr;
        if (vd_wr && vd_be == 2'b11 &&
            ((vd_count === 3'd2) || (vd_count === 3'd3) || (vd_count === 3'd4))) begin
          sd_write_chunk = 1'b1; sd_chunk_count = {4'd0,vd_count};
          sd_chunk_data = {960'd0,vd_words}; sd_write_reverse = vd_reverse === 1'b1;
        end
      end
      G_VC: begin sd_addr = vc_addr; sd_din = vc_din; sd_be = vc_be; sd_rd = vc_rd; sd_wr = vc_wr; end
      G_WB: begin
        sd_addr = wb_addr; sd_din = wb_data[15:0]; sd_be = 2'b11; sd_wr = wb_request;
        sd_write_chunk = 1'b1; sd_chunk_count = wb_count; sd_chunk_data = wb_data;
      end
`ifdef REVX_BLMOVE_BURST
      G_WB2: begin
        sd_addr = wb2_addr; sd_din = wb2_data[15:0]; sd_be = 2'b11; sd_wr = wb2_request;
        sd_write_chunk = 1'b1; sd_chunk_count = wb2_count; sd_chunk_data = wb2_data;
      end
`endif
      default: ;
    endcase
  end

  // ack + read-data fan-out (only the granted master sees its ack)
  assign s_dout  = sd_dout;
  assign s_chunk_dout = sd_chunk_dout;
  assign a_dout  = sd_dout;
  assign b_dout  = sd_dout;
  assign vd_dout = sd_dout;
  assign vc_dout = sd_dout;
  assign rb_dout = sd_chunk_dout;
  assign s_ack   = (grant == G_S)  & sd_ack;
  assign a_ack   = (grant == G_A)  & sd_ack;
  assign b_ack   = (grant == G_B)  & sd_ack;
  assign vd_ack  = (grant == G_VD) & sd_ack;
  assign vc_ack  = (grant == G_VC) & sd_ack;
  assign dl_ack  = (grant == G_DL) & sd_ack;
  assign wb_ack  = (grant == G_WB) & sd_ack;
`ifdef REVX_BLMOVE_BURST
  assign wb2_ack = (grant == G_WB2) & sd_ack;
`endif
  assign rb_ack  = (grant == G_RB) & sd_ack;
endmodule
`default_nettype wire
