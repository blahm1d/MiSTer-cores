// revx_word_sdram.sv -- Midway X-unit 32-bit-word CPU access to a region held in
// the 16-bit MT48 SDRAM, sequenced over ONE 16-bit req/ack channel.
//
// FORK of rtl/wolf/ram_sdram.sv: it reuses that module's PROVEN FSM shell (latch
// on req while idle, drive sd_rd/sd_wr held-until-ack, drop on ack, pulse done,
// `active` for arbitration -- ram_sdram.sv:69-117) and its SDRAM-channel contract
// (sd_addr/sd_din/sd_be/sd_rd/sd_wr/sd_dout/sd_ack, sdram_model.sv:39-68).  What
// changes is the CPU-side WORD MODEL: the RevX CPU<->memory contract is a 32-bit
// little-endian word at mem_addr[31:5] with mem_be[3:0] byte enables (TMS34020,
// tms34010.cpp:66 is_34020 ? 32 : 16; HANDOFF-REVX-KICKOFF-20260906.md "CPU<->
// memory contract"), NOT the 34010 field (boff/sz) window ram_sdram serves.  A
// 32-bit CPU word W maps to TWO consecutive 16-bit SDRAM words:
//   lo = BASE + 2*W  (byte lanes 0,1)   hi = BASE + 2*W + 1  (byte lanes 2,3)
// -- exactly the ROM_LOAD32_BYTE little-endian interleave the X-unit program ROM
// uses (midxunit.cpp:707-711; AUDIT.md row "Program ROM").
//
// WRITE, cabinet 3 (2026-09-07): the MT48 on the RevX board does NOT honour the
// per-byte write mask (DQM) as driven by this design -- the DIAG v3 self-test read
// back both masked-write orders as the LAST write in BOTH lanes (T3 = 55555555),
// so a partial (be=01/10) half write corrupts the neighbouring byte on silicon.
// Reads / addresses / commands / full-word writes are fine.  Therefore, when
// REVX_SDRAM_RMW_PARTIAL is ON (default), a 16-bit half whose byte enables are
// PARTIAL (exactly one of the two lanes) is written by READ-MODIFY-WRITE: read the
// half, merge the enabled byte over the fetched half, then write the FULL half with
// sd_be=11 (a full-word write is INSENSITIVE to the DQM fault).  Full halves (be=11)
// and reads are unchanged; a half with no enables (be=00 on a write) is skipped.
// COST: ONE extra SDRAM read per partial half (i.e. per byte / odd-aligned CPU
// write into this region -- main RAM).  RMW is safe across the read->write gap:
// this engine serves one CPU access at a time and the CPU is the sole writer of its
// region, so a refresh or another master's access in the gap cannot disturb the
// latched half.  Guarded so the NATIVE masked path can be restored once the chip's
// DQM cause is settled (DIAG v4a native-vs-early-DQM self-test): -DREVX_SDRAM_RMW_OFF
// forces REVX_SDRAM_RMW_PARTIAL=0.  READ: both halves are fetched and assembled {hi,lo}.
//
// READ_ONLY=1 (program ROM / gfx-in-SDRAM) drops all writes (region is a boot-
// loaded image; CPU writes to ROM are ignored, matching midxunit.cpp main_map ROM
// being a rom() region) -- we_l is forced 0, so RMW never triggers there.

`timescale 1ns/1ps
`default_nettype none
module revx_word_sdram #(
  parameter int WORDS     = 32'h40000,        // 32-bit words in this region
  parameter int SD_AW     = 21,               // SDRAM word-address width
  parameter [SD_AW-1:0] BASE = '0,            // SDRAM word base (arb adds region base too)
  parameter bit READ_ONLY = 1'b0
)(
  input  logic              clk,
  input  logic              rst,
  input  logic              req,              // 1-cycle start pulse (latched while idle)
  input  logic              we,               // 1=write, 0=read
  input  logic [26:0]       waddr,            // 32-bit-word index within the region
  input  logic [3:0]        be,               // byte enables (lane b -> bits[8b+7:8b])
  input  logic [31:0]       wd,               // write data
  output logic [31:0]       rdata,            // read result (valid at done)
  output logic              done,             // 1-cycle completion strobe
  output logic              active,           // 1 while an access is in progress
  output logic [SD_AW-1:0]  sd_addr,
  output logic [15:0]       sd_din,
  output logic [1:0]        sd_be,
  output logic              sd_rd,
  output logic              sd_wr,
  input  logic [15:0]       sd_dout,
  input  logic              sd_ack
);
  // RMW-on-partial-write guard (cabinet 3 chip DQM fault).  Default ON; the native
  // masked-write path returns with -DREVX_SDRAM_RMW_OFF once the DQM cause is fixed.
`ifdef REVX_SDRAM_RMW_OFF
  localparam bit REVX_SDRAM_RMW_PARTIAL = 1'b0;
`else
  localparam bit REVX_SDRAM_RMW_PARTIAL = 1'b1;
`endif

  logic        we_l;
  logic [26:0] wi;
  logic [3:0]  be_l;
  logic [31:0] wd_l;
  logic [15:0] rmw_dat;                        // merged half awaiting the RMW write-back

  // two SDRAM word addresses for this 32-bit CPU word (LE interleave).
  // 2*W in region-word units, truncated to the SDRAM word-address width.
  wire [27:0]      w2   = {wi, 1'b0};                 // 2*W
  wire [SD_AW-1:0] a_lo = BASE + w2[SD_AW-1:0];       // 2*W
  wire [SD_AW-1:0] a_hi = BASE + w2[SD_AW-1:0] + 1'b1;// 2*W+1

  logic [15:0] o_lo, o_hi;                      // captured halves

  typedef enum logic [2:0] { S_IDLE, S_LO, S_LO_W, S_HI, S_HI_W, S_FIN } st_t;
  st_t st;
  assign active = (st != S_IDLE);
`ifdef REVX_SDRAM_INTERLEAVE_MUTANT
  // Deliberate gospel-misread the backend gate must KILL: swap the two 16-bit halves
  // on read -> breaks the ROM_LOAD32_BYTE little-endian interleave (midxunit.cpp:707).
  assign rdata  = {o_lo, o_hi};
`else
  assign rdata  = {o_hi, o_lo};
`endif

  // does each half carry any enabled byte on a write?
  wire wr_lo = we_l & (|be_l[1:0]);
  wire wr_hi = we_l & (|be_l[3:2]);
  // a half needs RMW when EXACTLY ONE of its two byte lanes is enabled on a write
  // (be==01 or be==10); be==11 is a full half (direct write), be==00 is skipped.
  wire part_lo = we_l & (be_l[1:0] != 2'b00) & (be_l[1:0] != 2'b11);
  wire part_hi = we_l & (be_l[3:2] != 2'b00) & (be_l[3:2] != 2'b11);

  always_ff @(posedge clk) begin
    if (rst) begin
      st <= S_IDLE; done <= 1'b0; sd_rd <= 1'b0; sd_wr <= 1'b0;
      o_lo <= 16'h0; o_hi <= 16'h0;
    end else begin
      done <= 1'b0;
      case (st)
        S_IDLE: begin
          sd_rd <= 1'b0; sd_wr <= 1'b0;
          if (req) begin
            we_l <= we & ~READ_ONLY;            // READ_ONLY: force read/no-op write
            wi   <= waddr; be_l <= be; wd_l <= wd;
            o_lo <= 16'h0; o_hi <= 16'h0;
            st   <= S_LO;
          end
        end
        // ---- low half (SDRAM word 2*W, byte lanes 0/1) ----
        S_LO: begin
          if (we_l && !wr_lo) begin              // write with no low-half enables: skip
            sd_wr <= 1'b0; st <= S_HI;
          end else if (sd_ack) begin
            if (!we_l) begin
              o_lo <= sd_dout; st <= S_HI;        // plain read: capture the half
            end else if (REVX_SDRAM_RMW_PARTIAL && part_lo) begin
              // RMW pre-read complete: merge the one enabled byte over the fetched half
              rmw_dat <= { be_l[1] ? wd_l[15:8] : sd_dout[15:8],
                           be_l[0] ? wd_l[7:0]  : sd_dout[7:0] };
              st <= S_LO_W;
            end else begin
              st <= S_HI;                          // full (be=11) or native masked write done
            end
            sd_rd <= 1'b0; sd_wr <= 1'b0;
          end else begin
            sd_addr <= a_lo;
            if (!we_l) begin
              sd_be <= 2'b00; sd_rd <= 1'b1;                            // plain read
            end else if (REVX_SDRAM_RMW_PARTIAL && part_lo) begin
              sd_be <= 2'b00; sd_rd <= 1'b1;                            // RMW: read the half first
            end else begin
              sd_din <= wd_l[15:0]; sd_be <= be_l[1:0]; sd_wr <= 1'b1;  // full / native masked write
            end
          end
        end
        // ---- low half RMW write-back: FULL 16-bit half, mask-independent (sd_be=11) ----
        S_LO_W: begin
          if (sd_ack) begin sd_wr <= 1'b0; st <= S_HI; end
          else begin sd_addr <= a_lo; sd_din <= rmw_dat; sd_be <= 2'b11; sd_wr <= 1'b1; end
        end
        // ---- high half (SDRAM word 2*W+1, byte lanes 2/3) ----
        S_HI: begin
          if (we_l && !wr_hi) begin              // write with no high-half enables: skip
            sd_wr <= 1'b0; st <= S_FIN;
          end else if (sd_ack) begin
            if (!we_l) begin
              o_hi <= sd_dout; st <= S_FIN;
            end else if (REVX_SDRAM_RMW_PARTIAL && part_hi) begin
              rmw_dat <= { be_l[3] ? wd_l[31:24] : sd_dout[15:8],
                           be_l[2] ? wd_l[23:16] : sd_dout[7:0] };
              st <= S_HI_W;
            end else begin
              st <= S_FIN;
            end
            sd_rd <= 1'b0; sd_wr <= 1'b0;
          end else begin
            sd_addr <= a_hi;
            if (!we_l) begin
              sd_be <= 2'b00; sd_rd <= 1'b1;
            end else if (REVX_SDRAM_RMW_PARTIAL && part_hi) begin
              sd_be <= 2'b00; sd_rd <= 1'b1;
            end else begin
              sd_din <= wd_l[31:16]; sd_be <= be_l[3:2]; sd_wr <= 1'b1;
            end
          end
        end
        // ---- high half RMW write-back: FULL 16-bit half, mask-independent (sd_be=11) ----
        S_HI_W: begin
          if (sd_ack) begin sd_wr <= 1'b0; st <= S_FIN; end
          else begin sd_addr <= a_hi; sd_din <= rmw_dat; sd_be <= 2'b11; sd_wr <= 1'b1; end
        end
        S_FIN: begin
          done <= 1'b1;
          st   <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
