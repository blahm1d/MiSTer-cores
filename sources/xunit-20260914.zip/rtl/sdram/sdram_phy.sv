// sdram_phy.sv — Phase 6 W1f item1b: single-word MT48LC16M16 SDRAM controller presenting
// the req/ack word contract yunit_sdram_arb drives (req held until ack; edge-accept on
// rising rd|wr while idle; 1-cycle ack pulse with read data valid). Single access per
// transaction (no burst) + periodic auto-refresh. Timing constants from the proven darfpga
// / srg320 MiSTer controllers (MT48LC16M16, up to ~128 MHz). Command timing is validated
// on real hardware (Phase 7); sim uses the behavioral req/ack model, so this drives the
// pins for synthesis + a behavioral-chip round-trip sanity check.
//
// PERF (RevX wide fetch lane, 2026-09-09): optional READ-CHUNK extension mirroring the
// proven write-chunk: with rd + read_chunk asserted, the controller issues ONE ACTIVE then
// chunk_count consecutive READ commands to consecutive columns of the open row — spaced TWO
// clocks apart (tCCD-comfortable AND matching the single-latch behavioral chip model, where
// a 1-clock-spaced stream would alias its rlatch), auto-precharge on the LAST read only, and
// returns the words packed in chunk_dout[16*k +: 16] (k = fetch order), acking ONCE after the
// last word is captured and the precharge has retired.  A chunk must not cross the 512-column
// row boundary (caller's contract, same as the write chunk).  Legacy callers leave read_chunk
// inactive/open: byte-identical behavior.
`timescale 1ns/1ps
`default_nettype none
module sdram_phy #(
  parameter int CLK_MHZ    = 100,           // SDRAM clock (100-128)
  parameter int RASCAS     = 3,             // tRCD in clks
  parameter int CAS        = 2,             // CAS latency (2/3)
  parameter int TRP        = 3,             // precharge in clks
  parameter int TWR        = 2,             // chunk final WRITE recovery before precharge
  parameter int TRFC       = 9,             // refresh cycle in clks
  parameter int REFRESH_IV = 780,           // auto-refresh interval in clks (~7.8us@100MHz)
  parameter int PWRUP      = 20000          // power-up wait in clks (~200us; sims may shorten)
)(
  input  logic         clk,
  input  logic         init,               // hold high after config to run power-up init
  // req/ack word port (matches yunit_sdram_arb)
  input  logic [24:0]  addr,               // word address {bank[1:0], row[12:0], col[8:0]} = addr[23:0]
  input  logic [15:0]  din,
  input  logic [1:0]   be,                  // write byte-enables (-> DQM low-active)
  input  logic         dqm_early,           // DIAG v4a (RevX cabinet 3): when 1, assert the write
                                            //   DQM byte mask one clock BEFORE the WRITE command as
                                            //   well as during it, so a chip that samples DQM a
                                            //   fraction of a cycle late (H1) still catches it.
                                            //   Per-request; ONLY the self-test steal port drives
                                            //   it 1 (arb writes leave it 0 = native single-cycle
                                            //   masked write).  Ignored on reads.
  input  logic         rd,
  input  logic         wr,
  output logic [15:0]  dout,
  output logic         ack,
  // Optional held word-port extension: sequential full-word WRITEs within
  // one 512-column row. Legacy callers leave write_chunk inactive/open.
  input logic write_chunk,
  // BL1 command columns may decrement; payload remains in producer order.
  // Inactive/open is ascending, preserving every existing scalar/SRT client.
  input logic write_reverse,
  input logic [6:0] chunk_count,
  input logic [1023:0] chunk_data,
  // PERF: sequential READ chunk (one ACTIVE + chunk_count consecutive READs at
  // 2-clock spacing, data packed little-endian per fetch order, single ack).
  input logic read_chunk,
  output logic [255:0] chunk_dout,
  output logic         ready,             // high once power-up init completes (safe to issue)
  // MT48LC16M16 pins
  inout  wire  [15:0]  SDRAM_DQ,
  output logic [12:0]  SDRAM_A,
  output logic [1:0]   SDRAM_BA,
  output logic         SDRAM_DQML,
  output logic         SDRAM_DQMH,
  output logic         SDRAM_nCS,
  output logic         SDRAM_nRAS,
  output logic         SDRAM_nCAS,
  output logic         SDRAM_nWE,
  output logic         SDRAM_CKE
);
  // command = {nCS,nRAS,nCAS,nWE}
  localparam [3:0] CMD_NOP=4'b0111, CMD_ACTIVE=4'b0011, CMD_READ=4'b0101, CMD_WRITE=4'b0100,
                   CMD_PRECHARGE=4'b0010, CMD_REFRESH=4'b0001, CMD_LOADMODE=4'b0000;
  localparam [12:0] MODE = {3'b000, 1'b1 /*no wr burst*/, 2'b00, CAS[2:0], 1'b0, 3'b000 /*burst1*/};
  // Read-chunk data-capture delay.  Data for a READ command issued at edge T is captured at
  // edge T + CAP_DLY: the single-read path captures at T+3 (S_RDWAIT counts CAS down from the
  // cycle after the command; the chip model drives DQ from T+1 and holds until the next READ
  // command + 1, so with the chunk's 2-clock command spacing the T+3 edge reads word k both in
  // the model and on silicon where CAS=2 puts data on DQ at T+3).  CAP_DLY = CAS + 1.
  // The issue_pipe marker is pushed AT the issue edge, so it sits in pipe[0] one clock later;
  // rcap_now = pipe[PIPE_W-1] therefore fires at issue + PIPE_W.  PIPE_W MUST equal CAP_DLY so
  // the chunk capture lands on the SAME issue+3 edge as the proven single-read path -- a wider
  // pipe fires at issue+4, one word late (the next READ's rlatch already landing -> every slot
  // shifts by one and the last slot duplicates; caught by tb_revx_fetch_burst, 2026-09-09).
  localparam int CAP_DLY = CAS + 1;        // 3 for CAS=2
  localparam int PIPE_W  = CAP_DLY;        // marker pipe width (fires at +CAP_DLY)

  wire [1:0]  a_bank = addr[23:22];
  wire [12:0] a_row  = addr[21:9];
  wire [8:0]  a_col  = addr[8:0];

  typedef enum logic [3:0] { S_PWR, S_INIT, S_IDLE, S_ACT, S_RDWAIT, S_PRE, S_REF, S_CHUNK, S_RCHUNK } st_t;
  st_t st;
  logic [15:0] pwr_cnt;             // power-up delay
  logic [3:0]  istep;              // init micro-step: PRE, REF, REF, LOADMODE
  logic [3:0]  wait_cnt;
  logic [15:0] ref_cnt;
  logic        served;             // serve-once-per-assertion (survives refresh preemption)
  logic        is_wr;
  logic chunk_l, write_reverse_l;
  wire [8:0] write_col = write_reverse_l
      ? a_l[8:0] - {3'd0,chunk_idx} : a_l[8:0] + {3'd0,chunk_idx};
  logic [6:0] chunk_count_l;
  logic [5:0] chunk_idx;
  logic [1023:0] chunk_data_l;
  wire chunk_last = ({1'b0,chunk_idx} + 7'd1) == chunk_count_l;
  logic [24:0] a_l; logic [15:0] d_l; logic [1:0] be_l;
  logic        dqm_early_l;      // DIAG v4a: latched dqm_early for the accepted write
  logic [3:0]  cmd;
  logic        dq_oe;              // drive DQ (write)
  logic [15:0] dq_o;
  logic        init_d;

  // ---- read-chunk machinery (inert while rchunk_l = 0) ----
  logic        rchunk_l;            // latched read_chunk at accept
  logic [4:0]  ric;                 // READs issued so far (0..chunk_count-1)
  logic        rch_pause;           // 2-clock command spacing toggle
  logic [PIPE_W-1:0] issue_pipe;    // marker shift: top bit = a READ was issued CAP_DLY clocks ago
  logic [255:0] chunk_sh;           // stage-2 shift register: newest word at the top
  logic         rcap_now_q;         // stage-1 -> stage-2 handoff
  logic [4:0]   chunk_shift_count;  // captured words plus low-packing padding

  // stage-2 shift register: the first captured word shifts down to [15:0] and the
  // newest sits at [255:240], so word j naturally ends up at chunk_sh[16j+:16] --
  // exactly the chunk contract's layout.  No permutation needed (pure wiring).
  assign chunk_dout = chunk_sh;
  assign {SDRAM_nCS, SDRAM_nRAS, SDRAM_nCAS, SDRAM_nWE} = cmd;
  assign SDRAM_CKE = 1'b1;
  assign SDRAM_DQ  = dq_oe ? dq_o : 16'hZZZZ;

  // data arrives CAP_DLY clocks after its READ command (same edge as the single-read capture)
  wire rcap_now = issue_pipe[PIPE_W-1];

  // Reserve the same refresh budget without putting an adder on the late
  // incoming chunk_count path. RB is at most 16 words; SRT WB is at most 64.
  // Keep the original nine-bit budget for parameter values that can wrap it.
  localparam [8:0] READ_RESERVE  = 9'(RASCAS+TRP+6);
  localparam [8:0] WRITE_RESERVE = 9'(RASCAS+TRP+TWR+4);
  wire [8:0] chunk_budget = (read_chunk === 1'b1)
      ? ({2'd0,chunk_count} << 1) + 9'(RASCAS+TRP+6)
      : {2'd0,chunk_count} + 9'(RASCAS+TRP+TWR+4);
  wire chunk_reserve_short;
  generate
    if (READ_RESERVE <= 9'd257 && WRITE_RESERVE <= 9'd384) begin : g_reserve_margin
      // For all seven-bit counts, these constants make the original budget
      // non-wrapping. Compute R-C locally; the count only sees a comparison.
      localparam [15:0] READ_BASE    = {7'd0,READ_RESERVE};
      localparam [15:0] WRITE_BASE   = {7'd0,WRITE_RESERVE};
      localparam [15:0] READ_WINDOW  = READ_BASE  + 16'd256;
      localparam [15:0] WRITE_WINDOW = WRITE_BASE + 16'd128;
      wire [7:0] read_margin  = ref_cnt[7:0] - READ_RESERVE[7:0];
      wire [6:0] write_margin = ref_cnt[6:0] - WRITE_RESERVE[6:0];
      // R < C+N: true below C, false at/above C+128, otherwise N > R-C.
      wire write_short = (ref_cnt < WRITE_BASE) ||
          ((ref_cnt < WRITE_WINDOW) && (chunk_count > write_margin));
      // R < C+2N: within the 256-clock window, N > floor((R-C)/2).
      wire read_short = (ref_cnt < READ_BASE) ||
          ((ref_cnt < READ_WINDOW) && (chunk_count > read_margin[7:1]));
      assign chunk_reserve_short = (read_chunk === 1'b1) ? read_short : write_short;
    end else begin : g_reserve_legacy
      assign chunk_reserve_short = ref_cnt < {7'd0,chunk_budget};
    end
  endgenerate
  wire reserve_refresh = (rd || wr) && !served &&
      ((write_chunk === 1'b1) || (read_chunk === 1'b1)) &&
      chunk_reserve_short;
  always_ff @(posedge clk) begin
    cmd     <= CMD_NOP;
    dq_oe   <= 1'b0;
    ack     <= 1'b0;
    SDRAM_A <= 13'd0; SDRAM_BA <= 2'd0; SDRAM_DQML <= 1'b0; SDRAM_DQMH <= 1'b0;
    if (!(rd | wr)) served <= 1'b0;   // rearm when the requester drops its line (per contract)
    init_d  <= init;
    if (ref_cnt != 0) ref_cnt <= ref_cnt - 1'b1;

    // read-chunk capture pipeline (free-running shift; idle when no chunk is running)
    issue_pipe <= {issue_pipe[PIPE_W-2:0], 1'b0};
    // Stage 1 REUSES the legacy single-read capture register `dout` (line ~240):
    // the design keeps exactly ONE SDRAM_DQ capture register, the one whose pad
    // placement has closed timing in every build.  The chunk grid captures through
    // it via the rcap_now term added to its enable; between captures dout holds,
    // so the stage-2 shift below samples each word at the same edges as before.
    // (Every separate capture register we tried -- demux, per-slice enable,
    // free-running, shift -- got placed deep in fabric and failed SDRAM_DQ setup
    // by -3.3..-4.4 ns while dout closed in the SAME fits.)
    if (rcap_now) dout <= SDRAM_DQ;   // chunk grid capture through the shared register
    if (rcap_now_q) begin
      chunk_sh <= {dout, chunk_sh[255:16]};
      chunk_shift_count <= chunk_shift_count + 5'd1;
    end else if (rchunk_l && st == S_PRE &&
                 chunk_shift_count >= chunk_count_l && chunk_shift_count < 5'd16) begin
      // Short reads otherwise leave their valid words in the HIGH lanes.
      // Pad only after all real captures, retaining the single DQ register
      // and shift-only packing. Full 16-word cache fills never take this path.
      chunk_sh <= {16'd0, chunk_sh[255:16]};
      chunk_shift_count <= chunk_shift_count + 5'd1;
    end
    rcap_now_q <= rcap_now;

    if (init & ~init_d) begin                     // rising edge of init -> power-up
      st <= S_PWR; pwr_cnt <= PWRUP[15:0]; ready <= 1'b0;   // ~100us+ @100MHz (PWRUP)
    end else case (st)
      // -------- power-up wait, then the init command sequence --------
      S_PWR: if (pwr_cnt != 0) pwr_cnt <= pwr_cnt - 1'b1;
             else begin istep <= 4'd0; st <= S_INIT; end
      S_INIT: begin
        // istep: 0=PRECHARGE-ALL, 1=REFRESH, 2=REFRESH, 3=LOADMODE, done
        if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
        else case (istep)
          4'd0: begin cmd<=CMD_PRECHARGE; SDRAM_A<=13'h400; wait_cnt<=TRP[3:0];  istep<=4'd1; end // A[10]=1 all
          4'd1: begin cmd<=CMD_REFRESH;                     wait_cnt<=TRFC[3:0]; istep<=4'd2; end
          4'd2: begin cmd<=CMD_REFRESH;                     wait_cnt<=TRFC[3:0]; istep<=4'd3; end
          4'd3: begin cmd<=CMD_LOADMODE; SDRAM_A<=MODE; SDRAM_BA<=2'd0; wait_cnt<=4'd3; istep<=4'd4; end
          default: begin ref_cnt<=REFRESH_IV[15:0]; st<=S_IDLE; ready<=1'b1; end  // init done
        endcase
      end
      // -------- idle: refresh has priority, then a pending access --------
      S_IDLE: begin
        // Present the row independently of the late request/reservation gate.
        // ACTIVE still captures it on exactly the same edge. NOP and AUTO
        // REFRESH ignore A (Micron 256Mb SDRAM Rev.W, Table14 / Note7).
        // REVX_IDLE_ROW_PRESENT_BEGIN
        SDRAM_A <= a_row;
        // REVX_IDLE_ROW_PRESENT_END
        if (ref_cnt == 0
`ifndef SRT_NO_REFRESH_RESERVATION
            || reserve_refresh
`endif
        ) begin
          cmd <= CMD_REFRESH; wait_cnt <= TRFC[3:0]; ref_cnt <= REFRESH_IV[15:0]; st <= S_REF;
        end else if ((rd | wr) & ~served) begin      // accept a not-yet-served access (held or pulsed)
          served <= 1'b1;                             // (survives a refresh preempting the accept)
          a_l <= addr; d_l <= din; be_l <= be; is_wr <= wr; dqm_early_l <= dqm_early;
          chunk_l <= wr && (write_chunk === 1'b1);
          write_reverse_l <= write_reverse === 1'b1;
          rchunk_l <= !wr && (read_chunk === 1'b1);
          chunk_count_l <= chunk_count; chunk_data_l <= chunk_data;
          chunk_shift_count <= 5'd0;
          chunk_idx <= 0; ric <= 5'd0; rch_pause <= 1'b0;
          cmd <= CMD_ACTIVE; SDRAM_BA <= a_bank;
          wait_cnt <= RASCAS[3:0] - 4'd1; st <= S_ACT;
        end
      end
      S_ACT: begin
             // DIAG v4a early-DQM (RevX cabinet 3, H1): when dqm_early_l is set, drive the write
             // byte mask through the ACTIVE->WRITE wait cycles so it is stable on the pins one clock
             // BEFORE the WRITE command as well as during it.  Harmless on the chip in ACTIVE/NOP
             // (DQM only masks DQ during the READ/WRITE data windows); it just gives a slow-DQM chip
             // extra setup.  Native writes (dqm_early_l=0) keep the single-cycle mask below.
             if (is_wr && dqm_early_l) begin SDRAM_DQML <= ~be_l[0]; SDRAM_DQMH <= ~be_l[1]; end
             if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
             else begin
               SDRAM_BA <= a_l[23:22]; SDRAM_A <= {2'b00, 1'b1, 1'b0, a_l[8:0]}; // A[10]=1 auto-precharge
               if (is_wr) begin
                 cmd <= CMD_WRITE; dq_oe <= 1'b1; dq_o <= d_l;
                 SDRAM_DQML <= ~be_l[0]; SDRAM_DQMH <= ~be_l[1];   // low-active byte mask
                 st <= S_PRE; wait_cnt <= TRP[3:0];
                 if (chunk_l) begin
                   // Burst-length1 mode still permits one WRITE command per
                   // clock to an open row. Only the final word auto-precharges.
                   dq_o <= chunk_data_l[15:0]; chunk_data_l <= {16'd0,chunk_data_l[1023:16]}; SDRAM_DQML <= 0; SDRAM_DQMH <= 0;
                   SDRAM_A <= {2'b00, (chunk_count_l == 5'd1), 1'b0, a_l[8:0]};
                   if (chunk_count_l == 5'd1) wait_cnt <= 4'(TRP + TWR);
                   else begin chunk_idx <= 1; st <= S_CHUNK; end
                 end
               end else if (rchunk_l) begin
                 // Read chunk: issue the FIRST read here, the rest at 2-clock spacing in
                 // S_RCHUNK, auto-precharge only on the last.  Data is captured CAP_DLY
                 // clocks after each command via the issue_pipe/rcap_idx machinery; the
                 // tail waits TRP+1 after the last command so the ack lands one clock
                 // AFTER the final capture (chunk_dout_r settled) and the auto-precharge
                 // has retired.
                 cmd <= CMD_READ; SDRAM_DQML <= 1'b0; SDRAM_DQMH <= 1'b0;
                 SDRAM_A <= {2'b00, (chunk_count_l == 5'd1), 1'b0, a_l[8:0]};
                 issue_pipe[0] <= 1'b1;
                 ric <= 5'd1; rch_pause <= 1'b1;
                 if (chunk_count_l == 5'd1)
                   st <= S_PRE;
                 else
                   st <= S_RCHUNK;
                 wait_cnt <= 4'(TRP + 2);   // +2: stage-2 slice write lands one clock after capture
               end else begin
                 cmd <= CMD_READ;
                 // P0019 note (RevX cabinet 2, 2026-09-07): DQM is ALSO the read output-enable
                 // mask on the MT48LC16M16 (DQM high at clock N -> that byte lane is High-Z
                 // at N+2, i.e. exactly the CAS=2 data word).  This explicit clear is
                 // REDUNDANT with the per-cycle default at the top of the always block (the
                 // masks are only ever high during the WRITE command cycle), so it is a
                 // statement of intent, not a fix: the verifier (commit 807981e) showed the
                 // pre-P0019 PHY already reads with DQM low.  The cabinet's lo:=hi reads
                 // (reset vector FFFFE0E0 for FFFDE000) are therefore NOT explained by this
                 // RTL; the DIAG v3 self-test rows discriminate write-mask / read-lane /
                 // read-timing on silicon.  sim/sdram_chip.sv models the read-side mask.
                 SDRAM_DQML <= 1'b0; SDRAM_DQMH <= 1'b0;             // read both lanes
                 st  <= S_RDWAIT; wait_cnt <= CAS[3:0];            // wait CAS latency
               end
             end
             end
      S_RDWAIT: if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
                else begin dout <= SDRAM_DQ; ack <= 1'b1; st <= S_IDLE; end
      S_PRE:  if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
              else if (!rchunk_l || chunk_shift_count == 5'd16) begin
                ack <= 1'b1; st <= S_IDLE; // return only after low lanes are valid
              end
      S_REF:  if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
              else st <= S_IDLE;
      S_CHUNK: begin
        cmd <= CMD_WRITE; dq_oe <= 1'b1;
        dq_o <= chunk_data_l[15:0]; chunk_data_l <= {16'd0,chunk_data_l[1023:16]};
        SDRAM_BA <= a_l[23:22];
`ifdef DMA_GROUP_FORWARD_MUT
        SDRAM_A <= {2'b00, chunk_last, 1'b0, (a_l[8:0] + {3'd0,chunk_idx})};
`else
        SDRAM_A <= {2'b00, chunk_last, 1'b0, write_col};
`endif
        SDRAM_DQML <= 0; SDRAM_DQMH <= 0;
        if (chunk_last) begin
          st <= S_PRE; wait_cnt <= 4'(TRP + TWR);
`ifdef REVX_SRT_CHUNK_EARLY_ACK_MUT
          ack <= 1'b1;
`endif
        end
        else chunk_idx <= chunk_idx + 1'b1;
      end
      // ---- read chunk: one READ every OTHER clock at consecutive columns (2-clock spacing:
      //      comfortable tCCD on silicon AND matched to the single-latch behavioral chip
      //      model, whose rlatch would alias a 1-clock-spaced stream).  The last READ carries
      //      auto-precharge; the tail (S_PRE, TRP+2) acks one clock after the final STAGE-2
      //      slice write (stage 1 captures SDRAM_DQ, stage 2 demuxes into chunk_dout_r).
      S_RCHUNK: begin
        if (!rch_pause) begin
          cmd <= CMD_READ; SDRAM_DQML <= 1'b0; SDRAM_DQMH <= 1'b0;
          SDRAM_BA <= a_l[23:22];
          // column = a_l + ric; the last issued word auto-precharges
          SDRAM_A <= {2'b00, ({1'b0,ric} == (chunk_count_l - 5'd1)), 1'b0,
                      (a_l[8:0] + {4'd0,ric})};
          issue_pipe[0] <= 1'b1;
          if ({1'b0,ric} == (chunk_count_l - 5'd1)) begin
            st <= S_PRE; wait_cnt <= 4'(TRP + 2);   // +2: stage-2 slice write lands one clock after capture
          end else begin
            ric <= ric + 5'd1;
          end
        end
        rch_pause <= !rch_pause;
      end
      default: st <= S_IDLE;
    endcase
  end
endmodule
`default_nettype wire
