// Passive L2 post-calibration discriminator. All addresses are TMS bit addresses.
// No memory requests, CPU control, ROM changes, or watchdog changes originate here.
// One TIMER-clear epoch; snapshot at TIMER>=16 and freeze at the game's fatal loop.
// Row order, low word first: TC IP AC OB LA LD RT IR DR. See cabinet card for flags.
`default_nettype none
module revx_postcal_capture (
  input wire clk, rst,
  input wire cpu_accept,
  input wire [31:0] cpu_pc,
  input wire irq_entry, irq_return,
  input wire bus_req, bus_we, bus_ack, bus_fetch,
  input wire [31:0] bus_addr, bus_wdata, bus_rdata,
  input wire [3:0] bus_be,
  output reg [287:0] early_sample, final_sample
);
  // Register the raw taps before decoding: ACK is full system rate, not CPU CE.
  reg accept_q, entry_q, return_q, write_q, read_q, wait_q;
  reg [31:0] pc_q, op_pc, bus_pc_q, addr_q, wdata_q, rdata_q;
  reg [3:0] be_q;
  always @(posedge clk) begin
    if (rst) begin
      accept_q<=0; entry_q<=0; return_q<=0; write_q<=0; read_q<=0; wait_q<=0;
      pc_q<=0; op_pc<=0; bus_pc_q<=0; addr_q<=0; wdata_q<=0; rdata_q<=0; be_q<=0;
    end else begin
      accept_q<=cpu_accept; pc_q<=cpu_pc;
      entry_q<=irq_entry; return_q<=irq_return;
      if (cpu_accept) op_pc<=cpu_pc;
      bus_pc_q<=cpu_accept ? cpu_pc : op_pc;
      write_q<=bus_req && bus_we && bus_ack;
      read_q<=bus_req && !bus_we && bus_ack && !bus_fetch;
      wait_q<=bus_req && !bus_ack;
      addr_q<=bus_addr; wdata_q<=bus_wdata; rdata_q<=bus_rdata; be_q<=bus_be;
    end
  end

  function automatic game_pc(input [31:0] pc);
    game_pc = pc[31:24]==8'h20 || pc[31:24]==8'hff;
  endfunction
  reg active, frozen, early_valid;
  reg [15:0] timer;
  reg [31:0] interrupted_pc;
  reg [3:0] ip_lanes;
  reg [3:0] irq_depth;
  reg irq_fault, overflow, timer_fault, clear_fault, insert_fault;
  reg [31:0] elapsed, irq_clocks, foreground_wait;
  reg [15:0] allocations, insertions;
  reg [31:0] object_base, clear_next, link_addr, link_data;
  reg object_valid, link_valid, clear_active, copyr_seen, text_returned;
  reg [5:0] clear_count;
  reg [3:0] insert_mask;
  reg [1:0] link_kind;

  wire timer_write = write_q && addr_q==32'h20517ce0 && |be_q[3:2];
  wire epoch_clear = timer_write && be_q[3:2]==2'b11 && wdata_q[31:16]==0;
  wire foreground = irq_depth==0 && !entry_q;
  wire accept_game = accept_q && game_pc(pc_q);
  wire bus_game = game_pc(bus_pc_q) && foreground;
  wire fatal = accept_game && pc_q[23:0]==24'h813460;
  // TC[31:16]: valid, fatal, reserved, IP valid, clear fault, insertion fault,
  // IRQ accounting fault, overflow, TIMER fault, OB valid, link valid,
  // COPYR seen, text returned, reserved, link kind[1:0].
  wire [15:0] flags = {active, 1'b0, 1'b0, &ip_lanes, clear_fault, insert_fault,
                      irq_fault, overflow, timer_fault, object_valid, link_valid,
                      copyr_seen, text_returned, 1'b0, link_kind};
  wire [287:0] sample = {foreground_wait, irq_clocks, elapsed, link_data, link_addr,
                         object_base, allocations, insertions, interrupted_pc, flags, timer};

  always @(posedge clk) begin
    if (rst) begin
      active<=0; frozen<=0; early_valid<=0; early_sample<=0; final_sample<=0;
      timer<=0; interrupted_pc<=0; ip_lanes<=0; irq_depth<=0; irq_fault<=0;
      elapsed<=0; irq_clocks<=0; foreground_wait<=0;
      allocations<=0; insertions<=0; object_base<=0; clear_next<=0;
      link_addr<=0; link_data<=0; link_kind<=0; object_valid<=0; link_valid<=0;
      clear_active<=0; clear_count<=0; insert_mask<=0;
      copyr_seen<=0; text_returned<=0;
      overflow<=0; timer_fault<=0; clear_fault<=0; insert_fault<=0;
    end else if (!frozen) begin
      // Preserve nesting across a dispatcher clear. A mismatched RETI (including
      // an unobserved software trap) invalidates IRQ timing; never silently wrap.
      case ({entry_q,return_q})
        2'b10: if (irq_depth!=15) irq_depth<=irq_depth+1'b1; else irq_fault<=1;
        2'b01: if (irq_depth!=0) irq_depth<=irq_depth-1'b1; else irq_fault<=1;
        2'b11: irq_fault<=1;
        default: ;
      endcase

      if (epoch_clear) begin
        active<=1; early_valid<=0; early_sample<=0; final_sample<=0; timer<=0;
        interrupted_pc<=0; ip_lanes<=0;
        elapsed<=0; irq_clocks<=0; foreground_wait<=0;
        allocations<=0; insertions<=0; object_base<=0; clear_next<=0;
        link_addr<=0; link_data<=0; link_kind<=0; object_valid<=0; link_valid<=0;
        clear_active<=0; clear_count<=0; insert_mask<=0;
        copyr_seen<=0; text_returned<=0;
        overflow<=0; timer_fault<=0; clear_fault<=0; insert_fault<=0;
      end else if (active) begin
        if (&elapsed) overflow<=1; else elapsed<=elapsed+1'b1;
        if (!foreground) begin
          if (&irq_clocks) overflow<=1; else irq_clocks<=irq_clocks+1'b1;
        end else if (wait_q) begin
          if (&foreground_wait) overflow<=1; else foreground_wait<=foreground_wait+1'b1;
        end
        if (timer_write) begin
          if (be_q[2]) timer[7:0]<=wdata_q[23:16];
          if (be_q[3]) timer[15:8]<=wdata_q[31:24];
          if (be_q[3:2]!=2'b11 || wdata_q[31:16]!=(timer+16'd1)) timer_fault<=1;
        end
        if (write_q && addr_q==32'h203f5ae0) begin
          for (integer i=0; i<4; i=i+1) if (be_q[i]) begin
            interrupted_pc[i*8 +: 8]<=wdata_q[i*8 +: 8]; ip_lanes[i]<=1;
          end
        end

        if (accept_game && foreground) begin
          case (pc_q[23:0])
            24'h84de50: copyr_seen<=1;
            24'h84dfa0: text_returned<=1;
            24'h8fd920: begin clear_active<=1; clear_count<=0; end // GETOBJ
            24'h8fdca0: begin // after clear, ONOT_SORTED and OCTRL stores completed
              if (!clear_active || clear_count!=40) clear_fault<=1;
              if (&allocations) overflow<=1; else allocations<=allocations+1'b1;
              clear_active<=0;
            end
            24'h8fe5a0: insert_mask<=0; // INSOBJ starts its protected link update
            default: ;
          endcase
        end
        if (write_q && bus_game) begin
          case (bus_pc_q[23:0])
            24'h8fdbd0, 24'h8fdbe0: begin
              if (clear_count==0) begin object_base<=addr_q; object_valid<=1; end
              else if (addr_q!=clear_next) clear_fault<=1;
              clear_next<=addr_q+32'd32;
              if (!clear_active || be_q!=4'b1111 || wdata_q!=0 || clear_count>=40)
                clear_fault<=1;
              if (clear_count!=63) clear_count<=clear_count+1'b1;
            end
            24'h8fe5d0: begin
              if (insert_mask!=0 || be_q!=15) insert_fault<=1;
              insert_mask[0]<=1;
            end
            24'h8fe5e0: begin
              if (insert_mask!=1 || be_q!=15) insert_fault<=1;
              insert_mask[1]<=1;
            end
            24'h8fe5f0: begin
              if (insert_mask!=3 || be_q!=15) insert_fault<=1;
              insert_mask[2]<=1;
            end
            24'h8fe610: begin
              if (insert_mask!=7 || be_q!=15) insert_fault<=1;
              insert_mask[3]<=1;
            end
            24'h8fe640: begin // actual completed mark-sorted write, not a no-op RETS
              if (insert_mask!=15 || be_q!=4'b1100 || wdata_q[31:16]!=0) insert_fault<=1;
              if (&insertions) overflow<=1; else insertions<=insertions+1'b1;
              insert_mask<=0;
            end
            default: ;
          endcase
        end
        if (read_q && bus_game) begin
          case (bus_pc_q[23:0])
            24'h8fe3d0, 24'h8fe4b0: begin
              link_addr<=addr_q; link_data<=rdata_q; link_valid<=1; link_kind<=1;
            end
            24'h9025f0, 24'h902630: begin
              link_addr<=addr_q; link_data<=rdata_q; link_valid<=1; link_kind<=2;
            end
            24'h904b50, 24'h904c10: begin
              link_addr<=addr_q; link_data<=rdata_q; link_valid<=1; link_kind<=3;
            end
            default: ;
          endcase
        end
        // TIMER was already committed; this snapshots settled shadows on the next
        // clock. The fatal PC is several instructions after the TIMER=200 store.
        if (!early_valid && timer>=16) begin early_sample<=sample; early_valid<=1; end
      end
      if (fatal) begin
        final_sample<=sample;
        final_sample[30]<=1; // fatal flag, even if no valid clear epoch was observed
        frozen<=1;
      end
    end
  end
endmodule
`default_nettype wire
