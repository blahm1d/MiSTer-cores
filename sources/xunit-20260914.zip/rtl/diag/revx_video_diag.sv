// Revolution X gameplay video observer. All inputs are passive observations.
// No traffic is generated and no ready, grant, IRQ or display register is driven.
// Per-frame values include the preceding frame; sticky counters reset only on rst.
// SB[31:16] is the worst scan request-wait clock count SINCE RESET; SB[15:0]
// is completed 16-word scan bursts in the PRECEDING FRAME. The maximum stays
// sticky across clean frames. Source/write wait clocks may overlap, not add.
`default_nettype none
module revx_video_diag_counters (
  input wire clk, rst,
  input wire frame_tick, first_visible, visible, hud_disabled,
  input wire [15:0] active_y,
  input wire [17:0] row_base,
  input wire pixel_miss,
  input wire scan_req, scan_ack,
  input wire vram_word_commit, vram_chunk_commit,
  input wire [6:0] vram_chunk_count,
  input wire gfx_beat,
  input wire dma_busy, src_wait, fb_wait,
  input wire blit_done,
  input wire cpu_accept, // opcode acceptance only; excludes interrupt-entry pulse
  input wire [31:0] cpu_pc,
  input wire [31:0] dpyst_value,
  input wire dpyst_valid,
  output logic [447:0] values
);
  function automatic [31:0] sat32(input [31:0] a, input [6:0] b);
    logic [32:0] sum;
    begin sum={1'b0,a}+{26'd0,b}; sat32=sum[32]?32'hffffffff:sum[31:0]; end
  endfunction
  function automatic [15:0] inc16(input [15:0] a);
    inc16 = (&a) ? a : a+16'd1;
  endfunction

  // Register the events before wide counters to keep tap fanout off critical
  // CPU/DMA/memory control cones. The frame marker uses the same register stage.
  logic frame_q, first_q, visible_q, disabled_q, miss_q;
  logic scan_req_q, scan_ack_q, vword_q, vchunk_q, gfx_q;
  logic busy_q, src_q, fbwait_q, done_q, accept_q, dpyvalid_q;
  logic [6:0] chunk_q;
  logic [15:0] y_q;
  logic [17:0] row_q;
  logic [31:0] pc_q, dpydata_q;
  always_ff @(posedge clk) begin
    if (rst) begin
      frame_q<=0; first_q<=0; visible_q<=0; disabled_q<=0; miss_q<=0;
      scan_req_q<=0; scan_ack_q<=0; vword_q<=0; vchunk_q<=0; gfx_q<=0;
      busy_q<=0; src_q<=0; fbwait_q<=0; done_q<=0; accept_q<=0; dpyvalid_q<=0;
      chunk_q<=0; y_q<=0; row_q<=0; pc_q<=0; dpydata_q<=0;
    end else begin
      frame_q<=frame_tick; first_q<=first_visible;
      visible_q<=visible; disabled_q<=hud_disabled; miss_q<=pixel_miss;
      scan_req_q<=scan_req; scan_ack_q<=scan_ack;
      vword_q<=vram_word_commit; vchunk_q<=vram_chunk_commit; chunk_q<=vram_chunk_count;
      gfx_q<=gfx_beat; busy_q<=dma_busy; src_q<=src_wait; fbwait_q<=fb_wait;
      done_q<=blit_done;
      y_q<=active_y; row_q<=row_base;
      accept_q<=cpu_accept; pc_q<=cpu_pc;
      dpyvalid_q<=dpyst_valid; dpydata_q<=dpyst_value;
    end
  end

  logic [23:0] frames;
  logic [31:0] clocks, vwords, gfxbeats, srcclks, fbclks, blits;
  logic [31:0] misses, disabled_pixels;
  logic [15:0] scan_bursts, scan_age, scan_max, late_frames, last_drain;
  logic [17:0] front_row;
  logic busy_d, scan_ack_d;
  logic [31:0] dpyst_shadow, first_dpyst;
  logic dpyst_seen;
  logic first_seen, q_seen, cpu_seen, normal_seen, overload_seen, route_error;
  logic route_pending, cpu_path;
  logic [15:0] publications, repeats, dma_skips, cpu_skips;
  wire [6:0] write_words = {6'd0,vword_q} + (vchunk_q ? chunk_q : 7'd0);
  always_ff @(posedge clk) begin
    if (rst) begin
      frames<=0; clocks<=0; vwords<=0; gfxbeats<=0; srcclks<=0; fbclks<=0; blits<=0;
      misses<=0; disabled_pixels<=0;
      scan_bursts<=0; scan_age<=0; scan_max<=0; late_frames<=0; last_drain<=0;
      front_row<=0; dpyst_shadow<=0; dpyst_seen<=0; first_dpyst<=0; first_seen<=0;
      publications<=0; repeats<=0; dma_skips<=0; cpu_skips<=0;
      q_seen<=0; cpu_seen<=0; normal_seen<=0; overload_seen<=0; route_error<=0;
      route_pending<=0; cpu_path<=0;
      busy_d<=0; scan_ack_d<=0; values<=448'd0;
      values[31:0]<=32'hd3000000; // version is visible even before the first frame
    end else begin
      busy_d<=busy_q; scan_ack_d<=scan_ack_q;
      clocks<=sat32(clocks,7'd1);
      vwords<=sat32(vwords,write_words);
      if (gfx_q) gfxbeats<=sat32(gfxbeats,7'd1);
      if (src_q) srcclks<=sat32(srcclks,7'd1);
      if (fbwait_q) fbclks<=sat32(fbclks,7'd1);
      if (done_q) blits<=sat32(blits,7'd1);
      if (scan_req_q && !scan_ack_q) begin
        scan_age<=inc16(scan_age);
        if (inc16(scan_age)>scan_max) scan_max<=inc16(scan_age);
      end else scan_age<=0;
      if (scan_ack_q && !scan_ack_d) scan_bursts<=inc16(scan_bursts);
      if (miss_q) misses<=sat32(misses,7'd1);
      if (disabled_q) disabled_pixels<=sat32(disabled_pixels,7'd1);
      if (first_q) begin
        front_row<=row_q;
        if (busy_q) late_frames<=inc16(late_frames);
      end
      // Sample EVERY native frame, including a frame whose first active line
      // is ENV-disabled during the game's SRT operations. first_visible is not
      // a valid denominator for repeated page starts in that case.
      if (frame_q) begin
`ifdef REVX_VIDEO_DIAG_VALID_MUTANT
        if (1'b1) begin // negative control: trust unobserved native I/O reset zeros
`else
        if (dpyvalid_q) begin
`endif
`ifdef REVX_VIDEO_DIAG_PAGE_REGION_MUTANT
          if (first_seen && dpydata_q[20]==first_dpyst[20]) repeats<=inc16(repeats);
`else
          if (first_seen && dpydata_q==first_dpyst) repeats<=inc16(repeats);
`endif
          first_dpyst<=dpydata_q; first_seen<=1;
        end
      end
      // Actual L2.0 starts are 000001c0/000fe1c0 (row bases 0/1fc00).
      // They are 254 rows apart, NOT two 128K-word aligned regions. Observe
      // committed native register state; never infer publication from a VRAM
      // address bit or look for suppressed native writes on the external bus.
      if (dpyvalid_q) begin
        dpyst_shadow<=dpydata_q; dpyst_seen<=1;
        if (dpyst_seen && dpydata_q!=dpyst_shadow) publications<=inc16(publications);
      end
      if (busy_d && !busy_q) last_drain<=visible_q ? y_q+16'd1 : 16'd0;
      // Exact unchanged L2.0 opcode-acceptance PC anchors. The legacy CPU start
      // tap also pulses on IRQ entry, so the wrapper excludes that event.
      // instr_word_o holds the PREVIOUS opcode and must not gate these PCs.
      // A display
      // IRQ first checks the software DMA queue. Its CPU check is reached only
      // if that queue is empty. The common overload target is classified by
      // whether that same IRQ reached the CPU check. No register is modified.
      if (accept_q) begin
        case (pc_q)
          32'h20812ab0: begin
            q_seen<=1; if (route_pending) route_error<=1;
            route_pending<=1; cpu_path<=0;
          end
          32'h20812d60: begin
            cpu_seen<=1; cpu_path<=1; if (!route_pending) route_error<=1;
          end
          32'h20812ed0: begin
            normal_seen<=1; if (!route_pending) route_error<=1;
            route_pending<=0;
          end
          32'h20812e60: begin
            overload_seen<=1;
            if (!route_pending) route_error<=1;
`ifdef REVX_VIDEO_DIAG_ROUTE_MUTANT
            else if (!cpu_path) cpu_skips<=inc16(cpu_skips);
`else
            else if (cpu_path) cpu_skips<=inc16(cpu_skips);
`endif
            else dma_skips<=inc16(dma_skips);
            route_pending<=0;
          end
          default: ;
        endcase
      end
      if (frame_q) begin
        frames<=frames+24'd1;
        values[  0 +: 32]<={8'hd3,frames+24'd1}; // ID: version + live frame count
        values[ 32 +: 32]<=clocks;               // FC: fabric clocks/frame
        values[ 64 +: 32]<=vwords;               // BW: committed VRAM words/frame
        values[ 96 +: 32]<=gfxbeats;              // GB: graphics DDR 64-bit beats/frame
        values[128 +: 32]<=srcclks;               // SW: source request wait clocks/frame
        values[160 +: 32]<=fbclks;                // DW: framebuffer request wait clocks/frame
        values[192 +: 32]<={scan_max,scan_bursts}; // SB: sticky worst wait / bursts in preceding frame
        values[224 +: 32]<=misses;                // UN: all requested pixel deadline misses
        values[256 +: 32]<=disabled_pixels;       // DV: ENV-disabled native pixels in top 64 rows
        values[288 +: 32]<=blits;                 // BL: physically completed commands/frame
        values[320 +: 32]<={publications,repeats}; // PF: DPYST changes / repeated frame starts
        values[352 +: 32]<={dma_skips,cpu_skips};  // SK: exact-ROM DMA / CPU overload skips
        values[384 +: 32]<={late_frames,last_drain};// LF: busy-at-first-line frames / drain row+1
        values[416 +: 32]<={dpyst_seen,first_seen,q_seen,cpu_seen,
          normal_seen,overload_seen,route_error,7'd0,front_row}; // CV: validity/coverage + first row
        // Boundary-cycle work belongs to the new frame, so no event is lost.
        clocks<=1; vwords<={26'd0,write_words}; gfxbeats<={31'd0,gfx_q};
        srcclks<={31'd0,src_q}; fbclks<={31'd0,fbwait_q}; blits<={31'd0,done_q};
        scan_bursts<={15'd0,(scan_ack_q && !scan_ack_d)};
      end
    end
  end
endmodule
`default_nettype wire

// Transparent lower-corner view; the top game HUD is completely unobscured.
// The font and three-stage geometry pipeline preserve the established renderer.
`default_nettype none
module revx_video_diag_overlay #(parameter bit SHOW_TEXT=1'b1)(
  input logic clk, ce_pix, rst,
  input logic [447:0] values,
  input logic [7:0] g_r,g_g,g_b,
  input logic g_hs,g_vs,g_hb,g_vb,g_de,
  output logic [7:0] vid_r,vid_g,vid_b,
  output logic hsync,vsync,hblank,vblank,de
);
  function automatic [7:0] hx(input [3:0] n);   // nibble -> ASCII (mirrors telemetry hx())
    hx = (n < 4'ha) ? (8'h30 + {4'd0,n}) : (8'h41 + {4'd0,n} - 8'd10);
  endfunction
  function automatic [4:0] glyph(input [7:0] ch, input [2:0] row);
    logic [34:0] f;
    case (ch)
      "0": f={5'b01110,5'b10001,5'b10011,5'b10101,5'b11001,5'b10001,5'b01110};
      "1": f={5'b00100,5'b01100,5'b00100,5'b00100,5'b00100,5'b00100,5'b01110};
      "2": f={5'b01110,5'b10001,5'b00001,5'b00010,5'b00100,5'b01000,5'b11111};
      "3": f={5'b11110,5'b00001,5'b00001,5'b01110,5'b00001,5'b00001,5'b11110};
      "4": f={5'b00010,5'b00110,5'b01010,5'b10010,5'b11111,5'b00010,5'b00010};
`ifdef REVX_VIDEO_DIAG_GLYPH_MUTANT
      "5": f={5'b11111,5'b10000,5'b10000,5'b10000,5'b00001,5'b00001,5'b11110}; // MUTANT: row3 corrupted
`else
      "5": f={5'b11111,5'b10000,5'b10000,5'b11110,5'b00001,5'b00001,5'b11110};
`endif
      "6": f={5'b01110,5'b10000,5'b10000,5'b11110,5'b10001,5'b10001,5'b01110};
      "7": f={5'b11111,5'b00001,5'b00010,5'b00100,5'b01000,5'b01000,5'b01000};
      "8": f={5'b01110,5'b10001,5'b10001,5'b01110,5'b10001,5'b10001,5'b01110};
      "9": f={5'b01110,5'b10001,5'b10001,5'b01111,5'b00001,5'b00001,5'b01110};
      "A": f={5'b01110,5'b10001,5'b10001,5'b11111,5'b10001,5'b10001,5'b10001};
      "B": f={5'b11110,5'b10001,5'b10001,5'b11110,5'b10001,5'b10001,5'b11110};
      "C": f={5'b01111,5'b10000,5'b10000,5'b10000,5'b10000,5'b10000,5'b01111};
      "D": f={5'b11110,5'b10001,5'b10001,5'b10001,5'b10001,5'b10001,5'b11110};
      "E": f={5'b11111,5'b10000,5'b10000,5'b11110,5'b10000,5'b10000,5'b11111};
      "F": f={5'b11111,5'b10000,5'b10000,5'b11110,5'b10000,5'b10000,5'b10000};
      "G": f={5'b01111,5'b10000,5'b10000,5'b10111,5'b10001,5'b10001,5'b01111};
      "H": f={5'b10001,5'b10001,5'b10001,5'b11111,5'b10001,5'b10001,5'b10001};
      "U": f={5'b10001,5'b10001,5'b10001,5'b10001,5'b10001,5'b10001,5'b01110};
      "V": f={5'b10001,5'b10001,5'b10001,5'b10001,5'b10001,5'b01010,5'b00100};
      "W": f={5'b10001,5'b10001,5'b10001,5'b10101,5'b10101,5'b10101,5'b01010};
      "Q": f={5'b01110,5'b10001,5'b10001,5'b10001,5'b10101,5'b10010,5'b01101};
      "I": f={5'b01110,5'b00100,5'b00100,5'b00100,5'b00100,5'b00100,5'b01110};
      "K": f={5'b10001,5'b10010,5'b10100,5'b11000,5'b10100,5'b10010,5'b10001};
      "L": f={5'b10000,5'b10000,5'b10000,5'b10000,5'b10000,5'b10000,5'b11111};
      "O": f={5'b01110,5'b10001,5'b10001,5'b10001,5'b10001,5'b10001,5'b01110};
      "P": f={5'b11110,5'b10001,5'b10001,5'b11110,5'b10000,5'b10000,5'b10000};
      "R": f={5'b11110,5'b10001,5'b10001,5'b11110,5'b10100,5'b10010,5'b10001};
      "S": f={5'b01111,5'b10000,5'b10000,5'b01110,5'b00001,5'b00001,5'b11110};
      "T": f={5'b11111,5'b00100,5'b00100,5'b00100,5'b00100,5'b00100,5'b00100};
      default: f=35'd0;   // space and anything unused -> blank
    endcase
    case (row)
      3'd0: glyph=f[34:30]; 3'd1: glyph=f[29:25]; 3'd2: glyph=f[24:20];
      3'd3: glyph=f[19:15]; 3'd4: glyph=f[14:10]; 3'd5: glyph=f[9:5];
      3'd6: glyph=f[4:0];   default: glyph=5'd0;
    endcase
  endfunction


  logic [447:0] values_q;
  (* ramstyle = "logic" *) logic [7:0] gr_q,gg_q,gb_q;
  (* ramstyle = "logic" *) logic ghs_q,gvs_q,ghb_q,gvb_q,gde_q;
  always_ff @(posedge clk) if (ce_pix) begin
    values_q<=values;
    gr_q<=g_r; gg_q<=g_g; gb_q<=g_b;
    ghs_q<=g_hs; gvs_q<=g_vs; ghb_q<=g_hb; gvb_q<=g_vb; gde_q<=g_de;
  end
  logic [11:0] gx,gy;
  logic de_q,vb_q;
  always_ff @(posedge clk) begin
    if (rst) begin gx<=0; gy<=0; de_q<=0; vb_q<=0; end
    else if (ce_pix) begin
      de_q<=gde_q; vb_q<=gvb_q;
      if (gvb_q && !vb_q) begin gy<=0; gx<=0; end
      else if (gde_q) gx<=gx+12'd1;
      else if (de_q && !gde_q) begin gx<=0; gy<=gy+12'd1; end
    end
  end
  function automatic [31:0] rowval(input [4:0] r);
    case (r)
      5'd0: rowval=values_q[0 +: 32];
      5'd1: rowval=values_q[32 +: 32];
      5'd2: rowval=values_q[64 +: 32];
      5'd3: rowval=values_q[96 +: 32];
      5'd4: rowval=values_q[128 +: 32];
      5'd5: rowval=values_q[160 +: 32];
      5'd6: rowval=values_q[192 +: 32];
      5'd7: rowval=values_q[224 +: 32];
      5'd8: rowval=values_q[256 +: 32];
      5'd9: rowval=values_q[288 +: 32];
      5'd10: rowval=values_q[320 +: 32];
      5'd11: rowval=values_q[352 +: 32];
      5'd12: rowval=values_q[384 +: 32];
      5'd13: rowval=values_q[416 +: 32];
      default: rowval=0;
    endcase
  endfunction
  function automatic [15:0] rowtag(input [4:0] r);
    case (r)
      5'd0: rowtag="ID";
      5'd1: rowtag="FC";
      5'd2: rowtag="BW";
      5'd3: rowtag="GB";
      5'd4: rowtag="SW";
      5'd5: rowtag="DW";
      5'd6: rowtag="SB";
      5'd7: rowtag="UN";
      5'd8: rowtag="DV";
      5'd9: rowtag="BL";
      5'd10: rowtag="PF";
      5'd11: rowtag="SK";
      5'd12: rowtag="LF";
      5'd13: rowtag="CV";
      default: rowtag="  ";
    endcase
  endfunction
  // ---- geometry: 7 y-bands (pitch 10) x 2 columns x (2 tag + space + 8 hex) cells ----
  localparam int X0L = 4, X0R = 270, CW = 6, NCH = 11, COLW = NCH*CW; // 66 px per column
  // ---- render PIPELINE (TIMING FIX for slow-corner gx -> vid_b cone) --------------------------
  // Model 1's telemetry overlay (model1_telemetry_overlay.sv:259-555) splits the per-pixel text
  // renderer across registered stages so no single combinational cone runs from the pixel counter
  // to the video output.  The RevX restyle (commit 3ca933a) took Model 1's font+layout but kept the
  // renderer FLAT: gx -> (xoff*171 /6) -> rowval() 16:1 mux -> nibble shift -> glyph() ROM -> pixel
  // mux -> vid_* was one cone (STA: 12 logic levels, 16.6 ns @ Slow/100C, slack -4.4 ns).  Below it
  // is cut into 3 registered stages (r1/r2/r3) ahead of the existing output register, mirroring the
  // Model 1 "_s1 addressing stage, then registered rgb_out" shape.
  //
  // LATENCY COMPENSATION: the visible output is IDENTICAL to the flat version, delayed by exactly
  // 3 ce_pix ticks.  The passthrough video AND the sync/de/blank are delayed by the SAME 3 ticks
  // (gr_d*/gg_d*/gb_d* and gde_d*/ghs_d*/... below), so the ENTIRE output stream is uniformly
  // shifted -- every glyph lands at the same (gx,gy) relative to the game raster and the syncs.
  // (Proof: new vid(t)=f(gde,glyph_on(gx),gr) each fed from signals delayed 3, so new vid(t)==old
  // vid(t-3); likewise every sync.)  The gate re-derives (x,y) from the DUT's OWN output de/vblank,
  // so it needs no latency constant and the golden lands at the same coordinates.
  //   S0 (comb, gx/gy):  band decode + column decode + xoff*171 /6 -> celln            -> r1
  //   S1 (comb, r1):     celln*6 -> fx, rowidx, digidx, rowval() 16:1, rowtag()        -> r2
  //   S2 (comb, r2):     nibble select (8:1, == rv>>((7-digidx)*4)) -> ch              -> r3
  //   S3 (comb, r3):     glyph() ROM -> fpix -> {white | passthrough}                  -> output reg

  // -- S0 combinational: geometry from the pixel counters --
  logic [3:0] yrow0; logic [2:0] frow0; logic in_band0;
  always_comb begin
    in_band0=1'b0; yrow0=3'd0; frow0=3'd0;
    if (gy>=12'd146 && gy<=12'd152) begin yrow0=4'd0; frow0=(gy-12'd146); in_band0=1'b1; end
    else if (gy>=12'd156 && gy<=12'd162) begin yrow0=4'd1; frow0=(gy-12'd156); in_band0=1'b1; end
    else if (gy>=12'd166 && gy<=12'd172) begin yrow0=4'd2; frow0=(gy-12'd166); in_band0=1'b1; end
    else if (gy>=12'd176 && gy<=12'd182) begin yrow0=4'd3; frow0=(gy-12'd176); in_band0=1'b1; end
    else if (gy>=12'd186 && gy<=12'd192) begin yrow0=4'd4; frow0=(gy-12'd186); in_band0=1'b1; end
    else if (gy>=12'd196 && gy<=12'd202) begin yrow0=4'd5; frow0=(gy-12'd196); in_band0=1'b1; end
    else if (gy>=12'd206 && gy<=12'd212) begin yrow0=4'd6; frow0=(gy-12'd206); in_band0=1'b1; end
  end
  wire        in_left0  = (gx >= X0L) && (gx < X0L + COLW);
  wire        in_right0 = (gx >= X0R) && (gx < X0R + COLW);
  wire        in_col0   = in_left0 || in_right0;
  wire [11:0] xoff0     = in_right0 ? (gx - X0R[11:0]) : (gx - X0L[11:0]);   // 0..65 when in_col
  // floor(xoff/6) == (xoff*171)>>10 over 0..207 -- IDENTICAL to the flat version's divide.
  wire [23:0] xmul0     = xoff0 * 24'd171;
  wire [7:0]  celln0    = xmul0[17:10];                                      // 0..10

  logic in_band_1, in_col_1, colsel_1;
  logic [3:0] yrow_1; logic [2:0] frow_1;
  logic [6:0] xoff_1;                 // 0..65 in-column; only fx uses it
  logic [7:0] celln_1;
  always_ff @(posedge clk) if (ce_pix) begin
    in_band_1<=in_band0; in_col_1<=in_col0; colsel_1<=in_right0;
    yrow_1<=yrow0; frow_1<=frow0; xoff_1<=xoff0[6:0]; celln_1<=celln0;
  end

  // -- S1 combinational: cell/char index resolution + row value/tag mux --
  wire [11:0] cellx6_1 = ({4'd0,celln_1} << 2) + ({4'd0,celln_1} << 1);     // celln*6
  wire [2:0]  fx_1     = xoff_1 - cellx6_1[6:0];                            // 0..5 (5 = gap)
  wire [4:0]  rowidx_1 = {1'b0,yrow_1} + (colsel_1 ? 5'd7 : 5'd0);
  wire [2:0]  digidx_1 = celln_1[2:0] - 3'd3;                               // valid celln 3..10
  wire [31:0] rv_1     = rowval(rowidx_1);
  wire [15:0] tagw_1   = rowtag(rowidx_1);

  logic in_band_2, in_col_2;
  logic [2:0] frow_2, fx_2, digidx_2;
  logic [7:0] celln_2;
  logic [31:0] rv_2; logic [15:0] tagw_2;
  always_ff @(posedge clk) if (ce_pix) begin
    in_band_2<=in_band_1; in_col_2<=in_col_1; frow_2<=frow_1; fx_2<=fx_1;
    digidx_2<=digidx_1; celln_2<=celln_1; rv_2<=rv_1; tagw_2<=tagw_1;
  end

  // -- S2 combinational: select this cell's character --
  // nibble select is an 8:1 mux == (rv_2 >> ((7-digidx_2)*4))[3:0], bit-identical to the flat form
  // and to the gate's exp_rowval>>((10-celln)*4); it avoids a 32-bit barrel shifter on the cone.
  logic [3:0] nyb_2; logic [7:0] ch_2;
  always_comb begin
    case (digidx_2)
      3'd0: nyb_2 = rv_2[31:28]; 3'd1: nyb_2 = rv_2[27:24]; 3'd2: nyb_2 = rv_2[23:20];
      3'd3: nyb_2 = rv_2[19:16]; 3'd4: nyb_2 = rv_2[15:12]; 3'd5: nyb_2 = rv_2[11:8];
      3'd6: nyb_2 = rv_2[7:4];   default: nyb_2 = rv_2[3:0];
    endcase
    ch_2 = (celln_2 == 8'd0) ? tagw_2[15:8] :
           (celln_2 == 8'd1) ? tagw_2[7:0]  :
           (celln_2 == 8'd2) ? 8'h20        : hx(nyb_2);
  end

  logic [7:0] ch_3; logic [2:0] frow_3, fx_3; logic valid_3;
  always_ff @(posedge clk) if (ce_pix) begin
    ch_3<=ch_2; frow_3<=frow_2; fx_3<=fx_2; valid_3<=(in_band_2 && in_col_2);
  end

  // -- S3 combinational: glyph ROM -> this pixel --
  wire [4:0] gbits_3 = glyph(ch_3, frow_3);
  // glyph bit for this column: fx 0..4 select MSB..LSB (leftmost pixel = gbits[4]); fx 5 = gap.
  wire       fpix_3     = (fx_3 < 3'd5) ? gbits_3[3'd4 - fx_3] : 1'b0;
  wire       glyph_on   = SHOW_TEXT && valid_3 && fpix_3;
  wire       in_overlay = SHOW_TEXT && valid_3;     // text region (used only by the BG mutant)

  // -- passthrough video + timing, delayed by the SAME 3 ce_pix ticks as the glyph pipeline --
  (* ramstyle = "logic" *) logic [7:0] gr_d1,gr_d2,gr_d3, gg_d1,gg_d2,gg_d3, gb_d1,gb_d2,gb_d3;
  (* ramstyle = "logic" *) logic ghs_d1,ghs_d2,ghs_d3, gvs_d1,gvs_d2,gvs_d3, ghb_d1,ghb_d2,ghb_d3;
  (* ramstyle = "logic" *) logic gvb_d1,gvb_d2,gvb_d3, gde_d1,gde_d2,gde_d3;
  always_ff @(posedge clk) if (ce_pix) begin
    gr_d1<=gr_q;   gr_d2<=gr_d1;   gr_d3<=gr_d2;
    gg_d1<=gg_q;   gg_d2<=gg_d1;   gg_d3<=gg_d2;
    gb_d1<=gb_q;   gb_d2<=gb_d1;   gb_d3<=gb_d2;
    ghs_d1<=ghs_q; ghs_d2<=ghs_d1; ghs_d3<=ghs_d2;
    gvs_d1<=gvs_q; gvs_d2<=gvs_d1; gvs_d3<=gvs_d2;
    ghb_d1<=ghb_q; ghb_d2<=ghb_d1; ghb_d3<=ghb_d2;
    gvb_d1<=gvb_q; gvb_d2<=gvb_d1; gvb_d3<=gvb_d2;
    gde_d1<=gde_q; gde_d2<=gde_d1; gde_d3<=gde_d2;
  end

  // ---- output: white glyph over unchanged pass-through (no panel, no dim) ----
  always_ff @(posedge clk) if (ce_pix) begin
    de<=gde_d3; hsync<=ghs_d3; vsync<=gvs_d3; hblank<=ghb_d3; vblank<=gvb_d3;
    if (!gde_d3)         begin vid_r<=8'd0;  vid_g<=8'd0;  vid_b<=8'd0;  end   // blank
    else if (glyph_on)   begin vid_r<=8'hFF; vid_g<=8'hFF; vid_b<=8'hFF; end   // white glyph
    else begin
`ifdef REVX_VIDEO_DIAG_BG_MUTANT
      if (in_overlay)    begin vid_r<=8'h10; vid_g<=8'h10; vid_b<=8'h30; end   // MUTANT panel (must FAIL transparency)
      else               begin vid_r<=gr_d3; vid_g<=gg_d3; vid_b<=gb_d3; end
`else
                         begin vid_r<=gr_d3; vid_g<=gg_d3; vid_b<=gb_d3; end   // pass-through UNCHANGED
`endif
    end
  end
endmodule
`default_nettype wire
