package require ::quartus::project
package require ::quartus::sta

project_open Arcade-LegendOfKage -revision Arcade-LegendOfKage
create_timing_netlist
read_sdc
update_timing_netlist

set core_clk [get_clocks {*emu|pll|*PLL_OUTPUT_COUNTER|divclk}]
report_timing -from_clock $core_clk -to_clock $core_clk -setup \
    -npaths 20 -detail full_path -file output_files/core_setup_timing.rpt
report_timing -from_clock $core_clk -to_clock $core_clk -hold \
    -npaths 20 -detail full_path -file output_files/core_hold_timing.rpt

delete_timing_netlist
project_close
