$ErrorActionPreference = "Stop"

throw @'
The legacy all-in-one build is intentionally disabled.

Legend qualification must run through qualification/run_fifo_qualified_build.sh
under the shared Quartus FIFO. That chain holds one ticket through map, fit,
physical-topology audit, complete multicorner STA, fail-closed timing gate, and
only then assembly. It leaves any qualified artifact in output_files and never
copies an unqualified result into releases.
'@
