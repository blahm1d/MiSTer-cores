// Generated from the OSD generation projection; do not edit.
// Generation SHA256: 53faeacc9b9f701e3a807af2adbcd47c1ae8edcad6ccbe5818fc07fa00bf0166
// No two-flop status-level source packing is required.
