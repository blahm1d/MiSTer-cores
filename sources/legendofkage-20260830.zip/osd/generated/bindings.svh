// Generated from the OSD generation projection; do not edit.
// Generation SHA256: 53faeacc9b9f701e3a807af2adbcd47c1ae8edcad6ccbe5818fc07fa00bf0166
// Raw destination/source-native status indexing is confined here.
wire osd_reset = status[0];
wire [2:0] osd_scaler_effects = (status[5:3] <= 3'd4) ? status[5:3] : 3'd0;
wire osd_flip_screen = status[6];
wire osd_service = status[7];
wire osd_raster_timing = status[8];
wire signed [3:0] osd_crt_hsync_adjust = $signed(status[27:24]);
wire signed [3:0] osd_crt_vsync_adjust = $signed(status[31:28]);
wire [15:0] osd_status_menumask =
    16'h0000;
