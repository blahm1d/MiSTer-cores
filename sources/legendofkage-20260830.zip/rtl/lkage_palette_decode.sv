// MAME palette_device::xRGB_444 byte layout on the Z80's 8-bit bus:
//   even address: GGGGBBBB
//   odd address:  xxxxRRRR
// The four unused high bits of the odd byte are intentionally ignored.
module lkage_palette_decode (
    input  wire [7:0] even_byte,
    input  wire [7:0] odd_byte,
    output wire [11:0] rgb444
);
    assign rgb444 = {odd_byte[3:0], even_byte[7:4], even_byte[3:0]};
endmodule
