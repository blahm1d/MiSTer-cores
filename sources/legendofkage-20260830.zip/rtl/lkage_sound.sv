// Legend of Kage sound board: 4 MHz Z80, two 4 MHz YM2203s, and the
// main-to-sound latch/NMI gate documented by MAME.
module lkage_sound (
    input  wire         clk,
    input  wire         reset,
    input  wire         cen4,

    input  wire         rom_we,
    input  wire [14:0]  rom_wr_addr,
    input  wire [7:0]   rom_wr_data,

    input  wire [7:0]   sound_latch,
    input  wire         latch_pending,
    output reg          latch_ack,

    output wire [15:0]  audio
);

`ifdef LKAGE_BRINGUP
    // The first hardware image concentrates on CPU/video validation.  The
    // complete sound implementation remains below and is selected simply by
    // removing LKAGE_BRINGUP from the Quartus project.
    assign audio = 16'd0;
    always @(posedge clk) begin
        if (reset) latch_ack <= 1'b0;
        else       latch_ack <= latch_pending;
    end
`else

    wire [15:0] cpu_addr;
    wire [7:0]  cpu_dout;
    reg  [7:0]  cpu_din;
    wire m1_n, mreq_n, iorq_n, rd_n, wr_n, rfsh_n;
    wire halt_n, busak_n;

    wire [7:0] rom_q;
    lkage_dpram #(.AW(15)) u_sound_rom (
        .clk_a  (clk), .addr_a(rom_wr_addr), .data_a(rom_wr_data),
        .we_a   (rom_we), .q_a(),
        .clk_b  (clk), .addr_b(cpu_addr[14:0]), .data_b(8'd0),
        .we_b   (1'b0), .q_b(rom_q)
    );

    reg prev_wr_n, prev_rd_n;
    wire cpu_write = prev_wr_n && !wr_n && !mreq_n;
    wire cpu_read  = prev_rd_n && !rd_n && !mreq_n;

    wire ram_cs = !mreq_n && (cpu_addr >= 16'h8000) && (cpu_addr <= 16'h87ff);
    wire [7:0] ram_q;
    lkage_dpram #(.AW(11)) u_sound_ram (
        .clk_a  (clk), .addr_a(cpu_addr[10:0]), .data_a(cpu_dout),
        .we_a   (cpu_write && ram_cs), .q_a(ram_q),
        .clk_b  (clk), .addr_b(11'd0), .data_b(8'd0),
        .we_b   (1'b0), .q_b()
    );

    wire ym1_cs = !mreq_n && (cpu_addr[15:1] == 15'h4800);
    wire ym2_cs = !mreq_n && (cpu_addr[15:1] == 15'h5000);
    wire [7:0] ym1_dout, ym2_dout;
    wire ym1_irq_n, ym2_irq_n;
    wire [9:0] ym1_psg, ym2_psg;
    wire signed [15:0] ym1_fm, ym2_fm;
    wire signed [15:0] ym1_mix, ym2_mix;

    jt03 u_ym1 (
        .rst(reset), .clk(clk), .cen(cen4),
        .din(cpu_dout), .addr(cpu_addr[0]), .cs_n(~ym1_cs), .wr_n(wr_n),
        .dout(ym1_dout), .irq_n(ym1_irq_n),
        .IOA_in(8'hff), .IOB_in(8'hff), .IOA_out(), .IOB_out(),
        .IOA_oe(), .IOB_oe(), .psg_A(), .psg_B(), .psg_C(),
        .fm_snd(ym1_fm), .psg_snd(ym1_psg), .snd(ym1_mix),
        .snd_sample(), .debug_view()
    );

    jt03 u_ym2 (
        .rst(reset), .clk(clk), .cen(cen4),
        .din(cpu_dout), .addr(cpu_addr[0]), .cs_n(~ym2_cs), .wr_n(wr_n),
        .dout(ym2_dout), .irq_n(ym2_irq_n),
        .IOA_in(8'hff), .IOB_in(8'hff), .IOA_out(), .IOB_out(),
        .IOA_oe(), .IOB_oe(), .psg_A(), .psg_B(), .psg_C(),
        .fm_snd(ym2_fm), .psg_snd(ym2_psg), .snd(ym2_mix),
        .snd_sample(), .debug_view()
    );

    // The first YM2203 is the board's Z80 interrupt source.
    reg nmi_enable;
    wire nmi_n = ~(latch_pending && nmi_enable);

    T80s u_sound_cpu (
        .RESET_n(~reset), .CLK(clk), .CEN(cen4), .WAIT_n(1'b1),
        .INT_n(ym1_irq_n), .NMI_n(nmi_n), .BUSRQ_n(1'b1), .OUT0(1'b0),
        .DI(cpu_din), .DOUT(cpu_dout), .A(cpu_addr),
        .M1_n(m1_n), .MREQ_n(mreq_n), .IORQ_n(iorq_n),
        .RD_n(rd_n), .WR_n(wr_n), .RFSH_n(rfsh_n),
        .HALT_n(halt_n), .BUSAK_n(busak_n)
    );

    always @(*) begin
        cpu_din = 8'hff;
        if (!mreq_n && !rd_n) begin
            if (cpu_addr < 16'h8000)
                cpu_din = rom_q;
            else if (cpu_addr >= 16'h8000 && cpu_addr <= 16'h87ff)
                cpu_din = ram_q;
            else if (cpu_addr[15:1] == 15'h4800)
                cpu_din = ym1_dout;
            else if (cpu_addr[15:1] == 15'h5000)
                cpu_din = ym2_dout;
            else if (cpu_addr == 16'hb000)
                cpu_din = sound_latch;
        end
    end

    always @(posedge clk) begin
        prev_wr_n <= wr_n;
        prev_rd_n <= rd_n;
        latch_ack <= 1'b0;

        if (reset) begin
            prev_wr_n <= 1'b1;
            prev_rd_n <= 1'b1;
            nmi_enable <= 1'b0;
        end else begin
            if (cpu_write && cpu_addr == 16'hb001) nmi_enable <= 1'b1;
            if (cpu_write && cpu_addr == 16'hb002) nmi_enable <= 1'b0;
            if (cpu_read  && cpu_addr == 16'hb000) latch_ack  <= 1'b1;
        end
    end

    // jt03's signed output already combines the FM and PSG sections.  Average
    // the two packages to retain headroom in MiSTer's signed 16-bit path.
    wire signed [16:0] audio_sum = $signed(ym1_mix) + $signed(ym2_mix);
    assign audio = audio_sum[16:1];

`endif

endmodule
