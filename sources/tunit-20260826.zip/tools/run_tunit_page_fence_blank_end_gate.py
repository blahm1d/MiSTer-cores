#!/usr/bin/env python3
"""Run the production page-publication seam across a finite vertical blank.

The benches follow NBA Jam TE's assembly order: DPYADR changes while the final
visible-page DMA is active, then the CPU clears the page software now regards
as hidden. They prove that publication and that destructive SRT write share one
ownership boundary, including the production one-cycle store-backend contract.
They also prove that a genuinely undrained page is held rather than forced
partial, then recovers on the next idle frame.
Icarus only; no Questa licence is taken.
"""

from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def compact(path: Path) -> str:
    return "".join(path.read_text(encoding="utf-8").split())


def verify_shipping_binding() -> bool:
    """Fail closed if the proven seam is not the production top-level seam."""
    top = compact(ROOT / "rtl/tunit/tunit_top.sv")
    mux = compact(ROOT / "rtl/tunit/tunit_store_mux.sv")
    fence = compact(ROOT / "rtl/tunit/tunit_page_fence.sv")
    required = (
        (top, ".vram_stall(srt_write_stall_w)", "store-mux stall port"),
        (
            top,
            "wirelogicnba_page_owner_profile_w=(profile_q==PROFILE_NBAJAM)||"
            "(profile_q==PROFILE_NBAJAM_TE);",
            "NBA/TE profile scope",
        ),
        (
            top,
            "assignsrt_write_stall_w=nba_page_owner_profile_w&&"
            "vram_srt_hw&&vram_we&&!srt_write_allow_w;",
            "shipping SRT-write stall expression",
        ),
        (
            top,
            ".srt_req(vram_start&&vram_srt_hw&&!srt_write_stall_w)",
            "shipping D-lane request gate",
        ),
        (
            mux,
            "S_START:if(!vram_stall)state<=S_WAIT;",
            "one-cycle backend-start retention",
        ),
        (
            fence,
            "assignsrt_write_allow=!(page_delta&&"
            "(armed||blank_window||late_live_proposal));",
            "page-owner release",
        ),
    )
    missing = [label for text, token, label in required if token not in text]
    if missing:
        print(
            "PAGE FENCE BLANK-END GATE: FAIL shipping binding missing: "
            + ", ".join(missing),
            file=sys.stderr,
        )
        return False
    return True


def main() -> int:
    if not verify_shipping_binding():
        return 1
    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    if not iverilog or not vvp:
        print("ERROR: iverilog/vvp not found", file=sys.stderr)
        return 2
    out_dir = ROOT / "sim/out"
    out_dir.mkdir(parents=True, exist_ok=True)
    sources = [
        ROOT / "rtl/tunit/tunit_page_fence.sv",
        ROOT / "sim/tb_tunit_page_fence_blank_end.sv",
    ]
    pass_marker = "RESULT: PASS tunit_page_fence_blank_end"
    kill_marker = "active-page clear released before page publication"
    for name, defines, should_pass in (
        ("production", (), True),
        ("early-srt-mutation", ("MUT_TUNIT_PAGE_OWNER_EARLY_SRT",), False),
    ):
        out = out_dir / f"tunit_page_fence_blank_end_{name}.vvp"
        result = subprocess.run(
            [iverilog, "-g2012", *(f"-D{item}" for item in defines),
             "-s", "tb_tunit_page_fence_blank_end", "-o", str(out),
             *(str(path) for path in sources)],
            cwd=ROOT, text=True, capture_output=True, check=False,
        )
        if result.returncode:
            print((result.stdout or "") + (result.stderr or ""), end="")
            return 1
        result = subprocess.run(
            [vvp, str(out)], cwd=ROOT, text=True, capture_output=True,
            timeout=300, check=False,
        )
        log = (result.stdout or "") + (result.stderr or "")
        print(log, end="")
        if should_pass:
            if result.returncode or pass_marker not in log:
                return 1
        elif (result.returncode == 0 or kill_marker not in log or
              pass_marker in log):
            print("PAGE FENCE BLANK-END GATE: FAIL (mutation survived)",
                  file=sys.stderr)
            return 1
        else:
            print("[mutation] early SRT clear rejected by retained-page oracle")

    # Bind the same release to the production D-lane and DDR model. This proves
    # that store_mux parks its one-cycle backend start, the displayed old page
    # remains readable, and the clear makes forward progress after commit.
    integrated_sources = [
        ROOT / "rtl/common/tunit_pkg.sv",
        ROOT / "rtl/tunit/tunit_page_fence.sv",
        ROOT / "rtl/tunit/tunit_local_store.sv",
        ROOT / "rtl/tunit/tunit_store_mux.sv",
        ROOT / "rtl/sdram/vram_sdram.sv",
        ROOT / "rtl/sdram/vram_sdram_top.sv",
        ROOT / "rtl/sdram/stv_vram_ddr_agent.sv",
        ROOT / "rtl/sdram/stv_vram_ddr_top.sv",
        ROOT / "sim/models/ddr3_avalon_model.sv",
        ROOT / "sim/tb_tunit_page_owner_srt.sv",
    ]
    integrated_pass = (
        "RESULT: PASS tunit_page_owner_srt "
        "source-order+retention+forward-progress+missed-window+"
        "read-pass+profile-scope"
    )
    integrated_kill = "active-page SRT clear retired before page publication"
    for name, defines, should_pass in (
        ("owner-srt-production", (), True),
        ("owner-srt-mutation", ("MUT_TUNIT_PAGE_OWNER_EARLY_SRT",), False),
    ):
        out = out_dir / f"tunit_page_fence_blank_end_{name}.vvp"
        result = subprocess.run(
            [iverilog, "-g2012", *(f"-D{item}" for item in defines),
             "-s", "tb_tunit_page_owner_srt", "-o", str(out),
             *(str(path) for path in integrated_sources)],
            cwd=ROOT, text=True, capture_output=True, check=False,
        )
        if result.returncode:
            print((result.stdout or "") + (result.stderr or ""), end="")
            return 1
        result = subprocess.run(
            [vvp, str(out)], cwd=ROOT, text=True, capture_output=True,
            timeout=300, check=False,
        )
        log = (result.stdout or "") + (result.stderr or "")
        print(log, end="")
        if should_pass:
            if result.returncode or integrated_pass not in log:
                return 1
        elif (result.returncode == 0 or integrated_kill not in log or
              integrated_pass in log):
            print("PAGE FENCE BLANK-END GATE: FAIL "
                  "(integrated mutation survived)", file=sys.stderr)
            return 1
        else:
            print("[mutation] real D-lane early clear rejected")
    print("PAGE FENCE BLANK-END GATE: PASS "
          "page-owner-mutation=killed d-lane=bound shipping=bound")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
