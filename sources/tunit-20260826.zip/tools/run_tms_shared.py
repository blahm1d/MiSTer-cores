#!/usr/bin/env python3
"""Compile the TMS34010 RTL once, then run each TB in an isolated library."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess
import sys

# A ModelSim ASE licence death is INCONCLUSIVE, never a FAIL.
#
# The ASE licence is nodelocked to ONE vsim across every core session on this box, so a
# sibling taking it kills this run mid-bench. Both verdicts here were
# `ok = returncode == 0 and marker in log`, which turns "someone took my licence" into
# "my RTL is broken" -- a FALSE RED that cost this project a non-reproducible 27/27
# claim. Flagged by the Gladiator session, who had the identical ordering.
#
# Exit 75 distinguishes it: not pass, not fail, no information.
LICENCE_DEATH_MARKERS = (
    "vish lost connection to vsim process",
    "Unable to checkout a license",
    "Licensing error",
    "License checkout failed",
    "MGLS_LICENSE_FILE",
    "queuing for license",
)


def licence_died(log: str) -> bool:
    low = log.lower()
    return any(m.lower() in low for m in LICENCE_DEATH_MARKERS)




def run(command: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=cwd, text=True, capture_output=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", default="tb_*.sv")
    parser.add_argument("--label", required=True)
    parser.add_argument("--define", action="append", default=[])
    parser.add_argument("--stop-on-fail", action="store_true")
    args = parser.parse_args()

    tools = {name: shutil.which(name) for name in ("vlib", "vlog", "vsim")}
    missing = [name for name, path in tools.items() if path is None]
    if missing:
        print("ERROR: missing simulator tools: " + ", ".join(missing), file=sys.stderr)
        return 2

    root = Path(__file__).resolve().parents[1]
    tms = root / "rtl" / "tms34010"
    tests = sorted((tms / "sim" / "tb").glob(args.pattern))
    if not tests:
        print(f"ERROR: no tests match {args.pattern}", file=sys.stderr)
        return 2

    out = root / "sim" / "out" / args.label / "shared"
    if out.exists():
        print(f"ERROR: output already exists; choose a new --label: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    package = tms / "rtl" / "tms34010_pkg.sv"
    rtl = sorted(path for path in (tms / "rtl").rglob("*.sv") if path != package)
    models = sorted((tms / "sim" / "models").glob("*.sv"))
    core_sources = [package, *rtl, *models]

    result = run([tools["vlib"], "corelib"], out)
    if result.returncode != 0:
        (out / "core_compile.log").write_text(result.stdout + result.stderr, encoding="utf-8", errors="replace")
        print("ERROR: vlib corelib failed", file=sys.stderr)
        return 1

    defines = [f"+define+{value}" for value in args.define]
    result = run([tools["vlog"], "-sv", "-work", "corelib", *defines, *map(str, core_sources)], out)
    core_log = (result.stdout or "") + (result.stderr or "")
    (out / "core_compile.log").write_text(core_log, encoding="utf-8", errors="replace")
    if result.returncode != 0:
        print("ERROR: core compilation failed; see core_compile.log", file=sys.stderr)
        return 1

    passed: list[str] = []
    failed: list[str] = []
    inconclusive = 0
    for index, test in enumerate(tests, 1):
        library = f"tb{index:03d}"
        lib_result = run([tools["vlib"], library], out)
        compile_result = run(
            [tools["vlog"], "-sv", "-work", library, "-L", "corelib", *defines, str(test)], out
        )
        compile_log = (lib_result.stdout or "") + (lib_result.stderr or "")
        compile_log += (compile_result.stdout or "") + (compile_result.stderr or "")
        if lib_result.returncode != 0 or compile_result.returncode != 0:
            (out / f"{test.stem}.log").write_text(compile_log, encoding="utf-8", errors="replace")
            failed.append(test.stem)
            print(f"[{index:03d}/{len(tests):03d}] FAIL {test.stem} (compile)", flush=True)
            if args.stop_on_fail:
                break
            continue

        sim_result = run(
            [tools["vsim"], "-c", "-L", "corelib", "-do", "run -all; quit -f", f"{library}.{test.stem}"], out
        )
        log = compile_log + (sim_result.stdout or "") + (sim_result.stderr or "")
        (out / f"{test.stem}.log").write_text(log, encoding="utf-8", errors="replace")
        if licence_died(log):
            print(f"[{index:03d}/{len(tests):03d}] INCONCLUSIVE {test.stem} (ASE licence died -- not an RTL result)", flush=True)
            inconclusive += 1
            continue
        ok = sim_result.returncode == 0 and "TEST_RESULT: PASS" in log
        (passed if ok else failed).append(test.stem)
        print(f"[{index:03d}/{len(tests):03d}] {'PASS' if ok else 'FAIL'} {test.stem}", flush=True)
        if not ok and args.stop_on_fail:
            break

    attempted = len(passed) + len(failed) + inconclusive
    summary = [
        f"label={args.label}",
        f"selected={len(tests)}",
        f"run={attempted}",
        f"passed={len(passed)}",
        f"failed={len(failed)}",
        f"inconclusive={inconclusive}",
        "failed_tests=" + ",".join(failed),
    ]
    (out / "summary.txt").write_text("\n".join(summary) + "\n", encoding="utf-8")
    print(" ".join(summary))
    if failed or attempted != len(tests):
        return 1
    if inconclusive:
        return 75
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
