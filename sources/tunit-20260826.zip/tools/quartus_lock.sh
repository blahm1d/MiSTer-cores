#!/usr/bin/env bash
# Machine-wide Quartus mutex, shared by every core session on this box.
#
# THE PATH IS THE CONTRACT: /tmp/fpga_quartus.lock
#
# Several core sessions (T-unit, Wolf, Y-unit/Smash T.V., NARC/Z-unit, Gladiator)
# share one machine. A fit is ~25 min and ~2.5 GB, and concurrent fits kill each
# other. Etiquette alone already failed once here, and it failed SILENTLY: the
# Questa mutex had T-unit on /tmp/tunit-questa.lock while three other sessions
# were on /tmp/umk3_questa.lock, so four sessions each believed they were
# interlocked while one of them was interlocked with nobody. A second
# implementation of this lock would recreate exactly that, so do NOT write
# another one -- adopt this path verbatim.
#
# Usage:
#   tools/quartus_lock.sh <command> [args...]
#   tools/quartus_lock.sh --status
#
#   tools/quartus_lock.sh bash -c '
#     quartus_map.exe Arcade-TUnit && quartus_fit.exe Arcade-TUnit && quartus_sta.exe Arcade-TUnit'
#
# DELIBERATE DIFFERENCE FROM questa_lock.sh: that runner REAPS orphaned vsim,
# because a wedged vsim holds a nodelocked licence and costs everyone. This one
# NEVER kills a running Quartus. A live fit is up to 25 minutes of someone's
# work, and it may belong to a session that started legitimately before this
# lock existed. If a Quartus process is running we WAIT, whatever the lock says.
# Stale locks are broken only when the owner process is gone AND no Quartus is
# running -- both conditions, never one.

set -u

LOCK_DIR="${FPGA_QUARTUS_LOCK:-/tmp/fpga_quartus.lock}"
OWNER_FILE="$LOCK_DIR/owner"
WAIT_LIMIT_S=${FPGA_QUARTUS_WAIT_S:-5400}   # 90 min: three back-to-back fits
POLL_S=15

log() { printf '[quartus-lock] %s\n' "$*" >&2; }

quartus_running() {
  tasklist 2>/dev/null | grep -qiE '^quartus_(map|fit|sta|asm|sh|cdb)' && return 0
  # Some managed Windows sessions allow Get-Process but deny tasklist.  The
  # tasklist error is intentionally hidden above, so without this fallback a
  # denied query is indistinguishable from an idle box and two fits can overlap.
  powershell.exe -NoProfile -NonInteractive -Command '
    $q = Get-Process -Name quartus_map,quartus_fit,quartus_sta,quartus_asm,quartus_sh,quartus_cdb -ErrorAction SilentlyContinue
    if ($null -ne $q) { exit 0 }
    exit 1
  ' >/dev/null 2>&1 && return 0
  return 1
}

owner_alive() {
  [ -f "$OWNER_FILE" ] || return 1
  local pid
  pid=$(awk 'NR==1{print $1}' "$OWNER_FILE" 2>/dev/null)
  [ -n "$pid" ] || return 1
  kill -0 "$pid" 2>/dev/null
}

show_owner() {
  if [ -f "$OWNER_FILE" ]; then
    log "held by: $(cat "$OWNER_FILE" 2>/dev/null | tr '\n' ' ')"
  else
    log "held, but no owner file yet (a race, or a crashed acquirer)"
  fi
}

# --status: report and exit, so a session can check before announcing.
if [ "${1:-}" = "--status" ]; then
  if [ -d "$LOCK_DIR" ]; then
    show_owner
    owner_alive && log "owner is ALIVE" || log "owner is GONE (stale unless Quartus is running)"
  else
    log "lock is FREE"
  fi
  quartus_running && log "a Quartus process IS running right now" \
                  || log "no Quartus process running"
  exit 0
fi

if [ $# -eq 0 ]; then
  log "ERROR: no command given (use --status to query)"
  exit 2
fi

# INVARIANT -- BOTH CONDITIONS, PERMANENTLY. DO NOT "SIMPLIFY" THIS TO THE PID CHECK.
#
# The owner PID is a claim about a PROCESS, not about the BOX (Y-unit, 2026-07-27).
# Any build that relaunches its top-level script -- a seed sweep, a retry loop --
# kills the PID in the owner file while the box stays legitimately occupied. That
# happened here today: the lock named `wolf:openice-rc2` with a dead PID while
# quartus_fit 96232 was alive and the session had moved on to RC4. The owner PID had
# been dead "by design" for two relaunches.
#
# So the rule that LOOKS most precise -- "owner PID dead => the lock is stale" -- is
# the one that would have cleared a live claim and corrupted a running fit. The PID
# check is the tempting refactor precisely because it looks exact. It is not: it is
# exact about the wrong subject. Only the live-Quartus check speaks about the box.
break_if_stale() {
  [ -d "$LOCK_DIR" ] || return 0
  if owner_alive; then
    return 1                        # legitimately held
  fi
  if quartus_running; then
    log "owner process is gone but Quartus is STILL RUNNING -- not breaking the lock"
    return 1                        # never race a live fit
  fi
  # SUSTAINED absence, not a single sample. A build that relaunches its top-level
  # script between seeds has GAPS with no Quartus process alive while the claim is
  # entirely valid. On 2026-07-27 this exact combination -- a dead owner PID from a
  # superseded relaunch plus a momentary gap between seeds -- let this runner break
  # a LIVE Wolf-unit lock, because both conditions were true at the instant sampled.
  # A point-in-time observation is not a durable fact (Y-unit). Require the box to
  # stay quiet across several spaced checks before believing it.
  local q=0
  while [ "$q" -lt 4 ]; do
    sleep 10
    if quartus_running; then
      log "Quartus reappeared during the stale-check (a relaunch gap, not a stale lock) -- backing off"
      return 1
    fi
    if [ ! -d "$LOCK_DIR" ]; then
      return 0                      # owner released it themselves; nothing to break
    fi
    if owner_alive; then
      log "owner reappeared during the stale-check -- not breaking the lock"
      return 1
    fi
    q=$((q + 1))
  done
  log "breaking stale lock (owner gone AND no Quartus for 40s of spaced checks)"
  rm -rf "$LOCK_DIR"
  return 0
}

acquire() {
  local waited=0
  # An unheld lock does NOT mean a free box. Killing a Quartus parent orphans its
  # internal workers: stopping one map run here released the lock (the EXIT trap
  # fired) while SIXTEEN quartus_map.exe processes kept running. A session that
  # trusted the lock file alone would have started straight into those orphans.
  # So refuse to acquire while ANY Quartus is alive, whatever the lock says.
  while quartus_running; do
    if [ "$waited" -eq 0 ]; then
      # Do not assert the lock state here: this loop has only checked for live
      # Quartus processes, so claiming "lock is free" is a statement the code
      # never verified. It printed exactly that while the lock was in fact held
      # by another session -- a tool reporting a state it cannot see, which is
      # the defect class this whole runner exists to prevent.
      if [ -d "$LOCK_DIR" ]; then
        log "a Quartus process is RUNNING and the lock is HELD -- waiting"
        show_owner
      else
        log "a Quartus process is RUNNING with NO lock held (orphan or an unlocked build) -- refusing to start"
      fi
    fi
    if [ "$waited" -ge "$WAIT_LIMIT_S" ]; then
      log "ERROR: Quartus still running after ${waited}s; clear it before building"
      return 75
    fi
    sleep "$POLL_S"; waited=$((waited + POLL_S))
  done
  # REFUSE, DO NOT WAIT (2026-08-10).  This used to poll for up to WAIT_LIMIT_S
  # for the lock, and that is a race, not a queue: a lock gives mutual exclusion,
  # never ordering, so two sessions both waiting can both take it in whatever
  # order they happen to poll.  The shared convention says refuse; that is what
  # /tmp/fpga_quartus.queue is for.
  #
  # MEASURED COST OF WAITING, today: the owner told me another session had the
  # box, so I stood down -- but this loop kept polling in the background, silently
  # took the lock ~60s later when the Y-unit fit finished, and had spawned
  # quartus_map before anyone noticed.  Yielding then required killing the process
  # tree and the Quartus binary, which left MY dead pid owning the lock, i.e. a
  # stale lock that would have stranded the box for everyone.  A runner that can
  # acquire the box after you believe you have stopped is worse than one that
  # simply fails.
  #
  # QUARTUS_LOCK_WAIT=1 restores the old behaviour for a deliberate,
  # supervised march where blocking is the intent.
  if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    if break_if_stale; then
      mkdir "$LOCK_DIR" 2>/dev/null || { log "ERROR: lost the race after breaking a stale lock"; return 75; }
    elif [ "${QUARTUS_LOCK_WAIT:-0}" = "1" ]; then
      waited=0
      while ! mkdir "$LOCK_DIR" 2>/dev/null; do
        if break_if_stale; then continue; fi
        if [ "$waited" -eq 0 ]; then log "box is busy, waiting (QUARTUS_LOCK_WAIT=1)"; show_owner; fi
        if [ "$waited" -ge "$WAIT_LIMIT_S" ]; then
          log "ERROR: timed out after ${waited}s waiting for the box"
          return 75
        fi
        sleep "$POLL_S"; waited=$((waited + POLL_S))
        [ $((waited % 300)) -eq 0 ] && log "still waiting (${waited}s)"
      done
    else
      log "REFUSING: the box is busy. Queue via /tmp/fpga_quartus.queue and retry,"
      log "or set QUARTUS_LOCK_WAIT=1 if blocking here is genuinely what you want."
      show_owner
      return 75                     # distinct code: never got the box
    fi
  fi
  { echo "$$"; echo "session=${FPGA_SESSION:-unknown}"; echo "started=$(date -Is)"; \
    echo "cmd=$*"; } > "$OWNER_FILE"
  return 0
}

release() {
  local rc=$?
  if [ -d "$LOCK_DIR" ] && [ "$(awk 'NR==1{print $1}' "$OWNER_FILE" 2>/dev/null)" = "$$" ]; then
    # NARC's rule: do not tell a lie about the resource. Killing a parent leaves
    # its Quartus children running, so an unconditional release announces a free
    # box while the box is fully occupied -- the same class as a GC'd MAME tap
    # reporting a low count, or a grep reporting a test result. All three report
    # a state they cannot actually observe. Verify before releasing.
    local waited=0
    while quartus_running; do
      if [ "$waited" -eq 0 ]; then
        log "NOT releasing: a Quartus process remains alive after this run"
        log "The machine-wide lock will stay held; this wrapper never kills a potentially foreign fit"
      fi
      [ "$waited" -ge 120 ] && { log "ERROR: Quartus is still alive; lock HELD deliberately so nobody starts into it"; return $rc; }
      sleep 3; waited=$((waited + 3))
    done
    rm -rf "$LOCK_DIR"
    log "released (verified: no Quartus running)"
  fi
  return $rc
}

acquire "$@" || exit $?
trap release EXIT INT TERM

log "acquired (session=${FPGA_SESSION:-unknown}); running: $*"
export FPGA_QUARTUS_LOCK_HELD=1
"$@"
rc=$?
log "command exited rc=$rc"
exit $rc
