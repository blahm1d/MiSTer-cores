#!/usr/bin/env python3
"""Compile and classify the aligned T-unit CPU VRAM read32 contract."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCES = (
    "sim/tb_tunit_vram_read32_planes.sv",
    "sim/models/ddr3_avalon_model.sv",
    "rtl/sdram/stv_vram_ddr_top.sv",
    "rtl/sdram/vram_sdram_top.sv",
    "rtl/sdram/vram_sdram.sv",
    "rtl/sdram/stv_vram_ddr_agent.sv",
)
FULL_WIDTH_MARKER = "PASS tb_tunit_vram_read32_planes full_width=1 controls=PASS"
REPRO_MARKER = (
    "REPRO tb_tunit_vram_read32_planes upper_half_zero=1 controls=PASS "
    "bank1=00002211 bank0=0000b2a1"
)
FAIL_MARKER = "FAIL: aligned CPU read32 drops upper selected bytes"


def run(command: list[str], log: Path) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command, cwd=ROOT, text=True, capture_output=True, check=False
    )
    log.write_text(
        (result.stdout or "") + (result.stderr or ""),
        encoding="utf-8",
        errors="replace",
    )
    return result


def marker_line(text: str, prefix: str) -> str:
    return next((line for line in text.splitlines() if line.startswith(prefix)), "")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label",
        default="tunit-vram-read32-planes-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    parser.add_argument(
        "--expect-repro",
        action="store_true",
        help="diagnostic mode: succeed only for the exact known upper-half-zero signature",
    )
    parser.add_argument(
        "--mutation",
        choices=("production", "truncate-upper"),
        default="production",
        help="compile production RTL or restore the former read32 truncation",
    )
    args = parser.parse_args()

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    image = out / "tb_tunit_vram_read32_planes.vvp"
    compile_command = [
            "iverilog",
            "-g2012",
            "-s",
            "tb_tunit_vram_read32_planes",
            "-o",
            str(image),
    ]
    if args.mutation == "truncate-upper":
        compile_command.append("-DMUT_TUNIT_VRAM_READ32_TRUNCATE")
    compile_command.extend(SOURCES)
    compile_result = run(compile_command, out / "compile.log")
    if compile_result.returncode:
        print(f"ERROR: compile failed; see {out}")
        return compile_result.returncode

    sim_result = run(["vvp", str(image)], out / "sim.log")
    sim_text = (sim_result.stdout or "") + (sim_result.stderr or "")
    observed = marker_line(sim_text, "OBSERVED tb_tunit_vram_read32_planes")
    if observed:
        print(observed)

    if args.expect_repro:
        if (
            sim_result.returncode != 0
            and REPRO_MARKER in sim_text
            and FAIL_MARKER in sim_text
            and FULL_WIDTH_MARKER not in sim_text
        ):
            print(f"PASS: exact aligned-read32 upper-half-zero defect reproduced ({out})")
            return 0
        print(f"ERROR: expected defect signature was not reproduced; see {out}")
        return 1

    if sim_result.returncode == 0 and FULL_WIDTH_MARKER in sim_text:
        print(f"PASS: aligned CPU read32 returns all four selected bytes ({out})")
        return 0

    if REPRO_MARKER in sim_text and FAIL_MARKER in sim_text:
        print(f"FAIL: aligned CPU read32 full-width contract is broken ({out})")
    else:
        print(f"ERROR: unclassified simulation failure; see {out}")
    return sim_result.returncode or 1


if __name__ == "__main__":
    raise SystemExit(main())
