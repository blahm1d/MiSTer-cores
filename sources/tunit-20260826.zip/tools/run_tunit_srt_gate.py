#!/usr/bin/env python3
"""Prove FILL emits one SRT sideband operation per hardware row callback."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
NETLIST = ROOT / "build_syn" / "tunit_core.v"
BENCH = ROOT / "sim" / "monitors" / "tb_tunit_srt_fill.v"
PIXT_BENCH = ROOT / "sim" / "monitors" / "tb_tunit_srt_pixt.v"
PASS_MARKER = "TEST_RESULT: PASS tb_tunit_srt_fill"
FAIL_MARKER = "TEST_RESULT: FAIL tb_tunit_srt_fill srt_reroute_missing"
PIXT_PASS_MARKER = "TEST_RESULT: PASS tb_tunit_srt_pixt"
PIXT_FAIL_MARKER = "TEST_RESULT: FAIL tb_tunit_srt_pixt timeout"
SRT_ENABLE = re.compile(r"mem_srt = srt_on;")
# Suppress only the EXECUTE-issued linear PIXT command.  PIXT RMW now has a
# second, legitimate command publication after its local PPOP preparation
# edge; a context-free assignment match would mutate both and cease to be the
# promised one-change rollback.  The initial issue is uniquely followed by
# the captured field size in both source and sv2v output.
SRT_COMMAND_ENABLE = re.compile(
    r"move_mem_cmd_valid_q <= 1'b1;(?=\s*move_mem_cmd_size_q\s*<=\s*mv_fs;)"
)


def compile_and_run(
    netlist: Path,
    output: Path,
    timeout: int,
    plusargs: tuple[str, ...] = (),
    *,
    bench: Path = BENCH,
    top: str = "tb_tunit_srt_fill",
) -> tuple[int, str]:
    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    if not iverilog or not vvp:
        return 2, "ERROR: iverilog/vvp not found on PATH\n"
    compile_result = subprocess.run(
        [
            iverilog,
            "-g2012",
            "-s",
            top,
            "-o",
            str(output),
            str(netlist),
            str(bench),
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    log = (compile_result.stdout or "") + (compile_result.stderr or "")
    if compile_result.returncode:
        return compile_result.returncode, log
    try:
        run_result = subprocess.run(
            [vvp, str(output), *plusargs],
            cwd=ROOT,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        text = (exc.stdout or "") + (exc.stderr or "")
        return 1, text + f"\nERROR: SRT bench exceeded {timeout}s\n"
    return (
        run_result.returncode,
        log + (run_result.stdout or "") + (run_result.stderr or ""),
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label",
        default="srt-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    parser.add_argument("--timeout", type=int, default=120)
    args = parser.parse_args()

    if not NETLIST.is_file() or not BENCH.is_file() or not PIXT_BENCH.is_file():
        print("ERROR: flatten a named variant before running the SRT gate",
              file=sys.stderr)
        return 2

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    normal_rc, normal_log = compile_and_run(
        NETLIST, out / "srt_normal.vvp", args.timeout
    )
    (out / "normal.log").write_text(normal_log, encoding="utf-8")
    print(normal_log, end="")
    if normal_rc or PASS_MARKER not in normal_log or "TEST_RESULT: FAIL" in normal_log:
        print("SRT GATE: FAIL (production flattened netlist)", file=sys.stderr)
        return 1

    multi_rc, multi_log = compile_and_run(
        NETLIST, out / "srt_multi.vvp", args.timeout, ("+MULTI",)
    )
    (out / "multi.log").write_text(multi_log, encoding="utf-8")
    print(multi_log, end="")
    if multi_rc or PASS_MARKER not in multi_log or "TEST_RESULT: FAIL" in multi_log:
        print("SRT GATE: FAIL (multi-word/multi-row callbacks)", file=sys.stderr)
        return 1

    source = NETLIST.read_text(encoding="utf-8")
    pixt_rc, pixt_log = compile_and_run(
        NETLIST,
        out / "srt_pixt.vvp",
        args.timeout,
        bench=PIXT_BENCH,
        top="tb_tunit_srt_pixt",
    )
    (out / "pixt.log").write_text(pixt_log, encoding="utf-8")
    print(pixt_log, end="")
    if (pixt_rc or PIXT_PASS_MARKER not in pixt_log
            or "TEST_RESULT: FAIL" in pixt_log):
        print("SRT GATE: FAIL (linear PIXT command did not retire)",
              file=sys.stderr)
        return 1

    # Regression for the production failure found at MK2 FF817080: the
    # registered MOVE command was suppressed precisely when SRT was active,
    # leaving CORE_MEMORY with mem_req=0 forever. Restore that expression in a
    # mutant and require the exact-FA52 bench to kill it.
    command_mutated, command_count = SRT_COMMAND_ENABLE.subn(
        "move_mem_cmd_valid_q <= !srt_active;", source
    )
    if command_count != 1:
        print(
            "SRT GATE: FAIL (linear-command mutation matched "
            f"{command_count}, expected 1)",
            file=sys.stderr,
        )
        return 1
    command_mutant = out / "tunit_core_srt_command_suppressed.v"
    command_mutant.write_text(command_mutated, encoding="utf-8")
    command_rc, command_log = compile_and_run(
        command_mutant,
        out / "srt_pixt_mutant.vvp",
        args.timeout,
        bench=PIXT_BENCH,
        top="tb_tunit_srt_pixt",
    )
    (out / "pixt_mutant.log").write_text(command_log, encoding="utf-8")
    if (command_rc != 0 or PIXT_FAIL_MARKER not in command_log
            or PIXT_PASS_MARKER in command_log):
        print(command_log, end="")
        print("SRT GATE: FAIL (linear-command suppression mutation survived)",
              file=sys.stderr)
        return 1
    print("SRT MUTATION linear-command-on->suppressed: KILLED")

    mutated, count = SRT_ENABLE.subn("mem_srt = 1'b0;", source)
    if count < 1:
        print(
            f"SRT GATE: FAIL (sideband-disable mutation matched {count})",
            file=sys.stderr,
        )
        return 1
    mutant = out / "tunit_core_srt_disabled.v"
    mutant.write_text(mutated, encoding="utf-8")
    mutant_rc, mutant_log = compile_and_run(
        mutant, out / "srt_mutant.vvp", args.timeout
    )
    (out / "mutant.log").write_text(mutant_log, encoding="utf-8")
    if mutant_rc != 0 or FAIL_MARKER not in mutant_log or PASS_MARKER in mutant_log:
        print(mutant_log, end="")
        print("SRT GATE: FAIL (sideband-disable mutation survived)", file=sys.stderr)
        return 1
    # Both mutants must compile and complete normally.  The exact failing marker
    # is the semantic oracle; a compiler error, timeout or simulator crash is not
    # a mutation kill.
    print("SRT MUTATION sideband-on->off: KILLED")
    print("SRT GATE: PASS (linear PIXT plus single/multi-row callbacks)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
