#!/usr/bin/env python3
"""Prove ADPCM reload fencing, fixed-bank coverage, and cache image epochs."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SV2V = Path(r"C:\tools\sv2v\sv2v-Windows\sv2v.exe")
FIXED_BENCH = ROOT / "sim" / "tb_tunit_adpcm_reload_fixedbank.sv"
EPOCH_BENCH = ROOT / "sim" / "tb_tunit_adpcm_cache_epoch.sv"
BOARD = ROOT / "rtl" / "experimental" / "adpcm" / "tunit_adpcm_board.sv"
TOP = ROOT / "rtl" / "tunit" / "tunit_top.sv"
BOARD_TOP = ROOT / "rtl" / "tunit" / "tunit_board.sv"
CDC = ROOT / "rtl" / "tunit" / "tunit_adpcm_rom_cdc.sv"
SOUND_DDR = ROOT / "rtl" / "tunit" / "tunit_sound_ddr_multi.sv"


def run(command: list[str], timeout: int, cwd: Path = ROOT) -> tuple[int, str]:
    try:
        result = subprocess.run(
            command, cwd=cwd, text=True, capture_output=True, timeout=timeout,
            errors="replace",
        )
    except subprocess.TimeoutExpired as exc:
        return 124, (exc.stdout or "") + (exc.stderr or "") + "\nTIMEOUT\n"
    return result.returncode, (result.stdout or "") + (result.stderr or "")


def vendor_sources() -> list[Path]:
    return (
        [ROOT / "rtl" / "vendor" / "mc6809" / "mc6809is.v"]
        + sorted((ROOT / "rtl" / "vendor" / "jt51" / "hdl").glob("*.v"))
        + sorted((ROOT / "rtl" / "vendor" / "jt6295" / "src").glob("*.v"))
    )


def static_contract() -> list[str]:
    errors: list[str] = []
    top = TOP.read_text(encoding="utf-8")
    board_top = BOARD_TOP.read_text(encoding="utf-8")
    board = BOARD.read_text(encoding="utf-8")
    cdc = CDC.read_text(encoding="utf-8")
    sound_ddr = SOUND_DDR.read_text(encoding="utf-8")
    required = (
        (top, ".board_reset_sys(adpcm_board_reset || !roms_loaded_q || loader_rst_sound)"),
        (top, ".epoch_reset_sys(adpcm_cache_epoch_reset)"),
        (top, ".snd_dl_we(snd_wr && !sound_dcs)"),
        (board_top, ".loader_rst_sound,"),
        (board, '(* ramstyle = "M10K" *) logic [7:0] fixed_rom [0:16383];'),
        (board, "snd_dl_addr[23:14] == 10'h00f"),
        (cdc, "input  wire logic        epoch_reset_sys,"),
        (cdc, "`ifdef MUT_TUNIT_ADPCM_CACHE_EPOCH_REVERT"),
        (cdc, "wire logic cache_reset = rst_pon || epoch_reset_sys;"),
        (cdc, "always_ff @(posedge clk_snd or posedge cache_reset)"),
        (sound_ddr, "assign dl_busy = dl_wr || wc_valid || force_flush || owner_is_download;"),
        (sound_ddr, "if (agent_seen_busy && !agent_busy) owner <= O_IDLE;"),
    )
    for text, needle in required:
        if needle not in text:
            errors.append(f"shipping contract missing {needle}")
    fixed_section_match = re.search(
        r"logic\s+fixed_q_valid;(?P<body>.*?)`ifdef\s+MUT_TUNIT_NO_FIXED_BANK",
        board,
        re.DOTALL,
    )
    if fixed_section_match is None:
        errors.append("fixed-bank implementation section missing")
    else:
        fixed_section = fixed_section_match.group("body")
        single_clock_shape = re.compile(
            r"always_ff\s*@\(posedge\s+snd_dl_clk\)\s*begin\s*"
            r"if\s*\(snd_dl_we\s*&&\s*\(snd_dl_addr\[23:14\]\s*==\s*10'h00f\)\)\s*"
            r"fixed_rom\[snd_dl_addr\[13:0\]\]\s*<=\s*snd_dl_data;\s*"
            r"fixed_q\s*<=\s*fixed_rom\[cpu_addr\[13:0\]\];\s*"
            r"fixed_aq\s*<=\s*cpu_addr\[13:0\];\s*end",
            re.DOTALL,
        )
        if single_clock_shape.search(fixed_section) is None:
            errors.append("fixed-bank RAM read/write/tag left the snd_dl_clk block")
        valid_shape = re.compile(
            r"always_ff\s*@\(posedge\s+clk\)\s*begin\s*"
            r"if\s*\(reset\)\s*fixed_q_valid\s*<=\s*1'b0;\s*"
            r"else\s*fixed_q_valid\s*<=\s*1'b1;\s*end",
            re.DOTALL,
        )
        if valid_shape.search(fixed_section) is None:
            errors.append("fixed-bank valid left its sound-domain reset gate")
        if re.search(r"if\s*\(reset\).*?(fixed_q|fixed_aq)\s*<=", fixed_section, re.DOTALL):
            errors.append("fixed-bank read data/address regained a reset branch")
    fixed_ready_shape = re.compile(
        r"`ifdef\s+MUT_TUNIT_NO_FIXED_BANK\s*"
        r"(?:.|\n)*?wire\s+fixed_ready\s*=\s*1'b0;\s*`else\s*"
        r"wire\s+fixed_ready\s*=\s*cpu_rom_fixed\s*&&\s*"
        r"fixed_q_valid\s*&&\s*\(fixed_aq\s*==\s*cpu_addr\[13:0\]\);\s*`endif",
        re.DOTALL,
    )
    if fixed_ready_shape.search(board) is None:
        errors.append("fixed-bank consumption lost its valid/address-tag guard")
    if "M10K, no_rw_check" in board:
        errors.append("fixed bank still carries forbidden no_rw_check")

    epoch_match = re.search(
        r"wire\s+logic\s+adpcm_cache_epoch_reset\s*=\s*(?P<rhs>.*?);",
        top,
        re.DOTALL,
    )
    if epoch_match is None:
        errors.append("shipping ADPCM cache epoch expression missing")
    else:
        epoch_rhs = " ".join(epoch_match.group("rhs").split())
        expected_rhs = "!roms_loaded_q || loader_rst_sound || snd_dl_busy"
        if epoch_rhs != expected_rhs:
            errors.append(
                "shipping ADPCM cache epoch must be exactly " + expected_rhs
            )
        if "adpcm_board_reset" in epoch_rhs:
            errors.append("ordinary FE/FF board reset is coupled to cache epoch")

    owner_match = re.search(
        r"wire\s+logic\s+owner_is_download\s*=\s*(?P<rhs>.*?);",
        sound_ddr,
        re.DOTALL,
    )
    if owner_match is None or "owner == O_WRITE_WAIT" not in owner_match.group("rhs"):
        errors.append("snd_dl_busy no longer covers final backend write wait")
    return errors


def build_fixedbank_and_run(
    work: Path,
    kind: str,
    define: str | None,
    sv2v: str,
    iverilog: str,
    vvp: str,
    timeout: int,
) -> tuple[bool, str]:
    work.mkdir(parents=True)
    converted = work / "tb_tunit_adpcm_reload_fixedbank.sv2v.v"
    sources = [
        ROOT / "rtl" / "common" / "tunit_pkg.sv",
        ROOT / "rtl" / "tunit" / "tunit_profile_layout.sv",
        ROOT / "rtl" / "tunit" / "tunit_loader.sv",
        ROOT / "rtl" / "tunit" / "tunit_sound_cdc.sv",
        BOARD,
        FIXED_BENCH,
    ]
    command = [sv2v]
    if define:
        command += ["-D", define]
    command += [f"--write={converted}", *(str(path) for path in sources)]
    code, convert_log = run(command, timeout)
    if code:
        (work / "build.log").write_text(convert_log, encoding="utf-8")
        return False, "sv2v failed\n" + convert_log

    image = work / "tb_tunit_adpcm_reload_fixedbank.vvp"
    command = [
        iverilog, "-g2012", "-s", "tb_tunit_adpcm_reload_fixedbank",
        "-o", str(image), *(str(path) for path in vendor_sources()), str(converted),
    ]
    code, compile_log = run(command, timeout)
    (work / "build.log").write_text(convert_log + compile_log, encoding="utf-8")
    if code:
        return False, "iverilog failed\n" + compile_log

    code, log = run([vvp, str(image)], timeout,
                    cwd=ROOT / "rtl" / "vendor" / "jt6295" / "src")
    (work / "sim.log").write_text(log, encoding="utf-8", errors="replace")
    pass_marker = "PASS tb_tunit_adpcm_reload_fixedbank"
    fail_marker = "FAIL: second fixed-bank write escaped sound reset"
    if kind == "stock":
        passed = code == 0 and pass_marker in log and "FAIL:" not in log
    else:
        # Windows vvp can return zero after $fatal, so require the exact
        # behavioural witness and Fatal text. A compile failure never counts.
        passed = fail_marker in log and "Fatal" in log and pass_marker not in log
    return passed, log


def build_epoch_and_run(
    work: Path,
    kind: str,
    define: str | None,
    sv2v: str,
    iverilog: str,
    vvp: str,
    timeout: int,
) -> tuple[bool, str]:
    work.mkdir(parents=True)
    converted = work / "tb_tunit_adpcm_cache_epoch.sv2v.v"
    command = [sv2v]
    if define:
        command += ["-D", define]
    command += [f"--write={converted}", str(CDC), str(EPOCH_BENCH)]
    code, convert_log = run(command, timeout)
    if code:
        (work / "build.log").write_text(convert_log, encoding="utf-8")
        return False, "sv2v failed\n" + convert_log

    image = work / "tb_tunit_adpcm_cache_epoch.vvp"
    command = [
        iverilog, "-g2012", "-s", "tb_tunit_adpcm_cache_epoch",
        "-o", str(image), str(converted),
    ]
    code, compile_log = run(command, timeout)
    (work / "build.log").write_text(convert_log + compile_log, encoding="utf-8")
    if code:
        return False, "iverilog failed\n" + compile_log

    code, log = run([vvp, str(image)], timeout)
    (work / "sim.log").write_text(log, encoding="utf-8", errors="replace")
    pass_marker = "PASS tb_tunit_adpcm_cache_epoch"
    fail_marker = "FAIL: warm reload served stale image-A byte"
    if kind == "cache-epoch-stock":
        passed = code == 0 and pass_marker in log and "FAIL:" not in log
    else:
        # The mutation must compile and reach the exact image-A witness. A
        # timeout, compile failure, or unrelated assertion is never a kill.
        passed = (
            fail_marker in log
            and re.search(r"fatal", log, re.IGNORECASE) is not None
            and pass_marker not in log
        )
    return passed, log


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--label",
        default="adpcm-reload-integration-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()

    errors = static_contract()
    if errors:
        for error in errors:
            print("ADPCM RELOAD GATE: FAIL -- " + error)
        return 1

    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    sv2v = str(DEFAULT_SV2V) if DEFAULT_SV2V.is_file() else shutil.which("sv2v")
    if not iverilog or not vvp or not sv2v:
        print("ADPCM RELOAD GATE: FAIL -- missing iverilog/vvp/sv2v")
        return 2

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    cases = (
        ("fixedbank-stock", "stock", None, build_fixedbank_and_run),
        (
            "fixedbank-reset-drop-mutant",
            "reset-drop-mutant",
            "MUT_TUNIT_RELOAD_RESET_DROP",
            build_fixedbank_and_run,
        ),
        ("cache-epoch-stock", "cache-epoch-stock", None, build_epoch_and_run),
        (
            "cache-epoch-revert-mutant",
            "cache-epoch-revert-mutant",
            "MUT_TUNIT_ADPCM_CACHE_EPOCH_REVERT",
            build_epoch_and_run,
        ),
    )
    all_pass = True
    for directory, kind, define, runner in cases:
        passed, log = runner(
            out / directory, kind, define, sv2v, iverilog, vvp, args.timeout
        )
        print(("PASS " if passed else "FAIL ") + kind)
        for line in log.splitlines():
            if line.startswith(("PASS ", "FAIL:", "Fatal", "FATAL")):
                print("  " + line)
        all_pass &= passed

    if all_pass:
        print(
            "ADPCM RELOAD INTEGRATION GATE: PASS "
            "(fixed-bank + two-image cache epoch; both revert mutants killed)"
        )
        return 0
    print("ADPCM RELOAD INTEGRATION GATE: FAIL")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
