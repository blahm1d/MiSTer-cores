#!/usr/bin/env python3
"""Prove ENV transport and the NBA/TE SRT-visible hold."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCES = (
    ROOT / "rtl" / "common" / "tunit_pkg.sv",
    ROOT / "rtl" / "tms34010" / "rtl" / "tms34010_pkg.sv",
    ROOT / "rtl" / "tms34010" / "rtl" / "video" / "tms34010_video.sv",
    ROOT / "rtl" / "tms34010" / "rtl" / "io" / "tms34010_io_regs.sv",
    ROOT / "rtl" / "tunit" / "tunit_video.sv",
    ROOT / "sim" / "tb_tunit_display_blank.sv",
)
PASS_MARKER = "RESULT: PASS (tb_tunit_display_blank)"
TRANSPORT_MUTATION_FAILURES = (
    "FAIL: D1 ENV-low frame preserves H_ACT*V_ACT de transport",
    "FAIL: D3 ENV-low frame STILL prefetches H_ACT*V_ACT pixels",
)
SRT_MUTATION_FAILURES = (
    "FAIL: E3 ENV-low SRT hold keeps the published frame visible",
)


def run_case(
    iverilog: str, vvp: str, out: Path, *, mutation: str | None
) -> tuple[int, str]:
    image = out / ((mutation or "nominal") + ".vvp")
    command = [iverilog, "-g2012", "-s", "tb_tunit_display_blank"]
    if mutation == "transport-mutation":
        command.append("-DMUT_TUNIT_ENV_COLLAPSE_TRANSPORT")
    elif mutation == "srt-reblank-mutation":
        command.append("-DMUT_TUNIT_ENV_SRT_REBLANK")
    command.extend(["-o", str(image), *(str(source) for source in SOURCES)])
    compiled = subprocess.run(
        command, cwd=ROOT, text=True, capture_output=True, check=False
    )
    log = (compiled.stdout or "") + (compiled.stderr or "")
    if compiled.returncode:
        return compiled.returncode, log
    simulated = subprocess.run(
        [vvp, str(image)],
        cwd=ROOT,
        text=True,
        capture_output=True,
        timeout=30,
        check=False,
    )
    return simulated.returncode, log + (simulated.stdout or "") + (simulated.stderr or "")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label", default="env-transport-" + datetime.now().strftime("%Y%m%d-%H%M%S")
    )
    args = parser.parse_args()

    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    missing = [str(source) for source in SOURCES if not source.is_file()]
    if not iverilog or not vvp or missing:
        detail = ", ".join(missing) if missing else "iverilog/vvp"
        print(f"ERROR: missing ENV transport gate input: {detail}", file=sys.stderr)
        return 2

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    nominal_rc, nominal_log = run_case(iverilog, vvp, out, mutation=None)
    (out / "nominal.log").write_text(nominal_log, encoding="utf-8", errors="replace")
    if nominal_rc != 0 or PASS_MARKER not in nominal_log or "RESULT: FAIL" in nominal_log:
        print(nominal_log, end="")
        print("ENV TRANSPORT GATE: FAIL nominal", file=sys.stderr)
        return 1

    for mutation, expected in (
        ("transport-mutation", TRANSPORT_MUTATION_FAILURES),
        ("srt-reblank-mutation", SRT_MUTATION_FAILURES),
    ):
        mutation_rc, mutation_log = run_case(iverilog, vvp, out, mutation=mutation)
        (out / f"{mutation}.log").write_text(
            mutation_log, encoding="utf-8", errors="replace"
        )
        mutation_killed = (
            mutation_rc == 0
            and "RESULT: FAIL" in mutation_log
            and PASS_MARKER not in mutation_log
            and all(marker in mutation_log for marker in expected)
        )
        if not mutation_killed:
            print(mutation_log, end="")
            print(f"ENV TRANSPORT GATE: FAIL {mutation} escaped", file=sys.stderr)
            return 1

    print(nominal_log, end="")
    print(
        f"ENV TRANSPORT GATE: PASS label={args.label} "
        "mutations=transport,srt-reblank-killed"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
