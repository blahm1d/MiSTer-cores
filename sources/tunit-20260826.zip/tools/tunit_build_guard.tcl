# Fail closed if Quartus is pointed at Arcade-TUnit.qsf directly.  Direct map,
# fit, STA or GUI compilation can otherwise consume an ignored stale
# build_syn/tunit_core.v without running the source-hash preflight or the
# STA-before-assembly gate.  tools/build_tunit.sh owns this sentinel.
set tunit_wrapper_active 0
if {[info exists ::env(TUNIT_BUILD_WRAPPER_ACTIVE)] &&
    $::env(TUNIT_BUILD_WRAPPER_ACTIVE) eq "1"} {
    set tunit_wrapper_active 1
}
if {!$tunit_wrapper_active} {
    error "T-unit Quartus project is wrapper-only: use tools/build_tunit.sh; direct Quartus may compile a stale ignored netlist"
}
unset tunit_wrapper_active

if {![info exists ::env(FPGA_QUARTUS_LOCK_HELD)] ||
    $::env(FPGA_QUARTUS_LOCK_HELD) ne "1"} {
  error "T-unit Quartus project is not running under tools/quartus_lock.sh"
}

if {![info exists ::env(TUNIT_FIFO_TICKET_HELD)] ||
    $::env(TUNIT_FIFO_TICKET_HELD) ne "1"} {
  error "T-unit Quartus project has no verified shared-FIFO ticket"
}

if {![info exists ::env(FPGA_SESSION)] ||
    [string trim $::env(FPGA_SESSION)] eq ""} {
  error "T-unit Quartus project has no named shared-host owner"
}

if {![info exists ::env(TUNIT_BUILD_VARIANT)] ||
    [lsearch -exact {universal adpcm dcs} $::env(TUNIT_BUILD_VARIANT)] < 0} {
    error "T-unit build wrapper did not provide a valid TUNIT_BUILD_VARIANT"
}

# Core-scoped HDMI scaler policy.  The default remains the MiSTer Main-owned
# near-neighbour/polyphase selection.  The two engineering A/B policies select
# built-in ascal modes and therefore must be explicit, uniquely labelled, and
# impossible to mistake for an ordinary production image.
if {![info exists ::env(TUNIT_ASCAL_POLICY)] ||
    [lsearch -exact {main nearest bilinear} $::env(TUNIT_ASCAL_POLICY)] < 0} {
    error "T-unit build wrapper did not provide main|nearest|bilinear TUNIT_ASCAL_POLICY"
}

set tunit_ascal_policy $::env(TUNIT_ASCAL_POLICY)
if {$tunit_ascal_policy ne "main" &&
    (![info exists ::env(TUNIT_ENGINEERING_BUILD)] ||
     $::env(TUNIT_ENGINEERING_BUILD) ne "1")} {
        error "fixed T-unit ascal policies are engineering-only until cabinet acceptance"
}

if {![info exists ::env(TUNIT_ARTIFACT_ID)]} {
    error "T-unit build wrapper did not pin TUNIT_ARTIFACT_ID"
}
if {[info exists ::env(TUNIT_ENGINEERING_BUILD)] &&
    $::env(TUNIT_ENGINEERING_BUILD) eq "1" &&
    ![regexp {^[A-Z0-9][A-Z0-9._-]{0,63}$} $::env(TUNIT_ARTIFACT_ID)]} {
    error "engineering T-unit physical builds require a safe immutable TUNIT_ARTIFACT_ID"
}
switch -- $tunit_ascal_policy {
    main {
        if {$::env(TUNIT_ARTIFACT_ID) eq "NBA-ASCAL-A-NEAREST" ||
            $::env(TUNIT_ARTIFACT_ID) eq "NBA-ASCAL-B-BILINEAR"} {
            error "reserved NBA-ASCAL artifact id requires its matching fixed policy"
        }
    }
    nearest {
        if {$::env(TUNIT_ARTIFACT_ID) ne "NBA-ASCAL-A-NEAREST"} {
            error "nearest T-unit ascal policy requires NBA-ASCAL-A-NEAREST"
        }
    }
    bilinear {
        if {$::env(TUNIT_ARTIFACT_ID) ne "NBA-ASCAL-B-BILINEAR"} {
            error "bilinear T-unit ascal policy requires NBA-ASCAL-B-BILINEAR"
        }
    }
}

# sys/sys.tcl is a pinned MiSTer framework input and registers the stock
# wall-clock build-id pre-flow.  QSF files accept only assignment directives,
# so perform the removal from this sourced Tcl after every other QSF source has
# run, then install exactly one wrapper-pinned deterministic replacement.
remove_all_global_assignments -name PRE_FLOW_SCRIPT_FILE
set_global_assignment -name PRE_FLOW_SCRIPT_FILE "quartus_sh:tools/tunit_build_id.tcl"

if {$tunit_ascal_policy ne "main" &&
    $::env(TUNIT_BUILD_VARIANT) ne "adpcm"} {
    error "NBA ascal A/B policies require the ADPCM build variant"
}
if {$tunit_ascal_policy ne "main" &&
    [info exists ::env(TUNIT_DIAG_BUILD)] &&
    $::env(TUNIT_DIAG_BUILD) ne "0"} {
    error "NBA ascal A/B policies forbid the diagnostic overlay"
}
if {![info exists ::env(TUNIT_AB_REFERENCE_MANIFEST)]} {
    error "T-unit build wrapper did not pin TUNIT_AB_REFERENCE_MANIFEST"
}
set tunit_ascal_a_reference "output_files/Arcade-TUnit-ADPCM-ENGINEERING-NBA-ASCAL-A-NEAREST.manifest.json"
if {$tunit_ascal_policy eq "bilinear"} {
    if {$::env(TUNIT_AB_REFERENCE_MANIFEST) ne $tunit_ascal_a_reference} {
        error "bilinear T-unit ascal policy requires the exact A manifest reference"
    }
} elseif {$::env(TUNIT_AB_REFERENCE_MANIFEST) ne ""} {
    error "only the bilinear T-unit ascal policy accepts an A/B reference"
}

switch -- $tunit_ascal_policy {
    main { }
    nearest {
        set_global_assignment -name VERILOG_MACRO "TUNIT_ASCAL_FIXED_NEAREST=1"
    }
    bilinear {
        set_global_assignment -name VERILOG_MACRO "TUNIT_ASCAL_FIXED_BILINEAR=1"
    }
}
