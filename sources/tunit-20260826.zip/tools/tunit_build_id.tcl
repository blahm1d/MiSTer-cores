# Deterministic T-unit build-id/CDF pre-flow.
#
# The stock MiSTer script derives BUILD_DATE from the wall clock immediately
# before map. That makes build_id.v an untracked late-mutating logic input and
# can confound a multi-image A/B across midnight. The queue wrapper pins one
# six-digit YYMMDD value before flatten; this pre-flow accepts only that value
# and rewrites the exact same bytes.
proc generateBuildID_Verilog {} {
    if {![info exists ::env(TUNIT_BUILD_DATE)] ||
        ![regexp {^[0-9]{6}$} $::env(TUNIT_BUILD_DATE)]} {
        post_message -type error "TUNIT_BUILD_DATE is absent or not YYMMDD"
        exit 2
    }
    set buildDate "`define BUILD_DATE \"$::env(TUNIT_BUILD_DATE)\""
    set outputFileName "build_id.v"
    set fileData ""
    if {[file exists $outputFileName]} {
        set outputFile [open $outputFileName "r"]
        set fileData [read $outputFile]
        close $outputFile
    }
    if {$buildDate ne $fileData} {
        set outputFile [open $outputFileName "w"]
        puts -nonewline $outputFile $buildDate
        close $outputFile
        post_message "Generated deterministic build_id.v: $buildDate"
    }
}

proc generateCDF {revision device outpath} {
    set outputFileName "jtag.cdf"
    set outputFile [open $outputFileName "w"]
    puts $outputFile "JedecChain;"
    puts $outputFile "\tFileRevision(JESD32A);"
    puts $outputFile "\tDefaultMfr(6E);"
    puts $outputFile ""
    puts $outputFile "\tP ActionCode(Ign)"
    puts $outputFile "\t\tDevice PartName(SOCVHPS) MfrSpec(OpMask(0));"
    puts $outputFile "\tP ActionCode(Cfg)"
    puts $outputFile "\t\tDevice PartName($device) Path(\"$outpath/\") File(\"$revision.sof\") MfrSpec(OpMask(1));"
    puts $outputFile "ChainEnd;"
    puts $outputFile ""
    puts $outputFile "AlteraBegin;"
    puts $outputFile "\tChainType(JTAG);"
    puts $outputFile "AlteraEnd;"
    close $outputFile
}

set project_name [lindex $quartus(args) 1]
set revision [lindex $quartus(args) 2]
if {[project_exists $project_name]} {
    if {[string equal "" $revision]} {
        project_open $project_name -revision [get_current_revision $project_name]
    } else {
        project_open $project_name -revision $revision
    }
} else {
    post_message -type error "Project $project_name does not exist"
    exit 2
}
set device [get_global_assignment -name DEVICE]
set outpath [get_global_assignment -name PROJECT_OUTPUT_DIRECTORY]
if [is_project_open] { project_close }
generateBuildID_Verilog
generateCDF $revision $device $outpath
