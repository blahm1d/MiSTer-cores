#!/usr/bin/env python3
"""Generate a variant-identified Quartus-17-compatible synthesis blob."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "tools" / "quartus_sv2v_files.txt"
OUTPUT = ROOT / "build_syn" / "tunit_core.v"
BUILD_MANIFEST = ROOT / "build_syn" / "tunit_core.manifest.json"
DEFAULT_SV2V = Path(r"C:\tools\sv2v\sv2v-Windows\sv2v.exe")
VARIANT_DEFINE = {
    "universal": None,
    "adpcm": "-DTUNIT_NO_DCS",
    "dcs": "-DTUNIT_NO_ADPCM",
}
QUARTUS_EXECUTABLES = (
    "quartus_sh.exe",
    "quartus_map.exe",
    "quartus_fit.exe",
    "quartus_sta.exe",
    "quartus_asm.exe",
)
FRAMEWORK_ROW = re.compile(r"^([0-9a-f]{40})  (.+)$")


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def quartus_toolchain() -> dict[str, object] | None:
    raw_directory = os.environ.get("TUNIT_QUARTUS_BIN_WIN")
    if not raw_directory:
        return None
    directory = Path(raw_directory)
    missing = [name for name in QUARTUS_EXECUTABLES if not (directory / name).is_file()]
    if missing:
        raise SystemExit(
            "Quartus toolchain identity is incomplete: " + ", ".join(missing)
        )
    return {
        "directory": str(directory),
        "executables_sha256": {
            name: digest(directory / name) for name in QUARTUS_EXECUTABLES
        },
    }


def framework_physical_inputs() -> list[Path]:
    manifest = ROOT / "docs" / "MISTER-FRAMEWORK-MANIFEST.md"
    paths = [
        ROOT / match.group(2)
        for line in manifest.read_text(encoding="utf-8").splitlines()
        if (match := FRAMEWORK_ROW.match(line))
    ]
    if len(paths) != 61:
        raise SystemExit(
            f"framework physical closure has {len(paths)} rows, expected 61"
        )
    return paths


def git_value(*args: str) -> str:
    result = subprocess.run(
        ["git", *args], cwd=ROOT, text=True, capture_output=True, check=False
    )
    return (result.stdout or "").strip() if result.returncode == 0 else "unknown"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--variant",
        choices=tuple(VARIANT_DEFINE),
        default=None,
        help="silicon sound-family image; default is universal unless the "
             "legacy SV2V_DEFINES variable selects one family",
    )
    parser.add_argument(
        "--diag",
        action="store_true",
        help="define TUNIT_DIAG: build the cabinet instrument (busy-wedge "
             "counters in tunit_top plus the on-screen overlay). NEVER use for "
             "a release image, and wipe db/ and incremental_db/ when switching "
             "back -- SMART_RECOMPILE has leaked diag overlays into production.",
    )
    args = parser.parse_args()

    sv2v = Path(os.environ.get("SV2V", DEFAULT_SV2V))
    if not sv2v.is_file():
        raise SystemExit(
            f"sv2v not found at {sv2v}. Set SV2V to the sv2v executable."
        )

    sources = []
    for raw_line in MANIFEST.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        source = ROOT / Path(line)
        if not source.is_file():
            raise SystemExit(f"missing synthesis source: {source}")
        sources.append(source)

    # Keep the old environment variable usable for development, but make its
    # family selection unambiguous and refuse a conflict with --variant.
    legacy_extra = shlex.split(os.environ.get("SV2V_DEFINES", ""))
    family_defines = {
        item for item in legacy_extra
        if item in ("-DTUNIT_NO_DCS", "-DTUNIT_NO_ADPCM")
    }
    if len(family_defines) > 1:
        raise SystemExit("both sound engines cannot be excluded")
    if args.variant is not None and legacy_extra:
        raise SystemExit(
            "do not combine explicit --variant with SV2V_DEFINES; production "
            "variants must declare every supported define through named options"
        )
    if args.variant is None:
        if "-DTUNIT_NO_DCS" in family_defines:
            variant = "adpcm"
        elif "-DTUNIT_NO_ADPCM" in family_defines:
            variant = "dcs"
        else:
            variant = "universal"
    else:
        variant = args.variant

    extra = [item for item in legacy_extra if item not in family_defines]
    if VARIANT_DEFINE[variant]:
        extra.append(VARIANT_DEFINE[variant])
    if args.diag and "-DTUNIT_DIAG" not in extra:
        extra.append("-DTUNIT_DIAG")

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    temporary = OUTPUT.with_name(f"{OUTPUT.name}.{os.getpid()}.tmp")
    command = [str(sv2v), "-DSYNTHESIS", *extra, *(str(path) for path in sources)]
    print(f"variant: {variant}")
    if extra:
        print("sv2v extra defines:", " ".join(extra))
    print(f"sv2v: {len(sources)} files -> {OUTPUT}")
    try:
        with temporary.open("wb") as output_stream:
            # Detached queue runners on Windows do not necessarily inherit a
            # valid console input handle. sv2v never reads stdin, so make that
            # contract explicit instead of letting Popen query an invalid
            # inherited handle before the production build can begin.
            result = subprocess.run(
                command,
                stdin=subprocess.DEVNULL,
                stdout=output_stream,
                check=False,
            )
        if result.returncode:
            temporary.unlink(missing_ok=True)
            raise SystemExit(f"sv2v failed with exit code {result.returncode}")
        if temporary.stat().st_size == 0:
            temporary.unlink(missing_ok=True)
            raise SystemExit("sv2v produced an empty output file")
        temporary.replace(OUTPUT)
    finally:
        temporary.unlink(missing_ok=True)

    text = OUTPUT.read_text(encoding="utf-8")
    remaining_casts = sum(
        1 for line in text.splitlines() if "'(" in line
    )
    vendor_inputs = (
        [
            ROOT / "rtl" / "vendor" / "mc6809" / "mc6809is.v",
            ROOT / "rtl" / "vendor" / "jt51" / "hdl" / "jt51.qip",
            ROOT / "rtl" / "vendor" / "jt6295" / "src" / "jt6295.qip",
        ]
        + sorted((ROOT / "rtl" / "vendor" / "jt51" / "hdl").glob("*.v"))
        + sorted((ROOT / "rtl" / "vendor" / "jt6295" / "src").glob("*.v"))
        + sorted((ROOT / "rtl" / "vendor" / "jt6295" / "src").glob("*.hex"))
    )
    tracked_inputs = sources + framework_physical_inputs() + vendor_inputs + [
        MANIFEST,
        ROOT / "Arcade-TUnit.qpf",
        ROOT / "build_id.v",
        ROOT / "Arcade-TUnit.sv",
        ROOT / "Arcade-TUnit.qsf",
        ROOT / "files.qip",
        ROOT / "rtl" / "common" / "tunit_quartus_pkg.sv",
        # The Quartus-facing HDMI scaler lives outside the flattened game core.
        # Bind the exact chassis sources and verifier into every artifact
        # manifest so a policy-labelled RBF cannot outlive its ascal wiring.
        ROOT / "sys" / "sys_top.v",
        ROOT / "sys" / "ascal.vhd",
        ROOT / "sys" / "hps_io.sv",
        ROOT / "docs" / "MISTER-FRAMEWORK-MANIFEST.md",
        ROOT / "tools" / "verify_framework_snapshot.py",
        ROOT / "tools" / "tunit_diag_qsf.tcl",
        ROOT / "tools" / "tunit_build_guard.tcl",
        ROOT / "tools" / "tunit_build_id.tcl",
        ROOT / "tools" / "pin_tunit_build_id.py",
        ROOT / "tools" / "check_tunit_ascal_policy.py",
        ROOT / "tools" / "verify_tunit_candidate_provenance.py",
        ROOT / "rtl" / "tunit.sdc",
        ROOT / "rtl" / "pll" / "pll_0002.v",
        ROOT / "tools" / "build_quartus_rtl.py",
        ROOT / "tools" / "preflight_tunit_build.py",
        ROOT / "tools" / "run_tunit_srt_gate.py",
        ROOT / "tools" / "run_tunit_env_transport_gate.py",
        ROOT / "sim" / "tb_tunit_display_blank.sv",
        ROOT / "tools" / "run_tunit_ppop_truth_gate.py",
        ROOT / "sim" / "monitors" / "tb_tunit_srt_fill.v",
        ROOT / "sim" / "monitors" / "tb_tunit_srt_pixt.v",
        # NBA/TE poll the timed software completion before performing a page
        # erase. Bind the real mapped-memory/VRAM repaint mutation proof.
        ROOT / "tools" / "run_tunit_srt_dma_order_gate.py",
        ROOT / "sim" / "tb_tunit_srt_dma_repaint.sv",
        ROOT / "sim" / "models" / "ddr3_avalon_model.sv",
        ROOT / "tools" / "run_tunit_vram_rdw_gate.py",
        ROOT / "tools" / "run_tunit_vram_read32_planes_gate.py",
        ROOT / "sim" / "tb_tunit_vram_read32_planes.sv",
        ROOT / "docs" / "NBA-SCREEN-SCALE-READ32-MAME0289-GOSPEL-2026-08-26.md",
        ROOT / "tools" / "run_tunit_nvram_gate.py",
        ROOT / "sim" / "tb_tunit_nvram_bridge.sv",
        # The flashing diagnostic is behavior-neutral, but its page-publication
        # counters and no-miss mutation are part of the cabinet evidence contract.
        ROOT / "tools" / "run_tunit_page_fence_gate.py",
        ROOT / "tools" / "run_tunit_page_fence_blank_end_gate.py",
        ROOT / "sim" / "tb_tunit_page_fence.sv",
        ROOT / "sim" / "tb_tunit_page_fence_blank_end.sv",
        ROOT / "sim" / "tb_tunit_page_owner_srt.sv",
        ROOT / "sim" / "tb_tunit_display_publish.sv",
        ROOT / "docs" / "NBA-PAGE-OWNER-SOURCE-CONTRACT-2026-08-23.md",
        ROOT / "sim" / "tb_tunit_page_diag.sv",
        ROOT / "tools" / "run_tunit_orphan_gate.py",
        ROOT / "tools" / "run_component_suite.py",
        # NBA scanout publication/coherence proof. These gates exercise the
        # same A/C/D publication stream and upper cache that ship in the blob.
        ROOT / "tools" / "run_tunit_scanline_coherence_gate.py",
        ROOT / "tools" / "run_tunit_scanline_integrated_tc_gate.py",
        ROOT / "tools" / "run_tunit_scanline_lookahead_gate.py",
        ROOT / "tools" / "run_tunit_scale140_rgb_gate.py",
        ROOT / "tools" / "run_tunit_video_pageflip_gate.py",
        ROOT / "sim" / "tb_tunit_scanline_coherence.sv",
        ROOT / "sim" / "tb_tunit_scanline_integrated_tc.sv",
        ROOT / "sim" / "tb_tunit_scanline_lookahead.sv",
        ROOT / "sim" / "tb_tunit_scale140_rgb.sv",
        ROOT / "sim" / "tb_tunit_video_ddr_pageflip.sv",
        ROOT / "docs" / "NBA-PENDING-PREWARM-MAME0289-GOSPEL-2026-08-26.md",
        ROOT / "tools" / "audit_tunit_scanline_physical.py",
        ROOT / "tools" / "audit_tunit_postfit_cdc.py",
        ROOT / "tools" / "report_tunit_scanline_snoop_timing.tcl",
        ROOT / "sim" / "tb_tunit_adpcm_board.sv",
        ROOT / "tools" / "run_tunit_ddr3_arb_gate.py",
        ROOT / "sim" / "tb_tunit_ddr3_arb.sv",
        ROOT / "tools" / "run_tms_shared.py",
        ROOT / "tools" / "run_tunit_audio_telemetry_gate.py",
        # ADPCM acceptance is split honestly: TE has an equal-duration MAME YM
        # stream; NBA AA is command delivery only because its 22.855 s attract
        # state is not replayed. Bind the oracle, capture script and reload gate
        # into the exact candidate provenance used for map/fit/assembly.
        ROOT / "tools" / "run_tunit_adpcm_tune_gate.py",
        ROOT / "tools" / "run_tunit_adpcm_realrom.py",
        ROOT / "tools" / "run_tunit_adpcm_reload_gate.py",
        ROOT / "sim" / "tb_tunit_adpcm_tune_pace.sv",
        ROOT / "sim" / "tb_tunit_adpcm_reload_fixedbank.sv",
        ROOT / "sim" / "tb_tunit_adpcm_cache_epoch.sv",
        ROOT / "sim" / "trace_tunit_adpcm_command_ym.lua",
        ROOT / "docs" / "goldens" / "nbajam_cmds.txt",
        ROOT / "docs" / "goldens" / "nbajamte_cmds.txt",
        ROOT / "docs" / "goldens" / "nbajamte_ym92_mame0280.json",
        ROOT / "tools" / "run_tunit_prequartus_qualification.py",
        ROOT / "tools" / "verify_tunit_qualification_receipt.py",
        ROOT / "tools" / "verify_tunit_goldens.py",
        ROOT / "docs" / "goldens" / "SHA256SUMS.txt",
        ROOT / "tools" / "build_tunit.sh",
        ROOT / "tools" / "run_queued_tunit_build.sh",
        ROOT / "tools" / "quartus_lock.sh",
        ROOT / "tools" / "assemble_gate.py",
        ROOT / "tools" / "finalize_tunit_artifact.py",
    ]
    # The framework list deliberately overlaps selected chassis files above.
    # Hash every physical input once so A/B equality is exact and the manifest
    # stays stable under harmless ordering changes.
    tracked_inputs = list(dict.fromkeys(tracked_inputs))
    missing_tracked = [path for path in tracked_inputs if not path.is_file()]
    if missing_tracked:
        raise SystemExit(
            "missing physical build input(s): "
            + ", ".join(str(path) for path in missing_tracked)
        )
    metadata = {
        "schema": 1,
        "variant": variant,
        "family_define": VARIANT_DEFINE[variant],
        "extra_defines": extra,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_commit": git_value("rev-parse", "HEAD"),
        "git_dirty": bool(git_value("status", "--porcelain")),
        "build_date": os.environ.get("TUNIT_BUILD_DATE"),
        "netlist": str(OUTPUT.relative_to(ROOT)).replace("\\", "/"),
        "netlist_sha256": digest(OUTPUT),
        "quartus_toolchain": quartus_toolchain(),
        "inputs_sha256": {
            str(path.relative_to(ROOT)).replace("\\", "/"): digest(path)
            for path in tracked_inputs
        },
    }
    manifest_tmp = BUILD_MANIFEST.with_name(
        f"{BUILD_MANIFEST.name}.{os.getpid()}.tmp"
    )
    try:
        manifest_tmp.write_text(
            json.dumps(metadata, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        manifest_tmp.replace(BUILD_MANIFEST)
    finally:
        manifest_tmp.unlink(missing_ok=True)
    print(f"generated {OUTPUT.stat().st_size:,} bytes; cast-lines remaining: {remaining_casts}")
    print(f"provenance: {BUILD_MANIFEST}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
