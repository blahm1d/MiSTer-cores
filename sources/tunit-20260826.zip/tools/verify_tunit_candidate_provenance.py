#!/usr/bin/env python3
"""Rehash a dirty candidate's sources and optionally bind ascal B to A."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output_files"
CURRENT_PROVENANCE = ROOT / "build_syn" / "tunit_core.manifest.json"
ASCAL_A_REFERENCE = (
    "output_files/"
    "Arcade-TUnit-ADPCM-ENGINEERING-NBA-ASCAL-A-NEAREST.manifest.json"
)
QUARTUS_EXECUTABLES = (
    "quartus_sh.exe",
    "quartus_map.exe",
    "quartus_fit.exe",
    "quartus_sta.exe",
    "quartus_asm.exe",
)


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def safe_path(base: Path, relative: str, errors: list[str]) -> Path | None:
    candidate = (base / relative).resolve()
    try:
        candidate.relative_to(base.resolve())
    except ValueError:
        errors.append(f"manifest path escapes {base.name}: {relative!r}")
        return None
    return candidate


def verify_hash_map(
    values: object, base: Path, label: str, errors: list[str]
) -> None:
    if not isinstance(values, dict) or not values:
        errors.append(f"manifest has no {label} hash map")
        return
    for relative, expected in values.items():
        if not isinstance(relative, str) or not isinstance(expected, str):
            errors.append(f"{label} hash map has a non-string row")
            continue
        path = safe_path(base, relative, errors)
        if path is None:
            continue
        if not path.is_file():
            errors.append(f"{label} file is missing: {relative}")
        elif digest(path) != expected:
            errors.append(f"{label} hash changed: {relative}")


def load_json(path: Path, label: str, errors: list[str]) -> dict[str, object]:
    if not path.is_file():
        errors.append(f"{label} is missing: {path}")
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"{label} is unreadable: {exc}")
        return {}
    if not isinstance(value, dict):
        errors.append(f"{label} root is not an object")
        return {}
    return value


def live_quartus_toolchain(errors: list[str]) -> dict[str, object]:
    raw_directory = os.environ.get("TUNIT_QUARTUS_BIN_WIN", "")
    if not raw_directory:
        errors.append("TUNIT_QUARTUS_BIN_WIN is absent")
        return {}
    directory = Path(raw_directory)
    hashes: dict[str, str] = {}
    for name in QUARTUS_EXECUTABLES:
        path = directory / name
        if not path.is_file():
            errors.append(f"Quartus executable is missing: {path}")
        else:
            hashes[name] = digest(path)
    return {"directory": str(directory), "executables_sha256": hashes}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--variant", required=True, choices=("universal", "adpcm", "dcs")
    )
    parser.add_argument("--reference", default="")
    args = parser.parse_args()

    errors: list[str] = []
    current = load_json(
        CURRENT_PROVENANCE, "current flattened-netlist provenance", errors
    )
    expected_manifest_sha = os.environ.get(
        "TUNIT_CANDIDATE_PROVENANCE_SHA256", ""
    )
    if not expected_manifest_sha:
        errors.append("candidate provenance baseline hash is absent")
    elif CURRENT_PROVENANCE.is_file() and digest(CURRENT_PROVENANCE) != expected_manifest_sha:
        errors.append("candidate provenance manifest changed after flatten")
    if current.get("variant") != args.variant:
        errors.append(
            f"current provenance variant={current.get('variant')!r}, "
            f"expected {args.variant!r}"
        )
    current_inputs = current.get("inputs_sha256")
    verify_hash_map(current_inputs, ROOT, "current source", errors)
    netlist = current.get("netlist")
    netlist_sha = current.get("netlist_sha256")
    if not isinstance(netlist, str) or not isinstance(netlist_sha, str):
        errors.append("current provenance has no netlist identity")
    else:
        verify_hash_map({netlist: netlist_sha}, ROOT, "current netlist", errors)
    current_toolchain = current.get("quartus_toolchain")
    live_toolchain = live_quartus_toolchain(errors)
    if current_toolchain != live_toolchain:
        errors.append("Quartus executable identity changed after flatten")

    reference_path: Path | None = None
    if args.reference:
        if args.variant != "adpcm":
            parser.error("the ascal A/B reference is valid only for ADPCM")
        reference_arg = Path(args.reference)
        reference_path = (
            reference_arg.resolve()
            if reference_arg.is_absolute()
            else (ROOT / reference_arg).resolve()
        )
        expected_reference = (ROOT / ASCAL_A_REFERENCE).resolve()
        if reference_path != expected_reference:
            parser.error(
                "B must reference the exact A manifest " + ASCAL_A_REFERENCE
            )

        reference = load_json(reference_path, "A reference manifest", errors)
        expected_reference_fields = {
            "variant": "adpcm",
            "ascal_policy": "nearest",
            "artifact_id": "NBA-ASCAL-A-NEAREST",
            "engineering": True,
            "artifact_class": "engineering-do-not-package",
        }
        for key, expected in expected_reference_fields.items():
            if reference.get(key) != expected:
                errors.append(
                    f"A reference {key}={reference.get(key)!r}, "
                    f"expected {expected!r}"
                )
        timing_checks = reference.get("timing_checks")
        worst_slack = reference.get("worst_slack")
        if not isinstance(timing_checks, int) or timing_checks <= 0:
            errors.append("A reference has no positive timing-check count")
        if not isinstance(worst_slack, (int, float)) or worst_slack < 0:
            errors.append("A reference is not timing-clean")

        verify_hash_map(
            reference.get("artifacts_sha256"), OUT, "A artifact", errors
        )
        verify_hash_map(
            reference.get("reports_sha256"), OUT, "A report", errors
        )
        warning = reference.get("engineering_warning")
        if not isinstance(warning, dict):
            errors.append("A reference has no engineering warning record")
        else:
            warning_path = warning.get("path")
            warning_hash = warning.get("sha256")
            if isinstance(warning_path, str) and isinstance(warning_hash, str):
                verify_hash_map(
                    {warning_path: warning_hash}, OUT, "A warning", errors
                )
            else:
                errors.append("A engineering warning record is malformed")

        reference_provenance = reference.get("source_provenance")
        if not isinstance(reference_provenance, dict):
            errors.append("A reference has no source provenance")
            reference_provenance = {}
        for key in (
            "variant",
            "family_define",
            "extra_defines",
            "git_commit",
            "git_dirty",
            "build_date",
            "netlist_sha256",
            "inputs_sha256",
            "quartus_toolchain",
        ):
            if current.get(key) != reference_provenance.get(key):
                errors.append(f"current B provenance differs from A at {key}")
        current_seed = os.environ.get("TUNIT_SEED") or None
        if reference.get("fitter_seed_override") != current_seed:
            errors.append(
                "current B fitter seed differs from A: "
                f"B={current_seed!r} A={reference.get('fitter_seed_override')!r}"
            )
        if reference_provenance.get("build_date") != os.environ.get(
            "TUNIT_BUILD_DATE"
        ):
            errors.append("current B build date differs from A")

    if errors:
        for error in errors:
            print(f"CANDIDATE PROVENANCE: FAIL -- {error}")
        return 1

    reference_text = (
        f" reference_sha256={digest(reference_path)}" if reference_path else ""
    )
    print(
        "CANDIDATE PROVENANCE: PASS "
        f"variant={args.variant} "
        f"netlist_sha256={current.get('netlist_sha256')} "
        f"tracked_inputs={len(current_inputs)}{reference_text}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
