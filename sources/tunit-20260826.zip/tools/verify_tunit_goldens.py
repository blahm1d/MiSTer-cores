#!/usr/bin/env python3
"""Fail-closed integrity and exact-diff gate for the frozen five-title corpus."""

from __future__ import annotations

import argparse
from hashlib import sha256
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[1]
GOLDENS = ROOT / "docs" / "goldens"
SUMS = GOLDENS / "SHA256SUMS.txt"
TITLES = ("mk", "mk2", "nbajam", "nbajamte", "jdreddp")
KINDS = ("blits", "cmds", "px")
EXPECTED = {f"{title}_{kind}.txt" for title in TITLES for kind in KINDS}
PROVENANCE = (
    "official MAME 0.289 signed tag",
    "mame0289",
    "f34f02505e32c1993c6a782b6814232cbfc74e36",
    "3000 frames",
)
SUM_ROW = re.compile(r"^([0-9a-f]{64})  ([a-z0-9_]+\.txt)$")
CMD_ROW = re.compile(
    r"^W t=([0-9]+\.[0-9]{6}) f=([0-9]+) data=([0-9A-F]{4})(?: .*)?$"
)
BLIT_ROW = re.compile(
    r"^BLITCENSUS frames=(\d+) total=(\d+) mean=([0-9.]+) "
    r"median=(\d+) p99=(\d+) peak=(\d+)$"
)
PIXEL_ROW = re.compile(
    r"^PIXCENSUS frames=(\d+) blits=(\d+) px_total=(\d+) "
    r"px_mean=(\d+) px_median=(\d+) px_p99=(\d+) px_peak=(\d+)$"
)


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def fail(message: str, errors: list[str]) -> None:
    errors.append(message)


def load_manifest(errors: list[str]) -> dict[str, str]:
    try:
        text = SUMS.read_text(encoding="utf-8")
    except OSError as exc:
        fail(f"cannot read {SUMS}: {exc}", errors)
        return {}
    for marker in PROVENANCE:
        if marker not in text:
            fail(f"golden provenance is missing {marker!r}", errors)
    rows: dict[str, str] = {}
    for line_number, line in enumerate(text.splitlines(), 1):
        if not line or line.startswith("#"):
            continue
        match = SUM_ROW.fullmatch(line)
        if not match:
            fail(f"malformed checksum row {line_number}: {line!r}", errors)
            continue
        wanted, name = match.groups()
        if name in rows:
            fail(f"duplicate checksum row: {name}", errors)
        rows[name] = wanted
    if set(rows) != EXPECTED:
        fail(
            "checksum corpus differs: missing="
            f"{sorted(EXPECTED - set(rows))} extra={sorted(set(rows) - EXPECTED)}",
            errors,
        )
    return rows


def validate_corpus(rows: dict[str, str], errors: list[str]) -> None:
    blit_totals: dict[str, int] = {}
    pixel_blits: dict[str, int] = {}
    for name, wanted in sorted(rows.items()):
        path = GOLDENS / name
        if not path.is_file():
            fail(f"missing golden: {name}", errors)
            continue
        actual = digest(path)
        if actual != wanted:
            fail(f"golden hash mismatch: {name} got={actual} want={wanted}", errors)
            continue
        text = path.read_text(encoding="ascii", errors="strict")
        lines = text.splitlines()
        if not lines:
            fail(f"empty golden: {name}", errors)
            continue
        title, kind = name[:-4].rsplit("_", 1)
        if kind == "cmds":
            last_time = -1.0
            for line_number, line in enumerate(lines, 1):
                match = CMD_ROW.fullmatch(line)
                if not match:
                    fail(f"{name}:{line_number}: malformed command row", errors)
                    continue
                when = float(match.group(1))
                if when < last_time:
                    fail(f"{name}:{line_number}: command time moved backwards", errors)
                last_time = when
                if "RESET_ASSERT" in line and match.group(3) != "FE00":
                    fail(f"{name}:{line_number}: RESET_ASSERT is not FE00", errors)
        elif kind == "blits":
            match = BLIT_ROW.fullmatch(lines[0]) if len(lines) == 1 else None
            if not match or int(match.group(1)) != 3000:
                fail(f"{name}: malformed or non-3000-frame blit census", errors)
            else:
                blit_totals[title] = int(match.group(2))
        else:
            match = PIXEL_ROW.fullmatch(lines[0]) if len(lines) == 1 else None
            if not match or int(match.group(1)) != 3000:
                fail(f"{name}: malformed or non-3000-frame pixel census", errors)
            else:
                pixel_blits[title] = int(match.group(2))
    for title in TITLES:
        if title in blit_totals and title in pixel_blits:
            if blit_totals[title] != pixel_blits[title]:
                fail(
                    f"{title}: blit census total {blit_totals[title]} != "
                    f"pixel census blits {pixel_blits[title]}",
                    errors,
                )


def compare_candidate(candidate: Path, rows: dict[str, str], errors: list[str]) -> None:
    if not candidate.is_dir():
        fail(f"candidate corpus directory is missing: {candidate}", errors)
        return
    present = {path.name for path in candidate.glob("*.txt")}
    if present != EXPECTED:
        fail(
            "candidate corpus differs: missing="
            f"{sorted(EXPECTED - present)} extra={sorted(present - EXPECTED)}",
            errors,
        )
    for name in sorted(EXPECTED & present):
        candidate_hash = digest(candidate / name)
        if candidate_hash != rows.get(name):
            fail(
                f"candidate differs from frozen MAME golden: {name} "
                f"got={candidate_hash} want={rows.get(name)}",
                errors,
            )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--candidate-dir",
        type=Path,
        help="require a regenerated 15-file corpus to match byte-for-byte",
    )
    args = parser.parse_args()
    errors: list[str] = []
    rows = load_manifest(errors)
    if rows:
        validate_corpus(rows, errors)
        if args.candidate_dir is not None:
            compare_candidate(args.candidate_dir.resolve(), rows, errors)
    if errors:
        for error in errors:
            print(f"GOLDEN GATE: FAIL -- {error}", file=sys.stderr)
        return 1
    suffix = (
        f"; candidate={args.candidate_dir.resolve()} byte-exact"
        if args.candidate_dir is not None
        else ""
    )
    print(
        "PASS: T-unit MAME 0.289 goldens files=15 titles=5 "
        f"frames=3000 hashes=exact cross_census=exact{suffix}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
