#!/usr/bin/env python3
"""Verify a PASS pre-Quartus receipt still binds the current clean netlist."""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]

# Deliberately independent of run_tunit_prequartus_qualification.py.  Importing
# the runner's constants here lets one edit redefine both the producer and its
# verifier, recreating the self-consistency failure this receipt is meant to
# stop.  A gate-contract change must now update and review two separate files.
REQUIRED_GATE_CONTRACT = (
    ("flatten_universal", "build_quartus_rtl.py", "provenance:"),
    ("frozen_mame_goldens", "verify_tunit_goldens.py", "PASS: T-unit MAME 0.289 goldens"),
    ("framework_snapshot", "verify_framework_snapshot.py", "PASS: framework snapshot"),
    ("mra_mame_crosscheck", "validate_tunit_candidate_mras.py", "PASS: local MAME"),
    ("component_suite", "run_component_suite.py", "selected=46 run=46 passed=46 failed=0\nfailed_tests=\ncadence_phase6_mutation=killed"),
    ("ddr3_priority", "run_tunit_ddr3_arb_gate.py", "DDR3 ARBITRATION GATE: PASS"),
    ("tms34010_union", "run_tms_shared.py", "selected=130 run=130 passed=130 failed=0 inconclusive=0"),
    ("audio_telemetry_window", "run_tunit_audio_telemetry_gate.py", "AUDIO TELEMETRY GATE: PASS"),
    ("orphan_mutations", "run_tunit_orphan_gate.py", "ORPHAN GATE: PASS"),
    ("profile_layout", "run_tunit_profile_matrix.py", "PASS: T-unit profile/layout matrix"),
    ("five_profile_boot", "run_tunit_profile_boot_gate.py", "PROFILE BOOT GATE: PASS"),
    ("loader_equivalence", "run_tunit_loader_equiv_gate.py", "LOADER-EQUIV GATE: PASS"),
    ("loader_mutations", "run_tunit_loader_equiv_gate.py", "LOADER-EQUIV MUTATION SUITE: PASS"),
    ("srt_fill", "run_tunit_srt_gate.py", "SRT GATE: PASS"),
    ("srt_dma_order", "run_tunit_srt_dma_order_gate.py", "TUNIT SRT-DMA ORDER GATE: PASS"),
    ("instruction_spacing", "run_tunit_spacing_gate.py", "SPACING GATE: PASS"),
    ("dma_matrix", "run_tunit_dma_matrix.py", "T-unit DMA2 matrix: 161/161 cases"),
    ("video_matrix", "run_tunit_video_matrix.py", "T-unit video matrix:"),
    ("gfx_cycle_accounting", "run_tunit_gfx_cycle_gate.py", "PASS: signed MAME 0.289 graphics cycles"),
    ("ppop_truth", "run_tunit_ppop_truth_gate.py", "PPOP GATE: PASS"),
    ("gfx_reuse_cache", "run_tunit_gfx_reuse_cache_gate.py", "PASS: T source reuse matches Wolf"),
    ("vram_rdw", "run_tunit_vram_rdw_gate.py", "PASS: CPU VRAM requests survive"),
    ("vram_read32_planes", "run_tunit_vram_read32_planes_gate.py", "PASS: aligned CPU read32 returns all four selected bytes"),
    ("vram_read32_truncate_mutation", "run_tunit_vram_read32_planes_gate.py", "PASS: exact aligned-read32 upper-half-zero defect reproduced"),
    ("vram_scan_coherency", "run_tunit_vram_scan_gate.py", "PASS: scan coherency contracts exercised"),
    ("vram_bank1", "run_tunit_vram_bank1_gate.py", "PASS: bank-1 paired-write contracts exercised"),
    ("scanline_coherence", "run_tunit_scanline_coherence_gate.py", "PASS: scanline coherence gate"),
    ("scanline_integrated_acd", "run_tunit_scanline_integrated_tc_gate.py", "PASS: integrated TC gate"),
    ("scanline_lookahead", "run_tunit_scanline_lookahead_gate.py", "PASS: scanline lookahead gate"),
    ("scale140_rgb", "run_tunit_scale140_rgb_gate.py", "PASS: Scale140 paired pixels survive DDR-to-RGB; mutation killed"),
    ("video_pageflip", "run_tunit_video_pageflip_gate.py", "PASS: hidden pending page prewarms before atomic publication"),
    ("page_fence", "run_tunit_page_fence_gate.py", "PAGE FENCE GATE: PASS"),
    ("page_fence_blank_end", "run_tunit_page_fence_blank_end_gate.py", "PAGE FENCE BLANK-END GATE: PASS"),
    ("dma_page_kill", "run_tunit_dma_page_kill_gate.py", "PASS: T-unit DMA2 literal kill publishes page"),
    ("raster_resync", "run_tunit_raster_resync_gate.py", "RASTER RESYNC GATE: PASS"),
    ("crt_adjust", "run_tunit_crt_adjust_gate.py", "PASS: tb_tunit_crt_adjust"),
    ("adpcm_te_tune_nba_command", "run_tunit_adpcm_tune_gate.py", "ADPCM TE-TUNE/NBA-COMMAND GATE: PASS"),
    ("adpcm_reload_fixedbank", "run_tunit_adpcm_reload_gate.py", "ADPCM RELOAD INTEGRATION GATE: PASS"),
    ("mk2_dcs_pcm", "run_mk2_dcs_pcm.py", "PASS: MK2 DCS2K PCM gate"),
    ("mk2_frame_crc", "run_mk2_frame_gate.py", "PASS: MK2 frame gate"),
)
REQUIRED_GATE_NAMES = tuple(row[0] for row in REQUIRED_GATE_CONTRACT)
REQUIRED_EXPLICIT_INPUT_NAMES = (
    "dcs_rom", "dcs_wav", "mame", "mk2_frame_golden", "mk2_graphics",
    "mk2_nvram", "mk2_program", "profile_program_jdreddp", "profile_program_mk",
    "profile_program_mk2", "profile_program_nbajam", "profile_program_nbajamte",
    "rom_archive_jdreddp", "rom_archive_mk", "rom_archive_mk2",
    "rom_archive_nbajam", "rom_archive_nbajamte",
)
REQUIRED_COMMAND_SEQUENCES = {
    "flatten_universal": (("--variant", "universal"),),
    "component_suite": (("--stop-on-fail",),),
    "tms34010_union": (("--stop-on-fail",),),
    "five_profile_boot": (("--cadence", "both"),),
    "loader_mutations": (("--mutate", "ALL"),),
    "instruction_spacing": (("--sweep-cycles", "200000"),),
    "vram_read32_truncate_mutation": (
        ("--mutation", "truncate-upper"),
        ("--expect-repro",),
    ),
    "mk2_dcs_pcm": (("--track", "01ca"), ("--looping",)),
    # Independently pin the longest MAME/DUT bit-exact boot window. Frame 59 is
    # intentionally excluded: the capture has advanced to PC FFA64620 while
    # the real-latency RTL is still at FF80F2A0, so later attract animation is
    # not a cycle-locked pixel oracle. The video_pageflip gate separately binds
    # and mutates the NBA/TE-only page-owner seam and its non-NBA scope.
    "mk2_frame_crc": (
        ("--engine", "netlist-qrun"),
        ("--netlist", str(ROOT / "build_syn" / "tunit_core.v")),
        ("--frame-count", "59"),
        ("--frame-skip", "0"),
        ("--golden-start", "0"),
        ("--wall-timeout", "3600"),
        ("--qualification-window",),
    ),
}
FORBIDDEN_GATE_ARGUMENTS = (
    "--allow-dirty", "--diagnostic", "--no-mutate", "--skip-listxml",
)
FRAME_SIMULATOR_TOOL_NAMES = ("qrun", "vlog", "vopt", "vsim")


def digest(path: Path) -> str:
    value = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, text=True, stderr=subprocess.DEVNULL
    ).strip()


def resolve_recorded(path: str) -> Path:
    value = Path(path)
    return value if value.is_absolute() else ROOT / value


def qsf_newline_equivalent(path: Path, expected: str) -> bool:
    """Accept only Quartus's known mixed-newline-to-all-CRLF rewrite."""

    raw = path.read_bytes()
    if b"\r" in raw.replace(b"\r\n", b"") or not raw.endswith(b"\r\n"):
        return False
    logical = raw.replace(b"\r\n", b"\n")
    lines = logical[:-1].split(b"\n")
    for start in range(len(lines)):
        for end in range(start, len(lines)):
            candidate = b"".join(
                line + (b"\n" if start <= index <= end else b"\r\n")
                for index, line in enumerate(lines)
            )
            if sha256(candidate).hexdigest() == expected:
                return True
    return False


def contains_sequence(command: list[str], sequence: tuple[str, ...]) -> bool:
    width = len(sequence)
    return any(tuple(command[index:index + width]) == sequence
               for index in range(len(command) - width + 1))


def command_option(gate: dict, option: str) -> str | None:
    command = gate.get("command")
    if not isinstance(command, list) or command.count(option) != 1:
        return None
    index = command.index(option)
    if index + 1 >= len(command):
        return None
    return str(command[index + 1])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--variant", choices=("universal",), required=True)
    args = parser.parse_args()
    receipt_path = args.receipt.resolve()
    errors: list[str] = []
    try:
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"QUALIFICATION RECEIPT: FAIL -- unreadable receipt: {exc}", file=sys.stderr)
        return 2
    if receipt.get("schema") != 1:
        errors.append("unsupported schema")
    label = receipt.get("label")
    if not isinstance(label, str) or not re.fullmatch(
        r"[A-Za-z0-9][A-Za-z0-9_.-]*", label
    ):
        errors.append("qualification label is missing or malformed")
    if receipt.get("status") != "PASS":
        errors.append(f"status is {receipt.get('status')!r}, not PASS")
    if not receipt.get("production_build_eligible") or receipt.get("source_dirty"):
        errors.append(
            "receipt was not produced from a clean production-build-eligible tree"
        )
    if receipt.get("acceptance") != (
        "pre-Quartus candidate baseline; cabinet acceptance not implied"
    ):
        errors.append("receipt acceptance scope is missing or changed")
    if receipt.get("variant") != args.variant:
        errors.append("variant mismatch")
    current_commit = git("rev-parse", "HEAD")
    if receipt.get("source_commit") != current_commit:
        errors.append(
            f"source commit mismatch receipt={receipt.get('source_commit')} current={current_commit}"
        )
    if git("status", "--porcelain"):
        errors.append("current worktree is dirty")
    golden_manifest = ROOT / "docs" / "goldens" / "SHA256SUMS.txt"
    if (
        not golden_manifest.is_file()
        or digest(golden_manifest) != receipt.get("golden_manifest_sha256")
    ):
        errors.append("frozen MAME golden manifest changed")
    runner = ROOT / "tools" / "run_tunit_prequartus_qualification.py"
    if digest(runner) != receipt.get("runner_sha256"):
        errors.append("qualification runner changed after the receipt was issued")

    simulator_tools = receipt.get("frame_simulator_tools")
    if not isinstance(simulator_tools, dict) or tuple(sorted(simulator_tools)) != tuple(
        sorted(FRAME_SIMULATOR_TOOL_NAMES)
    ):
        errors.append("frame-simulator toolchain receipt is absent or malformed")
        simulator_tools = {}
    current_qrun = shutil.which("qrun")
    current_qrun_path = Path(current_qrun).resolve() if current_qrun else None
    for name in FRAME_SIMULATOR_TOOL_NAMES:
        record = simulator_tools.get(name)
        if not isinstance(record, dict):
            errors.append(f"frame-simulator tool record is missing: {name}")
            continue
        path_text = record.get("path")
        wanted = record.get("sha256")
        if not isinstance(path_text, str):
            errors.append(f"frame-simulator tool path is malformed: {name}")
            continue
        path = Path(path_text).resolve()
        if current_qrun_path is None:
            errors.append("qrun is no longer available on PATH")
        elif name == "qrun" and path != current_qrun_path:
            errors.append("qualified qrun path differs from the current qrun")
        elif name != "qrun":
            suffix = current_qrun_path.suffix or ".exe"
            expected = current_qrun_path.with_name(name + suffix)
            if path != expected:
                errors.append(f"qualified {name} is not qrun's sibling binary")
        if not path.is_file() or digest(path) != wanted:
            errors.append(f"qualified frame-simulator tool changed: {name}")

    gates = receipt.get("gates")
    if not isinstance(gates, list):
        gates = []
        errors.append("gate list is absent")
    names = tuple(gate.get("name") for gate in gates if isinstance(gate, dict))
    if names != REQUIRED_GATE_NAMES:
        errors.append("gate set/order differs from the release contract")
    gate_contract = {name: (script, marker) for name, script, marker in REQUIRED_GATE_CONTRACT}
    gate_logs: dict[str, str] = {}
    for gate in gates:
        if not isinstance(gate, dict):
            continue
        name = gate.get("name", "<unnamed>")
        if gate.get("returncode") != 0 or not gate.get("marker_found"):
            errors.append(f"gate is not a proven pass: {name}")
        expected = gate_contract.get(name)
        if expected is None:
            errors.append(f"unexpected gate: {name}")
        else:
            expected_script, expected_marker = expected
            if Path(str(gate.get("script_path", ""))).name != expected_script:
                errors.append(f"{name}: wrong gate script")
            if gate.get("required_marker") != expected_marker:
                errors.append(f"{name}: required verdict marker differs from contract")
            command = gate.get("command")
            if not isinstance(command, list) or len(command) < 2:
                errors.append(f"{name}: executed command is absent or malformed")
            else:
                expected_command_script = (ROOT / "tools" / expected_script).resolve()
                try:
                    actual_command_script = Path(str(command[1])).resolve()
                except OSError:
                    actual_command_script = Path()
                if actual_command_script != expected_command_script:
                    errors.append(f"{name}: executed command used the wrong script path")
                for sequence in REQUIRED_COMMAND_SEQUENCES.get(name, ()):
                    if not contains_sequence(command, sequence):
                        errors.append(
                            f"{name}: executed command lacks required arguments "
                            + " ".join(sequence)
                        )
                for forbidden in FORBIDDEN_GATE_ARGUMENTS:
                    if forbidden in command:
                        errors.append(f"{name}: forbidden relaxation argument {forbidden}")
        for kind in ("script", "log"):
            path = resolve_recorded(str(gate.get(f"{kind}_path", "")))
            wanted = gate.get(f"{kind}_sha256")
            if not path.is_file() or digest(path) != wanted:
                errors.append(f"{name}: {kind} evidence missing or changed")
            elif kind == "log" and expected is not None:
                log_text = path.read_text(encoding="utf-8", errors="replace")
                gate_logs[str(name)] = log_text
                if expected[1] not in log_text:
                    errors.append(f"{name}: required verdict marker is absent from log")

    frame_log = gate_logs.get("mk2_frame_crc", "")
    for name, record in simulator_tools.items():
        if not isinstance(record, dict):
            continue
        needle = (
            f"SIMULATOR_TOOL name={name} sha256={record.get('sha256')} "
            f"path={record.get('path')}"
        )
        if needle not in frame_log:
            errors.append(f"mk2_frame_crc: simulator log does not bind tool {name}")

    manifest_path = ROOT / "build_syn" / "tunit_core.manifest.json"
    netlist_path = ROOT / "build_syn" / "tunit_core.v"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        manifest = {}
        errors.append(f"current netlist manifest unreadable: {exc}")
    if manifest.get("variant") != args.variant:
        errors.append("current flattened netlist variant differs")
    if manifest.get("extra_defines") != []:
        errors.append("current production netlist contains extra Verilog defines")
    if manifest.get("git_commit") != current_commit or manifest.get("git_dirty"):
        errors.append("current flattened netlist was not generated from this clean commit")
    if not netlist_path.is_file() or digest(netlist_path) != receipt.get("netlist_sha256"):
        errors.append("current flattened netlist differs from qualified netlist")
    if manifest.get("netlist_sha256") != receipt.get("netlist_sha256"):
        errors.append("current netlist manifest hash differs from qualification")
    if receipt.get("flatten_git_commit") != receipt.get("source_commit"):
        errors.append("flatten receipt commit differs from qualification commit")
    if bool(receipt.get("flatten_git_dirty")) != bool(receipt.get("source_dirty")):
        errors.append("flatten receipt dirty state differs from qualification state")
    source_inputs = receipt.get("source_inputs_sha256", {})
    if not isinstance(source_inputs, dict) or not source_inputs:
        errors.append("receipt contains no flattened-source hashes")
        source_inputs = {}
    if manifest.get("inputs_sha256") != source_inputs:
        errors.append("current netlist source-input set differs from qualification")
    for relative, wanted in source_inputs.items():
        path = ROOT / relative
        if not path.is_file():
            errors.append(f"qualified source input missing or changed: {relative}")
            continue
        if digest(path) == wanted:
            continue
        if relative == "Arcade-TUnit.qsf" and qsf_newline_equivalent(path, wanted):
            continue
        errors.append(f"qualified source input missing or changed: {relative}")
    explicit_inputs = receipt.get("explicit_inputs_sha256", {})
    if not isinstance(explicit_inputs, dict):
        errors.append("explicit qualification input set is malformed")
        explicit_inputs = {}
    if tuple(sorted(explicit_inputs)) != REQUIRED_EXPLICIT_INPUT_NAMES:
        errors.append("explicit qualification input set differs from contract")
    for name, record in explicit_inputs.items():
        if not isinstance(record, dict):
            errors.append(f"malformed explicit input record: {name}")
            continue
        path = resolve_recorded(str(record.get("path", "")))
        if not path.is_file() or digest(path) != record.get("sha256"):
            errors.append(f"explicit qualification input missing or changed: {name}")

    gate_by_name = {
        str(gate.get("name")): gate for gate in gates if isinstance(gate, dict)
    }
    expected_option_inputs = (
        ("mra_mame_crosscheck", "--mame", "mame"),
        ("mk2_dcs_pcm", "--rom", "dcs_rom"),
        ("mk2_dcs_pcm", "--wav", "dcs_wav"),
        ("mk2_frame_crc", "--program", "mk2_program"),
        ("mk2_frame_crc", "--graphics", "mk2_graphics"),
        ("mk2_frame_crc", "--sound", "dcs_rom"),
        ("mk2_frame_crc", "--nvram", "mk2_nvram"),
        ("mk2_frame_crc", "--golden", "mk2_frame_golden"),
    )
    for gate_name, option, input_name in expected_option_inputs:
        gate = gate_by_name.get(gate_name, {})
        value = command_option(gate, option)
        record = explicit_inputs.get(input_name, {})
        recorded_path = record.get("path") if isinstance(record, dict) else None
        if value is None or recorded_path is None or (
            resolve_recorded(value).resolve()
            != resolve_recorded(str(recorded_path)).resolve()
        ):
            errors.append(f"{gate_name}: {option} is not the bound {input_name}")
    frame_netlist = command_option(gate_by_name.get("mk2_frame_crc", {}), "--netlist")
    if (
        frame_netlist is None
        or resolve_recorded(frame_netlist).resolve()
        != (ROOT / "build_syn" / "tunit_core.v").resolve()
    ):
        errors.append("mk2_frame_crc: --netlist is not the qualified production netlist")
    archive_record = explicit_inputs.get("rom_archive_mk", {})
    archive_path = (
        resolve_recorded(str(archive_record.get("path"))).resolve()
        if isinstance(archive_record, dict) and archive_record.get("path")
        else None
    )
    for gate_name in ("mra_mame_crosscheck", "adpcm_te_tune_nba_command"):
        value = command_option(gate_by_name.get(gate_name, {}), "--rom-dir")
        if value is None or archive_path is None or resolve_recorded(value).resolve() != archive_path.parent:
            errors.append(f"{gate_name}: --rom-dir is not the bound archive directory")
    for title in ("mk", "mk2", "nbajam", "nbajamte", "jdreddp"):
        name = f"profile_program_{title}"
        record = explicit_inputs.get(name, {})
        recorded = record.get("path") if isinstance(record, dict) else None
        expected_path = (ROOT / "sim" / "generated" / f"{title}_main.bin").resolve()
        if recorded is None or resolve_recorded(str(recorded)).resolve() != expected_path:
            errors.append(f"{name}: path is not the fixed profile-boot input")

    if errors:
        for error in errors:
            print(f"QUALIFICATION RECEIPT: FAIL -- {error}", file=sys.stderr)
        return 1
    print(
        "PASS: qualification receipt bound "
        f"gates={len(gates)} variant={args.variant} commit={current_commit} "
        f"netlist={receipt.get('netlist_sha256')} receipt_sha256={digest(receipt_path)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
