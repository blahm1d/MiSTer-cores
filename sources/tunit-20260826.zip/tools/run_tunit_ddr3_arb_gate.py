#!/usr/bin/env python3
"""Prove A-C-B DDR3 priority and kill the conditional-sound rollback."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
RTL = ROOT / "rtl" / "tunit" / "tunit_ddr3_arb.sv"
BENCH = ROOT / "sim" / "tb_tunit_ddr3_arb.sv"
PASS_MARKER = (
    "PASS tb_tunit_ddr3_arb priority A-C-B held-grant beat-routing reset"
)
MUTATION_MARKER = "unconditional C did not follow A"


def timeout_text(value: str | bytes | None) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value


def compile_and_run(
    out: Path, name: str, defines: tuple[str, ...]
) -> tuple[int, int | None, str]:
    image = out / f"{name}.vvp"
    compile_result = subprocess.run(
        [
            "iverilog", "-g2012", *(f"-D{item}" for item in defines),
            "-s", "tb_tunit_ddr3_arb", "-o", str(image), str(RTL), str(BENCH),
        ],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    compile_log = (compile_result.stdout or "") + (compile_result.stderr or "")
    (out / f"{name}-compile.log").write_text(
        compile_log, encoding="utf-8", errors="replace"
    )
    if compile_result.returncode:
        return compile_result.returncode, None, compile_log
    try:
        sim_result = subprocess.run(
            ["vvp", str(image)], cwd=ROOT, text=True, capture_output=True,
            timeout=60, check=False,
        )
    except subprocess.TimeoutExpired as exc:
        log = timeout_text(exc.stdout) + timeout_text(exc.stderr)
        log += "\nTIMEOUT after 60s\n"
        (out / f"{name}-sim.log").write_text(
            log, encoding="utf-8", errors="replace"
        )
        return 0, 124, log
    log = (sim_result.stdout or "") + (sim_result.stderr or "")
    (out / f"{name}-sim.log").write_text(
        log, encoding="utf-8", errors="replace"
    )
    return 0, sim_result.returncode, log


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--label",
        default="tunit-ddr3-arb-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    args = parser.parse_args()
    if not shutil.which("iverilog") or not shutil.which("vvp"):
        print("DDR3 ARBITRATION GATE: FAIL -- iverilog/vvp unavailable", file=sys.stderr)
        return 2
    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"DDR3 ARBITRATION GATE: FAIL -- output exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)

    stock_compile, stock_sim, stock_log = compile_and_run(out, "stock", ())
    if (
        stock_compile != 0
        or stock_sim != 0
        or PASS_MARKER not in stock_log
        or "Fatal" in stock_log
    ):
        print(stock_log, end="")
        print("DDR3 ARBITRATION GATE: FAIL -- production A-C-B contract", file=sys.stderr)
        return 1

    mutant_compile, mutant_sim, mutant_log = compile_and_run(
        out, "sound-last-mutant", ("MUT_TUNIT_SOUND_LAST",)
    )
    killed = (
        mutant_compile == 0
        and mutant_sim == 1
        and MUTATION_MARKER in mutant_log
        and PASS_MARKER not in mutant_log
    )
    if not killed:
        print(mutant_log, end="")
        print(
            "DDR3 ARBITRATION GATE: FAIL -- conditional-sound rollback survived "
            "or failed for an unrelated reason",
            file=sys.stderr,
        )
        return 1
    print(
        "DDR3 ARBITRATION GATE: PASS stock=A-C-B; "
        "MUT_TUNIT_SOUND_LAST killed by exact C-after-A witness"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
