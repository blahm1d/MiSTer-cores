#!/usr/bin/env python3
"""Mutation-prove TC retargeting and loading-row CPU-write coherence."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    iverilog = shutil.which("iverilog")
    vvp = shutil.which("vvp")
    if not iverilog or not vvp:
        print("ERROR: iverilog and vvp are required", file=sys.stderr)
        return 2

    label = "tunit-scanline-coherence-" + datetime.now().strftime("%Y%m%d-%H%M%S")
    out = ROOT / "sim" / "out" / label
    out.mkdir(parents=True)
    sources = [
        ROOT / "rtl/tunit/tunit_scanline.sv",
        ROOT / "sim/tb_tunit_scanline_coherence.sv",
    ]
    cases = {
        "production": ([], "PASS tb_tunit_scanline_coherence"),
        "three-line-mutation": (
            ["-DMUT_TUNIT_SCAN_THREE_LINES"],
            "PASS MUTATION_KILLED three-line-repeat",
        ),
        "victim-valid-mutation": (
            ["-DMUT_TUNIT_SCAN_KEEP_VICTIM_VALID"],
            "PASS MUTATION_KILLED victim-valid",
        ),
        "no-retarget-abort-mutation": (
            ["-DMUT_TUNIT_SCAN_NO_RETARGET_ABORT"],
            "PASS MUTATION_KILLED no-retarget-abort",
        ),
        "no-fill-snoop-mutation": (
            ["-DMUT_TUNIT_SCAN_NO_FILL_SNOOP"],
            "PASS MUTATION_KILLED no-fill-snoop",
        ),
    }
    passed = True
    for name, (defines, marker) in cases.items():
        executable = out / f"{name}.vvp"
        compile_cmd = [
            iverilog,
            "-g2012",
            "-s",
            "tb_tunit_scanline_coherence",
            *defines,
            "-o",
            str(executable),
            *(str(source) for source in sources),
        ]
        compile_result = subprocess.run(
            compile_cmd, cwd=ROOT, text=True, capture_output=True
        )
        (out / f"{name}-compile.log").write_text(
            (compile_result.stdout or "") + (compile_result.stderr or ""),
            encoding="utf-8",
        )
        if compile_result.returncode:
            passed = False
            continue
        run_result = subprocess.run(
            [vvp, str(executable)], cwd=ROOT, text=True, capture_output=True
        )
        log = (run_result.stdout or "") + (run_result.stderr or "")
        (out / f"{name}-sim.log").write_text(log, encoding="utf-8")
        if run_result.returncode or marker not in log or "FATAL" in log.upper():
            passed = False

    print(("PASS" if passed else "FAIL") + f": scanline coherence gate ({out})")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
