#!/usr/bin/env python3
"""Verify CPU VRAM request staging and unselected-plane preservation."""

from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
SOURCES = (
    "sim/tb_tunit_vram_line_cache.sv",
    "sim/models/ddr3_avalon_model.sv",
    "rtl/sdram/stv_vram_ddr_top.sv",
    "rtl/sdram/vram_sdram_top.sv",
    "rtl/sdram/vram_sdram.sv",
    "rtl/sdram/stv_vram_ddr_agent.sv",
)
PASS_MARKER = "PASS tb_tunit_vram_line_cache reads=2 writes=3"


def run(command: list[str], log: Path) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        command, cwd=ROOT, text=True, capture_output=True, check=False
    )
    log.write_text(
        (result.stdout or "") + (result.stderr or ""),
        encoding="utf-8",
        errors="replace",
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--label",
        default="tunit-vram-rdw-" + datetime.now().strftime("%Y%m%d-%H%M%S"),
    )
    args = parser.parse_args()

    out = ROOT / "sim" / "out" / args.label
    if out.exists():
        print(f"ERROR: output already exists: {out}", file=sys.stderr)
        return 2
    out.mkdir(parents=True)
    image = out / "tb.vvp"

    compile_result = run(
        [
            "iverilog",
            "-g2012",
            "-s",
            "tb_tunit_vram_line_cache",
            "-o",
            str(image),
            *SOURCES,
        ],
        out / "compile.log",
    )
    if compile_result.returncode:
        print(f"ERROR: VRAM RDW gate compile failed; see {out / 'compile.log'}")
        return compile_result.returncode

    sim_result = run(["vvp", str(image)], out / "sim.log")
    sim_text = (sim_result.stdout or "") + (sim_result.stderr or "")
    if sim_result.returncode or PASS_MARKER not in sim_text:
        print(f"ERROR: VRAM RDW gate failed; see {out / 'sim.log'}")
        return sim_result.returncode or 1

    print(sim_text.strip())
    print(
        "PASS: CPU VRAM requests survive a forced cache flush and cached "
        f"read/modify/write stores preserve old bytes ({out})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
