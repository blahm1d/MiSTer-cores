// Williams ADPCM board telemetry, 12 MHz sound domain.
//
// WHY.  The cabinet shows FM music absent or lingering on NBA Jam, NBA Jam TE
// and Judge Dredd while OKI samples play fine.  Every hypothesis so far has been
// killed by measurement (ROM transport, jt51 BUSY, 6809 ROM starvation, the
// clock layer, DDR3 attachment), and the board reproduces NBA TE's coin chime
// against MAME's envelope in isolation.  Nothing on this board is observable on
// hardware, so the next step cannot be another theory.
//
// WHAT MAKES A FIELD WORTH A PANEL SLOT.  Each counter below has a MAME 0.289
// golden measured this session, so a cabinet reading is a COMPARISON, not an
// interpretation.  A counter whose value I can already predict earns nothing --
// that is why "audio overrun" and a starvation flag are absent: commands are
// proven to arrive, and the 6809 measures 100% under every injectable latency.
//
//   ym_per_s     NBA TE  ~51,000/s   (2,399,100 YM writes in 47.0 s)
//   firq_per_s   NBA TE   13,236.6   MK 13,133.5.  This is NOT a music tick --
//                at 2 MHz it leaves ~152 cycles and is the streamed-sample clock
//                for the 8-bit DAC (NBA/TE stream one sample per FIRQ from fixed
//                ROM at DC1F-DC35).  A slow FIRQ IS drawn-out audio.
//   dac_per_s    MK ~3,432/s (38,726 writes over 600 frames)
//   oki_writes   NBA TE 2 in 47 s -- samples are rare and autonomous
//   cmd_reads    NBA TE 3 in 47 s -- whole tracks play from ONE command
//   e_rate_cpct  E ticks >> 6; the 2.000 MHz gospel reads 31250
//   romwait_pct  frozen clocks >> 8; healthy is 0, 100% would be 46875
//   resets       sound-board reset EDGES in this one-second window.  This is a
//                delta, not a since-POR total, so successive panel pages can
//                distinguish a boot reset from a reset that repeats at runtime
//
// The window is one second of board time so every rate field is directly
// comparable to the goldens above without arithmetic on the cabinet.
`default_nettype none
module tunit_audio_telemetry #(
  parameter integer CLK_HZ = 12_000_000
)(
  input  wire logic        clk,          // 12 MHz sound clock
  input  wire logic        rst,

  // Board-internal observation points (all already exist on the board).
  input  wire logic        cpu_e_en,     // 6809E tick
  input  wire logic        cpu_rom_wait, // CPU clock frozen waiting on ROM
  input  wire logic        cpu_write,    // one-clock accepted write strobe
  input  wire logic        cpu_rnw,
  input  wire logic [15:0] cpu_addr,
  input  wire logic        io_ym,
  input  wire logic        io_dac,
  input  wire logic        io_oki,
  input  wire logic        io_cmd,
  input  wire logic        board_reset,
  input  wire logic [3:0]  oki_start,    // jt6295 channel launches
  input  wire logic        cmd_overflow, // sound-CDC dropped a host command

  // Latched at each window close, stable for the reader's CDC.
  output logic [15:0]      ym_per_s,
  output logic [15:0]      firq_per_s,
  output logic [15:0]      dac_per_s,
  output logic [15:0]      oki_writes,
  output logic [15:0]      e_rate_cpct,
  output logic [15:0]      romwait_pct,
  output logic [15:0]      cmd_reads,
  output logic [15:0]      misc,         // {reset_delta[7:0], ovf_sticky, 3'b0, oki_start_delta[3:0]}
  output logic             tick          // one clock per window close
);
  localparam integer WINDOW = CLK_HZ;
  // 2.000 MHz gospel is CLK_HZ/6 E ticks per second (williamssound.cpp:52,768);
  // at the >>6 scale below that reads 31250.

  logic [23:0] win;
  // e_c reaches 2,000,000/s and romwait_c can reach 12,000,000/s.  Both were
  // 20 bits (max 1,048,575), so on the cabinet e_rate WRAPPED and read 14,721
  // -- a plausible-looking 47% that actually meant a healthy 99.5%.  Exactly
  // the wrap this module's own comment warns about, applied to ym/firq/dac and
  // not to these two.  24 bits covers both with margin.
  logic [19:0] ym_c, firq_c, dac_c;
  logic [23:0] e_c, romwait_c;
  logic [15:0] oki_c, cmdr_c;
  logic [7:0]  reset_c;
  logic [3:0]  okistart_c;
  logic        ovf_c;
  logic        old_reset;
  logic [3:0]  old_start;

  // Vector fetches identify the interrupt source without a disassembler:
  // fff6 = YM2151 FIRQ, fff8 = host command IRQ (williamssound.cpp:771-772,840).
  wire firq_fetch = cpu_e_en && cpu_rnw && (cpu_addr == 16'hfff6);
  wire cmd_read   = cpu_e_en && cpu_rnw && io_cmd;
  wire reset_edge = board_reset && !old_reset;
  wire oki_start_edge = (oki_start != 4'd0) && (old_start == 4'd0);
  wire ym_event = cpu_write && io_ym;
  wire dac_event = cpu_write && io_dac;
  wire oki_event = cpu_write && io_oki;

  // Include an event that lands on the closing clock in the window being
  // reported.  The previous implementation cleared the counters later in the
  // same always_ff block, so every counter family silently dropped boundary events.
  wire [20:0] ym_window = {1'b0, ym_c} + ym_event;
  wire [20:0] firq_window = {1'b0, firq_c} + firq_fetch;
  wire [20:0] dac_window = {1'b0, dac_c} + dac_event;
  wire [24:0] e_window = {1'b0, e_c} + cpu_e_en;
  wire [24:0] romwait_window = {1'b0, romwait_c} + cpu_rom_wait;
  wire [16:0] oki_window = {1'b0, oki_c} + oki_event;
  wire [16:0] cmdr_window = {1'b0, cmdr_c} + cmd_read;
  wire [8:0] reset_window = {1'b0, reset_c} + reset_edge;
  wire [4:0] okistart_window = {1'b0, okistart_c} + oki_start_edge;

  always_ff @(posedge clk) begin
    if (rst) begin
      win <= 24'd0;
      ym_c <= '0; firq_c <= '0; dac_c <= '0; e_c <= '0; romwait_c <= '0;
      oki_c <= '0; cmdr_c <= '0; reset_c <= '0; okistart_c <= '0; ovf_c <= 1'b0;
      old_reset <= 1'b0; old_start <= 4'd0;
      ym_per_s <= '0; firq_per_s <= '0; dac_per_s <= '0; oki_writes <= '0;
      e_rate_cpct <= '0; romwait_pct <= '0; cmd_reads <= '0; misc <= '0;
      tick <= 1'b0;
    end else begin
      tick <= 1'b0;
      old_reset <= board_reset;
      old_start <= oki_start;

      if (win == WINDOW-1) begin
        win <= 24'd0;
        // Saturate rather than wrap: a wrapped rate reads as a plausible small
        // number and would be indistinguishable from a stalled engine.
        ym_per_s    <= (ym_window   > 21'd65535) ? 16'hffff : ym_window[15:0];
        firq_per_s  <= (firq_window > 21'd65535) ? 16'hffff : firq_window[15:0];
        dac_per_s   <= (dac_window  > 21'd65535) ? 16'hffff : dac_window[15:0];
        oki_writes  <= (oki_window  > 17'd65535) ? 16'hffff : oki_window[15:0];
        cmd_reads   <= (cmdr_window > 17'd65535) ? 16'hffff : cmdr_window[15:0];
        // Shifts, not division.  The first version divided by E_GOSPEL and
        // WINDOW -- non-power-of-two constants -- which synthesised a real
        // divider and cost two DSP blocks for a field nobody reads at runtime.
        // Report scaled raw counts instead and put the scale in the golden:
        //   e_rate  = E ticks >> 6, so the 2.000 MHz gospel reads 31250
        //   romwait = frozen clocks >> 8, so 100% would read 46875 and the
        //             expected healthy value is 0
        e_rate_cpct <= (e_window > 25'd4194303) ? 16'hffff : e_window[21:6];
        romwait_pct <= (romwait_window > 25'd16777215) ? 16'hffff : romwait_window[23:8];
        misc        <= {
          reset_window[8] ? 8'hff : reset_window[7:0],
          ovf_c | cmd_overflow,
          3'b000,
          okistart_window[4] ? 4'hf : okistart_window[3:0]
        };
        tick        <= 1'b1;
        ym_c <= '0; firq_c <= '0; dac_c <= '0; e_c <= '0; romwait_c <= '0;
        oki_c <= '0; cmdr_c <= '0;
        reset_c <= '0; okistart_c <= '0;
        // Command overflow remains sticky by design: one dropped command is a
        // permanent failure even after the one-second event window advances.
        ovf_c <= ovf_c | cmd_overflow;
      end else begin
        win <= win + 1'b1;
        // Saturate the accumulators themselves, not just their published
        // values.  Otherwise a sufficiently busy or faulted source can wrap
        // before window close and be reported as a plausible small rate.
        if (cpu_e_en && e_c != 24'hffffff)
          e_c <= e_c + 1'b1;
        if (cpu_rom_wait && romwait_c != 24'hffffff)
          romwait_c <= romwait_c + 1'b1;
        if (ym_event && ym_c != 20'hfffff)
          ym_c <= ym_c + 1'b1;
        if (dac_event && dac_c != 20'hfffff)
          dac_c <= dac_c + 1'b1;
        if (oki_event && oki_c != 16'hffff)
          oki_c <= oki_c + 1'b1;
        if (firq_fetch && firq_c != 20'hfffff)
          firq_c <= firq_c + 1'b1;
        if (cmd_read && cmdr_c != 16'hffff)
          cmdr_c <= cmdr_c + 1'b1;
        if (reset_edge && reset_c != 8'hff) reset_c <= reset_c + 1'b1;
        if (oki_start_edge && okistart_c != 4'hf)
          okistart_c <= okistart_c + 1'b1;
        if (cmd_overflow) ovf_c <= 1'b1;
      end
    end
  end
endmodule
`default_nettype wire
