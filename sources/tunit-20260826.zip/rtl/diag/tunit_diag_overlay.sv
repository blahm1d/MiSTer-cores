// tunit_diag_overlay.sv -- T-unit cabinet instrument (+define+TUNIT_DIAG).
//
// FORK of the cabinet-proven wolf-crt/rtl/diag/smashtv_diag2_overlay.sv. The
// glyph font, the virtual-coordinate quadrant compositing, and the per-frame
// activity-detect pattern are transcribed from it; the rows and lanes are
// T-unit's. Wolf earned this instrument by hitting a blit_busy wedge on
// silicon (wolf_top.sv:1076-1094) and keeping the readout. T-unit had none,
// which is why "renders then goes black" cost a sim campaign to explain.
//
// The diag paints the top-left QUADRANT and passes the real game through
// everywhere else, so the numbers and the scene are readable in one photo.
//
//   status bar  : GREEN = a page flip published this frame / RED = none
//   (Colour bars and the sweep column were removed 2026-07-30: cosmetic, and
//    this device is at 75% with a framework video cone at its effort floor.)
//   LED strip   : 8 lanes, green = healthy/alive, red = bad/stuck
//                 0 core_rst released   1 sdram_ready     2 pll_locked
//                 3 profile_valid       4 loader idle     5 no illegal opcode
//                 6 vblank toggling     7 PAGE FLIPS PUBLISHING  <-- the crux
//   hex row 1   : DERAIL CAPTURE -- PC before the last region change. Names the
//                 instruction that jumped into blank ROM when the CPU wedges.
//   hex row 2   : DMA ACTIVITY {register-write count, last DMA_COMMAND}. The
//                 cabinet reads dma_busy == 0 on every title: a zero count means
//                 the CPU never writes the DMA block, a nonzero count with
//                 command bit 15 clear means it never asks to go, and bit 15 set
//                 with the blitter idle means the engine ignores the trigger.
//
//   NOTE: this composite is DE-gated, so it blanks with the picture on MK2
//   (which clears DPYCTL.ENV). That is deliberate -- the DE-forcing variant cost
//   more timing than this device has spare. Read row 2 on NBA Jam / TE / Judge
//   Dredd, which keep DE alive and show the same silent blitter.
//   hex row 3   : dbg_commit_count  -- published page flips. MUST climb at the
//                 ~54.7 Hz frame rate. Frozen => the fence is not publishing
//                 and the display is pinned to one framebuffer page.
//   hex row 4   : live CPU PC (~2 Hz) -- CPU liveness.

`default_nettype none
module tunit_diag_overlay
#(
  parameter int H_ACT = 400, V_ACT = 254
)(
  input  wire logic        clk, ce_pix, rst,

  input  wire logic        core_rst,
  input  wire logic [7:0]  reset_reason,
  input  wire logic        cpu_illegal,
  input  wire logic [31:0] cpu_pc,

  // NAMES ARE STALE -- READ tunit_top.sv:345-365 BEFORE TRUSTING THEM.  The
  // 2026-07-30 cabinet reading retired the busy counters (dma_busy read
  // 00000000, so a hold-max was a constant zero) and the two ports were
  // REPURPOSED without being renamed:
  //   dbg_blit_hold_max -> DERAIL CAPTURE: pc_prev latched at a PC region
  //                        change (:357).  NOT a blit duration.
  //   dbg_wr_hold_max   -> DMA ACTIVITY {register-write count, last
  //                        DMA_COMMAND} (:365).  NOT a write-drain duration.
  //   dbg_commit_count  -> genuinely published page flips (:358).
  // Taking these at face value would put two rows on the video page labelled as
  // blit timing that contain neither.
  input  wire logic [31:0] dbg_blit_hold_max,
  input  wire logic [31:0] dbg_wr_hold_max,
  input  wire logic [31:0] dbg_commit_count,

  // AUDIO PAGE (rtl/diag/tunit_audio_telemetry.sv), alternated with the system
  // page every ~3 s so a cabinet test needs no OSD interaction while watching.
  //   row A {ym_per_s, firq_per_s}      goldens NBA TE ~51000 / 13236
  //   row B {dac_per_s, oki_writes}     MK ~3432 / TE 2 in 47 s
  //   row C {e_rate_cpct, romwait_pct}  expect 31250 (2 MHz >> 6) / 0
  //   row D {cmd_reads, misc}           misc = {reset_delta[7:0],ovf_sticky,3'b0,start_delta[3:0]}
  input  wire logic [31:0] audio_tel_a,
  input  wire logic [31:0] audio_tel_b,
  input  wire logic [31:0] audio_tel_c,
  input  wire logic [31:0] audio_tel_d,

  // VIDEO PAGE. video_underrun_count increments on each active-pixel cache
  // miss. The miss-valid bit now suppresses the palette-zero lookup and emits
  // literal RGB black while preserving DE and raster timing. So this is a
  // literal count of black fallback pixels, one per missed pixel, and remains
  // the direct instrument for
  // three cabinet reports -- NBA's alternate rows missing WHILE DRAWING, MK2's
  // sky going black after the coin-up flash, and unsmooth scaling -- all of
  // which are "black appears transiently under heavy blitting".
  //
  // It has existed and been computed all along, and is already routed to the
  // emu top; it was simply never given a panel slot, so the cabinet could never
  // report it.  EXPECTED HEALTHY VALUE IS 0 and it is a running total, so any
  // non-zero reading is real and a climbing one localises the fault to scanout
  // starvation rather than to the blitter or the palette.
  input  wire logic [31:0] video_underrun_count,

  // BLIT-QUEUE HEALTH: {q_overflow, 15'b0, q_drops[15:0]}.
  // midway_dma's normal queue does NOT back-pressure -- a trigger arriving while
  // it is full is DROPPED (midway_dma.sv:770-772) and the flag was left
  // UNCONNECTED in tunit_memsys for the life of the core. On 2026-08-10 that cost
  // a cabinet round trip: moving the gfx ROM to a port shared with main RAM
  // starved the blitter, blits were silently lost, and NBA Jam showed missing
  // players and a shadow popping in and out. This panel field turns that entire
  // diagnosis into one reading.
  // EXPECTED HEALTHY VALUE IS 00000000. Any non-zero top nibble means blits were
  // dropped; the low half is HOW MANY, which separates a single drop at a mode
  // change from a starving blitter.
  input  wire logic [31:0] dbg_blitq,

  // PAGE PUBLICATION: {mismatch-at-active frames[15:0], 12'b0,
  // render_busy, commit_pulse, wanted_page, active_page}. The counter advances
  // only if blank has ended and the fence still exposes the wrong page.
  input  wire logic [31:0] dbg_page_state,

  // live game raster passthrough
  input  wire logic [7:0]  g_r, g_g, g_b,
  input  wire logic        g_hs, g_vs, g_hb, g_vb, g_de,

  output logic [7:0]       vid_r, vid_g, vid_b,
  output logic             hsync, vsync, hblank, vblank, de
);
  function automatic logic [14:0] glyph(input logic [3:0] v);
    case (v)
      4'h0: glyph=15'b111_101_101_101_111;  4'h1: glyph=15'b010_110_010_010_111;
      4'h2: glyph=15'b111_001_111_100_111;  4'h3: glyph=15'b111_001_111_001_111;
      4'h4: glyph=15'b101_101_111_001_001;  4'h5: glyph=15'b111_100_111_001_111;
      4'h6: glyph=15'b111_100_111_101_111;  4'h7: glyph=15'b111_001_001_010_010;
      4'h8: glyph=15'b111_101_111_101_111;  4'h9: glyph=15'b111_101_111_001_111;
      4'hA: glyph=15'b111_101_111_101_101;  4'hB: glyph=15'b110_101_110_101_110;
      4'hC: glyph=15'b111_100_100_100_111;  4'hD: glyph=15'b110_101_101_101_110;
      4'hE: glyph=15'b111_100_111_100_111;  default: glyph=15'b111_100_111_100_100; // F
    endcase
  endfunction

  function automatic logic fpix(input logic [3:0] d, input logic [2:0] col,
                                input logic [2:0] row);
    logic [14:0] g; logic [2:0] rb; g=glyph(d);
    case (row) 3'd0:rb=g[14:12]; 3'd1:rb=g[11:9]; 3'd2:rb=g[8:6]; 3'd3:rb=g[5:3];
               default:rb=g[2:0]; endcase
    fpix = (col==3'd0)?rb[2] : (col==3'd1)?rb[1] : (col==3'd2)?rb[0] : 1'b0;
  endfunction

  // Track the GAME's active raster from its de/vblank, then render in virtual
  // full-frame coordinates hc=gx<<1, vc=gy<<1 so the layout lands in the
  // top-left quadrant and the game shows everywhere else.
  logic [11:0] gx, gy; logic de_q, vb_q; logic [23:0] frame;
  logic [31:0] pc_q, pc_qq, pc_show;
  always_ff @(posedge clk) begin
    if (rst) begin
      gx<=0; gy<=0; de_q<=0; vb_q<=0; frame<=0; pc_q<=0; pc_qq<=0; pc_show<=0;
    end else if (ce_pix) begin
      de_q<=g_de; vb_q<=g_vb; pc_q<=cpu_pc; pc_qq<=pc_q;
      if (g_vb && !vb_q) begin
        gy<=12'd0; gx<=12'd0; frame<=frame+24'd1;
        if (frame[4:0]==5'd0) pc_show<=pc_qq;
      end
      else if (g_de) gx<=gx+12'd1;
      else if (de_q && !g_de) begin gx<=12'd0; gy<=gy+12'd1; end
    end
  end
  wire [11:0] hc = gx << 1;
  wire [11:0] vc = gy << 1;
  wire s0_de = (hc<H_ACT) && (vc<V_ACT);

  wire frame_tick = ce_pix && g_vb && !vb_q;

  // Per-frame activity detect: a lane is green only if the signal was seen BOTH
  // high and low inside one frame. A stuck signal stays red.
  logic a1_vb, a0_vb, alive_vb, illegal_sticky;
  // Page-flip liveness is derived from the commit counter advancing, so no
  // extra pulse has to be routed up from the video subsystem.
  logic [31:0] commit_seen;
  logic        alive_commit, commit_moved;
  always_ff @(posedge clk) begin
    if (rst) begin
      a1_vb<=0; a0_vb<=0; alive_vb<=0; illegal_sticky<=0;
      commit_seen<=32'd0; alive_commit<=0; commit_moved<=0;
    end else begin
      if (cpu_illegal) illegal_sticky<=1'b1;
      if (g_vb) a1_vb<=1'b1; else a0_vb<=1'b1;
      if (dbg_commit_count != commit_seen) commit_moved<=1'b1;
      if (frame_tick) begin
        alive_vb<=a1_vb&a0_vb; a1_vb<=1'b0; a0_vb<=1'b0;
        alive_commit<=commit_moved; commit_moved<=1'b0;
        commit_seen<=dbg_commit_count;
      end
    end
  end

  // LED strip geometry is power-of-two so lane select and offset are wire
  // slices, not a compare chain plus a multiply. 8 lanes x 32 px = hc 0..255.
  wire in_leds = (vc>=12'd44) && (vc<12'd52) && (hc < 12'd256);
  wire [2:0]  led_lane = hc[7:5];
  wire [4:0]  led_x    = hc[4:0];
  wire led_body = (led_x>=5'd2) && (led_x<5'd30);
  logic led_good;
  // reset_reason = {0, !profile_build_ok, rst_pon, !profile_valid,
  //                 !sdram_ready, !pll_locked, loader_or_backend_busy, rst_game}
  always_comb case (led_lane)
    3'd0: led_good = ~core_rst;
    3'd1: led_good = ~reset_reason[3];   // sdram_ready
    3'd2: led_good = ~reset_reason[2];   // pll_locked
    3'd3: led_good = ~reset_reason[4];   // profile_valid
    3'd4: led_good = ~reset_reason[1];   // loader/backend idle
    3'd5: led_good = ~illegal_sticky;
    3'd6: led_good =  alive_vb;
    default: led_good = alive_commit;    // lane 7: page flips are publishing
  endcase

  // This cabinet diagnostic has no usable page control.  Pin it to the video
  // page so the television-zoom fault can be observed without waiting for (or
  // photographing) the 160-frame page alternator.  The fixed magenta colour is
  // therefore also an unambiguous build/ABI marker.
  localparam logic [1:0] page_id = 2'd2;
  wire audio_page = (page_id == 2'd1);
  wire video_page = (page_id == 2'd2);

  logic [31:0] rowval; logic in_hex; logic [11:0] ry0;
  always_comb begin
    in_hex=1'b0; rowval=32'd0; ry0=12'd0;
    if      (vc>=12'd52  && vc<12'd96 ) begin in_hex=1'b1; ry0=12'd52;
      rowval = video_page ? video_underrun_count :
               audio_page ? audio_tel_a : dbg_blit_hold_max; end
    else if (vc>=12'd100 && vc<12'd144) begin in_hex=1'b1; ry0=12'd100;
      // Publication state. Bit 4 is the sticky SRT/DMA ordering-overlap witness;
      // upper 16 counts misses and the original low live flags remain in place.
      // This preserves ticket 8's ABI while adding a causal behavior witness.
      rowval = video_page ? dbg_page_state :
               audio_page ? audio_tel_b : dbg_wr_hold_max;   end
    else if (vc>=12'd148 && vc<12'd192) begin in_hex=1'b1; ry0=12'd148;
      // DMA activity {register-write count, last DMA_COMMAND} -- despite the
      // port name.  Shows whether the blitter is actually working while row A
      // is counting black pixels.
      rowval = video_page ? dbg_wr_hold_max :
               audio_page ? audio_tel_c : dbg_commit_count;  end
    else if (vc>=12'd200 && vc<12'd244) begin in_hex=1'b1; ry0=12'd200;
      // Blit-queue health outranks the live PC here: dropped blits are the one
      // video fault that is otherwise completely invisible.
      rowval = video_page ? dbg_blitq :
               audio_page ? audio_tel_d : pc_show;           end
  end
  localparam int PX0=72;
  wire        hxin  = (hc>=PX0) && (hc<PX0+256);
  wire [7:0]  hrx   = hc - PX0[11:0];
  wire [2:0]  hdig  = hrx[7:5];
  wire [1:0]  hfcol = hrx[4:3];
  wire [11:0] hry12 = vc - ry0;
  wire [2:0]  hfrow = hry12[5:3];
  // Explicit 8:1 nibble select instead of a 32-bit variable shifter.
  logic [3:0] nyb;
  always_comb case (hdig)
    3'd0: nyb = rowval[31:28];  3'd1: nyb = rowval[27:24];
    3'd2: nyb = rowval[23:20];  3'd3: nyb = rowval[19:16];
    3'd4: nyb = rowval[15:12];  3'd5: nyb = rowval[11:8];
    3'd6: nyb = rowval[7:4];    default: nyb = rowval[3:0];
  endcase

  // TIMING (run-5 lesson): the 32-bit barrel shift + glyph decode + final
  // pixel mux in one ce_pix cone pushed the 80 MHz core domain to -0.270 and
  // blocked the build. Pipeline the expensive selects one ce_pix ahead. The
  // registered values go stale for exactly one pixel at cell boundaries; the
  // glyph grid has a blank fourth column, so nothing visible changes.
  logic [3:0] hnyb_q;
  logic       hex_gate_q;
  logic [1:0] hfcol_q;
  logic [2:0] hfrow_q;
  logic       led_pix_q, led_good_q, in_leds_q, in_status_q, in_hex_q;
  logic       quad_q;
  // Registered like every other composite select (the file's rule: the final
  // mux consumes ONLY registered selects).  page_id is a build-time constant,
  // so this costs nothing and keeps the one-ce_pix pipeline shape uniform.
  logic [1:0] page_q;
  always_ff @(posedge clk) if (ce_pix) begin
    page_q     <= page_id;
    hnyb_q     <= nyb;
    hex_gate_q <= in_hex && hxin && (hfcol<2'd3) && (hfrow<3'd5);
    hfcol_q    <= hfcol;
    hfrow_q    <= hfrow;
    in_leds_q  <= (vc>=12'd44) && (vc<12'd52);
    led_pix_q  <= led_body;
    led_good_q <= led_good;
    in_status_q<= (vc>=12'd24) && (vc<12'd44);
    in_hex_q   <= in_hex;
    quad_q     <= s0_de;
  end
  wire hex_on = hex_gate_q && fpix(hnyb_q, {1'b0,hfcol_q}, hfrow_q);

  // Final composite consumes ONLY registered selects (one ce_pix behind the
  // live coordinates; the whole quadrant shifts one pixel, uniformly).
  always_ff @(posedge clk) if (ce_pix) begin
    de<=g_de; hsync<=g_hs; vsync<=g_vs; hblank<=g_hb; vblank<=g_vb;
    if (!g_de)            begin vid_r<=8'd0; vid_g<=8'd0; vid_b<=8'd0; end
    else if (!quad_q)     begin vid_r<=g_r;  vid_g<=g_g;  vid_b<=g_b;  end
    else if (in_status_q) begin
      if (alive_commit) begin vid_r<=8'h00; vid_g<=8'hC0; vid_b<=8'h00; end
      else              begin vid_r<=8'hC0; vid_g<=8'h00; vid_b<=8'h00; end
    end
    else if (in_leds_q) begin
      if (led_pix_q) begin
        if (led_good_q) begin vid_r<=8'h00; vid_g<=8'hE0; vid_b<=8'h00; end
        else            begin vid_r<=8'hE0; vid_g<=8'h00; vid_b<=8'h00; end
      end else          begin vid_r<=8'h00; vid_g<=8'h00; vid_b<=8'h00; end
    end
    else if (in_hex_q) begin
      // PAGE IS ENCODED IN THE DIGIT COLOUR.  The header claimed a marker digit
      // made a photograph unambiguous about which page it caught; no such digit
      // was ever rendered, so with two pages the page had to be inferred from
      // the values, and with three that is no longer possible.  Colour costs no
      // geometry and no extra timing -- it reuses this same registered mux.
      //   YELLOW  = system   CYAN = audio   MAGENTA = video
      if (hex_on) begin
        case (page_q)
          2'd1:    begin vid_r<=8'h00; vid_g<=8'hFF; vid_b<=8'hFF; end  // audio
          2'd2:    begin vid_r<=8'hFF; vid_g<=8'h00; vid_b<=8'hFF; end  // video
          default: begin vid_r<=8'hFF; vid_g<=8'hFF; vid_b<=8'h00; end  // system
        endcase
      end else            begin vid_r<=8'h10; vid_g<=8'h10; vid_b<=8'h30; end
    end
    else                begin vid_r<=8'h08; vid_g<=8'h08; vid_b<=8'h08; end
  end
endmodule
`default_nettype wire
