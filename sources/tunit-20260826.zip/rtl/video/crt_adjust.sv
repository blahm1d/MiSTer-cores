//============================================================================
// CRT Adjust -- core-side analog CRT geometry for MiSTer arcade cores.
//
// Copyright (C) 2026 Umberto Parisi (rmonic79), with Andrea Bogazzi.
// Source: https://github.com/rmonic79/MiSTer-CRT-Adjust
// Upstream blob: 31f7cccff76053c15e40f30fa1663665596bf18a
// License: GNU GPL v3 or later.
//
// This local copy intentionally keeps the upstream core-side architecture:
// native refresh/sync, a ping-pong line buffer, integer-uniform pixel holds,
// and a shared hs_ref_out for the line engine and external read-rate generator.
//============================================================================
`default_nettype none

`ifndef HPOS_SYNCSHIFT
`define HPOS_SYNCSHIFT     0
`define HPOS_CONTENTSHIFT  1
`endif

module crt_adjust #(
    parameter VTOTAL    = 263,
    parameter HTOTAL    = 384,
    parameter HPOS_MODE = `HPOS_CONTENTSHIFT
) (
    input wire               clk,
    input wire               pxl_cen,
    input wire               pxl2_cen,
    input wire               active,
    input wire signed  [4:0] hsize,
    input wire signed  [8:0] hoffset,
    input wire signed  [5:0] voffset,
    input wire         [7:0] r_in,
    input wire         [7:0] g_in,
    input wire         [7:0] b_in,
    input wire               hs_in,
    input wire               vs_in,
    input wire               hb_in,
    input wire               vb_in,
    output reg         [7:0] r_out,
    output reg         [7:0] g_out,
    output reg         [7:0] b_out,
    output reg               hs_out,
    output reg               vs_out,
    output reg               hb_out,
    output reg               vb_out,
    output wire              hs_ref_out
);
    localparam integer AW = 10;

    reg [7:0] r_in_q, g_in_q, b_in_q;
    reg       hs_in_q, hb_in_q, vs_in_q, vb_in_q;
    reg       hs_in_d;
    initial begin
        r_in_q = 0; g_in_q = 0; b_in_q = 0;
        hs_in_q = 0; hb_in_q = 1; vs_in_q = 0; vb_in_q = 0;
        hs_in_d = 0;
    end

    always @(posedge clk) if (pxl_cen) begin
        r_in_q  <= r_in;
        g_in_q  <= g_in;
        b_in_q  <= b_in;
        hs_in_q <= hs_in;
        hb_in_q <= hb_in;
        vs_in_q <= vs_in;
        vb_in_q <= vb_in;
        hs_in_d <= hs_in;
    end

    wire signed [9:0] hshift_tap = hoffset[8]
        ? (10'(HTOTAL) + {{1{hoffset[8]}}, hoffset})
        : {1'd0, hoffset};
    reg [HTOTAL-1:0] hsync_pix_shreg;
    reg              hs_shifted;
    initial begin
        hsync_pix_shreg = 0;
        hs_shifted = 0;
    end
    always @(posedge clk) if (pxl_cen)
        hsync_pix_shreg <= {hsync_pix_shreg[HTOTAL-2:0], hs_in};
    always @(posedge clk) if (pxl_cen)
        hs_shifted <= (hshift_tap == 10'd0)
                    ? hs_in : hsync_pix_shreg[hshift_tap - 10'd1];

    wire hs_read_ref = (HPOS_MODE == `HPOS_SYNCSHIFT)
                     ? hs_shifted : hs_in;
    assign hs_ref_out = hs_read_ref;
    reg hs_ref_d1;
    initial hs_ref_d1 = 0;
    always @(posedge clk) if (pxl_cen) hs_ref_d1 <= hs_read_ref;
    wire hs_rise_in = pxl_cen && hs_read_ref && !hs_ref_d1;

    // The ping-pong schedule is boundary-regressed, but keep Quartus's
    // read-during-write behavior defined instead of waiving collision checks.
    (* ramstyle = "M10K" *)
    reg [23:0] mem [0:(1<<AW)-1];
    integer ii;
    initial for (ii = 0; ii < (1<<AW); ii = ii + 1) mem[ii] = 24'd0;

    reg [AW-1:0] wrp;
    reg [AW-1:0] hmax;
    reg [AW-1:0] hb0, hb1;
    reg          lhb_l;
    reg          bank;
    initial begin
        wrp = 0; hmax = 0;
        hb0 = 0; hb1 = 0;
        lhb_l = 0;
        bank = 0;
    end
    wire lhb = ~hb_in;

    always @(posedge clk) if (pxl_cen) begin
        lhb_l <= lhb;
        mem[{bank, wrp[AW-2:0]}] <= {r_in, g_in, b_in};
        if (hs_rise_in) begin
            wrp  <= {AW{1'b0}};
            hmax <= wrp;
            bank <= ~bank;
        end else begin
            wrp <= wrp + 1'b1;
        end
        if ( lhb && !lhb_l) hb1 <= wrp;
        if (!lhb &&  lhb_l) hb0 <= wrp;
    end

    reg [AW-1:0] rdcnt;
    reg          hs_in_d2;
    reg          hs_rise_pending;
    initial begin
        rdcnt = 0;
        hs_in_d2 = 0;
        hs_rise_pending = 0;
    end
    always @(posedge clk) begin
        hs_in_d2 <= hs_read_ref;
        if (hs_read_ref && !hs_in_d2) hs_rise_pending <= 1'b1;
        else if (pxl2_cen)            hs_rise_pending <= 1'b0;
    end
    always @(posedge clk) if (pxl2_cen) begin
        if (hs_rise_pending) rdcnt <= {AW{1'b0}};
        else                 rdcnt <= rdcnt + 1'b1;
    end

    reg [23:0] rd_data;
    reg        pass_q;
    initial begin
        rd_data = 0;
        pass_q = 0;
    end

    reg vb_line, vb_active;
    initial begin
        vb_line = 0;
        vb_active = 0;
    end
    always @(posedge clk) if (hs_rise_in) begin
        vb_line   <= vb_in;
        vb_active <= vb_line;
    end

    wire signed [AW+1:0] hoff_s =
        (HPOS_MODE == `HPOS_CONTENTSHIFT)
        ? $signed(hoffset) : {(AW+2){1'b0}};
    wire signed [AW+1:0] rdcnt_s = $signed({2'b0, rdcnt});
    wire signed [AW+1:0] hb1_s   = $signed({2'b0, hb1});
    wire signed [AW+1:0] hb0_s   = $signed({2'b0, hb0});
    wire        [AW-1:0] rd_addr = rdcnt_s - hoff_s;
    always @(posedge clk) if (pxl2_cen) begin
        rd_data <= mem[{~bank, rd_addr[AW-2:0]}];
        pass_q  <= (rdcnt_s >= (hb1_s + hoff_s)) &&
                   (rdcnt_s <  (hb0_s + hoff_s)) && !vb_active;
    end

    wire signed [8:0] vshift_tap = voffset[5]
        ? (9'(VTOTAL) + {{3{voffset[5]}}, voffset})
        : {3'd0, voffset};
    reg [VTOTAL-1:0] vsync_line_shreg;
    reg              vs_shifted;
    initial begin
        vsync_line_shreg = 0;
        vs_shifted = 0;
    end
    always @(posedge clk) if (hs_rise_in)
        vsync_line_shreg <= {vsync_line_shreg[VTOTAL-2:0], vs_in};
    always @(posedge clk) if (hs_rise_in)
        vs_shifted <= (vshift_tap == 9'd0)
                    ? vs_in : vsync_line_shreg[vshift_tap - 9'd1];

    wire hs_pos_out = (HPOS_MODE == `HPOS_SYNCSHIFT)
                    ? hs_shifted : hs_in_q;
    wire bypass = ~active;

    initial begin
        r_out = 0; g_out = 0; b_out = 0;
        hs_out = 0; vs_out = 0; hb_out = 1; vb_out = 0;
    end
    always @(posedge clk) begin
        if (bypass) begin
            if (pxl_cen) begin
                r_out  <= r_in_q;
                g_out  <= g_in_q;
                b_out  <= b_in_q;
                hb_out <= hb_in_q;
                hs_out <= hs_in_q;
                vs_out <= vs_in_q;
                vb_out <= vb_in_q;
            end
        end else if (pxl2_cen) begin
            if (pass_q) begin
                r_out <= rd_data[23:16];
                g_out <= rd_data[15:8];
                b_out <= rd_data[7:0];
            end else begin
                r_out <= 8'd0;
                g_out <= 8'd0;
                b_out <= 8'd0;
            end
            hb_out <= ~pass_q;
            hs_out <= hs_pos_out;
            vs_out <= vs_shifted;
            vb_out <= vb_in_q;
        end
    end
endmodule

`default_nettype wire
