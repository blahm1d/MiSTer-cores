// Four-way grant-held T-unit SDRAM arbiter.
//
// PARTITION REBALANCE (docs/PARTITION-REBALANCE-PLAN.md, 2026-08-10): gfx ROM and
// sound ROM move here from DDR3, leaving DDR3 carrying VRAM alone.  T-unit was the
// outlier of the three sibling cores -- it stacked two cold cacheable streams on top
// of hard-real-time scanout while this private chip ran one cacheable stream.
// Y-unit's qualified split is the mirror of that, and this converges on it.
//
// PRIORITY, and the reasoning per client rather than a guessed order:
//
//   SOUND  first, despite being by far the smallest consumer.  jt6295_rom.v:57-79
//          latches the ADPCM byte WITHOUT consulting rom_ok, one cen32 slot after
//          presenting the address: a late response is not waited for, it is
//          silently the PREVIOUS byte.  That is a hard ~4.1 us deadline whose
//          violation is inaudible-as-a-fault and audible-as-corruption.  It asks
//          for one word roughly every 133 us, so giving it the top slot costs the
//          other clients essentially nothing.
//   PROG   second.  Instruction fetch stalls the CPU; it is latency-critical and
//          already filtered by a 64-line x 8-word cache.
//   RAM    third.  CPU data, same argument, lower rate.
//   GFX    last.  The bulk consumer (~24 MB/s at MAME's 41 ns/pixel blit model) but
//          the most latency-tolerant: it is a throughput stream behind an 8-byte
//          line cache, and delaying it slows the blitter rather than corrupting it.
//
// The GAP state after every grant is inherited from the two-way version and kept
// deliberately: it gives the adapter an inter-command bubble, the same contract
// vram_sdram_top proved.  Do not remove it to buy throughput without measuring.
`default_nettype none
module tunit_sdram_arb #(
  parameter int SD_AW=25,
  parameter logic [SD_AW-1:0] PROGRAM_BASE=25'h000000,
  parameter logic [SD_AW-1:0] RAM_BASE=25'h080000,
  // Word bases.  gfx is the largest region (MK2 is 12 MB = 0x600000 words) and the
  // sound ROM follows it.  Both are above RAM_BASE and sized from
  // tunit_profile_layout.sv's worst case; see the plan document's capacity gate.
  parameter logic [SD_AW-1:0] GFX_BASE=25'h100000,
  parameter logic [SD_AW-1:0] SOUND_BASE=25'h700000
)(
  input  wire logic clk,
  input  wire logic rst,

  input  wire logic [19:0] p_addr,
  input  wire logic [15:0] p_din,
  input  wire logic [1:0]  p_be,
  input  wire logic p_rd,p_wr,
  output logic [15:0] p_dout,
  output logic p_ack,

  input  wire logic [24:0] r_addr,
  input  wire logic [15:0] r_din,
  input  wire logic [1:0]  r_be,
  input  wire logic r_rd,r_wr,
  output logic [15:0] r_dout,
  output logic r_ack,

  // gfx ROM word channel (read-only in play; the loader writes through r_*/boot)
  input  wire logic [23:0] g_addr,          // WORD index into the gfx region
  input  wire logic [15:0] g_din,
  input  wire logic [1:0]  g_be,
  input  wire logic g_rd,g_wr,
  output logic [15:0] g_dout,
  output logic g_ack,

  // sound ROM word channel
  input  wire logic [23:0] s_addr,          // WORD index into the sound region
  input  wire logic [15:0] s_din,
  input  wire logic [1:0]  s_be,
  input  wire logic s_rd,s_wr,
  output logic [15:0] s_dout,
  output logic s_ack,

  output logic [SD_AW-1:0] sd_addr,
  output logic [15:0] sd_din,
  output logic [1:0] sd_be,
  output logic sd_rd,sd_wr,
  input  wire logic [15:0] sd_dout,
  input  wire logic sd_ack
);
  typedef enum logic [2:0] {G_NONE,G_PROG,G_RAM,G_GFX,G_SND,G_GAP} grant_t;
  grant_t grant;
  wire logic p_req=p_rd||p_wr;
  wire logic r_req=r_rd||r_wr;
  wire logic g_req=g_rd||g_wr;
  wire logic s_req=s_rd||s_wr;

  always_ff @(posedge clk) begin
    if(rst) grant<=G_NONE;
    else case(grant)
`ifdef MUT_ARB_SND_LAST
      // Named causal mutant: demote sound to lowest priority. Must be killed by
      // the sound-vs-prog case, which is the whole justification for its slot.
      G_NONE: if(p_req)grant<=G_PROG;
              else if(r_req)grant<=G_RAM;
              else if(g_req)grant<=G_GFX;
              else if(s_req)grant<=G_SND;
`else
      G_NONE: if(s_req)grant<=G_SND;
              else if(p_req)grant<=G_PROG;
              else if(r_req)grant<=G_RAM;
              else if(g_req)grant<=G_GFX;
`endif
      G_PROG: if(sd_ack)grant<=G_GAP;
      G_RAM:  if(sd_ack)grant<=G_GAP;
      G_GFX:  if(sd_ack)grant<=G_GAP;
      G_SND:  if(sd_ack)grant<=G_GAP;
      G_GAP: grant<=G_NONE;
      default: grant<=G_NONE;
    endcase
  end

  always_comb begin
    sd_addr='0;sd_din=16'd0;sd_be=2'b00;sd_rd=1'b0;sd_wr=1'b0;
    p_ack=1'b0;r_ack=1'b0;g_ack=1'b0;s_ack=1'b0;
    p_dout=sd_dout;r_dout=sd_dout;g_dout=sd_dout;s_dout=sd_dout;
    case(grant)
      G_PROG: begin
        sd_addr=PROGRAM_BASE+SD_AW'(p_addr);sd_din=p_din;sd_be=p_be;sd_rd=p_rd;sd_wr=p_wr;p_ack=sd_ack;
      end
      G_RAM: begin
        sd_addr=RAM_BASE+r_addr;sd_din=r_din;sd_be=r_be;sd_rd=r_rd;sd_wr=r_wr;r_ack=sd_ack;
      end
      G_GFX: begin
        sd_addr=GFX_BASE+SD_AW'(g_addr);sd_din=g_din;sd_be=g_be;sd_rd=g_rd;sd_wr=g_wr;g_ack=sd_ack;
      end
      G_SND: begin
        sd_addr=SOUND_BASE+SD_AW'(s_addr);sd_din=s_din;sd_be=s_be;sd_rd=s_rd;sd_wr=s_wr;s_ack=sd_ack;
      end
      default: ;
    endcase
  end
endmodule
`default_nettype wire
