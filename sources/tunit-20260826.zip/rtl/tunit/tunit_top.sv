// Midway T-unit board core, profile 1 (MK2/DCS2K) pre-Quartus integration.

`default_nettype none
module tunit_top
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
(
  input  wire logic clk,
  // 12 MHz Williams ADPCM board domain (PLL outclk_2). Crossed to this 80 MHz
  // domain only through explicit command, ROM, reset/profile, and audio CDCs.
  input  wire logic clk_snd,
  input  wire logic rst_pon,
  input  wire logic rst_game,
  input  wire logic pll_locked,
  input  wire logic sdram_ready,
  input  wire tunit_profile_t profile,
  input  wire tunit_variant_t variant,
  input  wire logic profile_valid,
  input  wire logic loader_busy,
  input  wire logic loader_rst_sound,

  input  wire logic [15:0] in0,input wire logic[15:0]in1,
  input  wire logic [15:0] in2,input wire logic[15:0]dsw,

  input  wire logic prog_wr,input wire logic[18:0]prog_addr,
  input  wire logic[15:0]prog_wdata,input wire logic[1:0]prog_be,output logic prog_ready,
  input  wire logic gfx_wr,input wire logic[23:0]gfx_addr,input wire logic[7:0]gfx_wdata,output logic gfx_ready,
  input  wire logic snd_wr,input wire logic[23:0]snd_addr,input wire logic[7:0]snd_wdata,output logic snd_ready,

  input  wire logic nvram_ext_wr,input wire logic[13:0]nvram_ext_addr,
  input  wire logic[7:0]nvram_ext_wdata,output logic[7:0]nvram_ext_rdata,
  output logic nvram_write_pulse,

  output logic [24:0] sdram_addr,output logic[15:0]sdram_din,output logic[1:0]sdram_be,
  output logic sdram_rd,sdram_wr,input wire logic[15:0]sdram_dout,input wire logic sdram_ack,

  output logic [28:0] ddram_addr,output logic[7:0]ddram_burstcnt,
  output logic ddram_rd,ddram_we,output logic[63:0]ddram_din,output logic[7:0]ddram_be,
  input  wire logic ddram_busy,input wire logic[63:0]ddram_dout,input wire logic ddram_dout_ready,

  output logic[7:0]vid_r,vid_g,vid_b,output logic hsync,vsync,hblank,vblank,de,
  output logic ce_pixel_o,
  output logic signed[15:0]audio,output logic audio_ce,

  output logic[31:0]cpu_pc,output logic cpu_illegal,output logic[7:0]reset_reason,
  output logic rst_cpu_o,output logic dma_busy,output logic loader_or_backend_busy,
  output logic video_underrun,output logic[31:0]video_underrun_count,
  output logic audio_underrun,output logic audio_overrun,
  output logic[31:0]audio_tel_a,audio_tel_b,audio_tel_c,audio_tel_d,
  output logic[13:0]adsp_pc,output logic adsp_valid,output logic adsp_unimplemented,
  // TUNIT-P0035 -- Wolf's busy-wedge instrument (wolf_top.sv:1076-1094). Ports
  // exist unconditionally so the hierarchy does not change between diag and
  // production builds; the counters themselves are `TUNIT_DIAG-only.
  output logic[31:0]dbg_blit_hold_max,output logic[31:0]dbg_wr_hold_max,
  output logic[31:0]dbg_commit_count,
  // {q_overflow, 15'b0, q_drops[15:0]} -- blit-queue health, see tunit_memsys
  output logic[31:0]dbg_blitq,
  // {missed-publication frames[15:0], 11'b0, SRT/DMA overlap, render_busy,
  //  commit, wanted_page, active_page}. Diagnostic-only; zero in production.
  output logic[31:0]dbg_page_state
);
  wire logic sdram_por=rst_pon||!pll_locked;

  // 80 MHz system-domain enables: exact 8 MHz pixels, average-exact 31.25 MHz
  // TMS state cadence, and 31.25 kHz DCS DAC service. Five ordinary RTL
  // state advances are one 160 ns TMS execution cycle; instruction-specific
  // delay states account for additional documented cycles.
  logic[3:0]pix_div;logic ce_pix;
  logic[8:0]cpu_acc;logic ce_cpu,ce_cpu_legacy;logic[9:0]cpu_sum;
  logic[26:0]dac_acc;logic dac_ce;
`ifdef TUNIT_CPU_MICRO_80MHZ
  assign cpu_sum={1'b0,cpu_acc}+10'd320;
`elsif TUNIT_CPU_MICRO_40MHZ
  // Diagnostic mutation for the architectural-cadence experiment.  This is
  // deliberately not a shipping speed control: an exact MAME-cycle retirement
  // scheduler must bound the faster microengine before this can be enabled in
  // production.
  assign cpu_sum={1'b0,cpu_acc}+10'd160;
`else
  assign cpu_sum={1'b0,cpu_acc}+10'd125;
`endif
  assign ce_pixel_o=ce_pix;
  always_ff @(posedge clk)begin
    if(sdram_por)begin pix_div<=0;ce_pix<=0;cpu_acc<=0;ce_cpu_legacy<=0;dac_acc<=0;dac_ce<=0;end
    else begin
      // 80 MHz fabric (was 96). Every EMULATED rate stays EXACT -- this is an
      // implementation choice, not a fidelity change:
      //   pixel : 80/10      = 8 MHz      exact  (was 96/12 = 8 MHz)
      //   CPU   : 125/320*80 = 31.25 MHz  exact  (was 125/384*96 = 31.25 MHz)
      // 80 MHz is one of only a couple of frequencies where BOTH land exactly (88 MHz
      // also works via 125/352 and /11, but buys only +0.94 ns of period).
      ce_pix<=(pix_div==4'd9);pix_div<=(pix_div==4'd9)?0:pix_div+1'b1;
      if(cpu_sum>=10'd320)begin cpu_acc<=cpu_sum-10'd320;ce_cpu_legacy<=1;end
      else begin cpu_acc<=cpu_sum[8:0];ce_cpu_legacy<=0;end
      if(dac_acc+27'd31250>=27'd80000000)begin dac_acc<=dac_acc+27'd31250-27'd80000000;dac_ce<=1;end
      else begin dac_acc<=dac_acc+27'd31250;dac_ce<=0;end
    end
  end

  logic gfx_dl_ack,gfx_dl_busy,snd_dl_ack,snd_dl_busy,prog_busy,prog_dl_busy;
  assign gfx_ready=gfx_dl_ack;
  assign snd_ready=snd_dl_ack;
  assign loader_or_backend_busy=loader_busy||prog_dl_busy||gfx_dl_busy||snd_dl_busy;
  // Register the board reset in the system domain.  The download engines and
  // readiness inputs are synchronous here; keeping their decode out of every
  // core register's reset/enable cone removes a very high-fanout timing path.
  // Power-on reset remains an immediate assertion, while all other causes gain
  // one harmless clock of assertion/deassertion latency.
  // TUNIT-P0031 — register the quasi-static profile at this boundary.
  //
  // MEASURED binding constraint. The worst setup path in the last fit was
  //   tunit_loader:loader|profile[0]~DUPLICATE -> tunit_mem:mapped|mem_rdata[24]
  //   Relationship 10.416 (ONE clock, no exception), Data Delay 11.479,
  //   Slack -1.922
  // with mem_rdata[20]/[18]/[16]/[22] behind it. `profile` is the game selector:
  // written at reset (tunit_loader.sv:305,345) and once at descriptor parse
  // (:493), then static for the whole session -- yet it fanned out combinationally
  // into the memory system and was timed at a full clock. The fitter had already
  // replicated it (~DUPLICATE) trying to solve this itself.
  //
  // The alternative was an SDC exception justified by "consumers are held in
  // reset while it changes". That is true today, but it is an invariant a future
  // fourth assignment site could silently invalidate, and defending it needs a
  // non-vacuous monitor kept alive forever. A register removes the invariant
  // instead of documenting it: the cone ends at a flop, there is no exception to
  // justify and nothing left to regress.
  //
  // profile_valid is registered ALONGSIDE it deliberately. It gates rst_cpu_o
  // below, so delaying both by the same cycle guarantees the registered profile
  // is settled BEFORE consumers can leave reset. Registering the data alone
  // would open a one-cycle window where reset released against a stale copy.
  // Cost: one clock of latency on a value that is stable for the entire run,
  // during a window when every consumer is already held in reset.
  tunit_profile_t profile_q;
  tunit_variant_t variant_q;
  logic           profile_valid_q;
  always_ff @(posedge clk or posedge rst_pon) begin
    if(rst_pon) begin
      profile_q       <= tunit_profile_t'('0);
      variant_q       <= VARIANT_STANDARD;
      profile_valid_q <= 1'b0;
    end else begin
      profile_q       <= profile;
      variant_q       <= variant;
      profile_valid_q <= profile_valid;
    end
  end

  // A split image must never run a descriptor for the sound engine that was
  // compiled out. Universal simulation builds accept either family.
  logic profile_build_ok;
`ifdef TUNIT_NO_DCS
`ifdef TUNIT_NO_ADPCM
  assign profile_build_ok = 1'b0;
`else
  assign profile_build_ok = profile_q != PROFILE_MK2;
`endif
`else
`ifdef TUNIT_NO_ADPCM
  assign profile_build_ok = profile_q == PROFILE_MK2;
`else
  assign profile_build_ok = 1'b1;
`endif
`endif
  assign reset_reason={1'b0,!profile_build_ok,rst_pon,!profile_valid,
                       !sdram_ready,!pll_locked,loader_or_backend_busy,rst_game};

  always_ff @(posedge clk or posedge rst_pon) begin
    if(rst_pon) rst_cpu_o<=1'b1;
    else rst_cpu_o<=rst_game||loader_or_backend_busy||
                    !pll_locked||!sdram_ready||!profile_valid_q||
                    !profile_build_ok;
  end

  // ---- CPU + exact T-unit memory system ----------------------------------
  logic cpu_req,cpu_we,cpu_srt,cpu_ack;logic[31:0]cpu_addr,cpu_wdata,cpu_rdata;logic[5:0]cpu_size;
  logic[15:0]dpystrt,dpyctl,dpytap,dpyadr,display_row_full,display_col_full;
  logic[1:0]display_yoffset;logic display_enable,tms_vblank_start,timing_start,tms_ce;
  logic display_blank; // TUNIT-P0048: live HEBLNK >= HSBLNK
  logic lint1;
  logic cpu_instr_start,cpu_instr_retire;
  logic[15:0]cpu_instr_cycles;
  logic[6:0]cpu_instr_class_dbg;
  logic cpu_instr_cycles_valid,cpu_cadence_stall,cpu_cadence_overrun;
  logic cpu_cadence_overrun_pulse;
  logic cpu_cycle_budget_invalid;
`ifndef MUT_TUNIT_CPU_LEGACY_SCHED
  tunit_cpu_cycle_scheduler u_cpu_scheduler(
    .clk,.rst(rst_cpu_o),.instr_start(cpu_instr_start),
    .instr_retire(cpu_instr_retire),
    .instr_cycles(cpu_instr_cycles_valid?cpu_instr_cycles:16'd1),
    .ce_cpu,.cadence_stall(cpu_cadence_stall),
    .cadence_overrun_pulse(cpu_cadence_overrun_pulse),
    .cadence_overrun(cpu_cadence_overrun));
  always_ff @(posedge clk)begin
    if(rst_cpu_o)cpu_cycle_budget_invalid<=1'b0;
    else if(cpu_instr_retire&&!cpu_instr_cycles_valid)
      cpu_cycle_budget_invalid<=1'b1;
  end
`else
  assign ce_cpu=ce_cpu_legacy;
  assign cpu_cadence_stall=1'b0;
  assign cpu_cadence_overrun=1'b0;
  assign cpu_cadence_overrun_pulse=1'b0;
  always_ff @(posedge clk)cpu_cycle_budget_invalid<=1'b0;
`endif
  tms34010_core cpu(
    .clk,.ce_cpu,.ce_pix(tms_ce),.rst(rst_cpu_o),
    .mem_req(cpu_req),.mem_we(cpu_we),.mem_addr(cpu_addr),.mem_size(cpu_size),.mem_wdata(cpu_wdata),
    .mem_srt(cpu_srt),
    .mem_rdata(cpu_rdata),.mem_ack(cpu_ack),.state_o(),.pc_o(cpu_pc),.instr_word_o(),
    .illegal_opcode_o(cpu_illegal),
    .instruction_start_o(cpu_instr_start),.instruction_retire_o(cpu_instr_retire),
    .instruction_cycles_o(cpu_instr_cycles),.instruction_cycles_valid_o(cpu_instr_cycles_valid),
    .instruction_class_o(cpu_instr_class_dbg),
    .dpystrt_o(dpystrt),.dpyctl_o(dpyctl),.dpytap_o(dpytap),
    .dpyadr_o(dpyadr),.display_row_o(display_row_full),.display_col_o(display_col_full),
    .display_yoffset_o(display_yoffset),.display_enable_o(display_enable),
    .display_blank_o(display_blank),
    .vblank_start_o(tms_vblank_start),.timing_start_o(timing_start),.lint1_in(lint1));

  logic store_req,store_we,store_srt,store_ack; tunit_map_target_t store_target;
  logic[27:0]store_word_addr;logic[3:0]store_boff;logic[5:0]store_size;
  logic[31:0]store_wdata,store_rdata;
  logic rom_req,rom_is_gfx,rom_ack;logic[23:0]rom_byte_addr;logic[47:0]rom_line;
  logic dcs_status_rd,dcs_data_rd,dcs_data_wr,dcs_data_offset;logic[15:0]dcs_wdata,dcs_status_rdata,dcs_data_rdata;logic[1:0]dcs_be;
  logic dma_src_req,dma_src_ack,dma_src_active,dma_src_stream;
  logic dma_fb_we,dma_fb_ack,dma_wr_busy;logic[31:0]dma_src_addr;logic[7:0]dma_src_data;
  logic[18:0]dma_fb_addr;logic[15:0]dma_fb_wdata,dma_palette;
  logic video_bank;logic[23:0]gfx_bank_offset;logic[15:0]control_word;
  logic[31:0]dbg_dma_activity_w;   // declared before the instance that drives it
  logic dbg_srt_dma_overlap_w;
  logic memsys_q_overflow; logic[15:0]memsys_q_drops;
  assign dbg_blitq = {memsys_q_overflow, 15'd0, memsys_q_drops};
  tunit_memsys memsys(
    .dbg_q_overflow(memsys_q_overflow),.dbg_q_drops(memsys_q_drops),
    .clk,.rst(rst_cpu_o),.ce_cpu,.profile(profile_q),.variant(variant_q),
    // MAME leaves m_gfx_rom_large clear for every T-unit title except MK2
    // (midtunit.cpp:656). Small-ROM games normalize 0x02xxxxxx source offsets.
    .gfx_rom_large(profile_q == PROFILE_MK2),
    .mem_req(cpu_req),.mem_we(cpu_we),.mem_addr(cpu_addr),.mem_size(cpu_size),.mem_srt(cpu_srt),
    .mem_wdata(cpu_wdata),.mem_rdata(cpu_rdata),.mem_ack(cpu_ack),.in0,.in1,.in2,.dsw,
    .store_req,.store_we,.store_srt,.store_target,.store_word_addr,.store_bit_offset(store_boff),.store_size,
    .store_wdata,.store_rdata,.store_ack,.rom_req,.rom_is_gfx,.rom_byte_addr,.rom_line,.rom_ack,
    .dcs_status_rd,.dcs_data_rd,.dcs_data_wr,.dcs_data_offset,.dcs_wdata,.dcs_byte_en(dcs_be),
    .dcs_status_rdata,.dcs_data_rdata,.dma_src_req,.dma_src_addr,
    .dma_src_active,.dma_src_stream,.dma_src_data,.dma_src_ack,
    .dma_fb_we,.dma_fb_addr,.dma_fb_wdata,.dma_fb_ack,.dma_wr_busy,.dma_busy,
    .dbg_dma_activity(dbg_dma_activity_w),
    .dbg_srt_dma_overlap(dbg_srt_dma_overlap_w),.lint1,.dma_palette,
    .video_bank,.gfx_bank_offset,.control_word,.cmos_write_enable(),.watchdog_kick(),.last_target());

  // ---- program ROM + main RAM in SDRAM -----------------------------------
  logic prog_line_ack,prog_sd_rd,prog_sd_wr,prog_sd_ack;logic[47:0]prog_line;
  logic[19:0]prog_sd_addr;logic[15:0]prog_sd_din,prog_sd_dout;logic[1:0]prog_sd_be;
  tunit_prog_sdram program_rom(
    .clk,.rst(sdram_por),.line_req(rom_req&&!rom_is_gfx),.line_byte_addr(rom_byte_addr),
    .line_data(prog_line),.line_ack(prog_line_ack),.dl_wr(prog_wr),.dl_word_addr(prog_addr),
    .dl_wdata(prog_wdata),.dl_be(prog_be),.dl_ready(prog_ready),.busy(prog_busy),.dl_busy(prog_dl_busy),
    .sd_addr(prog_sd_addr),.sd_din(prog_sd_din),.sd_be(prog_sd_be),.sd_rd(prog_sd_rd),.sd_wr(prog_sd_wr),
    .sd_dout(prog_sd_dout),.sd_ack(prog_sd_ack));
  logic ram_start,ram_we;logic[27:0]ram_widx;logic[3:0]ram_boff;logic[5:0]ram_size;logic[31:0]ram_wdata,ram_rdata;
  logic ram_done,ram_active,ram_sd_rd,ram_sd_wr,ram_sd_ack;logic[24:0]ram_sd_addr;logic[15:0]ram_sd_din,ram_sd_dout;logic[1:0]ram_sd_be;
  ram_sdram #(.RAMW(32'h40000),.SD_AW(25)) main_ram(
    .clk,.rst(rst_cpu_o),.req(ram_start),.we(ram_we),.widx(ram_widx),.boff(ram_boff),.sz(ram_size),.wd(ram_wdata),
    .rdata(ram_rdata),.done(ram_done),.active(ram_active),.sd_addr(ram_sd_addr),.sd_din(ram_sd_din),
    .sd_be(ram_sd_be),.sd_rd(ram_sd_rd),.sd_wr(ram_sd_wr),.sd_dout(ram_sd_dout),.sd_ack(ram_sd_ack));
  // SDRAM arbiter channels. DECLARED BEFORE FIRST USE: these were declared next
  // to their consumers further down, and Questa creates an implicit net at the
  // use site here and then rejects the real declaration as a redeclaration
  // (vlog-2388). iverilog and sv2v both accepted it, so this only appeared at the
  // wrapper elaboration gate.
  tunit_sdram_arb sdram_mux(
    .clk,.rst(sdram_por),.p_addr(prog_sd_addr),.p_din(prog_sd_din),.p_be(prog_sd_be),.p_rd(prog_sd_rd),.p_wr(prog_sd_wr),
    .p_dout(prog_sd_dout),.p_ack(prog_sd_ack),.r_addr(ram_sd_addr),.r_din(ram_sd_din),.r_be(ram_sd_be),
    .r_rd(ram_sd_rd),.r_wr(ram_sd_wr),.r_dout(ram_sd_dout),.r_ack(ram_sd_ack),
    // gfx channel TIED OFF, deliberately. Moving the blitter's source stream here
    // regressed the cabinet: T-unit's MAIN RAM is on this SDRAM (ram_sdram,
    // 256 KB) and the CPU drives it continuously, so the blitter -- correctly the
    // lowest priority, being the most latency-tolerant -- starved. midway_dma's
    // normal queue does not back-pressure: a trigger arriving full is DROPPED
    // (midway_dma.sv:770-772), silently. That is missing players and a shadow
    // popping in and out on NBA Jam. Y-unit can carry gfx here because their
    // SDRAM does NOT also carry main RAM; T-unit's does, and that is the
    // difference I missed, and Y-unit confirmed the root of it: their main RAM
    // is ON-CHIP BRAM (64K words), so their SDRAM never carries it. T-unit's is
    // 512 KB = 4,194,304 bits = 410 M10K blocks, against 60 free at 493/553.
    // Main RAM therefore CANNOT move to BRAM here -- short by 350 blocks -- and
    // moving it to DDR3 would put latency-critical CPU data on the slow port to
    // free the fast one for a throughput stream, which is backwards.
    //
    // So this tie-off is PERMANENT on this device, not future work. gfx can only
    // move here if the blit queue gains back-pressure (which Y-unit ships and has
    // cabinet-proven), never by relocating main RAM.
    //
    // Sound stays -- one word per ~133 us cannot starve anything.
    //
    // SCALE, so the next attempt starts from the numbers: the queue is 512 deep
    // (tunit_memsys.sv:176), so overflowing it means the blitter fell ~512
    // triggers behind. That is the size of the deficit gfx-on-SDRAM created, and
    // any future attempt has to close a gap that large -- not shave a few
    // percent. MAME never drops at all (midtunit_v.cpp:695-740), so every one of
    // those was graphics the game drew and the player never saw.
    .g_addr(24'd0),.g_din(16'd0),.g_be(2'b00),.g_rd(1'b0),.g_wr(1'b0),.g_dout(),.g_ack(),
    // sound channel TIED OFF. Moving the sound ROM here corrupted MK2's audio on
    // the cabinet ("birds and static"): MK2 is the DCS title and its 64-bit
    // dcs_data reads go through the same tunit_sound_ddr_multi whose memory agent
    // was swapped, so a 4x16-bit reassembly fault lands directly on DCS PCM.
    // tb_tunit_sound_ddr_multi PASSED with DCS-mirror=1 against a memory model I
    // wrote myself, which is exactly the coverage illusion this tree keeps
    // finding elsewhere. Sound stays on DDR3 until a DCS check exists that runs
    // against something other than my own model.
    .s_addr(24'd0),.s_din(16'd0),.s_be(2'b00),.s_rd(1'b0),.s_wr(1'b0),.s_dout(),.s_ack(),
    .sd_addr(sdram_addr),.sd_din(sdram_din),.sd_be(sdram_be),.sd_rd(sdram_rd),.sd_wr(sdram_wr),
    .sd_dout(sdram_dout),.sd_ack(sdram_ack));

  // ---- VRAM in DDR3, local CMOS/palette, and live scanout ----------------
  logic vram_start,vram_we,vram_srt;logic[27:0]vram_widx;logic[3:0]vram_boff;logic[5:0]vram_size;logic[31:0]vram_wdata,vram_rdata;
  logic vram_done,vram_normal_done,srt_done;
  logic[31:0]vram_normal_rdata,srt_e0e1;
  logic[14:0]palette_addr;logic[15:0]palette_data;
  logic page_commit_w,active_page_w,srt_write_allow_w;
  logic srt_write_stall_w;
  tunit_store_mux stores(
    .clk,.rst(rst_cpu_o),.store_req,.store_we,.store_srt,.store_target,.store_word_addr,
    .store_bit_offset(store_boff),.store_size,.store_wdata,.store_rdata,.store_ack,.video_bank,.dma_palette,
    .nvram_ext_wr,.nvram_ext_addr,.nvram_ext_wdata,.nvram_ext_rdata,.nvram_write_pulse,
    .vram_req(vram_start),.vram_we,.vram_srt,.vram_widx,.vram_boff,.vram_size,.vram_wdata,.vram_rdata,.vram_done,
    .vram_stall(srt_write_stall_w),
    .ram_req(ram_start),.ram_we,.ram_widx,.ram_boff,.ram_size,.ram_wdata,.ram_rdata,.ram_done,
    .palette_scan_addr(palette_addr),.palette_scan_data(palette_data));

  logic scan_req,scan_ack,scan_ready;logic[18:0]scan_addr;logic[15:0]scan_data;
  logic cpu_snoop_valid,cpu_snoop_pending,cpu_snoop_overflow;
  logic[18:0]cpu_snoop_addr;logic[63:0]cpu_snoop_data;
  logic[28:0]vddr_addr;logic[7:0]vddr_burst;logic vddr_rd,vddr_we;logic[63:0]vddr_din,vddr_dout;logic[7:0]vddr_be;logic vddr_busy,vddr_ready;
  wire logic vram_srt_hw = vram_srt && !vram_widx[0];
  // NBA/TE are the source-proven users of the post-flip SRT page clear.
  // Keep the ownership change profile-local until the remaining game sources
  // establish that they use the same ordering contract.
  wire logic nba_page_owner_profile_w = (profile_q == PROFILE_NBAJAM) ||
                                        (profile_q == PROFILE_NBAJAM_TE);
  assign srt_write_stall_w = nba_page_owner_profile_w &&
                             vram_srt_hw && vram_we &&
                             !srt_write_allow_w;
  assign vram_done = vram_srt_hw ? srt_done : vram_normal_done;
  assign vram_rdata = vram_srt_hw
                    ? (vram_we ? 32'd0 : srt_e0e1)
                    : vram_normal_rdata;
  stv_vram_ddr_top #(.VRAMW(FB_WORDS),.VRAM_DDR_BASE(29'h6400000)) vram(
    .clk,.rst(rst_cpu_o),.sdram_por,.req(vram_start&&!vram_srt_hw),.we(vram_we),.widx(vram_widx),.boff(vram_boff),
    .sz(vram_size),.wd(vram_wdata),.videobank(video_bank),.dma_palette,
    .rdata(vram_normal_rdata),.done(vram_normal_done),
    .cpu_snoop_valid,.cpu_snoop_addr,.cpu_snoop_data,
    .cpu_snoop_pending,.cpu_snoop_overflow,
    .fb_we(dma_fb_we),.fb_addr(dma_fb_addr),.fb_wdata(dma_fb_wdata),.fb_ack(dma_fb_ack),
    .wr_busy(dma_wr_busy),.dbg_cst(),.erase_start(1'b0),.erase_row0(9'd0),.erase_lines(10'd0),.erase_busy(),
    .scan_req,.scan_addr,.scan_data,.scan_ack,
    // MAIN.ASM flips DPYADR, then clears the page that software now regards
    // as hidden. When DDR publication defers that flip, keep store_mux in its
    // backend-start state until scanout has actually released the old page.
    // Release therefore preserves the one-cycle backend request contract;
    // SRT reads are unaffected.
    .srt_req(vram_start&&vram_srt_hw&&!srt_write_stall_w),.srt_we(vram_we),
    .srt_entry({vram_widx[17:0],1'b0}),.srt_done,.srt_e0e1,
    .ddram_addr(vddr_addr),.ddram_burstcnt(vddr_burst),
    .ddram_rd(vddr_rd),.ddram_we(vddr_we),.ddram_din(vddr_din),.ddram_be(vddr_be),
    .ddram_busy(vddr_busy),.ddram_dout(vddr_dout),.ddram_dout_ready(vddr_ready));

  function automatic logic[15:0] advance_dpyadr(input logic[15:0]a,input logic[15:0]ctl,input logic[15:0]start);
    if(a[1:0]==0)advance_dpyadr=((a&16'hfffc)-(ctl&16'h03fc))|(start&3);
    else advance_dpyadr=(a&16'hfffc)|((a-1'b1)&3);
  endfunction
  logic[15:0]next_dpyadr,next2_dpyadr,next_display_word,next2_display_word;
  logic[8:0]display_row,next_row,next2_row,display_col;
  always_comb begin
    next_dpyadr=advance_dpyadr(dpyadr,dpyctl,dpystrt);
    next2_dpyadr=advance_dpyadr(next_dpyadr,dpyctl,dpystrt);
    next_display_word=dpyctl[10]?next_dpyadr:(next_dpyadr^16'hfffc);
    next2_display_word=dpyctl[10]?next2_dpyadr:(next2_dpyadr^16'hfffc);
    display_row=display_row_full[8:0];next_row=next_display_word[12:4];
    next2_row=next2_display_word[12:4];
    display_col={display_col_full[7:0],1'b0};
  end
  logic vblank_irq;
  // Lever 1 REVERTED to 4 (cab 2026-08-21). FLIP_PREFETCH_LINES=8 shrank the
  // page-commit window (page_commit_window = vc < V_TOTAL-N), so under heavy blit
  // load the drain+settle missed the shorter window -> commit skipped -> WORSE
  // HUD/UI flicker (team-select + in-game). The fence is already correctly drain-
  // gated (render_busy = dma_busy||dma_wr_busy), so the flash/top-band belongs to
  // Lever 2 (proactive scanline prefetch), NOT this window bump.
  tunit_video_top #(.FLIP_PREFETCH_LINES(4)) scanout(
    .clk,.rst(rst_cpu_o),.ce_pix,.timing_start,.display_enable,
    .env_srt_visible_hold(nba_page_owner_profile_w && dpyctl[11]),
    .pending_page_prewarm_enable(nba_page_owner_profile_w),
    .display_blank,
    .vblank_start(tms_vblank_start),
    // MAME renders a visible line with the current DPYADR, then advances it.
    // Keep that current row on the pixel path while prefetching its successor.
    .display_row,.next_row,.next2_row,.display_col,
    .wr_busy(dma_wr_busy),.dma_busy,
    .palette_addr,.palette_data,
    .cpu_snoop_valid,.cpu_snoop_addr,.cpu_snoop_data,
    .cpu_snoop_pending,.cpu_snoop_overflow,
    .scan_req,.scan_addr,.scan_data,.scan_ack,.vid_r,.vid_g,.vid_b,.hsync,.vsync,.hblank,.vblank,.de,
    .vblank_irq,.tms_ce,.scan_ready,.video_underrun,.video_underrun_count,
    .page_commit(page_commit_w),.active_page(active_page_w),
    .srt_write_allow(srt_write_allow_w));

  // ---- busy-wedge instrument (TUNIT-P0035) --------------------------------
  // Transcribed from the cabinet-proven Wolf core, wolf_top.sv:1076-1094. Wolf
  // hit a blit_busy wedge on silicon and kept a screen-readable counter for it;
  // T-unit had no equivalent, which is why a black screen needed a sim campaign
  // to explain instead of one cab photo.
  //
  //   dbg_blit_hold_max -- longest run of clocks dma_busy stayed high. HUGE
  //                        means the DMA FSM itself wedged.
  //   dbg_wr_hold_max   -- longest run of clocks dma_wr_busy stayed high. HUGE
  //                        with a normal blit hold means the VRAM write drain.
  //   dbg_commit_count  -- published page CHANGES, not frames. Games do not
  //                        necessarily alternate pages every frame; use the
  //                        page-state missed-publication counter for failures.
`ifdef TUNIT_DIAG
  // 2026-07-30 cabinet reading retired the busy counters: dma_busy is 00000000
  // on MK2 AND NBA Jam TE -- the blitter never starts, so a hold-max is a
  // constant zero. Reuse row 1 for DERAIL CAPTURE instead: latch the source of
  // every long PC jump. When the CPU wedges (MK2 freezes at FFC98DC0, inside a
  // 35,019-word run of blank FFFF ROM), the last latched source names the exact
  // instruction that jumped there -- which one photo turns into a code lookup.
  logic[31:0]pc_prev,page_diag_state_w;
  tunit_page_diag page_diag(
    .clk,.rst(rst_cpu_o),.vblank,.wanted_page(display_row[8]),
    .active_page(active_page_w),.render_busy(dma_busy||dma_wr_busy),
    .page_commit(page_commit_w),.state(page_diag_state_w));
  // Preserve the ticket-8 page-state ABI and consume one previously reserved
  // bit for the new sticky causal witness. Existing miss/live fields stay put.
  assign dbg_page_state={page_diag_state_w[31:5],dbg_srt_dma_overlap_w,
                         page_diag_state_w[3:0]};
  always_ff @(posedge clk or posedge rst_pon) begin
    if(rst_pon) begin
      pc_prev<=32'd0;dbg_blit_hold_max<=32'd0;dbg_commit_count<=32'd0;
    end else begin
      pc_prev<=cpu_pc;
      // REGION-CHANGE capture, not a magnitude compare. The first cut computed
      // a full 32-bit |delta| every clock -- two subtractors and a comparator
      // at 80 MHz -- and cost 0.29 ns on the chronic HDMI cone (run 11 landed
      // -0.226 where run 10 closed at +0.060 without it). A 12-bit inequality
      // on the upper PC bits is far cheaper and still catches the wedge we are
      // chasing: MK2 jumps FFA5xxxx -> FFC9xxxx, which differs in [27:20].
      if(cpu_pc[31:20]!=pc_prev[31:20]) dbg_blit_hold_max<=pc_prev;
      if(page_commit_w) dbg_commit_count<=dbg_commit_count+32'd1;
    end
  end
  // Row 2: DMA activity. Inputs are NOT the fault -- MK2 provably reacts to a
  // button press -- so the open question is why no blit ever starts. This shows
  // {register-write count, last DMA_COMMAND value}; go bit is command bit 15.
  assign dbg_wr_hold_max = dbg_dma_activity_w;
`else
  assign dbg_blit_hold_max=32'd0;
  assign dbg_wr_hold_max=32'd0;
  assign dbg_commit_count=32'd0;
  assign dbg_page_state=32'd0;
`endif

  // ---- graphics DDR + six-byte CPU adapter ------------------------------
  logic gfx_line_ack,gfx_byte_req,gfx_byte_ack;logic[47:0]gfx_line;logic[25:0]gfx_byte_addr;logic[7:0]gfx_byte_data;
  tunit_gfx_line gfx_cpu(.clk,.rst(rst_cpu_o),.line_req(rom_req&&rom_is_gfx),.line_byte_addr(rom_byte_addr),
    .line_data(gfx_line),.line_ack(gfx_line_ack),.byte_req(gfx_byte_req),.byte_addr(gfx_byte_addr),
    .byte_data(gfx_byte_data),.byte_ack(gfx_byte_ack));
  assign rom_line=rom_is_gfx?gfx_line:prog_line;
  assign rom_ack=rom_is_gfx?gfx_line_ack:prog_line_ack;
  logic[28:0]gddr_addr;logic[7:0]gddr_burst;logic gddr_rd,gddr_we;logic[63:0]gddr_din,gddr_dout;logic[7:0]gddr_be;logic gddr_busy,gddr_ready;
  logic gfx_dl_idle,gfx_dcs_safe;
  // Include the presented write immediately, before the first accepting
  // clock edge, so the aggregate loader/reset fence cannot briefly deassert
  // while a graphics byte is entering the backend.
  assign gfx_dl_busy = gfx_wr || !gfx_dl_idle;
  midway_gfx_ddr_top #(
    .GFX_DDR_BASE(29'h6800000),
    .USE_STREAM_HINT(1'b1)
  ) graphics(
    .clk,.rst(rst_cpu_o),.sdram_por,
    .src_req(dma_src_req),.src_addr(dma_src_addr),
    .src_active(dma_src_active),.src_stream(dma_src_stream),
    .src_data(dma_src_data),.src_ack(dma_src_ack),.dcs_safe(gfx_dcs_safe),
    .cg_req(gfx_byte_req),.cg_addr(gfx_byte_addr),.cg_data(gfx_byte_data),.cg_ack(gfx_byte_ack),
    .dl_wr(gfx_wr),.dl_addr({1'b0,gfx_addr}),.dl_data(gfx_wdata),
    .dl_ack(gfx_dl_ack),.dl_idle(gfx_dl_idle),
    .dbg_wbeats(),.dbg_srd(),.dbg_cgrd(),.ddram_addr(gddr_addr),.ddram_burstcnt(gddr_burst),
    .ddram_rd(gddr_rd),.ddram_we(gddr_we),.ddram_din(gddr_din),.ddram_be(gddr_be),
    .ddram_busy(gddr_busy),.ddram_dout(gddr_dout),.ddram_dout_ready(gddr_ready));

  // ---- Sound: DCS2K (MK2) or Williams ADPCM (MK1/NBA Jam/TE/Judge Dredd) -----
  //
  // Both boards are instantiated and the PROFILE selects which one the CPU talks to
  // and which one drives the DAC. They are mutually exclusive per title
  // (tunit_profile_layout.sv gives sound_type=1 only for MK2), so only one is ever
  // live. The sound PORT decodes for every profile -- that gate was the reason the
  // four ADPCM titles had no audio at all, upstream of this engine existing.
  logic sound_dcs;
  assign sound_dcs = (profile_q == PROFILE_MK2);

  logic sound_rom_req,sound_rom_ready;logic[19:0]sound_rom_addr;logic[63:0]sound_rom_data;
  logic[15:0]dcs_status_q,dcs_data_q;
  logic signed[15:0]dcs_audio;logic dcs_audio_ce;
  logic dcs_audio_underrun,dcs_audio_overrun;
`ifdef TUNIT_NO_DCS
  // DCS engine EXCLUDED for an ADPCM-family image. adsp2105 alone is 7,225 ALMs own,
  // 23% of the design, and serves MK2 only -- so an image built for MK1/NBA Jam/TE/
  // Judge Dredd should not carry it. Tie the CPU-visible side to the idle values MAME
  // returns for an absent board so a mis-set profile reads sane data rather than X.
  assign dcs_status_q   = 16'h00c0;
  assign dcs_data_q     = 16'h00ff;
  assign dcs_audio      = 16'sd0;
  assign dcs_audio_ce   = 1'b0;
  assign sound_rom_req  = 1'b0;
  assign sound_rom_addr = 20'd0;
  assign dcs_audio_underrun = 1'b0;
  assign dcs_audio_overrun  = 1'b0;
  assign adsp_pc        = 14'd0;
  assign adsp_valid     = 1'b0;
  assign adsp_unimplemented = 1'b0;
`else
  tunit_dcs2k dcs(
    .clk,.rst(rst_cpu_o),.dac_ce_31250(dac_ce),
    .cpu_status_rd(dcs_status_rd && sound_dcs),.cpu_data_rd(dcs_data_rd && sound_dcs),
    .cpu_data_wr(dcs_data_wr && sound_dcs),.cpu_data_offset(dcs_data_offset),.cpu_wdata(dcs_wdata),.cpu_byte_en(dcs_be),
    .cpu_status_rdata(dcs_status_q),.cpu_data_rdata(dcs_data_q),.rom_req(sound_rom_req),.rom_addr(sound_rom_addr),
    .rom_ready(sound_rom_ready),.rom_rdata(sound_rom_data),.audio(dcs_audio),.audio_ce(dcs_audio_ce),
    .audio_underrun(dcs_audio_underrun),.audio_overrun(dcs_audio_overrun),
    .adsp_pc,.adsp_valid,.adsp_unimplemented);
`endif

  // Williams ADPCM host side. Follows midtunit_adpcm_state::sound_state_r/sound_r/
  // sound_w, not the released assembly -- NBA Jam's own SYS.EQU active .if TUNIT2
  // block names a board revision that did not ship (its ROM has zero references to
  // the addresses that block declares).
  logic[15:0]adpcm_status_q,adpcm_data_q;
  logic adpcm_cmd_wr;logic[7:0]adpcm_cmd;logic adpcm_board_reset;logic[7:0]adpcm_busy_reads;
  logic[20:0]adpcm_snd_addr;logic[7:0]adpcm_snd_data;logic adpcm_snd_ok;
  logic adpcm_sys_req;logic[20:0]adpcm_sys_addr;logic[7:0]adpcm_sys_data;logic adpcm_sys_ack;
  // Full DDR3 beat behind every ADPCM fetch; the byte lane is now selected in
  // the cache rather than thrown away at the memory client.
  logic[63:0]adpcm_sys_line;
  logic signed[15:0]adpcm_audio_l,adpcm_audio_r,adpcm_audio_sys;
  logic adpcm_irq_state;
  logic adpcm_command_wr_snd;logic[7:0]adpcm_command_snd;
  logic adpcm_board_reset_snd;logic[2:0]adpcm_profile_snd;
  logic adpcm_cdc_overflow;
  // Audio telemetry: sound-domain window results and their system-domain rows.
  logic [15:0] tel_ym_snd,tel_firq_snd,tel_dac_snd,tel_oki_snd;
  logic [15:0] tel_erate_snd,tel_romwait_snd,tel_cmdrd_snd,tel_misc_snd;
  logic        tel_tick_snd;
`ifdef TUNIT_NO_ADPCM
  // Williams board EXCLUDED for an MK2-family image.
  assign adpcm_status_q   = 16'hffff;
  assign adpcm_data_q     = 16'hffff;
  assign adpcm_cmd_wr     = 1'b0;
  assign adpcm_cmd        = 8'h00;
  assign adpcm_board_reset= 1'b0;
  assign adpcm_busy_reads = 8'd0;
  assign adpcm_snd_addr   = 21'd0;
  assign adpcm_sys_req    = 1'b0;
  assign adpcm_sys_addr   = 21'd0;
  assign adpcm_audio_l    = 16'sd0;
  assign adpcm_audio_r    = 16'sd0;
  assign adpcm_audio_sys  = 16'sd0;
  assign adpcm_irq_state  = 1'b0;
  assign adpcm_cdc_overflow = 1'b0;
  assign audio_tel_a = 32'd0; assign audio_tel_b = 32'd0;
  assign audio_tel_c = 32'd0; assign audio_tel_d = 32'd0;
`else
  tunit_adpcm_host adpcm_host(
    .clk,.rst(rst_cpu_o),
    .status_rd(dcs_status_rd && !sound_dcs),.data_rd(dcs_data_rd && !sound_dcs),
    .data_wr(dcs_data_wr && !sound_dcs),.data_offset(dcs_data_offset),
    .wdata(dcs_wdata),.byte_en(dcs_be),
    .status_rdata(adpcm_status_q),.data_rdata(adpcm_data_q),
    .command_wr(adpcm_cmd_wr),.command(adpcm_cmd),
    .board_reset(adpcm_board_reset),.busy_reads(adpcm_busy_reads));

  // One-way boot latch: set when the loader has finished and the CPU has been
  // released, cleared only by power-on. Deliberately NOT a live backend-busy
  // board reset. A later download is fenced separately by loader_rst_sound.
  logic roms_loaded_q;
  always_ff @(posedge clk or posedge sdram_por) begin
    if (sdram_por) roms_loaded_q <= 1'b0;
    else if (!rst_cpu_o) roms_loaded_q <= 1'b1;
  end

  // The outer 8-line cache contains bytes from one loaded ROM image. Keep it
  // invalid before first release, across the loader's complete sound epoch,
  // and through tunit_sound_ddr_multi's final physical write completion. This
  // is cache-only: ordinary FE/FF adpcm_board_reset is intentionally absent.
  wire logic adpcm_cache_epoch_reset =
    !roms_loaded_q || loader_rst_sound || snd_dl_busy;

  // Byte bridge across the 12/80 MHz boundary, then the board itself on clk_snd.
  tunit_adpcm_rom_cdc adpcm_cdc(
    .clk_snd,.clk_sys(clk),.rst_pon(sdram_por),
    .epoch_reset_sys(adpcm_cache_epoch_reset),
    .snd_addr(adpcm_snd_addr),.snd_data(adpcm_snd_data),.snd_ok(adpcm_snd_ok),
    .sys_req(adpcm_sys_req),.sys_addr(adpcm_sys_addr),.sys_line(adpcm_sys_line),.sys_ack(adpcm_sys_ack));

  tunit_sound_cdc sound_cdc(
    .clk_sys(clk),.clk_snd,.rst_pon(sdram_por),
    .command_wr_sys(adpcm_cmd_wr),.command_sys(adpcm_cmd),
    // SOUND-BOARD RESET IS CURRENTLY THE HOST'S D8 WRITE PLUS A ONE-WAY BOOT
    // HOLD.  This is recovery behavior, not a proven cabinet fix.
    //
    // This used to be `adpcm_board_reset || rst_cpu_o`, and rst_cpu_o folds in
    // loader_or_backend_busy, which decomposes into LIVE fence and write-combine
    // state (dl_dirty, wc_valid, fsel, qsel) rather than "a download is
    // happening". Any of those glitching high after boot re-reset the sound
    // board mid-game.
    //
    // MAME 0.289 command traces observed only boot-era host reset writes over 60
    // seconds (mk 2, nbajam 3, nbajamte 1, jdreddp 1).  The earlier cabinet
    // reading `resets=20` was mistakenly described as a one-second rate; the
    // counter was cumulative since POR.  It therefore does NOT prove a
    // repeating-reset divergence or explain the missing-music symptoms.
    //
    // MAME has no reset path from main-CPU conditions: midtunit_m.cpp:558-561,
    // reset_write(~data & 0x100), is the host reset control.  Keeping live
    // loader/backend state out of the reset input matches that topology, but the
    // board-wide RTL reset domain is still broader than MAME's host reset
    // semantics and remains an open, independently testable seam.
    //
    // roms_loaded_q latches ONE WAY. Before it sets, the board is held reset
    // because its ROM genuinely is not there yet. loader_rst_sound is the
    // loader's exact transaction fence, not the live DDR backend state removed
    // by the recovery fix: it asserts before a second game's mapped sound write
    // and stays high through the final snd_ready acknowledgement.
    .board_reset_sys(adpcm_board_reset || !roms_loaded_q || loader_rst_sound),
    .profile_sys(profile_q),.audio_l_snd(adpcm_audio_l),.audio_r_snd(adpcm_audio_r),
    .command_wr_snd(adpcm_command_wr_snd),.command_snd(adpcm_command_snd),
    .board_reset_snd(adpcm_board_reset_snd),.profile_snd(adpcm_profile_snd),
    .audio_sys(adpcm_audio_sys),.overflow_sticky(adpcm_cdc_overflow));

  tunit_adpcm_board adpcm_board(
    .clk(clk_snd),.reset_pon(sdram_por),.reset(adpcm_board_reset_snd),
    .profile(adpcm_profile_snd),.command_wr(adpcm_command_wr_snd),.command(adpcm_command_snd),
    // The loader's mapped logical stream is also the fixed-bank preload tap.
    // snd_wr is held through backend acknowledgement; repeated writes of the
    // same stable byte are harmless. loader_rst_sound holds the ADPCM board in
    // reset through that transaction. DCS can use logical 03c000 in a universal
    // image, so suppress its writes at this ADPCM-only preload tap.
    .snd_dl_clk(clk),.snd_dl_addr(snd_addr),.snd_dl_data(snd_wdata),
    .snd_dl_we(snd_wr && !sound_dcs),
    .ext_rom_addr(adpcm_snd_addr),.ext_rom_data(adpcm_snd_data),.ext_rom_ok(adpcm_snd_ok),
    .audio_l(adpcm_audio_l),.audio_r(adpcm_audio_r),.irq_state(adpcm_irq_state),
    .tel_ym_per_s(tel_ym_snd),.tel_firq_per_s(tel_firq_snd),
    .tel_dac_per_s(tel_dac_snd),.tel_oki_writes(tel_oki_snd),
    .tel_e_rate_cpct(tel_erate_snd),.tel_romwait_pct(tel_romwait_snd),
    .tel_cmd_reads(tel_cmdrd_snd),.tel_misc(tel_misc_snd),.tel_tick(tel_tick_snd));

`ifdef TUNIT_DIAG
  logic [31:0] audio_tel_d_cdc;
  tunit_audio_tel_cdc audio_tel_cdc(
    .clk_snd,.clk_sys(clk),.rst_pon(sdram_por),
    .tick_snd(tel_tick_snd),
    .ym_snd(tel_ym_snd),.firq_snd(tel_firq_snd),.dac_snd(tel_dac_snd),
    .oki_snd(tel_oki_snd),.erate_snd(tel_erate_snd),.romwait_snd(tel_romwait_snd),
    .cmdrd_snd(tel_cmdrd_snd),.misc_snd(tel_misc_snd),
    .row_a(audio_tel_a),.row_b(audio_tel_b),.row_c(audio_tel_c),.row_d(audio_tel_d_cdc));
  // The actual command FIFO overflow flag is created in the 80 MHz host
  // domain.  The board-local telemetry input is intentionally tied low, so OR
  // the real sticky flag into the stable system-domain row after the CDC.
  assign audio_tel_d = {
    audio_tel_d_cdc[31:8],
    audio_tel_d_cdc[7] | adpcm_cdc_overflow,
    audio_tel_d_cdc[6:0]
  };
`else
  // See tunit_adpcm_board.sv: the (* preserve *) on this module's hold
  // registers stopped Quartus stripping ~256 dead registers from every
  // production image.  No telemetry in production means no crossing either.
  assign audio_tel_a=32'd0;assign audio_tel_b=32'd0;
  assign audio_tel_c=32'd0;assign audio_tel_d=32'd0;
`endif
`endif

  assign dcs_status_rdata = sound_dcs ? dcs_status_q : adpcm_status_q;
  assign dcs_data_rdata   = sound_dcs ? dcs_data_q   : adpcm_data_q;

  // DAC select. The framework takes one mono channel, so the ADPCM board's stereo
  // pair is averaged rather than dropping a side. audio_ce follows the DCS strobe in
  // DCS mode and the shared 31.25 kHz DAC tick otherwise.
  assign audio    = sound_dcs ? dcs_audio : adpcm_audio_sys;
  assign audio_ce = sound_dcs ? dcs_audio_ce : dac_ce;
  assign audio_underrun = sound_dcs ? dcs_audio_underrun : 1'b0;
  assign audio_overrun  = sound_dcs ? dcs_audio_overrun  : adpcm_cdc_overflow;

  logic[28:0]sddr_addr;logic[7:0]sddr_burst;logic sddr_rd,sddr_we;logic[63:0]sddr_din,sddr_dout;logic[7:0]sddr_be;logic sddr_busy,sddr_ready;
  tunit_sound_ddr_multi sound_rom(
    .clk,.sdram_por,.sound_dcs,
    .dl_wr(snd_wr),.dl_addr(snd_addr),.dl_data(snd_wdata),.dl_ack(snd_dl_ack),.dl_busy(snd_dl_busy),
    .dcs_req(sound_rom_req),.dcs_addr(sound_rom_addr),.dcs_ready(sound_rom_ready),.dcs_data(sound_rom_data),
    .adpcm_req(adpcm_sys_req),.adpcm_addr(adpcm_sys_addr),.adpcm_ready(adpcm_sys_ack),.adpcm_data(adpcm_sys_data),.adpcm_line(adpcm_sys_line),
    .ddram_addr(sddr_addr),.ddram_burstcnt(sddr_burst),.ddram_rd(sddr_rd),.ddram_we(sddr_we),
    .ddram_din(sddr_din),.ddram_be(sddr_be),.ddram_busy(sddr_busy),.ddram_dout(sddr_dout),
    .ddram_dout_ready(sddr_ready));

  tunit_ddr3_arb ddr_mux(
    .clk,.rst(sdram_por),.a_addr(vddr_addr),.a_burstcnt(vddr_burst),.a_rd(vddr_rd),.a_we(vddr_we),.a_din(vddr_din),.a_be(vddr_be),
    .a_busy(vddr_busy),.a_dout(vddr_dout),.a_dout_ready(vddr_ready),
    .b_addr(gddr_addr),.b_burstcnt(gddr_burst),.b_rd(gddr_rd),.b_we(gddr_we),.b_din(gddr_din),.b_be(gddr_be),
    .b_busy(gddr_busy),.b_dout(gddr_dout),.b_dout_ready(gddr_ready),
    .c_addr(sddr_addr),.c_burstcnt(sddr_burst),.c_rd(sddr_rd),.c_we(sddr_we),.c_din(sddr_din),.c_be(sddr_be),
    .c_busy(sddr_busy),.c_dout(sddr_dout),.c_dout_ready(sddr_ready),
    .c_priority(gfx_dcs_safe),
    .ddram_addr,.ddram_burstcnt,.ddram_rd,.ddram_we,.ddram_din,.ddram_be,.ddram_busy,.ddram_dout,.ddram_dout_ready);
endmodule
`default_nettype wire
