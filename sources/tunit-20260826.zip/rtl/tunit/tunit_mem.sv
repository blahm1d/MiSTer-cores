// T-unit CPU-bus router. Storage is intentionally abstracted behind the store
// and ROM line ports so the board can place RAM/program in SDRAM and VRAM/gfx
// in HPS DDR3 without embedding Wolf-unit address assumptions here.

`default_nettype none
module tunit_mem
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        ce_cpu,
  input  wire tunit_profile_t profile,
  input  wire tunit_variant_t variant,

  input  wire logic        mem_req,
  input  wire logic        mem_we,
  input  wire logic [31:0] mem_addr,
  input  wire logic [5:0]  mem_size,
  input  wire logic [31:0] mem_wdata,
  output logic [31:0] mem_rdata,
  output logic        mem_ack,

  input  wire logic [15:0] in0,
  input  wire logic [15:0] in1,
  input  wire logic [15:0] in2,
  input  wire logic [15:0] dsw,

  output logic        store_req,
  output logic        store_we,
  output tunit_map_target_t store_target,
  output logic [27:0] store_word_addr,
  output logic [3:0]  store_bit_offset,
  output logic [5:0]  store_size,
  output logic [31:0] store_wdata,
  input  wire logic [31:0] store_rdata,
  input  wire logic        store_ack,

  output logic        rom_req,
  output logic        rom_is_gfx,
  output logic [23:0] rom_byte_addr,
  input  wire logic [47:0] rom_line,
  input  wire logic        rom_ack,

  output logic        dcs_status_rd,
  output logic        dcs_data_rd,
  output logic        dcs_data_wr,
  output logic        dcs_data_offset,
  output logic [15:0] dcs_wdata,
  output logic [1:0]  dcs_byte_en,
  input  wire logic [15:0] dcs_status_rdata,
  input  wire logic [15:0] dcs_data_rdata,

  output logic        video_bank,
  output logic [23:0] gfx_bank_offset,
  output logic [15:0] control_word,
  output logic        cmos_write_enable,
  output logic        watchdog_kick,
  output logic [7:0]  last_target
);

  typedef enum logic [2:0] {M_IDLE, M_ROUTE, M_DIRECT, M_STORE, M_ROM, M_ACK} state_t;
  state_t state;
  logic [31:0] addr_q, wdata_q;
  logic [5:0] size_q;
  logic we_q;
  tunit_map_target_t target_q;
  tunit_map_target_t route_target;
  // Legacy component benches may leave ce_cpu unconnected; X/Z means full rate.
  wire logic cpu_step = ce_cpu !== 1'b0;

  wire logic route_is_store_target = route_target == MAP_VRAM ||
                                     route_target == MAP_RAM ||
                                     route_target == MAP_CMOS ||
                                     route_target == MAP_PALETTE;
  wire logic route_is_rom_target = route_target == MAP_GFX ||
                                   route_target == MAP_PROGRAM;
  assign route_target = tunit_map_decode(profile, addr_q);

  logic prot_hit;
  logic [15:0] prot_rdata;
  logic [15:0] direct_wdata;
  logic [1:0] direct_be;

  always_comb begin
    direct_wdata = wdata_q[15:0] << addr_q[3:0];
    direct_be[0] = (addr_q[3:0] < 8) && (size_q != 0);
    direct_be[1] = ((addr_q[3:0] + size_q) > 8);
  end

  tunit_protection_all protection (
    .clk(clk), .rst(rst), .profile(profile),
    .mk_turbo(variant == VARIANT_MK_TURBO),
    .rd(state == M_DIRECT && !we_q), .wr(state == M_DIRECT && we_q),
    .addr(addr_q), .wdata(direct_wdata), .byte_en(direct_be),
    .rdata(prot_rdata), .hit(prot_hit)
  );

  tunit_control control (
    .clk(clk), .rst(rst),
    .wr(state == M_DIRECT && we_q && target_q == MAP_CONTROL),
    .wdata(direct_wdata), .byte_en(direct_be),
    .gfx_rom_large(profile == PROFILE_MK2),
    .control(control_word), .video_bank(video_bank),
    .gfx_bank_offset(gfx_bank_offset)
  );

  function automatic logic [15:0] direct_read_word(input logic [31:0] a);
    tunit_map_target_t t;
    begin
      t = tunit_map_decode(profile, a);
      case (t)
        MAP_IN0:        direct_read_word = in0;
        MAP_IN1:        direct_read_word = in1;
        MAP_IN2:        direct_read_word = in2;
        MAP_DSW:        direct_read_word = dsw;
        MAP_DCS_STATUS: direct_read_word = dcs_status_rdata;
        MAP_DCS_DATA:   direct_read_word = dcs_data_rdata;
        default:        direct_read_word = 16'hffff;
      endcase
    end
  endfunction

  logic [47:0] direct_window;
  logic [47:0] field_mask;
  logic [27:0] rom_word_rel;
  logic [22:0] gfx_word_rel;
  logic [23:0] gfx_window_base;
  always_comb begin
    direct_window = {direct_read_word({addr_q[31:4] + 28'd2,4'h0}),
                     direct_read_word({addr_q[31:4] + 28'd1,4'h0}),
                     prot_hit ? prot_rdata : direct_read_word({addr_q[31:4],4'h0})};
    field_mask = (48'd1 << size_q) - 48'd1;
    if (addr_q >= TMAP_PROG_LO)
      rom_word_rel = addr_q[31:4] - TMAP_PROG_LO[31:4];
    else
      rom_word_rel = addr_q[31:4] - TMAP_PROG_MIR_LO[31:4];

    // T-unit graphics space is three 4 MiB byte windows. Window 1 is fixed
    // at physical graphics offset 4 MiB; windows 0 and 2 select physical
    // offset 0 or 8 MiB through control bit 7. This is the exact
    // midtunit_gfxrom_r() offset folding, including window 2 mirroring.
    gfx_word_rel = addr_q[31:4] - TMAP_GFX_LO[31:4];
    gfx_window_base = gfx_word_rel[21] ? 24'h400000 : gfx_bank_offset;
  end

  assign mem_ack = state == M_ACK;
  assign store_req = state == M_STORE;
  assign store_we = we_q;
  assign store_target = target_q;
  assign store_word_addr = addr_q[31:4];
  assign store_bit_offset = addr_q[3:0];
  assign store_size = size_q;
  assign store_wdata = wdata_q;

  assign rom_req = state == M_ROM;
  assign rom_is_gfx = target_q == MAP_GFX;
  assign rom_byte_addr = rom_is_gfx
                       ? gfx_window_base + {gfx_word_rel[20:0], 1'b0}
                       : rom_word_rel[23:0] << 1;

  assign dcs_status_rd = state == M_DIRECT && !we_q && target_q == MAP_DCS_STATUS;
  assign dcs_data_rd = state == M_DIRECT && !we_q && target_q == MAP_DCS_DATA;
  assign dcs_data_wr = state == M_DIRECT && we_q && target_q == MAP_DCS_DATA;
  assign dcs_data_offset = addr_q[4];
  assign dcs_wdata = direct_wdata;
  assign dcs_byte_en = direct_be;

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= M_IDLE;
      addr_q <= 0;
      wdata_q <= 0;
      size_q <= 0;
      we_q <= 0;
      target_q <= MAP_NONE;
      mem_rdata <= 0;
      cmos_write_enable <= 0;
      watchdog_kick <= 0;
      last_target <= MAP_NONE;
    end else begin
      watchdog_kick <= 0;
      case (state)
        // Capture a newly asserted CPU command at the full system rate. The
        // ce_cpu-gated core holds every request and its payload until ack, so
        // the router can begin work on the first clock after assertion instead
        // of inserting another complete CPU-enable interval.
        M_IDLE: if (mem_req) begin
          addr_q <= mem_addr;
          wdata_q <= mem_wdata;
          size_q <= mem_size;
          we_q <= mem_we;
          state <= M_ROUTE;
        end
        M_ROUTE: begin
          // The raw command was registered in M_IDLE. Decode that held address
          // during this already-existing route phase and capture the target
          // on the same edge that selects the next state. This removes the
          // CPU/address-arithmetic cone from command capture without adding a
          // transaction cycle.
          target_q <= route_target;
          last_target <= {3'd0,route_target};
          if (route_is_store_target) state <= M_STORE;
          else if (route_is_rom_target && !we_q) state <= M_ROM;
          else state <= M_DIRECT;
        end
        M_DIRECT: begin
          if (prot_hit) last_target <= 8'hfe;
          if (!we_q)
            mem_rdata <= 32'((direct_window >> addr_q[3:0]) & field_mask);
          else begin
            mem_rdata <= 0;
            if (target_q == MAP_CMOS_ENABLE) cmos_write_enable <= 1;
            if (target_q == MAP_WATCHDOG) watchdog_kick <= 1;
          end
          state <= M_ACK;
        end
        M_STORE: if (store_ack) begin
          mem_rdata <= store_rdata;
          // MAME currently permits every CMOS write, but still consumes the
          // hardware write-enable latch on the next CMOS write.
          if (we_q && target_q == MAP_CMOS) cmos_write_enable <= 0;
          state <= M_ACK;
        end
        M_ROM: if (rom_ack) begin
          mem_rdata <= 32'((rom_line >> addr_q[3:0]) & field_mask);
          state <= M_ACK;
        end
        // Hold completion until a CPU-enable edge can observe it. The 34010
        // may keep mem_req asserted into its next transfer, so waiting for a
        // low level is incorrect; release exactly on the sampling edge.
        M_ACK: if(cpu_step) state <= M_IDLE;
        default: state <= M_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
