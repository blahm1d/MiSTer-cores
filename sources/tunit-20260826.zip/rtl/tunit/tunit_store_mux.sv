// Board storage router. Converts the held tunit_memsys store request into a
// single-cycle start pulse for exactly one backend, then holds ownership until
// that backend completes. This boundary prevents held-request reaccept bugs in
// the latency-tolerant RAM/VRAM field engines.

`default_nettype none
module tunit_store_mux
  import tunit_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        store_req,
  input  wire logic        store_we,
  input  wire logic        store_srt,
  input  wire tunit_map_target_t store_target,
  input  wire logic [27:0] store_word_addr,
  input  wire logic [3:0]  store_bit_offset,
  input  wire logic [5:0]  store_size,
  input  wire logic [31:0] store_wdata,
  output logic [31:0]      store_rdata,
  output logic             store_ack,

  input  wire logic        video_bank,
  input  wire logic [15:0] dma_palette,

  input  wire logic        nvram_ext_wr,
  input  wire logic [13:0] nvram_ext_addr,
  input  wire logic [7:0]  nvram_ext_wdata,
  output logic [7:0]       nvram_ext_rdata,
  output logic             nvram_write_pulse,

  output logic             vram_req,
  output logic             vram_we,
  output logic             vram_srt,
  output logic [27:0]      vram_widx,
  output logic [3:0]       vram_boff,
  output logic [5:0]       vram_size,
  output logic [31:0]      vram_wdata,
  input  wire logic [31:0] vram_rdata,
  input  wire logic        vram_done,
  // Hold the backend-start state when a board-level ownership fence cannot
  // yet accept this VRAM transaction. vram_req consequently remains asserted
  // with the already-latched address/data until the fence releases it.
  input  wire logic        vram_stall,

  output logic             ram_req,
  output logic             ram_we,
  output logic [27:0]      ram_widx,
  output logic [3:0]       ram_boff,
  output logic [5:0]       ram_size,
  output logic [31:0]      ram_wdata,
  input  wire logic [31:0] ram_rdata,
  input  wire logic        ram_done,

  input  wire logic [14:0] palette_scan_addr,
  output logic [15:0]      palette_scan_data
);
  typedef enum logic [2:0] {S_IDLE,S_START,S_WAIT,S_ACK} state_t;
  state_t state;
  tunit_map_target_t target_q;
  logic we_q;
  logic srt_q;
  logic [27:0] word_q;
  logic [3:0] boff_q;
  logic [5:0] size_q;
  logic [31:0] wdata_q;
  logic [31:0] result_q;

  wire logic local_owner = (target_q == MAP_CMOS) ||
                           (target_q == MAP_PALETTE);
  wire logic local_req = (state == S_START) && local_owner;
  logic [31:0] local_rdata;
  logic local_done;

  tunit_local_store local_store(
    .clk,.rst,.req(local_req),.we(we_q),.target(target_q),
    .word_addr(word_q),.bit_offset(boff_q),.size(size_q),.wdata(wdata_q),
    .rdata(local_rdata),.done(local_done),
    .nvram_ext_wr,.nvram_ext_addr,.nvram_ext_wdata,
    .nvram_ext_rdata,.nvram_write_pulse,
    .palette_scan_addr,.palette_scan_data
  );

  assign vram_req = (state == S_START) && (target_q == MAP_VRAM);
  assign vram_we = we_q;
  assign vram_srt = srt_q;
  assign vram_widx = word_q - TMAP_VRAM_LO[31:4];
  assign vram_boff = boff_q;
  assign vram_size = size_q;
  assign vram_wdata = wdata_q;

  assign ram_req = (state == S_START) && (target_q == MAP_RAM);
  assign ram_we = we_q;
  assign ram_widx = word_q - TMAP_RAM_LO[31:4];
  assign ram_boff = boff_q;
  assign ram_size = size_q;
  assign ram_wdata = wdata_q;

  assign store_ack = state == S_ACK;
  assign store_rdata = result_q;

  always_ff @(posedge clk) begin
    if(rst) begin
      state <= S_IDLE;
      target_q <= MAP_NONE;
      we_q <= 1'b0;
      srt_q <= 1'b0;
      word_q <= 28'd0;
      boff_q <= 4'd0;
      size_q <= 6'd0;
      wdata_q <= 32'd0;
      result_q <= 32'd0;
    end else begin
      case(state)
        S_IDLE: if(store_req) begin
          target_q <= store_target;
          we_q <= store_we;
          srt_q <= store_srt;
          word_q <= store_word_addr;
          boff_q <= store_bit_offset;
          size_q <= store_size;
          wdata_q <= store_wdata;
          state <= S_START;
        end
        S_START: if(!vram_stall) state <= S_WAIT;
        S_WAIT: begin
          if((target_q == MAP_VRAM) && vram_done) begin
            result_q <= vram_rdata; state <= S_ACK;
          end else if((target_q == MAP_RAM) && ram_done) begin
            result_q <= ram_rdata; state <= S_ACK;
          end else if(local_owner && local_done) begin
            result_q <= local_rdata; state <= S_ACK;
          end else if((target_q != MAP_VRAM) && (target_q != MAP_RAM) &&
                      (target_q != MAP_CMOS) && (target_q != MAP_PALETTE)) begin
            result_q <= 32'd0; state <= S_ACK;
          end
        end
        S_ACK: state <= S_IDLE;
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
