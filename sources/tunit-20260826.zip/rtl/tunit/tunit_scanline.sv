// Four-line framebuffer window for the T-unit DDR3 VRAM backend.
//
// Unlike the older Y/Wolf helper, rows are tagged dynamically from the live
// TMS34010 display-address state. This preserves DUDATE/subrow behavior and
// page changes without an MK2-only FIRST_ROW or COL_TAP assumption.

`default_nettype none
module tunit_scanline #(
  parameter int NCOL = 512
)(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        ce_pix,
  input  wire logic        frame_reprime,
  input  wire logic [8:0]  display_row,
  input  wire logic [8:0]  next_row,
  input  wire logic [8:0]  next2_row,
  input  wire logic        active_pixel,
  input  wire logic        cpu_snoop_valid,
  input  wire logic [18:0] cpu_snoop_addr,
  input  wire logic [63:0] cpu_snoop_data,
  input  wire logic        cpu_snoop_pending,
  input  wire logic        cpu_snoop_overflow,

  input  wire logic [18:0] vram_raddr,
  output logic [15:0]      vram_rdata,
  output logic             vram_rvalid,

  output logic             scan_req,
  output logic [18:0]      scan_addr,
  input  wire logic [15:0] scan_data,
  input  wire logic        scan_ack,

  output logic             ready,
  output logic             underrun,
  output logic [31:0]      underrun_count
);
  localparam int NBEAT = (NCOL + 3) / 4;
  // NO no_rw_check HERE -- IT IS A FALSE PROMISE ON THESE ARRAYS.
  //
  // `no_rw_check` tells the fitter that no address is read and written in the same
  // cycle. That is FALSE for these line buffers: the video port reads
  // line0[vram_raddr[8:2]] every cycle while the snoop path writes the same
  // complete beat, and the snoop fires exactly when the incoming VRAM
  // write's tag matches the line currently cached (:142-149) -- i.e. precisely while
  // the video is displaying it. The two addresses can and do coincide.
  //
  // MEASURED consequence, from this project's own map.rpt: the fitter took the
  // promise and gave line0_rtl_0
  //     OPERATION_MODE = DUAL_PORT
  //     READ_DURING_WRITE_MODE_MIXED_PORTS = DONT_CARE
  // and Quartus documents DONT_CARE mixed-port collision output as UNDEFINED. Verilog
  // models the same collision as deterministic OLD data, so NO SIMULATION IN THIS TREE
  // CAN EVER EXHIBIT IT -- sim green, cabinet corrupt, CLAUDE.md section 6 exactly.
  //
  // Note the vendored guideline in docs/hdl-coding-guidelines/30 quotes "Quartus
  // ignores the no_rw_check RAMSTYLE for M10K BRAMs". This project's map.rpt shows it
  // did NOT ignore it. Trust the report over the reference.
  //
  // Found by the Gladiator session's audit of the identical pattern in their video
  // RAMs. Credit theirs; the collision proof and the map.rpt evidence are this tree's.
  // Store one aligned 64-bit framebuffer beat per RAM word.  This preserves
  // four logical rows (128x64 = 512x16 bits per row).  Cyclone V implements
  // each packed 64-bit logical row in two M10Ks; that physical cost buys a
  // one-clock coherent A/C/D beat update instead of a four-cycle serializer
  // that a burst writer can outrun.
  (* ramstyle = "M10K" *) logic [63:0] line0 [0:NBEAT-1];
  (* ramstyle = "M10K" *) logic [63:0] line1 [0:NBEAT-1];
  (* ramstyle = "M10K" *) logic [63:0] line2 [0:NBEAT-1];
  (* ramstyle = "M10K" *) logic [63:0] line3 [0:NBEAT-1];

  logic [8:0] tag0, tag1, tag2, tag3;
  logic valid0, valid1, valid2, valid3;
  logic partial_hit0,partial_hit1,partial_hit2,partial_hit3;
  wire logic hit0 = (valid0 && (tag0 == vram_raddr[17:9])) || partial_hit0;
  wire logic hit1 = (valid1 && (tag1 == vram_raddr[17:9])) || partial_hit1;
  wire logic hit2 = (valid2 && (tag2 == vram_raddr[17:9])) || partial_hit2;
  wire logic hit3 = (valid3 && (tag3 == vram_raddr[17:9])) || partial_hit3;
  // A software DPYADR override (Total Carnage's supported split-screen path)
  // can select a row outside the predicted +1/+2 window only 1,000 sysclks
  // before active video. A full 512-word publication cannot meet that bound,
  // but a progressively filled row can: expose only complete 64-bit beats and
  // keep normal miss/underrun behavior for every beat still in flight.
  wire logic pixel_ready = hit0 || hit1 || hit2 || hit3;
  wire logic current_ready = (valid0 && tag0 == display_row) ||
                             (valid1 && tag1 == display_row) ||
                             (valid2 && tag2 == display_row) ||
                             (valid3 && tag3 == display_row);
  wire logic next_ready = (next_row == display_row) ||
                          (valid0 && tag0 == next_row) ||
                          (valid1 && tag1 == next_row) ||
                          (valid2 && tag2 == next_row) ||
                          (valid3 && tag3 == next_row);
`ifdef MUT_TUNIT_SCAN_TWO_LINES
  // Exact old behavior for the adversarial gate: do not consume DDR service
  // for a second lookahead row.
  wire logic next2_ready = 1'b1;
`else
  wire logic next2_ready = (next2_row == display_row) ||
                           (next2_row == next_row) ||
                           (valid0 && tag0 == next2_row) ||
                           (valid1 && tag1 == next2_row) ||
                           (valid2 && tag2 == next2_row) ||
                           (valid3 && tag3 == next2_row);
`endif
  assign ready = current_ready && next_ready;

  function automatic logic [15:0] beat_lane(
      input logic [63:0] data,input logic [1:0] lane);
    case(lane)
      2'd0:beat_lane=data[15:0];
      2'd1:beat_lane=data[31:16];
      2'd2:beat_lane=data[47:32];
      default:beat_lane=data[63:48];
    endcase
  endfunction

  logic [63:0] line0_q, line1_q, line2_q, line3_q;
  logic hit0_q, hit1_q, hit2_q, hit3_q;
  logic [1:0] read_lane_q;
  logic line0_we, line1_we, line2_we, line3_we;
  logic [$clog2(NBEAT)-1:0] line0_waddr, line1_waddr;
  logic [$clog2(NBEAT)-1:0] line2_waddr, line3_waddr;
  logic [63:0] line0_wdata, line1_wdata, line2_wdata, line3_wdata;
  assign vram_rdata = hit0_q ? beat_lane(line0_q,read_lane_q) :
                      hit1_q ? beat_lane(line1_q,read_lane_q) :
                      hit2_q ? beat_lane(line2_q,read_lane_q) :
                      hit3_q ? beat_lane(line3_q,read_lane_q) : 16'd0;
  // Pixel index zero is a legal game colour (dark blue on the observed NBA
  // screens), so downstream scanout must not mistake a miss fallback for a
  // valid palette lookup.  These registered hits have the same latency as
  // vram_rdata.
  assign vram_rvalid = hit0_q || hit1_q || hit2_q || hit3_q;

  // Unconditional registered reads are the Quartus M10K inference shape.
  // The hit bits are sampled beside the address so the selected data still has
  // exactly one ce_pix latency, matching the original behavioral read.
  always_ff @(posedge clk) begin
    if (line0_we) line0[line0_waddr] <= line0_wdata;
    if (line1_we) line1[line1_waddr] <= line1_wdata;
    if (line2_we) line2[line2_waddr] <= line2_wdata;
    if (line3_we) line3[line3_waddr] <= line3_wdata;
    line0_q <= line0[vram_raddr[8:2]];
    line1_q <= line1[vram_raddr[8:2]];
    line2_q <= line2[vram_raddr[8:2]];
    line3_q <= line3[vram_raddr[8:2]];
    // The packed-word lane is part of the BRAM read address contract, so track
    // it at the same full system-clock rate as line*_q.  Sampling it only on
    // ce_pix adds a complete visible-pixel delay versus the original 512x16
    // stores and shifts RGB/DE alignment by one column.
    read_lane_q <= vram_raddr[1:0];
    if (rst) begin
      hit0_q <= 1'b0;
      hit1_q <= 1'b0;
      hit2_q <= 1'b0;
      hit3_q <= 1'b0;
      read_lane_q <= 2'd0;
      underrun <= 1'b0;
      underrun_count <= 32'd0;
    end else if (ce_pix) begin
      hit0_q <= hit0;
      hit1_q <= hit1;
      hit2_q <= hit2;
      hit3_q <= hit3;
      if (active_pixel && !pixel_ready) begin
        underrun <= 1'b1;
        underrun_count <= underrun_count + 32'd1;
      end
    end
  end

  logic loading;
  logic fill_complete;
  logic [1:0] target_sel;
  logic [8:0] target_row;
  logic [8:0] load_col;
  // Completeness/ownership bitmap for the in-progress victim. A bit becomes
  // readable after either its scan beat commits or a newer A/C/D publication
  // writes the whole beat; the same bit suppresses any later stale scan data.
  logic [NBEAT-1:0] target_snoop_beats;
  logic [63:0] fill_beat_data;
  logic        fill_beat_pending;
  logic [$clog2(NBEAT)-1:0] fill_beat_addr;
  logic [63:0] fill_beat_wdata;
  logic [8:0] observed_row, previous_row;
  logic previous_valid;
  wire logic previous_keep_valid = previous_valid ||
                                   (display_row != observed_row);
  wire logic [8:0] previous_keep_row =
      (display_row != observed_row) ? observed_row : previous_row;
  logic snoop_overflow;
  always_comb begin
    partial_hit0 = loading && (target_sel == 2'd0) &&
                   (target_row == vram_raddr[17:9]) &&
                   target_snoop_beats[vram_raddr[8:2]];
    partial_hit1 = loading && (target_sel == 2'd1) &&
                   (target_row == vram_raddr[17:9]) &&
                   target_snoop_beats[vram_raddr[8:2]];
    partial_hit2 = loading && (target_sel == 2'd2) &&
                   (target_row == vram_raddr[17:9]) &&
                   target_snoop_beats[vram_raddr[8:2]];
    partial_hit3 = loading && (target_sel == 2'd3) &&
                   (target_row == vram_raddr[17:9]) &&
                   target_snoop_beats[vram_raddr[8:2]];
  end
  // Compatibility observation used by existing benches: the upstream
  // publication FIFO is now the only queue; the wide line RAM consumes one
  // complete beat per clock and needs no local serializer occupancy.
  wire logic [2:0] snoop_count = cpu_snoop_pending ? 3'd1 : 3'd0;

  // A live DPYADR write can replace the predicted raster sequence at any
  // line.  Continue a fill only while it is still the highest-priority row
  // missing from the cache.  This both cancels obsolete speculation and lets
  // a newly selected current row preempt an otherwise-still-useful lookahead.
`ifdef MUT_TUNIT_SCAN_NO_RETARGET_ABORT
  wire logic target_is_priority = 1'b1;
`else
  wire logic target_is_priority =
      (target_row == display_row) ||
      (current_ready && (target_row == next_row)) ||
      (current_ready && next_ready && (target_row == next2_row));
`endif
  wire logic scan_response = loading && !fill_complete &&
                             !fill_beat_pending && scan_req && scan_ack;
  wire logic scan_commit = scan_response && target_is_priority;
`ifdef MUT_TUNIT_SCAN_NO_FILL_SNOOP
  wire logic snoop_hits_loading = 1'b0;
`else
  wire logic snoop_hits_loading = loading && cpu_snoop_valid &&
                                  (cpu_snoop_addr[17:9] == target_row);
`endif
  wire logic snoop_hits_target_beat = snoop_hits_loading &&
                                      (cpu_snoop_addr[8:2] == fill_beat_addr);
  // Keep this observation point for the four-corner physical cone audit.
  // A complete scan beat is published only after its four 16-bit returns have
  // accumulated and only if no newer writer publication owns that beat.
  (* keep *) wire logic scan_write = fill_beat_pending &&
                                   !target_snoop_beats[fill_beat_addr] &&
                                   !snoop_hits_loading;

  function automatic logic [1:0] choose_victim(
      input logic [8:0] keep0,input logic [8:0] keep1,
      input logic [8:0] keep2);
    begin
      if (!valid0) choose_victim = 2'd0;
      else if (!valid1) choose_victim = 2'd1;
      else if (!valid2) choose_victim = 2'd2;
`ifndef MUT_TUNIT_SCAN_THREE_LINES
      else if (!valid3) choose_victim = 2'd3;
      else if ((tag0 != keep0) && (tag0 != keep1) && (tag0 != keep2))
        choose_victim = 2'd0;
      else if ((tag1 != keep0) && (tag1 != keep1) && (tag1 != keep2))
        choose_victim = 2'd1;
      else if ((tag2 != keep0) && (tag2 != keep1) && (tag2 != keep2))
        choose_victim = 2'd2;
      else choose_victim = 2'd3;
`else
      else if ((tag0 != keep0) && (tag0 != keep1)) choose_victim = 2'd0;
      else if ((tag1 != keep0) && (tag1 != keep1)) choose_victim = 2'd1;
      else choose_victim = 2'd2;
`endif
    end
  endfunction

  // Keep each line store to one syntactic write site.  A coherent full-beat
  // publication has priority only on the row it touches; an unrelated row may
  // commit its accumulated scan beat in the same clock through another M10K.
  always_comb begin
    line0_we = 1'b0;
    line1_we = 1'b0;
    line2_we = 1'b0;
    line3_we = 1'b0;
    line0_waddr = '0;
    line1_waddr = '0;
    line2_waddr = '0;
    line3_waddr = '0;
    line0_wdata = 64'd0;
    line1_wdata = 64'd0;
    line2_wdata = 64'd0;
    line3_wdata = 64'd0;
    if (cpu_snoop_valid &&
          ((valid0 && (tag0 == cpu_snoop_addr[17:9]))
`ifndef MUT_TUNIT_SCAN_NO_FILL_SNOOP
          || (loading && (target_sel == 2'd0) &&
              (target_row == cpu_snoop_addr[17:9]))
`endif
          )) begin
      line0_we = 1'b1;
      line0_waddr = cpu_snoop_addr[8:2];
      line0_wdata = cpu_snoop_data;
    end else if (scan_write && (target_sel == 2'd0)) begin
      line0_we = 1'b1;
      line0_waddr = fill_beat_addr;
      line0_wdata = fill_beat_wdata;
    end
    if (cpu_snoop_valid &&
          ((valid1 && (tag1 == cpu_snoop_addr[17:9]))
`ifndef MUT_TUNIT_SCAN_NO_FILL_SNOOP
          || (loading && (target_sel == 2'd1) &&
              (target_row == cpu_snoop_addr[17:9]))
`endif
          )) begin
      line1_we = 1'b1;
      line1_waddr = cpu_snoop_addr[8:2];
      line1_wdata = cpu_snoop_data;
    end else if (scan_write && (target_sel == 2'd1)) begin
      line1_we = 1'b1;
      line1_waddr = fill_beat_addr;
      line1_wdata = fill_beat_wdata;
    end
    if (cpu_snoop_valid &&
          ((valid2 && (tag2 == cpu_snoop_addr[17:9]))
`ifndef MUT_TUNIT_SCAN_NO_FILL_SNOOP
          || (loading && (target_sel == 2'd2) &&
              (target_row == cpu_snoop_addr[17:9]))
`endif
          )) begin
      line2_we = 1'b1;
      line2_waddr = cpu_snoop_addr[8:2];
      line2_wdata = cpu_snoop_data;
    end else if (scan_write && (target_sel == 2'd2)) begin
      line2_we = 1'b1;
      line2_waddr = fill_beat_addr;
      line2_wdata = fill_beat_wdata;
    end
    if (cpu_snoop_valid &&
          ((valid3 && (tag3 == cpu_snoop_addr[17:9]))
`ifndef MUT_TUNIT_SCAN_NO_FILL_SNOOP
          || (loading && (target_sel == 2'd3) &&
              (target_row == cpu_snoop_addr[17:9]))
`endif
          )) begin
      line3_we = 1'b1;
      line3_waddr = cpu_snoop_addr[8:2];
      line3_wdata = cpu_snoop_data;
    end else if (scan_write && (target_sel == 2'd3)) begin
      line3_we = 1'b1;
      line3_waddr = fill_beat_addr;
      line3_wdata = fill_beat_wdata;
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      valid0 <= 1'b0;
      valid1 <= 1'b0;
      valid2 <= 1'b0;
      valid3 <= 1'b0;
      tag0 <= 9'd0;
      tag1 <= 9'd0;
      tag2 <= 9'd0;
      tag3 <= 9'd0;
      loading <= 1'b0;
      fill_complete <= 1'b0;
      target_sel <= 2'd0;
      target_row <= 9'd0;
      load_col <= 9'd0;
      target_snoop_beats <= '0;
      fill_beat_data <= 64'd0;
      fill_beat_pending <= 1'b0;
      fill_beat_addr <= '0;
      fill_beat_wdata <= 64'd0;
      observed_row <= display_row;
      previous_row <= 9'd0;
      previous_valid <= 1'b0;
      scan_req <= 1'b0;
      scan_addr <= 19'd0;
      snoop_overflow <= 1'b0;
    end else begin
      if (frame_reprime) begin
        observed_row <= display_row;
        previous_row <= 9'd0;
        previous_valid <= 1'b0;
      end else if (display_row != observed_row) begin
        previous_row <= observed_row;
        previous_valid <= 1'b1;
        observed_row <= display_row;
      end
      if (frame_reprime) begin
        valid0 <= 1'b0;
        valid1 <= 1'b0;
        valid2 <= 1'b0;
        valid3 <= 1'b0;
        loading <= 1'b0;
        fill_complete <= 1'b0;
        scan_req <= 1'b0;
        target_snoop_beats <= '0;
        fill_beat_pending <= 1'b0;
        fill_beat_data <= 64'd0;
      end else if (loading && !target_is_priority) begin
        // Cancel before accepting a response for the stale target.  The lower
        // row cache latches its own miss identity and safely drains it; dropping
        // scan_req prevents that old response from being committed here.  The
        // next cycle selects the new current/next/next2 priority.
        loading <= 1'b0;
        fill_complete <= 1'b0;
        scan_req <= 1'b0;
        target_snoop_beats <= '0;
        fill_beat_pending <= 1'b0;
        fill_beat_data <= 64'd0;
      end else if (!loading) begin
        scan_req <= 1'b0;
        if (!current_ready) begin
          target_sel <= choose_victim(
              next_row,next2_row,
              previous_keep_valid ? previous_keep_row : next_row);
          target_row <= display_row;
          load_col <= 9'd0;
          scan_addr <= {1'b0, display_row, 9'd0};
          loading <= 1'b1;
          fill_complete <= 1'b0;
          target_snoop_beats <= '0;
          fill_beat_pending <= 1'b0;
          fill_beat_data <= 64'd0;
`ifndef MUT_TUNIT_SCAN_KEEP_VICTIM_VALID
          case (choose_victim(
              next_row,next2_row,
              previous_keep_valid ? previous_keep_row : next_row))
            2'd3: valid3 <= 1'b0;
            2'd2: valid2 <= 1'b0;
            2'd1: valid1 <= 1'b0;
            default: valid0 <= 1'b0;
          endcase
`endif
        end else if (!next_ready) begin
          target_sel <= choose_victim(
              display_row,next2_row,
              previous_keep_valid ? previous_keep_row : display_row);
          target_row <= next_row;
          load_col <= 9'd0;
          scan_addr <= {1'b0, next_row, 9'd0};
          loading <= 1'b1;
          fill_complete <= 1'b0;
          target_snoop_beats <= '0;
          fill_beat_pending <= 1'b0;
          fill_beat_data <= 64'd0;
`ifndef MUT_TUNIT_SCAN_KEEP_VICTIM_VALID
          case (choose_victim(
              display_row,next2_row,
              previous_keep_valid ? previous_keep_row : display_row))
            2'd3: valid3 <= 1'b0;
            2'd2: valid2 <= 1'b0;
            2'd1: valid1 <= 1'b0;
            default: valid0 <= 1'b0;
          endcase
`endif
        end else if (!next2_ready) begin
          target_sel <= choose_victim(
              display_row,next_row,
              previous_keep_valid ? previous_keep_row : display_row);
          target_row <= next2_row;
          load_col <= 9'd0;
          scan_addr <= {1'b0, next2_row, 9'd0};
          loading <= 1'b1;
          fill_complete <= 1'b0;
          target_snoop_beats <= '0;
          fill_beat_pending <= 1'b0;
          fill_beat_data <= 64'd0;
`ifndef MUT_TUNIT_SCAN_KEEP_VICTIM_VALID
          case (choose_victim(
              display_row,next_row,
              previous_keep_valid ? previous_keep_row : display_row))
            2'd3: valid3 <= 1'b0;
            2'd2: valid2 <= 1'b0;
            2'd1: valid1 <= 1'b0;
            default: valid0 <= 1'b0;
          endcase
`endif
        end
      end else if (fill_complete) begin
        scan_req <= 1'b0;
        if (!cpu_snoop_pending && !cpu_snoop_valid && !snoop_overflow) begin
          if (target_sel == 2'd3) begin tag3 <= target_row; valid3 <= 1'b1; end
          else if (target_sel == 2'd2) begin tag2 <= target_row; valid2 <= 1'b1; end
          else if (target_sel == 2'd1) begin tag1 <= target_row; valid1 <= 1'b1; end
          else begin tag0 <= target_row; valid0 <= 1'b1; end
          loading <= 1'b0;
          fill_complete <= 1'b0;
        end
      end else if (fill_beat_pending) begin
        scan_req <= 1'b0;
        // A newer complete publication already wrote this beat, or is doing so
        // on this edge.  Discard the accumulated older scan data.  Otherwise
        // scan_write commits it through the victim M10K's sole write site.
        if (target_snoop_beats[fill_beat_addr] || snoop_hits_target_beat ||
            scan_write) begin
          if (scan_write)
            target_snoop_beats[fill_beat_addr] <= 1'b1;
          fill_beat_pending <= 1'b0;
          if (load_col == NCOL-1) begin
            fill_complete <= 1'b1;
          end else begin
            load_col <= load_col + 9'd1;
            scan_addr <= {1'b0, target_row, load_col + 9'd1};
          end
        end
      end else if (scan_commit) begin
        scan_req <= 1'b0;
        case (load_col[1:0])
          2'd0: fill_beat_data[15:0] <= scan_data;
          2'd1: fill_beat_data[31:16] <= scan_data;
          2'd2: fill_beat_data[47:32] <= scan_data;
          default: fill_beat_data[63:48] <= scan_data;
        endcase
        if (load_col[1:0] == 2'd3) begin
          if (target_snoop_beats[load_col[8:2]] ||
              (snoop_hits_loading &&
               (cpu_snoop_addr[8:2] == load_col[8:2]))) begin
            if (load_col == NCOL-1) begin
              fill_complete <= 1'b1;
            end else begin
              load_col <= load_col + 9'd1;
              scan_addr <= {1'b0, target_row, load_col + 9'd1};
            end
          end else begin
            fill_beat_addr <= load_col[8:2];
            fill_beat_wdata <= {scan_data,fill_beat_data[47:0]};
            fill_beat_pending <= 1'b1;
          end
        end else begin
          load_col <= load_col + 9'd1;
          scan_addr <= {1'b0, target_row, load_col + 9'd1};
        end
      end else if (!scan_req) begin
        scan_req <= 1'b1;
      end

      if (cpu_snoop_overflow)
        snoop_overflow <= 1'b1;

`ifndef MUT_TUNIT_SCAN_NO_FILL_SNOOP
      // Mark a complete publication as soon as it targets this fill.  Every
      // later older scan word in the same beat is then suppressed.
      if (loading && cpu_snoop_valid &&
          (cpu_snoop_addr[17:9] == target_row)) begin
        target_snoop_beats[cpu_snoop_addr[8:2]] <= 1'b1;
      end
`endif
    end
  end
endmodule
`default_nettype wire
