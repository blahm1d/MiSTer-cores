// Line-cached request/response bridge between the 12 MHz Williams ADPCM board
// and the 80 MHz sound-DDR client.  The board holds snd_addr stable until
// snd_ok; toggle handshakes make that bundled-data contract explicit.
//
// WHY A LINE CACHE (2026-08-09).
//
// The previous revision cached exactly ONE byte at ONE address, so every change
// of snd_addr cost a full CDC round trip plus a DDR3 round trip, with the 6809's
// entire E/Q generator frozen for the duration (tunit_adpcm_board.sv:105).  That
// is the worst possible shape of client for the DDR3 port it sits on, where it
// is also the LOWEST priority requester behind the framebuffer and a 12 MiB
// graphics ROM (tunit_ddr3_arb.sv:39-44).
//
// Two measurements drove this change:
//
//  * jt6295 re-presents the SAME byte address on two consecutive visits of a
//    voice (jt6295_serial.v:174,195 -- rom_addr is cnt[18:1] and the nibble
//    select is cnt[0]), and four voices plus the phrase-header stream interleave
//    between those visits.  A single-entry cache is therefore evicted before the
//    second visit every time, so the hardware paid two round trips for every
//    byte it actually needed once.
//  * tunit_sound_ddr_multi.sv:178 ALREADY fetches a full 64-bit DDR3 word for
//    every one of those bytes (agent_addr = adpcm_addr[20:3]) and then discards
//    seven eighths of it at :205.  The line was always being paid for.
//
// So this holds NLINE 8-byte lines, direct mapped, filled from the 64-bit word
// the sound-DDR client already reads.  DDR3 traffic per fill is unchanged; the
// number of fills drops by up to 8x on sequential sample data and by 7x on a
// phrase header, whose seven bytes (jt6295_ctrl.v:122 {phrase, addr_lsb}) all
// land inside one aligned line.
//
// Eight lines, not one, because five streams interleave: four ADPCM voices and
// the control-table reader.  Indexing on snd_addr[5:3] keeps concurrent voices
// in separate lines instead of thrashing a single entry.
//
// The proven precedent is the Y-unit core, whose Williams sound boards run from
// SDRAM behind exactly this shape of cache and are cabinet-clean:
// "Keep the current word and prefetch the following word so sequential 6809/OKI
//  traffic normally completes without stretching the 12 MHz board clock"
// (Arcade-SmashTV_MiSTer rtl/yunit/yunit_sound_rom_cache.sv:1-6).

`default_nettype none
module tunit_adpcm_rom_cdc #(
  // 8 lines x 8 bytes.  One line is exactly one DDR3 beat.
  parameter int NLINE_LG2 = 3
)(
  input  wire logic        clk_snd,
  input  wire logic        clk_sys,
  input  wire logic        rst_pon,
  // System-domain ROM-image epoch fence. This is deliberately separate from
  // the Williams board's FE/FF reset: a board reset must not evict immutable
  // ROM, while a same-RBF loader transaction must evict every preimage line.
  input  wire logic        epoch_reset_sys,

  input  wire logic [20:0] snd_addr,
  output logic [7:0]       snd_data,
  output logic             snd_ok,

  output logic             sys_req,
  output logic [20:0]      sys_addr,
  input  wire logic [63:0] sys_line,
  input  wire logic        sys_ack
);
  localparam int NLINE  = 1 << NLINE_LG2;
  // byte-in-line = [2:0], line index = [2+NLINE_LG2 : 3], tag = the rest
  localparam int IDX_HI = 2 + NLINE_LG2;
  localparam int TAG_W  = 21 - (IDX_HI + 1);

`ifdef MUT_TUNIT_ADPCM_CACHE_EPOCH_REVERT
  // Mutation arm: restore the stale-cache failure by ignoring image epochs.
  wire logic cache_reset = rst_pon;
`else
  wire logic cache_reset = rst_pon || epoch_reset_sys;
`endif

  logic [2:0] snd_rst_pipe = 3'b111;
  wire logic snd_rst = snd_rst_pipe[2];

  // BUNDLED-DATA PAYLOADS ARE PRESERVED.  set_clock_groups -asynchronous makes
  // STA ignore this crossing entirely, INCLUDING the skew between payload bits,
  // so the only protection is an explicit set_max_skew -- and that collection
  // silently comes back empty if the fitter merges or duplicates these
  // registers.  A Y-unit RBF shipped with exactly that: sndrom_max_skew rows=0
  // expected=2, constraint skipped, crossing unconstrained on silicon.
  logic req_toggle;
  (* preserve *) logic [20:0] request_addr;
  logic request_pending;
  (* preserve, async_reg = "true" *) logic [1:0] rsp_sync;
  logic rsp_seen;

  (* preserve, async_reg = "true" *) logic [1:0] req_sync;
  logic req_seen;
  logic rsp_toggle;
  (* preserve *) logic [63:0] response_line;

  logic [63:0]      line_data [0:NLINE-1];
  logic [TAG_W-1:0] line_tag  [0:NLINE-1];
  logic             line_valid[0:NLINE-1];

  wire [NLINE_LG2-1:0] req_idx = snd_addr[IDX_HI:3];
  wire [TAG_W-1:0]     req_tag = snd_addr[20:IDX_HI+1];
  wire [2:0]           req_off = snd_addr[2:0];

`ifdef MUT_ADPCM_BYTE_CACHE
  // MUTATION ARM = the shipped behaviour this change replaces: one entry keyed
  // on the exact BYTE address, so any change of snd_addr is a miss.  The gate
  // must show this arm taking many more DDR3 round trips and losing the 6809
  // rate at a latency the production arm survives.  If it does not, the
  // production cache is not doing the work its comment claims.
  logic [20:0] byte_tag;
  logic        byte_valid;
  wire hit = byte_valid && (byte_tag == snd_addr);
`else
  wire hit = line_valid[req_idx] && (line_tag[req_idx] == req_tag);
`endif

  assign snd_ok   = hit;
  assign snd_data = line_data[req_idx][8*req_off +: 8];

  wire [NLINE_LG2-1:0] fill_idx = request_addr[IDX_HI:3];
  wire [TAG_W-1:0]     fill_tag = request_addr[20:IDX_HI+1];

  // Assert immediately when the system-domain image fence rises; release only
  // after three clk_snd edges. The cache, request toggle and pending bundled
  // payload are therefore all dead for the complete loader/backend epoch.
  always_ff @(posedge clk_snd or posedge cache_reset) begin
    if (cache_reset) snd_rst_pipe <= 3'b111;
    else snd_rst_pipe <= {snd_rst_pipe[1:0], 1'b0};
  end

  integer li;
  always_ff @(posedge clk_snd) begin
    if (snd_rst) begin
      req_toggle <= 1'b0;
      request_addr <= 21'd0;
      request_pending <= 1'b0;
      rsp_sync <= 2'b00;
      rsp_seen <= 1'b0;
      for (li = 0; li < NLINE; li = li + 1) begin
        line_valid[li] <= 1'b0;
        line_tag[li]   <= '0;
        line_data[li]  <= 64'd0;
      end
`ifdef MUT_ADPCM_BYTE_CACHE
      byte_tag <= 21'd0;
      byte_valid <= 1'b0;
`endif
    end else begin
      rsp_sync <= {rsp_sync[0], rsp_toggle};

      // A miss launches exactly one outstanding fill.  snd_addr is stable for
      // the whole round trip by the board's bundled-data contract, but the fill
      // is completed against request_addr, not the live address, so a board
      // reset that retargets mid-flight cannot mislabel the line.
      if (!request_pending && !hit) begin
        request_addr <= snd_addr;
        request_pending <= 1'b1;
        req_toggle <= ~req_toggle;
      end

      if (rsp_sync[1] != rsp_seen) begin
        rsp_seen <= rsp_sync[1];
        line_data[fill_idx]  <= response_line;
        line_tag[fill_idx]   <= fill_tag;
        line_valid[fill_idx] <= 1'b1;
        request_pending <= 1'b0;
`ifdef MUT_ADPCM_BYTE_CACHE
        byte_tag <= request_addr;
        byte_valid <= 1'b1;
`endif
      end
    end
  end

  always_ff @(posedge clk_sys) begin
    if (cache_reset) begin
      req_sync <= 2'b00;
      req_seen <= 1'b0;
      rsp_toggle <= 1'b0;
      sys_req <= 1'b0;
      sys_addr <= 21'd0;
      response_line <= 64'd0;
    end else begin
      req_sync <= {req_sync[0], req_toggle};

      if (!sys_req && (req_sync[1] != req_seen)) begin
        req_seen <= req_sync[1];
        sys_addr <= request_addr;
        sys_req <= 1'b1;
      end

      if (sys_req && sys_ack) begin
        response_line <= sys_line;
        sys_req <= 1'b0;
        rsp_toggle <= req_seen;
      end
    end
  end
endmodule
`default_nettype wire
