// Loader, persistence, cabinet inputs, and synthesizable T-unit board core.

`default_nettype none
module tunit_board
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
(
  input  wire logic clk,input wire logic clk_snd,input wire logic rst_pon,input wire logic rst_game,
  input  wire logic pll_locked,input wire logic sdram_ready,

  input  wire logic ioctl_download,input wire logic ioctl_upload,input wire logic ioctl_wr,
  input  wire logic[7:0]ioctl_index,input wire logic[24:0]ioctl_addr,input wire logic[7:0]ioctl_dout,
  output logic ioctl_wait,output logic[7:0]ioctl_din,output logic ioctl_upload_req,
  input  wire logic autosave,input wire logic manual_save,input wire logic clear_nvram,input wire logic osd_status,

  input  wire logic[15:0]joystick_0,input wire logic[15:0]joystick_1,
  input  wire logic[15:0]joystick_2,input wire logic[15:0]joystick_3,
  input  wire logic service,input wire logic service_credit,input wire logic tilt,
  input  wire logic volume_up,input wire logic volume_down,input wire logic ejb_trigger,

  output logic[24:0]sdram_addr,output logic[15:0]sdram_din,output logic[1:0]sdram_be,
  output logic sdram_rd,output logic sdram_wr,input wire logic[15:0]sdram_dout,input wire logic sdram_ack,
  output logic[28:0]ddram_addr,output logic[7:0]ddram_burstcnt,output logic ddram_rd,output logic ddram_we,
  output logic[63:0]ddram_din,output logic[7:0]ddram_be,input wire logic ddram_busy,
  input  wire logic[63:0]ddram_dout,input wire logic ddram_dout_ready,

  output logic[7:0]vid_r,vid_g,vid_b,output logic hsync,vsync,hblank,vblank,de,ce_pixel,
  output logic signed[15:0]audio,output logic audio_ce,

  output tunit_profile_t profile,output logic profile_valid,output logic[3:0]complete_mask,
  output logic[7:0]descriptor_error,output logic[31:0]loader_accepted,loader_dropped,
  output logic[31:0]cpu_pc,output logic cpu_illegal,output logic[7:0]reset_reason,
  output logic rst_cpu,output logic dma_busy,output logic loader_or_backend_busy,
  output logic video_underrun,output logic[31:0]video_underrun_count,
  output logic audio_underrun,output logic audio_overrun,
  output logic[31:0]audio_tel_a,audio_tel_b,audio_tel_c,audio_tel_d,
  output logic[13:0]adsp_pc,output logic adsp_valid,output logic adsp_unimplemented,
  output logic nvram_dirty,
  output logic[31:0]dbg_blit_hold_max,dbg_wr_hold_max,dbg_commit_count,
  output logic[31:0]dbg_blitq,dbg_page_state
);
  logic dip_wr;logic[24:0]dip_addr;logic[7:0]dip_data;
  logic prog_wr,gfx_wr,snd_wr,prog_ready,gfx_ready,snd_ready;
  logic[18:0]prog_addr;logic[15:0]prog_wdata;logic[1:0]prog_be;
  logic[23:0]gfx_addr,snd_addr;logic[7:0]gfx_wdata,snd_wdata;
  logic loader_busy,loader_rst_cpu,loader_rst_sound;
  tunit_variant_t variant;

  tunit_loader loader(
    .clk,.rst_pon,.rst_game,.ioctl_download,.ioctl_wr,.ioctl_index,.ioctl_addr,.ioctl_data(ioctl_dout),.ioctl_wait,
    .dip_wr,.dip_addr,.dip_data,.prog_wr,.prog_addr,.prog_wdata,.prog_be,.prog_ready,
    .gfx_wr,.gfx_addr,.gfx_wdata,.gfx_ready,.snd_wr,.snd_addr,.snd_wdata,.snd_ready,
    .profile,.variant,.profile_valid,.loader_busy,.rst_cpu(loader_rst_cpu),.rst_sound(loader_rst_sound),
    .accepted_count(loader_accepted),.dropped_count(loader_dropped),.complete_mask,.descriptor_error);

  logic[7:0]dip_lo,dip_hi;
  always_ff @(posedge clk) begin
    if(rst_pon)begin dip_lo<=8'h7d;dip_hi<=8'hfc;end
    else if(dip_wr)begin
      if(dip_addr==0)dip_lo<=dip_data;
      else if(dip_addr==1)dip_hi<=dip_data;
    end
  end
  logic[15:0]in0,in1,in2,dsw;
  tunit_inputs inputs(
    .clk,.rst_pon,.profile,.joystick_0_raw(joystick_0),.joystick_1_raw(joystick_1),
    .joystick_2_raw(joystick_2),.joystick_3_raw(joystick_3),
    .service_raw(service),.service_credit_raw(service_credit),.tilt_raw(tilt),
    .volume_up_raw(volume_up),.volume_down_raw(volume_down),
    .ejb_trigger_raw(ejb_trigger),.vblank_raw(vblank),
    .dsw({dip_hi,dip_lo}),.in0,.in1,.in2,.dsw_o(dsw));

  logic nvram_ext_wr,nvram_loading,nvram_write_pulse;
  logic[13:0]nvram_ext_addr;logic[7:0]nvram_ext_wdata,nvram_ext_rdata;
  tunit_nvram_bridge nvram_bridge(
    .clk,.rst_pon,.ioctl_download,.ioctl_upload,.ioctl_wr,.ioctl_index,.ioctl_addr,.ioctl_dout,
    .ioctl_din,.ioctl_upload_req,.autosave,.manual_save,.clear_nvram,.osd_status,
    .cpu_write_pulse(nvram_write_pulse),.nvram_ext_wr,.nvram_ext_addr,.nvram_ext_wdata,
    .nvram_ext_rdata,.nvram_loading,.nvram_dirty);

  // The loader owns release ordering: descriptor, all three ROM payloads, and
  // any queued backend writes must be complete before the core may run.
  wire logic board_game_reset=rst_game||nvram_loading||loader_rst_cpu;
  tunit_top core(
    .clk_snd,
    .clk,.rst_pon,.rst_game(board_game_reset),.pll_locked,.sdram_ready,.profile,.variant,.profile_valid,.loader_busy,
    .loader_rst_sound,
    .in0,.in1,.in2,.dsw,.prog_wr,.prog_addr,.prog_wdata,.prog_be,.prog_ready,
    .gfx_wr,.gfx_addr,.gfx_wdata,.gfx_ready,.snd_wr,.snd_addr,.snd_wdata,.snd_ready,
    .nvram_ext_wr,.nvram_ext_addr,.nvram_ext_wdata,.nvram_ext_rdata,.nvram_write_pulse,
    .sdram_addr,.sdram_din,.sdram_be,.sdram_rd,.sdram_wr,.sdram_dout,.sdram_ack,
    .ddram_addr,.ddram_burstcnt,.ddram_rd,.ddram_we,.ddram_din,.ddram_be,.ddram_busy,.ddram_dout,.ddram_dout_ready,
    .vid_r,.vid_g,.vid_b,.hsync,.vsync,.hblank,.vblank,.de,.ce_pixel_o(ce_pixel),.audio,.audio_ce,
    .cpu_pc,.cpu_illegal,.reset_reason,.rst_cpu_o(rst_cpu),.dma_busy,.loader_or_backend_busy,
    .video_underrun,.video_underrun_count,.audio_underrun,.audio_overrun,.audio_tel_a,.audio_tel_b,.audio_tel_c,.audio_tel_d,.adsp_pc,.adsp_valid,.adsp_unimplemented,
    .dbg_blit_hold_max,.dbg_wr_hold_max,.dbg_commit_count,.dbg_blitq,
    .dbg_page_state);
endmodule
`default_nettype wire
