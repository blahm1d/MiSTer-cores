// T-unit video/control latch (MAME 0.287 midtunit_control_w).

`default_nettype none
module tunit_control(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        wr,
  input  wire logic [15:0] wdata,
  input  wire logic [1:0]  byte_en,
  input  wire logic        gfx_rom_large,
  output logic [15:0] control,
  output logic        video_bank,
  output logic [23:0] gfx_bank_offset
);
  always_ff @(posedge clk) begin
    if (rst) control <= 16'h0000;
    else if (wr) begin
      if (byte_en[0]) control[7:0] <= wdata[7:0];
      if (byte_en[1]) control[15:8] <= wdata[15:8];
    end
  end
  assign video_bank = control[5];
  assign gfx_bank_offset = (gfx_rom_large && control[7]) ? 24'h800000 : 24'h000000;
endmodule
`default_nettype wire
