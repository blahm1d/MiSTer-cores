// Synthesizable local T-unit storage for CMOS and xRGB1555 palette RAM.
// Main RAM and VRAM remain on their external latency-tolerant backends.

`default_nettype none
module tunit_local_store
  import tunit_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        req,
  input  wire logic        we,
  input  wire tunit_map_target_t target,
  input  wire logic [27:0] word_addr,
  input  wire logic [3:0]  bit_offset,
  input  wire logic [5:0]  size,
  input  wire logic [31:0] wdata,
  output logic [31:0]      rdata,
  output logic             done,

  input  wire logic        nvram_ext_wr,
  input  wire logic [13:0] nvram_ext_addr,
  input  wire logic [7:0]  nvram_ext_wdata,
  output logic [7:0]       nvram_ext_rdata,
  output logic             nvram_write_pulse,

  input  wire logic [14:0] palette_scan_addr,
  output logic [15:0]      palette_scan_data
);
  localparam int CMOS_WORDS = 8192;
  localparam int PAL_WORDS  = 32768;

  // NO no_rw_check: nvram_mem has TWO write ports (external at :97/:99 and CPU at
  // :101) and two read ports on independent addresses, so read-during-write is
  // structurally reachable. Lower severity than the palette because NVRAM is not
  // scanned per-pixel, but an undefined read is never acceptable in battery-backed
  // storage -- a corrupted CMOS read is how a core loses its settings or fails a
  // checksum on boot.
  (* ramstyle = "M10K" *) logic [15:0] nvram_mem [0:CMOS_WORDS-1];
  // NO no_rw_check: the video port reads palette[palette_scan_addr] EVERY cycle
  // (:114) on a DIFFERENT address from the CPU write palette[cpu_mem_addr] (:110),
  // so this is a genuine mixed-port read-during-write and the addresses collide
  // whenever the CPU writes the entry currently being scanned out. The Gladiator
  // session measured 84-86% of such writes landing during ACTIVE display, not
  // blanking. Under no_rw_check the fitter is free to pick DONT_CARE, whose
  // collision output Quartus documents as UNDEFINED, while Verilog models it as
  // deterministic old data -- so simulation can never show it and only the cabinet
  // can. This project's own map.rpt confirmed the sibling array line0_rtl_0 got
  // exactly DONT_CARE, so the risk is measured here, not hypothetical.
  (* ramstyle = "M10K" *) logic [15:0] palette [0:PAL_WORDS-1];

  integer nv_i;
`ifndef SYNTHESIS
  initial begin
    // Simulation starts from the same clean CMOS image as an uninitialized
    // Cyclone-V block RAM. Quartus 17 cannot elaborate initialization loops
    // longer than 5000 iterations, so synthesis relies on M10K power-up zero
    // and the index-4 MiSTer persistence load.
    for (nv_i = 0; nv_i < CMOS_WORDS; nv_i = nv_i + 1)
      nvram_mem[nv_i] = 16'h0000;
  end
`endif

  typedef enum logic [2:0] {L_IDLE,L_ADDR,L_WAIT,L_CAP,L_WRITE,L_FIN} lstate_t;
  lstate_t state;
  logic we_q;
  tunit_map_target_t target_q;
  logic [27:0] rel_q;
  logic [3:0] boff_q;
  logic [5:0] size_q;
  logic [31:0] wdata_q;
  logic [47:0] field_mask_q;
  logic [47:0] write_mask_q;
  logic [47:0] shifted_wdata_q;
  logic [1:0] index;
  logic [15:0] old0,old1,old2;
  logic [14:0] array_addr;
  logic [15:0] nvram_cpu_q, palette_cpu_q;
  logic [15:0] nvram_ext_q;
  logic nvram_ext_lane_q;

  wire logic target_cmos = target_q == MAP_CMOS;
  wire logic target_pal  = target_q == MAP_PALETTE;
  wire logic word_valid = target_cmos ? ((rel_q + index) < CMOS_WORDS) :
                          target_pal  ? ((rel_q + index) < PAL_WORDS)  : 1'b0;
  wire logic [5:0] last_bit = boff_q + size_q - 6'd1;
  wire logic [1:0] words_touched = (size_q == 0) ? 2'd0 :
                                   (last_bit < 16) ? 2'd1 :
                                   (last_bit < 32) ? 2'd2 : 2'd3;
  wire logic [47:0] old_window = {old2,old1,old0};
  wire logic [47:0] merged = (old_window & ~write_mask_q) |
                              (shifted_wdata_q & write_mask_q);

  wire logic local_write = (state == L_WRITE) && word_valid;
  wire logic nvram_cpu_we = local_write && target_cmos && !nvram_ext_wr;
  wire logic palette_cpu_we = local_write && target_pal;
  wire logic [14:0] cpu_mem_addr = (state == L_WRITE)
                                  ? 15'(rel_q + index) : array_addr;
  wire logic [15:0] cpu_mem_wdata = (index == 2'd0) ? merged[15:0] :
                                    (index == 2'd1) ? merged[31:16] :
                                                      merged[47:32];
  wire logic [15:0] array_q = target_cmos ? nvram_cpu_q :
                              target_pal  ? palette_cpu_q : 16'd0;

  // Keep each physical memory to two clocked ports. This exact shape is
  // important: separate ad-hoc read and write processes made Quartus implement
  // the CMOS as 131,072 flip-flops instead of M10Ks.
  always @(posedge clk) begin
    nvram_cpu_q <= nvram_mem[cpu_mem_addr[12:0]];
    nvram_ext_q <= nvram_mem[nvram_ext_addr[13:1]];
    nvram_ext_lane_q <= nvram_ext_addr[0];
    if (nvram_ext_wr) begin
      if (nvram_ext_addr[0])
        nvram_mem[nvram_ext_addr[13:1]][15:8] <= nvram_ext_wdata;
      else
        nvram_mem[nvram_ext_addr[13:1]][7:0] <= nvram_ext_wdata;
    end else if (nvram_cpu_we)
      nvram_mem[cpu_mem_addr[12:0]] <= cpu_mem_wdata;
  end
  always_comb
    nvram_ext_rdata = nvram_ext_lane_q ? nvram_ext_q[15:8]
                                       : nvram_ext_q[7:0];

  always @(posedge clk) begin
    palette_cpu_q <= palette[cpu_mem_addr];
    if (palette_cpu_we)
      palette[cpu_mem_addr] <= cpu_mem_wdata;
  end

  // Independent registered palette scan port (the second palette RAM port).
  always_ff @(posedge clk) palette_scan_data <= palette[palette_scan_addr];

  always @(posedge clk) begin
    nvram_write_pulse <= 1'b0;

    if (rst) begin
      state <= L_IDLE;
      done <= 1'b0;
      rdata <= 32'd0;
      we_q <= 1'b0;
      target_q <= MAP_NONE;
      rel_q <= 28'd0;
      boff_q <= 4'd0;
      size_q <= 6'd0;
      wdata_q <= 32'd0;
      field_mask_q <= 48'd0;
      write_mask_q <= 48'd0;
      shifted_wdata_q <= 48'd0;
      index <= 2'd0;
      old0 <= 16'd0; old1 <= 16'd0; old2 <= 16'd0;
      array_addr <= 15'd0;
    end else begin
      done <= 1'b0;
      case(state)
        L_IDLE: if(req) begin
          we_q <= we;
          target_q <= target;
          rel_q <= (target == MAP_CMOS)
                   ? (word_addr - TMAP_CMOS_LO[31:4])
                   : (word_addr - TMAP_PAL_LO[31:4]);
          boff_q <= bit_offset;
          size_q <= size;
          wdata_q <= wdata;
          field_mask_q <= (size == 0) ? 48'd0 :
                          ((48'd1 << size) - 48'd1);
          old0 <= 16'd0; old1 <= 16'd0; old2 <= 16'd0;
          index <= 2'd0;
          state <= (size == 0) ? L_FIN : L_ADDR;
        end
        L_ADDR: begin
          // Prepare the variable shifts while the synchronous memory reads
          // are in flight. L_WRITE then sees only a shallow mask/merge cone
          // at the M10K input instead of two cascaded barrel shifters.
          write_mask_q <= field_mask_q << boff_q;
          shifted_wdata_q <= {16'd0,wdata_q} << boff_q;
          array_addr <= 15'(rel_q + index);
          state <= L_WAIT;
        end
        L_WAIT: state <= L_CAP;
        L_CAP: begin
          case(index)
            2'd0: old0 <= word_valid ? array_q : 16'd0;
            2'd1: old1 <= word_valid ? array_q : 16'd0;
            default: old2 <= word_valid ? array_q : 16'd0;
          endcase
          if(index + 2'd1 >= words_touched) begin
            index <= 2'd0;
            state <= we_q ? L_WRITE : L_FIN;
          end else begin
            index <= index + 2'd1;
            state <= L_ADDR;
          end
        end
        L_WRITE: begin
          if (nvram_cpu_we) nvram_write_pulse <= 1'b1;
          if(index + 2'd1 >= words_touched) state <= L_FIN;
          else index <= index + 2'd1;
        end
        L_FIN: begin
          rdata <= we_q ? 32'd0 : 32'((old_window >> boff_q) & field_mask_q);
          done <= 1'b1;
          state <= L_IDLE;
        end
        default: state <= L_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
