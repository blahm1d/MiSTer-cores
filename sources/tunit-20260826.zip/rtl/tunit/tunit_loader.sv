// T-unit MRA loader/router. The descriptor is the sole profile authority:
// payloads are rejected until an exact legal descriptor has completed.
// Physical chip streams are transformed by the shared per-profile mappers.

`default_nettype none

module tunit_loader
  import tunit_pkg::*;
  import tunit_profile_layout_pkg::*;
#(
  // Non-zero values are focused-test completion-count overrides. Production
  // leaves these at zero and consumes the runtime profile metadata.
  parameter logic [24:0] PROGRAM_BYTES = 25'd0,
  parameter logic [24:0] GFX_BYTES     = 25'd0,
  parameter logic [24:0] SOUND_BYTES   = 25'd0,
  parameter integer FIFO_ADDR_BITS     = 9,
  parameter integer FIFO_HIGH_WATER    = 384
)
(
  input  wire logic   clk,
  input  wire logic   rst_pon,
  input  wire logic   rst_game,

  input  wire logic [7:0]  ioctl_index,
  input  wire logic        ioctl_download,
  input  wire logic        ioctl_wr,
  input  wire logic [24:0] ioctl_addr,
  input  wire logic [7:0]  ioctl_data,
  output logic             ioctl_wait,

  output logic        dip_wr,
  output logic [24:0] dip_addr,
  output logic [7:0]  dip_data,

  output logic        prog_wr,
  output logic [18:0] prog_addr,
  output logic [15:0] prog_wdata,
  output logic [1:0]  prog_be,
  input  wire logic   prog_ready,

  output logic        gfx_wr,
  output logic [23:0] gfx_addr,
  output logic [7:0]  gfx_wdata,
  input  wire logic   gfx_ready,

  output logic        snd_wr,
  output logic [23:0] snd_addr,
  output logic [7:0]  snd_wdata,
  input  wire logic   snd_ready,

  output tunit_profile_t profile,
  output tunit_variant_t variant,
  output logic        profile_valid,
  output logic        loader_busy,
  output logic        rst_cpu,
  output logic        rst_sound,
  output logic [31:0] accepted_count,
  output logic [31:0] dropped_count,
  output logic [3:0]  complete_mask,
  output logic [7:0]  descriptor_error
);

  localparam integer FIFO_DEPTH = 1 << FIFO_ADDR_BITS;

  logic [7:0] descriptor [0:7];
  logic [31:0] accepted_by_index [0:3];
  logic [31:0] writes_by_index [0:3];
  logic prev_download;
  logic [7:0] active_index;
  logic active_transfer_error;

  logic [1:0]  fifo_index [0:FIFO_DEPTH-1];
  logic [24:0] fifo_addr [0:FIFO_DEPTH-1];
  logic [7:0]  fifo_data [0:FIFO_DEPTH-1];
  // TUNIT-P0032 -- the graphics stream map is retimed to the PUSH side and its
  // result rides the FIFO, so gfx_addr leaves this module straight out of a
  // register with no profile/variant cone behind it. See the block comment at
  // the gfx_map instance for the measurement and the equivalence argument.
  logic [24:0] fifo_gfx [0:FIFO_DEPTH-1];   // {map_valid_and_is_gfx, logical_addr}
  logic [24:0] gfx_pend;                    // FIFO read register, loaded on pop
  // TUNIT-P0033 -- the sound stream map is retimed to the PUSH side the same
  // way, but the sound map is copy_index-dependent, so BOTH copies are computed
  // at push and ride the FIFO. See the block comment at the sound_map instances.
  logic [24:0] fifo_snd0 [0:FIFO_DEPTH-1];  // {map_valid_and_is_snd, ddr_addr} @copy 0
  logic [24:0] fifo_snd1 [0:FIFO_DEPTH-1];  // {map_valid_and_is_snd, ddr_addr} @copy 1
  logic [24:0] snd_pend;                    // drives snd_wr/snd_addr directly
  logic [24:0] snd_next;                    // copy-1 image, swapped in on advance
  logic [FIFO_ADDR_BITS-1:0] fifo_wptr;
  logic [FIFO_ADDR_BITS-1:0] fifo_rptr;
  logic [FIFO_ADDR_BITS:0] fifo_count;

  logic        pending_active;
  logic [1:0]  pend_index;
  logic [24:0] pend_physical_addr;
  logic [7:0]  pend_data;
  logic        pend_copy_index;
  logic        snd_intercopy_gap;

  logic profile_meta_valid;
  logic [24:0] profile_program_bytes;
  logic [24:0] profile_gfx_bytes;
  logic [24:0] profile_sound_bytes;
  logic [63:0] profile_descriptor;

  tunit_profile_meta profile_meta(
    .profile,
    .variant,
    .meta_valid(profile_meta_valid),
    .sound_type(),
    .gfx_layout(),
    .program_layout(),
    .feature_flags(),
    .gfx_large(),
    .program_physical_bytes(profile_program_bytes),
    .program_logical_bytes(),
    .gfx_physical_bytes(profile_gfx_bytes),
    .gfx_populated_bytes(),
    .gfx_region_bytes(),
    .sound_physical_bytes(profile_sound_bytes),
    .sound_cpu_logical_bytes(),
    .sound_sample_logical_bytes(),
    .sound_dense_logical_bytes(),
    .sound_ddr_image_bytes(),
    .descriptor(profile_descriptor)
  );

  wire logic [24:0] expected_program_bytes =
    (PROGRAM_BYTES != 0) ? PROGRAM_BYTES : profile_program_bytes;
  wire logic [24:0] expected_gfx_bytes =
    (GFX_BYTES != 0) ? GFX_BYTES : profile_gfx_bytes;
  wire logic [24:0] expected_sound_bytes =
    (SOUND_BYTES != 0) ? SOUND_BYTES : profile_sound_bytes;

  tunit_profile_t descriptor_profile;
  tunit_variant_t descriptor_variant;
  logic descriptor_meta_valid;
  logic [63:0] expected_descriptor;

  always_comb begin
    case (descriptor[2])
      8'd0: descriptor_profile = PROFILE_MK1;
      8'd1: descriptor_profile = PROFILE_MK2;
      8'd2: descriptor_profile = PROFILE_NBAJAM;
      8'd3: descriptor_profile = PROFILE_NBAJAM_TE;
      8'd4: descriptor_profile = PROFILE_JDREDD;
      default: descriptor_profile = PROFILE_MK1;
    endcase

    descriptor_variant = VARIANT_STANDARD;
    if ((descriptor[2] == 8'd0) && (descriptor[6] == FEATURE_MK_TURBO_PROT))
      descriptor_variant = VARIANT_MK_TURBO;
    else if ((descriptor[2] == 8'd2) &&
             (descriptor[5] == 8'd2) &&
             (descriptor[6] == FEATURE_NBA_PROGRAM_RELOAD))
      descriptor_variant = VARIANT_NBA_PROTO;
  end

  tunit_profile_meta descriptor_meta(
    .profile(descriptor_profile),
    .variant(descriptor_variant),
    .meta_valid(descriptor_meta_valid),
    .sound_type(),
    .gfx_layout(),
    .program_layout(),
    .feature_flags(),
    .gfx_large(),
    .program_physical_bytes(),
    .program_logical_bytes(),
    .gfx_physical_bytes(),
    .gfx_populated_bytes(),
    .gfx_region_bytes(),
    .sound_physical_bytes(),
    .sound_cpu_logical_bytes(),
    .sound_sample_logical_bytes(),
    .sound_dense_logical_bytes(),
    .sound_ddr_image_bytes(),
    .descriptor(expected_descriptor)
  );

  wire logic [63:0] received_descriptor = {
    descriptor[7], descriptor[6], descriptor[5], descriptor[4],
    descriptor[3], descriptor[2], descriptor[1], descriptor[0]
  };
  wire logic descriptor_exact =
    descriptor_meta_valid && (received_descriptor == expected_descriptor);

  wire logic download_start = ioctl_download && !prev_download;
  wire logic download_end = !ioctl_download && prev_download;
  wire logic descriptor_start = download_start && (ioctl_index == 8'd3);
  wire logic rom_index = ioctl_index <= 8'd2;
  wire logic index_matches_transfer =
    download_start || (ioctl_index == active_index);

  logic rom_addr_valid;
  always_comb begin
    rom_addr_valid = 1'b0;
    if (profile_valid && profile_meta_valid) begin
      case (ioctl_index)
        8'd0: rom_addr_valid = ioctl_addr < profile_program_bytes;
        8'd1: rom_addr_valid = ioctl_addr < profile_gfx_bytes;
        8'd2: rom_addr_valid = ioctl_addr < profile_sound_bytes;
        default: ;
      endcase
    end
  end

  wire logic fifo_can_accept = fifo_count < FIFO_DEPTH;
  wire logic fifo_push = ioctl_download && ioctl_wr && rom_index &&
                         index_matches_transfer && rom_addr_valid &&
                         fifo_can_accept;
  wire logic fifo_pop = !pending_active && (fifo_count != 0);

  assign loader_busy = ioctl_download || pending_active || (fifo_count != 0);
  assign ioctl_wait = ioctl_download && rom_index && profile_valid &&
                      (fifo_count >= FIFO_HIGH_WATER);
  // MiSTer delivers index-254 switch bytes as an ioctl side channel, not as a
  // ROM download.  The working Wolf/Y-unit shells accept these writes from
  // ioctl_wr alone; requiring ioctl_download made the MRA default depend on
  // host transaction timing and could leave a title on the compiled fallback
  // until the DIP menu was touched.  Only the two declared DSW bytes route.
  assign dip_wr = ioctl_wr && (ioctl_index == 8'd254) &&
                  !ioctl_addr[24:1];
  assign dip_addr = ioctl_addr;
  assign dip_data = ioctl_data;
  // Hold both processors until the descriptor and every payload have
  // completed.  Checking all four bits also prevents reset from opening
  // between separately delivered MRA regions.
  assign rst_cpu = rst_game || loader_busy || !profile_valid ||
                   (complete_mask != 4'b1111);
  assign rst_sound = rst_cpu;

  logic prog_map_valid;
  logic [1:0] prog_copy_count;
  logic [18:0] prog_map_addr;
  logic prog_map_high;
  tunit_program_stream_map program_map(
    .profile,
    .variant,
    .physical_addr(pend_physical_addr),
    .copy_index(pend_copy_index),
    .write_valid(prog_map_valid),
    .copy_count(prog_copy_count),
    .word_addr(prog_map_addr),
    .high_byte(prog_map_high)
  );

  // TUNIT-P0032 -- graphics stream map, retimed from the pop side to the push
  // side.
  //
  // MEASURED binding constraint, re-derived from the fit under it
  // (output_files/tunit_setup_paths.txt, Path #1, Slow 1100mV 100C):
  //   variant[0]~DUPLICATE -> wolf_gfx_ddr_top|wl_data[31]
  //   Relationship 10.416 (ONE clock, no exception), Data Delay 11.496,
  //   Slack -1.850, and the same source drives wl_data[30..8], line_tag[*]
  //   and line_data[*] -- 100+ of the 200 violated paths.
  // The detailed path enters the graphics block through logical_addr:
  //   variant[0] -> gfx_map|write_valid~1/~2/~3 -> gfx_map|logical_addr[4]~19
  //   -> graphics|Equal0~6..12 -> comb~3 -> wflush_req -> ost~21
  //   -> wl_mask[5]~0 -> wl_data[30]~32 -> wl_data[31]|ena
  // i.e. 2.78 ns of quasi-static decode inside this module sits in FRONT of
  // 8.72 ns of real work inside wolf_gfx_ddr_top. Deleting the front half is
  // the whole fix; nothing in wolf_gfx_ddr_top has to change.
  //
  // The map used to be computed from pend_physical_addr, so it was combinational
  // between the FIFO read register and the module boundary. It cannot instead be
  // computed from fifo_addr[fifo_rptr]: that array is inferred as a 512x25
  // Simple Dual Port M10K (Arcade-TUnit.map.rpt:968, "altsyncram:fifo_addr_rtl_0
  // ... Simple Dual Port ; 512 ; 25 ; 12800") precisely BECAUSE its only read is
  // registered. An asynchronous read would destroy that inference -- Cyclone V
  // M10K has no asynchronous read port at all -- and spill 12,800 bits into
  // MLABs behind a 16:1 output mux, which would put MORE delay on the pop path
  // than it removed from the output path.
  //
  // So the map moves one stage EARLIER instead, onto ioctl_addr at push, and the
  // mapped address rides the FIFO in its own array. gfx_addr is then literally
  // the FIFO read register's output.
  //
  // EQUIVALENCE: pend_physical_addr(N) is by construction the fifo_addr entry
  // written from ioctl_addr at that entry's push, so map(pend_physical_addr) at
  // pop equals map(ioctl_addr) at push whenever profile/variant are unchanged
  // between the two. They are: profile/variant are written only at rst_pon, at
  // descriptor_start, and at download_end of ioctl_index==3 -- and
  // descriptor_start clears fifo_wptr/fifo_rptr/fifo_count/pending_active, while
  // an index-3 download can never push (fifo_push requires rom_index). The FIFO
  // is therefore provably EMPTY across every profile/variant change.
  logic gfx_map_valid;
  logic [23:0] gfx_map_addr;
  tunit_gfx_stream_map gfx_map(
    .profile,
    .variant,
    .physical_addr(ioctl_addr),
    .write_valid(gfx_map_valid),
    .logical_addr(gfx_map_addr)
  );

  // The pushed tag folds "this entry is a graphics byte" into the map's own
  // write_valid, so nothing downstream of the FIFO has to look at the index.
  wire logic gfx_push_valid = (ioctl_index[1:0] == 2'd1) && gfx_map_valid;

  // TUNIT-P0033 -- sound stream map, retimed from the pop side to the push side.
  //
  // MEASURED binding constraint, re-derived from the fit under it
  // (output_files/tunit_setup_paths.txt, Path #17, Slow 1100mV 100C):
  //   loader|pend_physical_addr[23]~DUPLICATE -> tunit_sound_ddr:sound_rom|wc_data[39]
  //   Relationship 10.416 (ONE clock, no exception), Data Delay 10.764,
  //   Slack -1.151, 14 logic levels. The SAME source register drives all 33
  //   remaining violated rows in that report -- wc_data[*], wc_mask[*], dl_ack
  //   and dl_seen -- and nothing else in the design.
  // The detailed path:
  //   pend_physical_addr[23] -> sound_map|LessThan6~0 -> LessThan5~0
  //   -> LessThan4~0 -> Mux27~2 -> ddr_addr[16]~5 -> ddr_addr[14]~23
  //   -> sound_rom|Equal1~6..9 (the wc_beat == dl_beat compare at
  //      tunit_sound_ddr.sv:133) -> force_flush~1 -> wc_mask~0
  //   -> wc_data~5 -> wc_data~15 -> wc_data[39]
  // i.e. 5.134 ns of quasi-static range-decode and offset arithmetic inside this
  // module sits in FRONT of 5.630 ns of real work inside tunit_sound_ddr.
  // Deleting the front half is the whole fix; tunit_sound_ddr does not change.
  //
  // THE pend_copy_index DEPENDENCY, and how it is solved.
  // Unlike the graphics map, this map is a function of copy_index as well as of
  // the physical address: MK1 OKI, MK2 DCS and NBA-family CPU images are each
  // written TWICE, at addresses that differ by a per-branch constant
  // (+0x04_0000, +0x08_0000, +0x02_0000 respectively -- tunit_profile_layout.sv
  // :328-337, :348-350, :364-365). copy_index is pop-side state, so it is not
  // available at push. Selecting between two stored images with a pop-side mux
  // would only shorten the cone, not remove it.
  // Instead BOTH copies are computed at push and BOTH ride the FIFO, and the
  // pop side keeps a two-deep shift: snd_pend drives the port, snd_next is
  // swapped into it by the same enable that increments pend_copy_index. So
  // snd_addr/snd_wr leave this module out of a flop with zero logic behind them.
  //
  // copy_count is no longer read from the map. It is derived as
  // `snd_next[24] ? 2 : 1`, which is EXACTLY equivalent: in every branch of
  // tunit_sound_stream_map, copy_count is a function of profile/variant and the
  // physical address ONLY (never of copy_index), and copy_count==1 branches are
  // precisely the ones that write `write_valid = !copy_index` -- so copy-1's
  // valid bit is set if and only if copy_count is 2. Branches that produce
  // write_valid==0 for copy 0 take the error path before copy_count is read.
  //
  // EQUIVALENCE (identical argument to TUNIT-P0032): pend_physical_addr(N) is by
  // construction the fifo_addr entry written from ioctl_addr at that entry's
  // push, so map(pend_physical_addr) at pop equals map(ioctl_addr) at push
  // whenever profile/variant are unchanged between the two -- and the FIFO is
  // provably EMPTY across every profile/variant change (descriptor_start clears
  // the pointers and the count, and an index-3 download can never push because
  // fifo_push requires rom_index).
  logic sound_map0_valid;
  logic sound_map1_valid;
  logic [23:0] sound_map0_addr;
  logic [23:0] sound_map1_addr;
  tunit_sound_stream_map sound_map0(
    .profile,
    .variant,
    .physical_addr(ioctl_addr),
    .copy_index(1'b0),
    .write_valid(sound_map0_valid),
    .copy_count(),
    .target(),
    .logical_addr(),
    .ddr_addr(sound_map0_addr)
  );
  tunit_sound_stream_map sound_map1(
    .profile,
    .variant,
    .physical_addr(ioctl_addr),
    .copy_index(1'b1),
    .write_valid(sound_map1_valid),
    .copy_count(),
    .target(),
    .logical_addr(),
    .ddr_addr(sound_map1_addr)
  );

  // As with graphics, the pushed tag folds "this entry is a sound byte" into the
  // map's own write_valid, so nothing downstream of the FIFO looks at the index.
  wire logic snd_push_valid0 = (ioctl_index[1:0] == 2'd2) && sound_map0_valid;
  wire logic snd_push_valid1 = (ioctl_index[1:0] == 2'd2) && sound_map1_valid;

  logic pending_map_valid;
  logic [1:0] pending_copy_count;
  logic pending_ready;
  always_comb begin
    pending_map_valid = 1'b0;
    pending_copy_count = 2'd0;
    pending_ready = 1'b0;

    prog_wr = 1'b0;
    prog_addr = prog_map_addr;
    prog_wdata = {pend_data, pend_data};
    prog_be = prog_map_high ? 2'b10 : 2'b01;

    gfx_wdata = pend_data;
    snd_wdata = pend_data;

    if (pending_active) begin
      case (pend_index)
        2'd0: begin
          pending_map_valid = prog_map_valid;
          pending_copy_count = prog_copy_count;
          pending_ready = prog_ready;
          prog_wr = prog_map_valid;
        end
        2'd1: begin
          pending_map_valid = gfx_pend[24] && !pend_copy_index;
          pending_copy_count = 2'd1;
          pending_ready = gfx_ready;
        end
        2'd2: begin
          pending_map_valid = snd_pend[24];
          pending_copy_count = snd_next[24] ? 2'd2 : 2'd1;
          pending_ready = snd_intercopy_gap ? 1'b0 : snd_ready;
        end
        default: ;
      endcase
    end
  end

  // gfx_addr is the FIFO read register verbatim -- no logic, no profile, no
  // variant. gfx_wr is that register's tag bit qualified by the pending flags,
  // all three of which are registers loaded by the same pop; it is exactly the
  // old expression with gfx_map_valid replaced by the pre-computed tag.
  assign gfx_addr = gfx_pend[23:0];
  assign gfx_wr = pending_active && gfx_pend[24] && !pend_copy_index;

  // snd_addr is the copy-selected FIFO read register verbatim -- no profile,
  // variant, or pend_physical_addr cone. Insert one explicit low-valid clock
  // between mirrored copies. This gives the DDR backend an unambiguous
  // transaction boundary and avoids relying on it to infer a new request from
  // an address change while snd_wr remains asserted.
  assign snd_addr = snd_pend[23:0];
  assign snd_wr = pending_active && snd_pend[24] && !snd_intercopy_gap;

  wire logic pending_fire =
    pending_active && pending_map_valid && pending_ready;
  wire logic pending_last_copy =
    ({1'b0, pend_copy_index} + 2'd1) >= pending_copy_count;

  integer i;
  always_ff @(posedge clk) begin
    if (rst_pon) begin
      profile <= PROFILE_MK1;
      variant <= VARIANT_STANDARD;
      profile_valid <= 1'b0;
      pending_active <= 1'b0;
      pend_index <= 2'd0;
      pend_physical_addr <= 25'd0;
      pend_data <= 8'd0;
      pend_copy_index <= 1'b0;
      snd_intercopy_gap <= 1'b0;
      // map(0) under the reset profile is {valid=1, addr=0}; the tag bit is
      // cleared instead so gfx_wr is 0 out of reset exactly as before.
      gfx_pend <= 25'd0;
      // Same argument for sound: only the tag bit has to be cleared for
      // snd_wr to be 0 out of reset exactly as before.
      snd_pend <= 25'd0;
      snd_next <= 25'd0;
      fifo_wptr <= '0;
      fifo_rptr <= '0;
      fifo_count <= '0;
      prev_download <= 1'b0;
      active_index <= 8'd0;
      active_transfer_error <= 1'b0;
      accepted_count <= 32'd0;
      dropped_count <= 32'd0;
      complete_mask <= 4'd0;
      descriptor_error <= 8'd0;
      for (i = 0; i < 8; i = i + 1)
        descriptor[i] <= 8'd0;
      for (i = 0; i < 4; i = i + 1) begin
        accepted_by_index[i] <= 32'd0;
        writes_by_index[i] <= 32'd0;
      end
    end else begin
      prev_download <= ioctl_download;
      if (snd_intercopy_gap)
        snd_intercopy_gap <= 1'b0;

      if (download_start) begin
        active_index <= ioctl_index;
        active_transfer_error <= 1'b0;
        if (ioctl_index < 8'd4) begin
          accepted_by_index[ioctl_index[1:0]] <= 32'd0;
          writes_by_index[ioctl_index[1:0]] <= 32'd0;
          complete_mask[ioctl_index[1:0]] <= 1'b0;
        end
      end

      // A new descriptor starts a new game transaction. Invalidate the old
      // profile and every completion bit before any payload can be accepted.
      if (descriptor_start) begin
        profile <= PROFILE_MK1;
        variant <= VARIANT_STANDARD;
        profile_valid <= 1'b0;
        complete_mask <= 4'd0;
        descriptor_error <= 8'd0;
        fifo_wptr <= '0;
        fifo_rptr <= '0;
        fifo_count <= '0;
        pending_active <= 1'b0;
        pend_copy_index <= 1'b0;
        snd_intercopy_gap <= 1'b0;
        for (i = 0; i < 8; i = i + 1)
          descriptor[i] <= 8'd0;
        for (i = 0; i < 4; i = i + 1) begin
          accepted_by_index[i] <= 32'd0;
          writes_by_index[i] <= 32'd0;
        end
      end else begin
        case ({fifo_push, fifo_pop})
          2'b10: fifo_count <= fifo_count + 1'b1;
          2'b01: fifo_count <= fifo_count - 1'b1;
          default: fifo_count <= fifo_count;
        endcase

        if (fifo_push) begin
          fifo_index[fifo_wptr] <= ioctl_index[1:0];
          fifo_addr[fifo_wptr] <= ioctl_addr;
          fifo_data[fifo_wptr] <= ioctl_data;
          fifo_gfx[fifo_wptr] <= {gfx_push_valid, gfx_map_addr};
          fifo_snd0[fifo_wptr] <= {snd_push_valid0, sound_map0_addr};
          fifo_snd1[fifo_wptr] <= {snd_push_valid1, sound_map1_addr};
          fifo_wptr <= fifo_wptr + 1'b1;
        end

        if (fifo_pop) begin
          pend_index <= fifo_index[fifo_rptr];
          pend_physical_addr <= fifo_addr[fifo_rptr];
          pend_data <= fifo_data[fifo_rptr];
          // Registered read only -- keeps the M10K inference (map.rpt:968).
          gfx_pend <= fifo_gfx[fifo_rptr];
          snd_pend <= fifo_snd0[fifo_rptr];
          snd_next <= fifo_snd1[fifo_rptr];
          pend_copy_index <= 1'b0;
          fifo_rptr <= fifo_rptr + 1'b1;
          pending_active <= 1'b1;
        end

        if (pending_active && !pending_map_valid) begin
          pending_active <= 1'b0;
          active_transfer_error <= 1'b1;
        end else if (pending_fire) begin
          if (pending_last_copy) begin
            pending_active <= 1'b0;
            pend_copy_index <= 1'b0;
          end else begin
            pend_copy_index <= pend_copy_index + 1'b1;
            // The copy-1 image becomes the live one on exactly the enable that
            // advances copy_index, so snd_addr never leaves a register.
            snd_pend <= snd_next;
            if (pend_index == 2'd2)
              snd_intercopy_gap <= 1'b1;
          end
        end
      end

      if (ioctl_wr) begin
        // Index 254 is outside the ROM transaction protocol.  It neither
        // requires ioctl_download nor participates in accepted/dropped counts.
        if (ioctl_index == 8'd254) begin
          ;
        end else if (!ioctl_download) begin
          dropped_count <= dropped_count + 32'd1;
        end else begin
          case (ioctl_index)
            8'd0, 8'd1, 8'd2: begin
              writes_by_index[ioctl_index[1:0]] <=
                (download_start ? 32'd0 :
                 writes_by_index[ioctl_index[1:0]]) + 32'd1;
              if (fifo_push) begin
                accepted_count <= accepted_count + 32'd1;
                accepted_by_index[ioctl_index[1:0]] <=
                  (download_start ? 32'd0 :
                   accepted_by_index[ioctl_index[1:0]]) + 32'd1;
              end else begin
                dropped_count <= dropped_count + 32'd1;
                active_transfer_error <= 1'b1;
                if (!profile_valid)
                  descriptor_error[7] <= 1'b1;
              end
            end

            8'd3: begin
              writes_by_index[3] <=
                (download_start ? 32'd0 : writes_by_index[3]) + 32'd1;
              if (ioctl_addr < 25'd8) begin
                accepted_count <= accepted_count + 32'd1;
                accepted_by_index[3] <=
                  (download_start ? 32'd0 : accepted_by_index[3]) + 32'd1;
                descriptor[ioctl_addr[2:0]] <= ioctl_data;
              end else begin
                dropped_count <= dropped_count + 32'd1;
                active_transfer_error <= 1'b1;
              end
            end

            default: begin
              dropped_count <= dropped_count + 32'd1;
              active_transfer_error <= 1'b1;
            end
          endcase

          if (!download_start && (ioctl_index != active_index)) begin
            active_transfer_error <= 1'b1;
            dropped_count <= dropped_count + 32'd1;
          end
        end
      end

      // Completion is based on both accepted writes and total transfer writes.
      // This rejects short, long, invalid-address, and overflowed transfers.
      if (download_end) begin
        case (active_index)
          8'd0:
            complete_mask[0] <= profile_valid && profile_meta_valid &&
              !active_transfer_error &&
              (accepted_by_index[0] == expected_program_bytes) &&
              (writes_by_index[0] == expected_program_bytes);
          8'd1:
            complete_mask[1] <= profile_valid && profile_meta_valid &&
              !active_transfer_error &&
              (accepted_by_index[1] == expected_gfx_bytes) &&
              (writes_by_index[1] == expected_gfx_bytes);
          8'd2:
            complete_mask[2] <= profile_valid && profile_meta_valid &&
              !active_transfer_error &&
              (accepted_by_index[2] == expected_sound_bytes) &&
              (writes_by_index[2] == expected_sound_bytes);
          8'd3: begin
            complete_mask[3] <=
              !active_transfer_error &&
              (accepted_by_index[3] == 32'd8) &&
              (writes_by_index[3] == 32'd8) &&
              descriptor_exact;

            descriptor_error[0] <= active_transfer_error ||
              (accepted_by_index[3] != 32'd8) ||
              (writes_by_index[3] != 32'd8);
            descriptor_error[1] <= descriptor[0] != 8'h54;
            descriptor_error[2] <= descriptor[1] != 8'h01;
            descriptor_error[3] <= !descriptor_meta_valid ||
                                   (descriptor[2] > 8'd4);
            descriptor_error[4] <= descriptor_meta_valid &&
                                   (descriptor[3] != expected_descriptor[31:24]);
            descriptor_error[5] <= descriptor_meta_valid &&
                                  ((descriptor[4] != expected_descriptor[39:32]) ||
                                   (descriptor[5] != expected_descriptor[47:40]));
            descriptor_error[6] <= descriptor_meta_valid &&
                                   (descriptor[6] != expected_descriptor[55:48]);
            descriptor_error[7] <= !descriptor_exact;

            if (!active_transfer_error &&
                (accepted_by_index[3] == 32'd8) &&
                (writes_by_index[3] == 32'd8) &&
                descriptor_exact) begin
              profile <= descriptor_profile;
              variant <= descriptor_variant;
              profile_valid <= 1'b1;
            end else begin
              profile_valid <= 1'b0;
            end
          end
          default: ;
        endcase
      end
    end
  end

endmodule

`default_nettype wire
