// T-unit framebuffer page-publication seam.
//
// The TMS34010's live display row is a proposal during vertical blank. Commit
// only its page bit after the physical renderer and VRAM writer have drained,
// then give the posted path a fixed pixel-clock settle. Low row sequencing and
// the column tap stay live so T-unit DUDATE/subrow behavior is preserved.
//
// NBA Jam TE MAIN.ASM DIRQ publishes DPYADR first, then polls DMACTRL until the
// final command stops. Real VRAM is immediately coherent with scanout. Our
// DDR-backed scanline cache is not DMA-snooped, so following DPYADR immediately
// can cache a blank/partial page for the whole frame. The Wolf sibling uses the
// same private DDR publication boundary, but its later HUD-flicker candidates
// were cabinet-refuted; that precedent is structural, not acceptance evidence.
// Sample whether the final visible-page render is outstanding, wait for its one
// drain edge, settle posted writes once, then commit scanout and prefetch together.
// Later busy traffic paints the newly hidden page and deliberately does not
// re-arm this frame's already-qualified commit.
`default_nettype none
module tunit_page_fence #(
  parameter int SETTLE_PIXELS = 128
)(
  input  wire logic       clk,
  input  wire logic       rst,
  input  wire logic       ce_pix,
  input  wire logic       vblank_start,
  input  wire logic       commit_window,
  input  wire logic       render_busy,
  // Private-DDR accommodation for NBA/TE. Real VRAM and MAME expose the new
  // DPYADR page immediately, but the FPGA must first make its current/next
  // rows resident in the upper cache. While enabled, advertise the hidden
  // proposal and hold publication until both rows are complete.
  input  wire logic       pending_prewarm_enable,
  input  wire logic       pending_prewarm_ready,
  input  wire logic [8:0] display_row,
  input  wire logic [8:0] next_row,
  output logic [8:0]      committed_display_row,
  output logic [8:0]      committed_next_row,
  output logic            page_commit,
  output logic            active_page,
  output logic            pending_prewarm,
  output logic            pending_page,
  // NBA Jam MAIN.ASM flips DPYADR before clearing the page that just became
  // hidden.  If DDR publication has to defer that flip, the clear must remain
  // parked too; otherwise it erases the complete page scanout is retaining.
  output logic            srt_write_allow
);
  localparam int SW = (SETTLE_PIXELS < 2) ? 1 : $clog2(SETTLE_PIXELS + 1);
  localparam logic [SW-1:0] SETTLE_RELOAD = SW'(SETTLE_PIXELS);

  logic armed;
  logic wait_drain;
  logic blank_window;
  logic saw_commit_window;
  logic [SW-1:0] settle;
`ifdef MUT_TUNIT_NO_PENDING_PREWARM
  wire logic pending_prewarm_enable_eff = 1'b0;
`else
  wire logic pending_prewarm_enable_eff =
      (pending_prewarm_enable === 1'b1);
`endif
`ifdef MUT_TUNIT_NO_PENDING_CACHE_WARM
  wire logic pending_cache_warm_eff = 1'b0;
`else
  wire logic pending_cache_warm_eff = pending_prewarm_enable_eff;
`endif
  // A software DPYADR override becomes visible combinationally one clock
  // before pending_page captures it. Use that live proposal during blank so
  // neither the pixel path nor the loader sees a one-clock wrong-page glitch.
  // NBA's source-ordered SRT read can also postpone DPYADR beyond the finite
  // window. Contain that late profile-scoped proposal immediately rather than
  // letting the raw page bit escape active without a publication pulse.
  wire logic late_live_proposal = pending_prewarm_enable_eff &&
                                  !blank_window &&
                                  (display_row[8] != active_page);
  // Once the NBA/TE accommodation is active, the translation must always be
  // derived from the live page bit.  Falling back to pending_page after a late
  // B proposal is cancelled back to A would otherwise expose stale B for one
  // clock before the pending register catches up.
  wire logic proposal_page = pending_prewarm_enable_eff ? display_row[8] :
                             (blank_window ? display_row[8] : pending_page);
  wire logic page_delta = proposal_page ^ active_page;
  wire logic pending_prewarm_ready_eff =
      (pending_prewarm_ready === 1'b1);
  assign pending_prewarm = pending_cache_warm_eff && blank_window &&
                           commit_window && armed && page_delta;

`ifdef MUT_TUNIT_PAGE_OWNER_EARLY_SRT
  // Proof mutation: restore the old independent page-fence/SRT behavior.
  assign srt_write_allow = 1'b1;
`else
  // Keep the CPU's source-ordered shift-register write parked from the first
  // pending page mismatch through the actual publication edge. The store mux
  // retains its backend-start state; reads remain independent.
  assign srt_write_allow = !(page_delta &&
                             (armed || blank_window || late_live_proposal));
`endif

  // Translate the complete live current/next row pair by one physical page
  // while a new proposal is held. XORing the same page delta into both rows
  // preserves their exact DUDATE relationship instead of rebuilding next_row.
  assign committed_display_row = display_row ^ {page_delta,8'b0};
  assign committed_next_row    = next_row    ^ {page_delta,8'b0};

  always_ff @(posedge clk) begin
    if (rst) begin
      pending_page <= 1'b0;
      active_page <= 1'b0;
      armed <= 1'b0;
      wait_drain <= 1'b0;
      blank_window <= 1'b0;
      saw_commit_window <= 1'b0;
      settle <= SETTLE_RELOAD;
      page_commit <= 1'b0;
    end else begin
      page_commit <= 1'b0;

      if (vblank_start) begin
        blank_window <= 1'b1;
        saw_commit_window <= 1'b0;
        pending_page <= display_row[8];
        armed <= 1'b1;
        wait_drain <= render_busy;
        settle <= SETTLE_RELOAD;
      end else begin
        // Use the undelayed local safe-window signal, not the RGB pipeline's
        // delayed vblank output. A TMS re-anchor can otherwise expose the tail
        // of the previous raster and close this blank before it has begun.
        if (commit_window) saw_commit_window <= 1'b1;
        if (saw_commit_window && !commit_window) blank_window <= 1'b0;

        // The display ISR may override the automatic DPYSTRT load during this
        // same blank. Follow the final proposal and restart qualification.
        if (pending_prewarm_enable_eff && !blank_window &&
            (display_row[8] != pending_page)) begin
          // A source-legal late NBA/TE DPYADR write missed this frame's finite
          // publication window. Remember it, retain the old page (including
          // the following SRT clear), and retry from the next source vblank.
          pending_page <= display_row[8];
          armed <= 1'b1;
          wait_drain <= render_busy;
          settle <= SETTLE_RELOAD;
        end else if (blank_window && (display_row[8] != pending_page)) begin
          pending_page <= display_row[8];
          armed <= 1'b1;
          wait_drain <= render_busy;
          settle <= SETTLE_RELOAD;
        end else if (armed) begin
          if (wait_drain) begin
            // One-shot qualification: once the final visible-page command has
            // drained, later traffic belongs to the newly hidden draw page.
            if (!render_busy) begin
              wait_drain <= 1'b0;
              settle <= SETTLE_RELOAD;
            end
          end else if (settle != '0) begin
            if (ce_pix) settle <= settle - 1'b1;
          end else if (blank_window && commit_window &&
                       (!pending_cache_warm_eff || !page_delta ||
                        pending_prewarm_ready_eff)) begin
            if (active_page != pending_page) begin
              active_page <= pending_page;
              page_commit <= 1'b1;
            end
            armed <= 1'b0;
          end
        end
      end
    end
  end
endmodule

// Diagnostic-only publication witness. Keep it separate from the fence so
// observability cannot feed back into page ownership and its behavior has a
// focused mutation gate. A wanted/active mismatch is normal while blank is
// draining; only a mismatch that survives the end of blank is counted.
module tunit_page_diag(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        vblank,
  input  wire logic        wanted_page,
  input  wire logic        active_page,
  input  wire logic        render_busy,
  input  wire logic        page_commit,
  output logic [31:0]      state
);
  logic vblank_q,wanted_q;
  logic [15:0] miss_frames;

  always_ff @(posedge clk or posedge rst) begin
    if(rst) begin
      vblank_q<=1'b0;
      wanted_q<=1'b0;
      miss_frames<=16'd0;
    end else begin
      vblank_q<=vblank;
      // Follow a late ISR DPYADR override throughout blank.
      if(vblank) wanted_q<=wanted_page;
`ifndef MUT_TUNIT_PAGE_DIAG_NO_MISS
      if(vblank_q&&!vblank&&(active_page!=wanted_q)&&
         miss_frames!=16'hffff)
        miss_frames<=miss_frames+16'd1;
`endif
    end
  end

  assign state={miss_frames,12'd0,render_busy,page_commit,wanted_q,active_page};
endmodule
`default_nettype wire
