// -----------------------------------------------------------------------------
// tms34010_io_cpu_config.sv
//
// CPU-domain shadows of the software-programmed graphics I/O registers.
//
// The full-rate I/O register file is retained for architectural readback and
// video/device behavior.  At the retiring CPU ack, this block write-forwards
// the already-stable command directly into CE-gated shadows.  Long graphics
// cones therefore launch from genuine CPU registers, with no io_reg-Q path.
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_io_cpu_config
  import tms34010_pkg::*;
(
  input  wire logic                  clk,
  input  wire logic                  rst,
  input  wire logic                  ce_cpu,
  input  wire logic                  req,
  input  wire logic                  we,
  input  wire logic                  is_io,
  input  wire logic                  ack,
  input  wire logic [ADDR_WIDTH-1:0] addr,
  input  wire logic [15:0]           wdata,
  // Field size of the access (1..32); sub-word writes merge into the shadow.
  input  wire logic [FIELD_SIZE_WIDTH-1:0] size,

  // Live taps exist only for mutation coverage.  Production shadows never
  // sample them; synthesis removes these unused paths.
  input  wire logic [15:0]           live_psize,
  input  wire logic [15:0]           live_convdp,
  input  wire logic [15:0]           live_convsp,
  input  wire logic [15:0]           live_control,
  input  wire logic [15:0]           live_pmask,
  input  wire logic [15:0]           live_dpyctl,

  output logic [15:0]                psize,
  output logic [15:0]                convdp,
  output logic [15:0]                convsp,
  output logic [15:0]                control,
  output logic [15:0]                pmask,
  output logic [15:0]                dpyctl
);

`ifdef MUT_IO_LIVE_TAPS
  // Mutation: restore the rejected full-rate io_reg-Q -> CPU combinational
  // paths that produced the post-fit PSIZE -> p_wdata setup violation.
  assign psize   = live_psize;
  assign convdp  = live_convdp;
  assign convsp  = live_convsp;
  assign control = live_control;
  assign pmask   = live_pmask;
  assign dpyctl  = live_dpyctl;
`else
  wire [IO_REG_IDX_W-1:0] wr_idx = addr[IO_REG_IDX_W+3:4];
  wire config_write = (ce_cpu !== 1'b0) && req && we && is_io && ack;
  // Sub-word writes merge into the shadow's current value; an aligned FS=16
  // write reduces to `wdata`.
  wire [15:0] psize_m   = io_field_merge(psize,   wdata, addr[3:0], size);
  wire [15:0] convdp_m  = io_field_merge(convdp,  wdata, addr[3:0], size);
  wire [15:0] convsp_m  = io_field_merge(convsp,  wdata, addr[3:0], size);
  wire [15:0] control_m = io_field_merge(control, wdata, addr[3:0], size);
  wire [15:0] pmask_m   = io_field_merge(pmask,   wdata, addr[3:0], size);
  wire [15:0] dpyctl_m  = io_field_merge(dpyctl,  wdata, addr[3:0], size);

  always_ff @(posedge clk) begin
    if (rst) begin
      psize   <= 16'h0000;
      convdp  <= 16'h0000;
      convsp  <= 16'h0000;
      control <= 16'h0000;
      pmask   <= 16'h0000;
      dpyctl  <= 16'h0000;
    end else if (config_write) begin
      unique case (wr_idx)
        IO_IDX_PSIZE:   psize   <= psize_m;
        IO_IDX_CONVDP:  convdp  <= convdp_m;
        IO_IDX_CONVSP:  convsp  <= convsp_m;
        IO_IDX_CONTROL: control <= control_m;
        IO_IDX_PMASK:   pmask   <= pmask_m;
        IO_IDX_DPYCTL:  dpyctl  <= dpyctl_m;
        default: ;
      endcase
    end
  end
`endif

endmodule : tms34010_io_cpu_config
`default_nettype wire
