// CPU-facing I/O read mux.  Long/special config and status readbacks come from
// CE-domain shadows; every other I/O register, including live H/V counters,
// remains on the architectural asynchronous io_regs read path.
`default_nettype none
module tms34010_io_cpu_read_mux
  import tms34010_pkg::*;
(
  input  wire logic                  is_io,
  input  wire logic [ADDR_WIDTH-1:0] addr,
  input  wire logic [15:0]           live_rdata,
  input  wire logic [15:0]           psize,
  input  wire logic [15:0]           convdp,
  input  wire logic [15:0]           convsp,
  input  wire logic [15:0]           control,
  input  wire logic [15:0]           pmask,
  input  wire logic [15:0]           intenb,
  input  wire logic [15:0]           intpend,
  input  wire logic [15:0]           hstctlh,
  output logic [15:0]                cpu_rdata
);
  wire [IO_REG_IDX_W-1:0] rd_idx = addr[IO_REG_IDX_W+3:4];

  always_comb begin
    cpu_rdata = live_rdata;
`ifndef MUT_IO_LIVE_READBACK
    if (is_io) begin
      case (rd_idx)
        IO_IDX_PSIZE:   cpu_rdata = psize;
        IO_IDX_CONVDP:  cpu_rdata = convdp;
        IO_IDX_CONVSP:  cpu_rdata = convsp;
        IO_IDX_CONTROL: cpu_rdata = control;
        IO_IDX_PMASK:   cpu_rdata = pmask;
        IO_IDX_INTENB:  cpu_rdata = intenb;
        IO_IDX_INTPEND: cpu_rdata = intpend;
        IO_IDX_HSTCTLH: cpu_rdata = hstctlh;
        default: ;
      endcase
    end
`endif
  end
endmodule : tms34010_io_cpu_read_mux
`default_nettype wire
