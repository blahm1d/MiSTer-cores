// CPU-domain shadows for interrupt/status I/O registers.
// Accepted CPU writes forward at their retiring ack.  A per-register bridge
// then holds the forwarded value for one further CPU edge so the full-rate
// physical io_reg commit cannot be sampled one edge stale in /1 operation.
`default_nettype none
module tms34010_io_cpu_status
  import tms34010_pkg::*;
(
  input  wire logic                  clk,
  input  wire logic                  rst,
  input  wire logic                  ce_cpu,
  input  wire logic                  req,
  input  wire logic                  we,
  input  wire logic                  is_io,
  input  wire logic                  ack,
  input  wire logic [ADDR_WIDTH-1:0] addr,
  input  wire logic [15:0]           wdata,
  // Field size of the access (1..32). Sub-word writes (e.g. `SETF 1,0,0` then
  // MOVE Rs,@INTENB+DIP) must merge into the shadow, not replace it.
  input  wire logic [FIELD_SIZE_WIDTH-1:0] size,
  input  wire logic [15:0]           live_intenb,
  input  wire logic [15:0]           live_intpend,
  input  wire logic [15:0]           live_hstctlh,
  input  wire logic                  nmi_clear,
  output logic [15:0]                intenb,
  output logic [15:0]                intpend,
  output logic [15:0]                hstctlh
);

  logic intenb_write_bridge;
  logic intpend_write_bridge;
  logic hstctlh_write_bridge;
  wire [IO_REG_IDX_W-1:0] wr_idx = addr[IO_REG_IDX_W+3:4];
  wire status_write = (ce_cpu !== 1'b0) && req && we && is_io && ack;
  wire [15:0] intenb_merged  = io_field_merge(intenb,  wdata, addr[3:0], size);
  wire [15:0] intpend_merged = io_field_merge(intpend, wdata, addr[3:0], size);
  wire [15:0] hstctlh_merged = io_field_merge(hstctlh, wdata, addr[3:0], size);

  always_ff @(posedge clk) begin
    if (rst) begin
      intenb  <= 16'h0000;
      intpend <= 16'h0000;
      hstctlh <= 16'h0000;
      intenb_write_bridge  <= 1'b0;
      intpend_write_bridge <= 1'b0;
      hstctlh_write_bridge <= 1'b0;
    end else if (ce_cpu !== 1'b0) begin
      if (status_write && wr_idx == IO_IDX_INTENB) begin
        intenb <= intenb_merged;
        intenb_write_bridge <= 1'b1;
      end else begin
`ifndef MUT_IO_STATUS_NO_BRIDGE
        if (intenb_write_bridge) begin
          intenb_write_bridge <= 1'b0;       // one-CE hold
        end else begin
`endif
          intenb <= live_intenb;
          intenb_write_bridge <= 1'b0;
`ifndef MUT_IO_STATUS_NO_BRIDGE
        end
`endif
      end

      if (status_write && wr_idx == IO_IDX_INTPEND) begin
`ifdef MUT_IO_INTPEND_WHOLE_WRITE
        intpend <= intpend_merged;
`else
        // Match the physical register exactly at CPU retirement: DI/WV are
        // write-zero-to-clear, while all read-only/reserved bits ignore data.
        intpend <= intpend_apply_cpu_write(intpend,intpend_merged);
`endif
        intpend_write_bridge <= 1'b1;
      end else begin
`ifndef MUT_IO_STATUS_NO_BRIDGE
        if (intpend_write_bridge) begin
          intpend_write_bridge <= 1'b0;      // one-CE hold
        end else begin
`endif
          intpend <= live_intpend;
          intpend_write_bridge <= 1'b0;
`ifndef MUT_IO_STATUS_NO_BRIDGE
        end
`endif
      end

      if (status_write && wr_idx == IO_IDX_HSTCTLH) begin
        hstctlh <= hstctlh_merged;
        hstctlh_write_bridge <= 1'b1;
      end else begin
`ifndef MUT_IO_STATUS_NO_BRIDGE
        if (hstctlh_write_bridge) begin
          hstctlh_write_bridge <= 1'b0;      // one-CE hold
        end else begin
`endif
          hstctlh <= live_hstctlh;
          hstctlh_write_bridge <= 1'b0;
`ifndef MUT_IO_STATUS_NO_BRIDGE
        end
`endif
      end

      // Taking NMI must suppress the sampled request before the core returns to
      // FETCH, even if it coincides with a forwarded/bridged host-control value.
      if (nmi_clear)
        hstctlh[HSTCTL_NMI_BIT] <= 1'b0;
    end
  end

endmodule : tms34010_io_cpu_status
`default_nettype wire
