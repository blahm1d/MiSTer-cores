// stv_vram_ddr_top.sv — VRAM-in-DDR3 subsystem (P1). Drop-in for vram_sdram_top: same
// accessor ports, but VRAM lives in the HPS DDR3 (f2h_sdram1) — freeing the SDRAM port so
// the scanout no longer starves the CPU.
//
// INCREMENT 2 (this file): the scanout is now served by a ROW-BURST CACHE (the bandwidth win).
// yunit_scanline (the proven W3 double-buffer) is UNCHANGED and still issues one scan_req per
// column; on the first miss of a row the cache bursts the WHOLE row (128 beats = 512 entries)
// from DDR3 in ONE transaction, then serves every column of that row from a 128x64b BRAM at a
// ~2-clk hit. So a line costs ~1 burst instead of 512 single reads.
//
// Two requesters share the single DDR3 agent (single-outstanding), muxed by a grant-held L2
// arbiter (scanout burst = priority; it is real-time but rare — once per row):
//   A = the proven vram_sdram_top (CPU field RMW + blitter fb + autoerase) with its scanout
//       port tied off; its single 16-bit sd_* word port is translated to single-beat DDR3
//       accesses via the 4:1 packing (entry>>2 = beat, entry[1:0] = lane, 2-byte lane BE).
//   B = the scanout row cache: burst-fills a row, serves scan_req from cache.
//
// 4:1 packing: entry = (row<<9)|col ; beat = entry>>2 ; lane = entry[1:0]. A 512-entry row =
// 128 contiguous beats at beat_base = row<<7. Reset: accessor engines + A/B/L2 on core rst;
// the persistent DDR agent on sdram_por (P0022).
`default_nettype none
module stv_vram_ddr_top #(
    parameter int VRAMW = 32'h40000,
    parameter [28:0] VRAM_DDR_BASE = 29'h6400000,
    parameter int POSTED_WRITE_GUARD = 255
)(
    input  wire logic    clk,
    input  wire logic    rst,
    input  wire logic    sdram_por,
    // CPU field access
    input  wire logic    req,
    input  wire logic    we,
    input  wire logic [27:0] widx,
    input  wire logic [3:0] boff,
    input  wire logic [5:0] sz,
    input  wire logic [31:0] wd,
    input  wire logic    videobank,
    input  wire logic [15:0] dma_palette,
    output logic [31:0]  rdata,
    output logic         done,
    output logic         cpu_snoop_valid,
    output logic [18:0]  cpu_snoop_addr,
    output logic [63:0]  cpu_snoop_data,
    output logic         cpu_snoop_pending,
    output logic         cpu_snoop_overflow,
    // blitter framebuffer write
    input  wire logic    fb_we,
    input  wire logic [18:0] fb_addr,
    input  wire logic [15:0] fb_wdata,
    output logic         fb_ack,
    output logic         wr_busy,     // write path still draining (combiner/FIFO/C-lane) — for the blit-done handshake
    output logic [2:0]   dbg_cst,     // DIAG: C-lane drain FSM state (C_IDLE/C_RD/C_MRG/C_WR/C_BURST) — pin the wedge point
    // autoerase sweep
    input  wire logic    erase_start,
    input  wire logic [8:0] erase_row0,
    input  wire logic [9:0] erase_lines,
    output logic         erase_busy,
    // video scanout read
    input  wire logic    scan_req,
    input  wire logic [18:0] scan_addr,
    output logic [15:0]  scan_data,
    output logic         scan_ack,
    // TMS34010 shift-register transfer. One request latches/transfers a
    // complete 1024-entry row pair through the dedicated D lane.
    input  wire logic    srt_req,
    input  wire logic    srt_we,
    input  wire logic [18:0] srt_entry,
    output logic         srt_done,
    output logic [31:0]  srt_e0e1,
    // DDR3 Avalon master
    output logic [28:0]  ddram_addr,
    output logic [ 7:0]  ddram_burstcnt,
    output logic         ddram_rd,
    output logic         ddram_we,
    output logic [63:0]  ddram_din,
    output logic [ 7:0]  ddram_be,
    input  wire logic    ddram_busy,
    input  wire logic [63:0] ddram_dout,
    input  wire logic    ddram_dout_ready
);
    function automatic logic [7:0] lane_be(input [1:0] l);
        case (l) 2'd0: lane_be=8'h03; 2'd1: lane_be=8'h0C; 2'd2: lane_be=8'h30; default: lane_be=8'hC0; endcase
    endfunction

    // ================= A: proven accessors (scanout tied off) -> single 16b sd_* port =========
    logic [20:0] sd_addr;  logic [15:0] sd_din;  logic [1:0] sd_be;  logic sd_rd, sd_wr;
    logic [15:0] sd_dout;  logic sd_ack;
    logic [31:0] slow_rdata;logic slow_done;
    // The store router presents req as a one-cycle start pulse.  The A-side
    // cache can be occupied by a scanout-forced dirty-line flush when that
    // pulse arrives, so capture every CPU command before selecting the fast
    // cache path or the serialized field engine.  Without this queue, a
    // 32-bit request arriving during A_FLUSH vanished and left the 34010
    // stalled forever waiting for a completion that could never be produced.
    logic cpu_pending,cpu_slow_active,slow_launch;
    logic cpu_we;
    logic [27:0]cpu_widx;
    logic [3:0]cpu_boff;
    logic [5:0]cpu_sz;
    logic [31:0]cpu_wd;
    logic cpu_videobank;
    logic [15:0]cpu_palette;
    wire logic fast_eligible=cpu_pending&&cpu_we&&(cpu_boff==4'd0)&&
                             (((cpu_sz==6'd32)&&!cpu_widx[0])
`ifndef MUT_TUNIT_VRAM_NO_FAST16_BANK1
                              ||((cpu_sz==6'd16)&&cpu_videobank)
`endif
                             );
    logic fast_pending,fast_done,fast_videobank,fast_is16;
    logic [27:0]fast_widx;
    logic [31:0]fast_wdata;
    logic [15:0]fast_palette;
    logic slow_pending,slow_rd,slow_wr;
    logic [20:0]slow_addr;
    logic [15:0]slow_din;
    logic [1:0]slow_be;
    wire logic fast_work=fast_pending;
    wire logic slow_work=slow_pending;
    wire logic [27:0]fast_widx_now=fast_widx;
    wire logic [31:0]fast_wdata_now=fast_wdata;
    wire logic fast_videobank_now=fast_videobank;
    wire logic fast_is16_now=fast_is16;
    wire logic [15:0]fast_palette_now=fast_palette;
    assign rdata=slow_rdata;
    assign done=slow_done||fast_done;
    vram_sdram_top #(.VRAMW(VRAMW), .SD_AW(21), .VRAM_BASE(21'd0)) u_acc (
        .clk(clk), .rst(rst),
        .req(slow_launch), .we(cpu_we), .widx(cpu_widx), .boff(cpu_boff), .sz(cpu_sz), .wd(cpu_wd),
        .videobank(cpu_videobank), .dma_palette(cpu_palette), .rdata(slow_rdata), .done(slow_done),
        .fb_we(1'b0), .fb_addr(19'd0), .fb_wdata(16'd0), .fb_ack(),   // W-THRU2: fb bypasses the sd path
        .erase_start(erase_start), .erase_row0(erase_row0), .erase_lines(erase_lines), .erase_busy(erase_busy),
        .scan_req(1'b0), .scan_addr(19'd0), .scan_data(), .scan_ack(),
        .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
        .sd_dout(sd_dout), .sd_ack(sd_ack) );

    // A-side request to the L2 arbiter (levels held until *_done). The CPU
    // port keeps an eight-beat write-back line. T-unit clears and copies VRAM
    // with sequential 32-bit fields: one DDR burst fill plus one full-byte-enable
    // burst writeback replaces eight read/modify/write round trips while still
    // preserving the untouched video plane.
    localparam int A_LINE_BEATS=8;
    logic        a_start, a_wr, a_is_burst;
    logic [25:0] a_addr;
    logic [63:0] a_wdata;
    logic [ 7:0] a_be, a_burstlen;
    logic        a_done, a_rd_valid;   // driven by L2
    logic [63:0] a_rdata;              // driven by L2
    // This is a true read/modify/write store: a_fast_merge/a_lane_merge must
    // see the OLD cache word on a same-address write so the unselected video
    // byte plane survives. Quartus 17 implements that Verilog behavior with
    // pass-through logic around a DONT_CARE M10K primitive (warning 276020).
    // Keep the resource choice explicit; the release gate verifies both the
    // mapper's semantic-preservation warning and the emitted bypass nodes.
    (* ramstyle = "M10K" *) logic [63:0] a_cache [0:A_LINE_BEATS-1];
    logic [16:0] a_cache_base;
    logic [2:0]  a_fill_index, a_stream_index;
    logic [7:0]  a_fill_valid;
    logic [7:0]  a_cache_idle;
    logic        a_cache_valid, a_cache_dirty;
    logic        a_rc_write;
    logic        a_snoop_valid;
    logic [18:0] a_snoop_addr;
    logic [63:0] a_snoop_data;
    logic [9:0]  a_rc_row;
    logic [6:0]  a_rc_beat;
    logic [63:0] a_rc_data;
    logic        b_start;
    logic [25:0] b_addr;
    logic [7:0]  b_burstlen;
    logic        b_overlap_q;
    wire         c_busy;
    wire         tst_wnext;
    logic        c_start, c_wr, c_done;
    logic        a_rmw_lock;
    logic        c_idle_q;
    logic        a_lookup_hit;
    logic        a_flush_soon;
    logic        d_cache_invalidate;
    logic        d_block;
    wire  [16:0] a_req_beat = fast_work?fast_widx_now[17:1]:slow_addr[18:2];
    wire  [16:0] a_req_base = {a_req_beat[16:3],3'b000};
    wire         a_cache_hit = a_cache_valid && c_idle_q &&
                               (a_cache_base[16:3] == a_req_beat[16:3]);
    wire [17:0]  b_last_beat={1'b0,b_addr[16:0]}+{10'd0,b_burstlen}-18'd1;
    wire         b_cache_overlap=b_start&&b_overlap_q;
    // c_idle_q goes low on the first accepted framebuffer request, before the
    // combiner can launch a C-lane transaction. Using that registered guard
    // here preserves the dirty-line ordering while removing live FIFO-pointer
    // state from the A-side launch cone.
    wire         a_forced_flush_req = a_cache_dirty &&
                                      (b_cache_overlap || !c_idle_q ||
                                       d_block || (a_cache_idle >= 8'd192)
                                       || a_flush_soon
                                      );
    wire  [63:0] a_burst_data = a_cache[a_stream_index];
    wire  [63:0] a_hit_data = a_cache[a_req_beat[2:0]];
    // Critical-word-first fill discriminator.  The serialized field engine
    // holds one 16-bit lane request in slow_pending.  Once that request's
    // 64-bit beat has returned, it is safe to serve/merge the lane even while
    // the remainder of the eight-beat line continues filling.
    wire         a_fill_slow_same_line = slow_work &&
                         (a_cache_base[16:3] == a_req_beat[16:3]);
    wire         a_fill_slow_incoming = a_rd_valid &&
                         (a_fill_index == a_req_beat[2:0]);
    wire         a_fill_slow_ready = a_fill_slow_same_line &&
                         (a_fill_valid[a_req_beat[2:0]] ||
                          a_fill_slow_incoming);
    wire  [63:0] a_fill_slow_data = a_fill_slow_incoming
                                    ? a_rdata : a_hit_data;
    wire         a_fill_fast_same_line = fast_work &&
                         (a_cache_base[16:3] == a_req_beat[16:3]);
    wire         a_fill_fast_incoming = a_rd_valid &&
                         (a_fill_index == a_req_beat[2:0]);
    wire         a_fill_fast_ready = a_fill_fast_same_line &&
                         (a_fill_valid[a_req_beat[2:0]] ||
                          a_fill_fast_incoming);
`ifdef MUT_TUNIT_VRAM_WAIT_FULL_FILL
    wire         a_fill_fast_accept = 1'b0;
`else
    wire         a_fill_fast_accept = a_fill_fast_ready;
`endif
    wire  [63:0] a_fill_fast_data = a_fill_fast_incoming
                                    ? a_rdata : a_hit_data;
    localparam [2:0] A_IDLE=3'd0, A_FILL=3'd1, A_FLUSH=3'd2,
                     A_ACK=3'd3, A_FAST_WAIT=3'd4, A_LOOKUP=3'd5;
    logic [2:0] ats;

    function automatic [63:0] a_lane_merge(
        input [63:0] old_data, input [1:0] lane,
        input [15:0] new_data, input [1:0] be);
        logic [63:0] result;
        begin
            result=old_data;
            if(be[0])result[lane*16 +: 8]=new_data[7:0];
            if(be[1])result[lane*16+8 +: 8]=new_data[15:8];
            a_lane_merge=result;
        end
    endfunction

    function automatic [63:0] a_fast_merge(
        input [63:0] old_data,input [31:0] new_data,
        input logic bank,input [15:0] palette);
        logic [63:0] result;
        begin
            result=old_data;
            if(bank)begin
                result[15:0]={palette[7:0],new_data[7:0]};
                result[31:16]={palette[15:8],new_data[15:8]};
                result[47:32]={palette[7:0],new_data[23:16]};
                result[63:48]={palette[15:8],new_data[31:24]};
            end else begin
                result[15:8]=new_data[7:0];
                result[31:24]=new_data[15:8];
                result[47:40]=new_data[23:16];
                result[63:56]=new_data[31:24];
            end
            a_fast_merge=result;
        end
    endfunction

    function automatic [63:0] a_fast16_bank1_merge(
        input [63:0] old_data,input logic half,
        input [15:0] new_data,input [15:0] palette);
        logic [63:0] result;
        begin
            result=old_data;
            if(!half)begin
                result[15:0]={palette[7:0],new_data[7:0]};
`ifndef MUT_TUNIT_FAST16_DROP_UPPER
                result[31:16]={palette[15:8],new_data[15:8]};
`endif
            end else begin
                result[47:32]={palette[7:0],new_data[7:0]};
`ifndef MUT_TUNIT_FAST16_DROP_UPPER
                result[63:48]={palette[15:8],new_data[15:8]};
`endif
            end
            a_fast16_bank1_merge=result;
        end
    endfunction

    wire [63:0] a_fast_write_data = fast_is16_now ?
        a_fast16_bank1_merge(a_hit_data,fast_widx_now[0],
                             fast_wdata_now[15:0],fast_palette_now) :
        a_fast_merge(a_hit_data,fast_wdata_now,
                     fast_videobank_now,fast_palette_now);
    wire [63:0] a_fill_fast_write_data = fast_is16_now ?
        a_fast16_bank1_merge(a_fill_fast_data,fast_widx_now[0],
                             fast_wdata_now[15:0],fast_palette_now) :
        a_fast_merge(a_fill_fast_data,fast_wdata_now,
                     fast_videobank_now,fast_palette_now);

    always_ff @(posedge clk) begin
        if (rst) begin
            ats<=A_IDLE; a_start<=1'b0; a_wr<=1'b0; a_is_burst<=1'b0;
            a_addr<=26'd0; a_wdata<=64'd0; a_be<=8'd0; a_burstlen<=8'd1;
            a_cache_base<=17'd0; a_fill_index<=3'd0; a_stream_index<=3'd0;
            a_fill_valid<=8'd0;
            a_cache_idle<=8'd0; a_cache_valid<=1'b0; a_cache_dirty<=1'b0;
            a_rmw_lock<=1'b0; a_lookup_hit<=1'b0;a_flush_soon<=1'b0;
            sd_ack<=1'b0; sd_dout<=16'd0;
            fast_pending<=1'b0;fast_done<=1'b0;fast_widx<=28'd0;
            fast_wdata<=32'd0;fast_videobank<=1'b0;fast_palette<=16'd0;
            fast_is16<=1'b0;
            cpu_pending<=1'b0;cpu_slow_active<=1'b0;slow_launch<=1'b0;
            cpu_we<=1'b0;cpu_widx<=28'd0;cpu_boff<=4'd0;cpu_sz<=6'd0;
            cpu_wd<=32'd0;cpu_videobank<=1'b0;cpu_palette<=16'd0;
            slow_pending<=1'b0;slow_rd<=1'b0;slow_wr<=1'b0;
            slow_addr<=21'd0;slow_din<=16'd0;slow_be<=2'b00;
            a_rc_write<=1'b0;a_rc_row<=10'd0;a_rc_beat<=7'd0;a_rc_data<=64'd0;
            a_snoop_valid<=1'b0;a_snoop_addr<=19'd0;a_snoop_data<=64'd0;
        end else begin
            sd_ack<=1'b0;fast_done<=1'b0;slow_launch<=1'b0;
            a_rc_write<=1'b0;a_snoop_valid<=1'b0;
            if(req&&!cpu_pending&&!cpu_slow_active&&!fast_pending)begin
                cpu_pending<=1'b1;cpu_we<=we;cpu_widx<=widx;cpu_boff<=boff;
                cpu_sz<=sz;cpu_wd<=wd;cpu_videobank<=videobank;
                cpu_palette<=dma_palette;
            end
            if(slow_done)cpu_slow_active<=1'b0;
            if(a_cache_dirty && a_cache_idle!=8'hff)a_cache_idle<=a_cache_idle+1'b1;
            if(c_done&&c_wr)a_cache_valid<=1'b0;
            if(d_cache_invalidate)a_cache_valid<=1'b0;
            if(tst_wnext&&a_start&&a_wr&&a_is_burst)
                a_stream_index<=a_stream_index+1'b1;
            case(ats)
                A_IDLE: begin
                    a_is_burst<=1'b0;a_burstlen<=8'd1;
                    if(fast_eligible&&!fast_pending)begin
                        cpu_pending<=1'b0;
                        fast_pending<=1'b1;fast_widx<=cpu_widx;fast_wdata<=cpu_wd;
                        fast_videobank<=cpu_videobank;fast_palette<=cpu_palette;
                        fast_is16<=(cpu_sz==6'd16);
                    end else if(cpu_pending&&!cpu_slow_active)begin
                        cpu_pending<=1'b0;cpu_slow_active<=1'b1;
                        slow_launch<=1'b1;
                    end
                    if((sd_rd||sd_wr)&&!slow_pending)begin
                        slow_pending<=1'b1;slow_rd<=sd_rd;slow_wr<=sd_wr;
                        slow_addr<=sd_addr;slow_din<=sd_din;slow_be<=sd_be;
                    end
                    if(a_forced_flush_req)begin
                        a_addr<={9'd0,a_cache_base};a_be<=8'hff;a_burstlen<=A_LINE_BEATS;
                        a_stream_index<=3'd0;a_wr<=1'b1;a_is_burst<=1'b1;
                        a_start<=1'b1;a_rmw_lock<=1'b1;a_flush_soon<=1'b0;
                        ats<=A_FLUSH;
                    end else if(fast_work||slow_work)begin
                        // Register the tag result before selecting hit,
                        // writeback, or fill. This cuts the pending-request
                        // and tag-compare cone away from a_start.
                        a_lookup_hit<=a_cache_hit;ats<=A_LOOKUP;
                    end
                end
                A_LOOKUP: begin
                    // A newly busy C lane or scan overlap can arise during
                    // the lookup stage. Treat either conservatively as a
                    // writeback request. A cache invalidation during lookup
                    // converts a formerly hit request into a miss.
                    if(a_cache_dirty&&
                       (!a_lookup_hit||!a_cache_valid||!c_idle_q||
                        b_cache_overlap||(a_cache_idle>=8'd192)))begin
                        a_addr<={9'd0,a_cache_base};a_be<=8'hff;a_burstlen<=A_LINE_BEATS;
                        a_stream_index<=3'd0;a_wr<=1'b1;a_is_burst<=1'b1;
                        a_start<=1'b1;a_rmw_lock<=1'b1;ats<=A_FLUSH;
                    end else if(fast_work&&a_lookup_hit&&a_cache_valid&&c_idle_q)begin
                        a_cache[a_req_beat[2:0]]<=a_fast_write_data;
                        a_rc_write<=1'b1;a_rc_row<=a_req_beat[16:7];
                        a_rc_beat<=a_req_beat[6:0];
                        a_rc_data<=a_fast_write_data;
                        a_snoop_valid<=1'b1;
                        a_snoop_addr<={a_req_beat,2'b00};
                        a_snoop_data<=a_fast_write_data;
                        a_cache_dirty<=1'b1;a_cache_idle<=8'd0;
`ifndef MUT_TUNIT_VRAM_NO_TAIL_TRIGGER
                        if(fast_is16_now&&fast_videobank_now&&
                           (a_req_beat[2:0]==3'd7)&&fast_widx_now[0])
                          a_flush_soon<=1'b1;
`endif
                        fast_pending<=1'b0;fast_done<=1'b1;ats<=A_FAST_WAIT;
                    end else if(slow_work&&a_lookup_hit&&a_cache_valid&&c_idle_q)begin
                        if(slow_rd)begin
                            case(slow_addr[1:0])
                                2'd0:sd_dout<=a_hit_data[15:0];2'd1:sd_dout<=a_hit_data[31:16];
                                2'd2:sd_dout<=a_hit_data[47:32];default:sd_dout<=a_hit_data[63:48];
                            endcase
                        end else begin
                            a_cache[a_req_beat[2:0]]<=a_lane_merge(
                                a_hit_data,slow_addr[1:0],slow_din,slow_be);
                            a_cache_dirty<=1'b1;a_cache_idle<=8'd0;
`ifndef MUT_TUNIT_VRAM_NO_TAIL_TRIGGER
                            if(cpu_videobank&&(cpu_sz==6'd16)&&
                               (cpu_boff==4'd0)&&
                               (a_req_beat[2:0]==3'd7)&&
                               (slow_addr[1:0]==2'd3))
                              a_flush_soon<=1'b1;
`endif
                        end
                        slow_pending<=1'b0;sd_ack<=1'b1;ats<=A_ACK;
                    end else begin
                        // A clean miss fills the complete line. A dirty miss
                        // is handled by the writeback arm above while the
                        // request remains held in its pending register.
                        a_cache_base<=a_req_base;a_cache_valid<=1'b0;
                        a_fill_index<=3'd0;a_fill_valid<=8'd0;
                        a_addr<={9'd0,a_req_base};a_be<=8'h00;a_burstlen<=A_LINE_BEATS;
                        a_wr<=1'b0;a_is_burst<=1'b1;a_start<=1'b1;ats<=A_FILL;
                    end
                end
                A_FILL: begin
                    if(a_rd_valid)begin
                        a_cache[a_fill_index]<=a_rdata;
                        a_fill_valid[a_fill_index]<=1'b1;
                        a_fill_index<=a_fill_index+1'b1;
                    end
                    // Do not wait for the unused tail of the line. Reads use
                    // the just-returned critical beat directly; writes merge
                    // into that complete beat and issue the same full-data
                    // row-cache/scanout snoop as an ordinary cache hit.
                    if(a_fill_slow_ready)begin
                        if(slow_rd)begin
                            case(slow_addr[1:0])
                                2'd0:sd_dout<=a_fill_slow_data[15:0];
                                2'd1:sd_dout<=a_fill_slow_data[31:16];
                                2'd2:sd_dout<=a_fill_slow_data[47:32];
                                default:sd_dout<=a_fill_slow_data[63:48];
                            endcase
                        end else begin
                            a_cache[a_req_beat[2:0]]<=a_lane_merge(
                                a_fill_slow_data,slow_addr[1:0],slow_din,slow_be);
                            a_cache_dirty<=1'b1;a_cache_idle<=8'd0;
`ifndef MUT_TUNIT_VRAM_NO_TAIL_TRIGGER
                            if(cpu_videobank&&(cpu_sz==6'd16)&&
                               (cpu_boff==4'd0)&&
                               (a_req_beat[2:0]==3'd7)&&
                               (slow_addr[1:0]==2'd3))
                              a_flush_soon<=1'b1;
`endif
                            a_rc_write<=1'b1;a_rc_row<=a_req_beat[16:7];
                            a_rc_beat<=a_req_beat[6:0];
                            a_rc_data<=a_lane_merge(
                                a_fill_slow_data,slow_addr[1:0],slow_din,slow_be);
                            a_snoop_valid<=1'b1;
                            a_snoop_addr<={a_req_beat,2'b00};
                            a_snoop_data<=a_lane_merge(
                                a_fill_slow_data,slow_addr[1:0],slow_din,slow_be);
                        end
                        slow_pending<=1'b0;sd_ack<=1'b1;
                    end
                    if(a_fill_fast_accept)begin
                        a_cache[a_req_beat[2:0]]<=a_fill_fast_write_data;
                        a_cache_dirty<=1'b1;a_cache_idle<=8'd0;
                        a_rc_write<=1'b1;a_rc_row<=a_req_beat[16:7];
                        a_rc_beat<=a_req_beat[6:0];
                        a_rc_data<=a_fill_fast_write_data;
                        a_snoop_valid<=1'b1;
                        a_snoop_addr<={a_req_beat,2'b00};
                        a_snoop_data<=a_fill_fast_write_data;
`ifndef MUT_TUNIT_VRAM_NO_TAIL_TRIGGER
                        if(fast_is16_now&&fast_videobank_now&&
                           (a_req_beat[2:0]==3'd7)&&fast_widx_now[0])
                          a_flush_soon<=1'b1;
`endif
                        fast_pending<=1'b0;fast_done<=1'b1;
                    end
                    if(a_done)begin
                        a_start<=1'b0;a_is_burst<=1'b0;a_cache_valid<=1'b1;
                        a_fill_valid<=8'hff;
                        a_cache_dirty<=a_cache_dirty ||
                                       (a_fill_slow_ready&&slow_wr) ||
                                       a_fill_fast_accept;
                        a_cache_idle<=8'd0;ats<=A_IDLE;
                    end
                end
                A_FLUSH: if(a_done)begin
                    a_start<=1'b0;a_wr<=1'b0;a_is_burst<=1'b0;a_rmw_lock<=1'b0;
                    a_cache_dirty<=1'b0;a_cache_idle<=8'd0;a_flush_soon<=1'b0;
                    ats<=A_IDLE;
                end
                A_ACK:ats<=A_IDLE;
                A_FAST_WAIT:if(!req)ats<=A_IDLE;
                default:ats<=A_IDLE;
            endcase
        end
    end

    // ================= B: scanout row-burst cache ============================================
    // no_rw_check REMOVED: the promise (no address read and written in the same cycle)
  // is FALSE here, and this project's map.rpt proved the consequence -- the sibling
  // scanline array took DONT_CARE, whose collision output Quartus documents as
  // UNDEFINED while Verilog models it as deterministic OLD data. That is a guaranteed
  // sim/silicon divergence: every gate in this tree validates against the Verilog
  // semantics, so the attribute makes silicon disagree with the only oracle we have.
  // Removing it costs a defined mode and nothing else. Audit prompted by Gladiator.
  (* ramstyle = "M10K" *) logic [63:0] rc [0:127]; // one row = 128 beats x 4 entries
    logic [9:0]  rc_row;  logic rc_valid;
    wire  [9:0]  req_row = scan_addr[18:9];   // continuous (NOT `logic = ...`, which is init-only)
    wire  [8:0]  req_col = scan_addr[8:0];
    logic [63:0] rc_q;  wire [6:0] rc_raddr = req_col[8:2];  logic [1:0] rc_rlane;
    logic rc_we;
    logic [6:0] rc_waddr;
    logic [63:0] rc_wdata;
    always_ff @(posedge clk) begin
        if (rc_we) rc[rc_waddr] <= rc_wdata;
        rc_q <= rc[rc_raddr];                                // reads the CURRENT scan col's beat (1 clk)
    end

    // per-sub-burst address/length are declared beside A's overlap detector.
    logic        b_done, b_rd_valid;   // driven by L2
    logic [63:0] b_rdata;              // driven by L2
    logic [7:0]  fillbeat;
    // A row fill is four independent <=32-beat DDR bursts.  Latch the miss
    // identity across all four: the upstream scanline cache can cancel and
    // retarget scan_addr at vblank while the lower fill is still draining.
    // Using live req_row for later sub-bursts splices two framebuffer rows
    // into one rc[] line and tags the mixture as the later request.
    logic [9:0]  b_fill_row;
    logic        b_fill_dirty;
    logic        cache_wr_evt;
    logic [9:0]  cache_wr_row0, cache_wr_row1;
`ifdef MUT_NO_SCAN_WRITE_COHERENCE
    wire         rc_write_hit = 1'b0;
    wire         fill_write_hit = 1'b0;
`else
    wire         rc_write_hit = cache_wr_evt &&
                                ((rc_row == cache_wr_row0) ||
                                 (rc_row == cache_wr_row1));
    wire         fill_write_hit = cache_wr_evt &&
                                  ((b_fill_row == cache_wr_row0) ||
                                   (b_fill_row == cache_wr_row1));
`endif
    // A row = 128 beats, but the REAL HPS f2sdram UNDER-DELIVERS a burst longer than its max
    // (NS ran 32-beat bursts on HW; the 128-beat request stalled the fill on silicon -> the
    // pulsing-line-on-white hang, reproduced in tb_vram_ddr_xdiff with the 32-cap oracle). Fill
    // the row in <=BMAX sub-bursts, re-requesting from wherever fillbeat reached.
`ifdef MUT_TUNIT_VRAM_SCAN_BURST_32
    // Rollback discriminator: reproduces the long display-side ownership
    // interval that collides with the source-timed NBA CPU copy.
    localparam [7:0] BMAX = 8'd32;
`else
    // The board's CPU and display sides do not impose a 32-beat mutual block.
    // Eight-beat sub-bursts retain the full-row cache but bound the emulated
    // dual-port interference and create regular grant points for CPU/audio.
    localparam [7:0] BMAX = 8'd8;
`endif
    localparam [2:0] B_IDLE=3'd0, B_REQ=3'd1, B_ARM=3'd2,
                     B_FILL=3'd3, B_HIT=3'd4, B_WAIT=3'd5;
    logic [2:0] bts;
    // One syntactic write port lets Quartus infer the row cache as an M10K.
    // The coherency update keeps its original priority over a simultaneous
    // fill beat (it was the later nonblocking assignment in this process).
    always_comb begin
        rc_we = 1'b0;
        rc_waddr = 7'd0;
        rc_wdata = 64'd0;
        if (a_rc_write && rc_valid && (rc_row == a_rc_row)) begin
            rc_we = 1'b1;
            rc_waddr = a_rc_beat;
            rc_wdata = a_rc_data;
        end else if ((bts == B_FILL) && b_rd_valid) begin
            rc_we = 1'b1;
            rc_waddr = fillbeat[6:0];
            rc_wdata = b_rdata;
        end
    end
    always_ff @(posedge clk) begin
        if (rst) begin
            bts<=B_IDLE; b_start<=1'b0; b_addr<=26'd0; b_burstlen<=8'd0;
            b_overlap_q<=1'b0; rc_valid<=1'b0; rc_row<=10'd0;
            b_fill_row<=10'd0; b_fill_dirty<=1'b0; fillbeat<=8'd0;
            rc_rlane<=2'd0; scan_ack<=1'b0; scan_data<=16'd0;
        end else begin
            scan_ack <= 1'b0;
            case (bts)
                B_IDLE: if (scan_req) begin
                    if (rc_valid && !rc_write_hit && (rc_row==req_row)) begin // HIT (rc_raddr combinational -> rc_q aligned by B_HIT)
                        rc_rlane<=req_col[1:0]; bts<=B_HIT;
                    end else begin                                   // MISS -> fill the row in <=BMAX sub-bursts
                        fillbeat<=8'd0; b_fill_row<=req_row;
                        b_fill_dirty<=1'b0; bts<=B_REQ;
                    end
                end
                B_REQ: begin                                        // set up the next sub-burst from fillbeat
`ifdef MUT_LIVE_BFILL_ROW
                    b_addr     <= {9'd0, req_row, 7'd0} + {18'd0, fillbeat};
`else
                    b_addr     <= {9'd0, b_fill_row, 7'd0} + {18'd0, fillbeat};
`endif
                    b_burstlen <= ((8'd128 - fillbeat) > BMAX) ? BMAX : (8'd128 - fillbeat);
                    bts <= B_ARM;
                end
                // Register the overlap decision from the now-stable B
                // address before exposing b_start to the A cache and L2
                // arbiter.  This replaces a wide cross-lane single-cycle
                // address/flush cone with a one-bit ordering guard.
                B_ARM: begin
                    b_overlap_q <=
                        ({1'b0,a_cache_base}<=b_last_beat)&&
                        ({1'b0,a_cache_base}+18'd7>={1'b0,b_addr[16:0]});
                    b_start <= 1'b1;
                    bts <= B_FILL;
                end
                B_FILL: begin
                    if (b_rd_valid) begin
                        fillbeat <= fillbeat + 8'd1;
                    end
                    if (b_done) begin                               // sub-burst complete
                        b_start <= 1'b0;
                        if (fillbeat >= 8'd128) begin
                            if (b_fill_dirty || fill_write_hit)
                                rc_valid<=1'b0;
                            else
                                rc_valid<=1'b1;
`ifdef MUT_LIVE_BFILL_ROW
                            rc_row<=req_row;
`else
                            rc_row<=b_fill_row;
`endif
                            bts<=B_IDLE;
                        end
                        else bts <= B_REQ;                          // more of the row to fetch
                    end
                end
                B_HIT: begin                                          // rc_q valid now
                    case (rc_rlane)
                        2'd0: scan_data<=rc_q[15:0]; 2'd1: scan_data<=rc_q[31:16];
                        2'd2: scan_data<=rc_q[47:32]; default: scan_data<=rc_q[63:48];
                    endcase
                    scan_ack<=1'b1; bts<=B_WAIT;
                end
                B_WAIT: if (!scan_req) bts<=B_IDLE;   // ONE ack per request: wait for the consumer to drop
                                                      // scan_req before re-arming, else B_IDLE re-detects the
                                                      // still-high scan_req as a 2nd hit -> double-serve ->
                                                      // the next column reads this column's beat (col shift).
                default: bts<=B_IDLE;
            endcase
            // An SRT transfer replaces two complete rows. A cache line filled
            // before that transfer must never be published afterward.
            if (d_cache_invalidate) rc_valid<=1'b0;
            // Match the cabinet-proven Wolf cache contract: never serve a
            // warm line, or publish an in-progress fill, across a framebuffer
            // writer touching either row in the affected span.
            if (rc_write_hit) rc_valid<=1'b0;
            if ((bts==B_REQ || bts==B_ARM || bts==B_FILL) && fill_write_hit)
                b_fill_dirty<=1'b1;
        end
    end

    // ================= D: SRT row-pair engine declarations =================
    // 1024 16-bit entries pack into 256 64-bit DDR beats. The buffer is
    // written only during a latch and read only during a transfer.
    (* ramstyle = "M10K" *) logic [63:0] dbuf [0:255];
    logic [16:0] d_base_beat;
    logic        d_op_we;
    logic [8:0]  d_fill;
    logic        d_start, d_wr;
    logic [25:0] d_addr;
    logic [7:0]  d_blen;
    logic        d_done, d_rd_valid;
    logic [63:0] dbuf_q;
    wire         d_burst_next;
    logic [31:0] srt_e0e1_r;
    assign srt_e0e1 = srt_e0e1_r;
    localparam [2:0] D_IDLE=3'd0, D_DRAIN=3'd1, D_RREQ=3'd2,
                     D_RFILL=3'd3, D_WREQ=3'd4, D_WSTREAM=3'd5,
                     D_FIN=3'd6;
    logic [2:0] dst;
    assign d_block = (dst != D_IDLE);
    assign d_cache_invalidate = d_start && d_wr;

    // ================= C: W-THRU2 fb beat write-combine =======================================
    // The blitter fb stream previously rode the 16-bit sd channel: EVERY pixel cost a
    // full-beat RMW pair (~25 clk/px effective) -- the dominant term in the measured frame
    // budget (median attract frame 179k px vs 1.755M cycles). Blit rows are sx-sequential
    // (either direction), so 4 entries/beat combine naturally: FULL beats write with NO
    // RMW read (be=FF, the bridge-safe full-beat pattern, cf. the dl path); partial beats
    // (row edges) RMW. Ordering: the CPU sd lane is gated on a drained combiner (L2 below);
    // a 1-deep own-write forward covers C's partial-flush-after-flush hazard; A's fwd_beat
    // is invalidated on any C write (A must never merge a CPU RMW into a stale copy).
    logic [16:0] wc_beat;      // entry[18:2]
    logic [3:0]  wc_mask;
    logic [63:0] wc_data;
    logic [7:0]  wc_idle;
    localparam [7:0] FB_WFLUSH_IDLE = 8'd64;
    logic        fb_we_d;
    logic        fb_pend;    // held request the combiner could not accept at its edge
    wire  [16:0] fb_beat = fb_addr[18:2];
    wire         fb_same = (wc_mask != 4'd0) && (fb_beat == wc_beat);
    wire         fb_new  = fb_we & ~fb_we_d;          // dma holds fb_we until fb_ack
    wire         fb_req  = fb_new | fb_pend;          // live request (edge or parked)
    // a pending CPU sd op (a_start) FORCES a drain and parks new fb accepts for its
    // duration — without this the sustained fb stream never leaves the combiner empty
    // and the CPU lane starves (contention-gate DEADLOCK, caught 2026-07-10).
    wire         wc_flush_req = (wc_mask != 4'd0) &&
                                ((fb_req && !fb_same) || (wc_idle >= FB_WFLUSH_IDLE) ||
                                 a_start || d_block);
    // c_start/c_wr are declared beside the A-side state that observes them.
    logic [25:0] c_addr;
    logic [63:0] c_wdata;
    logic [7:0]  c_be;
    logic        c_rd_valid;                           // driven by L2
    logic [63:0] c_rdata;                              // driven by L2
    logic [63:0] c_fwd;  logic [16:0] c_fwd_beat;  logic c_fwd_v;   // 1-deep own-write forward
    logic [3:0]  cf_mask;  logic [63:0] cf_data;  logic [16:0] cf_beat;  // latched flush job
    localparam [2:0] C_IDLE=3'd0, C_RD=3'd1, C_MRG=3'd2, C_WR=3'd3, C_BURST=3'd4;
    logic [2:0] cst;
    // WRITE FIFO: completed beats {mask,beat,data} queue here so the combiner (and the blitter's
    // per-pixel fb_ack) never wait on the flush round-trip (combiner->L2->agent->arb->DDR3->back,
    // ~12 clk, the measured 23% write stall). The cst FSM drains the FIFO in the background; the
    // blit only stalls if the FIFO fills (drain can't keep up = truly bandwidth-bound, which the
    // idealized-DDR3 experiment says we are NOT). Sequential blit rows never revisit a beat, so
    // FIFO entries are distinct beats -> a partial-beat RMW never reads a beat still queued.
    localparam int WF_DEPTH = 16;                      // holds a burst's worth (SCAN_MAX=8) + slack; 16:1
    localparam int WF_AW    = 4;                       // muxes vs 32:1 keeps the FIFO off the clk_sys crit path
    logic [3:0]  wf_mask [0:WF_DEPTH-1];
    logic [16:0] wf_beat [0:WF_DEPTH-1];
    // A push into an empty FIFO can write the same physical slot sampled by
    // the registered-head pipeline. Quartus preserves the source behavior
    // with the same checked pass-through implementation used for a_cache.
    (* ramstyle = "M10K" *) logic [63:0] wf_data [0:WF_DEPTH-1];
    logic [WF_AW:0] wf_wptr, wf_rptr;                  // +1 bit for full/empty disambiguation
    wire wf_empty = (wf_wptr == wf_rptr);
    wire wf_full  = (wf_wptr[WF_AW-1:0] == wf_rptr[WF_AW-1:0]) && (wf_wptr[WF_AW] != wf_rptr[WF_AW]);
    assign c_busy = (cst != C_IDLE) || (wc_mask != 4'd0) || !wf_empty;
    // Register the cross-lane idle qualification before it reaches every bit
    // of the A-side cache write port. Blocking a fresh fb request here makes
    // the registered view conservative on both busy transitions: one extra
    // idle cycle after a drain is safe, while a newly accepted C-lane write
    // can never leave a stale one-cycle "idle" window.
    always_ff @(posedge clk) begin
        if (rst) c_idle_q <= 1'b0;
        else     c_idle_q <= !c_busy && !fb_req;
    end
    // wr_busy = write path ACCEPTED all beats (cst idle + combiner + FIFO empty). NOTE: on the real
    // DDRAM (HPS f2h_sdram) bus this is bridge-ACCEPT, not DRAM-LAND (no write-response exists).
    // wolf_dma's S_DONE holds on this accept-level wr_busy before completing a blit -- there is NO
    // separate posted-write-settle counter anywhere in the tree (a prior PW_SETTLE experiment,
    // 3cbae0b, was fully reverted by e1eff3b; this comment previously referenced it stale).
    assign wr_busy = c_busy || (d_block && d_op_we);
    assign dbg_cst = cst;    // DIAG: expose the C-lane FSM state to pin C_RD (RMW read) vs C_WR (drain)
    function automatic [63:0] lane_merge(input [63:0] base, input [63:0] neu, input [3:0] m);
        lane_merge = {m[3] ? neu[63:48] : base[63:48], m[2] ? neu[47:32] : base[47:32],
                      m[1] ? neu[31:16] : base[31:16], m[0] ? neu[15:0]  : base[15:0]};
    endfunction
    wire [WF_AW-1:0] wf_wp = wf_wptr[WF_AW-1:0];
    wire [WF_AW-1:0] wf_rp = wf_rptr[WF_AW-1:0];
    wire same_or_empty = (wc_mask == 4'd0) || fb_same;
    // ---- BURST DRAIN: drain a consecutive full-beat run as ONE Avalon burst so the (high-latency,
    // real f2h) bridge round-trip is paid once per run, not per beat. The blit keeps pushing to the
    // FIFO during the burst (decoupled) -> combines the FIFO's no-stall with burst amortization.
    // (reuses the module-level BMAX=32 — the scanout-proven cab-safe A-side burst cap)
    logic        c_is_burst;                           // current C flush is a multi-beat burst
    logic [7:0]  c_blen;                               // burst length in beats
    logic [25:0] c_burst_addr;                         // burst base (LOWEST) beat address
    logic        c_dir;                                // burst DATA order: 0=ascending(rp up), 1=descending(rp+len-1 down)
    logic [WF_AW-1:0] c_bp;                            // burst data-read index (FWFT; steps +/-1 per beat)
    logic [7:0]  wf_idle;                              // cycles since the last FIFO push (drain-timeout)
    wire  [WF_AW:0] wf_occ = wf_wptr - wf_rptr;         // FIFO occupancy
    wire  [63:0] c_burst_data = wf_data[c_bp];          // streamed head (ascending or descending order)
    wire         c_burst_next;                          // agent accepted a burst beat
    wire         a_cache_wr_evt = a_start && a_wr;
    wire         c_cache_wr_evt = c_start && c_wr;
    wire [16:0]  c_cache_first = c_is_burst ? c_burst_addr[16:0]
                                             : c_addr[16:0];
    wire [16:0]  c_cache_last = c_is_burst
                                  ? (c_burst_addr[16:0] +
                                     {{9{1'b0}},c_blen} - 17'd1)
                                  : c_addr[16:0];
    assign cache_wr_evt = a_cache_wr_evt || c_cache_wr_evt ||
                          d_cache_invalidate;
    assign cache_wr_row0 = a_cache_wr_evt ? a_addr[16:7]
                         : d_cache_invalidate ? d_base_beat[16:7]
                         :                      c_cache_first[16:7];
    assign cache_wr_row1 = a_cache_wr_evt ? a_addr[16:7]
                         : d_cache_invalidate ? (d_base_beat[16:7] + 10'd1)
                         :                      c_cache_last[16:7];
    // BIDIRECTIONAL consecutive FULL-beat run from the head. UMK3 flips sprites (dst sx DESCENDS,
    // wolf_dma:614/658/686) so a mirrored row pushes DESCENDING beats -> must be detected + bursted
    // (streamed reversed) too, else half of MK's sprites never burst. Ascending Avalon burst always
    // starts at the LOWEST beat.
    // SCAN_MAX 8->4 (2026-07-12): the 8-way parallel FIFO scan fanning out of wf_rptr was the
    // dominant setup-critical path (wf_rptr -> Mux85 array-read -> Add10 -> run_len_r, ROUTING-bound,
    // -1.30ns and seed-insensitive). Halving the scan width halves that fanout/congestion. Max burst
    // is now 4 beats (still amortizes the bridge round-trip 4:1 vs single-beat); throughput cost is
    // modest and does not change the coarse starvation-vs-commit blit-count discrimination. NOTE: the
    // eventual throughput-critical FIX build should instead PIPELINE the detector (register the array
    // reads) to keep SCAN_MAX=8; this trim is the low-risk unblock for the measurement build.
    // (casez pattern width is tied to SCAN_MAX — update both together.)
    localparam int SCAN_MAX = 4;                        // max sub-burst = consecutive full beats from the head
    // Register the four FIFO entries before checking consecutiveness. This
    // splits the pointer-driven 16:1 array mux from the compare/priority logic;
    // hd_valid already provides the settling cycle after every head change.
    logic [3:0]          wf_scan_mask [0:SCAN_MAX-1];
    logic [16:0]         wf_scan_beat [0:SCAN_MAX-1];
    logic [WF_AW:0]      wf_scan_occ;
    wire head_full = (wf_scan_mask[0] == 4'hF);
    wire pair_asc  = (wf_scan_occ >= 2) && head_full &&
                     (wf_scan_mask[1] == 4'hF) &&
                     (wf_scan_beat[1] == wf_scan_beat[0] + 17'd1);
    wire pair_desc = (wf_scan_occ >= 2) && head_full &&
                     (wf_scan_mask[1] == 4'hF) &&
                     (wf_scan_beat[1] == wf_scan_beat[0] - 17'd1);
    logic [7:0]          run_len;
    logic [SCAN_MAX-1:0] cons;                          // cons[k]=1: beat rp+k is full AND consecutive (head +/- k)
    integer k;
    always_comb begin
        for (k = 0; k < SCAN_MAX; k = k + 1)
            cons[k] = (k < wf_scan_occ) && (wf_scan_mask[k] == 4'hF) &&
                      ( pair_asc  ? (wf_scan_beat[k] == (wf_scan_beat[0] + k[16:0])) :
                        pair_desc ? (wf_scan_beat[k] == (wf_scan_beat[0] - k[16:0])) :
                                    (k == 0) );
        casez (cons)                                    // leading-consecutive-ones count (find first 0 from LSB)
            4'b???0: run_len = 8'd0;                    // head not a full beat
            4'b??01: run_len = 8'd1;
            4'b?011: run_len = 8'd2;
            4'b0111: run_len = 8'd3;
            default: run_len = 8'd4;                    // all SCAN_MAX consecutive (cons==4'hF)
        endcase
    end
    // LAZY drain: for a run, wait until it's sealed (a non-consecutive beat follows) or the FIFO is
    // near full or the blit paused -> long bursts (whole rows) that amortize the bridge round-trip.
    wire wf_nearfull = (wf_occ >= (WF_DEPTH-4));
    // PIPELINE the FIFO-head read (timing 2026-07-11): the drain FSM consumes REGISTERED head fields,
    // not live 16:1 muxes off wf_rptr. That turned the wf_rptr->c_wdata path (14.66ns, -4.2 setup) into
    // hd_data(reg)->c_wdata(reg). The scan detector has a second register stage,
    // so hd_valid stalls the drain for two cycles after a pop / push-into-empty
    // while the head, run length, direction, and forward-hit snapshot align.
    logic [63:0] hd_data;  logic [16:0] hd_beat;  logic [3:0] hd_mask;
    logic [7:0] run_len_q;
    logic pair_asc_q, pair_desc_q, hd_fwd_hit_q;
    logic [WF_AW:0] wf_rptr_q, wf_rptr_qq;
    logic wf_ne_q, wf_ne_qq;
    wire hd_full    = (hd_mask == 4'hF);
    wire hd_valid   = !wf_empty && (wf_rptr == wf_rptr_q) &&
                      (wf_rptr == wf_rptr_qq) && wf_ne_q && wf_ne_qq;
    wire drain_go_r = hd_full ? ((run_len_q < wf_occ) || wf_nearfull ||
                                 (wf_idle >= FB_WFLUSH_IDLE) || a_start ||
                                 d_block) : 1'b1;
    integer scan_i;
    always_ff @(posedge clk) begin
        if (rst) begin
            wc_beat<=17'd0; wc_mask<=4'd0; wc_data<=64'd0; wc_idle<=8'd0;
            fb_we_d<=1'b0; fb_ack<=1'b0; fb_pend<=1'b0;
            c_start<=1'b0; c_wr<=1'b0; c_addr<=26'd0; c_wdata<=64'd0; c_be<=8'd0;
            c_fwd<=64'd0; c_fwd_beat<=17'd0; c_fwd_v<=1'b0;
            cf_mask<=4'd0; cf_data<=64'd0; cf_beat<=17'd0; cst<=C_IDLE;
            wf_wptr<=0; wf_rptr<=0;
            c_is_burst<=1'b0; c_blen<=8'd1; c_burst_addr<=26'd0; c_dir<=1'b0; c_bp<=0; wf_idle<=8'd0;
            hd_data<=64'd0; hd_beat<=17'd0; hd_mask<=4'd0;
            run_len_q<=8'd0;pair_asc_q<=1'b0;pair_desc_q<=1'b0;
            hd_fwd_hit_q<=1'b0;
            wf_scan_occ<=0; wf_rptr_q<=0; wf_rptr_qq<=0;
            wf_ne_q<=1'b0;wf_ne_qq<=1'b0;
            for (scan_i=0; scan_i<SCAN_MAX; scan_i=scan_i+1) begin
                wf_scan_mask[scan_i]<=4'd0;
                wf_scan_beat[scan_i]<=17'd0;
            end
        end else begin
            fb_ack  <= 1'b0;
            fb_we_d <= fb_we;
            // pipeline registers: continuously track the FIFO head + its run detection (1-cycle lag)
            hd_data <= wf_data[wf_rp];  hd_beat <= wf_beat[wf_rp];  hd_mask <= wf_mask[wf_rp];
            wf_scan_occ <= wf_occ;
            for (scan_i=0; scan_i<SCAN_MAX; scan_i=scan_i+1) begin
                wf_scan_mask[scan_i] <= wf_mask[wf_rp + scan_i[WF_AW-1:0]];
                wf_scan_beat[scan_i] <= wf_beat[wf_rp + scan_i[WF_AW-1:0]];
            end
            run_len_q <= run_len;
            pair_asc_q <= pair_asc;
            pair_desc_q <= pair_desc;
            hd_fwd_hit_q <= c_fwd_v && (c_fwd_beat == wf_beat[wf_rp]);
            wf_rptr_q <= wf_rptr;  wf_rptr_qq <= wf_rptr_q;
            wf_ne_q <= !wf_empty;  wf_ne_qq <= wf_ne_q;
            if (wc_mask != 4'd0 && wc_idle != 8'hFF) wc_idle <= wc_idle + 8'd1;
            if (wf_idle != 8'hFF) wf_idle <= wf_idle + 8'd1;   // reset on any FIFO push below
            if (fb_new) fb_pend <= 1'b1;                 // default: park a fresh request (accept clears it)
            // ---- combiner: accept pixel and/or PUSH the completed beat to the write FIFO ----
            if (fb_req && !a_start && !d_block && same_or_empty) begin
                fb_pend <= 1'b0; fb_ack <= 1'b1; wc_idle <= 8'd0;
                wc_beat <= fb_beat;
                wc_mask[fb_addr[1:0]] <= 1'b1;
                wc_data[fb_addr[1:0]*16 +: 16] <= fb_wdata;
            end else if (fb_req && !a_start && !d_block &&
                         (wc_mask != 4'd0) && !fb_same && !wf_full) begin
                // different beat + FIFO room: PUSH the old beat, START a fresh combiner with this pixel
                wf_mask[wf_wp] <= wc_mask;  wf_beat[wf_wp] <= wc_beat;  wf_data[wf_wp] <= wc_data;
                wf_wptr <= wf_wptr + 1'b1;  wf_idle <= 8'd0;
                fb_pend <= 1'b0; fb_ack <= 1'b1; wc_idle <= 8'd0;
                wc_beat <= fb_beat;
                wc_mask <= (4'd1 << fb_addr[1:0]);
                wc_data[fb_addr[1:0]*16 +: 16] <= fb_wdata;
            end else if ((wc_mask != 4'd0) && !wf_full &&
                         ((wc_idle >= FB_WFLUSH_IDLE) || a_start || d_block)) begin
                // idle-timeout / CPU-op drain: PUSH the lingering beat, no pixel accepted this cycle
                wf_mask[wf_wp] <= wc_mask;  wf_beat[wf_wp] <= wc_beat;  wf_data[wf_wp] <= wc_data;
                wf_wptr <= wf_wptr + 1'b1;  wf_idle <= 8'd0;
                wc_mask <= 4'd0;
            end
            // ---- drain the FIFO: BURST a consecutive run (asc or desc), else single-beat write / RMW ----
            if ((cst == C_IDLE) && hd_valid && drain_go_r) begin
                if (hd_full) begin                                         // FULL beat at head (registered)
                    if (run_len_q >= 8'd2) begin                           // BURST the run (pay the round-trip ONCE)
                        c_blen <= run_len_q;  c_is_burst <= 1'b1;  c_wr <= 1'b1;  c_start <= 1'b1;  cst <= C_BURST;
                        c_fwd_v <= 1'b0;                                    // burst writes many beats -> drop the 1-deep fwd
                        if (pair_asc_q) begin                              // ascending: stream rp -> up, base = head
                            c_dir <= 1'b0;  c_bp <= wf_rp;
                            c_burst_addr <= {9'd0, hd_beat};
                        end else begin                                     // descending (flipped): stream rp+len-1 -> down
                            c_dir <= 1'b1;  c_bp <= wf_rp + run_len_q[WF_AW-1:0] - 1'b1;
                            // base = LOWEST beat = head - (run_len-1); zero-extend run_len_q to 17b.
                            c_burst_addr <= {9'd0, (hd_beat - ({9'd0, run_len_q} - 17'd1))};
                        end
                        // wf_rptr pops the whole run at C_BURST completion (NOT per-beat)
                    end else begin                                         // lone full beat -> single-beat write
                        wf_rptr <= wf_rptr + 1'b1;
                        c_addr <= {9'd0, hd_beat};  c_wdata <= hd_data;  c_be <= 8'hFF;
                        c_wr <= 1'b1;  c_start <= 1'b1;  cst <= C_WR;
                        c_fwd <= hd_data;  c_fwd_beat <= hd_beat;  c_fwd_v <= 1'b1;
                    end
                end else begin                                             // PARTIAL beat
`ifdef PARTIAL_BE_WRITE
                    // N64-STYLE (2026-07-14): write the partial byte-enables DIRECTLY as a single beat —
                    // NO RMW read, NO fwd-merge. This DELETES C_RD (the character-wedge state) entirely;
                    // busy can't hang because there is no read to stall. Correctness relies on the f2h
                    // bridge honoring per-byte BE on a 1-beat write = a live re-test of P1.5(a) (the N64
                    // ships doing exactly this). If (a) is real the partial pixels drop (holey chars) BUT
                    // the CPU does NOT freeze -> a clean visible discriminator, never worse than today.
                    wf_rptr <= wf_rptr + 1'b1;
                    c_addr <= {9'd0, hd_beat};  c_wdata <= hd_data;
                    c_be   <= {{2{hd_mask[3]}}, {2{hd_mask[2]}}, {2{hd_mask[1]}}, {2{hd_mask[0]}}};
                    c_wr <= 1'b1;  c_start <= 1'b1;  cst <= C_WR;
`else
                    if (hd_fwd_hit_q) begin                                // own-write fwd
                        cf_mask <= hd_mask;  cf_data <= hd_data;  cf_beat <= hd_beat;
                        wf_rptr <= wf_rptr + 1'b1;
                        c_wdata <= lane_merge(c_fwd, hd_data, hd_mask);
                        c_addr <= {9'd0, hd_beat};  c_be <= 8'hFF;
                        c_wr <= 1'b1;  c_start <= 1'b1;  cst <= C_WR;
                        c_fwd <= lane_merge(c_fwd, hd_data, hd_mask);  c_fwd_beat <= hd_beat;
                    end else begin                                         // RMW read first
                        cf_mask <= hd_mask;  cf_data <= hd_data;  cf_beat <= hd_beat;
                        wf_rptr <= wf_rptr + 1'b1;
                        c_addr <= {9'd0, hd_beat};  c_wr <= 1'b0;  c_start <= 1'b1;  cst <= C_RD;
                    end
`endif
                end
            end
            case (cst)
                C_RD: begin
                    if (c_rd_valid) c_wdata <= lane_merge(c_rdata, cf_data, cf_mask);
                    if (c_done) begin c_start <= 1'b0; cst <= C_MRG; end
                end
                C_MRG: begin                               // issue the merged full-beat write
                    c_addr <= {9'd0, cf_beat};  c_be <= 8'hFF;  c_wr <= 1'b1;  c_start <= 1'b1;
                    c_fwd <= c_wdata;  c_fwd_beat <= cf_beat;  c_fwd_v <= 1'b1;
                    cst <= C_WR;
                end
                C_WR: if (c_done) begin c_start <= 1'b0; c_wr <= 1'b0; cst <= C_IDLE; end
                C_BURST: begin
                    if (c_burst_next) c_bp <= c_dir ? (c_bp - 1'b1) : (c_bp + 1'b1);  // stream next beat
                    if (c_done) begin
                        c_start <= 1'b0; c_wr <= 1'b0; c_is_burst <= 1'b0;
                        wf_rptr <= wf_rptr + {1'b0, c_blen[WF_AW-1:0]};   // pop the whole run at once
                        cst <= C_IDLE;
                    end
                end
                default: ;
            endcase
        end
    end

    // ================= L2 arbiter: A (single beat) vs B (128-beat burst) -> agent =============
    logic        tst_wr_req, tst_rd_req;
    logic [25:0] tst_addr;
    logic [63:0] tst_wdata_lat, tst_rdata;             // latched single-beat write value
    wire  [63:0] tst_wdata;                            // agent write data: live FIFO head during a burst
    logic [ 7:0] tst_be, tst_burstcnt;
    logic        tst_rd_valid, tst_busy;
    logic        tst_wr_done;
    logic [25:0] tst_wr_base;
    logic [ 7:0] tst_wr_count;
    logic [63:0] tst_wr_last_data;
    wire         tst_waccept;
    wire [25:0]  tst_waccept_addr;
    wire [63:0]  tst_waccept_data;
    wire [7:0]   tst_waccept_be;

    logic [2:0] l_gnt;   // 0=A, 1=B, 2=C, 3=scan readback fence, 4=D (SRT)
    localparam [1:0] L_IDLE=2'd0, L_ACCEPT=2'd1, L_RUN=2'd2, L_DONE=2'd3;
    logic [1:0] ls;
    logic [7:0]  posted_guard;
    logic [16:0] posted_base, posted_last;
    // Every accepted write dirties its affected scan region. Before a cold
    // row fill, grant 3 repeatedly reads the exact final accepted beat until
    // the physical DDR value matches. This is Wolf's publication fence; it
    // replaces any guessed posted-write delay.
    logic [3:0]  scan_dirty;
    logic [16:0] scan_fence_addr [0:3];
    logic [63:0] scan_fence_expect [0:3];
    logic [1:0]  scan_fence_page;
    wire  [16:0] retired_write_base = tst_wr_base[16:0];
    wire  [16:0] retired_write_last = tst_wr_base[16:0] +
                                      {{9{1'b0}},tst_wr_count} - 17'd1;
    wire  [1:0]  retired_page_first = retired_write_base[16:15];
    wire  [1:0]  retired_page_last  = retired_write_last[16:15];
    wire  [3:0]  retired_page_mask  = (4'b0001 << retired_page_first) |
                                      (4'b0001 << retired_page_last);
    wire  [1:0]  b_fill_page = b_addr[16:15];
    wire         b_publication_pending = scan_dirty[b_fill_page];
    wire         b_retire_collision = tst_wr_done &&
                                      retired_page_mask[b_fill_page];
    wire         fence_complete_evt = (ls == L_RUN) && !tst_busy &&
                                      (l_gnt == 3'd3);
    wire         fence_match_evt = fence_complete_evt && tst_rd_valid &&
                                   (tst_rdata ==
                                    scan_fence_expect[scan_fence_page]);
    wire         a_posted_hazard = (posted_guard != 8'd0) &&
                                   (a_addr[16:0] >= posted_base) &&
                                   (a_addr[16:0] <= posted_last);
    wire         c_posted_hazard = (posted_guard != 8'd0) &&
                                   (c_addr[16:0] >= posted_base) &&
                                   (c_addr[16:0] <= posted_last);
    integer scan_pg;
    always_ff @(posedge clk) begin
        if (sdram_por) begin
            scan_dirty <= 4'b0000;
            for (scan_pg=0; scan_pg<4; scan_pg=scan_pg+1) begin
                scan_fence_addr[scan_pg] <= 17'd0;
                scan_fence_expect[scan_pg] <= 64'd0;
            end
        end else begin
            if (fence_match_evt)
                scan_dirty[scan_fence_page] <= 1'b0;
            if (tst_wr_done)
                for (scan_pg=0; scan_pg<4; scan_pg=scan_pg+1)
                    if (scan_dirty[scan_pg] ||
                        retired_page_mask[scan_pg]) begin
                        scan_dirty[scan_pg] <= 1'b1;
                        scan_fence_addr[scan_pg] <= retired_write_last;
                        scan_fence_expect[scan_pg] <= tst_wr_last_data;
                    end
        end
    end

    assign tst_wdata    = (l_gnt==3'd0 && a_is_burst) ? a_burst_data :
                          (l_gnt==3'd2 && c_is_burst) ? c_burst_data :
                          (l_gnt==3'd4)               ? dbuf_q : tst_wdata_lat;
    assign c_burst_next = (l_gnt==3'd2 && c_is_burst && ls==L_RUN) && tst_wnext;
    assign d_burst_next = (l_gnt==3'd4 && ls==L_RUN) && tst_wnext;

    // Serialize every coherent upper-cache publication through one stream.
    // A-side CPU writes already hold a complete merged beat.  C (framebuffer)
    // and D (SRT) writes join only when the DDR agent accepts their exact full
    // beat; this prevents a speculative invalidation/refill race and includes
    // the final beat that tst_wnext deliberately omits.
    localparam int PUB_DEPTH = 8;
    logic [18:0] pub_addr_fifo [0:PUB_DEPTH-1];
    logic [63:0] pub_data_fifo [0:PUB_DEPTH-1];
    logic [2:0] pub_wr_ptr, pub_rd_ptr;
    logic [3:0] pub_count;
    logic pub_overflow;
`ifdef MUT_TUNIT_SCAN_CPU_ONLY_SNOOP
    wire cd_publish_valid = 1'b0;
`elsif MUT_TUNIT_SCAN_NO_D_SNOOP
    wire cd_publish_valid = tst_waccept && (tst_waccept_be == 8'hff) &&
                            (l_gnt == 3'd2);
`else
    wire cd_publish_valid = tst_waccept && (tst_waccept_be == 8'hff) &&
                            ((l_gnt == 3'd2) || (l_gnt == 3'd4));
`endif
    wire cd_partial_accept = tst_waccept && (tst_waccept_be != 8'hff) &&
                             ((l_gnt == 3'd2) || (l_gnt == 3'd4));
    wire [18:0] cd_publish_addr = {tst_waccept_addr[16:0],2'b00};
    wire pub_pop = (pub_count != 0);
    wire [4:0] pub_space = PUB_DEPTH - pub_count + (pub_pop ? 5'd1 : 5'd0);
    wire pub_take_a = a_snoop_valid && (pub_space >= 5'd1);
    wire pub_take_cd = cd_publish_valid &&
                       (pub_space >= (a_snoop_valid ? 5'd2 : 5'd1));
    assign cpu_snoop_pending = (pub_count != 0) || a_snoop_valid ||
                               cd_publish_valid;
    assign cpu_snoop_overflow = pub_overflow;
    always_ff @(posedge clk) begin
        if (rst) begin
            pub_wr_ptr <= 3'd0;
            pub_rd_ptr <= 3'd0;
            pub_count <= 4'd0;
            pub_overflow <= 1'b0;
            cpu_snoop_valid <= 1'b0;
            cpu_snoop_addr <= 19'd0;
            cpu_snoop_data <= 64'd0;
        end else begin
            cpu_snoop_valid <= 1'b0;
            if (pub_pop) begin
                cpu_snoop_valid <= 1'b1;
                cpu_snoop_addr <= pub_addr_fifo[pub_rd_ptr];
                cpu_snoop_data <= pub_data_fifo[pub_rd_ptr];
                pub_rd_ptr <= pub_rd_ptr + 3'd1;
            end
            if (pub_take_a) begin
                pub_addr_fifo[pub_wr_ptr] <= a_snoop_addr;
                pub_data_fifo[pub_wr_ptr] <= a_snoop_data;
            end
            if (pub_take_cd) begin
                pub_addr_fifo[pub_wr_ptr + (pub_take_a ? 3'd1 : 3'd0)] <=
                    cd_publish_addr;
                pub_data_fifo[pub_wr_ptr + (pub_take_a ? 3'd1 : 3'd0)] <=
                    tst_waccept_data;
            end
            pub_wr_ptr <= pub_wr_ptr + (pub_take_a ? 3'd1 : 3'd0) +
                         (pub_take_cd ? 3'd1 : 3'd0);
            pub_count <= pub_count - (pub_pop ? 4'd1 : 4'd0) +
                         (pub_take_a ? 4'd1 : 4'd0) +
                         (pub_take_cd ? 4'd1 : 4'd0);
            if ((a_snoop_valid && !pub_take_a) ||
                (cd_publish_valid && !pub_take_cd) ||
                cd_partial_accept)
                pub_overflow <= 1'b1;
        end
    end
    always_ff @(posedge clk) begin
        if (rst) begin
            ls<=L_IDLE; l_gnt<=3'd0; tst_rd_req<=1'b0; tst_wr_req<=1'b0;
            tst_addr<=26'd0; tst_wdata_lat<=64'd0; tst_be<=8'd0; tst_burstcnt<=8'd1;
            a_done<=1'b0; b_done<=1'b0; scan_fence_page<=2'd0;
            posted_guard<=8'd0; posted_base<=17'd0; posted_last<=17'd0;
        end else begin
            tst_rd_req<=1'b0; tst_wr_req<=1'b0; a_done<=1'b0;
            b_done<=1'b0; c_done<=1'b0; d_done<=1'b0;
            if (posted_guard != 8'd0)
                posted_guard <= posted_guard - 8'd1;
            if (tst_wr_done) begin
                posted_guard <= POSTED_WRITE_GUARD[7:0];
                if (posted_guard != 8'd0) begin
                    posted_base <= (retired_write_base < posted_base) ?
                                   retired_write_base : posted_base;
                    posted_last <= (retired_write_last > posted_last) ?
                                   retired_write_last : posted_last;
                end else begin
                    posted_base <= retired_write_base;
                    posted_last <= retired_write_last;
                end
            end
            case (ls)
                // Gate acceptance on the agent actually being IDLE. The agent runs on sdram_por while
                // A/B/L2 run on core rst (P0022 split): a core_rst pulse mid-burst snaps L2 to L_IDLE
                // while the agent keeps draining its pre-reset transaction. Without this guard L2 would
                // pulse a req the busy agent ignores, then mistake the OLD transaction's tst_busy for
                // its own acceptance and fabricate a completion for an access that never issued
                // ([[lessons_gate_fsm_not_output]] — never sequence on a busy you do not own). Waiting
                // for !tst_busy makes the orphaned burst drain (its beats are dropped: a_rd_valid/
                // b_rd_valid are gated on ls==L_RUN) before any fresh command is issued.
                L_IDLE: if (!tst_busy) begin
                    if (b_start && b_retire_collision) begin
                        // Let the persistent tracker consume this edge's
                        // newly accepted write before testing its dirty bit.
                    end
                    // A dirty CPU line receives priority only once its cache
                    // FSM has requested a flush. Unrelated scanout bursts do
                    // not force writeback or hold the arbiter idle.
                    else if (a_cache_dirty && (a_start || b_cache_overlap)) begin
                        // On overlap, hold one arbitration cycle while A's FSM
                        // raises a_start; then write back before B can read.
                        if(a_start)begin
                            l_gnt<=3'd0; tst_addr<=a_addr; tst_burstcnt<=a_burstlen;
                            tst_wdata_lat<=a_wdata; tst_be<=a_be; tst_wr_req<=1'b1;
                            ls<=L_ACCEPT;
                        end
                    end else if (b_start && b_publication_pending) begin
                        l_gnt<=3'd3;
                        scan_fence_page<=b_fill_page;
                        tst_addr<={9'd0,scan_fence_addr[b_fill_page]};
                        tst_burstcnt<=8'd1;
                        tst_rd_req<=1'b1;
                        ls<=L_ACCEPT;
                    end else if (b_start) begin                       // scanout sub-burst = priority (deadline)
                        l_gnt<=3'd1; tst_addr<=b_addr; tst_burstcnt<=b_burstlen; tst_rd_req<=1'b1; ls<=L_ACCEPT;
                    end else if (a_rmw_lock) begin            // ATOMIC RMW: only A may issue; C locked out
                        if (a_start && (a_wr || !a_posted_hazard)) begin
                            l_gnt<=3'd0; tst_addr<=a_addr; tst_burstcnt<=a_burstlen;
                            if (a_wr) begin tst_wdata_lat<=a_wdata; tst_be<=a_be; tst_wr_req<=1'b1; end
                            else            tst_rd_req<=1'b1;
                            ls<=L_ACCEPT;
                        end
                    end else if (c_start && (c_wr || !c_posted_hazard)) begin
                        l_gnt<=3'd2;
                        if (c_is_burst) begin                // multi-beat burst: addr+len once, stream data
                            tst_addr<=c_burst_addr; tst_burstcnt<=c_blen; tst_be<=8'hFF; tst_wr_req<=1'b1;
                        end else begin
                            tst_addr<=c_addr; tst_burstcnt<=8'd1;
                            if (c_wr) begin tst_wdata_lat<=c_wdata; tst_be<=c_be; tst_wr_req<=1'b1; end
                            else            tst_rd_req<=1'b1;
                        end
                        ls<=L_ACCEPT;
                    end else if (d_start) begin
                        // The D FSM has already parked new C accepts and
                        // waited for the A side and combiner to drain.
                        l_gnt<=3'd4; tst_addr<=d_addr; tst_burstcnt<=d_blen;
                        if (d_wr) begin tst_be<=8'hff; tst_wr_req<=1'b1; end
                        else            tst_rd_req<=1'b1;
                        ls<=L_ACCEPT;
                    end else if (a_start && !c_busy && !d_block &&
                                 (a_wr || !a_posted_hazard)) begin
                        l_gnt<=3'd0; tst_addr<=a_addr; tst_burstcnt<=a_burstlen;
                        if (a_wr) begin tst_wdata_lat<=a_wdata; tst_be<=a_be; tst_wr_req<=1'b1; end
                        else            tst_rd_req<=1'b1;
                        ls<=L_ACCEPT;
                    end
                end
                L_ACCEPT: if (tst_busy) ls<=L_RUN;            // agent accepted the transaction
                L_RUN: if (!tst_busy) begin                  // transaction complete
                        if (l_gnt==3'd1) b_done<=1'b1;
                        else if (l_gnt==3'd2) c_done<=1'b1;
                        else if (l_gnt==3'd4) d_done<=1'b1;
                        else if (l_gnt==3'd0) a_done<=1'b1;
                        ls<=L_DONE;
                    end
                L_DONE: ls<=L_IDLE;                           // bubble: requester clears its start level before re-arbitrate
                default: ls<=L_IDLE;
            endcase
        end
    end
    // route read beats to the granted consumer
    assign a_rd_valid = (l_gnt==3'd0) && (ls==L_RUN) && tst_rd_valid;
    assign b_rd_valid = (l_gnt==3'd1) && (ls==L_RUN) && tst_rd_valid;
    assign c_rd_valid = (l_gnt==3'd2) && (ls==L_RUN) && tst_rd_valid;
    assign d_rd_valid = (l_gnt==3'd4) && (ls==L_RUN) && tst_rd_valid;
    assign a_rdata = tst_rdata;
    assign b_rdata = tst_rdata;
    assign c_rdata = tst_rdata;

    // ================= D: SRT row-pair engine ===============================
`ifdef SYNTHESIS
    wire srt_go = srt_req;
`else
    wire srt_go = (srt_req === 1'b1);
`endif
    wire [8:0] d_fill_rd_n = d_fill + (d_rd_valid ? 9'd1 : 9'd0);
    wire [7:0] dbuf_ra = d_burst_next ? (d_fill[7:0] + 8'd1) :
                                        d_fill[7:0];
    always_ff @(posedge clk) dbuf_q <= dbuf[dbuf_ra];
    always_ff @(posedge clk)
        if (d_rd_valid && !d_op_we) dbuf[d_fill[7:0]] <= tst_rdata;

    always_ff @(posedge clk) begin
        if (rst) begin
            dst<=D_IDLE; d_start<=1'b0; d_wr<=1'b0; d_addr<=26'd0;
            d_blen<=8'd1; d_fill<=9'd0; d_base_beat<=17'd0;
            d_op_we<=1'b0; srt_done<=1'b0; srt_e0e1_r<=32'd0;
        end else begin
            srt_done <= 1'b0;
            case (dst)
                D_IDLE: if (srt_go) begin
                    d_base_beat <= srt_entry[18:2];
                    d_op_we <= srt_we;
                    d_fill <= 9'd0;
                    dst <= D_DRAIN;
                end
                D_DRAIN: if (!c_busy && (ats == A_IDLE) &&
                            !a_cache_dirty &&
                            (d_op_we || (posted_guard == 8'd0)))
                    dst <= d_op_we ? D_WREQ : D_RREQ;
                D_RREQ: begin
                    d_addr <= {9'd0,d_base_beat} + {17'd0,d_fill};
                    d_blen <= ((9'd256-d_fill) > {1'b0,BMAX}) ?
                              BMAX : 8'((9'd256-d_fill));
                    d_wr<=1'b0; d_start<=1'b1; dst<=D_RFILL;
                end
                D_RFILL: begin
                    if (d_rd_valid) begin
                        if (d_fill==9'd0) srt_e0e1_r<=tst_rdata[31:0];
                        d_fill<=d_fill_rd_n;
                    end
                    if (d_done) begin
                        d_start<=1'b0;
                        dst <= (d_fill_rd_n>=9'd256) ? D_FIN : D_RREQ;
                    end
                end
                D_WREQ: begin
                    d_addr <= {9'd0,d_base_beat} + {17'd0,d_fill};
                    d_blen <= ((9'd256-d_fill) > {1'b0,BMAX}) ?
                              BMAX : 8'((9'd256-d_fill));
                    d_wr<=1'b1; d_start<=1'b1; dst<=D_WSTREAM;
                end
                D_WSTREAM: begin
                    if (d_burst_next) d_fill<=d_fill+9'd1;
                    if (d_done) begin
                        d_start<=1'b0; d_wr<=1'b0; d_fill<=d_fill+9'd1;
                        dst <= ((d_fill+9'd1)>=9'd256) ? D_FIN : D_WREQ;
                    end
                end
                D_FIN: begin srt_done<=1'b1; dst<=D_IDLE; end
                default: dst<=D_IDLE;
            endcase
        end
    end

    stv_vram_ddr_agent #(.VRAM_DDR_BASE(VRAM_DDR_BASE)) u_agent (
        .clk(clk), .sdram_por(sdram_por),
        .tst_wr_req(tst_wr_req), .tst_rd_req(tst_rd_req), .tst_addr(tst_addr),
        .tst_wdata(tst_wdata), .tst_be(tst_be), .tst_burstcnt(tst_burstcnt),
        .tst_rdata(tst_rdata), .tst_rd_valid(tst_rd_valid), .tst_busy(tst_busy),
        .tst_wr_done(tst_wr_done), .tst_wr_base(tst_wr_base),
        .tst_wr_count(tst_wr_count), .tst_wr_last_data(tst_wr_last_data),
        .tst_wnext(tst_wnext),
        .tst_waccept(tst_waccept),.tst_waccept_addr(tst_waccept_addr),
        .tst_waccept_data(tst_waccept_data),.tst_waccept_be(tst_waccept_be),
        .ddram_addr(ddram_addr), .ddram_burstcnt(ddram_burstcnt), .ddram_rd(ddram_rd), .ddram_we(ddram_we),
        .ddram_din(ddram_din), .ddram_be(ddram_be),
        .ddram_busy(ddram_busy), .ddram_dout(ddram_dout), .ddram_dout_ready(ddram_dout_ready) );
endmodule
`default_nettype wire
