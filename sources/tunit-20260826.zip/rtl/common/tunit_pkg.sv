// Midway T-unit constants and pure decode helpers.
//
// Address ranges are TMS34010 bit addresses, matching MAME 0.287's
// midtunit_base_state::main_map and mk2_state::mk2_map.

`default_nettype none

package tunit_pkg;

  typedef enum logic [2:0] {
    PROFILE_MK1       = 3'd0,
    PROFILE_MK2       = 3'd1,
    PROFILE_NBAJAM    = 3'd2,
    PROFILE_NBAJAM_TE = 3'd3,
    PROFILE_JDREDD    = 3'd4
  } tunit_profile_t;

  typedef enum logic [4:0] {
    MAP_NONE,
    MAP_VRAM,
    MAP_RAM,
    MAP_CMOS,
    MAP_CMOS_ENABLE,
    MAP_IN0,
    MAP_IN1,
    MAP_IN2,
    MAP_DSW,
    MAP_PALETTE,
    MAP_DMA,
    MAP_CONTROL,
    MAP_DCS_STATUS,
    MAP_DCS_DATA,
    MAP_WATCHDOG,
    MAP_GFX,
    MAP_PROGRAM
  } tunit_map_target_t;

  localparam logic [31:0] TMAP_VRAM_LO       = 32'h0000_0000;
  localparam logic [31:0] TMAP_VRAM_HI       = 32'h003f_ffff;
  localparam logic [31:0] TMAP_RAM_LO        = 32'h0100_0000;
  localparam logic [31:0] TMAP_RAM_HI        = 32'h013f_ffff;
  localparam logic [31:0] TMAP_CMOS_LO       = 32'h0140_0000;
  localparam logic [31:0] TMAP_CMOS_HI       = 32'h0141_ffff;
  localparam logic [31:0] TMAP_CMOSEN_LO     = 32'h0148_0000;
  localparam logic [31:0] TMAP_CMOSEN_HI     = 32'h014f_ffff;
  localparam logic [31:0] TMAP_IN0_LO        = 32'h0160_0000;
  localparam logic [31:0] TMAP_IN0_HI        = 32'h0160_000f;
  localparam logic [31:0] TMAP_IN1_LO        = 32'h0160_0010;
  localparam logic [31:0] TMAP_IN1_HI        = 32'h0160_001f;
  localparam logic [31:0] TMAP_IN2_LO        = 32'h0160_0020;
  localparam logic [31:0] TMAP_IN2_HI        = 32'h0160_002f;
  localparam logic [31:0] TMAP_DSW_LO        = 32'h0160_0030;
  localparam logic [31:0] TMAP_DSW_HI        = 32'h0160_003f;
  localparam logic [31:0] TMAP_PAL_LO        = 32'h0180_0000;
  localparam logic [31:0] TMAP_PAL_HI        = 32'h0187_ffff;
  localparam logic [31:0] TMAP_DMA_LO        = 32'h01a8_0000;
  localparam logic [31:0] TMAP_DMA_HI        = 32'h01a8_00ff;
  localparam logic [31:0] TMAP_CTRL_LO       = 32'h01b0_0000;
  localparam logic [31:0] TMAP_CTRL_HI       = 32'h01b0_001f;
  localparam logic [31:0] TMAP_DCSSTAT_LO    = 32'h01d0_0000;
  localparam logic [31:0] TMAP_DCSSTAT_HI    = 32'h01d0_001f;
  localparam logic [31:0] TMAP_DCSDATA_LO    = 32'h01d0_1020;
  localparam logic [31:0] TMAP_DCSDATA_HI    = 32'h01d0_103f;
  localparam logic [31:0] TMAP_WDOG_LO       = 32'h01d8_1060;
  localparam logic [31:0] TMAP_WDOG_HI       = 32'h01d8_107f;
  localparam logic [31:0] TMAP_CTRL_MIR_LO   = 32'h01f0_0000;
  localparam logic [31:0] TMAP_CTRL_MIR_HI   = 32'h01f0_001f;
  localparam logic [31:0] TMAP_GFX_LO        = 32'h0200_0000;
  localparam logic [31:0] TMAP_GFX_HI        = 32'h07ff_ffff;
  localparam logic [31:0] TMAP_PROG_MIR_LO   = 32'h1f80_0000;
  localparam logic [31:0] TMAP_PROG_MIR_HI   = 32'h1fff_ffff;
  localparam logic [31:0] TMAP_PROG_LO       = 32'hff80_0000;
  localparam logic [31:0] TMAP_PROG_HI       = 32'hffff_ffff;

  function automatic logic addr_in_range(
    input logic [31:0] addr,
    input logic [31:0] lo,
    input logic [31:0] hi
  );
    addr_in_range = (addr >= lo) && (addr <= hi);
  endfunction

  function automatic tunit_map_target_t tunit_map_decode(
    input tunit_profile_t profile,
    input logic [31:0] addr
  );
    begin
      tunit_map_decode = MAP_NONE;
      if      (addr_in_range(addr, TMAP_VRAM_LO,     TMAP_VRAM_HI))     tunit_map_decode = MAP_VRAM;
      else if (addr_in_range(addr, TMAP_RAM_LO,      TMAP_RAM_HI))      tunit_map_decode = MAP_RAM;
      else if (addr_in_range(addr, TMAP_CMOS_LO,     TMAP_CMOS_HI))     tunit_map_decode = MAP_CMOS;
      else if (addr_in_range(addr, TMAP_CMOSEN_LO,   TMAP_CMOSEN_HI))   tunit_map_decode = MAP_CMOS_ENABLE;
      else if (addr_in_range(addr, TMAP_IN0_LO,      TMAP_IN0_HI))      tunit_map_decode = MAP_IN0;
      else if (addr_in_range(addr, TMAP_IN1_LO,      TMAP_IN1_HI))      tunit_map_decode = MAP_IN1;
      else if (addr_in_range(addr, TMAP_IN2_LO,      TMAP_IN2_HI))      tunit_map_decode = MAP_IN2;
      else if (addr_in_range(addr, TMAP_DSW_LO,      TMAP_DSW_HI))      tunit_map_decode = MAP_DSW;
      else if (addr_in_range(addr, TMAP_PAL_LO,      TMAP_PAL_HI))      tunit_map_decode = MAP_PALETTE;
      else if (addr_in_range(addr, TMAP_DMA_LO,      TMAP_DMA_HI))      tunit_map_decode = MAP_DMA;
      else if (addr_in_range(addr, TMAP_CTRL_LO,     TMAP_CTRL_HI) ||
               addr_in_range(addr, TMAP_CTRL_MIR_LO, TMAP_CTRL_MIR_HI)) tunit_map_decode = MAP_CONTROL;
      // SOUND PORT IS NOT MK2-ONLY. MAME registers the SAME addresses for both
      // sound boards and only swaps the handlers:
      //   midtunit_adpcm_state::main_adpcm_map  0x01d00000 -> sound_state_r
      //                                         0x01d01020 -> sound_r / sound_w
      //   mk2_state::mk2_map                    0x01d00000 -> dcs_state_r
      //                                         0x01d01020 -> dcs_r / dcs_w
      // Gating the DECODE on PROFILE_MK2 meant the four ADPCM profiles (MK1, NBA Jam,
      // NBA Jam TE, Judge Dredd) had their sound accesses fall through to no target at
      // all, so their audio could never work regardless of which engine was built.
      // Confirmed against ROM bytes, not just source: NBA Jam's shipping program image
      // references 0x01D01020 (1x) and 0x01D00000 (4x) and has ZERO references to the
      // 0x1680000/0x1860040 pair that its own released SYS.EQU lists in the ACTIVE
      // `.if TUNIT2` block -- that block does not describe the ROM that shipped, the
      // commented-out block does. Same trap as MK2's.
      // The PROFILE selects the CONSUMER (DCS vs ADPCM), never whether the address
      // decodes. Keeping the names MAP_DCS_* since they are the shared sound-port
      // targets; renaming them is churn for no behavioural gain.
      else if (addr_in_range(addr, TMAP_DCSSTAT_LO, TMAP_DCSSTAT_HI))  tunit_map_decode = MAP_DCS_STATUS;
      else if (addr_in_range(addr, TMAP_DCSDATA_LO, TMAP_DCSDATA_HI))  tunit_map_decode = MAP_DCS_DATA;
      else if (addr_in_range(addr, TMAP_WDOG_LO,     TMAP_WDOG_HI))     tunit_map_decode = MAP_WATCHDOG;
      else if (addr_in_range(addr, TMAP_GFX_LO,      TMAP_GFX_HI))      tunit_map_decode = MAP_GFX;
      else if (addr_in_range(addr, TMAP_PROG_MIR_LO, TMAP_PROG_MIR_HI) ||
               addr_in_range(addr, TMAP_PROG_LO,     TMAP_PROG_HI))     tunit_map_decode = MAP_PROGRAM;
    end
  endfunction

  function automatic logic tunit_map_readable(input tunit_map_target_t target);
    case (target)
      MAP_VRAM, MAP_RAM, MAP_CMOS, MAP_IN0, MAP_IN1, MAP_IN2, MAP_DSW,
      MAP_PALETTE, MAP_DMA, MAP_DCS_STATUS, MAP_DCS_DATA, MAP_GFX,
      MAP_PROGRAM: tunit_map_readable = 1'b1;
      default:     tunit_map_readable = 1'b0;
    endcase
  endfunction

  function automatic logic tunit_map_writable(input tunit_map_target_t target);
    case (target)
      MAP_VRAM, MAP_RAM, MAP_CMOS, MAP_CMOS_ENABLE, MAP_PALETTE, MAP_DMA,
      MAP_CONTROL, MAP_DCS_DATA, MAP_WATCHDOG: tunit_map_writable = 1'b1;
      default:                               tunit_map_writable = 1'b0;
    endcase
  endfunction

  // DMA2 register layout from MAME 0.287 midtunit_v.h/midtunit_v.cpp.
  localparam logic [4:0] DMA_LRSKIP    = 5'd0;
  localparam logic [4:0] DMA_COMMAND   = 5'd1;
  localparam logic [4:0] DMA_OFFSETLO  = 5'd2;
  localparam logic [4:0] DMA_OFFSETHI  = 5'd3;
  localparam logic [4:0] DMA_XSTART    = 5'd4;
  localparam logic [4:0] DMA_YSTART    = 5'd5;
  localparam logic [4:0] DMA_WIDTH     = 5'd6;
  localparam logic [4:0] DMA_HEIGHT    = 5'd7;
  localparam logic [4:0] DMA_PALETTE   = 5'd8;
  localparam logic [4:0] DMA_COLOR     = 5'd9;
  localparam logic [4:0] DMA_SCALE_X   = 5'd10;
  localparam logic [4:0] DMA_SCALE_Y   = 5'd11;
  localparam logic [4:0] DMA_TOPCLIP   = 5'd12;
  localparam logic [4:0] DMA_BOTCLIP   = 5'd13;
  localparam logic [4:0] DMA_UNKNOWN_E = 5'd14;
  localparam logic [4:0] DMA_CONFIG    = 5'd15;
  localparam logic [4:0] DMA_LEFTCLIP  = 5'd16;
  localparam logic [4:0] DMA_RIGHTCLIP = 5'd17;
  localparam int DMA_NREGS = 18;
  localparam int DMA_CMD_TRIG_BIT = 15;

  function automatic logic [4:0] dma_regmap(input logic bank, input logic [3:0] off);
    case (off)
      4'd12:   dma_regmap = bank ? DMA_TOPCLIP : DMA_LEFTCLIP;
      4'd13:   dma_regmap = bank ? DMA_BOTCLIP : DMA_RIGHTCLIP;
      default: dma_regmap = {1'b0, off};
    endcase
  endfunction

  localparam int FB_WORDS = 32'h0008_0000;
  localparam int FB_ADDR_W = 19;
  localparam int FB_ROWSHIFT = 9;
  localparam int PAL_ENTRIES = 32768;

  function automatic logic [23:0] rgb555_to_888(input logic [15:0] c);
    logic [4:0] r5, g5, b5;
    begin
      r5 = c[14:10]; g5 = c[9:5]; b5 = c[4:0];
      rgb555_to_888 = {r5, r5[4:2], g5, g5[4:2], b5, b5[4:2]};
    end
  endfunction

  function automatic logic [3:0] dma_bpp(input logic [15:0] command);
    logic [2:0] b;
    begin
      b = command[14:12];
      dma_bpp = (b == 3'd0) ? 4'd8 : {1'b0, b};
    end
  endfunction

endpackage

`default_nettype wire
