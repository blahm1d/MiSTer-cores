// Midway T-unit (initial MK2/DCS2K profile) MiSTer wrapper.

module emu(
  input CLK_50M,input RESET,inout[48:0]HPS_BUS,
  output CLK_VIDEO,output CE_PIXEL,output[12:0]VIDEO_ARX,output[12:0]VIDEO_ARY,
  output[7:0]VGA_R,VGA_G,VGA_B,output VGA_HS,VGA_VS,VGA_DE,VGA_F1,
  output[1:0]VGA_SL,output VGA_SCALER,VGA_DISABLE,
  input[11:0]HDMI_WIDTH,input[11:0]HDMI_HEIGHT,
  output HDMI_FREEZE,HDMI_BLACKOUT,HDMI_BOB_DEINT,
`ifdef MISTER_FB
  output FB_EN,output[4:0]FB_FORMAT,output[11:0]FB_WIDTH,FB_HEIGHT,
  output[31:0]FB_BASE,output[13:0]FB_STRIDE,input FB_VBL,FB_LL,output FB_FORCE_BLANK,
`ifdef MISTER_FB_PALETTE
  output FB_PAL_CLK,output[7:0]FB_PAL_ADDR,output[23:0]FB_PAL_DOUT,
  input[23:0]FB_PAL_DIN,output FB_PAL_WR,
`endif
`endif
  output LED_USER,output[1:0]LED_POWER,LED_DISK,output[1:0]BUTTONS,
  input CLK_AUDIO,output[15:0]AUDIO_L,AUDIO_R,output AUDIO_S,output[1:0]AUDIO_MIX,
  inout[3:0]ADC_BUS,output SD_SCK,SD_MOSI,input SD_MISO,output SD_CS,input SD_CD,
  output DDRAM_CLK,input DDRAM_BUSY,output[7:0]DDRAM_BURSTCNT,output[28:0]DDRAM_ADDR,
  input[63:0]DDRAM_DOUT,input DDRAM_DOUT_READY,output DDRAM_RD,output[63:0]DDRAM_DIN,
  output[7:0]DDRAM_BE,output DDRAM_WE,
  output SDRAM_CLK,SDRAM_CKE,output[12:0]SDRAM_A,output[1:0]SDRAM_BA,inout[15:0]SDRAM_DQ,
  output SDRAM_DQML,SDRAM_DQMH,SDRAM_nCS,SDRAM_nCAS,SDRAM_nRAS,SDRAM_nWE,
`ifdef MISTER_DUAL_SDRAM
  input SDRAM2_EN,output SDRAM2_CLK,output[12:0]SDRAM2_A,output[1:0]SDRAM2_BA,
  inout[15:0]SDRAM2_DQ,output SDRAM2_nCS,SDRAM2_nCAS,SDRAM2_nRAS,SDRAM2_nWE,
`endif
  input UART_CTS,output UART_RTS,input UART_RXD,output UART_TXD,UART_DTR,input UART_DSR,
  input[6:0]USER_IN,output[6:0]USER_OUT,input OSD_STATUS
);
  import tunit_pkg::*;

  // clk_snd is the 12 MHz PLL output the Williams ADPCM board runs on. It was
// generated and left dangling as `clk_unused0`; the board's own header and the
// tunit_adpcm_rom_cdc bridge are both written for a real 12 MHz domain crossing
// to the 96 MHz sound-DDR client, so this is the intended wiring rather than a
// new clock invented here.
  wire clk_sys,clk_sdram,clk_snd,clk_unused1,locked;
  wire[127:0]status;wire[1:0]buttons;wire forced_scandoubler,direct_video;
  wire[21:0]gamma_bus;wire ioctl_download,ioctl_upload,ioctl_upload_req,ioctl_wr,ioctl_rd;
  wire[26:0]ioctl_addr_hps;wire[24:0]ioctl_addr=ioctl_addr_hps[24:0];
  wire[7:0]ioctl_dout,ioctl_din;wire[15:0]ioctl_index_hps;wire[7:0]ioctl_index=ioctl_index_hps[7:0];wire ioctl_wait;
  wire[31:0]joystick_0_hps,joystick_1_hps,joystick_2_hps,joystick_3_hps;
  wire[15:0]joystick_0=joystick_0_hps[15:0],joystick_1=joystick_1_hps[15:0];
  wire[15:0]joystick_2=joystick_2_hps[15:0],joystick_3=joystick_3_hps[15:0];
  pll pll(.refclk(CLK_50M),.rst(1'b0),.outclk_0(clk_sys),.outclk_1(clk_sdram),
          .outclk_2(clk_snd),.outclk_3(clk_unused1),.locked(locked));
  assign DDRAM_CLK=clk_sys;
  assign SDRAM_CLK=clk_sdram;

  assign {SD_SCK,SD_MOSI,SD_CS}='z;
  assign {UART_RTS,UART_TXD,UART_DTR}=3'b000;
  assign USER_OUT='1;
  assign ADC_BUS='z;
`ifdef MISTER_DUAL_SDRAM
  assign {SDRAM2_CLK,SDRAM2_A,SDRAM2_BA,SDRAM2_DQ,SDRAM2_nCS,
          SDRAM2_nCAS,SDRAM2_nRAS,SDRAM2_nWE}='z;
`endif
  assign VGA_F1=1'b0;assign VGA_SCALER=1'b0;assign VGA_DISABLE=1'b0;
  assign HDMI_FREEZE=1'b0;assign HDMI_BLACKOUT=1'b0;assign HDMI_BOB_DEINT=1'b0;
`ifdef MISTER_FB
  assign {FB_EN,FB_FORMAT,FB_WIDTH,FB_HEIGHT,FB_BASE,FB_STRIDE,FB_FORCE_BLANK}='0;
`ifdef MISTER_FB_PALETTE
  assign {FB_PAL_CLK,FB_PAL_ADDR,FB_PAL_DOUT,FB_PAL_WR}='0;
`endif
`endif
  assign LED_POWER=2'b00;assign BUTTONS=2'b00;assign AUDIO_MIX=2'b00;
  assign VIDEO_ARX=status[1]?13'd16:13'd4;
  assign VIDEO_ARY=status[1]?13'd9:13'd3;

`include "build_id.v"
  localparam CONF_STR={
    "A.TUNIT;;",
    "O1,Aspect Ratio,4:3,16:9;",
    "O35,Scandoubler FX,None,HQ2x,CRT 25%,CRT 50%,CRT 75%;",
    "-,-= Analogue video output =-;",
    "P1O[16],CRT Adjust,Off,On;",
    "H1P1O[21:17],CRT H-Size,0,-1,-2,-3,-4,-5,-6,-7,-8;",
    "H1P1O[28:22],CRT H-Position,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,+16,+17,+18,+19,+20,+21,+22,+23,+24,+25,+26,+27,+28,+29,+30,+31,+32,+33,+34,+35,+36,+37,+38,+39,+40,+41,+42,+43,+44,+45,+46,+47,-5,-4,-3,-2,-1;",
    "H1P1O[33:29],CRT V-Shift,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1;",
    "-;","DIP;","-;",
    "O6,Autosave NVRAM,Off,On;","T7,Save NVRAM;","T8,Clear NVRAM;",
    "-;","TE,Enter EJB Menu (MK1/MK2);",
    "-;","T9,Service/Test;","TA,Service Credit;","TB,Tilt;","TC,Volume Up;","TD,Volume Down;",
    "-;","R0,Reset;",
    "J1,High Punch,Low Punch,Block,High Kick,Low Kick,Block 2,Start,Coin;",
    "jn,X,Y,A,B,R,L,Start,Select;","V,v",`BUILD_DATE
  };

  wire[15:0]status_menumask={14'd0,~status[16],direct_video};
  hps_io #(.CONF_STR(CONF_STR)) hps_io(
    .clk_sys(clk_sys),.HPS_BUS(HPS_BUS),.buttons,.status,.status_menumask,
    .forced_scandoubler,.gamma_bus,.direct_video,.video_rotated(1'b0),
    .ioctl_download,.ioctl_upload,.ioctl_upload_req,.ioctl_upload_index(8'd4),
    .ioctl_wr,.ioctl_rd,.ioctl_addr(ioctl_addr_hps),.ioctl_dout,.ioctl_din,
    .ioctl_index(ioctl_index_hps),.ioctl_wait,
    .joystick_0(joystick_0_hps),.joystick_1(joystick_1_hps),
    .joystick_2(joystick_2_hps),.joystick_3(joystick_3_hps));

  logic[2:0]por_pipe=3'b111;
  always_ff @(posedge clk_sys)begin
    if(!locked)por_pipe<=3'b111;else por_pipe<={por_pipe[1:0],1'b0};
  end
  wire rst_pon=por_pipe[2];
  wire rst_game=RESET||status[0]||buttons[1];
  wire sdram_por=rst_pon;

  wire[24:0]sd_addr,ctl_addr;wire[15:0]sd_din,sd_dout,ctl_din,ctl_dout;
  wire[1:0]sd_be,ctl_wtbt;wire sd_rd,sd_wr,sd_ack,ctl_rd,ctl_we,ctl_ready,sdram_ready;
  yunit_sdram_adapter sdram_adapter(
    .clk(clk_sys),.rst(sdram_por),.sd_addr,.sd_din,.sd_be,.sd_rd,.sd_wr,.sd_dout,.sd_ack,.sdram_ready,
    .ctl_addr,.ctl_din,.ctl_wtbt,.ctl_rd,.ctl_we,.ctl_dout,.ctl_ready);
  sdram_stock sdram_controller(
    .init(sdram_por),.clk(clk_sys),.SDRAM_DQ,.SDRAM_A,.SDRAM_DQML,.SDRAM_DQMH,.SDRAM_BA,
    .SDRAM_nCS,.SDRAM_nWE,.SDRAM_nRAS,.SDRAM_nCAS,.SDRAM_CKE,
    .wtbt(ctl_wtbt),.addr(ctl_addr),.dout(ctl_dout),.din(ctl_din),.we(ctl_we),.rd(ctl_rd),.ready(ctl_ready));

  wire[7:0]core_r,core_g,core_b;wire core_hs,core_vs,core_hb,core_vb,core_de,core_ce;
  wire signed[15:0]core_audio;wire core_audio_ce;
  tunit_profile_t profile;wire profile_valid;wire[3:0]complete_mask;wire[7:0]descriptor_error;
  wire[31:0]loader_accepted,loader_dropped,cpu_pc,video_underrun_count;
  wire cpu_illegal,core_rst,dma_busy,loader_or_backend_busy,video_underrun,audio_underrun,audio_overrun;
  wire[7:0]reset_reason;wire[13:0]adsp_pc;wire adsp_valid,adsp_unimplemented,nvram_dirty;
  wire[31:0]dbg_blit_hold_max,dbg_wr_hold_max,dbg_commit_count,dbg_blitq;
  wire[31:0]dbg_page_state;
  wire[31:0]audio_tel_a,audio_tel_b,audio_tel_c,audio_tel_d;
  tunit_board board(
    .clk_snd(clk_snd),
    .clk(clk_sys),.rst_pon,.rst_game,.pll_locked(locked),.sdram_ready,
    .ioctl_download,.ioctl_upload,.ioctl_wr,.ioctl_index,.ioctl_addr,.ioctl_dout,.ioctl_wait,.ioctl_din,.ioctl_upload_req,
    .autosave(status[6]),.manual_save(status[7]),.clear_nvram(status[8]),.osd_status(OSD_STATUS),
    .joystick_0,.joystick_1,.joystick_2,.joystick_3,
    .service(status[9]),.service_credit(status[10]),.tilt(status[11]),
    .volume_up(status[12]),.volume_down(status[13]),.ejb_trigger(status[14]),
    .sdram_addr(sd_addr),.sdram_din(sd_din),.sdram_be(sd_be),.sdram_rd(sd_rd),.sdram_wr(sd_wr),.sdram_dout(sd_dout),.sdram_ack(sd_ack),
    .ddram_addr(DDRAM_ADDR),.ddram_burstcnt(DDRAM_BURSTCNT),.ddram_rd(DDRAM_RD),.ddram_we(DDRAM_WE),
    .ddram_din(DDRAM_DIN),.ddram_be(DDRAM_BE),.ddram_busy(DDRAM_BUSY),.ddram_dout(DDRAM_DOUT),.ddram_dout_ready(DDRAM_DOUT_READY),
    .vid_r(core_r),.vid_g(core_g),.vid_b(core_b),.hsync(core_hs),.vsync(core_vs),.hblank(core_hb),.vblank(core_vb),.de(core_de),.ce_pixel(core_ce),
    .audio(core_audio),.audio_ce(core_audio_ce),.profile,.profile_valid,.complete_mask,.descriptor_error,
    .loader_accepted,.loader_dropped,.cpu_pc,.cpu_illegal,.reset_reason,.rst_cpu(core_rst),.dma_busy,.loader_or_backend_busy,
    .video_underrun,.video_underrun_count,.audio_underrun,.audio_overrun,.audio_tel_a,.audio_tel_b,.audio_tel_c,.audio_tel_d,.adsp_pc,.adsp_valid,.adsp_unimplemented,.nvram_dirty,
    .dbg_blit_hold_max,.dbg_wr_hold_max,.dbg_commit_count,.dbg_blitq,
    .dbg_page_state);

  // ---- cabinet instrument (TUNIT-P0035, +define+TUNIT_DIAG) ---------------
  // Follows Wolf, which keeps its busy-wedge readout behind a diag define and
  // composites into a screen corner. Production builds must NOT define this.
  // NOTE: Quartus SMART_RECOMPILE has leaked diag overlays into production
  // images before -- wipe db/ and incremental_db/ when switching back.
  wire[7:0]diag_r,diag_g,diag_b;
  wire diag_hs,diag_vs,diag_hb,diag_vb;
`ifdef TUNIT_DIAG
  wire diag_de_unused;
  tunit_diag_overlay instrument(
    .clk(clk_sys),.ce_pix(core_ce),.rst(rst_pon),
    .core_rst,.reset_reason,.cpu_illegal,.cpu_pc,
    .dbg_blit_hold_max,.dbg_wr_hold_max,.dbg_commit_count,
    .audio_tel_a,.audio_tel_b,.audio_tel_c,.audio_tel_d,
    .video_underrun_count,.dbg_blitq,.dbg_page_state,
    .g_r(core_r),.g_g(core_g),.g_b(core_b),
    .g_hs(core_hs),.g_vs(core_vs),.g_hb(core_hb),.g_vb(core_vb),.g_de(core_de),
    .vid_r(diag_r),.vid_g(diag_g),.vid_b(diag_b),
    .hsync(diag_hs),.vsync(diag_vs),.hblank(diag_hb),.vblank(diag_vb),
    .de(diag_de_unused));
`else
  assign {diag_r,diag_g,diag_b}={core_r,core_g,core_b};
  assign diag_hs=core_hs;assign diag_vs=core_vs;
  assign diag_hb=core_hb;assign diag_vb=core_vb;
`endif

  wire[7:0]video_r,video_g,video_b;
  wire video_hs,video_vs,video_hb,video_vb,video_ce;
  tunit_crt_adjust crt_geometry(
    .clk(clk_sys),.ce_pix(core_ce),.active_in(status[16]),
    .hsize_code(status[21:17]),.hpos_code(status[28:22]),
    .vshift_code(status[33:29]),
    .r_in(diag_r),.g_in(diag_g),.b_in(diag_b),
    .hs_in(diag_hs),.vs_in(diag_vs),.hb_in(diag_hb),.vb_in(diag_vb),
    .ce_pix_out(video_ce),.r_out(video_r),.g_out(video_g),.b_out(video_b),
    .hs_out(video_hs),.vs_out(video_vs),.hb_out(video_hb),.vb_out(video_vb));
  arcade_video #(.WIDTH(512),.DW(24)) video(
    .clk_video(clk_sys),.ce_pix(video_ce),.RGB_in({video_r,video_g,video_b}),
    .HBlank(video_hb),.VBlank(video_vb),.HSync(video_hs),.VSync(video_vs),
    .CLK_VIDEO,.CE_PIXEL,.VGA_R,.VGA_G,.VGA_B,.VGA_HS,.VGA_VS,.VGA_DE,.VGA_SL,
    .fx(status[5:3]),.forced_scandoubler,.gamma_bus);

  assign AUDIO_L=core_audio;assign AUDIO_R=core_audio;assign AUDIO_S=1'b1;
  assign LED_USER=ioctl_download||loader_or_backend_busy;
  assign LED_DISK={1'b0,DDRAM_RD||DDRAM_WE};
endmodule
