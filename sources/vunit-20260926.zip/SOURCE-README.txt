Cruis'n (V Unit) - r30 (Cruis'n USA, World, Off Road)
RBF SHA-256: b768a364b8df4f3587ea0c447961eb90f3f3b09595094dc276c10456d796f307

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: vunit-gm1-r30
The compiled binary's validation status is recorded in the feed catalog.
