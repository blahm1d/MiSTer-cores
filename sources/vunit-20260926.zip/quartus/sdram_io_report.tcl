# sdram_io_report.tcl -- read-only TimeQuest report of the board-SDRAM pin paths at every operating corner (gm1), forked
# from bandwidth/bw1/quartus/sdram_io_report.tcl (build 2+). Runs inside the fit ticket after quartus_sta (run_fit.sh).
# Output: output_files/sdram_io_timing.txt with the worst setup and hold paths into the core from SDRAM_DQ and out to the
# SDRAM_* pins, full-path detail, so the relationships can be checked against gm1.sdc (SDRAM_CLK at -3515 ps with a setup
# multicycle of 2: input setup ~23.5 ns, input hold ~+3.5 ns).
project_open gm1 -revision gm1
create_timing_netlist
read_sdc
update_timing_netlist
set rpt output_files/sdram_io_timing.txt
file delete -force $rpt
foreach_in_collection op [get_available_operating_conditions] {
    set_operating_conditions $op
    update_timing_netlist
    set tag [string map {" " "_"} [get_operating_conditions_info $op -display_name]]
    report_timing -setup -from [get_ports {SDRAM_DQ[*]}] -npaths 2 -detail full_path -file $rpt -append -panel_name "sdram_in_setup_$tag"
    report_timing -hold  -from [get_ports {SDRAM_DQ[*]}] -npaths 2 -detail full_path -file $rpt -append -panel_name "sdram_in_hold_$tag"
    report_timing -setup -to [get_ports {SDRAM_A[*] SDRAM_BA[*] SDRAM_DQ[*] SDRAM_DQML SDRAM_DQMH SDRAM_CKE SDRAM_nCS SDRAM_nRAS SDRAM_nCAS SDRAM_nWE}] -npaths 2 -detail full_path -file $rpt -append -panel_name "sdram_out_setup_$tag"
    report_timing -hold  -to [get_ports {SDRAM_A[*] SDRAM_BA[*] SDRAM_DQ[*] SDRAM_DQML SDRAM_DQMH SDRAM_CKE SDRAM_nCS SDRAM_nRAS SDRAM_nCAS SDRAM_nWE}] -npaths 2 -detail full_path -file $rpt -append -panel_name "sdram_out_hold_$tag"
}
project_close
