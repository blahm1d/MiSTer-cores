#!/usr/bin/env bash
# Assemble an immutable Quartus snapshot for the gm1 master core and print the submit command. Copies the pinned framework
# sys/ (read-only), the gm1 quartus files and RTL, the C31 (rtl/c31, the G1/G2-gated fit form), the V-unit video and DDR
# plumbing, the fabric DCS (rtl/dcs_fabric) and the two cabinet-proven bw1 platform files, records SHA-256 of every copied
# source, and freezes a fresh build id. Does NOT run Quartus and does NOT submit (the main session holds the veto).
# Run bandwidth/gm1/review/preflight_gm1.py on the printed snapshot before submitting.
#
# --diag  (2026-09-25, forked from bandwidth/wg1/quartus/prepare.sh) CABINET DIAGNOSTIC variant: after the source
#         record is written, appends  set_global_assignment -name VERILOG_MACRO "GM1_DIAG_MIRROR=1"  to the SNAPSHOT
#         gm1.qsf only (the project QSF stays release-clean). gm1_core.sv then builds the full gm1_status_mirror
#         (status block + wheel mailbox -> DDR3 0x38700000, read by ladder/diag_mirror/gm1_perflog.sh) instead of the
#         release gm1_wheel_mailbox (mailbox only). Snapshot dir gm1-quartus-diag-<UTC>. Preflight it with
#         preflight_gm1.py <snapshot quartus dir> --diag  (needs a run_gm1_sim.py --diag-mirror FRAMES receipt and a
#         PASS ladder/diag_mirror/check_status_mirror.py receipt on the same sources).
set -Eeuo pipefail
DIAG=0
if [ "${1:-}" = "--diag" ]; then DIAG=1; elif [ -n "${1:-}" ]; then echo "usage: prepare.sh [--diag]" >&2; exit 2; fi
ROOT=/d/deck/fpga/cruisinusa
L=$ROOT/bandwidth/gm1
STAMP=$(date -u +%Y%m%dT%H%M%S%NZ)
if [ "$DIAG" = 1 ]; then TOP=$ROOT/build/gm1-quartus-diag-$STAMP; else TOP=$ROOT/build/gm1-quartus-$STAMP; fi
SNAP=$TOP/source
Q=$SNAP/quartus
mkdir -p "$Q" "$SNAP"/rtl/gm1 "$SNAP"/rtl/c31/mem/sdram "$SNAP"/rtl/c31/periph "$SNAP"/rtl/vunit "$SNAP"/rtl/memory \
         "$SNAP"/rtl/integration "$SNAP"/rtl/video "$SNAP"/rtl/platform "$SNAP"/rtl/presentation "$SNAP"/rtl/dcs_fabric \
         "$SNAP"/rtl/bw1
cp "$L"/quartus/*.sv "$L"/quartus/*.sdc "$L"/quartus/*.qsf "$L"/quartus/*.qpf "$L"/quartus/*.qip \
   "$L"/quartus/*.sh "$L"/quartus/*.mra "$L"/quartus/*.tcl "$Q"/
cp "$L"/review/sta_audit_gm1.py "$Q"/
cp "$L"/review/assembly_gate_gm1.py "$Q"/
cp "$L"/rtl/*.sv "$SNAP/rtl/gm1"/
cp "$ROOT"/rtl/c31/*.sv "$ROOT"/rtl/c31/*.svh "$SNAP/rtl/c31"/
# memory tier (r8) = the A1d request/response tier pinned in the gm1 lane: C2 behind a request/response port, c31_memory
# wrapper keeps the C2 ports and timing (gate build/c31-memp2-20260917T024715224345Z, G2 identical clocks, unit fit
# 3,914 ALM / 295 RAM). Previous: rtl/mem_c2 (C2). C3's burst page cache is not built.
# stage 3 (2026-09-18): the P3 tier (P2 + a read-only fetch port, tied off by the wrapper; gate
# build/c31-memp3-20260917T045533005801Z). Previous: rtl/mem_p2.
cp "$L"/rtl/mem_p3/c31_memory.sv "$L"/rtl/mem_p3/c31_bus_adapter.sv "$L"/rtl/mem_p3/c31_memory_p3.sv \
   "$L"/rtl/mem_p3/c31_page_cache.sv "$L"/rtl/mem_p3/c31_memory_fp.sv "$SNAP/rtl/c31/mem"/
cp "$ROOT"/rtl/c31/mem/sdram/*.sv "$SNAP/rtl/c31/mem/sdram"/
cp "$ROOT"/rtl/c31/periph/*.sv "$SNAP/rtl/c31/periph"/
cp "$ROOT"/rtl/vunit/*.sv "$SNAP/rtl/vunit"/
cp "$ROOT"/rtl/memory/*.sv "$SNAP/rtl/memory"/
cp "$ROOT"/rtl/integration/vunit_board_io.sv "$SNAP/rtl/integration"/
cp "$ROOT"/rtl/video/cusa_video_ce.sv "$SNAP/rtl/video"/
cp "$ROOT"/rtl/platform/avalon_shared_mux.sv "$ROOT"/rtl/platform/mister_ddram_adapter.sv "$SNAP/rtl/platform"/
cp "$ROOT"/rtl/presentation/*.sv "$SNAP/rtl/presentation"/
cp "$ROOT"/rtl/dcs_fabric/*.sv "$SNAP/rtl/dcs_fabric"/
cp "$ROOT"/bandwidth/bw1/rtl/core/bw1_pll.sv "$ROOT"/bandwidth/bw1/rtl/core/bw1_hdmi_status.sv "$SNAP/rtl/bw1"/
cp -r "$ROOT"/platform/mister/sys "$Q"/sys
BID=$(printf 'a9100001%08x%08x%08x' $(( (RANDOM<<16)^RANDOM )) $(date -u +%s) $(( (RANDOM<<16)^RANDOM )))
printf "// gm1 frozen build id for %s\n\`define CUSA_ENGINEERING_BUILD_ID 128'h%s\n" "$STAMP" "$BID" > "$Q"/cusa_build_identity.svh
(cd "$SNAP" && find rtl quartus -type f ! -path 'quartus/sys/*' | sort | xargs sha256sum) > "$TOP/SOURCE.sha256"
if [ "$DIAG" = 1 ]; then
  # after the record: SOURCE.sha256 keeps the project QSF hash; preflight --diag checks the ONLY QSF delta is this line
  printf '\n# CABINET DIAGNOSTIC BUILD (prepare.sh --diag): full status mirror -> DDR3 0x38700000\nset_global_assignment -name VERILOG_MACRO "GM1_DIAG_MIRROR=1"\n' >> "$Q"/gm1.qsf
  echo "DIAG variant: GM1_DIAG_MIRROR=1 appended to the snapshot gm1.qsf"
fi
chmod +x "$Q"/run_fit.sh "$Q"/submit.sh "$Q"/prepare.sh 2>/dev/null || true
echo "Snapshot:  $Q"
echo "Build id:  0x$BID"
echo "c31_core:  $(sha256sum "$SNAP/rtl/c31/c31_core.sv" | cut -c1-64)"
echo "PREFLIGHT (main session, before submit):"
echo "  C:/Python314/python.exe $L/review/preflight_gm1.py $(cygpath -w "$Q" 2>/dev/null || echo "$Q")$([ "$DIAG" = 1 ] && echo " --diag")"
echo "SUBMIT (main session only, after preflight):"
echo "  bash.exe $Q/submit.sh"
echo "Expected RBF on success:  $Q/output_files/gm1.rbf"
