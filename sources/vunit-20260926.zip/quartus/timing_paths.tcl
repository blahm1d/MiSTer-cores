# Preserve actionable endpoint evidence with every physical attempt.
set here [file dirname [file normalize [info script]]]
set out [file join $here output_files timing_paths]
file mkdir $out
project_open [file join $here gm1] -revision gm1
create_timing_netlist
read_sdc
update_timing_netlist
foreach_in_collection op [get_available_operating_conditions] {
    set corner [get_operating_conditions_info $op -display_name]
    if {![string match "*Slow*" $corner]} { continue }
    set_operating_conditions $op
    update_timing_netlist
    set tag [string map {" " "_"} $corner]
    report_timing -setup -npaths 32 -nworst 1 -detail full_path -file [file join $out paths_$tag.txt] -panel_name "paths_$tag"
    # Retain each independent block's worst paths even when the global list
    # is saturated by CPU/cache endpoints. These reports do not add exceptions.
    foreach {block pattern} {
        cpu {*|c31_core:u_core|*}
        cache {*|c31_memory_fp:u_mem|*}
        texture {*|vunit_memory_arbiter:memory|*}
        raster {*|vunit_flat_raster:renderer|*}
        shared_ddr {*|avalon_shared_mux:shared_mux|*}
        sdram {*|gm1_sdram:u_sdram|*}
    } {
        set targets [get_registers -nowarn $pattern]
        if {[get_collection_size $targets] == 0} {
            post_message -type error "gm1: empty timing-path block $block ($pattern)"
            error "missing timing endpoints: $block"
        }
        report_timing -setup -to $targets -npaths 8 -nworst 1 -detail full_path -file [file join $out paths_${tag}_${block}.txt] -panel_name "paths_${tag}_${block}"
    }
    array unset worst
    array unset count
    array unset launch
    set paths [get_timing_paths -setup -npaths 200000 -nworst 1 -less_than_slack 2.5]
    foreach_in_collection p $paths {
        set slack [get_path_info $p -slack]
        set to [get_node_info -name [get_path_info $p -to]]
        regsub -all {\[[0-9]+\]} $to {[]} to
        regsub -all {~DUPLICATE} $to {} to
        if {![info exists worst($to)] || $slack < $worst($to)} {
            set worst($to) $slack
            set launch($to) [get_node_info -name [get_path_info $p -from]]
        }
        if {![info exists count($to)]} { set count($to) 0 }
        incr count($to)
    }
    set rows {}
    foreach k [array names worst] { lappend rows [list $worst($k) $count($k) $k $launch($k)] }
    set fh [open [file join $out endpoints_$tag.txt] w]
    puts $fh "corner=$corner endpoints_below_2.5ns=[get_collection_size $paths]"
    foreach r [lsort -real -index 0 $rows] {
        puts $fh [format "%8.3f n=%-6d %s <- %s" [lindex $r 0] [lindex $r 1] [lindex $r 2] [lindex $r 3]]
    }
    close $fh
}
project_close
puts "GM1_TIMING_PATH_REPORT_DONE"
