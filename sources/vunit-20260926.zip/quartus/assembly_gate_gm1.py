"""Preserve strict STA verdict; optionally permit an explicitly authorized test artifact."""
from pathlib import Path
import json
import subprocess
import sys


def decide(audit, max_slow_setup_corners):
    if audit['result'] == 'PASS':
        return 'PASS', []
    if max_slow_setup_corners not in (1, 2) or audit['unparsed']:
        return 'BLOCKED', []
    allowed = set()
    failing = []
    for corner, kinds in audit['corners'].items():
        for row in kinds.get('Setup', []):
            if row['slack_ns'] < 0 or row['tns_ns'] != 0:
                if not corner.startswith('Slow '):
                    return 'BLOCKED', []
                failing.append(corner)
                if row['slack_ns'] < 0:
                    allowed.add('%s Setup %s %.3f ns' % (corner, row['clock'], row['slack_ns']))
                if row['tns_ns'] != 0:
                    allowed.add('%s Setup %s nonzero TNS %.3f ns' % (corner, row['clock'], row['tns_ns']))
    corners = sorted(set(failing))
    if 1 <= len(corners) <= max_slow_setup_corners and audit['violations'] and set(audit['violations']) <= allowed:
        label = 'ONE_SLOW_SETUP_CORNER' if len(corners) == 1 else 'TWO_SLOW_SETUP_CORNERS'
        return 'TEST_ONLY_' + label, corners
    return 'BLOCKED', corners


def main():
    q = Path(sys.argv[1]).resolve()
    policy_path = q / 'assembly_policy.json'
    policy = json.loads(policy_path.read_text(encoding='utf-8')) if policy_path.exists() else {}
    allow = 2 if policy.get('allow_two_slow_setup_corners') is True else (1 if policy.get('allow_one_slow_setup_corner') is True else 0)
    audit_path = q / 'output_files/sta_audit.json'
    rc = subprocess.run([sys.executable, str(q / 'sta_audit_gm1.py'), str(q)]).returncode
    if rc not in (0, 1) or not audit_path.exists():
        raise SystemExit('Strict audit did not complete')
    audit = json.loads(audit_path.read_text(encoding='utf-8'))
    result, corners = decide(audit, allow)
    receipt = {'result': result, 'strict_result': audit['result'], 'policy': policy,
               'exception_corners': corners, 'violations': audit['violations'], 'unparsed': audit['unparsed']}
    (q / 'output_files/assembly_gate.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt, indent=2))
    return 1 if result == 'BLOCKED' else 0


if __name__ == '__main__':
    sys.exit(main())
