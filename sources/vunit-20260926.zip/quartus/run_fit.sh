#!/usr/bin/env bash
# gm1 single-ticket Quartus chain (runs INSIDE the shared FIFO ticket, cwd = the prepared snapshot's quartus dir).
# Pinned Quartus 17.0: map -> fit -> sta (multicorner) -> STA verdict -> asm -> RBF. The main session's strict per-corner
# audit (bandwidth/gm1/review/sta_audit_gm1.py) is the sign-off authority. Mirrors bandwidth/dcs1/quartus/run_fit.sh.
set -Eeuo pipefail
export MSYS2_ARG_CONV_EXCL="*"
HERE="$(cd "$(dirname "$0")" && pwd)"
QBIN=/c/intelFPGA_lite/17.0/quartus/bin64
REV=gm1
cd "$HERE"
echo "The next controlled worker in this ticket is the pinned Quartus executable."
"$QBIN/quartus_map.exe" $REV
"$QBIN/quartus_fit.exe" $REV
"$QBIN/quartus_sta.exe" $REV
"$QBIN/quartus_sta.exe" -t sdram_io_report.tcl
"$QBIN/quartus_sta.exe" -t timing_paths.tcl
STA=output_files/$REV.sta.rpt
if [ ! -f "$STA" ]; then echo "STA report missing"; exit 3; fi
if grep -qi "Timing requirements not met" "$STA"; then
  echo "STA_VERDICT=REQUIREMENTS_NOT_MET" | tee output_files/sta_verdict.txt
else
  echo "STA_VERDICT=NO_UNMET_REQUIREMENT_MESSAGE" | tee output_files/sta_verdict.txt
fi
# Frozen audit is the SIGN-OFF gate (unchanged, still strict). User 2026-09-24: ALWAYS assemble, so a corner-only miss
# does not need a second FIFO ticket for the waiver assembly. The audit verdict is recorded and the ticket still exits
# non-zero when it fails, so a timing miss stays visible in the FIFO log; the RBF is then a WAIVER candidate only
# (output_files/TIMING_NOT_SIGNED_OFF.txt), and the main session decides per the cold-corner rule.
set +e
/c/Python314/python.exe "$(cygpath -am "$HERE/assembly_gate_gm1.py")" "$(cygpath -am "$HERE")"
GATE_RC=$?
set -e
"$QBIN/quartus_asm.exe" $REV
ls -l output_files/$REV.rbf && echo "RBF: $HERE/output_files/$REV.rbf"
if [ "$GATE_RC" -ne 0 ]; then
  echo "assembly gate rc=$GATE_RC: RBF built but NOT signed off (waiver candidate only)" | tee output_files/TIMING_NOT_SIGNED_OFF.txt
  exit 10
fi
