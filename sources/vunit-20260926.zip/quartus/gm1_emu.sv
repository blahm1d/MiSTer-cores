// SPDX-License-Identifier: GPL-2.0-or-later
// gm1_emu.sv -- MiSTer emu wrapper for the Cruis'n USA master core (gm1), forked from bandwidth/bw1/quartus/bw1_emu.sv
// (the cabinet-proven platform: bw1_pll 50 MHz core clock plus a -3515 ps sibling for SDRAM_CLK, P0022 power-on reset,
// hps_io ioctl WIDE=1, DDRAM and board SDRAM on the core clock) and bandwidth/dcs1/quartus/dcs1_emu.sv (DCS audio).
//
// Controls follow MAME midvunit.cpp INPUT_PORTS (midvunit, crusnusa; pinned 0.289 copy
// segamodel1/references/mame-mame0289/src/mame/williams/midvunit.cpp:747-798):
//   IN0 (active low)  coin1 0x0001, start 0x0004, test 0x0010, service 0x0040,
//                     gears 4/3/2/1 = 0x0400/0x0800/0x1000/0x2000
//   IN1 (active low)  radio 0x0002, views 1/2/3 = 0x0010/0x0020/0x0040; bits 7-15 read 0 (no motion board)
//   WHEEL  0x80 centre, 0x10-0xf0      ACCEL / BRAKE  0x00 released, 0xff pressed
//   DSW    0xf9fe (MAME defaults: master, upright, motion off, USA-8 coinage)
// Shifter: MAME's default "Buttons (sticky)" behaviour with sequential Shift Up / Shift Down buttons: the selected gear
// stays engaged; the core starts in 1st gear. Steering: left stick X. r25 pad map (user): RT Gas, LT Brake, RB/LB Shift
// Up/Down, X/Y/B View 1/2/3, A Radio, Back Coin, Start Start, d-pad up/down Volume, left Test, right Service.
// r29: the per-game control table lives in module gm1_controls (end of this file, line-cited to midvunit.cpp:747-798);
// Test / Service / Volume Up / Volume Down / Nitro are appended J1 buttons, the d-pad shortcuts are OSD-switchable.
`include "cusa_build_identity.svh"
module emu (
    `include "sys/emu_ports.vh"
);
    localparam CONF_STR = {
        "CruisinUSA;;",
        "-;",
        "O2,Send ENTER,Off,On;",
        "T8,Save NVRAM;",                     // r23: also saved by Main's Save settings, and automatically on OSD open after CMOS changed
        "O3,Sound filter,Arcade,Off;",
        "O67,Dither,MAME,Soft,Dark,Raw;",     // r22: translucent black mesh panels (gm1_dedither.sv); Raw = arcade framebuffer
        "O45,Rumble,High,Medium,Low,Off;",   // r21: gamepad rumble from the game's force-feedback intent (gm1_rumble.sv)   // 2026-09-23: TL084 output-stage model (gm1_tl084_lpf.sv); Off = raw DAC
        "OA,D-pad Test/Service/Volume,On,Off;",   // r29: status[10] (status[9] is reserved for the 15 kHz option)
        // r30 cabinet controls (docs/CAB_CONTROLS.md); every default = the r29 behaviour
        "OBC,Pedals,Buttons,Right stick Y split,Right stick X gas/Y brake,Right stick X/Y inverted;",
        "ODE,Analog source,USB,DE10 ADC wheel+pedals,DE10 ADC wheel only;",
        "OF,SNAC,Off,Cab switches;",
        "OG,SNAC motor,Off,On;",
        "-;",
        // r29: APPEND ONLY -- saved pad maps are positional. Test, Service, Volume Up / Down and Nitro (Off Road) added
        // after Start so every existing map keeps its meaning.
        "J1,Gas,Brake,Shift Up,Shift Down,View 1,View 2,View 3,Radio,Coin,Start,Test,Service,Volume Up,Volume Down,Nitro;",
        "jn,None,None,R,L,Y,X,A,B,Select,Start;",   // r25 default pad map (see the controls block)
        // Bump this on EVERY revision. It read gm1-master-r2 on r3 and r4, which cost time
        // identifying what was actually running on the cabinet (see the 2026-09-16 handoff).
        "V,gm1-master-r30"
    };
    wire clk_sys, clk_sdram_pin, pll_locked;
    wire [15:0] rumble_core;                       // r21 gm1_rumble output (clk_sys domain)
    wire [15:0] rumble_q = rumble_core;
    wire [127:0] status;
    wire [1:0]  buttons;
    wire [31:0] joystick_0;
    wire [15:0] joystick_l_analog_0, joystick_r_analog_0;
    tri [35:0] ext_bus;
    assign ext_bus[32]=1'b0;
    assign ext_bus[15:0]=16'b0;
    tri [21:0] gamma_bus;
    assign gamma_bus[21]=1'b0;

    wire        ioctl_download, ioctl_wr;
    wire [26:0] ioctl_addr;
    wire [15:0] ioctl_dout;
    wire [15:0] ioctl_index;
    wire        ioctl_wait;
    wire        ioctl_upload, nvram_upload_req, nvram_dirty;   // r23 NVRAM save (gm1_cmos_shadow.sv)
    wire [15:0] ioctl_din;

    wire [64:0] mister_rtc;                         // r24: PIC2 clock for Cruis'n World / Off Road Challenge
    hps_io #(.CONF_STR(CONF_STR), .WIDE(1)) hps_io (
        .clk_sys(clk_sys),.RTC(mister_rtc),.HPS_BUS(HPS_BUS),.EXT_BUS(ext_bus),.gamma_bus(gamma_bus),
        .joystick_0(joystick_0),.joystick_l_analog_0(joystick_l_analog_0),.joystick_r_analog_0(joystick_r_analog_0),
        .joystick_0_rumble(rumble_q),.joystick_1_rumble(16'd0),.joystick_2_rumble(16'd0),
        .joystick_3_rumble(16'd0),.joystick_4_rumble(16'd0),.joystick_5_rumble(16'd0),
        .ps2_kbd_clk_in(1'b1),.ps2_kbd_data_in(1'b1),.ps2_mouse_clk_in(1'b1),.ps2_mouse_data_in(1'b1),
        .ps2_kbd_led_status(3'd0),.ps2_kbd_led_use(3'd0),
        .sd_rd(1'b0),.sd_wr(1'b0),
        .status(status),.buttons(buttons),.status_menumask(16'b0),
        .status_in(128'b0),.status_set(1'b0),.info_req(1'b0),.info(8'b0),
        .video_rotated(1'b0),.new_vmode(1'b0),
        .ioctl_download(ioctl_download),.ioctl_index(ioctl_index),.ioctl_wr(ioctl_wr),
        .ioctl_addr(ioctl_addr),.ioctl_dout(ioctl_dout),.ioctl_wait(ioctl_wait),
        .ioctl_upload(ioctl_upload),.ioctl_upload_req(nvram_upload_req),.ioctl_upload_index(8'd3),.ioctl_din(ioctl_din)
    );

    bw1_pll pll (.refclk(CLK_50M),.rst(1'b0),.outclk_0(clk_sys),.outclk_1(clk_sdram_pin),.locked(pll_locked));

    // Power-on reset (P0022): 2-FF synced ~locked on the one core clock; both ROM capture paths and the SDRAM
    // controller use it.
    (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS" *)
    reg [2:0] por50_pipe=3'b111;
    always @(posedge clk_sys or negedge pll_locked) if(!pll_locked) por50_pipe<=3'b111; else por50_pipe<={por50_pipe[1:0],1'b0};
    wire por50 = por50_pipe[2];
    wire core_reset = RESET || status[0] || buttons[1];

    // ---- controls (r29/r30: gm1_controls, end of this file; gates family/check_controls.py, family/check_cabctl_io.py) ----
    wire [1:0]  game_id;          // r24 family core: captured by gm1_core from MRA index 4 (0 = Cruis'n USA)
    wire [15:0] in0, in1, dips;
    wire [31:0] adc_word;
    wire        b_test;
    wire        osd_enter;
    // r30 cabinet-control options (docs/CAB_CONTROLS.md). Defaults (all 0) are the r29 behaviour.
    wire [1:0]  pedal_mode = status[12:11];
    wire [1:0]  adc_src    = status[14:13];
    wire        snac_en    = status[15];
    wire        motor_en   = status[16];
    wire [23:0] pots;
    wire [15:0] cab_sw;
    gm1_controls u_controls (.clk(clk_sys), .reset(por50), .game(game_id), .joystick(joystick_0),
        .l_analog(joystick_l_analog_0), .r_analog(joystick_r_analog_0), .pedal_mode(pedal_mode), .adc_src(adc_src),
        .pots(pots), .cab_sw(cab_sw), .dpad_off(status[10]), .osd_enter(osd_enter),
        .in0(in0), .in1(in1), .dips(dips), .adc(adc_word), .test_any(b_test));

    // DE10-Nano LTC2308 (ADC_BUS = {ADC_SCK, ADC_SDO, ADC_SDI, ADC_CONVST}): pots on the 2x5 ADC header IN0-IN2.
    // Held in reset and the pins released ('z, as r29) while the source is USB.
    wire adc_on = (adc_src != 2'd0);
    wire adc_sck, adc_sdi, adc_convst;
    gm1_adc_pots u_pots (.clk(clk_sys), .reset(por50 || !adc_on), .convst(adc_convst), .sck(adc_sck), .sdi(adc_sdi),
        .sdo(ADC_BUS[2]), .pots(pots));
    assign ADC_BUS[3] = adc_on ? adc_sck    : 1'bz;
    assign ADC_BUS[2] = 1'bz;
    assign ADC_BUS[1] = adc_on ? adc_sdi    : 1'bz;
    assign ADC_BUS[0] = adc_on ? adc_convst : 1'bz;

    // SNAC user port (open drain; 1 = released): USER_IO[0] 74HC165 CLK, [1] SH/LD, [3] QH in; motor [4] PWM_N,
    // [5] DIR_N, [2] EN_N; [6] unused (released: the I/O board IO6 jumper may tie it to 3.3 V).
    wire snac_clk, snac_load_n, mot_pwm_n, mot_dir_n, mot_en_n;
    wire [7:0] motor_byte; wire motor_we;
    gm1_snac_165 u_snac (.clk(clk_sys), .reset(por50 || !snac_en), .qh(USER_IN[3]), .load_n(snac_load_n), .sck(snac_clk),
        .sw(cab_sw));
    gm1_snac_motor u_motor (.clk(clk_sys), .reset(por50 || !motor_en), .motor(motor_byte), .motor_we(motor_we),
        .pwm_n(mot_pwm_n), .dir_n(mot_dir_n), .en_n(mot_en_n));
    assign USER_OUT = {1'b1, motor_en ? mot_dir_n : 1'b1, motor_en ? mot_pwm_n : 1'b1, 1'b1,
                       motor_en ? mot_en_n : 1'b1, snac_en ? snac_load_n : 1'b1, snac_en ? snac_clk : 1'b1};

    // ENTER from the OSD. IN0 bit 4 is the Test switch, which is what the game calls ENTER
    // (midvunit.cpp:751, PORT_NAME("Enter") ... // Test switch). The cold-boot calibration screen
    // demands it on every power-on because CMOS does not persist, and it is the 11th entry in the
    // J1 list -- past the end of what fits on a normal pad, which is what blocked the first cabinet
    // run. Toggling the OSD item in EITHER direction emits one press, so it can never latch stuck.
    // 500 ms of wall time is ~7 guest frames at this core's quarter speed, so the game cannot miss
    // it between input polls.
    reg        osd_enter_q;
    reg [25:0] enter_hold;
    always @(posedge clk_sys) begin
        if (por50) begin osd_enter_q <= status[2]; enter_hold <= 26'd0; end
        else begin
            osd_enter_q <= status[2];
            if (status[2] != osd_enter_q)  enter_hold <= 26'd25_000_000;   // 500 ms at 50 MHz
            else if (enter_hold != 26'd0)  enter_hold <= enter_hold - 26'd1;
        end
    end
    assign osd_enter = (enter_hold != 26'd0);

    // r10: which source ever asserted IN0 bit 4 (TEST/Enter). On r7 and r9 pressing START kicked the game into its
    // diagnostics, which the original source does on a TEST edge (CUSA.ASM:975-979, 1068-1082). Sticky until the
    // core is reloaded, shown on status page 2 row C (bits 15, 14).
    reg test_btn_seen, osd_enter_seen;
    always @(posedge clk_sys) begin
        if (por50) begin test_btn_seen <= 1'b0; osd_enter_seen <= 1'b0; end
        else begin
            if (b_test)    test_btn_seen  <= 1'b1;
            if (osd_enter) osd_enter_seen <= 1'b1;
        end
    end

    assign {UART_RTS,UART_TXD,UART_DTR}=0;
    assign {SD_SCK,SD_MOSI,SD_CS}='z;
    `ifdef MISTER_DUAL_SDRAM
    assign {SDRAM2_DQ,SDRAM2_A,SDRAM2_BA,SDRAM2_CLK,SDRAM2_nWE,SDRAM2_nCAS,SDRAM2_nRAS,SDRAM2_nCS}='z;
    `endif
    `ifdef MISTER_FB
    assign {FB_EN,FB_FORMAT,FB_WIDTH,FB_HEIGHT,FB_BASE,FB_STRIDE}=0;
    assign FB_FORCE_BLANK=1;
      `ifdef MISTER_FB_PALETTE
      assign {FB_PAL_CLK,FB_PAL_ADDR,FB_PAL_DOUT,FB_PAL_WR}=0;
      `endif
    `endif
    assign VIDEO_ARX=13'd4; assign VIDEO_ARY=13'd3;
    assign {VGA_SL,VGA_F1,VGA_SCALER,VGA_DISABLE}=0;
    assign {HDMI_FREEZE,HDMI_BLACKOUT,HDMI_BOB_DEINT}=0;
    assign CLK_VIDEO=clk_sys;
    assign DDRAM_CLK=clk_sys;
    assign SDRAM_CLK=clk_sdram_pin;

    wire [7:0] r,g,b; wire ce,de,hs,vs; wire fault;
    wire signed [15:0] dcs_audio; wire dcs_audio_ce;
    gm1_core core (
        .clk(clk_sys),.por(por50),.core_reset(core_reset),
        .ioctl_download(ioctl_download),.ioctl_wr(ioctl_wr),.ioctl_addr(ioctl_addr),.ioctl_dout(ioctl_dout),
        .ioctl_index(ioctl_index),.ioctl_wait(ioctl_wait),
        .ioctl_upload(ioctl_upload),.ioctl_din(ioctl_din),.nvram_save(status[8]),.nvram_upload_req(nvram_upload_req),.nvram_dirty(nvram_dirty),
        .game(game_id),.mister_rtc(mister_rtc),
        .DDRAM_BUSY(DDRAM_BUSY),.DDRAM_DOUT_READY(DDRAM_DOUT_READY),.DDRAM_DOUT(DDRAM_DOUT),
        .DDRAM_ADDR(DDRAM_ADDR),.DDRAM_BURSTCNT(DDRAM_BURSTCNT),.DDRAM_BE(DDRAM_BE),
        .DDRAM_DIN(DDRAM_DIN),.DDRAM_RD(DDRAM_RD),.DDRAM_WE(DDRAM_WE),
        .SDRAM_DQ(SDRAM_DQ),.SDRAM_A(SDRAM_A),.SDRAM_BA(SDRAM_BA),.SDRAM_DQML(SDRAM_DQML),.SDRAM_DQMH(SDRAM_DQMH),
        .SDRAM_nCS(SDRAM_nCS),.SDRAM_nCAS(SDRAM_nCAS),.SDRAM_nRAS(SDRAM_nRAS),.SDRAM_nWE(SDRAM_nWE),.SDRAM_CKE(SDRAM_CKE),
        .cabinet_in0(in0),.cabinet_in1(in1),.cabinet_switch2(16'h0008),.cabinet_dips(dips),
        .adc_channels(adc_word),
        .show_status(1'b0), .status_page(2'b00), .rumble_intensity(2'd3 - status[5:4]), .dither_mode(status[7:6]), .rumble(rumble_core), .wheel_motor_o(motor_byte), .wheel_motor_we_o(motor_we), .test_src_seen({test_btn_seen, osd_enter_seen}),
        .audio(dcs_audio),.audio_ce(dcs_audio_ce),
        .vga_ce(ce),.vga_de(de),.vga_hs(hs),.vga_vs(vs),.vga_r(r),.vga_g(g),.vga_b(b),.fault(fault),
        .loader_done(),.dcs_rom_loaded(),.game_running(),.instructions(),.cpu_pc(),.presented_frames());

    // 2026-09-23 r19: the board's DAC -> TL084 filter stage, modelled (gm1_tl084_lpf.sv; ASSUMED 10 kHz Butterworth until
    // the V-unit R/C values are known). Holds each 31.25 kHz sample for the framework's audio path. OSD "Sound filter:
    // Off" (status[3]) bypasses it (raw DAC samples, as before r19).
    wire signed [15:0] sample_q;
    gm1_tl084_lpf u_tl084 (.clk(clk_sys), .reset(por50), .bypass(status[3]), .in_ce(dcs_audio_ce), .in_sample(dcs_audio),
                           .out_ce(), .out_sample(sample_q));

    assign CE_PIXEL=ce; assign VGA_DE=de; assign VGA_HS=hs; assign VGA_VS=vs;
    assign VGA_R=r; assign VGA_G=g; assign VGA_B=b;
    assign AUDIO_L=sample_q; assign AUDIO_R=sample_q; assign AUDIO_MIX=0; assign AUDIO_S=1;
    assign {LED_DISK,LED_POWER,BUTTONS}=0;
    assign LED_USER=fault;
endmodule

// ------------------------------------------------------------------------------------------------------------------
// gm1_controls -- the cabinet inputs for all three games (r29, r30 cabinet-control options). Gospel: MAME 0.289
// williams/midvunit.cpp (pinned copy segamodel1/references/mame-mame0289): crusnusa / crusnwld / offroadc all
// PORT_INCLUDE( midvunit ) (:799-800, :908-909, :994-995), so IN0 / IN1 / WHEEL / ACCEL / BRAKE mean the same bits in
// every game:
//   IN0 (:748-764, active low)  0x0001 coin 1, 0x0002 coin 2, 0x0004 start, 0x0010 Enter (test switch), 0x0040
//        service 1, 0x0100 volume down, 0x0200 volume up, 0x2000/0x1000/0x0800/0x0400 = 1st/2nd/3rd/4th gear
//   IN1 (:766-774, active low)  0x0002 radio, 0x0010/0x0020/0x0040 view 1/2/3; bits 7-15: crusnusa MOTION customs
//        (:812-818, read 0 without a motion board), crusnwld / offroadc IPT_UNUSED (read 1; bit 15 is replaced by the
//        PIC2 status in crusnwld_serial_status_r :335-339, gm1_family_io)
//   ADC0844 (:1195-1199) ch1 WHEEL 0x80 centre 0x10..0xf0 (:776-777), ch2 ACCEL, ch3 BRAKE 0x00 rest .. 0xff floored
//        (:779-783; MAME 0.289 field probe: min 0, max 255, default 0); adc_r = read() << m_adc_shift (:172-176),
//        shift 24 crusnusa (:2204) / 16 crusnwld, offroadc (:2218, :2236) -- the shift is applied in gm1_board
//        (fam_adc), this module supplies the channel bytes only.
//   DSW defaults: crusnusa 0xf9fe, crusnwld 0xf9ec, offroadc 0xfffd (MRA defaults, family/dsw_defaults.lua).
// Nitro (Off Road Challenge): MAME has no separate input; in offroadc a START (IN0 0x0004) press during a race uses one
// nitro (measured 2026-09-26, MAME 0.289, count 2 -> 1), and the game's SWITCH TEST lists no nitro switch. The Nitro
// button therefore drives IN0 bit 2 only when game == 2.
// joystick bits: 0-3 d-pad R L D U, then the J1 list in order: 4 Gas, 5 Brake, 6 Shift Up, 7 Shift Down, 8-10 View
// 1-3, 11 Radio, 12 Coin, 13 Start, 14 Test, 15 Service, 16 Volume Up, 17 Volume Down, 18 Nitro.
// r30 options (all default 0 = the r29 behaviour, docs/CAB_CONTROLS.md):
//   pedal_mode  0 Buttons; 1 right stick Y split (up = gas, down = brake, rest = centre); 2 right stick X = gas,
//               Y = brake, released at the negative end; 3 as 2, released at the positive end. Gas / Brake buttons
//               still press fully (max of button and axis).
//   adc_src     0 USB; 1 DE10 ADC wheel (CH0) + pedals (CH1 gas, CH2 brake); 2 DE10 ADC wheel only (pedals as
//               pedal_mode); 3 = 1.
//   cab_sw      SNAC 74HC165 switches (1 = closed), 0 when SNAC is Off: D0-D3 gear 1-4 (H shifter: a closed gear
//               switch selects that gear, which stays selected in neutral like MAME's sticky gear buttons,
//               midvunit.cpp:130-139), D4-D6 View 1-3, D7 Radio, D8 Coin 1, D9 Start, D10 Test, D11 Service,
//               D12 Volume Up, D13 Volume Down, D14 Nitro (Off Road only, as the Nitro button), D15 Coin 2.
//               Every switch is OR'd with its USB button.
module gm1_controls (
    input  wire        clk,
    input  wire        reset,
    input  wire [1:0]  game,          // 0 Cruis'n USA, 1 Cruis'n World, 2 Off Road Challenge
    input  wire [31:0] joystick,
    input  wire [15:0] l_analog,      // hps_io: X [7:0], Y [15:8], signed -127..127
    input  wire [15:0] r_analog,      // hps_io right stick: X [7:0], Y [15:8], signed (up = negative Y)
    input  wire [1:0]  pedal_mode,
    input  wire [1:0]  adc_src,
    input  wire [23:0] pots,          // gm1_adc_pots {CH2 brake, CH1 gas, CH0 wheel} bytes
    input  wire [15:0] cab_sw,
    input  wire        dpad_off,      // OSD: d-pad Test / Service / Volume shortcuts Off
    input  wire        osd_enter,     // OSD "Send ENTER" pulse (IN0 bit 4)
    output reg  [15:0] in0,
    output reg  [15:0] in1,
    output wire [15:0] dips,
    output wire [31:0] adc,           // {0, BRAKE, ACCEL, WHEEL}
    output wire        test_any
);
    wire joy_right = joystick[0], joy_left = joystick[1], joy_down = joystick[2], joy_up = joystick[3];
    wire b_gas = joystick[4], b_brake = joystick[5], b_up = joystick[6], b_down = joystick[7];
    wire b_v1 = joystick[8] | cab_sw[4], b_v2 = joystick[9] | cab_sw[5], b_v3 = joystick[10] | cab_sw[6];
    wire b_radio = joystick[11] | cab_sw[7];
    wire b_coin = joystick[12] | cab_sw[8], b_start = joystick[13] | cab_sw[9];
    wire j_test = joystick[14] | cab_sw[10], j_service = joystick[15] | cab_sw[11];
    wire j_volup = joystick[16] | cab_sw[12], j_voldn = joystick[17] | cab_sw[13];
    wire j_nitro = joystick[18] | cab_sw[14];
    wire b_coin2 = cab_sw[15];
    // r25 d-pad shortcuts (left = Test, right = Service, up / down = Volume Up / Down). Main also reports the left stick
    // as d-pad directions, so each fires only while the stick is centred on that axis. The mapped buttons above are
    // real switches and never carry that interlock: the calibration screens need TEST pressed at full lock.
    wire signed [7:0] sx = l_analog[7:0], sy = l_analog[15:8];
    wire x_centred = (sx > -8'sd40) && (sx < 8'sd40), y_centred = (sy > -8'sd40) && (sy < 8'sd40);
    wire dp_test  = !dpad_off && joy_left  && x_centred, dp_service = !dpad_off && joy_right && x_centred;
    wire dp_volup = !dpad_off && joy_up    && y_centred, dp_voldn   = !dpad_off && joy_down  && y_centred;
    wire s_test = j_test | dp_test, s_service = j_service | dp_service;
    wire s_volup = j_volup | dp_volup, s_voldn = j_voldn | dp_voldn;
    wire s_start = b_start | (game == 2'd2 && j_nitro);
    assign test_any = s_test;

    // Shifter: MAME's default "Buttons (sticky)" behaviour with sequential Shift Up / Down; the core starts in 1st.
    // r30: a closed SNAC gear switch selects its gear (lowest wins if several) and has priority over the buttons.
    reg [1:0] gear;              // 0..3 = 1st..4th
    reg       up_q, down_q;
    always @(posedge clk) begin
        if (reset) begin gear <= 2'd0; up_q <= 1'b0; down_q <= 1'b0; end
        else begin
            up_q <= b_up; down_q <= b_down;
            if      (cab_sw[0]) gear <= 2'd0;
            else if (cab_sw[1]) gear <= 2'd1;
            else if (cab_sw[2]) gear <= 2'd2;
            else if (cab_sw[3]) gear <= 2'd3;
            else if (b_up && !up_q && gear != 2'd3) gear <= gear + 2'd1;
            else if (b_down && !down_q && gear != 2'd0) gear <= gear - 2'd1;
        end
    end

    assign dips = (game == 2'd1) ? 16'hf9ec : (game == 2'd2) ? 16'hfffd : 16'hf9fe;
    always @* begin
        in0 = 16'hffff;
        in0[0]  = ~b_coin;
        in0[1]  = ~b_coin2;
        in0[2]  = ~s_start;
        in0[4]  = ~(s_test | osd_enter);
        in0[6]  = ~s_service;
        in0[9]  = ~s_volup;      // IN0 bit 9 VOLUME_UP / bit 8 VOLUME_DOWN also walk the operator menus
        in0[8]  = ~s_voldn;
        in0[13] = ~(gear == 2'd0);
        in0[12] = ~(gear == 2'd1);
        in0[11] = ~(gear == 2'd2);
        in0[10] = ~(gear == 2'd3);
        in1 = (game == 2'd0) ? 16'h007f : 16'hffff;
        in1[1] = ~b_radio;
        in1[4] = ~b_v1;
        in1[5] = ~b_v2;
        in1[6] = ~b_v3;
    end

    // Steering: left stick X, full MAME range 0x10..0xf0 around 0x80 (all three games; the game's own CMOS calibration
    // maps it -- see the release README: calibrate at full lock with a mapped TEST button). r30: or the DE10 ADC CH0
    // pot byte, held to the same MAME field range (PORT_MINMAX(0x10,0xf0), :777).
    function automatic [7:0] clamp_wheel(input signed [9:0] v);
        clamp_wheel = (v < 10'sd16) ? 8'h10 : (v > 10'sd240) ? 8'hf0 : v[7:0];
    endfunction
    wire signed [7:0] lx = l_analog[7:0];
    wire [7:0] wheel_usb = clamp_wheel(10'sd128 + {{2{lx[7]}}, lx});
    wire [7:0] wheel_pot = clamp_wheel({2'b00, pots[7:0]});
    wire       pot_wheel  = (adc_src != 2'd0);
    wire       pot_pedals = adc_src[0];                 // 1 and 3: pedals from CH1 / CH2 as well
    wire [7:0] wheel = pot_wheel ? wheel_pot : wheel_usb;

    // Pedals (r30). MAME's IPT_PEDAL / PEDAL2 are 0x00 released .. 0xff floored. Right-stick axes (signed, -128..127):
    // a half axis v = 0..128 (Y split) maps ped_half, a full axis u = 0..255 (released end = 0) maps ped_full; both
    // have a 8-count dead band at rest (encoder / pot noise must not creep the throttle) and reach 0xff at full travel.
    /* verilator lint_off UNUSEDSIGNAL */
    function automatic [7:0] ped_half(input [7:0] v);                 // 0..128
        reg [11:0] p;
        begin
            p = ({4'd0, v} - 12'd8) * 12'd17;
            ped_half = (v <= 8'd8) ? 8'h00 : (v >= 8'd128) ? 8'hff : p[10:3];
        end
    endfunction
    function automatic [7:0] ped_full(input [7:0] u);                 // 0..255
        reg [16:0] p;
        begin
            p = ({9'd0, u} - 17'd8) * 17'd273;
            ped_full = (u <= 8'd8) ? 8'h00 : (u >= 8'd247) ? 8'hff : p[15:8];
        end
    endfunction
    /* verilator lint_on UNUSEDSIGNAL */
    wire [7:0] rx = r_analog[7:0], ry = r_analog[15:8];
    wire [7:0] ry_up   = ry[7] ? (8'd0 - ry) : 8'd0;     // stick up (negative) = gas, 1..128
    wire [7:0] ry_down = ry[7] ? 8'd0 : ry;              // stick down = brake, 0..127
    wire [7:0] rx_off = {~rx[7], rx[6:0]}, ry_off = {~ry[7], ry[6:0]};   // axis + 128: released at -128 -> 0
    reg  [7:0] a_gas, a_brake;
    always @* begin
        case (pedal_mode)
            2'd1:    begin a_gas = ped_half(ry_up);   a_brake = ped_half(ry_down); end
            2'd2:    begin a_gas = ped_full(rx_off);  a_brake = ped_full(ry_off);  end
            2'd3:    begin a_gas = ped_full(~rx_off); a_brake = ped_full(~ry_off); end
            default: begin a_gas = 8'h00;             a_brake = 8'h00;             end
        endcase
        if (pot_pedals) begin a_gas = pots[15:8]; a_brake = pots[23:16]; end
    end
    wire [7:0] accel = b_gas   ? 8'hff : a_gas;
    wire [7:0] brake = b_brake ? 8'hff : a_brake;
    assign adc = {8'h00, brake, accel, wheel};
endmodule

// ------------------------------------------------------------------------------------------------------------------
// gm1_adc_pots -- wheel / gas / brake pots on the DE10-Nano's LTC2308 (r30). Minimal SPI reader (the framework
// sys/ltc2308.sv protocol with discrete pins, so the emu can release the pins when the option is Off). Datasheet
// LTC2308 (Rev C): CONVST rising starts a conversion (tWHCONV >= 20 ns), tCONV <= 1.6 us, no SCK during conversion,
// CONVST low when it ends; then 12 SCK: SDO B11 first (valid after tCONV), later bits change on SCK falling; SDI
// (the 6-bit DIN S/D O/S S1 S0 UNI SLP) is latched on SCK rising and configures the NEXT conversion; fSCK <= 40 MHz,
// tACQ >= 240 ns. Here: CONVST 2 clk, 90 clk (1.8 us) wait, SCK = clk / 4 (12.5 MHz), one conversion every PERIOD
// clk (20 us, 50 kS/s: 16.7 kS/s per channel). Single-ended unipolar 0..4.096 V (1 mV per code).
// Per channel: first sample loads the filter, then y += (x - y) / 16 (12.4 fixed point, tau ~ 1 ms per channel).
// Byte = min(255, y * 80 / 1024 code): 3.264 V -> 255. Pots on the header's 3.3 V (or a 3.3 V divider) reach full
// scale; the game's CALIBRATE CONTROLS maps each cabinet's real pot travel.
module gm1_adc_pots #(parameter integer PERIOD = 1000) (
    input  wire        clk,
    input  wire        reset,
    output reg         convst,
    output reg         sck,
    output reg         sdi,           // to the LTC2308 SDI pin (config word)
    input  wire        sdo,           // from the LTC2308 SDO pin
    output reg  [23:0] pots           // {CH2, CH1, CH0} bytes
);
    localparam integer T_BITS = 92;   // CONVST at 0-1, first SCK low phase starts at 92 (1.84 us after CONVST rising)
    reg [10:0] t;
    reg [1:0]  cfg_ch;                // channel whose config is sent this transfer (converted next)
    reg [1:0]  conv_ch;               // channel converting now (config sent last transfer)
    reg        conv_ok;               // conv_ch is known (a config was sent since reset)
    reg [11:0] shin;
    reg [15:0] y0, y1, y2;
    reg [2:0]  seen;
    reg        upd; reg [1:0] upd_ch;
    wire [5:0] din = {1'b1, cfg_ch[0], 1'b0, cfg_ch[1], 1'b1, 1'b0};   // S/D=1, O/S, S1, S0, UNI=1, SLP=0
    // bit phase: every 4 clk from T_BITS: clk 0-1 SCK low (SDI set), 2-3 SCK high (rising at 2, SDO sampled at 2)
    wire [10:0] tb = t - T_BITS[10:0];
    wire        in_bits = (t >= T_BITS[10:0]) && (tb < 11'd48);
    wire [3:0]  bitn = tb[5:2];
    /* verilator lint_off UNUSEDSIGNAL */
    function automatic [15:0] iir(input [15:0] y, input [11:0] x, input first);
        reg signed [17:0] d;
        begin
            d = $signed({2'b00, x, 4'b0000}) - $signed({2'b00, y});
            iir = first ? {x, 4'b0000} : y + {{2{d[17]}}, d[17:4]};   // floor((x*16 - y) / 16), sign-extended
        end
    endfunction
    function automatic [7:0] to_byte(input [15:0] y);
        reg [22:0] p;
        begin
            p = y * 23'd80;
            to_byte = (p[22:14] > 9'd255) ? 8'hff : p[21:14];
        end
    endfunction
    /* verilator lint_on UNUSEDSIGNAL */
    always @(posedge clk) begin
        if (reset) begin
            t <= 11'd0; convst <= 1'b0; sck <= 1'b0; sdi <= 1'b0; cfg_ch <= 2'd0; conv_ch <= 2'd0; conv_ok <= 1'b0;
            shin <= 12'd0; y0 <= 16'd0; y1 <= 16'd0; y2 <= 16'd0; seen <= 3'd0; upd <= 1'b0; upd_ch <= 2'd0;
            pots <= 24'd0;
        end else begin
            t <= (t == PERIOD[10:0] - 11'd1) ? 11'd0 : t + 11'd1;
            convst <= (t == PERIOD[10:0] - 11'd1) || (t == 11'd0);
            upd <= 1'b0;
            if (in_bits) begin
                case (tb[1:0])
                    2'd0: begin sck <= 1'b0; sdi <= (bitn < 4'd6) ? din[3'd5 - bitn[2:0]] : 1'b0; end
                    2'd2: begin sck <= 1'b1; shin <= {shin[10:0], sdo}; end
                    default: ;
                endcase
            end else begin
                sck <= 1'b0; sdi <= 1'b0;
            end
            if (t == T_BITS[10:0] + 11'd48) begin          // transfer done: shin = the conversion of conv_ch
                if (conv_ok) begin upd <= 1'b1; upd_ch <= conv_ch; end
                case (conv_ch)
                    2'd0: if (conv_ok) begin y0 <= iir(y0, shin, !seen[0]); seen[0] <= 1'b1; end
                    2'd1: if (conv_ok) begin y1 <= iir(y1, shin, !seen[1]); seen[1] <= 1'b1; end
                    default: if (conv_ok) begin y2 <= iir(y2, shin, !seen[2]); seen[2] <= 1'b1; end
                endcase
                conv_ch <= cfg_ch; conv_ok <= 1'b1;
                cfg_ch  <= (cfg_ch == 2'd2) ? 2'd0 : cfg_ch + 2'd1;
            end
            if (upd) case (upd_ch)
                2'd0:    pots[7:0]   <= to_byte(y0);
                2'd1:    pots[15:8]  <= to_byte(y1);
                default: pots[23:16] <= to_byte(y2);
            endcase
        end
    end
endmodule

// ------------------------------------------------------------------------------------------------------------------
// gm1_snac_165 -- 16 cabinet switches through two chained 74HC165 on the SNAC user port (r30).
// Pins (open-drain user port, released = pulled high): load_n = SH/LD (low loads A..H), sck = CLK (rising shifts),
// qh = QH of the 74HC165 nearest the connector (U1; U2's QH feeds U1's SER). CLK INH tied low on the adapter.
// Every FRAME clocks (1 ms): load_n low HALF, release, wait HALF, sample QH (= U1.H); then 15 x (CLK low HALF, CLK
// high HALF, sample) -- samples are taken HALF (2.5 us) after each release so the pull-up rise (10 k on the MiSTer
// I/O board) has settled. Read order U1.H..U1.A, U2.H..U2.A; switch Dn: D0..D7 = U1.A..U1.H, D8..D15 = U2.A..U2.H.
// Inputs are pulled up on the adapter and closed to ground: 0 = pressed. A switch changes only when two consecutive
// frames agree (1-2 ms debounce). Output: sw[n] = 1 while Dn is closed.
module gm1_snac_165 #(parameter integer FRAME = 50000, parameter integer HALF = 125) (
    input  wire        clk,
    input  wire        reset,
    input  wire        qh,
    output reg         load_n,
    output reg         sck,
    output reg  [15:0] sw
);
    reg [15:0] ft;                    // frame timer
    reg [8:0]  h;                     // half-period timer
    reg [2:0]  st;                    // 0 idle, 1 load low, 2 settle, 3 clk low, 4 clk high
    reg [4:0]  nb;                    // samples taken
    reg [15:0] sr, prev;
    reg [1:0]  qh_s;                  // QH is asynchronous to clk: two-flop synchroniser (sampled 2.5 us after each edge)
    wire [15:0] frame = {sr[7:0], sr[15:8]};          // first sample = U1.H = D7 ... last = U2.A = D8
    always @(posedge clk) begin
        if (reset) begin
            ft <= 16'd0; h <= 9'd0; st <= 3'd0; nb <= 5'd0; sr <= 16'hffff; prev <= 16'hffff;
            load_n <= 1'b1; sck <= 1'b1; sw <= 16'd0; qh_s <= 2'b11;
        end else begin
            qh_s <= {qh_s[0], qh};
            ft <= (ft == FRAME[15:0] - 16'd1) ? 16'd0 : ft + 16'd1;
            if (h != 9'd0) h <= h - 9'd1;
            case (st)
                3'd0: if (ft == 16'd0) begin load_n <= 1'b0; sck <= 1'b1; h <= HALF[8:0] - 9'd1; st <= 3'd1; nb <= 5'd0; end
                3'd1: if (h == 9'd0) begin load_n <= 1'b1; h <= HALF[8:0] - 9'd1; st <= 3'd2; end
                3'd2, 3'd4: if (h == 9'd0) begin
                    sr <= {sr[14:0], qh_s[1]}; nb <= nb + 5'd1;
                    if (nb == 5'd15) st <= 3'd5;
                    else begin sck <= 1'b0; h <= HALF[8:0] - 9'd1; st <= 3'd3; end
                end
                3'd3: if (h == 9'd0) begin sck <= 1'b1; h <= HALF[8:0] - 9'd1; st <= 3'd4; end
                3'd5: begin                                   // frame complete
                    if (frame == prev) sw <= ~frame;
                    prev <= frame; st <= 3'd0;
                end
                default: st <= 3'd0;
            endcase
        end
    end
endmodule

// ------------------------------------------------------------------------------------------------------------------
// gm1_snac_motor -- steering-motor PWM + direction on the SNAC user port (r30), from the game's wheel-motor byte
// (gm1_wheel_motor: MAME midvunit.cpp wheel_board_w WHLCTLZ, the value the gm1_ffb daemon also uses). The byte is the
// game's signed torque, restoring: wheel held left (0x10) -> about +122, right -> about -123 (rumble/torque_sign.py);
// positive = push toward higher wheel input = RIGHT. Outputs are ACTIVE LOW so a released open-drain pin (pulled up)
// is always "motor off": pwm_n low = drive, dir_n low = push right, en_n low = the game is driving the wheel.
// duty = |t| * 2 / 256 (|t| = 128 -> 255/256), PWM = clk / PWM_DIV / 256 (19.5 kHz at 50 MHz, above hearing).
// Watchdog: no motor write for TIMEOUT clocks (500 ms, as the daemon) -> en_n high, PWM off, until the next write.
module gm1_snac_motor #(parameter integer PWM_DIV = 10, parameter integer TIMEOUT = 25_000_000) (
    input  wire       clk,
    input  wire       reset,
    input  wire [7:0] motor,
    input  wire       motor_we,
    output reg        pwm_n,
    output reg        dir_n,
    output reg        en_n
);
    reg  [24:0] wd;
    reg  [7:0]  t;
    reg  [3:0]  pre;
    reg  [7:0]  ph;
    wire [7:0]  mag  = t[7] ? (8'd0 - t) : t;             // 0..128
    wire [7:0]  duty = mag[7] ? 8'hff : {mag[6:0], 1'b0};
    wire        alive = (wd != 25'd0);
    always @(posedge clk) begin
        if (reset) begin
            wd <= 25'd0; t <= 8'd0; pre <= 4'd0; ph <= 8'd0; pwm_n <= 1'b1; dir_n <= 1'b1; en_n <= 1'b1;
        end else begin
            if (motor_we) begin t <= motor; wd <= TIMEOUT[24:0]; end
            else if (alive) wd <= wd - 25'd1;
            if (pre == PWM_DIV[3:0] - 4'd1) begin pre <= 4'd0; ph <= ph + 8'd1; end
            else pre <= pre + 4'd1;
            pwm_n <= !(alive && (ph < duty));
            dir_n <= !(alive && !t[7] && (t != 8'd0));
            en_n  <= !alive;
        end
    end
endmodule
