# gm1.sdc -- Cruis'n USA master core (gm1). The framework sys/sys_top.sdc owns the board clocks, derive_pll_clocks
# and the cross-framework clock groups. Everything in the core runs on the one 50 MHz core clock with data enables
# (the shipped platform/mister/CruisinUSA.sdc adds no core exception). This file adds exactly two proven sets:
#   1. the board-SDRAM pin constraints of bandwidth/bw1/quartus/bw1.sdc (cabinet-proven, builds 2-4), unchanged:
#      general[0] = outclk_0 = 50 MHz core clock; general[1] = outclk_1 = 50 MHz, -3515 ps, forwarded to SDRAM_CLK;
#   2. the fabric DCS MSTAT bank-select exception. r21 (2026-09-24): the DCS core enable is now every clock
#      (rtl/dcs_fabric/cusa_dcs2k_packed.sv header: the 1-in-2 enable was below the ADSP throughput floor and caused
#      the Cruis'n USA "electric shock" buzz), so the old dcs1.sdc setup-2/hold-1 CE multicycle is REMOVED (it would be
#      an optimistic false exception) and the bank-select exception is rescaled from 6/5 to 3/2 clocks.
# Names carrying [N] are never double-quoted (Tcl substitution), and no constraint uses get_clocks on a PLL output:
# this file is read before sys_top.sdc derives the PLL clocks (memory mister-sdc-read-order-pll-clocks).

# ---- 1. board SDRAM (bw1.sdc) ----
create_generated_clock -name SDRAM_CLK \
  -source [get_pins -compatibility_mode {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}] \
  [get_ports {SDRAM_CLK}]
set_input_delay -clock SDRAM_CLK -max 6.0 [get_ports {SDRAM_DQ[*]}]
set_input_delay -clock SDRAM_CLK -min 2.5 [get_ports {SDRAM_DQ[*]}]
set_output_delay -clock SDRAM_CLK -max 1.5  [get_ports {SDRAM_A[*] SDRAM_BA[*] SDRAM_DQ[*] SDRAM_DQML SDRAM_DQMH SDRAM_CKE SDRAM_nCS SDRAM_nRAS SDRAM_nCAS SDRAM_nWE}]
set_output_delay -clock SDRAM_CLK -min -0.8 [get_ports {SDRAM_A[*] SDRAM_BA[*] SDRAM_DQ[*] SDRAM_DQML SDRAM_DQMH SDRAM_CKE SDRAM_nCS SDRAM_nRAS SDRAM_nCAS SDRAM_nWE}]
# Read capture: SDRAM_CLK is phase-advanced, so data launched by an SDRAM_CLK edge is captured one core-clock period
# after the nearest following edge: setup multicycle 2, applied by node (gm1_sdram.sv keeps bw1's register name).
set_multicycle_path -setup -end -from [get_ports {SDRAM_DQ[*]}] -to [get_registers {*|SDRAM_DQ_in_q[*]}] 2

# ---- 2. fabric DCS (r21: full-rate enable, no CE multicycle) ----
# MSTAT bit 0 selects the active G0 bank. The core changes MSTAT only while retiring S_EXEC and forbids an instruction
# from both changing the bank bit and touching a banked register on the same retirement; the earliest dependent G0
# write is the next instruction's S_EXEC after FETCH and DECODE = three DCS enables (donor tunit.sdc:521-527), which
# at the r21 every-clock enable is three 50 MHz clocks (was six under the 1-in-2 enable).
set dcs_bank_select_regs [get_registers -nowarn {*adsp2105_packed:cpu|mstat[0]*}]
set dcs_g0_regs [get_registers -nowarn {*adsp2105_packed:cpu|gr[*]}]
if {[get_collection_size $dcs_bank_select_regs] == 0 || [get_collection_size $dcs_g0_regs] == 0} {
  post_message -type error "gm1: DCS bank-select timing collection is empty"
} else {
  post_message -type info "gm1: DCS bank-select multicycle 3/2 covers [get_collection_size $dcs_bank_select_regs] -> [get_collection_size $dcs_g0_regs] registers (r21 full-rate enable)"
  set_multicycle_path -setup 3 -from $dcs_bank_select_regs -to $dcs_g0_regs
  set_multicycle_path -hold  2 -from $dcs_bank_select_regs -to $dcs_g0_regs
}
