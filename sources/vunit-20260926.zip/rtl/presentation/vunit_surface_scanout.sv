// SPDX-License-Identifier: BSD-3-Clause
// Fixed-raster RGB32 presentation with two complete, tagged line banks.
// Reset requires parent-side external drain; halt preserves offers and debt.
module vunit_surface_scanout #(
    parameter integer WIDTH=512,HEIGHT=400,H_TOTAL=666,V_TOTAL=432,
    parameter integer H_SYNC_START=526,H_SYNC_END=551,V_SYNC_START=401,V_SYNC_END=404,
    // FIFO_BEATS is source-compatible; storage is now two complete lines.
    parameter integer PIXEL_DIVIDER=6,FIFO_BEATS=32,BURST_BEATS=4
) (
    input wire clk,reset,configured,halt_reads,
    input wire back_ready,back_surface,
    input wire [31:0] back_base,back_epoch,back_frame_sequence,
    input wire [63:0] back_first_tick,back_last_tick,
    input wire back_mixed_page,back_mixed_palette,
    output wire swap_event,scan_idle,
    output reg front_valid,front_surface,
    output reg [31:0] front_epoch,front_frame_sequence,
    output reg [63:0] front_first_tick,front_last_tick,
    output reg front_mixed_page,front_mixed_palette,
    output wire scan_read,
    output wire [31:0] scan_address,
    output wire [7:0] scan_byteenable,
    output wire [3:0] scan_burstcount,
    input wire scan_waitrequest,scan_readdatavalid,
    input wire [63:0] scan_readdata,
    input wire scan_read_error,
    output reg [7:0] scan_fault,
    output reg video_ce,video_de,video_hsync,video_vsync,
    output reg [7:0] video_r,video_g,video_b,
    output reg [9:0] video_x,
    output reg [8:0] video_y,
    output reg video_underflow,
    output reg [63:0] underrun_pixels,repeated_frames,physical_frames,
    output reg [31:0] presented_frames
);
    localparam integer LINE_BEATS=WIDTH/2;
    localparam integer BEAT_W=LINE_BEATS<2 ? 1 : $clog2(LINE_BEATS);
    localparam integer COUNT_W=$clog2(LINE_BEATS+1);
    localparam integer DIV_W=PIXEL_DIVIDER<2 ? 1 : $clog2(PIXEL_DIVIDER);
    reg [DIV_W-1:0] divider_phase;
    reg [9:0] raster_x;
    reg [8:0] raster_y;
    wire pixel_due=divider_phase==PIXEL_DIVIDER-1;
    wire active_pixel=raster_x<WIDTH && raster_y<HEIGHT;
    wire blank_entry=pixel_due && raster_x==0 && raster_y==HEIGHT;
    reg [31:0] front_base,stream_generation;

    (* ramstyle="M10K,no_rw_check" *) reg [63:0] line0[0:LINE_BEATS-1];
    (* ramstyle="M10K,no_rw_check" *) reg [63:0] line1[0:LINE_BEATS-1];
    reg [1:0] bank_owned,bank_complete;
    reg [8:0] bank_line0,bank_line1;
    reg [31:0] bank_generation0,bank_generation1;
    reg fill_active,fill_bank;
    reg [8:0] fill_line;
    reg [COUNT_W-1:0] fill_count;
    reg [9:0] next_line;
    // Horizontal blank makes the previous line reusable. Vertical blank starts
    // line zero; blank_entry invalidates all banks and advances the generation.
    wire [9:0] needed_line=raster_y>=HEIGHT ? 10'd0 :
        (raster_x>=WIDTH ? {1'b0,raster_y}+10'd1 : {1'b0,raster_y});
    wire [9:0] issue_line=next_line<needed_line ? needed_line : next_line;
    wire issue_bank=issue_line[0];
    wire issue_bank_free=issue_bank ?
        (!bank_owned[1] || bank_generation1!=stream_generation || {1'b0,bank_line1}<needed_line) :
        (!bank_owned[0] || bank_generation0!=stream_generation || {1'b0,bank_line0}<needed_line);
    wire [COUNT_W:0] remaining_line=LINE_BEATS-fill_count;
    wire [3:0] new_burstcount=remaining_line<BURST_BEATS ? remaining_line : BURST_BEATS;

    reg command_valid,command_bank;
    reg [31:0] command_address,command_generation;
    reg [8:0] command_line;
    reg [BEAT_W-1:0] command_offset;
    reg [3:0] command_count;
    reg [3:0] responses_left;
    reg pending_bank;
    reg [31:0] pending_generation;
    reg [8:0] pending_line;
    reg [BEAT_W-1:0] pending_offset;
    wire read_pending=responses_left!=0;
    wire offered_read=!reset && configured && command_valid;
    wire command_accept=offered_read && !scan_waitrequest;
    wire response_expected=read_pending || command_accept;
    wire unexpected_response=configured && scan_readdatavalid && !response_expected;
    wire error_response=configured && scan_readdatavalid && scan_read_error;
    wire protocol_error=unexpected_response || error_response;
    // Parent capture faults assert halt_reads before their sticky fault edge.
    // Stop both RAM/pixel publication immediately; offered commands and response
    // debt below still drain unchanged, including every beat of an active burst.
    wire publication_safe=configured && !halt_reads && scan_fault==0 && !protocol_error;
    assign scan_read=offered_read;
    assign scan_address=command_address;
    assign scan_byteenable=8'hff;
    assign scan_burstcount=command_count;
    assign scan_idle=!command_valid && !read_pending;
    assign swap_event=!reset && configured && !halt_reads && blank_entry && back_ready &&
                      scan_idle && scan_fault==0 && !protocol_error;
    wire response_bank=read_pending ? pending_bank : command_bank;
    wire [31:0] response_generation=read_pending ? pending_generation : command_generation;
    wire [8:0] response_line=read_pending ? pending_line : command_line;
    wire [BEAT_W-1:0] response_offset=read_pending ? pending_offset : command_offset;
    // An offer reserves every consecutive slot in one bank before acceptance.
    // Old/late responses drain but cannot complete or overwrite a live line.
    wire store_response=publication_safe && scan_readdatavalid && response_expected && !blank_entry &&
        fill_active && response_generation==stream_generation && response_bank==fill_bank &&
        response_line==fill_line && {1'b0,response_line}>=needed_line &&
        response_offset==fill_count && fill_count<LINE_BEATS;

    // Read the coordinate that the next fabric edge can publish, including
    // divider=1. Registered validity excludes same-edge read/write collisions:
    // a bank completed on this edge only becomes readable on a later edge.
    wire [9:0] read_x=pixel_due ? (raster_x==H_TOTAL-1 ? 10'd0 : raster_x+10'd1) : raster_x;
    wire [8:0] read_y=(pixel_due && raster_x==H_TOTAL-1) ?
        (raster_y==V_TOTAL-1 ? 9'd0 : raster_y+9'd1) : raster_y;
    wire [BEAT_W-1:0] read_offset=read_x<WIDTH ? (read_x>>1) : 0;
    reg [63:0] line_q0,line_q1;
    reg [1:0] line_q_valid;
    reg [8:0] line_q_y;
    reg [BEAT_W-1:0] line_q_offset;
    reg [31:0] line_q_generation;
    always @(posedge clk) begin
        line_q0<=line0[read_offset];
        line_q1<=line1[read_offset];
        if(store_response && !reset) begin
            if(response_bank) line1[response_offset]<=scan_readdata;
            else line0[response_offset]<=scan_readdata;
        end
    end
    wire [63:0] selected_beat=raster_y[0] ? line_q1 : line_q0;
    wire [31:0] selected_pixel=raster_x[0] ? selected_beat[63:32] : selected_beat[31:0];
    wire pixel_available=front_valid && publication_safe && line_q_valid[raster_y[0]] &&
        line_q_generation==stream_generation && line_q_y==raster_y && line_q_offset==(raster_x>>1);

    always @(posedge clk) begin
        if(reset) begin
            divider_phase<=0;raster_x<=0;raster_y<=HEIGHT;
            video_ce<=0;video_de<=0;video_hsync<=1;video_vsync<=1;
            video_r<=0;video_g<=0;video_b<=0;video_x<=0;video_y<=HEIGHT;video_underflow<=0;
            underrun_pixels<=0;repeated_frames<=0;physical_frames<=0;presented_frames<=0;
            front_valid<=0;front_surface<=0;front_base<=0;front_epoch<=0;front_frame_sequence<=0;
            front_first_tick<=0;front_last_tick<=0;front_mixed_page<=0;front_mixed_palette<=0;
            stream_generation<=0;next_line<=0;bank_owned<=0;bank_complete<=0;
            bank_line0<=0;bank_line1<=0;bank_generation0<=0;bank_generation1<=0;
            fill_active<=0;fill_bank<=0;fill_line<=0;fill_count<=0;
            command_valid<=0;command_bank<=0;command_address<=0;command_generation<=0;
            command_line<=0;command_offset<=0;command_count<=0;responses_left<=0;
            pending_bank<=0;pending_generation<=0;pending_line<=0;pending_offset<=0;
            line_q_valid<=0;line_q_y<=0;line_q_offset<=0;line_q_generation<=0;scan_fault<=0;
        end else begin
            line_q_y<=read_y;line_q_offset<=read_offset;line_q_generation<=stream_generation;
            line_q_valid[0]<=bank_complete[0] && bank_generation0==stream_generation && bank_line0==read_y;
            line_q_valid[1]<=bank_complete[1] && bank_generation1==stream_generation && bank_line1==read_y;
            // Raster and sync never wait for memory, halt, configuration or guest.
            video_ce<=pixel_due;video_underflow<=0;
            if(pixel_due) begin
                divider_phase<=0;video_x<=raster_x;video_y<=raster_y;video_de<=active_pixel;
                video_hsync<=!(raster_x>=H_SYNC_START && raster_x<H_SYNC_END);
                video_vsync<=!(raster_y>=V_SYNC_START && raster_y<V_SYNC_END);
                video_r<=0;video_g<=0;video_b<=0;
                if(active_pixel) begin
                    if(pixel_available) begin
                        video_r<=selected_pixel[23:16];video_g<=selected_pixel[15:8];video_b<=selected_pixel[7:0];
                    end else begin video_underflow<=1;underrun_pixels<=underrun_pixels+1'b1;end
                end
                if(raster_x==H_TOTAL-1) begin
                    raster_x<=0;
                    if(raster_y==V_TOTAL-1) begin raster_y<=0;physical_frames<=physical_frames+1'b1;end
                    else raster_y<=raster_y+1'b1;
                end else raster_x<=raster_x+1'b1;
            end else divider_phase<=divider_phase+1'b1;

            if(blank_entry) begin
                stream_generation<=stream_generation+1'b1;next_line<=0;
                bank_owned<=0;bank_complete<=0;fill_active<=0;fill_count<=0;line_q_valid<=0;
                if(swap_event) begin
                    presented_frames<=presented_frames+1'b1;
                    front_valid<=1;front_surface<=back_surface;front_base<=back_base;
                    front_epoch<=back_epoch;front_frame_sequence<=back_frame_sequence;
                    front_first_tick<=back_first_tick;front_last_tick<=back_last_tick;
                    front_mixed_page<=back_mixed_page;front_mixed_palette<=back_mixed_palette;
                end else if(front_valid) repeated_frames<=repeated_frames+1'b1;
            end else begin
                if(store_response) begin
                    fill_count<=fill_count+1'b1;
                    if(fill_count==LINE_BEATS-1) begin
                        bank_complete[response_bank]<=1'b1;fill_active<=0;
                    end
                end
                // Expired partial lines can be abandoned only after all burst
                // responses drain. Catch up to the live raster, never replay it.
                if(scan_idle && fill_active && {1'b0,fill_line}<needed_line) begin
                    fill_active<=0;bank_owned[fill_bank]<=0;bank_complete[fill_bank]<=0;fill_count<=0;
                end
                if(publication_safe && front_valid && !halt_reads && scan_idle) begin
                    if(!fill_active && issue_line<HEIGHT && issue_bank_free) begin
                        fill_active<=1;fill_bank<=issue_bank;fill_line<=issue_line[8:0];fill_count<=0;
                        next_line<=issue_line+1'b1;bank_owned[issue_bank]<=1'b1;bank_complete[issue_bank]<=1'b0;
                        if(issue_bank) begin bank_line1<=issue_line[8:0];bank_generation1<=stream_generation;end
                        else begin bank_line0<=issue_line[8:0];bank_generation0<=stream_generation;end
                    end else if(fill_active && {1'b0,fill_line}>=needed_line && fill_count<LINE_BEATS) begin
                        command_valid<=1;command_address<=front_base+fill_line*(WIDTH*4)+(fill_count<<3);
                        command_bank<=fill_bank;command_line<=fill_line;command_generation<=stream_generation;
                        command_offset<=fill_count;command_count<=new_burstcount;
                    end
                end
            end
            // Transport accounting continues through late generations and faults.
            if(scan_readdatavalid && read_pending) begin
                responses_left<=responses_left-1'b1;pending_offset<=pending_offset+1'b1;
            end
            if(command_accept) begin
                command_valid<=0;pending_bank<=command_bank;pending_line<=command_line;
                pending_generation<=command_generation;
                responses_left<=command_count-(scan_readdatavalid ? 4'd1 : 4'd0);
                pending_offset<=command_offset+(scan_readdatavalid ? 1'b1 : 1'b0);
            end
            if(protocol_error && scan_fault==0) scan_fault<=unexpected_response ? 1 : 2;
        end
    end
`ifndef SYNTHESIS
    initial begin
        if(WIDTH<2 || WIDTH>512 || WIDTH%2 || HEIGHT<1 || HEIGHT>511 ||
           H_TOTAL<=WIDTH || H_TOTAL>1024 || V_TOTAL<=HEIGHT || V_TOTAL>512 ||
           H_SYNC_START<WIDTH || H_SYNC_END<=H_SYNC_START || H_SYNC_END>H_TOTAL ||
           V_SYNC_START<HEIGHT || V_SYNC_END<=V_SYNC_START || V_SYNC_END>V_TOTAL ||
           PIXEL_DIVIDER<1 || FIFO_BEATS<1 || BURST_BEATS<1 || BURST_BEATS>8)
            $fatal(1,"Unsupported physical scanout geometry, divider, or burst size");
    end
`endif
endmodule
