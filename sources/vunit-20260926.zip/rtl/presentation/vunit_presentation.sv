`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// Two external RGB32 surfaces; this module captures complete source frames.
// Physical scanout is independent of guest advancement. See README.md for the
// ordered shared-memory/fence and reset-quiescence requirements.
module vunit_presentation #(
    parameter integer WIDTH=512,HEIGHT=400,H_TOTAL=666,V_TOTAL=432,
    parameter integer H_SYNC_START=526,H_SYNC_END=551,V_SYNC_START=401,V_SYNC_END=404,
    parameter integer PIXEL_DIVIDER=6,FIFO_BEATS=32,
    parameter integer REGISTERED_CAPTURE_RESPONSE=0
) (
    input wire clk,reset,
    input wire config_valid,
    output wire config_ready,
    input wire [31:0] config_surface0_base,config_surface1_base,config_surface_bytes,config_epoch,
    input wire backend_quiesced,
    output wire backend_reset_request,
    output reg configured,
    output wire [31:0] required_surface_bytes,
    // Intentional CRT stream discontinuity. Drain accepted/held capture work,
    // discard the unpublished back surface, then hunt a new x0/y0 sample.
    input wire source_restart,
    input wire rgb_valid,
    output wire rgb_ready,
    input wire [23:0] rgb_data,
    input wire [9:0] rgb_x,
    input wire [8:0] rgb_y,
    input wire rgb_de,rgb_hsync,rgb_vsync,rgb_csync,rgb_page,rgb_frame_end,
    input wire [31:0] rgb_palette_epoch,rgb_frame_sequence,
    input wire [63:0] rgb_tick,
    output wire cap_read,cap_write,
    output wire [31:0] cap_address,
    output wire [63:0] cap_writedata,
    output wire [7:0] cap_byteenable,
    output wire [3:0] cap_burstcount,
    input wire cap_waitrequest,cap_readdatavalid,
    input wire [63:0] cap_readdata,
    input wire cap_read_error,
    output wire scan_read,
    output wire [31:0] scan_address,
    output wire [7:0] scan_byteenable,
    output wire [3:0] scan_burstcount,
    input wire scan_waitrequest,scan_readdatavalid,
    input wire [63:0] scan_readdata,
    input wire scan_read_error,
    output wire video_ce,video_de,video_hsync,video_vsync,video_underflow,underrun_sticky,
    output wire [7:0] video_r,video_g,video_b,
    output wire [9:0] video_x,
    output wire [8:0] video_y,
    output wire front_valid,front_surface,
    output wire [31:0] front_epoch,front_frame_sequence,
    output wire [63:0] front_first_tick,front_last_tick,
    output wire front_mixed_page,front_mixed_palette,
    output wire [63:0] underrun_pixels,repeated_frames,physical_frames,
    output wire [31:0] presented_frames,
    output reg [63:0] capture_frames,capture_writes,discarded_frames,alignment_records,source_restarts,
    output reg aligning,back_ready,back_surface,
    output wire scan_idle,
    output wire [7:0] fault_code,
    output wire halted
);
    localparam integer FRAME_PIXELS=WIDTH*HEIGHT;
    localparam [31:0] FRAME_BYTES=FRAME_PIXELS*4;
    localparam [1:0] COLLECT=0,WRITE_WORD=1,FENCE_COMMAND=2,FENCE_WAIT=3;
    reg [1:0] cap_state;
    reg [7:0] capture_fault;
    wire [7:0] scan_fault;
    reg [31:0] base0,base1,epoch;
    wire [31:0] back_base=back_surface ? base1 : base0;
    reg [9:0] expected_x;
    reg [8:0] expected_y;
    reg [31:0] active_pixels,partial_pixel,last_word_address;
    reg [63:0] last_word;
    reg partial_valid,frame_started,abort_pending,continuation_expected,underrun_seen;
    reg first_page;
    reg [31:0] first_palette,back_frame_sequence;
    reg [63:0] back_first_tick,back_last_tick;
    reg back_mixed_page,back_mixed_palette;
    wire [32:0] end0={1'b0,config_surface0_base}+{1'b0,config_surface_bytes};
    wire [32:0] end1={1'b0,config_surface1_base}+{1'b0,config_surface_bytes};
    wire valid_config=config_surface0_base[2:0]==0 && config_surface1_base[2:0]==0 &&
        config_surface_bytes[2:0]==0 && config_surface_bytes>=FRAME_BYTES &&
        end0<=33'h100000000 && end1<=33'h100000000 &&
        (end0<={1'b0,config_surface1_base} || end1<={1'b0,config_surface0_base});
    wire base_healthy=configured && !reset && capture_fault==0 && scan_fault==0;
    // These command states own a request chosen on a previous clock edge.
    // Once offered, commands drain through faults; new work/publication stops.
    wire command_enabled=configured && !reset;
    wire offered_fence=command_enabled && cap_state==FENCE_COMMAND;
    // The active shared mux registers every capture reply: client acceptance
    // and reply publication cannot coincide. In that explicit profile, the
    // reply must own FENCE_WAIT, so new-command readiness is irrelevant to its
    // validation. Default preserves a directly connected zero-latency backend.
    wire response_expected=cap_state==FENCE_WAIT ||
        (!REGISTERED_CAPTURE_RESPONSE && offered_fence && !cap_waitrequest);
    wire unexpected_response=cap_readdatavalid && !response_expected;
    wire live_capture_error=base_healthy &&
        (unexpected_response || (cap_readdatavalid && cap_read_error));
    assign fault_code=capture_fault!=0 ? capture_fault : scan_fault!=0 ? {4'h8,scan_fault[3:0]} : 0;
    assign halted=fault_code!=0 || live_capture_error;
    assign underrun_sticky=underrun_seen || video_underflow;
    assign required_surface_bytes=FRAME_BYTES;
    assign backend_reset_request=reset || !configured || halted;
    assign config_ready=!reset && !configured && fault_code==0 && backend_quiesced &&
                        !cap_readdatavalid && !scan_readdatavalid;
    assign rgb_ready=base_healthy && !live_capture_error && !source_restart && !abort_pending &&
                     !back_ready && cap_state==COLLECT;
    assign cap_write=command_enabled && cap_state==WRITE_WORD;
    // Request intent cannot depend on the response or waitrequest it elicits.
    assign cap_read=offered_fence;
    assign cap_address=last_word_address;
    assign cap_writedata=last_word;
    assign cap_byteenable=8'hff;
    assign cap_burstcount=1;
    wire rgb_accepted=rgb_valid && rgb_ready;
    wire capture_write_accepted=cap_write && !cap_waitrequest;
    wire fence_accepted=cap_read && !cap_waitrequest;
    wire abort_now=abort_pending || source_restart;
    wire expected_de=expected_x<WIDTH && expected_y<HEIGHT;
    wire expected_end=expected_x==H_TOTAL-1 && expected_y==V_TOTAL-1;
    wire swap_event;

    task clear_frame;
        begin
            expected_x<=0;expected_y<=0;active_pixels<=0;
            partial_valid<=0;partial_pixel<=0;frame_started<=0;
        end
    endtask
    task finish_abort;
        begin
            cap_state<=COLLECT;abort_pending<=0;aligning<=1;back_ready<=0;
            continuation_expected<=0;
            clear_frame();
        end
    endtask
    always @(posedge clk) begin
        if(reset) underrun_seen<=0;
        else if(video_underflow) underrun_seen<=1;
    end
    always @(posedge clk) begin
        if(reset) begin
            configured<=0;capture_fault<=0;base0<=0;base1<=0;epoch<=0;
            cap_state<=COLLECT;back_surface<=0;back_ready<=0;aligning<=1;abort_pending<=0;
            expected_x<=0;expected_y<=0;active_pixels<=0;partial_valid<=0;partial_pixel<=0;
            last_word<=0;last_word_address<=0;frame_started<=0;continuation_expected<=0;
            first_page<=0;first_palette<=0;
            back_frame_sequence<=0;back_first_tick<=0;back_last_tick<=0;
            back_mixed_page<=0;back_mixed_palette<=0;
            capture_frames<=0;capture_writes<=0;discarded_frames<=0;alignment_records<=0;source_restarts<=0;
        end else if(config_valid && config_ready) begin
            if(!valid_config) capture_fault<=1;
            else begin
                configured<=1;base0<=config_surface0_base;base1<=config_surface1_base;epoch<=config_epoch;
            end
        end else if(configured) begin
            if(!base_healthy || live_capture_error) begin
                if(base_healthy) capture_fault<=unexpected_response ? 4 : 5;
                // Faults cannot revoke a request already presented to Avalon.
                // Count its actual write acceptance, or drain its read credit,
                // without publishing a completed frame or selecting more work.
                if(capture_write_accepted) begin
                    capture_writes<=capture_writes+1;
                    cap_state<=COLLECT;
                end else if(cap_readdatavalid && response_expected) cap_state<=COLLECT;
                else if(fence_accepted) cap_state<=FENCE_WAIT;
            end else begin
                if(swap_event) begin back_surface<=!back_surface;back_ready<=0;end
                if(source_restart) begin
                    source_restarts<=source_restarts+1;
                    if(frame_started || back_ready || cap_state!=COLLECT) discarded_frames<=discarded_frames+1;
                    back_ready<=0;aligning<=1;abort_pending<=1;
                end
                if(cap_state==COLLECT && abort_now) finish_abort();
                else if(capture_write_accepted) begin
                    capture_writes<=capture_writes+1;
                    if(abort_now) finish_abort();
                    else cap_state<=COLLECT;
                end else if(cap_readdatavalid && response_expected) begin
                    if(abort_now) finish_abort();
                    else if(cap_readdata!==last_word) capture_fault<=6;
                    else begin
                        // Complete full frame AND readback of its final beat.
                        // Shared ordered-port service must cover preceding writes.
                        back_ready<=1;capture_frames<=capture_frames+1;cap_state<=COLLECT;
                        continuation_expected<=1;
                        clear_frame();
                    end
                end else if(fence_accepted) cap_state<=FENCE_WAIT;
                else if(rgb_accepted) begin
                    if(aligning && (rgb_x!=0 || rgb_y!=0)) begin
                        alignment_records<=alignment_records+1;
                        if(rgb_frame_end) discarded_frames<=discarded_frames+1;
                    end else if(rgb_x!=expected_x || rgb_y!=expected_y || rgb_de!=expected_de ||
                                rgb_frame_end!=expected_end) capture_fault<=2;
                    else if((frame_started && (rgb_frame_sequence!=back_frame_sequence || rgb_tick<=back_last_tick)) ||
                            (!frame_started && continuation_expected &&
                             (rgb_frame_sequence!=back_frame_sequence+32'd1 || rgb_tick<=back_last_tick)))
                        capture_fault<=3;
                    else begin
                        aligning<=0;
                        if(!frame_started) begin
                            frame_started<=1;back_frame_sequence<=rgb_frame_sequence;
                            back_first_tick<=rgb_tick;first_page<=rgb_page;first_palette<=rgb_palette_epoch;
                            back_mixed_page<=0;back_mixed_palette<=0;
                        end else begin
                            if(rgb_page!=first_page) back_mixed_page<=1;
                            if(rgb_palette_epoch!=first_palette) back_mixed_palette<=1;
                        end
                        back_last_tick<=rgb_tick;
                        if(rgb_de) begin
                            active_pixels<=active_pixels+1;
                            if(!partial_valid) begin partial_pixel<={8'b0,rgb_data};partial_valid<=1;end
                            else begin
                                last_word<={8'b0,rgb_data,partial_pixel};
                                last_word_address<=back_base+((active_pixels>>1)<<3);
                                partial_valid<=0;cap_state<=WRITE_WORD;
                            end
                        end
                        if(expected_x==H_TOTAL-1) begin expected_x<=0;expected_y<=expected_y+1'b1;end
                        else expected_x<=expected_x+1'b1;
                        if(rgb_frame_end) begin
                            if(active_pixels!=FRAME_PIXELS || partial_valid) capture_fault<=2;
                            else cap_state<=FENCE_COMMAND;
                        end
                    end
                end
            end
        end
    end

    vunit_surface_scanout #(.WIDTH(WIDTH),.HEIGHT(HEIGHT),.H_TOTAL(H_TOTAL),.V_TOTAL(V_TOTAL),
        .H_SYNC_START(H_SYNC_START),.H_SYNC_END(H_SYNC_END),.V_SYNC_START(V_SYNC_START),.V_SYNC_END(V_SYNC_END),
        .PIXEL_DIVIDER(PIXEL_DIVIDER),.FIFO_BEATS(FIFO_BEATS)) scanout (
        .clk(clk),.reset(reset),.configured(configured),.halt_reads(halted),
        .back_ready(back_ready && !source_restart && !abort_pending && !halted),.back_surface(back_surface),
        .back_base(back_base),.back_epoch(epoch),.back_frame_sequence(back_frame_sequence),
        .back_first_tick(back_first_tick),.back_last_tick(back_last_tick),
        .back_mixed_page(back_mixed_page),.back_mixed_palette(back_mixed_palette),
        .swap_event(swap_event),.scan_idle(scan_idle),.front_valid(front_valid),.front_surface(front_surface),
        .front_epoch(front_epoch),.front_frame_sequence(front_frame_sequence),
        .front_first_tick(front_first_tick),.front_last_tick(front_last_tick),
        .front_mixed_page(front_mixed_page),.front_mixed_palette(front_mixed_palette),
        .scan_read(scan_read),.scan_address(scan_address),.scan_byteenable(scan_byteenable),
        .scan_burstcount(scan_burstcount),.scan_waitrequest(scan_waitrequest),
        .scan_readdatavalid(scan_readdatavalid),.scan_readdata(scan_readdata),.scan_read_error(scan_read_error),
        .scan_fault(scan_fault),.video_ce(video_ce),.video_de(video_de),.video_hsync(video_hsync),.video_vsync(video_vsync),
        .video_underflow(video_underflow),.video_r(video_r),.video_g(video_g),.video_b(video_b),
        .video_x(video_x),.video_y(video_y),.underrun_pixels(underrun_pixels),
        .repeated_frames(repeated_frames),.physical_frames(physical_frames),.presented_frames(presented_frames)
    );
`ifndef SYNTHESIS
    initial begin
        if(WIDTH<2 || WIDTH>512 || WIDTH%2 || HEIGHT<1 || HEIGHT>511 ||
           H_TOTAL<=WIDTH || H_TOTAL>1024 || V_TOTAL<=HEIGHT || V_TOTAL>512 ||
           H_SYNC_START<WIDTH || H_SYNC_END<=H_SYNC_START || H_SYNC_END>H_TOTAL ||
           V_SYNC_START<HEIGHT || V_SYNC_END<=V_SYNC_START || V_SYNC_END>V_TOTAL ||
           PIXEL_DIVIDER<1 || FIFO_BEATS<1)
            $fatal(1,"Unsupported presentation geometry");
    end
`endif
endmodule
`default_nettype wire
