// SPDX-License-Identifier: GPL-2.0-or-later
// gm1_tl084_lpf -- the V-unit DCS audio output stage: AD1851 DAC -> TL084 op-amp filter -> TDA2030 amps
// (midvunit.cpp:1296-1325 board notes). Modelled as a 2-pole Butterworth low-pass (unity-gain Sallen-Key, the usual
// TL084 reconstruction topology). ASSUMPTION: the board's R/C values are not documented anywhere found (MAME has no
// filter); cutoff 10 kHz by default -- regenerate the coefficients with bandwidth/gm1/audio/tl084_lpf_golden.py coeffs FC.
//
// One sample per in_ce (the DCS 31.25 kHz DAC strobe, >= 1600 clocks apart); Direct Form I, fixed point:
//   acc = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2 (coefficients Q2.16, 18-bit signed; exact 40-bit accumulator)
//   y   = saturate16((acc + 2^15) >>> 16)
// ONE shared 18x18 multiplier, five sequential products (7 clocks per sample) -- no timing or DSP pressure. out holds the
// filtered sample and out_ce pulses when it updates. The golden (independent) is tl084_lpf_golden.py.
`default_nettype none
module gm1_tl084_lpf #(
    parameter signed [17:0] B0 = 18'sd28491,   // FC = 10 kHz @ 31250 Hz (tl084_lpf_golden.py coeffs 10000)
    parameter signed [17:0] B1 = 18'sd56982,
    parameter signed [17:0] B2 = 18'sd28491,
    parameter signed [17:0] A1 = 18'sd34033,
    parameter signed [17:0] A2 = 18'sd14395
) (
    input  wire               clk,
    input  wire               reset,
    input  wire               bypass,        // 1 = pass the DAC sample through unfiltered
    input  wire               in_ce,
    input  wire signed [15:0] in_sample,
    output reg                out_ce,
    output reg  signed [15:0] out_sample
);
    reg signed [15:0] x0, x1, x2, y1, y2;
    reg signed [39:0] acc;
    reg        [2:0]  step;          // 0 idle, 1..5 products, 6 round/saturate/commit
    reg signed [17:0] m_a;           // coefficient operand
    reg signed [15:0] m_b;           // sample operand
    wire signed [33:0] prod = m_a * m_b;
    always @* begin
        case (step)
            3'd1: begin m_a = B0;  m_b = x0; end
            3'd2: begin m_a = B1;  m_b = x1; end
            3'd3: begin m_a = B2;  m_b = x2; end
            3'd4: begin m_a = -A1; m_b = y1; end
            3'd5: begin m_a = -A2; m_b = y2; end
            default: begin m_a = 18'sd0; m_b = 16'sd0; end
        endcase
    end
    wire signed [39:0] rounded = acc + 40'sd32768;
    wire signed [23:0] shifted = rounded[39:16];          // arithmetic >> 16 of the accumulator
    wire signed [15:0] sat = (shifted > 24'sd32767) ? 16'sd32767 : (shifted < -24'sd32768) ? -16'sd32768 : shifted[15:0];
    always @(posedge clk) begin
        out_ce <= 1'b0;
        if (reset) begin
            x0 <= 0; x1 <= 0; x2 <= 0; y1 <= 0; y2 <= 0; acc <= 0; step <= 3'd0; out_sample <= 16'sd0;
        end else if (bypass) begin
            step <= 3'd0;
            if (in_ce) begin out_sample <= in_sample; out_ce <= 1'b1; end
        end else begin
            case (step)
                3'd0: if (in_ce) begin x0 <= in_sample; acc <= 40'sd0; step <= 3'd1; end
                3'd1, 3'd2, 3'd3, 3'd4, 3'd5: begin acc <= acc + {{6{prod[33]}}, prod}; step <= step + 3'd1; end
                3'd6: begin
                    out_sample <= sat; out_ce <= 1'b1;
                    x2 <= x1; x1 <= x0; y2 <= y1; y1 <= sat;
                    step <= 3'd0;
                end
                default: step <= 3'd0;
            endcase
        end
    end
endmodule
`default_nettype wire
