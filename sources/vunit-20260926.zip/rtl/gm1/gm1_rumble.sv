// SPDX-License-Identifier: GPL-2.0-or-later
// gm1_rumble -- gamepad rumble (r26: + Cruis'n World / Off Road family mode, see rumble_golden.py) from the game's own force-feedback intent (Cruis'n gm1 r21, 2026-09-23).
// Signals (MAME-verified, bandwidth/gm1/rumble/analyze_wheelvars.py; WHEEL.ASM NUWHEEL at ROM word 0xAFF2):
//   WHEELPOS  C31 float at 0x00EA78: centre 125, impact kicks 110/140, road-texture jitter 121..129
//   _MODE     0x00C8F5: low nibble 4 = in game (rumble is silent otherwise)
//   engine    DCS host bytes 0x55 0xCC a b (SND.ASM PLYR_ENGINE): a = RPM-like, drops at gear shifts
// r24 (user, cabinet): the engine throb is a STRAIN envelope -- only while the gas is floored (>= 0xC0) and the RPM is
// still climbing (a above a lagging baseline), fading out (10/tick) when it levels off; a gear shift CUTS it and holds
// 0.3 s of silence (was a kick). "Not feeling rumble is as important as feeling rumble."
// Effects per 60 Hz tick: engine throb (lg_mot motor, slow sine whose rate rises with a), impact pulses
// scaled by the kick size, road-texture buzz (sm_mot motor), crash burst (3+ kicks within 60 ticks), intensity scale.
// Integer semantics are defined by the independent golden bandwidth/gm1/rumble/rumble_golden.py (gate check_rumble.py).
// Output rumble = {lg_mot[7:0], sm_mot[7:0]} for hps_io joystick_0_rumble. The tick work is spread over 4 clocks.
`default_nettype none
module gm1_rumble (
    input  wire        clk,
    input  wire        reset,
    input  wire        tick,              // 60 Hz strobe
    input  wire [1:0]  intensity,         // 0 off, 1 low, 2 medium, 3 high
    input  wire        pos_we_in,         // C31 write to WHEELPOS
    input  wire [31:0] pos_data_in,
    input  wire        mode_we_in,        // C31 write to _MODE
    input  wire [3:0]  mode_data_in,
    input  wire        snd_we_in,         // DCS host byte
    input  wire [7:0]  snd_byte_in,
    input  wire [7:0]  gas_in,            // r24: ACCEL pedal (0x00 released .. 0xff floored)
    input  wire        family,            // r26: 1 = Cruis'n World / Off Road Challenge (static per game)
    input  wire        tq_we_in,          // r26: TOWHEEL motor write (gm1_wheel_motor motor_we)
    input  wire [7:0]  tq_in,             // r26: signed motor torque byte
    input  wire [7:0]  wheel_in,          // r26: steering input (0x80 centre)
    output reg  [15:0] rumble
);
    // r22 (timing): register the snoops first. r21 failed -0.275 ns: rman -> C31 store datapath -> bus write data ->
    // float->int -> dev -> texture math -> tex in ONE clock. One clock of latency on a 60 Hz effect is invisible.
    reg        pos_we, mode_we, snd_we;
    reg [31:0] pos_data; reg [3:0] mode_data; reg [7:0] snd_byte; reg [7:0] gas;
    reg        tq_we; reg [7:0] tq_d; reg [7:0] wheel;   // r26
    always @(posedge clk) begin
        pos_we <= pos_we_in && !reset; mode_we <= mode_we_in && !reset; snd_we <= snd_we_in && !reset;
        pos_data <= pos_data_in; mode_data <= mode_data_in; snd_byte <= snd_byte_in; gas <= gas_in;
        tq_we <= tq_we_in && !reset; tq_d <= tq_in; wheel <= wheel_in;
    end
    // ---- C31 float -> integer (floor), positive values only ----
    wire signed [7:0] fe = pos_data[31:24];
    wire [23:0] fm = {1'b1, pos_data[22:0]};
    wire [4:0]  fsh = 5'd23 - fe[4:0];
    wire [15:0] pos_int = (fe == -8'sd128 || pos_data[23] || fe < 0) ? 16'd0 :
                          (fe > 8'sd23) ? 16'hFFFF : (fm >> fsh);
    wire signed [16:0] dev = $signed({1'b0, pos_int}) - 17'sd125;
    wire [16:0] adev = dev[16] ? -dev : dev;
    reg  signed [16:0] prev_dev;
    wire [16:0] pdev_abs = prev_dev[16] ? -prev_dev : prev_dev;
    wire signed [17:0] ddev = dev - prev_dev;
    wire [17:0] addev = ddev[17] ? -ddev : ddev;
    // saturate BEFORE multiplying: min(255, 17*|dev|) and min(255, 48*|ddev|) without wide products
    wire [7:0] kick_new = (adev >= 17'd15) ? 8'd255 : 8'(adev[3:0] * 8'd17);
    wire [7:0] tex_new  = (addev >= 18'd6) ? 8'd255 : 8'(addev[2:0] * 8'd48);
    // ---- state ----
    reg [7:0] kick, tex, crash, eng_a, prev_a, phase;
    reg [7:0] a_ref, env;    // r24: RPM baseline, engine strain envelope
    reg [4:0] pause;         // r24: silent ticks left after a gear shift
    // r26 family: torque kicks / texture, steering-flick hold, engine-command liveness as the in-game gate
    reg signed [7:0] prev_t; reg [8:0] prev_d; reg [5:0] live; reg [4:0] hold; reg gate;
    reg [7:0] wh0, wh1, wh2, wh3;
    wire signed [8:0] t_dif = $signed({tq_d[7], tq_d}) - $signed({prev_t[7], prev_t});
    wire [8:0] t_d = t_dif[8] ? -t_dif : t_dif;                              // 0..255
    wire [10:0] t_k3 = {t_d, 1'b0} + t_d + 11'd50;                           // 3d + 50
    wire [7:0] tq_kick = (t_k3 > 11'd255) ? 8'd255 : t_k3[7:0];
    wire [8:0] t_m5 = t_d - 9'd5;                                            // d in 6..39 -> 1..34
    wire [12:0] t_x16 = {t_m5, 4'd0};
    wire [7:0] tq_tex = (t_x16 > 13'd255) ? 8'd255 : t_x16[7:0];
    wire       w_flick = (wheel >= wh3) ? ((wheel - wh3) >= 8'd24) : ((wh3 - wheel) >= 8'd24);
    reg [3:0] mode;
    reg [2:0] kicks;
    reg [5:0] win;
    reg [1:0] pst;           // engine parser state
    reg [7:0] pa;
    reg [2:0] tst;           // tick sequencer: 0 idle, 1..4
    reg [7:0] level, engine, lg_mot, sm_mot;
    reg [15:0] prod;
    function automatic [7:0] sat8(input [15:0] v); sat8 = (v > 16'd255) ? 8'd255 : v[7:0]; endfunction
    function automatic [7:0] dec(input [7:0] v, input [2:0] sh);
        reg [7:0] r; begin r = v - (v >> sh); dec = (r < (8'd1 << sh)) ? 8'd0 : r; end
    endfunction
    function automatic signed [7:0] sinlut(input [4:0] i);   // round(127*sin(2*pi*i/32))
        case (i)
            5'd0: sinlut = 0;    5'd1: sinlut = 25;   5'd2: sinlut = 49;   5'd3: sinlut = 71;
            5'd4: sinlut = 90;   5'd5: sinlut = 106;  5'd6: sinlut = 117;  5'd7: sinlut = 125;
            5'd8: sinlut = 127;  5'd9: sinlut = 125;  5'd10: sinlut = 117; 5'd11: sinlut = 106;
            5'd12: sinlut = 90;  5'd13: sinlut = 71;  5'd14: sinlut = 49;  5'd15: sinlut = 25;
            5'd16: sinlut = 0;   5'd17: sinlut = -25; 5'd18: sinlut = -49; 5'd19: sinlut = -71;
            5'd20: sinlut = -90; 5'd21: sinlut = -106;5'd22: sinlut = -117;5'd23: sinlut = -125;
            5'd24: sinlut = -127;5'd25: sinlut = -125;5'd26: sinlut = -117;5'd27: sinlut = -106;
            5'd28: sinlut = -90; 5'd29: sinlut = -71; 5'd30: sinlut = -49; default: sinlut = -25;
        endcase
    endfunction
    wire signed [7:0] sv = sinlut(phase[7:3]);
    wire [8:0] mval = 9'd128 + {{2{sv[7]}}, sv[7:1]};       // 128 + (SIN >> 1)
    wire [7:0] scale = (intensity == 2'd0) ? 8'd0 : (intensity == 2'd1) ? 8'd85 : (intensity == 2'd2) ? 8'd170 : 8'd255;
    wire [15:0] lscaled = {8'd0, lg_mot} * {8'd0, scale};    // 16-bit products: v * s >> 8
    wire [15:0] sscaled = {8'd0, sm_mot} * {8'd0, scale};
    wire signed [12:0] lvl_raw = ($signed({5'b0, eng_a}) - 13'sd32) * 3 / 2;     // (a-32)*3/2, up to 334
    // r24 strain envelope (golden order: baseline first, then strain from the NEW baseline, then envelope, then pause)
    wire [7:0] a_gap   = eng_a - a_ref;
    wire [7:0] a_step  = (a_gap[7:3] == 5'd0) ? 8'd1 : {3'd0, a_gap[7:3]};
    wire [7:0] a_ref_n = (eng_a > a_ref) ? a_ref + a_step : eng_a;
    wire       strain  = (gas >= 8'hC0) && ({1'b0, eng_a} > {1'b0, a_ref_n} + 9'd2) && (pause == 5'd0);
    wire [7:0] lvl_sat = (lvl_raw < 0) ? 8'd0 : (lvl_raw > 13'sd255) ? 8'd255 : lvl_raw[7:0];
    wire [7:0] target  = strain ? lvl_sat : 8'd0;
    wire [8:0] env_up  = {1'b0, env} + 9'd24;
    wire [7:0] env_n   = (env < target) ? ((env_up > {1'b0, target}) ? target : env_up[7:0])
                                        : (({1'b0, env} < {1'b0, target} + 9'd10) ? target : env - 8'd10);
    always @(posedge clk) begin
        if (reset) begin
            kick <= 0; tex <= 0; crash <= 0; eng_a <= 0; prev_a <= 0; phase <= 0; mode <= 0;
            a_ref <= 0; env <= 0; pause <= 0;
            prev_t <= 0; prev_d <= 0; live <= 0; hold <= 0; gate <= 0; wh0 <= 8'h80; wh1 <= 8'h80; wh2 <= 8'h80; wh3 <= 8'h80;
            kicks <= 0; win <= 0; pst <= 0; pa <= 0; tst <= 0; prev_dev <= 0; rumble <= 16'd0;
        end else begin
            // ---- events ----
            if (pos_we) begin
                if (adev >= 17'd10) begin
                    if (pdev_abs < 17'd10) begin
                        kick <= (kick > kick_new) ? kick : kick_new;
                        if (kicks != 3'd7) kicks <= kicks + 3'd1;
                    end
                end else begin
                    tex <= (tex > tex_new) ? tex : tex_new;
                end
                prev_dev <= dev;
            end
            if (mode_we) mode <= mode_data;
            if (tq_we) begin                                  // r26 torque (only fed in family mode)
                if (hold == 5'd0) begin
                    if (t_d >= 9'd40) begin
                        if (prev_d < 9'd40) begin
                            kick <= (kick > tq_kick) ? kick : tq_kick;
                            if (kicks != 3'd7) kicks <= kicks + 3'd1;
                        end
                    end else if (t_d >= 9'd6) begin
                        tex <= (tex > tq_tex) ? tex : tq_tex;
                    end
                end
                prev_t <= tq_d; prev_d <= t_d;
            end
            if (snd_we) begin
                case (pst)
                    2'd0: pst <= (snd_byte == 8'h55) ? 2'd1 : 2'd0;
                    2'd1: pst <= (snd_byte == (family ? 8'hE0 : 8'hCC)) ? 2'd2 : ((snd_byte == 8'h55) ? 2'd1 : 2'd0);
                    2'd2: begin pa <= snd_byte; pst <= 2'd3; end
                    default: begin
                        pst <= 2'd0;
                        if (prev_a >= pa && (prev_a - pa) >= 8'h20) begin env <= 8'd0; pause <= 5'd18; end
                        eng_a <= pa; prev_a <= pa;
                        if (family) live <= 6'd60;
                    end
                endcase
            end
            // ---- tick sequencer ----
            case (tst)
                3'd0: if (tick) begin
                    if (kicks >= 3'd3) begin crash <= 8'd255; kicks <= 3'd0; end
                    if (win == 6'd59) begin win <= 6'd0; kicks <= 3'd0; end else win <= win + 6'd1;
                    a_ref <= a_ref_n; env <= env_n; level <= env_n;
                    if (pause != 5'd0) pause <= pause - 5'd1;
                    gate <= family ? (live != 6'd0) : (mode == 4'd4);
                    if (live != 6'd0) live <= live - 6'd1;
                    if (w_flick) hold <= 5'd20; else if (hold != 5'd0) hold <= hold - 5'd1;
                    wh0 <= wheel; wh1 <= wh0; wh2 <= wh1; wh3 <= wh2;
                    phase <= phase + 8'd17 + {3'd0, eng_a[7:3]};
                    tst <= 3'd1;
                end
                3'd1: begin prod <= level * mval[7:0] + (mval[8] ? {level, 8'd0} : 16'd0); tst <= 3'd2; end
                3'd2: begin
                    engine <= ({8'd0, prod[15:8]} * 16'd3) >> 2;
                    tst <= 3'd3;
                end
                3'd3: begin
                    lg_mot <= sat8({8'd0, engine} + kick + crash);
                    sm_mot <= sat8({8'd0, kick} + tex + (crash >> 1));
                    tst <= 3'd4;
                end
                default: begin
                    rumble <= gate ? {lscaled[15:8], sscaled[15:8]} : 16'd0;
                    kick <= dec(kick, 3'd2); tex <= dec(tex, 3'd3); crash <= dec(crash, 3'd4);
                    tst <= 3'd0;
                end
            endcase
        end
    end
endmodule
`default_nettype wire
