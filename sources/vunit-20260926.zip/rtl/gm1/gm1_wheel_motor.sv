// SPDX-License-Identifier: GPL-2.0-or-later
// gm1_wheel_motor -- the Cruis'n wheel board's motor latch (r23, 2026-09-23), for force-feedback wheels.
// Transcribed from MAME 0.28x midvunit.cpp wheel_board_w (lines 399-512, snapshot c662f9ca): every C31 write to
// 0x995000 is one call.
//   * bit 11 rising (vs the previous write): U8 latches WA0..WA3 = data[3:0]
//   * !bit 9                      -> U13 DCS path (not the motor)
//   * bit 9 && !bit 10 && !WA3    -> U9 74LS138 select WA[2:0]; WA == 4 is WHLCTLZ: m_wheel_motor = data[7:0]
//   * (bit 9 && !bit 10 && WA3 is the Galil path; not the motor)
//   * m_wheel_board_last = data
// Output: the motor byte (the game's signed torque, WHEEL.ASM TOWHEEL) and a one-clock pulse per motor write.
// Inputs are registered once (r21 lesson: a snoop must never hang combinationally off the C31 store datapath).
`default_nettype none
module gm1_wheel_motor (
    input  wire        clk,
    input  wire        reset,
    input  wire        we_in,          // C31 write to 0x995000 completed
    input  wire [31:0] data_in,
    output reg  [7:0]  motor,
    output reg         motor_we
);
    reg        we; reg [11:0] d;
    reg [11:0] last;
    reg [3:0]  latch;                  // {WA3, WA2, WA1, WA0}
    wire [3:0] latch_now = (d[11] && !last[11]) ? d[3:0] : latch;   // MAME latches before it decodes the same write
    always @(posedge clk) begin
        if (reset) begin
            we <= 1'b0; d <= 12'd0; last <= 12'd0; latch <= 4'd0; motor <= 8'd0; motor_we <= 1'b0;
        end else begin
            we <= we_in; d <= data_in[11:0];
            motor_we <= 1'b0;
            if (we) begin
                latch <= latch_now;
                if (d[9] && !d[10] && !latch_now[3] && latch_now[2:0] == 3'd4) begin
                    motor <= d[7:0]; motor_we <= 1'b1;
                end
                last <= d;
            end
        end
    end
endmodule
`default_nettype wire
