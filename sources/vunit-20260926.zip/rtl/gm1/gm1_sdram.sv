`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_sdram.sv -- board SDRAM for the Cruis'n USA master core (gm1).
//
// c31_sdram_backing (lane C3's fork of the bw1 cabinet-proven controller, rtl/c31/mem/sdram/) behind the bw1 pin
// stage (bandwidth/bw1/rtl/core/bw1_sdram_subsystem.sv: one output register on every SDRAM pin and one input
// register on SDRAM_DQ, PIN_LAT 2 compensated inside the controller), shared by two masters in turn:
//   * the maindata loader (gm1_loader) while loader_owns: single 32-bit writes at SDRAM byte addresses;
//   * c31_memory afterwards: its sd_* port in C31 word addresses (single read or write, or a 256-word page burst).
//
// C31 word regions -> SDRAM bytes (32 MiB byte space; every 256-word page stays 1024 contiguous bytes = one row of
// c31_sdram_burst's [C31-1] decomposition, so a page fill is one open-row burst):
//   ROM   0xc00000-0xffffff -> 0x0000000 + (w - 0xc00000) * 4
//   main  0x000000-0x01ffff -> 0x1000000 + w * 4
//   fast  0x400000-0x41ffff -> 0x1080000 + (w - 0x400000) * 4
//   CMOS  0x9c0000-0x9c1fff -> 0x1100000 + (w - 0x9c0000) * 4
// Any other word address from c31_memory is a map fault (sticky flag; the request is served at byte 0).
//
// Request glue. c31_sdram_backing starts a transaction whenever c_req is high in its idle state and reads c_baddr /
// c_wdata again after the first halfword, while both masters hold their request through a transaction and drop it
// only afterwards. So the glue latches the request fields at acceptance, holds c_req until the transaction
// completes (c_ack for a single, the WORDS-th c_dvalid for a burst: the backing is still in its burst state for one
// more clock, then idles with c_req already low), and accepts a new request only after the master dropped its
// request for at least one clock. A held request therefore never starts a second transaction.
module gm1_sdram #(
    parameter integer WORDS = 256
) (
    input  wire        clk,
    input  wire        por,           // power-on reset: controller init and glue (P0022 domain)
    input  wire        loader_owns,   // 1: loader master; 0: c31_memory master (switch only while both are idle)

    // loader master: single writes at SDRAM byte addresses
    input  wire        l_req,
    input  wire [24:0] l_baddr,
    input  wire [31:0] l_wdata,
    output wire        l_ack,

    // c31_memory master: C31 word addresses
    input  wire        sd_req,
    input  wire        sd_we,
    input  wire        sd_burst,
    input  wire [23:0] sd_addr,
    input  wire [31:0] sd_wdata,
    output wire        sd_ack,
    output wire [31:0] sd_rdata,

    output reg         map_fault,

    inout  wire [15:0] SDRAM_DQ,
    output wire [12:0] SDRAM_A,
    output wire [1:0]  SDRAM_BA,
    output wire        SDRAM_DQML, SDRAM_DQMH,
    output wire        SDRAM_nCS, SDRAM_nCAS, SDRAM_nRAS, SDRAM_nWE, SDRAM_CKE
);
    // ---- C31 word address -> SDRAM byte address ----
    function automatic [25:0] map_word(input [23:0] w);   // {hit, byte address}
        begin
            if (w >= 24'hc00000)                            map_word = {1'b1, 1'b0, w[21:0], 2'b00};  // w[21:0] = w - 0xc00000
            else if (w <= 24'h01ffff)                       map_word = {1'b1, 25'h1000000 | {6'd0, w[16:0], 2'b00}};
            else if (w >= 24'h400000 && w <= 24'h41ffff)    map_word = {1'b1, 25'h1080000 | {6'd0, w[16:0], 2'b00}};
            else if (w >= 24'h9c0000 && w <= 24'h9c1fff)    map_word = {1'b1, 25'h1100000 | {10'd0, w[12:0], 2'b00}};
            else                                            map_word = {1'b0, 25'd0};
        end
    endfunction
    wire [25:0] sd_map = map_word(sd_addr);

    // ---- request glue ----
    wire        m_req   = loader_owns ? l_req : sd_req;
    reg         g_active, g_done, g_we, g_burst;
    reg  [24:0] g_baddr;
    reg  [31:0] g_wdata;
    reg  [9:0]  g_words;

    wire        c_ack, c_dvalid, c_busy;
    wire [31:0] c_rdata, c_bdata;

    always @(posedge clk) begin
        if (por) begin
            g_active <= 1'b0; g_done <= 1'b0; g_we <= 1'b0; g_burst <= 1'b0;
            g_baddr <= 25'd0; g_wdata <= 32'd0; g_words <= 10'd0; map_fault <= 1'b0;
        end else begin
            if (!g_active) begin
                if (!m_req) g_done <= 1'b0;
                else if (!g_done) begin
                    g_active <= 1'b1; g_words <= 10'd0;
                    if (loader_owns) begin
                        g_we <= 1'b1; g_burst <= 1'b0; g_baddr <= l_baddr; g_wdata <= l_wdata;
                    end else begin
                        g_we <= sd_we; g_burst <= sd_burst && !sd_we; g_baddr <= sd_map[24:0]; g_wdata <= sd_wdata;
                        if (!sd_map[25]) map_fault <= 1'b1;
                    end
                end
            end else begin
                if (c_ack) begin g_active <= 1'b0; g_done <= 1'b1; end
                if (c_dvalid) begin
                    g_words <= g_words + 10'd1;
                    if (g_words == WORDS[9:0] - 10'd1) begin g_active <= 1'b0; g_done <= 1'b1; end
                end
            end
        end
    end

    assign l_ack    = loader_owns && c_ack;
    assign sd_ack   = !loader_owns && (c_ack || c_dvalid);
    assign sd_rdata = c_dvalid ? c_bdata : c_rdata;

    // ---- controller + backing ----
    wire [15:0] cb_dq_out; wire cb_dq_oe;
    wire [12:0] cb_A; wire [1:0] cb_BA;
    wire cb_dqml, cb_dqmh, cb_ncs, cb_nwe, cb_nras, cb_ncas, cb_cke;
    reg  [15:0] SDRAM_DQ_in_q;

    c31_sdram_backing #(.WORDS(WORDS), .BURST_HALFWORDS(2*WORDS)) backing (
        .clk(clk), .init(por),
        .c_req(g_active), .c_we(g_we), .c_burst(g_burst), .c_baddr(g_baddr), .c_wdata(g_wdata),
        .c_ack(c_ack), .c_rdata(c_rdata), .c_dvalid(c_dvalid), .c_bdata(c_bdata), .c_busy(c_busy),
        .i_dq(SDRAM_DQ_in_q), .o_dq_out(cb_dq_out), .o_dq_oe(cb_dq_oe), .o_A(cb_A), .o_dqml(cb_dqml),
        .o_dqmh(cb_dqmh), .o_BA(cb_BA), .o_ncs(cb_ncs), .o_nwe(cb_nwe), .o_nras(cb_nras), .o_ncas(cb_ncas),
        .o_cke(cb_cke));

    // ---- pin registers (bw1 build 2 pattern; the QSF packs them into the I/O cells) ----
    reg [12:0] SDRAM_A_q; reg [1:0] SDRAM_BA_q;
    reg        SDRAM_nCS_q, SDRAM_nRAS_q, SDRAM_nCAS_q, SDRAM_nWE_q, SDRAM_CKE_q, SDRAM_DQML_q, SDRAM_DQMH_q;
    reg [15:0] SDRAM_DQ_out_q; reg SDRAM_DQ_oe_q;
    always @(posedge clk) begin
        SDRAM_DQ_in_q <= SDRAM_DQ;                       // the only reader of SDRAM_DQ (no reset)
        if (por) begin
            SDRAM_A_q<=13'd0; SDRAM_BA_q<=2'd0; SDRAM_nCS_q<=1'b1; SDRAM_nRAS_q<=1'b1; SDRAM_nCAS_q<=1'b1; SDRAM_nWE_q<=1'b1;
            SDRAM_CKE_q<=1'b1; SDRAM_DQML_q<=1'b0; SDRAM_DQMH_q<=1'b0; SDRAM_DQ_out_q<=16'd0; SDRAM_DQ_oe_q<=1'b0;
        end else begin
            SDRAM_A_q <= cb_A; SDRAM_BA_q <= cb_BA; SDRAM_nCS_q <= cb_ncs; SDRAM_nRAS_q <= cb_nras;
            SDRAM_nCAS_q <= cb_ncas; SDRAM_nWE_q <= cb_nwe; SDRAM_CKE_q <= cb_cke; SDRAM_DQML_q <= cb_dqml;
            SDRAM_DQMH_q <= cb_dqmh; SDRAM_DQ_out_q <= cb_dq_out; SDRAM_DQ_oe_q <= cb_dq_oe;
        end
    end
    assign SDRAM_A = SDRAM_A_q; assign SDRAM_BA = SDRAM_BA_q;
    assign SDRAM_nCS = SDRAM_nCS_q; assign SDRAM_nRAS = SDRAM_nRAS_q; assign SDRAM_nCAS = SDRAM_nCAS_q; assign SDRAM_nWE = SDRAM_nWE_q;
    assign SDRAM_CKE = SDRAM_CKE_q; assign SDRAM_DQML = SDRAM_DQML_q; assign SDRAM_DQMH = SDRAM_DQMH_q;
    assign SDRAM_DQ = SDRAM_DQ_oe_q ? SDRAM_DQ_out_q : 16'bZ;
endmodule
`default_nettype wire
