`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_engine.sv -- single-clock game engine of the Cruis'n USA master core (gm1): gm1_board (C31, memory tier,
// peripherals, V-unit video board, board I/O) plus the DDR-side renderer plumbing, forked from
// rtl/integration/hybrid_ddr_top.sv with the mailbox bridge, scheduler and session ports removed. The texture skid, the
// palette-write snoop and vunit_memory_arbiter are carried over unchanged (they shipped in hybrid attempt 8); the
// arbiter parameters are those rtl/platform/cusa_platform_core.sv instantiated. r12 (2026-09-18) removed the native
// scanout (vunit_scanout) and replaced vunit_palette_cache with gm1_palette_ram: the display is gm1_fb_present in
// gm1_core, reading the framebuffer on real time, so the video path no longer pauses guest time.
module gm1_engine #(
    parameter integer WIDTH=512, HEIGHT=400, VUNIT_QUEUE_DEPTH=270,
    parameter integer ADC_CONVERSION_GUEST_STEPS=1000,
    parameter integer PRIVATE_TEXTURE_SERVICE=2,
    parameter integer REGISTER_VIEW=0,
    parameter integer FRAMEBUFFER_CACHE=1,
    parameter integer TEXTURE_CACHE=1,
    parameter integer TEXTURE_CACHE_BEATS=4,
    parameter integer TEXTURE_CACHE_LINES=1024,
    parameter integer TEXTURE_FAST_HIT=1,
    parameter integer FRAME_WRITE_COALESCE=1,
    parameter integer TEXTURE_HIT_UNDER_MISS=1,
    parameter integer TEXTURE_FILL_DEPTH=4,
    parameter integer TEXTURE_NEXT_LINE=1,
    parameter integer NUM_MAIN_PAGES=128,   // ladder rung 3c (see gm1_board.sv)
    parameter integer NUM_ROM_PAGES=16   // ladder rung 1b (see gm1_board.sv)
) (
    input  wire clk, reset,
    input  wire guest_run_enable,
    input  wire [23:0] boot_pc,
    // board SDRAM (C31 word space)
    output wire sd_req, sd_we, sd_burst,
    output wire [23:0] sd_addr,
    output wire [31:0] sd_wdata,
    input  wire sd_ack,
    input  wire [31:0] sd_rdata,
    // cabinet
    input  wire [15:0] cabinet_in0, cabinet_in1, cabinet_switch2, cabinet_dips,
    input  wire [31:0] adc_channels,
    // DCS control wires
    output wire dcs_latch_we,
    output wire [7:0] dcs_latch_data,
    output wire dcs_run,
    // DDR regions
    input  wire config_valid,
    output wire config_ready,
    input  wire [31:0] config_fb_base, config_texture_base, config_palette_base,
    input  wire backend_quiesced,
    output wire backend_reset_request, memory_configured,
    output wire avm_read, avm_write,
    output wire [31:0] avm_address,
    output wire [63:0] avm_writedata,
    output wire [7:0] avm_byteenable,
    output wire [3:0] avm_burstcount,
    input  wire avm_waitrequest, avm_readdatavalid,
    input  wire [63:0] avm_readdata,
    input  wire avm_read_error,
    // direct framebuffer presentation (gm1_fb_present in gm1_core; r12): the palette as block RAM with a pipelined read
    // port, and the count of V-unit raster frames the guest has completed
    input  wire protect_page, protected_page,
    input  wire [14:0] present_pal_addr,
    output wire [15:0] present_pal_word,
    output reg  [31:0] native_frames,
    // status
    output wire halted,
    output wire [7:0] memory_fault,
    output wire [31:0] memory_fault_address,
    output wire [7:0] vunit_fault,
    output wire [7:0] cpu_fault,
    output wire [23:0] cpu_pc,
    output wire [63:0] instructions,
    output wire [63:0] guest_tick,
    output wire ext_unmapped_seen, int0_seen, display_page,
    output wire [79:0] irq_diag,                    // r10 status page 2 (gm1_board.sv)
    output wire [95:0] render_diag,                 // r11 status page 3 (gm1_board.sv)
    output wire [255:0] perf_diag,                  // 2026-09-23 race-speed counters (gm1_board.sv, status mirror 11..14)
    output wire        rumble_pos_we, rumble_mode_we,   // r21 rumble snoops (gm1_board.sv)
    output wire        wheel_board_we,                  // r23 FFB wheel board write (gm1_board.sv)
    input  wire [1:0]  game,                            // r24 family core (gm1_family_io.sv)
    input  wire [64:0] mister_rtc,
    output wire [12:0] cmos_alt_addr,
    input  wire [31:0] cmos_alt_q,
    output wire [31:0] rumble_data
);
    wire memory_reset = reset;
    wire guest_memory_wait, guest_fb_offer, guest_tex_offer;
    wire memory_physical_wait, memory_halted, memory_credit;
    wire palette_cache_initialized;
    // r12: the native scanout (vunit_scanout) and its guest-time pause are gone -- the display reads the framebuffer on
    // real time (gm1_fb_present) and nothing on the video path stops guest time any more.
    wire board_guest_run = guest_run_enable && memory_configured && !memory_physical_wait &&
                           palette_cache_initialized && !halted;
    wire bus_run_enable  = memory_configured && palette_cache_initialized && !memory_physical_wait && !halted;
    assign halted = memory_halted || vunit_fault != 0;

    wire fb_valid, fb_ready;
    wire [18:0] fb_addr;
    wire [15:0] fb_data;
    wire fb_pair;
    wire [15:0] fb_data_hi;
    wire tex_req_pair;
    wire [2:0] tex_req_off2;
    wire [3:0] tex_req_tag;
    wire tex_req_valid, tex_rsp_ready;
    wire tex_req_ready;
    wire [21:0] tex_req_addr;
    wire tex_req_prefetch;
    wire memory_tex_rsp_valid, memory_tex_rsp_ready;
    wire [7:0] memory_tex_rsp_data, memory_tex_rsp_data2;
    wire [3:0] memory_tex_rsp_tag;
    reg tex_skid_valid;
    reg [7:0] tex_skid_data, tex_skid_data2;
    reg [3:0] tex_skid_tag;
    // Texture skid (hybrid_ddr_top.sv): buffers only when the renderer is not ready; otherwise the arbiter response
    // passes through in the same clock.
    wire tex_pass = memory_tex_rsp_valid && !tex_skid_valid;
    wire tex_out_valid = tex_skid_valid || tex_pass;
    wire [7:0] tex_out_data = tex_skid_valid ? tex_skid_data : memory_tex_rsp_data;
    wire [7:0] tex_out_data2 = tex_skid_valid ? tex_skid_data2 : memory_tex_rsp_data2;
    wire [3:0] tex_out_tag = tex_skid_valid ? tex_skid_tag : memory_tex_rsp_tag;
    wire tex_consume = tex_out_valid && tex_rsp_ready;
    assign memory_tex_rsp_ready = !tex_skid_valid || tex_consume;
    always @(posedge clk) begin
        if (memory_reset) begin tex_skid_valid<=0; tex_skid_data<=0; tex_skid_data2<=0; tex_skid_tag<=0; end
        else begin
            if (tex_skid_valid && tex_rsp_ready) tex_skid_valid<=0;
            if (memory_tex_rsp_valid && memory_tex_rsp_ready && !(tex_pass && tex_rsp_ready)) begin
                tex_skid_valid<=1; tex_skid_data<=memory_tex_rsp_data; tex_skid_data2<=memory_tex_rsp_data2; tex_skid_tag<=memory_tex_rsp_tag;
            end
        end
    end

    wire cpu_mem_req_valid, cpu_mem_req_ready, cpu_mem_req_write, cpu_mem_rsp_valid, cpu_mem_rsp_ready;
    wire [1:0] cpu_mem_req_region;
    wire [21:0] cpu_mem_req_addr;
    wire [31:0] cpu_mem_req_wdata, cpu_mem_rsp_rdata;
    wire [3:0] cpu_mem_req_be;
    wire memory_fb_valid, memory_fb_ready, memory_cpu_valid, memory_cpu_ready;
    gm1_fb_write_guard write_guard (
        .protect_page(protect_page), .protected_page(protected_page),
        .fb_valid(fb_valid), .fb_addr(fb_addr), .memory_fb_ready(memory_fb_ready),
        .memory_fb_valid(memory_fb_valid), .fb_ready(fb_ready),
        .cpu_valid(cpu_mem_req_valid), .cpu_write(cpu_mem_req_write), .cpu_region(cpu_mem_req_region),
        .cpu_addr(cpu_mem_req_addr), .memory_cpu_ready(memory_cpu_ready),
        .memory_cpu_valid(memory_cpu_valid), .cpu_ready(cpu_mem_req_ready)
    );
    reg palette_write_pending;
    reg [14:0] palette_write_addr;
    reg [31:0] palette_write_data;
    reg [3:0] palette_write_be;
    wire palette_write_commit = palette_write_pending && cpu_mem_rsp_valid && cpu_mem_rsp_ready;
    // Palette snoop (hybrid_ddr_top.sv): the CPU transaction is applied to the cache only after its DDR write drains.
    always @(posedge clk) begin
        if (memory_reset) begin
            palette_write_pending<=0; palette_write_addr<=0; palette_write_data<=0; palette_write_be<=0;
        end else begin
            if (cpu_mem_req_valid && cpu_mem_req_ready) begin
                palette_write_pending <= cpu_mem_req_write && cpu_mem_req_region==2;
                palette_write_addr <= cpu_mem_req_addr[16:2];
                palette_write_data <= cpu_mem_req_wdata; palette_write_be <= cpu_mem_req_be;
            end
            if (cpu_mem_rsp_valid && cpu_mem_rsp_ready) palette_write_pending<=0;
        end
    end
    wire [9:0] raster_x;
    wire [8:0] raster_y;
    wire raster_de, hsync, vsync, csync, pixel_event, frame_event;
    wire [31:0] palette_epoch;
    wire irq_int0, irq_int3, write_page, queue_nonempty, renderer_busy, queue_full;

    gm1_board #(.VUNIT_QUEUE_DEPTH(VUNIT_QUEUE_DEPTH), .WIDTH(WIDTH), .HEIGHT(HEIGHT),
        .PRIVATE_TEXTURE_SERVICE(PRIVATE_TEXTURE_SERVICE), .REGISTER_VIEW(REGISTER_VIEW),
        .ADC_CONVERSION_GUEST_STEPS(ADC_CONVERSION_GUEST_STEPS),
        .NUM_MAIN_PAGES(NUM_MAIN_PAGES), .NUM_ROM_PAGES(NUM_ROM_PAGES)) board (
        .clk(clk), .reset(memory_reset), .run_enable(board_guest_run), .bus_run_enable(bus_run_enable), .boot_pc(boot_pc),
        .sd_req(sd_req), .sd_we(sd_we), .sd_burst(sd_burst), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sd_ack), .sd_rdata(sd_rdata),
        .fb_valid(fb_valid), .fb_ready(fb_ready), .fb_addr(fb_addr), .fb_data(fb_data), .fb_pair(fb_pair), .fb_data_hi(fb_data_hi),
        .guest_fb_offer(guest_fb_offer), .guest_tex_offer(guest_tex_offer),
        .tex_req_valid(tex_req_valid), .tex_req_ready(tex_req_ready), .tex_req_addr(tex_req_addr), .tex_req_prefetch(tex_req_prefetch),
        .tex_rsp_valid(tex_out_valid), .tex_rsp_ready(tex_rsp_ready), .tex_rsp_data(tex_out_data), .tex_req_pair(tex_req_pair),
        .tex_req_off2(tex_req_off2), .tex_rsp_data2(tex_out_data2), .tex_req_tag(tex_req_tag), .tex_rsp_tag(tex_out_tag),
        .cpu_mem_req_valid(cpu_mem_req_valid), .cpu_mem_req_ready(cpu_mem_req_ready), .cpu_mem_req_write(cpu_mem_req_write),
        .cpu_mem_req_region(cpu_mem_req_region), .cpu_mem_req_addr(cpu_mem_req_addr), .cpu_mem_req_wdata(cpu_mem_req_wdata),
        .cpu_mem_req_be(cpu_mem_req_be), .cpu_mem_rsp_valid(cpu_mem_rsp_valid), .cpu_mem_rsp_ready(cpu_mem_rsp_ready),
        .cpu_mem_rsp_rdata(cpu_mem_rsp_rdata),
        .raster_x(raster_x), .raster_y(raster_y), .raster_de(raster_de), .hsync(hsync), .vsync(vsync), .csync(csync),
        .pixel_event(pixel_event), .frame_event(frame_event), .irq_int0(irq_int0), .irq_int3(irq_int3),
        .palette_epoch(palette_epoch), .source_restart(),
        .display_page(display_page), .write_page(write_page), .queue_nonempty(queue_nonempty),
        .renderer_busy(renderer_busy), .queue_full(queue_full), .guest_memory_wait(guest_memory_wait),
        .vunit_fault(vunit_fault), .guest_tick(guest_tick),
        .cabinet_in0(cabinet_in0), .cabinet_in1(cabinet_in1), .cabinet_switch2(cabinet_switch2),
        .cabinet_dips(cabinet_dips), .adc_channels(adc_channels),
        .dcs_latch_we(dcs_latch_we), .dcs_latch_data(dcs_latch_data), .dcs_run(dcs_run),
        .cpu_fault(cpu_fault), .cpu_pc(cpu_pc), .instructions(instructions),
        .ext_unmapped_seen(ext_unmapped_seen), .int0_seen(int0_seen), .irq_diag(irq_diag), .render_diag(render_diag), .perf_diag(perf_diag),
        .rumble_pos_we(rumble_pos_we), .rumble_mode_we(rumble_mode_we), .wheel_board_we(wheel_board_we), .rumble_data(rumble_data),
        .game(game), .mister_rtc(mister_rtc), .cmos_alt_addr(cmos_alt_addr), .cmos_alt_q(cmos_alt_q)
    );
    // Raster frames the guest has completed (the frame-end pixel of the V-unit raster, guest time). This replaces the
    // old capture's presented-frame count for the FRAMES gate and the status screen: the old path counted a native frame
    // once it had been captured, which is the same event minus the capture pipeline's latency.
    always @(posedge clk) begin
        if (memory_reset) native_frames <= 32'd0;
        else if (pixel_event && frame_event) native_frames <= native_frames + 32'd1;
    end
    vunit_memory_arbiter #(.FRAMEBUFFER_CACHE(FRAMEBUFFER_CACHE), .TEXTURE_CACHE(TEXTURE_CACHE), .TEXTURE_CACHE_BEATS(TEXTURE_CACHE_BEATS),
        .TEXTURE_CACHE_LINES(TEXTURE_CACHE_LINES), .TEXTURE_FAST_HIT(TEXTURE_FAST_HIT), .FRAME_WRITE_COALESCE(FRAME_WRITE_COALESCE),
        .TEXTURE_HIT_UNDER_MISS(TEXTURE_HIT_UNDER_MISS), .TEXTURE_FILL_DEPTH(TEXTURE_FILL_DEPTH), .TEXTURE_NEXT_LINE(TEXTURE_NEXT_LINE)) memory (
        .clk(clk), .reset(memory_reset), .config_valid(config_valid), .config_ready(config_ready),
        .config_fb_base(config_fb_base), .config_texture_base(config_texture_base), .config_palette_base(config_palette_base),
        .backend_quiesced(backend_quiesced), .backend_reset_request(backend_reset_request), .configured(memory_configured),
        .fault_code(memory_fault), .fault_address(memory_fault_address), .available_credit(memory_credit),
        .physical_wait(memory_physical_wait), .halted(memory_halted), .scanout_lock(1'b0),
        .guest_fb_offer(guest_fb_offer), .guest_tex_offer(guest_tex_offer),
        .fb_valid(memory_fb_valid), .fb_ready(memory_fb_ready), .fb_addr(fb_addr), .fb_data(fb_data), .fb_pair(fb_pair), .fb_data_hi(fb_data_hi),
        .tex_req_valid(tex_req_valid), .tex_req_ready(tex_req_ready), .tex_req_addr(tex_req_addr), .tex_req_prefetch(tex_req_prefetch), .tex_req_off2(tex_req_off2),
        .tex_rsp_valid(memory_tex_rsp_valid), .tex_rsp_ready(memory_tex_rsp_ready), .tex_rsp_data(memory_tex_rsp_data), .tex_rsp_data2(memory_tex_rsp_data2),
        .tex_req_tag(tex_req_tag), .tex_rsp_tag(memory_tex_rsp_tag),
        .cpu_mem_req_valid(memory_cpu_valid), .cpu_mem_req_ready(memory_cpu_ready), .cpu_mem_req_write(cpu_mem_req_write),
        .cpu_mem_req_region(cpu_mem_req_region), .cpu_mem_req_addr(cpu_mem_req_addr), .cpu_mem_req_wdata(cpu_mem_req_wdata), .cpu_mem_req_be(cpu_mem_req_be),
        .cpu_mem_rsp_valid(cpu_mem_rsp_valid), .cpu_mem_rsp_ready(cpu_mem_rsp_ready), .cpu_mem_rsp_rdata(cpu_mem_rsp_rdata),
        // r12: no scanout reads through the arbiter (gm1_fb_present reads DDR3 as its own mux client) and no palette
        // misses (gm1_palette_ram has no DDR3 backing path).
        .fb_read_req_valid(1'b0), .fb_read_req_ready(), .fb_read_req_addr(19'd0),
        .fb_read_rsp_valid(), .fb_read_rsp_ready(1'b1), .fb_read_rsp_data(),
        .pal_read_req_valid(1'b0), .pal_read_req_ready(), .pal_read_req_addr(15'd0),
        .pal_read_rsp_valid(), .pal_read_rsp_ready(1'b1), .pal_read_rsp_data(),
        .avm_read(avm_read), .avm_write(avm_write), .avm_address(avm_address), .avm_writedata(avm_writedata),
        .avm_byteenable(avm_byteenable), .avm_burstcount(avm_burstcount), .avm_waitrequest(avm_waitrequest),
        .avm_readdatavalid(avm_readdatavalid), .avm_readdata(avm_readdata), .avm_read_error(avm_read_error)
    );
    gm1_palette_ram palette_ram (
        .clk(clk), .reset(memory_reset), .initialized(palette_cache_initialized),
        .write_valid(palette_write_commit), .write_addr(palette_write_addr), .write_data(palette_write_data), .write_be(palette_write_be),
        .rd_addr(present_pal_addr), .rd_word(present_pal_word)
    );
endmodule
`default_nettype wire
