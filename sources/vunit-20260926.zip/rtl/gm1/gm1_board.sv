`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_board.sv -- the Cruis'n USA main board in fabric for the master core (gm1): the TMS320C31 (c31_core, multi-cycle
// fit form), its memory tier (c31_memory, lane C3), peripherals (c31_peripherals), guest-time pacing, the V-unit video
// board (vunit_board) and the board I/O (vunit_board_io). It takes the place of the hybrid's mailbox bridge and
// scheduler (rtl/integration/hybrid_vunit_top.sv) and presents the same renderer, CPU-memory and raster ports to
// gm1_engine.
//
// Bus decode and slave wiring follow the G2 lockstep DUT (tests/c31/g2/tb_c31_g2.sv). Guest time does NOT: G2 clocks
// the V-unit once per instruction, a lockstep simplification. Here guest time is H1-accurate:
//   * each retire adds retire_cyc H1 of debt (the MAME cycle table, carried by the core);
//   * c31_pacer emits at most one H1 per clock, at most one per two clocks on average (real time), while the engine
//     lets the guest run and the V-unit is not waiting for DDR; a V-unit render barrier (guest_calculation_wait)
//     stalls it without accruing catch-up (c31_pacer header);
//   * every instruction's IRQ sample and non-memory bus accesses see now = the sum of all earlier retire_cyc (the G2
//     timer contract). Up to r12 the core simply waited for all debt at every boundary; since stage 2
//     (c31_guest_gate, HORIZON=1) it runs ahead of guest time and waits only where that contract needs it (an
//     interrupt edge reachable within the owed H1, or a non-memory access);
//   * the V-unit raster and renderer step on the H1 tick (guest_ce) with the 2/3 video ratio (cusa_video_ce), and the
//     board I/O ADC converts in guest H1, as in the hybrid platform.
// Boot (tms320c3x.cpp device_reset): PC = RMEM(0), IE/IF/ST/IOF = 0, all other registers zero at power-on. The core
// has no reset-vector fetch, so one load_en pulse on the first clock out of reset loads PC = boot_pc (maindata word 0,
// captured by gm1_loader) with a zero register state.
// 0x994000 writes update the board I/O system control (ADC enables) exactly as the hybrid's service reply did; the
// DCS control wires come from c31_peripherals (0x9A0000 data strobe, 0x994000 bit 1 = active-high DCS run).
module gm1_board #(
    parameter integer VUNIT_QUEUE_DEPTH = 270,
    parameter integer WIDTH = 512,
    parameter integer HEIGHT = 400,
    parameter integer PRIVATE_TEXTURE_SERVICE = 2,
    parameter integer REGISTER_VIEW = 0,
    // 2026-09-23 r16: 0 = the V-unit renders CONCURRENTLY with the CPU in real time (the hardware); 1 = the renderer's
    // busy period freezes guest time and blocks V-unit/IO access (MAME's zero-time render; diagnosis only).
    parameter integer RENDER_HOLDS_GUEST = 0,
    // 2026-09-23 r17: 1 = guest time (raster/INT0, C31 timers, ADC, DCS events) runs at REAL time, as on the board.
    parameter integer GUEST_REAL_TIME = 1,
    parameter integer ADC_CONVERSION_GUEST_STEPS = 1000,
    parameter integer NUM_MAIN_PAGES = 128,   // ladder rung 3c 2026-09-22: 172 -> 128. The 172-way tag compare + fetch-map move-to-front was the worst path (Slow 100C -0.257 ns, build gm1-quartus-20260922T162714815764500Z); garage and race clocks are IDENTICAL at 172/128/96.
    parameter integer NUM_ROM_PAGES = 16,   // ladder rung 1b 2026-09-22: 109 -> 16, ROM misses compulsory (garage G2 byte-identical, 11 misses both)
    parameter integer NOW_BITS = 48
) (
    input  wire         clk,
    input  wire         reset,            // game reset (also the V-unit memory reset)
    input  wire         run_enable,       // engine: guest may advance (memory configured, no DDR/scanout wait, not halted)
    input  wire         bus_run_enable,   // engine: V-unit / IO bus grants allowed
    input  wire [23:0]  boot_pc,

    // board SDRAM, C31 word space (gm1_sdram)
    output wire         sd_req,
    output wire         sd_we,
    output wire         sd_burst,
    output wire [23:0]  sd_addr,
    output wire [31:0]  sd_wdata,
    input  wire         sd_ack,
    input  wire [31:0]  sd_rdata,

    // renderer and CPU-memory ports (same contract as hybrid_vunit_top)
    output wire         fb_valid,
    input  wire         fb_ready,
    output wire [18:0]  fb_addr,
    output wire [15:0]  fb_data,
    output wire         fb_pair,
    output wire [15:0]  fb_data_hi,
    output wire         guest_fb_offer,
    output wire         guest_tex_offer,
    output wire         tex_req_valid,
    input  wire         tex_req_ready,
    output wire [21:0]  tex_req_addr,
    output wire         tex_req_prefetch,
    input  wire         tex_rsp_valid,
    output wire         tex_rsp_ready,
    input  wire [7:0]   tex_rsp_data,
    output wire         tex_req_pair,
    output wire [2:0]   tex_req_off2,
    input  wire [7:0]   tex_rsp_data2,
    output wire [3:0]   tex_req_tag,
    input  wire [3:0]   tex_rsp_tag,
    output wire         cpu_mem_req_valid,
    input  wire         cpu_mem_req_ready,
    output wire         cpu_mem_req_write,
    output wire [1:0]   cpu_mem_req_region,
    output wire [21:0]  cpu_mem_req_addr,
    output wire [31:0]  cpu_mem_req_wdata,
    output wire [3:0]   cpu_mem_req_be,
    input  wire         cpu_mem_rsp_valid,
    output wire         cpu_mem_rsp_ready,
    input  wire [31:0]  cpu_mem_rsp_rdata,
    output wire [9:0]   raster_x,
    output wire [8:0]   raster_y,
    output wire         raster_de, hsync, vsync, csync, pixel_event, frame_event,
    output wire         irq_int0,
    output wire         irq_int3,
    output wire [31:0]  palette_epoch,
    output wire         source_restart,
    output wire         display_page, write_page, queue_nonempty, renderer_busy, queue_full,
    output wire         guest_memory_wait,
    output wire [7:0]   vunit_fault,
    output wire [63:0]  guest_tick,

    // cabinet
    input  wire [15:0]  cabinet_in0, cabinet_in1, cabinet_switch2, cabinet_dips,
    input  wire [31:0]  adc_channels,

    // DCS control wires (cusa_dcs_subsystem)
    output wire         dcs_latch_we,
    output wire [7:0]   dcs_latch_data,
    output wire         dcs_run,

    // status
    output wire [7:0]   cpu_fault,
    output wire [23:0]  cpu_pc,
    output reg  [63:0]  instructions,
    output reg          ext_unmapped_seen,
    output reg          int0_seen,
    // r10 status page 2 (interrupts / TEST): {INT0 pulses raised by the raster [15:0], INT0 vector reads [15:0],
    // INT3 pulses raised minus INT3 vector reads [15:0], {2'b0, GIE, IE0, IE3, IF0, IF3, 1'b0, 0x991060 reads with
    // TEST (bit 4) low, saturating [7:0]}, the first such 0x991060 read value [15:0]}
    output wire [79:0]  irq_diag,
    // r11 render-budget page: 32-bit clock counters, each exported as bits [31:16] (1 LSB = 65,536 clocks = 1.31 ms at
    // 50 MHz; wraps after 85.9 s): {CPU enabled (core_ce), CPU blocked by the renderer, ... of which setup FSM active,
    // ... texel wait, ... framebuffer write wait, CPU blocked on V-unit / board I/O memory}
    output wire [95:0]  render_diag,
    // 2026-09-23 race-speed counters (status mirror words 11..14, see bandwidth/gm1/ladder/perf_counters.py):
    // {nframes_sum[31:0], frametime_last[31:0], iters[31:0], iters_ge3[31:0], rbusy_clk[63:0], render_wait_clk[63:0]}
    output wire [255:0] perf_diag,
    // 2026-09-23 r21 rumble: C31 writes to WHEELPOS (0x00EA78) and _MODE (0x00C8F5) (WHEEL.ASM NUWHEEL, ROM word 0xAFF2)
    output wire         rumble_pos_we, rumble_mode_we,
    // r23 FFB wheels: C31 write to the wheel board 0x995000 (midvunit.cpp wheel_board_w; data = rumble_data)
    output wire         wheel_board_we,
    // r24 family core: 0 Cruis'n USA, 1 Cruis'n World, 2 Off Road Challenge (gm1_family_io.sv); RTC for the PIC2 clock;
    // Cruis'n World bit_data_r reads CMOS through gm1_cmos_shadow's read port
    input  wire [1:0]   game,
    input  wire [64:0]  mister_rtc,
    output wire [12:0]  cmos_alt_addr,
    input  wire [31:0]  cmos_alt_q,
    output wire [31:0]  rumble_data
);
    // ================= C31 core =================
    // ladder rung 3 (read overlap, build/c31-garage-read-overlap-20260920): the core's read-ahead request feeds the tier.
    wire        c_read_ahead; wire [23:0] c_read_ahead_addr;
    wire        c_bus_valid, c_bus_write;
    wire [2:0]  c_bus_kind;
    wire [23:0] c_bus_addr;
    wire [31:0] c_bus_wdata;
    wire        c_bus_ready;
    wire [31:0] c_bus_rdata;
    wire        retire, retire_fault, core_guest_step;
    wire [23:0] retire_pc;
    wire [31:0] retire_cyc;
    wire        core_ce;

    wire        core_at_sample;                // stage 2: the core's interrupt sample state (c31_guest_gate)
    wire [15:0] core_sample_cyc;               // stage 5c: H1 of the instruction retiring in a fused sample clock
    wire        core_fuse_allow;               // stage 5c: the gate allows a fused boundary this clock
    wire        c_f_valid, c_f_accept, c_f_rsp_valid;   // stage 4b: lookahead fetch port (c31_memory_fp)
    wire [23:0] c_f_addr;
    wire [31:0] c_f_rdata;
    wire [32*36-1:0] core_snap_state;          // live architectural state (VECTORS.md order); r10 reads ST/IE/IF
    reg reset_q;
    always @(posedge clk) reset_q <= reset;
    wire boot_load = reset_q && !reset;            // first clock out of reset: load PC = RMEM(0), registers zero

    c31_core u_core (
        .clk(clk), .rst(reset), .ce(core_ce),
        .read_ahead_valid(c_read_ahead), .read_ahead_addr(c_read_ahead_addr),
        .bus_valid(c_bus_valid), .bus_kind(c_bus_kind), .bus_write(c_bus_write),
        .bus_addr(c_bus_addr), .bus_wdata(c_bus_wdata), .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata),
        .retire(retire), .retire_pc(retire_pc), .retire_cyc(retire_cyc), .retire_fault(retire_fault),
        .guest_step(core_guest_step), .at_sample(core_at_sample),
        .sample_now(), .sample_cyc(core_sample_cyc), .fuse_allow(core_fuse_allow),
        .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
        .irq_level({7'd0, irq_int3, 2'b00, irq_int0}), .fault_code(cpu_fault),
        .load_en(boot_load), .load_pc(boot_pc), .load_state(1152'd0),
        .snap_pc(cpu_pc), .snap_state(core_snap_state)
    );

    // ================= memory tier =================
    wire        ext_valid, ext_write;
    wire [23:0] ext_addr;
    wire [31:0] ext_wdata;
    wire        ext_ready;
    wire [31:0] ext_rdata;
    wire        guest_pause;

    // Memory tier = lane C2 (bandwidth/gm1/rtl/mem_c2/, byte-identical to build/c31-mem-20260915T174441674155Z; the
    // G2 full-system lockstep ran it; its unit fit infers the page store: 4,022 ALM / 295 RAM blocks). Lane C3's
    // set-associative cache with streaming page bursts is not used: in its unit fit Quartus inferred none of the four
    // per-way page memories (declared inside a generate loop) and mapped 2.3M registers (2026-09-15). C2 fills a page
    // with single-word SDRAM reads, so the burst request is never raised.
    // 2026-09-22 ladder rung 1 (burst refill, on the 9/20 02:51 closing base): the P3 tier now fills a page with an
    // SDRAM burst (build/c31-garage-burst-20260920 memory files), so its sd_burst drives the port instead of 0.
    // Garage100k G2: 529,918 -> 455,713 clocks (-14.0%), bit-exact (H:\temp\cruisinusa\ladder-base0251-burst).
    // Stage 4b: the P3 tier with its fetch port exposed (c31_memory_fp = the gated c31_bus_adapter + c31_memory_p3; the
    // core's data-port fetches install their page in the fetch port's page map).
    // ladder rung 3: READ_OVERLAP=0. With it on, the first-read preissue ran core decode (ir) -> read_ahead_addr -> the
    // 172-way main-cache tag compare -> page-RAM clock enable in one clock: Slow 100C -7.824 ns
    // (build/gm1-quartus-20260922T153625410917000Z). Garage100k 410,587 (on) vs 425,098 (off) vs rung 2 436,715.
    c31_memory_fp #(.READ_OVERLAP(0), .NUM_MAIN_PAGES(NUM_MAIN_PAGES), .NUM_ROM_PAGES(NUM_ROM_PAGES)) u_mem (
        .clk(clk), .ce(1'b1), .rst(reset),
        .read_ahead_valid(c_read_ahead && core_ce), .read_ahead_addr(c_read_ahead_addr),
        .bus_valid(c_bus_valid), .bus_write(c_bus_write), .bus_fetch(c_bus_kind == 3'd0),
        .bus_addr(c_bus_addr), .bus_wdata(c_bus_wdata),
        .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata), .guest_pause(guest_pause),
        .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
        .sd_req(sd_req), .sd_burst(sd_burst), .sd_we(sd_we), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sd_ack), .sd_rdata(sd_rdata),
        .ext_valid(ext_valid), .ext_write(ext_write), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
        .ext_ready(ext_ready), .ext_rdata(ext_rdata),
        .nvram_protected(),
        .stat_main_hits(), .stat_main_misses(), .stat_rom_hits(), .stat_rom_misses(), .stat_pause_clocks(),
        .stat_fetch_accepts(), .stat_fetch_rejects(), .stat_fetch_stale()
    );

    // ================= ext sub-decode (tests/c31/g2/tb_c31_g2.sv) =================
    wire is_vunit = (ext_addr == 24'h600000 && ext_write) ||
                    (ext_addr >= 24'h900000 && ext_addr <= 24'h97ffff) ||
                    (ext_addr >= 24'ha00000 && ext_addr <= 24'hbfffff) ||
                    (ext_addr >= 24'h9e0000 && ext_addr <= 24'h9e7fff) ||
                    (ext_addr >= 24'h980020 && ext_addr <= 24'h98002b && (ext_write || ext_addr == 24'h980020)) ||
                    ext_addr == 24'h980000 || ext_addr == 24'h980040 || ext_addr == 24'h980041 ||
                    ext_addr == 24'h980080 || ext_addr == 24'h980082 || ext_addr == 24'h980083;
    wire is_io    = (ext_addr >= 24'h997000 && ext_addr <= 24'h997008) ||
                    ext_addr == 24'h990000 || ext_addr == 24'h991030 || ext_addr == 24'h991050 ||
                    ext_addr == 24'h991060 || ext_addr == 24'h992000 || ext_addr == 24'h993000;
    wire is_periph = ext_addr == 24'h808020 || ext_addr == 24'h808024 || ext_addr == 24'h808028 ||
                     ext_addr == 24'h808030 || ext_addr == 24'h808034 || ext_addr == 24'h808038 ||
                     ext_addr == 24'h808064 || ext_addr == 24'h994000 || ext_addr == 24'h995000 ||
                     ext_addr == 24'h9a0000;

    // ================= r24 family board I/O (Cruis'n World / Off Road Challenge; game 0 claims nothing) =================
    wire        fam_hit, fam_ready, fam_wait;
    wire [31:0] fam_rdata;
    gm1_family_io u_family (.clk(clk), .reset(reset), .game(game),
        .bus_valid(ext_valid), .bus_write(ext_write), .bus_sync(ext_sync), .bus_addr(ext_addr), .bus_wdata(ext_wdata),
        .hit(fam_hit), .ready(fam_ready), .rdata(fam_rdata), .guest_wait(fam_wait),
        .cabinet_in1(cabinet_in1), .mister_rtc(mister_rtc), .cmos_rd_addr(cmos_alt_addr), .cmos_rd_q(cmos_alt_q));
    // ADC (0x993000): MAME m_adc_shift = 16 for crusnwld / offroadc (midvunit.cpp:2218, :2236), 24 for crusnusa
    wire        fam_adc   = (game != 2'd0) && (ext_addr == 24'h993000);
    // control_w (0x994000): crusnwld_control_w has the DCS reset on bit 11 (midvunit.cpp:251), control_w on bit 1
    wire        fam_ctrl  = (game != 2'd0) && (ext_addr == 24'h994000);
    wire [31:0] io_wdata  = fam_adc ? {ext_wdata[23:16], ext_wdata[23:0]} : ext_wdata;
    wire [31:0] p_wdata   = fam_ctrl ? {ext_wdata[31:2], ext_wdata[11], ext_wdata[0]} : ext_wdata;

    // ================= guest time =================
    wire               vunit_mem_wait, io_mem_wait, guest_calc_wait;
    wire               render_hold = (RENDER_HOLDS_GUEST != 0) && guest_calc_wait;   // r16: 0 in the shipped core
    wire               guest_tick_en;
    wire [NOW_BITS-1:0] now;
    wire [15:0]        h1_owed;
    wire               ext_sync;
    // Stage 2 (2026-09-18): c31_guest_gate (rtl/c31/periph/c31_guest_gate.sv, HORIZON=1). The core runs ahead of guest
    // time; it waits at its interrupt sample only while an interrupt edge could still be generated by the H1 it owes
    // (event_lb: vunit_raster INT0, vunit_board_io INT3 -- the only interrupt sources wired, irq_level below), and every
    // non-memory access (ext_sync) completes only with nothing owed, so it sees now == T as before. The first owed H1
    // is paid in the retire clock (r12). Gate G1i runs the same module in both modes and requires identical interrupt
    // instruction sequences.
    wire [23:0] int0_event_lb, int3_event_lb;
`ifdef GM1_SERIAL_GUEST_GATE
    // Simulation reference only (bandwidth/gm1/tests/run_gm1_sim.py --define GM1_SERIAL_GUEST_GATE): the r12 serial
    // gating on otherwise identical sources, so a FRAMES run can require the horizon build's interrupt entries, frames
    // and milestones to match it exactly. Never defined for synthesis.
    localparam integer GUEST_HORIZON = 0;
`else
    localparam integer GUEST_HORIZON = 1;
`endif
    c31_guest_gate #(.NOW_BITS(NOW_BITS), .HORIZON(GUEST_HORIZON), .EXTRA_EVENT(1), .REAL_TIME(GUEST_REAL_TIME)) u_gate (
        .clk(clk), .rst(reset), .retire(retire), .retire_cyc(retire_cyc[15:0]), .at_sample(core_at_sample),
        .sample_cyc(core_sample_cyc), .fuse_allow(core_fuse_allow),
        .event_lb(int0_event_lb), .event_lb_extra(int3_event_lb), .step_allow(run_enable && !vunit_mem_wait && !io_mem_wait),
        .render_stall(render_hold),
        .core_ce(core_ce), .ext_sync(ext_sync), .guest_tick_en(guest_tick_en), .now(now), .h1_owed(h1_owed)
    );
    assign guest_tick = {{(64-NOW_BITS){1'b0}}, now};

    wire guest_video_ce;
    cusa_video_ce u_video_ratio (.clk(clk), .reset(reset), .guest_step(guest_tick_en), .video_ce(guest_video_ce));

    // ================= V-unit video board =================
    wire [7:0]  render_attr;                   // r11 observation: {setup active, row buffered, span attribution}
    wire        vb_ready;
    wire [31:0] vb_rdata;
    wire        vb_bus_ce = ext_valid && is_vunit && bus_run_enable && !render_hold && ext_sync;

    vunit_board #(.QUEUE_DEPTH(VUNIT_QUEUE_DEPTH), .WIDTH(WIDTH), .HEIGHT(HEIGHT),
                  .PRIVATE_TEXTURE_SERVICE(PRIVATE_TEXTURE_SERVICE), .FACTORED_CAPTURE_WAIT(0),
                  .REGISTER_VIEW(REGISTER_VIEW)) u_video (
        .clk(clk), .reset(reset), .guest_ce(guest_tick_en), .video_ce(guest_video_ce), .bus_ce(vb_bus_ce),
        .capture_wait_intent(1'b0),
        .req_valid(ext_valid && is_vunit), .req_ready(vb_ready), .req_write(ext_write),
        .req_addr(ext_addr), .req_wdata(ext_wdata), .req_rdata(vb_rdata),
        .fb_valid(fb_valid), .fb_ready(fb_ready), .fb_addr(fb_addr), .fb_data(fb_data),
        .fb_pair(fb_pair), .fb_data_hi(fb_data_hi),
        .tex_req_valid(tex_req_valid), .tex_req_ready(tex_req_ready), .tex_req_addr(tex_req_addr),
        .tex_req_prefetch(tex_req_prefetch), .tex_rsp_valid(tex_rsp_valid), .tex_rsp_ready(tex_rsp_ready),
        .tex_rsp_data(tex_rsp_data), .tex_req_pair(tex_req_pair), .tex_req_off2(tex_req_off2),
        .tex_rsp_data2(tex_rsp_data2), .tex_req_tag(tex_req_tag), .tex_rsp_tag(tex_rsp_tag),
        .cpu_mem_req_valid(cpu_mem_req_valid), .cpu_mem_req_ready(cpu_mem_req_ready),
        .cpu_mem_req_write(cpu_mem_req_write), .cpu_mem_req_region(cpu_mem_req_region),
        .cpu_mem_req_addr(cpu_mem_req_addr), .cpu_mem_req_wdata(cpu_mem_req_wdata),
        .cpu_mem_req_be(cpu_mem_req_be), .cpu_mem_rsp_valid(cpu_mem_rsp_valid),
        .cpu_mem_rsp_ready(cpu_mem_rsp_ready), .cpu_mem_rsp_rdata(cpu_mem_rsp_rdata),
        .display_page(display_page), .write_page(write_page), .queue_nonempty(queue_nonempty),
        .renderer_busy(renderer_busy), .queue_full(queue_full),
        .guest_memory_wait(vunit_mem_wait), .guest_calculation_wait(guest_calc_wait),
        .guest_fb_offer(guest_fb_offer), .guest_tex_offer(guest_tex_offer),
        .fault_sticky(vunit_fault),
        .raster_x(raster_x), .raster_y(raster_y), .raster_de(raster_de),
        .hsync(hsync), .vsync(vsync), .csync(csync), .pixel_event(pixel_event),
        .frame_event(frame_event), .irq_int0(irq_int0), .palette_epoch(palette_epoch),
        .source_restart(source_restart), .render_attr(render_attr), .int0_event_lb(int0_event_lb)
    );
    assign guest_memory_wait = vunit_mem_wait || io_mem_wait;

    // ================= board I/O (inputs, ADC, comm) =================
    wire        io_ready, io_mem_wait_b;
    wire [31:0] io_rdata, io_rdata_b;
    assign io_rdata    = (fam_adc && io_rdata_b != 32'hffffffff) ? {8'd0, io_rdata_b[31:24], 16'd0} : io_rdata_b;
    assign io_mem_wait = io_mem_wait_b || fam_wait;
    wire        io_bus_ce = ext_valid && is_io && !fam_hit && bus_run_enable && !render_hold && ext_sync;
    wire        control_write = ext_valid && ext_ready && ext_write && (ext_addr == 24'h994000);

    vunit_board_io #(.ADC_CONVERSION_GUEST_STEPS(ADC_CONVERSION_GUEST_STEPS)) u_io (
        .clk(clk), .reset(reset), .guest_ce(guest_tick_en), .bus_ce(io_bus_ce),
        .req_valid(ext_valid && is_io && !fam_hit && ext_sync), .req_write(ext_write),
        .req_addr(ext_addr), .req_wdata(io_wdata),
        .address_hit(), .access_supported(), .req_ready(io_ready), .req_rdata(io_rdata_b),
        .guest_memory_wait(io_mem_wait_b),
        .control_update(control_write), .control_data(ext_wdata[15:0]),
        .cabinet_in0(cabinet_in0), .cabinet_in1(cabinet_in1), .cabinet_switch2(cabinet_switch2),
        .cabinet_dips(cabinet_dips), .adc_channels(adc_channels), .irq_int3(irq_int3), .int3_event_lb(int3_event_lb),
        .cmos_protected(), .system_control(), .comm_data(), .comm_flags()
    );

    // ================= peripherals (timers, bus control, wheel latch, DCS wires) =================
    wire        p_ready;
    wire [31:0] p_rdata;

    c31_peripherals #(.NOW_BITS(NOW_BITS)) u_periph (
        .clk(clk), .ce(1'b1), .rst(reset),
        .bus_valid(ext_valid && is_periph && ext_sync), .bus_write(ext_write), .bus_addr(ext_addr), .bus_wdata(p_wdata),
        .bus_ready(p_ready), .bus_rdata(p_rdata),
        .now(now),
        .dcs_data(dcs_latch_data), .dcs_data_valid(dcs_latch_we), .dcs_data_tick(),
        .dcs_reset(dcs_run), .dcs_reset_strobe(), .dcs_reset_tick(),
        .wheel_motor(), .wheel_lamps(), .wheel_sound_bus(),
        .bus_control()
    );

    // ================= ext response mux =================
    // Stage 2: no non-memory access completes while guest time is still owed (c31_guest_gate ext_sync).
    assign ext_ready = ext_sync && (fam_hit  ? fam_ready :
                                    is_vunit ? vb_ready :
                                    is_io    ? io_ready :
                                    is_periph ? p_ready :
                                    ext_valid);   // unmapped: complete at once with 0 (flagged)
    assign ext_rdata = fam_hit  ? fam_rdata :
                       is_vunit ? vb_rdata :
                       is_io    ? io_rdata :
                       is_periph ? p_rdata : 32'd0;

    // ================= r10 interrupt / TEST diagnostics (status page 2) =================
    // The gm1 r9 cabinet session froze at the attract "SET" frame and after race select with the CPU running and no
    // fault; the cause was INT0 pulses lost between the core's boundary samples (fixed in c31_core, gate
    // scripts/check_c31_irq.py). These counters show it on silicon: raised vs taken INT0 (the C31 reads the vector
    // at line+1 = 0x000001 only on an interrupt entry), the same balance for INT3 (vector 0x000004), the CPU's
    // GIE/IE/IF bits, and what the game read from SWITCH1 (0x991060) whenever the TEST/Enter bit (4) was low -- the
    // original source enters diagnostics on a TEST edge (CUSA.ASM:975-979, 1068-1082), which is what kicked the user
    // out of a game at START on r7 and r9.
    reg [15:0] d_int0_gen, d_int0_taken, d_int3_gen, d_int3_taken, d_sw1_capture;
    reg [7:0]  d_sw1_low_reads;
    reg        d_int0_q, d_int3_q;
    always @(posedge clk) begin
        if (reset) begin
            d_int0_gen <= 16'd0; d_int0_taken <= 16'd0; d_int3_gen <= 16'd0; d_int3_taken <= 16'd0;
            d_sw1_capture <= 16'd0; d_sw1_low_reads <= 8'd0; d_int0_q <= 1'b0; d_int3_q <= 1'b0;
        end else begin
            d_int0_q <= irq_int0; d_int3_q <= irq_int3;
            if (irq_int0 && !d_int0_q) d_int0_gen <= d_int0_gen + 16'd1;
            if (irq_int3 && !d_int3_q) d_int3_gen <= d_int3_gen + 16'd1;
            if (c_bus_valid && c_bus_ready && !c_bus_write && c_bus_kind == 3'd1) begin
                if (c_bus_addr == 24'h000001) d_int0_taken <= d_int0_taken + 16'd1;
                if (c_bus_addr == 24'h000004) d_int3_taken <= d_int3_taken + 16'd1;
            end
            if (ext_valid && ext_ready && !ext_write && ext_addr == 24'h991060 && !ext_rdata[4]) begin
                if (d_sw1_low_reads == 8'd0) d_sw1_capture <= ext_rdata[15:0];
                if (d_sw1_low_reads != 8'hff) d_sw1_low_reads <= d_sw1_low_reads + 8'd1;
            end
        end
    end
    // ================= r11 render-budget counters (status page 3) =================
    // The r9 cabinet measured 12.9-20 clocks per instruction in 3D scenes against 6.47 in the POST window. These split
    // that wall time: clocks the CPU is enabled, and clocks the CPU is held because the renderer is calculating (the
    // pacer's render_stall: guest ticks stop, h1_owed stays non-zero, core_ce stays low) broken down by what the
    // renderer is doing -- polygon setup (priority), waiting for a texel, waiting for a framebuffer write (both DDR3).
    // Plus clocks the CPU is held on V-unit / board I/O memory access (vunit_cpu_memory, CMOS).
    reg [31:0] t_cpu, t_stall, t_setup, t_texel, t_fb, t_memblk;
    // Stage 2: the core can run while H1 is owed, so "held" is now literally "core enable low".
    wire       cpu_held = !core_ce;
    always @(posedge clk) begin
        if (reset) begin
            t_cpu <= 32'd0; t_stall <= 32'd0; t_setup <= 32'd0; t_texel <= 32'd0; t_fb <= 32'd0; t_memblk <= 32'd0;
        end else begin
            if (core_ce) t_cpu <= t_cpu + 32'd1;
            if (cpu_held && guest_calc_wait) begin
                t_stall <= t_stall + 32'd1;
                if (render_attr[7])                                        t_setup <= t_setup + 32'd1;
                else if (render_attr[5:0] == 6'd41 || render_attr[5:0] == 6'd42) t_texel <= t_texel + 32'd1;
                else if (render_attr[5:0] == 6'd43)                        t_fb    <= t_fb + 32'd1;
            end
            if (cpu_held && !guest_calc_wait && (vunit_mem_wait || io_mem_wait)) t_memblk <= t_memblk + 32'd1;
        end
    end
    assign render_diag = {t_cpu[31:16], t_stall[31:16], t_setup[31:16], t_texel[31:16], t_fb[31:16], t_memblk[31:16]};

    // ================= 2026-09-23 race-speed counters (status mirror words 11..14) =================
    // render_wait: the CPU is in the game's renderer-busy poll (0x980082 bit0 then bit1, CUSA main loop 0x4BD1-0x4C1C):
    // set by a poll read that returns busy, cleared by one that returns idle. rbusy: renderer busy or polygons queued.
    // NFRAMES (0x00C95F) is written once per loop iteration (2 = on pace, >= 3 = a missed vblank); FRAMETIME (0x00C966)
    // is the C31 timer count at the flip.
    reg [63:0] p_rwait, p_rbusy; reg [31:0] p_iters, p_ge3, p_nfsum, p_ftlast; reg p_rwait_on;
    wire p_poll = ext_valid && ext_ready && !ext_write && (ext_addr == 24'h980082 || ext_addr == 24'h980083);
    wire p_cwr  = c_bus_valid && c_bus_ready && c_bus_write;
    always @(posedge clk) begin
        if (reset) begin
            p_rwait <= 64'd0; p_rbusy <= 64'd0; p_iters <= 32'd0; p_ge3 <= 32'd0; p_nfsum <= 32'd0; p_ftlast <= 32'd0;
            p_rwait_on <= 1'b0;
        end else begin
            if (p_poll) p_rwait_on <= (ext_rdata[1:0] != 2'b00);
            if (p_rwait_on) p_rwait <= p_rwait + 64'd1;
            if (renderer_busy || queue_nonempty) p_rbusy <= p_rbusy + 64'd1;
            if (p_cwr && c_bus_addr == 24'h00c95f) begin
                p_iters <= p_iters + 32'd1; p_nfsum <= p_nfsum + c_bus_wdata;
                if (c_bus_wdata >= 32'd3) p_ge3 <= p_ge3 + 32'd1;
            end
            if (p_cwr && c_bus_addr == 24'h00c966) p_ftlast <= c_bus_wdata;
        end
    end
    assign perf_diag = {p_nfsum, p_ftlast, p_iters, p_ge3, p_rbusy, p_rwait};
    assign rumble_pos_we  = p_cwr && c_bus_addr == 24'h00ea78;
    assign rumble_mode_we = p_cwr && c_bus_addr == 24'h00c8f5;
    assign wheel_board_we = p_cwr && c_bus_addr == 24'h995000;
    assign rumble_data    = c_bus_wdata;

    wire [31:0] snap_st = core_snap_state[32*29 +: 32], snap_ie = core_snap_state[32*30 +: 32],
                snap_if = core_snap_state[32*31 +: 32];
    assign irq_diag = {d_int0_gen, d_int0_taken, d_int3_gen - d_int3_taken,
                       2'b00, snap_st[13], snap_ie[0], snap_ie[3], snap_if[0], snap_if[3], 1'b0, d_sw1_low_reads,
                       d_sw1_capture};

    always @(posedge clk) begin
        if (reset) begin
            instructions <= 64'd0; ext_unmapped_seen <= 1'b0; int0_seen <= 1'b0;
        end else begin
            if (retire) instructions <= instructions + 64'd1;
            if (ext_valid && !(fam_hit || is_vunit || is_io || is_periph)) ext_unmapped_seen <= 1'b1;
            if (irq_int0) int0_seen <= 1'b1;
        end
    end
endmodule
`default_nettype wire
