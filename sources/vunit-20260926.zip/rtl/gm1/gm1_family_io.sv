// SPDX-License-Identifier: GPL-2.0-or-later
// gm1_family_io -- the board I/O that Cruis'n World and Off Road Challenge add to the V-unit (gm1 family core, 2026-09-23).
// Gospel: MAME 0.289 williams/midvunit.cpp (segamodel1/references/mame-mame0289):
//   offroadc_map / crusnwld_map (:697-714):
//     0x991030 R  crusnwld_serial_status_r: in1 = (IN1 & 0x7fff) | (pic.status_r() << 15); returns in1 | in1 << 16
//     0x996000 R  crusnwld_serial_data_r:   pic.read() << 16            (no side effect)
//     0x996000 W  crusnwld_serial_data_w:   pic.write(data >> 16)
//   crusnwld_map only:
//     0x9d0000-0x9d1fff R  bit_data_r: bit = BIT(bit_data[idx >> 5], ~idx & 0x1f); idx = (idx + 1) & 0x1ff;
//                                      return bit ? nvram[offset] : ~nvram[offset]   (all 16 table words 0x3017c636)
//     0x9d0000 W           bit_reset_w: idx = 0
//   PIC2 = MIDWAY_SERIAL_PIC2 (midwayic.cpp), crusnwld upper 450 / offroadc upper 230, yearoffs 94, year = GAME() line;
//   serial bytes (generate_serial_data :73-121) checked against both games' own cold-boot reads by
//   bandwidth/gm1/family/pic2_serial_golden.py (MATCH, rand pair F2 BE from the logs).
// game: 0 Cruis'n USA (this module claims nothing), 1 Cruis'n World, 2 Off Road Challenge.
// The CMOS read for bit_data comes from gm1_cmos_shadow's second read port (the BRAM mirror of CMOS), 1-clock registered.
`default_nettype none
module gm1_family_io #(
    parameter int CLK_HZ = 50_000_000
) (
    input  wire        clk,
    input  wire        reset,
    input  wire [1:0]  game,
    input  wire        bus_valid, bus_write, bus_sync,
    input  wire [23:0] bus_addr,
    input  wire [31:0] bus_wdata,
    output wire        hit,
    output wire        ready,
    output reg  [31:0] rdata,
    output wire        guest_wait,
    input  wire [15:0] cabinet_in1,
    input  wire [64:0] mister_rtc,          // hps_io RTC: BCD sec, min, hour, mday, month, year%100, binary weekday
    output reg  [12:0] cmos_rd_addr,        // gm1_cmos_shadow second read port
    input  wire [31:0] cmos_rd_q
);
    function automatic [127:0] serial_data(input integer upper, input integer year);
        reg [127:0] v; integer sn, t, s0, s1, s2, s3, s4, s5, s6, s7, s8; reg [7:0] r12, r13;
        begin
            r12 = 8'hf2; r13 = 8'hbe;            // MAME machine().rand() pair, identical in both games' cold-boot logs
            sn = 123450 + upper * 1000000 + 6;   // serial DIP default 6 (midwayic.cpp:46)
            s0 = (sn / 100000000) % 10; s1 = (sn / 10000000) % 10; s2 = (sn / 1000000) % 10;
            s3 = (sn / 100000) % 10;    s4 = (sn / 10000) % 10;    s5 = (sn / 1000) % 10;
            s6 = (sn / 100) % 10;       s7 = (sn / 10) % 10;       s8 = sn % 10;
            v = 128'd0;
            v[8*12 +: 8] = r12; v[8*13 +: 8] = r13;
            t = 32'h174 * (year - 1980) + 32'h1f * (12 - 1) + 11;
            v[8*10 +: 8] = t[15:8]; v[8*11 +: 8] = t[7:0];
            t = s4 + s7 * 10 + s1 * 100;
            t = (t + 5 * r13) * 32'h1bcd + 32'h1f3f0;
            v[8*7 +: 8] = t[7:0]; v[8*8 +: 8] = t[15:8]; v[8*9 +: 8] = t[23:16];
            t = s6 + s8 * 10 + s0 * 100 + s2 * 10000;
            t = (t + 2 * r13 + r12) * 32'h107f + 32'h71e259;
            v[8*3 +: 8] = t[7:0]; v[8*4 +: 8] = t[15:8]; v[8*5 +: 8] = t[23:16]; v[8*6 +: 8] = t[31:24];
            t = s5 * 10 + s3 * 100;
            t = (t + r12) * 32'h245 + 32'h3d74;
            v[8*0 +: 8] = t[7:0]; v[8*1 +: 8] = t[15:8]; v[8*2 +: 8] = t[23:16];
            serial_data = v;
        end
    endfunction
    localparam [127:0] SER_WORLD   = serial_data(450, 1996);
    localparam [127:0] SER_OFFROAD = serial_data(230, 1997);
    localparam [31:0]  BIT_DATA    = 32'h3017c636;

    wire fam      = (game == 2'd1) || (game == 2'd2);
    wire a_status = bus_addr == 24'h991030 && !bus_write;
    wire a_pic    = bus_addr == 24'h996000;
    wire a_bit    = game == 2'd1 && bus_addr >= 24'h9d0000 && bus_addr <= 24'h9d1fff;
    assign hit    = fam && (a_status || a_pic || a_bit);
    wire bit_rd   = a_bit && !bus_write;

    // bit_data read: capture the CMOS index, the shadow answers 2 clocks later (address register + RAM register)
    reg        pend; reg [1:0] age;
    wire       reply = pend && age == 2'd2;
    assign ready      = hit && (!bit_rd || reply);
    assign guest_wait = bus_valid && hit && bit_rd && !reply;
    wire       accepted = bus_valid && bus_sync && ready;

    // PIC2
    wire [15:0] pic_q;
    reg  [8:0]  bit_idx;
    // MiSTer RTC -> MAME's clock bytes (make_bcd of sec, min, hour, weekday+1, mday, month+1, year-1900-94)
    wire [3:0] ylo = mister_rtc[43:40], yhi = mister_rtc[47:44];
    wire [4:0] ylo6 = {1'b0, ylo} + 5'd6;
    wire [7:0] year_b = (ylo6 >= 5'd10) ? {yhi + 4'd1, ylo6[3:0] - 4'd10} : {yhi, ylo6[3:0]};
    wire [7:0] rtc [7];
    assign rtc[0] = mister_rtc[7:0];   assign rtc[1] = mister_rtc[15:8];  assign rtc[2] = mister_rtc[23:16];
    assign rtc[3] = {4'd0, mister_rtc[51:48] + 4'd1};                     // tm_wday 0..6 -> 1..7
    assign rtc[4] = mister_rtc[31:24]; assign rtc[5] = mister_rtc[39:32]; assign rtc[6] = year_b;
    gm1_pic2 #(.CLK_HZ(CLK_HZ)) u_pic2 (.clk(clk), .rst(reset), .ser(game == 2'd1 ? SER_WORLD : SER_OFFROAD),
        .pic_wr(accepted && a_pic && bus_write), .pic_wdata(bus_wdata[23:16]),
        .pic_rd(accepted && a_status), .pic_rdata(pic_q), .rtc(rtc));

    always @* begin
        rdata = 32'd0;
        if (a_status) rdata = {pic_q[8], cabinet_in1[14:0], pic_q[8], cabinet_in1[14:0]};
        else if (a_pic) rdata = {8'd0, pic_q[7:0], 16'd0};
        else if (bit_rd) rdata = BIT_DATA[~bit_idx[4:0]] ? cmos_rd_q : ~cmos_rd_q;
    end

    always @(posedge clk) begin
        if (reset) begin
            pend <= 1'b0; age <= 2'd0; bit_idx <= 9'd0; cmos_rd_addr <= 13'd0;
        end else begin
            if (bus_valid && fam && bit_rd && !pend) begin pend <= 1'b1; age <= 2'd0; cmos_rd_addr <= bus_addr[12:0]; end
            else if (pend && age != 2'd2) age <= age + 2'd1;
            if (accepted && bit_rd) begin pend <= 1'b0; bit_idx <= bit_idx + 9'd1; end
            if (accepted && a_bit && bus_write && bus_addr == 24'h9d0000) bit_idx <= 9'd0;
        end
    end
endmodule
`default_nettype wire
