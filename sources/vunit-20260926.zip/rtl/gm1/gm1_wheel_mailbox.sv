`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_wheel_mailbox -- RELEASE form of the DDR3 status mirror: the r23 WHEEL MAILBOX only (2026-09-25, r28 area relief).
// gm1_status_mirror.sv (the full diagnostic block + this mailbox) is compiled instead only in cabinet diagnostic builds
// (gm1_core.sv selects; quartus/prepare.sh --diag). This module is the mailbox half of that file, unchanged in behaviour:
//   * ONE 64-bit single-beat write to BASE + 128 (0x38700080) = {MAGIC_W "gm1W" 32'h676d3157, seq[23:0], motor[7:0]}.
//     Little-endian in DDR3: the 32-bit word at 0x38700080 is {seq, motor}, the word at 0x38700084 is the magic -- what
//     ffb/gm1_ffb.c reads (MIRROR_PHYS 0x38700000, MB_WORD 0x80/4, MAGIC_W; gm1_ffb.c:35-37, 149-158).
//   * seq advances by one on EVERY wheel-board motor write (gm1_wheel_motor motor_we), published or not; the newest
//     motor byte is published as soon as the port is free, so bursts coalesce and the last write is always published
//     (the daemon only needs seq to CHANGE while the game drives the wheel; stale 500 ms = release, gm1_ffb.c:38, 164).
//   * the offered command is held unchanged until waitrequest drops (the avalon_shared_mux faults otherwise); updates
//     arriving meanwhile go to the live seq/motor registers and publish on the next write.
//   * nothing is written before the first motor write, and only while `enable` (DDR configured) is high.
// It never touches BASE..BASE+127 (the diagnostic block area), so the ARM perf logger simply finds no block magic.
// Gate: bandwidth/gm1/ladder/diag_mirror/check_wheel_mailbox.py (gm1_ffb.c decoder + cycle-exact differential against
// gm1_status_mirror's mailbox + mutants).
module gm1_wheel_mailbox #(
    parameter [31:0] BASE = 32'h38700000
) (
    input  wire         clk,
    input  wire         por,
    input  wire         enable,
    input  wire         wheel_motor_we,
    input  wire [7:0]   wheel_motor,
    // mux client (CAPTURE)
    output reg          write,
    output wire [31:0]  address,
    output wire [63:0]  writedata,
    output wire [7:0]   byteenable,
    output wire [3:0]   burstcount,
    input  wire         waitrequest
);
    localparam [31:0] MAGIC_W = 32'h676d3157;   // "gm1W"
    assign byteenable = 8'hff;
    assign burstcount = 4'd1;
    assign address    = BASE + 32'd128;

    reg        wpend;           // an update is waiting to be published
    reg [7:0]  wmot;            // newest motor byte
    reg [23:0] wseq;            // motor writes seen
    reg [31:0] wout;            // the offered {seq, motor}, frozen while the write is in flight
    assign writedata = {MAGIC_W, wout};

    always @(posedge clk) begin
        if (por) begin
            write <= 1'b0; wpend <= 1'b0; wmot <= 8'd0; wseq <= 24'd0; wout <= 32'd0;
        end else begin
            if (write) begin
                if (!waitrequest) write <= 1'b0;
            end else if (wpend && enable) begin
                wpend <= 1'b0; write <= 1'b1; wout <= {wseq, wmot};
            end
            if (wheel_motor_we) begin wpend <= 1'b1; wmot <= wheel_motor; wseq <= wseq + 24'd1; end
        end
    end
endmodule
`default_nettype wire
