// SPDX-License-Identifier: GPL-2.0-or-later
// gm1_cmos_shadow -- NVRAM save path for the Cruis'n gm1 core (r23, 2026-09-23).
// The game's CMOS (C31 0x9c0000-0x9c1fff, 8192 x 32 bits) lives in board SDRAM. MiSTer saves NVRAM by reading the core
// through hps_io's upload port (Main_MiSTer support/arcade/mra_loader.cpp arcade_nvm_save: index = the MRA <nvram>
// index, size bytes, 16-bit words with WIDE=1), and it needs each word within one HPS bus transfer -- too tight for an
// SDRAM read during a race. So this block keeps a BRAM copy written alongside EVERY CMOS write (loader seed / saved-NVRAM
// stream / all-ones fresh fill, and C31 stores after the loader finished), and the upload reads the copy. Nothing here
// is on the C31's CMOS read path.
// File format = the MRA seed = a MAME nvram image: word i little-endian at byte 4*i (halfword 0 = bits 15:0).
// Save requests (hps_io latches the rising edge; Main services it while the OSD is open, menu.cpp MENU_GENERIC_MAIN2):
//   * save_trigger rising edge (OSD "Save NVRAM"), or
//   * automatic: the game changed CMOS and then left it alone for QUIET clocks (debounced, so a game that writes
//     CMOS continuously never floods Main with requests -- the Gladiator save-loop lesson).
// dirty clears when an upload starts; a write during/after the upload sets it again.
`default_nettype none
module gm1_cmos_shadow #(
    parameter [31:0] QUIET = 32'd100_000_000       // 2 s at 50 MHz
) (
    input  wire        clk,
    input  wire        reset,                      // power-on reset
    // gm1_loader -> gm1_sdram loader port (SDRAM byte address; CMOS = 0x1100000-0x1107fff)
    input  wire        l_req, l_ack,
    input  wire [24:0] l_baddr,
    input  wire [31:0] l_wdata,
    // c31_memory -> gm1_sdram port (C31 word address; CMOS = 0x9c0000-0x9c1fff, gm1_sdram map_word)
    input  wire        sd_req, sd_we, sd_ack,
    input  wire [23:0] sd_addr,
    input  wire [31:0] sd_wdata,
    input  wire        ioctl_upload,
    // r24 family: Cruis'n World bit_data_r (gm1_family_io) reads CMOS through the SAME read port (one M10K copy, not two);
    // the save upload (OSD open) and that boot-time protection read never overlap, ioctl_upload selects
    input  wire [12:0] alt_rd_addr,
    output wire [31:0] alt_rd_q,
    input  wire [26:0] ioctl_addr,                 // byte address, steps by 2 (WIDE=1)
    output wire [15:0] ioctl_din,
    input  wire        save_trigger,               // OSD toggle/trigger bit (level)
    output reg         upload_req,                 // one-clock pulse to hps_io
    output reg         dirty
);
    // each CMOS write counted once, at its ack; only C31 writes mark the image dirty (loader writes are the load)
    wire l_we = l_req && l_ack && (l_baddr[24:15] == 10'h220);
    wire c_we = sd_req && sd_we && sd_ack && (sd_addr[23:13] == 11'h4e0);
    wire        we    = l_we || c_we;
    wire [12:0] widx  = l_we ? l_baddr[14:2] : sd_addr[12:0];
    wire [31:0] wdata = l_we ? l_wdata : sd_wdata;
    wire        track_dirty = c_we;
    reg [31:0] mem [0:8191];
    reg [31:0] q;
    reg        we_q; reg [12:0] widx_q; reg [31:0] wdata_q; reg dirty_ev_q;
    always @(posedge clk) begin                     // input register: keeps the source compare off this RAM's path
        we_q <= we; widx_q <= widx; wdata_q <= wdata; dirty_ev_q <= we && track_dirty;
        if (we_q) mem[widx_q] <= wdata_q;
        q <= mem[ioctl_upload ? ioctl_addr[14:2] : alt_rd_addr];
    end
    assign ioctl_din = ioctl_addr[1] ? q[31:16] : q[15:0];
    assign alt_rd_q  = q;

    reg [31:0] quiet_cnt;
    reg        trig_q, upl_q, auto_armed;
    always @(posedge clk) begin
        if (reset) begin
            dirty <= 1'b0; quiet_cnt <= 32'd0; trig_q <= 1'b0; upl_q <= 1'b0; auto_armed <= 1'b0; upload_req <= 1'b0;
        end else begin
            trig_q <= save_trigger; upl_q <= ioctl_upload;
            upload_req <= 1'b0;
            if (dirty_ev_q) begin
                dirty <= 1'b1; quiet_cnt <= 32'd0; auto_armed <= 1'b1;
            end else begin
                if (ioctl_upload && !upl_q) dirty <= 1'b0;
                if (auto_armed && quiet_cnt != QUIET) quiet_cnt <= quiet_cnt + 32'd1;
                if (auto_armed && quiet_cnt == QUIET) begin auto_armed <= 1'b0; upload_req <= dirty; end
            end
            if (save_trigger && !trig_q) upload_req <= 1'b1;
        end
    end
endmodule
`default_nettype wire
