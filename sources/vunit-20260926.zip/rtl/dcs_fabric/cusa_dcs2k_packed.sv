// Cruis'n USA DCS Audio 2K wrapper (PACKED core), fabric variant.
//
// Differs from tunit_dcs2k.sv (donor) in the host ABI, which is Cruis'n's:
//   * data latch:  C31 write 0x9A0000 -> data_w(data & 0xff) (midvunit.cpp:265-268).
//                  We feed host_cmd_data = {8'h00, host_data[7:0]} on host_data_wr;
//                  the core raises ADSP IRQ2 + SET_INPUT_FULL (dcs.cpp:1503-1520).
//   * reset:       0x994000 bit 1 -> reset_w(BIT(control,1)) (midvunit.cpp:237-238);
//                  active-HIGH run (dcs.cpp:1456-1471). Here dcs_run is a SEPARATE
//                  level input = control[1], NOT a bit of the data write (that is the
//                  T-unit ABI). Not inverted (that is midxunit/RevX, P0020).
//   * no host read path: Cruis'n never reads DCS status/output (write-only), so the
//                  host_status/host_response/host_resp_rd read ports are tied off.
//   * mono audio out (midvunit.cpp:1206), 31.25 kHz, gated by dcs_run.
//
// Clock scheme: ADSP on clk (P0019-clean). r21 (2026-09-24, "electric shock" fix): the core clock enable is now EVERY
// clock. The donor ran this FSM on a 1-in-2 enable of an 80 MHz clock (40 MHz effective) and states its throughput
// floor as >= ~31 MHz of enable (3.05 clk/instr vs the real ADSP-2105's 10 MIPS, adsp2105_packed.sv:48-55). Cruis'n's
// single 50 MHz clock with the inherited 1-in-2 enable gave 25 MHz = ~7.4-7.8 MIPS, below that floor. MEASURED
// (MAME 0.289 crusnusa44 race, ADSP trace): with the engine sound running the firmware's per-half-buffer loop (fill +
// command/voice work, PM 0x117..0x157..0x117) retires up to 64.7k instructions per 7.68 ms half buffer (84% of 76.8k at
// 10 MIPS); at 7.4-7.8 MIPS it overruns, the firmware then always refills the SAME half (its I7 wait, PM 0x117-0x125,
// only catches the next crossing) and the other half replays stale for seconds = a 65 Hz buzz. MAME's DAC stream has
// zero stale half-buffers in the same window. Full-rate enable = ~15 MIPS. Timing: every DCS register is now a
// single-cycle 20 ns path (the gm1 SDC CE multicycle is removed; the MSTAT bank-select exception becomes 3/2).
// Gate: scripts/check_dcs_race_deadline.py (MUT_CE_DIV2 restores the old enable and must fail it).
`default_nettype none
module cusa_dcs2k_packed #(
  parameter EXT_ROM = 1,
  parameter PF_LINES = 512
)(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        dac_ce_31250,   // 31.25 kHz sample-slot enable
  input  wire logic        host_data_wr,   // 1-clk strobe: C31 wrote 0x9A0000
  input  wire logic [7:0]  host_data,      // the 8-bit sound byte (data & 0xff)
  input  wire logic        dcs_run,        // level = control[1] (1=run, 0=reset), active-high

  output logic             rom_req,
  output logic [19:0]      rom_addr,
  input  wire logic        rom_ready,
  input  wire logic [63:0] rom_rdata,

  output logic signed [15:0] audio,
  output logic             audio_ce,
  output logic             audio_underrun,
  output logic             audio_overrun,
  output logic [13:0]      adsp_pc,
  output logic             adsp_valid,
  output logic             adsp_unimplemented,
  // r20: host command FIFO counters (dcs_host_fifo.sv): bytes that waited behind a FULL latch, bytes dropped
  output logic [31:0]      host_waits,
  output logic [31:0]      host_overflow
);
  logic core_ce, core_phase;
  logic host_cmd_w;
  logic [15:0] host_cmd_data;
  logic [15:0] host_status, host_response;   // unused (write-only board)
  logic dac_pending;
  logic [15:0] dac_sample;
  logic dac_strobe;

`ifdef MUT_CE_DIV2
  assign core_ce    = core_phase;   // MUTATION: the pre-r21 1-in-2 enable (25 MHz effective, below the throughput floor)
`else
  assign core_ce    = 1'b1;         // r21: full-rate core (see header)
`endif
  // r20: bytes come from dcs_host_fifo, offered only while the ADSP input latch reads EMPTY (host_status bit 11).
  logic       fifo_offer;
  logic [7:0] fifo_data;
  assign host_cmd_w    = core_ce && fifo_offer;
  assign host_cmd_data = {8'h00, fifo_data};
  dcs_host_fifo u_host_fifo (.clk(clk), .flush(rst || !dcs_run), .push(host_data_wr), .push_data(host_data),
      .latch_empty(host_status[11]), .deliver_ack(host_cmd_w), .offer(fifo_offer), .offer_data(fifo_data),
      .waits(host_waits), .overflow(host_overflow));
  assign audio      = dcs_run ? $signed(dac_sample) : 16'sd0;
  assign audio_ce   = dcs_run && dac_strobe;

  // Reset polarity: core held in reset while !dcs_run (active-high run). The
  // reset-release edge starts the bank-0 boot inside the core.
`ifdef MUT_RST_INV
  wire core_rst = rst || dcs_run;     // MUTATION (c): inverted reset polarity
`else
  wire core_rst = rst || !dcs_run;
`endif

  always_ff @(posedge clk) begin
    if (rst) begin
      core_phase       <= 1'b0;
      dac_pending      <= 1'b0;
    end else begin
      core_phase <= ~core_phase;
      if (!dcs_run) begin
        dac_pending      <= 1'b0;
      end else begin
        if (core_ce && dac_pending)      dac_pending      <= 1'b0;
        if (dac_ce_31250) dac_pending <= 1'b1;
      end
    end
  end

  adsp2105_packed #(
    .DCS_2K(1), .EXT_ROM(EXT_ROM), .PF_LINES(PF_LINES), .PRELOAD_PM(0), .CORE_CE_EN(1)
  ) cpu (
    .clk(clk), .rst(core_rst), .core_ce(core_ce), .host_rst(1'b0),
    .host_cmd_w(host_cmd_w), .host_cmd_data(host_cmd_data),
    .host_status_r(host_status), .host_response_r(host_response), .host_resp_rd(1'b0),
    .rom_ddr_req(rom_req), .rom_ddr_addr(rom_addr),
    .rom_ddr_rdy(rom_ready), .rom_ddr_q(rom_rdata),
    .dac_ce_in(core_ce && dac_pending),
    .o_ppc(adsp_pc), .o_valid(adsp_valid), .o_unimpl(adsp_unimplemented),
    .dac_sample(dac_sample), .dac_ce(dac_strobe),
    .audio_underrun(audio_underrun), .audio_overrun(audio_overrun)
  );
endmodule
`default_nettype wire
