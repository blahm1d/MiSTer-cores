`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// cusa_dcs_subsystem.sv -- Cruis'n USA fabric DCS sound board (no ARM). Standard MiSTer arcade
// wiring: hps_io ioctl (WIDE=1) delivers the DCS sound ROM (index DCS_IOCTL_INDEX = 2, the eight
// u2..u9 ROMs concatenated, 4 MiB) which this subsystem stores in HPS DDR3, and the packed DCS-2K
// core reads it back over a DDR3-shaped port while producing signed 16-bit mono audio at 31.25 kHz.
//
// Blocks:
//   cusa_dcs_rom_loader  ioctl index 2 -> FIFO -> 16-bit stream + P0022 capture audit (por domain)
//   cusa_dcs_ddr_agent   16-bit stream -> DDR store; core beat requests -> DDR reads / ERASEFF gap
//                        (one avalon_shared_mux client, bw1 signature; por domain)
//   cusa_dcs2k_packed    packed ADSP-2105 DCS-2K core (1-in-2 CE), core_reset domain
//
// Reset domains (doctrine section 6): the loader + DDR agent (the capture path + the loaded DDR
// content) run on `por` (power-on reset) so the ROM lands even though MiSTer Main holds core_reset
// high across the ioctl download (P0022). The DCS core runs on `core_reset` (it reboots on a warm
// reset and re-reads the still-resident DDR store). The control wires dcs_latch_we/dcs_latch_data
// (C31 write to 0x9A0000) and dcs_run (0x994000 bit 1, active-high run) come from c31_peripherals.
module cusa_dcs_subsystem #(
    parameter [31:0] DCS_DDR_BASE    = 32'h3900_0000,  // 4 MiB DCS ROM window (above the video region)
    parameter [31:0] EXPECTED_BYTES  = 32'h0040_0000,  // 4 MiB
    parameter [7:0]  DCS_IOCTL_INDEX = 8'd2
) (
    input  wire        clk,           // 50 MHz core clock
    input  wire        por,           // power-on reset (2-FF-synced ~locked); capture-path domain
    input  wire        core_reset,    // core/warm reset; DCS core reset + monitored by the loader
    input  wire        dac_ce_31250,  // 31.25 kHz sample-slot enable (top supplies 50e6/1600)

    // control wires from c31_peripherals
    input  wire        dcs_latch_we,      // C31 wrote 0x9A0000 (1-clk strobe)
    input  wire [7:0]  dcs_latch_data,    // the 8-bit sound byte (data & 0xff)
    input  wire        dcs_run,           // 0x994000 bit 1, active-high run

    // hps_io ioctl (WIDE=1)
    input  wire        ioctl_download,
    input  wire        ioctl_wr,
    input  wire [15:0] ioctl_index,
    input  wire [15:0] ioctl_dout,
    output wire        ioctl_wait,

    // DDRAM mux client (avalon; plug into avalon_shared_mux like the bw1 clients)
    output wire        client_read,
    output wire        client_write,
    output wire [31:0] client_address,
    output wire [63:0] client_writedata,
    output wire [7:0]  client_byteenable,
    output wire [3:0]  client_burstcount,
    input  wire        client_waitrequest,
    input  wire        client_readdatavalid,
    input  wire [63:0] client_readdata,
    input  wire        client_read_error,

    // audio out (signed 16-bit mono, 31.25 kHz)
    output wire signed [15:0] audio,
    output wire        audio_ce,       // sample strobe

    // status / audit
    output wire        rom_loaded,
    output wire [31:0] bytes_loaded,
    output wire [31:0] stream_crc,     // CRC-32 of the captured ioctl stream (expect 0x692a64fa)
    output wire [31:0] dropped_bytes,
    output wire [31:0] ddr_misses,     // populated DDR read transactions the ROM reader issued
    output wire [31:0] dac_underruns,
    output wire [31:0] host_waits,     // r20: host bytes that waited behind a FULL DCS input latch (dcs_host_fifo)
    output wire [31:0] host_overflow,  // r20: host bytes dropped by a full FIFO (should stay 0)
    output wire        reset_during_download,

    // core observability (lockstep / gate; tie off unused on the shipping top)
    output wire [13:0] dbg_adsp_pc,
    output wire        dbg_adsp_valid,
    output wire        dbg_adsp_unimpl
);
    // ---- loader -> agent 16-bit stream ----
    wire        ds_in_valid, ds_in_ready, ds_stream_end;
    wire [15:0] ds_in_data;
    wire [31:0] dropped_writes;

    // The loader (capture path) runs on `por` so the ROM lands while MiSTer Main holds core_reset
    // high across the download (P0022). SUBSYS_MUT_LOADER_CORERST wires it to core_reset instead:
    // then the reset-held-through-download freezes the capture path and nothing loads (D3 mutant).
`ifdef SUBSYS_MUT_LOADER_CORERST
    wire loader_por = core_reset;
`else
    wire loader_por = por;
`endif
    cusa_dcs_rom_loader #(
        .DCS_INDEX(DCS_IOCTL_INDEX), .EXPECTED_BYTES(EXPECTED_BYTES)
    ) loader (
        .clk(clk), .por(loader_por), .core_reset(core_reset),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr),
        .ioctl_index(ioctl_index), .ioctl_dout(ioctl_dout), .ioctl_wait(ioctl_wait),
        .dcs_in_valid(ds_in_valid), .dcs_in_data(ds_in_data), .dcs_in_ready(ds_in_ready),
        .dcs_stream_end(ds_stream_end),
        .dcs_seen(), .bytes_loaded(bytes_loaded), .stream_crc(stream_crc),
        .accepted_writes(), .dropped_writes(dropped_writes),
        .reset_during_download(reset_during_download));

    assign dropped_bytes = {dropped_writes[30:0], 1'b0};   // words -> bytes

    // ---- packed DCS core DDR beat port ----
    wire        rom_ddr_req, rom_ddr_rdy;
    wire [19:0] rom_ddr_addr;
    wire [63:0] rom_ddr_q;

    cusa_dcs_ddr_agent #(
        .DCS_DDR_BASE(DCS_DDR_BASE), .EXPECTED_BYTES(EXPECTED_BYTES)
    ) agent (
        .clk(clk), .por(por),
        .in_valid(ds_in_valid), .in_data(ds_in_data), .in_ready(ds_in_ready),
        .stream_end(ds_stream_end),
        .rom_ddr_req(rom_ddr_req), .rom_ddr_addr(rom_ddr_addr),
        .rom_ddr_rdy(rom_ddr_rdy), .rom_ddr_q(rom_ddr_q),
        .rom_loaded(rom_loaded), .ddr_reads(ddr_misses),
        .client_read(client_read), .client_write(client_write), .client_address(client_address),
        .client_writedata(client_writedata), .client_byteenable(client_byteenable),
        .client_burstcount(client_burstcount), .client_waitrequest(client_waitrequest),
        .client_readdatavalid(client_readdatavalid), .client_readdata(client_readdata),
        .client_read_error(client_read_error));

    // ---- packed DCS-2K core (core_reset domain, 1-in-2 CE) ----
    wire        au_underrun, au_overrun;
    cusa_dcs2k_packed core (
        .clk(clk), .rst(core_reset), .dac_ce_31250(dac_ce_31250),
        .host_data_wr(dcs_latch_we), .host_data(dcs_latch_data), .dcs_run(dcs_run),
        .rom_req(rom_ddr_req), .rom_addr(rom_ddr_addr),
        .rom_ready(rom_ddr_rdy), .rom_rdata(rom_ddr_q),
        .audio(audio), .audio_ce(audio_ce),
        .audio_underrun(au_underrun), .audio_overrun(au_overrun),
        .adsp_pc(dbg_adsp_pc), .adsp_valid(dbg_adsp_valid), .adsp_unimplemented(dbg_adsp_unimpl),
        .host_waits(host_waits), .host_overflow(host_overflow));

    // ---- DAC underrun event counter (por domain, cumulative) ----
    reg [31:0] underruns;
    reg        au_q;
    always @(posedge clk) begin
        if (por) begin underruns <= 32'd0; au_q <= 1'b0; end
        else begin
            au_q <= au_underrun;
            if (au_underrun && !au_q) underruns <= underruns + 32'd1;
        end
    end
    assign dac_underruns = underruns;
endmodule
`default_nettype wire
