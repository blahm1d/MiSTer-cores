// dcs_host_fifo -- host->DCS command-byte elastic buffer (Cruis'n r20, 2026-09-23).
//
// The V-unit host interface is WRITE-ONLY (midvunit.cpp:265-268, :689): the C31 writes command bytes to 0x9A0000 about
// 1.2 us apart (SND.ASM SENDSND: 30 NOPs, "blowing the specified timings ... to save time") and never reads DCS status.
// The DCS input latch is single (dcs.cpp:1503-1520: m_input_data = data), so a byte that arrives before the firmware has
// read the previous one OVERWRITES it. The real ADSP (SRAM, never stalls) and MAME (which boosts interleave on every host
// write) always read in time; our fabric ADSP can stall on DDR3 sound-ROM reads for microseconds and lose a byte,
// garbling the command. This FIFO holds bytes while the latch is still FULL and presents the next one only when the
// latch reads EMPTY (latch_control bit 11, set by the firmware's read, dcs.cpp:186). When the ADSP keeps up, the byte
// stream and its one-IRQ2-per-byte timing are unchanged. Flushed while the DCS is held in reset (the game never sends
// during a DCS reset: SENDSND returns while IN_RESET_MODE).
//   waits    : bytes that arrived while the latch was full or bytes were queued (would have been overwritten before r20)
//   overflow : bytes dropped because the FIFO itself was full (should stay 0)
`default_nettype none
module dcs_host_fifo #(
    parameter integer DEPTH_LOG2 = 4                // 16 bytes
) (
    input  wire        clk,
    input  wire        flush,                       // DCS reset: drop everything
    input  wire        push,                        // host wrote a byte (1-clk strobe)
    input  wire [7:0]  push_data,
    input  wire        latch_empty,                 // ADSP latch_control bit 11 (1 = firmware has read the latch)
    input  wire        deliver_ack,                 // the core accepted the offered byte this clock (core_ce && offer)
    output wire        offer,                       // a byte is offered to the core
    output wire [7:0]  offer_data,
    output reg  [31:0] waits,
    output reg  [31:0] overflow
);
    localparam integer DEPTH = 1 << DEPTH_LOG2;
    reg [7:0] mem [0:DEPTH-1];
    reg [DEPTH_LOG2:0] wr, rd;                      // one extra bit: full vs empty
    wire [DEPTH_LOG2:0] count = wr - rd;
    wire empty = (count == 0);
    wire full  = (count == DEPTH);
    // Offer the head only while the latch reads EMPTY. No settling guard is needed: the core accepts a byte only on a
    // core_ce clock (cpu_ce == core_ce, adsp2105_packed.sv:150) and flips latch_control to FULL on that same edge (the host
    // write wins over a same-clock firmware read, :2557-2569); the next accept opportunity is the next core_ce, two clocks
    // later, when latch_empty is already 0. (A guard register here was provably redundant -- its mutant was unkillable.)
    assign offer = !empty && latch_empty;
    assign offer_data = mem[rd[DEPTH_LOG2-1:0]];
    always @(posedge clk) begin
        if (flush) begin
            wr <= 0; rd <= 0;
        end else begin
            if (push) begin
                if (full) overflow <= overflow + 32'd1;
                else begin
                    mem[wr[DEPTH_LOG2-1:0]] <= push_data; wr <= wr + 1'b1;
                    if (!latch_empty || !empty) waits <= waits + 32'd1;
                end
            end
            if (deliver_ack) rd <= rd + 1'b1;
        end
    end
    initial begin waits = 0; overflow = 0; end
endmodule
`default_nettype wire
