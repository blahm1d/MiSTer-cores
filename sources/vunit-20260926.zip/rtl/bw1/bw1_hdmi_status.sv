`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// bw1_hdmi_status.sv -- simple readable HDMI status (requirement 5). 640x480@~60 (pixel clock
// = clk/2). Top region: 13 vertical bars, one per test id, colored gray=not run, yellow=running
// (current), green=pass, red=fail (from done_mask/pass_mask/cur_test). A small SDRAM-size meter
// (lit cells = size_mb/32) sits above. Bottom region: one wide B7 capture-audit bar, green when
// the ROM landed with no dropped writes and no reset-during-download, else red. A gentle
// heartbeat blink shows the core is alive.
module bw1_hdmi_status (
    input  wire        clk,           // 50 MHz (CLK_VIDEO)
    input  wire        reset,
    input  wire [15:0] done_mask, pass_mask,
    input  wire [7:0]  cur_test,
    input  wire [63:0] heartbeat,
    input  wire [7:0]  sdram_mb,
    input  wire        audit_ok,      // B7: md landed && !reset_during_download && dropped==0
    input  wire        audit_valid,   // B7 has been finalized
    output reg         ce_pixel, de, hs, vs,
    output reg  [7:0]  r, g, b
);
    // 640x480@60 (VGA): H 640+16+96+48=800, V 480+10+2+33=525
    reg [9:0] hc; reg [9:0] vc; reg ce;
    reg [5:0] col; reg [5:0] colpix;   // 16 columns of 40 px
    always @(posedge clk) begin
        if (reset) begin hc<=0; vc<=0; ce<=0; end
        else begin
            ce<=~ce;
            if (ce) begin
                if (hc==10'd799) begin hc<=0; if (vc==10'd524) vc<=0; else vc<=vc+1; end
                else hc<=hc+1;
            end
        end
    end
    // per-pixel column tracker
    always @(posedge clk) begin
        if (reset) begin col<=0; colpix<=0; end
        else if (ce) begin
            if (hc==10'd799) begin col<=0; colpix<=0; end
            else if (colpix==6'd39) begin colpix<=0; col<=col+1; end
            else colpix<=colpix+1;
        end
    end

    wire active = (hc<10'd640) && (vc<10'd480);
    wire [4:0] tid = {1'b0,col[3:0]} + 5'd1;         // col 0 -> test 1
    wire in_gap = (colpix>=6'd36) || (col>=6'd13);   // gaps between bars / spare columns
    wire top_region = (vc<10'd340);
    wire meter_region = (vc>=10'd350) && (vc<10'd380);
    wire audit_region = (vc>=10'd400) && (vc<10'd470);
    wire [7:0] blink = heartbeat[23] ? 8'h20 : 8'h10;

    // test-bar color
    reg [7:0] tr,tg,tb;
    always @* begin
        tr=8'h20; tg=8'h20; tb=8'h20; // default gray
        if (col<6'd13) begin
            if ({3'd0,cur_test[4:0]}==tid)      begin tr=8'hd0; tg=8'hd0; tb=8'h10; end // running=yellow
            else if (pass_mask[tid[3:0]])       begin tr=8'h10; tg=8'hc0; tb=8'h20; end // pass=green
            else if (done_mask[tid[3:0]])       begin tr=8'hd0; tg=8'h10; tb=8'h10; end // fail=red
            else                                begin tr=8'h30; tg=8'h30; tb=8'h30; end // not run=gray
        end
    end
    // sdram size meter: lit cells = size_mb/32 (1=32MB,2=64MB,4=128MB); show up to 4 cells
    wire [2:0] meter_cells = (sdram_mb>=8'd128)?3'd4:(sdram_mb>=8'd64)?3'd2:(sdram_mb>=8'd32)?3'd1:3'd0;
    wire meter_lit = (col < {3'd0,meter_cells}) && (col<6'd13) && !in_gap;

    always @(posedge clk) begin
        ce_pixel<=ce;
        de<=active;
        hs<=~((hc>=10'd656)&&(hc<10'd752));
        vs<=~((vc>=10'd490)&&(vc<10'd492));
        if (!active) begin r<=0; g<=0; b<=0; end
        else if (meter_region) begin
            if (meter_lit) begin r<=8'h20; g<=8'h60; b<=8'hf0; end else begin r<=blink; g<=blink; b<=blink; end
        end else if (top_region) begin
            if (in_gap) begin r<=blink; g<=blink; b<=blink; end
            else begin r<=tr; g<=tg; b<=tb; end
        end else if (audit_region) begin
            if (!audit_valid) begin r<=8'h40; g<=8'h40; b<=8'h10; end        // amber: not finalized
            else if (audit_ok)  begin r<=8'h10; g<=8'hc0; b<=8'h20; end        // green
            else                begin r<=8'hd0; g<=8'h10; b<=8'h10; end        // red
        end else begin r<=blink; g<=blink; b<=blink; end
    end
endmodule
`default_nettype wire
