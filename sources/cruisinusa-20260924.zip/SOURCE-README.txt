Cruis'n USA - r26 (whole game in FPGA)
RBF SHA-256: 56d70e253a245ba22237c53a557d976dfa09763225ee6cb853eea34f714a0b2f

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: cruisinusa-gm1-r26
The compiled binary's validation status is recorded in the feed catalog.
