# Root and PLL clocks are declared by sys/sys_top.sdc.
#
# Both 6809s are mc6809i instances driven by E and Q clock enables on the
# 103.8336 MHz master clock: the main CPU's bus cycle is 64 clocks, the sound
# CPU's 128.  Every mc6809i register is enable-gated (direct_enable on cen_E /
# cen_Q), so a path launched from a CPU register has at least 63 clocks before
# the next enable, and the CPU only samples its data input on the E enable,
# ~60 clocks after the address settled.  The r4 STA (single-cycle everywhere
# outside the CPU) measured the core clock at 64.5 MHz with -5.9 ns worst
# setup through the CPU's combinational next-address logic into the address
# decode, RAM ports and the registered data-in mux.
#
# Constraints below relax:
#   * CPU register -> CPU register (E->E, Q->Q) by 16 cycles (Gladiator scheme)
#   * CPU register -> anything else by 8 cycles (address/decode/RAM/din settle)
#   * data-in register -> CPU registers by 8 cycles (D is sampled on E only)
# Everything else (E/Q enable pulses, write strobes, interrupt samplers, the
# video and sound pipelines) keeps single-cycle timing.

set main_all [get_registers -nowarn {*mc6809i:main_cpu|*}]
set main_q   [get_registers -nowarn {*mc6809i:main_cpu|last_NMISample2 *mc6809i:main_cpu|last_wNMIClear *mc6809i:main_cpu|NMILatched *mc6809i:main_cpu|NMISample *mc6809i:main_cpu|IRQSample *mc6809i:main_cpu|FIRQSample *mc6809i:main_cpu|HALTSample *mc6809i:main_cpu|DMABREQSample}]
set main_e   [remove_from_collection $main_all $main_q]
set main_din [get_registers -nowarn {*chiller_main_bus:main_bus|cpu_din*}]

set_multicycle_path -setup 16 -from $main_e -to $main_e
set_multicycle_path -hold  15 -from $main_e -to $main_e
set_multicycle_path -setup 16 -from $main_q -to $main_q
set_multicycle_path -hold  15 -from $main_q -to $main_q
set_multicycle_path -setup 8 -from $main_all
set_multicycle_path -hold  7 -from $main_all
set_multicycle_path -setup 8 -from $main_din -to $main_all
set_multicycle_path -hold  7 -from $main_din -to $main_all

set snd_all [get_registers -nowarn {*mc6809i:cpu|*}]
set snd_q   [get_registers -nowarn {*mc6809i:cpu|last_NMISample2 *mc6809i:cpu|last_wNMIClear *mc6809i:cpu|NMILatched *mc6809i:cpu|NMISample *mc6809i:cpu|IRQSample *mc6809i:cpu|FIRQSample *mc6809i:cpu|HALTSample *mc6809i:cpu|DMABREQSample}]
set snd_e   [remove_from_collection $snd_all $snd_q]
set snd_din [get_registers -nowarn {*chiller_sound:sound|cpu_din*}]

set_multicycle_path -setup 16 -from $snd_e -to $snd_e
set_multicycle_path -hold  15 -from $snd_e -to $snd_e
set_multicycle_path -setup 16 -from $snd_q -to $snd_q
set_multicycle_path -hold  15 -from $snd_q -to $snd_q
set_multicycle_path -setup 8 -from $snd_all
set_multicycle_path -hold  7 -from $snd_all
set_multicycle_path -setup 8 -from $snd_din -to $snd_all
set_multicycle_path -hold  7 -from $snd_din -to $snd_all

# Slow-changing board registers that only feed CPU-side address decode: bank
# select, scanline window row and the palette I/O bank change on a CPU write
# and are consumed by the CPU 48+ clocks later.
set slow_regs [get_registers -nowarn {*chiller_video:video|rom_bank* *chiller_video:video|scanline_sel* *chiller_video:video|pal_io*}]
set_multicycle_path -setup 8 -from $slow_regs
set_multicycle_path -hold  7 -from $slow_regs

# Cascaded-RAM address registers whose data is consumed two or more clocks
# later: the scan-out addresses (data used at phase 2+ of a 12-clock pixel),
# the sample-ROM fetch address (data taken two clocks after issue), and the
# renderer's image-RAM address.
set scan_addr [get_registers -nowarn {*chiller_video:video|vram_scan_addr* *chiller_video:video|lb_scan_addr*}]
set_multicycle_path -setup 2 -from $scan_addr
set_multicycle_path -hold  1 -from $scan_addr
set fetch_addr [get_registers -nowarn {*chiller_sound:sound|sample_addr*}]
set_multicycle_path -setup 2 -from $fetch_addr
set_multicycle_path -hold  1 -from $fetch_addr
