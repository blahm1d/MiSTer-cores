// True dual-port RAM, one clock, "new data" read-during-write on a written
// port.  This is the Intel recommended template kept in its own module so
// Quartus infers ONE BIDIR_DUAL_PORT M10K array; the same template written
// inline next to other memories was split into a SINGLE_PORT plus a
// DUAL_PORT copy (r3 map: vram_rtl_0/_1, pal_*_rtl_0/_1).
// Contents power up to zero (MAME's RAM state; the M10K after configuration).
module chiller_dpram #(
    parameter AW = 8,
    parameter DW = 8
) (
    input  logic          clk,
    input  logic [AW-1:0] addr_a,
    input  logic [DW-1:0] din_a,
    input  logic          we_a,
    output logic [DW-1:0] q_a,
    input  logic [AW-1:0] addr_b,
    input  logic [DW-1:0] din_b,
    input  logic          we_b,
    output logic [DW-1:0] q_b
);
    localparam DEPTH = 1 << AW;
    localparam INNER = (DEPTH > 4096) ? 4096 : DEPTH;     // Quartus caps a loop at 5000 iterations
    localparam OUTER = DEPTH / INNER;

    (* ramstyle = "M10K, no_rw_check" *) logic [DW-1:0] mem [0:DEPTH-1];
    initial for (int i = 0; i < OUTER; i++)
        for (int j = 0; j < INNER; j++) mem[i * INNER + j] = '0;

    always_ff @(posedge clk) begin
        if (we_a) begin
            mem[addr_a] <= din_a;
            q_a <= din_a;
        end else
            q_a <= mem[addr_a];
    end

    always_ff @(posedge clk) begin
        if (we_b) begin
            mem[addr_b] <= din_b;
            q_b <= din_b;
        end else
            q_b <= mem[addr_b];
    end
endmodule
