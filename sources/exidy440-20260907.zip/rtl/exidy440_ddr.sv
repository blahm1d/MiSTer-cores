// HPS DDR3 agent for the CVSD sample ROM (128 KiB at byte 0x30000000).
//
// MiSTer DDRAM contract (sys_top / f2sdram): DDRAM_ADDR indexes 64-bit beats,
// DDRAM_RD / DDRAM_WE are sampled on a clock with DDRAM_BUSY low, DDRAM_BE is
// the byte-enable mask for a write, and read data returns with
// DDRAM_DOUT_READY (BURSTCNT 1 -> one beat).  Same pattern as the Y-unit
// stv_vram_ddr_agent and the NES/Genesis ddram.v wrappers.
//
// Writes come from the ROM download one byte at a time; wr_busy holds the
// ioctl stream (ioctl_wait) while a write waits for the bus.  Reads serve the
// MC6844 fetch engine: rd_req pulses with a 17-bit byte offset, rd_ack pulses
// with the byte.  Never reset by the core reset: the download runs while the
// core is held in reset (the P0022 trap), so only the power-on reset applies.
module exidy440_ddr #(
    parameter [28:0] BASE_BEAT = 29'h06000000     // byte 0x30000000 >> 3
) (
    input  logic        clk,
    input  logic        por,

    input  logic        wr_req,
    input  logic [16:0] wr_addr,
    input  logic [7:0]  wr_data,
    output logic        wr_busy,

    input  logic        rd_req,
    input  logic [16:0] rd_addr,
    output logic        rd_ack,
    output logic [7:0]  rd_data,

    output logic        DDRAM_CLK,
    input  logic        DDRAM_BUSY,
    output logic [7:0]  DDRAM_BURSTCNT,
    output logic [28:0] DDRAM_ADDR,
    input  logic [63:0] DDRAM_DOUT,
    input  logic        DDRAM_DOUT_READY,
    output logic        DDRAM_RD,
    output logic [63:0] DDRAM_DIN,
    output logic [7:0]  DDRAM_BE,
    output logic        DDRAM_WE
);
    assign DDRAM_CLK      = clk;
    assign DDRAM_BURSTCNT = 8'd1;

    logic        wr_pend, rd_pend, rd_wait;
    logic [16:0] wr_addr_q, rd_addr_q;
    logic [7:0]  wr_data_q;
    logic [2:0]  rd_lane;

    assign wr_busy = wr_pend;

    always_ff @(posedge clk) begin
        rd_ack <= 1'b0;
        if (por) begin
            wr_pend  <= 1'b0;
            rd_pend  <= 1'b0;
            rd_wait  <= 1'b0;
            DDRAM_RD <= 1'b0;
            DDRAM_WE <= 1'b0;
        end else begin
            if (wr_req) begin
                wr_pend   <= 1'b1;
                wr_addr_q <= wr_addr;
                wr_data_q <= wr_data;
            end
            if (rd_req) begin
                rd_pend   <= 1'b1;
                rd_addr_q <= rd_addr;
            end

            if (!DDRAM_BUSY) begin
                DDRAM_RD <= 1'b0;
                DDRAM_WE <= 1'b0;
                if (wr_pend && !DDRAM_WE && !DDRAM_RD) begin
                    DDRAM_ADDR <= BASE_BEAT + {12'd0, wr_addr_q[16:3]};
                    DDRAM_DIN  <= {8{wr_data_q}};
                    DDRAM_BE   <= 8'd1 << wr_addr_q[2:0];
                    DDRAM_WE   <= 1'b1;
                    wr_pend    <= 1'b0;
                end else if (rd_pend && !rd_wait && !DDRAM_WE && !DDRAM_RD) begin
                    DDRAM_ADDR <= BASE_BEAT + {12'd0, rd_addr_q[16:3]};
                    DDRAM_BE   <= 8'hFF;
                    DDRAM_RD   <= 1'b1;
                    rd_lane    <= rd_addr_q[2:0];
                    rd_pend    <= 1'b0;
                    rd_wait    <= 1'b1;
                end
            end

            if (rd_wait && DDRAM_DOUT_READY) begin
                rd_data <= DDRAM_DOUT[8 * rd_lane +: 8];
                rd_ack  <= 1'b1;
                rd_wait <= 1'b0;
            end
        end
    end
endmodule
