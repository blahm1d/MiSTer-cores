// Exidy 440 board (Crossbow .. Showdown family): the two 6809s, ROM/RAM,
// video, sound.  No MiSTer dependencies except the DDR3 port for the sample
// ROM; the emu wrapper is an appliance layer.
module chiller_board (
    input  logic        clk,            // 77.8752 MHz
    input  logic        reset,
    input  logic        por,            // power-on reset only (download path)

    // Game profile byte (MRA index 1), see exidy440_profile.sv
    input  logic [3:0]  game,

    // ROM download (MiSTer ioctl index 0), see chiller_roms for the layout
    input  logic        dl_wr,
    input  logic [19:0] dl_addr,
    input  logic [7:0]  dl_data,
    output logic        dl_busy,        // hold ioctl while a DDR3 write waits

    // Cabinet
    input  logic        trigger,
    input  logic        start,
    input  logic [1:0]  coin_n,
    input  logic [7:0]  aux_btn,
    input  logic [7:0]  dial,
    input  logic [3:0]  dip_in0,
    input  logic [7:0]  dip_in1,
    input  logic [7:0]  gun_x,          // 0..255 across the 320 active pixels
    input  logic [7:0]  gun_y,          // 0..255 across the 240 active lines
    output logic        coin_counter,

    // EEROM host port
    input  logic        nvram_host_enable,
    input  logic        nvram_host_write,
    input  logic [12:0] nvram_host_address,
    input  logic [7:0]  nvram_host_data_in,
    output logic [7:0]  nvram_host_data_out,

    // HPS DDR3 (sample ROM)
    output logic        DDRAM_CLK,
    input  logic        DDRAM_BUSY,
    output logic [7:0]  DDRAM_BURSTCNT,
    output logic [28:0] DDRAM_ADDR,
    input  logic [63:0] DDRAM_DOUT,
    input  logic        DDRAM_DOUT_READY,
    output logic        DDRAM_RD,
    output logic [63:0] DDRAM_DIN,
    output logic [7:0]  DDRAM_BE,
    output logic        DDRAM_WE,

    // Video
    output logic        ce_pix,
    output logic [7:0]  red,
    output logic [7:0]  green,
    output logic [7:0]  blue,
    output logic        hblank,
    output logic        vblank,
    output logic        hsync,
    output logic        vsync,
    output logic [8:0]  raster_h,
    output logic [8:0]  raster_v,

    // Audio
    output logic signed [15:0] audio_l,
    output logic signed [15:0] audio_r,

    // Debug taps
    output logic [15:0] debug_main_addr,
    output logic        debug_main_op,
    output logic        debug_main_rd,
    output logic        debug_main_wr,
    output logic [7:0]  debug_main_dout,
    output logic [7:0]  debug_main_din,
    output logic [15:0] debug_snd_addr,
    output logic        debug_snd_op,
    output logic        debug_snd_rd,
    output logic        debug_snd_wr,
    output logic        debug_render_overrun,
    output logic [3:0]  debug_dma_active
);
    logic ce_main_e, ce_main_q, ce_snd_e, ce_snd_q, ce_cvsd, ce_cvsd_half;
    chiller_clock_enables clocks (
        .clk(clk), .reset(reset),
        .ce_pix(ce_pix),
        .ce_main_e(ce_main_e), .ce_main_q(ce_main_q),
        .ce_snd_e(ce_snd_e), .ce_snd_q(ce_snd_q),
        .ce_cvsd(ce_cvsd), .ce_cvsd_half(ce_cvsd_half)
    );

    // ------------------------------------------------------------------
    // ROMs: program in M10K, samples in DDR3
    // ------------------------------------------------------------------
    logic [14:0] rom_fixed_addr;
    logic [7:0]  rom_fixed_data, rom_bank_data, snd_rom_data, sample_data;
    logic [13:0] rom_bank_offset;
    logic [3:0]  rom_bank;
    logic [12:0] snd_rom_addr;
    logic [16:0] sample_addr, sample_dl_addr;
    logic        sample_req, sample_ack, sample_dl_wr;

    chiller_roms roms (
        .clk(clk),
        .dl_wr(dl_wr), .dl_addr(dl_addr), .dl_data(dl_data),
        .sample_dl_wr(sample_dl_wr), .sample_dl_addr(sample_dl_addr),
        .main_fixed_addr(rom_fixed_addr), .main_fixed_data(rom_fixed_data),
        .main_bank(rom_bank), .main_bank_offset(rom_bank_offset), .main_bank_data(rom_bank_data),
        .snd_addr(snd_rom_addr), .snd_data(snd_rom_data)
    );

    exidy440_ddr ddr (
        .clk(clk), .por(por),
        .wr_req(sample_dl_wr), .wr_addr(sample_dl_addr), .wr_data(dl_data), .wr_busy(dl_busy),
        .rd_req(sample_req), .rd_addr(sample_addr), .rd_ack(sample_ack), .rd_data(sample_data),
        .DDRAM_CLK(DDRAM_CLK), .DDRAM_BUSY(DDRAM_BUSY), .DDRAM_BURSTCNT(DDRAM_BURSTCNT),
        .DDRAM_ADDR(DDRAM_ADDR), .DDRAM_DOUT(DDRAM_DOUT), .DDRAM_DOUT_READY(DDRAM_DOUT_READY),
        .DDRAM_RD(DDRAM_RD), .DDRAM_DIN(DDRAM_DIN), .DDRAM_BE(DDRAM_BE), .DDRAM_WE(DDRAM_WE)
    );

    // ------------------------------------------------------------------
    // Main CPU
    // ------------------------------------------------------------------
    logic [15:0] m_addr;
    logic [7:0]  m_din, m_dout, video_din, yscroll;
    logic        m_rnw, m_avma, m_vma, m_op, m_rd, m_wr, m_irq_n, m_firq_n;
    logic        firq_vblank, firq_beam, vblank_irq;
    logic        snd_cmd_wr, snd_cmd_ack;
    logic [7:0]  snd_cmd_data;
    wire         topsecex = (game == 4'd6);

    always_ff @(posedge clk) begin
        if (reset)          m_vma <= 1'b0;
        else if (ce_main_e) m_vma <= m_avma;
    end

    mc6809i main_cpu (
        .D(m_din), .DOut(m_dout), .ADDR(m_addr), .RnW(m_rnw),
        .clk(clk), .cen_E(ce_main_e), .cen_Q(ce_main_q),
        .BS(), .BA(),
        .nIRQ(m_irq_n), .nFIRQ(m_firq_n), .nNMI(1'b1),
        .AVMA(m_avma), .BUSY(), .LIC(),
        .nHALT(1'b1), .nRESET(~reset), .nDMABREQ(1'b1),
        .OP(m_op), .RegData()
    );

    chiller_main_bus main_bus (
        .clk(clk), .reset(reset), .ce_e(ce_main_e), .game(game),
        .cpu_addr(m_addr), .cpu_dout(m_dout), .cpu_rnw(m_rnw), .cpu_vma(m_vma),
        .cpu_din(m_din), .cpu_rd(m_rd), .cpu_wr(m_wr), .irq_n(m_irq_n),
        .rom_fixed_addr(rom_fixed_addr), .rom_fixed_data(rom_fixed_data),
        .rom_bank(rom_bank), .rom_bank_offset(rom_bank_offset), .rom_bank_data(rom_bank_data),
        .video_din(video_din), .firq_vblank(firq_vblank), .firq_beam(firq_beam), .yscroll(yscroll),
        .trigger(trigger), .start(start), .coin_n(coin_n), .aux_btn(aux_btn), .dial(dial),
        .dip_in0(dip_in0), .dip_in1(dip_in1), .coin_counter(coin_counter),
        .snd_cmd_wr(snd_cmd_wr), .snd_cmd_data(snd_cmd_data), .snd_cmd_ack(snd_cmd_ack),
        .nvram_host_enable(nvram_host_enable), .nvram_host_write(nvram_host_write),
        .nvram_host_address(nvram_host_address), .nvram_host_data_in(nvram_host_data_in),
        .nvram_host_data_out(nvram_host_data_out)
    );

    chiller_video video (
        .clk(clk), .reset(reset), .ce_pix(ce_pix),
        .cpu_addr(m_addr), .cpu_dout(m_dout), .cpu_rd(m_rd), .cpu_wr(m_wr),
        .cpu_din(video_din),
        .gun_x(gun_x), .gun_y(gun_y),
        .topsecex(topsecex), .yscroll(yscroll),
        .firq_vblank(firq_vblank), .firq_beam(firq_beam), .firq_n(m_firq_n),
        .rom_bank(rom_bank), .vblank_irq(vblank_irq),
        .red(red), .green(green), .blue(blue),
        .hblank(hblank), .vblank(vblank), .hsync(hsync), .vsync(vsync),
        .raster_h(raster_h), .raster_v(raster_v),
        .debug_render_overrun(debug_render_overrun)
    );

    chiller_sound sound (
        .clk(clk), .reset(reset), .ce_e(ce_snd_e), .ce_q(ce_snd_q),
        .ce_cvsd(ce_cvsd), .ce_cvsd_half(ce_cvsd_half),
        .vblank_irq(vblank_irq),
        .cmd_wr(snd_cmd_wr), .cmd_data(snd_cmd_data), .cmd_ack(snd_cmd_ack),
        .rom_addr(snd_rom_addr), .rom_data(snd_rom_data),
        .sample_req(sample_req), .sample_addr(sample_addr), .sample_ack(sample_ack), .sample_data(sample_data),
        .audio_l(audio_l), .audio_r(audio_r),
        .debug_pc(debug_snd_addr), .debug_cpu_rd(debug_snd_rd), .debug_cpu_wr(debug_snd_wr),
        .debug_cpu_op(debug_snd_op), .debug_dma_active(debug_dma_active)
    );

    assign debug_main_addr = m_addr;
    assign debug_main_op   = m_op;
    assign debug_main_rd   = m_rd;
    assign debug_main_wr   = m_wr;
    assign debug_main_dout = m_dout;
    assign debug_main_din  = m_din;
endmodule
