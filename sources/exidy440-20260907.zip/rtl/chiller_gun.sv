// Lightgun aim conditioning, crosshair and Sinden border.
//
// MiSTer delivers every recognised lightgun (Sinden VID 16c0/16d0, GunCon2
// driver, Wiimote, Retroshooter, touch) as the ABSOLUTE left analog stick of
// the player slot the gun occupies: signed 8-bit X in [7:0], Y in [15:8]
// (Main_MiSTer input.cpp: QUIRK_LIGHTGUN sets lightgun=1 at :5437-5449;
// EV_ABS codes 0/1 route through joy_analog() at :3987-3992).  A mouse-class
// gun (QUIRK_LIGHTGUN_MOUSE) arrives as relative PS/2 mouse deltas.
//
// The board wants MAME's AN0/AN1: 0..255 across the active raster
// (exidy440.cpp:795-799, exidy440_v.cpp:457-458).
module chiller_gun (
    input  logic        clk,
    input  logic        ce_pix,
    input  logic        reset,

    input  logic [1:0]  source,         // 0 lightgun/analog, 1 mouse, 2 joystick
    input  logic [15:0] analog,         // {Y, X} signed
    input  logic [24:0] ps2_mouse,      // MiSTer hps_io ps2_mouse
    input  logic [3:0]  joy_dirs,       // {up, down, left, right}
    input  logic        frame_tick,     // one pulse per frame (vblank start)

    output logic [7:0]  gun_x,
    output logic [7:0]  gun_y,

    // Overlay: applied by the wrapper on the board's RGB
    input  logic [8:0]  raster_h,
    input  logic [8:0]  raster_v,
    input  logic        crosshair_on,
    input  logic [1:0]  border,         // 0 off, 1 thin(4), 2 medium(8), 3 thick(12)
    output logic        overlay_white
);
    // Mouse: accumulate deltas into a 0..255 position (Y is inverted on PS/2)
    logic [7:0] mouse_x, mouse_y;
    logic       mouse_toggle_d;
    wire signed [8:0] mdx = {ps2_mouse[4], ps2_mouse[15:8]};
    wire signed [8:0] mdy = {ps2_mouse[5], ps2_mouse[23:16]};
    wire signed [9:0] nx = $signed({2'b00, mouse_x}) + (mdx >>> 1);
    wire signed [9:0] ny = $signed({2'b00, mouse_y}) - (mdy >>> 1);

    // Joystick: move the aim at a fixed rate each frame
    logic [7:0] joy_x, joy_y;

    always_ff @(posedge clk) begin
        if (reset) begin
            mouse_x <= 8'd128; mouse_y <= 8'd128;
            joy_x   <= 8'd128; joy_y   <= 8'd128;
            mouse_toggle_d <= ps2_mouse[24];
        end else begin
            mouse_toggle_d <= ps2_mouse[24];
            if (mouse_toggle_d != ps2_mouse[24]) begin
                mouse_x <= (nx < 0) ? 8'd0 : (nx > 255) ? 8'd255 : nx[7:0];
                mouse_y <= (ny < 0) ? 8'd0 : (ny > 255) ? 8'd255 : ny[7:0];
            end
            if (frame_tick) begin
                if (joy_dirs[0] && joy_x < 8'd253) joy_x <= joy_x + 8'd3;   // right
                if (joy_dirs[1] && joy_x > 8'd2)   joy_x <= joy_x - 8'd3;   // left
                if (joy_dirs[2] && joy_y < 8'd253) joy_y <= joy_y + 8'd3;   // down
                if (joy_dirs[3] && joy_y > 8'd2)   joy_y <= joy_y - 8'd3;   // up
            end
        end
    end

    always_comb begin
        case (source)
            2'd1:    begin gun_x = mouse_x; gun_y = mouse_y; end
            2'd2:    begin gun_x = joy_x;   gun_y = joy_y;   end
            default: begin gun_x = analog[7:0] ^ 8'h80; gun_y = analog[15:8] ^ 8'h80; end
        endcase
    end

    // Overlay geometry in raster space (320 x 240 active).  The aim products
    // and the overlay flag are registered: one master clock of latency is
    // 1/16 of a pixel, invisible, and keeps the multiply off the video path.
    logic [16:0] px_mul;
    logic [15:0] py_mul;
    logic [8:0]  aim_x, aim_y;
    wire  [4:0]  bw = {border, 2'b00};          // 0, 4, 8, 12 pixels
    wire in_border = (border != 2'd0) &&
                     ((raster_h < bw) || (raster_h >= 9'd320 - bw) ||
                      (raster_v < bw) || (raster_v >= 9'd240 - bw));
    wire on_cross = crosshair_on &&
                    (((raster_h == aim_x) && (raster_v + 9'd6 >= aim_y) && (raster_v <= aim_y + 9'd6)) ||
                     ((raster_v == aim_y) && (raster_h + 9'd6 >= aim_x) && (raster_h <= aim_x + 9'd6)));
    always_ff @(posedge clk) begin
        px_mul <= gun_x * 9'd320;
        py_mul <= gun_y * 8'd240;
        aim_x  <= px_mul[16:8];
        aim_y  <= py_mul[15:8];
        overlay_white <= in_border || on_cross;
    end
endmodule
