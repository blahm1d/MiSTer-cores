// Exidy 440 sound board: MC6809 at 811.2 kHz, MC6844 DMA controller, four
// CVSD channels, per-channel left/right volume, command latch.
// Transcribed from MAME 0.289 src/mame/exidy/exidy440_a.cpp (":line").
//
// Map (:57-70): 8000-83FF 6844, 8400-87FF volume, 8800-8BFF command,
// 9400-97FF bank, 9800-9BFF IRQ clear, A000-BFFF RAM, E000-FFFF ROM (4 KiB
// image at F000; E000-EFFF is region fill, reads 0).
module chiller_sound (
    input  logic        clk,
    input  logic        reset,
    input  logic        ce_e,
    input  logic        ce_q,
    input  logic        ce_cvsd,
    input  logic        ce_cvsd_half,

    input  logic        vblank_irq,     // pulse: screen vblank -> IRQ (:262-266)
    input  logic        cmd_wr,         // pulse from the main CPU (:233-238)
    input  logic [7:0]  cmd_data,
    output logic        cmd_ack,        // :224-231,241-244

    output logic [12:0] rom_addr,       // E000-FFFF offset (8 KiB image)
    input  logic [7:0]  rom_data,
    output logic        sample_req,     // one-clock pulse: fetch sample byte at sample_addr
    output logic [16:0] sample_addr,
    input  logic        sample_ack,     // one-clock pulse with sample_data valid
    input  logic [7:0]  sample_data,

    output logic signed [15:0] audio_l,
    output logic signed [15:0] audio_r,

    output logic [15:0] debug_pc,
    output logic        debug_cpu_rd,
    output logic        debug_cpu_wr,
    output logic        debug_cpu_op,
    output logic [3:0]  debug_dma_active
);
    // ------------------------------------------------------------------
    // CPU
    // ------------------------------------------------------------------
    logic [15:0] cpu_addr;
    logic [7:0]  cpu_din, cpu_dout;
    logic        cpu_rnw, cpu_avma, cpu_vma, cpu_op;
    logic        irq_pending, firq_pending;

    always_ff @(posedge clk) begin
        if (reset)      cpu_vma <= 1'b0;
        else if (ce_e)  cpu_vma <= cpu_avma;
    end

    mc6809i cpu (
        .D(cpu_din), .DOut(cpu_dout), .ADDR(cpu_addr), .RnW(cpu_rnw),
        .clk(clk), .cen_E(ce_e), .cen_Q(ce_q),
        .BS(), .BA(),
        .nIRQ(~irq_pending), .nFIRQ(~firq_pending), .nNMI(1'b1),
        .AVMA(cpu_avma), .BUSY(), .LIC(),
        .nHALT(1'b1), .nRESET(~reset), .nDMABREQ(1'b1),
        .OP(cpu_op), .RegData()
    );

    wire cpu_rd = ce_e && cpu_vma &&  cpu_rnw;
    wire cpu_wr = ce_e && cpu_vma && !cpu_rnw;
    assign debug_pc     = cpu_addr;
    assign debug_cpu_rd = cpu_rd;
    assign debug_cpu_wr = cpu_wr;
    assign debug_cpu_op = cpu_op;

    // ------------------------------------------------------------------
    // Memories
    // ------------------------------------------------------------------
    (* ramstyle = "M10K" *) logic [7:0] ram [0:8191];
    initial for (int ram_i = 0; ram_i < 256; ram_i++)   // Quartus caps a loop at 5000 iterations
        for (int ram_j = 0; ram_j < 32; ram_j++) ram[ram_i * 32 + ram_j] = '0;   // power-up zero, as MAME
    logic [7:0] ram_q;
    wire ram_sel = (cpu_addr[15:13] == 3'b101);      // A000-BFFF
    wire rom_sel = (cpu_addr[15:13] == 3'b111);      // E000-FFFF
    assign rom_addr = cpu_addr[12:0];

    always_ff @(posedge clk) begin
        if (cpu_wr && ram_sel) ram[cpu_addr[12:0]] <= cpu_dout;
        ram_q <= ram[cpu_addr[12:0]];
    end

    // ------------------------------------------------------------------
    // Registers
    // ------------------------------------------------------------------
    logic [7:0]  volume [0:15];      // stored inverted (:275)
    logic [7:0]  banks  [0:3];       // :654-657
    logic [7:0]  command;

    logic [15:0] dma_addr  [0:3];
    logic [15:0] dma_cnt   [0:3];
    logic [7:0]  dma_ctrl  [0:3];
    logic [15:0] dma_start_addr [0:3];
    logic [15:0] dma_start_cnt  [0:3];
    logic [3:0]  dma_active;
    logic [7:0]  dma_priority, dma_interrupt, dma_chain;

    wire dec_6844 = (cpu_addr[15:10] == 6'b1000_00);   // 8000-83FF
    wire dec_vol  = (cpu_addr[15:10] == 6'b1000_01);   // 8400-87FF
    wire dec_cmd  = (cpu_addr[15:10] == 6'b1000_10);   // 8800-8BFF
    wire dec_bank = (cpu_addr[15:10] == 6'b1001_01);   // 9400-97FF
    wire dec_iclr = (cpu_addr[15:10] == 6'b1001_10);   // 9800-9BFF
    wire [4:0] r_off = cpu_addr[4:0];
    wire [1:0] r_ch  = cpu_addr[3:2];

    wire [7:0] end_flags = {4'd0, dma_ctrl[3][7], dma_ctrl[2][7], dma_ctrl[1][7], dma_ctrl[0][7]};
    wire       any_end   = |end_flags[3:0];

    // Read mux (:305-393)
    logic [7:0] dma_rd;
    always_comb begin
        dma_rd = 8'h00;
        if (r_off < 5'h10) begin
            case (r_off[1:0])
                2'd0: dma_rd = dma_addr[r_ch][15:8];
                2'd1: dma_rd = dma_addr[r_ch][7:0];
                2'd2: dma_rd = dma_cnt[r_ch][15:8];
                default: dma_rd = dma_cnt[r_ch][7:0];
            endcase
        end else begin
            case (r_off)
                5'h10, 5'h11, 5'h12, 5'h13: dma_rd = dma_ctrl[r_off[1:0]];
                5'h14: dma_rd = dma_priority;
                5'h15: dma_rd = {any_end, dma_interrupt[6:0]};
                5'h16: dma_rd = dma_chain;
                default: dma_rd = 8'h00;
            endcase
        end
    end

    // Registered (mc6809i derives its next address from D combinationally)
    logic [7:0] din_mux;
    always_comb begin
        din_mux = 8'h00;
        if (dec_6844)     din_mux = dma_rd;
        else if (dec_vol) din_mux = volume[cpu_addr[3:0]];
        else if (dec_cmd) din_mux = command;
        else if (ram_sel) din_mux = ram_q;
        else if (rom_sel) din_mux = rom_data;
    end
    always_ff @(posedge clk) cpu_din <= din_mux;

    // ------------------------------------------------------------------
    // DMA / CVSD channel engines
    // ------------------------------------------------------------------
    logic [7:0]  shift_byte [0:3];
    logic [2:0]  bit_idx    [0:3];
    logic [3:0]  byte_ready;
    logic [3:0]  fetch_req;
    logic [3:0]  chan_restart;
    logic [3:0]  cvsd_bit_valid, cvsd_bit_data;

    // MAME bank base (:494-502): bit0 -> 0, bit1 -> 0x8000, bit2 -> 0x10000, bit3 -> 0x18000
    function automatic [16:0] bank_base(input [7:0] b);
        if (b[0])      bank_base = 17'h00000;
        else if (b[1]) bank_base = 17'h08000;
        else if (b[2]) bank_base = 17'h10000;
        else if (b[3]) bank_base = 17'h18000;
        else           bank_base = 17'h00000;
    endfunction

    // Shared sample-ROM fetch: one channel at a time, 3 clocks each.
    logic [1:0] f_ch;
    logic [1:0] f_state;


    integer c;
    always_ff @(posedge clk) begin
        chan_restart   <= 4'd0;
        cvsd_bit_valid <= 4'd0;
        if (reset) begin
            for (c = 0; c < 4; c = c + 1) begin
                volume[c] <= 8'd0; volume[c+4] <= 8'd0; volume[c+8] <= 8'd0; volume[c+12] <= 8'd0;
                banks[c] <= 8'd0;
                dma_addr[c] <= 16'd0; dma_cnt[c] <= 16'd0; dma_ctrl[c] <= 8'd0;
                dma_start_addr[c] <= 16'd0; dma_start_cnt[c] <= 16'd0;
                shift_byte[c] <= 8'd0; bit_idx[c] <= 3'd0;
            end
            dma_active    <= 4'd0;
            dma_priority  <= 8'd0;
            dma_interrupt <= 8'd0;
            dma_chain     <= 8'd0;
            command       <= 8'd0;
            cmd_ack       <= 1'b1;        // :96-97
            irq_pending   <= 1'b0;
            firq_pending  <= 1'b0;
            byte_ready    <= 4'd0;
            fetch_req     <= 4'd0;
            f_state       <= 2'd0;
            sample_req    <= 1'b0;

            f_ch          <= 2'd0;
        end else begin
            // Interrupt sources
            if (vblank_irq) irq_pending <= 1'b1;
            if (cpu_wr && dec_iclr) irq_pending <= 1'b0;
            if (cmd_wr) begin
                command      <= cmd_data;
                cmd_ack      <= 1'b0;
                firq_pending <= 1'b1;
            end
            if (cpu_rd && dec_cmd) begin
                firq_pending <= 1'b0;
                cmd_ack      <= 1'b1;
            end

            // Register writes (:275, :395-478, :654-657)
            if (cpu_wr && dec_vol)  volume[cpu_addr[3:0]] <= ~cpu_dout;
            if (cpu_wr && dec_bank) banks[cpu_addr[1:0]]  <= cpu_dout;
            if (cpu_wr && dec_6844) begin
                if (r_off < 5'h10) begin
                    case (r_off[1:0])
                        2'd0: dma_addr[r_ch][15:8] <= cpu_dout;
                        2'd1: dma_addr[r_ch][7:0]  <= cpu_dout;
                        2'd2: dma_cnt[r_ch][15:8]  <= cpu_dout;
                        default: dma_cnt[r_ch][7:0] <= cpu_dout;
                    endcase
                end else begin
                    case (r_off)
                        5'h10, 5'h11, 5'h12, 5'h13:
                            dma_ctrl[r_off[1:0]] <= {dma_ctrl[r_off[1:0]][7:6], cpu_dout[5:0]};
                        5'h14: begin
                            dma_priority <= cpu_dout;
                            for (c = 0; c < 4; c = c + 1) begin
                                if (!dma_active[c] && cpu_dout[c]) begin
                                    // going active (:420-437)
                                    dma_ctrl[c][6] <= 1'b1;
                                    dma_ctrl[c][7] <= 1'b0;
                                    dma_start_addr[c] <= dma_addr[c];
                                    dma_start_cnt[c]  <= dma_cnt[c];
                                    if (dma_cnt[c] <= 16'd3) begin
                                        // immediate end (:508-515, :294-303)
                                        dma_active[c]  <= 1'b0;
                                        dma_cnt[c]     <= 16'd0;
                                        dma_addr[c]    <= dma_addr[c] + dma_cnt[c];
                                        dma_ctrl[c][6] <= 1'b0;
                                        dma_ctrl[c][7] <= 1'b1;
                                    end else begin
                                        dma_active[c]   <= 1'b1;
                                        chan_restart[c] <= 1'b1;
                                        bit_idx[c]      <= 3'd0;
                                        byte_ready[c]   <= 1'b0;
                                        fetch_req[c]    <= 1'b1;
                                    end
                                end else if (dma_active[c] && !cpu_dout[c]) begin
                                    // going inactive (:440-447)
                                    dma_active[c] <= 1'b0;
                                    byte_ready[c] <= 1'b0;
                                end
                            end
                        end
                        5'h15: dma_interrupt <= {dma_interrupt[7], cpu_dout[6:0]};
                        5'h16: dma_chain <= cpu_dout;
                        default: ;
                    endcase
                end
            end
            // Control read clears the end flag (:353-361); interrupt read
            // folds the end flags into bit 7 (:369-381)
            if (cpu_rd && dec_6844) begin
                if (r_off[4:2] == 3'b100) dma_ctrl[r_off[1:0]][7] <= 1'b0;
                if (r_off == 5'h15) dma_interrupt[7] <= any_end;
            end

            // Bit clocks: ch0/1 on ce_cvsd, ch2/3 on ce_cvsd_half
            for (c = 0; c < 4; c = c + 1) begin
                if (((c < 2) ? ce_cvsd : ce_cvsd_half) && dma_active[c] && byte_ready[c]) begin
                    cvsd_bit_valid[c] <= 1'b1;
                    cvsd_bit_data[c]  <= shift_byte[c][bit_idx[c]];   // LSB first (:575)
                    bit_idx[c] <= bit_idx[c] + 3'd1;
                    if (bit_idx[c] == 3'd7) begin
                        dma_addr[c] <= dma_addr[c] + 16'd1;
                        dma_cnt[c]  <= dma_cnt[c] - 16'd1;
                        if (dma_cnt[c] == 16'd1) begin
                            // finished (:294-303)
                            dma_active[c]  <= 1'b0;
                            byte_ready[c]  <= 1'b0;
                            dma_cnt[c]     <= 16'd0;
                            dma_addr[c]    <= dma_start_addr[c] + dma_start_cnt[c];
                            dma_ctrl[c][6] <= 1'b0;
                            dma_ctrl[c][7] <= 1'b1;
                        end else begin
                            byte_ready[c] <= 1'b0;
                            fetch_req[c]  <= 1'b1;
                        end
                    end
                end
            end

            // Sample fetch service: one channel at a time through the DDR3
            // agent (exidy440_ddr); the byte arrives with sample_ack.
            sample_req <= 1'b0;
            case (f_state)
                2'd0: begin
                    if (fetch_req[0])      begin f_ch <= 2'd0; f_state <= 2'd1; end
                    else if (fetch_req[1]) begin f_ch <= 2'd1; f_state <= 2'd1; end
                    else if (fetch_req[2]) begin f_ch <= 2'd2; f_state <= 2'd1; end
                    else if (fetch_req[3]) begin f_ch <= 2'd3; f_state <= 2'd1; end
                end
                2'd1: begin
                    sample_addr <= bank_base(banks[f_ch]) + {1'b0, dma_addr[f_ch]};
                    sample_req  <= 1'b1;
                    fetch_req[f_ch] <= 1'b0;
                    f_state <= 2'd2;
                end
                2'd2: if (sample_ack) begin
                    if (dma_active[f_ch]) begin
                        shift_byte[f_ch] <= sample_data;
                        byte_ready[f_ch] <= 1'b1;
                    end
                    f_state <= 2'd0;
                end
                default: f_state <= 2'd0;
            endcase
        end
    end
    assign debug_dma_active = dma_active;

    // ------------------------------------------------------------------
    // Decoder and mixer (:180-215, :663-712)
    // ------------------------------------------------------------------
    logic signed [15:0] s0, s1, s2, s3;
    chiller_cvsd cvsd (
        .clk(clk), .reset(reset),
        .ce_cvsd(ce_cvsd), .ce_cvsd_half(ce_cvsd_half),
        .chan_restart(chan_restart),
        .bit_valid(cvsd_bit_valid), .bit_data(cvsd_bit_data),
        .sample0(s0), .sample1(s1), .sample2(s2), .sample3(s3),
        .busy()
    );

    // Mixer (exidy440_a.cpp:180-215): sample * volume / 256 truncating toward
    // zero, summed per side, clamped to 16 bits.  Volumes 0..7 = ch0 L, ch0 R,
    // ch1 L, ... (:203-208).
    chiller_mixer mixer (
        .clk(clk), .reset(reset), .tick(ce_cvsd),
        .s0(s0), .s1(s1), .s2(s2), .s3(s3),
        .vol0(volume[0]), .vol1(volume[1]), .vol2(volume[2]), .vol3(volume[3]),
        .vol4(volume[4]), .vol5(volume[5]), .vol6(volume[6]), .vol7(volume[7]),
        .audio_l(audio_l), .audio_r(audio_r)
    );
endmodule
