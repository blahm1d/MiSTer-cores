// Exidy 440 clock tree as clock enables from a single 77.8752 MHz master
// (12 x the 6.4896 MHz pixel clock, 6 x the 12.9792 MHz board crystal).
//
//   pixel      12.9792/2   = 6.4896 MHz  -> /12    exidy440_v.cpp:13
//   main E     12.9792/8   = 1.6224 MHz  -> /48    exidy440.cpp:304  (MC6809E, E fed directly)
//   sound E    12.9792/16  = 811.2 kHz   -> /96    exidy440_a.cpp:85 (MC6809 XTAL/4, internal /4)
//   CVSD FCLK  12.9792/256 = 50.7 kHz    -> /1536  exidy440_a.h:10
//   CVSD SCLK  FCLK/2      = 25.35 kHz   -> /3072  exidy440_a.cpp:162-163
//
// 16 x pixel (103.8336 MHz, r4) left the 184-block bank ROM, the VRAM and the
// framework's HQ2x/scaler paths 2-4 ns short; 12 x pixel is the largest
// integer multiple that closes with margin and still gives the sprite
// compositor 1,152 clocks per horizontal blanking (it needs ~1,085 for 40
// sprites on one line) and the CVSD decoder 1,536 per tick (uses ~560).
//
// The Q enables follow the E enables by one master clock, the contract that
// the Gladiator core proved against MAME with the same mc6809i.
module chiller_clock_enables (
    input  logic clk,
    input  logic reset,
    output logic ce_pix,
    output logic ce_main_e,
    output logic ce_main_q,
    output logic ce_snd_e,
    output logic ce_snd_q,
    output logic ce_cvsd,       // 50.7 kHz bit clock, channels 0/1
    output logic ce_cvsd_half   // 25.35 kHz bit clock, channels 2/3
);
    logic [3:0] p;      // master clocks within a pixel, 0..11
    logic [7:0] n;      // pixels, wraps every 256 (3072 master clocks)
    wire last_p = (p == 4'd11);

    always_ff @(posedge clk) begin
        if (reset) begin
            p <= '0;
            n <= '0;
            ce_pix <= 1'b0; ce_main_e <= 1'b0; ce_main_q <= 1'b0;
            ce_snd_e <= 1'b0; ce_snd_q <= 1'b0; ce_cvsd <= 1'b0; ce_cvsd_half <= 1'b0;
        end else begin
            p <= last_p ? 4'd0 : p + 4'd1;
            if (last_p) n <= n + 8'd1;
            ce_pix       <= last_p;
            ce_main_e    <= last_p && (n[1:0] == 2'b11);       // every 4 pixels
            ce_main_q    <= ce_main_e;
            ce_snd_e     <= last_p && (n[2:0] == 3'b111);      // every 8 pixels
            ce_snd_q     <= ce_snd_e;
            ce_cvsd      <= last_p && (n[6:0] == 7'h7f);       // every 128 pixels
            ce_cvsd_half <= last_p && (n == 8'hff);            // every 256 pixels
        end
    end
endmodule
