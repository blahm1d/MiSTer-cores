// Main 6809 address decode, RAM, EEROM and I/O for the Exidy 440 family.
// Memory map: MAME 0.289 exidy440.cpp:446-467; per-game port polarities and
// protections: exidy440.cpp:104-186 (hardware notes), :522-960 (ports),
// :384-421 (showdown PLD, claypign, topsecex), :2064-2130 (init_*).
module chiller_main_bus (
    input  logic        clk,
    input  logic        reset,
    input  logic        ce_e,

    // Game profile (exidy440_profile)
    input  logic [3:0]  game,

    // CPU (mc6809i).  vma is AVMA latched on E; rnw is the CPU's R/W.
    input  logic [15:0] cpu_addr,
    input  logic [7:0]  cpu_dout,
    input  logic        cpu_rnw,
    input  logic        cpu_vma,
    output logic [7:0]  cpu_din,
    output logic        cpu_rd,         // one-clock read pulse on E
    output logic        cpu_wr,         // one-clock write pulse on E
    output logic        irq_n,          // coin IRQ (exidy440.cpp:277-282,335-347)

    // ROMs (chiller_roms, registered one clock after the address)
    output logic [14:0] rom_fixed_addr,
    input  logic [7:0]  rom_fixed_data,
    input  logic [3:0]  rom_bank,
    output logic [13:0] rom_bank_offset,
    input  logic [7:0]  rom_bank_data,

    // Video block (decodes its own ranges from cpu_addr)
    input  logic [7:0]  video_din,
    input  logic        firq_vblank,
    input  logic        firq_beam,
    output logic [7:0]  yscroll,        // topsecex 2EC1 (exidy440.cpp:429-432)

    // Cabinet inputs, active high here; the profile sets the pin polarity
    input  logic        trigger,        // gun trigger / topsecex fire (AN1)
    input  logic        start,
    input  logic [1:0]  coin_n,         // active low, debounced
    input  logic [7:0]  aux_btn,        // showdown {.., white, red, blue, gold, betall};
                                        // topsecex {shield, turbo, oil, missile, laser, fireball, button2, -}
    input  logic [7:0]  dial,           // topsecex AN0 dial (already MAME-signed)
    input  logic [3:0]  dip_in0,        // IN0 bits 5:2
    input  logic [7:0]  dip_in1,        // IN1 audio-board DIP
    output logic        coin_counter,

    // Sound board
    output logic        snd_cmd_wr,
    output logic [7:0]  snd_cmd_data,
    input  logic        snd_cmd_ack,

    // EEROM host port (MiSTer ioctl index 2)
    input  logic        nvram_host_enable,
    input  logic        nvram_host_write,
    input  logic [12:0] nvram_host_address,
    input  logic [7:0]  nvram_host_data_in,
    output logic [7:0]  nvram_host_data_out
);
    assign cpu_rd = ce_e && cpu_vma &&  cpu_rnw;
    assign cpu_wr = ce_e && cpu_vma && !cpu_rnw;

    logic in0_active_low, in0_bit0_one, in0_bit0_vblank, in0_bit0_trigger, in0_bit1_zero;
    logic in2_start_low, in2_showdown, in2_topsecex, in3_bit2_one, claypign_prot, topsecex;
    logic [1:0] pld_tables;
    exidy440_profile profile (
        .game(game),
        .in0_active_low(in0_active_low), .in0_bit0_one(in0_bit0_one), .in0_bit0_vblank(in0_bit0_vblank),
        .in0_bit0_trigger(in0_bit0_trigger), .in0_bit1_zero(in0_bit1_zero),
        .in2_start_low(in2_start_low), .in2_showdown(in2_showdown), .in2_topsecex(in2_topsecex),
        .in3_bit2_one(in3_bit2_one), .claypign_prot(claypign_prot), .topsecex(topsecex),
        .pld_tables(pld_tables)
    );

    // 2000-3FFF: sprite/stack/scratch/work RAM in one 8 KiB block.  The video
    // block owns its ranges inside it (2A00-2DFF); writes landing there in
    // this RAM are harmless because reads are steered to the video block.
    (* ramstyle = "M10K" *) logic [7:0] work_ram [0:8191];
    initial for (int i = 0; i < 256; i++) for (int j = 0; j < 32; j++) work_ram[i * 32 + j] = '0;
    logic [7:0] work_q;
    wire work_sel = (cpu_addr[15:13] == 3'b001);

    // EEROM: 8 KiB, bank 15 at 6000-7FFF (exidy440.cpp:311-320,425-430).
    logic [7:0] eerom_q;
    wire bank_sel  = (cpu_addr[15:14] == 2'b01);
    wire eerom_sel = bank_sel && (rom_bank == 4'd15) && cpu_addr[13];
    wire fixed_sel = cpu_addr[15];

    assign rom_fixed_addr  = cpu_addr[14:0];
    assign rom_bank_offset = cpu_addr[13:0];

    always_ff @(posedge clk) begin
        if (cpu_wr && work_sel) work_ram[cpu_addr[12:0]] <= cpu_dout;
        work_q <= work_ram[cpu_addr[12:0]];
    end
    chiller_dpram #(.AW(13), .DW(8)) u_eerom (
        .clk(clk),
        .addr_a(cpu_addr[12:0]),      .din_a(cpu_dout),           .we_a(cpu_wr && eerom_sel),               .q_a(eerom_q),
        .addr_b(nvram_host_address),  .din_b(nvram_host_data_in), .we_b(nvram_host_enable && nvram_host_write), .q_b(nvram_host_data_out)
    );

    // I/O decode (exidy440.cpp:452-462)
    wire io_2b03 = (cpu_addr == 16'h2B03);
    wire io_2e   = (cpu_addr[15:8] == 8'h2E);
    wire [2:0] io_2e_grp = cpu_addr[7:5];        // 0:2E00 1:2E20 2:2E40 3:2E60 4:2E80 5:2EA0 6/7:2EC0-2EFF
    wire video_rd_sel = (cpu_addr[15:13] == 3'b000) ||               // image RAM
                        (cpu_addr[15:8] == 8'h2A) ||                 // VRAM window
                        (cpu_addr[15:2] == 14'h0AC0 && cpu_addr[1:0] != 2'd3) || // 2B00-2B02
                        (cpu_addr[15:9] == 7'b0010_110);             // palette

    // ---- IN0 (:522-960): {vblank, beam, dip[5:2], trigger, bit0} ----
    logic [7:0] in0;
    logic in0_bit0, in0_bit1;
    always_comb begin
        in0_bit0 = in0_bit0_vblank ? firq_vblank : in0_bit0_trigger ? trigger : in0_bit0_one ? 1'b1 : 1'b0;
        in0_bit1 = in0_bit1_zero ? 1'b0 : trigger;
        in0 = {firq_vblank, firq_beam, dip_in0, in0_bit1, in0_bit0};
        if (in0_active_low)               // crossbow: LS244 straight through
            in0 = {~firq_vblank, ~firq_beam, dip_in0, ~trigger, 1'b1};
    end
    // ---- IN2 (:545,:912-919,:838) ----
    logic [7:0] in2;
    always_comb begin
        if (in2_showdown)       in2 = {2'b00, aux_btn[4:0], start};   // white red blue gold bet-all action
        else if (in2_topsecex)  in2 = {7'd0, aux_btn[0]};             // button 2
        else if (in2_start_low) in2 = {7'b1111111, ~start};
        else                    in2 = {7'd0, start};
    end
    // ---- IN3 (:788-792): coins active low, bit 2 per game, bits 7:3 high ----
    wire [7:0] in3 = {5'b11111, in3_bit2_one, coin_n};
    // ---- topsecex extra ports (exidy440.cpp:424-426, :2079-2085) ----
    wire [7:0] ts_2ec5 = trigger ? 8'h02 : 8'h01;    // AN1 button 1 active low: pressed -> 0x02
    wire [7:0] ts_2ec7 = {~start, 1'b1, ~aux_btn[7], ~aux_btn[6], ~aux_btn[5], ~aux_btn[4], ~aux_btn[3], ~aux_btn[2]};

    // ---- Showdown / Yukon PLD on bank-0 reads (exidy440.cpp:384-408) ----
    logic        pld_sel_neg;            // "select == -1"
    logic        pld_sel;                // 0 / 1 when select >= 0
    logic [4:0]  pld_off;
    wire  pld_active = (pld_tables != 2'd0) && bank_sel && (rom_bank == 4'd0);
    function automatic [7:0] pld_byte(input [1:0] tables, input sel, input [4:0] i);
        case ({tables, sel})
            3'b010: case (i)  // showdown table 0
                5'd0: pld_byte=8'h15; 5'd1: pld_byte=8'h40; 5'd2: pld_byte=8'hc1; 5'd3: pld_byte=8'h8d; 5'd4: pld_byte=8'h4c; 5'd5: pld_byte=8'h84; 5'd6: pld_byte=8'h0e; 5'd7: pld_byte=8'hce;
                5'd8: pld_byte=8'h52; 5'd9: pld_byte=8'hd0; 5'd10: pld_byte=8'h99; 5'd11: pld_byte=8'h48; 5'd12: pld_byte=8'h80; 5'd13: pld_byte=8'h09; 5'd14: pld_byte=8'hc9; 5'd15: pld_byte=8'h45;
                5'd16: pld_byte=8'hc4; 5'd17: pld_byte=8'h8e; 5'd18: pld_byte=8'h5a; 5'd19: pld_byte=8'h92; 5'd20: pld_byte=8'h18; 5'd21: pld_byte=8'hd8; 5'd22: pld_byte=8'h51; default: pld_byte=8'hc0; endcase
            3'b011: case (i)  // showdown table 1
                5'd0: pld_byte=8'h11; 5'd1: pld_byte=8'h51; 5'd2: pld_byte=8'hc0; 5'd3: pld_byte=8'h89; 5'd4: pld_byte=8'h4d; 5'd5: pld_byte=8'h85; 5'd6: pld_byte=8'h0c; 5'd7: pld_byte=8'hcc;
                5'd8: pld_byte=8'h46; 5'd9: pld_byte=8'hd2; 5'd10: pld_byte=8'h98; 5'd11: pld_byte=8'h59; 5'd12: pld_byte=8'h91; 5'd13: pld_byte=8'h08; 5'd14: pld_byte=8'hc8; 5'd15: pld_byte=8'h41;
                5'd16: pld_byte=8'hc5; 5'd17: pld_byte=8'h8c; 5'd18: pld_byte=8'h4e; 5'd19: pld_byte=8'h86; 5'd20: pld_byte=8'h1a; 5'd21: pld_byte=8'hda; 5'd22: pld_byte=8'h50; default: pld_byte=8'hd1; endcase
            3'b100: case (i)  // yukon table 0
                5'd0: pld_byte=8'h31; 5'd1: pld_byte=8'h40; 5'd2: pld_byte=8'hc1; 5'd3: pld_byte=8'h95; 5'd4: pld_byte=8'h54; 5'd5: pld_byte=8'h90; 5'd6: pld_byte=8'h16; 5'd7: pld_byte=8'hd6;
                5'd8: pld_byte=8'h62; 5'd9: pld_byte=8'he0; 5'd10: pld_byte=8'ha5; 5'd11: pld_byte=8'h44; 5'd12: pld_byte=8'h80; 5'd13: pld_byte=8'h05; 5'd14: pld_byte=8'hc5; 5'd15: pld_byte=8'h51;
                5'd16: pld_byte=8'hd0; 5'd17: pld_byte=8'h96; 5'd18: pld_byte=8'h66; 5'd19: pld_byte=8'ha2; 5'd20: pld_byte=8'h24; 5'd21: pld_byte=8'he4; 5'd22: pld_byte=8'h61; default: pld_byte=8'hc0; endcase
            3'b101: case (i)  // yukon table 1
                5'd0: pld_byte=8'h21; 5'd1: pld_byte=8'h61; 5'd2: pld_byte=8'hc0; 5'd3: pld_byte=8'h85; 5'd4: pld_byte=8'h55; 5'd5: pld_byte=8'h91; 5'd6: pld_byte=8'h14; 5'd7: pld_byte=8'hd4;
                5'd8: pld_byte=8'h52; 5'd9: pld_byte=8'he2; 5'd10: pld_byte=8'ha4; 5'd11: pld_byte=8'h65; 5'd12: pld_byte=8'ha1; 5'd13: pld_byte=8'h04; 5'd14: pld_byte=8'hc4; 5'd15: pld_byte=8'h41;
                5'd16: pld_byte=8'hd1; 5'd17: pld_byte=8'h94; 5'd18: pld_byte=8'h56; 5'd19: pld_byte=8'h92; 5'd20: pld_byte=8'h26; 5'd21: pld_byte=8'he6; 5'd22: pld_byte=8'h60; default: pld_byte=8'he1; endcase
            default: pld_byte = 8'hff;
        endcase
    endfunction
    wire [7:0] pld_data = pld_sel_neg ? 8'hff : pld_byte(pld_tables, pld_sel, pld_off);

    // mc6809i computes its next address combinationally from D, so the data
    // input is registered (settles two clocks after the address, ~46 clocks
    // before the E enable samples it).
    logic [7:0] din_mux;
    always_comb begin
        din_mux = 8'h00;
        if (video_rd_sel)      din_mux = video_din;
        else if (io_2b03)      din_mux = in0;
        else if (io_2e) begin
            case (io_2e_grp)
                3'd0: din_mux = work_q;                          // sound command RAM
                3'd1: din_mux = in3;
                3'd2: din_mux = 8'h00;
                3'd3: din_mux = dip_in1;
                3'd4: din_mux = in2;
                3'd5: din_mux = snd_cmd_ack ? 8'hF7 : 8'hFF;     // :342-346
                default: begin                                   // 2EC0-2EFF
                    din_mux = 8'h00;
                    if (claypign_prot && cpu_addr[7:2] == 6'b110000) din_mux = 8'h76;   // 2EC0-2EC3 (:411-414)
                    if (topsecex) begin
                        case (cpu_addr[7:0])
                            8'hC5: din_mux = ts_2ec5;
                            8'hC6: din_mux = dial;
                            8'hC7: din_mux = ts_2ec7;
                            default: din_mux = 8'h00;
                        endcase
                    end
                end
            endcase
        end
        else if (work_sel)     din_mux = work_q;
        else if (eerom_sel)    din_mux = eerom_q;
        else if (pld_active)   din_mux = pld_data;
        else if (bank_sel)     din_mux = rom_bank_data;
        else if (fixed_sel)    din_mux = rom_fixed_data;
    end
    always_ff @(posedge clk) cpu_din <= din_mux;

    // Coin IRQ flip-flop: set on a coin press edge, cleared by any I/O1 access
    logic [1:0] coin_n_d;
    logic irq_pending;
    wire  coin_press = |(coin_n_d & ~coin_n);
    wire  irq_clear  = (cpu_rd || cpu_wr) && io_2e && (io_2e_grp == 3'd1);

    always_ff @(posedge clk) begin
        snd_cmd_wr <= 1'b0;
        if (reset) begin
            coin_n_d     <= 2'b11;
            irq_pending  <= 1'b0;
            coin_counter <= 1'b0;
            snd_cmd_data <= 8'd0;
            yscroll      <= 8'd0;
            pld_sel_neg  <= 1'b0;        // m_showdown_bank_select starts at 0, not -1
            pld_sel      <= 1'b0;
            pld_off      <= 5'd0;
        end else begin
            coin_n_d <= coin_n;
            if (coin_press)     irq_pending <= 1'b1;
            else if (irq_clear) irq_pending <= 1'b0;
            if (cpu_wr && io_2e && io_2e_grp == 3'd0) begin
                snd_cmd_wr   <= 1'b1;
                snd_cmd_data <= cpu_dout;
            end
            if (cpu_wr && io_2e && io_2e_grp == 3'd2) coin_counter <= cpu_dout[0];
            if (cpu_wr && topsecex && cpu_addr == 16'h2EC1) yscroll <= cpu_dout;

            // Showdown PLD (:384-408): the read returns the current sequence
            // byte and advances, THEN the offset is examined.
            if (cpu_rd && pld_active) begin
                if (!pld_sel_neg) pld_off <= (pld_off == 5'd23) ? 5'd0 : pld_off + 5'd1;
                if (cpu_addr[13:0] == 14'h0055) begin
                    pld_sel_neg <= 1'b1;
                end else if (pld_sel_neg) begin
                    pld_sel_neg <= 1'b0;
                    pld_sel     <= (cpu_addr[13:0] == 14'h1243);   // 0x00ed -> 0, 0x1243 -> 1, else 0
                    pld_off     <= 5'd0;
                end
            end
        end
    end
    assign irq_n = ~irq_pending;
endmodule
