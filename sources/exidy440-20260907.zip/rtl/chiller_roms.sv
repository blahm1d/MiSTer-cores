// ROM images, loaded from the MiSTer ioctl stream (index 0).
//
// Family stream layout (sim/tools/gen_mra.py writes every MRA to it):
//   0x00000  0x08000  main fixed program 8000-FFFF        (maincpu 0x08000)
//   0x08000  0x40000  main banks 0..15, 16 KiB each        (maincpu 0x10000 + bank*0x4000), gaps zero
//   0x48000  0x02000  sound program E000-FFFF              (440audio:audiocpu), gaps zero
//   0x4A000  0x20000  CVSD sample ROM -> HPS DDR3          (exidy440_ddr), not stored here
//   0x6A000  end
//
// Program and sound ROMs are M10K (288 + 8 blocks); the 128 KiB sample ROM
// lives in DDR3 because the fetch client tolerates any latency (one byte
// per 158 us) and the family needs all sixteen banks (Top Secret).
// Reads are synchronous (one clock), the only M10K read mode.
module chiller_roms (
    input  logic        clk,

    input  logic        dl_wr,
    input  logic [19:0] dl_addr,
    input  logic [7:0]  dl_data,
    output logic        sample_dl_wr,       // byte belongs to the sample region
    output logic [16:0] sample_dl_addr,

    input  logic [14:0] main_fixed_addr,   // 8000-FFFF offset
    output logic [7:0]  main_fixed_data,
    input  logic [3:0]  main_bank,
    input  logic [13:0] main_bank_offset,
    output logic [7:0]  main_bank_data,

    input  logic [12:0] snd_addr,          // E000-FFFF offset
    output logic [7:0]  snd_data
);
    localparam [19:0] FIXED_BASE  = 20'h00000;
    localparam [19:0] BANK_BASE   = 20'h08000;
    localparam [19:0] SND_BASE    = 20'h48000;
    localparam [19:0] SAMPLE_BASE = 20'h4A000;
    localparam [19:0] SAMPLE_END  = 20'h6A000;

    (* ramstyle = "M10K" *) logic [7:0] fixed_rom [0:32767];
    (* ramstyle = "M10K" *) logic [7:0] bank_rom  [0:262143];
    (* ramstyle = "M10K" *) logic [7:0] snd_rom   [0:8191];

    wire fixed_sel  = (dl_addr >= FIXED_BASE)  && (dl_addr < BANK_BASE);
    wire bank_sel   = (dl_addr >= BANK_BASE)   && (dl_addr < SND_BASE);
    wire snd_sel    = (dl_addr >= SND_BASE)    && (dl_addr < SAMPLE_BASE);
    wire sample_sel = (dl_addr >= SAMPLE_BASE) && (dl_addr < SAMPLE_END);

    wire [19:0] bank_dl_addr   = dl_addr - BANK_BASE;
    wire [19:0] sample_dl_off  = dl_addr - SAMPLE_BASE;
    assign sample_dl_wr   = dl_wr && sample_sel;
    assign sample_dl_addr = sample_dl_off[16:0];

    always_ff @(posedge clk) begin
        if (dl_wr && fixed_sel) fixed_rom[dl_addr[14:0]]     <= dl_data;
        if (dl_wr && bank_sel)  bank_rom[bank_dl_addr[17:0]] <= dl_data;
        if (dl_wr && snd_sel)   snd_rom[dl_addr[12:0]]       <= dl_data;

        main_fixed_data <= fixed_rom[main_fixed_addr];
        main_bank_data  <= bank_rom[{main_bank, main_bank_offset}];
        snd_data        <= snd_rom[snd_addr];
    end
endmodule
