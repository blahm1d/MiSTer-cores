// Exidy 440 video: raster, bitmap VRAM, palette, sprite line compositor,
// collision and lightgun beam FIRQs.  Transcribed from MAME 0.289
// src/mame/exidy/exidy440_v.cpp (cites as ":line").
//
// Raster (exidy440_v.cpp:13-23,470): pixel clock 6.4896 MHz, 416 x 260 total,
// 320 x 240 active, 60.000 Hz exactly.  set_raw() does not place the syncs;
// they are placed from the sync PROMs (docs/SYNC-PROMS.md).
//
// Composition (:322-348): the displayed pen is {sprite nibble, VRAM nibble};
// the palette word is {collision, R5, G5, B5} (:122-126).  Sprites are
// composited into a per-line buffer during the previous line's horizontal
// blanking, lowest sprite index winning (:279 draws 39 first, 0 last).
//
// Collision (:325-330): detected at scan time on the visible pen (the
// collision bit lives in the palette, so that is what the PCB can see).
// Documented deviation from MAME's per-sprite check: a flagged sprite pixel
// hidden under a higher-priority sprite is not reported.
//
// Beam FIRQ (:456-477): thirteen candidates on lines beamy-6..beamy+6 at
// column beamx; the game picks the middle one (:460-466 comment).
module chiller_video (
    input  logic        clk,
    input  logic        reset,
    input  logic        ce_pix,

    // Main CPU port.  cpu_rd / cpu_wr are single-clock pulses on the E enable
    // with VMA qualified; cpu_addr is stable from the preceding Q enable.
    input  logic [15:0] cpu_addr,
    input  logic [7:0]  cpu_dout,
    input  logic        cpu_rd,
    input  logic        cpu_wr,
    output logic [7:0]  cpu_din,        // valid for 0000-1FFF, 2A00-2B02, 2C00-2DFF

    // Lightgun aim, 0..255 each (MAME AN0/AN1, exidy440.cpp:795-799)
    input  logic [7:0]  gun_x,
    input  logic [7:0]  gun_y,

    // Top Secret (exidy440_v.cpp:479-484, :393-401, :412-423): 236 visible
    // lines, VRAM row scroll, no collision or beam FIRQ
    input  logic        topsecex,
    input  logic [7:0]  yscroll,

    output logic        firq_vblank,
    output logic        firq_beam,
    output logic        firq_n,         // to the 6809 nFIRQ (:225-231)
    output logic [3:0]  rom_bank,       // control bits 7:4 (:188)
    output logic        vblank_irq,     // one-clock pulse at the start of line 240

    output logic [7:0]  red,
    output logic [7:0]  green,
    output logic [7:0]  blue,
    output logic        hblank,
    output logic        vblank,
    output logic        hsync,
    output logic        vsync,
    output logic [8:0]  raster_h,
    output logic [8:0]  raster_v,
    output logic        debug_render_overrun
);
    localparam HTOTAL  = 416;
    localparam HACTIVE = 320;
    localparam HS_BEG  = 344;   // sync PROM xbl.9h: 3 characters into blanking
    localparam HS_END  = 376;   // 32 pixels wide
    localparam VTOTAL  = 260;
    localparam VACTIVE = 240;   // wrap height (:308,:398); the visible height is vactive below
    localparam VS_BEG  = 244;   // sync PROM xbl.12h: 4 lines into blanking
    localparam VS_END  = 248;   // 4 lines wide

    // ------------------------------------------------------------------
    // Raster counters
    // ------------------------------------------------------------------
    logic [8:0] hcnt, vcnt;
    logic [3:0] phase;              // master clocks since the last ce_pix
    wire  [8:0] vactive = topsecex ? 9'd236 : 9'd240;   // TOPSECEX_VBSTART (:26)
    wire        last_h = (hcnt == HTOTAL - 1);
    wire        last_v = (vcnt == VTOTAL - 1);
    wire [8:0]  next_v = last_v ? 9'd0 : vcnt + 9'd1;

    wire [8:0]  next_h = last_h ? 9'd0 : hcnt + 9'd1;
    wire [8:0]  next_v_at_h = last_h ? next_v : vcnt;   // vcnt after this pixel edge

    always_ff @(posedge clk) begin
        if (reset) begin
            hcnt  <= '0;
            vcnt  <= '0;
            phase <= '0;
        end else if (ce_pix) begin
            phase <= '0;
            hcnt  <= next_h;
            vcnt  <= next_v_at_h;
        end else begin
            phase <= phase + 4'd1;
        end
    end

    assign raster_h = hcnt;
    assign raster_v = vcnt;

    // ------------------------------------------------------------------
    // Control register (:180-194) and interrupt flags (:139-147,211-231)
    // ------------------------------------------------------------------
    logic firq_enable, firq_select, pal_io, pal_vis;
    logic [7:0] scanline_sel;       // 2B02 (:451, share "scanline")
    logic [7:0] latched_x;          // 2B01 read (:139-147)

    wire ctrl_wr     = cpu_wr && (cpu_addr == 16'h2B03);
    wire scan_wr     = cpu_wr && (cpu_addr == 16'h2B02);
    wire vbl_clr_wr  = cpu_wr && (cpu_addr == 16'h2B01);
    wire beam_clr_rd = cpu_rd && (cpu_addr == 16'h2B01);

    assign firq_n = ~(firq_vblank | (firq_enable & firq_beam));

    // vblank start: MAME screen_vblank(1) at (VBSTART, 0)
    wire vbl_start = ce_pix && last_h && (next_v == vactive);
    assign vblank_irq = vbl_start;

    // Gun aim sampled once per frame at the end of the visible area (:456-458).
    // MAME arms the beam timer only from that first frame end; before it no
    // beam event exists (the family gate caught a bogus latch at (0,0) during
    // the first frame: Crossbow's COM $2B01 read 1 where MAME reads 0).
    logic [8:0] beamx, beamy;
    logic       beam_armed;
    wire [16:0] beamx_mul = gun_x * 9'd320;
    wire [15:0] beamy_mul = gun_y * 8'd240;

    // Collision / beam events computed in the scan pipeline below
    logic collide_event, beam_event;
    logic [8:0] event_x;
    wire  [8:0] event_x_half = (event_x + 9'd1) >> 1;
    wire  [7:0] event_x_latch = (event_x_half[7:0] + 8'd3) ^ 8'h02;   // :245-248,263-265

    always_ff @(posedge clk) begin
        if (reset) begin
            firq_enable  <= 1'b0;
            firq_select  <= 1'b0;
            pal_io       <= 1'b0;
            pal_vis      <= 1'b0;
            rom_bank     <= 4'd0;
            firq_vblank  <= 1'b0;
            firq_beam    <= 1'b0;
            scanline_sel <= 8'd0;
            latched_x    <= 8'd0;
            beamx        <= 9'd0;
            beamy        <= 9'd0;
            beam_armed   <= 1'b0;
        end else begin
            if (ctrl_wr) begin
                rom_bank    <= cpu_dout[7:4];
                firq_enable <= cpu_dout[3];
                firq_select <= cpu_dout[2];
                pal_io      <= cpu_dout[1];
                pal_vis     <= cpu_dout[0];
            end
            if (scan_wr) scanline_sel <= cpu_dout;

            if (vbl_clr_wr)  firq_vblank <= 1'b0;
            if (beam_clr_rd) firq_beam   <= 1'b0;

            if (vbl_start) begin
                firq_vblank <= 1'b1;
                beamx <= beamx_mul[16:8];
                beamy <= beamy_mul[15:8];
                beam_armed <= 1'b1;
            end

            // Both events always latch X; only the selected source raises FIRQ.
            if (collide_event && !topsecex) begin
                latched_x <= event_x_latch;
                if (!firq_select && firq_enable) firq_beam <= 1'b1;
            end
            if (beam_event && !topsecex) begin
                latched_x <= event_x_latch;
                if (firq_select && firq_enable) firq_beam <= 1'b1;
            end
        end
    end

    // ------------------------------------------------------------------
    // Memories
    // ------------------------------------------------------------------
    // Image RAM: 64 images x 128 bytes (:293, exidy440.cpp:47-49)
    logic [7:0]  image_cpu_q, image_rd_q;
    logic [12:0] image_rd_addr;

    // VRAM: 256 rows x 256 bytes, two 4-bit pixels per byte (:78-95)
    logic [7:0]  vram_cpu_q, vram_scan_q;
    wire  [15:0] vram_cpu_addr = {scanline_sel, cpu_addr[7:0]};
    logic [15:0] vram_scan_addr;

    // Palette: 2 banks x 256 words, split into even/odd byte RAMs (:103-128)
    logic [7:0] pal_cpu_even_q, pal_cpu_odd_q, pal_scan_even_q, pal_scan_odd_q;
    wire  [8:0] pal_cpu_addr = {pal_io, cpu_addr[8:1]};
    logic [8:0] pal_scan_addr;      // registered at phase 3

    // Sprite RAM: 40 entries x 4 bytes, one MLAB lane per byte (:283-286)
    (* ramstyle = "MLAB, no_rw_check" *) logic [7:0] spr0 [0:63];
    initial for (int spr0_i = 0; spr0_i < 64; spr0_i++) spr0[spr0_i] = '0;
    (* ramstyle = "MLAB, no_rw_check" *) logic [7:0] spr1 [0:63];
    initial for (int spr1_i = 0; spr1_i < 64; spr1_i++) spr1[spr1_i] = '0;
    (* ramstyle = "MLAB, no_rw_check" *) logic [7:0] spr2 [0:63];
    initial for (int spr2_i = 0; spr2_i < 64; spr2_i++) spr2[spr2_i] = '0;
    (* ramstyle = "MLAB, no_rw_check" *) logic [7:0] spr3 [0:63];
    initial for (int spr3_i = 0; spr3_i < 64; spr3_i++) spr3[spr3_i] = '0;
    logic [5:0] spr_rd_idx;
    logic [7:0] spr0_q, spr1_q, spr2_q, spr3_q;

    // Sprite line buffer: two banks x 512 x 4 bits
    logic [9:0] lb_wr_addr, lb_scan_addr;
    logic [3:0] lb_wr_data, lb_scan_q;
    logic       lb_wr_en, lb_scan_clr;

    wire image_sel = (cpu_addr[15:13] == 3'b000);
    wire spr_sel   = (cpu_addr[15:8] == 8'h20) && (cpu_addr[7:0] < 8'hA0);
    wire vram_sel  = (cpu_addr[15:8] == 8'h2A);
    wire pal_sel   = (cpu_addr[15:9] == 7'b0010_110);      // 2C00-2DFF

    // True dual-port memories (chiller_dpram): port A = CPU, port B = video.
    chiller_dpram #(.AW(13), .DW(8)) u_image_ram (
        .clk(clk),
        .addr_a(cpu_addr[12:0]), .din_a(cpu_dout), .we_a(cpu_wr && image_sel), .q_a(image_cpu_q),
        .addr_b(image_rd_addr),  .din_b(8'd0),     .we_b(1'b0),                .q_b(image_rd_q)
    );
    chiller_dpram #(.AW(16), .DW(8)) u_vram (
        .clk(clk),
        .addr_a(vram_cpu_addr),  .din_a(cpu_dout), .we_a(cpu_wr && vram_sel),  .q_a(vram_cpu_q),
        .addr_b(vram_scan_addr), .din_b(8'd0),     .we_b(1'b0),                .q_b(vram_scan_q)
    );
    chiller_dpram #(.AW(9), .DW(8)) u_pal_even (
        .clk(clk),
        .addr_a(pal_cpu_addr),  .din_a(cpu_dout), .we_a(cpu_wr && pal_sel && !cpu_addr[0]), .q_a(pal_cpu_even_q),
        .addr_b(pal_scan_addr), .din_b(8'd0),     .we_b(1'b0),                              .q_b(pal_scan_even_q)
    );
    chiller_dpram #(.AW(9), .DW(8)) u_pal_odd (
        .clk(clk),
        .addr_a(pal_cpu_addr),  .din_a(cpu_dout), .we_a(cpu_wr && pal_sel && cpu_addr[0]), .q_a(pal_cpu_odd_q),
        .addr_b(pal_scan_addr), .din_b(8'd0),     .we_b(1'b0),                             .q_b(pal_scan_odd_q)
    );
    // Line buffer: port A renderer write, port B scan read with clear-after-read
    chiller_dpram #(.AW(10), .DW(4)) u_linebuf (
        .clk(clk),
        .addr_a(lb_wr_addr),   .din_a(lb_wr_data), .we_a(lb_wr_en),    .q_a(),
        .addr_b(lb_scan_addr), .din_b(4'd0),       .we_b(lb_scan_clr), .q_b(lb_scan_q)
    );

    // Sprite lanes: simple dual port, one block per lane
    always_ff @(posedge clk) begin
        if (cpu_wr && spr_sel && cpu_addr[1:0] == 2'd0) spr0[cpu_addr[7:2]] <= cpu_dout;
        spr0_q <= spr0[spr_rd_idx];
    end
    always_ff @(posedge clk) begin
        if (cpu_wr && spr_sel && cpu_addr[1:0] == 2'd1) spr1[cpu_addr[7:2]] <= cpu_dout;
        spr1_q <= spr1[spr_rd_idx];
    end
    always_ff @(posedge clk) begin
        if (cpu_wr && spr_sel && cpu_addr[1:0] == 2'd2) spr2[cpu_addr[7:2]] <= cpu_dout;
        spr2_q <= spr2[spr_rd_idx];
    end
    always_ff @(posedge clk) begin
        if (cpu_wr && spr_sel && cpu_addr[1:0] == 2'd3) spr3[cpu_addr[7:2]] <= cpu_dout;
        spr3_q <= spr3[spr_rd_idx];
    end

    // CPU read mux (:78-83 VRAM byte, :150-160 vpos, :139-147 latched X)
    wire [7:0] vpos = (vcnt > 9'd255) ? 8'd255 : vcnt[7:0];
    always_comb begin
        cpu_din = 8'h00;
        if (image_sel)                       cpu_din = image_cpu_q;
        else if (vram_sel)                   cpu_din = vram_cpu_q;
        else if (cpu_addr == 16'h2B00)       cpu_din = vpos;
        else if (cpu_addr == 16'h2B01)       cpu_din = latched_x;
        else if (cpu_addr == 16'h2B02)       cpu_din = scanline_sel;
        else if (pal_sel)                    cpu_din = cpu_addr[0] ? pal_cpu_odd_q : pal_cpu_even_q;
    end

    // ------------------------------------------------------------------
    // Sprite line renderer (:271-355), runs during horizontal blanking of
    // the line before the one it composes.
    // ------------------------------------------------------------------
    typedef enum logic [2:0] {R_IDLE, R_FETCH, R_EVAL, R_ADDR, R_LEFT, R_RIGHT} rstate_t;
    rstate_t rstate;
    logic [5:0]  r_idx;
    logic [8:0]  r_line;
    logic        r_bank;
    logic [5:0]  r_image;
    logic [3:0]  r_row;
    logic [2:0]  r_byte;
    logic signed [10:0] r_x;       // current pixel x, signed (-16 .. 335)
    logic        r_busy_at_line_start;

    // Composition starts as the current line enters horizontal blanking
    // (hcnt 319 -> 320) and targets the line after it.
    wire        render_go = ce_pix && (hcnt == HACTIVE - 1) && (next_v_line < vactive);
    wire [8:0]  next_v_line = next_v;
    // Sprite decode (:283-296)
    wire [8:0]  s_yoffs = {1'b0, ~spr0_q} + 9'd1;
    wire signed [10:0] s_dy = $signed({2'b00, s_yoffs}) - $signed({2'b00, r_line});
    wire [8:0]  s_xraw = ~{spr1_q[0], spr2_q};
    wire signed [10:0] s_x = (s_xraw >= 9'h1EF) ? ($signed({2'b00, s_xraw}) - 11'sd511)
                                                : $signed({2'b00, s_xraw});
    wire        s_visible = (s_dy >= 0) && (s_dy <= 15);
    wire [3:0]  pix_left  = image_rd_q[7:4];
    wire [3:0]  pix_right = image_rd_q[3:0];
    wire        x_on_screen = (r_x >= 0) && (r_x < HACTIVE);

    always_ff @(posedge clk) begin
        lb_wr_en <= 1'b0;
        debug_render_overrun <= 1'b0;
        if (reset) begin
            rstate <= R_IDLE;
            r_idx  <= 6'd0;
        end else begin
            if (ce_pix && last_h && rstate != R_IDLE) debug_render_overrun <= 1'b1;
            case (rstate)
                R_IDLE: if (render_go) begin
                    r_idx      <= 6'd39;
                    r_line     <= next_v_line;
                    r_bank     <= next_v_line[0];
                    spr_rd_idx <= 6'd39;
                    rstate     <= R_FETCH;
                end
                R_FETCH: rstate <= R_EVAL;               // sprite lanes registered
                R_EVAL: begin
                    if (s_visible) begin
                        r_image <= ~spr3_q[5:0];
                        r_row   <= s_dy[3:0];
                        r_x     <= s_x;
                        r_byte  <= 3'd0;
                        image_rd_addr <= {~spr3_q[5:0], s_dy[3:0], 3'd0};
                        rstate  <= R_ADDR;
                    end else if (r_idx == 6'd0) begin
                        rstate <= R_IDLE;
                    end else begin
                        r_idx      <= r_idx - 6'd1;
                        spr_rd_idx <= r_idx - 6'd1;
                        rstate     <= R_FETCH;
                    end
                end
                R_ADDR: rstate <= R_LEFT;                // image byte registered
                R_LEFT: begin
                    if (pix_left != 4'd0 && x_on_screen) begin
                        lb_wr_en   <= 1'b1;
                        lb_wr_addr <= {r_bank, r_x[8:0]};
                        lb_wr_data <= pix_left;
                    end
                    r_x    <= r_x + 11'sd1;
                    rstate <= R_RIGHT;
                end
                R_RIGHT: begin
                    if (pix_right != 4'd0 && x_on_screen) begin
                        lb_wr_en   <= 1'b1;
                        lb_wr_addr <= {r_bank, r_x[8:0]};
                        lb_wr_data <= pix_right;
                    end
                    r_x <= r_x + 11'sd1;
                    if (r_byte == 3'd7) begin
                        if (r_idx == 6'd0) begin
                            rstate <= R_IDLE;
                        end else begin
                            r_idx      <= r_idx - 6'd1;
                            spr_rd_idx <= r_idx - 6'd1;
                            rstate     <= R_FETCH;
                        end
                    end else begin
                        r_byte        <= r_byte + 3'd1;
                        image_rd_addr <= {r_image, r_row, r_byte + 3'd1};
                        rstate        <= R_ADDR;
                    end
                end
                default: rstate <= R_IDLE;
            endcase
        end
    end

    // ------------------------------------------------------------------
    // Scan-out pipeline: one pixel per ce_pix (12 master clocks), addresses
    // registered so the cascaded VRAM/line-buffer address paths get two
    // clocks (SDC multicycle 2 from vram_scan_addr / lb_scan_addr):
    //   phase 0: counters updated; VRAM / line-buffer addresses registered
    //   phase 1: beam comparison
    //   phase 2: VRAM and line-buffer data valid (two-clock address path)
    //   phase 3: pen -> palette address registered
    //   phase 5: palette word valid -> colour, collision
    //   phase 6: line-buffer clear-after-read
    //   next ce_pix: outputs registered with the matching blank/sync
    // ------------------------------------------------------------------
    logic       vis, vis_q;
    logic [3:0] spr_nib, bg_nib;
    logic [15:0] pal_word;
    logic [7:0] r_next, g_next, b_next;

    wire  [8:0] scroll_sum = next_v_at_h + {1'b0, yscroll};
    wire  [8:0] scroll_row = (scroll_sum >= 9'd240) ? scroll_sum - 9'd240 : scroll_sum;   // single wrap (:398-401)
    always_ff @(posedge clk) if (ce_pix) begin
        vram_scan_addr <= {scroll_row[7:0], next_h[8:1]};
        lb_scan_addr   <= {next_v_at_h[0], next_h};
    end
    assign vis     = (hcnt < HACTIVE) && (vcnt < vactive);
    assign bg_nib  = hcnt[0] ? vram_scan_q[3:0] : vram_scan_q[7:4];
    assign spr_nib = lb_scan_q;
    assign pal_word = {pal_scan_even_q, pal_scan_odd_q};

    function automatic [7:0] pal5(input [4:0] v);
        pal5 = {v, v[4:2]};
    endfunction

    always_ff @(posedge clk) begin
        lb_scan_clr   <= 1'b0;
        collide_event <= 1'b0;
        beam_event    <= 1'b0;
        if (reset) begin
            r_next <= '0; g_next <= '0; b_next <= '0;
            red <= '0; green <= '0; blue <= '0;
            hblank <= 1'b1; vblank <= 1'b1; hsync <= 1'b0; vsync <= 1'b0;
            pal_scan_addr <= '0;
        end else begin
            if (phase == 4'd1) begin
                if (beam_armed && (hcnt == beamx) && (vcnt + 9'd6 >= beamy) && (vcnt <= beamy + 9'd6)) begin
                    beam_event <= 1'b1;
                    event_x    <= hcnt;
                end
            end
            if (phase == 4'd3) pal_scan_addr <= {pal_vis, spr_nib, bg_nib};
            if (phase == 4'd5) begin
                r_next <= vis ? pal5(pal_word[14:10]) : 8'd0;
                g_next <= vis ? pal5(pal_word[9:5])   : 8'd0;
                b_next <= vis ? pal5(pal_word[4:0])   : 8'd0;
                if (vis && spr_nib != 4'd0 && pal_word[15]) begin
                    collide_event <= 1'b1;
                    event_x       <= hcnt;
                end
            end
            if (phase == 4'd6 && vis) lb_scan_clr <= 1'b1;
            if (ce_pix) begin
                red    <= r_next;
                green  <= g_next;
                blue   <= b_next;
                hblank <= (hcnt >= HACTIVE);
                vblank <= (vcnt >= vactive);
                hsync  <= (hcnt >= HS_BEG) && (hcnt < HS_END);
                vsync  <= (vcnt >= VS_BEG) && (vcnt < VS_END);
            end
        end
    end
endmodule
