// Four-channel CVSD decoder (2 x MC3418 4-bit, 2 x MC3417 3-bit) with the
// Exidy 440 output FIR, time-multiplexed on the master clock.
//
// This is the fixed-point specification in sim/tools/cvsd_golden.py
// (decode_fixed), itself a transcription of MAME 0.289 exidy440_a.cpp
// :544-651 (decode) and :512-533 (FIR).  The RTL must be bit-exact against
// decode_fixed for every burst; constants come from fixed_constants().
//
// Per channel bit clock (ce for ch0/1 = 50.7 kHz, ch2/3 = 25.35 kHz):
//   integrator += bit ? filt : -filt;  steps = ((steps << 1) | bit) & mask
//   integrator = (integrator * leak) >> 16
//   all-ones/all-zeros: filt = fmax - ((fmax - filt) * charge >> 16)
//   otherwise:          filt = (filt * decay) >> 16, floor fmin
//   temp = (integrator * 10000) >> 20;  sample = 32768*temp/(32768+|temp|)
//   FIR over the last 57 samples, >> 14, clamp to 16 bits
//
// chan_restart resets a channel's decoder and FIR history, which is what
// MAME does at the start of every DMA burst (the cache decodes each burst
// from the reset state).  When a channel carries no bit (DMA idle) the
// integrator leaks toward zero instead of MAME's cache-tail zeroing.
module chiller_cvsd (
    input  logic        clk,
    input  logic        reset,
    input  logic        ce_cvsd,        // 50.7 kHz tick
    input  logic        ce_cvsd_half,   // 25.35 kHz tick (coincides with ce_cvsd)
    input  logic [3:0]  chan_restart,   // pulse: reset decoder state of channel
    input  logic [3:0]  bit_valid,      // channel has a live DMA bit this tick
    input  logic [3:0]  bit_data,
    output logic signed [15:0] sample0,
    output logic signed [15:0] sample1,
    output logic signed [15:0] sample2,
    output logic signed [15:0] sample3,
    output logic        busy
);
    // fixed_constants(50700) and fixed_constants(25350)
    localparam [16:0] LEAK_F   = 17'd64256, CHARGE_F = 17'd65319, DECAY_F = 17'd65352;
    localparam [16:0] LEAK_S   = 17'd63001, CHARGE_S = 17'd65102, DECAY_S = 17'd65169;
    localparam [20:0] FMIN     = 21'd43621;
    localparam [20:0] FMAX     = 21'd1148610;
    localparam        FIR_LEN  = 57;

    function automatic signed [13:0] fir_tap(input [5:0] d);
        case (d)
            6'd0:  fir_tap = 14'sd8;     6'd1:  fir_tap = 14'sd4;     6'd2:  fir_tap = -14'sd16;
            6'd3:  fir_tap = -14'sd32;   6'd4:  fir_tap = -14'sd16;   6'd5:  fir_tap = 14'sd16;
            6'd6:  fir_tap = 14'sd64;    6'd7:  fir_tap = 14'sd64;    6'd8:  fir_tap = -14'sd4;
            6'd9:  fir_tap = -14'sd64;   6'd10: fir_tap = -14'sd128;  6'd11: fir_tap = -14'sd32;
            6'd12: fir_tap = 14'sd128;   6'd13: fir_tap = 14'sd128;   6'd14: fir_tap = 14'sd128;
            6'd15: fir_tap = -14'sd64;   6'd16: fir_tap = -14'sd256;  6'd17: fir_tap = -14'sd256;
            6'd18: fir_tap = 14'sd8;     6'd19: fir_tap = 14'sd256;   6'd20: fir_tap = 14'sd512;
            6'd21: fir_tap = 14'sd128;   6'd22: fir_tap = -14'sd512;  6'd23: fir_tap = -14'sd1024;
            6'd24: fir_tap = -14'sd512;  6'd25: fir_tap = 14'sd512;   6'd26: fir_tap = 14'sd2048;
            6'd27: fir_tap = 14'sd4096;  6'd28: fir_tap = 14'sd4096;  6'd29: fir_tap = 14'sd4096;
            6'd30: fir_tap = 14'sd2048;  6'd31: fir_tap = 14'sd512;   6'd32: fir_tap = -14'sd512;
            6'd33: fir_tap = -14'sd1024; 6'd34: fir_tap = -14'sd512;  6'd35: fir_tap = 14'sd128;
            6'd36: fir_tap = 14'sd512;   6'd37: fir_tap = 14'sd256;   6'd38: fir_tap = 14'sd8;
            6'd39: fir_tap = -14'sd256;  6'd40: fir_tap = -14'sd256;  6'd41: fir_tap = -14'sd64;
            6'd42: fir_tap = 14'sd128;   6'd43: fir_tap = 14'sd128;   6'd44: fir_tap = 14'sd128;
            6'd45: fir_tap = -14'sd32;   6'd46: fir_tap = -14'sd128;  6'd47: fir_tap = -14'sd64;
            6'd48: fir_tap = -14'sd4;    6'd49: fir_tap = 14'sd64;    6'd50: fir_tap = 14'sd64;
            6'd51: fir_tap = 14'sd16;    6'd52: fir_tap = -14'sd16;   6'd53: fir_tap = -14'sd32;
            6'd54: fir_tap = -14'sd16;   6'd55: fir_tap = 14'sd4;     6'd56: fir_tap = 14'sd8;
            default: fir_tap = 14'sd0;
        endcase
    endfunction

    // Per-channel state
    logic signed [31:0] integ [0:3];
    logic        [20:0] filt  [0:3];
    logic        [3:0]  steps [0:3];
    logic        [5:0]  wptr  [0:3];      // FIR history write pointer
    logic        [5:0]  hcount[0:3];      // valid history entries (saturates at 57)
    logic        [3:0]  restart_pending;
    logic               ce_d, ce_half_d;
    logic        [3:0]  tick_pending;
    logic        [3:0]  tick_valid;
    logic        [3:0]  tick_data;

    // FIR history: 4 channels x 64 x 16 bits
    (* ramstyle = "MLAB" *) logic signed [15:0] hist [0:255];
    initial for (int hist_i = 0; hist_i < 256; hist_i++) hist[hist_i] = '0;   // power-up zero, as MAME
    logic [7:0] hist_rd_addr;
    logic signed [15:0] hist_q;

    typedef enum logic [3:0] {IDLE, LOAD, STEP, STEP2, LEAK, FILT, FILT2, TEMP, DIV_INIT, DIV, PUSH,
                              FIR_WAIT, FIR_MAC, FIR_DRAIN, DONE} st_t;
    st_t st;
    logic [1:0] ch;
    logic       cur_valid, cur_bit;
    logic signed [31:0] w_integ;
    logic        [20:0] w_filt;
    logic        [3:0]  w_steps;
    logic        [3:0]  w_mask;
    logic        [16:0] k_leak, k_charge, k_decay;
    logic signed [48:0] prod_leak;
    logic        [37:0] prod_charge, prod_decay;
    logic signed [46:0] prod_gain;
    logic signed [26:0] temp;
    logic        [19:0] mag;
    logic               neg;
    logic        [35:0] dividend;
    logic        [20:0] divisor;
    logic        [21:0] rem;
    logic        [15:0] quot;
    logic        [5:0]  div_cnt;
    logic signed [15:0] sample;
    logic signed [31:0] acc;
    logic        [5:0]  tap;
    logic        [5:0]  tap_q;
    logic               coincide;
    logic        [20:0] fmax_minus_filt;
    logic               fir_v1, fir_v2;
    logic signed [13:0] fir_c1;
    logic signed [15:0] fir_h1;
    logic signed [29:0] fir_p2;
    logic        [2:0]  drain;

    assign busy = (st != IDLE);

    // Divider step (restoring): next partial remainder
    wire [21:0] div_r = {rem[20:0], dividend[34]};

    // FIR result: acc >> 14 (arithmetic), clamped to 16 bits (:529-533)
    wire signed [17:0] fir_sh = acc[31:14];
    wire signed [15:0] fir_clamped = (fir_sh > 18'sd32767)  ? 16'sd32767 :
                                     (fir_sh < -18'sd32768) ? 16'sh8000 : fir_sh[15:0];

    wire [3:0] mask_of_ch = (ch[1]) ? 4'b0111 : 4'b1111;   // exidy440_a.cpp:43-47

    integer i;
    always_ff @(posedge clk) begin
        if (reset) begin
            st <= IDLE;
            tick_pending <= 4'd0;
            restart_pending <= 4'd0;
            for (i = 0; i < 4; i = i + 1) begin
                integ[i] <= 32'sd0; filt[i] <= FMIN; steps[i] <= 4'hA;
                wptr[i] <= 6'd0; hcount[i] <= 6'd0;
            end
            sample0 <= '0; sample1 <= '0; sample2 <= '0; sample3 <= '0;
        end else begin
            restart_pending <= restart_pending | chan_restart;
            // The DMA engine presents its bit on the clock after the tick
            // (it reacts to ce_cvsd with a registered assignment), so sample
            // one clock late as well.
            ce_d      <= ce_cvsd;
            ce_half_d <= ce_cvsd_half;
            if (ce_d) begin
                tick_pending <= {ce_half_d, ce_half_d, 1'b1, 1'b1};
                tick_valid   <= bit_valid;
                tick_data    <= bit_data;
            end

            case (st)
                IDLE: begin
                    if (tick_pending[0])      begin ch <= 2'd0; st <= LOAD; end
                    else if (tick_pending[1]) begin ch <= 2'd1; st <= LOAD; end
                    else if (tick_pending[2]) begin ch <= 2'd2; st <= LOAD; end
                    else if (tick_pending[3]) begin ch <= 2'd3; st <= LOAD; end
                end
                LOAD: begin
                    tick_pending[ch] <= 1'b0;
                    cur_valid <= tick_valid[ch];
                    cur_bit   <= tick_data[ch];
                    w_mask    <= mask_of_ch;
                    k_leak    <= ch[1] ? LEAK_S   : LEAK_F;
                    k_charge  <= ch[1] ? CHARGE_S : CHARGE_F;
                    k_decay   <= ch[1] ? DECAY_S  : DECAY_F;
                    if (restart_pending[ch]) begin
                        restart_pending[ch] <= 1'b0;
                        w_integ  <= 32'sd0;
                        w_filt   <= FMIN;
                        w_steps  <= 4'hA & mask_of_ch;
                        hcount[ch] <= 6'd0;
                    end else begin
                        w_integ  <= integ[ch];
                        w_filt   <= filt[ch];
                        w_steps  <= steps[ch];
                    end
                    st <= STEP;
                end
                STEP: begin
                    if (cur_valid) begin
                        w_integ <= cur_bit ? (w_integ + $signed({11'd0, w_filt}))
                                           : (w_integ - $signed({11'd0, w_filt}));
                        w_steps <= ((w_steps << 1) | {3'd0, cur_bit}) & w_mask;
                    end
                    fmax_minus_filt <= FMAX - w_filt;
                    st <= STEP2;
                end
                STEP2: st <= LEAK;   // multiplier inputs stable for two clocks (SDC multicycle 2)
                LEAK: begin
                    prod_leak   <= w_integ * $signed({1'b0, k_leak});
                    prod_charge <= fmax_minus_filt * k_charge;
                    prod_decay  <= w_filt * k_decay;
                    coincide    <= cur_valid && ((w_steps == 4'd0) || (w_steps == w_mask));
                    st <= FILT;
                end
                FILT: begin
                    w_integ <= prod_leak[47:16];
                    if (coincide) begin
                        w_filt <= FMAX - prod_charge[36:16];   // never exceeds FMAX
                    end else begin
                        w_filt <= (prod_decay[36:16] < FMIN) ? FMIN : prod_decay[36:16];
                    end
                    st <= FILT2;
                end
                FILT2: st <= TEMP;   // w_integ stable for two clocks before the gain multiply
                TEMP: begin
                    prod_gain <= w_integ * 15'sd10000;
                    st <= DIV_INIT;
                end
                DIV_INIT: begin
                    temp    <= prod_gain[46:20];
                    st <= DIV;
                    div_cnt <= 6'd0;
                    rem     <= 22'd0;
                    quot    <= 16'd0;
                    neg     <= prod_gain[46];
                    // |temp| as a 20-bit magnitude
                    mag     <= prod_gain[46] ? (~prod_gain[39:20] + 20'd1) : prod_gain[39:20];
                end
                DIV: begin
                    // Restoring division: dividend = mag << 15 (35 bits), divisor = 32768 + mag
                    // Iterate over the 35 dividend bits, MSB first.  Quotient < 32768.
                    if (div_cnt == 6'd0) begin
                        dividend <= {1'b0, mag, 15'd0};
                        divisor  <= 21'd32768 + {1'b0, mag};
                        div_cnt  <= 6'd1;
                    end else if (div_cnt <= 6'd35) begin
                        dividend <= {dividend[33:0], 1'b0};
                        if (div_r >= {1'b0, divisor}) begin
                            rem  <= div_r - {1'b0, divisor};
                            quot <= {quot[14:0], 1'b1};
                        end else begin
                            rem  <= div_r;
                            quot <= {quot[14:0], 1'b0};
                        end
                        div_cnt <= div_cnt + 6'd1;
                    end else begin
                        sample <= neg ? -$signed({1'b0, quot[14:0]}) : $signed({1'b0, quot[14:0]});
                        st <= PUSH;
                    end
                end
                PUSH: begin
                    hist[{ch, wptr[ch]}] <= sample;
                    integ[ch] <= w_integ;
                    filt[ch]  <= w_filt;
                    steps[ch] <= w_steps;
                    if (hcount[ch] != 6'd57) hcount[ch] <= hcount[ch] + 6'd1;
                    acc <= 32'sd0;
                    tap <= 6'd0;
                    hist_rd_addr <= {ch, wptr[ch]};       // tap 0 = newest
                    fir_v1 <= 1'b0; fir_v2 <= 1'b0;
                    st <= FIR_WAIT;
                end
                FIR_WAIT: begin
                    tap_q <= tap;
                    hist_rd_addr <= {ch, wptr[ch] - tap - 6'd1};   // prefetch next
                    tap <= tap + 6'd1;
                    st <= FIR_MAC;
                end
                // Three-stage MAC pipeline: (1) hist_q/tap_q valid -> coefficient
                // and sample registered, (2) product registered, (3) accumulate.
                FIR_MAC: begin
                    fir_v1  <= (tap_q < hcount[ch]);      // hcount already includes the new sample
                    fir_c1  <= fir_tap(tap_q);
                    fir_h1  <= hist_q;
                    fir_v2  <= fir_v1;
                    fir_p2  <= fir_h1 * fir_c1;
                    if (fir_v2) acc <= acc + fir_p2;   // v2 and p2 hold the same tap
                    tap_q <= tap;
                    hist_rd_addr <= {ch, wptr[ch] - tap - 6'd1};
                    tap <= tap + 6'd1;
                    if (tap_q == 6'd56) begin
                        drain <= 3'd0;
                        st <= FIR_DRAIN;
                    end
                end
                FIR_DRAIN: begin
                    fir_v1  <= 1'b0;
                    fir_v2  <= fir_v1;
                    fir_p2  <= fir_h1 * fir_c1;
                    if (fir_v2) acc <= acc + fir_p2;   // v2 and p2 hold the same tap
                    drain <= drain + 3'd1;
                    if (drain == 3'd1) st <= DONE;
                end
                DONE: begin
                    wptr[ch] <= wptr[ch] + 6'd1;
                    case (ch)
                        2'd0: sample0 <= fir_clamped;
                        2'd1: sample1 <= fir_clamped;
                        2'd2: sample2 <= fir_clamped;
                        default: sample3 <= fir_clamped;
                    endcase
                    st <= IDLE;
                end
                default: st <= IDLE;
            endcase
        end
        hist_q <= hist[hist_rd_addr];
    end
endmodule
