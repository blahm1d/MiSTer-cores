Invasion: The Abductors / inv9 / blahm1d
Corresponding integration source from the preserved September 27 build.
Target: DE10-Nano, Cyclone V 5CSEBA6U23I7.
Quartus Prime Lite 17.0.2 build 602, seed 5.
Profile: ZK4_DCS_FABRIC=1, ZK4_CPU_NOBTB=1, ZK4_GAME_INVASION=1.

Open quartus/zk4.qpf to inspect or rebuild. Rebuilds require independent
qualification. This is the existing timing-waived engineering build; the
preserved timing report has worst setup slack -0.206 ns. No new compile ran.
The RTL and constraints are unchanged. Source export changes are recorded
in SOURCE-MANIFEST.json. Third-party copyright/license notices are retained.
The old preparation manifest predates final QSF profile/search-path pinning;
the exported manifest records actual frozen file hashes separately.
Host build launchers and compilation databases are omitted. Game ROMs are
loaded at runtime and are not included.
RBF SHA-256: 136b3fc8438ab46de6ff2f43539744a2217af30d799f6a93993eae10868c0413
