// Gate for zr_render3 -- the WHOLE renderer (front end -> setup -> pixel pipe) against MAME, end to end.
// Input: the capture's CPU writes to the Zeus 1 window (io.log.gz), replayed from the capture's seed. Output compared:
// at every frame boundary (frames.txt, the point MAME's frame buffer was dumped), wave RAM 1 -- the colour words of
// BOTH frame buffers -- and the render buffer's depth (on chip, read over the debug port), against MAME's dump,
// word-exact. No golden model in the loop: this is the RTL against MAME.
// The testbench is the wave RAM, shared by three ports: the front end's (pipelined, in-order responses: models and
// host access), the pixel pipe's texture-line reads (fixed latency) and its colour writes / reads.
// usage: tb_zr_render3 <render-evidence> [frames] [mlat] [w0lat] [crlat] [cw-backpressure%]
#include "Vzr_render3.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <deque>
#include <zlib.h>

typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8; typedef int32_t s32; typedef uint64_t u64;
static std::vector<u8> read_gz(const std::string& p) {
    std::vector<u8> out; gzFile f = gzopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    u8 buf[1 << 16]; int n; while ((n = gzread(f, buf, sizeof buf)) > 0) out.insert(out.end(), buf, buf + n); gzclose(f); return out;
}
static std::vector<u8> read_file(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); std::vector<u8> v(n); if (fread(v.data(), 1, n, f) != (size_t)n) exit(2); fclose(f); return v;
}
template <class T> static T item(const std::string& ev, const char* name) {
    std::vector<u8> v = read_gz(ev + "/seed_item_0_" + name + ".bin.gz"); T t; memcpy(&t, v.data(), sizeof(T)); return t;
}
static u64 rs = 0x243F6A8885A308D3ull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

int main(int argc, char** argv) {
    if (argc < 2) { printf("usage: tb_zr_render3 <evidence> [frames] [mlat] [w0lat] [crlat] [cw-bp%%]\n"); return 2; }
    std::string ev = argv[1]; int maxf = argc > 2 ? atoi(argv[2]) : 1 << 30;
    int MLAT = argc > 3 ? atoi(argv[3]) : 8, W0LAT = argc > 4 ? atoi(argv[4]) : 8, CRLAT = argc > 5 ? atoi(argv[5]) : 8;
    int CWBP = argc > 6 ? atoi(argv[6]) : 0, GBP = argc > 7 ? atoi(argv[7]) : 0;
    std::vector<u8> w[2] = {read_gz(ev + "/seed_item_0_m_waveram_0_.bin.gz"), read_gz(ev + "/seed_item_0_m_waveram_1_.bin.gz")};
    std::vector<u8> regs = read_file(ev + "/seed_zeus1_regs.bin");
    std::vector<u8> fifo = read_gz(ev + "/seed_item_0_m_zeus_fifo.bin.gz");
    std::vector<u8> mtx = read_gz(ev + "/seed_item_0_m_zeus_matrix.bin.gz"), pnt = read_gz(ev + "/seed_item_0_m_zeus_point.bin.gz");
    struct Fr { int fr; u64 n; u64 t; }; std::vector<Fr> frames;
    { FILE* f = fopen((ev + "/frames.txt").c_str(), "r"); int fr; unsigned long long n, s, a;
      while (f && fscanf(f, "%d %llu %llu %llu", &fr, &n, &s, &a) == 4) frames.push_back({fr, (u64)n, (u64)a}); if (f) fclose(f); }
    std::vector<u8> io = read_gz(ev + "/io.log.gz"); io.push_back(0);
    u32 reg84; memcpy(&reg84, &regs[0x84 * 4], 4);

    Verilated::commandArgs(argc, argv);
    Vzr_render3* t = new Vzr_render3;
    struct Pend { u64 data, due; };
    std::deque<Pend> fpend, w0q, crq;
    u64 clocks = 0, oob = 0;
    // PACED mode (ZR_PACE=1): every CPU write is presented no earlier than its MAME timestamp converted to 50 MHz
    // fabric clocks (1 clock = 2e10 attoseconds), so the renderer sees the command stream at the CPU's real pace
    // instead of back to back. Reported: how long the CPU would have stalled on the front end, and how long after
    // each frame boundary the renderer finished draining.
    const bool PACE = getenv("ZR_PACE") && atoi(getenv("ZR_PACE"));
    bool in_readback = false; u64 rt = 0, cpu_stall = 0, cpu_stall_max = 0; long long drain_max = -1; u64 drain_sum = 0;
    auto tick = [&]() {
        t->clk = 0; t->eval();
        // front end: pipelined port, up to 8 accepted, in-order responses after MLAT
        t->fm_gnt = fpend.size() < 8;
        if (t->fm_req && t->fm_gnt) {
            u64 off = (u64)t->fm_blk * 8; std::vector<u8>& m = w[t->fm_ram];
            if (t->fm_we) {
                if (off + 8 > m.size()) oob++;
                else for (int l = 0; l < 4; l++) if (t->fm_lanes >> l & 1) { u16 v = (u16)(t->fm_wdata >> (16 * l)); memcpy(&m[off + 2 * l], &v, 2); }
            } else { u64 d = 0; if (off + 8 > m.size()) oob++; else memcpy(&d, &m[off], 8); fpend.push_back({d, clocks + (u64)MLAT}); }
        }
        t->fm_rvalid = 0;
        if (!fpend.empty() && clocks >= fpend.front().due) { t->fm_rdata = fpend.front().data; t->fm_rvalid = 1; fpend.pop_front(); }
        // pixel pipe (v8 ports): texture lines and colour reads are request / grant with IN-ORDER responses after the
        // latency; GBP % of clocks refuse the grant. Colour reads sample memory when ACCEPTED (strict model).
        t->w0_rvalid = 0;
        if (!w0q.empty() && w0q.front().due <= clocks) { t->w0_rvalid = 1; t->w0_data = w0q.front().data; w0q.pop_front(); }
        t->cr_rvalid = 0;
        if (!crq.empty() && crq.front().due <= clocks) { t->cr_rvalid = 1; t->cr_data = (u16)crq.front().data; crq.pop_front(); }
        t->w0_gnt = (GBP == 0) || (int)(rnd() % 100) >= GBP;
        t->cr_gnt = (GBP == 0) || (int)(rnd() % 100) >= GBP;
        if (t->w0_req && t->w0_gnt) {
            u64 a = (u64)t->w0_line * 8; u64 d = 0;
            if (a + 8 <= w[0].size()) memcpy(&d, &w[0][a], 8); else { printf("FAIL: w0 line out of range\n"); exit(1); }
            w0q.push_back({d, clocks + (u64)W0LAT});
        }
        if (t->cr_req && t->cr_gnt) {
            u16 v; memcpy(&v, &w[1][t->cr_addr], 2); crq.push_back({v, clocks + (u64)CRLAT});
        }
        // posted colour writes
        t->cw_ready = (CWBP == 0) || (int)(rnd() % 100) >= CWBP;
        if (t->cw_valid && t->cw_ready) {
            if ((t->cw_addr & 3) || t->cw_addr + 4 > w[1].size()) { printf("FAIL: cw address %08X\n", t->cw_addr); exit(1); }
            u16 lo = t->cw_data & 0xffff, hi = t->cw_data >> 16;
            if (t->cw_mask & 1) memcpy(&w[1][t->cw_addr], &lo, 2);
            if (t->cw_mask & 2) memcpy(&w[1][t->cw_addr + 2], &hi, 2);
        }
        t->eval(); t->clk = 1; t->eval(); clocks++;
        if (!in_readback) rt++;                                    // real time: frozen while the testbench reads depth
    };
    t->rb_init = (reg84 & 0x1ff) * 512 * 8;
    t->rst = 1; t->wr_valid = 0; t->sd_we = 0; tick(); tick(); t->rst = 0; tick();
    auto seed = [&](int sel, int idx, u32 d) { t->sd_we = 1; t->sd_sel = sel; t->sd_idx = idx; t->sd_data = d; tick(); t->sd_we = 0; };
    for (int k = 0; k < 0x400; k++) { u32 v; memcpy(&v, &regs[4 * k], 4); seed(0, k, v); }
    for (int k = 0; k < 20; k++) { u32 v; memcpy(&v, &fifo[4 * k], 4); seed(1, k, v); }
    seed(2, 0, item<u8>(ev, "m_zeus_fifo_words"));
    for (int k = 0; k < 9; k++) { int16_t v; memcpy(&v, &mtx[2 * k], 2); seed(3, k, (u32)(s32)v); }
    for (int k = 0; k < 3; k++) { u32 v; memcpy(&v, &pnt[4 * k], 4); seed(4, k, v); }
    seed(5, 0, item<u32>(ev, "m_zeus_palbase")); seed(6, 0, item<u32>(ev, "m_zeus_objdata"));
    seed(7, 0, (u32)item<s32>(ev, "m_zeus_cliprect_min_x")); seed(7, 1, (u32)item<s32>(ev, "m_zeus_cliprect_max_x"));
    seed(7, 2, (u32)item<s32>(ev, "m_zeus_cliprect_min_y")); seed(7, 3, (u32)item<s32>(ev, "m_zeus_cliprect_max_y"));

    auto wait_idle = [&]() { u64 g = 0; while (!t->idle) { tick(); if (++g > 400000000ull) { printf("FAIL: renderer never idle\n"); exit(1); } } };
    const char* p = (const char*)io.data(); u64 rec = 0; size_t fi = 1; int ok = 0, bad = 0, nfr = 0;
    u64 busy_start = 0;
    auto frame = [&](int fr) {
        wait_idle(); nfr++;
        if (PACE) {   // drain = when the renderer went idle, relative to this frame's MAME boundary time
            long long bclk = (long long)((frames[fi].t - frames[0].t) / 20000000000ull);
            long long d = (long long)rt - bclk; if (d < 0) d = 0;
            drain_sum += (u64)d; if (d > drain_max) drain_max = d;
            printf("  frame %d: renderer idle %lld clocks after the frame boundary (%.1f %% of a frame)\n", fr, d, 100.0 * d / 882300.0);
        }
        in_readback = true;
        char nm[512]; snprintf(nm, sizeof nm, "%s/frame_%05d_0_m_waveram_1_.bin.gz", ev.c_str(), fr);
        std::vector<u8> m = read_gz(nm);
        u64 dcol = 0, ddep = 0, first = ~0ull;
        for (u32 k = 0; k < w[1].size() / 2; k++) {
            if (k & 2) continue;                                   // depth words: the render buffer's, on chip, below
            u16 a, b; memcpy(&a, &w[1][2 * k], 2); memcpy(&b, &m[2 * k], 2);
            if (a != b) { dcol++; if (first == ~0ull) first = k; }
        }
        u32 rb = t->rb_now;
        for (u32 yy = 0; yy < 256; yy++) for (u32 xx = 0; xx < 400; xx++) {
            t->dbg_daddr = yy * 400 + xx; tick(); t->clk = 0; t->eval();
            u16 dv = t->dbg_ddata;
            u32 word = (rb / 2) + ((yy << 10) | ((xx & 0x1fe) << 1) | (xx & 1) | 2);
            u16 mv; memcpy(&mv, &m[2 * word], 2);
            if (dv != mv) { ddep++; if (ddep < 4) printf("  depth y %u x %u: rtl %04X MAME %04X\n", yy, xx, dv, mv); }
        }
        in_readback = false;
        if (dcol == 0 && ddep == 0) ok++; else bad++;
        printf("frame %d: colour %s (%llu words differ), render-buffer depth %s (%llu differ); quads %u polys %u rejected %u extents %u, clocks %llu\n",
               fr, dcol ? "DIFFERS" : "IDENTICAL", (unsigned long long)dcol, ddep ? "DIFFERS" : "IDENTICAL", (unsigned long long)ddep,
               t->st_quads, t->st_polys, t->st_rejected, t->st_extents, (unsigned long long)clocks);
        if (dcol) { u16 a, b; memcpy(&a, &w[1][2 * first], 2); memcpy(&b, &m[2 * first], 2); printf("  first colour word %llu: rtl %04X MAME %04X\n", (unsigned long long)first, a, b); }
    };
    while (*p && fi < frames.size() && nfr < maxf) {
        char kind; unsigned addr, data;
        if (sscanf(p, "%c %x %x", &kind, &addr, &data) != 3) { printf("FAIL: io parse at record %llu\n", (unsigned long long)rec); return 2; }
        if (kind == 'W' && addr >= 0x880000 && addr <= 0x8803FF) {
            if (PACE) {   // wait for this write's real time: io.log columns are kind addr data pc ? time_as
                unsigned long long pc, x, tas;
                if (sscanf(p, "%*c %*x %*x %llx %llu %llu", &pc, &x, &tas) == 3 && tas > frames[0].t) {
                    u64 target = (tas - frames[0].t) / 20000000000ull;
                    while (rt < target) tick();
                }
            }
            t->wr_off = addr - 0x880000; t->wr_data = data; t->wr_valid = 1;
            u64 g = 0; while (!t->wr_ready) { tick(); if (++g > 400000000ull) { printf("FAIL: write never accepted\n"); return 1; } }
            cpu_stall += g; if (g > cpu_stall_max) cpu_stall_max = g;
            tick(); t->wr_valid = 0;
        }
        rec++;
        while (*p && *p != '\n') p++;
        if (*p) p++;
        while (fi < frames.size() && rec == frames[fi].n && nfr < maxf) { frame(frames[fi].fr); fi++; }
    }
    if (t->unsupported) { printf("FAIL: a debug quad (unsupported) reached the renderer\n"); bad++; }
    printf("COUPLING clocks %u: quad-waits-for-setup %u, drain-for-RB/CLR %u, extent-waits-for-pixel %u, pixel-starved %u, CPU-waits-for-front %u\n",
           t->st_clk, t->st_wsetup, t->st_wdrain, t->st_extstall, t->st_pixstarve, t->st_frontwait);
    {   // per-block census, per frame
        const char* nm[21] = {"f.quads", "f.busy", "f.mem", "f.tr", "f.zc", "f.proj", "f.emit", "f.dec", "s.clk", "s.fe", "s.a", "s.b",
                              "p.misslines", "p.palloads", "p.stall", "p.pixels", "p.cr_clk", "p.w0_clk", "p.busy", "f.notidle", "p.pflines"};
        printf("CENSUS per frame:");
        for (int k = 0; k < 21; k++) printf(" %s %.0f", nm[k], nfr ? (double)t->st_cen[k] / nfr : 0.0);
        printf("\n");
    }
    printf("SUMMARY frames %d clocks %llu (%.0f per frame) out-of-range %llu (front mlat %d, w0 %d, cr %d, cw bp %d%%, grant refusal %d%%)\n",
           nfr, (unsigned long long)clocks, nfr ? (double)clocks / nfr : 0.0, (unsigned long long)oob, MLAT, W0LAT, CRLAT, CWBP, GBP);
    if (PACE) printf("REALTIME cpu stalled %llu clocks total (%.2f %% of %llu), worst single write %llu; drain after frame boundary max %lld (%.1f %% of a frame), mean %.0f\n",
                     (unsigned long long)cpu_stall, rt ? 100.0 * cpu_stall / rt : 0.0, (unsigned long long)rt, (unsigned long long)cpu_stall_max,
                     drain_max, 100.0 * drain_max / 882300.0, nfr ? (double)drain_sum / nfr : 0.0);
    bool pass = bad == 0 && ok > 0;
    printf("%s: %d of %d frames bit-exact vs MAME (both colour buffers + render-buffer depth), CPU writes in, RTL renderer end to end\n",
           pass ? "PASS" : "FAIL", ok, nfr);
    delete t; return pass ? 0 : 1;
}
