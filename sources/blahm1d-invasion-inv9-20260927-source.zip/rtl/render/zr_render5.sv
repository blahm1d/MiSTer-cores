// zr_render5.sv -- zr_render4 with pixel v10 (the S3B -> S4 queue: destination reads hidden across up to 24 pixels).
// buffer, extent FIFO, object queue: zr_rfifo / zr_sdp). zr_render3 was the same chain with flop glue and setups v6-v8.
// CPU register writes in; wave RAM traffic out. Gate: tb_zr_render.cpp replays the capture's CPU writes and compares
// wave RAM 1 (both frame buffers) and the render buffer's on-chip depth against MAME's frame dumps -- end to end,
// the whole renderer against MAME, with no golden model in the loop.
//
// The glue is a record parser on the front end's output stream (zr1 --fronttap format):
//   RB  (render base)  -> applied once every earlier polygon's extents have reached the pixel pipe
//   CLR (clear)        -> the pixel pipe's clear, same ordering rule
//   QUD (quad)         -> the object is queued, the four vertices + cliprect start the setup engine
//   HWW / HRD          -> nothing here: the front end already did the wave RAM access
//   DBQ (debug quad)   -> r12: an axis-aligned rectangle becomes a rect clear (colour, depth 0x7fff) after the same drain;
//                         any other shape sets the sticky unsupported flag (MK4: 22 of 22 are the full screen)
// Objects travel beside the setup engine, not through it: setup holds up to three polygons (front stage + two slots),
// so a 4-deep object queue pops at each polygon's last extent (setup's ext_last). A polygon the y clip removes produces
// no extents: setup pulses `rejected` while it is still in the front stage, i.e. it is the newest queued object, so
// the queue drops its TAIL.
module zr_render5 import fp32_pkg::*; #(parameter int SB_AW = 9, parameter int EQ_AW = 4, parameter int OQ_AW = 5) (
  input  logic        clk,
  input  logic        rst,
  // CPU side (zeus_w)
  input  logic        wr_valid,
  output logic        wr_ready,
  input  logic [9:0]  wr_off,
  input  logic [31:0] wr_data,
  input  logic [9:0]  rd_off,
  output logic [31:0] rd_data,
  output logic [31:0] reg_cc, reg_b6, output logic mode32, output logic host_rd_ok,     // front-end register taps (host reads, scanout)
  // front end's wave RAM port (models, host access): pipelined, in-order responses
  output logic        fm_req, fm_we, fm_ram, output logic [20:0] fm_blk, output logic [3:0] fm_lanes,
  output logic [63:0] fm_wdata, input logic fm_gnt, input logic fm_rvalid, input logic [63:0] fm_rdata,
  // pixel pipe's wave RAM ports
  output logic        w0_req, output logic [20:0] w0_line, input logic w0_gnt, input logic w0_rvalid, input logic [63:0] w0_data,
  output logic        cw_valid, input logic cw_ready, output logic [31:0] cw_addr, cw_data, output logic [1:0] cw_mask, output logic [15:0] cw_z, output logic cw_zv,
  output logic        cr_req, output logic [31:0] cr_addr, input logic cr_gnt, input logic cr_rvalid, input logic [15:0] cr_data,
  // initial render base (the seed's register 0x84, as the front end would have emitted it)
  input  logic [31:0] rb_init,
  input  logic [16:0] dbg_daddr, output logic [15:0] dbg_ddata,
  output logic [31:0] rb_now,
  output logic        idle,
  output logic        unsupported,              // sticky: a DBQ record whose quad is not an axis-aligned rectangle (r12)
  // r12 cabinet census (always counted): CLR clears started, clears completed (pixel pipe, CLR + DBQ), debug quads drawn
  // as rect clears, debug quads that drew nothing (empty after clipping) or were not rectangles (-> unsupported)
  output logic [31:0] st_clears, st_clr_done, st_dbq, output logic [15:0] st_dbq_empty, st_dbq_bad,
  output logic [31:0] disp_cc,                 // r12: the display base for SCANOUT -- reg_cc once everything before it is drawn
  output logic        disp_ovf,                 // r12: sticky, more than 4 display-base changes were pending at once
  output logic        pipe_idle,                // r12: nothing behind the front end (stream buffer, parser, setup, object queue, pixel pipe) has work
`ifdef ZR_SEED
  input  logic        sd_we, input logic [3:0] sd_sel, input logic [9:0] sd_idx, input logic [31:0] sd_data,
  output logic [31:0] dbg_state [20],
  output logic [31:0] st_cen [21],              // per-block census for the testbench (sim only)
`endif
  output logic [31:0] st_quads, st_polys, st_rejected, st_extents,
  // coupling census: every block fits a frame alone (front 70 %, setup 51 %, pixel 55 %) but the chain measured ~990 K
  // clocks per 882 K frame, so these count where the blocks wait on each other
  output logic [31:0] st_clk, st_wsetup, st_wdrain, st_extstall, st_pixstarve, st_frontwait
`ifdef ZR_PROBE
  // sim-only probe (r13: ZR_PROBE is defined only by render/cons/run_zr_cons.sh, never in synthesis or the core): this
  // block's state bus + per-stage {work, progress}, stages [0] front end [1] record parser [2] setup [3] pixel pipe
  , output logic [39:0] dbg, output logic [3:0] wd_work, wd_prog
`endif
);
  // census counters count only when ZR_CENSUS is defined (every simulation runner); synthesis removes them
`ifdef ZR_CENSUS
  localparam logic [31:0] CEN = 32'd1;
`else
  localparam logic [31:0] CEN = 32'd0;
`endif
  // ================= front end =================
  logic f_valid, f_ready, f_idle; logic [31:0] f_word;
  logic fo_v, fo_r; logic [31:0] fo_w; logic [SB_AW:0] sb_cnt;           // the front end's raw output (v2: into the stream buffer)
  logic [31:0] f_q, f_c, f_e, f_x, f_b, f_m, f_t, f_z, f_p, f_o, f_d;
  zr_front5 u_front (.clk, .rst, .wr_valid, .wr_ready, .wr_off, .wr_data, .rd_off, .rd_data, .reg_cc, .reg_b6, .mode32, .host_rd_ok,
    .m_req(fm_req), .m_we(fm_we), .m_ram(fm_ram), .m_blk(fm_blk), .m_lanes(fm_lanes), .m_wdata(fm_wdata),
    .m_gnt(fm_gnt), .m_rvalid(fm_rvalid), .m_rdata(fm_rdata), .o_valid(fo_v), .o_ready(fo_r), .o_word(fo_w),
    .idle(f_idle),
`ifdef ZR_SEED
    .sd_we, .sd_sel, .sd_idx, .sd_data, .dbg_state,
`endif
    .st_quads(f_q), .st_culled(f_c), .st_emitted(f_e), .st_exc(f_x), .st_busy(f_b),
    .st_mem(f_m), .st_tr(f_t), .st_zc(f_z), .st_proj(f_p), .st_emit(f_o), .st_dec(f_d), .st_hwait());

  // ================= v2: stream buffer, front end -> parser =================
  // Measured on v1: a quad waited for setup's front stage 42 % of the time, and that stall ran straight back into the
  // front end and the CPU. 2**SB_AW words (~12 quads at 512) let the front end keep producing while setup is busy.

  zr_rfifo #(32, SB_AW) u_sb (.clk, .rst, .in_valid(fo_v), .in_ready(fo_r), .in_data(fo_w),
    .out_valid(f_valid), .out_ready(f_ready), .out_data(f_word), .empty());

  // ================= setup engine =================
  logic s_start, s_in_ready, s_idle, s_rejected, s_ev, s_er, s_exc, s_last, s_hazard;
  logic [31:0] s_vin [4][6]; logic signed [31:0] s_clip [4];
  logic signed [31:0] s_scan; logic signed [15:0] s_sx, s_ex; logic [31:0] s_st [4], s_dp [4]; logic signed [31:0] s_sti [3], s_dpi [3];   // L6: ints
  logic [31:0] s_c0, s_c1, s_c2, s_c3;
  zr_setup9 u_setup (.clk, .rst, .start(s_start), .in_ready(s_in_ready), .vin(s_vin),
    .clip_min_x(s_clip[0]), .clip_max_x(s_clip[1]), .clip_min_y(s_clip[2]), .clip_max_y(s_clip[3]),
    .idle(s_idle), .rejected(s_rejected), .ext_valid(s_ev), .ext_ready(s_er), .ext_scan(s_scan),
    .ext_startx(s_sx), .ext_stopx(s_ex), .ext_start(s_st), .ext_dpdx(s_dp), .ext_start_i(s_sti), .ext_dpdx_i(s_dpi), .ext_exc(s_exc), .ext_last(s_last),
    .hazard(s_hazard), .st_clk(s_c0), .st_fe(s_c1), .st_a(s_c2), .st_b(s_c3));

  // r11: the extent FIFO's and the pixel pipe's handshake nets are DECLARED HERE, before the object queue reads them.
  // r3..r10 declared them below their first use (oq_pop, line ~107); Verilator resolves the forward reference, but
  // Quartus 17.0 synthesised oq_pop UNDRIVEN (map Warning 10030 "has no driver ... default initial value '0'", every
  // zk4 build): the queue never popped, oq_n rose by one per drawn polygon, and the first RB after them waited for
  // `drained` forever (r10 cabinet: oq_n 147, setup idle, extent FIFO empty). Gate: render/cons/check_decl_order.py.
  typedef struct packed { logic signed [31:0] scan; logic signed [15:0] sx, ex; logic [2:0][31:0] st, dp; logic last; } ext_t;   // v4: intensity (3) is the MK4 constant
  ext_t e_in, e_out; logic e_ov, e_or; logic eq_empty;
  logic p_ev, p_er, p_cv, p_cr, p_idle; logic [31:0] rb;
  // r12 debug quad (DBQ record: colour, cliprect min_x max_x min_y max_y, 4 x {x, y} as floats of int16 -- zr_front5 S_EM)
  logic [15:0] dq_col; logic signed [17:0] dq_c [4]; logic signed [17:0] dq_vx [4], dq_vy [4]; logic dq_pend;
  logic dq_rect, dq_empty; logic [8:0] dq_x0, dq_x1, dq_y0, dq_y1; logic p_cdone, clr_is_dbq;

  // ================= object queue (v4: M10K) =================
  // v3 kept 2**OQ_AW object records (245 bits each) in flops with a combinational read -- ~7.8 K registers that no block
  // fit counted. v4: a simple-dual-port RAM. The head's record is read with the pop folded into the address (the clock
  // a polygon's last extent is taken, the RAM already reads the NEXT slot), so the pixel pipe sees no bubble; a push
  // into the slot being read in the same clock (the queue was empty, or its only entry is leaving) is forwarded.
  typedef struct packed {
    logic [31:0] ctrl, alpha, blend, texbase, palbase;
    logic [15:0] solid, trans, texw, voff; logic signed [15:0] zoff;
    logic dtest, dwrite; logic [2:0] texfmt;
  } obj_t;
  logic [OQ_AW-1:0] oq_w, oq_r; logic [OQ_AW:0] oq_n;
  obj_t cur;                                             // the object being assembled from a QUD record
  obj_t head, oq_q; logic bp_v;
  logic oq_push, oq_pop, oq_drop; logic [OQ_AW-1:0] oq_wslot, oq_ra;
  always_comb begin
    oq_push = s_start; oq_pop = p_ev && p_er && e_out.last; oq_drop = s_rejected;
    oq_wslot = oq_drop ? oq_w - 1'b1 : oq_w;
    oq_ra = oq_pop ? oq_r + 1'b1 : oq_r;
  end
  zr_sdp #($bits(obj_t), OQ_AW) u_oq (.clk, .we(oq_push), .waddr(oq_wslot), .wdata(cur), .raddr(oq_ra), .rdata(oq_q));
  // sound-area: NO write-to-read forwarding (v4 kept a 245-flop copy bp_d of the pushed record and a 245-bit mux). The
  // forwarded head was never consumed: the pixel pipe samples head only when it accepts an extent (p_ev && p_er,
  // zr_pixel10 `ld` block / xr_in), and in the one clock after a push into the slot being read (bp_v) the pushed object is
  // the head of an otherwise-empty queue (oq_n was 0, or 1 and popping) -- every extent in the FIFO belongs to an object
  // queued AHEAD of the head, and the new object's own extents cannot exist before setup has run its front stage. So
  // p_ev (which needs an extent in the FIFO and oq_n != 0 for its owner) is low whenever bp_v is high. From the next clock
  // the RAM read returns the written record. Sim checker (ZR_SIM): bp_v && p_ev is fatal; the count shows it is exercised.
  assign head = oq_q;
`ifdef ZR_SIM
  int unsigned sa_fwd_n;
  always_ff @(posedge clk)
    if (rst) begin bp_v <= 1'b0; sa_fwd_n <= 0; end
    else begin
      bp_v <= oq_push && oq_wslot == oq_ra;
      if (bp_v) begin
        sa_fwd_n <= sa_fwd_n + 1;
        if (sa_fwd_n == 0 || sa_fwd_n == 9 || sa_fwd_n == 99 || sa_fwd_n == 999 || sa_fwd_n == 9999)
          $display("SA-FWD clocks-after-push-into-read-slot reached %0d, consumed 0", sa_fwd_n + 1);
      end
      if (bp_v && p_ev) begin $display("SA-FWD VIOLATION: the head was consumed in the clock after a push into its slot"); $fatal(1, "SA-FWD"); end
    end
  final $display("SA-FWD clocks-after-push-into-read-slot %0d, consumed 0", sa_fwd_n);
`endif

  // ================= v2: extent FIFO, setup -> pixel pipe =================
  // Measured on v1: the pixel pipe was STARVED 62 % of the time while setup waited on it 27 % -- burstiness with no
  // buffer (setup emits a polygon's extents in a burst; the pixel pipe drains them at a rate set by extent length).
  // Objects now pop when the PIXEL PIPE takes a polygon's last extent, so the object queue also covers every polygon
  // with extents waiting in this FIFO.
  always_comb begin
    e_in.scan = s_scan; e_in.sx = s_sx; e_in.ex = s_ex; e_in.last = s_last;
    for (int k = 0; k < 3; k++) begin e_in.st[k] = s_sti[k]; e_in.dp[k] = s_dpi[k]; end   // L6: already int (fp_f2i_trunc in setup B)
  end
  logic [31:0] e_st [4], e_dp [4];
  always_comb begin for (int k = 0; k < 3; k++) begin e_st[k] = e_out.st[k]; e_dp[k] = e_out.dp[k]; end e_st[3] = '0; e_dp[3] = '0; end
  zr_rfifo #($bits(ext_t), EQ_AW) u_eq (.clk, .rst, .in_valid(s_ev), .in_ready(s_er), .in_data(e_in),
    .out_valid(e_ov), .out_ready(e_or), .out_data(e_out), .empty(eq_empty));

  // ================= pixel pipe =================
  logic [31:0] p_ml, p_pl, p_sc, p_px, p_pf;
  assign p_ev = e_ov && (oq_n != 0);
  assign e_or = p_er && (oq_n != 0);
  zr_pixel10 u_pixel (.clk, .rst, .ext_valid(p_ev), .ext_ready(p_er), .scan(e_out.scan), .startx(e_out.sx), .stopx(e_out.ex),
    .p_start(e_st), .p_dpdx(e_dp), .o_ctrl(head.ctrl), .o_alpha(head.alpha), .o_blend(head.blend),
    .o_solid(head.solid), .o_trans(head.trans), .o_texw(head.texw), .o_voff(head.voff), .o_zoff(head.zoff),
    .o_dtest(head.dtest), .o_dwrite(head.dwrite), .o_texfmt(head.texfmt), .o_texbase(head.texbase),
    .o_palbase(head.palbase), .rb_base(rb), .clr_valid(p_cv), .clr_ready(p_cr),
    .clr_rect(clr_is_dbq), .clr_color(dq_col), .clr_x0(dq_x0), .clr_x1(dq_x1), .clr_y0(dq_y0), .clr_y1(dq_y1), .clr_done(p_cdone),
    .w0_req, .w0_line, .w0_gnt, .w0_rvalid, .w0_data, .cw_valid, .cw_ready, .cw_addr, .cw_data, .cw_mask, .cw_z, .cw_zv,
    .cr_req, .cr_addr, .cr_gnt, .cr_rvalid, .cr_data, .dbg_daddr, .dbg_ddata, .idle(p_idle),
    .st_miss_lines(p_ml), .st_pal_loads(p_pl), .st_stall_clocks(p_sc), .st_pixels(p_px), .st_pf_lines(p_pf));
  assign rb_now = rb;
`ifdef ZR_SEED
  // census: front phases, setup phases, pixel-pipe stall sources (cr = destination read, w0 = texture/palette line)
  logic [31:0] c_cr, c_w0, c_pbusy, c_fbusy;
  always_ff @(posedge clk)
    if (rst) begin c_cr <= 0; c_w0 <= 0; c_pbusy <= 0; c_fbusy <= 0; end
    else begin
      if (cr_req) c_cr <= c_cr + 1; if (w0_req) c_w0 <= c_w0 + 1;
      if (!p_idle) c_pbusy <= c_pbusy + 1; if (!f_idle) c_fbusy <= c_fbusy + 1;
    end
  assign st_cen = '{f_q, f_b, f_m, f_t, f_z, f_p, f_o, f_d, s_c0, s_c1, s_c2, s_c3,
                    p_ml, p_pl, p_sc, p_px, c_cr, c_w0, c_pbusy, c_fbusy, p_pf};
`endif

  // ================= record parser =================
  typedef enum logic [2:0] { R_TAG, R_BODY, R_WAITDRAIN, R_CLR, R_START } rst_t;
  rst_t rs; logic [31:0] tag, rbv; logic [5:0] wi, wn; logic [1:0] vi; logic [2:0] fi;   // vertex / field of a QUD float
  logic drained; assign drained = s_idle && (oq_n == 0) && !s_start && eq_empty;
  assign f_ready = (rs == R_TAG) || (rs == R_BODY);
  assign s_start = (rs == R_START) && s_in_ready && (oq_n != (OQ_AW+1)'(2**OQ_AW));
  assign p_cv = (rs == R_CLR);
  assign clr_is_dbq = (tag == 32'h44425131);
  assign pipe_idle = (rs == R_TAG) && !f_valid && drained && p_idle;   // no record queued or in hand, nothing drawing

  // ---- r12 DISPLAY BASE ORDERING (page ownership). MAME applies a 0xCC write at once (midzeus_v.cpp:721-729) with every
  // earlier FIFO command already rendered (its poly work completes before the frame is shown), and MK4 writes RB then CC
  // then draws the next frame into the other page (MAME census: RB page != CC page on 2006 of 2006 flips). zr_front5
  // updates reg_cc when it PARSES the write, while polygons it emitted before are still in the stream buffer, setup or
  // the pixel pipe -- under load scanout showed a page still being drawn (paced free-run hvpoly: 19,794 colour writes
  // into the displayed page, drains up to 187 K clocks). Here each reg_cc change is held with the count of records the
  // front end had emitted (mark) and reaches scanout only when the parser has consumed them all and nothing is drawing.
  // (zr_memsys orders scanout reads after older colour writes to the same words -- hz_sc -- so writes still in the
  // coalescer are safe.) Host reads of 0xCC still see reg_cc at once.
  logic [15:0] em_cnt, cn_cnt; logic [31:0] cc_seen; logic [31:0] pc [4]; logic [15:0] pm [4]; logic [2:0] pn;
  logic cc_new, cc_go; logic [15:0] cc_diff;
  assign cc_new  = reg_cc != cc_seen;
  assign cc_diff = cn_cnt - pm[0];
  assign cc_go   = pn != 3'd0 && drained && p_idle && (cc_diff != 16'd0 ? !cc_diff[15] : rs == R_TAG);
  always_ff @(posedge clk)
    if (rst) begin em_cnt <= '0; cn_cnt <= '0; cc_seen <= '0; disp_cc <= '0; pn <= '0; disp_ovf <= 1'b0; end
    else begin : dcc
      logic [2:0] n;
      if (fo_v && fo_r) em_cnt <= em_cnt + 1'b1;
      if (f_valid && f_ready) cn_cnt <= cn_cnt + 1'b1;
      cc_seen <= reg_cc;
      n = pn;
      if (cc_go) begin disp_cc <= pc[0]; pc[0] <= pc[1]; pm[0] <= pm[1]; pc[1] <= pc[2]; pm[1] <= pm[2]; pc[2] <= pc[3]; pm[2] <= pm[3]; n = n - 3'd1; end
      if (cc_new) begin
        if (n == 3'd4) begin pc[3] <= reg_cc; pm[3] <= em_cnt; disp_ovf <= 1'b1; end   // full: the newest replaces the newest
        else begin pc[2'(n)] <= reg_cc; pm[2'(n)] <= em_cnt; n = n + 3'd1; end
      end
      pn <= n;
    end

  // ---- r12 debug quad -> rect clear. MAME (midzeus_v.cpp:575-620): colour = reg 00, zoffset 0x7fff, 4 int16 vertices,
  // render_polygon<4,0> (poly.h; golden zr1.cpp render_polygon) with render_poly_solid_fixedz = plot_depth. For integer
  // vertices of an axis-aligned rectangle every edge is exact: rows [miny, maxy] and x [minx, maxx] (oracle2 grow), clipped to the
  // cliprect (max + 1 exclusive). A quad that is not such a rectangle is outside this rule -> unsupported (MK4 draws
  // only (0,0)-(399,0)-(399,255)-(0,255): 22 of 22 in a 16,000-frame MAME census).
  function automatic logic signed [17:0] f2i16(input logic [31:0] f);   // a float holding an int16 exactly
    logic [7:0] e; logic [23:0] m; logic [17:0] mag;
    e = f[30:23]; m = {1'b1, f[22:0]};
    if (e < 8'd127) mag = '0; else if (e > 8'd142) mag = 18'h1ffff; else mag = 18'(m >> (8'd150 - e));
    return f[31] ? -$signed(mag) : $signed(mag);
  endfunction
  always_ff @(posedge clk) begin : dqr
    logic signed [17:0] mnx, mxx, mny, mxy, x0, x1, y0, y1; logic ok;
    mnx = dq_vx[0]; mxx = dq_vx[0]; mny = dq_vy[0]; mxy = dq_vy[0];
    for (int i = 1; i < 4; i++) begin
      if (dq_vx[i] < mnx) mnx = dq_vx[i]; if (dq_vx[i] > mxx) mxx = dq_vx[i];
      if (dq_vy[i] < mny) mny = dq_vy[i]; if (dq_vy[i] > mxy) mxy = dq_vy[i];
    end
    ok = 1'b1;                                            // every vertex a corner, every side axis-aligned
    for (int i = 0; i < 4; i++) begin
      if (dq_vx[i] != mnx && dq_vx[i] != mxx) ok = 1'b0;
      if (dq_vy[i] != mny && dq_vy[i] != mxy) ok = 1'b0;
      if ((dq_vx[i] == dq_vx[(i + 1) % 4]) == (dq_vy[i] == dq_vy[(i + 1) % 4]) && mnx != mxx && mny != mxy) ok = 1'b0;
    end
    // oracle2 (MAME d1e9f7db, #16225 zeus_draw_solid_quad): an axis-aligned quad grows its max x / max y vertices by 1,
    // so the named last column / row are drawn (0.289: [min, max) left column 399 / row 255 frozen). Exclusive ends:
    x0 = mnx > dq_c[0] ? mnx : dq_c[0]; x1 = mxx + 18'sd1 < dq_c[1] + 18'sd1 ? mxx + 18'sd1 : dq_c[1] + 18'sd1;
    y0 = mny > dq_c[2] ? mny : dq_c[2]; y1 = mxy + 18'sd1 < dq_c[3] + 18'sd1 ? mxy + 18'sd1 : dq_c[3] + 18'sd1;
    if (x0 < 0) x0 = '0; if (y0 < 0) y0 = '0; if (x1 > 18'sd400) x1 = 18'sd400; if (y1 > 18'sd256) y1 = 18'sd256;
    dq_rect <= ok; dq_empty <= (x0 >= x1) || (y0 >= y1);
    dq_x0 <= 9'(x0); dq_x1 <= 9'(x1); dq_y0 <= 9'(y0); dq_y1 <= 9'(y1);
  end
  assign idle = (rs == R_TAG) && f_idle && drained && p_idle && !f_valid;

  // record lengths (words after the tag)
  function automatic logic [5:0] body_len(input logic [31:0] t);
    case (t)
      32'h52423031: return 6'd1;   // RB
      32'h434C5231: return 6'd4;   // CLR
      32'h51554431: return 6'd41;  // QUD
      32'h44425131: return 6'd13;  // DBQ
      32'h48575731: return 6'd5;   // HWW
      32'h48524431: return 6'd4;   // HRD
      default:      return 6'd0;
    endcase
  endfunction

  always_ff @(posedge clk) begin
    if (rst) begin
      rs <= R_TAG; oq_w <= '0; oq_r <= '0; oq_n <= '0; rb <= rb_init; unsupported <= 1'b0; dq_pend <= 1'b0;
      st_clears <= 0; st_clr_done <= 0; st_dbq <= 0; st_dbq_empty <= 0; st_dbq_bad <= 0;
      st_quads <= 0; st_polys <= 0; st_rejected <= 0; st_extents <= 0;
      st_clk <= 0; st_wsetup <= 0; st_wdrain <= 0; st_extstall <= 0; st_pixstarve <= 0; st_frontwait <= 0;
    end else begin
      st_clk <= st_clk + CEN;
      if (p_cdone) st_clr_done <= st_clr_done + 1'b1;
      if (rs == R_START && !s_start) st_wsetup <= st_wsetup + CEN;           // a quad waits for setup's front stage
      if (rs == R_WAITDRAIN || rs == R_CLR) st_wdrain <= st_wdrain + CEN;     // RB / CLR wait for the pipe to drain
      if (s_ev && !s_er) st_extstall <= st_extstall + CEN;                   // setup waits: the extent FIFO is full
      if (p_er && !e_ov) st_pixstarve <= st_pixstarve + CEN;                  // the pixel pipe waits for extents
      if (!wr_ready) st_frontwait <= st_frontwait + CEN;                      // the CPU waits for the front end
      case (rs)
        R_TAG: if (f_valid) begin
          tag <= f_word; wi <= '0; wn <= body_len(f_word);
          rs <= (body_len(f_word) == 0) ? R_TAG : R_BODY;
        end
        R_BODY: if (f_valid) begin
          // capture the words this block uses
          if (tag == 32'h52423031 && wi == 0) rbv <= f_word;
          if (tag == 32'h51554431) case (wi)
            6'd0:  cur.ctrl <= f_word;     6'd1:  cur.solid <= f_word[15:0];  6'd2:  cur.zoff <= f_word[15:0];
            6'd3:  cur.trans <= f_word[15:0]; 6'd4: cur.texw <= f_word[15:0]; 6'd5: cur.voff <= f_word[15:0];
            6'd6:  cur.alpha <= f_word;    6'd7:  cur.blend <= f_word;       6'd8:  cur.dtest <= f_word[0];
            6'd9:  cur.dwrite <= f_word[0]; 6'd10: cur.texfmt <= f_word[2:0]; 6'd11: cur.texbase <= f_word;
            6'd12: cur.palbase <= f_word;
            6'd13, 6'd14, 6'd15: s_clip[2'(wi - 6'd13)] <= f_word;
            6'd16: begin s_clip[3] <= f_word; vi <= '0; fi <= '0; end
            default: begin                                         // words 17..40: vertex vi, field fi
              s_vin[vi][fi] <= f_word;
              if (fi == 3'd5) begin fi <= '0; vi <= vi + 2'd1; end else fi <= fi + 3'd1;
            end
          endcase
          if (tag == 32'h44425131) begin                         // r12 DBQ: colour, cliprect, 4 x {x, y}
            if (wi == 6'd0) dq_col <= f_word[15:0];
            else if (wi <= 6'd4) dq_c[2'(wi - 6'd1)] <= 18'($signed(f_word[17:0]));
            else if (wi[0]) dq_vx[2'((wi - 6'd5) >> 1)] <= f2i16(f_word);
            else dq_vy[2'((wi - 6'd6) >> 1)] <= f2i16(f_word);
          end
          wi <= wi + 6'd1;
          if (wi == wn - 6'd1) begin
            dq_pend <= 1'b1;                                     // dq_rect / dq_x* settle one clock after the last word
            case (tag)
              32'h52423031, 32'h434C5231, 32'h44425131: rs <= R_WAITDRAIN;    // order after every earlier polygon
              32'h51554431: rs <= R_START;
              default: rs <= R_TAG;
            endcase
          end
        end
        R_WAITDRAIN: if (dq_pend) dq_pend <= 1'b0;
          else if (drained && p_idle) begin
          if (tag == 32'h52423031) begin rb <= rbv; rs <= R_TAG; end
          else if (tag == 32'h44425131 && !dq_rect) begin unsupported <= 1'b1; st_dbq_bad <= st_dbq_bad + 1'b1; rs <= R_TAG; end
          else if (tag == 32'h44425131 && dq_empty) begin st_dbq_empty <= st_dbq_empty + 1'b1; rs <= R_TAG; end
          else rs <= R_CLR;
        end
        R_CLR: if (p_cr) begin                                   // the pixel pipe accepted the clear
          if (clr_is_dbq) st_dbq <= st_dbq + 1'b1; else st_clears <= st_clears + 1'b1;
          rs <= R_TAG;
        end
        R_START: if (s_start) begin st_quads <= st_quads + CEN; rs <= R_TAG; end
        default: rs <= R_TAG;
      endcase
      // queue bookkeeping, all in one place: push (a quad starts setup), pop (its last extent reached the pixel pipe),
      // drop the TAIL (setup rejected the newest polygon). A drop and a push can share a clock -- setup pulses
      // `rejected` as its front stage goes idle, which is exactly when it can accept the next quad -- and then the
      // new object takes the freed slot.
      begin : oqb                                        // (the RAM write + read-ahead are in the object-queue block)
        oq_w <= oq_w + OQ_AW'(oq_push) - OQ_AW'(oq_drop);
        if (oq_drop) st_rejected <= st_rejected + CEN;
        if (oq_pop) begin oq_r <= oq_r + 1'b1; st_polys <= st_polys + CEN; end
        oq_n <= oq_n + (OQ_AW+1)'(oq_push) - (OQ_AW+1)'(oq_pop) - (OQ_AW+1)'(oq_drop);
        if (p_ev && p_er) st_extents <= st_extents + CEN;
      end
    end
  end

`ifdef ZR_PROBE
  // ================= sim-only probe (was the r10 cabinet wedge probe; the conservation bench reads it) =================
  //   [2:0] rs  [3] drained  [4] p_idle  [5] s_in_ready  [6] f_valid  [7] s_idle  [8] eq_empty  [9] e_ov  [10] p_er
  //   [11] p_cr  [12] p_cv  [21:13] oq_n  [22] cw_valid  [23] cw_ready  [24] cr_req  [25] cr_gnt  [26] w0_req  [27] w0_gnt
  //   [28] s_ev  [29] s_er  [30] cr_rvalid  [31] w0_rvalid  [34:32] tag (1 RB 2 CLR 3 QUD 4 DBQ 5 HWW 6 HRD 7 other)
  //   [35] unsupported  [36] s_hazard
  logic [2:0] tag_code; rst_t rs_q;
  always_comb case (tag)
    32'h52423031: tag_code = 3'd1;  32'h434C5231: tag_code = 3'd2;  32'h51554431: tag_code = 3'd3;
    32'h44425131: tag_code = 3'd4;  32'h48575731: tag_code = 3'd5;  32'h48524431: tag_code = 3'd6;
    default:      tag_code = 3'd7;
  endcase
  always_ff @(posedge clk) rs_q <= rs;
  assign dbg = {3'd0, s_hazard, unsupported, tag_code, w0_rvalid, cr_rvalid, s_er, s_ev, w0_gnt, w0_req, cr_gnt, cr_req,
                cw_ready, cw_valid, 9'(oq_n), p_cv, p_cr, p_er, e_ov, eq_empty, s_idle, f_valid, s_in_ready, p_idle,
                drained, rs};
  // per stage: work = has something to do, prog = moved this clock (a watchdog counts work && !prog)
  assign wd_work = {!p_idle, !s_idle, (rs != R_TAG) || f_valid, !f_idle};
  assign wd_prog = {(p_ev && p_er) || (cw_valid && cw_ready) || (cr_req && cr_gnt) || (w0_req && w0_gnt) || cr_rvalid ||
                      w0_rvalid || (p_cv && p_cr),
                    (s_ev && s_er) || s_start || s_rejected,
                    (f_valid && f_ready) || rs != rs_q || s_start || (p_cv && p_cr),
                    fo_v && fo_r};                    // r13: the front end's output handshake (its own probe port is gone)
`endif
endmodule
