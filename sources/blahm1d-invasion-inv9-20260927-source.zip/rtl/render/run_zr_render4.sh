#!/bin/bash
# Build + run the end-to-end renderer gate (CPU writes -> front end -> setup -> pixel pipe -> wave RAM vs MAME).
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/render/run_zr_render.sh <render-evidence> [frames] [mlat] [w0lat] [crlat] [cw-bp%]
# ZRR4_MUT='sed-expression' mutates zr_render4.sv (refuses to run if it did not apply).
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-render2-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC="$S/render/zr_render4.sv"
if [ -n "${ZRR4_MUT:-}" ]; then sed "$ZRR4_MUT" "$SRC" > zr_render4.sv; cmp -s zr_render4.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zr_render4.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zr_render4 ${ZRR4_G:-} -DZR_SEED -DZR_SIM -DZR_CENSUS -Wno-fatal -Wno-lint -Wno-style -LDFLAGS -lz \
  "$S/fp32/fp32_pkg.sv" "$S/fp32/fp32_units.sv" "$S/setup/zr_sdp.sv" "$S/front/zr_front5.sv" "$S/setup/zr_setup9.sv" \
  "$S/pixel/zr_pixel9.sv" "$S/render/zr_fifo.sv" "$S/render/zr_rfifo.sv" "$SRC" "$S/render/tb_zr_render4.cpp" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
