// tb_zr_cons.cpp -- object-queue CONSERVATION bench for zr_render5 (r10 cabinet wedge: oq_n leaked to 147, RB waited
// for drained forever). Real zr_render5 + zr_setup9 + extent FIFO + zr_pixel10; the front end is zr_front5_stub.sv
// (records from this generator over DPI); the wave RAM ports are a random-latency responder.
// Checked EVERY clock:
//   C1  pushes == pops + drops + oq_n            (st_quads == st_polys + st_rejected + oq_n)
//   C2  nothing can still pop an object -> the queue is empty: setup idle AND the extent FIFO empty AND no quad being
//       started, held over two consecutive clocks (the one clock of a `rejected` pulse is excluded) -> oq_n == 0
// and at the end: the stream drains, the renderer goes idle, oq_n == 0.
// usage: tb <seed> <records> [mode]   mode 0 = adversarial mix (default), 1 = sane quads only
#include "Vzr_render5.h"
#include "verilated.h"
#if defined(CONS_DBG) || defined(CONS_SDBG)
#include "Vzr_render5___024root.h"
#endif
#include "svdpi.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <deque>
#include <vector>
#include <algorithm>
#include <cstdlib>

typedef uint32_t u32; typedef uint64_t u64; typedef int32_t s32;
static u64 rs = 1; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static int rr(int n) { return (int)(rnd() % (u64)n); }
static float rf(float a, float b) { return a + (b - a) * (float)((rnd() >> 11) * (1.0 / 9007199254740992.0)); }
static u32 fb(float f) { u32 u; memcpy(&u, &f, 4); return u; }

static std::deque<u32> stream;
static int gap_pct = 20;
extern "C" int cons_next(int* w) {
    if (stream.empty() || rr(100) < gap_pct) { *w = 0; return 0; }
    *w = (int)stream.front(); stream.pop_front(); return 1;
}

static int mode = 0;
static u32 coord(bool isx) {
    int k = mode == 1 ? 0 : mode == 2 ? 72 + rr(18) : rr(100);   // mode 2: huge / special / ties / raw bits only
    if (k < 55) return fb(isx ? rf(-40.f, 440.f) : rf(-40.f, 300.f));        // on / near screen
    if (k < 65) return fb(isx ? rf(-5000.f, -1.f) : rf(-3000.f, -1.f));      // off screen, negative
    if (k < 72) return fb(isx ? rf(400.f, 5000.f) : rf(256.f, 3000.f));      // off screen, positive
    if (k < 77) return fb(rf(-1e9f, 1e9f));                                  // huge
    if (k < 80) return fb(rf(-3e38f, 3e38f));
    if (k < 84) { static const u32 sp[] = {0x7f800000u, 0xff800000u, 0x7fc00000u, 0xffc00000u, 0x80000000u, 0x00000000u,
                                            0x00000001u, 0x80000001u, 0x7f7fffffu, 0xff7fffffu, 0x7fa00000u};
                  return sp[rr(11)]; }                                        // inf / NaN / zeros / denormals / max
    if (k < 88) return fb((float)rr(300) + (rr(2) ? 0.5f : 0.f));             // exact halves (rounding ties)
    if (k < 90) return (u32)rnd();                                            // raw bits
    return fb(isx ? rf(-40.f, 440.f) : rf(-40.f, 300.f));
}
static void push_qud() {
    stream.push_back(0x51554431u);
    u32 w[41];
    w[0] = (u32)rnd(); w[1] = (u32)rnd(); w[2] = (u32)rnd(); w[3] = (u32)rnd(); w[4] = (u32)(1u << (3 + rr(6)));
    w[5] = (u32)rnd(); w[6] = (u32)rnd(); w[7] = (u32)rnd(); w[8] = rr(2); w[9] = rr(2); w[10] = rr(8); w[11] = (u32)rr(1 << 20) * 4; w[12] = (u32)rr(1 << 20) * 4;
    // clip rect: the screen mostly; small, inverted, offset or empty sometimes
    s32 cminx = 0, cmaxx = 399, cminy = 0, cmaxy = 255;
    int c = mode == 1 ? 0 : rr(100);
    if (c >= 70 && c < 85) { cminx = rr(400); cmaxx = cminx + rr(100); cminy = rr(256); cmaxy = cminy + rr(80); }
    else if (c >= 85 && c < 92) { cminx = rr(400); cmaxx = cminx - rr(50); cminy = rr(256); cmaxy = cminy - rr(50); }  // inverted
    else if (c >= 97) {                                                      // extreme / unset clip registers
        static const s32 ex[] = {0, 399, 255, (s32)0x7fffffff, (s32)0x80000000, -1, 0x7ffffffe};
        cminx = ex[rr(7)]; cmaxx = ex[rr(7)]; cminy = ex[rr(7)]; cmaxy = ex[rr(7)];
        if ((long long)cmaxy - cminy > 700) { cminy = 0; if (cmaxy > 700) cmaxy = 255; }  // keep a run bounded (C3)
    }
    else if (c >= 92) { cminx = rr(800) - 400; cmaxx = cminx + rr(600); cminy = rr(600) - 300; cmaxy = cminy + rr(400); }
    w[13] = (u32)cminx; w[14] = (u32)cmaxx; w[15] = (u32)cminy; w[16] = (u32)cmaxy;
    // vertices: shape class
    float x[4], y[4]; u32 X[4], Y[4];
    int s = mode == 1 ? 0 : rr(100);
    for (int i = 0; i < 4; i++) { X[i] = coord(true); Y[i] = coord(false); }
    if (s >= 60 && s < 68) { u32 yy = Y[0]; for (int i = 0; i < 4; i++) Y[i] = yy; }                 // zero height
    else if (s >= 68 && s < 74) { Y[1] = Y[0]; X[1] = X[0]; }                                        // repeated vertex
    else if (s >= 74 && s < 80) { float b = rf(-10.f, 260.f); for (int i = 0; i < 4; i++) Y[i] = fb(b + rf(0.f, 0.99f)); }  // < 1 line
    else if (s >= 80 && s < 85) { float a = rf(-10.f, 400.f); for (int i = 0; i < 4; i++) X[i] = fb(a); }                   // zero width
    else if (s >= 85 && s < 90) { for (int i = 0; i < 4; i++) { X[i] = X[0]; Y[i] = Y[0]; } }         // a point
    (void)x; (void)y;
    for (int i = 0; i < 4; i++) {
        w[17 + i * 6 + 0] = X[i]; w[17 + i * 6 + 1] = Y[i];
        for (int p = 0; p < 4; p++) w[17 + i * 6 + 2 + p] = (mode != 1 && rr(20) == 0) ? coord(false) : fb(rf(0.f, 65535.f));
    }
    for (int i = 0; i < 41; i++) stream.push_back(w[i]);
}
static void push_record() {
    int k = rr(1000);
    if (k < 820) push_qud();
    else if (k < 900) { stream.push_back(0x52423031u); stream.push_back((u32)rr(4) << 18); }                // RB
    else if (k < 910) { stream.push_back(0x434C5231u); for (int i = 0; i < 4; i++) stream.push_back((u32)rnd()); }  // CLR
    else if (k < 930) { stream.push_back(0x44425131u); for (int i = 0; i < 13; i++) stream.push_back((u32)rnd()); } // DBQ
    else if (k < 965) { stream.push_back(0x48575731u); for (int i = 0; i < 5; i++) stream.push_back((u32)rnd()); }  // HWW
    else { stream.push_back(0x48524431u); for (int i = 0; i < 4; i++) stream.push_back((u32)rnd()); }             // HRD
}

int main(int argc, char** argv) {
    u64 seed = argc > 1 ? strtoull(argv[1], 0, 0) : 1; int nrec = argc > 2 ? atoi(argv[2]) : 2000; mode = argc > 3 ? atoi(argv[3]) : 0;
    if (getenv("ZRC_GAP")) gap_pct = atoi(getenv("ZRC_GAP"));
    rs = seed * 0x9E3779B97F4A7C15ull + 0x1234567ull; if (!rs) rs = 1;
    for (int i = 0; i < 16; i++) rnd();
    for (int i = 0; i < nrec; i++) push_record();
    // back-to-back RB / CLR at the end (the wedge's shape), then the stream ends
    stream.push_back(0x52423031u); stream.push_back(0); stream.push_back(0x434C5231u); for (int i = 0; i < 4; i++) stream.push_back(0);
    stream.push_back(0x52423031u); stream.push_back(0);

    Verilated::commandArgs(argc, argv);
    Vzr_render5* t = new Vzr_render5;
    const svScope sc = svGetScopeFromName("TOP.zr_render5.u_front"); if (sc) svSetScope(sc);
    struct P { u64 d, due; }; std::deque<P> w0q, crq;
    u64 clk = 0; int fail = 0; int held = 0; u64 max_oq = 0; u64 ext_at_pop = 0; u32 polys_seen = 0;
    t->rst = 1; t->wr_valid = 0; t->rb_init = 0; t->rd_off = 0; t->dbg_daddr = 0; t->fm_gnt = 0; t->fm_rvalid = 0;
    auto tick = [&]() {
        // memory responder: grants with random back-pressure, in-order responses after a random latency
        t->w0_gnt = t->w0_req && rr(100) < 70;
        t->cr_gnt = t->cr_req && rr(100) < 70;
        t->cw_ready = rr(100) < 80;
        t->w0_rvalid = 0; t->cr_rvalid = 0;
        if (!w0q.empty() && w0q.front().due <= clk) { t->w0_rvalid = 1; t->w0_data = w0q.front().d; w0q.pop_front(); }
        if (!crq.empty() && crq.front().due <= clk) { t->cr_rvalid = 1; t->cr_data = (uint16_t)crq.front().d; crq.pop_front(); }
        t->clk = 0; t->eval();
        bool w0acc = t->w0_req && t->w0_gnt, cracc = t->cr_req && t->cr_gnt;
        t->clk = 1; t->eval();
        if (w0acc) w0q.push_back({rnd(), clk + 3 + (u64)rr(12)});
        if (cracc) crq.push_back({rnd(), (crq.empty() ? clk : std::max(clk, crq.back().due)) + 2 + (u64)rr(10)});
        if (!w0q.empty() && w0q.size() > 1 && w0q.back().due < w0q[w0q.size() - 2].due) w0q.back().due = w0q[w0q.size() - 2].due;
        clk++;
    };
    for (int i = 0; i < 8; i++) tick();
    t->rst = 0;
    u64 limit = 400000000ull; u64 last_prog = 0; u64 last_sig = 0;
    for (; clk < limit; ) {
        tick();
        u64 dbg = t->dbg; unsigned oq_n = (dbg >> 13) & 0x1ff, rsv = dbg & 7;
        bool s_idle = (dbg >> 7) & 1, eq_empty = (dbg >> 8) & 1;
        if (oq_n > max_oq) max_oq = oq_n;
        if ((u64)t->st_quads != (u64)t->st_polys + t->st_rejected + oq_n) {
            printf("FAIL C1 clk %llu: pushes %u != pops %u + drops %u + oq_n %u\n", (unsigned long long)clk, t->st_quads, t->st_polys, t->st_rejected, oq_n);
            fail = 1; break;
        }
        if (s_idle && eq_empty && rsv != 4) held++; else held = 0;
        if (held >= 2 && oq_n != 0) {
            printf("FAIL C2 clk %llu: setup idle + extent FIFO empty but oq_n = %u (pushes %u pops %u drops %u) -- LEAK\n",
                   (unsigned long long)clk, oq_n, t->st_quads, t->st_polys, t->st_rejected);
            fail = 1; break;
        }
        u64 sig = (u64)t->st_quads + t->st_polys + t->st_extents + ((u64)rsv << 40);
        if (sig != last_sig) { last_sig = sig; last_prog = clk; }
        // C3: no clip rect this generator emits is taller than 700 lines, so a polygon (one pop) never owns more extents
        if ((u64)t->st_extents - ext_at_pop > 2000 && t->st_polys == polys_seen) {
            printf("FAIL C3 clk %llu: %llu extents since the last pop (runaway scanline loop)\n", (unsigned long long)clk,
                   (unsigned long long)((u64)t->st_extents - ext_at_pop));
#ifdef CONS_SDBG
#define SU(n) (long long)(int)(t->rootp->zr_render5__DOT__u_setup__DOT__##n)
            printf("  setup: p_ps %lld p_scan %lld minyc %lld/%lld maxyc %lld/%lld valid %lld/%lld issued %lld/%lld fst %lld pst %lld\n",
                   SU(p_ps), SU(p_scan), SU(ps_minyc[0]), SU(ps_minyc[1]), SU(ps_maxyc[0]), SU(ps_maxyc[1]), SU(ps_valid[0]), SU(ps_valid[1]),
                   SU(ps_issued[0]), SU(ps_issued[1]), SU(fst), SU(pst));
#endif
            fail = 1; break;
        }
        if (t->st_polys != polys_seen) { polys_seen = t->st_polys; ext_at_pop = t->st_extents; }
        if (stream.empty() && t->idle) break;
        if (clk - last_prog > 2000000ull) {
            printf("FAIL: no progress for 2M clocks at %llu (rs %u oq_n %u) dbg %010llx: drained %d p_idle %d s_in_ready %d f_valid %d s_idle %d eq_empty %d e_ov %d p_er %d s_ev %d s_er %d cw_v %d cr_req %d w0_req %d hazard %d work %x prog %x\n",
                   (unsigned long long)clk, rsv, oq_n, (unsigned long long)dbg, (int)(dbg >> 3 & 1), (int)(dbg >> 4 & 1), (int)(dbg >> 5 & 1), (int)(dbg >> 6 & 1),
                   (int)(dbg >> 7 & 1), (int)(dbg >> 8 & 1), (int)(dbg >> 9 & 1), (int)(dbg >> 10 & 1), (int)(dbg >> 28 & 1), (int)(dbg >> 29 & 1),
                   (int)(dbg >> 22 & 1), (int)(dbg >> 24 & 1), (int)(dbg >> 26 & 1), (int)(dbg >> 36 & 1), t->wd_work, t->wd_prog);
#ifdef CONS_DBG
#define PX(n) (unsigned long long)(t->rootp->zr_render5__DOT__u_pixel__DOT__##n)
            printf("  pixel: g_on %llu px_ir? xr_empty %llu pl_on %llu pal_pend %llu fill_on %llu s1_ok %llu s2 %llu s3 %llu s3b %llu s4 %llu s5 %llu crr_v %llu cr_out %llu w0r_v %llu clr_on %llu tc_init %llu x %llx xend %llx\n",
                   PX(g_on), PX(xr_empty), PX(pl_on), PX(pal_pend), PX(fill_on), PX(s1_ok), PX(s2_ok), PX(s3_ok), PX(s3b_ok), PX(s4_ok), PX(s5_ok),
                   PX(crr_v), PX(cr_out), PX(w0r_v), PX(clr_on), PX(tc_init), PX(x), PX(xend));
            printf("  fill_mask %llx fill_iss %llx dem_out %llu kq_cnt %llu w0q %zu due %llu rp_cnt %llu s1_allhit %llu\n", PX(fill_mask), PX(fill_iss), PX(dem_out), PX(kq_cnt), w0q.size(), w0q.empty() ? 0ull : (unsigned long long)w0q.front().due, PX(rp_cnt), PX(s1_allhit));
#endif
            fail = 1; break;
        }
    }
    unsigned oq_n = (t->dbg >> 13) & 0x1ff;
    if (!fail && !(stream.empty() && t->idle && oq_n == 0)) { printf("FAIL: end: stream %zu idle %d oq_n %u\n", stream.size(), (int)t->idle, oq_n); fail = 1; }
    printf("%s seed %llu mode %d: %llu clocks, quads %u polys %u rejected %u extents %u, max oq_n %llu, unsupported %d\n",
           fail ? "FAIL" : "PASS", (unsigned long long)seed, mode, (unsigned long long)clk, t->st_quads, t->st_polys, t->st_rejected, t->st_extents,
           (unsigned long long)max_oq, (int)t->unsupported);
    delete t; return fail;
}
