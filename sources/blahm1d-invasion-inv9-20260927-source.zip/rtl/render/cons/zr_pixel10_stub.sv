// zr_pixel10_stub.sv -- conservation bench only (tb_zr_cons.cpp, default): replaces zr_pixel10 under the SAME module
// name. Accepts extents with pseudo-random back-pressure, a random per-extent busy time, and a clear that takes a
// random time; idle when nothing is in flight. The object queue only sees the handshake (ext_valid && ext_ready) and
// idle / clr_ready, so this is what the conservation property needs. Never in a synthesis file list.
module zr_pixel10 #(parameter int CRMAX = 24) (
  input  logic        clk, rst,
  input  logic        ext_valid, output logic ext_ready,
  input  logic signed [31:0] scan, input logic signed [15:0] startx, stopx,
  input  logic [31:0] p_start [4], p_dpdx [4],
  input  logic [31:0] o_ctrl, o_alpha, o_blend,
  input  logic [15:0] o_solid, o_trans, o_texw, o_voff,
  input  logic signed [15:0] o_zoff,
  input  logic        o_dtest, o_dwrite,
  input  logic [2:0]  o_texfmt,
  input  logic [31:0] o_texbase, o_palbase,
  input  logic [31:0] rb_base,
  input  logic        clr_valid, output logic clr_ready,
  input  logic        clr_rect, input logic [15:0] clr_color, input logic [8:0] clr_x0, clr_x1, clr_y0, clr_y1, output logic clr_done,   // r12
  output logic        w0_req, output logic [20:0] w0_line, input logic w0_gnt, input logic w0_rvalid, input logic [63:0] w0_data,
  output logic        cw_valid, input logic cw_ready, output logic [31:0] cw_addr, cw_data, output logic [1:0] cw_mask, output logic [15:0] cw_z, output logic cw_zv,
  output logic        cr_req, output logic [31:0] cr_addr, input logic cr_gnt, input logic cr_rvalid, input logic [15:0] cr_data,
  input  logic [16:0] dbg_daddr, output logic [15:0] dbg_ddata,
  output logic        idle,
  output logic [31:0] st_miss_lines, st_pal_loads, st_stall_clocks, st_pixels, st_pf_lines
);
  logic [15:0] lfsr; logic [7:0] busy; logic clr_on;
`ifdef CONS_SLOW
  localparam bit SLOW = 1'b1;     // a quarter of the extents stall 255 clocks: the extent FIFO fills, setup backs up
`else
  localparam bit SLOW = 1'b0;
`endif
  assign ext_ready = busy == 0 && !clr_on && lfsr[2:0] != 3'd0;      // ~1/8 random refusals + the per-extent busy time
  assign clr_ready = busy == 0 && !clr_on;
  assign idle = busy == 0 && !clr_on;
  assign clr_done = 1'b0;
  assign w0_req = 1'b0; assign w0_line = '0; assign cw_valid = 1'b0; assign cw_addr = '0; assign cw_data = '0; assign cw_mask = '0;
  assign cw_z = '0; assign cw_zv = 1'b0; assign cr_req = 1'b0; assign cr_addr = '0; assign dbg_ddata = '0;
  assign st_miss_lines = '0; assign st_pal_loads = '0; assign st_stall_clocks = '0; assign st_pixels = '0; assign st_pf_lines = '0;
  always_ff @(posedge clk)
    if (rst) begin lfsr <= 16'hACE1; busy <= '0; clr_on <= 1'b0; end
    else begin
      lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};
      if (ext_valid && ext_ready) busy <= (lfsr[15:11] == 5'd0 || (SLOW && lfsr[9:8] == 2'd0)) ? 8'd255 : (startx < stopx) ? {4'd0, lfsr[7:4]} : 8'd0;   // + rare long stalls
      else if (busy != 0) busy <= busy - 8'd1;
      if (clr_valid && clr_ready) clr_on <= 1'b1;
      else if (clr_on && lfsr[5:0] == 6'd0) clr_on <= 1'b0;
    end
endmodule
