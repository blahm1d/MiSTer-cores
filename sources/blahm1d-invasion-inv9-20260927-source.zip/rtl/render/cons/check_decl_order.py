#!/usr/bin/env python3
"""check_decl_order.py -- flag identifiers USED before they are DECLARED in a module (SystemVerilog requires
declaration before use; Verilator and iverilog resolve forward references, Quartus 17.0 does not always).

Found by the r10 cabinet wedge: zr_render5.sv's `always_comb` at line 106 read p_ev / p_er / e_out, declared at lines
121 / 132. Verilator elaborated it; Quartus 17.0 synthesised `oq_pop` as UNDRIVEN (map Warning 10030, "using a default
initial value '0'", present in every zk4 build) -- the object queue never popped, oq_n climbed by one per drawn polygon
and the first RB after them waited for drained forever.

usage: check_decl_order.py file.sv [...]    exit 1 if any module-scope use precedes the declaration.
Scope: module-level declarations (ports, parameters, typedefs, logic/wire/reg/int/bit/genvar and typedef'd types).
Block-local declarations (inside begin ... end) are ignored as declarations and as uses of the same name elsewhere is
not attempted: a name declared ONLY inside a block is never flagged.
"""
import re
import sys

KW = set("""module endmodule input output inout logic wire reg bit int integer genvar parameter localparam typedef struct
packed enum signed unsigned assign always always_ff always_comb always_latch begin end if else case endcase default for
generate endgenerate function endfunction automatic return import posedge negedge or and not initial task endtask
while do foreach break continue unique priority void string real shortint longint byte const var static""".split())
TYPES0 = {"logic", "wire", "reg", "bit", "int", "integer", "genvar", "byte", "shortint", "longint"}


def strip(src):
    src = re.sub(r"/\*.*?\*/", lambda m: "\n" * m.group(0).count("\n"), src, flags=re.S)
    src = re.sub(r"//[^\n]*", "", src)
    src = re.sub(r'"(\\.|[^"\\])*"', '""', src)
    # conditional-compilation lines go whole (both arms of an `ifdef declare the same name: the first counts)
    src = re.sub(r"`(ifdef|ifndef|elsif|define|undef|include|timescale)\b[^\n]*", " ", src)
    src = re.sub(r"`\w+", " ", src)                          # `else / `endif / macro uses
    src = re.sub(r"\d+'[sS]?[bBoOdDhH][0-9a-fA-F_xXzZ?]+", "0", src)
    src = re.sub(r"'[01xXzZ]", "0", src)
    return src


def check(path):
    text = strip(open(path, encoding="utf-8", errors="replace").read())
    lines = text.split("\n")
    bad = []
    # module spans
    for m in re.finditer(r"\bmodule\s+(\w+)(.*?)\bendmodule\b", text, flags=re.S):
        name = m.group(1)
        body_start = m.start(2)
        body = m.group(2)
        line0 = text.count("\n", 0, body_start) + 1
        # the header ends at the first ');' that closes the port list
        hdr_end = body.find(");")
        hdr = body[: hdr_end + 2] if hdr_end >= 0 else ""
        decl = {}
        for ident in re.findall(r"\b[A-Za-z_]\w*\b", hdr):
            if ident not in KW:
                decl.setdefault(ident, line0)
        rest = body[len(hdr):]
        rest_line0 = line0 + hdr.count("\n")
        types = set(TYPES0)
        # walk statements at block depth 0 (begin/end, function/endfunction, case/endcase nesting)
        depth = 0; brace = 0; in_func = 0
        toks = list(re.finditer(r"\.\s*[A-Za-z_]\w*|\b[A-Za-z_]\w*\b|;|\(|\)|\{|\}|\[|\]|=|,", rest))
        uses = {}
        stmt = []
        for t in toks:
            s = t.group(0)
            ln = rest_line0 + rest.count("\n", 0, t.start())
            if s.startswith("."):                                # member access / named port: not a module-scope name
                continue
            if s in ("function", "task"):
                in_func += 1
            elif s in ("endfunction", "endtask"):
                in_func -= 1
            if s in ("begin", "function", "task", "case", "generate", "fork"):
                depth += 1
            elif s in ("end", "endfunction", "endtask", "endcase", "endgenerate", "join"):
                depth -= 1
            if s == "{": brace += 1
            if s == "}": brace -= 1
            if s in ("end", "endfunction", "endtask", "endcase", "endgenerate", "begin", "join"):
                stmt = []                                        # a block keyword ends a statement too
                continue
            in_typedef = bool(stmt) and stmt[0][0] == "typedef"      # struct member names are not uses
            if re.match(r"[A-Za-z_]", s) and s not in KW and not in_func and not in_typedef:
                uses.setdefault(s, ln)
            stmt.append((s, ln))
            if s == ";" and brace == 0:
                # a module-scope declaration statement?
                words = [w for w, _ in stmt]
                if depth == 0 and words:
                    i = 0
                    if words[0] == "typedef":
                        # typedef ... name;  (the last identifier)
                        ids = [(w, l) for w, l in stmt if re.match(r"[A-Za-z_]", w) and w not in KW]
                        if ids:
                            types.add(ids[-1][0])
                            decl.setdefault(ids[-1][0], ids[-1][1])
                            # enum members
                            if "enum" in words:
                                for w, l in ids[:-1]:
                                    decl.setdefault(w, l)
                    elif words[0] in ("parameter", "localparam") or words[0] in types or (words[0] == "import"):
                        if words[0] == "import":
                            pass
                        else:
                            # declarators: identifiers not inside [] / () and not after '=' until ','
                            br = 0; after_eq = False; first = True
                            for w, l in stmt:
                                if w in ("[", "(", "{"): br += 1; continue
                                if w in ("]", ")", "}"): br -= 1; continue
                                if br: continue
                                if w == "=": after_eq = True; continue
                                if w == ",": after_eq = False; continue
                                if after_eq or w in KW or w in types or not re.match(r"[A-Za-z_]", w):
                                    continue
                                decl.setdefault(w, l)
                stmt = []
        for ident, dl in decl.items():
            ul = uses.get(ident)
            if ul is not None and ul < dl:
                bad.append((path, name, ident, ul, dl))
    return bad


def main():
    bad = []
    for p in sys.argv[1:]:
        bad += check(p)
    for path, mod, ident, ul, dl in bad:
        print(f"USE-BEFORE-DECLARE {path}:{ul}: {mod}.{ident} used at line {ul}, declared at line {dl}")
    print(f"decl-order: {len(sys.argv) - 1} files, {len(bad)} use-before-declare")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
