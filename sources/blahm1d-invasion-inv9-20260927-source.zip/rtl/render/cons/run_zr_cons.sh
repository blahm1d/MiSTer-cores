#!/bin/bash
# Object-queue conservation bench (zr_render5 + zr_setup9 + extent FIFO + zr_pixel10, stub front end).
# usage: wsl -d Ubuntu -- bash run_zr_cons.sh [nseeds] [records] [mode] [first-seed]
# ZRC_MUT=sed-expression mutates zr_render5.sv, ZRC_SMUT mutates zr_setup9.sv (refuses to run if it did not apply).
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-cons-$$"; mkdir -p "$B"; cd "$B" || exit 2
R5="$S/render/zr_render5.sv"; S9="$S/setup/zr_setup9.sv"
# pixel pipe: the handshake stub (default, seconds-scale) or ZRC_PIX=real (zr_pixel10 + a random-latency wave RAM)
PIX="$S/render/cons/zr_pixel10_stub.sv"; [ "${ZRC_PIX:-stub}" = real ] && PIX="$S/pixel/zr_pixel10.sv"
if [ -n "${ZRC_MUT:-}" ]; then sed "$ZRC_MUT" "$R5" > zr_render5.sv; cmp -s zr_render5.sv "$R5" && { echo "MUTATION DID NOT APPLY"; exit 3; }; R5=zr_render5.sv; fi
if [ -n "${ZRC_SMUT:-}" ]; then sed "$ZRC_SMUT" "$S9" > zr_setup9.sv; cmp -s zr_setup9.sv "$S9" && { echo "MUTATION DID NOT APPLY"; exit 3; }; S9=zr_setup9.sv; fi
verilator --cc --exe --build -O2 -j 8 --top-module zr_render5 ${ZRC_G:-} -GSB_AW=13 -GEQ_AW=${ZRC_EQ:-8} -GOQ_AW=${ZRC_OQ:-8} -DZR_SIM -DZR_CENSUS -DZR_PROBE -Wno-fatal -Wno-lint -Wno-style \
  "$S/fp32/fp32_pkg.sv" "$S/fp32/fp32_units.sv" "$S/setup/zr_sdp.sv" "$S/render/cons/zr_front5_stub.sv" "$S9" \
  $PIX "$S/render/zr_fifo.sv" "$S/render/zr_rfifo.sv" "$R5" "$S/render/cons/tb_zr_cons.cpp" ${ZRC_CF:+-CFLAGS "$ZRC_CF"} -o tb > build.log 2>&1 || { grep -m5 -B2 -A6 "error" build.log; echo "BUILD FAILED"; exit 2; }
N=${1:-20}; REC=${2:-2000}; MODE=${3:-0}; F=${4:-1}; bad=0
seq $F $((F + N - 1)) | xargs -P ${ZRC_J:-16} -I{} sh -c "./obj_dir/tb {} $REC $MODE > out.{}.txt 2>&1; echo \$? > rc.{}.txt"
cat $(for ((s = F; s < F + N; s++)); do echo out.$s.txt; done) | grep -v "^PASS" | head -40
bad=$(cat rc.*.txt | grep -vc "^0$")
echo "conservation: $N seeds, $bad failed"
cd /; rm -rf "$B"; [ $bad -eq 0 ]
