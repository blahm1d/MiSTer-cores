// zr_front5_stub.sv -- conservation bench only (tb_zr_cons.cpp): replaces zr_front5 under the SAME module name so
// zr_render5 is benched unmodified. The record stream (RB / CLR / QUD / DBQ / HWW / HRD) comes from the C++ generator
// through DPI; no register file, no wave RAM traffic. Never in a synthesis file list.
module zr_front5 import fp32_pkg::*; (
  input  logic        clk, rst,
  input  logic        wr_valid, output logic wr_ready, input logic [9:0] wr_off, input logic [31:0] wr_data,
  input  logic [9:0]  rd_off, output logic [31:0] rd_data,
  output logic [31:0] reg_cc, reg_b6, output logic mode32, output logic host_rd_ok,
  output logic        m_req, m_we, m_ram, output logic [20:0] m_blk, output logic [3:0] m_lanes, output logic [63:0] m_wdata,
  input  logic        m_gnt, m_rvalid, input logic [63:0] m_rdata,
  output logic        o_valid, input logic o_ready, output logic [31:0] o_word,
  output logic        idle,
`ifdef ZR_SEED
  input  logic        sd_we, input logic [3:0] sd_sel, input logic [9:0] sd_idx, input logic [31:0] sd_data,
  output logic [31:0] dbg_state [20],
`endif
  output logic [31:0] st_quads, st_culled, st_emitted, st_exc, st_busy,
  output logic [31:0] st_mem, st_tr, st_zc, st_proj, st_emit, st_dec, st_hwait
);
  import "DPI-C" function int cons_next(output int w);   // 1: a word is offered this clock (w); 0: a gap
  logic have; logic [31:0] w;
  assign o_valid = have; assign o_word = w; assign idle = !have;
  assign wr_ready = 1'b1; assign rd_data = '0; assign reg_cc = '0; assign reg_b6 = '0; assign mode32 = 1'b0; assign host_rd_ok = 1'b1;
  assign m_req = 1'b0; assign m_we = 1'b0; assign m_ram = 1'b0; assign m_blk = '0; assign m_lanes = '0; assign m_wdata = '0;
  assign st_quads = '0; assign st_culled = '0; assign st_emitted = '0; assign st_exc = '0; assign st_busy = '0;
  assign st_mem = '0; assign st_tr = '0; assign st_zc = '0; assign st_proj = '0; assign st_emit = '0; assign st_dec = '0; assign st_hwait = '0;
`ifdef ZR_SEED
  assign dbg_state = '{default: '0};
`endif
  always_ff @(posedge clk)
    if (rst) have <= 1'b0;
    else if (!have || o_ready) begin
      int ww; int ok;
      ok = cons_next(ww);
      have <= (ok != 0); w <= ww;
    end
endmodule
