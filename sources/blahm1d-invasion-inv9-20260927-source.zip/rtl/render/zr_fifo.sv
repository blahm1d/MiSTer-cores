// zr_fifo.sv -- first-word-fall-through FIFO, 2**AW entries of W bits. MEASUREMENT version: the storage is a flop
// array with a combinational read, so it answers "what does decoupling buy" without RAM-latency plumbing. For the fit
// it is replaced by an M10K-backed version (a combinational read cannot map to M10K -- it would become LUT-RAM).
module zr_fifo #(parameter int W = 32, parameter int AW = 4) (
  input  logic         clk, rst,
  input  logic         in_valid, output logic in_ready, input logic [W-1:0] in_data,
  output logic         out_valid, input logic out_ready, output logic [W-1:0] out_data,
  output logic [AW:0]  count
);
  logic [W-1:0] mem [2**AW];
  logic [AW-1:0] wp, rp;
  assign in_ready  = count != (AW+1)'(2**AW);
  assign out_valid = count != 0;
  assign out_data  = mem[rp];
  always_ff @(posedge clk) begin
    if (rst) begin wp <= '0; rp <= '0; count <= '0; end
    else begin
      if (in_valid && in_ready) begin mem[wp] <= in_data; wp <= wp + 1'b1; end
      if (out_valid && out_ready) rp <= rp + 1'b1;
      count <= count + (AW+1)'(in_valid && in_ready) - (AW+1)'(out_valid && out_ready);
    end
  end
endmodule
