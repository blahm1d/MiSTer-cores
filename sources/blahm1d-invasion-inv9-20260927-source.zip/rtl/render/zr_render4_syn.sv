// zr_render4_syn.sv -- synthesis wrapper of zr_render4 for the standalone unit fit (the seed / census ports exist only
// under ZR_SEED, which synthesis does not define). No logic.
module zr_render4_syn (
  input  logic        clk, rst,
  input  logic        wr_valid, output logic wr_ready, input logic [9:0] wr_off, input logic [31:0] wr_data,
  input  logic [9:0]  rd_off, output logic [31:0] rd_data,
  output logic        fm_req, fm_we, fm_ram, output logic [20:0] fm_blk, output logic [3:0] fm_lanes,
  output logic [63:0] fm_wdata, input logic fm_gnt, input logic fm_rvalid, input logic [63:0] fm_rdata,
  output logic        w0_req, output logic [20:0] w0_line, input logic w0_gnt, input logic w0_rvalid, input logic [63:0] w0_data,
  output logic        cw_valid, input logic cw_ready, output logic [31:0] cw_addr, output logic [31:0] cw_data, output logic [1:0] cw_mask,
  output logic        cr_req, output logic [31:0] cr_addr, input logic cr_gnt, input logic cr_rvalid, input logic [15:0] cr_data,
  input  logic [31:0] rb_init,
  input  logic [16:0] dbg_daddr, output logic [15:0] dbg_ddata,
  output logic [31:0] rb_now,
  output logic        idle, unsupported,
  output logic [31:0] st_quads, st_polys, st_rejected, st_extents,
  output logic [31:0] st_clk, st_wsetup, st_wdrain, st_extstall, st_pixstarve, st_frontwait
);
  zr_render4 u (.*);
endmodule
