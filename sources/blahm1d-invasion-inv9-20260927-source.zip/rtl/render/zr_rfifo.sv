// zr_rfifo.sv -- first-word-fall-through FIFO whose storage is a simple-dual-port RAM with a REGISTERED read (the
// M10K / MLAB inference shape). The RAM holds 2**AW words; a two-entry output buffer absorbs the one-clock read latency
// so a word can leave every clock. Write-to-out_valid latency is two clocks. The RAM never sees a read and a write of
// the same word in the same clock: a word is read only after the edge that wrote it, and the write pointer reaches the
// read pointer only when the RAM is full (and then nothing is written).
//
// sound-area (2026-09-25): the output buffer's SECOND entry is the RAM's own read register. The RAM read carries a read
// enable (M10K rden / MLAB output clock enable), so its output holds the word last read until the next read; the
// second buffer entry is occupied exactly when ob_n == 2, and in that state no read is issued unless the head pops in
// the same clock (ob_n + r_v - pop < 2), so the held word is still on q at the edge that moves it to the head. External
// behaviour (in_ready, out_valid, out_data while out_valid, empty) is cycle-identical to the two-flop-entry version:
// lanes/sound-area/gates/rfifo_equiv (random + directed, old vs new, every clock). Saves W flops and the head's input
// mux per instance.
module zr_rfifo #(parameter int W = 32, parameter int AW = 5) (
  input  logic         clk, rst,
  input  logic         in_valid, output logic in_ready, input logic [W-1:0] in_data,
  output logic         out_valid, input logic out_ready, output logic [W-1:0] out_data,
  output logic         empty
);
  logic [AW-1:0] wp, rp; logic [AW:0] rc;          // rc: words in the RAM not yet read out
  logic r_v; logic [W-1:0] q;                       // a read in flight; the RAM read register (held while not reading)
  logic [W-1:0] ob0; logic [1:0] ob_n;              // head entry; the second entry, when ob_n == 2, is q
  logic wr, rd, pop;
  logic [W-1:0] mem [2**AW];
  assign in_ready = rc != (AW+1)'(2**AW);
  assign wr = in_valid && in_ready;
  assign pop = out_valid && out_ready;
  assign rd = (rc != 0) && ({1'b0, ob_n} + {2'b0, r_v} - {2'b0, pop}) < 3'd2;
  assign out_valid = ob_n != 0;
  assign out_data = ob0;
  assign empty = rc == 0 && !r_v && ob_n == 0;
  always_ff @(posedge clk) begin
    if (wr) mem[wp] <= in_data;
`ifdef ZR_RDW_HOSTILE
    if (rd && wr && wp == rp) q <= in_data ^ W'(1); else
`endif
    if (rd) q <= mem[rp];
  end
  always_ff @(posedge clk) begin
    if (rst) begin wp <= '0; rp <= '0; rc <= '0; r_v <= 1'b0; ob_n <= '0; end
    else begin
      if (wr) wp <= wp + 1'b1;
      if (rd) rp <= rp + 1'b1;
      rc <= rc + (AW+1)'(wr) - (AW+1)'(rd);
      r_v <= rd;
      // head load: the second entry (q) moves up on a pop from 2, or a landing read fills an empty head
      if ((pop && ob_n == 2'd2) || (r_v && (ob_n - 2'(pop)) == 2'd0)) ob0 <= q;
      ob_n <= ob_n - 2'(pop) + 2'(r_v);
    end
  end
endmodule
