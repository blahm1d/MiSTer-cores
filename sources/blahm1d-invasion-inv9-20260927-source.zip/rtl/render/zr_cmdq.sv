// zr_cmdq.sv -- the CPU -> Zeus 1 COMMAND QUEUE: register writes {offset, data} are accepted into an M10K FIFO at once
// and drained into the front end as it becomes ready, so the CPU keeps computing while the renderer draws.
// Why (measured 2026-09-22): without it the front end takes a register write only in S_IDLE (zr_front5.sv:462), so the
// CPU waits behind every command; the paced gate counted ~870 K clocks per frame of CPU-waits-for-front on hvpoly.
// MAME draws in zero game time; real hardware overlaps CPU and renderer -- the queue is that overlap. The front end
// sees exactly the same write sequence, so the renderer's output is unchanged (bit-exact gates).
// Reads that depend on queued writes (every Zeus register except the beam specials) must wait for `empty` (zk4_core);
// the queue itself only reports it.
// AW = 0: bypass (the pre-queue behaviour, for regression).
module zr_cmdq #(parameter int AW = 10) (
  input  logic        clk, rst,
  input  logic        in_valid, output logic in_ready, input logic [9:0] in_off, input logic [31:0] in_data,
  output logic        out_valid, input logic out_ready, output logic [9:0] out_off, output logic [31:0] out_data,
  output logic        empty,
  output logic [31:0] st_max_occ, st_full_clk                     // census: peak occupancy, clocks the queue refused
);
  generate if (AW == 0) begin : g_bypass
    assign out_valid = in_valid; assign in_ready = out_ready; assign out_off = in_off; assign out_data = in_data;
    assign empty = 1'b1;
    always_ff @(posedge clk) if (rst) begin st_max_occ <= '0; st_full_clk <= '0; end
                             else if (in_valid && !in_ready) st_full_clk <= st_full_clk + 1'b1;
  end else begin : g_q
    logic [41:0] q_out;
    zr_rfifo #(42, AW) u_q (.clk, .rst, .in_valid, .in_ready, .in_data({in_off, in_data}),
      .out_valid, .out_ready, .out_data(q_out), .empty);
    assign out_off = q_out[41:32]; assign out_data = q_out[31:0];
    logic [31:0] occ;
    always_ff @(posedge clk)
      if (rst) begin occ <= '0; st_max_occ <= '0; st_full_clk <= '0; end
      else begin
        occ <= occ + 32'(in_valid && in_ready) - 32'(out_valid && out_ready);
        if (occ > st_max_occ) st_max_occ <= occ;
        if (in_valid && !in_ready) st_full_clk <= st_full_clk + 1'b1;
      end
  end endgenerate
endmodule
