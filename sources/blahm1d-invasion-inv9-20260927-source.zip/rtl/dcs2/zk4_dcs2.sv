// zk4_dcs2.sv -- the whole MK4 DCS2 sound board in fabric, around dcs2_engine. Built to the main
// session's INTEGRATION-CONTRACT.md; instantiated in zk4_top (param DCS_FABRIC) in place of
// zk4_dcs_stub on zk4_ddr_arb3's S port. Memory map transcribed from the PROVEN golden board
// (lanes/dcs2-engine/python/dcs2_board.py == gospel/dcs.cpp:985-1160). One clock, 50 MHz.
// Quartus-17-safe: no `inside`, no function-result part-selects, casez only, no `unique`.
//
// STRUCTURAL STATUS (2026-09-23): synthesizable, port-accurate, real memory blocks + caches + DDR
// master + mailbox + SPORT/DAC + ROM loader + boot FSM. GATE-2 CALIBRATION ITEMS (flagged CAL#):
//   CAL1 SPORT autobuffer is modelled as SPORT-tx-register writes (real DCS DMAs a DM buffer).
//   CAL2 sport interrupt vector index (SPORT_IRQ_INDX) pending the MAME IRQ trace.
//   CAL3 IRQ one-shot handshake timing vs the engine's fetch.
`default_nettype none
module zk4_dcs2 #(
  parameter [31:0] ROM_BASE  = 32'h3100_0000,
  parameter [31:0] SRAM_BASE = 32'h3180_0000,
  parameter [2:0]  SPORT_IRQ_INDX = 3'd3,       // SPORT1 TX -> indx 3 (adsp2100.cpp:987-990)
  parameter bit    PACE_EN  = 1'b1,             // real-time pacer: 16 MHz ADSP-2104 = 16/50 instr per clk
  parameter int    PACE_CAP = 64,               // max banked catch-up credit, in instructions
  // sound ROM layout: 0 = MK4 (ROM_START(mk4) :1507-1511: u2 1 MiB + u3/u4/u5 2 MiB = 7 MiB stream), 1 = Invasion
  // (ROM_START(invasnab) :1573-1576: u2/u3/u4/u5 all 2 MiB = 8 MiB stream, exactly ROM_BASE .. SRAM_BASE)
  parameter bit    INV_ROM  = 1'b0,
  // DCS2 SPORT0 1 kHz timer (dcs.cpp:1889-1903 + sport0_irq :1999-2010), which the dcs2_audio_device has (:2558). MK4's
  // sound firmware never sets SYSCONTROL bit 12 (PACEGATE counts 0 SPORT0 interrupts), Invasion's does (MAME trace
  // invdcs: 749 SPORT0-RX vector entries in 777 ms) and waits on it -- built only where it is used.
  parameter bit    SPORT0_TIMER = 1'b0,
  parameter bit    LATCH_STATUS = 1'b0,         // dcs2_mailbox: 0x0402 output_control + 0x0403 latch_status + data2 (Invasion)
  // inv-buzz (2026-09-26): Invasion's DSP ping-pongs two DM regions that share the direct-mapped DM cache's slots and
  // streams several ROM-window pages at once (86 pages in 14 s of gameplay, A-B-A returns); each miss / 1K page fill
  // is a DDR round trip on the HPS DDR3 shared with the renderer and ascal; past ~60 clk per round trip the DSP misses the
  // half-buffer deadline and the DAC replays a stale half-buffer
  // (the cabinet buzz; MEASURED lanes/inv-buzz). Invasion builds: a 4-way hashed DM cache + a sectored ROM-window buffer.
  // MK4 (INV_ROM=0): direct-mapped cache + ONE page, the proven structure (its steady play never misses).
  parameter int    DM_WAYS_INV   = 4,           // 1 (direct-mapped) or 4 (4-way hashed) (Invasion only)
  parameter int    ROM_SLOTS_INV = 8,           // ROM-window buffer slots (Invasion only; MK4 = 1 slot of 1K)
  parameter int    ROM_SECT_INV  = 256          // words per slot: 256 = a quarter of a 1K window page (Invasion only)
) (
  input  logic        clk,
  input  logic        por,
  input  logic        rst,
  // host side (zk4_dcs_stub semantics)
  input  logic        data_w,
  input  logic [15:0] wdata,
  input  logic        ack_w,
  input  logic        data_r,
  input  logic        reset_w,
  input  logic        reset_level,
  output logic [15:0] control,
  output logic [15:0] data, data2,
  output logic        input_empty, output_full,
  // sound ROM load (hps_io WIDE ioctl, index 3, 7 MiB compact stream u2+u3+u4+u5)
  input  logic        ioctl_download, ioctl_wr,
  input  logic [15:0] ioctl_index, ioctl_dout,
  output logic        ioctl_wait,
  // DDR (zk4_ddr_arb3 S port)
  output logic        s_read, s_write,
  output logic [31:0] s_address,
  output logic [63:0] s_writedata,
  output logic [7:0]  s_byteenable,
  input  logic        s_waitrequest, s_readdatavalid,
  input  logic [63:0] s_readdata,
  // audio
  output logic signed [15:0] audio_l, audio_r,
  output logic        audio_ce,
  // status
  output logic        rom_loaded,
  output logic [31:0] rom_bytes, rom_crc,
  output logic [31:0] cache_misses, dac_underruns,
  output logic [31:0] pm_oow,          // sticky: # fetches OUTSIDE the TCM window (status-mirror telemetry)
  output logic [13:0] dsp_pc
);
  // ================= SDRC register file + field decode (dcs.cpp:222-240) =================
  logic [15:0] sdrc0, sdrc1, sdrc2, sdrc3;
  logic [7:0]  sdrc_seed;
  wire       SM_EN  = sdrc0[11];
  wire       SM_BK  = sdrc0[12];
  wire       ROM_MS = sdrc0[5];
  wire [1:0] ROM_ST = sdrc0[1:0];
  wire       ROM_SZ = sdrc0[4];
  wire [2:0] SMODE  = sdrc0[15:13];
  wire [1:0] DM_ST  = sdrc1[1:0];
  wire [12:0] EPM_PG = sdrc2[12:0];

  // ROM window base/size (dcs.cpp:1018-1022)
  wire        rw_en   = SM_EN && ROM_MS && (ROM_ST!=2'd3);
  wire [13:0] rw_base = (ROM_ST==2'd0)? 14'h0000 : (ROM_ST==2'd1)? 14'h3000 : 14'h3400;
  wire        rw_1k   = !(ROM_SZ==1'b0 && ROM_ST!=2'd0);   // pagesize 1024 vs 4096
  wire [13:0] rw_len  = rw_1k ? 14'd1024 : 14'd4096;

  // ================= on-chip M10K arrays (Quartus-17 inferable template: ONE write port, REGISTERED
  // read in the SAME clocked block, NO array reset, ramstyle "M10K, no_rw_check"). Each array's
  // write/read controls are driven by the servicer FSMs below (single driver per control signal). ===
  // Read address is COMBINATIONAL (the held access address); only the data is registered => exactly
  // one cycle to valid data, aligned with the servicers' 1-cycle e_pm_ready/e_dm_ready. (A registered
  // read address would be 2 cycles -- off by one, which desyncs the engine's !ready re-request.)
  wire [8:0] pmi_ra = e_pm_addr[8:0];
  wire [8:0] iri_ra = e_dm_addr[8:0];
  localparam int NPG = INV_ROM ? ROM_SLOTS_INV : 1;            // ROM-window buffer slots
  localparam int SW  = INV_ROM ? ROM_SECT_INV : 1024;          // words per slot (MK4: one whole 1K page, as before)
  localparam int SWB = $clog2(SW);
  localparam int PSW = (NPG > 1) ? $clog2(NPG) : 1;            // slot index width
  localparam int RWA = SWB + ((NPG > 1) ? $clog2(NPG) : 0);    // buffer address width
  logic [PSW-1:0] rw_rslot;                                    // slot the DM servicer reads (hit slot / filling slot)
  wire [RWA-1:0] rwn_ra = (NPG > 1) ? RWA'({rw_rslot, dm_rom_off[SWB-1:0]}) : RWA'(dm_rom_off[SWB-1:0]);
  wire [1:0] rw_sect = 2'(dm_rom_off[9:0] >> SWB);                // sector of the 1K window the access is in
  // PM internal (512x24)
  (* ramstyle="M10K, no_rw_check" *) reg [23:0] pm_int [0:511];
  reg [23:0] pm_int_q; reg pmi_we; reg [8:0] pmi_wa; reg [23:0] pmi_wd;
  always @(posedge clk) begin
    if (pmi_we) pm_int[pmi_wa] <= pmi_wd;
    pm_int_q <= pm_int[pmi_ra];
  end
  // PM tightly-coupled M10K for the FETCH window 0x2800-0x2FFF (2048x24), direct-wired exactly like
  // pm_int: combinational read address, registered data NEXT clock, NO req/ack/cache. Measured: ALL
  // executed SRAM-PM code (boot AND gameplay) is in 0x2800-0x2FFF; out-of-window PM stays on pmc.
  wire [10:0] tcm_ra = e_pm_addr[10:0];
  (* ramstyle="M10K, no_rw_check" *) reg [23:0] pm_tcm [0:2047];
  reg [23:0] tcm_q; reg tcm_we; reg [10:0] tcm_wa; reg [23:0] tcm_wd;
  always @(posedge clk) begin
    if (tcm_we) pm_tcm[tcm_wa] <= tcm_wd;
    tcm_q <= pm_tcm[tcm_ra];
  end
  // IRAM (512x16)
  (* ramstyle="M10K, no_rw_check" *) reg [15:0] iram [0:511];
  reg [15:0] iram_q; reg iri_we; reg [8:0] iri_wa; reg [15:0] iri_wd;
  always @(posedge clk) begin
    if (iri_we) iram[iri_wa] <= iri_wd;
    iram_q <= iram[iri_ra];
  end
  // ROM-window buffer: NPG slots of SW region words (inv-buzz: Invasion 8 x 256-word sectors, MK4 1 x 1K page)
  // A region word is 0xFF00|byte (populated) or 0xFFFF (hole): stored as 9 bits {pop, byte} -- NPG x SW x 9 (MK4: 1 x 1K =
  // 1Kx10 x 1 = the old 1024x16 minus a block; Invasion: 8 x 256 = 2Kx5 x 2 = 2 M10K = the old count).
  (* ramstyle="M10K, no_rw_check" *) reg [8:0] romwin [0:NPG*SW-1];
  reg [8:0] romwin_q9; reg rwn_we; reg [RWA-1:0] rwn_wa; reg [8:0] rwn_wd;
  always @(posedge clk) begin
    if (rwn_we) romwin[rwn_wa] <= rwn_wd;
    romwin_q9 <= romwin[rwn_ra];
  end
  wire [15:0] romwin_q = romwin_q9[8] ? {8'hff, romwin_q9[7:0]} : 16'hffff;
  logic [12:0] romwin_pg;        // the page being filled / last filled (fill FSM)
  logic [1:0]  pf_sect;          // the sector of romwin_pg being filled
  logic        romwin_valid;     // (1-slot view, kept for the benches: slot 0 valid)
  logic [PSW-1:0] pf_slot;       // slot the fill writes
  logic [14:0] pg_tag [NPG];     // slot k holds {page, sector} pg_tag[k] when pg_val[k]
  logic [NPG-1:0] pg_val;
  logic [NPG*PSW-1:0] pg_ord;    // recency order: slot pg_ord[k*PSW +: PSW] is the k-th most recent
  logic        rw_hit;           // {EPM_PG, rw_sect} is in a VALID slot (rw_hslot)
  logic [PSW-1:0] rw_hslot;
  always_comb begin
    rw_hit = 1'b0; rw_hslot = '0;
    for (int k = 0; k < NPG; k++) if (pg_val[k] && pg_tag[k] == {EPM_PG, rw_sect}) begin rw_hit = 1'b1; rw_hslot = PSW'(k); end
  end
  assign rw_rslot = rw_hit ? rw_hslot : pf_slot;
  // fill victim: an invalid slot first, else the least recent
  logic [PSW-1:0] pf_victim;
  always_comb begin
    pf_victim = pg_ord[(NPG-1)*PSW +: PSW];
    for (int k = NPG-1; k >= 0; k--) if (!pg_val[k]) pf_victim = PSW'(k);
  end
  assign romwin_valid = pg_val[0];
  logic        pf_filling;       // a page fill for romwin_pg is in progress (fill FSM owns it)
  logic [10:0] pf_wr_n;          // # words of romwin_pg already WRITTEN into the M10K (0..rw_len)

  // ================= engine <-> subsystem buses =================
  logic        e_pm_rd, e_pm_wr; logic [13:0] e_pm_addr; logic [23:0] e_pm_wdata;
  logic [23:0] e_pm_rdata; logic e_pm_ready;
  logic        e_dm_rd, e_dm_wr; logic [13:0] e_dm_addr; logic [15:0] e_dm_wdata;
  logic [15:0] e_dm_rdata; logic e_dm_ready;
  logic        e_irq_take; logic [2:0] e_irq_indx;
  logic        e_commit; logic [1887:0] e_dbg;
  logic        eng_rst;         // held during boot + when the mailbox halts the DSP
  logic        sysctl_wr9;      // SYSCONTROL (0x3fff) write with bit9 (BOOT FORCE) committed this cycle (used by the autobuf irq_clr)
  logic        s0_ctl_we; logic [15:0] s0_ctl_d;   // any SYSCONTROL write + its data (SPORT0 timer start / stop)
  logic        s0_oc_rd;        // the DSP read output_control (DM 0x0402) this cycle (sport0_irq's interlock)
  logic        ab_i7_we; logic [13:0] ab_i7_wd;  // CAL1: autobuffer side-write of I[7] (=reg)
  logic        e_tx1_we;        // engine: SPORT1 TX register write -> arm the autobuffer
  logic        e_ifc_we; logic [15:0] e_ifc_val;   // engine: IFC write (interrupt latch clear / force, autobuf)
  logic        sport_tx_irq;    // CAL1: SPORT1-TX interrupt (indx3) on buffer wrap (from dcs2_autobuf)
  logic        timer_irq;       // CAL3: ADSP-2101 timer interrupt (indx5) (from dcs2_autobuf)
  logic        e_irq_ack; logic [2:0] e_irq_ack_indx;  // engine: IRQ taken (clears latched source)

  // autobuffer side port (DAG MLAB): autobuf publishes indices, engine returns selected I/M/L + pc/mstat/I7
  wire [2:0]  ab_ireg_w, ab_mreg_w, ab_lreg_w;
  wire [13:0] ab_i_w, ab_m_w, ab_l_w, ab_i7_w, ab_pc_w; wire [6:0] ab_mstat_w;
  wire        e_icntl2; wire [5:0] e_imask;     // engine ICNTL[2] (IRQ2 edge) + IMASK (autobuf mux skips masked)
  // ================= REAL-TIME PACER (cycle credit) =================
  // The MK4 sound CPU is an ADSP-2104 on a 16 MHz XTAL (dcs.cpp:2598 ADSP2104(..., XTAL(16'000'000))),
  // one instruction per CPU cycle (adsp2100.cpp:1148-1162 execute_min/max_cycles = 1; the execute loop
  // retires one opcode per m_icount-- at :1919). No wait states are charged: WAITSTATES_REG (0x3ffe) and
  // SDRC_DM_3WS are declared (dcs.cpp:216/232) but never read. => 16 MIPS = 16 DSP cycles per 50 fabric
  // clocks. Credit += PACE_NUM each clock, -= PACE_DEN per retired instruction (e_commit); the engine may
  // START an instruction only while (credit - this cycle's debit) >= PACE_DEN (pace_hold to the engine,
  // which caches the opcode and waits at the instruction boundary). Credit saturates at PACE_CAP
  // instructions so a DDR stall can be caught up by at most PACE_CAP instructions, never unbounded.
  // CAL3 timer still counts e_commit (= DSP cycles), unchanged.
  localparam int PACE_NUM = 16, PACE_DEN = 50;
  localparam int PACE_MAX = PACE_CAP*PACE_DEN;
  localparam int PCW = $clog2(PACE_MAX+PACE_NUM+1) + 1;       // credit width (+1 sign)
  logic [PCW-2:0] pace_cr;                               // credit, 0..PACE_MAX
  wire  [PCW-1:0] pace_eff = {1'b0,pace_cr} - (e_commit ? PCW'(PACE_DEN) : PCW'(0));  // after this cycle's debit
  wire         pace_hold = PACE_EN && (pace_eff[PCW-1] || (pace_eff < PCW'(PACE_DEN)));
  always_ff @(posedge clk) begin
    if (eng_rst) pace_cr <= '0;
    else begin
      logic [PCW-1:0] nx; nx = pace_eff + PCW'(PACE_NUM);
      if (nx[PCW-1]) pace_cr <= '0;                        // (cannot happen: every start is credit-gated)
      else if (nx > PCW'(PACE_MAX)) pace_cr <= (PCW-1)'(PACE_MAX);
      else pace_cr <= nx[PCW-2:0];
    end
  end

  dcs2_engine u_eng (
    .clk(clk), .rst(eng_rst), .ce(1'b1), .pace_hold(pace_hold),
    .pm_rd(e_pm_rd), .pm_wr(e_pm_wr), .pm_addr(e_pm_addr), .pm_wdata(e_pm_wdata),
    .pm_rdata(e_pm_rdata), .pm_ready(e_pm_ready),
    .dm_rd(e_dm_rd), .dm_wr(e_dm_wr), .dm_addr(e_dm_addr), .dm_wdata(e_dm_wdata),
    .dm_rdata(e_dm_rdata), .dm_ready(e_dm_ready),
    .irq_take(e_irq_take), .irq_indx(e_irq_indx),
    .i7_we(ab_i7_we), .i7_wd(ab_i7_wd), .warm_rst(warm_reset),
    .irq_ack(e_irq_ack), .irq_ack_indx(e_irq_ack_indx), .tx1_we(e_tx1_we), .ifc_we(e_ifc_we), .ifc_val(e_ifc_val),
    .seed_en(1'b0), .seed(1888'd0),
    .ab_ireg(ab_ireg_w), .ab_mreg(ab_mreg_w), .ab_lreg(ab_lreg_w),
    .ab_i(ab_i_w), .ab_m(ab_m_w), .ab_l(ab_l_w),
    .ab_i7(ab_i7_w), .ab_pc(ab_pc_w), .ab_mstat(ab_mstat_w), .ab_icntl2(e_icntl2), .ab_imask(e_imask),
    .commit(e_commit), .dbg(e_dbg),
    .undec_seen(), .undec_pc(), .undec_op()
  );
  assign dsp_pc = ab_pc_w;                  // engine pc (side port; was e_dbg[13:0])
  wire [13:0] e_i7 = ab_i7_w;               // I[7] -- the autobuffer pointer (side port)

  // ================= DDR agent + ROM loader =================
  logic        rs_valid; logic [15:0] rs_data; logic rs_ready; logic [31:0] rs_woff;
  logic        c_req, c_we; logic [31:0] c_addr; logic [63:0] c_wdata; logic [7:0] c_be;
  logic        c_ack, c_rvalid; logic [63:0] c_rdata; logic [31:0] ddr_reads, ddr_writes; logic rs_idle;
  logic        c_can_accept;

  dcs2_ddr_agent #(.ROM_BASE(ROM_BASE), .SRAM_BASE(SRAM_BASE)) u_ddr (
    .clk(clk), .por(por),
    .s_read(s_read), .s_write(s_write), .s_address(s_address), .s_writedata(s_writedata),
    .s_byteenable(s_byteenable), .s_waitrequest(s_waitrequest),
    .s_readdatavalid(s_readdatavalid), .s_readdata(s_readdata),
    .rs_valid(rs_valid), .rs_data(rs_data), .rs_ready(rs_ready), .rs_woff(rs_woff),
    .c_req(c_req), .c_we(c_we), .c_addr(c_addr), .c_wdata(c_wdata), .c_be(c_be),
    .c_ack(c_ack), .c_rvalid(c_rvalid), .c_rdata(c_rdata),
    .fl_req(fl_req), .fl_start(fl_start), .fl_fcnt(fcnt), .fl_rvalid(fl_rvalid_w), .fl_rdata(fl_rdata_w), .fl_busy(fl_busy_w),
    .ddr_reads(ddr_reads), .ddr_writes(ddr_writes), .rs_idle(rs_idle),
    .c_can_accept(c_can_accept)
  );

  // ROM loader (index 3, 7 MiB). Presents a 16-bit stream; we hand it a linear word offset.
  logic dcs_in_valid; logic [15:0] dcs_in_data; logic dcs_in_ready; logic dcs_stream_end;
  logic dcs_seen; logic [31:0] bytes_loaded, stream_crc, acc_w_cnt, drop_w_cnt; logic rdd;
  cusa_dcs_rom_loader #(.DCS_INDEX(8'd3), .EXPECTED_BYTES(INV_ROM ? 32'h0080_0000 : 32'h0070_0000)) u_ldr (
    .clk(clk), .por(por), .core_reset(rst),
    .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index), .ioctl_dout(ioctl_dout),
    .ioctl_wait(ioctl_wait),
    .dcs_in_valid(dcs_in_valid), .dcs_in_data(dcs_in_data), .dcs_in_ready(dcs_in_ready),
    .dcs_stream_end(dcs_stream_end), .dcs_seen(dcs_seen), .bytes_loaded(bytes_loaded),
    .stream_crc(stream_crc), .accepted_writes(acc_w_cnt), .dropped_writes(drop_w_cnt),
    .reset_during_download(rdd)
  );
  assign rom_loaded = dcs_stream_end && rs_idle;   // all ROM data in DDR (loader FIFO + agent tail drained)
  assign rom_bytes  = bytes_loaded;
  assign rom_crc    = stream_crc;

  // feed the loader stream into the DDR agent ROM-store port with a running word offset
  logic [31:0] rs_woff_r;
  assign rs_valid = dcs_in_valid;
  assign rs_data  = dcs_in_data;
  assign rs_woff  = rs_woff_r;
  assign dcs_in_ready = rs_ready | ~dcs_in_valid;   // agent accepts one word per rs_ready
  always_ff @(posedge clk) begin
    if (por) rs_woff_r <= 32'd0;
    else if (rs_valid && rs_ready) rs_woff_r <= rs_woff_r + 32'd1;
  end

  // ================= SRAM caches (PM 24-bit, DM 16-bit) =================
  // PM-SRAM view: 0x0800-0x3FFF program space (word addr = pm_addr). DDR sub-window at SRAM_BASE.
  // DM-SRAM view: banked index si (0..0x3FFF). DDR sub-window at SRAM_BASE+0x40000*8 (disjoint).
  localparam [31:0] PMSRAM_BASE = SRAM_BASE;                 // 0x31800000
  localparam [31:0] DMSRAM_BASE = SRAM_BASE + 32'h0004_0000; // + 0x40000 bytes, disjoint

  logic        pmc_req, pmc_we; logic [13:0] pmc_addr; logic [23:0] pmc_wdata;
  logic        pmc_ready; logic [23:0] pmc_rdata;
  logic        pmc_mreq, pmc_mwe; logic [31:0] pmc_maddr; logic [63:0] pmc_mwdata; logic [7:0] pmc_mbe;
  logic        pmc_mack, pmc_mrvalid; logic [31:0] pmc_miss; logic pmc_idle;
  dcs2_sram_cache #(.AW(14), .DW(24), .IDX(11), .BASE(PMSRAM_BASE)) u_pmc (
    .clk(clk), .por(por), .req(pmc_req), .we(pmc_we), .addr(pmc_addr), .wdata(pmc_wdata),
    .ready(pmc_ready), .rdata(pmc_rdata),
    .m_req(pmc_mreq), .m_we(pmc_mwe), .m_addr(pmc_maddr), .m_wdata(pmc_mwdata), .m_be(pmc_mbe),
    .m_ack(pmc_mack), .m_rvalid(pmc_mrvalid), .m_rdata(c_rdata), .misses(pmc_miss), .idle(pmc_idle)
  );

  // Engine-side DM cache client (driven by the DM servicer, exactly as before).
  logic        dmc_req, dmc_we; logic [13:0] dmc_addr; logic [15:0] dmc_wdata;
  logic        dmc_ready; logic [15:0] dmc_rdata;
  logic        dmc_mreq, dmc_mwe; logic [31:0] dmc_maddr; logic [63:0] dmc_mwdata; logic [7:0] dmc_mbe;
  logic        dmc_mack, dmc_mrvalid; logic [31:0] dmc_miss;
  // Cache-side port (arbitrated between the engine servicer and the SPORT1 autobuffer DAC-read).
  logic        cc_req, cc_we; logic [13:0] cc_addr; logic [15:0] cc_wdata;
  logic        cc_ready; logic [15:0] cc_rdata; logic cc_idle;
  // DM cache: direct-mapped u_dmc (MK4) or 4-way hashed u_dmc4w (Invasion, inv-buzz): same capacity, same M10K blocks, same
  // DDR layout. Both are instantiated so the MK4 hierarchy (u_dmc, used by the engine / board benches) is unchanged;
  // the unselected one has req tied low and no output used -> no fanout, removed by synthesis.
  localparam bit DM4W = INV_ROM && (DM_WAYS_INV == 4);
  logic        d1_ready, d1_mreq, d1_mwe, d1_idle; logic [15:0] d1_rdata; logic [31:0] d1_maddr, d1_miss;
  logic [63:0] d1_mwdata; logic [7:0] d1_mbe;
  logic        d2_ready, d2_mreq, d2_mwe, d2_idle; logic [15:0] d2_rdata; logic [31:0] d2_maddr, d2_miss;
  logic [63:0] d2_mwdata; logic [7:0] d2_mbe;
  dcs2_sram_cache #(.AW(14), .DW(16), .IDX(12), .BASE(DMSRAM_BASE)) u_dmc (
    .clk(clk), .por(por), .req(cc_req & ~DM4W), .we(cc_we), .addr(cc_addr), .wdata(cc_wdata),
    .ready(d1_ready), .rdata(d1_rdata),
    .m_req(d1_mreq), .m_we(d1_mwe), .m_addr(d1_maddr), .m_wdata(d1_mwdata), .m_be(d1_mbe),
    .m_ack(dmc_mack & ~DM4W), .m_rvalid(dmc_mrvalid & ~DM4W), .m_rdata(c_rdata), .misses(d1_miss), .idle(d1_idle)
  );
  dcs2_sram_cache_4w #(.AW(14), .DW(16), .IDX(12), .BASE(DMSRAM_BASE)) u_dmc4w (
    .clk(clk), .por(por), .req(cc_req & DM4W), .we(cc_we), .addr(cc_addr), .wdata(cc_wdata),
    .ready(d2_ready), .rdata(d2_rdata),
    .m_req(d2_mreq), .m_we(d2_mwe), .m_addr(d2_maddr), .m_wdata(d2_mwdata), .m_be(d2_mbe),
    .m_ack(dmc_mack & DM4W), .m_rvalid(dmc_mrvalid & DM4W), .m_rdata(c_rdata), .misses(d2_miss), .idle(d2_idle)
  );
  assign cc_ready  = DM4W ? d2_ready  : d1_ready;   assign cc_rdata  = DM4W ? d2_rdata  : d1_rdata;
  assign dmc_mreq  = DM4W ? d2_mreq   : d1_mreq;    assign dmc_mwe   = DM4W ? d2_mwe    : d1_mwe;
  assign dmc_maddr = DM4W ? d2_maddr  : d1_maddr;   assign dmc_mwdata= DM4W ? d2_mwdata : d1_mwdata;
  assign dmc_mbe   = DM4W ? d2_mbe    : d1_mbe;     assign dmc_miss  = DM4W ? d2_miss   : d1_miss;
  assign cc_idle   = DM4W ? d2_idle   : d1_idle;
  assign cache_misses = pmc_miss + dmc_miss;
  assign pm_oow = pm_oow_r;                  // out-of-window fetch count (see PM servicer)

  // ===== DM-cache arbiter: engine servicer (priority) vs SPORT1 autobuffer DAC-read =====
  // The engine's dmc_req is a 1-cycle launch pulse (single-master assumption). To share the cache
  // with the low-rate DAC block-read WITHOUT losing that pulse, HOLD the engine request until the
  // cache accepts it, give the engine strict priority, and route ready/rdata by a busy-owner latch.
  // BOOT-INERT: during boot the autobuffer is disabled+unarmed -> dac_rd=0 -> own_dac=0 ->
  // dmc_ready=cc_ready, cc_req=engine, ZERO added latency = byte-identical to the pre-arbiter path
  // (gate-2 unaffected). dac_rd/dac_addr/dac_ready/dac_rdata are the autobuffer's DAC-read port.
  logic        dac_rd; logic [13:0] dac_addr; logic dac_ready_w; logic [15:0] dac_rdata_w;
  // dcs2-audio fix: dac_addr is a DSP DATA-SPACE address (dcs_irq reads m_data->read_word(reg), dcs.cpp:1974), but the
  // cache is indexed by SRAM WORD (m_sram[]). The engine servicer translates with dm_sram_idx(SM_BK, addr) (below,
  // dcs.cpp:1001-1013); the DAC read did not, so DM 0x3400 read SRAM word 0x3400 (bank-1 alt RAM) instead of 0x2C00.
  logic [13:0] dac_si;          // = dm_sram_idx(SM_BK, dac_addr), assigned after the function declarations
  logic        esd_hold, cc_busy, cc_own_dac;
  wire         eng_req    = dmc_req | esd_hold;
  // cc_idle: the cache may be draining a POSTED write-back after it already returned ready -> hold.
  wire         accept_eng = eng_req & ~cc_busy & cc_idle;
  wire         accept_dac = dac_rd  & ~cc_busy & cc_idle & ~eng_req;      // engine strict priority
  assign       cc_req   = accept_eng | accept_dac;
  assign       cc_we    = accept_eng ? dmc_we   : 1'b0;         // DAC path is read-only
  assign       cc_addr  = accept_eng ? dmc_addr : dac_si;
  assign       cc_wdata = dmc_wdata;
  assign       dmc_ready  = cc_ready & ~cc_own_dac;
  assign       dmc_rdata  = cc_rdata;
  assign       dac_ready_w = cc_ready &  cc_own_dac;
  assign       dac_rdata_w = cc_rdata;
  always_ff @(posedge clk) begin
    if (por || rst) begin esd_hold<=1'b0; cc_busy<=1'b0; cc_own_dac<=1'b0; end
    else begin
      if      (dmc_req & ~accept_eng) esd_hold <= 1'b1;         // capture a pulse that could not go now
      else if (accept_eng)            esd_hold <= 1'b0;
      if      (cc_req & ~cc_busy) begin cc_busy <= 1'b1; cc_own_dac <= accept_dac; end
      else if (cc_ready)              cc_busy <= 1'b0;
    end
  end

  // ================= DDR generic-port arbiter (boot > rompage > pmcache > dmcache) =================
  // boot + rompage issue transactions through boot_* signals below.
  logic        bt_req, bt_we; logic [31:0] bt_addr; logic [63:0] bt_wdata; logic bt_ack, bt_rvalid;
  // priority select
  wire sel_bt  = bt_req;
  wire sel_pmc = !bt_req && pmc_mreq;
  wire sel_dmc = !bt_req && !pmc_mreq && dmc_mreq;
  always_comb begin
    c_req=1'b0; c_we=1'b0; c_addr=32'd0; c_wdata=64'd0; c_be=8'hff;
    if (sel_bt)      begin c_req=bt_req;  c_we=bt_we;  c_addr=bt_addr;  c_wdata=bt_wdata;  end
    else if (sel_pmc)begin c_req=pmc_mreq;c_we=pmc_mwe;c_addr=pmc_maddr;c_wdata=pmc_mwdata;c_be=pmc_mbe; end  // packed-line
    else if (sel_dmc)begin c_req=dmc_mreq;c_we=dmc_mwe;c_addr=dmc_maddr;c_wdata=dmc_mwdata;c_be=dmc_mbe; end  // caches: valid-word BE
  end
  // The agent's c_ack is REGISTERED one+ cycles after the command is latched (S_IDLE->S_ADDR), and its
  // c_rvalid later still. By c_ack time a higher-priority client (typically bt_req rising while a PMC
  // write-back finishes) may have raised its req, moving sel_*. Deriving the ack strobes from live
  // sel_* then mis-routes c_ack to the wrong client -- e.g. bt_ack fires on a PMC write's c_ack,
  // advancing the ROM-window fill FSM with no read outstanding (rd_owner stays 0 because c_we=1) ->
  // permanent PF_RDW deadlock. Fix: latch the OWNER when the agent latches the command (c_can_accept &
  // c_req) and route both c_ack and c_rvalid through it (the analog of the existing rd_owner latch).
  wire c_accept = c_can_accept & c_req;   // agent latches this cycle's mux command
  logic [1:0] cmd_owner;  // owner of the command currently in flight in the agent
  logic       cmd_we;     // direction of that command (latched with the owner)
  always_ff @(posedge clk) begin
    if (por) begin cmd_owner<=2'd0; cmd_we<=1'b0; end
    else if (c_accept) begin cmd_owner <= sel_bt?2'd1 : sel_pmc?2'd2 : sel_dmc?2'd3 : 2'd0; cmd_we <= c_we; end
  end
  assign bt_ack     = (cmd_owner==2'd1) & c_ack;
  assign pmc_mack   = (cmd_owner==2'd2) & c_ack;
  assign dmc_mack   = (cmd_owner==2'd3) & c_ack;
  // A read's response (c_rvalid) arrives AFTER c_ack; route it to the latched command owner.
  logic [1:0] rd_owner;   // 0 none, 1 bt, 2 pmc, 3 dmc
  always_ff @(posedge clk) begin
    if (por) rd_owner<=2'd0;
    // ckpt4o_fix: use the LATCHED direction. The live c_we belongs to whatever client the mux shows at
    // c_ack time (e.g. a PMC write-back raised while a DMC fill READ is in flight -> c_we=1) -> rd_owner
    // stayed 0, the read's c_rvalid was routed to nobody, and the DMC waited in S_FILLW forever.
    else if (c_ack && !cmd_we) rd_owner <= cmd_owner;
    else if (c_rvalid) rd_owner<=2'd0;
  end
  assign bt_rvalid  = (rd_owner==2'd1) & c_rvalid;
  assign pmc_mrvalid= (rd_owner==2'd2) & c_rvalid;
  assign dmc_mrvalid= (rd_owner==2'd3) & c_rvalid;

  // ================= boot FSM (dcs.cpp:476-524): copy ROM page -> internal PM =================
  // On rst-deassert (game start) with the ROM loaded, read ROM store words EPM_PG*0x1000.. and pack
  // the low bytes into internal PM words; hold the engine in reset until done.
  localparam BOOT_IDLE=3'd0, BOOT_RD=3'd1, BOOT_RDW=3'd2, BOOT_WR=3'd3, BOOT_DONE=3'd4;
  logic [2:0]  boot_st;
  logic [12:0] boot_i;          // PM word index (0..pagelen-1)
  logic [8:0]  boot_len;        // pagelen words (<=2048; (buf3+1)*8)
  logic [1:0]  boot_lane;       // which of 4 ROM words within the line
  logic [7:0]  boot_b0, boot_b1, boot_b2, boot_b3;
  logic        boot_have_len;
  logic        rst_q;

  // ================= memory servicer state =================
  logic        pm_busy, dm_busy;
  logic        boot_pm_we; logic [8:0] boot_pm_addr; logic [23:0] boot_pm_data;  // boot -> PM write (single writer = PM block)
  logic [15:0] sdrc_q_reg;

  // --- combinational DM decode helpers (dcs2_board._sram_dm_index) ---
  function automatic logic dm_is_sram(input logic bk, input logic [13:0] a);
    logic r; r=1'b0;
    if (bk==1'b0) begin
      if (a>=14'h0800 && a<=14'h37ff) r=1'b1;
    end else begin
      if (a>=14'h1800 && a<=14'h37ff) r=1'b1;   // 0x0800-0x17ff unmapped in bank1
    end
    dm_is_sram=r;
  endfunction
  function automatic logic [13:0] dm_sram_idx(input logic bk, input logic [13:0] a);
    logic [13:0] si; si=14'd0;
    if (bk==1'b0) begin
      if      (a<=14'h17ff) si=14'h0000 + (a-14'h0800);
      else if (a<=14'h27ff) si=14'h1000 + (a-14'h1800);
      else                  si=14'h2000 + (a-14'h2800);
    end else begin
      if      (a<=14'h27ff) si=14'h3000 + (a-14'h1800);
      else                  si=14'h2000 + (a-14'h2800);
    end
    dm_sram_idx=si;
  endfunction

  wire dm_sram_hit = SM_EN && dm_is_sram(SM_BK, e_dm_addr);
  wire [13:0] dm_si = dm_sram_idx(SM_BK, e_dm_addr);
  // DAC-read: the same data-space -> SRAM-word map as the engine. ASSUMPTION (MAME-unreachable on MK4, not modelled):
  // the autobuffer lies in DM SRAM (MK4: I7 base 0x3400, L7 0x3C0 -> 0x3400-0x37BF, SRAM in both banks); a buffer in
  // the ROM window, IRAM (0x3800-0x39FF) or unmapped space would still read the cache here.
  assign dac_si = dm_sram_idx(SM_BK, dac_addr);
  wire dm_rom_hit  = rw_en && (e_dm_addr>=rw_base) && (e_dm_addr < (rw_base+rw_len));
  wire dm_sdrc_hit = (e_dm_addr>=14'h0480 && e_dm_addr<=14'h0483);
  wire dm_mbx_hit  = (e_dm_addr>=14'h0400 && e_dm_addr<=14'h0407);
  wire dm_iram_hit = (e_dm_addr>=14'h3800 && e_dm_addr<=14'h39ff);
  wire dm_ctl_hit  = (e_dm_addr>=14'h3fe0 && e_dm_addr<=14'h3fff);
  wire [13:0] dm_rom_off = e_dm_addr - rw_base;

  // PM decode
  wire pm_int_hit  = (e_pm_addr < 14'h0200);
  wire pm_tcm_hit  = SM_EN && (e_pm_addr[13:11]==3'b101);          // 0x2800-0x2FFF -> tightly-coupled M10K
  wire pm_sram_hit = SM_EN && (e_pm_addr>=14'h0800) && (e_pm_addr<=14'h3fff) && !pm_tcm_hit; // pmc = rest

  // mailbox DSP-side
  logic        mbx_acc; logic [2:0] mbx_off; logic [15:0] mbx_rdata; logic irq2_req; logic snd_reset;
  dcs2_mailbox #(.LATCH_STATUS(LATCH_STATUS)) u_mbx (
    .clk(clk), .rst(rst),
    .data_w(data_w), .wdata(wdata), .ack_w(ack_w), .data_r(data_r),
    .reset_w(reset_w), .reset_level(reset_level),
    .control(control), .data(data), .data2(data2),
    .input_empty(input_empty), .output_full(output_full),
    .dm_acc(mbx_acc), .dm_we(e_dm_wr), .dm_off(mbx_off), .dm_wdata(e_dm_wdata), .dm_rdata(mbx_rdata),
    .irq2_req(irq2_req), .snd_reset(snd_reset)
  );
  assign mbx_off = e_dm_addr[2:0];

  // Control-reg file (0x3fe0-0x3fff) written by the DM servicer (adsp_control mirror).
  reg [15:0] ctl_reg [0:31];

  // SPORT / DAC: dcs2_sport_dac drives the two DACs at 31.25 kHz (audio_ce) from a stereo FIFO fed by
  // the autobuffer block-read (deinterleaved L,R). FIFO deepened to hold a half-buffer (240 pairs).
  logic dac_smp_we; logic [15:0] dac_smp;      // one autobuffer word per DAC-read (interleaved L,R)
  logic sm_we_l, sm_we_r; logic [15:0] sm_l, sm_r; logic sm_phase;   // deinterleave: L then R
  always_ff @(posedge clk) begin
    sm_we_l<=1'b0; sm_we_r<=1'b0;
    if (rst) sm_phase<=1'b0;
    else if (dac_smp_we) begin
      if (!sm_phase) begin sm_l<=dac_smp; sm_we_l<=1'b1; sm_phase<=1'b1; end
      else           begin sm_r<=dac_smp; sm_we_r<=1'b1; sm_phase<=1'b0; end
    end
  end
  logic sport_irq_unused;
  dcs2_sport_dac #(.FIFO_AW(9)) u_dac (       // 512 stereo pairs: > one 240-pair half-buffer burst
    .clk(clk), .rst(rst),
    .smp_we_l(sm_we_l), .smp_l(sm_l), .smp_we_r(sm_we_r), .smp_r(sm_r),
    .audio_l(audio_l), .audio_r(audio_r), .audio_ce(audio_ce),
    .sport_irq(sport_irq_unused), .dac_underruns(dac_underruns)
  );

  // ================= CAL1/CAL2/CAL3: dcs2_autobuf (SPORT1 autobuffer + ADSP-2101 timer + IRQ mux) =====
  // Corrected block-advance autobuffer (I[7] += size/2 per half-buffer, SPORT1-TX only on wrap) +
  // faithful timer + IRQ latch/mux. Bit-exact vs MAME (bench/run_gates_sport.sh). The DAC-read reads
  // the DM SRAM through the arbiter above; audio words feed the deinterleaver -> u_dac.
  // AREA: DAG regs are MLAB in the engine; use the narrow side port instead of the all-8 e_dbg fan-out.
  wire timer_ena = ab_mstat_w[5];              // MSTAT bit5 = MSTAT_TIMER (2100ops.hxx:74)

  // ---- SPORT0 1 kHz timer (SPORT0_TIMER): every SYSCONTROL write re-arms it when bit 12 is set (first pulse 10 us later,
  // then every 1 ms: adjust(from_usec(10), 0, from_hz(1000))) and stops it when clear; a pulse is skipped when the DSP
  // read output_control within the last 5 DSP cycles (sport0_irq :2003-2009). Real time at 50 MHz, like the reg timer.
  logic sport0_rx_irq;
  generate if (SPORT0_TIMER) begin : g_s0
    logic s0_run; logic [15:0] s0_cnt; logic [2:0] s0_age;
    always_ff @(posedge clk)
      if (rst) begin s0_run <= 1'b0; s0_cnt <= '0; s0_age <= 3'd7; sport0_rx_irq <= 1'b0; end
      else begin
        sport0_rx_irq <= 1'b0;
        if (s0_oc_rd) s0_age <= 3'd0; else if (e_commit && s0_age != 3'd7) s0_age <= s0_age + 3'd1;
        if (s0_ctl_we) begin s0_run <= s0_ctl_d[12]; s0_cnt <= 16'd499; end        // 10 us = 500 clocks
        else if (s0_run) begin
          if (s0_cnt == 16'd0) begin
            s0_cnt <= 16'd49999;                                                      // 1 ms = 50,000 clocks
            if (s0_age > 3'd5) sport0_rx_irq <= 1'b1;                                 // diff > 5 cycles
          end else s0_cnt <= s0_cnt - 16'd1;
        end
      end
  end else begin : g_no_s0
    assign sport0_rx_irq = 1'b0;
  end endgenerate

  dcs2_autobuf u_autobuf (
    .clk(clk), .rst(rst), .irq_clr(snd_reset || sysctl_wr9),   // ADSP reset: host hold / SYSCONTROL bit-9 pulse
    .audio_ce(audio_ce), .tick_force(1'b0), .e_commit(e_commit),
    .syscontrol(ctl_reg[5'h1f]), .s1_autobuf(ctl_reg[5'h0f]), .s1_control(ctl_reg[5'h12]),
    .tscale(ctl_reg[5'h1b]), .tcount(ctl_reg[5'h1c]), .tperiod(ctl_reg[5'h1d]), .timer_ena(timer_ena),
    .ab_ireg(ab_ireg_w), .ab_mreg(ab_mreg_w), .ab_lreg(ab_lreg_w),
    .i_sel(ab_i_w), .m_sel(ab_m_w), .l_sel(ab_l_w),
    .tx1_we(e_tx1_we), .arm_seed_we(1'b0), .arm_seed_base(14'd0),
    .i7_we(ab_i7_we), .i7_wd(ab_i7_wd),
    .dac_rd(dac_rd), .dac_addr(dac_addr), .dac_rdata(dac_rdata_w), .dac_ready(dac_ready_w),
    .dac_smp_we(dac_smp_we), .dac_smp(dac_smp),
    .sport_tx_irq(sport_tx_irq), .timer_irq(timer_irq),
    .irq2_req(irq2_req), .e_icntl2(e_icntl2), .e_imask(e_imask),   // IRQ2 edge/level + mask-skip in the mux
    .sport0_rx_irq(sport0_rx_irq), .ifc_we(e_ifc_we), .ifc_val(e_ifc_val),
    .e_irq_ack(e_irq_ack), .e_irq_ack_indx(e_irq_ack_indx),
    .e_irq_take(e_irq_take), .e_irq_indx(e_irq_indx), .tick_stb()
  );

  // ================= PM servicer. pm_int is M10K (1-cycle read latency): assert ready only AFTER the
  // launched read settles. The engine holds pm_rd high across a memory instruction's fetch->data-read
  // (they differ only by ADDRESS), so gate a NEW access on (address changed since last served) and
  // reset that guard whenever the engine is idle -- this stops the fetch's ready bleeding into the
  // S_MEM data read (which returned the fetched opcode as stale data). Read address is combinational.
  logic pm_int_pend; logic [13:0] pm_sa; logic pm_sv;   // served address + valid
  logic pmc_wpend;                                      // a POSTED PM-SRAM write is still in the cache
  logic [31:0] pm_oow_r;                                // sticky: fetches OUTSIDE the TCM window (pmc path)
  always_ff @(posedge clk) begin
    e_pm_ready <= 1'b0; pmi_we <= 1'b0; tcm_we <= 1'b0;
    if (boot_pm_we) begin pmi_we<=1'b1; pmi_wa<=boot_pm_addr; pmi_wd<=boot_pm_data; end
    if (por || rst) begin pm_busy<=1'b0; pmc_req<=1'b0; pm_int_pend<=1'b0; pm_sv<=1'b0; pm_oow_r<=32'd0; pmc_wpend<=1'b0; end
    else begin
      pmc_req <= 1'b0;
      if (pmc_ready && pmc_wpend) pmc_wpend <= 1'b0;             // the posted write completed in the cache
      if (!(e_pm_rd || e_pm_wr)) pm_sv <= 1'b0;                 // idle -> re-arm (allow re-access same addr)
      if ((e_pm_rd || e_pm_wr) && !pm_busy && !(pm_sv && e_pm_addr==pm_sa)) begin
        if (pm_tcm_hit) begin
          // tightly-coupled window 0x2800-0x2FFF: direct M10K, 1-cycle (tcm_ra comb -> tcm_q next clk).
          // Coherence: a PM write into the window updates the TCM; a window PM-data read reads tcm_q.
          if (e_pm_wr) begin tcm_we<=1'b1; tcm_wa<=e_pm_addr[10:0]; tcm_wd<=e_pm_wdata; end
          e_pm_ready<=1'b1; pm_sa<=e_pm_addr; pm_sv<=1'b1;
        end else if (pm_int_hit) begin
          if (e_pm_wr && !boot_pm_we) begin pmi_we<=1'b1; pmi_wa<=e_pm_addr[8:0]; pmi_wd<=e_pm_wdata; end
          // 1-cycle hit path: pmi_ra=e_pm_addr (comb) launched the M10K read THIS cycle -> pm_int_q valid
          // NEXT cycle; assert ready NEXT cycle (was pm_busy+pm_int_pend -> ready 1 clk later).
          e_pm_ready<=1'b1; pm_sa<=e_pm_addr; pm_sv<=1'b1;
        end else if (pm_sram_hit) begin
          // POSTED writes (real-time pacing): a PM-SRAM write is handed to the cache and acked to the engine
          // at once (MAME: 1 cycle). In-order: the next PM-SRAM access waits until that write completed
          // (pmc_wpend) and the cache is idle (a posted DDR write-back may be draining).
          if (pmc_idle && !pmc_wpend && !pmc_req) begin
            if (e_pm_rd) pm_oow_r <= pm_oow_r + 32'd1;          // sticky telemetry: code ran OUTSIDE the window
            pmc_req<=1'b1; pmc_we<=e_pm_wr; pmc_addr<=e_pm_addr; pmc_wdata<=e_pm_wdata;
            if (e_pm_wr) begin pmc_wpend<=1'b1; e_pm_ready<=1'b1; pm_sa<=e_pm_addr; pm_sv<=1'b1; end
            else pm_busy<=1'b1;
          end
        end else begin
          e_pm_ready <= 1'b1; pm_sa<=e_pm_addr; pm_sv<=1'b1;    // unmapped -> 0xffffff
        end
      end else if (pm_busy) begin
        if (pm_int_pend) begin pm_int_pend<=1'b0; pm_busy<=1'b0; e_pm_ready<=1'b1; pm_sa<=e_pm_addr; pm_sv<=1'b1; end
        else if (pmc_ready) begin pm_busy<=1'b0; e_pm_ready<=1'b1; pm_sa<=e_pm_addr; pm_sv<=1'b1; end
      end
    end
  end
  assign e_pm_rdata = pm_tcm_hit ? tcm_q : (pm_int_hit ? pm_int_q : (pm_sram_hit ? pmc_rdata : 24'hffffff));

  // ================= DM servicer =================
  // ROM-window read-while-fill: the fill writes romwin in ascending word order; a read of a word of
  // the page being filled may be served as soon as that word is in the M10K (offset < pf_wr_n), instead of
  // waiting for the whole page (1024 words ~1,060 clk/page). The checksum (PM 2894-289C) reads the page
  // sequentially from word 0 at <1 word / 14 clk, so after the first beat it never waits. MAME serves the
  // bank with zero wait (install_read_bank), so this only removes a fabric-only stall; data identical.
  // (slots: a valid slot holding EPM_PG, or the slot being filled with EPM_PG once the word has landed; the filling
  // slot is invalid until its fill completes, so the two never both match)
  wire rw_page_ok = rw_hit || ({romwin_pg, pf_sect} == {EPM_PG, rw_sect} && pf_filling &&
                    ((NPG > 1) ? (pf_wr_n > 11'(dm_rom_off[SWB-1:0])) : ({3'd0,pf_wr_n} > dm_rom_off)));
  logic [15:0] sdrc_q;                          // iram_q/romwin_q live in their RAM blocks above
  integer      ck;                              // ctl_reg reset loop
  logic        dm_iram_pend, dm_rom_pend;       // M10K 1-cycle read waits (pm_busy-gated, see PM note)
  logic [13:0] dm_sa; logic dm_sv;               // served address guard (see PM servicer note)
  logic        dm_wpend;                         // a POSTED DM-SRAM write is still in flight to the cache
  // SDRC read (dcs.cpp:1054-1160)
  always_comb begin
    case (e_dm_addr[1:0])
      2'd0: sdrc_q = sdrc0;
      2'd1: sdrc_q = sdrc1;
      2'd2: sdrc_q = sdrc2;
      default: begin
        case (SMODE)
          3'd0: sdrc_q = 16'h5a81; 3'd1: sdrc_q = 16'h5aa4;
          3'd2: sdrc_q = 16'h5a00 | ({7'd0, sdrc_seed[5:0], 1'b0} & 16'h007e);
          3'd3: sdrc_q = 16'h5ab9; 3'd4: sdrc_q = 16'h5a03; 3'd5: sdrc_q = 16'h5a69;
          3'd6: sdrc_q = 16'h5a20; default: sdrc_q = 16'h5aff;
        endcase
      end
    endcase
  end

  always_ff @(posedge clk) begin
    e_dm_ready <= 1'b0; mbx_acc <= 1'b0; iri_we<=1'b0; sysctl_wr9<=1'b0; s0_ctl_we<=1'b0; s0_oc_rd<=1'b0;
    if (por) begin
      dm_busy<=1'b0; dmc_req<=1'b0; dm_iram_pend<=1'b0; dm_rom_pend<=1'b0; dm_sv<=1'b0; dm_wpend<=1'b0;
      sdrc0<=16'd0; sdrc1<=16'd0; sdrc2<=16'd0; sdrc3<=16'd0; sdrc_seed<=8'd0;
      for (ck=0;ck<32;ck=ck+1) ctl_reg[ck]<=16'd0;
    end else if (rst || snd_reset) begin
      // dcs_reset (game reset OR host reset_w reboot): SDRC regs cleared (remap), control zero.
      // SRAM (DDR) persists.
      dm_busy<=1'b0; dmc_req<=1'b0; dm_iram_pend<=1'b0; dm_rom_pend<=1'b0; dm_sv<=1'b0; dm_wpend<=1'b0;
      sdrc0<=16'd0; sdrc1<=16'd0; sdrc2<=16'd0; sdrc3<=16'd0; sdrc_seed<=8'd0;
      for (ck=0;ck<32;ck=ck+1) ctl_reg[ck]<=16'd0;
    end else begin
      dmc_req<=1'b0;
      if (dmc_ready && dm_wpend) dm_wpend <= 1'b0;             // the posted write completed in the cache
      if (!(e_dm_rd || e_dm_wr)) dm_sv <= 1'b0;                 // idle -> re-arm
      if ((e_dm_rd || e_dm_wr) && !dm_busy && !(dm_sv && e_dm_addr==dm_sa)) begin
        if (dm_rom_hit) begin
          // ROM window read-only via page buffer; refill on EPM_PG change
          if (!rw_page_ok) begin
            dm_busy<=1'b1;                      // trigger a page (re)fill / wait for the word (below)
          end else begin
            e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1;   // 1-cycle hit: romwin_q valid next cycle
          end
        end else if (dm_sram_hit) begin
          // POSTED writes (see PM servicer): ack a DM-SRAM write at hand-off; the next DM-SRAM access waits
          // for it (dm_wpend) -- the DAC arbiter holds only ONE engine request (esd_hold / dmc_addr).
          if (!dm_wpend && !dmc_req) begin
            dmc_req<=1'b1; dmc_we<=e_dm_wr; dmc_addr<=dm_si; dmc_wdata<=e_dm_wdata;
            if (e_dm_wr) begin dm_wpend<=1'b1; e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1; end
            else dm_busy<=1'b1;
          end
        end else if (dm_sdrc_hit) begin
          if (e_dm_wr) begin
            case (e_dm_addr[1:0])
              2'd0: sdrc0<=e_dm_wdata; 2'd1: sdrc1<=e_dm_wdata; 2'd2: sdrc2<=e_dm_wdata;
              default: begin
                case (SMODE)
                  3'd1: sdrc_seed <= e_dm_wdata[7:0];
                  3'd3: sdrc_seed <= {sdrc_seed[6:0],1'b1};
                  3'd4: sdrc_seed <= sdrc_seed + {1'b0,sdrc_seed[7:1]};
                  3'd5: sdrc_seed <= sdrc_seed ^ {sdrc_seed[6:0],1'b1};
                  default: ;
                endcase
                sdrc3<=e_dm_wdata;
              end
            endcase
          end
          sdrc_q_reg <= sdrc_q; e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1;
        end else if (dm_mbx_hit) begin
          mbx_acc<=1'b1; e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1;
          if (!e_dm_wr && e_dm_addr == 14'h0402) s0_oc_rd<=1'b1;    // output_control_r (dcs.cpp:1666-1673)
        end else if (dm_iram_hit) begin
          if (e_dm_wr) begin iri_we<=1'b1; iri_wa<=e_dm_addr[8:0]; iri_wd<=e_dm_wdata; end
          e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1;   // 1-cycle hit path (iram_q valid next cycle)
        end else if (dm_ctl_hit) begin
          // adsp_control (0x3fe0-0x3fff) register file -> timer (CAL3) + SPORT autobuffer (CAL1).
          // SYSCONTROL(0x3fff) bit9 = BOOT FORCE (dcs.cpp:1872-1879): clear the reg + self-reboot pulse.
          if (e_dm_wr) begin
            if (e_dm_addr[4:0]==5'h1f && e_dm_wdata[9]) begin ctl_reg[5'h1f]<=16'd0; sysctl_wr9<=1'b1; end
            else ctl_reg[e_dm_addr[4:0]] <= e_dm_wdata;
            if (e_dm_addr[4:0]==5'h1f) begin s0_ctl_we<=1'b1; s0_ctl_d<=e_dm_wdata; end   // SPORT0 timer (dcs.cpp:1889)
          end
          e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1;
        end else begin
          e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1;   // unmapped -> 0xffff
        end
      end else if (dm_busy) begin
        if (dm_iram_pend) begin dm_iram_pend<=1'b0; dm_busy<=1'b0; e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1; end
        else if (dm_rom_pend) begin dm_rom_pend<=1'b0; dm_busy<=1'b0; e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1; end
        else if (dm_sram_hit) begin
          if (dmc_ready) begin dm_busy<=1'b0; e_dm_ready<=1'b1; dm_sa<=e_dm_addr; dm_sv<=1'b1; end
        end else if (dm_rom_hit) begin
          // page (re)fill runs in the ROM-window fill FSM below; when the page is ready, launch the
          // M10K read wait (dm_rom_pend), completing on the next cycle with romwin_q.
          if (rw_page_ok) begin dm_rom_pend<=1'b1; end
        end
      end
    end
  end
  assign e_dm_rdata =
      dm_rom_hit  ? romwin_q :
      dm_sram_hit ? dmc_rdata :
      dm_sdrc_hit ? sdrc_q_reg :
      dm_mbx_hit  ? mbx_rdata :
      dm_iram_hit ? iram_q : 16'hffff;

  // ================= CAL4: region-word -> compact-stream reconstruction (contract ROM MAP) =========
  // The loader stores the COMPACT 7 MiB stream byte-for-byte at ROM_BASE+s. The DSP reads ERASEFF
  // region WORDS: word w -> chip=w[22:21], byteInChip=w[20:0], populated iff chip>0 or byteInChip<
  // 0x100000; region word = 0xFF00|streambyte(chip,byteInChip) when populated else 0xFFFF.
  // Returns {populated, stream_byte_offset[23:0]}.
  function automatic [24:0] regw_map(input [22:0] w);
    logic [1:0] chip; logic [20:0] bic; logic pop; logic [23:0] base;
    chip=w[22:21]; bic=w[20:0];
    if (INV_ROM) begin
      // Invasion: four 2 MiB chips (LOAD16_BYTE at 0/4/8/C MiB), every region word populated; chip c's bytes start at
      // stream offset c * 2 MiB, so offset = {chip, byteInChip} (max 0x7FFFFF: ROM_BASE + 8 MiB = SRAM_BASE, no overlap)
      pop = 1'b1; base = {1'b0, chip, 21'd0};
    end else begin
      pop = (chip!=2'd0) || (~bic[20]);
      case(chip) 2'd0:base=24'h000000; 2'd1:base=24'h100000; 2'd2:base=24'h300000; default:base=24'h500000; endcase
    end
    regw_map = {pop, base + {3'd0,bic}};
  endfunction

  // ================= ROM-window page fill FSM (uses the boot/DDR path when idle) =================
  // Fills romwin[0..rw_len-1] with reconstructed region words for EPM_PG's page (1 DDR byte read per
  // word). Runs when a ROM access misses the page.
  localparam PF_IDLE=2'd0, PF_WAIT1=2'd1, PF_EXTRACT=2'd2;
  logic [1:0]  pf_st; logic [10:0] pf_i; logic pf_pop; logic [2:0] pf_lane;
  wire [RWA-1:0] rw_waddr = (NPG > 1) ? RWA'({pf_slot, pf_i[SWB-1:0]}) : RWA'(pf_i[SWB-1:0]);   // fill write address
  wire [10:0]    pf_len   = (NPG > 1) ? 11'(SW) : rw_len[10:0];                                // words per fill
  // recency update: slot s becomes the most recent (pg_ord[0])
  function automatic [NPG*PSW-1:0] ord_touch(input [NPG*PSW-1:0] o, input [PSW-1:0] s);
    logic seen; seen = 1'b0; ord_touch = o;
    for (int k = NPG-1; k > 0; k--) begin
      if (o[k*PSW +: PSW] == s) seen = 1'b1;
      if (seen) ord_touch[k*PSW +: PSW] = o[(k-1)*PSW +: PSW];
    end
    ord_touch[0 +: PSW] = s;
  endfunction
  // ---- pipelined page fill: a consecutive-beat read STREAM from the agent (fl_*) feeding a small
  // beat FIFO the word-extractor drains. Reader runs FDEPTH ahead of extraction -> hides DDR latency.
  logic        fl_req; logic [31:0] fl_start;      // to agent
  wire         fl_rvalid_w; wire [63:0] fl_rdata_w; wire fl_busy_w; // from agent (beat + fill-active status)
  logic [63:0] fbuf [0:7]; logic [2:0] fwr, frd; logic [3:0] fcnt;  // beat FIFO (>= FDEPTH+2)
  wire         fifo_empty = (fcnt==4'd0);
  // ---- DDR-beat cache: CAL4 packs 8 consecutive region-word BYTES into one 64-bit DDR beat (lanes
  // 0..7). Cache the beat so 8 consecutive words = ONE read + 7 no-read extracts (bit-identical romwin,
  // 8x fewer reads). Cuts the boot page-checksum fill ~49k->~5.5k clk/page.
  logic [63:0] pf_word;              // latched c_rdata of the beat currently cached
  logic [20:0] pf_addr_cur;          // DDR word address [23:3] of the current word (== cached beat)
  // page base region-word = EPM_PG*pagesize (mod 2^23); map the first word and the next word.
  wire [24:0] pg_base_w  = (rw_1k ? {2'd0, EPM_PG, 10'd0} : {EPM_PG, 12'd0}) + 25'(rw_sect) * 25'(SW);   // + the sector
  wire [24:0] pf_map_base = regw_map(pg_base_w[22:0]);
  // the words AFTER the first follow the page being FILLED (romwin_pg, latched at the fill start), never the live
  // EPM_PG: a fill serves reads as soon as their word lands, so the DSP can move DM($0482) to another page while the
  // fill still streams (Invasion's sound-command reader flips page 11 <-> 0 around every byte; MK4 never did) -- with
  // the live page the extractor mapped later words to the NEW page, took a beat boundary where there was none and
  // popped a beat early: the rest of the page landed one beat (8 words) ahead.
  wire [24:0] pg_fill_w  = (rw_1k ? {2'd0, romwin_pg, 10'd0} : {romwin_pg, 12'd0}) + 25'(pf_sect) * 25'(SW);
  wire [22:0] pf_w_next  = pg_fill_w[22:0] + {12'd0, pf_i} + 23'd1;
  wire [24:0] pf_map_next = regw_map(pf_w_next);
  wire        pf_same_beat = (pf_map_next[23:3] == pf_addr_cur);   // next word is in the cached beat
  // dcs_boot (dcs.cpp:499-522): boot image = region words at (EPM_PG * 0x1000). For chip 0 (EPM_PG <
  // 0x200) the region word == stream byte, so the compact-stream byte base is EPM_PG*0x1000.
  wire [24:0] boot_base = {EPM_PG, 12'd0};
  // (sysctl_wr9 declared above, with eng_rst)      // SYSCONTROL (0x3fff) write with bit9 (BOOT FORCE) committed this cycle
  logic needs_reboot;    // latched self-reboot request (from bit9); boot re-runs from EPM_PG
  logic warm_reset;      // high across the self-reboot's eng_rst window: engine preserves data regs
  logic recopy_fin;      // 1-cyc pulse at re-copy BOOT_WR->DONE; ends warm window in lock-step w/ eng_rst

  // ================= boot + ROM-window share the boot_* DDR client =================
  // Boot has priority; when boot is done, the page-fill uses the same client.
  always_ff @(posedge clk) begin
    if (por) begin
      boot_st<=BOOT_IDLE; boot_i<=13'd0; boot_len<=9'd0; boot_lane<=2'd0; boot_have_len<=1'b0;
      bt_req<=1'b0; bt_we<=1'b0; bt_addr<=32'd0; bt_wdata<=64'd0; rst_q<=1'b1; needs_reboot<=1'b0; warm_reset<=1'b0; recopy_fin<=1'b0;
      eng_rst<=1'b1; pf_st<=PF_IDLE; pf_i<=11'd0; pf_lane<=2'd0; pg_val<='0; pf_slot<='0; for (int k = 0; k < NPG; k++) pg_ord[k*PSW +: PSW] <= PSW'(k); pf_filling<=1'b0; pf_wr_n<=11'd0; // note: romwin_valid also in dm block; keep single writer -> move here
      fl_req<=1'b0; fl_start<=32'd0; fwr<=3'd0; frd<=3'd0; fcnt<=4'd0;
    end else begin
      rst_q <= rst;
      bt_req <= bt_req & ~bt_ack;
      boot_pm_we <= 1'b0; rwn_we <= 1'b0;      // pulse defaults (single write port owners)
      if (rwn_we) pf_wr_n <= 11'(rwn_wa[SWB-1:0]) + 11'd1;  // word rwn_wa lands in the M10K at THIS edge
      // slot recency: a ROM-window access that hits a slot makes it the most recent (the fill start touches its victim)
      if (NPG > 1 && dm_rom_hit && rw_hit && (e_dm_rd || e_dm_wr)) pg_ord <= ord_touch(pg_ord, rw_hslot);
      if (sysctl_wr9) needs_reboot <= 1'b1;    // latch the firmware self-reboot (SYSCONTROL bit9)
      // warm_reset spans the self-reboot's eng_rst window (sysctl_wr9 -> re-boot BOOT_DONE) so the
      // engine's reset PRESERVES the data regs / DAG / CNTR (ADSP device_reset). Cold / host reset = 0.
      recopy_fin <= 1'b0;                          // pulse default
      if (rst || snd_reset) warm_reset <= 1'b0;
      else if (sysctl_wr9)  warm_reset <= 1'b1;    // set on the self-reboot
      else if (recopy_fin)  warm_reset <= 1'b0;    // clear 1 cyc after re-copy DONE = with eng_rst deassert
      // engine held in reset during boot, a pending self-reboot, and while the mailbox halts.
      // sysctl_wr9 is included so the reset lands the cycle after the SYSCONTROL write commits
      // (MAME: 0x54 -> 0x0000 with no intervening instruction).
      eng_rst <= (boot_st!=BOOT_DONE) || snd_reset || rst || needs_reboot || sysctl_wr9;

      // ---- boot sequence: game reset / host reset_w (dcs_reset: SDRC reset -> page 0) OR firmware
      // self-reboot via SYSCONTROL bit9 (dcs.cpp:1872-1879: CPU reset + dcs_boot from the CURRENT
      // EPM page, SDRC NOT reset). Both copy the page at EPM_PG*0x1000.
      if (rst || snd_reset || needs_reboot) begin
        boot_st<=BOOT_IDLE; boot_i<=13'd0; boot_have_len<=1'b0; pg_val<='0; needs_reboot<=1'b0; pf_filling<=1'b0;
      end
      else case (boot_st)
        BOOT_IDLE: if (rom_loaded) begin
          // PM word boot_i uses stream bytes (EPM_PG*0x1000 + boot_i*4),+1,+2 (consecutive, chip 0).
          bt_req<=1'b1; bt_we<=1'b0;
          bt_addr<=ROM_BASE + {7'd0, boot_base} + {17'd0, boot_i[12:1], 3'b000};
          boot_st<=BOOT_RD;
        end
        BOOT_RD: if (bt_ack) boot_st<=BOOT_RDW;
        BOOT_RDW: if (bt_rvalid) begin
          // byte lane j = (boot_i*4)&7 = boot_i[0]*4; b0..b2 = 3 consecutive stream bytes at j,j+1,j+2
          if (boot_i[0]) begin boot_b0<=c_rdata[39:32]; boot_b1<=c_rdata[47:40]; boot_b2<=c_rdata[55:48]; end
          else          begin boot_b0<=c_rdata[7:0];   boot_b1<=c_rdata[15:8];  boot_b2<=c_rdata[23:16]; end
          if (!boot_have_len) begin boot_len<=c_rdata[31:24]+9'd1; boot_have_len<=1'b1; end // buf[3]=stream byte 3
          boot_st<=BOOT_WR;
        end
        BOOT_WR: begin
          boot_pm_we<=1'b1; boot_pm_addr<=boot_i[8:0]; boot_pm_data<={boot_b0, boot_b1, boot_b2};
          if ((boot_i+1) >= {4'd0, boot_len, 3'b000}) begin boot_st<=BOOT_DONE; recopy_fin<=1'b1; end  // re-copy done; warm window ends 1 cyc later (with eng_rst)
          else begin boot_i<=boot_i+13'd1; boot_st<=BOOT_IDLE; end
        end
        BOOT_DONE: begin : bd_arm
          // ---- ROM-window PIPELINED page fill: the agent (fl_*) streams consecutive beats into a FIFO;
          // the extractor drains one word/clk (8 words per beat), popping the next beat when it changes.
          logic pop; logic flush; pop = 1'b0; flush = 1'b0;
          case (pf_st)
            PF_IDLE: if (dm_rom_hit && !rw_hit && !fl_busy_w) begin
              pf_i<=11'd0; romwin_pg<=EPM_PG; pf_slot<=pf_victim; pg_val[pf_victim]<=1'b0; pg_tag[pf_victim]<={EPM_PG, rw_sect}; pf_sect<=rw_sect; if (NPG > 1) pg_ord<=ord_touch(pg_ord, pf_victim); pf_filling<=1'b1; pf_wr_n<=11'd0; // clear during refill: else a pending
              // ROM read (line ~513: romwin_valid && romwin_pg==EPM_PG) fires on the STALE page the cycle
              // romwin_pg flips to EPM_PG, before the new page lands (RAW hazard at the copy-loop page
              // boundary: 0x00B1 DM($0482)=EPM_PG++ then 0x00B3 SI=DM(0) read of the new page).
              pf_pop<=pf_map_base[24]; pf_lane<=pf_map_base[2:0];      // CAL4: reconstruct word 0
              pf_addr_cur<=pf_map_base[23:3];
              fl_start<=ROM_BASE + {pf_map_base[23:3], 3'b000};        // first beat; agent auto-increments
              fl_req<=1'b1; flush=1'b1;                                // start the stream; flush stale beats
              pf_st<=PF_WAIT1;
            end
            PF_WAIT1: if (fcnt!=4'd0) begin                            // first beat has arrived
              pf_word<=fbuf[frd]; pop=1'b1; pf_st<=PF_EXTRACT;
            end
            PF_EXTRACT: begin
              // invariant: pf_word holds pf_addr_cur's beat, valid for word pf_i.
              if (pf_i >= (pf_len-11'd1)) begin                        // last word: extract, finish
                rwn_we<=1'b1; rwn_wa<=rw_waddr;
                rwn_wd<= {pf_pop, pf_word[{2'd0,pf_lane}*8 +: 8]};
                pg_val[pf_slot]<=1'b1; fl_req<=1'b0; pf_st<=PF_IDLE; pf_filling<=1'b0;
              end else if (pf_same_beat) begin                         // next word in the same cached beat
                rwn_we<=1'b1; rwn_wa<=rw_waddr;
                rwn_wd<= {pf_pop, pf_word[{2'd0,pf_lane}*8 +: 8]};
                pf_i<=pf_i+11'd1;
                pf_pop<=pf_map_next[24]; pf_lane<=pf_map_next[2:0]; pf_addr_cur<=pf_map_next[23:3];
              end else if (fcnt!=4'd0) begin                           // next word is a new beat, available
                rwn_we<=1'b1; rwn_wa<=rw_waddr;
                rwn_wd<= {pf_pop, pf_word[{2'd0,pf_lane}*8 +: 8]};
                pf_word<=fbuf[frd]; pop=1'b1;                          // pop pf_i+1's beat
                pf_i<=pf_i+11'd1;
                pf_pop<=pf_map_next[24]; pf_lane<=pf_map_next[2:0]; pf_addr_cur<=pf_map_next[23:3];
              end
              // else: next beat not yet in the FIFO (reader behind) -> stall, retry next cycle.
            end
            default: pf_st<=PF_IDLE;
          endcase
          // ---- beat FIFO bookkeeping (push from the agent, pop from the extractor) ----
          if (flush) begin fwr<=3'd0; frd<=3'd0; fcnt<=4'd0; end       // fill start: discard stale beats
          else begin
            if (pop) frd<=frd+3'd1;
            if (fl_rvalid_w) begin fbuf[fwr]<=fl_rdata_w; fwr<=fwr+3'd1; end
            fcnt <= fcnt + (fl_rvalid_w?4'd1:4'd0) - (pop?4'd1:4'd0);
          end
        end
        default: boot_st<=BOOT_DONE;
      endcase
    end
  end
endmodule
`default_nettype wire
