// dcs2_sram_cache.sv -- direct-mapped, write-back, write-allocate cache over the DDR-backed SRAM.
// Sized to hold the MEASURED hot set on-chip so steady play never misses (PLAN-DCS2-FABRIC.md: code
// 0x2800-0x2FFF ~1.5K words, data ~4.3K words). The firmware RAM-tests / clears the whole SRAM at boot
// -> those sweeps stream through DDR.
//
// 2026-09-24 (real-time pacing, ckpt4o_fix): a line is now ONE FULL 64-bit DDR beat holding WPL words
// (DM 16-bit: 4 words in 16-bit lanes; PM 24-bit: 2 words in 32-bit lanes, low 24 bits), instead of one
// word per beat. Same word capacity (1<<IDX words) and the SAME word->slot mapping (slot = addr[IDX-1:0]),
// so the steady-state hit set is unchanged; the boot sweeps now cost ONE DDR op per WPL words.
//   * per-word valid bits: a WRITE miss allocates without a fill (only the written word becomes valid);
//     a READ of an invalid word in a tag-matching line fills and MERGES (valid words are kept).
//   * dirty write-back uses the DDR byte enables (m_be) of the VALID words only, so never-filled words
//     cannot clobber DDR. The write-back of a WRITE miss is POSTED (ready returns at allocation; the
//     cache reports !idle until the agent accepts the write, so no request races it).
//   Measured motivation (tb_evt PH accounting, paced): boot sweeps = the whole 0.1 s residual lag.
//
// AREA: data line and metadata are M10K using the Quartus-17 inferable template EXACTLY -- ONE write
// port per array, a REGISTERED read in the SAME clocked block, NO reset on the array,
// `ramstyle "M10K, no_rw_check"`. A power-on clear FSM walks the index writing valid=0 through the single
// write port. The data array is WPL*DW wide (DM 1024x64, PM 1024x48): same bits as before.
`default_nettype none
module dcs2_sram_cache #(
  parameter int AW  = 14,        // SRAM word-address width (this view)
  parameter int DW  = 16,        // data width (DM=16, PM=24)
  parameter int IDX = 12,        // WORD-slot index bits => (1<<IDX) words of capacity
  parameter [31:0] BASE = 32'h3180_0000
) (
  input  wire            clk,
  input  wire            por,
  input  wire            req,
  input  wire            we,
  input  wire [AW-1:0]   addr,
  input  wire [DW-1:0]   wdata,
  output reg             ready,
  output reg  [DW-1:0]   rdata,
  output reg             m_req, m_we,
  output reg  [31:0]     m_addr,
  output reg  [63:0]     m_wdata,
  output reg  [7:0]      m_be,       // DDR byte enables (writes); 8'hff on reads
  input  wire            m_ack,
  input  wire            m_rvalid,
  input  wire [63:0]     m_rdata,
  output reg  [31:0]     misses,
  output wire            idle        // may take a new req (not while a posted write-back is in flight)
);
  localparam int LW    = (DW <= 16) ? 2 : 1;   // log2 words per 64-bit line
  localparam int WPL   = (1 << LW);
  localparam int LANE  = 64 / WPL;             // DDR lane width per word (16 or 32 bits)
  localparam int LBYTE = LANE / 8;             // byte enables per word
  localparam int LIDX  = IDX - LW;             // line index bits
  localparam int LINES = (1 << LIDX);
  localparam int TW    = AW - IDX;             // tag bits (same as the one-word-line cache)
  localparam int CW    = WPL * DW;             // cache line width (compact: 64 DM / 48 PM)
  localparam int MW    = 2 + WPL + TW;         // {valid, dirty, wv[WPL], tag}

  (* ramstyle = "M10K, no_rw_check" *) reg [CW-1:0] cdata [0:LINES-1];
  (* ramstyle = "M10K, no_rw_check" *) reg [MW-1:0] cmeta [0:LINES-1];
  reg [CW-1:0] data_q; reg [MW-1:0] meta_q;
  reg            cd_we, cm_we;
  reg [LIDX-1:0] cd_wa, cm_wa;
  reg [CW-1:0]   cd_wd; reg [MW-1:0] cm_wd;

  localparam S_CLR=4'd0, S_IDLE=4'd1, S_CMP=4'd3, S_WB=4'd4, S_WBW=4'd5,
             S_FILL=4'd6, S_FILLW=4'd7, S_DONE=4'd8, S_WBP=4'd9;
  reg [3:0]      st;
  // !cd_we/!cm_we: a line write issued at S_CMP lands in the M10K one edge LATER; a request accepted in
  // that cycle would read the line at the same edge (no_rw_check -> OLD data). Not idle until it landed.
  assign idle = (st==S_IDLE) && !cd_we && !cm_we;

  wire [LW-1:0]   a_w   = addr[LW-1:0];
  wire [LIDX-1:0] a_idx = addr[IDX-1:LW];
  wire [TW-1:0]   a_tag = addr[AW-1:IDX];
  reg  [LIDX-1:0] r_idx; reg [TW-1:0] r_tag; reg [LW-1:0] r_w; reg r_we; reg [DW-1:0] r_wdata;
  wire [LIDX-1:0] rd_addr = (st==S_IDLE && req) ? a_idx : r_idx;
  always @(posedge clk) begin
    if (cd_we) cdata[cd_wa] <= cd_wd;
    data_q <= cdata[rd_addr];
    if (cm_we) cmeta[cm_wa] <= cm_wd;
    meta_q <= cmeta[rd_addr];
  end

  wire           m_valid = meta_q[MW-1];
  wire           m_dirty = meta_q[MW-2];
  wire [WPL-1:0] m_wv    = meta_q[TW +: WPL];
  wire [TW-1:0]  m_tag   = meta_q[TW-1:0];

  // ---- line <-> word / DDR-beat helpers ----
  function automatic [DW-1:0] word_of(input [CW-1:0] l, input [LW-1:0] w);
    word_of = l[w*DW +: DW];
  endfunction
  function automatic [CW-1:0] put_word(input [CW-1:0] l, input [LW-1:0] w, input [DW-1:0] v);
    put_word = l; put_word[w*DW +: DW] = v;
  endfunction
  function automatic [63:0] to_beat(input [CW-1:0] l);            // compact line -> DDR lanes
    integer j; to_beat = 64'd0;
    for (j = 0; j < WPL; j = j + 1) to_beat[j*LANE +: DW] = l[j*DW +: DW];
  endfunction
  function automatic [CW-1:0] merge_beat(input [CW-1:0] l, input [WPL-1:0] keep, input [63:0] b);
    integer j; merge_beat = l;                                   // keep valid cache words, else DDR
    for (j = 0; j < WPL; j = j + 1) if (!keep[j]) merge_beat[j*DW +: DW] = b[j*LANE +: DW];
  endfunction
  function automatic [7:0] be_of(input [WPL-1:0] wv);
    integer j; be_of = 8'h00;
    for (j = 0; j < WPL; j = j + 1) if (wv[j]) be_of[j*LBYTE +: LBYTE] = {LBYTE{1'b1}};
  endfunction
  function automatic [31:0] line_addr(input [TW-1:0] t, input [LIDX-1:0] i);
    line_addr = BASE + ({{(32-TW-LIDX){1'b0}}, t, i} << 3);
  endfunction

  reg [LIDX:0]   clr_i;
  reg            r_merge;        // fill merges into a tag-matching line (keep r_keep words)
  reg [WPL-1:0]  r_keep;
  reg            r_dirty;        // dirty bit to keep after a merge-fill
  reg [CW-1:0]   r_line;         // line image at S_CMP (merge base)
  reg [DW-1:0]   fill_q;

  always @(posedge clk) begin
    ready <= 1'b0; m_req <= m_req & ~m_ack; cd_we<=1'b0; cm_we<=1'b0;
    if (por) begin
      st<=S_CLR; clr_i<=0; m_req<=1'b0; m_we<=1'b0; m_be<=8'hff; misses<=0; rdata<=0; fill_q<=0; r_idx<=0;
    end else begin
      case (st)
        S_CLR: begin
          cm_we<=1'b1; cm_wa<=clr_i[LIDX-1:0]; cm_wd<={MW{1'b0}};
          if (clr_i==LINES-1) st<=S_IDLE;
          clr_i<=clr_i+1'b1;
        end
        S_IDLE: if (req) begin
          r_idx<=a_idx; r_tag<=a_tag; r_w<=a_w; r_we<=we; r_wdata<=wdata; st<=S_CMP;
        end
        S_CMP: begin
          if (m_valid && m_tag==r_tag && (r_we || m_wv[r_w])) begin          // HIT
            if (r_we) begin
              cd_we<=1'b1; cd_wa<=r_idx; cd_wd<=put_word(data_q, r_w, r_wdata);
              cm_we<=1'b1; cm_wa<=r_idx; cm_wd<={1'b1, 1'b1, m_wv | (WPL'(1) << r_w), r_tag};
              rdata<=r_wdata;
            end else rdata<=word_of(data_q, r_w);
            ready<=1'b1; st<=S_IDLE;
          end else if (m_valid && m_tag==r_tag) begin                         // READ of an invalid word
            misses<=misses+1'b1;                                              // in a matching line: merge-fill
            r_merge<=1'b1; r_keep<=m_wv; r_dirty<=m_dirty; r_line<=data_q;
            m_req<=1'b1; m_we<=1'b0; m_be<=8'hff; m_addr<=line_addr(r_tag, r_idx); st<=S_FILL;
          end else if (r_we) begin                                            // WRITE miss: allocate, no fill
            misses<=misses+1'b1;
            cd_we<=1'b1; cd_wa<=r_idx; cd_wd<=put_word({CW{1'b0}}, r_w, r_wdata);
            cm_we<=1'b1; cm_wa<=r_idx; cm_wd<={1'b1, 1'b1, WPL'(1) << r_w, r_tag};
            rdata<=r_wdata; ready<=1'b1;
            if (m_valid && m_dirty) begin                                     // POSTED write-back
              m_req<=1'b1; m_we<=1'b1; m_be<=be_of(m_wv);
              m_addr<=line_addr(m_tag, r_idx); m_wdata<=to_beat(data_q);
              st<=S_WBP;
            end else st<=S_IDLE;
          end else begin                                                      // READ miss (tag)
            misses<=misses+1'b1;
            r_merge<=1'b0; r_keep<={WPL{1'b0}}; r_dirty<=1'b0; r_line<={CW{1'b0}};
            if (m_valid && m_dirty) begin
              m_req<=1'b1; m_we<=1'b1; m_be<=be_of(m_wv);
              m_addr<=line_addr(m_tag, r_idx); m_wdata<=to_beat(data_q);
              st<=S_WB;
            end else begin
              m_req<=1'b1; m_we<=1'b0; m_be<=8'hff; m_addr<=line_addr(r_tag, r_idx); st<=S_FILL;
            end
          end
        end
        S_WBP:  if (m_ack) st<=S_IDLE;
        S_WB:   if (m_ack) st<=S_WBW;
        S_WBW: begin m_req<=1'b1; m_we<=1'b0; m_be<=8'hff; m_addr<=line_addr(r_tag, r_idx); st<=S_FILL; end
        S_FILL: if (m_ack) st<=S_FILLW;
        S_FILLW: if (m_rvalid) begin : fillw
          logic [CW-1:0] nl;
          nl = merge_beat(r_line, r_keep, m_rdata);
          fill_q <= word_of(nl, r_w);
          cd_we<=1'b1; cd_wa<=r_idx; cd_wd<=nl;
          cm_we<=1'b1; cm_wa<=r_idx; cm_wd<={1'b1, r_merge & r_dirty, {WPL{1'b1}}, r_tag};
          st<=S_DONE;
        end
        S_DONE: begin rdata <= fill_q; ready<=1'b1; st<=S_IDLE; end
        default: st<=S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
`default_nettype none
// dcs2_sram_cache_4w -- the SAME cache contract as dcs2_sram_cache (packed 64-bit lines, per-word valid, write-back,
// write-allocate without fill, merge-fill, byte-enabled write-back of valid words, POSTED write-back on a write miss, the
// idle output, same ports, same DDR backing layout: line L of the SRAM view at BASE + L*8) but FOUR-WAY SET-ASSOCIATIVE
// with a hashed set index and tree pseudo-LRU, at the SAME word capacity (1<<IDX words).
//   set  = line[SIDX-1:0] ^ {tag[2:0], 0..}   (the low tag bits fold into the top set bits, so SRAM regions an exact
//          power of two apart -- Invasion's DM 0x0A00 / 0x1A00 / 0x2A00 tables -- land in different sets)
//   tag  = line[LIDX-1:SIDX]
// M10K: data AND metadata of a set live in ONE M10K word (4 lines + 4 x {valid, dirty, wv[WPL], tag} + 3 PLRU bits;
// DM: 256 x 299 = 8 blocks in 256x40 mode = the direct-mapped cache's 7 (1024x64) + 1 (1024x8)), single write port,
// registered read -- the Quartus-17 inferable template. Every write rewrites the whole set word from the registered image.
//
// inv-buzz 2026-09-26 (MEASURED, lanes/inv-buzz): Invasion's sound program cycles DM tables whose SRAM words share
// direct-mapped (and 2-way) slots: 52,000 DM misses/s in the coin-up sound, 17,000/s in gameplay (cache_sim.py on the
// DSP's own access stream: 36,886 read misses 2-way vs 1,502 4-way hashed in a 2 s gameplay window). Each miss is a DDR
// round trip on the HPS DDR3 shared with the renderer and the ascal scaler; beyond ~60 clk per round trip the DSP misses
// its half-buffer deadline and the DAC replays a stale half-buffer (the cabinet buzz). MK4 keeps dcs2_sram_cache.
module dcs2_sram_cache_4w #(
  parameter int AW  = 14,
  parameter int DW  = 16,
  parameter int IDX = 12,
  parameter [31:0] BASE = 32'h3180_0000
) (
  input  wire            clk,
  input  wire            por,
  input  wire            req,
  input  wire            we,
  input  wire [AW-1:0]   addr,
  input  wire [DW-1:0]   wdata,
  output reg             ready,
  output reg  [DW-1:0]   rdata,
  output reg             m_req, m_we,
  output reg  [31:0]     m_addr,
  output reg  [63:0]     m_wdata,
  output reg  [7:0]      m_be,
  input  wire            m_ack,
  input  wire            m_rvalid,
  input  wire [63:0]     m_rdata,
  output reg  [31:0]     misses,
  output wire            idle
);
  localparam int LW    = (DW <= 16) ? 2 : 1;
  localparam int WPL   = (1 << LW);
  localparam int LANE  = 64 / WPL;
  localparam int LBYTE = LANE / 8;
  localparam int SIDX  = IDX - LW - 2;         // set index bits (four lines per set)
  localparam int SETS  = (1 << SIDX);
  localparam int TW    = AW - LW - SIDX;       // tag bits
  localparam int FB    = (TW < 3) ? TW : 3;    // tag bits folded into the set index
  localparam int CW    = WPL * DW;
  localparam int MW    = 2 + WPL + TW;         // per way {valid, dirty, wv[WPL], tag}
  localparam int MB    = 4 * CW;               // meta base bit in the set word
  localparam int PB    = 4 * CW + 4 * MW;      // PLRU base bit
  localparam int EW    = PB + 3;               // set word width

  (* ramstyle = "M10K, no_rw_check" *) reg [EW-1:0] cset [0:SETS-1];
  reg [EW-1:0] q;
  reg          cs_we; reg [SIDX-1:0] cs_wa; reg [EW-1:0] cs_wd;

  localparam S_CLR=4'd0, S_IDLE=4'd1, S_CMP=4'd3, S_WB=4'd4, S_WBW=4'd5,
             S_FILL=4'd6, S_FILLW=4'd7, S_DONE=4'd8, S_WBP=4'd9;
  reg [3:0]      st;
  assign idle = (st==S_IDLE) && !cs_we;

  function automatic [SIDX-1:0] fold(input [TW-1:0] t);
    fold = '0; fold[SIDX-1 -: FB] = t[FB-1:0];
  endfunction
  wire [LW-1:0]   a_w   = addr[LW-1:0];
  wire [TW-1:0]   a_tag = addr[AW-1:LW+SIDX];
  wire [SIDX-1:0] a_set = addr[LW+SIDX-1:LW] ^ fold(a_tag);
  reg  [SIDX-1:0] r_set; reg [TW-1:0] r_tag; reg [LW-1:0] r_w; reg r_we; reg [DW-1:0] r_wdata;
  // outside S_IDLE+req the read address is r_set: q keeps showing the CURRENT set (no write lands on it between S_CMP
  // and S_FILLW), so the fill merges into it without a latched copy.
  wire [SIDX-1:0] rd_addr = (st==S_IDLE && req) ? a_set : r_set;
  always @(posedge clk) begin
    if (cs_we) cset[cs_wa] <= cs_wd;
    q <= cset[rd_addr];
  end

  function automatic [MW-1:0] meta_of(input [EW-1:0] s, input [1:0] w);
    meta_of = s[MB + w*MW +: MW];
  endfunction
  function automatic [CW-1:0] line_of(input [EW-1:0] s, input [1:0] w);
    line_of = s[w*CW +: CW];
  endfunction
  wire [2:0] pl = q[PB +: 3];
  logic [3:0] match; logic [3:0] vld; logic [MW-1:0] mt [4];
  always_comb for (int k = 0; k < 4; k++) begin
    mt[k]    = q[MB + k*MW +: MW];
    vld[k]   = mt[k][MW-1];
    match[k] = vld[k] && (mt[k][TW-1:0] == r_tag);
  end
  function automatic [2:0] pl_touch(input [2:0] p, input [1:0] w);   // point the tree AWAY from way w
    pl_touch = p; pl_touch[0] = ~w[1];
    if (w[1]) pl_touch[2] = ~w[0]; else pl_touch[1] = ~w[0];
  endfunction
  wire       mhit = |match;
  wire [1:0] mway = match[3] ? 2'd3 : match[2] ? 2'd2 : match[1] ? 2'd1 : 2'd0;
  wire [MW-1:0] mm = meta_of(q, mway);
  wire [CW-1:0] ml = line_of(q, mway);
  // victim: the first invalid way, else the tree-PLRU way (root pl[0]: 0 = left pair by pl[1], 1 = right pair by pl[2])
  wire [1:0] plv  = pl[0] ? {1'b1, pl[2]} : {1'b0, pl[1]};
  wire [1:0] vway = !vld[0] ? 2'd0 : !vld[1] ? 2'd1 : !vld[2] ? 2'd2 : !vld[3] ? 2'd3 : plv;
  wire [MW-1:0] vm = meta_of(q, vway);
  wire [CW-1:0] vl = line_of(q, vway);

  function automatic [DW-1:0] word_of(input [CW-1:0] l, input [LW-1:0] w);
    word_of = l[w*DW +: DW];
  endfunction
  function automatic [CW-1:0] put_word(input [CW-1:0] l, input [LW-1:0] w, input [DW-1:0] v);
    put_word = l; put_word[w*DW +: DW] = v;
  endfunction
  function automatic [63:0] to_beat(input [CW-1:0] l);
    integer j; to_beat = 64'd0;
    for (j = 0; j < WPL; j = j + 1) to_beat[j*LANE +: DW] = l[j*DW +: DW];
  endfunction
  function automatic [CW-1:0] merge_beat(input [CW-1:0] l, input [WPL-1:0] keep, input [63:0] b);
    integer j; merge_beat = l;
    for (j = 0; j < WPL; j = j + 1) if (!keep[j]) merge_beat[j*DW +: DW] = b[j*LANE +: DW];
  endfunction
  function automatic [7:0] be_of(input [WPL-1:0] wv);
    integer j; be_of = 8'h00;
    for (j = 0; j < WPL; j = j + 1) if (wv[j]) be_of[j*LBYTE +: LBYTE] = {LBYTE{1'b1}};
  endfunction
  function automatic [31:0] line_addr(input [TW-1:0] t, input [SIDX-1:0] s);   // s = the HASHED set
    logic [SIDX-1:0] raw; raw = s ^ fold(t);
    line_addr = BASE + ({{(32-TW-SIDX){1'b0}}, t, raw} << 3);
  endfunction
  // the set word with way w's line + meta replaced and w made most recent (PLRU points away from it)
  function automatic [EW-1:0] set_upd(input [EW-1:0] s, input [1:0] w, input [CW-1:0] l, input [MW-1:0] m);
    set_upd = s; set_upd[w*CW +: CW] = l; set_upd[MB + w*MW +: MW] = m;
    set_upd[PB +: 3] = pl_touch(s[PB +: 3], w);
  endfunction

  reg [SIDX:0]   clr_i;
  reg [1:0]      r_way;
  reg            r_merge;
  reg [WPL-1:0]  r_keep;
  reg            r_dirty;
  reg [DW-1:0]   fill_q;

  always @(posedge clk) begin
    ready <= 1'b0; m_req <= m_req & ~m_ack; cs_we<=1'b0;
    if (por) begin
      st<=S_CLR; clr_i<=0; m_req<=1'b0; m_we<=1'b0; m_be<=8'hff; misses<=0; rdata<=0; fill_q<=0; r_set<=0; r_way<=2'd0;
    end else begin
      case (st)
        S_CLR: begin
          cs_we<=1'b1; cs_wa<=clr_i[SIDX-1:0]; cs_wd<={EW{1'b0}};
          if (clr_i==SETS-1) st<=S_IDLE;
          clr_i<=clr_i+1'b1;
        end
        S_IDLE: if (req) begin
          r_set<=a_set; r_tag<=a_tag; r_w<=a_w; r_we<=we; r_wdata<=wdata; st<=S_CMP;
        end
        S_CMP: begin
          if (mhit && (r_we || mm[TW + r_w])) begin                                   // HIT
            if (r_we) begin
              cs_we<=1'b1; cs_wa<=r_set;
              cs_wd<=set_upd(q, mway, put_word(ml, r_w, r_wdata), {1'b1, 1'b1, mm[TW +: WPL] | (WPL'(1) << r_w), r_tag});
              rdata<=r_wdata;
            end else begin
              rdata<=word_of(ml, r_w);
              if (pl_touch(pl, mway) != pl) begin cs_we<=1'b1; cs_wa<=r_set; cs_wd<=set_upd(q, mway, ml, mm); end   // PLRU touch
            end
            ready<=1'b1; st<=S_IDLE;
          end else if (mhit) begin                                                     // READ of an invalid word
            misses<=misses+1'b1;                                                       // in a matching line: merge-fill
            r_way<=mway; r_merge<=1'b1; r_keep<=mm[TW +: WPL]; r_dirty<=mm[MW-2];
            m_req<=1'b1; m_we<=1'b0; m_be<=8'hff; m_addr<=line_addr(r_tag, r_set); st<=S_FILL;
          end else if (r_we) begin                                                     // WRITE miss: allocate, no fill
            misses<=misses+1'b1;
            cs_we<=1'b1; cs_wa<=r_set;
            cs_wd<=set_upd(q, vway, put_word({CW{1'b0}}, r_w, r_wdata), {1'b1, 1'b1, WPL'(1) << r_w, r_tag});
            rdata<=r_wdata; ready<=1'b1;
            if (vm[MW-1] && vm[MW-2]) begin                                            // POSTED write-back of the victim
              m_req<=1'b1; m_we<=1'b1; m_be<=be_of(vm[TW +: WPL]);
              m_addr<=line_addr(vm[TW-1:0], r_set); m_wdata<=to_beat(vl);
              st<=S_WBP;
            end else st<=S_IDLE;
          end else begin                                                               // READ miss (tag)
            misses<=misses+1'b1;
            r_way<=vway; r_merge<=1'b0; r_keep<={WPL{1'b0}}; r_dirty<=1'b0;
            if (vm[MW-1] && vm[MW-2]) begin
              m_req<=1'b1; m_we<=1'b1; m_be<=be_of(vm[TW +: WPL]);
              m_addr<=line_addr(vm[TW-1:0], r_set); m_wdata<=to_beat(vl);
              st<=S_WB;
            end else begin
              m_req<=1'b1; m_we<=1'b0; m_be<=8'hff; m_addr<=line_addr(r_tag, r_set); st<=S_FILL;
            end
          end
        end
        S_WBP:  if (m_ack) st<=S_IDLE;
        S_WB:   if (m_ack) st<=S_WBW;
        S_WBW: begin m_req<=1'b1; m_we<=1'b0; m_be<=8'hff; m_addr<=line_addr(r_tag, r_set); st<=S_FILL; end
        S_FILL: if (m_ack) st<=S_FILLW;
        S_FILLW: if (m_rvalid) begin : fillw
          logic [CW-1:0] nl;
          nl = merge_beat(r_merge ? line_of(q, r_way) : {CW{1'b0}}, r_keep, m_rdata);
          fill_q <= word_of(nl, r_w);
          cs_we<=1'b1; cs_wa<=r_set;
          cs_wd<=set_upd(q, r_way, nl, {1'b1, r_merge & r_dirty, {WPL{1'b1}}, r_tag});
          st<=S_DONE;
        end
        S_DONE: begin rdata <= fill_q; ready<=1'b1; st<=S_IDLE; end
        default: st<=S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
