#!/bin/bash
# event-trace runner: run_evt.sh <engine.sv> <tag> <t_end>  (env: EVT=1 etc. set by caller inside wsl)
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/board
D2=/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs2
DN=/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs/donor
T=/mnt/d/deck/fpga/zeus/zeus1/tools
F0=/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix
ENG="$1"; TAG="$2"; TE="$3"; shift 3
LOG=/mnt/h/temp/zeus/mk4-devcensus-cold/devices.log
REGION=/mnt/h/temp/zeus/mk4_dcs_stream_from_zip.bin
read -r R12 R13 REST <<< "$(python3 $T/pic_serial_from_log.py "$LOG")" || { echo "PREPASS FAILED"; exit 2; }
RTC="${REST#*| }"
B=/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix/build_$TAG
mkdir -p "$B"; cd "$B" || exit 2
if true; then
verilator --cc --exe --build -O3 -j 8 --top-module zk4_board_fabric_bench --public-flat-rw -GRAND12=8\'h$R12 -GRAND13=8\'h$R13 \
  -Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-CASEINCOMPLETE -Wno-UNOPTFLAT \
  $S/zk4_pic2.sv $S/zk4_ioasic.sv $S/zk4_cmos.sv $S/zk4_board_io.sv \
  "${AB:-$F0/dcs2_autobuf.sv}" "$ENG" "${AGT:-$D2/dcs2_ddr_agent.sv}" "${SRC:-$F0/dcs2_sram_cache.sv}" "${MBX:-$F0/dcs2_mailbox.sv}" $D2/dcs2_sport_dac.sv "${ZK4:-$F0/zk4_dcs2.sv}" \
  $DN/cusa_dcs_rom_loader.sv $DN/cusa_dcs_fifo.sv \
  $S/zk4_board_fabric_bench.sv ${TB:-/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix/tb_evt.cpp} -o tb > build.log 2>&1 || { grep -m20 -E "%Error" build.log; echo "BUILD FAILED"; exit 2; }
fi
./obj_dir/tb "$LOG" "$RTC" "$REGION" "$TE" "$@"
