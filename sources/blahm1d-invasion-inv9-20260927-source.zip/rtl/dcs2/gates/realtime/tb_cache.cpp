// Directed + randomized gate for the packed-line dcs2_sram_cache (DW set by -G). Reference = a flat
// word memory (the SRAM as MAME sees it: dcs.cpp m_sram, every read returns the last written value).
// DDR model honours byte enables and starts as all-ones (the bench DDR default), so any write-back that
// clobbers never-written words, or a merge-fill that loses a dirty word, is visible on a later read.
// Pressure: address window 4x the cache word capacity (conflict evictions), sequential sweeps (the boot
// clears / RAM tests) + random mixes, random DDR latencies. Exit 0 iff every read matches.
#include "Vdcs2_sram_cache.h"
#include "verilated.h"
#include "Vdcs2_sram_cache___024root.h"
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <unordered_map>
#include <deque>
static Vdcs2_sram_cache* c; static std::unordered_map<uint64_t,uint64_t> ddr; static long cyc = 0;
static std::deque<std::pair<int,uint64_t>> rq;    // (countdown, key)
static int wcnt = 0;
static void tick() {
    // DDR slave: one command at a time from the cache; random accept latency; reads return later.
    c->m_ack = 0; c->m_rvalid = 0;
    static int acc_wait = -1;
    if (c->m_req) { if (acc_wait < 0) acc_wait = rand() % 14; if (acc_wait == 0) {
            uint64_t key = (uint64_t)c->m_addr >> 3;
            if (c->m_we) { uint64_t m = 0; for (int b = 0; b < 8; b++) if (c->m_be >> b & 1) m |= 0xFFull << (8*b);
                auto it = ddr.find(key); uint64_t old = it != ddr.end() ? it->second : ~0ull; ddr[key] = (old & ~m) | (c->m_wdata & m); }
            else rq.push_back({2 + rand() % 20, key});   // data >= 1 clk after the ack (dcs2_ddr_agent: c_ack in S_ADDR, c_rvalid from S_RWAIT)
            c->m_ack = 1; acc_wait = -1; } else acc_wait--; }
    if (!rq.empty()) { if (--rq.front().first <= 0) { auto it = ddr.find(rq.front().second);
            c->m_rdata = it != ddr.end() ? it->second : ~0ull; c->m_rvalid = 1; rq.pop_front(); } }
    c->clk = 0; c->eval(); c->clk = 1; c->eval(); cyc++;
}
int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv); c = new Vdcs2_sram_cache; srand(12345);
    const int DW = argc > 1 ? atoi(argv[1]) : 16; const uint32_t DMASK = (DW >= 32) ? 0xffffffffu : ((1u << DW) - 1);
    const int LANE = DW <= 16 ? 16 : 32; const uint32_t BASE = 0x31800000u;
    const int AW = 14, SPAN = 1 << AW;
    c->por = 1; c->req = 0; c->m_ack = 0; c->m_rvalid = 0; for (int i = 0; i < 4; i++) tick(); c->por = 0;
    while (!c->idle) tick();
    // reference: SRAM word w = its DDR lane (initial all ones -> DMASK) until written
    std::unordered_map<int,uint32_t> ref;
    auto refget = [&](int a) { auto it = ref.find(a); return it != ref.end() ? it->second : DMASK; };
    long fails = 0, reads = 0, writes = 0;
    auto op = [&](bool we, int a, uint32_t d) {
        while (!c->idle) tick();
        c->req = 1; c->we = we; c->addr = a; c->wdata = d & DMASK; tick(); c->req = 0;
        long g = 0; while (!c->ready) { tick(); if (++g > 100000) { printf("HANG a=%04x we=%d st=%d m_req=%d rq=%zu cyc=%ld\n", a, (int)we, (int)c->rootp->dcs2_sram_cache__DOT__st, (int)c->m_req, rq.size(), cyc); exit(3); } }
        if (we) { ref[a] = d & DMASK; writes++; }
        else { reads++; uint32_t exp = refget(a); if ((uint32_t)c->rdata != exp) { if (fails < 10) printf("MISMATCH rd a=%04x got %x exp %x\n", a, (unsigned)c->rdata, exp); fails++; } }
    };
    // 1. sequential write sweep over 4x capacity (boot clear), then read-back sweep (RAM test)
    for (int a = 0; a < SPAN; a++) op(true, a, a * 0x9e37u + 1);
    for (int a = 0; a < SPAN; a++) op(false, a, 0);
    // 2. partial lines: write only word 1 of lines, evict, read all words (never-written words stay DDR ones)
    for (int a = 1; a < SPAN; a += 4) op(true, a, a ^ 0x5a5a);
    for (int a = 0; a < SPAN; a++) op(false, a, 0);
    // 3. random mix with conflict pressure
    for (long i = 0; i < 400000; i++) { int a = rand() % SPAN; if (rand() & 1) op(true, a, rand()); else op(false, a, 0); }
    printf("CACHE gate DW=%d: %ld reads, %ld writes, %ld cycles: %s (%ld mismatches)\n", DW, reads, writes, cyc, fails ? "FAIL" : "PASS", fails);
    (void)LANE; (void)BASE;
    delete c; return fails ? 1 : 0;
}
