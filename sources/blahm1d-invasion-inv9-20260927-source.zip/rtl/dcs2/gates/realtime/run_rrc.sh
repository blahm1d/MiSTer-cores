#!/bin/bash
# warm reboot regcheck (OVL level-commit) for an engine. usage: run_rrc.sh <engine.sv> <tag>
ENG="$1"; TAG="$2"
BE=/mnt/d/deck/fpga/zeus/zeus1/lanes/dcs2-engine/bench
G=/mnt/h/temp/zeus/dcs2-engine/golden/dcs2_golden.tr
B=/mnt/h/temp/zeus/dcs2-engine/rom/dcs_compact.bin
M=/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix/obj_rrc_$TAG
bash /mnt/h/temp/zeus/dcs2-area/ckpt4o_fix/build_rrc_final.sh "$ENG" dcs2_rrc "$M" 2>&1 | tail -2
cd $BE
env OVL=1 IGN_CTX=1 "$M/dcs2_rrc" "$G" "$B" 65536 12 20 90000000 2>&1 | grep -iE "reached 0x2800|DIVERG|REBOOT-REG|matched" | tail -6
