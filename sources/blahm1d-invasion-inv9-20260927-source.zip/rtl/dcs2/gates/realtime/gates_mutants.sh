#!/bin/bash
# Coverage: each new mechanism must be killed by a named gate.
#   M1 pacer off (PACE_EN=0)                 -> PACEGATE must FAIL (reply ~0.9 s early)
#   M2 read-while-fill off-by-one (>= )      -> PACEGATE must FAIL (reads a word not yet in the M10K)
#   M3 radix-4 arithmetic right shift -> 0s  -> engine shift gate must FAIL
set -u
F=/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix; S=/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs2
export TB=$F/tb_zk4_board_fabric_acct.cpp AB=$S/dcs2_autobuf.sv MBX=$S/dcs2_mailbox.sv SRC=$S/dcs2_sram_cache.sv
fail=0
chk() { if [ "$2" -ne 0 ]; then echo "  $1 KILLED"; else echo "  $1 SURVIVED"; fail=1; fi; }
o=$(ZK4=$F/mut/zk4_nopace.sv PACEGATE=1 bash $F/run_evt.sh $S/dcs2_engine.sv m1 47.40 2>/dev/null | grep -E "PACEGATE|BUILD"); echo "$o"
echo "$o" | grep -q "PACEGATE FAIL"; chk "M1 pacer-off" $([ $? -eq 0 ] && echo 1 || echo 0)
o=$(ZK4=$F/mut/zk4_rwf_off1.sv PACEGATE=1 bash $F/run_evt.sh $S/dcs2_engine.sv m2 47.40 2>/dev/null | grep -E "PACEGATE|BUILD"); echo "$o"
echo "$o" | grep -q "PACEGATE FAIL"; chk "M2 read-while-fill off-by-one" $([ $? -eq 0 ] && echo 1 || echo 0)
bash $F/gates_eng.sh $F/mut/eng_sra4.sv m3 > $F/mut/m3.txt 2>&1; r=$?; grep -E "shift|boot|fight" $F/mut/m3.txt
chk "M3 radix-4 sra fill" $r
echo "MUTANTS: $([ $fail -eq 0 ] && echo 'ALL KILLED' || echo 'SURVIVOR')"; exit $fail
