#!/bin/bash
# Board-level gates on the final source set (cold MAME device log, acct bench with byte-enable DDR):
#   PACEGATE (t_end 47.40): instr-to-0x79/0x01 == MAME, SPORT/TIMER IRQ counts, reply not early
#   COLDGATE (t_end 46.50): 009B-clear commits <= MAME's 53,780 (== 53,780 at the reply if reached)
#   HOSTCHECK (t_end 47.40): the unmodified host-visible compare (reported, see RESUME for its status)
# usage: gates_board.sh [tag] [extra env for hostile runs, e.g. "DDR_HOSTILE=30 DDR_DEPTH=4"]
set -u
F=/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix; S=/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs2
TAG="${1:-final}"; EXTRA="${2:-}"
export TB=$F/tb_zk4_board_fabric_acct.cpp ZK4=$S/zk4_dcs2.sv AB=$S/dcs2_autobuf.sv MBX=$S/dcs2_mailbox.sv SRC=$S/dcs2_sram_cache.sv
fail=0
o=$(env $EXTRA PACEGATE=1 bash $F/run_evt.sh $S/dcs2_engine.sv b_$TAG 47.40 2>/dev/null | grep -E "PACEGATE|BUILD FAILED"); echo "$o"
echo "$o" | grep -q "PACEGATE PASS" || fail=1
o=$(env $EXTRA COLDGATE=1 bash $F/run_evt.sh $S/dcs2_engine.sv b_$TAG 46.50 2>/dev/null | grep -E "COLDGATE|BUILD FAILED"); echo "$o"
echo "$o" | grep -q "COLDGATE PASS" || fail=1
env $EXTRA bash $F/run_evt.sh $S/dcs2_engine.sv b_$TAG 47.40 2>/dev/null | grep -E "MISMATCH|lead|ACCT|PASS|FAIL"
echo "BOARD GATES[$TAG] (pace+cold): $([ $fail -eq 0 ] && echo PASS || echo FAIL)"; exit $fail
