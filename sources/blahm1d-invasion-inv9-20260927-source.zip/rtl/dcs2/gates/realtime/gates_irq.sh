#!/bin/bash
# Directed IRQ-mux + mailbox gates, each run on the FIXED rtl and on the TREE rtl (mutant = pre-fix
# behaviour; must FAIL). usage: gates_irq.sh   (exit 0 iff fixed PASS and both mutants FAIL)
set -u
F=/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix
T=/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs2
W=$F/gates_irq; mkdir -p "$W"; cd "$W" || exit 2
VF="-Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-CASEINCOMPLETE -Wno-UNOPTFLAT"
bld() { rm -rf "$3"; verilator $VF --cc "$1" --exe "$2" --build -O1 --top-module "$4" --public-flat-rw --Mdir "$3" -o tb > "$3.log" 2>&1; }
fail=0
bld $F/dcs2_autobuf.sv $F/tb_irqmux.cpp o_mux_fix dcs2_autobuf || { echo "BUILD-FAIL mux fix"; fail=1; }
bld $F/dcs2_mailbox.sv $F/tb_mailbox.cpp o_mbx_fix dcs2_mailbox || { echo "BUILD-FAIL mbx fix"; fail=1; }
bld $F/dcs2_mailbox_tree_orig.sv $F/tb_mailbox.cpp o_mbx_mut dcs2_mailbox || { echo "BUILD-FAIL mbx mutant"; fail=1; }
# the tree autobuf has no e_icntl2/e_imask ports -> mutant = fixed file with the pre-fix mux lines restored
sed -e 's/if (irq2_chk \&\& m_irq2)  /if (irq2_req)/' -e 's/sport_tx_pend \&\& m_sport/sport_tx_pend/' -e 's/timer_pend \&\& m_timer/timer_pend/' $F/dcs2_autobuf.sv > mut_autobuf.sv
grep -q "if (irq2_req)" mut_autobuf.sv || { echo "MUTANT NOT APPLIED"; fail=1; }
bld mut_autobuf.sv $F/tb_irqmux.cpp o_mux_mut dcs2_autobuf || { echo "BUILD-FAIL mux mutant"; fail=1; }
echo "[fix] irqmux";   ./o_mux_fix/tb > mux_fix.txt; r=$?; tail -1 mux_fix.txt; [ $r -eq 0 ] || fail=1
echo "[fix] mailbox";  ./o_mbx_fix/tb > mbx_fix.txt; r=$?; tail -1 mbx_fix.txt; [ $r -eq 0 ] || fail=1
echo "[mutant] irqmux (pre-fix mux)";   ./o_mux_mut/tb > mux_mut.txt; r=$?; grep -c FAIL mux_mut.txt | sed 's/^/  failing lines: /'; [ $r -ne 0 ] && echo "  KILLED" || { echo "  SURVIVED"; fail=1; }
echo "[mutant] mailbox (tree: read acks)"; ./o_mbx_mut/tb > mbx_mut.txt; r=$?; grep FAIL mbx_mut.txt | head -3; [ $r -ne 0 ] && echo "  KILLED" || { echo "  SURVIVED"; fail=1; }
echo "IRQ GATES: $([ $fail -eq 0 ] && echo PASS || echo FAIL)"; exit $fail
