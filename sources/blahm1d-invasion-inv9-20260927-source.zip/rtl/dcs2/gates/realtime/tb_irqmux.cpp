// Directed gate: dcs2_autobuf IRQ selection vs adsp2101_device::check_irqs (MAME 0.289 adsp2100.cpp:967-999)
// + generate_irq mask skip (:894) + IRQ2 edge/level by ICNTL bit2 (:972, latch set on CLEAR->ASSERT :1167-1171,
// cleared by generate_irq :898). Pend flops are poked via --public-flat-rw (the timer/SPORT generators are
// covered by run_gates_sport.sh; this gate isolates the MUX). Exit 0 iff all cases pass.
#include "Vdcs2_autobuf.h"
#include "Vdcs2_autobuf___024root.h"
#include "verilated.h"
#include <cstdio>
static Vdcs2_autobuf* d; static long fails = 0;
static void tick() { d->clk = 0; d->eval(); d->clk = 1; d->eval(); }
#define R(x) d->rootp->dcs2_autobuf__DOT__##x
static void setpend(int sport, int timer) { R(sport_tx_pend) = sport; R(timer_pend) = timer; d->eval(); }
static void expect(const char* n, int take, int indx) {
    d->eval();
    bool ok = d->e_irq_take == take && (!take || d->e_irq_indx == indx);
    printf("%-44s take=%d indx=%d  exp take=%d indx=%d  %s\n", n, d->e_irq_take, d->e_irq_indx, take, indx, ok ? "PASS" : "FAIL");
    if (!ok) fails++;
}
int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv); d = new Vdcs2_autobuf;
    d->rst = 1; d->audio_ce = 0; d->e_commit = 0; d->tick_force = 0; d->syscontrol = 0; d->s1_autobuf = 0; d->s1_control = 0;
    d->tscale = 0; d->tcount = 0; d->tperiod = 0; d->timer_ena = 0; d->tx1_we = 0; d->arm_seed_we = 0; d->arm_seed_base = 0;
    d->dac_rdata = 0; d->dac_ready = 0; d->irq2_req = 0; d->e_icntl2 = 0; d->e_imask = 0; d->e_irq_ack = 0; d->e_irq_ack_indx = 0;
    tick(); tick(); d->rst = 0; tick();
    // A. priority with everything enabled (IMASK=$25 as set by the firmware): IRQ2 > SPORT1-TX > TIMER
    d->e_imask = 0x25; d->irq2_req = 1; tick(); setpend(1, 1); expect("A1 all pending, IMASK=25 -> IRQ2", 1, 0);
    d->irq2_req = 0; tick(); setpend(1, 1); expect("A2 SPORT+TIMER, IMASK=25 -> SPORT(3)", 1, 3);
    // B. masked IRQ2 must NOT hide SPORT/TIMER (generate_irq returns false -> fall through)
    d->e_icntl2 = 0; d->irq2_req = 1; tick(); d->e_imask = 0x05; setpend(1, 0); expect("B1 IRQ2 line, IMASK=05 -> SPORT(3)", 1, 3);
    setpend(0, 1); expect("B2 IRQ2 line, IMASK=05, timer -> TIMER(5)", 1, 5);
    setpend(0, 0); expect("B3 IRQ2 line only, IMASK=05 -> none", 0, 0);
    // C. masked SPORT must NOT hide TIMER
    d->irq2_req = 0; tick(); d->e_imask = 0x01; setpend(1, 1); expect("C1 SPORT+TIMER, IMASK=01 -> TIMER(5)", 1, 5);
    d->e_imask = 0x04; setpend(1, 1); expect("C2 SPORT+TIMER, IMASK=04 -> SPORT(3)", 1, 3);
    d->e_imask = 0x00; setpend(1, 1); expect("C3 all masked -> none", 0, 0);
    setpend(0, 0);
    // D. IRQ2 LEVEL (ICNTL=0): re-offered while the line is high, even after being taken
    d->e_imask = 0x20; d->e_icntl2 = 0; d->irq2_req = 0; tick(); d->irq2_req = 1; tick(); expect("D1 level, line high -> IRQ2", 1, 0);
    d->e_irq_ack = 1; d->e_irq_ack_indx = 0; tick(); d->e_irq_ack = 0; tick(); expect("D2 level, taken, line still high -> IRQ2", 1, 0);
    // E. IRQ2 EDGE (ICNTL=4): one IRQ per CLEAR->ASSERT transition
    d->irq2_req = 0; tick(); tick(); d->e_icntl2 = 1; d->irq2_req = 1; tick(); expect("E1 edge, rising line -> IRQ2", 1, 0);
    d->e_irq_ack = 1; d->e_irq_ack_indx = 0; tick(); d->e_irq_ack = 0; tick(); expect("E2 edge, taken, line still high -> none", 0, 0);
    d->irq2_req = 0; tick(); d->irq2_req = 1; tick(); expect("E3 edge, new host write (re-assert) -> IRQ2", 1, 0);
    d->e_imask = 0x00; expect("E4 edge latched but masked -> none", 0, 0);
    d->e_imask = 0x20; expect("E5 unmasked again: latch kept -> IRQ2", 1, 0);
    printf("IRQMUX directed gate: %s (%ld fail)\n", fails ? "FAIL" : "PASS", fails);
    delete d; return fails ? 1 : 0;
}
