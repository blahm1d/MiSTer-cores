// COMBINED HOST CHECK for the fabric DCS2: MAME 0.289's cold-boot device log is replayed into zk4_board_io wired to the
// REAL zk4_dcs2 sound board (zk4_board_fabric_bench.sv), which boots from the real MK4 sound ROM served by a hostile
// DDR model. MAME resets the sound board at the first 0x990008 write (43.164 s in the cold log) and its host then reads
// the boot replies 0x79 / 0x01 (47.1186 s / 47.2598 s). Before that write the log is replayed FAST (board state only,
// sound board held in reset, nothing compared); from it on, in MAME time (x 50 MHz), with every read compared:
//   * SOUNDIN (0x99000B, the reply data the game waits on) and every non-sound read: EXACT, no exception.
//   * SOUNDSTAT (0x99000A): exact, except two declared, counted and listed timing classes --
//       consume edge : input-empty (0x80) lags within 3 us of a SOUNDOUT write (as in the stand-in gate);
//       reply lead   : output-full (0x40) already set here while MAME's is not yet (our DSP retires ~25 MIPS vs MAME's
//                      16, so its reply is READY earlier; it must never be LATER -- that is a failure).
//   * coverage: both boot replies must have been read and matched, else FAIL.
// usage: tb_zk4_board_fabric <devices.log> "<rtc 7 hex>" <region_le16.bin> [t_end=47.40] [LAT=12] [RLAT=20]
#include "Vzk4_board_fabric_bench.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include <unordered_map>
#include <deque>
#include <utility>
typedef uint64_t u64; typedef uint32_t u32;

int main(int argc, char** argv) {
    if (argc < 4) { printf("usage: tb_zk4_board_fabric <devices.log> \"rtc\" <region_le16.bin> [t_end] [LAT] [RLAT]\n"); return 2; }
    FILE* f = fopen(argv[1], "r"); if (!f) { printf("FAIL: cannot open %s\n", argv[1]); return 2; }
    unsigned rtc[7]; if (sscanf(argv[2], "%x %x %x %x %x %x %x", &rtc[0], &rtc[1], &rtc[2], &rtc[3], &rtc[4], &rtc[5], &rtc[6]) != 7) return 2;
    std::vector<uint16_t> region; { FILE* r = fopen(argv[3], "rb"); if (!r) { printf("FAIL: region\n"); return 2; }
        fseek(r, 0, SEEK_END); long n = ftell(r); fseek(r, 0, SEEK_SET); region.resize(n / 2);
        if (fread(region.data(), 2, region.size(), r) != region.size()) {} fclose(r); }
    double t_end = argc > 4 ? atof(argv[4]) : 47.40;
    int LAT = argc > 5 ? atoi(argv[5]) : 12, RLAT = argc > 6 ? atoi(argv[6]) : 20;
    Verilated::commandArgs(argc, argv);
    Vzk4_board_fabric_bench* t = new Vzk4_board_fabric_bench;
    // ---- DDR model: MULTI-OUTSTANDING in-order (models arb3+DDR3 pipelined reads). First read opens the
    //      row (LAT), pipelined after (1 clk), up to DEPTH outstanding, data RLAT clks after accept, returned
    //      in issue order. The old single-outstanding model (one rd_pending) lost the pipelined fill's beats
    //      -> the DSP hung in the boot copy at 0x00B4. Hostile knobs: DDR_DEPTH, DDR_HOSTILE (percent of
    //      cycles that stall acceptance AND gap readdatavalid = ARM/renderer contention). ----
    std::unordered_map<u64, u64> ddr; long cnt = 0; std::deque<std::pair<u64,int>> rq;
    int DEPTH = getenv("DDR_DEPTH") ? atoi(getenv("DDR_DEPTH")) : 8;
    int HOST  = getenv("DDR_HOSTILE") ? atoi(getenv("DDR_HOSTILE")) : 0;
    u64 clk = 0;
    auto tick = [&]() {
        bool cmd = t->s_read || t->s_write, w0 = t->s_write;
        int need = rq.empty() ? LAT : 1;
        bool stall = HOST && ((rand() % 100) < HOST);
        bool accept = cmd && cnt >= need && (w0 || (int)rq.size() < DEPTH) && !stall;
        t->s_waitrequest = accept ? 0 : 1;
        t->clk = 0; t->eval();
        bool isw = t->s_write; u64 key = ((u64)t->s_address) >> 3; u64 wd = t->s_writedata;
        bool rgap = HOST && ((rand() % 100) < HOST);
        t->clk = 1; t->eval(); clk++;
        if (accept && isw) ddr[key] = wd;
        t->s_readdatavalid = 0;
        for (auto& e : rq) if (e.second > 0) e.second--;
        if (!rgap && !rq.empty() && rq.front().second == 0) { auto it = ddr.find(rq.front().first);
            t->s_readdatavalid = 1; t->s_readdata = it != ddr.end() ? it->second : 0xFFFFFFFFFFFFFFFFull; rq.pop_front(); }
        if (accept && !isw) rq.push_back({key, RLAT});
        if (accept) cnt = 0; else if (cmd) cnt++; else cnt = 0;
    };
    for (int i = 0; i < 7; i++) t->rtc[i] = rtc[i];
    for (int i = 0; i < 4; i++) t->in_port[i] = 0xFFFF;
    t->por = 1; t->rst = 1; t->dcs_rst = 1; t->req = 0; t->ioctl_download = 0; t->ioctl_wr = 0; t->ioctl_index = 0;
    t->s_waitrequest = 1; t->s_readdatavalid = 0;
    for (int i = 0; i < 8; i++) tick();
    t->por = 0; tick(); t->rst = 0; tick();
    // ---- A: sound ROM download through zk4_dcs2's own loader (index 3) ----
    t->ioctl_download = 1; t->ioctl_index = 3;
    for (size_t w = 0; w < region.size();) {
        if (t->ioctl_wait) { t->ioctl_wr = 0; tick(); continue; }
        t->ioctl_dout = region[w]; t->ioctl_wr = 1; tick(); t->ioctl_wr = 0; w++;
    }
    t->ioctl_download = 0;
    long dr = 0; while (!t->rom_loaded && dr < 4000000) { tick(); dr++; }
    printf("ROM: %zu words fed, rom_loaded %d after %ld drain clocks, DDR words %zu\n", region.size(), (int)t->rom_loaded, dr, ddr.size());
    if (!t->rom_loaded) { printf("FAIL: sound ROM never loaded\n"); return 1; }
    // ---- B/C: replay ----
    std::map<std::string, u64> n_ok, n_bad; std::map<std::string, int> shown;
    char line[256]; long ln = 0; u64 reads = 0, writes = 0, consume_edges = 0, reply_lead = 0;
    double last_sndout = -1.0, T0 = -1.0, first_lead = -1.0, mame_full_at = -1.0; u64 base = 0;
    while (fgets(line, sizeof line, f)) {
        ln++;
        int fr; char k; unsigned a, d, pc; double tm;
        if (sscanf(line, "%d %c %x %x %x %lf", &fr, &k, &a, &d, &pc, &tm) != 6) continue;
        if (a < 0x8D0000 || a > 0x9FFFFF) continue;
        if (tm > t_end) break;
        bool wr = k == 'W';
        if (T0 < 0 && wr && a == 0x990008) {                        // MAME resets the sound board here
            T0 = tm; base = clk; t->dcs_rst = 0; tick();
            printf("sound-board reset at MAME t %.9f (line %ld): real time from here\n", T0, ln);
        }
        if (T0 >= 0) { u64 due = base + (u64)((tm - T0) * 50e6); while (clk < due) tick(); }
        if (!wr && a >= 0x990000 && a <= 0x990003) t->in_port[a & 3] = d;
        if (wr && a == 0x990009) last_sndout = tm;
        t->req = 1; t->we = wr; t->addr = a; t->wdata = d; tick(); t->req = 0; t->we = 0;
        if (wr) { writes++; continue; }
        t->clk = 0; t->eval();
        if (!t->rvalid) { printf("FAIL: no rvalid for read %06X (line %ld)\n", a, ln); return 1; }
        if (T0 < 0) continue;                                       // fast phase: state only
        reads++;
        u32 got = t->rdata;
        std::string cat = (a >= 0x9F0000 && a <= 0x9F7FFF) ? "cmos" : (a >= 0x8D0000 && a <= 0x8D0009) ? "disk_asic_jr" :
                          (a >= 0x990000 && a <= 0x99000F) ? ("ioasic+" + std::to_string(a & 15)) : "unmapped";
        if (a == 0x99000A && (d & 0x40) && mame_full_at < 0) mame_full_at = tm;
        if (got == d) { n_ok[cat]++; continue; }
        if (a == 0x99000A && ((got ^ d) == 0x80) && (d & 0x7F) == 0x08 && last_sndout >= 0 && tm - last_sndout < 3e-6) {
            consume_edges++; continue;
        }
        if (a == 0x99000A && ((got ^ d) == 0x40) && (got & 0x40)) {  // ours ready, MAME's not yet
            if (first_lead < 0) { first_lead = tm; printf("  reply lead begins MAME t %.6f (%.3f s after the reset)\n", tm, tm - T0); }
            reply_lead++; continue;
        }
        n_bad[cat]++;
        if (shown[cat]++ < 6) printf("  MISMATCH %s line %ld t %.9f (+%.6f s) addr %06X: rtl %08X mame %08X dsp_pc %04X\n",
                                     cat.c_str(), ln, tm, tm - T0, a, got, d, t->dsp_pc);
    }
    u64 bad = 0;
    printf("FABRIC BOARD replay: %ld lines, %llu compared reads, %llu writes, %llu clocks\n", ln,
           (unsigned long long)reads, (unsigned long long)writes, (unsigned long long)clk);
    for (auto& kv : n_ok) printf("  %-14s ok %llu bad %llu\n", kv.first.c_str(), (unsigned long long)kv.second, (unsigned long long)n_bad[kv.first]);
    for (auto& kv : n_bad) { if (!n_ok.count(kv.first)) printf("  %-14s ok 0 bad %llu\n", kv.first.c_str(), (unsigned long long)kv.second); bad += kv.second; }
    printf("  declared: consume edges %llu, reply lead %llu reads (ours ready from %.6f, MAME from %.6f)\n",
           (unsigned long long)consume_edges, (unsigned long long)reply_lead, first_lead, mame_full_at);
    u64 replies = n_ok["ioasic+11"];
    if (T0 < 0) { printf("FAIL: the sound-board reset was never reached\n"); return 1; }
    if (replies < 2) { printf("FAIL: coverage -- only %llu boot replies read and matched (need 0x79 and 0x01)\n", (unsigned long long)replies); return 1; }
    printf("%s: host-visible sound board equal to MAME through the boot handshake (%llu mismatches, %llu replies matched)\n",
           bad ? "FAIL" : "PASS", (unsigned long long)bad, (unsigned long long)replies);
    delete t; return bad ? 1 : 0;
}
