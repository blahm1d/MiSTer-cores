#!/bin/bash
# reboot_regcheck against _tcm/src with a chosen engine. usage: build_rrc_tcm.sh <engine.sv> <out> <mdir>
set -e
cd /mnt/d/deck/fpga/zeus/zeus1/lanes/dcs2-engine/bench
S=${RRC_SRC:-/mnt/d/deck/fpga/zeus/zeus1/lanes/dcs2-engine/fit/zk4_dcs2_20ns_tcm/src}
ENG="$1"; OUT="$2"; MDIR="$3"
rm -rf "$MDIR"
verilator -Wno-WIDTHEXPAND -Wno-WIDTHTRUNC -Wno-UNOPTFLAT -Wno-WIDTH -Wno-CASEINCOMPLETE \
  -Wno-CMPCONST -Wno-UNUSEDSIGNAL -Wno-UNDRIVEN -Wno-TIMESCALEMOD -Wno-PINMISSING \
  --cc "${RRC_ZK4:-$S/zk4_dcs2.sv}" "$ENG" "$S/dcs2_ddr_agent.sv" "${RRC_MBX:-$S/dcs2_mailbox.sv}" \
       "$S/dcs2_sport_dac.sv" "${RRC_SRCC:-$S/dcs2_sram_cache.sv}" "${RRC_AB:-$S/dcs2_autobuf.sv}" \
       "$S/cusa_dcs_rom_loader.sv" "$S/cusa_dcs_fifo.sv" \
  --exe /mnt/h/temp/zeus/dcs2-area/ckpt4o_fix/rrc_be.cpp --build -O2 -o "$OUT" --top-module zk4_dcs2 --public-flat-rw --Mdir "$MDIR" 2>&1 | grep -iE "%Error|error:" | head
echo "BUILD_DONE $OUT"
