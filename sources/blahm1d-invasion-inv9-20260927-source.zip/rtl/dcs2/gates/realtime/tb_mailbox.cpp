// Directed gate: dcs2_mailbox DSP-side ack semantics vs MAME 0.289 DCS2 (auto-ack OFF, dcs.cpp:852):
//   read  0x0400 = input_latch_r (:1555-1563) -> data only, NO ack (m_auto_ack false)
//   write 0x0400 = input_latch_ack_w (:1544-1549) -> SET_INPUT_EMPTY + IRQ2 CLEAR
//   host reset low -> dcs_reset (:543): IRQ2 clear (:582), input empty + output empty (:585-586)
// Firmware sequence reproduced (our PC path == MAME's through the 0x01 reply): the IRQ2 handler reads the
// latch at 0x2b6c and acks it with a DM($0400) write at 0x2bcb, 33 instructions later.
#include "Vdcs2_mailbox.h"
#include "verilated.h"
#include <cstdio>
static Vdcs2_mailbox* d; static long fails = 0;
static void tick() { d->clk = 0; d->eval(); d->clk = 1; d->eval(); }
static void chk(const char* n, bool c) { printf("%-60s %s\n", n, c ? "PASS" : "FAIL"); if (!c) fails++; }
static void dsp(int we, int off, int wd) { d->dm_acc = 1; d->dm_we = we; d->dm_off = off; d->dm_wdata = wd; d->eval(); }
int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv); d = new Vdcs2_mailbox;
    d->rst = 1; d->data_w = 0; d->wdata = 0; d->ack_w = 0; d->data_r = 0; d->reset_w = 0; d->reset_level = 1;
    d->dm_acc = 0; d->dm_we = 0; d->dm_off = 0; d->dm_wdata = 0; tick(); tick(); d->rst = 0; tick();
    // host command 0x649B (cold log 47.306875800 W 990009 0000649B)
    d->data_w = 1; d->wdata = 0x649b; tick(); d->data_w = 0; tick();
    chk("M1 host write -> IRQ2 line high, input not empty", d->irq2_req == 1 && d->input_empty == 0);
    // 0x2b6c: AX = DM($0400)  (read)
    dsp(0, 0, 0); bool rdok = d->dm_rdata == 0x649b; tick(); d->dm_acc = 0; tick();
    chk("M2 DSP read 0x0400 returns 0x649B", rdok);
    chk("M3 after READ: IRQ2 still high, input still FULL (no auto-ack)", d->irq2_req == 1 && d->input_empty == 0);
    for (int i = 0; i < 33 * 3; i++) tick();   // 33 instructions of handler
    chk("M4 33 instr later, before the ack: still pending", d->irq2_req == 1 && d->input_empty == 0);
    // 0x2bcb: DM($0400) = x  (ack write)
    dsp(1, 0, 0x0ec3); tick(); d->dm_acc = 0; d->dm_we = 0; tick();
    chk("M5 after ACK WRITE: IRQ2 low, input empty", d->irq2_req == 0 && d->input_empty == 1);
    // output latch unaffected by the ack; reply write sets output full
    dsp(1, 1, 0x0079); tick(); d->dm_acc = 0; d->dm_we = 0; tick();
    chk("M6 DSP write 0x0401 = 0x79 -> output full, data 0x79", d->output_full == 1 && d->data == 0x0079);
    // host reset low clears the comm bits + IRQ2 (dcs_reset)
    d->data_w = 1; d->wdata = 0x55aa; tick(); d->data_w = 0; tick();
    d->reset_w = 1; d->reset_level = 0; tick(); d->reset_w = 0; tick();
    chk("M7 host reset low: IRQ2 low, input empty, output empty", d->irq2_req == 0 && d->input_empty == 1 && d->output_full == 0);
    printf("MAILBOX directed gate: %s (%ld fail)\n", fails ? "FAIL" : "PASS", fails);
    delete d; return fails ? 1 : 0;
}
