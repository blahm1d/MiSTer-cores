// Reboot-dispatch per-commit REGISTER diff. Runs the whole zk4_dcs2 from power-on (correct memory,
// no seeding), detects the firmware self-reboot (sysctl_wr9), then aligns our first post-reboot PC
// 0x0000 commit with the MAME golden's post-reboot 0x0000 (line 544219) and compares dbg[0..58] vs
// the golden #R block every commit. Reports the FIRST divergent register (index, PC, field, values).
// Golden = the plain-text #R trace (gunzipped). Same masks/field names as dcs2_sys_regcheck.
// Usage: dcs2_reboot_regcheck <golden.tr> <compact.bin> [feed] [LAT] [RLAT] [maxcyc]
#include "Vzk4_dcs2.h"
#include "Vzk4_dcs2___024root.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <array>
#include <unordered_map>
#include <deque>
#include <utility>

static const int NF=59;
static uint32_t MASK[NF];
static void init_mask(){
  for(int i=0;i<NF;i++) MASK[i]=0xffffffff;
  MASK[0]=0x3fff; for(int i=1;i<=19;i++) MASK[i]=0xffff;
  MASK[13]=0xff; MASK[16]=0xff; MASK[17]=0x1f;
  for(int i=20;i<=43;i++) MASK[i]=0x3fff;
  MASK[44]=0xff; MASK[45]=0x3fff; MASK[46]=0xff; MASK[47]=0x7f; MASK[48]=0xff; MASK[49]=0x7f; MASK[50]=0x1f;
  MASK[51]=0xff; MASK[52]=0xf; MASK[53]=0xf; MASK[54]=0xf; for(int i=55;i<59;i++) MASK[i]=0;
}
static const char* FN[NF]={"pc","ax0","ax1","ay0","ay1","ar","af","mx0","mx1","my0","my1","mr0","mr1","mr2","mf",
 "si","se","sb","sr0","sr1","i0","i1","i2","i3","i4","i5","i6","i7","m0","m1","m2","m3","m4","m5","m6","m7",
 "l0","l1","l2","l3","l4","l5","l6","l7","px","cntr","astat","mstat","sstat","imask","icntl","pcsp","cntrsp","statsp","loopsp","irq0","irq1","irq2","irq3"};

int main(int argc,char**argv){
  Verilated::commandArgs(argc,argv);
  if(argc<3){ fprintf(stderr,"usage: dcs2_reboot_regcheck <golden.tr> <compact.bin> [feed] [LAT] [RLAT] [maxcyc]\n"); return 2; }
  long feed=argc>3?atol(argv[3]):65536; int LAT=argc>4?atoi(argv[4]):12, RLAT=argc>5?atoi(argv[5]):20;
  long maxcyc=argc>6?atol(argv[6]):120000000L;
  init_mask();
  if(getenv("PCONLY")){ for(int i=1;i<NF;i++) MASK[i]=0; }   // compare PC only (isolate control-flow divergence)
  // ignore specific context regs carried from before the golden window (set pre-frame-2503):
  if(getenv("IGN_CTX")){ int ig[]={9,10,16,20,24}; for(int x:ig) MASK[x]=0; } // my0,my1,se,i0,i4
  // parse the golden .tr; store records from the reboot (pc==0x54 & ax0==0x208 -> next 0x0000) onward.
  std::vector<std::array<uint32_t,NF>> G;
  { FILE*f=fopen(argv[1],"r"); if(!f){perror("golden");return 2;}
    char*line=nullptr; size_t cap=0; ssize_t len; bool sawreboot=false, storing=false; long ln=0;
    while((len=getline(&line,&cap,f))>=0){ ln++;
      if(line[0]!='#'||line[1]!='R') continue;
      std::array<uint32_t,NF> r; char*p=line+2; int j=0;
      for(;j<NF;j++){ r[j]=(uint32_t)strtoul(p,&p,16); }
      if(!storing){
        if(!sawreboot && (r[0]&0x3fff)==0x54 && (r[1]&0xffff)==0x208) sawreboot=true;
        else if(sawreboot && (r[0]&0x3fff)==0x0000){ storing=true; }
      }
      if(storing) G.push_back(r);
    }
    fclose(f); if(line) free(line);
  }
  printf("golden post-reboot records: %zu (first pc=%04x)\n", G.size(), G.empty()?0xffff:(G[0][0]&0x3fff));
  if(G.empty()){ printf("NO REBOOT FOUND IN GOLDEN\n"); return 2; }

  std::vector<uint16_t> rom; { FILE*f=fopen(argv[2],"rb"); if(!f){perror("rom");return 2;} fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET); rom.resize(n/2); if(fread(rom.data(),2,rom.size(),f)!=rom.size()){} fclose(f);}
  if((long)rom.size()<feed) feed=rom.size();

  Vzk4_dcs2* dut=new Vzk4_dcs2; auto& root=*dut->rootp;
  std::unordered_map<uint64_t,uint64_t> ddr;
  // multi-outstanding in-order DDR model: first read opens the row (LAT), pipelined after (1 clk),
  // up to DEPTH outstanding, data RLAT clocks after acceptance, returned in issue order. Represents
  // arb3+DDR3 pipelined reads (vs the old single-outstanding stand-in). Hostile knobs: DDR_DEPTH,
  // DDR_HOSTILE (percent of cycles that stall acceptance = ARM/renderer contention).
  long cnt=0; std::deque<std::pair<uint64_t,int>> rq;
  int DEPTH=getenv("DDR_DEPTH")?atoi(getenv("DDR_DEPTH")):8;
  int HOST =getenv("DDR_HOSTILE")?atoi(getenv("DDR_HOSTILE")):0;
  int OVL  =getenv("OVL")?1:0;   // level-detect commit for the overlap engine (consecutive commits)
  auto tick=[&](){
    bool c0=dut->s_read||dut->s_write, w0=dut->s_write;
    int need=rq.empty()?LAT:1;
    bool stall = HOST && ((rand()%100)<HOST);
    bool canacc = c0 && cnt>=need && (w0 || (int)rq.size()<DEPTH) && !stall;
    dut->s_waitrequest = canacc?0:1; dut->eval();
    bool cmd=dut->s_read||dut->s_write; bool w=dut->s_write; bool acc=canacc;
    uint64_t k=((uint64_t)dut->s_address)>>3, wd=dut->s_writedata; unsigned be=dut->s_byteenable;
    dut->clk=1; dut->eval();
    bool rgap = HOST && ((rand()%100) < HOST);   // random readdatavalid gap (bursty returns stress the FIFO)
    if(acc && w){ uint64_t m=0; for(int b=0;b<8;b++) if(be>>b&1) m|=0xFFull<<(8*b);   // honour byte enables (arb3 passes them)
      auto it=ddr.find(k); uint64_t old=it!=ddr.end()?it->second:~0ULL; ddr[k]=(old&~m)|(wd&m); }
    { static long mclk=0; static uint64_t lastk=~0ULL; static int infill=0; mclk++;
      int flr=(int)root.zk4_dcs2__DOT__fl_req;
      if(acc && !w && flr){                       // a FILL read
        if(getenv("BURSTLOG")){
          bool newfill = !infill;                 // first fill read after (re)start
          const char* flag = newfill? "START" : (k==lastk)?"DUP" : (k!=lastk+1)?"NONSEQ" : "";
          if(flag[0]) fprintf(stderr,"[fill] mclk=%ld beat=%llx last=%llx outst=%d %s\n",mclk,
            (unsigned long long)k,(unsigned long long)lastk,(int)root.zk4_dcs2__DOT__u_ddr__DOT__fl_outst,flag);
        }
        lastk=k; infill=1;
      } else if(!flr) infill=0; }
    dut->s_readdatavalid=0;
    for(auto&e:rq) if(e.second>0) e.second--;
    if(!rgap && !rq.empty() && rq.front().second==0){ auto it=ddr.find(rq.front().first);
      dut->s_readdatavalid=1; dut->s_readdata=it!=ddr.end()?it->second:~0ULL; rq.pop_front(); }
    if(acc && !w) rq.push_back({k,RLAT});
    if(acc) cnt=0; else if(cmd) cnt++; else cnt=0;
    dut->clk=0; dut->eval();
  };
  dut->clk=0; dut->por=1; dut->rst=1; dut->reset_level=1; dut->data_w=0; dut->wdata=0; dut->ack_w=0; dut->data_r=0; dut->reset_w=0;
  dut->ioctl_download=0; dut->ioctl_wr=0; dut->ioctl_index=0; dut->ioctl_dout=0; dut->s_waitrequest=1; dut->s_readdatavalid=0; dut->s_readdata=0; dut->eval();
  for(int i=0;i<8;i++) tick(); dut->por=0;
  dut->ioctl_download=1; dut->ioctl_index=3; long w=0;
  while(w<feed){ if(dut->ioctl_wait){dut->ioctl_wr=0;tick();continue;} dut->ioctl_dout=rom[w]; dut->ioctl_wr=1; tick(); dut->ioctl_wr=0; w++; }
  dut->ioctl_download=0; dut->ioctl_wr=0; long dr=0; while(!dut->rom_loaded&&dr<5000000){tick();dr++;}
  dut->rst=0;

  if(getenv("DDR_CHK")){
    for(uint32_t off=0x2440; off<=0x2460; off+=8){ uint64_t k=((uint64_t)(0x31000000u+off))>>3; auto it=ddr.find(k);
      printf("  [ddrchk] byte-off %04x word=%016llx %s\n", off, (unsigned long long)(it!=ddr.end()?it->second:0), it!=ddr.end()?"":"(MISSING)"); }
  }
  long cyc=0; bool prev=false; bool rebooted=false, aligned=false; long gi=0, matched=0, firstdiv=-1;
  while(cyc<maxcyc){
    tick(); cyc++;
    if(getenv("WDBG") && cyc>=70072610 && cyc<70085000 && (cyc%1500==0))
      printf("[wdbg] cyc=%ld eng_rst=%d warm=%d ax0=%x needs_reboot=%d boot_st=%d\n", cyc,
        (int)root.zk4_dcs2__DOT__eng_rst, (int)root.zk4_dcs2__DOT__warm_reset, root.zk4_dcs2__DOT__e_dbg.at(1)&0xffff,
        (int)root.zk4_dcs2__DOT__needs_reboot, (int)root.zk4_dcs2__DOT__boot_st);
    if(root.zk4_dcs2__DOT__sysctl_wr9 && !rebooted){ rebooted=true; printf("[dbg] reboot detected at cyc=%ld eng_rst=%d warm=%d ax0=%x\n", cyc, (int)root.zk4_dcs2__DOT__eng_rst,(int)root.zk4_dcs2__DOT__warm_reset, root.zk4_dcs2__DOT__e_dbg.at(1)&0xffff); }
    bool c = root.zk4_dcs2__DOT__e_commit;
    if(c && (OVL||!prev)){   // OVL: ckpt4o overlap engine asserts commit on consecutive cycles -> level-detect
      uint16_t pc = root.zk4_dcs2__DOT__e_dbg.at(0) & 0x3fff;
      if(rebooted && !aligned){
        static int pr=0; if(pr<12){ printf("[dbg] post-reboot commit pc=%04x cyc=%ld\n", pc, cyc); pr++; }
        // my e_dbg = state AFTER the instr (post-advance pc); golden #R = state BEFORE. So my commit
        // for the reset JUMP $0039 (dbg pc=0x0039, regs after) aligns with golden record 0x0039 (G[1],
        // regs before 0x0039 = after the JUMP). Skip the 0x55 blip; align at the first pc==0x0039.
        if(pc==0x0039){ aligned=true; gi=1; printf("[dbg] ALIGNED my pc=0x0039 -> G[1] (pc=%04x), cyc=%ld\n", G[1][0]&0x3fff, cyc); }
      }
      if(aligned){
        if(gi>=(long)G.size()){ printf("golden exhausted at match %ld (pc=%04x)\n", matched, pc); break; }
        for(int j=0;j<NF;j++){
          uint32_t cv=(root.zk4_dcs2__DOT__e_dbg.at(j))&MASK[j], gv=G[gi][j]&MASK[j];
          if(cv!=gv){
            printf("REG-DIVERGENCE @post-reboot instr %ld (golden line %ld, pc golden=%04x dut=%04x): first field %s dut=%x golden=%x\n",
                   matched, gi, G[gi][0]&0x3fff, pc, FN[j], cv, gv);
            printf("  ALL differing fields:");
            for(int k=0;k<NF;k++){ uint32_t a=(root.zk4_dcs2__DOT__e_dbg.at(k))&MASK[k], b=G[gi][k]&MASK[k]; if(a!=b) printf(" %s(dut=%x,gold=%x)", FN[k], a, b); }
            printf("\n");
            firstdiv=matched; break;
          }
        }
        if(firstdiv>=0) break;
        matched++; gi++;
        if((matched%20000)==0) printf("  [regcheck] %ld post-reboot instr matched (gi=%ld pc=%04x cyc=%ld)\n", matched, gi, pc, cyc);
        static bool ann=false; if(!ann && (G[gi-1][0]&0x3fff)==0x2800){ printf("reached 0x2800 (main program) after %ld matched (pc-only=%d)\n", matched, getenv("PCONLY")?1:0); ann=true; if(!getenv("NOBREAK")) break; }
      }
    }
    prev=c;
  }
  printf("REBOOT-REGCHECK: matched %ld post-reboot instructions%s, cyc=%ld\n", matched, firstdiv>=0?" (DIVERGED)":"", cyc);
  delete dut; return firstdiv>=0?1:0;
}
