// COMBINED HOST CHECK for the fabric DCS2: MAME 0.289's cold-boot device log is replayed into zk4_board_io wired to the
// REAL zk4_dcs2 sound board (zk4_board_fabric_bench.sv), which boots from the real MK4 sound ROM served by a hostile
// DDR model. MAME resets the sound board at the first 0x990008 write (43.164 s in the cold log) and its host then reads
// the boot replies 0x79 / 0x01 (47.1186 s / 47.2598 s). Before that write the log is replayed FAST (board state only,
// sound board held in reset, nothing compared); from it on, in MAME time (x 50 MHz), with every read compared:
//   * SOUNDIN (0x99000B, the reply data the game waits on) and every non-sound read: EXACT, no exception.
//   * SOUNDSTAT (0x99000A): exact, except two declared, counted and listed timing classes --
//       consume edge : input-empty (0x80) lags within 3 us of a SOUNDOUT write (as in the stand-in gate);
//       reply lead   : output-full (0x40) already set here while MAME's is not yet (our DSP retires ~25 MIPS vs MAME's
//                      16, so its reply is READY earlier; it must never be LATER -- that is a failure).
//   * coverage: both boot replies must have been read and matched, else FAIL.
// usage: tb_zk4_board_fabric <devices.log> "<rtc 7 hex>" <region_le16.bin> [t_end=47.40] [LAT=12] [RLAT=20]
#include "Vzk4_board_fabric_bench.h"
#include "Vzk4_board_fabric_bench___024root.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include <unordered_map>
#include <deque>
#include <utility>
typedef uint64_t u64; typedef uint32_t u32;

int main(int argc, char** argv) {
    if (argc < 4) { printf("usage: tb_zk4_board_fabric <devices.log> \"rtc\" <region_le16.bin> [t_end] [LAT] [RLAT]\n"); return 2; }
    FILE* f = fopen(argv[1], "r"); if (!f) { printf("FAIL: cannot open %s\n", argv[1]); return 2; }
    unsigned rtc[7]; if (sscanf(argv[2], "%x %x %x %x %x %x %x", &rtc[0], &rtc[1], &rtc[2], &rtc[3], &rtc[4], &rtc[5], &rtc[6]) != 7) return 2;
    std::vector<uint16_t> region; { FILE* r = fopen(argv[3], "rb"); if (!r) { printf("FAIL: region\n"); return 2; }
        fseek(r, 0, SEEK_END); long n = ftell(r); fseek(r, 0, SEEK_SET); region.resize(n / 2);
        if (fread(region.data(), 2, region.size(), r) != region.size()) {} fclose(r); }
    double t_end = argc > 4 ? atof(argv[4]) : 47.40;
    int LAT = argc > 5 ? atoi(argv[5]) : 12, RLAT = argc > 6 ? atoi(argv[6]) : 20;
    Verilated::commandArgs(argc, argv);
    Vzk4_board_fabric_bench* t = new Vzk4_board_fabric_bench;
    auto& R = *t->rootp;
    #define DSP(sig) R.zk4_board_fabric_bench__DOT__u_dcs2__DOT__##sig
    // ---- ACCT: per-clock activity accounting over the reboot->reply window (set from T0) ----
    bool acct = false;
    u64 a_clks=0, a_commit=0, a_ddr=0, a_dm=0, a_pm=0, a_compute=0, a_idle=0;
    u64 a_pffill=0, a_irq=0;              // clocks with a page-fill in progress / irq-ack pulses
    u64 pm_tcm=0, pm_int=0, pm_sram=0, pm_oob=0;   // PM accesses started, by region
    u64 dm_rom=0, dm_sram=0, dm_iram=0, dm_oth=0;  // DM accesses started, by hit type
    u64 pm_lat=0, pm_n=0, dm_lat=0, dm_n=0, pm_maxl=0, dm_maxl=0;
    u64 pm_lat_t[4]={0,0,0,0}, pm_n_t[4]={0,0,0,0};   // PM latency split: 0=tcm 1=int 2=pmc 3=oob
    u64 dm_lat_t[4]={0,0,0,0}, dm_n_t[4]={0,0,0,0};   // DM latency split: 0=rom 1=sram(dmc) 2=iram 3=oth
    int pm_type=0, dm_type=0;
    bool pm_act=false; u64 pm_st=0; bool dm_act=false; u64 dm_st=0; int last_pfst=0;
    std::deque<std::string> t2ring;   // TRACE2 ring buffer (last N host-region request lines)
    uint16_t maxpc_seen=0;            // highest committed PC after the sound reset
    u64 n009b=0;                      // COLDGATE: commits in the 009B PM-clear DO-loop (one pass ~14336)
    // ---- DDR model: multi-outstanding in-order (pipelined arb3+DDR3). First read opens the row (LAT),
    //      pipelined after (1 clk), up to DEPTH outstanding, data RLAT clks after accept, in issue order.
    //      Hostile knobs: DDR_DEPTH, DDR_HOSTILE (percent of cycles that stall acceptance). ----
    std::unordered_map<u64, u64> ddr; long cnt = 0; std::deque<std::pair<u64,int>> rq;
    int DEPTH = getenv("DDR_DEPTH")?atoi(getenv("DDR_DEPTH")):8;
    int HOST  = getenv("DDR_HOSTILE")?atoi(getenv("DDR_HOSTILE")):0;
    u64 clk = 0;
    auto tick = [&]() {
        bool cmd = t->s_read || t->s_write, w0 = t->s_write;
        int need = rq.empty()?LAT:1;
        bool stall = HOST && ((rand()%100)<HOST);
        bool accept = cmd && cnt>=need && (w0 || (int)rq.size()<DEPTH) && !stall;
        t->s_waitrequest = accept ? 0 : 1;
        t->clk = 0; t->eval();
        bool isw = t->s_write; u64 key = ((u64)t->s_address) >> 3; u64 wd = t->s_writedata;
        t->clk = 1; t->eval(); clk++;
        if (accept && isw) ddr[key] = wd;
        t->s_readdatavalid = 0;
        for (auto& e : rq) if (e.second>0) e.second--;
        if (!rq.empty() && rq.front().second==0) { auto it=ddr.find(rq.front().first);
            t->s_readdatavalid=1; t->s_readdata= it!=ddr.end()?it->second:0xFFFFFFFFFFFFFFFFull; rq.pop_front(); }
        if (accept && !isw) rq.push_back({key,RLAT});
        if (accept) cnt=0; else if (cmd) cnt++; else cnt=0;
        if (acct) {
            a_clks++;
            bool ddrb = t->s_read || t->s_write;
            bool dmb  = DSP(dm_busy);
            bool pmb  = DSP(pm_busy);
            bool com  = DSP(e_commit);
            int  pfst = DSP(pf_st);
            // TRACE: committed-PC + memory-request stream after the sound reset (find the cold-boot spin
            // divergence: ckpt4o loops at 0x009x while v3d passes through). Env TRACE=N limits to N commits.
            if (getenv("TRACE")) { static long tl=0; long TL=atol(getenv("TRACE"));
                if (com && tl<TL) { uint16_t pc=t->dsp_pc&0x3fff;
                    bool dmr=DSP(e_dm_rd)&&DSP(e_dm_ready), dmw=DSP(e_dm_wr)&&DSP(e_dm_ready);
                    fprintf(stderr,"%ld pc=%04x%s%s dm=%04x rd=%04x wr=%06x\n", tl, pc,
                        dmr?" DMR":"", dmw?" DMW":"", DSP(e_dm_addr)&0x3fff, DSP(e_dm_rdata)&0xffff, DSP(e_dm_wdata)&0xffffff);
                    tl++; } }
            // TRACE2: per-clock PM/DM request trace in the host-handshake region 0x0040-0x0095 (catch a
            // double host-latch read PM(I4,M4) at 0x0043 that double-advances I4). Env TRACE2=N lines.
            if (getenv("TRACE2")) { long T2=atol(getenv("TRACE2")); uint16_t pc=t->dsp_pc&0x3fff;
                unsigned lo=getenv("TR_LO")?strtoul(getenv("TR_LO"),0,16):0x0040;
                unsigned hi=getenv("TR_HI")?strtoul(getenv("TR_HI"),0,16):0x0095;
                if (pc>=lo && pc<=hi) {
                    bool pr=DSP(e_pm_rd), pw=DSP(e_pm_wr), dr=DSP(e_dm_rd), dw=DSP(e_dm_wr);
                    if (pr||pw||dr||dw) { char b[192];
                        snprintf(b,sizeof b,"pc=%04x %s%s%s%s pma=%04x pmrd=%06x dma=%04x pmrdy=%d dmrdy=%d dmrd=%04x com=%d",
                        pc, pr?"PR":"", pw?"PW":"", dr?"DR":"", dw?"DW":"", DSP(e_pm_addr)&0x3fff, DSP(e_pm_rdata)&0xffffff, DSP(e_dm_addr)&0x3fff,
                        (int)DSP(e_pm_ready), (int)DSP(e_dm_ready), DSP(e_dm_rdata)&0xffff, (int)com);
                        t2ring.push_back(b); if ((long)t2ring.size()>T2) t2ring.pop_front(); } } }
            if (getenv("CYC_LO")) { u64 lo=strtoull(getenv("CYC_LO"),0,10), hi=strtoull(getenv("CYC_HI"),0,10);
                if (clk>=lo && clk<=hi) fprintf(stderr,"C clk=%llu st=%d pc=%04x ppc=%04x pm_rd=%d pm_a=%04x rdy=%d rdata=%06x take=%d idx=%d lat=%d com=%d ack=%d opr=%06x pcsp=%d top=%04x\n",
                    (unsigned long long)clk,(int)DSP(u_eng__DOT__st),(int)DSP(u_eng__DOT__pc),(int)DSP(u_eng__DOT__ppc),(int)DSP(e_pm_rd),(int)DSP(e_pm_addr),
                    (int)DSP(e_pm_ready),(int)DSP(e_pm_rdata),(int)DSP(e_irq_take),(int)DSP(e_irq_indx),0,(int)DSP(e_commit),(int)DSP(e_irq_ack),
                    (int)DSP(u_eng__DOT__opr),(int)DSP(u_eng__DOT__pcsp),(int)DSP(u_eng__DOT__pcst)[(DSP(u_eng__DOT__pcsp)-1)&15]); }
            if (getenv("CYC_LO")) { u64 lo=strtoull(getenv("CYC_LO"),0,10), hi=strtoull(getenv("CYC_HI"),0,10);
                if (clk>=lo && clk<=hi) fprintf(stderr,"D clk=%llu dm_rd=%d dm_wr=%d dm_a=%04x dm_rdy=%d dm_busy=%d romhit=%d sramhit=%d rwv=%d rwpg=%x epm=%x pf=%d flb=%d dmc_req=%d rom_pend=%d sv=%d sa=%04x\n",
                    (unsigned long long)clk,(int)DSP(e_dm_rd),(int)DSP(e_dm_wr),(int)DSP(e_dm_addr),(int)DSP(e_dm_ready),(int)DSP(dm_busy),(int)DSP(dm_rom_hit),
                    (int)DSP(dm_sram_hit),(int)DSP(romwin_valid),(int)DSP(romwin_pg),(int)(DSP(sdrc2)&0x1fff),(int)DSP(pf_st),(int)DSP(fl_busy_w),(int)DSP(dmc_req),
                    (int)DSP(dm_rom_pend),(int)DSP(dm_sv),(int)DSP(dm_sa)); }
            if (getenv("MW_LO")) { u64 lo=strtoull(getenv("MW_LO"),0,10), hi=strtoull(getenv("MW_HI"),0,10); static int pdst=-1, ppst=-1;
                int dst=DSP(u_dmc__DOT__st), pst=DSP(u_pmc__DOT__st);
                if (clk>=lo && clk<=hi && (DSP(c_req)||DSP(c_ack)||DSP(c_rvalid)||dst!=pdst||pst!=ppst))
                    fprintf(stderr,"W clk=%llu dmc_st=%d pmc_st=%d bt=%d pmcq=%d dmcq=%d c_req=%d c_we=%d can=%d c_ack=%d c_rv=%d cown=%d rown=%d ag=%d own_dac=%d\n",
                    (unsigned long long)clk,dst,pst,(int)DSP(bt_req),(int)DSP(pmc_mreq),(int)DSP(dmc_mreq),(int)DSP(c_req),(int)DSP(c_we),(int)DSP(c_can_accept),
                    (int)DSP(c_ack),(int)DSP(c_rvalid),(int)DSP(cmd_owner),(int)DSP(rd_owner),(int)DSP(u_ddr__DOT__st),(int)DSP(cc_own_dac));
                pdst=dst; ppst=pst; }
            if (getenv("CYC_LO")) { u64 lo=strtoull(getenv("CYC_LO"),0,10), hi=strtoull(getenv("CYC_HI"),0,10);
                if (clk>=lo && clk<=hi) fprintf(stderr,"M clk=%llu esd=%d ccb=%d own_dac=%d dac_rd=%d cc_req=%d cc_rdy=%d dmc_st=%d dmc_mreq=%d pmc_mreq=%d bt_req=%d c_req=%d can=%d cown=%d rown=%d ag_st=%d s_rd=%d s_wr=%d\n",
                    (unsigned long long)clk,(int)DSP(esd_hold),(int)DSP(cc_busy),(int)DSP(cc_own_dac),(int)DSP(dac_rd),(int)DSP(cc_req),(int)DSP(cc_ready),
                    (int)DSP(u_dmc__DOT__st),(int)DSP(dmc_mreq),(int)DSP(pmc_mreq),(int)DSP(bt_req),(int)DSP(c_req),(int)DSP(c_can_accept),(int)DSP(cmd_owner),(int)DSP(rd_owner),
                    (int)DSP(u_ddr__DOT__st),(int)t->s_read,(int)t->s_write); }
            if (getenv("EVT")) { static long ek=0; static int prst=-1, pw9=0; static uint16_t ppc=0xffff;
                uint16_t pc=t->dsp_pc&0x3fff; int er=DSP(eng_rst), w9=DSP(sysctl_wr9);
                if (er!=prst) { fprintf(stderr,"E k=%ld clk=%llu ENG_RST=%d pc=%04x\n",ek,(unsigned long long)clk,er,pc); prst=er; }
                if (w9 && !pw9) fprintf(stderr,"E k=%ld clk=%llu SYSCTL_BIT9 pc=%04x\n",ek,(unsigned long long)clk,pc); pw9=w9;
                if (DSP(e_irq_ack)) fprintf(stderr,"E k=%ld clk=%llu IRQ idx=%d pc=%04x\n",ek,(unsigned long long)clk,(int)DSP(e_irq_ack_indx),pc);
                if (DSP(e_dm_ready)) { unsigned a=DSP(e_dm_addr)&0x3fff;
                    if ((a>=0x400&&a<=0x407)||(a>=0x480&&a<=0x483)||(a>=0x3fe0)) fprintf(stderr,"E k=%ld clk=%llu DM%s a=%04x d=%04x pc=%04x\n",ek,
                        (unsigned long long)clk, DSP(e_dm_wr)?"W":"R", a, DSP(e_dm_wr)?(DSP(e_dm_wdata)&0xffff):(DSP(e_dm_rdata)&0xffff), pc); }
                if (com) { if (getenv("EVTPC") || (pc<0x200) != (ppc<0x200)) fprintf(stderr,"E k=%ld clk=%llu PC %04x -> %04x\n",ek,(unsigned long long)clk,ppc,pc);
                    ppc=pc; ek++; } }
            if (com) { a_commit++; uint16_t p=t->dsp_pc&0x3fff; if (p>maxpc_seen) maxpc_seen=p;
                       if (p>=0x0098 && p<=0x00a2) n009b++; }
            if (pfst) a_pffill++;
            if (DSP(e_irq_ack)) a_irq++;
            // exclusive attribution, priority ddr > dm > pm > compute > idle
            if (ddrb) a_ddr++; else if (dmb) a_dm++; else if (pmb) a_pm++; else if (com) a_compute++; else a_idle++;
            // PM access start -> region classify + latency
            bool pmrd = DSP(e_pm_rd) || DSP(e_pm_wr);
            if (pmrd && !pm_act) { pm_act=true; pm_st=clk; unsigned pa = DSP(e_pm_addr) & 0x3fff;
                if      (((pa>>11)&7)==5)               { pm_tcm++;  pm_type=0; }
                else if (pa < 0x200)                    { pm_int++;  pm_type=1; }
                else if (pa>=0x800 && pa<=0x3fff)       { pm_sram++; pm_type=2; }
                else                                    { pm_oob++;  pm_type=3; } }
            if (pm_act && DSP(e_pm_ready)) { u64 L=clk-pm_st+1; pm_lat+=L; pm_n++; if(L>pm_maxl)pm_maxl=L;
                pm_lat_t[pm_type]+=L; pm_n_t[pm_type]++; pm_act=false; }
            // DM access start -> hit-type classify + latency
            bool dmrd = DSP(e_dm_rd) || DSP(e_dm_wr);
            if (dmrd && !dm_act) { dm_act=true; dm_st=clk;
                if      (DSP(dm_rom_hit))  { dm_rom++;  dm_type=0; }
                else if (DSP(dm_sram_hit)) { dm_sram++; dm_type=1; }
                else if (DSP(dm_iram_hit)) { dm_iram++; dm_type=2; }
                else                       { dm_oth++;  dm_type=3; } }
            if (dm_act && DSP(e_dm_ready)) { u64 L=clk-dm_st+1; dm_lat+=L; dm_n++; if(L>dm_maxl)dm_maxl=L;
                dm_lat_t[dm_type]+=L; dm_n_t[dm_type]++; dm_act=false; }
            last_pfst = pfst;
        }
    };
    for (int i = 0; i < 7; i++) t->rtc[i] = rtc[i];
    for (int i = 0; i < 4; i++) t->in_port[i] = 0xFFFF;
    t->por = 1; t->rst = 1; t->dcs_rst = 1; t->req = 0; t->ioctl_download = 0; t->ioctl_wr = 0; t->ioctl_index = 0;
    t->s_waitrequest = 1; t->s_readdatavalid = 0;
    for (int i = 0; i < 8; i++) tick();
    t->por = 0; tick(); t->rst = 0; tick();
    // ---- A: sound ROM download through zk4_dcs2's own loader (index 3) ----
    t->ioctl_download = 1; t->ioctl_index = 3;
    for (size_t w = 0; w < region.size();) {
        if (t->ioctl_wait) { t->ioctl_wr = 0; tick(); continue; }
        t->ioctl_dout = region[w]; t->ioctl_wr = 1; tick(); t->ioctl_wr = 0; w++;
    }
    t->ioctl_download = 0;
    long dr = 0; while (!t->rom_loaded && dr < 4000000) { tick(); dr++; }
    printf("ROM: %zu words fed, rom_loaded %d after %ld drain clocks, DDR words %zu\n", region.size(), (int)t->rom_loaded, dr, ddr.size());
    if (!t->rom_loaded) { printf("FAIL: sound ROM never loaded\n"); return 1; }
    // ---- B/C: replay ----
    std::map<std::string, u64> n_ok, n_bad; std::map<std::string, int> shown;
    char line[256]; long ln = 0; u64 reads = 0, writes = 0, consume_edges = 0, reply_lead = 0;
    double last_sndout = -1.0, T0 = -1.0, first_lead = -1.0, mame_full_at = -1.0; u64 base = 0;
    while (fgets(line, sizeof line, f)) {
        ln++;
        int fr; char k; unsigned a, d, pc; double tm;
        if (sscanf(line, "%d %c %x %x %x %lf", &fr, &k, &a, &d, &pc, &tm) != 6) continue;
        if (a < 0x8D0000 || a > 0x9FFFFF) continue;
        if (tm > t_end) break;
        bool wr = k == 'W';
        if (T0 < 0 && wr && a == 0x990008) {                        // MAME resets the sound board here
            T0 = tm; base = clk; t->dcs_rst = 0; acct = true; tick();
            printf("sound-board reset at MAME t %.9f (line %ld): real time from here\n", T0, ln);
        }
        if (T0 >= 0) { u64 due = base + (u64)((tm - T0) * 50e6); while (clk < due) tick(); }
        if (!wr && a >= 0x990000 && a <= 0x990003) t->in_port[a & 3] = d;
        if (wr && a == 0x990009) last_sndout = tm;
        t->req = 1; t->we = wr; t->addr = a; t->wdata = d; tick(); t->req = 0; t->we = 0;
        if (wr) { writes++; continue; }
        t->clk = 0; t->eval();
        if (!t->rvalid) { printf("FAIL: no rvalid for read %06X (line %ld)\n", a, ln); return 1; }
        if (T0 < 0) continue;                                       // fast phase: state only
        reads++;
        u32 got = t->rdata;
        std::string cat = (a >= 0x9F0000 && a <= 0x9F7FFF) ? "cmos" : (a >= 0x8D0000 && a <= 0x8D0009) ? "disk_asic_jr" :
                          (a >= 0x990000 && a <= 0x99000F) ? ("ioasic+" + std::to_string(a & 15)) : "unmapped";
        if (a == 0x99000A && (d & 0x40) && mame_full_at < 0) mame_full_at = tm;
        if (got == d) { n_ok[cat]++; continue; }
        if (a == 0x99000A && ((got ^ d) == 0x80) && (d & 0x7F) == 0x08 && last_sndout >= 0 && tm - last_sndout < 3e-6) {
            consume_edges++; continue;
        }
        if (a == 0x99000A && ((got ^ d) == 0x40) && (got & 0x40)) {  // ours ready, MAME's not yet
            if (first_lead < 0) { first_lead = tm; printf("  reply lead begins MAME t %.6f (%.3f s after the reset)\n", tm, tm - T0); }
            reply_lead++; continue;
        }
        n_bad[cat]++;
        if (shown[cat]++ < 6) printf("  MISMATCH %s line %ld t %.9f (+%.6f s) addr %06X: rtl %08X mame %08X dsp_pc %04X\n",
                                     cat.c_str(), ln, tm, tm - T0, a, got, d, t->dsp_pc);
    }
    u64 bad = 0;
    printf("FABRIC BOARD replay: %ld lines, %llu compared reads, %llu writes, %llu clocks\n", ln,
           (unsigned long long)reads, (unsigned long long)writes, (unsigned long long)clk);
    for (auto& kv : n_ok) printf("  %-14s ok %llu bad %llu\n", kv.first.c_str(), (unsigned long long)kv.second, (unsigned long long)n_bad[kv.first]);
    for (auto& kv : n_bad) { if (!n_ok.count(kv.first)) printf("  %-14s ok 0 bad %llu\n", kv.first.c_str(), (unsigned long long)kv.second); bad += kv.second; }
    printf("  declared: consume edges %llu, reply lead %llu reads (ours ready from %.6f, MAME from %.6f)\n",
           (unsigned long long)consume_edges, (unsigned long long)reply_lead, first_lead, mame_full_at);
    if (acct && a_clks) {
        double c = (double)a_clks;
        printf("==== ACCT reboot->replay window: %llu clocks, %llu commits, CPI %.3f, MIPS@50 %.2f ====\n",
               (unsigned long long)a_clks, (unsigned long long)a_commit,
               a_commit? c/a_commit : 0.0, a_commit? 50.0*a_commit/c : 0.0);
        printf("  exclusive clock split (priority ddr>dm>pm>compute>idle):\n");
        printf("    DDR-agent (s_read/write)  %12llu  %5.1f%%\n", (unsigned long long)a_ddr,     100*a_ddr/c);
        printf("    DM busy (non-DDR)         %12llu  %5.1f%%\n", (unsigned long long)a_dm,      100*a_dm/c);
        printf("    PM fetch busy             %12llu  %5.1f%%\n", (unsigned long long)a_pm,      100*a_pm/c);
        printf("    compute (commit, no mem)  %12llu  %5.1f%%\n", (unsigned long long)a_compute, 100*a_compute/c);
        printf("    idle/stall (no activity)  %12llu  %5.1f%%\n", (unsigned long long)a_idle,    100*a_idle/c);
        printf("  overlap markers: page-fill-in-progress %llu (%.1f%%), irq-acks %llu\n",
               (unsigned long long)a_pffill, 100.0*a_pffill/c, (unsigned long long)a_irq);
        printf("  PM accesses %llu: tcm %llu / int %llu / sram(pmc) %llu / oob %llu; avg lat %.2f max %llu\n",
               (unsigned long long)pm_n, (unsigned long long)pm_tcm, (unsigned long long)pm_int,
               (unsigned long long)pm_sram, (unsigned long long)pm_oob, pm_n? (double)pm_lat/pm_n:0.0, (unsigned long long)pm_maxl);
        printf("  DM accesses %llu: rom-window %llu / sram %llu / iram %llu / oth %llu; avg lat %.2f max %llu\n",
               (unsigned long long)dm_n, (unsigned long long)dm_rom, (unsigned long long)dm_sram,
               (unsigned long long)dm_iram, (unsigned long long)dm_oth, dm_n? (double)dm_lat/dm_n:0.0, (unsigned long long)dm_maxl);
        if (getenv("TRACE2")) { fprintf(stderr,"==== TRACE2 ring (last %zu host-region lines near t_end) ====\n", t2ring.size());
            for (auto& s : t2ring) fprintf(stderr,"%s\n", s.c_str()); }
        printf("  PM avg lat BY TYPE: tcm %.2f (n=%llu) / int %.2f (n=%llu) / pmc %.2f (n=%llu) / oob %.2f (n=%llu)\n",
               pm_n_t[0]?(double)pm_lat_t[0]/pm_n_t[0]:0.0, (unsigned long long)pm_n_t[0],
               pm_n_t[1]?(double)pm_lat_t[1]/pm_n_t[1]:0.0, (unsigned long long)pm_n_t[1],
               pm_n_t[2]?(double)pm_lat_t[2]/pm_n_t[2]:0.0, (unsigned long long)pm_n_t[2],
               pm_n_t[3]?(double)pm_lat_t[3]/pm_n_t[3]:0.0, (unsigned long long)pm_n_t[3]);
        printf("  DM avg lat BY TYPE: rom %.2f (n=%llu) / sram(dmc) %.2f (n=%llu) / iram %.2f (n=%llu) / oth %.2f (n=%llu)\n",
               dm_n_t[0]?(double)dm_lat_t[0]/dm_n_t[0]:0.0, (unsigned long long)dm_n_t[0],
               dm_n_t[1]?(double)dm_lat_t[1]/dm_n_t[1]:0.0, (unsigned long long)dm_n_t[1],
               dm_n_t[2]?(double)dm_lat_t[2]/dm_n_t[2]:0.0, (unsigned long long)dm_n_t[2],
               dm_n_t[3]?(double)dm_lat_t[3]/dm_n_t[3]:0.0, (unsigned long long)dm_n_t[3]);
    }
    if (getenv("COLDGATE")) {   // cold-boot progress gate: the DSP must leave the boot region (reach the
        // main program 0x2800+) after the sound reset. The warm reboot regcheck misses the 009B cold-boot
        // spin; this catches it (v3d reaches 0x28xx; the unfixed ckpt4o is stuck at 0x009B).
        // FAIL if the DSP re-runs the 009B PM-clear more than a few times (ckpt4o loops ~105 passes = the
        // spin; v3d runs it ~once ~14336 commits). maxpc alone is fooled: ckpt4o reaches 0x2924 then falls
        // back to 009B. Threshold: > ~4 passes.
        bool pass = n009b <= 60000;
        printf("COLDGATE %s: 009B-clear commits = %llu (one pass ~14336; > ~4 passes => the 009B spin); maxpc 0x%04x\n",
               pass ? "PASS" : "FAIL", (unsigned long long)n009b, maxpc_seen);
        delete t; return pass ? 0 : 1;
    }
    u64 replies = n_ok["ioasic+11"];
    if (T0 < 0) { printf("FAIL: the sound-board reset was never reached\n"); return 1; }
    if (replies < 2) { printf("FAIL: coverage -- only %llu boot replies read and matched (need 0x79 and 0x01)\n", (unsigned long long)replies); return 1; }
    printf("%s: host-visible sound board equal to MAME through the boot handshake (%llu mismatches, %llu replies matched)\n",
           bad ? "FAIL" : "PASS", (unsigned long long)bad, (unsigned long long)replies);
    delete t; return bad ? 1 : 0;
}
