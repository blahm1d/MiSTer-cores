#!/bin/bash
# Engine gate set for an overlap engine (ckpt4o family). usage: gates_eng.sh <engine.sv> <tag>
# boot 6.78M / fight 110k (sim_main_ovl, level-commit) / shift 3264 / cond14 (ovl) / sat_mr / undec.
set -u
ENG="$1"; TAG="$2"
AB=/mnt/d/deck/fpga/zeus/zeus1/lanes/dcs2-area/bench
OV=/mnt/h/temp/zeus/dcs2-area/ckpt4o
H=/mnt/h/temp/zeus/dcs2-engine/bench
W=/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix/gates_$TAG
mkdir -p "$W"; cd "$W" || exit 2
VF="-Wno-WIDTHEXPAND -Wno-WIDTHTRUNC -Wno-UNOPTFLAT -Wno-WIDTH -Wno-CASEINCOMPLETE -Wno-CMPCONST -Wno-UNUSEDSIGNAL -Wno-UNDRIVEN -Wno-TIMESCALEMOD"
bld() { # <tb.cpp> <out> <mdir> [extra]
  rm -rf "$3"; verilator $VF --cc "$ENG" --exe "$1" --build -O2 -o "$2" --top-module dcs2_engine --Mdir "$3" ${4:-} > "$3.log" 2>&1 || { echo "  BUILD-FAIL $2"; tail -5 "$3.log"; return 1; }
}
fail=0
bld "$OV/sim_main_ovl.cpp" dcs2_sim obj_s || fail=1
bld "$AB/shift_directed_tb.cpp" shift_directed obj_sh || fail=1
bld "$OV/cond14_ovl_tb.cpp" cond14_directed obj_c14 --public-flat-rw || fail=1
bld "$AB/sat_mr_tb.cpp" sat_mr obj_sat --public-flat-rw || fail=1
bld "$AB/undec_tb.cpp" undec obj_und --public-flat-rw || fail=1
python3 /mnt/d/deck/fpga/zeus/zeus1/lanes/dcs2-engine/python/emit_shift_directed.py "$W/shift_directed.bin" >/dev/null || { echo "  vector-gen FAIL"; fail=1; }
echo "[1/6] boot";  o=$(./obj_s/dcs2_sim "$H/boot_rec.bin" 100000000 1 2>&1 | grep -iE "committed|DIVERG" | tail -1); echo "  $o"; echo "$o" | grep -q "all matched" || fail=1
echo "[2/6] fight"; o=$(./obj_s/dcs2_sim "$H/fight_rec.bin" 110000 2 "$H/fight_rec.bin.seed" 2>&1 | grep -iE "committed|DIVERG" | tail -1); echo "  $o"; echo "$o" | grep -q "all matched" || fail=1
echo "[3/6] shift"; o=$(./obj_sh/shift_directed "$W/shift_directed.bin" 2>&1 | tail -1); rc=$?; echo "  $o"; ./obj_sh/shift_directed "$W/shift_directed.bin" >/dev/null 2>&1 || fail=1
echo "[4/6] cond14"; ./obj_c14/cond14_directed > c14.txt 2>&1; rc=$?; echo "  $(tail -1 c14.txt) rc=$rc"; [ $rc -eq 0 ] || fail=1
echo "[5/6] sat_mr"; ./obj_sat/sat_mr > sat.txt 2>&1; rc=$?; echo "  $(tail -1 sat.txt) rc=$rc"; [ $rc -eq 0 ] || fail=1
echo "[6/6] undec"; ./obj_und/undec > und.txt 2>&1; rc=$?; echo "  $(tail -1 und.txt) rc=$rc"; [ $rc -eq 0 ] || fail=1
echo "GATES[$TAG]: $([ $fail -eq 0 ] && echo 'ALL PASS' || echo 'FAIL')"
exit $fail
