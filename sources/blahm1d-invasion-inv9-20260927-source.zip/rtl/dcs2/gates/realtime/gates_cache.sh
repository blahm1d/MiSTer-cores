#!/bin/bash
# Packed-line SRAM cache gate: fixed RTL must PASS at DW=16 (DM) and DW=24 (PM); three mutants must FAIL.
set -u
F=/mnt/h/temp/zeus/dcs2-area/ckpt4o_fix
W=$F/gates_cache; mkdir -p "$W"; cd "$W" || exit 2
VF="-Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-CASEINCOMPLETE -Wno-UNOPTFLAT"
bld() { rm -rf "$2"; verilator $VF --cc "$1" --exe $F/tb_cache.cpp --build -O2 --top-module dcs2_sram_cache -GDW=$3 -GIDX=$4 --Mdir "$2" --public-flat-rw -o tb > "$2.log" 2>&1; }
fail=0
sed 's/if (wv\[j\]) be_of\[j\*LBYTE +: LBYTE\] = {LBYTE{1.b1}};/be_of[j*LBYTE +: LBYTE] = {LBYTE{1'"'"'b1}};/' $F/dcs2_sram_cache.sv > mut_be.sv
sed 's/if (!keep\[j\]) merge_beat/merge_beat/' $F/dcs2_sram_cache.sv > mut_merge.sv
sed "s/cm_wd<={1'b1, 1'b1, WPL'(1) << r_w, r_tag};/cm_wd<={1'b1, 1'b1, {WPL{1'b1}}, r_tag};/" $F/dcs2_sram_cache.sv > mut_wv.sv
for m in mut_be mut_merge mut_wv; do cmp -s $m.sv $F/dcs2_sram_cache.sv && { echo "MUTANT $m NOT APPLIED"; fail=1; }; done
for dw in 16:12 24:11; do D=${dw%%:*}; I=${dw#*:}
  bld $F/dcs2_sram_cache.sv o_fix_$D $D $I || { echo "BUILD-FAIL fix $D"; fail=1; continue; }
  ./o_fix_$D/tb $D > fix_$D.txt; r=$?; echo "[fix DW=$D] $(tail -1 fix_$D.txt)"; [ $r -eq 0 ] || fail=1
  for m in mut_be mut_merge mut_wv; do
    bld $m.sv o_${m}_$D $D $I || { echo "BUILD-FAIL $m $D"; fail=1; continue; }
    ./o_${m}_$D/tb $D > ${m}_$D.txt 2>&1; r=$?
    if [ $r -ne 0 ]; then echo "  [$m DW=$D] KILLED ($(grep -c MISMATCH ${m}_$D.txt) mismatch lines shown)"; else echo "  [$m DW=$D] SURVIVED"; fail=1; fi
  done
done
echo "CACHE GATES: $([ $fail -eq 0 ] && echo PASS || echo FAIL)"; exit $fail
