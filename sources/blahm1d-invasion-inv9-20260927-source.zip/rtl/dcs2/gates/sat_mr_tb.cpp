// Directed gate for SAT MR (top-byte 0x05, "IF MV SAT MR"), which MK4 executes 7,168x in the fight
// golden but always with MV=0 (so the engine's former NOP was bit-exact only latently). This exercises
// the effect directly: seed MR + ASTAT(MV), fetch one 0x05, check the committed MR vs the ADSP-2101
// gospel (adsp2100.cpp:1289): if MV, mr = (mr2&0x80)? {ff,8000,0000} : {00,7fff,ffff}; else unchanged.
#include "Vdcs2_engine.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
static const int I_MR0=11,I_MR1=12,I_MR2=13,I_ASTAT=46;
int main(int argc,char**argv){
  Verilated::commandArgs(argc,argv);
  Vdcs2_engine* d=new Vdcs2_engine;
  d->clk=0; d->ce=1; d->pm_ready=0; d->dm_ready=0; d->irq_take=0; d->irq_indx=0;
  auto tick=[&](){ d->clk=0; d->eval(); d->clk=1; d->eval(); };
  // {mr2,mr1,mr0,astat, exp_mr2,exp_mr1,exp_mr0}
  struct C{uint32_t mr2,mr1,mr0,astat, e2,e1,e0; const char*n;} cs[]={
    {0xff,0x1234,0x5678, 0x40, 0xff,0x8000,0x0000,"MV,neg -> ff_8000_0000"},
    {0x00,0x1234,0x5678, 0x40, 0x00,0x7fff,0xffff,"MV,pos -> 00_7fff_ffff"},
    {0xff,0x1234,0x5678, 0x00, 0xff,0x1234,0x5678,"noMV -> unchanged"},
    {0x7f,0x0001,0x0002, 0x40, 0x00,0x7fff,0xffff,"MV,mr2=7f(bit7=0) pos"},
    {0x80,0xabcd,0xef01, 0x40, 0xff,0x8000,0x0000,"MV,mr2=80(bit7=1) neg"},
  };
  long fails=0;
  for(auto&c:cs){
    uint32_t sw[59]={0}; sw[I_MR0]=c.mr0; sw[I_MR1]=c.mr1; sw[I_MR2]=c.mr2; sw[I_ASTAT]=c.astat;
    d->seed_en=1; d->rst=1; for(int k=0;k<59;k++) d->seed.at(k)=sw[k];
    for(int i=0;i<6;i++) tick(); d->rst=0; d->seed_en=0;
    bool fetched=false,committed=false; int g=0;
    while(g++<64){ d->pm_ready=0; d->dm_ready=0;
      if(d->pm_rd && !fetched){ d->pm_rdata=0x050000; d->pm_ready=1; fetched=true; }
      tick(); if(d->commit){committed=true;break;} }
    uint32_t r0=d->dbg.at(I_MR0)&0xffff, r1=d->dbg.at(I_MR1)&0xffff, r2=d->dbg.at(I_MR2)&0xff;
    uint32_t e2=c.e2&0xff;
    if(!committed || r0!=c.e0 || r1!=c.e1 || r2!=e2){
      printf("FAIL [%s]: mr dut=%02x_%04x_%04x exp=%02x_%04x_%04x commit=%d\n",c.n,r2,r1,r0,e2,c.e1,c.e0,committed); fails++;
    } else printf("ok   [%s]\n",c.n);
  }
  printf("SAT MR directed gate: %s (%ld fail)\n", fails?"FAIL":"PASS", fails);
  delete d; return fails?1:0;
}
