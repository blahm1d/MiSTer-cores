#!/bin/bash
# Build + run the SAT MR and undecoded-opcode directed benches against ../rtl/dcs2_engine.sv (this verify copy).
cd /mnt/h/temp/zeus/verify_satmr_tree/bench || exit 9
W="-Wno-WIDTHEXPAND -Wno-WIDTHTRUNC -Wno-UNOPTFLAT -Wno-WIDTH -Wno-CASEINCOMPLETE -Wno-UNUSEDSIGNAL -Wno-UNDRIVEN -Wno-CMPCONST -Wno-TIMESCALEMOD"
fail=0
for t in sat_mr undec; do
  rm -rf obj_dir_$t
  verilator $W --cc ../rtl/dcs2_engine.sv --exe ${t}_tb.cpp --build -O2 -o ${t}_tb --top-module dcs2_engine --public-flat-rw --Mdir obj_dir_$t >/dev/null 2>&1 || { echo "$t BUILD-FAIL"; fail=1; continue; }
  ./obj_dir_$t/${t}_tb | tail -3; [ ${PIPESTATUS[0]} -eq 0 ] || fail=1
done
echo "SATMR_UNDEC_RC=$fail"
