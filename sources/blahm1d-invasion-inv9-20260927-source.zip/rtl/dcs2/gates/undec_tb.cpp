// Directed test for the undecoded-opcode sticky safety net. Injects opcodes and checks undec_seen/
// undec_op: an undecoded form (0x04 stack-control, 0x02 modflag, 0x03 jmp-FI) must trip the flag with
// the offending top-byte; a legit-NOP-on-2104 form (0x01 IO, 0x08 reserved) must NOT trip it.
#include "Vdcs2_engine.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
static bool run_op(uint32_t op){
  Vdcs2_engine* d=new Vdcs2_engine;
  d->clk=0; d->ce=1; d->pm_ready=0; d->dm_ready=0; d->irq_take=0; d->irq_indx=0; d->seed_en=0;
  d->rst=1; auto tick=[&](){ d->clk=0; d->eval(); d->clk=1; d->eval(); };
  for(int i=0;i<6;i++) tick(); d->rst=0;
  bool fetched=false; int g=0;
  while(g++<64){ d->pm_ready=0; d->dm_ready=0;
    if(d->pm_rd && !fetched){ d->pm_rdata=op; d->pm_ready=1; fetched=true; }
    tick(); if(d->commit) break; }
  bool seen=d->undec_seen; uint32_t uop=d->undec_op;
  delete d; return seen && (uop==((op>>16)&0xff));
}
static bool run_noflag(uint32_t op){
  Vdcs2_engine* d=new Vdcs2_engine;
  d->clk=0; d->ce=1; d->pm_ready=0; d->dm_ready=0; d->irq_take=0; d->irq_indx=0; d->seed_en=0;
  d->rst=1; auto tick=[&](){ d->clk=0; d->eval(); d->clk=1; d->eval(); };
  for(int i=0;i<6;i++) tick(); d->rst=0;
  bool fetched=false; int g=0;
  while(g++<64){ d->pm_ready=0; d->dm_ready=0;
    if(d->pm_rd && !fetched){ d->pm_rdata=op; d->pm_ready=1; fetched=true; }
    tick(); if(d->commit) break; }
  bool seen=d->undec_seen; delete d; return !seen;
}
int main(int argc,char**argv){
  Verilated::commandArgs(argc,argv); long f=0;
  struct{uint32_t op;const char*n;} trip[]={{0x040000,"0x04 stack-ctrl"},{0x020000,"0x02 modflag"},{0x030000,"0x03 jmp-FI"}};
  struct{uint32_t op;const char*n;} noflag[]={{0x010000,"0x01 IO(2104 NOP)"},{0x080000,"0x08 reserved"},{0x000000,"0x00 NOP"}};
  for(auto&t:trip){ bool ok=run_op(t.op); printf("%s inject %s -> undec_seen expected 1\n", ok?"ok  ":"FAIL",t.n); if(!ok)f++; }
  for(auto&t:noflag){ bool ok=run_noflag(t.op); printf("%s inject %s -> undec_seen expected 0\n", ok?"ok  ":"FAIL",t.n); if(!ok)f++; }
  printf("undec sticky gate: %s (%ld fail)\n", f?"FAIL":"PASS", f); return f?1:0;
}
