#!/usr/bin/env python3
"""Stack unit golden: ADSP-21xx PC / CNTR / STATUS / LOOP stacks, transcribed from MAME 0.289, independent of the RTL.

  stacks        2100ops.hxx:119-296 (pc_stack_top/push/pop, cntr_stack_push/pop, loop_stack_push/pop,
                stat_stack_push/pop): depths PC 16, CNTR 4, STATUS 4, LOOP 4 (adsp2100.h:298-301). A push on a
                FULL stack stores nothing, leaves sp, sets the OVER bit (a DO on a full loop stack does NOT arm
                the loop: m_loop/m_loop_condition are only set inside the push); a pop on an EMPTY stack leaves
                sp 0 and reads/uses entry 0. sstat bits 2100ops.hxx:104-111 (PC_EMPTY 01 PC_OVER 02 COUNT_EMPTY
                04 COUNT_OVER 08 STATUS_EMPTY 10 STATUS_OVER 20 LOOP_EMPTY 40 LOOP_OVER 80); reset sstat 0x55,
                m_loop 0xffff (adsp2100.cpp device_reset).
  loop end      adsp2100.cpp:1203-1220: at pc == m_loop: condition true -> pc = pc_stack_top(); else
                loop_stack_pop(); pc_stack_pop_val(); pc++ -- BEFORE the fetched instruction executes.
  CE            slow_condition 2100ops.hxx:314-323: (int32)--cntr > 0, else cntr_stack_pop().
  0x04          adsp2100.cpp:1278-1287 stack control: bit4 POP PC (pop_val), bit3 POP LOOP, bit2 POP CNTR,
                bit1 STS: bit0 ? POP : PUSH.
  0x0a          RTS/RTI (cond 15 = always): pc_stack_pop(); RTI also stat_stack_pop().
  0x14-0x17     DO addr UNTIL cond: loop_stack_push(op & 0x3ffff); pc_stack_push() (pc already advanced).
  0x18/0x1c     JUMP / CALL imm (cond 15); CALL = pc_stack_push() then pc = addr.
  CNTR = imm    write_reg3 case 5 (2100ops.hxx:448): cntr_stack_push(); cntr = val & 0x3fff.
  AX0 = imm     load data register immediate (no stack effect).

Program: random structured code (nested DO..UNTIL CE, loops left by a JUMP with or without the POP PC / POP LOOP /
POP CNTR cleanup the War Gods DCS2 firmware uses at 0x3408-0x340A, CALL/RTS, PUSH/POP STS, stray pops that
underflow) restarting at 0 forever; the expected stream is (next pc, cntr, sstat, pc_sp, cntr_sp, stat_sp, loop_sp)
after every committed instruction for the first N.

Usage: stack_golden.py gen <prog.hex> <expect.txt> <commits> <seed>
       stack_golden.py check <expect.txt> <rtl.txt>
"""
import random, sys

NOP = 0x000000
def ax0(v): return 0x400000 | ((v & 0xffff) << 4)
def cntr_imm(v): return 0x3C0005 | ((v & 0x3fff) << 4)
def do_ce(a): return 0x14000E | ((a & 0x3fff) << 4)
def jump(a): return 0x18000F | ((a & 0x3fff) << 4)
def call(a): return 0x1C000F | ((a & 0x3fff) << 4)
RTS = 0x0A000F
def stkctl(pc_, lp, cn, sts): return 0x040000 | (pc_ << 4) | (lp << 3) | (cn << 2) | sts   # sts: 0 none, 2 push, 3 pop


class Asm:
    def __init__(self): self.code = []; self.fix = []
    def here(self): return len(self.code)
    def emit(self, w, label=None):
        if label is not None: self.fix.append((len(self.code), label))
        self.code.append(w)
    def resolve(self, labels):
        for i, lab in self.fix:
            self.code[i] |= (labels[lab] & 0x3fff) << 4


def gen_prog(rnd):
    a = Asm(); labels = {}; nl = [0]; subs = []
    def lab():
        nl[0] += 1; return 'L%d' % nl[0]

    def block(depth, n):
        for _ in range(n):
            r = rnd.random()
            if depth < 7 and r < 0.30:                       # proper DO loop
                a.emit(cntr_imm(rnd.choice([1, 1, 2, 2, 3, 0])))
                end = lab(); a.emit(do_ce(0), end)
                block(depth + 1, rnd.randint(0, 2))
                labels[end] = a.here(); a.emit(ax0(rnd.getrandbits(16)))
            elif depth < 7 and r < 0.45:                     # DO left by a jump (firmware 0x33C8/0x33F3 shape)
                a.emit(cntr_imm(rnd.choice([2, 3, 4])))
                end, out = lab(), lab()
                a.emit(do_ce(0), end)
                block(depth + 1, rnd.randint(0, 1))
                a.emit(jump(0), out)
                labels[end] = a.here(); a.emit(NOP)
                labels[out] = a.here()
                if rnd.random() < 0.55: a.emit(stkctl(1, 1, 1, 0))   # POP PC, POP LOOP, POP CNTR (0x3408-0x340A)
                elif rnd.random() < 0.5: a.emit(stkctl(1, 0, 0, 0)); a.emit(stkctl(0, 1, 0, 0)); a.emit(stkctl(0, 0, 1, 0))
                # else: leak (stacks grow -> overflow saturation)
            elif r < 0.55 and len(subs) < 6:                 # CALL a subroutine
                s = lab(); subs.append((s, depth)); a.emit(call(0), s)
            elif r < 0.62:
                a.emit(stkctl(0, 0, 0, rnd.choice([2, 2, 3])))  # PUSH / POP STS
            elif r < 0.66:
                a.emit(stkctl(rnd.getrandbits(1), rnd.getrandbits(1), rnd.getrandbits(1), 0))  # stray pops
            elif r < 0.75:
                a.emit(cntr_imm(rnd.getrandbits(3)))          # bare CNTR = imm (push)
            else:
                a.emit(ax0(rnd.getrandbits(16)))

    block(0, 40)
    a.emit(jump(0), 'START')
    labels['START'] = 0
    done = 0
    while done < len(subs):
        s, d = subs[done]; done += 1
        labels[s] = a.here()
        block(min(d + 1, 7), rnd.randint(1, 4))
        a.emit(RTS)
    a.resolve(labels)
    return a.code


class Mame:
    def __init__(self, pm):
        self.pm = pm + [0] * (0x4000 - len(pm))
        self.pc = 0; self.loop = 0xffff; self.lcond = 0; self.cntr = 0; self.sstat = 0x55
        self.pcs = [0] * 16; self.pcsp = 0
        self.cns = [0] * 4; self.cnsp = 0
        self.sts = [0] * 4; self.stsp = 0
        self.lps = [0] * 4; self.lpsp = 0
    # 2100ops.hxx:119-296
    def pc_top(self): return self.pcs[self.pcsp - 1] if self.pcsp > 0 else self.pcs[0]
    def pc_push(self, v=None):
        if self.pcsp < 16: self.pcs[self.pcsp] = self.pc if v is None else v; self.pcsp += 1; self.sstat &= ~0x01
        else: self.sstat |= 0x02
    def pc_pop(self):
        if self.pcsp > 0:
            self.pcsp -= 1
            if self.pcsp == 0: self.sstat |= 0x01
        return self.pcs[self.pcsp]
    def cn_push(self):
        if self.cnsp < 4: self.cns[self.cnsp] = self.cntr; self.cnsp += 1; self.sstat &= ~0x04
        else: self.sstat |= 0x08
    def cn_pop(self):
        if self.cnsp > 0:
            self.cnsp -= 1
            if self.cnsp == 0: self.sstat |= 0x04
        self.cntr = self.cns[self.cnsp]
    def lp_push(self, v):
        if self.lpsp < 4:
            self.lps[self.lpsp] = v; self.lpsp += 1; self.loop = v >> 4; self.lcond = v & 15; self.sstat &= ~0x40
        else: self.sstat |= 0x80
    def lp_pop(self):
        if self.lpsp > 0:
            self.lpsp -= 1
            if self.lpsp == 0: self.loop = 0xffff; self.lcond = 0; self.sstat |= 0x40
            else: self.loop = self.lps[self.lpsp - 1] >> 4; self.lcond = self.lps[self.lpsp - 1] & 15
    def st_push(self):
        if self.stsp < 4: self.sts[self.stsp] = 0; self.stsp += 1; self.sstat &= ~0x10
        else: self.sstat |= 0x20
    def st_pop(self):
        if self.stsp > 0:
            self.stsp -= 1
            if self.stsp == 0: self.sstat |= 0x10
    def ce(self):                                   # slow_condition
        self.cntr = (self.cntr - 1) & 0xffffffff
        if self.cntr != 0 and self.cntr < 0x80000000: return True
        self.cn_pop(); return False

    def step(self):
        op = self.pm[self.pc & 0x3fff]
        if self.pc != self.loop: self.pc = (self.pc + 1) & 0x3fff
        else:
            c = self.ce() if self.lcond == 14 else (self.lcond == 15)
            if c: self.pc = self.pc_top()
            else: self.lp_pop(); self.pc_pop(); self.pc = (self.pc + 1) & 0x3fff
        h = op >> 16
        if h == 0x04:
            if op & 0x10: self.pc_pop()
            if op & 0x08: self.lp_pop()
            if op & 0x04: self.cn_pop()
            if op & 0x02:
                if op & 0x01: self.st_pop()
                else: self.st_push()
        elif h == 0x0a:
            if (op & 15) == 15:
                self.pc = self.pc_pop()
                if op & 0x10: self.st_pop()
        elif 0x14 <= h <= 0x17: self.lp_push(op & 0x3ffff); self.pc_push()
        elif 0x18 <= h <= 0x1b: self.pc = (op >> 4) & 0x3fff
        elif 0x1c <= h <= 0x1f: self.pc_push(); self.pc = (op >> 4) & 0x3fff
        elif 0x3c <= h <= 0x3f and (op & 15) == 5: self.cn_push(); self.cntr = (op >> 4) & 0x3fff
        elif (h >> 4) == 0x4: pass
        elif op == 0: pass
        else: raise SystemExit('golden: unmodelled op %06X' % op)
        return '%04X %04X %02X %X %X %X %X' % (self.pc, self.cntr & 0xffff, self.sstat, self.pcsp, self.cnsp,
                                               self.stsp, self.lpsp)


def gen(prog_path, exp_path, n, seed):
    rnd = random.Random(seed)
    pm = gen_prog(rnd)
    with open(prog_path, 'w') as f:
        for w in pm: f.write('%06X\n' % w)
    m = Mame(pm)
    with open(exp_path, 'w') as f:
        for _ in range(n): f.write(m.step() + '\n')
    print('program %d words, %d commits' % (len(pm), n))


def check(exp_path, rtl_path):
    e = [l.upper().split() for l in open(exp_path)]; r = [l.upper().split() for l in open(rtl_path)]   # hex case only
    for i in range(len(e)):
        if i >= len(r): print('RTL stopped at commit %d of %d' % (i, len(e))); return 1
        if e[i] != r[i]:
            print('DIVERGENCE at commit %d: golden %s rtl %s (pc cntr sstat pcsp cnsp stsp lpsp)' % (i, ' '.join(e[i]), ' '.join(r[i])))
            return 1
    print('%d commits match' % len(e)); return 0


if __name__ == '__main__':
    if sys.argv[1] == 'gen': gen(sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5]))
    else: sys.exit(check(sys.argv[2], sys.argv[3]))
