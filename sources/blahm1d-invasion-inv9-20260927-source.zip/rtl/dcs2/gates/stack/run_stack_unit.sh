#!/usr/bin/env bash
# MK4 stack unit gate (iverilog, WSL): dcs2_engine PC/CNTR/STATUS/LOOP stacks (DO/CE loop ends, CALL/RTS, CNTR pushes,
# 0x04 stack control POP PC/LOOP/CNTR + PUSH/POP STS, overflow saturation, underflow) vs stack_golden.py (MAME 0.289
# transcription, copied unchanged from the War Gods lane D:/deck/fpga/cruisinusa/bandwidth/wg1/dcs2/unit/stack/,
# sha256 21d01d8e...), random structured programs, 4000 commits, five seeds.
# usage: run_stack_unit.sh [engine.sv] [tag] [extra iverilog -D define (mutant)]
#   default engine = the tree engine. Expected: PASS; the pre-dcs2-stack engine FAIL; -DMUT_STK_WRAP FAIL.
set -u
U=/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs2/gates/stack
ENG="${1:-/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs2/dcs2_engine.sv}"; TAG="${2:-tree}"; DEF="${3:-}"
S=/mnt/h/temp/zeus/stk/unit_$TAG
mkdir -p $S
iverilog -g2012 -DSYNTHESIS -DSIM_STACK_INIT $DEF -o $S/tb_stack.vvp -s tb_stack $U/tb_stack.sv "$ENG" > $S/iverilog.log 2>&1 || { cat $S/iverilog.log | head -20; echo "STACK UNIT GATE BUILD FAIL"; exit 2; }
rc=0
for seed in 1 2 3 4 5; do
  python3 $U/stack_golden.py gen $S/prog$seed.hex $S/exp$seed.txt 4000 $seed > /dev/null || exit 2
  n=$(wc -l < $S/exp$seed.txt)
  timeout 600 vvp -n $S/tb_stack.vvp +prog=$S/prog$seed.hex +out=$S/rtl$seed.txt +n=$n > $S/vvp$seed.log 2>&1 || { tail -5 $S/vvp$seed.log; exit 2; }
  grep -q TIMEOUT $S/vvp$seed.log && { echo "seed $seed: TIMEOUT"; rc=1; continue; }
  echo -n "seed $seed: "; python3 $U/stack_golden.py check $S/exp$seed.txt $S/rtl$seed.txt || rc=1
done
[ $rc -eq 0 ] && echo "STACK UNIT GATE PASS [$TAG]" || echo "STACK UNIT GATE FAIL [$TAG]"
exit $rc
