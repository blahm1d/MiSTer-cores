// tb_stack.sv -- MK4 stack unit bench (adapted from the War Gods wg1 dcs2/unit/stack/tb_stack.sv to the MK4 ckpt4o
// engine ports): dcs2_engine runs the program from stack_golden.py (MAME 0.289 transcription, unchanged copy); for
// every committed instruction it prints next pc, CNTR, SSTAT and the four stack pointers (dbg fields 0,45,48,51-54).
// Sampling: on the NEGEDGE of a cycle with commit=1 (the ckpt4o engine raises commit on the edge that retires the
// instruction and can retire the next one on the very next edge -- self-loop fast path -- so a posedge+#1 sample
// would see the following instruction). stack_golden.py check compares against the MAME model (never RTL vs RTL).
`timescale 1ns/1ps
module tb_stack;
  reg clk = 0, rst = 1;
  wire pm_rd, pm_wr, dm_rd, dm_wr; wire [13:0] pm_addr, dm_addr; wire [23:0] pm_wdata; wire [15:0] dm_wdata;
  reg [23:0] pm_rdata; reg pm_ready; reg [15:0] dm_rdata; reg dm_ready;
  wire irq_ack, tx1_we, commit; wire [2:0] irq_ack_indx; wire [1887:0] dbg;
  wire [13:0] ab_i, ab_m, ab_l, ab_i7, ab_pc; wire [6:0] ab_mstat; wire ab_icntl2; wire [5:0] ab_imask;
  wire undec_seen; wire [13:0] undec_pc; wire [7:0] undec_op;
  reg [23:0] pm [0:16383];
  reg [15:0] dm [0:16383];
  integer fo, ncommit, nexp, k;
  reg [1023:0] prog_path, out_path;
  dcs2_engine u (
    .clk(clk), .rst(rst), .ce(1'b1),
    .pm_rd(pm_rd), .pm_wr(pm_wr), .pm_addr(pm_addr), .pm_wdata(pm_wdata), .pm_rdata(pm_rdata), .pm_ready(pm_ready),
    .dm_rd(dm_rd), .dm_wr(dm_wr), .dm_addr(dm_addr), .dm_wdata(dm_wdata), .dm_rdata(dm_rdata), .dm_ready(dm_ready),
    .irq_take(1'b0), .irq_indx(3'd0), .pace_hold(1'b0), .i7_we(1'b0), .i7_wd(14'd0), .warm_rst(1'b0),
    .irq_ack(irq_ack), .irq_ack_indx(irq_ack_indx), .tx1_we(tx1_we),
    .seed_en(1'b0), .seed(1888'd0), .commit(commit),
    .ab_ireg(3'd7), .ab_mreg(3'd7), .ab_lreg(3'd7), .ab_i(ab_i), .ab_m(ab_m), .ab_l(ab_l), .ab_i7(ab_i7), .ab_pc(ab_pc),
    .ab_mstat(ab_mstat), .ab_icntl2(ab_icntl2), .ab_imask(ab_imask),
    .undec_seen(undec_seen), .undec_pc(undec_pc), .undec_op(undec_op), .dbg(dbg));
  always #5 clk = ~clk;
  // zero-latency memory, served in the request cycle (the engine gates' sim_main_ovl.cpp model, LAT=0): ready/data
  // accompany the request and the engine samples them at the next edge; writes land at that edge.
  always @* begin
    pm_ready = pm_rd | pm_wr; dm_ready = dm_rd | dm_wr;
    pm_rdata = pm[pm_addr]; dm_rdata = dm[dm_addr];
  end
  always @(posedge clk) begin
    if (pm_wr) pm[pm_addr] <= pm_wdata;
    if (dm_wr) dm[dm_addr] <= dm_wdata;
  end
  initial begin
    for (k = 0; k < 16384; k = k + 1) begin pm[k] = 24'h0; dm[k] = 16'h0; end
    if (!$value$plusargs("prog=%s", prog_path)) $fatal(1, "+prog");
    if (!$value$plusargs("out=%s", out_path)) $fatal(1, "+out");
    if (!$value$plusargs("n=%d", nexp)) $fatal(1, "+n");
    $readmemh(prog_path, pm);
    fo = $fopen(out_path, "w");
    ncommit = 0;
    repeat (4) @(posedge clk);
    rst = 0;
  end
  always @(negedge clk) if (!rst && commit) begin
    $fwrite(fo, "%04X %04X %02X %0X %0X %0X %0X\n", dbg[0*32 +: 14], dbg[45*32 +: 16], dbg[48*32 +: 8],
            dbg[51*32 +: 5], dbg[52*32 +: 3], dbg[53*32 +: 3], dbg[54*32 +: 3]);
    ncommit = ncommit + 1;
    if (ncommit == nexp) begin $fclose(fo); $finish; end
  end
  initial begin #200000000; $display("TIMEOUT commits %0d", ncommit); $fclose(fo); $finish; end
endmodule
