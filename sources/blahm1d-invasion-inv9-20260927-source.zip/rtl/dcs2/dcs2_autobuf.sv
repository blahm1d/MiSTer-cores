// dcs2_autobuf.sv -- DCS2 SPORT1 autobuffer (CAL1) + ADSP-2101 timer (CAL3) + IRQ latch/mux (CAL2).
// Transcribed BLIND from MAME 0.289 gospel (gospel/dcs.cpp, gospel/adsp2100/adsp2100.cpp).
// Quartus-17-safe SystemVerilog. One clock. Replaces the WRONG inline CAL1/CAL3 in zk4_dcs2.sv.
//
// ===== MAME behaviour this module reproduces (cite: gospel/dcs.cpp) =====
//  sound_tx_callback (2043-2094): ARMED when the DSP writes the SPORT1 TX register (offset==1,
//    a core reg move TX1=..., NOT a DM write). Requires SYSCONTROL bit11 (0x0800) & S1_AUTOBUF
//    bit1 (0x0002). Then (2058-2078):
//       ireg = (S1_AUTOBUF >> 9) & 7;  mreg = ((S1_AUTOBUF >> 7) & 3) | (ireg & 4);  lreg = ireg;
//       source = I[ireg] & ~0xf;   I[ireg] = source;   ireg_base = source;
//       recompute_sample_rate();  -> arms the half-buffer reg_timer.
//  recompute_sample_rate (2014-2041): external 31.25 kHz sample clock (unless S1_CONTROL bit14);
//       reg_timer period = sample_period * size / (2 * channels * incs)   (channels=2 for DCS2,
//       dcs.cpp:822;  size=L[lreg]; incs=M[mreg]).
//  dcs_irq (1957-1997, the reg_timer callback): reg = I[ireg];  count = size/(2*incs);
//       for i in 0..count: buffer[i]=DM[reg]; reg += incs;    (-> DAC, count/channels frames)
//       ireg_base = get_ibase(ireg);
//       if (reg >= ireg_base + size) { reg = ireg_base; pulse IRQ1 = SPORT1-TX (indx3); }
//       I[ireg] = reg;
//    => I[ireg] advances by count*incs == size/2 per HALF-buffer tick (NOT +M per sample), and
//       SPORT1-TX pulses ONLY on buffer WRAP (NOT every tick). Both were wrong in the old CAL1.
//    MEASURED (fight golden, python/analyze_autobuf.py): I7 0x3400->0x35E0 (+0x1E0=+480=size/2)
//       every 122,880 core cycles; wrap 0x35E0->0x3400 (SPORT1-TX) every 2 ticks; incs=M[5]=1,
//       size=L[7]=0x3C0=960, ireg=7 (S1_AUTOBUF=0x0E82).  advance = size>>1 exactly since
//       count*incs = (size/(2*incs))*incs = size/2 (buffer sized to whole samples) -> no divide.
//  ADSP-2101 timer (dcs.cpp:1693-1803): first fire TSCALE*(TCOUNT+1) core clocks after enable,
//       then every TSCALE*(TPERIOD+1)  (reset_timer:1783 + internal_timer_callback:1727).
//       TSCALE = TIMER_SCALE_REG (0x1b) VALUE (m_timer_scale=data, :1928) -- NOT +1.
//       IRQ = ADSP2105_TIMER (indx5, vector 0x18).
//
module dcs2_autobuf #(
  parameter [2:0]  SPORT_IRQ_INDX = 3'd3,      // SPORT1-TX -> indx 3 (adsp2100.cpp:987-990)
  parameter [2:0]  TIMER_IRQ_INDX = 3'd5,      // TIMER     -> indx 5 (adsp2100.cpp:997-998)
  parameter [15:0] CHANNELS       = 16'd2,     // DCS2 stereo (dcs.cpp:822)
  parameter int    SMP_CLKS       = 1600       // fabric clocks per 31.25 kHz sample (50 MHz; dcs.cpp:2028)
)(
  input  logic        clk,
  input  logic        rst,
  input  logic        irq_clr,                // wg-hazards: ADSP reset (host reset held / SYSCONTROL reboot pulse):
                                               // device_reset clears m_irq_state + m_irq_latch (adsp2100.cpp:662-664),
                                               // applied at the reset RELEASE (diexec.cpp:725-729) -> clear while high
  input  logic        audio_ce,               // 31.25 kHz DAC strobe (free-running). No longer the tick grid:
                                               // see smp_div (wg-hazards F1)
  input  logic        e_commit,               // engine retired one instruction = one DSP cycle
                                               // (MAME's timer counts m_cpu->total_cycles, NOT clk)
  input  logic        tick_force,             // gate-only: inject a reg_timer tick at a golden instant
  // control-reg file mirror (0x3fe0-0x3fff), written by the DM servicer
  input  logic [15:0] syscontrol,             // ctl 0x1f
  input  logic [15:0] s1_autobuf,             // ctl 0x0f
  input  logic [15:0] s1_control,             // ctl 0x12  (bit14 = internal SPORT1 clock)
  input  logic [15:0] tscale,                 // ctl 0x1b
  input  logic [15:0] tcount,                 // ctl 0x1c
  input  logic [15:0] tperiod,                // ctl 0x1d
  input  logic        timer_ena,              // MSTAT timer-enable (ENA/DIS TIMER); 1=running
  // AREA: engine DAG regs now in MLAB. Instead of the all-8 e_dbg fan-out, this module publishes the
  // selected indices (ireg/mreg/lreg) and the engine returns the selected values on a narrow side port.
  output logic [2:0]  ab_ireg,
  output logic [2:0]  ab_mreg,
  output logic [2:0]  ab_lreg,
  input  logic [13:0] i_sel,           // = engine I[ab_ireg]
  input  logic [13:0] m_sel,           // = engine Msg[ab_mreg]
  input  logic [13:0] l_sel,           // = engine L[ab_lreg]
  // arm: DSP wrote SPORT1 TX register (sound_tx_callback offset==1)
  input  logic        tx1_we,
  // seed path (gate): load the autobuffer base + running flag mid-stream (fight seed)
  input  logic        arm_seed_we,
  input  logic [13:0] arm_seed_base,
  // engine I7 side-write (faithful set_state_int(ADSP2100_I0+ireg, reg); ireg==7 for MK4)
  output logic        i7_we,
  output logic [13:0] i7_wd,
  // DAC-read DMA master: read DM[reg + k*incs], `count` words
  output logic        dac_rd,
  output logic [13:0] dac_addr,
  input  logic [15:0] dac_rdata,
  input  logic        dac_ready,
  output logic        dac_smp_we,             // one strobe per sample word read (DAC deinterleaves)
  output logic [15:0] dac_smp,
  // interrupt sources (1-cycle pulses -> latched by the IRQ mux below)
  output logic        sport_tx_irq,
  output logic        timer_irq,
  // IRQ mux to the engine (irq2_req is the level-held host mailbox IRQ, highest priority)
  input  logic        irq2_req,               // host mailbox IRQ2 LINE (level; set on host write, cleared on DSP ack)
  input  logic        sport0_rx_irq,          // SPORT0-RX pulse (zk4_dcs2's 1 kHz SPORT0 timer; 0 when not built = MK4)
  input  logic        ifc_we,                 // DSP wrote IFC (2100ops.hxx:474-488, ADSP-2101 form): bits 2/3/5 clear
  input  logic [15:0] ifc_val,                //  the IRQ1 / SPORT0-RX / IRQ2 latches, bits 8/9/11 set them (the timer
                                              //  latch is not touched; IRQ0 / SPORT0-TX have no source here)
  input  logic        e_icntl2,               // engine ICNTL[2]: 1 = IRQ2 edge-sensitive (latch), 0 = level
  input  logic [5:0]  e_imask,                // engine IMASK (bit 5>>indx enables indx; adsp2100.cpp:894)
  input  logic        e_irq_ack,
  input  logic [2:0]  e_irq_ack_indx,
  output logic        e_irq_take,
  output logic [2:0]  e_irq_indx,
  // observability
  output logic        tick_stb                // a reg_timer tick fired this cycle
);
  // ---- autobuffer register selection (gospel dcs.cpp:2058-2061) ----
  wire        sport_en = syscontrol[11] & s1_autobuf[1];
  wire [2:0]  ireg = s1_autobuf[11:9];                       // (AB>>9)&7
  wire [2:0]  mreg = {ireg[2], s1_autobuf[8:7]};             // ((AB>>7)&3) | (ireg&4)
  wire [2:0]  lreg = ireg;
  assign ab_ireg = ireg; assign ab_mreg = mreg; assign ab_lreg = lreg;  // publish to engine side port
  wire [13:0] i_reg = i_sel;                                 // engine I[ireg] (was i_all[ireg])
  wire [13:0] incs  = m_sel;                                 // engine Msg[mreg]
  wire [13:0] size  = l_sel;                                 // engine L[lreg]
  wire [13:0] advance = {1'b0, size[13:1]};                  // size>>1 == count*incs (no divide)

  // ---- DAC-read DMA FSM state (declared first: referenced by `tick`) ----
  localparam DMA_IDLE=1'd0, DMA_RD=1'd1;
  reg         dma_st;
  reg  [13:0] dma_reg;      // running reg (= I[ireg]) during the copy
  reg  [13:0] dma_addr;     // current read address
  reg  [13:0] dma_end;      // reg + advance (stop address, exclusive)

  // ---- autobuffer base (ireg_base) ----
  reg  [13:0] ab_base;
  reg         ab_armed;

  // ---- reg_timer cadence: fire every size/(2*channels*incs) audio_ce strobes ----
  // accumulate (2*channels*incs) per audio_ce; fire when acc >= size (subtract size).  (dcs.cpp:2038)
  reg  [21:0] ce_acc;
  wire [21:0] ce_step = {8'd0, incs} * ({6'd0, CHANNELS} << 1);   // 2 * channels * incs
  // wg-hazards F1 (War Gods dcs2 fix, ported): MAME restarts the half-buffer timer AT the arm --
  // recompute_sample_rate() m_reg_timer->adjust(period, 0, period) (dcs.cpp:2036-2040, called from
  // sound_tx_callback :2082) -> first tick = arm + period exactly. The old cadence counted the free-running
  // DAC strobe, so the first tick came up to one sample (512 DSP cycles) early. The sample grid is now a
  // local divider restarted by the arming TX write (same 50 MHz clock as the DAC: no drift vs audio_ce).
  reg  [$clog2(SMP_CLKS)-1:0] smp_div;
  wire        smp_ce_arm = (smp_div == ($clog2(SMP_CLKS))'(SMP_CLKS - 1));
`ifdef MUT_FREE_GRID
  wire        smp_ce = audio_ce;                                  // mutant: the pre-fix free-running grid
`else
  wire        smp_ce = smp_ce_arm;
`endif
  wire        cadence_fire = sport_en & smp_ce & ~tx1_we & ((ce_acc + ce_step) >= {8'd0, size});
  wire        tick = (cadence_fire | tick_force) & (dma_st == DMA_IDLE);

  assign dac_rd   = (dma_st == DMA_RD);
  assign dac_addr = dma_addr;

  always_ff @(posedge clk) begin
    // default 1-cycle strobes
    i7_we <= 1'b0; sport_tx_irq <= 1'b0; dac_smp_we <= 1'b0; tick_stb <= 1'b0;
    if (rst) begin
      ce_acc <= 22'd0; ab_base <= 14'd0; ab_armed <= 1'b0; dma_st <= DMA_IDLE;
      dma_reg <= 14'd0; dma_addr <= 14'd0; dma_end <= 14'd0; smp_div <= '0;
    end else begin
      smp_div <= (tx1_we && sport_en) || smp_ce_arm ? '0 : smp_div + 1'b1;   // F1: grid restarts at the arm
`ifndef MUT_NO_DISARM
      // wg-hazards F2: SPORT1 disabled (SYSCONTROL bit 11 = 0, dcs.cpp:1884-1887) or autobuffer off (S1_AUTOBUF
      // bit 1 = 0, :1909-1913) -> m_reg_timer->reset(): no tick until the next arming TX write (:2082). The old
      // code only gated the cadence, so a re-enable without a TX write resumed ticking on the stale arm.
      if (!sport_en) ab_armed <= 1'b0;
`endif
      // arm (real HW): SPORT1 TX register write while enabled -> capture base, rewind I[ireg]
      if (tx1_we && sport_en) begin
        ab_base  <= i_reg & 14'h3ff0;          // source &= ~0xf (gospel:2072)
        ab_armed <= 1'b1;
        i7_we    <= 1'b1; i7_wd <= i_reg & 14'h3ff0;   // I[ireg] = source (gospel:2075)
        ce_acc   <= 22'd0;                      // recompute_sample_rate re-phases the timer
      end
      // seed (gate): load base + armed mid-stream
      if (arm_seed_we) begin ab_base <= arm_seed_base; ab_armed <= 1'b1; end

      // reg_timer cadence accumulator (real-HW path)
      if (tx1_we && sport_en) ;                        // F1: the arm (above) owns ce_acc this clock
      else if (cadence_fire) ce_acc <= (ce_acc + ce_step) - {8'd0, size};
      else if (sport_en && smp_ce) ce_acc <= ce_acc + ce_step;

      // ---- reg_timer tick ----
      // MAME's dcs_irq runs in ZERO guest time (host timer callback): I[ireg] jumps by the whole
      // block AT the boundary (the busy-poll loop 2F3F sees it step), and IRQ1 pulses on wrap. So
      // update I[ireg]+IRQ IMMEDIATELY (1 cycle) -- NOT after the 480-word copy (which in real HW
      // takes cycles and would lag the pointer). The DAC block-read runs DECOUPLED (DMA FSM below)
      // to feed the two DACs over the following half-buffer period. (dcs.cpp:1957-1995)
      if (tick && ab_armed && (size != 14'd0)) begin
        logic [14:0] regp;
        tick_stb <= 1'b1;
        regp = {1'b0, i_reg} + {1'b0, advance};             // reg + count*incs
        if (regp >= ({1'b0, ab_base} + {1'b0, size})) begin // wrap: reg >= ireg_base + size
          i7_we <= 1'b1; i7_wd <= ab_base;                  // reg = ireg_base (gospel:1987)
          sport_tx_irq <= 1'b1;                             // SPORT1-TX (indx3) ONLY on wrap (:1991)
        end else begin
          i7_we <= 1'b1; i7_wd <= regp[13:0];               // reg advanced (gospel:1995)
        end
        // launch the DAC block copy of [reg, reg+advance) stride incs (audio only, decoupled)
        if (dma_st == DMA_IDLE) begin
          dma_reg  <= i_reg;
          dma_addr <= i_reg;                                // read from the OLD reg (gospel:1974)
          dma_end  <= i_reg + advance;
        end
      end
      // ---- decoupled DAC block-read DMA (feeds audio_l/audio_r via the DAC) ----
      case (dma_st)
        DMA_IDLE: begin
          if (tick && ab_armed && (size != 14'd0) && (advance != 14'd0)) dma_st <= DMA_RD;
        end
        DMA_RD: begin
          if (dac_ready) begin
            dac_smp_we <= 1'b1; dac_smp <= dac_rdata;       // one audio word -> DAC
            if ((dma_addr + incs) >= dma_end) dma_st <= DMA_IDLE;  // last word done
            dma_addr <= dma_addr + incs;                    // reg += incs (gospel:1975)
          end
        end
        default: dma_st <= DMA_IDLE;
      endcase
    end
  end

  // ================= CAL3: ADSP-2101 timer (dcs.cpp:1693-1803) =================
  // first fire TSCALE*(TCOUNT+1) DSP CYCLES after the MSTAT timer-enable edge; then every
  // TSCALE*(TPERIOD+1). MAME counts m_cpu->total_cycles() (dcs.cpp:1700,1721) -- ONE per retired
  // instruction on this core, NOT 50 MHz fabric clocks -> gate the countdown on e_commit.
  // m_timer_scale = (data & 0xff) + 1 (dcs.cpp:1924 -- the prescale reload). The RAW register is NOT
  // the divisor; TSCALE reg 0x0001 -> divisor 2.
  wire [15:0] t_scale = {8'd0, tscale[7:0]} + 16'd1;
  wire [15:0] t_div0  = (t_scale == 16'd0) ? 16'd0 : (t_scale - 16'd1);
  reg  [15:0] tmr_div;                                      // DSP cycles within one timer count
  reg  [15:0] tmr_cnt;                                      // remaining counts to the next fire
  always_ff @(posedge clk) begin
    timer_irq <= 1'b0;
    if (rst || !timer_ena) begin
      // hold the timer PRIMED while disabled so it counts correctly from the enable edge (reset_timer:
      // first fire = TSCALE*(TCOUNT+1) with NO spurious fire at enable). dcs.cpp:1747-1783.
      tmr_div <= t_div0; tmr_cnt <= tcount;
    end else if (e_commit) begin                            // advance ONLY on a retired DSP cycle
      if (tmr_div == 16'd0) begin
        tmr_div <= t_div0;
        if (tmr_cnt == 16'd0) begin
          timer_irq <= 1'b1;                                // ADSP2105_TIMER (indx5, vector 0x18)
          tmr_cnt   <= tperiod;                             // reload period for every subsequent fire
        end else tmr_cnt <= tmr_cnt - 16'd1;
      end else tmr_div <= tmr_div - 16'd1;
    end
  end

  // ================= CAL2: IRQ latch + priority mux (adsp2100.cpp:967-998) =================
  // SPORT1-TX / TIMER are edge pulses -> latch until the engine ACKs that vector. IRQ2 is level-held
  // by the host mailbox. Priority IRQ2(0) > SPORT1-TX(3) > TIMER(5) (lower indx = higher priority).
  reg sport_tx_pend, timer_pend;
  always_ff @(posedge clk) begin
`ifdef MUT_NO_IRQCLR
    if (rst) begin sport_tx_pend <= 1'b0; timer_pend <= 1'b0; end
`else
    if (rst || irq_clr) begin sport_tx_pend <= 1'b0; timer_pend <= 1'b0; end   // F3: ADSP device_reset
`endif
    else begin
      if (sport_tx_irq)                                          sport_tx_pend <= 1'b1;
      else if (e_irq_ack && e_irq_ack_indx == SPORT_IRQ_INDX)    sport_tx_pend <= 1'b0;
      if (timer_irq)                                             timer_pend <= 1'b1;
      else if (e_irq_ack && e_irq_ack_indx == TIMER_IRQ_INDX)    timer_pend <= 1'b0;
      if (ifc_we && SPORT_IRQ_INDX == 3'd3) begin                // IFC: IRQ1 (= the SPORT1-TX line) clear / force
        if (ifc_val[2]) sport_tx_pend <= 1'b0;
        if (ifc_val[8]) sport_tx_pend <= 1'b1;
      end
    end
  end
  // SPORT0-RX (indx 2, vector 0x0C): an ASSERT/CLEAR pulse latches (execute_set_input :1167-1171) until taken; the
  // ADSP-2101 checks it after IRQ2 / SPORT0-TX and before IRQ1 / SPORT1-TX (check_irqs :976-984).
  reg sport0_pend;
  always_ff @(posedge clk)
    if (rst || irq_clr) sport0_pend <= 1'b0;
    else begin
      if (sport0_rx_irq)                                         sport0_pend <= 1'b1;
      else if (e_irq_ack && e_irq_ack_indx == 3'd2)              sport0_pend <= 1'b0;
      if (ifc_we && ifc_val[3]) sport0_pend <= 1'b0;             // IFC SPORT0-RX clear / force
      if (ifc_we && ifc_val[9]) sport0_pend <= 1'b1;
    end
  // IRQ2 sensitivity (adsp2101_device::check_irqs, adsp2100.cpp:971-974): ICNTL bit2 selects the edge
  // latch (set on the line's CLEAR->ASSERT transition, execute_set_input :1167-1171; cleared when the IRQ
  // is generated, generate_irq :898) or the live line state.
  reg irq2_q, irq2_lat;
  always_ff @(posedge clk) begin
    if (rst) begin irq2_q <= 1'b0; irq2_lat <= 1'b0; end
    else begin
      irq2_q <= irq2_req;
`ifndef MUT_NO_IRQCLR
      if (irq_clr)                                 irq2_lat <= 1'b0;   // F3 (the line level itself stays)
      else
`endif
      if (irq2_req && !irq2_q)                     irq2_lat <= 1'b1;
      else if (e_irq_ack && e_irq_ack_indx==3'd0)  irq2_lat <= 1'b0;
      if (ifc_we && ifc_val[5])  irq2_lat <= 1'b0;                     // IFC IRQ2 latch clear / force
      if (ifc_we && ifc_val[11]) irq2_lat <= 1'b1;
    end
  end
  wire irq2_chk = e_icntl2 ? irq2_lat : irq2_req;
  // A MASKED source is skipped and the chain falls through to the next (generate_irq returns false when
  // !(imask & (0x20>>indx)), adsp2100.cpp:894; check_irqs :967-999 only returns on a TAKEN irq).
  wire m_irq2  = e_imask[5];                       // 0x20>>0
  wire m_sport = e_imask[3'd5 - SPORT_IRQ_INDX];   // 0x20>>3 = bit2
  wire m_timer = e_imask[3'd5 - TIMER_IRQ_INDX];   // 0x20>>5 = bit0
  always_comb begin
    if (irq2_chk && m_irq2)            begin e_irq_take = 1'b1; e_irq_indx = 3'd0; end
    else if (sport0_pend && e_imask[3])  begin e_irq_take = 1'b1; e_irq_indx = 3'd2; end   // 0x20>>2 = bit3
    else if (sport_tx_pend && m_sport) begin e_irq_take = 1'b1; e_irq_indx = SPORT_IRQ_INDX; end
    else if (timer_pend && m_timer)    begin e_irq_take = 1'b1; e_irq_indx = TIMER_IRQ_INDX; end
    else                               begin e_irq_take = 1'b0; e_irq_indx = 3'd0; end
  end
endmodule
