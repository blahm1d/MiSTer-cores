// dcs2_sport_dac.sv -- SPORT1 autobuffer -> two DACs at 31.25 kHz (dcs.cpp:2014-2094). The DSP fills
// a stereo sample pair via SPORT-tx-mapped DM writes; the SPORT clocks them out at the sample rate
// and raises the autobuffer interrupt (the hook the engine needs -- SPORT_IRQ_INDX, calibrated to the
// MAME IRQ trace at gate 2). Compact model: a small stereo FIFO drained at 31.25 kHz.
`default_nettype none
module dcs2_sport_dac #(
  parameter int CLK_HZ      = 50_000_000,
  parameter int SAMPLE_HZ   = 31_250,
  parameter int FIFO_AW     = 4                 // 16 stereo pairs of slack
) (
  input  wire        clk,
  input  wire        rst,
  // DSP writes a sample pair through the SPORT tx path (routed by the memory decoder):
  input  wire        smp_we_l, input wire [15:0] smp_l,
  input  wire        smp_we_r, input wire [15:0] smp_r,
  // DAC out
  output reg  signed [15:0] audio_l, audio_r,
  output reg         audio_ce,       // 1-clk strobe at SAMPLE_HZ
  output reg         sport_irq,      // autobuffer interrupt pulse (drives the engine irq mux)
  output reg  [31:0] dac_underruns
);
  localparam int DIV = CLK_HZ / SAMPLE_HZ;      // 1600 @ 50 MHz
  reg [$clog2(DIV)-1:0] divc;

  // stereo staging FIFO
  reg signed [15:0] fl [0:(1<<FIFO_AW)-1];
`ifndef ZK4_MONO
  reg signed [15:0] fr [0:(1<<FIFO_AW)-1];
`else
  // sound-area ZK4_MONO (user request 2026-09-25): the pair is folded to ONE sample, mono = floor((L + R) / 2) (17-bit
  // sum, arithmetic shift: exact halving, cannot overflow int16), stored in fl only, and driven to BOTH DAC outputs so
  // Quartus merges the duplicated right-channel logic downstream (audio_out). The DSP side -- sample capture, FIFO
  // pointers, the 31.25 kHz tick, sport_irq, underruns -- is unchanged, clock for clock.
  wire signed [16:0] mono_sum = 17'(pend_l) + 17'($signed(smp_r));
`endif
  reg [FIFO_AW:0] wl, rl;                        // pair write / read pointers (extra bit for full/empty)
  wire empty = (wl==rl);
  reg signed [15:0] pend_l; reg have_l;

  always @(posedge clk) begin
    audio_ce  <= 1'b0;
    sport_irq <= 1'b0;
    if (rst) begin
      divc<=0; wl<=0; rl<=0; audio_l<=0; audio_r<=0; dac_underruns<=0; have_l<=0; pend_l<=0;
    end else begin
      // capture a stereo pair: L then R (SPORT is interleaved); push when both are present
      if (smp_we_l) begin pend_l<=$signed(smp_l); have_l<=1'b1; end
      if (smp_we_r && have_l) begin
`ifndef ZK4_MONO
        fl[wl[FIFO_AW-1:0]] <= pend_l;
        fr[wl[FIFO_AW-1:0]] <= $signed(smp_r);
`else
        fl[wl[FIFO_AW-1:0]] <= mono_sum[16:1];
`endif
        wl <= wl + 1'b1; have_l<=1'b0;
      end
      // sample-rate tick
      if (divc==DIV-1) begin
        divc<=0; audio_ce<=1'b1; sport_irq<=1'b1;    // autobuffer advance -> interrupt
        if (!empty) begin
          audio_l <= fl[rl[FIFO_AW-1:0]];
`ifndef ZK4_MONO
          audio_r <= fr[rl[FIFO_AW-1:0]];
`else
          audio_r <= fl[rl[FIFO_AW-1:0]];
`endif
          rl <= rl + 1'b1;
        end else begin
          dac_underruns <= dac_underruns + 1'b1;     // hold last sample
        end
      end else divc<=divc+1'b1;
    end
  end
endmodule
`default_nettype wire
