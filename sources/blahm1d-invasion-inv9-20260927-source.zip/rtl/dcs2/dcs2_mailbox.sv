// dcs2_mailbox.sv -- DCS2 host<->DSP mailbox (dcs.cpp:174-187, 378-382, 1450-1640). Host side has the
// EXACT zk4_dcs_stub port semantics; the DSP side is the real ADSP latch access at DM 0x0400-0x0407.
// The real engine now PRODUCES the boot reply sequence (0x79 then 0x01) by running boot code, so this
// block is just the faithful latch pair + IRQ2-on-host-write + the reset/halt control.
`default_nettype none
module dcs2_mailbox #(
  // LATCH_STATUS = 1 (Invasion): the MAME DCS2 DSP-side registers the MK4 firmware never reads -- 0x0402 read =
  // m_output_control (output_control_r :1666-1674, written by the DSP's 0x0402 writes, output_control_delayed_w
  // :1651-1656), 0x0403 = latch_status_r (:1474-1486: 0x80 input full, 0x40 output empty, | the I/O ASIC FIFO status
  // & 0x38 = 0x08 "empty": midwayic.cpp:906-918, no FIFO on Zeus), and data2 (the host's SOUNDSTAT high byte) =
  // m_output_control (data2_r :1677-1683). 0 = the MK4 model as gated (0x0402 = {in_full, out_full}, data2 = 0).
  parameter bit LATCH_STATUS = 1'b0
) (
  input  wire        clk,
  input  wire        rst,            // game reset
  // ---- host side (zk4_dcs_stub semantics) ----
  input  wire        data_w,         // host wrote a command (1-clk strobe)
  input  wire [15:0] wdata,
  input  wire        ack_w,          // host acked the output latch
  input  wire        data_r,         // host read the output latch
  input  wire        reset_w,        // host reset strobe
  input  wire        reset_level,    // level accompanying reset_w
  output wire [15:0] control,        // bit11 input-empty, bit10 output-empty
  output wire [15:0] data, data2,
  output wire        input_empty, output_full,
  // ---- DSP side: DM 0x0400-0x0407 access (serviced by the memory decoder) ----
  input  wire        dm_acc,         // 1-clk strobe: a DM access to 0x0400-0x0407 commits this cycle
  input  wire        dm_we,
  input  wire [2:0]  dm_off,         // addr - 0x0400
  input  wire [15:0] dm_wdata,
  output reg  [15:0] dm_rdata,       // combinational value for dm_off
  // ---- to the engine ----
  output reg         irq2_req,       // host command pending -> IRQ2 (indx 2)
  output reg         snd_reset       // hold the sound engine in reset (halt) when high
);
  reg [15:0] in_latch, out_latch;
  reg        in_full, out_full;
  reg        halted;
  reg [15:0] out_ctl;                                             // m_output_control (LATCH_STATUS)

  assign control      = {4'd0, ~in_full, ~out_full, 10'd0};
  assign data         = out_latch;
  assign data2        = LATCH_STATUS ? out_ctl : 16'd0;
  assign input_empty  = ~in_full;
  assign output_full  = out_full;

  // DSP-side read mux (combinational): 0x0400 input latch, 0x0402 control/flags (0x0403 latch status: LATCH_STATUS).
  always @(*) begin
    case (dm_off)
      3'd0: dm_rdata = in_latch;                                  // 0x0400 input latch read
      3'd2: dm_rdata = LATCH_STATUS ? out_ctl : {14'd0, in_full, out_full};   // 0x0402
      3'd3: dm_rdata = LATCH_STATUS ? {8'd0, in_full, ~out_full, 6'b001000} : 16'hffff;   // 0x0403 latch_status_r
      default: dm_rdata = 16'hffff;
    endcase
  end

  always @(posedge clk) begin
    if (rst) begin
      in_latch<=16'd0; out_latch<=16'd0; in_full<=1'b0; out_full<=1'b0; out_ctl<=16'd0;
      irq2_req<=1'b0; snd_reset<=1'b0; halted<=1'b0;
    end else begin
      // ---- host writes a command ----
      if (data_w) begin in_latch<=wdata; in_full<=1'b1; irq2_req<=1'b1; end
      // ---- host consumes the output latch ----
      if (data_r) out_full<=1'b0;
      if (ack_w)  out_full<=1'b0;
      // ---- host reset / halt control ----
      if (reset_w) begin
        // going low: halt + dcs_reset (dcs.cpp:1458-1466 -> :543): IRQ2 line cleared (:582), comm bits
        // SET_INPUT_EMPTY / SET_OUTPUT_EMPTY (:585-586).
        if (!reset_level) begin halted<=1'b1; snd_reset<=1'b1; in_full<=1'b0; out_full<=1'b0; irq2_req<=1'b0; end
        else if (halted)  begin halted<=1'b0; snd_reset<=1'b0; end
      end
      // ---- DSP-side latch access ----
      if (dm_acc) begin
        // DCS2 has auto-ack OFF (dcs.cpp:852 m_auto_ack=false): a READ of 0x0400 (input_latch_r :1555-1563)
        // returns the latch WITHOUT acking. The ACK is the DSP WRITE to 0x0400 (map :365 -> input_latch_ack_w
        // :1544-1549): SET_INPUT_EMPTY + IRQ2 line CLEAR. (Was: read cleared both.)
        if ( dm_we && dm_off==3'd0) begin in_full<=1'b0; irq2_req<=1'b0; end   // ack input latch
        if ( dm_we && dm_off==3'd1) begin out_latch<=dm_wdata; out_full<=1'b1; end // write output latch
        if ( dm_we && dm_off==3'd2) out_ctl <= dm_wdata;          // 0x0402 output_control_w (LATCH_STATUS reads it)
      end
    end
  end
endmodule
`default_nettype wire
