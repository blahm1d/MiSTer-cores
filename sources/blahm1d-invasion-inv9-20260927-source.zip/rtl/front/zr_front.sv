// zr_front.sv -- Zeus 1 (MK4) renderer FRONT END v1 (R5, 50 MHz): everything between the CPU's register writes and the
// setup engine / pixel pipe. Written from MAME master 61c79406 midzeus_v.cpp (copies in zeus/references/mame-master):
//   zeus_w / register16_w / register32_w / zeus_register_update (:420-737), zeus_pointer_w (:442-500),
//   zeus_fifo_process (:747-955, mk4: m_is_mk4b false), zeus_draw_model (:965-1050), zeus_draw_quad (:1060-1221),
//   debug quad (:580-621), waveram addressing (:87-143); poly.h zclip_if_less (:1301-1332).
// v1 is the ORDER reference: one engine, one step at a time. Gate: tb_zr_front.cpp compares the output stream
// word-for-word with zr1 --fronttap, plus the register file and the persistent state at every frame.
//
// Output: a 32-bit word stream in zr1's --fronttap record format (tags included):
//   RB  52423031 off | CLR 434C5231 x0 x1 y0 y1 | QUD 51554431 + 13 object words + cliprect + 4 x 6 floats |
//   DBQ 44425131 solid x0 x1 y0 y1 + 4 x (x, y) | HWW 48575731 ram off lanes lo hi | HRD 48524431 ram off lo hi
// Wave RAM: one port, 64-bit blocks (block index = byte offset / 8), one request outstanding.
//
// Arithmetic facts used (each exact):
//   * transform: s16*s16 products fit s32; sum + point fits 35 bits; the "rounding hack" (x + 0x4000) & ~0x7fff leaves
//     x = k * 2^15 with |k| < 2^18, so (float)x = i2f(k) with the exponent + 15 (exact), and x < 512.0 <=> k <= 0.
//   * cull: dot = 2^15 * sum(rotnormal[r] * k[r]): same sign as the 47-bit sum (MAME's s64 never overflows).
//   * u << ushift, v << vshift <= 65280, and 65535: exact in float.
//   * 512 / z and the z-clip fraction: IEEE divides (fp_rcp4 is a general a / b).
// Not modelled (unobservable): the light vector (0x23 / 0x2e), unkbase (0x02c0f0). Untextured quads carry texture
// fields 0 (zr1's convention; MAME's are stale pool values, unused unless the quad is also non-solid -- zr1 counts).
module zr_front import fp32_pkg::*; (
  input  logic        clk,
  input  logic        rst,
  input  logic        wr_valid,              // CPU writes (zeus_w: offset = word index 0..0x3ff within 0x880000)
  output logic        wr_ready,
  input  logic [9:0]  wr_off,
  input  logic [31:0] wr_data,
  input  logic [9:0]  rd_off,                // raw register file read (valid when idle; 1-clock latency)
  output logic [31:0] rd_data,
  output logic        m_req,                 // wave RAM
  output logic        m_we,
  output logic        m_ram,                 // 0: wave RAM 0, 1: wave RAM 1
  output logic [20:0] m_blk,                 // 64-bit block index
  output logic [3:0]  m_lanes,               // write: 16-bit lane enables
  output logic [63:0] m_wdata,
  input  logic        m_ack,
  input  logic [63:0] m_rdata,
  output logic        o_valid,               // output record stream
  input  logic        o_ready,
  output logic [31:0] o_word,
  output logic        idle,
`ifdef ZR_SEED
  input  logic        sd_we,
  input  logic [3:0]  sd_sel,                // 0 reg, 1 fifo word, 2 fifo_n, 3 matrix, 4 point, 5 palbase, 6 objdata, 7 clip
  input  logic [9:0]  sd_idx,
  input  logic [31:0] sd_data,
  output logic [31:0] dbg_state [20],        // matrix 9, point 3, palbase, objdata, clip 4, fifo_n, 0
`endif
  output logic [31:0] st_quads, st_culled, st_emitted, st_exc, st_busy
);
  // ---------------- persistent state ----------------
  logic signed [15:0] mtx [3][3];
  logic signed [31:0] pnt [3];
  logic [31:0] palbase, objdata, r80, f0;
  logic signed [31:0] clp [4];                        // min_x max_x min_y max_y
  logic [4:0]  fifo_n;

  // ---------------- RAMs ----------------
  logic rf_we; logic [9:0] rf_wa, rf_ra; logic [31:0] rf_wd, rf_q;
  zr_sdp #(32, 10) u_rf (.clk, .we(rf_we), .waddr(rf_wa), .wdata(rf_wd), .raddr(rf_ra), .rdata(rf_q));
  logic cb_we; logic [5:0] cb_wa, cb_ra; logic [31:0] cb_wd, cb_q;    // command words: FIFO 0..19, model 32..45
  zr_sdp #(32, 6) u_cb (.clk, .we(cb_we), .waddr(cb_wa), .wdata(cb_wd), .raddr(cb_ra), .rdata(cb_q));
  logic cv_we; logic [5:0] cv_wa, cv_ra; logic [31:0] cv_wd, cv_q;    // clipvert[8] x 6 fields: PERSISTENT like the
  zr_sdp #(32, 6) u_cv (.clk, .we(cv_we), .waddr(cv_wa), .wdata(cv_wd), .raddr(cv_ra), .rdata(cv_q));  // MAME stack slot
  assign rd_data = rf_q;

  // ---------------- output FIFO (64 words) ----------------
  logic of_we; logic [31:0] of_wd; logic [5:0] of_wp, of_rp; logic [6:0] of_cnt; logic [31:0] of_q; logic of_rd, of_pend;
  zr_sdp #(32, 6) u_of (.clk, .we(of_we), .waddr(of_wp), .wdata(of_wd), .raddr(of_rp), .rdata(of_q));
  logic [6:0] of_free; assign of_free = 7'd63 - of_cnt;       // one word of slack for a write not yet counted
  assign of_rd = !of_pend && (of_cnt != 0) && (!o_valid || o_ready);
  always_ff @(posedge clk) begin
    if (rst) begin of_wp <= '0; of_rp <= '0; of_cnt <= '0; o_valid <= 1'b0; of_pend <= 1'b0; end
    else begin
      if (o_valid && o_ready) o_valid <= 1'b0;
      if (of_pend) begin o_word <= of_q; o_valid <= 1'b1; end
      of_pend <= of_rd;
      if (of_rd) of_rp <= of_rp + 6'd1;
      if (of_we) of_wp <= of_wp + 6'd1;
      of_cnt <= of_cnt + 7'(of_we) - 7'(of_rd);
    end
  end

  // ---------------- float units + tagged write-back ----------------
  typedef struct packed { logic v; logic [2:0] kind; logic [5:0] idx; } tag_t;
  localparam logic [2:0] K_FR = 3'd1, K_CV = 3'd2, K_CVX = 3'd3, K_CVY = 3'd4;   // float reg / clipvert / + max x / + max y
  logic [31:0] add_a, add_b, mul_a, mul_b, add_y, mul_y; logic add_sub, add_e, mul_e; tag_t add_t, mul_t;
  tag_t at [5], mt [5];
  fp_add5 u_add (.clk, .a(add_a), .b(add_b), .sub(add_sub), .y(add_y), .exc(add_e));
  fp_mul5 u_mul (.clk, .a(mul_a), .b(mul_b), .y(mul_y), .exc(mul_e));
  logic dv_go, dv_done, dv_e, dv_busy; logic [31:0] dv_a, dv_b, dv_y; logic [3:0] dv_dst;
  fp_rcp4 u_div (.clk, .rst, .start(dv_go), .a(dv_a), .b(dv_b), .done(dv_done), .y(dv_y), .exc(dv_e), .busy(dv_busy));
  logic [31:0] fr [12];                                                  // float temporaries
  localparam int FR_NUM = 0, FR_DEN = 1, FR_D0 = 2, FR_PX = 8, FR_PY = 9, FR_OOZ = 10, FR_FRAC = 11;
  logic [31:0] maxx, maxy;
  logic pipes_busy; assign pipes_busy = at[0].v || at[1].v || at[2].v || at[3].v || at[4].v ||
                                        mt[0].v || mt[1].v || mt[2].v || mt[3].v || mt[4].v || dv_busy || dv_done;

  // ---------------- engine state ----------------
  typedef enum logic [6:0] {
    S_IDLE, S_RW0, S_RW1, S_UPD, S_RB,
    S_HW0, S_HW1, S_HW2, S_HW3, S_HW4, S_HW5, S_HW6, S_HR0, S_HR1, S_HR2, S_HR3, S_HR4,
    S_CL0, S_CL1, S_CL2, S_CL3,
    S_F0, S_F1, S_FR0, S_FR1, S_FR2, S_FX,
    S_SW0, S_SW1, S_MXP, S_MXL, S_MXP2,
    S_DB0, S_DB1, S_EM,
    S_MSTART, S_MCHK, S_MPOP, S_MW0, S_MW1, S_MDEC, S_MTEX, S_MNEXT,
    S_Q0, S_Q1, S_Q2, S_QV0, S_QVA, S_QV1, S_QV2, S_QV3, S_QV4, S_QN0, S_QN1, S_QN2, S_QN3, S_QN4, S_QV5,
    S_QZ0, S_QZC, S_QCP, S_QZN, S_QI0, S_QI1, S_QI2, S_QI3, S_QI4, S_QI5, S_QI6, S_QI7, S_QI8, S_QI9,
    S_QP, S_QP0, S_QP1, S_QP2, S_QP3, S_QP4, S_QP5, S_QP6, S_QP7, S_QP8,
    S_QA0, S_QA1, S_QA2, S_QA3, S_QA4,
    S_QO0, S_QO1, S_QO2, S_QO3, S_QO4, S_QO5
  } st_t;
  st_t st, rw_ret, q_ret;

  logic [9:0]  w_off;  logic [31:0] w_data;
  logic [9:0]  rw_off; logic [31:0] rw_data; logic rw32; logic [31:0] rw_new;
  logic [9:0]  u_off;  logic [31:0] u_val;
  logic [31:0] b0, b2, b4, b6, t0, t1, t2, t3;
  logic [5:0]  fn;                                   // FIFO word count after the append
  logic [3:0]  sk;
  logic [31:0] sw [9];                               // FIFO words 1..9 (matrix) / debug-quad registers 08..0e
  logic [31:0] texdata, md0, m_hi; logic [4:0] dcnt; logic mdone; logic [8:0] ment;
  logic qlong; logic [5:0] qb; logic [31:0] ctrl, r04, nrm, ixy, iuvz;
  logic [1:0] qi, mrow;
  logic signed [19:0] vk [4][3]; logic [7:0] vu [4], vv [4];
  logic signed [31:0] pr [3]; logic signed [24:0] rn [3];
  logic [2:0] nout, vn, ff, pi; logic prevc;
  logic [5:0] ocnt; logic em_dbq;

  // multipliers: transform / rotnormal / matrix product (3 x s16*s16); cull dot (3 x s25*s20)
  logic signed [15:0] ma [3], mb [3]; logic signed [31:0] mp [3];
  always_comb for (int k = 0; k < 3; k++) mp[k] = 32'(ma[k]) * 32'(mb[k]);
  logic signed [46:0] dotp;
  always_comb dotp = 47'(rn[0]) * 47'(vk[0][0]) + 47'(rn[1]) * 47'(vk[0][1]) + 47'(rn[2]) * 47'(vk[0][2]);

  // vertex field as float (exact): f 0..2 = x y z (k * 2^15), 3 = u << ushift, 4 = v << vshift, 5 = 65535
  function automatic logic [31:0] k15(input logic signed [19:0] k);
    fres_t r; r = fp_i2f(32'(k));
    return (k == 0) ? 32'd0 : {r.v[31], r.v[30:23] + 8'd15, r.v[22:0]};
  endfunction
  logic [3:0] ush, vsh; assign ush = 4'd8 - 4'(r04[5:4]); assign vsh = 4'd8 - 4'(r04[7:6]);
  function automatic logic [31:0] vfield(input logic [1:0] v, input logic [2:0] f);
    fres_t r;
    case (f)
      3'd0, 3'd1, 3'd2: return k15(vk[v][f]);
      3'd3: begin r = fp_i2f(32'(16'(vu[v]) << ush)); return r.v; end
      3'd4: begin r = fp_i2f(32'(16'(vv[v]) << vsh)); return r.v; end
      default: return 32'h477fff00;
    endcase
  endfunction

  // waveram addressing (block index = byte offset / 8)
  function automatic logic [20:0] blk0(input logic [31:0] a); return 21'({a[22:12], a[8:0]}); endfunction   // w0_block
  function automatic logic [20:0] exp0(input logic [31:0] a); return 21'({a[26:16], a[8:0]}); endfunction   // w0_expanded
  function automatic logic [20:0] exp1(input logic [31:0] a); return 21'({a[24:16], a[8:0]}); endfunction   // w1_expanded

  // ---------------- model walker (fetch side): streams n blocks into a 16-deep FIFO ----------------
  logic wk_start; logic [20:0] wk_base; logic [8:0] wk_n;
  logic wk_on, wk_wait; logic [20:0] wk_addr; logic [8:0] wk_left;
  logic wf_we, wf_pop; logic [3:0] wf_wp, wf_rp; logic [4:0] wf_cnt; logic [63:0] wf_q;
  zr_sdp #(64, 4) u_wf (.clk, .we(wf_we), .waddr(wf_wp), .wdata(m_rdata), .raddr(wf_rp), .rdata(wf_q));
  logic e_req, e_we, e_ram; logic [20:0] e_blk; logic [3:0] e_lanes; logic [63:0] e_wd;
  assign m_req = wk_on ? wk_wait : e_req;
  assign m_we = wk_on ? 1'b0 : e_we;
  assign m_ram = wk_on ? 1'b0 : e_ram;
  assign m_blk = wk_on ? wk_addr : e_blk;
  assign m_lanes = e_lanes; assign m_wdata = e_wd;
  assign wf_we = wk_on && wk_wait && m_ack;
  always_ff @(posedge clk) begin
    if (rst) begin wk_on <= 1'b0; wk_wait <= 1'b0; wf_wp <= '0; wf_rp <= '0; wf_cnt <= '0; end
    else begin
      if (wk_start) begin wk_on <= 1'b1; wk_addr <= wk_base; wk_left <= wk_n; wk_wait <= 1'b0; end
      else if (wk_on) begin
        if (wk_wait) begin
          if (m_ack) begin wk_wait <= 1'b0; wk_addr <= wk_addr + 21'd1; wk_left <= wk_left - 9'd1; if (wk_left == 9'd1) wk_on <= 1'b0; end
        end else if (wf_cnt < 5'd15) wk_wait <= 1'b1;
      end
      if (wf_we) wf_wp <= wf_wp + 4'd1;
      if (wf_pop) wf_rp <= wf_rp + 4'd1;
      wf_cnt <= wf_cnt + 5'(wf_we) - 5'(wf_pop);
    end
  end

  // ---------------- combinational drive ----------------
  logic [7:0] fcmd, mcmd; assign fcmd = f0[31:24]; assign mcmd = md0[31:24];
  logic mquad; assign mquad = (mcmd == 8'h25) || (mcmd == 8'h30) || (mcmd == 8'h28);
  logic [5:0] xyo; assign xyo = qlong ? 6'd2 : 6'd1;
  logic [1:0] iv1, iv2; assign iv2 = vn[1:0]; assign iv1 = (vn == 3'd0) ? 2'd3 : 2'(vn - 3'd1);
  logic [31:0] fv1 [6], fv2 [6];
  always_comb for (int f = 0; f < 6; f++) begin fv1[f] = vfield(iv1, 3'(f)); fv2[f] = vfield(iv2, 3'(f)); end
  logic thisc; assign thisc = (vk[iv2][2] <= 0);
  // QUD word w >= 18 lives at clipvert {vertex (w-18)/6, field (w-18)%6}
  function automatic logic [5:0] cvw(input logic [5:0] w);
    logic [5:0] j; j = w - 6'd18; return {3'(j / 6), 3'(j % 6)};
  endfunction

  always_comb begin
    rf_ra = rd_off; cb_ra = '0; cv_ra = '0;
    add_a = '0; add_b = '0; add_sub = 1'b0; add_t = '0;
    mul_a = '0; mul_b = '0; mul_t = '0;
    dv_go = 1'b0; dv_a = '0; dv_b = '0;
    wf_pop = 1'b0; wk_start = 1'b0; wk_base = '0; wk_n = '0;
    cv_we = 1'b0; cv_wa = '0; cv_wd = '0;
    for (int k = 0; k < 3; k++) begin ma[k] = '0; mb[k] = '0; end
    case (st)
      S_RW0: rf_ra = {rw_off[9:1], 1'b0};
      S_HW0: rf_ra = 10'h0b6; S_HW1: rf_ra = 10'h0b0; S_HW2: rf_ra = 10'h0b2; S_HW3: rf_ra = 10'h0b4;
      S_HR0: rf_ra = 10'h0b6;
      S_CL0: rf_ra = 10'h0c6; S_CL1: rf_ra = 10'h0c8; S_CL2: rf_ra = 10'h0ca;
      S_FR0: begin rf_ra = 10'h000; cb_ra = 6'd1; end
      S_FR1: begin rf_ra = 10'h006; cb_ra = 6'd2; end
      S_SW0: cb_ra = 6'(sk);
      S_MXP: begin : mxp
        logic [1:0] r, c; r = 2'(sk / 3); c = 2'(sk % 3);
        // m1 row r: lo / hi of d4|d8|d9, hi of d5|d6|d7; m2 column c: lo / hi of d1|d2|d3, lo of d5|d6|d7 (sw[k] = d(k+1))
        ma[0] = $signed(sw[r == 0 ? 3 : r == 1 ? 7 : 8][15:0]); ma[1] = $signed(sw[r == 0 ? 3 : r == 1 ? 7 : 8][31:16]);
        ma[2] = $signed(sw[r == 0 ? 4 : r == 1 ? 5 : 6][31:16]);
        mb[0] = $signed(sw[c][15:0]); mb[1] = $signed(sw[c][31:16]); mb[2] = $signed(sw[4 + c][15:0]);
      end
      S_MXL: cb_ra = 6'(4'd10 + sk);
      S_DB0: rf_ra = (sk == 0) ? 10'h000 : 10'(10'h008 + 10'({sk[2:0], 1'b0}) - 10'd2);
      S_MCHK: if (objdata != 0 && !mdone) begin wk_start = 1'b1; wk_base = blk0(objdata); wk_n = 9'(objdata[31:24]) + 9'd1; end
      S_MW0: wf_pop = 1'b1;
      S_Q0:  begin rf_ra = 10'h004; cb_ra = qb; end
      S_Q1:  cb_ra = qb + (qlong ? 6'd1 : 6'd9);
      S_Q2:  cb_ra = qb + xyo;
      S_QV0: cb_ra = qb + xyo + 6'd1 + 6'({qi, 1'b0});
      S_QV1, S_QV2, S_QV3: begin
        ma[0] = $signed(ixy[15:0]); ma[1] = $signed(ixy[31:16]); ma[2] = $signed(iuvz[15:0]);
        for (int k = 0; k < 3; k++) mb[k] = mtx[mrow][k];
      end
      S_QN0, S_QN1, S_QN2: begin
        ma[0] = 16'($signed(nrm[7:0])); ma[1] = 16'($signed(nrm[15:8])); ma[2] = 16'($signed(nrm[23:16]));
        for (int k = 0; k < 3; k++) mb[k] = mtx[mrow][k];
      end
      S_QV5: cb_ra = qb + xyo + 6'({qi + 2'd1, 1'b0});
      // z-clip interpolation: frac = (512 - v1.z) / (v2.z - v1.z); out = v1 + frac * (v2 - v1)
      S_QI0: begin add_a = 32'h44000000; add_b = fv1[2]; add_sub = 1'b1; add_t = '{1'b1, K_FR, 6'(FR_NUM)}; end
      S_QI1: begin add_a = fv2[2]; add_b = fv1[2]; add_sub = 1'b1; add_t = '{1'b1, K_FR, 6'(FR_DEN)}; end
      S_QI2: if (!pipes_busy) begin dv_go = 1'b1; dv_a = fr[FR_NUM]; dv_b = fr[FR_DEN]; end
      S_QI4: begin add_a = fv2[ff]; add_b = fv1[ff]; add_sub = 1'b1; add_t = '{1'b1, K_FR, 6'(FR_D0) + 6'(ff)}; end
      S_QI6: begin mul_a = fr[FR_FRAC]; mul_b = fr[FR_D0 + ff]; mul_t = '{1'b1, K_FR, 6'(FR_D0) + 6'(ff)}; end
      S_QI8: begin add_a = fv1[ff]; add_b = fr[FR_D0 + ff]; add_t = '{1'b1, K_CV, {nout, ff}}; end
      // projection: ooz = 512 / z; x = x * ooz + 200.5; y = y * ooz + 128.5
      S_QP0: cv_ra = {pi, 3'd2};
      S_QP1: begin dv_go = 1'b1; dv_a = 32'h44000000; dv_b = cv_q; end
      S_QP2: cv_ra = {pi, 3'd0};
      S_QP3: begin cv_ra = {pi, 3'd1}; mul_a = cv_q; mul_b = fr[FR_OOZ]; mul_t = '{1'b1, K_FR, 6'(FR_PX)}; end
      S_QP4: begin mul_a = cv_q; mul_b = fr[FR_OOZ]; mul_t = '{1'b1, K_FR, 6'(FR_PY)}; end
      S_QP6: begin add_a = fr[FR_PX]; add_b = 32'h43488000; add_t = '{1'b1, K_CVX, {pi, 3'd0}}; end   // + 200.5
      S_QP7: begin add_a = fr[FR_PY]; add_b = 32'h43008000; add_t = '{1'b1, K_CVY, {pi, 3'd1}}; end   // + 128.5
      // adjust: x == maxx -> x += 0.0005f (same for y)
      S_QA0: cv_ra = {pi, 3'd0};
      S_QA1: begin cv_ra = {pi, 3'd1}; if (fp_eq(cv_q, maxx)) begin add_a = cv_q; add_b = 32'h3a03126f; add_t = '{1'b1, K_CV, {pi, 3'd0}}; end end
      S_QA2: if (fp_eq(cv_q, maxy)) begin add_a = cv_q; add_b = 32'h3a03126f; add_t = '{1'b1, K_CV, {pi, 3'd1}}; end
      S_QO0: rf_ra = 10'h000; S_QO1: rf_ra = 10'h07e; S_QO2: rf_ra = 10'h04e; S_QO3: rf_ra = 10'h05c;
      S_QO5: cv_ra = cvw(ocnt + 6'd1);
      default: ;
    endcase
    // clipvert writes: float write-back, else the z-clip copy of an unclipped vertex
    if (at[4].v && at[4].kind != K_FR) begin cv_we = 1'b1; cv_wa = at[4].idx; cv_wd = add_y; end
    else if (st == S_QCP && !thisc) begin cv_we = 1'b1; cv_wa = {nout, ff}; cv_wd = fv2[ff]; end
  end

  // QUD words 0..17 (then clipvert words)
  logic [31:0] tex_off, obj_w; logic tex_on, tex_bad; logic [2:0] tfv; logic [9:0] texw; logic [30:0] tex_t;
  always_comb begin
    tex_on = ctrl[24];
    tex_bad = tex_on && texdata[17:16] != 2'd1 && texdata[17:16] != 2'd2;
    tfv = !tex_on ? 3'd0 : texdata[17:16] == 2'd1 ? (texdata[21] ? 3'd2 : 3'd1) : (texdata[21] ? 3'd4 : 3'd3);
    texw = 10'(10'd512 >> texdata[24:22]);
    // w0_texture: (((addr & ~1) * width) / 8) % 2^20 blocks, addr = texdata[31:26] : texdata[15:0], width = 512 >> s
    tex_t = 31'({texdata[31:26], texdata[15:1], 1'b0}) << (4'd9 - 4'(texdata[24:22]));
    tex_off = {9'd0, tex_t[22:3], 3'd0};
    case (ocnt)
      6'd0:  obj_w = 32'h51554431;
      6'd1:  obj_w = ctrl;
      6'd2:  obj_w = t0 & 32'h7fff;                          // solidcolor = reg 00
      6'd3:  obj_w = 32'($signed(t1[31:16]));                // zoffset = reg 7e >> 16
      6'd4:  obj_w = ctrl[16] ? 32'd0 : 32'h100;             // transcolor
      6'd5:  obj_w = tex_on ? 32'(texw) : 32'd0;
      6'd6:  obj_w = tex_on ? 32'(ctrl[15:0]) : 32'd0;       // voffset
      6'd7:  obj_w = t2;                                     // alpha = reg 4e
      6'd8:  obj_w = t3;                                     // blend = reg 5c
      6'd9:  obj_w = 32'(!r04[11]);
      6'd10: obj_w = 32'(r04[9]);
      6'd11: obj_w = 32'(tfv);
      6'd12: obj_w = tex_on ? tex_off : 32'd0;
      6'd13: obj_w = {8'd0, blk0(palbase), 3'd0};
      6'd14: obj_w = clp[0]; 6'd15: obj_w = clp[1]; 6'd16: obj_w = clp[2]; 6'd17: obj_w = clp[3];
      default: obj_w = cv_q;
    endcase
  end

  // record emitter for CLR / DBQ (S_EM): em_dbq selects the debug quad (14 words) over the clear (5)
  logic [31:0] em_w;
  always_comb begin
    em_w = '0;
    if (em_dbq) begin
      case (sk)
        4'd0: em_w = 32'h44425131; 4'd1: em_w = {16'd0, t0[15:0]};
        4'd2: em_w = clp[0]; 4'd3: em_w = clp[1]; 4'd4: em_w = clp[2]; 4'd5: em_w = clp[3];
        default: begin : dq
          fres_t r; logic [3:0] j; logic [31:0] w;
          j = sk - 4'd6; w = sw[j[2:1]]; r = fp_i2f16(j[0] ? w[31:16] : w[15:0]); em_w = r.v;
        end
      endcase
    end else case (sk)
      4'd0: em_w = 32'h434C5231; 4'd1: em_w = clp[0]; 4'd2: em_w = clp[1]; 4'd3: em_w = clp[2]; default: em_w = clp[3];
    endcase
  end

  assign wr_ready = (st == S_IDLE);
  assign idle = (st == S_IDLE) && (of_cnt == 0) && !of_pend && !o_valid && !of_we && !wk_on;

  always_ff @(posedge clk) begin
    rf_we <= 1'b0; cb_we <= 1'b0; of_we <= 1'b0;
    if (rst) begin
      st <= S_IDLE; e_req <= 1'b0; fifo_n <= '0; objdata <= '0; palbase <= '0; r80 <= '0; f0 <= '0;
      st_quads <= 0; st_culled <= 0; st_emitted <= 0; st_exc <= 0; st_busy <= 0;
      for (int k = 0; k < 5; k++) begin at[k] <= '0; mt[k] <= '0; end
    end else begin
      if (st != S_IDLE) st_busy <= st_busy + 1;
      // ---- float write-back ----
      at[0] <= add_t; mt[0] <= mul_t;
      for (int k = 1; k < 5; k++) begin at[k] <= at[k - 1]; mt[k] <= mt[k - 1]; end
      if (at[4].v) begin
        if (add_e) st_exc <= st_exc + 1;
        if (at[4].kind == K_FR) fr[at[4].idx[3:0]] <= add_y;
        if (at[4].kind == K_CVX && fp_lt(maxx, add_y)) maxx <= add_y;        // std::max(maxx, x) = maxx < x ? x : maxx
        if (at[4].kind == K_CVY && fp_lt(maxy, add_y)) maxy <= add_y;
      end
      if (mt[4].v) begin if (mul_e) st_exc <= st_exc + 1; fr[mt[4].idx[3:0]] <= mul_y; end
      if (dv_go) dv_dst <= (st == S_QI2) ? 4'(FR_FRAC) : 4'(FR_OOZ);
      if (dv_done) begin if (dv_e) st_exc <= st_exc + 1; fr[dv_dst] <= dv_y; end
      if (e_req && m_ack) e_req <= 1'b0;

      case (st)
        S_IDLE: if (wr_valid) begin
          // zeus_w: 32-bit if reg 0x80 bit 17, else 16-bit halves
          rw_off <= wr_off; rw_data <= wr_data; rw32 <= r80[17]; rw_ret <= S_IDLE; st <= S_RW0;
        end
        // ---- register write (register16_w / register32_w), then zeus_register_update on EVEN offsets ----
        S_RW0: st <= S_RW1;
        S_RW1: begin : rw
          logic [31:0] nv;
          nv = rw32 ? rw_data : rw_off[0] ? {rw_data[15:0], rf_q[15:0]} : {rf_q[31:16], rw_data[15:0]};
          rf_we <= 1'b1; rf_wa <= {rw_off[9:1], 1'b0}; rf_wd <= nv; rw_new <= nv;
          if ({rw_off[9:1], 1'b0} == 10'h080) r80 <= nv;
          if (!rw_off[0]) begin u_off <= rw_off; u_val <= nv; st <= S_UPD; end else st <= rw_ret;
        end
        S_UPD: begin
          st <= rw_ret;
          case (u_off)
            10'h052: begin rf_we <= 1'b1; rf_wa <= 10'h0b2; rf_wd <= u_val; end
            10'h060: if (u_val[0] && r80[23:0] == 24'h22fcff) begin sk <= '0; st <= S_DB0; end
            10'h070: pnt[0] <= {u_val[15:0], 16'd0};
            10'h072: pnt[1] <= {u_val[15:0], 16'd0};
            10'h074: pnt[2] <= {u_val[15:0], 16'd0};
            10'h084: begin sk <= '0; st <= S_RB; end
            10'h0b0, 10'h0b2: st <= S_HW0;
            10'h0b4: st <= S_HR0;
            10'h0c0, 10'h0c2, 10'h0c4, 10'h0c6, 10'h0c8, 10'h0ca: st <= S_CL0;
            10'h0e0: st <= S_F0;
            default: ;
          endcase
        end
        // render base: w1_expanded(reg84 << 16) = block (reg84 & 0x1ff) * 512
        S_RB: if (sk != 0 || of_free >= 7'd2) begin
          of_we <= 1'b1; of_wd <= (sk == 0) ? 32'h52423031 : {11'd0, u_val[8:0], 12'd0};
          if (sk == 0) sk <= 4'd1; else st <= rw_ret;
        end
        // ---- host wave RAM write (b0 / b2 update) ----
        S_HW0: st <= S_HW1;
        S_HW1: begin b6 <= rf_q; st <= S_HW2; end
        S_HW2: begin b0 <= rf_q; st <= S_HW3; end
        S_HW3: begin b2 <= rf_q; st <= S_HW4; end
        S_HW4: begin
          b4 <= rf_q;
          if (b6[31:16] != 0 && ((u_off == 10'h0b0 && !b6[25]) || (u_off == 10'h0b2 && b6[25]))) begin
            e_req <= 1'b1; e_we <= 1'b1; e_ram <= b6[31]; e_blk <= b6[31] ? exp1(rf_q) : exp0(rf_q);
            e_lanes <= b6[23:20]; e_wd <= {b2, b0}; st <= S_HW5;
          end else st <= rw_ret;
        end
        S_HW5: if (!e_req && of_free >= 7'd6) begin sk <= '0; st <= S_HW6; end
        S_HW6: begin
          of_we <= 1'b1;
          case (sk)
            4'd0: of_wd <= 32'h48575731; 4'd1: of_wd <= 32'(e_ram); 4'd2: of_wd <= {8'd0, e_blk, 3'd0};
            4'd3: of_wd <= 32'(e_lanes); 4'd4: of_wd <= b0; default: of_wd <= b2;
          endcase
          sk <= sk + 4'd1;
          if (sk == 4'd5) begin
            if (b6[17]) begin rf_we <= 1'b1; rf_wa <= 10'h0b4; rf_wd <= b4 + 32'd1; end
            st <= rw_ret;
          end
        end
        // ---- host wave RAM read (b4 update) ----
        S_HR0: st <= S_HR1;
        S_HR1: if (rf_q[16]) begin
            e_req <= 1'b1; e_we <= 1'b0; e_ram <= rf_q[31]; e_blk <= rf_q[31] ? exp1(u_val) : exp0(u_val); st <= S_HR2;
          end else st <= rw_ret;
        S_HR2: if (e_req && m_ack) begin
            b0 <= m_rdata[31:0]; b2 <= m_rdata[63:32]; rf_we <= 1'b1; rf_wa <= 10'h0b0; rf_wd <= m_rdata[31:0]; st <= S_HR3;
          end
        S_HR3: begin rf_we <= 1'b1; rf_wa <= 10'h0b2; rf_wd <= b2; if (of_free >= 7'd5) begin sk <= '0; st <= S_HR4; end end
        S_HR4: begin
          of_we <= 1'b1;
          case (sk)
            4'd0: of_wd <= 32'h48524431; 4'd1: of_wd <= 32'(e_ram); 4'd2: of_wd <= {8'd0, e_blk, 3'd0};
            4'd3: of_wd <= b0; default: of_wd <= b2;
          endcase
          sk <= sk + 4'd1; if (sk == 4'd4) st <= rw_ret;
        end
        // ---- cliprect from the CRTC registers (:699-719) ----
        S_CL0: st <= S_CL1;
        S_CL1: begin b6 <= rf_q; st <= S_CL2; end            // c6
        S_CL2: begin b0 <= rf_q; st <= S_CL3; end            // c8
        S_CL3: begin : cl                                    // rf_q = ca
          logic signed [31:0] vt, ht, vx0, vx1, vy1;
          vt = 32'(rf_q[31:16]); ht = 32'(b6[31:16]); vx0 = 32'(b6[15:0]); vx1 = ht - 32'sd3; vy1 = 32'(b0[15:0]);
          if (ht > 0 && vt > 0 && vx0 < vx1 && vy1 < vt) begin clp[0] <= 0; clp[1] <= vx1 - vx0; clp[2] <= 0; clp[3] <= vy1; end
          st <= rw_ret;
        end
        // ---- FIFO (reg 0xe0): append, then zeus_fifo_process ----
        S_F0: begin : fa
          logic [4:0] ix;
          ix = (fifo_n >= 5'd20) ? 5'd19 : fifo_n;
          cb_we <= 1'b1; cb_wa <= 6'(ix); cb_wd <= u_val;
          if (ix == 0) f0 <= u_val;
          fn <= 6'(ix) + 6'd1; fifo_n <= ix + 5'd1;
          st <= S_F1;
        end
        S_F1: begin : fp
          logic done;
          done = 1'b1;
          case (fcmd)
            8'h00, 8'h01: if (fn < 2 && f0 != 0) done = 1'b0;
            8'h18, 8'h23, 8'h2e: if (fn < 2) done = 1'b0;
            8'h1c, 8'h1e: if (fn < ((f0[15:0] != 16'h7fff) ? 6'd8 : 6'd13)) done = 1'b0;
            8'h25, 8'h28, 8'h30: if (fn < 4 || ((f0 & 32'h808000) != 0 && fn < 10)) done = 1'b0;
            8'h67: if (fn < 3) done = 1'b0;
            default: ;
          endcase
          st <= S_IDLE;
          if (done) begin
            fifo_n <= '0;
            case (fcmd)
              8'h17: begin rw_off <= {3'd0, f0[22:16]}; rw_data <= {16'd0, f0[15:0]}; rw32 <= 1'b0; rw_ret <= S_IDLE; st <= S_RW0; end
              8'h1c, 8'h1e: begin sk <= 4'd1; st <= S_SW0; end
              8'h00, 8'h01, 8'h13, 8'h18, 8'h25, 8'h28, 8'h30, 8'h67: st <= S_FR0;
              default: ;
            endcase
          end
        end
        // prefetch reg 00 (t0), word 1 (t1), reg 06 (t2), word 2 (t3)
        S_FR0: st <= S_FR1;
        S_FR1: begin t0 <= rf_q; t1 <= cb_q; st <= S_FR2; end
        S_FR2: begin t2 <= rf_q; t3 <= cb_q; st <= S_FX; end
        S_FX: begin
          st <= S_IDLE;
          case (fcmd)
            8'h00, 8'h01: case (f0[23:0])
                24'h008000, 24'h018000: objdata <= t1;
                24'h00c040: palbase <= t1;
                default: ;
              endcase
            8'h18: begin rw_off <= {3'd0, f0[22:16]}; rw_data <= t1; rw32 <= 1'b1; rw_ret <= S_IDLE; st <= S_RW0; end
            8'h13: begin texdata <= {t2[15:0], 16'd0}; st <= S_MSTART; end
            8'h67: begin objdata <= t1; texdata <= t3; st <= S_MSTART; end
            default: begin                                                             // 25 / 28 / 30
              if (fn < 10 && (f0 & 32'hffff7f) == 0) begin sk <= '0; em_dbq <= 1'b0; st <= S_EM; end
              else begin texdata <= {t2[15:0], t0[31:16]}; qlong <= 1'b0; qb <= 6'd0; q_ret <= S_IDLE; st <= S_Q0; end
            end
          endcase
        end
        // ---- matrix commands: words 1..9 -> sw, then load / product ----
        S_SW0: st <= S_SW1;
        S_SW1: begin
          sw[sk - 4'd1] <= cb_q;
          if (sk == 4'd9) begin
            if (f0[15:0] != 16'h7fff) begin
              mtx[0][0] <= $signed(sw[1][15:0]); mtx[0][1] <= $signed(sw[1][31:16]); mtx[0][2] <= $signed(f0[15:0]);
              mtx[1][0] <= $signed(sw[2][15:0]); mtx[1][1] <= $signed(sw[2][31:16]); mtx[1][2] <= $signed(sw[0][31:16]);
              mtx[2][0] <= $signed(sw[3][15:0]); mtx[2][1] <= $signed(sw[3][31:16]); mtx[2][2] <= $signed(sw[0][15:0]);
              pnt[0] <= sw[4]; pnt[1] <= sw[5]; pnt[2] <= sw[6];
              st <= S_IDLE;
            end else begin sk <= '0; st <= S_MXP; end
          end else begin sk <= sk + 4'd1; st <= S_SW0; end
        end
        S_MXP: begin : mx
          logic signed [33:0] s;
          s = 34'(mp[0]) + 34'(mp[1]) + 34'(mp[2]);
          mtx[2'(sk / 3)][2'(sk % 3)] <= s[31:16];
          if (sk == 4'd8) begin sk <= '0; st <= S_MXL; end else sk <= sk + 4'd1;
        end
        S_MXL: st <= S_MXP2;                                  // point = words 10, 11, 12
        S_MXP2: begin pnt[sk[1:0]] <= cb_q; if (sk == 4'd2) st <= S_IDLE; else begin sk <= sk + 4'd1; st <= S_MXL; end end
        // ---- debug quad: regs 00, 08, 0a, 0c, 0e ----
        S_DB0: st <= S_DB1;
        S_DB1: begin
          if (sk == 0) t0 <= rf_q; else sw[sk - 4'd1] <= rf_q;
          if (sk == 4'd4) begin sk <= '0; em_dbq <= 1'b1; st <= S_EM; end else begin sk <= sk + 4'd1; st <= S_DB0; end
        end
        S_EM: if (sk != 0 || of_free >= (em_dbq ? 7'd14 : 7'd5)) begin
          of_we <= 1'b1; of_wd <= em_w; sk <= sk + 4'd1;
          if (sk == (em_dbq ? 4'd13 : 4'd4)) st <= S_IDLE;
        end
        // ---- zeus_draw_model (texdata set; objdata set) ----
        S_MSTART: begin dcnt <= '0; mdone <= 1'b0; st <= S_MCHK; end
        S_MCHK: if (objdata != 0 && !mdone) begin objdata <= '0; ment <= 9'(objdata[31:24]) + 9'd1; st <= S_MPOP; end
                else st <= S_IDLE;
        S_MPOP: if (wf_cnt != 0) st <= S_MW0;                 // entry counted -> readable on the next clock
        S_MW0: begin
          cb_we <= 1'b1; cb_wa <= {1'b1, dcnt}; cb_wd <= wf_q[31:0]; m_hi <= wf_q[63:32];
          if (dcnt == 0) md0 <= wf_q[31:0];
          ment <= ment - 9'd1; st <= S_MW1;
        end
        S_MW1: begin cb_we <= 1'b1; cb_wa <= {1'b1, dcnt + 5'd1}; cb_wd <= m_hi; dcnt <= dcnt + 5'd2; st <= S_MDEC; end
        S_MDEC: begin
          st <= S_MNEXT;
          if (dcnt == (mquad ? 5'd14 : 5'd2)) begin
            dcnt <= '0;
            case (mcmd)
              8'h08: mdone <= 1'b1;
              8'h0c: case (md0[23:0])
                  24'h008000, 24'h018000: objdata <= m_hi;
                  24'h00c040: palbase <= m_hi;
                  default: ;
                endcase
              8'h17: begin rw_off <= {3'd0, md0[22:16]}; rw_data <= {16'd0, md0[15:0]}; rw32 <= 1'b0; rw_ret <= S_MTEX; st <= S_RW0; end
              8'h19: begin rw_off <= {3'd0, md0[22:16]}; rw_data <= m_hi; rw32 <= 1'b1; rw_ret <= S_MTEX; st <= S_RW0; end
              8'h25, 8'h28, 8'h30: begin qlong <= 1'b1; qb <= 6'd32; q_ret <= S_MNEXT; st <= S_Q0; end
              default: ;
            endcase
          end
        end
        S_MTEX: begin if (rw_off[6:0] == 7'h06) texdata <= {rw_new[15:0], texdata[15:0]}; st <= S_MNEXT; end
        S_MNEXT: st <= (ment != 0) ? S_MPOP : S_MCHK;
        // ---- zeus_draw_quad ----
        S_Q0: begin st_quads <= st_quads + 1; st <= S_Q1; end
        S_Q1: begin r04 <= rf_q; nrm <= cb_q; st <= S_Q2; end
        S_Q2: begin ctrl <= cb_q; qi <= '0; st <= S_QV0; end
        S_QV0: begin ixy <= cb_q; st <= S_QVA; end
        S_QVA: begin iuvz <= cb_q; mrow <= 2'd0; st <= S_QV1; end
        S_QV1, S_QV2, S_QV3, S_QV4: begin : tr
          logic signed [34:0] s;
          s = 35'(pr[0]) + 35'(pr[1]) + 35'(pr[2]) + 35'(pnt[mrow - 2'd1]) + 35'sh4000;
          for (int k = 0; k < 3; k++) pr[k] <= mp[k];
          if (st != S_QV1) vk[qi][mrow - 2'd1] <= s[34:15];
          mrow <= mrow + 2'd1;
          case (st)
            S_QV1: st <= S_QV2; S_QV2: st <= S_QV3; S_QV3: st <= S_QV4;
            default: begin vu[qi] <= iuvz[23:16]; vv[qi] <= iuvz[31:24]; mrow <= 2'd0; st <= (qi == 0) ? S_QN0 : S_QV5; end
          endcase
        end
        S_QN0, S_QN1, S_QN2, S_QN3: begin
          for (int k = 0; k < 3; k++) pr[k] <= mp[k];
          if (st != S_QN0) rn[mrow - 2'd1] <= 25'(pr[0]) + 25'(pr[1]) + 25'(pr[2]);
          mrow <= mrow + 2'd1;
          case (st) S_QN0: st <= S_QN1; S_QN1: st <= S_QN2; S_QN2: st <= S_QN3; default: st <= S_QN4; endcase
        end
        S_QN4: if (dotp >= 0) begin st_culled <= st_culled + 1; st <= q_ret; end else st <= S_QV5;
        S_QV5: if (qi == 2'd3) st <= S_QZ0; else begin qi <= qi + 2'd1; st <= S_QV0; end
        // ---- zclip_if_less(4, vert, clipvert, 512.0f) ----
        S_QZ0: begin prevc <= (vk[3][2] <= 0); nout <= '0; vn <= '0; st <= S_QZC; end
        S_QZC: begin ff <= '0; st <= (thisc != prevc) ? S_QI0 : S_QCP; end
        S_QI0: st <= S_QI1;
        S_QI1: st <= S_QI2;
        S_QI2: if (!pipes_busy) st <= S_QI3;                  // divide issued this clock
        S_QI3: if (!pipes_busy) begin ff <= '0; st <= S_QI4; end
        S_QI4: begin ff <= ff + 3'd1; if (ff == 3'd5) st <= S_QI5; end
        S_QI5: if (!pipes_busy) begin ff <= '0; st <= S_QI6; end
        S_QI6: begin ff <= ff + 3'd1; if (ff == 3'd5) st <= S_QI7; end
        S_QI7: if (!pipes_busy) begin ff <= '0; st <= S_QI8; end
        S_QI8: begin ff <= ff + 3'd1; if (ff == 3'd5) st <= S_QI9; end
        S_QI9: if (!pipes_busy) begin nout <= nout + 3'd1; ff <= '0; st <= S_QCP; end
        S_QCP: if (thisc) st <= S_QZN;
               else begin ff <= ff + 3'd1; if (ff == 3'd5) begin nout <= nout + 3'd1; st <= S_QZN; end end
        S_QZN: begin prevc <= thisc; if (vn == 3'd3) st <= S_QP; else begin vn <= vn + 3'd1; st <= S_QZC; end end
        // ---- projection ----
        S_QP: if (nout < 3'd3) st <= q_ret; else begin pi <= '0; maxx <= 32'hc47a0000; maxy <= 32'hc47a0000; st <= S_QP0; end
        S_QP0: st <= S_QP1;
        S_QP1: st <= S_QP2;
        S_QP2: if (!pipes_busy) st <= S_QP3;
        S_QP3: st <= S_QP4;
        S_QP4: st <= S_QP5;
        S_QP5: if (!pipes_busy) st <= S_QP6;
        S_QP6: st <= S_QP7;
        S_QP7: st <= S_QP8;
        S_QP8: if (!pipes_busy) begin if (pi == nout - 3'd1) begin pi <= '0; st <= S_QA0; end else begin pi <= pi + 3'd1; st <= S_QP0; end end
        // ---- adjust ----
        S_QA0: st <= S_QA1;
        S_QA1: st <= S_QA2;
        S_QA2: st <= S_QA3;
        S_QA3: if (pi == nout - 3'd1) st <= S_QA4; else begin pi <= pi + 3'd1; st <= S_QA0; end
        S_QA4: if (!pipes_busy) st <= tex_bad ? q_ret : S_QO0;
        // ---- emit QUD: regs 00, 7e, 4e, 5c, then 42 words ----
        S_QO0: st <= S_QO1;
        S_QO1: begin t0 <= rf_q; st <= S_QO2; end
        S_QO2: begin t1 <= rf_q; st <= S_QO3; end
        S_QO3: begin t2 <= rf_q; st <= S_QO4; end
        S_QO4: begin t3 <= rf_q; ocnt <= '0; st <= S_QO5; end
        S_QO5: if (ocnt != 0 || of_free >= 7'd42) begin
          of_we <= 1'b1; of_wd <= obj_w; ocnt <= ocnt + 6'd1;
          if (ocnt == 6'd41) begin st_emitted <= st_emitted + 1; st <= q_ret; end
        end
        default: st <= S_IDLE;
      endcase
    end
`ifdef ZR_SEED
    if (sd_we) case (sd_sel)
      4'd0: begin rf_we <= 1'b1; rf_wa <= sd_idx; rf_wd <= sd_data; if (sd_idx == 10'h080) r80 <= sd_data; end
      4'd1: begin cb_we <= 1'b1; cb_wa <= 6'(sd_idx); cb_wd <= sd_data; if (sd_idx == 0) f0 <= sd_data; end
      4'd2: fifo_n <= 5'(sd_data);
      4'd3: mtx[sd_idx / 3][sd_idx % 3] <= sd_data[15:0];
      4'd4: pnt[sd_idx[1:0]] <= sd_data;
      4'd5: palbase <= sd_data;
      4'd6: objdata <= sd_data;
      4'd7: clp[sd_idx[1:0]] <= sd_data;
      default: ;
    endcase
`endif
  end

`ifdef ZR_SEED
  always_comb begin
    for (int k = 0; k < 9; k++) dbg_state[k] = 32'(mtx[k / 3][k % 3]);
    for (int k = 0; k < 3; k++) dbg_state[9 + k] = pnt[k];
    dbg_state[12] = palbase; dbg_state[13] = objdata;
    for (int k = 0; k < 4; k++) dbg_state[14 + k] = clp[k];
    dbg_state[18] = 32'(fifo_n); dbg_state[19] = '0;
  end
`endif
endmodule
