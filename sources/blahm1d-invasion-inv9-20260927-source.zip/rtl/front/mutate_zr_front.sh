#!/bin/bash
# zr_front coverage: each mutant is a plausible misreading of midzeus_v.cpp / poly.h and must FAIL the gate
# (run_zr_front.sh: record stream + state + register file vs zr1 --fronttap), under hostile memory (latency 23) and
# 60 % output back-pressure. REPORT-only mutants are listed with the reason they cannot die on this window.
#   F1  cull dot > 0 instead of >= 0                       F2  rounding hack without the + 0x4000
#   F3  z-clip test z <= 0 instead of z < 512 (k < 0)      F4  interpolation based at v2 instead of v1
#   F5  projection x + 200.0 instead of 200.5              F6  y adjust compared against maxx
#   F7  max starts at -FLT_MAX instead of -1000            F8  model reg-06 write does not update texdata
#   F9  0x08 (model done) ends the CURRENT block too       F10 3-vertex quads (stale clipvert[3]) not rendered
#   F11 texture base width shift 8 - s instead of 9 - s    F12 16-bit write to an ODD offset lands in the low half
#   F13 matrix product >> 15 instead of >> 16              F14 matrix load [1][2] from d1 low instead of high
#   F15 clear test mask 0xffffff instead of 0xffff7f       F16 projection y + 128.0 instead of 128.5
#   F17 cull uses vertex 1 instead of vertex 0             F18 ushift from bits 7:6 (vshift's) instead of 5:4
#   F19 model 0x0c palbase pointer ignored                 F20 model 0x0c objdata (chain) ignored
#   F21 u / v bytes swapped                                F22 clip fraction numerator 512 - v2.z
# Run it on BOTH stimuli. On the MK4 fight capture 16 of the 22 die; the other six (F1 dot == 0, F3 z == 0, F8 model
# reg-06, F9 entries after 0x08, F13 matrix product, F19 model palbase) cannot die there because the window never
# visits those paths -- zr1's "REACH front" counters read 0 for each. The SYNTHETIC stimulus
# (zeus1/golden/front_synth.cpp, zr1 as oracle) visits all of them (dot_zero 115, z_zero 3, model_reg06 111,
# after_done 1184, mtx_product 80, model_palbase 311, fifo_quads 169, reg16_odd 159) and kills all six.
# usage: wsl -d Ubuntu -- bash mutate_zr_front.sh <evidence> <front.bin> [frames]
set -u
R=/mnt/d/deck/fpga/zeus/zeus1/rtl/front/run_zr_front.sh; T=$(mktemp -d); EV="$1"; FB="$2"; NF="${3:-20}"
declare -A M
M[F1]='s/S_QN4: if (dotp >= 0)/S_QN4: if (dotp > 0)/'
M[F2]='s/ + 35'"'"'sh4000;/ + 35'"'"'sh0;/'
M[F3]='s/\[2\] <= 0)/[2] < 0)/g'
M[F4]='s/S_QI8: begin add_a = fv1\[ff\];/S_QI8: begin add_a = fv2[ff];/'
M[F5]='s/32'"'"'h43488000/32'"'"'h43480000/'
M[F6]='s/if (fp_eq(cv_q, maxy))/if (fp_eq(cv_q, maxx))/'
M[F7]='s/maxx <= 32'"'"'hc47a0000; maxy <= 32'"'"'hc47a0000;/maxx <= 32'"'"'hff7fffff; maxy <= 32'"'"'hff7fffff;/'
M[F8]='s/if (rw_off\[6:0\] == 7'"'"'h06) texdata <=/if (1'"'"'b0) texdata <=/'
M[F9]='s/8'"'"'h08: mdone <= 1'"'"'b1;/8'"'"'h08: begin mdone <= 1'"'"'b1; ment <= 9'"'"'d0; end/'
M[F10]='s/S_QP: if (nout < 3'"'"'d3)/S_QP: if (nout < 3'"'"'d4)/'
M[F11]='s/<< (4'"'"'d9 - 4'"'"'(texdata\[24:22\]))/<< (4'"'"'d8 - 4'"'"'(texdata[24:22]))/'
M[F12]='s/rw_off\[0\] ? {rw_data\[15:0\], rf_q\[15:0\]}/rw_off[0] ? {rf_q[31:16], rw_data[15:0]}/'
M[F13]='s/mtx\[2'"'"'(sk \/ 3)\]\[2'"'"'(sk % 3)\] <= s\[31:16\];/mtx[2'"'"'(sk \/ 3)][2'"'"'(sk % 3)] <= s[30:15];/'
M[F14]='s/mtx\[1\]\[2\] <= \$signed(sw\[0\]\[31:16\]);/mtx[1][2] <= $signed(sw[0][15:0]);/'
M[F15]='s/(f0 \& 32'"'"'hffff7f) == 0/(f0 \& 32'"'"'hffffff) == 0/'
M[F16]='s/32'"'"'h43008000/32'"'"'h43000000/'
M[F17]='s/47'"'"'(rn\[0\]) \* 47'"'"'(vk\[0\]\[0\]) + 47'"'"'(rn\[1\]) \* 47'"'"'(vk\[0\]\[1\]) + 47'"'"'(rn\[2\]) \* 47'"'"'(vk\[0\]\[2\])/47'"'"'(rn[0]) * 47'"'"'(vk[1][0]) + 47'"'"'(rn[1]) * 47'"'"'(vk[1][1]) + 47'"'"'(rn[2]) * 47'"'"'(vk[1][2])/'
M[F18]='s/assign ush = 4'"'"'d8 - 4'"'"'(r04\[5:4\]);/assign ush = 4'"'"'d8 - 4'"'"'(r04[7:6]);/'
M[F19]='s/24'"'"'h00c040: palbase <= m_hi;/24'"'"'h00c040: ;/'
M[F20]='s/24'"'"'h008000, 24'"'"'h018000: objdata <= m_hi;/24'"'"'h008000, 24'"'"'h018000: ;/'
M[F21]='s/vu\[qi\] <= iuvz\[23:16\]; vv\[qi\] <= iuvz\[31:24\];/vu[qi] <= iuvz[31:24]; vv[qi] <= iuvz[23:16];/'
M[F22]='s/S_QI0: begin add_a = 32'"'"'h44000000; add_b = fv1\[2\];/S_QI0: begin add_a = 32'"'"'h44000000; add_b = fv2[2];/'
LIST="${ZF_LIST:-F1 F2 F3 F4 F5 F6 F7 F8 F9 F10 F11 F12 F13 F14 F15 F16 F17 F18 F19 F20 F21 F22}"
REPORT="${ZF_REPORT:-}"
run() { ZF_MUT="${M[$1]}" timeout 5400 bash "$R" "$EV" "$FB" "$NF" 23 60 > "$T/$1.log" 2>&1; echo $? > "$T/$1.rc"; }
n=0; for m in $LIST; do run "$m" & n=$((n + 1)); if [ $n -ge 6 ]; then wait -n; n=$((n - 1)); fi; sleep 1; done
wait
ok=0
for m in $LIST; do
  rc=$(cat "$T/$m.rc"); rep=0; case " $REPORT " in *" $m "*) rep=1;; esac
  if grep -q "DID NOT APPLY" "$T/$m.log"; then echo "$m NOT APPLIED"; ok=1
  elif grep -q "BUILD FAILED" "$T/$m.log"; then echo "$m BUILD FAILED (not a kill)"; ok=1
  elif [ "$rc" = 0 ]; then if [ $rep = 1 ]; then echo "$m survived (REPORT-only, see header)"; else echo "$m SURVIVED"; ok=1; fi
  elif [ "$rc" = 124 ]; then echo "$m killed: hung (timeout)"
  else echo "$m killed: $(grep -m1 -E 'FAIL|differ' "$T/$m.log" | cut -c1-120)"; fi
done
rm -rf "$T"; exit $ok
