#!/bin/bash
# zr_front5 mutation gate. Mutants: mutants_zr_front5.txt (NAME<TAB>class<TAB>sed). Each runs the frame gate on the
# SYNTHETIC stimulus (zeus1/golden/front_synth.cpp: visits the paths the fight never does) and a real capture, both
# under hostile memory (23 clk) and 60 % output back-pressure. req: must FAIL at least one. perf: reported.
# usage: wsl -d Ubuntu -- bash mutate_zr_front5.sh <synth-evidence> <real-evidence> <real front.bin> [real-frames] [jobs]
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/front; R=$D/run_zr_front5.sh
SY="$1"; EV="$2"; FB="$3"; NF="${4:-4}"; J="${5:-6}"
T=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}"); export T R SY EV FB NF
LIST="${ZF5_LIST:-$(grep -v '^#' $D/mutants_zr_front5.txt | cut -f1 | tr '\n' ' ')}"
one() {
  m="$1"; e=$(grep -P "^$m\t" /mnt/d/deck/fpga/zeus/zeus1/rtl/front/mutants_zr_front5.txt | cut -f3-)
  ZF5_MUT="$e" timeout 3000 bash "$R" "$SY" "$SY/front.bin" 99 23 60 > "$T/$m.s.log" 2>&1; echo $? > "$T/$m.s.rc"
  ZF5_MUT="$e" timeout 3000 bash "$R" "$EV" "$FB" "$NF" 23 60 > "$T/$m.r.log" 2>&1; echo $? > "$T/$m.r.rc"
}
export -f one
printf '%s\n' $LIST | xargs -P "$J" -I{} bash -c 'one {}'
bad=0
for m in $LIST; do
  cls=$(grep -P "^$m\t" $D/mutants_zr_front5.txt | cut -f2); rs=$(cat "$T/$m.s.rc"); rr=$(cat "$T/$m.r.rc")
  if grep -q "DID NOT APPLY" "$T/$m.s.log"; then echo "$m NOT APPLIED"; bad=1; continue; fi
  if grep -q "BUILD FAILED" "$T/$m.s.log"; then echo "$m BUILD FAILED (not a kill)"; bad=1; continue; fi
  why=$(grep -h -m1 -E 'DIFFER|FAIL|differ' "$T/$m.s.log" "$T/$m.r.log" | head -1 | cut -c1-100)
  { [ "$rs" = 124 ] || [ "$rr" = 124 ]; } && why="hung (timeout) $why"
  if [ "$rs" = 0 ] && [ "$rr" = 0 ]; then
    case "$cls" in perf) echo "$m survived: performance-only / unreachable";; *) echo "$m SURVIVED"; bad=1;; esac
  else echo "$m killed [synth rc $rs, real rc $rr]: $why"; fi
done
rm -rf "$T"; exit $bad
