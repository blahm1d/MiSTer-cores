#!/bin/bash
# Build + run the zr_front4 gate (CPU writes -> RTL front end -> record stream vs zr1 --fronttap).
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/front/run_zr_front4.sh <render-evidence> <front.bin> [frames] [mlat] [out-bp%]
# ZF4_MUT='sed-expression' mutates zr_front4.sv (refuses to run if it did not apply).
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-front-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC="$S/front/zr_front4.sv"
if [ -n "${ZF4_MUT:-}" ]; then sed "$ZF4_MUT" "$SRC" > zr_front4.sv; cmp -s zr_front4.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zr_front4.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zr_front4 -DZR_SEED -Wno-fatal -Wno-lint -Wno-style -LDFLAGS -lz \
  "$S/fp32/fp32_pkg.sv" "$S/fp32/fp32_units.sv" "$S/setup/zr_sdp.sv" "$SRC" "$S/front/tb_zr_front4.cpp" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
