// zr_front5_syn.sv -- synthesis wrapper of zr_front5 for the standalone unit fit (the seed / debug ports exist only
// under ZR_SEED, which synthesis does not define). No logic.
module zr_front5_syn (
  input  logic        clk, rst,
  input  logic        wr_valid, output logic wr_ready, input logic [9:0] wr_off, input logic [31:0] wr_data,
  input  logic [9:0]  rd_off, output logic [31:0] rd_data,
  output logic        m_req, m_we, m_ram, output logic [20:0] m_blk, output logic [3:0] m_lanes,
  output logic [63:0] m_wdata, input logic m_gnt, input logic m_rvalid, input logic [63:0] m_rdata,
  output logic        o_valid, input logic o_ready, output logic [31:0] o_word,
  output logic        idle,
  output logic [31:0] st_quads, st_culled, st_emitted, st_exc, st_busy,
  output logic [31:0] st_mem, st_tr, st_zc, st_proj, st_emit, st_dec, st_hwait
);
  zr_front5 u (.clk, .rst, .wr_valid, .wr_ready, .wr_off, .wr_data, .rd_off, .rd_data, .m_req, .m_we, .m_ram, .m_blk,
    .m_lanes, .m_wdata, .m_gnt, .m_rvalid, .m_rdata, .o_valid, .o_ready, .o_word, .idle, .st_quads, .st_culled, .st_emitted,
    .st_exc, .st_busy, .st_mem, .st_tr, .st_zc, .st_proj, .st_emit, .st_dec, .st_hwait);
endmodule
