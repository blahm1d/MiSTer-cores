// zr_front.sv -- Zeus 1 (MK4) renderer FRONT END v1 (R5, 50 MHz): everything between the CPU's register writes and the
// setup engine / pixel pipe. Written from MAME master 61c79406 midzeus_v.cpp (copies in zeus/references/mame-master):
//   zeus_w / register16_w / register32_w / zeus_register_update (:420-737), zeus_pointer_w (:442-500),
//   zeus_fifo_process (:747-955, mk4: m_is_mk4b false), zeus_draw_model (:965-1050), zeus_draw_quad (:1060-1221),
//   debug quad (:580-621), waveram addressing (:87-143); poly.h zclip_if_less (:1301-1332).
// v1 is the ORDER reference: one engine, one step at a time. Gate: tb_zr_front.cpp compares the output stream
// word-for-word with zr1 --fronttap, plus the register file and the persistent state at every frame.
//
// Output: a 32-bit word stream in zr1's --fronttap record format (tags included):
//   RB  52423031 off | CLR 434C5231 x0 x1 y0 y1 | QUD 51554431 + 13 object words + cliprect + 4 x 6 floats |
//   DBQ 44425131 solid x0 x1 y0 y1 + 4 x (x, y) | HWW 48575731 ram off lanes lo hi | HRD 48524431 ram off lo hi
// Wave RAM: one port, 64-bit blocks (block index = byte offset / 8), one request outstanding.
//
// Arithmetic facts used (each exact):
//   * transform: s16*s16 products fit s32; sum + point fits 35 bits; the "rounding hack" (x + 0x4000) & ~0x7fff leaves
//     x = k * 2^15 with |k| < 2^18, so (float)x = i2f(k) with the exponent + 15 (exact), and x < 512.0 <=> k <= 0.
//   * cull: dot = 2^15 * sum(rotnormal[r] * k[r]): same sign as the 47-bit sum (MAME's s64 never overflows).
//   * u << ushift, v << vshift <= 65280, and 65535: exact in float.
//   * 512 / z and the z-clip fraction: IEEE divides (fp_rcp4 is a general a / b).
// Not modelled (unobservable): the light vector (0x23 / 0x2e), unkbase (0x02c0f0). Untextured quads carry texture
// fields 0 (zr1's convention; MAME's are stale pool values, unused unless the quad is also non-solid -- zr1 counts).
//
// v5 (THROUGHPUT, Pass 1 of zeus1/OPTIMIZATION-PASSES-MK4.md): the heaviest windows need 1.64 M front clocks per 882 K
// frame (hvpoly 13867-13886, 8,723 quads per frame). v4 ran every quad through ONE sequence; per emitted quad the
// census measured decode 37 + transform ~40 + zclip ~34 + projection 118 (a serial mul -> add chain per vertex, not the
// divide) + emit 47. v5 is TWO decoupled stages over double-buffered clip vertices:
//   S1 (the v4 state machine): decode, transform, cull, zclip. Model decode takes 2 clocks per 64-bit entry instead
//      of 5. While transform/zclip run, a background writer precomputes the quad's 17 object words (v4's obj_w, the
//      same registers read at the same point of the quad) into a snapshot RAM bank.
//   S2 (new): projection with TWO dividers and a per-vertex pipelined schedule, then the 42-word emit. v4's adjust
//      pass (x == maxx -> x + 0.0005) becomes two adds per quad, substituted while emitting -- the same value, since
//      every x that equals maxx gets maxx + 0.0005.
// S2 shares S1's adder (S2 has priority: its adds are triggered by multiplies retiring) and multiplier (S1 has
// priority: zclip's interpolation). Records other than QUD are emitted by S1 only while S2 is idle, so the stream
// order is v4's. MAME's clipvert stack slot is PERSISTENT across quads; only slot 3 is ever observable (a quad with
// three vertices emits whatever slot 3 last held), so S2 keeps that slot in p3 and updates it in quad order.
module zr_front5 import fp32_pkg::*; (
  input  logic        clk,
  input  logic        rst,
  input  logic        wr_valid,              // CPU writes (zeus_w: offset = word index 0..0x3ff within 0x880000)
  output logic        wr_ready,
  input  logic [9:0]  wr_off,
  input  logic [31:0] wr_data,
  input  logic [9:0]  rd_off,                // raw register file read (valid when idle; 1-clock latency)
  output logic [31:0] rd_data,
  // read-only register taps for the host read path and the scanout (shadows written in the register file's clock)
  output logic [31:0] reg_cc,                // 0xCC display base (screen_update, midzeus_v.cpp:329)
  output logic [31:0] reg_b6,                // 0xB6 (status 0xF6 read, :375-381)
  output logic        mode32,                // reg 0x80 bit 17: 32-bit register mode (zeus_r :384-405)
  output logic        host_rd_ok,            // ddr-fullbe: the register-file read port is the HOST's this clock (rd_off -> rd_data)
  output logic        m_req,                 // wave RAM
  output logic        m_we,
  output logic        m_ram,                 // 0: wave RAM 0, 1: wave RAM 1
  output logic [20:0] m_blk,                 // 64-bit block index
  output logic [3:0]  m_lanes,               // write: 16-bit lane enables
  output logic [63:0] m_wdata,
  input  logic        m_gnt,                 // v3: the request is ACCEPTED this clock (not completed)
  input  logic        m_rvalid,              // v3: a read response, IN ORDER, some clocks later
  input  logic [63:0] m_rdata,
  output logic        o_valid,               // output record stream
  input  logic        o_ready,
  output logic [31:0] o_word,
  output logic        idle,
`ifdef ZR_SEED
  input  logic        sd_we,
  input  logic [3:0]  sd_sel,                // 0 reg, 1 fifo word, 2 fifo_n, 3 matrix, 4 point, 5 palbase, 6 objdata, 7 clip
  input  logic [9:0]  sd_idx,
  input  logic [31:0] sd_data,
  output logic [31:0] dbg_state [20],        // matrix 9, point 3, palbase, objdata, clip 4, fifo_n, 0
`endif
  output logic [31:0] st_quads, st_culled, st_emitted, st_exc, st_busy,
  // phase census (throughput campaign): where the clocks actually go, so v3 implements the change that matters
  // instead of all four predicted ones (rtl/front/V2-PREDICTION.md).
  output logic [31:0] st_mem, st_tr, st_zc, st_proj, st_emit, st_dec,
  output logic [31:0] st_hwait                 // v5: S1 waiting to hand a quad to S2 (st_proj / st_emit are S2's clocks)
);
  // census counters count only when ZR_CENSUS is defined (every simulation runner); synthesis removes them
`ifdef ZR_CENSUS
  localparam logic [31:0] CEN = 32'd1;
`else
  localparam logic [31:0] CEN = 32'd0;
`endif
  // ---------------- persistent state ----------------
  logic signed [15:0] mtx [3][3];
  logic signed [31:0] pnt [3];
  logic [31:0] palbase, objdata, r80, f0;
  logic signed [31:0] clp [4];                        // min_x max_x min_y max_y
  logic [4:0]  fifo_n;

  // ---------------- RAMs ----------------
  logic rf_we; logic [9:0] rf_wa, rf_ra; logic [31:0] rf_wd, rf_q;
  zr_sdp #(32, 10) u_rf (.clk, .we(rf_we), .waddr(rf_wa), .wdata(rf_wd), .raddr(rf_ra), .rdata(rf_q));
  // taps: every register-file write (CPU, update side effects, seed) passes rf_we / rf_wa / rf_wd
  always_ff @(posedge clk)
    if (rst) begin reg_cc <= '0; reg_b6 <= '0; end
    else if (rf_we) begin
      if (rf_wa == 10'h0cc) reg_cc <= rf_wd;
      if (rf_wa == 10'h0b6) reg_b6 <= rf_wd;
    end
  assign mode32 = r80[17];
  logic cb_we; logic [5:0] cb_wa, cb_ra; logic [31:0] cb_wd, cb_q;    // command words: FIFO 0..19, model 32..45
  zr_sdp #(32, 6) u_cb (.clk, .we(cb_we), .waddr(cb_wa), .wdata(cb_wd), .raddr(cb_ra), .rdata(cb_q));
  // v5: clipvert[8] x 6 fields, TWO banks: S1 zclips into bank b1 while S2 projects / emits bank s2_bk
  logic b1, s2_bk;
  logic c1_we, c2_we; logic [5:0] c1_wa, c2_wa, c2_ra; logic [31:0] c1_wd, c2_wd, c2_q; logic [31:0] cq [2];
  genvar gc;
  generate for (gc = 0; gc < 2; gc++) begin : g_cv
    logic w1, w2;
    assign w1 = c1_we && (b1 == 1'(gc)); assign w2 = c2_we && (s2_bk == 1'(gc));
    zr_sdp #(32, 6) u_cv (.clk, .we(w1 || w2), .waddr(w1 ? c1_wa : c2_wa), .wdata(w1 ? c1_wd : c2_wd), .raddr(c2_ra), .rdata(cq[gc]));
  end endgenerate
  assign c2_q = cq[s2_bk];
  // v5: object-word snapshot, two banks x 32 words ({bank, word 1..17}): S1's writer fills, S2's emit reads
  logic sn_we; logic [5:0] sn_wa, sn_ra; logic [31:0] sn_wd, sn_q;
  zr_sdp #(32, 6) u_sn (.clk, .we(sn_we), .waddr(sn_wa), .wdata(sn_wd), .raddr(sn_ra), .rdata(sn_q));
  assign rd_data = rf_q;

  // ---------------- output FIFO (64 words) ----------------
  logic of_we; logic [31:0] of_wd; logic [5:0] of_wp, of_rp; logic [6:0] of_cnt; logic [31:0] of_q; logic of_rd, of_pend;
  zr_sdp #(32, 6) u_of (.clk, .we(of_we), .waddr(of_wp), .wdata(of_wd), .raddr(of_rp), .rdata(of_q));
  logic [6:0] of_free; assign of_free = 7'd63 - of_cnt;       // one word of slack for a write not yet counted
  assign of_rd = !of_pend && (of_cnt != 0) && (!o_valid || o_ready);
  always_ff @(posedge clk) begin
    if (rst) begin of_wp <= '0; of_rp <= '0; of_cnt <= '0; o_valid <= 1'b0; of_pend <= 1'b0; end
    else begin
      if (o_valid && o_ready) o_valid <= 1'b0;
      if (of_pend) begin o_word <= of_q; o_valid <= 1'b1; end
      of_pend <= of_rd;
      if (of_rd) of_rp <= of_rp + 6'd1;
      if (of_we) of_wp <= of_wp + 6'd1;
      of_cnt <= of_cnt + 7'(of_we) - 7'(of_rd);
    end
  end

  // ---------------- float units + tagged write-back ----------------
  typedef struct packed { logic v; logic [3:0] kind; logic [5:0] idx; } tag_t;
  // S1: float reg / clipvert (bank b1). S2: clipvert x / y (bank s2_bk, + max tracking), x / y products (-> the add),
  // maxx + 0.0005 / maxy + 0.0005
  localparam logic [3:0] K_FR = 4'd1, K_CV = 4'd2, K2_CVX = 4'd3, K2_CVY = 4'd4, K2_PX = 4'd5, K2_PY = 4'd6,
                         K2_MXA = 4'd7, K2_MYA = 4'd8;
  logic [31:0] add_a, add_b, mul_a, mul_b, add_y, mul_y; logic add_sub, add_e, mul_e; tag_t add_t, mul_t;
  tag_t at [5], mt [5];
  fp_add5 u_add (.clk, .a(add_a), .b(add_b), .sub(add_sub), .y(add_y), .exc(add_e));
  fp_mul5 u_mul (.clk, .a(mul_a), .b(mul_b), .y(mul_y), .exc(mul_e));
  logic dv_go, dv_done, dv_e, dv_busy; logic [31:0] dv_a, dv_b, dv_y; logic [3:0] dv_dst;
  fp_rcp4 u_div (.clk, .rst, .start(dv_go), .a(dv_a), .b(dv_b), .done(dv_done), .y(dv_y), .exc(dv_e), .busy(dv_busy));
  logic [31:0] fr [12];                                                  // float temporaries (S1: zclip)
  localparam int FR_NUM = 0, FR_DEN = 1, FR_D0 = 2, FR_FRAC = 11;
  // S1 waits only for ITS OWN operations (S2's share the units)
  logic pipes_busy, s2_inflight;
  always_comb begin
    pipes_busy = dv_busy || dv_done; s2_inflight = 1'b0;
    for (int k = 0; k < 5; k++) begin
      if (at[k].v && (at[k].kind == K_FR || at[k].kind == K_CV)) pipes_busy = 1'b1;
      if (mt[k].v && (mt[k].kind == K_FR || mt[k].kind == K_CV)) pipes_busy = 1'b1;
      if (at[k].v && at[k].kind >= K2_CVX) s2_inflight = 1'b1;
      if (mt[k].v && mt[k].kind >= K2_CVX) s2_inflight = 1'b1;
    end
  end
  // S2 unit requests (driven in the S2 block below)
  logic s2_add, s2_mul, s1_mul; logic [31:0] s2_aa, s2_ab, s2_ma, s2_mb; tag_t s2_at, s2_mt;

  // ---------------- engine state ----------------
  typedef enum logic [6:0] {
    S_IDLE, S_RW0, S_RW1, S_UPD, S_RB,
    S_HW0, S_HW1, S_HW2, S_HW3, S_HW4, S_HW5, S_HW6, S_HR0, S_HR1, S_HR2, S_HR3, S_HR4,
    S_CL0, S_CL1, S_CL2, S_CL3,
    S_F0, S_F1, S_FR0, S_FR1, S_FR2, S_FX,
    S_SW0, S_SW1, S_MXP, S_MXL, S_MXP2,
    S_DB0, S_DB1, S_EM,
    S_MSTART, S_MCHK, S_MPOP, S_MW0, S_MW1, S_MDEC, S_MTEX, S_MNEXT,
    S_Q0, S_Q1, S_Q2, S_QV0, S_QVA, S_QV1, S_QV2, S_QV3, S_QV4, S_QN0, S_QN1, S_QN2, S_QN3, S_QN4, S_QV5,
    S_QZ0, S_QZC, S_QCP, S_QZN, S_QI0, S_QI1, S_QI2, S_QI3, S_QI4, S_QI5, S_QI6, S_QI7, S_QI8, S_QI9,
    S_QP, S_QH
  } st_t;
  st_t st, rw_ret, q_ret;

  logic [9:0]  w_off;  logic [31:0] w_data;
  logic [9:0]  rw_off; logic [31:0] rw_data; logic rw32; logic [31:0] rw_new;
  logic [9:0]  u_off;  logic [31:0] u_val;
  logic [31:0] b0, b2, b4, b6, t0, t1, t2, t3;
  logic [3:0]  str_lanes;                            // cab-r4 RMW: original host-write lanes (for the HWW stream)
  logic [5:0]  fn;                                   // FIFO word count after the append
  logic [3:0]  sk;
  logic [31:0] sw [9];                               // FIFO words 1..9 (matrix) / debug-quad registers 08..0e
  logic [31:0] texdata, md0, m_hi; logic [4:0] dcnt; logic mdone; logic [8:0] ment;
  logic qlong; logic [5:0] qb; logic [31:0] ctrl, r04, nrm, ixy, iuvz;
  logic [1:0] qi, mrow;
  logic signed [19:0] vk [4][3]; logic [7:0] vu [4], vv [4];
  logic signed [31:0] pr [3]; logic signed [24:0] rn [3];
  logic [2:0] nout, vn, ff; logic prevc;
  logic em_dbq;
  // v5 snapshot writer: sn_k 0..3 read regs 00 / 7e / 4e / 5c into t0..t3, 4..20 write object words 1..17, 21 done
  logic sn_on, sn_rp, sn_rd, rf_free; logic [4:0] sn_k; logic [1:0] sn_ri; logic [5:0] sn_w;

  // multipliers: transform / rotnormal / matrix product (3 x s16*s16); cull dot (3 x s25*s20)
  logic signed [15:0] ma [3], mb [3]; logic signed [31:0] mp [3];
  always_comb for (int k = 0; k < 3; k++) mp[k] = 32'(ma[k]) * 32'(mb[k]);
  logic signed [46:0] dotp;
  always_comb dotp = 47'(rn[0]) * 47'(vk[0][0]) + 47'(rn[1]) * 47'(vk[0][1]) + 47'(rn[2]) * 47'(vk[0][2]);

  // vertex field as float (exact): f 0..2 = x y z (k * 2^15), 3 = u << ushift, 4 = v << vshift, 5 = 65535
  function automatic logic [31:0] k15(input logic signed [19:0] k);
    fres_t r; r = fp_i2f(32'(k));
    return (k == 0) ? 32'd0 : {r.v[31], r.v[30:23] + 8'd15, r.v[22:0]};
  endfunction
  logic [3:0] ush, vsh; assign ush = 4'd8 - 4'(r04[5:4]); assign vsh = 4'd8 - 4'(r04[7:6]);
  // sound-area L7: ONE int->float converter per vfield call (v4/v5 built three: k15's, u's and v's, then selected the
  // result). The integer is selected first; every case is still exactly fp_i2f of the same integer, and k15's exponent
  // +15 (k != 0) is applied after. Bit-identical for every (v, f).
  function automatic logic [31:0] vfield(input logic [1:0] v, input logic [2:0] f);
    fres_t r; logic signed [31:0] x;
    case (f)
      3'd0, 3'd1, 3'd2: x = 32'(vk[v][f[1:0]]);
      3'd3:             x = 32'(16'(vu[v]) << ush);
      default:          x = 32'(16'(vv[v]) << vsh);
    endcase
    r = fp_i2f(x);
    case (f)
      3'd0, 3'd1, 3'd2: return (x == 32'sd0) ? 32'd0 : {r.v[31], r.v[30:23] + 8'd15, r.v[22:0]};
      3'd3, 3'd4:       return r.v;
      default:          return 32'h477fff00;
    endcase
  endfunction

  // waveram addressing (block index = byte offset / 8)
  function automatic logic [20:0] blk0(input logic [31:0] a); return 21'({a[22:12], a[8:0]}); endfunction   // w0_block
  function automatic logic [20:0] exp0(input logic [31:0] a); return 21'({a[26:16], a[8:0]}); endfunction   // w0_expanded
  function automatic logic [20:0] exp1(input logic [31:0] a); return 21'({a[24:16], a[8:0]}); endfunction   // w1_expanded

  // ---------------- model walker (fetch side): streams n blocks into a 16-deep FIFO ----------------
  logic wk_start; logic [20:0] wk_base; logic [8:0] wk_n;
  // v3 (THROUGHPUT): the walker keeps many reads in flight instead of one. Measured on v2: the memory wait was 27 %
  // of all busy clocks at 23-clock latency (rtl/front/V2-PREDICTION.md census) because a model block's seven 64-bit
  // reads were issued one at a time. Model blocks are sequential, so the addresses are known far ahead.
  logic wk_on; logic [20:0] wk_addr; logic [8:0] wk_left; logic [4:0] wk_out;   // wk_out = responses still owed
  logic wf_we, wf_pop; logic [3:0] wf_wp, wf_rp; logic [4:0] wf_cnt; logic [63:0] wf_q;
  zr_sdp #(64, 4) u_wf (.clk, .we(wf_we), .waddr(wf_wp), .wdata(m_rdata), .raddr(wf_rp), .rdata(wf_q));
  logic e_req, e_we, e_ram; logic [20:0] e_blk; logic [3:0] e_lanes; logic [63:0] e_wd;
  // The walker owns the port while a model runs (host accesses only happen between models), so the mux stays simple.
  // It issues whenever the FIFO has room for every response already owed plus this one.
  logic wk_issue; assign wk_issue = wk_on && (wk_left != 0) && ((wf_cnt + 5'(wk_out)) < 5'd15);
  assign m_req = wk_on ? wk_issue : e_req;
  assign m_we = wk_on ? 1'b0 : e_we;
  assign m_ram = wk_on ? 1'b0 : e_ram;
  assign m_blk = wk_on ? wk_addr : e_blk;
  assign m_lanes = e_lanes; assign m_wdata = e_wd;
  assign wf_we = wk_on && m_rvalid;                       // responses arrive in order: straight into the FIFO
  always_ff @(posedge clk) begin
    if (rst) begin wk_on <= 1'b0; wk_out <= '0; wf_wp <= '0; wf_rp <= '0; wf_cnt <= '0; end
    else begin
      if (wk_start) begin wk_on <= 1'b1; wk_addr <= wk_base; wk_left <= wk_n; wk_out <= '0; end
      else if (wk_on) begin
        if (wk_issue && m_gnt) begin
          wk_addr <= wk_addr + 21'd1; wk_left <= wk_left - 9'd1;
          wk_out <= wk_out + 5'(!m_rvalid);               // one more owed, unless one arrives this clock
        end else if (m_rvalid) wk_out <= wk_out - 5'd1;
        // the walk ends when the last response has landed, not when the last request was issued
        if (wk_left == 0 && wk_out == (m_rvalid ? 5'd1 : 5'd0)) wk_on <= 1'b0;
      end
      if (wf_we) wf_wp <= wf_wp + 4'd1;
      if (wf_pop) wf_rp <= wf_rp + 4'd1;
      wf_cnt <= wf_cnt + 5'(wf_we) - 5'(wf_pop);
    end
  end

  // ---------------- combinational drive ----------------
  logic [7:0] fcmd, mcmd; assign fcmd = f0[31:24]; assign mcmd = md0[31:24];
  logic mquad; assign mquad = (mcmd == 8'h25) || (mcmd == 8'h30) || (mcmd == 8'h28);
  logic [5:0] xyo; assign xyo = qlong ? 6'd2 : 6'd1;
  logic [1:0] iv1, iv2; assign iv2 = vn[1:0]; assign iv1 = (vn == 3'd0) ? 2'd3 : 2'(vn - 3'd1);
  // v2 (AREA): v1 built all twelve vertex-field converters in parallel (fv1[6] and fv2[6]) while the state machine
  // uses at most two at a time -- twelve copies of an int->float converter (priority encode + shift + round). One per
  // side, with the field selected by the state, is the same behaviour. v1 measured 4,870 ALM of which 3,701 were LUT
  // logic only (zeus1/area/front1_20ns).
  logic [2:0]  fsel;
  logic [31:0] fv1s, fv2s;
  assign fsel = (st == S_QI0 || st == S_QI1) ? 3'd2 : ff;
  assign fv1s = vfield(iv1, fsel);
  assign fv2s = vfield(iv2, fsel);
  logic thisc; assign thisc = (vk[iv2][2] <= 0);
  // QUD word w >= 18 lives at clipvert {vertex (w-18)/6, field (w-18)%6}
  // v2 (AREA): no '/' or '%'. v1's divisions on these small counters made Quartus instantiate four lpm_divide blocks
  // (41 ALM, zeus1/area/front1_20ns entity table) for constants that are a two-bit case.
  function automatic logic [1:0] div3(input logic [3:0] k);
    case (k) 4'd0, 4'd1, 4'd2: return 2'd0; 4'd3, 4'd4, 4'd5: return 2'd1; default: return 2'd2; endcase
  endfunction
  function automatic logic [1:0] mod3(input logic [3:0] k);
    case (k) 4'd0, 4'd3, 4'd6: return 2'd0; 4'd1, 4'd4, 4'd7: return 2'd1; default: return 2'd2; endcase
  endfunction
  function automatic logic [5:0] cvw(input logic [5:0] w);
    logic [5:0] j; logic [2:0] v, f;
    j = w - 6'd18;
    v = (j < 6'd6) ? 3'd0 : (j < 6'd12) ? 3'd1 : (j < 6'd18) ? 3'd2 : 3'd3;
    case (v) 3'd0: f = 3'(j); 3'd1: f = 3'(j - 6'd6); 3'd2: f = 3'(j - 6'd12); default: f = 3'(j - 6'd18); endcase
    return {v, f};
  endfunction

  // v5: the snapshot writer may use the register-file read port in any quad state that does not present its own
  // address (S_Q0 does; S_Q1 only CAPTURES reg 04, so the writer's read there lands a clock later, unharmed)
  assign rf_free = (st == S_Q1) || (st == S_Q2) || (st >= S_QV0 && st <= S_QH);
  assign sn_rd = sn_on && sn_k < 5'd4 && rf_free;
  assign sn_w = 6'(sn_k) - 6'd3;

  always_comb begin
    rf_ra = rd_off; cb_ra = '0;
    add_a = '0; add_b = '0; add_sub = 1'b0; add_t = '0;
    mul_a = '0; mul_b = '0; mul_t = '0;
    dv_go = 1'b0; dv_a = '0; dv_b = '0;
    wf_pop = 1'b0; wk_start = 1'b0; wk_base = '0; wk_n = '0;
    c1_we = 1'b0; c1_wa = '0; c1_wd = '0;
    for (int k = 0; k < 3; k++) begin ma[k] = '0; mb[k] = '0; end
    if (sn_rd) case (sn_k[1:0]) 2'd0: rf_ra = 10'h000; 2'd1: rf_ra = 10'h07e; 2'd2: rf_ra = 10'h04e; default: rf_ra = 10'h05c; endcase
    case (st)
      S_RW0: rf_ra = {rw_off[9:1], 1'b0};
      S_HW0: rf_ra = 10'h0b6; S_HW1: rf_ra = 10'h0b0; S_HW2: rf_ra = 10'h0b2; S_HW3: rf_ra = 10'h0b4;
      S_HR0: rf_ra = 10'h0b6;
      S_CL0: rf_ra = 10'h0c6; S_CL1: rf_ra = 10'h0c8; S_CL2: rf_ra = 10'h0ca;
      S_FR0: begin rf_ra = 10'h000; cb_ra = 6'd1; end
      S_FR1: begin rf_ra = 10'h006; cb_ra = 6'd2; end
      S_SW0: cb_ra = 6'(sk);
      S_MXP: begin : mxp
        logic [1:0] r, c; r = div3(sk); c = mod3(sk);
        // m1 row r: lo / hi of d4|d8|d9, hi of d5|d6|d7; m2 column c: lo / hi of d1|d2|d3, lo of d5|d6|d7 (sw[k] = d(k+1))
        ma[0] = $signed(sw[r == 0 ? 3 : r == 1 ? 7 : 8][15:0]); ma[1] = $signed(sw[r == 0 ? 3 : r == 1 ? 7 : 8][31:16]);
        ma[2] = $signed(sw[r == 0 ? 4 : r == 1 ? 5 : 6][31:16]);
        mb[0] = $signed(sw[c][15:0]); mb[1] = $signed(sw[c][31:16]); mb[2] = $signed(sw[4 + c][15:0]);
      end
      S_MXL: cb_ra = 6'(4'd10 + sk);
      S_DB0: rf_ra = (sk == 0) ? 10'h000 : 10'(10'h008 + 10'({sk[2:0], 1'b0}) - 10'd2);
      S_MCHK: if (objdata != 0 && !mdone) begin wk_start = 1'b1; wk_base = blk0(objdata); wk_n = 9'(objdata[31:24]) + 9'd1; end
      S_MW0: wf_pop = 1'b1;
      S_Q0:  begin rf_ra = 10'h004; cb_ra = qb; end
      S_Q1:  cb_ra = qb + (qlong ? 6'd1 : 6'd9);
      S_Q2:  cb_ra = qb + xyo;
      S_QV0: cb_ra = qb + xyo + 6'd1 + 6'({qi, 1'b0});
      S_QV1, S_QV2, S_QV3: begin
        ma[0] = $signed(ixy[15:0]); ma[1] = $signed(ixy[31:16]); ma[2] = $signed(iuvz[15:0]);
        for (int k = 0; k < 3; k++) mb[k] = mtx[mrow][k];
      end
      S_QN0, S_QN1, S_QN2: begin
        ma[0] = 16'($signed(nrm[7:0])); ma[1] = 16'($signed(nrm[15:8])); ma[2] = 16'($signed(nrm[23:16]));
        for (int k = 0; k < 3; k++) mb[k] = mtx[mrow][k];
      end
      S_QV5: cb_ra = qb + xyo + 6'({qi + 2'd1, 1'b0});
      // z-clip interpolation: frac = (512 - v1.z) / (v2.z - v1.z); out = v1 + frac * (v2 - v1). v5: an add waits
      // while S2 owns the adder that clock (the state holds; see the sequencer).
      S_QI0: if (!s2_add) begin add_a = 32'h44000000; add_b = fv1s; add_sub = 1'b1; add_t = '{1'b1, K_FR, 6'(FR_NUM)}; end
      S_QI1: if (!s2_add) begin add_a = fv2s; add_b = fv1s; add_sub = 1'b1; add_t = '{1'b1, K_FR, 6'(FR_DEN)}; end
      S_QI2: if (!pipes_busy) begin dv_go = 1'b1; dv_a = fr[FR_NUM]; dv_b = fr[FR_DEN]; end
      S_QI4: if (!s2_add) begin add_a = fv2s; add_b = fv1s; add_sub = 1'b1; add_t = '{1'b1, K_FR, 6'(FR_D0) + 6'(ff)}; end
      S_QI6: begin mul_a = fr[FR_FRAC]; mul_b = fr[FR_D0 + ff]; mul_t = '{1'b1, K_FR, 6'(FR_D0) + 6'(ff)}; end
      S_QI8: if (!s2_add) begin add_a = fv1s; add_b = fr[FR_D0 + ff]; add_t = '{1'b1, K_CV, {nout, ff}}; end
      default: ;
    endcase
    // S2's issues (S2 owns the adder when it asks; S1 owns the multiplier in S_QI6 and S2 waits)
    if (s2_add) begin add_a = s2_aa; add_b = s2_ab; add_sub = 1'b0; add_t = s2_at; end
    if (s2_mul) begin mul_a = s2_ma; mul_b = s2_mb; mul_t = s2_mt; end
    // S1 clipvert writes: its zclip adds retiring, else the copy of an unclipped vertex
    if (at[4].v && at[4].kind == K_CV) begin c1_we = 1'b1; c1_wa = at[4].idx; c1_wd = add_y; end
    else if (st == S_QCP && !thisc) begin c1_we = 1'b1; c1_wa = {nout, ff}; c1_wd = fv2s; end
  end


  // ================= v5 S2: projection -> emit, over clipvert bank s2_bk =================
  typedef enum logic [1:0] { P_IDLE, P_PROJ, P_EMIT } p_t;
  p_t ps;
  logic s2_on, s2_tb, s1_hand; logic [2:0] s2_n;            // busy, tex_bad (emit silently), vertex count
  logic [3:0] dj, ci; logic [2:0] cs;                       // divide-issue vertex, consumer vertex, consumer step
  logic di_rd, di_r, dz_v, cn_rd; logic [31:0] dz, xs, ys;
  logic d_go [2], d_done [2], d_busy [2], d_e [2], res_v [2]; logic [31:0] d_y [2];
  logic h_v; logic [31:0] h_a, h_b; tag_t h_t;              // a product retired -> its add, next clock
  logic [31:0] pmx, pmy, pmxa, pmya; logic [1:0] aj;
  logic [31:0] p3 [6];                                      // MAME's persistent clipvert slot 3
  logic [5:0] eo; logic e_go, e_cap; logic [2:0] e_f; logic [31:0] e_val;
  genvar gd;
  generate for (gd = 0; gd < 2; gd++) begin : g_d2
    fp_rcp4 u_d (.clk, .rst, .start(d_go[gd]), .a(32'h44000000), .b(dz), .done(d_done[gd]), .y(d_y[gd]), .exc(d_e[gd]), .busy(d_busy[gd]));
  end endgenerate
  assign s1_hand = (st == S_QH) && sn_k == 5'd21 && !s2_on;
  always_comb begin
    s1_mul = (st == S_QI6);
    // one clipvert read port: emit, else the consumer (x, y), else the divide issuer (z)
    cn_rd = (ps == P_PROJ) && (ci < 4'(s2_n)) && (cs == 3'd0 || cs == 3'd1);
    di_rd = (ps == P_PROJ) && (dj < 4'(s2_n)) && !dz_v && !di_r && !cn_rd;
    if (ps == P_EMIT) c2_ra = cvw(eo + 6'd1);
    else if (cn_rd) c2_ra = {ci[2:0], (cs == 3'd0) ? 3'd0 : 3'd1};
    else if (di_rd) c2_ra = {dj[2:0], 3'd2};
    else c2_ra = '0;
    sn_ra = {s2_bk, 5'(eo + 6'd1)};
    for (int k = 0; k < 2; k++) d_go[k] = dz_v && (dj[0] == 1'(k)) && !d_busy[k] && !d_done[k] && !res_v[k];
    // the multiplier (S1's S_QI6 first)
    s2_mul = 1'b0; s2_ma = '0; s2_mb = '0; s2_mt = '0;
    if (ps == P_PROJ && cs == 3'd3 && res_v[ci[0]] && !s1_mul) begin
      s2_mul = 1'b1; s2_ma = xs; s2_mb = d_y[ci[0]]; s2_mt = '{1'b1, K2_PX, {ci[2:0], 3'd0}};
    end
    if (ps == P_PROJ && cs == 3'd4 && !s1_mul) begin
      s2_mul = 1'b1; s2_ma = ys; s2_mb = d_y[ci[0]]; s2_mt = '{1'b1, K2_PY, {ci[2:0], 3'd1}};
    end
    // the adder (S2 first): a retired product's add, or the two adjust constants at the start of the emit
    s2_add = h_v || (ps == P_EMIT && aj != 2'd2);
    s2_aa = h_v ? h_a : (aj == 2'd0) ? pmx : pmy;
    s2_ab = h_v ? h_b : 32'h3a03126f;
    // (field by field: Quartus 17.0 rejects an assignment pattern inside a conditional, Error 10828)
    if (h_v) s2_at = h_t;
    else begin s2_at.v = 1'b1; s2_at.kind = (aj == 2'd0) ? K2_MXA : K2_MYA; s2_at.idx = 6'd0; end
    // S2 clipvert writes: projected x / y
    c2_we = at[4].v && (at[4].kind == K2_CVX || at[4].kind == K2_CVY); c2_wa = at[4].idx; c2_wd = add_y;
    // the emitted word (v4's obj_w order): tag, 17 snapshot words, 4 x 6 clipvert words
    e_go = (eo != 6'd0) || s2_tb || of_free >= 7'd42;
    e_cap = 1'b0; e_f = '0;
    if (eo == 6'd0) e_val = 32'h51554431;
    else if (eo <= 6'd17) e_val = sn_q;
    else begin : cvv
      logic [5:0] vf; vf = cvw(eo); e_f = vf[2:0];
      if (vf[5:3] == 3'd3 && s2_n == 3'd3) e_val = p3[vf[2:0]];              // slot 3 not written by this quad
      else if (vf[2:0] == 3'd0 && fp_eq(c2_q, pmx)) e_val = pmxa;               // adjust: x == maxx -> maxx + 0.0005
      else if (vf[2:0] == 3'd1 && fp_eq(c2_q, pmy)) e_val = pmya;
      else e_val = c2_q;
      e_cap = (vf[5:3] == 3'd3) && s2_n >= 3'd4;
    end
  end

  // QUD words 1..17 (v5: written into the snapshot RAM by the writer; S2 emits them with the clipvert words)
  logic [31:0] tex_off, obj_w; logic tex_on, tex_bad; logic [2:0] tfv; logic [9:0] texw; logic [30:0] tex_t;
  always_comb begin
    tex_on = ctrl[24];
    tex_bad = tex_on && texdata[17:16] != 2'd1 && texdata[17:16] != 2'd2;
    tfv = !tex_on ? 3'd0 : texdata[17:16] == 2'd1 ? (texdata[21] ? 3'd2 : 3'd1) : (texdata[21] ? 3'd4 : 3'd3);
    texw = 10'(10'd512 >> texdata[24:22]);
    // w0_texture: (((addr & ~1) * width) / 8) % 2^20 blocks, addr = texdata[31:26] : texdata[15:0], width = 512 >> s
    tex_t = 31'({texdata[31:26], texdata[15:1], 1'b0}) << (4'd9 - 4'(texdata[24:22]));
    tex_off = {9'd0, tex_t[22:3], 3'd0};
    case (sn_w)                                             // v5: indexed by the snapshot writer
      6'd0:  obj_w = 32'h51554431;
      6'd1:  obj_w = ctrl;
      6'd2:  obj_w = t0 & 32'h7fff;                          // solidcolor = reg 00
      6'd3:  obj_w = 32'($signed(t1[31:16]));                // zoffset = reg 7e >> 16
      6'd4:  obj_w = ctrl[16] ? 32'd0 : 32'h100;             // transcolor
      6'd5:  obj_w = tex_on ? 32'(texw) : 32'd0;
      6'd6:  obj_w = tex_on ? 32'(ctrl[15:0]) : 32'd0;       // voffset
      6'd7:  obj_w = t2;                                     // alpha = reg 4e
      6'd8:  obj_w = t3;                                     // blend = reg 5c
      6'd9:  obj_w = 32'(!r04[11]);
      6'd10: obj_w = 32'(r04[9]);
      6'd11: obj_w = 32'(tfv);
      6'd12: obj_w = tex_on ? tex_off : 32'd0;
      6'd13: obj_w = {8'd0, blk0(palbase), 3'd0};
      6'd14: obj_w = clp[0]; 6'd15: obj_w = clp[1]; 6'd16: obj_w = clp[2]; 6'd17: obj_w = clp[3];
      default: obj_w = 32'd0;
    endcase
  end

  // record emitter for CLR / DBQ (S_EM): em_dbq selects the debug quad (14 words) over the clear (5)
  logic [31:0] em_w;
  always_comb begin
    em_w = '0;
    if (em_dbq) begin
      case (sk)
        4'd0: em_w = 32'h44425131; 4'd1: em_w = {16'd0, t0[15:0]};
        4'd2: em_w = clp[0]; 4'd3: em_w = clp[1]; 4'd4: em_w = clp[2]; 4'd5: em_w = clp[3];
        default: begin : dq
          fres_t r; logic [3:0] j; logic [31:0] w;
          j = sk - 4'd6; w = sw[j[2:1]]; r = fp_i2f16(j[0] ? w[31:16] : w[15:0]); em_w = r.v;
        end
      endcase
    end else case (sk)
      4'd0: em_w = 32'h434C5231; 4'd1: em_w = clp[0]; 4'd2: em_w = clp[1]; 4'd3: em_w = clp[2]; default: em_w = clp[3];
    endcase
  end

  assign wr_ready = (st == S_IDLE);
  // ddr-fullbe: rf_ra follows rd_off only in S_IDLE with the snapshot writer off (the always_comb above: every other
  // state and sn_rd drive rf_ra). A host (CPU) register read must be issued only while this holds, else it samples
  // whatever register the front end is reading (r8 cabinet: POST wave-RAM test read b0 = the b6 value -> ERROR F9).
  assign host_rd_ok = (st == S_IDLE) && !sn_rd;
  assign idle = (st == S_IDLE) && !s2_on && (of_cnt == 0) && !of_pend && !o_valid && !of_we && !wk_on;

  always_ff @(posedge clk) begin
    rf_we <= 1'b0; cb_we <= 1'b0; of_we <= 1'b0;
    if (rst) begin
      st <= S_IDLE; e_req <= 1'b0; fifo_n <= '0; objdata <= '0; palbase <= '0; r80 <= '0; f0 <= '0;
      st_quads <= 0; st_culled <= 0; st_emitted <= 0; st_exc <= 0; st_busy <= 0;
      st_mem <= 0; st_tr <= 0; st_zc <= 0; st_proj <= 0; st_emit <= 0; st_dec <= 0; st_hwait <= 0;
      for (int k = 0; k < 5; k++) begin at[k] <= '0; mt[k] <= '0; end
      b1 <= 1'b0; sn_on <= 1'b0; sn_rp <= 1'b0; sn_we <= 1'b0;
      s2_on <= 1'b0; ps <= P_IDLE; h_v <= 1'b0; di_r <= 1'b0; dz_v <= 1'b0;
      for (int k = 0; k < 2; k++) res_v[k] <= 1'b0;
      for (int k = 0; k < 6; k++) p3[k] <= '0;
    end else begin
      if (st != S_IDLE) st_busy <= st_busy + CEN;
      // phase census: memory wait = the walker has no entry to give, or a host access is outstanding
      if ((st == S_MPOP && wf_cnt == 0) || (st == S_HR2 && !m_rvalid) || (st == S_HW5 && e_req)) st_mem <= st_mem + CEN;
      if (st == S_Q0 || st == S_Q1 || st == S_Q2 || st == S_QV0 || st == S_QVA || st == S_QV1 || st == S_QV2 ||
          st == S_QV3 || st == S_QV4 || st == S_QV5 || st == S_QN0 || st == S_QN1 || st == S_QN2 || st == S_QN3 ||
          st == S_QN4) st_tr <= st_tr + CEN;
      if (st == S_QZ0 || st == S_QZC || st == S_QCP || st == S_QZN || (st >= S_QI0 && st <= S_QI9)) st_zc <= st_zc + CEN;
      if (ps == P_PROJ) st_proj <= st_proj + CEN;
      if (ps == P_EMIT) st_emit <= st_emit + CEN;
      if (st == S_QH && !s1_hand) st_hwait <= st_hwait + CEN;
      if (st == S_MCHK || st == S_MPOP || st == S_MW0 || st == S_MW1 || st == S_MDEC || st == S_MNEXT ||
          st == S_MTEX || st == S_MSTART) st_dec <= st_dec + CEN;
      // ---- float write-back ----
      at[0] <= add_t; mt[0] <= mul_t;
      for (int k = 1; k < 5; k++) begin at[k] <= at[k - 1]; mt[k] <= mt[k - 1]; end
      h_v <= 1'b0;                                          // an S2 add waiting in h_* issues the clock it is set
      if (at[4].v) begin
        if (add_e) st_exc <= st_exc + CEN;
        case (at[4].kind)
          K_FR:   fr[at[4].idx[3:0]] <= add_y;
          K2_CVX: if (fp_lt(pmx, add_y)) pmx <= add_y;        // std::max(maxx, x) = maxx < x ? x : maxx
          K2_CVY: if (fp_lt(pmy, add_y)) pmy <= add_y;
          K2_MXA: pmxa <= add_y;
          K2_MYA: pmya <= add_y;
          default: ;
        endcase
      end
      if (mt[4].v) begin
        if (mul_e) st_exc <= st_exc + CEN;
        case (mt[4].kind)
          K_FR:  fr[mt[4].idx[3:0]] <= mul_y;
          // projection: x * ooz + 200.5, y * ooz + 128.5 -- the add issues the next clock (S2 owns the adder)
          K2_PX: begin h_v <= 1'b1; h_a <= mul_y; h_b <= 32'h43488000; h_t <= '{1'b1, K2_CVX, mt[4].idx}; end
          K2_PY: begin h_v <= 1'b1; h_a <= mul_y; h_b <= 32'h43008000; h_t <= '{1'b1, K2_CVY, mt[4].idx}; end
          default: ;
        endcase
      end
      if (dv_done) begin if (dv_e) st_exc <= st_exc + CEN; fr[FR_FRAC] <= dv_y; end
      for (int k = 0; k < 2; k++) if (d_done[k]) begin if (d_e[k]) st_exc <= st_exc + CEN; res_v[k] <= 1'b1; end
      if (e_req && m_gnt) e_req <= 1'b0;                 // v3: accepted, not completed

      case (st)
        S_IDLE: if (wr_valid) begin
          // zeus_w: 32-bit if reg 0x80 bit 17, else 16-bit halves
          rw_off <= wr_off; rw_data <= wr_data; rw32 <= r80[17]; rw_ret <= S_IDLE; st <= S_RW0;
        end
        // ---- register write (register16_w / register32_w), then zeus_register_update on EVEN offsets ----
        S_RW0: st <= S_RW1;
        S_RW1: begin : rw
          logic [31:0] nv;
          nv = rw32 ? rw_data : rw_off[0] ? {rw_data[15:0], rf_q[15:0]} : {rf_q[31:16], rw_data[15:0]};
          rf_we <= 1'b1; rf_wa <= {rw_off[9:1], 1'b0}; rf_wd <= nv; rw_new <= nv;
          if ({rw_off[9:1], 1'b0} == 10'h080) r80 <= nv;
          if (!rw_off[0]) begin u_off <= rw_off; u_val <= nv; st <= S_UPD; end else st <= rw_ret;
        end
        S_UPD: begin
          st <= rw_ret;
          case (u_off)
            10'h052: begin rf_we <= 1'b1; rf_wa <= 10'h0b2; rf_wd <= u_val; end
            10'h060: if (u_val[0] && r80[23:0] == 24'h22fcff) begin sk <= '0; st <= S_DB0; end
            10'h070: pnt[0] <= {u_val[15:0], 16'd0};
            10'h072: pnt[1] <= {u_val[15:0], 16'd0};
            10'h074: pnt[2] <= {u_val[15:0], 16'd0};
            10'h084: begin sk <= '0; st <= S_RB; end
            10'h0b0, 10'h0b2: st <= S_HW0;
            10'h0b4: st <= S_HR0;
            10'h0c0, 10'h0c2, 10'h0c4, 10'h0c6, 10'h0c8, 10'h0ca: st <= S_CL0;
            10'h0e0: st <= S_F0;
            default: ;
          endcase
        end
        // render base: w1_expanded(reg84 << 16) = block (reg84 & 0x1ff) * 512
        S_RB: if (sk != 0 || (of_free >= 7'd2 && !s2_on)) begin   // v5: after every QUD S2 still holds
          of_we <= 1'b1; of_wd <= (sk == 0) ? 32'h52423031 : {11'd0, u_val[8:0], 12'd0};
          if (sk == 0) sk <= 4'd1; else st <= rw_ret;
        end
        // ---- host wave RAM write (b0 / b2 update) ----
        S_HW0: st <= S_HW1;
        S_HW1: begin b6 <= rf_q; st <= S_HW2; end
        S_HW2: begin b0 <= rf_q; st <= S_HW3; end
        S_HW3: begin b2 <= rf_q; st <= S_HW4; end
        S_HW4: begin
          b4 <= rf_q;
          if (b6[31:16] != 0 && ((u_off == 10'h0b0 && !b6[25]) || (u_off == 10'h0b2 && b6[25]))) begin
            // The HPS f2sdram drops partial-byte-enable writes (cab-r4); the lane-masked write goes to zr_memsys AS IS
            // and zr_memsys makes it full-BE (a C_FR read of the block, merge, full write -- ddr-fullbe). The cab-r4
            // front-end RMW (S_HWA) is gone: one merge, at the DDR boundary, for every client.
            e_ram <= b6[31]; e_blk <= b6[31] ? exp1(rf_q) : exp0(rf_q);
            e_wd <= {b2, b0}; str_lanes <= b6[23:20];
            e_req <= 1'b1; e_we <= 1'b1; e_lanes <= b6[23:20]; st <= S_HW5;
          end else st <= rw_ret;
        end
        S_HW5: if (!e_req && of_free >= 7'd6 && !s2_on) begin sk <= '0; st <= S_HW6; end
        S_HW6: begin
          of_we <= 1'b1;
          case (sk)
            4'd0: of_wd <= 32'h48575731; 4'd1: of_wd <= 32'(e_ram); 4'd2: of_wd <= {8'd0, e_blk, 3'd0};
            4'd3: of_wd <= 32'(str_lanes); 4'd4: of_wd <= b0; default: of_wd <= b2;   // stream: ORIGINAL lanes
          endcase
          sk <= sk + 4'd1;
          if (sk == 4'd5) begin
            if (b6[17]) begin rf_we <= 1'b1; rf_wa <= 10'h0b4; rf_wd <= b4 + 32'd1; end
            st <= rw_ret;
          end
        end
        // ---- host wave RAM read (b4 update) ----
        S_HR0: st <= S_HR1;
        S_HR1: if (rf_q[16]) begin
            e_req <= 1'b1; e_we <= 1'b0; e_ram <= rf_q[31]; e_blk <= rf_q[31] ? exp1(u_val) : exp0(u_val); st <= S_HR2;
          end else st <= rw_ret;
        S_HR2: if (m_rvalid) begin                            // v3: the READ RESPONSE, not the acceptance
            b0 <= m_rdata[31:0]; b2 <= m_rdata[63:32]; rf_we <= 1'b1; rf_wa <= 10'h0b0; rf_wd <= m_rdata[31:0]; st <= S_HR3;
          end
        S_HR3: begin rf_we <= 1'b1; rf_wa <= 10'h0b2; rf_wd <= b2; if (of_free >= 7'd5 && !s2_on) begin sk <= '0; st <= S_HR4; end end
        S_HR4: begin
          of_we <= 1'b1;
          case (sk)
            4'd0: of_wd <= 32'h48524431; 4'd1: of_wd <= 32'(e_ram); 4'd2: of_wd <= {8'd0, e_blk, 3'd0};
            4'd3: of_wd <= b0; default: of_wd <= b2;
          endcase
          sk <= sk + 4'd1; if (sk == 4'd4) st <= rw_ret;
        end
        // ---- cliprect from the CRTC registers (:699-719) ----
        S_CL0: st <= S_CL1;
        S_CL1: begin b6 <= rf_q; st <= S_CL2; end            // c6
        S_CL2: begin b0 <= rf_q; st <= S_CL3; end            // c8
        S_CL3: begin : cl                                    // rf_q = ca
          logic signed [31:0] vt, ht, vx0, vx1, vy1;
          vt = 32'(rf_q[31:16]); ht = 32'(b6[31:16]); vx0 = 32'(b6[15:0]); vx1 = ht - 32'sd3; vy1 = 32'(b0[15:0]);
          if (ht > 0 && vt > 0 && vx0 < vx1 && vy1 < vt) begin clp[0] <= 0; clp[1] <= vx1 - vx0; clp[2] <= 0; clp[3] <= vy1; end
          st <= rw_ret;
        end
        // ---- FIFO (reg 0xe0): append, then zeus_fifo_process ----
        S_F0: begin : fa
          logic [4:0] ix;
          ix = (fifo_n >= 5'd20) ? 5'd19 : fifo_n;
          cb_we <= 1'b1; cb_wa <= 6'(ix); cb_wd <= u_val;
          if (ix == 0) f0 <= u_val;
          fn <= 6'(ix) + 6'd1; fifo_n <= ix + 5'd1;
          st <= S_F1;
        end
        S_F1: begin : fp
          logic done;
          done = 1'b1;
          case (fcmd)
            8'h00, 8'h01: if (fn < 2 && f0 != 0) done = 1'b0;
            8'h18, 8'h23, 8'h2e: if (fn < 2) done = 1'b0;
            8'h1c, 8'h1e: if (fn < ((f0[15:0] != 16'h7fff) ? 6'd8 : 6'd13)) done = 1'b0;
            8'h25, 8'h28, 8'h30: if (fn < 4 || ((f0 & 32'h808000) != 0 && fn < 10)) done = 1'b0;
            8'h67: if (fn < 3) done = 1'b0;
            default: ;
          endcase
          st <= S_IDLE;
          if (done) begin
            fifo_n <= '0;
            case (fcmd)
              8'h17: begin rw_off <= {3'd0, f0[22:16]}; rw_data <= {16'd0, f0[15:0]}; rw32 <= 1'b0; rw_ret <= S_IDLE; st <= S_RW0; end
              8'h1c, 8'h1e: begin sk <= 4'd1; st <= S_SW0; end
              8'h00, 8'h01, 8'h13, 8'h18, 8'h25, 8'h28, 8'h30, 8'h67: st <= S_FR0;
              default: ;
            endcase
          end
        end
        // prefetch reg 00 (t0), word 1 (t1), reg 06 (t2), word 2 (t3)
        S_FR0: st <= S_FR1;
        S_FR1: begin t0 <= rf_q; t1 <= cb_q; st <= S_FR2; end
        S_FR2: begin t2 <= rf_q; t3 <= cb_q; st <= S_FX; end
        S_FX: begin
          st <= S_IDLE;
          case (fcmd)
            8'h00, 8'h01: case (f0[23:0])
                24'h008000, 24'h018000: objdata <= t1;
                24'h00c040: palbase <= t1;
                default: ;
              endcase
            8'h18: begin rw_off <= {3'd0, f0[22:16]}; rw_data <= t1; rw32 <= 1'b1; rw_ret <= S_IDLE; st <= S_RW0; end
            8'h13: begin texdata <= {t2[15:0], 16'd0}; st <= S_MSTART; end
            8'h67: begin objdata <= t1; texdata <= t3; st <= S_MSTART; end
            default: begin                                                             // 25 / 28 / 30
              if (fn < 10 && (f0 & 32'hffff7f) == 0) begin sk <= '0; em_dbq <= 1'b0; st <= S_EM; end
              else begin texdata <= {t2[15:0], t0[31:16]}; qlong <= 1'b0; qb <= 6'd0; q_ret <= S_IDLE; st <= S_Q0; end
            end
          endcase
        end
        // ---- matrix commands: words 1..9 -> sw, then load / product ----
        S_SW0: st <= S_SW1;
        S_SW1: begin
          sw[sk - 4'd1] <= cb_q;
          if (sk == 4'd9) begin
            if (f0[15:0] != 16'h7fff) begin
              mtx[0][0] <= $signed(sw[1][15:0]); mtx[0][1] <= $signed(sw[1][31:16]); mtx[0][2] <= $signed(f0[15:0]);
              mtx[1][0] <= $signed(sw[2][15:0]); mtx[1][1] <= $signed(sw[2][31:16]); mtx[1][2] <= $signed(sw[0][31:16]);
              mtx[2][0] <= $signed(sw[3][15:0]); mtx[2][1] <= $signed(sw[3][31:16]); mtx[2][2] <= $signed(sw[0][15:0]);
              pnt[0] <= sw[4]; pnt[1] <= sw[5]; pnt[2] <= sw[6];
              st <= S_IDLE;
            end else begin sk <= '0; st <= S_MXP; end
          end else begin sk <= sk + 4'd1; st <= S_SW0; end
        end
        S_MXP: begin : mx
          logic signed [33:0] s; logic [1:0] rr, cc;
          s = 34'(mp[0]) + 34'(mp[1]) + 34'(mp[2]);
          rr = div3(sk); cc = mod3(sk);            // not inside the assignment's index: Verilator rejects that
          mtx[rr][cc] <= s[31:16];
          if (sk == 4'd8) begin sk <= '0; st <= S_MXL; end else sk <= sk + 4'd1;
        end
        S_MXL: st <= S_MXP2;                                  // point = words 10, 11, 12
        S_MXP2: begin pnt[sk[1:0]] <= cb_q; if (sk == 4'd2) st <= S_IDLE; else begin sk <= sk + 4'd1; st <= S_MXL; end end
        // ---- debug quad: regs 00, 08, 0a, 0c, 0e ----
        S_DB0: st <= S_DB1;
        S_DB1: begin
          if (sk == 0) t0 <= rf_q; else sw[sk - 4'd1] <= rf_q;
          if (sk == 4'd4) begin sk <= '0; em_dbq <= 1'b1; st <= S_EM; end else begin sk <= sk + 4'd1; st <= S_DB0; end
        end
        S_EM: if (sk != 0 || (of_free >= (em_dbq ? 7'd14 : 7'd5) && !s2_on)) begin
          of_we <= 1'b1; of_wd <= em_w; sk <= sk + 4'd1;
          if (sk == (em_dbq ? 4'd13 : 4'd4)) st <= S_IDLE;
        end
        // ---- zeus_draw_model (texdata set; objdata set) ----
        S_MSTART: begin dcnt <= '0; mdone <= 1'b0; st <= S_MCHK; end
        S_MCHK: if (objdata != 0 && !mdone) begin objdata <= '0; ment <= 9'(objdata[31:24]) + 9'd1; st <= S_MPOP; end
                else st <= S_IDLE;
        S_MPOP: if (wf_cnt != 0) st <= S_MW0;                 // entry counted -> readable on the next clock
        S_MW0: begin
          cb_we <= 1'b1; cb_wa <= {1'b1, dcnt}; cb_wd <= wf_q[31:0]; m_hi <= wf_q[63:32];
          if (dcnt == 0) md0 <= wf_q[31:0];
          ment <= ment - 9'd1; st <= S_MW1;
        end
        // v5: an entry that does not complete its command goes straight on to the next one (v4 spent S_MDEC +
        // S_MNEXT + S_MPOP on every entry: 5 clocks per 64-bit entry, 37 of a quad's clocks on hvpoly)
        S_MW1: begin
          cb_we <= 1'b1; cb_wa <= {1'b1, dcnt + 5'd1}; cb_wd <= m_hi; dcnt <= dcnt + 5'd2;
          if (dcnt + 5'd2 == (mquad ? 5'd14 : 5'd2)) st <= S_MDEC;
          else if (ment == 0) st <= S_MCHK;
          else if (wf_cnt != 0) st <= S_MW0;
          else st <= S_MPOP;
        end
        S_MDEC: begin
          st <= S_MNEXT;
          if (dcnt == (mquad ? 5'd14 : 5'd2)) begin
            dcnt <= '0;
            case (mcmd)
              8'h08: mdone <= 1'b1;
              8'h0c: case (md0[23:0])
                  24'h008000, 24'h018000: objdata <= m_hi;
                  24'h00c040: palbase <= m_hi;
                  default: ;
                endcase
              8'h17: begin rw_off <= {3'd0, md0[22:16]}; rw_data <= {16'd0, md0[15:0]}; rw32 <= 1'b0; rw_ret <= S_MTEX; st <= S_RW0; end
              8'h19: begin rw_off <= {3'd0, md0[22:16]}; rw_data <= m_hi; rw32 <= 1'b1; rw_ret <= S_MTEX; st <= S_RW0; end
              8'h25, 8'h28, 8'h30: begin qlong <= 1'b1; qb <= 6'd32; q_ret <= S_MNEXT; st <= S_Q0; end
              default: ;
            endcase
          end
        end
        S_MTEX: begin if (rw_off[6:0] == 7'h06) texdata <= {rw_new[15:0], texdata[15:0]}; st <= S_MNEXT; end
        S_MNEXT: st <= (ment != 0) ? S_MPOP : S_MCHK;
        // ---- zeus_draw_quad ----
        S_Q0: begin st_quads <= st_quads + CEN; st <= S_Q1; end
        S_Q1: begin r04 <= rf_q; nrm <= cb_q; st <= S_Q2; end
        S_Q2: begin ctrl <= cb_q; qi <= '0; st <= S_QV0; end
        S_QV0: begin ixy <= cb_q; st <= S_QVA; end
        S_QVA: begin iuvz <= cb_q; mrow <= 2'd0; st <= S_QV1; end
        S_QV1, S_QV2, S_QV3, S_QV4: begin : tr
          logic signed [34:0] s;
          s = 35'(pr[0]) + 35'(pr[1]) + 35'(pr[2]) + 35'(pnt[mrow - 2'd1]) + 35'sh4000;
          for (int k = 0; k < 3; k++) pr[k] <= mp[k];
          if (st != S_QV1) vk[qi][mrow - 2'd1] <= s[34:15];
          mrow <= mrow + 2'd1;
          case (st)
            S_QV1: st <= S_QV2; S_QV2: st <= S_QV3; S_QV3: st <= S_QV4;
            default: begin vu[qi] <= iuvz[23:16]; vv[qi] <= iuvz[31:24]; mrow <= 2'd0; st <= (qi == 0) ? S_QN0 : S_QV5; end
          endcase
        end
        S_QN0, S_QN1, S_QN2, S_QN3: begin
          for (int k = 0; k < 3; k++) pr[k] <= mp[k];
          if (st != S_QN0) rn[mrow - 2'd1] <= 25'(pr[0]) + 25'(pr[1]) + 25'(pr[2]);
          mrow <= mrow + 2'd1;
          case (st) S_QN0: st <= S_QN1; S_QN1: st <= S_QN2; S_QN2: st <= S_QN3; default: st <= S_QN4; endcase
        end
        S_QN4: if (dotp >= 0) begin st_culled <= st_culled + CEN; st <= q_ret; end else st <= S_QV5;
        S_QV5: if (qi == 2'd3) st <= S_QZ0; else begin qi <= qi + 2'd1; st <= S_QV0; end
        // ---- zclip_if_less(4, vert, clipvert, 512.0f) ----
        S_QZ0: begin prevc <= (vk[3][2] <= 0); nout <= '0; vn <= '0; st <= S_QZC; end
        S_QZC: begin ff <= '0; st <= (thisc != prevc) ? S_QI0 : S_QCP; end
        S_QI0: if (!s2_add) st <= S_QI1;                      // v5: the add issued (S2 did not own the adder)
        S_QI1: if (!s2_add) st <= S_QI2;
        S_QI2: if (!pipes_busy) st <= S_QI3;                  // divide issued this clock
        S_QI3: if (!pipes_busy) begin ff <= '0; st <= S_QI4; end
        S_QI4: if (!s2_add) begin ff <= ff + 3'd1; if (ff == 3'd5) st <= S_QI5; end
        S_QI5: if (!pipes_busy) begin ff <= '0; st <= S_QI6; end
        S_QI6: begin ff <= ff + 3'd1; if (ff == 3'd5) st <= S_QI7; end
        S_QI7: if (!pipes_busy) begin ff <= '0; st <= S_QI8; end
        S_QI8: if (!s2_add) begin ff <= ff + 3'd1; if (ff == 3'd5) st <= S_QI9; end
        S_QI9: if (!pipes_busy) begin nout <= nout + 3'd1; ff <= '0; st <= S_QCP; end
        S_QCP: if (thisc) st <= S_QZN;
               else begin ff <= ff + 3'd1; if (ff == 3'd5) begin nout <= nout + 3'd1; st <= S_QZN; end end
        S_QZN: begin prevc <= thisc; if (vn == 3'd3) st <= S_QP; else begin vn <= vn + 3'd1; st <= S_QZC; end end
        // ---- v5: hand the clipped polygon to S2 (projection + emit), or drop it (fewer than 3 vertices) ----
        S_QP: st <= (nout < 3'd3) ? q_ret : S_QH;
        S_QH: if (s1_hand) begin b1 <= !b1; sn_on <= 1'b0; st <= q_ret; end
        default: st <= S_IDLE;
      endcase

      // ---- v5 snapshot writer: regs 00 / 7e / 4e / 5c -> t0..t3, then object words 1..17 -> snapshot bank b1 ----
      sn_we <= 1'b0;
      sn_rp <= sn_rd;
      if (sn_rp) case (sn_ri) 2'd0: t0 <= rf_q; 2'd1: t1 <= rf_q; 2'd2: t2 <= rf_q; default: t3 <= rf_q; endcase
      if (sn_rd) begin sn_ri <= sn_k[1:0]; sn_k <= sn_k + 5'd1; end
      else if (sn_on && rf_free && sn_k >= 5'd4 && sn_k <= 5'd20) begin
        sn_we <= 1'b1; sn_wa <= {b1, sn_w[4:0]}; sn_wd <= obj_w; sn_k <= sn_k + 5'd1;
      end
      if (st == S_Q2) begin sn_on <= 1'b1; sn_k <= '0; end   // every quad (re)starts it; a culled one abandons it

      // ================= S2: projection -> emit =================
      if (s1_hand) begin
        s2_on <= 1'b1; s2_bk <= b1; s2_n <= nout; s2_tb <= tex_bad; ps <= P_PROJ;
        dj <= '0; ci <= '0; cs <= '0; pmx <= 32'hc47a0000; pmy <= 32'hc47a0000; aj <= '0; eo <= '0;
      end
      // divide issue: read z_j, start divider j[0] when it is free and its last result was consumed
      di_r <= di_rd;
      if (di_r) begin dz <= c2_q; dz_v <= 1'b1; end
      if (d_go[0] || d_go[1]) begin dz_v <= 1'b0; dj <= dj + 4'd1; end
      // consumer: x, y of vertex ci, then x * ooz, y * ooz (the adds follow as the products retire)
      if (ps == P_PROJ) case (cs)
        3'd0: if (cn_rd) cs <= 3'd1;
        3'd1: begin xs <= c2_q; cs <= 3'd2; end
        3'd2: begin ys <= c2_q; cs <= 3'd3; end
        3'd3: if (s2_mul) cs <= 3'd4;
        default: if (s2_mul) begin res_v[ci[0]] <= 1'b0; ci <= ci + 4'd1; cs <= 3'd0; end
      endcase
      if (ps == P_PROJ && dj == 4'(s2_n) && ci == 4'(s2_n) && !dz_v && !s2_inflight && !h_v) ps <= P_EMIT;
      // emit: word eo now, the address of eo + 1 on the read ports; maxx / maxy + 0.0005 issue on the first two
      // clocks and land long before word 18. A tex_bad quad runs the same walk SILENTLY (it still updates slot 3).
      if (ps == P_EMIT) begin
        if (aj != 2'd2) aj <= aj + 2'd1;
        if (e_go) begin
          if (!s2_tb) begin of_we <= 1'b1; of_wd <= e_val; end
          if (e_cap) p3[e_f] <= e_val;
          eo <= eo + 6'd1;
          if (eo == 6'd41) begin ps <= P_IDLE; s2_on <= 1'b0; if (!s2_tb) st_emitted <= st_emitted + CEN; end
        end
      end
    end
`ifdef ZR_SEED
    if (sd_we) case (sd_sel)
      4'd0: begin rf_we <= 1'b1; rf_wa <= sd_idx; rf_wd <= sd_data; if (sd_idx == 10'h080) r80 <= sd_data; end
      4'd1: begin cb_we <= 1'b1; cb_wa <= 6'(sd_idx); cb_wd <= sd_data; if (sd_idx == 0) f0 <= sd_data; end
      4'd2: fifo_n <= 5'(sd_data);
      4'd3: mtx[sd_idx / 3][sd_idx % 3] <= sd_data[15:0];
      4'd4: pnt[sd_idx[1:0]] <= sd_data;
      4'd5: palbase <= sd_data;
      4'd6: objdata <= sd_data;
      4'd7: clp[sd_idx[1:0]] <= sd_data;
      default: ;
    endcase
`endif
  end

`ifdef ZR_SEED
  // coverage census for the unit-priority rules (mutants G5 / G11 can only die where these are nonzero)
  logic [15:0] col_a, col_m;
  always_ff @(posedge clk)
    if (rst) begin col_a <= '0; col_m <= '0; end
    else begin
      if (s2_add && (st == S_QI0 || st == S_QI1 || st == S_QI4 || st == S_QI8)) col_a <= col_a + 16'd1;
      if (s1_mul && ps == P_PROJ && ((cs == 3'd3 && res_v[ci[0]]) || cs == 3'd4)) col_m <= col_m + 16'd1;
    end
  always_comb begin
    for (int k = 0; k < 9; k++) dbg_state[k] = 32'(mtx[k / 3][k % 3]);
    for (int k = 0; k < 3; k++) dbg_state[9 + k] = pnt[k];
    dbg_state[12] = palbase; dbg_state[13] = objdata;
    for (int k = 0; k < 4; k++) dbg_state[14 + k] = clp[k];
    dbg_state[18] = 32'(fifo_n); dbg_state[19] = {col_a, col_m};   // v5 coverage: S1/S2 unit collisions (not compared)
  end
`endif
endmodule
