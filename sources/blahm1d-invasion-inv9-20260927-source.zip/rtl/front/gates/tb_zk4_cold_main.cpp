// tb_zk4_cold_main.cpp -- driver for the MK4 whole-core cold-boot sim (lanes/coldboot).
//
// Drives clk / por / core_reset and the hps_io ioctl WIDE stream (index 1 = the first 16 MiB of the maindata
// image = the MK4.mra interleave, word-exact) into the REAL zk4_top, with core reset HELD across the download
// (as MiSTer Main does). Then the HOLD + zk4_ram_reload phase, then the CPU.
//
// Two independent measurements:
//  (1) RELOAD TAP (oracle-free): every completed reload read (from ROM 0xA00000+k) and write (to main word k)
//      is captured hierarchically and diffed against maindata[k] (word 0 << 1). This exposes a corrupt main RAM
//      WITHOUT any MAME device replay -- the decisive cabinet-vs-bench discriminator.
//  (2) RETIRED-PC vs the MAME golden (golden_pc.bin triples): first PC, first divergence, and the fault.
//      Device reads here are served by the REAL RTL (not a MAME oracle), so a PC divergence at a time-dependent
//      device read is EXPECTED in a correct core; the cabinet bug is the CPU walking to 0x040000 and faulting
//      F_ILLEGAL, which is a RAM/data failure, not a device-value one.
//
// usage: zk4_cold <golden-dir> <maindata.bin> [--max-insn N] [--stop-clocks N] [--wr-gap N] [--wait-lag N]
#include "Vtb_zk4_cold.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <unordered_map>

static std::vector<uint32_t> load_words(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) { fprintf(stderr, "FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    std::vector<uint32_t> v(n / 4);
    if (fread(v.data(), 4, v.size(), f) != v.size()) { fprintf(stderr, "FAIL: short read %s\n", p.c_str()); exit(2); }
    fclose(f); return v;
}
static std::vector<uint8_t> load_bytes(const std::string& p, size_t limit) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) { fprintf(stderr, "FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    size_t take = limit && (size_t)n > limit ? limit : (size_t)n;
    std::vector<uint8_t> v(take);
    if (fread(v.data(), 1, take, f) != take) { fprintf(stderr, "FAIL: short read %s\n", p.c_str()); exit(2); }
    fclose(f); return v;
}

int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IOLBF, 0);   // line-buffered so a $fatal/early-exit still shows progress
    if (argc < 3) { fprintf(stderr, "usage: zk4_cold <golden-dir> <maindata.bin> [opts]\n"); return 2; }
    std::string gdir = argv[1], mdpath = argv[2];
    uint64_t max_insn = 200000, stop_clocks = 40000000;
    int wr_gap = 2, wait_lag = 2;
    for (int i = 3; i < argc; i++) {
        std::string a = argv[i];
        auto nx = [&](long dflt){ return i+1<argc ? strtol(argv[++i],0,0) : dflt; };
        if (a == "--max-insn") max_insn = nx(max_insn);
        else if (a == "--stop-clocks") stop_clocks = nx(stop_clocks);
        else if (a == "--wr-gap") wr_gap = nx(wr_gap);
        else if (a == "--wait-lag") wait_lag = nx(wait_lag);
    }

    std::vector<uint32_t> gold = load_words(gdir + "/golden_pc.bin");
    size_t ngold = gold.size() / 3;
    auto GPC = [&](uint64_t k){ return gold[3*k]; };

    std::vector<uint32_t> maindata = load_words(mdpath);      // 0x600000 words expected
    // The ioctl stream = the first 16 MiB (0x400000 words) as 16-bit halfwords, low half of each word first.
    const size_t STREAM_BYTES = 16u*1024*1024;
    std::vector<uint8_t> stream = load_bytes(mdpath, STREAM_BYTES);
    size_t stream_hw = stream.size() / 2;                     // halfwords
    printf("COLD: golden=%s ngold=%zu first_pc=%06X maindata=%zu words stream=%zu halfwords\n",
           gdir.c_str(), ngold, GPC(0), maindata.size(), stream_hw);

    Verilated::commandArgs(argc, argv);
    Vtb_zk4_cold* t = new Vtb_zk4_cold;

    // reload capture, indexed by main word k (0..0x3FFFF)
    std::vector<uint32_t> main_written(0x40000, 0xDEADBEEFu);
    std::vector<uint8_t>  main_wseen(0x40000, 0);
    std::vector<uint32_t> rom_read(0x40000, 0xDEADBEEFu);
    std::vector<uint8_t>  rom_rseen(0x40000, 0);

    auto expected_main = [&](uint32_t k)->uint32_t {
        uint32_t w = maindata[k];
        return (k == 0) ? (w << 1) : w;
    };

    t->clk = 0; t->por = 1; t->core_reset = 1; t->show_status = 0;
    t->ioctl_download = 0; t->ioctl_wr = 0; t->ioctl_addr = 0; t->ioctl_dout = 0; t->ioctl_index = 0;
    t->in0 = 0xFFFF; t->in1 = 0xFFFF; t->in2 = 0xFFFF; t->in3 = 0xFFFF;
    t->eval();

    uint64_t clk = 0;
    // loader-write capture (stable across a held transaction): what the loader put at ROM byte 0 / main word 0
    uint8_t rom0_seen = 0, main0_seen = 0; uint32_t rom0_wdata = 0xDEADBEEF, main0_wdata = 0xDEADBEEF;
    uint64_t rom0_acks = 0;
    auto caploader = [&](){
        if (t->t_l_req && (t->t_l_baddr == 0)) { rom0_seen = 1; rom0_wdata = t->t_l_wdata; if (t->t_l_ack) rom0_acks++; }
        if (t->t_l_req && (t->t_l_baddr == 0x1800000u)) { main0_seen = 1; main0_wdata = t->t_l_wdata; }
    };
    auto posedge = [&](){ t->clk = 0; t->eval(); t->clk = 1; t->eval(); clk++; caploader(); };

    // POR
    for (int i = 0; i < 32; i++) posedge();
    t->por = 0;
    for (int i = 0; i < 8; i++) posedge();

    // ---- download index 1 ----
    t->ioctl_download = 1; t->ioctl_index = 1;
    size_t pos = 0;               // halfword index
    int lag_left = 0; bool prev_wait = false;
    uint64_t wait_clocks = 0, wait_run = 0, wait_run_max = 0;
    // hold reset during the whole download; drive one halfword per wr with wr_gap idle clocks
    while (pos < stream_hw) {
        // present a write when allowed
        bool wait = t->ioctl_wait;
        if (wait) { wait_clocks++; wait_run++; if (wait_run > wait_run_max) wait_run_max = wait_run; }
        else wait_run = 0;
        if (wait && !prev_wait) lag_left = wait_lag;
        prev_wait = wait;
        if (!wait || lag_left > 0) {
            if (wait) lag_left--;
            uint16_t lo = stream[2*pos];
            uint16_t hi = (2*pos+1 < stream.size()) ? stream[2*pos+1] : 0;
            t->ioctl_dout = (uint16_t)(lo | (hi << 8));
            t->ioctl_addr = (uint32_t)pos;
            t->ioctl_wr = 1;
            posedge();
            t->ioctl_wr = 0;
            pos++;
            for (int g = 0; g < wr_gap; g++) posedge();
        } else {
            posedge();
        }
        if (clk > 400000000ull) { printf("FAIL: download did not complete (clk=%llu pos=%zu)\n", (unsigned long long)clk, pos); return 2; }
    }
    t->ioctl_download = 0; t->ioctl_wr = 0;
    printf("COLD: download done clk=%llu words_loaded=%u stream_crc=%08X dropped=%u wait_clocks=%llu wait_run_max=%llu\n",
           (unsigned long long)clk, t->t_words_loaded, t->t_stream_crc, t->t_dropped,
           (unsigned long long)wait_clocks, (unsigned long long)wait_run_max);
    // let the loader finish its ROM/fast/tail fills (loader_done)
    for (int i = 0; i < 64; i++) posedge();
    // release core reset (MiSTer drops it after the download); zk4_top still holds game reset until loader_done+HOLD+reload
    t->core_reset = 0;

    // ---- run: watch loader_done, phase, reload taps, and the CPU ----
    uint64_t retired = 0;
    uint64_t first_div_instr = ~0ull; uint32_t first_div_dut = 0, first_div_mame = 0;
    bool faulted = false; uint32_t fault_pc = 0, fault_code = 0;
    bool reported_reload = false, reload_bad = false;
    uint64_t reload_wmiss = 0, reload_rmiss = 0;
    uint8_t prev_phase = 0xFF;
    bool loader_done_seen = false, game_run_seen = false;
    // cab-r4 stall detector: after game_run, if the CPU stops retiring for STALL_CLOCKS while clocks
    // advance, declare a STALL (the cabinet 0x01C164 symptom: frozen in one ext access) and report cpu_pc.
    uint64_t last_retire_clk = 0; bool stalled = false; uint32_t stall_pc = 0;
    const uint64_t STALL_CLOCKS = 3000000;
    uint64_t next_progress = 90000000ull;
    bool err_path_seen = false; uint64_t err_path_retired = 0;   // cpu_pc in the POST error-screen region

    while (clk < stop_clocks) {
        // sample pre-edge tap state, then step
        uint8_t phase = t->t_phase;
        // reload read/write completion capture (combinational taps sampled at the edge)
        // do the capture AFTER the edge so q_ack/rdata are the registered post-edge values
        posedge();

        if (!loader_done_seen && t->loader_done) { loader_done_seen = true;
            printf("COLD: loader_done clk=%llu boot_pc=%06X map_fault=%d\n", (unsigned long long)clk, t->boot_pc_o, t->sdram_map_fault);
            // SPLIT the residual: what is actually stored in SDRAM ROM word 0/1 after the loader owns nothing more
            printf("SDRAM-PEEK@loader_done: ROMword0 = %04X%04X (mem[1]mem[0]), ROMword1 = %04X%04X ; expect word0=00008000 word1=%08X\n",
                   t->t_mem1, t->t_mem0, t->t_mem3, t->t_mem2, maindata.size()>1?maindata[1]:0);
            printf("LOADER-WRITE: ROM byte0 offered=%d wdata=%08X acks=%llu ; MAIN word0 offered=%d wdata=%08X\n",
                   rom0_seen, rom0_wdata, (unsigned long long)rom0_acks, main0_seen, main0_wdata);
        }

        // reload transaction capture: a completed transaction is q_ack & rl_req
        if (t->t_q_ack && t->t_rl_req) {
            uint32_t a = t->t_rl_addr & 0xFFFFFF;
            if (t->t_rl_we) {
                if (a < 0x40000) { main_written[a] = t->t_rl_wdata; main_wseen[a] = 1; }
            } else {
                if (a >= 0xA00000 && a < 0xA40000) { uint32_t k = a - 0xA00000; rom_read[k] = t->t_sd_rdata; rom_rseen[k] = 1; }
            }
        }

        if (t->t_phase != prev_phase) {
            const char* nm[] = {"P_HOLD","P_START","P_ARM","P_RELOAD","P_RUN","?","?","?"};
            printf("COLD: phase %s clk=%llu reloads=%u rl_busy=%d\n", nm[t->t_phase & 7], (unsigned long long)clk, t->t_reloads, t->t_rl_busy);
            prev_phase = t->t_phase;
        }

        if (!game_run_seen && t->t_game_run) {
            game_run_seen = true;
            printf("COLD: game_run clk=%llu reloads=%u\n", (unsigned long long)clk, t->t_reloads);
        }

        // once the reload has completed (game_run and reload not busy), report the RAM diff ONCE
        if (game_run_seen && !reported_reload) {
            reported_reload = true;
            uint64_t wmiss = 0, rmiss = 0, wseen = 0, rseen = 0; uint32_t first_wbad = 0xFFFFFFFF, first_rbad = 0xFFFFFFFF;
            for (uint32_t k = 0; k < 0x40000; k++) {
                if (main_wseen[k]) { wseen++; if (main_written[k] != expected_main(k)) { wmiss++; if (first_wbad == 0xFFFFFFFF) first_wbad = k; } }
                if (rom_rseen[k])  { rseen++; if (rom_read[k] != maindata[k]) { rmiss++; if (first_rbad == 0xFFFFFFFF) first_rbad = k; } }
            }
            printf("RELOAD-DIFF: writes_seen=%llu write_mismatches=%llu (vs maindata, word0<<1)  reads_seen=%llu read_mismatches=%llu\n",
                   (unsigned long long)wseen, (unsigned long long)wmiss, (unsigned long long)rseen, (unsigned long long)rmiss);
            reload_wmiss = wmiss; reload_rmiss = rmiss; reload_bad = (wmiss != 0 || rmiss != 0);
            if (first_wbad != 0xFFFFFFFF) {
                uint32_t k = first_wbad;
                printf("RELOAD-DIFF: first WRITE mismatch main word %06X: reload wrote %08X, expected %08X (maindata[%06X]=%08X)\n",
                       k, main_written[k], expected_main(k), k, maindata[k]);
                for (uint32_t j = k; j < k+6 && j < 0x40000; j++)
                    printf("   main[%06X] wrote=%08X exp=%08X %s\n", j, main_wseen[j]?main_written[j]:0xDEADBEEF, expected_main(j), (main_wseen[j]&&main_written[j]==expected_main(j))?"ok":"BAD");
            }
            if (first_rbad != 0xFFFFFFFF) {
                uint32_t k = first_rbad;
                printf("RELOAD-DIFF: first READ mismatch ROM word %06X: reload read %08X, maindata[%06X]=%08X\n",
                       k, rom_read[k], k, maindata[k]);
            }
            if (wseen < 0x40000) printf("RELOAD-DIFF: WARN only %llu of 0x40000 main words were written by the reload\n", (unsigned long long)wseen);
        }

        // CPU retire compare
        if (t->t_retire && t->t_kpc_v) {
            uint32_t dut_pc = t->t_kpc;
            if (retired < ngold) {
                uint32_t mame = GPC(retired);
                if (dut_pc != mame && first_div_instr == ~0ull) {
                    first_div_instr = retired; first_div_dut = dut_pc; first_div_mame = mame;
                    printf("PC-DIV: first divergence at retired instruction %llu: DUT %06X, MAME %06X\n",
                           (unsigned long long)retired, dut_pc, mame);
                    printf("  golden window:");
                    for (uint64_t j = retired>6?retired-6:0; j <= retired+3 && j < ngold; j++) printf(" %06X", GPC(j));
                    printf("\n");
                }
            }
            retired++;
            last_retire_clk = clk;
            if (retired >= max_insn) { printf("COLD: reached max-insn %llu\n", (unsigned long long)max_insn); break; }
        }

        // error-path detection: the POST "Wave RAM ... ERROR" screen streamer (0x01C15E..0x01C164)
        if (!err_path_seen && t->cpu_pc >= 0x01C15Eu && t->cpu_pc <= 0x01C164u) {
            err_path_seen = true; err_path_retired = retired;
            printf("ERRPATH: cpu_pc entered the POST error-screen region (%06X) at retired=%llu\n",
                   t->cpu_pc, (unsigned long long)retired);
        }
        // progress + stall detection (after the reload completes)
        if (game_run_seen) {
            if (last_retire_clk == 0) last_retire_clk = clk;
            if (clk >= next_progress) {
                printf("PROGRESS: clk=%llu retired=%llu cpu_pc=%06X\n",
                       (unsigned long long)clk, (unsigned long long)retired, t->cpu_pc);
                next_progress += 10000000ull;
            }
            if (!stalled && (clk - last_retire_clk) > STALL_CLOCKS) {
                stalled = true; stall_pc = t->cpu_pc;
                printf("STALL: CPU stopped retiring for %llu clocks at cpu_pc=%06X (retired=%llu clk=%llu)\n",
                       (unsigned long long)STALL_CLOCKS, stall_pc, (unsigned long long)retired, (unsigned long long)clk);
                const char* stn[] = {"IDLE","RW0","RW1","UPD","RB","HW0","HW1","HW2","HW3","HW4","HW5","HW6",
                    "HR0","HR1","HR2","HR3","HR4","CL0","CL1","CL2","CL3","F0","F1","FR0","FR1","FR2","FX"};
                int st = t->t_fe_st;
                printf("DUMP front: st=%d(%s) e_req=%d m_req=%d m_gnt=%d m_rvalid=%d s2_on=%d wk_on=%d rs=%d\n",
                       st, (st<27?stn[st]:"?"), t->t_fe_ereq, t->t_fe_mreq, t->t_fe_mgnt, t->t_fe_mrvalid,
                       t->t_fe_s2on, t->t_fe_wkon, t->t_rs);
                printf("DUMP cmdq: occ=%u in_ready=%d empty=%d\n", t->t_cq_occ, t->t_cq_inready, t->t_cq_empty);
                printf("DUMP memsys: qfm_v=%d ok_fm=%d hz_fm=%d older_rd=%d cw_hold=%d | qsc_v=%d qcr_v=%d qw0_v=%d | "
                       "sel fm=%d sc=%d cr=%d w0=%d wr=%d | g_req_valid=%d g_req_ready=%d\n",
                       t->t_m_qfmv, t->t_m_okfm, t->t_m_hzfm, t->t_m_olderrd, t->t_m_cwhold,
                       t->t_m_qscv, t->t_m_qcrv, t->t_m_qw0v,
                       t->t_m_selfm, t->t_m_selsc, t->t_m_selcr, t->t_m_selw0, t->t_m_selwr,
                       t->t_m_greqv, t->t_m_greqr);
                printf("DUMP gateway: used=%u pending=%u read_count=%u write_active=%d gathering=%d fence_req=%d fault=%d\n",
                       t->t_gw_used, t->t_gw_pending, t->t_gw_rdcnt, t->t_gw_wactive, t->t_gw_gather, t->t_gw_fence, t->t_gw_fault);
                printf("DUMP arb: sel_m=%d locked=%d owner_m=%d wleft=%u | DDR busy=%d rd=%d we=%d\n",
                       t->t_arb_selm, t->t_arb_locked, t->t_arb_ownerm, t->t_arb_wleft, t->t_ddr_busy, t->t_ddr_rd, t->t_ddr_we);
                // sample a few times to see whether anything is moving
                for (int s = 0; s < 5; s++) {
                    for (int i = 0; i < 200; i++) posedge();
                    printf("DUMP+%d: cpu_pc=%06X fe_st=%d e_req=%d m_req=%d m_gnt=%d m_rvalid=%d gw_used=%u gw_pend=%u gw_rd=%u "
                           "arb_selm=%d locked=%d ddr_busy=%d cq_occ=%u\n",
                           (s+1)*200, t->cpu_pc, t->t_fe_st, t->t_fe_ereq, t->t_fe_mreq, t->t_fe_mgnt, t->t_fe_mrvalid,
                           t->t_gw_used, t->t_gw_pending, t->t_gw_rdcnt, t->t_arb_selm, t->t_arb_locked, t->t_ddr_busy, t->t_cq_occ);
                }
                break;
            }
        }

        if (t->cpu_fault != 0 && !faulted) {
            faulted = true; fault_pc = t->cpu_pc; fault_code = t->cpu_fault;
            printf("CPU-FAULT: fault_code=0x%02X cpu_pc=%06X clk=%llu retired=%llu\n",
                   fault_code, fault_pc, (unsigned long long)clk, (unsigned long long)retired);
            // run a little further to confirm it is stuck, then stop
            for (int i = 0; i < 200; i++) posedge();
            break;
        }
    }

    printf("INT0/ZW: n_int0=%u n_zw=%u (at end)\n", t->t_n_int0, t->t_n_zw);
    printf("BANK1-ORACLE: writes=%u be_not_ff=%u | first_nz: seen=%d addr=%07X be=%02X din=%016llX | readback: seen=%d val=%016llX\n",
           t->t_b1_wr_cnt, t->t_b1_benotff, (int)t->t_b1_first_seen, t->t_b1_first_addr, t->t_b1_first_be,
           (unsigned long long)t->t_b1_first_din, (int)t->t_b1_rb_seen, (unsigned long long)t->t_b1_rb_val);
    printf("BANK1-STORE: block0x000=%016llX block0x100=%016llX cabcell[0x101304]=%016llX (cabinet had 0x7FFF7FFF00000000=clear; correct-merge=0x7FFF7FFF7FE00000)\n",
           (unsigned long long)t->t_wr1_b0, (unsigned long long)t->t_wr1_b100, (unsigned long long)t->t_wr1_test);
    printf("ERRPATH: seen=%d (at retired=%llu) -- if seen, the POST failed the bank-1 test in sim (repro)\n",
           (int)err_path_seen, (unsigned long long)err_path_retired);
    printf("SUMMARY: clk=%llu retired=%llu loader_done=%d game_run=%d faulted=%d fault_code=0x%02X fault_pc=%06X first_div_instr=%lld cpu_pc=%06X\n",
           (unsigned long long)clk, (unsigned long long)retired, (int)loader_done_seen, (int)game_run_seen,
           (int)faulted, fault_code, fault_pc,
           first_div_instr==~0ull ? -1ll : (long long)first_div_instr, t->cpu_pc);

    // ---- HARDENED VERDICT: PASS (rc=0) ONLY on a clean cold boot ----
    // Any reload-diff mismatch, any PC divergence from the MAME golden, or any CPU fault -> non-zero.
    bool pc_div = (first_div_instr != ~0ull);
    bool ran_reload = game_run_seen && reported_reload;
    int rc = 0;
    if (stalled) {
        if (stall_pc == 0x01C164) { printf("VERDICT: REPRODUCED the cabinet STALL (CPU frozen at cpu_pc=0x01C164)\n"); rc = 48; }
        else { printf("VERDICT: STALL at cpu_pc=%06X (not the 0x01C164 signature)\n", stall_pc); rc = 49; }
    }
    else if (faulted && fault_pc == 0x040000) { printf("VERDICT: FAIL - REPRODUCED the cabinet fault (F_ILLEGAL at PC 0x040000)\n"); rc = 42; }
    else if (faulted) { printf("VERDICT: FAIL - CPU fault code %02X at pc %06X (not the 0x040000 signature)\n", fault_code, fault_pc); rc = 43; }
    else if (reload_bad) { printf("VERDICT: FAIL - reload-diff mismatch (write=%llu read=%llu vs maindata)\n",
                                  (unsigned long long)reload_wmiss, (unsigned long long)reload_rmiss); rc = 44; }
    else if (pc_div) { printf("VERDICT: FAIL - retired PC diverged from the MAME golden at instruction %llu (DUT %06X, MAME %06X)\n",
                              (unsigned long long)first_div_instr, first_div_dut, first_div_mame); rc = 45; }
    else if (!ran_reload) { printf("VERDICT: INCONCLUSIVE - the reload never completed in %llu clocks (loader_done=%d game_run=%d); raise --stop-clocks\n",
                                   (unsigned long long)clk, (int)loader_done_seen, (int)game_run_seen); rc = 46; }
    else if (retired < max_insn) { printf("VERDICT: INCONCLUSIVE - stopped at %llu retired (< max-insn %llu) with no fault; raise --stop-clocks\n",
                                          (unsigned long long)retired, (unsigned long long)max_insn); rc = 47; }
    else printf("VERDICT: PASS - clean cold boot: reload bit-exact vs maindata, %llu retired PCs match the MAME golden, no fault\n",
                (unsigned long long)retired);

    t->final();
    delete t;
    return rc;
}
