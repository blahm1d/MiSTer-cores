`timescale 1ns/1ps
`default_nettype none
// tb_zk4_cold_hostile.sv -- cab-r4 whole-core cold-boot DUT == lanes/coldboot/tb_zk4_cold.sv but with
//   (1) the HOSTILE DDR model (posted writes + random busy + random readdatavalid gaps), and
//   (2) the WRPROBE $display spam removed (it floods the log + slows the run).
// Module name kept `tb_zk4_cold` so tb_zk4_cold_main.cpp / Vtb_zk4_cold are reused unchanged.
module tb_zk4_cold #(
    parameter int HOLD = 256,
    parameter int WVL  = 24,   // DDR write visibility latency (1 = RAW preserved)
    parameter int BUSYP = 40,  // % random DDRAM_BUSY
    parameter int RDGAP = 35,  // % random readdatavalid gap
    parameter int NOBE = 0,    // legacy alias for WRMODE=1
    parameter int WRMODE = 0   // 0 honour BE, 1 NOBE, 2 DROP_PARTIAL, 3 ZERO_DISABLED
) (
    input  wire        clk, por, core_reset, show_status,
    input  wire        ioctl_download, ioctl_wr,
    input  wire [26:0] ioctl_addr,
    input  wire [15:0] ioctl_dout, ioctl_index,
    output wire        ioctl_wait,
    input  wire [15:0] in0, in1, in2, in3,
    output wire        loader_done, sdram_map_fault,
    output wire [23:0] boot_pc_o, cpu_pc,
    output wire [7:0]  cpu_fault,
    output wire        render_fault,
    output wire [2:0]  t_phase,
    output wire        t_rl_req, t_rl_we, t_rl_busy, t_game_run,
    output wire [23:0] t_rl_addr,
    output wire [31:0] t_rl_wdata,
    output wire        t_q_ack,
    output wire [31:0] t_sd_rdata, t_reloads, t_words_loaded, t_stream_crc, t_dropped,
    output wire        t_retire, t_kpc_v,
    output wire [23:0] t_kpc,
    output wire        t_l_req, t_l_ack,
    output wire [24:0] t_l_baddr,
    output wire [31:0] t_l_wdata,
    output wire        t_loader_owns,
    output wire [15:0] t_mem0, t_mem1, t_mem2, t_mem3,
    // cab-r4 deadlock state dump
    output wire [6:0]  t_fe_st,
    output wire        t_fe_ereq, t_fe_mreq, t_fe_mgnt, t_fe_mrvalid, t_fe_s2on, t_fe_wkon,
    output wire [2:0]  t_rs,
    output wire [31:0] t_cq_occ,
    output wire        t_cq_inready, t_cq_empty,
    output wire        t_m_qfmv, t_m_okfm, t_m_hzfm, t_m_olderrd, t_m_selfm, t_m_selsc, t_m_selcr, t_m_selw0, t_m_selwr,
    output wire        t_m_greqv, t_m_greqr, t_m_qscv, t_m_qcrv, t_m_qw0v, t_m_cwhold,
    output wire [5:0]  t_gw_used, t_gw_pending, t_gw_rdcnt,
    output wire        t_gw_wactive, t_gw_gather, t_gw_fence, t_gw_fault,
    output wire        t_arb_selm, t_arb_locked, t_arb_ownerm,
    output wire [7:0]  t_arb_wleft,
    output wire        t_ddr_busy, t_ddr_rd, t_ddr_we,
    output wire [31:0] t_n_int0, t_n_zw,
    // bank-1 host-write oracle
    output wire [31:0] t_b1_wr_cnt, t_b1_benotff,
    output wire        t_b1_first_seen,
    output wire [28:0] t_b1_first_addr,
    output wire [63:0] t_b1_first_din,
    output wire [7:0]  t_b1_first_be,
    output wire        t_b1_rb_seen,
    output wire [63:0] t_b1_rb_val,
    output wire [63:0] t_wr1_b0, t_wr1_b100, t_wr1_test
);
    logic [15:0] in_port [4];
    logic [7:0]  rtc [7];
    always_comb begin in_port[0]=in0; in_port[1]=in1; in_port[2]=in2; in_port[3]=in3; end
    always_comb begin rtc[0]=8'd0; rtc[1]=8'd0; rtc[2]=8'd0; rtc[3]=8'd1; rtc[4]=8'd1; rtc[5]=8'd1; rtc[6]=8'd0; end

    wire [15:0] SDRAM_DQ;
    wire [12:0] SDRAM_A; wire [1:0] SDRAM_BA;
    wire SDRAM_DQML, SDRAM_DQMH, SDRAM_nCS, SDRAM_nCAS, SDRAM_nRAS, SDRAM_nWE, SDRAM_CKE;
    wire DDRAM_BUSY, DDRAM_DOUT_READY, DDRAM_RD, DDRAM_WE;
    wire [63:0] DDRAM_DOUT, DDRAM_DIN;
    wire [28:0] DDRAM_ADDR;
    wire [7:0]  DDRAM_BURSTCNT, DDRAM_BE;
    wire [15:0] ioctl_din;
    wire signed [15:0] audio_l, audio_r;
    wire ce_pix, hs, vs, de; wire [7:0] r, g, b;

    zk4_top #(.HOLD(HOLD)) dut (
        .clk(clk), .por(por), .core_reset(core_reset), .show_status(show_status), .status_page(3'd0),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_addr(ioctl_addr),
        .ioctl_dout(ioctl_dout), .ioctl_index(ioctl_index), .ioctl_wait(ioctl_wait), .ioctl_din(ioctl_din),
        .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA), .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH),
        .SDRAM_nCS(SDRAM_nCS), .SDRAM_nCAS(SDRAM_nCAS), .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE),
        .DDRAM_BUSY(DDRAM_BUSY), .DDRAM_DOUT_READY(DDRAM_DOUT_READY), .DDRAM_DOUT(DDRAM_DOUT),
        .DDRAM_ADDR(DDRAM_ADDR), .DDRAM_BURSTCNT(DDRAM_BURSTCNT), .DDRAM_BE(DDRAM_BE), .DDRAM_DIN(DDRAM_DIN),
        .DDRAM_RD(DDRAM_RD), .DDRAM_WE(DDRAM_WE),
        .in_port(in_port), .rtc(rtc),
        .ce_pix(ce_pix), .hs(hs), .vs(vs), .de(de), .r(r), .g(g), .b(b),
        .loader_done(loader_done), .sdram_map_fault(sdram_map_fault), .cpu_pc(cpu_pc), .cpu_fault(cpu_fault),
        .render_fault(render_fault), .audio_l(audio_l), .audio_r(audio_r)
    );

    gm1_sdram_model sdram (
        .clk(clk), .dq(SDRAM_DQ), .addr(SDRAM_A), .ba(SDRAM_BA),
        .nCS(SDRAM_nCS), .nRAS(SDRAM_nRAS), .nCAS(SDRAM_nCAS), .nWE(SDRAM_nWE), .cke(SDRAM_CKE)
    );

    // HOSTILE DDR model: posted writes (24-cyc visibility), random busy, random readdatavalid gaps.
    bw1_ddr_model #(.READ_LATENCY(8), .STORE_WORDS(2097152), .STORE_BASE(29'h6000000),
                    .WRITE_VIS_LATENCY(WVL), .BUSY_PCT(BUSYP), .RDGAP_PCT(RDGAP), .NOBE(NOBE), .WRMODE(WRMODE)) ddr (
        .clk(clk), .reset(por), .busy_period(8'd3),
        .DDRAM_ADDR(DDRAM_ADDR), .DDRAM_BURSTCNT(DDRAM_BURSTCNT), .DDRAM_BE(DDRAM_BE), .DDRAM_DIN(DDRAM_DIN),
        .DDRAM_RD(DDRAM_RD), .DDRAM_WE(DDRAM_WE), .DDRAM_BUSY(DDRAM_BUSY), .DDRAM_DOUT_READY(DDRAM_DOUT_READY),
        .DDRAM_DOUT(DDRAM_DOUT)
    );

    assign boot_pc_o     = dut.boot_pc;
    assign t_phase       = dut.phase;
    assign t_rl_req      = dut.rl_req;
    assign t_rl_we       = dut.rl_we;
    assign t_rl_busy     = dut.rl_busy;
    assign t_game_run    = dut.game_run;
    assign t_rl_addr     = dut.rl_addr;
    assign t_rl_wdata    = dut.rl_wdata;
    assign t_q_ack       = dut.q_ack;
    assign t_sd_rdata    = dut.sd_rdata;
    assign t_reloads     = dut.reloads;
    assign t_words_loaded= dut.words_loaded;
    assign t_stream_crc  = dut.stream_crc;
    assign t_dropped     = dut.dropped;
    assign t_retire      = dut.u_core.c_retire;
    assign t_kpc         = dut.u_core.u_cpu.kpc;
    assign t_kpc_v       = dut.u_core.u_cpu.kpc_v;
    assign t_l_req       = dut.l_req;
    assign t_l_ack       = dut.l_ack;
    assign t_l_baddr     = dut.l_baddr;
    assign t_l_wdata     = dut.l_wdata;
    assign t_loader_owns = !dut.loader_done;
    assign t_mem0        = sdram.mem[0];
    assign t_mem1        = sdram.mem[1];
    assign t_mem2        = sdram.mem[2];
    assign t_mem3        = sdram.mem[3];

    // ---- cab-r4 deadlock state taps (hierarchical, sim only) ----
    assign t_fe_st       = dut.u_core.u_zeus.u_r.u_front.st;
    assign t_fe_ereq     = dut.u_core.u_zeus.u_r.u_front.e_req;
    assign t_fe_mreq     = dut.u_core.u_zeus.u_r.u_front.m_req;
    assign t_fe_mgnt     = dut.u_core.u_zeus.u_r.u_front.m_gnt;
    assign t_fe_mrvalid  = dut.u_core.u_zeus.u_r.u_front.m_rvalid;
    assign t_fe_s2on     = dut.u_core.u_zeus.u_r.u_front.s2_on;
    assign t_fe_wkon     = dut.u_core.u_zeus.u_r.u_front.wk_on;
    assign t_rs          = dut.u_core.u_zeus.u_r.rs;
    assign t_cq_occ      = dut.u_core.u_zeus.u_cq.g_q.occ;
    assign t_cq_inready  = dut.u_core.u_zeus.u_cq.in_ready;
    assign t_cq_empty    = dut.u_core.u_zeus.u_cq.empty;
    assign t_m_qfmv      = dut.u_core.u_zeus.u_m.qfm_v;
    assign t_m_okfm      = dut.u_core.u_zeus.u_m.ok_fm;
    assign t_m_hzfm      = dut.u_core.u_zeus.u_m.hz_fm;
    assign t_m_olderrd   = dut.u_core.u_zeus.u_m.older_rd;
    assign t_m_selfm     = dut.u_core.u_zeus.u_m.sel_fm;
    assign t_m_selsc     = dut.u_core.u_zeus.u_m.sel_sc;
    assign t_m_selcr     = dut.u_core.u_zeus.u_m.sel_cr;
    assign t_m_selw0     = dut.u_core.u_zeus.u_m.sel_w0;
    assign t_m_selwr     = dut.u_core.u_zeus.u_m.sel_wr;
    assign t_m_greqv     = dut.u_core.u_zeus.u_m.g_req_valid;
    assign t_m_greqr     = dut.u_core.u_zeus.u_m.g_req_ready;
    assign t_m_qscv      = dut.u_core.u_zeus.u_m.qsc_v;
    assign t_m_qcrv      = dut.u_core.u_zeus.u_m.qcr_v;
    assign t_m_qw0v      = dut.u_core.u_zeus.u_m.qw0_v;
    assign t_m_cwhold    = dut.u_core.u_zeus.u_m.cw_hold;
    assign t_gw_used     = dut.u_core.u_zeus.u_m.u_gw.used;
    assign t_gw_pending  = dut.u_core.u_zeus.u_m.u_gw.pending;
    assign t_gw_rdcnt    = dut.u_core.u_zeus.u_m.u_gw.read_count;
    assign t_gw_wactive  = dut.u_core.u_zeus.u_m.u_gw.write_active;
    assign t_gw_gather   = dut.u_core.u_zeus.u_m.u_gw.gathering;
    assign t_gw_fence    = dut.u_core.u_zeus.u_m.u_gw.fence_req;
    assign t_gw_fault    = dut.u_core.u_zeus.u_m.u_gw.fault;
    assign t_arb_selm    = dut.g_arb2.u_arb.sel_m;
    assign t_arb_locked  = dut.g_arb2.u_arb.locked;
    assign t_arb_ownerm  = dut.g_arb2.u_arb.owner_m;
    assign t_arb_wleft   = dut.g_arb2.u_arb.wleft;
    assign t_ddr_busy    = DDRAM_BUSY;
    assign t_ddr_rd      = DDRAM_RD;
    assign t_ddr_we      = DDRAM_WE;
    assign t_n_int0      = dut.u_core.diag[1];   // INT0 frames counted (vblank)
    assign t_n_zw        = dut.u_core.diag[2];   // Zeus writes

    // ---- cab-r4 bank-1 host-write ORACLE (WR1_BASE = 29'h0610_0000, byte 0x30800000) ----
    reg [31:0] b1_cnt, b1_benotff; reg b1_first_seen; reg [28:0] b1_first_addr; reg [63:0] b1_first_din;
    reg [7:0]  b1_first_be; reg b1_rb_seen; reg [63:0] b1_rb_val; integer w1log;
    initial begin b1_cnt=0; b1_benotff=0; b1_first_seen=0; b1_first_addr=0; b1_first_din=0; b1_first_be=0;
                  b1_rb_seen=0; b1_rb_val=0; w1log=0; end
    wire b1_wr_now = !por && DDRAM_WE && !DDRAM_BUSY
                     && DDRAM_ADDR >= 29'h0610_0000 && DDRAM_ADDR < 29'h0614_0000;
    always @(posedge clk) begin
        if (b1_wr_now) begin
            b1_cnt <= b1_cnt + 1;
            if (DDRAM_BE != 8'hFF) b1_benotff <= b1_benotff + 1;
            if (w1log < 40) begin
                w1log = w1log + 1;
                $display("BANK1WR addr=%07X(blk=%06X) be=%02X din=%016X", DDRAM_ADDR,
                         DDRAM_ADDR-29'h0610_0000, DDRAM_BE, DDRAM_DIN);
            end
            if (!b1_first_seen && DDRAM_DIN[31:0] != 32'd0) begin
                b1_first_seen <= 1'b1; b1_first_addr <= DDRAM_ADDR; b1_first_din <= DDRAM_DIN; b1_first_be <= DDRAM_BE;
                $display("BANK1WR-FIRSTNZ addr=%07X be=%02X din=%016X", DDRAM_ADDR, DDRAM_BE, DDRAM_DIN);
            end
        end
        // first host read-back after the first non-zero write: latch the 64-bit value the memsys returns
        if (b1_first_seen && !b1_rb_seen && dut.u_core.u_zeus.fm_rvalid) begin
            b1_rb_seen <= 1'b1; b1_rb_val <= dut.u_core.u_zeus.fm_rdata;
            $display("BANK1RB fm_rdata=%016X", dut.u_core.u_zeus.fm_rdata);
        end
    end
    assign t_b1_wr_cnt=b1_cnt; assign t_b1_benotff=b1_benotff; assign t_b1_first_seen=b1_first_seen;
    assign t_b1_first_addr=b1_first_addr; assign t_b1_first_din=b1_first_din; assign t_b1_first_be=b1_first_be;
    assign t_b1_rb_seen=b1_rb_seen; assign t_b1_rb_val=b1_rb_val;
    // DDR-model store at bank1 blocks 0x0 and 0x100 (index = addr - STORE_BASE=0x0600_0000)
    assign t_wr1_b0   = ddr.mem[29'h0010_0000];
    assign t_wr1_b100 = ddr.mem[29'h0010_0100];
    // the CABINET's failing cell: DDR word 0x0610_1304 -> store index 0x0010_1304
    assign t_wr1_test = ddr.mem[29'h0010_1304];

    // re-clear monitor: log every accepted write to DDR word 0x0610_1304 (clear -> test -> re-clear?)
    integer tclog; initial tclog = 0;
    always @(posedge clk) if (!por && DDRAM_WE && !DDRAM_BUSY && DDRAM_ADDR == 29'h0610_1304 && tclog < 20) begin
        tclog = tclog + 1;
        $display("TESTCELLWR #%0d be=%02X din=%016X", tclog, DDRAM_BE, DDRAM_DIN);
    end
endmodule
`default_nettype wire
