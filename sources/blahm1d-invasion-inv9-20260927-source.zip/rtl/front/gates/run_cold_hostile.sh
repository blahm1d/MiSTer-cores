#!/bin/bash
# run_cold_hostile.sh -- cab-r4 whole-core cold boot with the HOSTILE DDR model (posted writes + random
# busy + random readdatavalid gaps) and the WRPROBE spam removed. SDRAM first-write fix applied via override.
# Verilator 5.032 in WSL. Usage:
#   MSYS2_ARG_CONV_EXCL="*" wsl bash .../run_cold_hostile.sh [--max-insn N] [--stop-clocks N] [--wr-gap 0]
# Env: ZK4_MUT_FILE/ZK4_MUT (mutation hook, e.g. revert the fence fix), ZK4_KEEP=1.
set -u
Z=/mnt/d/deck/fpga/zeus
L=$Z/zeus1/lanes/coldboot
R4=$Z/zeus1/lanes/cab-r4
RTLZ=$Z/zeus1/rtl
CPU=$Z/core/rtl/cpu
GM1=/mnt/d/deck/fpga/cruisinusa/bandwidth/gm1/tests
# oracle2 (zk4-s6): the boot golden traced on MAME master d1e9f7db (INT0 at reg 0xC8 line 259; core/golden/mk4-boot10r-o2,
# from evidence o2bootregs-o2d1e9f7db-mk4-20260926T075649Z). mk4-boot10r (61c79406) takes INT0 at 256 and is superseded.
GOLD=${ZK4_GOLD:-$Z/core/golden/mk4-boot10r-o2}
MAIN=${ZK4_MAIN:-$Z/evidence/mk4-image/mk4_maindata.bin}
HOLD=${ZK4_HOLD:-256}
STAMP=$(date -u +%Y%m%dT%H%M%S%NZ)-$$
WORK=/mnt/h/temp/zeus/cab-r4/hostile-$STAMP
OUT=$R4/out
mkdir -p "$WORK/rtl" "$WORK/cpu" "$WORK/tb" "$OUT"

RTL_WRAP="wrapper/donor/c31_sdram_burst.sv wrapper/donor/c31_sdram_backing.sv wrapper/donor/gm1_hdmi_status.sv \
 wrapper/zk4_ddr_arb.sv wrapper/zk4_status_mirror.sv wrapper/zk4_ram_reload.sv \
 wrapper/zk4_sdram.sv wrapper/zk4_loader.sv wrapper/zk4_top.sv"
RTL_TIER="tier/c31_page_cache.sv tier/c31_page_cache_sa.sv tier/c31_bus_adapter.sv tier/zk4_memory_p3.sv tier/zk4_memory_fp.sv"
RTL_REND="fp32/fp32_pkg.sv fp32/fp32_units.sv setup/zr_sdp.sv front/zr_front5.sv setup/zr_setup9.sv pixel/zr_pixel10.sv \
 render/zr_fifo.sv render/zr_rfifo.sv render/zr_cmdq.sv render/zr_render5.sv \
 memsys/zr_ddr_gateway.sv memsys/zr_memsys.sv memsys/zr_rsys.sv \
 video/zr_scanout.sv core/zr_host1.sv core/zk4_c32_ctl.sv core/zk4_core.sv \
 board/zk4_pic2.sv board/zk4_ioasic.sv board/zk4_dcs_stub.sv board/zk4_cmos.sv board/zk4_board_io.sv"
CPU_FILES="c31_core.sv c31_ea.sv c31_shift.sv c31_mpyi.sv c31_cond.sv c31_addsubf.sv c31_mpyf.sv c31_negf.sv \
 c31_absf.sv c31_rnd.sv c31_norm.sv c31_fconv.sv c31_int2float.sv c31_float2int.sv"

for f in $RTL_WRAP $RTL_TIER $RTL_REND; do mkdir -p "$WORK/rtl/$(dirname $f)"; cp "$RTLZ/$f" "$WORK/rtl/$f"; done
for f in $CPU_FILES; do cp "$CPU/$f" "$WORK/cpu/"; done
cp "$CPU"/*.svh "$WORK/cpu/" 2>/dev/null || true
# cab-r4 tb + hostile DDR model; SDRAM chip model + the coldboot main driver reused
cp "$R4/tools/tb_zk4_cold_hostile.sv" "$WORK/tb/tb_zk4_cold.sv"
cp "$R4/tools/bw1_ddr_model_hostile.sv" "$WORK/tb/bw1_ddr_model.sv"
cp "$GM1/gm1_sdram_model.sv" "$WORK/tb/"
cp "$R4/tools/tb_zk4_cold_main.cpp" "$WORK/tb/"   # cab-r4 driver: stall detector + progress prints

# SDRAM first-write fix (residual word-0) -- override the donor burst with the fixed copy
cp "$L/c31_sdram_burst.fixed.sv" "$WORK/rtl/wrapper/donor/c31_sdram_burst.sv"
echo "override: c31_sdram_burst.sv <- c31_sdram_burst.fixed.sv"

# optional fence-fix override(s): ZK4_OVR_FILE (rel under rtl/) <- ZK4_OVR_SRC
if [ -n "${ZK4_OVR_SRC:-}" ]; then
  cp "$ZK4_OVR_SRC" "$WORK/rtl/${ZK4_OVR_FILE:?ZK4_OVR_FILE required with ZK4_OVR_SRC}"
  echo "override: ${ZK4_OVR_FILE} <- $ZK4_OVR_SRC"
fi

# optional mutation (verifier: prove a gate FAILS if the fix is reverted)
if [ -n "${ZK4_MUT:-}" ]; then
  MF="$WORK/rtl/${ZK4_MUT_FILE:?ZK4_MUT_FILE required with ZK4_MUT}"
  cp "$MF" /tmp/zk4h_orig_$STAMP.sv
  sed -i "$ZK4_MUT" "$MF"
  if cmp -s "$MF" /tmp/zk4h_orig_$STAMP.sv; then echo "MUTATION DID NOT APPLY: $ZK4_MUT"; exit 3; fi
  echo "mutation=$ZK4_MUT on ${ZK4_MUT_FILE}"
fi

{ echo "stamp=$STAMP hold=$HOLD gold=$GOLD main=$MAIN args=$*";
  sha256sum "$WORK"/rtl/wrapper/*.sv "$WORK"/tb/*.sv "$WORK"/tb/*.cpp 2>/dev/null; } > "$OUT/receipt-$STAMP.txt"

WARN="-Wno-fatal -Wno-WIDTH -Wno-UNOPTFLAT -Wno-CASEINCOMPLETE -Wno-UNSIGNED -Wno-SELRANGE -Wno-WIDTHCONCAT \
 -Wno-CMPCONST -Wno-PINCONNECTEMPTY -Wno-UNUSED -Wno-DECLFILENAME -Wno-MULTIDRIVEN -Wno-SYNCASYNCNET \
 -Wno-TIMESCALEMOD -Wno-INITIALDLY -Wno-COMBDLY -Wno-LATCH -Wno-BLKANDNBLK -Wno-WIDTHTRUNC -Wno-WIDTHEXPAND -Wno-BLKLOOPINIT"

cd "$WORK" || exit 2
FILES=""
for f in $RTL_WRAP $RTL_TIER $RTL_REND; do FILES="$FILES rtl/$f"; done
for f in $CPU_FILES; do FILES="$FILES cpu/$f"; done

WVL=${ZK4_WVL:-24}; BUSYP=${ZK4_BUSYP:-40}; RDGAP=${ZK4_RDGAP:-35}; NOBE=${ZK4_NOBE:-0}; WRMODE=${ZK4_WRMODE:-0}
echo "ddr knobs: WVL=$WVL BUSYP=$BUSYP RDGAP=$RDGAP NOBE=$NOBE WRMODE=$WRMODE"
verilator --cc --exe --build -O3 -j 0 --top-module tb_zk4_cold \
  -GHOLD=$HOLD -GWVL=$WVL -GBUSYP=$BUSYP -GRDGAP=$RDGAP -GNOBE=$NOBE -GWRMODE=$WRMODE --public-flat-rw -Icpu -Irtl/fp32 $WARN -DSYNTHESIS \
  tb/tb_zk4_cold.sv tb/gm1_sdram_model.sv tb/bw1_ddr_model.sv \
  $FILES \
  tb/tb_zk4_cold_main.cpp -o zk4_cold > "$OUT/build-$STAMP.log" 2>&1
BRC=$?
if [ $BRC -ne 0 ]; then echo "BUILD FAILED rc=$BRC"; tail -40 "$OUT/build-$STAMP.log"; exit 2; fi
echo "BUILD OK"

ulimit -v 16000000
timeout 3600 ./obj_dir/zk4_cold "$GOLD" "$MAIN" "$@" 2>&1 | tee "$OUT/run-$STAMP.log" | grep -v "WRPROBE"
RC=${PIPESTATUS[0]}
echo "rc=$RC" | tee -a "$OUT/receipt-$STAMP.txt"
echo "OUT=$OUT/run-$STAMP.log rc=$RC"
[ "${ZK4_KEEP:-0}" = 1 ] || rm -rf "$WORK"
exit $RC
