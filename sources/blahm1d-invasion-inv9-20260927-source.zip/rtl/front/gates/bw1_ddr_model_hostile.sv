`timescale 1ns/1ps
`default_nettype none
// bw1_ddr_model_hostile.sv -- cab-r4 DDR model that MATCHES the proven rsys/memsys gate contract
// (zeus1/rtl/memsys/tb_zr_rsys.cpp:70-90): a PER-BEAT due-time queue, MANY reads outstanding, returned
// IN ORDER one beat/clock, FULL burstcount, writes land on acceptance. The donor bw1_ddr_model deadlocks
// the MK4 gateway (4-bit burstcount truncation + single outstanding read); both are fixed here.
// Optional hostile knobs (leave at faithful defaults to reproduce the gate's model):
//   BUSY_PCT          random DDRAM_BUSY on the COMMAND side (Avalon waitrequest) -- the gate's DWBP.
//   WRITE_VIS_LATENCY >1 posts writes (visible only after N cycles) -- probes read-after-write dependence.
//   RDGAP_PCT         >0 injects extra readdatavalid holes (beyond the natural per-beat schedule).
module bw1_ddr_model #(
    parameter integer READ_LATENCY = 12,
    parameter integer STORE_WORDS  = 8192,
    parameter [28:0]  STORE_BASE   = 29'h0,
    parameter integer WRITE_VIS_LATENCY = 1,
    parameter integer BUSY_PCT     = 0,
    parameter integer RDGAP_PCT    = 0,
    parameter integer NOBE         = 0,      // legacy alias for WRMODE=1
    parameter integer WRMODE       = 0,      // write behaviour of the DDR port:
                                             //   0 = HONOUR BE (correct read-modify-write; MAME-faithful)
                                             //   1 = NOBE: ignore BE, write all 8 bytes of DIN
                                             //   2 = DROP_PARTIAL: a write with BE != 0xFF is DISCARDED (no effect)
                                             //   3 = ZERO_DISABLED: write all 8 bytes, disabled lanes -> 0
    parameter [31:0]  SEED         = 32'hC0FFEE01
) (
    input  wire        clk, reset,
    input  wire [7:0]  busy_period,            // ignored (compat)
    input  wire [28:0] DDRAM_ADDR,
    input  wire [7:0]  DDRAM_BURSTCNT, DDRAM_BE,
    input  wire [63:0] DDRAM_DIN,
    input  wire        DDRAM_RD, DDRAM_WE,
    output reg         DDRAM_BUSY,
    output reg         DDRAM_DOUT_READY,
    output reg [63:0]  DDRAM_DOUT
);
    localparam integer BQ = 1024;               // pending-beat queue depth (>= max outstanding beats)
    localparam integer PW = 512;                // posted-write ring depth
    reg [63:0] mem [0:STORE_WORDS-1];
    reg [63:0] bq_data [0:BQ-1];
    reg [31:0] bq_due  [0:BQ-1];
    reg [10:0] bq_head, bq_tail; reg [11:0] bq_cnt;
    reg [31:0] cyc, lfsr;
    // posted writes
    reg [28:0] pw_addr [0:PW-1];
    reg [63:0] pw_data [0:PW-1];
    reg [7:0]  pw_be   [0:PW-1];
    reg [15:0] pw_ttl  [0:PW-1];
    reg        pw_v    [0:PW-1];
    integer i, j, k;
    initial begin
        for (i=0;i<STORE_WORDS;i=i+1) mem[i]=64'd0;
        for (i=0;i<PW;i=i+1) pw_v[i]=1'b0;
    end
    function [63:0] fpat(input [28:0] a); fpat = {~a[28:0],3'b0, a[28:0]}; endfunction
    function integer in_store(input [28:0] a);
        in_store = (a>=STORE_BASE && a < (STORE_BASE+STORE_WORDS[28:0])) ? 1 : 0;
    endfunction
    function [63:0] rdword(input [28:0] a);
        rdword = in_store(a) ? mem[a-STORE_BASE] : fpat(a);
    endfunction
    wire next_bit = lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0];
    wire bq_full = (bq_cnt > (BQ-40));
    always @* begin
        DDRAM_BUSY = reset ? 1'b1 : (bq_full || (BUSY_PCT!=0 && lfsr[7:0] < ((BUSY_PCT*256)/100)));
    end
    always @(posedge clk) begin
        DDRAM_DOUT_READY <= 1'b0;
        if (reset) begin
            cyc<=0; lfsr<=SEED; bq_head<=0; bq_tail<=0; bq_cnt<=0; DDRAM_DOUT<=0;
            for (j=0;j<PW;j=j+1) pw_v[j]<=1'b0;
        end else begin : body
            integer add; reg del;
            add = 0; del = 1'b0;
            cyc<=cyc+1;
            lfsr <= {lfsr[30:0], next_bit};
            // commit posted writes whose ttl expired
            for (j=0;j<PW;j=j+1) if (pw_v[j]) begin
                if (pw_ttl[j]<=16'd1) begin
                    if (in_store(pw_addr[j]))
                        for (i=0;i<8;i=i+1) if (pw_be[j][i]) mem[pw_addr[j]-STORE_BASE][i*8+:8] <= pw_data[j][i*8+:8];
                    pw_v[j]<=1'b0;
                end else pw_ttl[j] <= pw_ttl[j]-16'd1;
            end
            // deliver the head beat when due, one per clock, in order (optional extra random gaps)
            if (bq_cnt!=0 && bq_due[bq_head] <= cyc) begin
                if (RDGAP_PCT!=0 && lfsr[15:8] < ((RDGAP_PCT*256)/100)) begin
                    // extra random hole
                end else begin
                    DDRAM_DOUT <= bq_data[bq_head]; DDRAM_DOUT_READY <= 1'b1;
                    bq_head <= bq_head + 11'd1; del = 1'b1;
                end
            end
            // command acceptance (only when not busy)
            if (!DDRAM_BUSY) begin
                if (DDRAM_RD) begin : rdpush
                    integer n; n = DDRAM_BURSTCNT; if (n==0) n = 256;
                    for (k=0;k<n;k=k+1) begin
                        bq_data[(bq_tail+k[10:0])] <= rdword(DDRAM_ADDR + 29'(k));
                        bq_due [(bq_tail+k[10:0])] <= cyc + READ_LATENCY[31:0] + 32'(k);
                    end
                    bq_tail <= bq_tail + 11'(n);
                    add = n;
                end else if (DDRAM_WE) begin : wr
                    reg [7:0] ebe; reg [63:0] edin; reg dowr; integer mode;
                    mode = (WRMODE!=0) ? WRMODE : ((NOBE!=0) ? 1 : 0);
                    dowr = 1'b1; ebe = DDRAM_BE; edin = DDRAM_DIN;
                    case (mode)
                        1: begin ebe = 8'hFF; end                                   // NOBE: all 8 bytes = DIN
                        2: begin if (DDRAM_BE != 8'hFF) dowr = 1'b0; end             // DROP_PARTIAL: discard partial write
                        3: begin edin = 64'd0; for (i=0;i<8;i=i+1) if (DDRAM_BE[i]) edin[i*8+:8]=DDRAM_DIN[i*8+:8]; ebe = 8'hFF; end
                        default: ;                                                  // 0: honour BE (RMW)
                    endcase
                    if (dowr) begin
                        if (WRITE_VIS_LATENCY<=1) begin
                            if (in_store(DDRAM_ADDR))
                                for (i=0;i<8;i=i+1) if (ebe[i]) mem[DDRAM_ADDR-STORE_BASE][i*8+:8] <= edin[i*8+:8];
                        end else begin : wpost
                            reg found; found=1'b0;
                            for (j=0;j<PW;j=j+1) if (!found && !pw_v[j]) begin
                                pw_v[j]<=1'b1; pw_addr[j]<=DDRAM_ADDR; pw_data[j]<=edin; pw_be[j]<=ebe;
                                pw_ttl[j]<=WRITE_VIS_LATENCY[15:0]; found=1'b1;
                            end
                            if (!found && in_store(DDRAM_ADDR))
                                for (i=0;i<8;i=i+1) if (ebe[i]) mem[DDRAM_ADDR-STORE_BASE][i*8+:8] <= edin[i*8+:8];
                        end
                    end
                end
            end
            bq_cnt <= bq_cnt - (del ? 12'd1 : 12'd0) + 12'(add);
        end
    end
endmodule
`default_nettype wire
