# zr_front v2 — predicted structure, cost and clocks (written BEFORE the fit)

Per the build-to-close rule: the prediction goes down first, the fit confirms or corrects it. v1's measurement is the
baseline; v2 is only worth building if the fit of v1 says there is room for it.

## v1 measured (bit-exact gate, 20/20 fight frames + state + register file)
| | at 8-clock memory | at 23-clock memory |
|---|---|---|
| busy clocks / frame | 731 K (83 % of a 50 MHz frame) | 928 K (105 % — over budget) |
| per rendered polygon | ~330 clk | ~430 clk |
Area/Fmax: `zeus1/area/front1_20ns` — PENDING. **No v2 work starts until that lands.**

## Where v1's clocks go (structural, from the state machine, not yet profiled)
1. **Projection ~130 clk/quad.** 4 vertices x (divide 16 + 2 multiplies + 2 adds), each waiting for the pipes to drain
   before the next step. The divider is idle most of that.
2. **Emission 42 clk/quad.** One 32-bit word per clock into the output FIFO after everything else finishes.
3. **Model reads.** One outstanding request; 7 blocks per quad, so 7 x latency is exposed whenever the prefetch FIFO
   drains (at 23-clock latency that alone is ~160 clk/quad if nothing hides it).

## v2 changes, each with its predicted saving
| change | mechanism | predicted |
|---|---|---|
| pipelined memory port | walker issues requests while earlier ones are outstanding (in-order responses), 16-deep FIFO | model reads stop being latency-bound: ~160 -> ~15 clk/quad at 23-clock latency |
| overlapped projection | vertex i+1's divide starts as soon as the divider frees; multiply/add of vertex i chains off the multiply's write-back | ~130 -> ~75 clk/quad |
| reserved output records | reserve a record in a 64-bit-wide output RAM, write each field when it becomes final (object words during the transform, x/y after the adjust), commit at the end; culled/dropped quads roll back | ~42 -> ~12 clk/quad |
| clip vertices in 6 field RAMs | one clock per vertex copy instead of six | ~20 clk/quad |
**Predicted total: ~150 clk per rendered polygon, ~250-300 K clk/frame (30 % of a 50 MHz frame), latency-independent.**

## MEASURED 2026-09-22 — phase census (20 fight frames, hostile 23-clock memory, `st_mem/st_tr/st_zc/st_proj/st_emit/st_dec`)

| phase | clocks | share of 18,555,153 busy | the change that targets it |
|---|---|---|---|
| model decode | 7,528,864 | 41 % | mostly the memory wait below (S_MPOP with an empty walker FIFO) |
| **projection** | 5,842,750 | **31 %** | overlapped divide |
| **memory wait** | 5,031,941 | **27 %** (inside decode) | pipelined memory port |
| transform | 1,723,372 | 9 % | leave alone |
| emit | 1,714,513 | 9 % | reserved output records |
| z-clip | 1,239,493 | 7 % | leave alone |

**The census confirms the predicted ranking** (memory port first, projection second, emit third) and rules out the
other two: transform and z-clip together are 16 % and are not worth restructuring. Implement 1 and 2, measure, and
only then decide whether emit is worth the extra complexity.

## Predicted cost (to be confirmed by `zeus1/area/front2_20ns`)
- Float units unchanged: one add (latency 5), one multiply (latency 5), one radix-4 divider.
- +6 small field RAMs (8 x 32 each — MLAB-sized), +1 output RAM (64 entries x 65 bits), -1 combined clipvert RAM.
- Reservation/rollback pointers: ~40 flops. Walker in-flight counter: ~10 flops.
- **Predicted: within +200 ALM and +2 M10K of v1, same Fmax** (no new arithmetic in any path; the changes are
  sequencing and storage). If the v1 fit is already near its allowance, v2's sequencing changes do not rescue it —
  the block would need a different split instead, which is why the fit comes first.

## Timing risk to watch (predict, then check the fit's worst path)
- The 35-bit transform accumulate plus the "rounding hack" plus the 20-bit slice is one adder chain: ~3 levels, safe.
- The cull dot product is 3 x (25 x 20) products summed to 47 bits in ONE clock: that is the widest arithmetic in the
  block. If the v1 fit's worst path lands there, split it (products one clock, sum the next) BEFORE adding v2's
  sequencing work.
