// Gate for zr_front: the capture's CPU writes to the Zeus 1 window (io.log.gz, 0x880000-0x8803FF), replayed through the
// RTL from the capture's seed; the RTL's output stream vs zr1 --fronttap WORD FOR WORD (RB / CLR / QUD / DBQ / HWW /
// HRD records), and at every frame boundary (frames.txt, the same point zr1 compares MAME's frame buffer) the
// persistent state (matrix, point, palbase, objdata, cliprect, fifo_words) and the WHOLE register file.
// The testbench is the wave RAM: seed images, fixed latency MLAT, writes applied on acceptance, out-of-range reads
// return 0 and are counted (zr1 does the same; MAME's value there is undefined).
// usage: tb_zr_front <render-evidence-dir> <front.bin> [max-frames] [mlat] [out-backpressure%]
#include "Vzr_front.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <zlib.h>

typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8; typedef int32_t s32; typedef uint64_t u64;
static std::vector<u8> read_gz(const std::string& p) {
    std::vector<u8> out; gzFile f = gzopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    u8 buf[1 << 16]; int n; while ((n = gzread(f, buf, sizeof buf)) > 0) out.insert(out.end(), buf, buf + n); gzclose(f); return out;
}
static std::vector<u8> read_file(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); std::vector<u8> v(n); if (fread(v.data(), 1, n, f) != (size_t)n) exit(2); fclose(f); return v;
}
template <class T> static T item(const std::string& ev, const char* name) {
    std::vector<u8> v = read_gz(ev + "/seed_item_0_" + name + ".bin.gz"); T t; memcpy(&t, v.data(), sizeof(T)); return t;
}
static u64 rs = 0x9E3779B97F4A7C15ull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

int main(int argc, char** argv) {
    if (argc < 3) { printf("usage: tb_zr_front <evidence> <front.bin> [max-frames] [mlat] [out-bp%%]\n"); return 2; }
    std::string ev = argv[1]; int maxf = argc > 3 ? atoi(argv[3]) : 1 << 30;
    int MLAT = argc > 4 ? atoi(argv[4]) : 8, OBP = argc > 5 ? atoi(argv[5]) : 0;
    std::vector<u8> w[2] = {read_gz(ev + "/seed_item_0_m_waveram_0_.bin.gz"), read_gz(ev + "/seed_item_0_m_waveram_1_.bin.gz")};
    std::vector<u8> regs = read_file(ev + "/seed_zeus1_regs.bin");
    std::vector<u8> fifo = read_gz(ev + "/seed_item_0_m_zeus_fifo.bin.gz");
    std::vector<u8> mtx = read_gz(ev + "/seed_item_0_m_zeus_matrix.bin.gz"), pnt = read_gz(ev + "/seed_item_0_m_zeus_point.bin.gz");
    std::vector<u8> refb = read_file(argv[2]); const u32* ref = (const u32*)refb.data(); size_t nref = refb.size() / 4, rp = 0;
    std::vector<std::pair<int, u64>> frames;
    { FILE* f = fopen((ev + "/frames.txt").c_str(), "r"); int fr; unsigned long long n, s, a;
      while (f && fscanf(f, "%d %llu %llu %llu", &fr, &n, &s, &a) == 4) frames.push_back({fr, n}); if (f) fclose(f); }
    std::vector<u8> io = read_gz(ev + "/io.log.gz"); io.push_back(0);

    Verilated::commandArgs(argc, argv);
    Vzr_front* t = new Vzr_front;
    int mcnt = -1; u64 clocks = 0, oob = 0, words = 0, mreq = 0; bool bad = false;
    auto tick = [&]() {
        t->clk = 0; t->eval();
        t->m_ack = 0;
        if (t->m_req) {
            if (mcnt < 0) mcnt = MLAT;
            if (mcnt == 0) {
                u64 off = (u64)t->m_blk * 8; std::vector<u8>& m = w[t->m_ram];
                if (t->m_we) {
                    if (off + 8 > m.size()) oob++;
                    else for (int l = 0; l < 4; l++) if (t->m_lanes >> l & 1) { u16 v = (u16)(t->m_wdata >> (16 * l)); memcpy(&m[off + 2 * l], &v, 2); }
                } else {
                    u64 d = 0; if (off + 8 > m.size()) oob++; else memcpy(&d, &m[off], 8);
                    t->m_rdata = d;
                }
                t->m_ack = 1; mcnt = -2; mreq++;
            } else if (mcnt > 0) mcnt--;
        } else mcnt = -1;
        t->o_ready = (OBP == 0) || (int)(rnd() % 100) >= OBP;
        if (t->o_valid && t->o_ready && !bad) {
            u32 wv = t->o_word;
            if (rp >= nref) { printf("FAIL: RTL emitted word %08X past the end of the reference\n", wv); bad = true; }
            else if (ref[rp] == 0x46524D31u) { printf("FAIL: RTL emitted %08X where the reference has a frame boundary (word %zu)\n", wv, rp); bad = true; }
            else if (wv != ref[rp]) { printf("FAIL: output word %zu: RTL %08X reference %08X\n", rp, wv, ref[rp]); bad = true; }
            else { rp++; words++; }
        }
        t->eval(); t->clk = 1; t->eval(); clocks++;
    };
    t->rst = 1; t->wr_valid = 0; t->sd_we = 0; tick(); tick(); t->rst = 0; tick();
    auto seed = [&](int sel, int idx, u32 d) { t->sd_we = 1; t->sd_sel = sel; t->sd_idx = idx; t->sd_data = d; tick(); t->sd_we = 0; };
    for (int k = 0; k < 0x400; k++) { u32 v; memcpy(&v, &regs[4 * k], 4); seed(0, k, v); }
    for (int k = 0; k < 20; k++) { u32 v; memcpy(&v, &fifo[4 * k], 4); seed(1, k, v); }
    seed(2, 0, item<u8>(ev, "m_zeus_fifo_words"));
    for (int k = 0; k < 9; k++) { int16_t v; memcpy(&v, &mtx[2 * k], 2); seed(3, k, (u32)(s32)v); }
    for (int k = 0; k < 3; k++) { u32 v; memcpy(&v, &pnt[4 * k], 4); seed(4, k, v); }
    seed(5, 0, item<u32>(ev, "m_zeus_palbase")); seed(6, 0, item<u32>(ev, "m_zeus_objdata"));
    seed(7, 0, (u32)item<s32>(ev, "m_zeus_cliprect_min_x")); seed(7, 1, (u32)item<s32>(ev, "m_zeus_cliprect_max_x"));
    seed(7, 2, (u32)item<s32>(ev, "m_zeus_cliprect_min_y")); seed(7, 3, (u32)item<s32>(ev, "m_zeus_cliprect_max_y"));

    auto wait_idle = [&]() { u64 g = 0; while (!t->idle && !bad) { tick(); if (++g > 200000000ull) { printf("FAIL: never idle\n"); exit(1); } } };
    const char* p = (const char*)io.data(); u64 rec = 0; size_t fi = 1; int ok = 0, nfr = 0;
    auto frame = [&](int fr) {
        wait_idle(); if (bad) return;
        if (rp + 3 > nref || ref[rp] != 0x46524D31u || (int)ref[rp + 1] != fr || ref[rp + 2] != 0x53544131u) {
            printf("FAIL: frame %d: reference not at FRM/STA (word %zu = %08X): the RTL emitted fewer words\n", fr, rp, rp < nref ? ref[rp] : 0); bad = true; return;
        }
        rp += 3; int sd = 0;
        for (int k = 0; k < 19; k++) if (t->dbg_state[k] != ref[rp + k]) { if (sd < 4) printf("  frame %d state[%d]: RTL %08X ref %08X\n", fr, k, t->dbg_state[k], ref[rp + k]); sd++; }
        rp += 19;
        if (ref[rp] != 0x52454731u) { printf("FAIL: frame %d: no REG record\n", fr); bad = true; return; }
        rp++; int rd = 0;
        for (int k = 0; k < 0x400; k++) {
            t->rd_off = k; tick();
            t->clk = 0; t->eval();
            if (t->rd_data != ref[rp + k]) { if (rd < 4) printf("  frame %d reg %03X: RTL %08X ref %08X\n", fr, k, t->rd_data, ref[rp + k]); rd++; }
        }
        rp += 0x400; nfr++;
        if (sd || rd) { printf("FAIL: frame %d: %d state words and %d registers differ\n", fr, sd, rd); bad = true; return; }
        ok++;
        printf("frame %d: stream IDENTICAL through word %zu, state + register file IDENTICAL (quads %u culled %u emitted %u, clocks %llu)\n",
               fr, rp, t->st_quads, t->st_culled, t->st_emitted, (unsigned long long)clocks);
    };
    while (*p && fi < frames.size() && nfr < maxf && !bad) {
        char kind; unsigned addr, data;
        if (sscanf(p, "%c %x %x", &kind, &addr, &data) != 3) { printf("FAIL: io parse at record %llu\n", (unsigned long long)rec); return 2; }
        if (kind == 'W' && addr >= 0x880000 && addr <= 0x8803FF) {
            t->wr_off = addr - 0x880000; t->wr_data = data; t->wr_valid = 1;
            u64 g = 0; while (!t->wr_ready && !bad) { tick(); if (++g > 200000000ull) { printf("FAIL: write never accepted\n"); return 1; } }
            tick(); t->wr_valid = 0;
        }
        rec++;
        while (*p && *p != '\n') p++;
        if (*p) p++;
        while (fi < frames.size() && rec == frames[fi].second && !bad) { frame(frames[fi].first); fi++; }
    }
    printf("SUMMARY words %llu quads %u culled %u emitted %u float-exceptions %u busy %u clocks %llu memory requests %llu out-of-range %llu (latency %d, out back-pressure %d%%)\n",
           (unsigned long long)words, t->st_quads, t->st_culled, t->st_emitted, t->st_exc, t->st_busy, (unsigned long long)clocks,
           (unsigned long long)mreq, (unsigned long long)oob, MLAT, OBP);
    bool pass = !bad && ok > 0 && ok == nfr;
    printf("%s: %d of %d frames: output stream word-exact vs zr1 --fronttap, state + register file exact\n", pass ? "PASS" : "FAIL", ok, nfr);
    delete t; return pass ? 0 : 1;
}
