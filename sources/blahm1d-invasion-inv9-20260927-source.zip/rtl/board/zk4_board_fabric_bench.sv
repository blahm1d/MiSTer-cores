// zk4_board_fabric_bench.sv -- tb_zk4_board_fabric's DUT: zk4_board_io wired to the REAL fabric DCS2 sound board
// (zk4_dcs2, rtl/dcs2) exactly as zk4_top wires it (DCS_FABRIC = 1). The bench serves zk4_dcs2's DDR port from a model
// holding the sound ROM, and drives the ROM download (ioctl index 3) through zk4_dcs2's own loader.
module zk4_board_fabric_bench #(parameter logic [7:0] RAND12 = 8'h00, RAND13 = 8'h00,
                                parameter int PIC_UPPER = 461, PIC_YEAR = 1997, parameter bit SHUFFLE_DEFAULT = 1'b1,
                                parameter bit INV_ROM = 1'b0) (   // Invasion: 468 / 1999 / 0 / 1 (zk4_top per-game constants)
  input  logic        clk, por, rst, dcs_rst,
  input  logic        req, we, input logic [23:0] addr, input logic [31:0] wdata,
  output logic        rvalid, output logic [31:0] rdata,
  input  logic [15:0] in_port [4],
  input  logic [7:0]  rtc [7],
  // sound ROM download (hps_io WIDE, index 3)
  input  logic        ioctl_download, ioctl_wr, input logic [15:0] ioctl_index, ioctl_dout, output logic ioctl_wait,
  // zk4_dcs2 DDR port (the bench's DDR model)
  output logic        s_read, s_write, output logic [31:0] s_address, output logic [63:0] s_writedata,
  output logic [7:0]  s_byteenable,
  input  logic        s_waitrequest, s_readdatavalid, input logic [63:0] s_readdata,
  // observability
  output logic        rom_loaded, output logic [13:0] dsp_pc, output logic [15:0] dcs_control_o, dcs_data_o
);
  logic [15:0] dcs_control, dcs_data, dcs_data2, dcs_wdata; logic dcs_input_empty, dcs_output_full;
  logic dcs_data_w, dcs_ack_w, dcs_data_r, dcs_reset_w, dcs_reset_level, ioasic_irq;
  zk4_board_io #(.RAND12(RAND12), .RAND13(RAND13), .PIC_UPPER(PIC_UPPER), .PIC_YEAR(PIC_YEAR),
    .SHUFFLE_DEFAULT(SHUFFLE_DEFAULT)) u_b (.clk, .rst, .req, .we, .addr, .wdata, .rvalid, .rdata, .in_port,
    .rtc, .dcs_control, .dcs_data, .dcs_data2, .dcs_input_empty, .dcs_output_full, .dcs_data_w, .dcs_wdata, .dcs_ack_w,
    .dcs_data_r, .dcs_reset_w, .dcs_reset_level, .ioasic_irq, .h_we(1'b0), .h_row(14'd0), .h_d(16'd0), .h_q());
  logic signed [15:0] a_l, a_r; logic a_ce;
  zk4_dcs2 #(.INV_ROM(INV_ROM), .SPORT0_TIMER(INV_ROM), .LATCH_STATUS(INV_ROM)) u_dcs2 (.clk, .por, .rst(dcs_rst),
    .data_w(dcs_data_w), .wdata(dcs_wdata), .ack_w(dcs_ack_w), .data_r(dcs_data_r), .reset_w(dcs_reset_w),
    .reset_level(dcs_reset_level), .control(dcs_control), .data(dcs_data), .data2(dcs_data2),
    .input_empty(dcs_input_empty), .output_full(dcs_output_full),
    .ioctl_download, .ioctl_wr, .ioctl_index, .ioctl_dout, .ioctl_wait,
    .s_read, .s_write, .s_address, .s_writedata, .s_byteenable, .s_waitrequest, .s_readdatavalid, .s_readdata,
    .audio_l(a_l), .audio_r(a_r), .audio_ce(a_ce),
    .rom_loaded, .rom_bytes(), .rom_crc(), .cache_misses(), .dac_underruns(), .dsp_pc, .pm_oow());
  assign dcs_control_o = dcs_control; assign dcs_data_o = dcs_data;
endmodule
