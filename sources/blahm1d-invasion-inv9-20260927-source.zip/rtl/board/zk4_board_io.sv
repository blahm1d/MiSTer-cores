// zk4_board_io.sv -- the MK4 board devices outside RAM / ROM / Zeus / CPU control (MAME 0.289 midzeus.cpp zeus_map
// :826-841, unmap_value_high):
//   8D0000-8D0009 disk_asic_jr     register file (disk_asic_jr_r / _w :437-535); machine_reset sets [6] = 0xA0 (:242)
//   990000-99000F Midway I/O ASIC  zk4_ioasic
//   9E0000        watchdog         write ignored (nopw); read unmapped -> 0xFFFFFFFF
//   9F0000-9F7FFF CMOS             read = nvram | 0xFFFFFF00 (:286-289); write stored only when disk_asic_jr[2] and
//                                  not protected; every write re-protects (:276-283). NVRAM default all ones (:1387).
//   9F8000        CMOS protect     write clears the protection (:292-295); read unmapped
//   anything else in 800000-9FFFFF that reaches this block: unmapped (reads 0xFFFFFFFF, writes dropped)
// Storage: CMOS 32 K x 8 in M10K (only the low byte is ever visible). The core top routes only this block's ranges
// here; the CPU control page (808000) and the Zeus window (880000) are elsewhere.
// Bus: one-clk req (we, word address, wdata); rvalid + rdata one clk later.
module zk4_board_io #(parameter int CLK_HZ = 50_000_000, parameter logic [7:0] RAND12 = 8'h00, RAND13 = 8'h00,
                      parameter int PIC_UPPER = 461, PIC_YEAR = 1997, parameter bit SHUFFLE_DEFAULT = 1'b1) (
  input  logic        clk, rst,
  input  logic        req, we, input logic [23:0] addr, input logic [31:0] wdata,
  output logic        rvalid, output logic [31:0] rdata,
  input  logic [15:0] in_port [4],
  input  logic [7:0]  rtc [7],
  // DCS2 (stand-in, ARM transport or fabric)
  input  logic [15:0] dcs_control, dcs_data, dcs_data2, input logic dcs_input_empty, dcs_output_full,
  output logic        dcs_data_w, output logic [15:0] dcs_wdata, output logic dcs_ack_w, dcs_data_r,
  output logic        dcs_reset_w, dcs_reset_level,
  output logic        ioasic_irq,
  // MiSTer host port on the CMOS (hps_io WIDE ioctl, index 2): row = byte address >> 1, one halfword per row
  input  logic        h_we, input logic [13:0] h_row, input logic [15:0] h_d, output logic [15:0] h_q
);
  logic is_jr, is_io, is_cmos, is_prot;
  assign is_jr   = addr >= 24'h8D0000 && addr <= 24'h8D0009;
  assign is_io   = addr[23:4] == 20'h99000;
  assign is_cmos = addr >= 24'h9F0000 && addr <= 24'h9F7FFF;
  assign is_prot = addr == 24'h9F8000;

  // disk_asic_jr
  logic [31:0] jr [10];
  logic        prot;                                             // m_cmos_protected (reset true, :240)
  // I/O ASIC
  logic [31:0] io_q;
  zk4_ioasic #(.CLK_HZ(CLK_HZ), .RAND12(RAND12), .RAND13(RAND13), .PIC_UPPER(PIC_UPPER), .PIC_YEAR(PIC_YEAR),
    .SHUFFLE_DEFAULT(SHUFFLE_DEFAULT)) u_io (.clk, .rst, .req(req && is_io), .we,
    .off(addr[3:0]), .wdata, .rdata(io_q), .in_port, .rtc, .dcs_control, .dcs_data, .dcs_data2, .dcs_input_empty,
    .dcs_output_full, .dcs_data_w, .dcs_wdata, .dcs_ack_w, .dcs_data_r, .dcs_reset_w, .dcs_reset_level, .irq(ioasic_irq));
  // CMOS
  logic cm_we; logic [7:0] cm_q;
  assign cm_we = req && we && is_cmos && jr[2] != 32'd0 && !prot;
  // zk4_cmos: inverted storage (all ones untouched) + the MiSTer host port (NVRAM save / restore)
  zk4_cmos u_cmos (.clk, .a_we(cm_we), .a_addr(addr[14:0]), .a_d(wdata[7:0]), .a_q(cm_q),
                   .b_we(h_we), .b_row(h_row), .b_d(h_d), .b_q(h_q));

  logic sel_cmos; logic [31:0] q_other;
  always_ff @(posedge clk)
    if (rst) begin
      for (int i = 0; i < 10; i++) jr[i] <= '0;
      jr[6] <= 32'hA0; prot <= 1'b1; rvalid <= 1'b0;
    end else begin
      rvalid <= req && !we;
      sel_cmos <= is_cmos;
      q_other <= is_jr ? jr[addr[3:0]] : is_io ? io_q : 32'hFFFFFFFF;
      if (req && we) begin
        if (is_jr) jr[addr[3:0]] <= wdata;
        if (is_cmos) prot <= 1'b1;
        if (is_prot) prot <= 1'b0;
      end
    end
  // disk_asic_jr[2]: "only the low bit is used" (:445-448) but cmos_w tests the whole word (:278): kept whole
  assign rdata = sel_cmos ? {24'hFFFFFF, cm_q} : q_other;
endmodule
