#!/bin/bash
# zk4 board-device mutation gate: every mutant must FAIL the exact-mode replay. usage: wsl bash mutate_zk4_board.sh <cold devices.log> [jobs]
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/board; LOG="$1"; J="${2:-4}"
T=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}"); export T D LOG
one() { m="$1"; line=$(awk -F"\t" -v m="$m" '$1==m' $D/mutants_zk4_board.txt); f=$(echo "$line" | cut -f2); e=$(echo "$line" | cut -f3)
  ZKB_MUT="$e" ZKB_MUT_FILE="$f" timeout 3600 bash $D/run_zk4_board.sh "$LOG" exact > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc"; }
export -f one
LIST=$(grep -v "^#" $D/mutants_zk4_board.txt | cut -f1 | tr "\n" " ")
printf "%s\n" $LIST | xargs -P "$J" -I{} bash -c "one {}"
bad=0
for m in $LIST; do
  rc=$(cat "$T/$m.rc")
  if grep -q "DID NOT APPLY\|BUILD FAILED" "$T/$m.log"; then echo "$m NOT APPLIED / BUILD FAILED"; bad=1
  elif [ "$rc" = 0 ] && grep "^#EQUIV" $D/mutants_zk4_board.txt | grep -qw "$m"; then echo "$m survived: equivalent on MK4 evidence (see list header)"
  elif [ "$rc" = 0 ]; then echo "$m SURVIVED"; bad=1
  else echo "$m killed: $(grep -m1 MISMATCH "$T/$m.log" | cut -c1-120)"; fi
done
rm -rf "$T"; exit $bad
