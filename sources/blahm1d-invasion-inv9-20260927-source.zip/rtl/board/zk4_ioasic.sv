// zk4_ioasic.sv -- Midway I/O ASIC as MK4 uses it (MAME 0.289 williams/midwayic.cpp blob d20d6b25):
// ioasic_reset :791-800, update_ioasic_irq :803-826, ioasic_input_empty / output_full :841-860, get_fifo_status
// :906-918, read :1007-1104, write :1132-1252. MK4 config (midzeus.cpp:1405-1419): SHUFFLE_STANDARD = the identity map
// (:738), shuffle_default 1 (active from reset), DCS2 attached, ports 0-3 = DIPS / SYSTEM / IN1 / IN2.
//
// Scope decisions (each cited, MAME-reachable on MK4 or not):
//   * the ASIC sound FIFO (fifo_w / fifo_full_w, :961-993) is fed only by drivers that stream through it (not
//     midzeus): on MK4 it is always empty, so get_fifo_status() = 0x08 constant and INTSTAT bit 3 is always set.
//   * the IRQ output (m_irq_callback) is not wired on MK4 (midzeus.cpp configures no irq callback): computed, exported.
//   * UART: registers + loopback per :1165-1187; MK4 never touches ports 4-6 (tools/device_census_log.py, 3,600 frames).
//   * aux output (PICIN write, :1231-1234) has no MK4 consumer.
// CPU interface: one-clk req with we / off[3:0] / wdata; rdata valid in the SAME clk (combinational, the caller
// registers it); read side effects (UARTIN, SOUNDIN, PICIN) apply at the req edge.
// DCS interface (dcs.cpp): control_r = m_latch_control (bit 11 input empty, bit 10 output empty), data_r / data2_r,
// data_w (SOUNDOUT), ack_w (SOUNDIN write, and SOUNDIN read when auto-ack), reset_w (SOUNDCTL bit 0), plus the two
// callback levels input_empty / output_full that drive the sound IRQ state.
module zk4_ioasic #(parameter int CLK_HZ = 50_000_000, parameter logic [7:0] RAND12 = 8'h00, RAND13 = 8'h00,
                    parameter bit AUTO_ACK = 1'b0,
                    parameter int PIC_UPPER = 461, PIC_YEAR = 1997,  // set_upper / GAME year (MK4 461 / 1997, Invasion 468 / 1999)
                    parameter bit SHUFFLE_DEFAULT = 1'b1) (           // set_shuffle_default: MK4 1, Invasion 0 (midzeus.cpp:1417, 1422-1429)
  input  logic        clk, rst,
  input  logic        req, we, input logic [3:0] off, input logic [31:0] wdata,
  output logic [31:0] rdata,
  input  logic [15:0] in_port [4],                               // DIPS, SYSTEM, IN1, IN2 (active-low as MAME's ports)
  input  logic [7:0]  rtc [7],
  // DCS2
  input  logic [15:0] dcs_control, dcs_data, dcs_data2,
  input  logic        dcs_input_empty, dcs_output_full,          // callback levels (ioasic_input_empty / output_full)
  output logic        dcs_data_w, output logic [15:0] dcs_wdata, output logic dcs_ack_w, output logic dcs_data_r,
  output logic        dcs_reset_w, output logic dcs_reset_level,  // reset_w(state) on every SOUNDCTL write
  output logic        irq
);
  localparam int PORT0 = 0, UARTCTL = 4, UARTOUT = 5, UARTIN = 6, SOUNDCTL = 8, SOUNDOUT = 9, SOUNDSTAT = 10,
                 SOUNDIN = 11, PICOUT = 12, PICIN = 13, INTSTAT = 14, INTCTL = 15;
  logic [31:0] r [16];
  logic [7:0]  sound_irq;                                        // m_sound_irq_state (reset 0x80, :794)
  logic        pic_wr, pic_rd; logic [7:0] pic_wd; logic [15:0] pic_q;
  // m_shuffle_active (midwayic.cpp:785-793): reset to shuffle_default; a 0xE2 write to PORT0 unlocks it (:1147-1153).
  // While locked, PORT0 reads 0x2001 (:1017-1021) and register writes are not stored (:1137-1139); SHUFFLE_STANDARD's map
  // is the identity (:738), so the offset is the same either way. MK4 (default 1): always unlocked.
  logic shuffle_active;
  zk4_pic2 #(.CLK_HZ(CLK_HZ), .RAND12(RAND12), .RAND13(RAND13), .UPPER(PIC_UPPER), .YEAR(PIC_YEAR)) u_pic (.clk, .rst, .pic_wr, .pic_wdata(pic_wd),
    .pic_rd, .pic_rdata(pic_q), .rtc);

  // update_ioasic_irq (:803-826), evaluated continuously: INTSTAT and the irq level are pure functions of the state
  logic [15:0] intstat;
  always_comb begin
    intstat = 16'h2000 | {8'd0, sound_irq} | (r[UARTIN][15:0] & 16'h3f00) | 16'h0008;   // FIFO always empty on MK4
    intstat |= 16'h0001;                                          // irqbits != 0 always (0x2000 is set)
  end
  assign irq = r[INTCTL][0] && ((intstat & r[INTCTL][15:0] & 16'h3ffe) != 16'd0);

  // reads (:1007-1104); shuffle = identity on MK4
  always_comb begin
    rdata = r[off];
    case (off)
      4'd0: rdata = shuffle_active ? {16'd0, in_port[0]} : 32'h2001;   // m_input_cb[0]() / locked 0x2001
      4'd1: rdata = {16'd0, in_port[1]};
      4'd2: rdata = {16'd0, in_port[2]};
      4'd3: rdata = {16'd0, in_port[3]};
      4'd10: rdata = {16'd0, (dcs_data2 & 16'hff00) | (16'h0008 & 16'h0038) | (((dcs_control >> 4) ^ 16'h0040) & 16'h00c0)};
      4'd11: rdata = {16'd0, dcs_data};
      4'd13: rdata = {16'd0, pic_q};
      4'd14: rdata = {16'd0, intstat};
      default: ;
    endcase
  end
  assign pic_rd = req && !we && off == 4'(PICIN);
  assign pic_wr = req && we && off == 4'(PICOUT);
  assign pic_wd = wdata[7:0];                                     // SHUFFLE_STANDARD: no xor (:1222-1229)
  assign dcs_data_r = req && !we && off == 4'(SOUNDIN);
  assign dcs_data_w = req && we && off == 4'(SOUNDOUT);
  assign dcs_wdata  = wdata[15:0];
  assign dcs_ack_w  = (req && we && off == 4'(SOUNDIN)) || (AUTO_ACK && dcs_data_r);
  assign dcs_reset_w = req && we && off == 4'(SOUNDCTL);
  assign dcs_reset_level = wdata[0];

  always_ff @(posedge clk)
    if (rst) begin
      for (int i = 0; i < 16; i++) r[i] <= '0;
      r[SOUNDCTL] <= 32'h1;                                       // device_start :768
      sound_irq <= 8'h80;
      shuffle_active <= SHUFFLE_DEFAULT;                          // device_reset :793
    end else begin
      // DCS callbacks (ioasic_input_empty / output_full): levels -> sound IRQ state bits 7 / 6
      sound_irq[7] <= dcs_input_empty; sound_irq[6] <= dcs_output_full;
      if (req && !we && off == 4'(UARTIN)) begin                 // :1042-1053
        r[UARTIN] <= r[UARTIN] & ~32'h1000;
        if (r[UARTIN][7:0] == 8'h0d) r[UARTIN] <= 32'h300a;
      end
      if (req && we) begin
        if (shuffle_active) r[off] <= wdata;                      // COMBINE_DATA only while shuffling (always on MK4)
        case (off)
          4'd0: if (wdata == 32'he2) begin r[INTCTL] <= '0; r[UARTCTL] <= '0; shuffle_active <= 1'b1; end
          4'd5: if (r[UARTCTL][11]) r[UARTIN] <= {16'd0, 8'h30, wdata[7:0]};   // loopback (:1170-1175)
                else r[UARTIN] <= r[UARTIN] | 32'h2000;                          // tx: Tx EMPTY (:1179)
          default: ;
        endcase
      end
    end
endmodule
