#!/bin/bash
# Invasion board replay gate: zk4_board_io (I/O ASIC with set_upper 468 / 1999 / no shuffle default, PIC2 serial, CMOS,
# disk_asic_jr) vs MAME 0.289's own device log of a COLD invasnab boot (scripts/mk4_device_census.lua on invasnab, empty
# NVRAM, 3,600 frames; ROM-derived: H: only). 0x9C0000 (the gun, zk4_gun) is skipped. Exact mode: the DCS2 host-visible
# state comes from the log. Then two mutants MUST FAIL: V1 = MK4's PIC UPPER 461 (serial number), V2 = MK4's shuffle
# default 1 (PORT0 reads before the 0xE2 unlock).
# usage: wsl bash run_zk4_board_inv.sh [devices.log]      exit 0 only if the tree passes and both mutants fail
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/board
LOG=${1:-/mnt/h/temp/zeus/invasion/devcold/devices.log}
G="-GPIC_UPPER=468 -GPIC_YEAR=1999 -GSHUFFLE_DEFAULT=0"
ok=0
o=$(ZKB_G="$G" ZKB_SKIP_GUN=1 bash $S/run_zk4_board.sh "$LOG" exact 2>&1); echo "$o" | tail -16
echo "$o" | grep -q "^PASS" || ok=1
o=$(ZKB_G="-GPIC_UPPER=461 -GPIC_YEAR=1999 -GSHUFFLE_DEFAULT=0" ZKB_SKIP_GUN=1 bash $S/run_zk4_board.sh "$LOG" exact 2>&1)
echo "V1 (UPPER 461): $(echo "$o" | grep -E '^(PASS|FAIL)')"; echo "$o" | grep -q "^FAIL" || ok=1
o=$(ZKB_G="-GPIC_UPPER=468 -GPIC_YEAR=1999 -GSHUFFLE_DEFAULT=1" ZKB_SKIP_GUN=1 bash $S/run_zk4_board.sh "$LOG" exact 2>&1)
echo "V2 (shuffle default 1): $(echo "$o" | grep -E '^(PASS|FAIL)')"; echo "$o" | grep -q "^FAIL" || ok=1
echo "INVASION BOARD GATE: $([ $ok = 0 ] && echo PASS || echo FAIL)"
exit $ok
