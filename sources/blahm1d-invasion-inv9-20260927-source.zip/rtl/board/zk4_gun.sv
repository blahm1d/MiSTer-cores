// zk4_gun.sv -- Invasion: The Abductors (invasnab) two-player lightgun block at C32 0x9C0000. Invasion builds only
// (instantiated under `ZK4_GAME_INVASION in zk4_core); MK4 has no device here (unmapped, reads 0xFFFFFFFF).
//
// Transcribed from MAME 0.289 midzeus.cpp (invasnab_state):
//   map      invasnab_map (cpp:843-847): 0x9C0000 read = invasn_gun_r, write = invasn_gun_w (one 32-bit word)
//   write    invasn_gun_w (cpp:766-791): COMBINE_DATA(&m_gun_control) (full 32-bit mask on the C32 bus);
//            m_gun_irq_state &= ~((control >> 2) & 3); update_gun_irq(); then per player p a FALLING edge of control bit
//            2+p latches m_gun_x = (GUNX * 400 / 255 + min_x + BEAM_XOFFS + BEAM_DX * 2) % width, clamped to
//            [BEAM_DX, width - BEAM_DX], and m_gun_y = GUNY * 256 / 255 + min_y + BEAM_DY * 2, and arms that player's
//            beam timer at (max(0, gun_y - BEAM_DY), max(0, gun_x - BEAM_DX)).
//   timer    invasn_gun_callback (cpp:750-763): irq_state |= 1 << p; update_gun_irq(); re-arm on the next line at the
//            same x while that line <= visible max_y and <= gun_y + BEAM_DY.
//   irq      update_gun_irq (cpp:740-747): ASSERT IRQ3 when (irq_state & control & 3) != 0, else CLEAR. The C32 runs
//            Invasion in edge mode (ST.INTCONFIG = 1, invasion/MEASURE-20260925.md sec. 4): every ASSERT call sets IF
//            bit 3 (tms320c3x.cpp:942-956), the CLEAR calls do nothing -> irq3 here is a one-clock EVENT per ASSERT call.
//   read     invasn_gun_r (cpp:794-813): 0xFFFF ^ (TRIGGER << 8); per player with 0 < GUNX < 0xFF (0 / 0xFF = off-screen)
//            bit 12 + p flips when |hpos - gun_x| <= BEAM_DX and |vpos - gun_y| <= BEAM_DY.
//   constants BEAM_XOFFS 40, BEAM_DY 3, BEAM_DX 3 (cpp:48-50).
// Screen geometry = the game's own Zeus timing registers (midzeus_v.cpp:699-718 screen->configure from 0xC6/0xC8/0xCA):
// Invasion writes C6 = 0x0211007F (htotal 529, visible min_x 127, max_x = htotal - 3 = 526 -> width 400), C8 low = 255
// (max_y), CA = 0x01160107 (vtotal 278) -- the same fixed raster zr_scanout produces (beam_h / beam_v = MAME hpos / vpos).
// ASSUMPTION (flagged): the geometry is constant after boot (MEASURE-20260925.md sec. 3, "Beam geometry"); a game write
// that changed it would move MAME's gun mapping, not ours.
//
// Timer realisation: MAME schedules a timer at time_until_pos(y, x) = the START of pixel (y, x); a position at or less than
// half a pixel ahead of "now" goes to the next frame (emu/screen.cpp time_until_pos). Here each armed timer is a (ty, tx)
// comparator that fires on the clock the scanout counters CHANGE to (ty, tx) -- the start of that pixel -- so an arm made
// inside the target pixel waits a frame, like MAME.
// FIRE_EARLY: the comparator fires FIRE_EARLY pixels before MAME's pixel (borrowing into the previous line when
// gun_x - BEAM_DX < FIRE_EARLY). The latched gun_x / gun_y and the in-range read are unchanged (MAME's values). The
// cabinet builds use 0: a constant offset cannot absorb our CPU's VARIABLE latency (measured in the zci bench: 62 core
// clocks = 10 px on a page-cache hit, 583-846 clocks = 97-141 px on a miss, vs MAME's fixed 5-6 px) -- see VBEAM.
// VBEAM (work item 4, the fit-driven alternative that holds MAME's behaviour): MAME's C32 (60 MHz, zero-wait RAM) reads
// hpos / vpos in the IRQ3 handler 5-6 pixels after the timer (MEASURE-20260925 sec. 3). From each timer fire until the
// handler's gun acknowledge (a write with bit 2 or 3 set) the block serves a VIRTUAL beam = the timer's pixel advanced by
// the CPU's own GUEST time (retire_cyc = MAME H1 cycles at 30 MHz; 1 cycle = 5/18 pixel at 66.667 MHz / 8), so the
// handler's hpos / vpos reads (zr_host1, through zk4_core) and the gun's in-range bits see what MAME's CPU saw, whatever
// our fabric CPU's page-cache latency. Gated in zci against MAME's own reads (core/run_zci.sh).
// VBEAM_BIAS = 1 pixel: the guest cycles counted from the fire are exactly MAME's H1 cycles from the boundary where the
// fire is seen to the start of the reading instruction (zci: 17 = 17 on every event), but MAME's timer lands INSIDE the
// interrupted instruction and the access sits inside the reading one; that sub-instruction phase is not a function of
// the instruction path (MAME reads +5 and +6 px after identical 17-cycle paths). +1 px is its measured centre; the zci
// gate bounds the residual at 1 pixel, the phase itself.
module zk4_gun #(
  parameter int VIS_MIN_X = 127, VIS_W = 400, VIS_MIN_Y = 0, VIS_MAX_Y = 255, SCR_W = 529, SCR_H = 278,
  parameter int BEAM_XOFFS = 40, BEAM_DX = 3, BEAM_DY = 3,
  parameter int FIRE_EARLY = 0,
  parameter bit VBEAM = 1'b1, parameter int VBEAM_BIAS = 1     // virtual beam on; +1 px = MAME's fire-to-boundary + access phase (see below)
) (
  input  logic        clk, rst,
  // C32 access to 0x9C0000 (one-clock request; rvalid + rdata the next clock, like zk4_board_io)
  input  logic        req, we, input logic [31:0] wdata,
  output logic        rvalid, output logic [31:0] rdata,
  output logic [31:0] rd_now,                                    // the value a read in this clock returns (benches)
  // the scanout's raw counters (MAME hpos / vpos)
  input  logic [9:0]  beam_h, input logic [8:0] beam_v,
  // MAME ports GUNX1/GUNY1/GUNX2/GUNY2 (0..0xFF) and TRIGGER (bit p = player p, active high)
  input  logic [7:0]  gun_xin [2], input logic [7:0] gun_yin [2], input logic [1:0] trigger,
  output logic        irq3,                                      // one-clock IRQ3 ASSERT event
  // virtual beam (VBEAM): the CPU's retire strobe + guest cycles of the retired instruction; the beam a Zeus hpos /
  // vpos read should return while vactive
  input  logic        retire, input logic [31:0] retire_cyc,
  output logic        vactive, output logic [9:0] vbeam_h, output logic [8:0] vbeam_v,
  // observability
  output logic [9:0]  gun_x [2], output logic [8:0] gun_y [2], output logic [1:0] armed, output logic [1:0] irq_state,
  output logic [3:0]  control
);
  // ---- m_gun_x / m_gun_y from the ports (cpp:784-786) ----
  // GUNX * 400 / 255 == (GUNX * 25701) >> 14 for every GUNX in 0..255 (exhaustively checked); GUNY * 256 / 255 = GUNY
  // for GUNY < 255 and 256 at 255.
  function automatic [9:0] map_x(input [7:0] x);
    logic [22:0] p; logic [9:0] s;
    p = {15'd0, x} * 23'd25701;
    s = {1'b0, p[22:14]} + 10'(VIS_MIN_X + BEAM_XOFFS + BEAM_DX * 2);
    if (s >= 10'(SCR_W)) s = s - 10'(SCR_W);                     // % width (s < 2 * width)
    if (s < 10'(BEAM_DX)) s = 10'(BEAM_DX);                       // std::clamp(x, BEAM_DX, width - BEAM_DX)
    else if (s > 10'(SCR_W - BEAM_DX)) s = 10'(SCR_W - BEAM_DX);
    map_x = s;
  endfunction
  function automatic [8:0] map_y(input [7:0] y);
    map_y = 9'(y) + ((y == 8'hFF) ? 9'd1 : 9'd0) + 9'(VIS_MIN_Y + BEAM_DY * 2);
  endfunction
  // the comparator position for MAME timer pixel (ty, tx): FIRE_EARLY pixels earlier in raster order
  function automatic [18:0] fire_pos(input [8:0] ty, input [9:0] tx);
    logic [8:0] y; logic [10:0] x;
    y = ty; x = {1'b0, tx};
    if (x < 11'(FIRE_EARLY)) begin
      x = x + 11'(SCR_W) - 11'(FIRE_EARLY);
      y = (y == 9'd0) ? 9'(SCR_H - 1) : y - 9'd1;
    end else x = x - 11'(FIRE_EARLY);
    fire_pos = {y, x[9:0]};
  endfunction

  logic [9:0] tx [2]; logic [8:0] ty [2];                        // MAME timer pixel (ty = the timer's line)
  logic [9:0] fx [2]; logic [8:0] fy [2];                        // comparator pixel (tx / ty shifted by FIRE_EARLY)
  logic [9:0] h_q; logic [8:0] v_q;
  logic moved; assign moved = (beam_h != h_q) || (beam_v != v_q);
  logic [1:0] hit;
  always_comb for (int p = 0; p < 2; p++) hit[p] = armed[p] && moved && beam_h == fx[p] && beam_v == fy[p];

  // ---- virtual beam (VBEAM): timer pixel + floor(guest cycles * 5 / 18) (+ VBEAM_BIAS) ----
  // floor(c * 5 / 18) == (c * 18205) >> 16 for every c < 4096 (exhaustively checked); c is capped at VCAP (the handler
  // reads within ~40 cycles), so the virtual beam is at most one line past the timer's.
  localparam int VCAP = 1800;
  logic [11:0] vcyc; logic [9:0] vh0; logic [8:0] vv0;
  logic [26:0] vpxp; assign vpxp = {15'd0, vcyc} * 27'd18205;
  logic [10:0] vhs;  assign vhs = {1'b0, vh0} + vpxp[26:16] + 11'(VBEAM_BIAS);
  assign vbeam_h = (vhs >= 11'(SCR_W)) ? 10'(vhs - 11'(SCR_W)) : vhs[9:0];
  assign vbeam_v = (vhs >= 11'(SCR_W)) ? ((vv0 == 9'(SCR_H - 1)) ? 9'd0 : vv0 + 9'd1) : vv0;
  logic [9:0] rbh; logic [8:0] rbv;                               // the beam a read sees
  assign rbh = (VBEAM && vactive) ? vbeam_h : beam_h;
  assign rbv = (VBEAM && vactive) ? vbeam_v : beam_v;

  // ---- read value (cpp:794-813) ----
  logic signed [11:0] rdx [2], rdy [2];                         // beam - gun position (no latch: always assigned)
  always_comb
    for (int p = 0; p < 2; p++) begin
      rdx[p] = $signed({2'b0, rbh}) - $signed({2'b0, gun_x[p]});
      rdy[p] = $signed({3'b0, rbv}) - $signed({3'b0, gun_y[p]});
    end
  always_comb begin
    rd_now = 32'h0000FFFF ^ {22'd0, trigger, 8'd0};
    for (int p = 0; p < 2; p++)
      if (gun_xin[p] != 8'h00 && gun_xin[p] != 8'hFF &&
          rdx[p] >= -12'sd3 && rdx[p] <= 12'sd3 && rdy[p] >= -12'sd3 && rdy[p] <= 12'sd3) rd_now[12 + p] = ~rd_now[12 + p];
  end

  logic wr; assign wr = req && we;
  logic [3:0] c_new; assign c_new = wdata[3:0];                  // bits 4-31 are stored by MAME but never used
  always_ff @(posedge clk)
    if (rst) begin
      control <= 4'd0; irq_state <= 2'd0; armed <= 2'd0; irq3 <= 1'b0; rvalid <= 1'b0; rdata <= 32'd0;
      h_q <= '0; v_q <= '0; vactive <= 1'b0; vcyc <= '0; vh0 <= '0; vv0 <= '0;
      for (int p = 0; p < 2; p++) begin gun_x[p] <= '0; gun_y[p] <= '0; tx[p] <= '0; ty[p] <= '0; fx[p] <= '0; fy[p] <= '0; end
    end else begin : run
      logic [1:0] st; logic [3:0] ctl; logic ev;
      h_q <= beam_h; v_q <= beam_v;
      rvalid <= req && !we;
      if (req && !we) rdata <= rd_now;
      st = irq_state; ctl = control; ev = 1'b0;
      // write: control, clear, update_gun_irq, then the falling-edge latches (cpp:768-790)
      if (wr) begin
        ctl = c_new;
        st = st & ~c_new[3:2];
        if ((st & ctl[1:0]) != 2'd0) ev = 1'b1;
        for (int p = 0; p < 2; p++)
          if (control[2 + p] && !c_new[2 + p]) begin : latch
            logic [9:0] gx; logic [8:0] gy; logic [18:0] f;
            gx = map_x(gun_xin[p]); gy = map_y(gun_yin[p]);
            gun_x[p] <= gx; gun_y[p] <= gy;
            ty[p] <= (gy > 9'(BEAM_DY)) ? gy - 9'(BEAM_DY) : 9'd0;
            tx[p] <= (gx > 10'(BEAM_DX)) ? gx - 10'(BEAM_DX) : 10'd0;
            f = fire_pos((gy > 9'(BEAM_DY)) ? gy - 9'(BEAM_DY) : 9'd0, (gx > 10'(BEAM_DX)) ? gx - 10'(BEAM_DX) : 10'd0);
            fy[p] <= f[18:10]; fx[p] <= f[9:0];
            armed[p] <= 1'b1;
          end
      end
      // timer callbacks (cpp:750-763): state, update_gun_irq, next-line re-arm or stop
      for (int p = 0; p < 2; p++)
        if (hit[p] && !(wr && control[2 + p] && !c_new[2 + p])) begin : fire
          logic [8:0] ny; logic [18:0] f;
          st[p] = 1'b1;
          if ((st & ctl[1:0]) != 2'd0) ev = 1'b1;
          ny = ty[p] + 9'd1;                                       // beamy = the timer's own line (vpos at the callback)
          if (ny <= 9'(VIS_MAX_Y) && ny <= gun_y[p] + 9'(BEAM_DY)) begin
            ty[p] <= ny;
            f = fire_pos(ny, tx[p]); fy[p] <= f[18:10]; fx[p] <= f[9:0];
          end else armed[p] <= 1'b0;
        end
      control <= ctl; irq_state <= st; irq3 <= ev;
      // virtual beam: (re)start at every timer fire, advance by retired guest cycles, end at the handler's acknowledge
      // (a gun write with bit 2 or 3 set) or after VCAP cycles
      if (VBEAM && hit != 2'b00) begin
        vactive <= 1'b1; vcyc <= '0;
        if (hit[1]) begin vh0 <= tx[1]; vv0 <= ty[1]; end else begin vh0 <= tx[0]; vv0 <= ty[0]; end
      end else begin : vadv
        logic [12:0] vs;
        vs = {1'b0, vcyc} + ((retire_cyc > 32'(VCAP)) ? 13'(VCAP) : retire_cyc[12:0]);
        if (vactive && retire) vcyc <= (vs >= 13'(VCAP)) ? 12'(VCAP) : vs[11:0];
        if ((wr && c_new[3:2] != 2'd0) || vcyc >= 12'(VCAP)) vactive <= 1'b0;
      end
    end
endmodule
