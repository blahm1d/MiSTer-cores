// zk4_board_bench.sv -- tb_zk4_board's DUT: zk4_board_io plus the DCS2 side, either
//   USE_STUB = 1: the DCS2 stand-in wired as the core top wires it (protocol run), or
//   USE_STUB = 0: the DCS2 state driven by the bench from MAME's log (exact run: the I/O ASIC formatting under test).
module zk4_board_bench #(parameter logic [7:0] RAND12 = 8'h00, RAND13 = 8'h00, parameter bit USE_STUB = 1'b1,
                         parameter int PIC_UPPER = 461, PIC_YEAR = 1997, parameter bit SHUFFLE_DEFAULT = 1'b1) (
  input  logic        clk, rst,
  input  logic        req, we, input logic [23:0] addr, input logic [31:0] wdata,
  output logic        rvalid, output logic [31:0] rdata,
  input  logic [15:0] in_port [4],
  input  logic [7:0]  rtc [7],
  // log-driven DCS2 state (USE_STUB = 0)
  input  logic [15:0] tb_dcs_control, tb_dcs_data, tb_dcs_data2, input logic tb_dcs_input_empty, tb_dcs_output_full
);
  logic [15:0] dcs_control, dcs_data, dcs_data2, dcs_wdata; logic dcs_input_empty, dcs_output_full;
  logic dcs_data_w, dcs_ack_w, dcs_data_r, dcs_reset_w, dcs_reset_level, ioasic_irq;
  zk4_board_io #(.RAND12(RAND12), .RAND13(RAND13), .PIC_UPPER(PIC_UPPER), .PIC_YEAR(PIC_YEAR),
    .SHUFFLE_DEFAULT(SHUFFLE_DEFAULT)) u_b (.clk, .rst, .req, .we, .addr, .wdata, .rvalid, .rdata, .in_port,
    .rtc, .dcs_control, .dcs_data, .dcs_data2, .dcs_input_empty, .dcs_output_full, .dcs_data_w, .dcs_wdata, .dcs_ack_w,
    .dcs_data_r, .dcs_reset_w, .dcs_reset_level, .ioasic_irq, .h_we(1'b0), .h_row(14'd0), .h_d(16'd0), .h_q());
  logic [15:0] s_control, s_data, s_data2; logic s_in_empty, s_out_full;
  zk4_dcs_stub u_d (.clk, .rst, .data_w(dcs_data_w), .wdata(dcs_wdata), .ack_w(dcs_ack_w), .data_r(dcs_data_r),
    .reset_w(dcs_reset_w), .reset_level(dcs_reset_level), .control(s_control), .data(s_data), .data2(s_data2),
    .input_empty(s_in_empty), .output_full(s_out_full));
  assign dcs_control     = USE_STUB ? s_control  : tb_dcs_control;
  assign dcs_data        = USE_STUB ? s_data     : tb_dcs_data;
  assign dcs_data2       = USE_STUB ? s_data2    : tb_dcs_data2;
  assign dcs_input_empty = USE_STUB ? s_in_empty : tb_dcs_input_empty;
  assign dcs_output_full = USE_STUB ? s_out_full : tb_dcs_output_full;
endmodule
