#!/usr/bin/env bash
# zk4_gun unit gate (iverilog, WSL): the RTL vs gun_golden.py (MAME 0.289 midzeus.cpp:740-813 transcribed independently),
# 6 seeds x N stimulus events at FIRE_EARLY 0 (MAME parity) + 2 seeds at FIRE_EARLY 7 (the calibrated comparator).
# usage: run_zk4_gun.sh [tag] [extra iverilog defines, e.g. -DMUT_...]      verdict = exit code
set -u
G=/mnt/d/deck/fpga/zeus/zeus1/rtl/board/gun; R=/mnt/d/deck/fpga/zeus/zeus1/rtl/board
TAG="${1:-tree}"; DEF="${2:-}"; N=${GUN_N:-6000}
S=/mnt/h/temp/zeus/invasion/gun_$TAG; mkdir -p $S
rc=0
for fe in 0 7; do
  iverilog -g2012 -DFE=$fe $DEF -o $S/tb$fe.vvp -s tb_zk4_gun $G/tb_zk4_gun.sv $R/zk4_gun.sv > $S/iv$fe.log 2>&1 || { head -20 $S/iv$fe.log; echo "GUN UNIT GATE BUILD FAIL"; exit 2; }
  seeds="1 2 3 4 5 6"; [ $fe != 0 ] && seeds="7 8"
  for seed in $seeds; do
    python3 $G/gun_golden.py gen $S/stim$seed.txt $S/exp$seed.txt $N $seed $fe > $S/gen$seed.log || exit 2
    timeout 900 vvp -n $S/tb$fe.vvp +stim=$S/stim$seed.txt +out=$S/rtl$seed.txt > $S/vvp$seed.log 2>&1 || { tail -3 $S/vvp$seed.log; rc=1; continue; }
    grep -q FAIL $S/vvp$seed.log && { echo "seed $seed: $(grep FAIL $S/vvp$seed.log | head -1)"; rc=1; continue; }
    echo -n "FE $fe seed $seed ($(cat $S/gen$seed.log | sed 's/gen: //')): "; python3 $G/gun_golden.py check $S/exp$seed.txt $S/rtl$seed.txt || rc=1
  done
done
[ $rc -eq 0 ] && echo "GUN UNIT GATE PASS [$TAG]" || echo "GUN UNIT GATE FAIL [$TAG]"
exit $rc
