// tb_zk4_gun.sv -- zk4_gun unit bench (iverilog): replays gun_golden.py's stimulus clock by clock against a raster of
// 529 x 278 pixels at 2 clocks per pixel (the model counts 6; stimulus sits at phase 1) (pixel 0 = vpos 256, hpos 0 = a vblank start, like the model) and logs
//   E <pixel>        every clock irq3 is high (pixel of the clock that raised it)
//   R <pixel> <hex>  every read (rd_now in the request clock; rvalid / rdata checked to carry it the next clock)
// usage: vvp tb.vvp +stim=<file> +out=<file>      (-DFE=<n> sets FIRE_EARLY)
`timescale 1ns/1ps
module tb_zk4_gun;
`ifndef FE
  `define FE 0
`endif
  logic clk = 0, rst = 1;
  logic req = 0, we = 0; logic [31:0] wdata = 0;
  logic rvalid; logic [31:0] rdata, rd_now;
  logic [9:0] beam_h; logic [8:0] beam_v;
  logic [7:0] gx [2], gy [2]; logic [1:0] trig = 0;
  logic irq3;
  logic [9:0] o_gx [2]; logic [8:0] o_gy [2]; logic [1:0] o_armed, o_st; logic [3:0] o_ctl;
  zk4_gun #(.FIRE_EARLY(`FE), .VBEAM(1'b0)) dut (.clk, .rst, .req, .we, .wdata, .rvalid, .rdata, .rd_now, .beam_h, .beam_v,
    .retire(1'b0), .retire_cyc(32'd0), .vactive(), .vbeam_h(), .vbeam_v(),
    .gun_xin(gx), .gun_yin(gy), .trigger(trig), .irq3, .gun_x(o_gx), .gun_y(o_gy), .armed(o_armed), .irq_state(o_st),
    .control(o_ctl));
  always #5 clk = ~clk;
  longint unsigned cyc;                                          // bench clock since reset release
  longint unsigned pix; assign pix = cyc / 2;                   // 2 bench clocks per pixel (the gun only sees beam changes)
  // raster: pixel n -> vpos (256 + n / 529) % 278, hpos n % 529
  assign beam_h = 10'(pix % 529);
  assign beam_v = 9'((256 + (pix / 529)) % 278);
  integer fs, fo, n; longint unsigned sclk; byte kind; logic [31:0] a, b; string sf, of;
  logic rd_pend; logic [31:0] rd_exp;
  initial begin
    gx[0] = 8'h80; gx[1] = 8'h80; gy[0] = 8'h80; gy[1] = 8'h80;
    if (!$value$plusargs("stim=%s", sf) || !$value$plusargs("out=%s", of)) begin $display("usage"); $finish; end
    fs = $fopen(sf, "r"); fo = $fopen(of, "w");
    cyc = 0; rd_pend = 0;
    repeat (3) @(posedge clk); #1 rst = 0;
    forever begin
      n = $fscanf(fs, "%d %c %h %h\n", sclk, kind, a, b);
      if (n != 4) begin $display("stim parse error"); $finish; end
      // run clocks up to the stimulus clock, logging events
      if (kind != "Z" && sclk % 6 != 1) begin $display("FAIL: stimulus not at pixel phase 1/6"); $finish; end
      while (cyc < (sclk / 6) * 2 + 1) begin : ffw
        // fast-forward: with no timer armed and irq3 low the gun has nothing to see between two stimuli (a beam jump
        // raises `moved` but hits need `armed`), so skip to just before the next one
        // with a timer armed: skip to 2 pixels before the nearest comparator pixel
        longint unsigned lim, d, fr, cur; #1; lim = (sclk / 6) * 2 + 1 - 4; fr = 529 * 278; cur = pix % fr;
        for (int p = 0; p < 2; p++) if (o_armed[p]) begin
          d = ((((longint'(dut.fy[p]) + 278 - 256) % 278) * 529 + longint'(dut.fx[p])) + fr - cur) % fr;
          if (d < 3) lim = 0; else if (cyc + (d - 2) * 2 < lim) lim = cyc + (d - 2) * 2;
        end
`ifndef NOFF
        if (!irq3 && !rd_pend && lim > cyc + 8) cyc = lim;
`endif
        tick();
      end             // model clock (6 per pixel, phase 1) -> bench clock (2 per pixel, phase 1)
      if (kind == "Z") begin $fclose(fo); $display("TB DONE at clock %0d", cyc); $finish; end
      case (kind)
        "W": begin req = 1; we = 1; wdata = a; end
        "R": begin req = 1; we = 0; end
        "X": gx[a[0]] = b[7:0];
        "Y": gy[a[0]] = b[7:0];
        "T": trig = a[1:0];
        default: begin $display("bad kind %c", kind); $finish; end
      endcase
      tick();
      req = 0; we = 0;
    end
  end
  task automatic tick();
    #1;                                                          // after the NBAs of the last edge (inputs settled)
    if (irq3) $fwrite(fo, "E %0d\n", (cyc - 1) / 2);
    if (rd_pend) begin
      if (!rvalid || rdata !== rd_exp) begin $display("FAIL: rvalid/rdata %b %h vs rd_now %h", rvalid, rdata, rd_exp); $finish; end
      rd_pend = 0;
    end
    if (req && !we) begin $fwrite(fo, "R %0d %04X\n", pix, rd_now[15:0]); rd_pend = 1; rd_exp = rd_now;
      if (rd_now[31:16] !== 16'h0) begin $display("FAIL: read high half %h", rd_now); $finish; end end
    @(posedge clk); cyc = cyc + 1;
  endtask
endmodule
