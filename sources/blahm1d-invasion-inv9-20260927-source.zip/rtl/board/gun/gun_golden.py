"""Invasion lightgun golden model (MAME 0.289 midzeus.cpp invasnab_state, cpp:740-813) for the zk4_gun unit gate.

Written from the MAME source, independently of rtl/board/zk4_gun.sv. Time is in PIXELS (MAME attotime / pixeltime) from a
vblank start (vpos 256, hpos 0); the Invasion raster is htotal 529 x vtotal 278, visible 400 x 256 from hpos 127
(midzeus_v.cpp:699-718 screen->configure from Zeus 0xC6 = 0x0211007F, 0xC8 max_y 255, 0xCA vtotal 278).
  screen vpos(t) = (256 + floor(t) // 529) % 278      screen hpos(t) = floor(t) % 529        (emu/screen.cpp vpos/hpos)
  time_until_pos(y, x) from now: target = ((y + 278 - 256) % 278) * 529 + x (+ k frames) = the START of that pixel;
  "if targetdelta <= curdelta + pixeltime / 2, head to the next frame".
Stimulus events carry fractional pixel times (a CPU access lands inside a pixel). Output lines:
  E <pixel>        an IRQ3 ASSERT call (update_gun_irq with a non-zero mask), at floor(time)
  R <pixel> <hex>  a read of 0x9C0000 and its value
usage: gun_golden.py gen <stim.txt> <exp.txt> <n_events> <seed> [fire_early]
       gun_golden.py check <exp.txt> <rtl.txt>
stim line: <clock> <kind> <a> <b>   kind W (a = data), R, X (a = player, b = value), Y, T (a = trigger bits); the clock is
the RTL bench clock (6 clocks per pixel, the access sits at pixel phase 1 of 6 = time pixel + 1/6).
fire_early: the RTL comparator fires that many pixels before MAME's pixel; E lines from timer callbacks move by it.
"""
import random, sys

HT, VT, MIN_X, VW, MAX_Y = 529, 278, 127, 400, 255
BEAM_XOFFS, BEAM_DY, BEAM_DX = 40, 3, 3
FRAME = HT * VT
CE = 6


def vpos(t): return (256 + int(t) // HT) % VT
def hpos(t): return int(t) % HT


FE = 0


def until_pos(now, y, x):
    # with FE > 0 the RTL comparator sits FE pixels earlier, and the next-frame decision is made on that position
    y = (y + VT - (MAX_Y + 1)) % VT
    tgt = (int(now) // FRAME - 1) * FRAME + y * HT + x
    while tgt - FE <= now + 0.5:       # "within 1/2 of a pixel" -> next frame
        tgt += FRAME
    return tgt


class Gun:
    def __init__(s):
        s.control = 0; s.irq = 0; s.gx = [0, 0]; s.gy = [0, 0]; s.timer = [None, None]
        s.inx = [0x80, 0x80]; s.iny = [0x80, 0x80]; s.trig = 0; s.out = []; s.fe = 0

    def update(s, t):                   # update_gun_irq: only ASSERT calls are events (edge-mode C32)
        if s.irq & s.control & 3:
            s.out.append(("E", int(t)))

    def fire(s, p, t):                  # invasn_gun_callback
        beamy = vpos(t)
        s.irq |= 1 << p
        s.update(t - s.fe)
        s.timer[p] = None
        beamy += 1
        if beamy <= MAX_Y and beamy <= s.gy[p] + BEAM_DY:
            s.timer[p] = until_pos(t, beamy, max(0, s.gx[p] - BEAM_DX))

    def run_to(s, t):
        while True:
            c = [(s.timer[p], p) for p in (0, 1) if s.timer[p] is not None and s.timer[p] - s.fe <= t]
            if not c:
                return
            tt, p = min(c)
            s.fire(p, tt)

    def write(s, t, d):                 # invasn_gun_w
        old = s.control
        s.control = d & 0xFFFFFFFF
        s.irq &= ~((s.control >> 2) & 3)
        s.update(t)
        for p in (0, 1):
            m = 0x04 << p
            if ((old ^ s.control) & m) and not (s.control & m):
                x = (s.inx[p] * VW // 0xFF + MIN_X + BEAM_XOFFS + BEAM_DX * 2) % HT
                s.gx[p] = min(max(x, BEAM_DX), HT - BEAM_DX)
                s.gy[p] = s.iny[p] * 256 // 0xFF + 0 + BEAM_DY * 2
                s.timer[p] = until_pos(t, max(0, s.gy[p] - BEAM_DY), max(0, s.gx[p] - BEAM_DX))

    def read(s, t):                     # invasn_gun_r
        r = 0xFFFF ^ (s.trig << 8)
        bx, by = hpos(t), vpos(t)
        for p in (0, 1):
            if 0 < s.inx[p] < 0xFF:
                dx, dy = bx - s.gx[p], by - s.gy[p]
                if -BEAM_DX <= dx <= BEAM_DX and -BEAM_DY <= dy <= BEAM_DY:
                    r ^= 0x1000 << p
        s.out.append(("R", int(t), r))


XS = [0x00, 0x01, 0x02, 0x50, 0x80, 0xE2, 0xE3, 0xE4, 0xFE, 0xFF]
YS = [0x00, 0x01, 0x30, 0x80, 0xF9, 0xFC, 0xFD, 0xFE, 0xFF]


def gen(stim, exp, n, seed, fe):
    rnd = random.Random(seed)
    global FE
    FE = fe
    g = Gun(); g.fe = fe
    clk = 13                            # every stimulus sits at pixel phase 1 of 6
    lines = []
    frame_clk = FRAME * CE
    # the game's pattern (MEASURE sec. 3) mixed with random control values, input changes and reads
    def emit(c, k, a, b):
        lines.append((c, k, a, b))
        t = (c // CE) + (c % CE) / CE
        g.run_to(t)
        if k == "W": g.write(t, a)
        elif k == "R": g.read(t)
        elif k == "X": g.inx[a] = b
        elif k == "Y": g.iny[a] = b
        elif k == "T": g.trig = a
    while len(lines) < n:
        r = rnd.random()
        pend = [g.timer[p] - fe for p in (0, 1) if g.timer[p] is not None]
        if r < 0.10:
            clk = (clk // frame_clk + 1) * frame_clk + rnd.randrange(0, 40) * CE + 1  # next vblank: the INT0 latch pair
            emit(clk, "W", 0x0F, 0); clk += CE * rnd.randrange(1, 3)
            emit(clk, "W", 0x03, 0); clk += CE * rnd.randrange(1, 4)
            continue
        if r < 0.28 and pend:
            # the game's IRQ3 handler: read the gun a few pixels after the beam timer, then ack (0x07 / 0x0B, 0x03)
            c = int(min(pend) + rnd.randrange(-4, 9)) * CE + 1
            if c > clk:
                clk = c; emit(clk, "R", 0, 0)
                if rnd.random() < 0.7:
                    clk += CE * rnd.randrange(1, 3); emit(clk, "W", rnd.choice([0x07, 0x0B]), 0)
                    clk += CE; emit(clk, "W", 0x03, 0)
                continue
        step = rnd.choice([1, 1, 2, 3, 5, 17, 60, 300, 529, 1500, 9000])
        clk += step * CE
        if r < 0.40:
            emit(clk, "R", 0, 0)
        elif r < 0.52:
            emit(clk, "W", rnd.choice([0x07, 0x0B, 0x03, 0x0F, 0x00, 0x01, 0x02, 0x04, 0x08, 0x0C,
                                          rnd.randrange(16), rnd.randrange(1 << 32)]), 0)
        elif r < 0.66:
            emit(clk, "X", rnd.randrange(2), rnd.choice(XS + [rnd.randrange(256)]))
        elif r < 0.80:
            emit(clk, "Y", rnd.randrange(2), rnd.choice(YS + [rnd.randrange(256)]))
        elif r < 0.85:
            emit(clk, "T", rnd.randrange(4), 0)
        else:
            emit(clk, "R", 0, 0)
    end = clk + 2 * frame_clk
    with open(stim, "w") as f:
        for c, k, a, b in lines:
            f.write(f"{c} {k} {a:X} {b:X}\n")
        f.write(f"{end} Z 0 0\n")
    g.run_to(end // CE)
    with open(exp, "w") as f:
        for o in g.out:
            f.write(("E %d\n" % o[1]) if o[0] == "E" else ("R %d %04X\n" % (o[1], o[2])))
    ne = sum(1 for o in g.out if o[0] == "E"); nr = len(g.out) - ne
    nin = sum(1 for o in g.out if o[0] == "R" and (o[2] & 0x3000) != 0x3000)
    print(f"gen: {len(lines)} events, {ne} IRQ3 asserts, {nr} reads ({nin} with a gun in range)")


def dedup(v):
    # two ASSERT calls in the same pixel (both players' timers on one pixel, or a timer and a write) set the same IF
    # bit once: the C32 cannot tell them apart, and the RTL raises one event. Collapse repeats of the same E line.
    o = []
    for x in v:
        if not (o and x[0] == "E" and o[-1] == x):
            o.append(x)
    return o


def check(exp, rtl):
    a = dedup([l.upper().split() for l in open(exp) if l.strip()])
    b = dedup([l.upper().split() for l in open(rtl) if l.strip()])
    for i in range(max(len(a), len(b))):
        x = a[i] if i < len(a) else None; y = b[i] if i < len(b) else None
        if x != y:
            print(f"MISMATCH at output {i}: MAME {' '.join(x) if x else 'END'} RTL {' '.join(y) if y else 'END'}")
            return 1
    ne = sum(1 for l in a if l[0] == "E")
    print(f"PASS {len(a)} outputs ({ne} IRQ3 asserts, {len(a) - ne} reads)")
    return 0


if __name__ == "__main__":
    if sys.argv[1] == "gen":
        gen(sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]) if len(sys.argv) > 6 else 0)
    else:
        sys.exit(check(sys.argv[2], sys.argv[3]))
