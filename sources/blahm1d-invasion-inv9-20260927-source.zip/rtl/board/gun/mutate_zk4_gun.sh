#!/usr/bin/env bash
# zk4_gun mutation check: each mutant misreads MAME midzeus.cpp:740-813 on purpose; run_zk4_gun.sh MUST FAIL on every one.
# A mutant whose sed does not change the file is reported NOT-APPLIED (never counted as killed).
set -u
G=/mnt/d/deck/fpga/zeus/zeus1/rtl/board/gun; R=/mnt/d/deck/fpga/zeus/zeus1/rtl/board
W=/mnt/h/temp/zeus/invasion/gun_mut; mkdir -p $W
M=(
 "G1 latch-on-rising-edge|s/if (control\[2 + p\] \&\& !c_new\[2 + p\]) begin : latch/if (!control[2 + p] \&\& c_new[2 + p]) begin : latch/"
 "G2 BEAM_DY-bound-exclusive|s/ny <= gun_y\[p\] + 9'(BEAM_DY)/ny < gun_y[p] + 9'(BEAM_DY)/"
 "G3 no-next-line-rearm|s/if (ny <= 9'(VIS_MAX_Y) \&\&/if (1'b0 \&\&/"
 "G4 in-range-dx-2|s/rdx\[p\] >= -12'sd3 \&\& rdx\[p\] <= 12'sd3/rdx[p] >= -12'sd2 \&\& rdx[p] <= 12'sd2/"
 "G5 triggers-swapped|s/{22'd0, trigger, 8'd0}/{22'd0, trigger[0], trigger[1], 8'd0}/"
 "G6 enable-mask-ignored|s/if ((st \& ctl\[1:0\]) != 2'd0) ev = 1'b1;/if (st != 2'd0) ev = 1'b1;/g"
 "G7 x-offset-without-2DX|s/VIS_MIN_X + BEAM_XOFFS + BEAM_DX \* 2/VIS_MIN_X + BEAM_XOFFS/"
 "G8 y255-not-256|s/((y == 8'hFF) ? 9'd1 : 9'd0)/9'd0/"
 "G9 no-width-wrap|s/if (s >= 10'(SCR_W)) s = s - 10'(SCR_W);//"
 "G10 write-does-not-clear|s/st = st \& ~c_new\[3:2\];/st = st;/"
 "G11 offscreen-test-dropped|s/gun_xin\[p\] != 8'h00 \&\& gun_xin\[p\] != 8'hFF/1'b1/"
 "G12 max_y-cutoff-plus3|s/ny <= 9'(VIS_MAX_Y) \&\&/ny <= 9'(VIS_MAX_Y + 3) \&\&/"
 "G13 fire-early-no-line-borrow|s/y = (y == 9'd0) ? 9'(SCR_H - 1) : y - 9'd1;/y = y;/"
)
killed=0; total=0; bad=0
for m in "${M[@]}"; do
  name="${m%%|*}"; expr="${m#*|}"; total=$((total+1))
  cp $R/zk4_gun.sv $W/zk4_gun.sv; sed -i "$expr" $W/zk4_gun.sv
  if cmp -s $R/zk4_gun.sv $W/zk4_gun.sv; then echo "$name NOT-APPLIED"; bad=1; continue; fi
  # run the gate on the mutant copy (the gate reads zk4_gun.sv from R: point it at W)
  out=$(sed "s#; R=$R\$#; R=$W#" $G/run_zk4_gun.sh | GUN_N=${GUN_N:-6000} bash -s "mut_${name%% *}" 2>&1 | tail -1)
  if echo "$out" | grep -q "GATE FAIL"; then echo "$name KILLED"; killed=$((killed+1)); else echo "$name SURVIVED ($out)"; bad=1; fi
done
echo "zk4_gun mutants: $killed/$total killed"
[ $bad = 0 ] && [ $killed = $total ]
