#!/bin/bash
# Combined host check (fabric DCS2): tb_zk4_board_fabric. usage: wsl bash run_zk4_board_fabric.sh <devices.log> [t_end] [LAT] [RLAT]
# Sound ROM: the COMPACT 7 MiB stream MiSTer delivers on ioctl index 3 (u2+u3+u4+u5 from mk4.zip, CRC32 0x474599CA),
# fed as 16-bit LE words through zk4_dcs2 own loader. Override with ZKF_REGION.
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/board; D2=/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs2; DN=/mnt/d/deck/fpga/zeus/zeus1/rtl/dcs/donor
T=/mnt/d/deck/fpga/zeus/zeus1/tools
LOG="$1"; shift
REGION="${ZKF_REGION:-/mnt/h/temp/zeus/mk4_dcs_stream_from_zip.bin}"
read -r R12 R13 REST <<< "$(python3 $T/pic_serial_from_log.py "$LOG")" || { echo "PREPASS FAILED"; exit 2; }
RTC="${REST#*| }"
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zk4-boardfab-$$"; mkdir -p "$B"; cd "$B" || exit 2
verilator --cc --exe --build -O3 -j 8 --top-module zk4_board_fabric_bench -GRAND12=8\'h$R12 -GRAND13=8\'h$R13 \
  -Wno-fatal -Wno-lint -Wno-style -Wno-WIDTH -Wno-CASEINCOMPLETE -Wno-UNOPTFLAT \
  $S/zk4_pic2.sv $S/zk4_ioasic.sv $S/zk4_cmos.sv $S/zk4_board_io.sv \
  $D2/dcs2_autobuf.sv $D2/dcs2_engine.sv $D2/dcs2_ddr_agent.sv $D2/dcs2_sram_cache.sv $D2/dcs2_mailbox.sv $D2/dcs2_sport_dac.sv $D2/zk4_dcs2.sv \
  $DN/cusa_dcs_rom_loader.sv $DN/cusa_dcs_fifo.sv \
  $S/zk4_board_fabric_bench.sv $S/tb_zk4_board_fabric.cpp -o tb > build.log 2>&1 || { grep -m20 -E "%Error" build.log; echo "BUILD FAILED"; exit 2; }
echo "prepass: RAND12 $R12 RAND13 $R13 rtc $RTC region $REGION"
./obj_dir/tb "$LOG" "$RTC" "$REGION" "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
