#!/bin/bash
# zk4_board_io replay gate vs MAME's cold-boot device log. usage: wsl bash run_zk4_board.sh <devices.log> exact|stub [max-lines]
# ZKB_MUT=sed-expression mutates ZKB_MUT_FILE (default zk4_ioasic.sv) in a private copy.
# Invasion: ZKB_G="-GPIC_UPPER=468 -GPIC_YEAR=1999 -GSHUFFLE_DEFAULT=0" ZKB_SKIP_GUN=1 with an Invasion cold log.
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/board; T=/mnt/d/deck/fpga/zeus/zeus1/tools
LOG="$1"; shift
read -r R12 R13 REST <<< "$(python3 $T/pic_serial_from_log.py "$LOG")" || { echo "PREPASS FAILED"; exit 2; }
RTC="${REST#*| }"
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zk4-board-$$"; mkdir -p "$B"; cd "$B" || exit 2
cp $S/zk4_pic2.sv $S/zk4_ioasic.sv $S/zk4_dcs_stub.sv $S/zk4_cmos.sv $S/zk4_board_io.sv $S/zk4_board_bench.sv .
if [ -n "${ZKB_MUT:-}" ]; then MF="${ZKB_MUT_FILE:-zk4_ioasic.sv}"; cp "$MF" orig.sv; sed -i "$ZKB_MUT" "$MF"; cmp -s "$MF" orig.sv && { echo "MUTATION DID NOT APPLY"; exit 3; }; fi
MODE="${1:-exact}"; STUB=0; [ "$MODE" = stub ] && STUB=1
verilator --cc --exe --build -O3 -j 8 --top-module zk4_board_bench -GRAND12=8\'h$R12 -GRAND13=8\'h$R13 -GUSE_STUB=$STUB ${ZKB_G:-} -Wno-fatal -Wno-lint -Wno-style \
  zk4_pic2.sv zk4_ioasic.sv zk4_dcs_stub.sv zk4_cmos.sv zk4_board_io.sv zk4_board_bench.sv $S/tb_zk4_board.cpp -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
echo "prepass: RAND12 $R12 RAND13 $R13 rtc $RTC"
./obj_dir/tb "$LOG" "$RTC" "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
