// zk4_dcs_stub.sv -- a DCS2 STAND-IN for the silent first build: the host-visible behaviour of MAME's DCS2 (dcs.cpp)
// on MK4, measured from MAME 0.289 (scripts/mk4_device_census.lua, timestamps), with no sound CPU behind it.
//   * latch control (dcs.cpp:174-187): bit 11 = input (host -> DCS) latch empty, bit 10 = output latch empty.
//   * a host word (data_w) marks the input latch full; MAME's DCS takes it within ~2 us (0x08 then 0x88 on SOUNDSTAT).
//   * reset_w(0) halts the sound CPU; reset_w(1) after it reboots: the boot answers 0x79 after 3.925 s, then, 0.122 s
//     after the host acknowledges it, 0x01 (MK4 reads both at boot and never reads another reply in 3,600 frames).
//   * data_r clears the output-full callback; ack_w empties the output latch (dcs.cpp:1604-1640, delayed_ack_w).
// The ARM (or a fabric DCS2) replaces this block behind the same ports; the gate for this block is the protocol above.
module zk4_dcs_stub #(
  parameter int CLK_HZ = 50_000_000,
  parameter int CONSUME_CLK = 25,                                // 0.5 us: MAME consumed in (0.33, 0.63] us (cold log t 0.0603 and 54.354)
  parameter int BOOT_CLK = 196_241_490,                          // 3.9248297 s: bracketed to 0.3 us in the cold log (warm: same)
  parameter int REPLY2_CLK = 6_091_653                           // 0.1218331 s after the ack, bracketed to 0.3 us (warm: same)
) (
  input  logic        clk, rst,
  input  logic        data_w, input logic [15:0] wdata, input logic ack_w, input logic data_r,
  input  logic        reset_w, input logic reset_level,
  output logic [15:0] control, data, data2,
  output logic        input_empty, output_full
);
  logic in_empty, out_empty, halted, out_cb;
  logic [1:0] stage;                                             // 0 idle / power-on, 1 booting, 2 reply 1 out, 3 reply 2 pending
  logic [$clog2(BOOT_CLK+1)-1:0] t; logic [$clog2(CONSUME_CLK+1)-1:0] tc;
  assign control = {4'd0, in_empty, out_empty, 10'd0};
  assign data2 = 16'd0;
  assign input_empty = in_empty;
  assign output_full = out_cb;
  always_ff @(posedge clk)
    if (rst) begin in_empty <= 1'b1; out_empty <= 1'b1; out_cb <= 1'b0; halted <= 1'b0; stage <= 2'd0; t <= '0; tc <= '0; data <= '0; end
    else begin
      // host -> DCS: taken after CONSUME_CLK (the sound CPU reads the latch and acks it)
      if (data_w) begin in_empty <= 1'b0; tc <= ($clog2(CONSUME_CLK+1))'(CONSUME_CLK); end
      else if (!in_empty && !halted) begin if (tc == '0) in_empty <= 1'b1; else tc <= tc - 1'b1; end
      // DCS -> host
      if (data_r) out_cb <= 1'b0;
      if (ack_w) begin
        out_empty <= 1'b1;
        if (stage == 2'd2) begin stage <= 2'd3; t <= ($clog2(BOOT_CLK+1))'(REPLY2_CLK); end
      end
      if (reset_w) begin
        if (!reset_level) begin halted <= 1'b1; stage <= 2'd0; end
        else if (halted) begin halted <= 1'b0; stage <= 2'd1; t <= ($clog2(BOOT_CLK+1))'(BOOT_CLK); end
      end else if ((stage == 2'd1 || stage == 2'd3) && !halted) begin
        if (t == '0) begin
          data <= (stage == 2'd1) ? 16'h0079 : 16'h0001; out_empty <= 1'b0; out_cb <= 1'b1;
          stage <= (stage == 2'd1) ? 2'd2 : 2'd0;
        end else t <= t - 1'b1;
      end
    end
endmodule
