// zk4_board_io replay gate: MAME 0.289's own device log of a COLD MK4 boot (scripts/mk4_device_census.lua with an
// empty NVRAM directory, 3,600 frames) is replayed in time order into the RTL (MAME time x 50 MHz = clock), and every
// read of 0x8D0000-0x9FFFFF is compared with what MAME returned:
//   disk_asic_jr, CMOS (through the protect / write-enable rule), unmapped reads, I/O ASIC (ports, INTCTL, PIC2
//   serial / clock / latch protocol, SOUNDSTAT / SOUNDIN answered by the DCS2 STAND-IN at its measured timing).
// Stimulus only (not checked): the four input ports (set from the logged value before each port read) and the RTC
// (MAME's clock bytes, tools/pic_serial_from_log.py). PIC data[12]/[13] are MAME's rand() bytes, passed as parameters
// by the runner; the other 14 serial bytes check the transcription.
// Two modes (the bench's USE_STUB parameter, chosen at build time by the runner):
//   exact : the DCS2 state is STIMULUS from MAME's log (control bits from each logged SOUNDSTAT, reply data from each
//           logged SOUNDIN) -- the I/O ASIC's formatting and everything else must equal MAME with ZERO exceptions.
//   stub  : the DCS2 stand-in answers. Its replies must equal MAME's; the only permitted divergences are
//           input-latch CONSUME edges (SOUNDSTAT 0x08 vs 0x88 within 3 us of a SOUNDOUT write), counted and listed:
//           MAME's consume latency depends on what its sound CPU is running (0.33-0.63 us idle, 1.53-2.43 us playing,
//           cold log), which a stand-in without a sound CPU cannot reproduce.
// usage: tb_zk4_board <devices.log> "<rtc: 7 hex bytes>" exact|stub [max-lines]
#include "Vzk4_board_bench.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <map>
#include <string>
typedef uint64_t u64; typedef uint32_t u32;

int main(int argc, char** argv) {
    if (argc < 4) { printf("usage: tb_zk4_board <devices.log> \"rtc bytes\" exact|stub [max-lines]\n"); return 2; }
    FILE* f = fopen(argv[1], "r"); if (!f) { printf("FAIL: cannot open %s\n", argv[1]); return 2; }
    unsigned rtc[7]; if (sscanf(argv[2], "%x %x %x %x %x %x %x", &rtc[0], &rtc[1], &rtc[2], &rtc[3], &rtc[4], &rtc[5], &rtc[6]) != 7) return 2;
    bool exact = !strcmp(argv[3], "exact");
    if (!exact && strcmp(argv[3], "stub")) { printf("FAIL: mode must be exact or stub\n"); return 2; }
    long maxl = argc > 4 ? atol(argv[4]) : -1;
    // ZKB_SKIP_GUN=1 (Invasion runs only): 0x9C0000 is the lightgun (zk4_gun, not zk4_board_io) -- its accesses are
    // skipped and counted. MK4 runs never set it (MK4 has no device there: its reads must match "unmapped").
    bool skip_gun = getenv("ZKB_SKIP_GUN") && !strcmp(getenv("ZKB_SKIP_GUN"), "1"); u64 gun_skipped = 0;
    Verilated::commandArgs(argc, argv);
    Vzk4_board_bench* t = new Vzk4_board_bench;
    u64 clk = 0;
    auto tick = [&]() { t->clk = 0; t->eval(); t->clk = 1; t->eval(); clk++; };
    for (int i = 0; i < 7; i++) t->rtc[i] = rtc[i];
    for (int i = 0; i < 4; i++) t->in_port[i] = 0xFFFF;
    // log-driven DCS2 state (exact mode): idle = both latches empty (dcs.cpp:174-187)
    t->tb_dcs_control = 0x0C00; t->tb_dcs_data = 0; t->tb_dcs_data2 = 0; t->tb_dcs_input_empty = 1; t->tb_dcs_output_full = 0;
    t->rst = 1; t->req = 0; tick(); tick(); t->rst = 0; tick();
    std::map<std::string, u64> n_ok, n_bad; std::map<std::string, int> shown;
    char line[256]; long ln = 0; u64 reads = 0, writes = 0, consume_edges = 0; double last_sndout = -1.0;
    while (fgets(line, sizeof line, f)) {
        if (maxl >= 0 && ln >= maxl) break;
        ln++;
        int fr; char k; unsigned a, d, pc; double tm;
        if (sscanf(line, "%d %c %x %x %x %lf", &fr, &k, &a, &d, &pc, &tm) != 6) continue;
        if (a < 0x8D0000 || a > 0x9FFFFF) continue;                 // CPU control page: not this block
        if (skip_gun && a == 0x9C0000) { gun_skipped++; continue; }  // Invasion: the gun word is zk4_gun (own gates)
        u64 due = (u64)(tm * 50e6);
        while (clk < due) tick();
        bool wr = k == 'W';
        if (!wr && a >= 0x990000 && a <= 0x990003) t->in_port[a & 3] = d;   // stimulus
        if (exact && !wr && a == 0x99000A) {                         // stimulus: SOUNDSTAT bit 7 = input empty,
            bool in_empty = d & 0x80, out_full = d & 0x40;           // bit 6 = output full (midwayic.cpp:1060)
            t->tb_dcs_control = (in_empty ? 0x800 : 0) | (out_full ? 0 : 0x400);
            t->tb_dcs_input_empty = in_empty; t->tb_dcs_output_full = out_full;
        }
        if (exact && !wr && a == 0x99000B) t->tb_dcs_data = d & 0xFFFF;   // stimulus: the sound CPU's reply
        if (exact && skip_gun && !wr && a == 0x99000A) t->tb_dcs_data2 = d & 0xFF00;   // Invasion: data2_r high byte
        if (exact && skip_gun && !wr && a == 0x99000E) {             // Invasion: the DCS2 callback levels before its
            bool in_empty = d & 0x80, out_full = d & 0x40;           // first SOUNDSTAT read (Invasion's sound board raises
            bool chg = in_empty != (bool)t->tb_dcs_input_empty || out_full != (bool)t->tb_dcs_output_full;  // output_full at
            t->tb_dcs_input_empty = in_empty; t->tb_dcs_output_full = out_full;   // boot; MK4's does not)
            t->tb_dcs_control = (in_empty ? 0x800 : 0) | (out_full ? 0 : 0x400);
            if (chg) { tick(); tick(); }                             // the level was there before the read: let the
                                                                     // I/O ASIC's registered sound-IRQ state take it
        }
        if (wr && a == 0x990009) last_sndout = tm;
        t->req = 1; t->we = wr; t->addr = a; t->wdata = d; tick(); t->req = 0; t->we = 0;
        if (wr) { writes++; continue; }
        reads++;
        t->clk = 0; t->eval();
        if (!t->rvalid) { printf("FAIL: no rvalid for read %06X (line %ld)\n", a, ln); return 1; }
        u32 got = t->rdata;
        std::string cat = (a >= 0x9F0000 && a <= 0x9F7FFF) ? "cmos" : (a >= 0x8D0000 && a <= 0x8D0009) ? "disk_asic_jr" :
                          (a >= 0x990000 && a <= 0x99000F) ? ("ioasic+" + std::to_string(a & 15)) : "unmapped";
        if (got == d) { n_ok[cat]++; continue; }
        // stub mode: an input-latch consume edge (0x08 vs 0x88) within 3 us of a SOUNDOUT write is the stand-in's
        // declared limit -- counted and listed, not a pass by tolerance of anything else
        if (!exact && a == 0x99000A && ((got ^ d) == 0x80) && (d & 0x7F) == 0x08 && last_sndout >= 0 && tm - last_sndout < 3e-6) {
            consume_edges++;
            printf("  consume edge line %ld t %.9f: %.2f us after SOUNDOUT, rtl %02X mame %02X\n", ln, tm, (tm - last_sndout) * 1e6, got, d);
            continue;
        }
        n_bad[cat]++;
        if (shown[cat]++ < 4) printf("  MISMATCH %s line %ld frame %d t %.9f addr %06X: rtl %08X mame %08X (pc %06X)\n", cat.c_str(), ln, fr, tm, a, got, d, pc);
    }
    u64 bad = 0;
    printf("BOARD replay (%s): %ld log lines, %llu reads, %llu writes, %llu clocks\n", exact ? "exact, DCS2 state from the log" : "DCS2 stand-in",
           ln, (unsigned long long)reads, (unsigned long long)writes, (unsigned long long)clk);
    for (auto& kv : n_ok) printf("  %-14s ok %llu bad %llu\n", kv.first.c_str(), (unsigned long long)kv.second, (unsigned long long)n_bad[kv.first]);
    for (auto& kv : n_bad) { if (!n_ok.count(kv.first)) printf("  %-14s ok 0 bad %llu\n", kv.first.c_str(), (unsigned long long)kv.second); bad += kv.second; }
    if (!exact) printf("  stand-in consume edges (declared limit): %llu\n", (unsigned long long)consume_edges);
    if (skip_gun) printf("  0x9C0000 gun accesses skipped (zk4_gun): %llu\n", (unsigned long long)gun_skipped);
    printf("%s: every device read equal to MAME (%llu mismatches)\n", bad ? "FAIL" : "PASS", (unsigned long long)bad);
    delete t; return bad ? 1 : 0;
}
