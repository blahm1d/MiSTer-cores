// zk4_pic2.sv -- Midway serial PIC 2 (security serial number, clock, 256-byte NVRAM), as the MK4 I/O ASIC exposes it.
// Transcribed from MAME 0.289 williams/midwayic.cpp (blob d20d6b25): generate_serial_data :73-121, status_r :418-437,
// read :440-459, write :462-632, nvram_default :634-637 (0xFF, :383). MK4 config: upper 461 (midzeus.cpp:1417), year
// 1997 (GAME() line), serial DIP default 6 (midwayic.cpp:46), yearoffs 94 (:1412).
//   data[12], data[13] are machine().rand() in MAME: parameters here (the game checks consistency, not the values).
//   Time: the latch's data-ready flag expires 1 ms after a write; a written clock is parroted back for 500 ms.
// Interface: pic_wr (one clk, PICOUT write, byte), pic_rd (one clk, PICIN read: returns {status, data} and applies
// status_r's side effect), rtc_* the live clock already in MAME's shape (BCD sec, min, hour, weekday+1, mday,
// month+1, year-1900-yearoffs).
module zk4_pic2 #(
  parameter int          CLK_HZ = 50_000_000,
  parameter logic [7:0]  RAND12 = 8'h00, RAND13 = 8'h00,
  parameter int          UPPER = 461, YEAR = 1997, SERIAL_DIGIT = 6
) (
  input  logic        clk, rst,
  input  logic        pic_wr, input logic [7:0] pic_wdata,
  input  logic        pic_rd, output logic [15:0] pic_rdata,   // {7'b0, status, data} (ioasic PICIN, :1093)
  input  logic [7:0]  rtc [7]
);
  // ---------------- serial data (constant at elaboration: generate_serial_data) ----------------

  // byte i at [8*i +: 8]; scalar locals only (Verilator 5.032's constant evaluator faults on local unpacked arrays)
  function automatic logic [127:0] serial_data();
    logic [127:0] v; int unsigned sn, t, s0, s1, s2, s3, s4, s5, s6, s7, s8;
    sn = 123450 + UPPER * 1000000 + (SERIAL_DIGIT & 15);
    s0 = (sn / 100000000) % 10; s1 = (sn / 10000000) % 10; s2 = (sn / 1000000) % 10;
    s3 = (sn / 100000) % 10;    s4 = (sn / 10000) % 10;    s5 = (sn / 1000) % 10;
    s6 = (sn / 100) % 10;       s7 = (sn / 10) % 10;       s8 = sn % 10;
    v = '0;
    v[8*12 +: 8] = RAND12; v[8*13 +: 8] = RAND13;              // data[14], data[15] = 0
    t = 32'h174 * (YEAR - 1980) + 32'h1f * (12 - 1) + 11;
    v[8*10 +: 8] = 8'(t >> 8); v[8*11 +: 8] = 8'(t);
    t = s4 + s7 * 10 + s1 * 100;
    t = (t + 5 * RAND13) * 32'h1bcd + 32'h1f3f0;
    v[8*7 +: 8] = 8'(t); v[8*8 +: 8] = 8'(t >> 8); v[8*9 +: 8] = 8'(t >> 16);
    t = s6 + s8 * 10 + s0 * 100 + s2 * 10000;
    t = (t + 2 * RAND13 + RAND12) * 32'h107f + 32'h71e259;
    v[8*3 +: 8] = 8'(t); v[8*4 +: 8] = 8'(t >> 8); v[8*5 +: 8] = 8'(t >> 16); v[8*6 +: 8] = 8'(t >> 24);
    t = s5 * 10 + s3 * 100;
    t = (t + RAND12) * 32'h245 + 32'h3d74;
    v[8*0 +: 8] = 8'(t); v[8*1 +: 8] = 8'(t >> 8); v[8*2 +: 8] = 8'(t >> 16);
    return v;
  endfunction
  localparam logic [127:0] SER = serial_data();

  // ---------------- state ----------------
  localparam int MS = CLK_HZ / 1000;
  logic [11:0] latch;
  logic [$clog2(MS+1)-1:0] l_age; logic l_expired;                // clocks since the last write, saturating at 1 ms
  logic [7:0]  st;
  logic [4:0]  idx, tot;
  logic [7:0]  buffer [16];
  logic [7:0]  time_buf [7]; logic [2:0] tidx;
  logic        tjw; logic [$clog2(500*MS+1)-1:0] tjw_cnt;          // time_just_written, 500 ms
  logic [7:0]  nv_addr;
  // NVRAM: 256 x 8, one write port, registered read (M10K / MLAB shape); initial 0xFF (nvram_default)
  logic        nv_we; logic [7:0] nv_wa, nv_wd, nv_ra, nv_q;
  logic [7:0]  nvram [256];
  initial for (int i = 0; i < 256; i++) nvram[i] = 8'hFF;
  always_ff @(posedge clk) begin if (nv_we) nvram[nv_wa] <= nv_wd; nv_q <= nvram[nv_ra]; end
  logic        nv_fill, nv_fill2;                                 // read command: address registered, RAM read, then buffer[0]
  // the low nibble written at step 0x35 (the 0x45 step ORs the high nibble onto it, :589 / :595)
  logic [3:0]  nv_lo;
  always_ff @(posedge clk) if (pic_wr && pic_wdata[4] && st == 8'h35) nv_lo <= pic_wdata[3:0];

  assign l_expired = l_age == ($clog2(MS+1))'(MS);
  // read (:440-459) and status_r (:418-437): PICIN = read() | status_r() << 8; read() sees the latch BEFORE
  // status_r's side effect (operands evaluated left to right; checked against MAME's log by the device gate)
  always_comb begin
    logic [7:0] d;
    if (latch[11:8] != 4'd0) d = latch[7:0];
    else if (idx < tot)      d = 8'hFF;
    else                     d = 8'h00;
    pic_rdata = {7'd0, latch[11:8] != 4'd0, d};
  end

  always_ff @(posedge clk)
    if (rst) begin
      latch <= '0; l_age <= '0; st <= '0; idx <= '0; tot <= '0; tidx <= '0; tjw <= 1'b0; tjw_cnt <= '0;
      nv_addr <= '0; nv_we <= 1'b0; nv_fill <= 1'b0; nv_fill2 <= 1'b0;
      for (int i = 0; i < 16; i++) buffer[i] <= 8'h00;
      for (int i = 0; i < 7; i++) time_buf[i] <= 8'h00;
    end else begin
      nv_we <= 1'b0;
      if (!l_expired) l_age <= l_age + 1'b1;
      if (tjw) begin if (tjw_cnt == '0) tjw <= 1'b0; else tjw_cnt <= tjw_cnt - 1'b1; end
      nv_fill2 <= nv_fill; nv_fill <= 1'b0;
      if (nv_fill2) buffer[0] <= nv_q;                           // nv_ra set at the command edge, nv_q one edge later
      if (pic_rd) begin                                          // status_r side effect
        if (latch[11:8] != 4'd0) begin
          if (l_expired) latch <= {4'd0, latch[7:0]};
          else latch <= latch - 12'h100;
        end
      end
      if (pic_wr) begin : wr
        logic [11:0] nl; logic [3:0] cmd;
        nl = {4'h4, 4'h8, pic_wdata[3:0]};                      // (data & 0x00f) | 0x480
        latch <= nl; l_age <= '0;
        cmd = (st != 8'd0) ? st[3:0] : nl[3:0];
        if (pic_wdata[4]) begin
          case (cmd)
            4'd0: if (idx < tot) begin latch <= {4'h4, buffer[idx[3:0]]}; idx <= idx + 1'b1; end
            4'd1: if (idx < tot) begin latch <= {4'h4, buffer[idx[3:0]]}; idx <= idx + 1'b1; end
                  else begin for (int i = 0; i < 16; i++) buffer[i] <= SER[8*i +: 8]; tot <= 5'd16; idx <= '0; end
            4'd3: begin
                    idx <= '0; tot <= 5'd7;
                    for (int i = 0; i < 7; i++) buffer[i] <= tjw ? time_buf[i] : rtc[i];
                  end
            4'd4: if (st == 8'h00) begin st <= 8'h14; tidx <= '0; end
                  else if (st == 8'h14) begin time_buf[tidx] <= {4'd0, nl[3:0]}; st <= 8'h24; end
                  else if (st == 8'h24) begin
                    time_buf[tidx] <= time_buf[tidx] | {nl[3:0], 4'd0};
                    if (tidx + 1'b1 < 3'd7) begin tidx <= tidx + 1'b1; st <= 8'h14; end
                    else begin tidx <= tidx + 1'b1; tjw <= 1'b1; tjw_cnt <= ($clog2(500*MS+1))'(500 * MS); st <= 8'h00; end
                  end
            4'd5: if (st == 8'h00) st <= 8'h15;
                  else if (st == 8'h15) begin nv_addr <= {4'd0, nl[3:0]}; st <= 8'h25; end
                  else if (st == 8'h25) begin nv_addr <= nv_addr | {nl[3:0], 4'd0}; st <= 8'h35; end
                  else if (st == 8'h35) begin nv_we <= 1'b1; nv_wa <= nv_addr; nv_wd <= {4'd0, nl[3:0]}; st <= 8'h45; end
                  else if (st == 8'h45) begin nv_we <= 1'b1; nv_wa <= nv_addr; nv_wd <= {nl[3:0], nv_lo}; st <= 8'h00; end
            4'd6: if (st == 8'h00) st <= 8'h16;
                  else if (st == 8'h16) begin nv_addr <= {4'd0, nl[3:0]}; st <= 8'h26; end
                  else if (st == 8'h26) begin
                    st <= 8'h00; tot <= 5'd1; idx <= '0;
                    nv_ra <= nv_addr | {nl[3:0], 4'd0}; nv_fill <= 1'b1;   // buffer[0] = nvram[addr] next clk
                  end
            4'd8: latch <= {4'h4, ~{4'd0, cmd}};
            default: ;
          endcase
        end
      end
    end
endmodule
