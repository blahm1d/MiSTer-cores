// zk4_cmos.sv -- MK4 CMOS (32 K x 8, MAME midzeus nvram) with a second port for the MiSTer host, so the OSD can save it
// to SD and Main can restore it at load (MRA <nvram index="2" size="32768"/>; hps_io WIDE: 16-bit transfers).
// Two 16 K x 8 banks, even and odd byte, so one host halfword = one address in both banks (ioctl_dout[7:0] is the
// byte at the even address, [15:8] the odd one). Game port: byte address a[14:0] -> bank a[0], row a[14:1].
// Storage is INVERTED (M10K powers up 0 = MAME's DEFAULT_ALL_1 with no initial loop; Quartus Error 10106 at 5,000
// iterations); both ports invert on the way in and out, so the file on SD holds the true bytes.
// Each port uses the Altera true-dual-port template (write: q <= d) -- old-data same-port read-during-write cannot map
// to an M10K TDP (Chiller r1: duplicated / uninferred RAMs). Host writes only happen during the NVRAM download, while
// zk4_top holds the game in reset, so the two ports never write together.
module zk4_cmos (
  input  logic        clk,
  input  logic        a_we, input logic [14:0] a_addr, input logic [7:0] a_d, output logic [7:0] a_q,   // game
  input  logic        b_we, input logic [13:0] b_row,  input logic [15:0] b_d, output logic [15:0] b_q   // host
);
  logic [7:0] q_ae, q_ao, q_be, q_bo;
  zk4_cmos_bank u_even (.clk, .a_we(a_we && !a_addr[0]), .a_row(a_addr[14:1]), .a_d(~a_d), .a_q(q_ae),
                        .b_we, .b_row, .b_d(~b_d[7:0]), .b_q(q_be));
  zk4_cmos_bank u_odd  (.clk, .a_we(a_we &&  a_addr[0]), .a_row(a_addr[14:1]), .a_d(~a_d), .a_q(q_ao),
                        .b_we, .b_row, .b_d(~b_d[15:8]), .b_q(q_bo));
  logic a_odd; always_ff @(posedge clk) a_odd <= a_addr[0];
  assign a_q = ~(a_odd ? q_ao : q_ae);
  assign b_q = ~{q_bo, q_be};
endmodule

module zk4_cmos_bank (
  input  logic       clk,
  input  logic       a_we, input logic [13:0] a_row, input logic [7:0] a_d, output logic [7:0] a_q,
  input  logic       b_we, input logic [13:0] b_row, input logic [7:0] b_d, output logic [7:0] b_q
);
  (* ramstyle = "M10K, no_rw_check" *) logic [7:0] mem [16384];
  always_ff @(posedge clk) if (a_we) begin mem[a_row] <= a_d; a_q <= a_d; end else a_q <= mem[a_row];
  always_ff @(posedge clk) if (b_we) begin mem[b_row] <= b_d; b_q <= b_d; end else b_q <= mem[b_row];
endmodule
