#!/bin/bash
# Build + run the staged-unit streaming check (fp_add4 / fp_mul4 vs host SSE). Build dir on H: scratch.
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/fp32/run_fp32_pipe_check.sh [vectors]
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/fp32
B="${ZSCRATCH:-/mnt/h/temp/zeus}/fp32-pipe-$$"; mkdir -p "$B"; cd "$B" || exit 2
TOPM="${FP_TOP:-fp32_pipe_tb_top}"
verilator --cc --exe --build -O3 -j 8 --top-module "$TOPM" --prefix Vfp32_pipe_tb_top -Wno-fatal -Wno-lint -Wno-style \
  -CFLAGS "-O2 -msse2 -mfpmath=sse -ffp-contract=off" \
  "$S/fp32_pkg.sv" "$S/fp32_units.sv" "$S/$TOPM.sv" "$S/fp32_pipe_check.cpp" -o chk > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/chk "${1:-6000000}" "${2:-4}"; rc=$?
cd /; rm -rf "$B"; exit $rc
