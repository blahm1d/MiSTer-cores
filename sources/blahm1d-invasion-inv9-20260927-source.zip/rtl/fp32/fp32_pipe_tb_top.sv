// Test wrapper for the staged units: fp_add4 (add and sub) and fp_mul4, one new operand pair per clock each.
module fp32_pipe_tb_top (
  input  logic clk,
  input  logic [31:0] a, b, input logic sub,
  output logic [31:0] add_y, mul_y, output logic add_exc, mul_exc
);
  fp_add4 u_add (.clk, .a, .b, .sub, .y(add_y), .exc(add_exc));
  fp_mul4 u_mul (.clk, .a, .b, .y(mul_y), .exc(mul_exc));
endmodule
