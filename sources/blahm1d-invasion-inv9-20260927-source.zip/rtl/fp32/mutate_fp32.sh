#!/bin/bash
# fp32_pkg coverage: each mutant misreads one IEEE / MAME rounding rule; the host-SSE differential must FAIL each.
#   F1 round-half-up instead of ties-to-even        F2 add: sticky dropped on alignment
#   F3 mul: sticky dropped                          F4 div: remainder sticky dropped
#   F5 round_coordinate: fraction >= 0.5            F6 x + (-x) = -0 instead of +0
#   F7 f2i rounds to nearest instead of truncating (cvttss2si)
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/fp32
declare -A M
M[F1]='s/inc = S\[2\] \& (S\[1\] | S\[0\] | S\[3\]);/inc = S[2];/'
M[F2]='s/Y = {yw\[49:24\], |yw\[23:0\]};/Y = {yw[49:24], 1'"'"'b0};/'
M[F3]='s/if (P\[47\]) begin S = {P\[47:22\], |P\[21:0\]};/if (P[47]) begin S = {P[47:22], 1'"'"'b0};/'
M[F4]='s/if (q\[26\]) S = {q\[26:1\], q\[0\] | (rem != 24'"'"'d0)};/if (q[26]) S = {q[26:1], q[0]};/'
M[F5]='s/up = fr\[31\] \&\& (fr\[30:0\] != 31'"'"'d0 || sticky);/up = fr[31];/'
M[F6]='s/if (S == 27'"'"'d0) begin r.v = 32'"'"'h00000000; return r; end/if (S == 27'"'"'d0) begin r.v = 32'"'"'h80000000; return r; end/'
M[F7]='s/else t = 32'"'"'({1'"'"'b1, a\[22:0\]} >> (-sh));/else t = 32'"'"'((25'"'"'({1'"'"'b1, a[22:0]}) + (25'"'"'d1 << (-sh-1))) >> (-sh));/'
ok=0
for m in F1 F2 F3 F4 F5 F6 F7; do
  B="${ZSCRATCH:-/mnt/h/temp/zeus}/fp32-mut-$m-$$"; mkdir -p "$B"
  sed "${M[$m]}" "$S/fp32_pkg.sv" > "$B/fp32_pkg.sv"
  if cmp -s "$B/fp32_pkg.sv" "$S/fp32_pkg.sv"; then echo "$m NOT APPLIED"; ok=1; rm -rf "$B"; continue; fi
  ( cd "$B" && verilator --cc --exe --build -O3 -j 4 --top-module fp32_tb_top -Wno-fatal -Wno-lint -Wno-style \
      -CFLAGS "-O2 -msse2 -mfpmath=sse -ffp-contract=off" fp32_pkg.sv "$S/fp32_tb_top.sv" "$S/fp32_check.cpp" -o fp32_check > build.log 2>&1 \
      || { echo "$m BUILD FAILED (not a kill)"; exit 9; }
    ./obj_dir/fp32_check 400000 > run.log 2>&1; rc=$?
    if [ $rc = 0 ]; then echo "$m SURVIVED"; exit 1; else echo "$m killed: $(grep -m1 '^FAIL' run.log | cut -c1-110)"; fi ) &
done
wait
rm -rf "${ZSCRATCH:-/mnt/h/temp/zeus}"/fp32-mut-*-$$
