// fp32_units.sv -- pipelined / iterative wrappers around fp32_pkg for the Zeus 1 setup engine.
//   fp_add_pipe / fp_mul_pipe : one op per clock, result LAT clocks after issue (the arithmetic is fp32_pkg's; the
//                               registers are placed after it so Quartus register retiming can balance the stages)
//   fp_rcp_iter               : a / b by restoring division, 2 quotient bits per clock, bit-exact to fp32_pkg::fp_div
//                               (28 quotient bits: the 28th bit + remainder is the same sticky as fp_div's remainder)


module fp_add_pipe import fp32_pkg::*; #(parameter int LAT = 3) (
  input  logic clk, input logic ce,
  input  logic [31:0] a, b, input logic sub,
  output logic [31:0] y, output logic exc
);
  fres_t r;
  always_comb r = fp_add(a, sub ? {~b[31], b[30:0]} : b);
  logic [32:0] pipe [LAT];
  always_ff @(posedge clk) if (ce) begin
    pipe[0] <= {r.exc, r.v};
    for (int i = 1; i < LAT; i++) pipe[i] <= pipe[i - 1];
  end
  assign {exc, y} = pipe[LAT - 1];
endmodule

module fp_mul_pipe import fp32_pkg::*; #(parameter int LAT = 3) (
  input  logic clk, input logic ce,
  input  logic [31:0] a, b,
  output logic [31:0] y, output logic exc
);
  fres_t r;
  always_comb r = fp_mul(a, b);
  logic [32:0] pipe [LAT];
  always_ff @(posedge clk) if (ce) begin
    pipe[0] <= {r.exc, r.v};
    for (int i = 1; i < LAT; i++) pipe[i] <= pipe[i - 1];
  end
  assign {exc, y} = pipe[LAT - 1];
endmodule

// ---- explicitly staged units (R3d, fit-driven): result readable 4 clocks after issue, one op per clock ----
// fp_add4: issue (operands registered) | align | add + lzc | normalise + round
module fp_add4 import fp32_pkg::*; (
  input  logic clk,
  input  logic [31:0] a, b, input logic sub,
  output logic [31:0] y, output logic exc
);
  logic [31:0] ra, rb; fadd1_t s1; fadd2_t s2; fres_t s3;
  // shift-by-multiply: align + normalise variable shifters mapped to DSP one-hot multiplies.
  // Combinational products (no extra register stage) -> latency unchanged (ra/rb, s1, s2, s3 = 4).
  fadd0_t s0w;
  (* multstyle = "dsp" *) logic [50:0] alp;   // align:     my(24) << (26-d)  = my * onehot(27)
  (* multstyle = "dsp" *) logic [53:0] nsp;   // normalise: S(27) << lz        = S  * onehot(27)
  always_comb s0w = fp_add_s1a(ra, rb);
  always_comb alp = s0w.my * fp_align_pow(s0w.d);   // 24 x 27 one-hot -> one DSP (zero MSBs pruned)
  always_comb nsp = s2.S   * (27'd1 << s2.lz);       // 27 x 27 one-hot -> one DSP
  always_ff @(posedge clk) begin
    ra <= a; rb <= sub ? {~b[31], b[30:0]} : b;
    s1 <= fp_add_s1b_prod(s0w, alp[49:0]);
    s2 <= fp_add_s2(s1);
    s3 <= fp_add_s3_prod(s2, nsp[26:0]);
  end
  assign y = s3.v; assign exc = s3.exc;
endmodule

// fp_mul4: issue (operands registered) | classify + 24x24 product (DSP) | normalise + round | output register
module fp_mul4 import fp32_pkg::*; (
  input  logic clk,
  input  logic [31:0] a, b,
  output logic [31:0] y, output logic exc
);
  logic [31:0] ra, rb; fmul1_t s1; logic [47:0] p; fres_t s2, s3;
  always_ff @(posedge clk) begin
    ra <= a; rb <= b;
    s1 <= fp_mul_s1(ra, rb);
    p  <= {1'b1, ra[22:0]} * {1'b1, rb[22:0]};
    s2 <= fp_mul_s2(s1, p);
    s3 <= s2;
  end
  assign y = s3.v; assign exc = s3.exc;
endmodule

// ---- latency-5 units (R3e): the align stage split (compare/swap | shift); multiplier padded to match ----
module fp_add5 import fp32_pkg::*; (
  input  logic clk,
  input  logic [31:0] a, b, input logic sub,
  output logic [31:0] y, output logic exc
);
  logic [31:0] ra, rb; fadd0_t s0; fadd1_t s1; fadd2_t s2; fres_t s3;
  // shift-by-multiply: align (from registered s0) + normalise mapped to DSP one-hot multiplies.
  // Combinational products feed the existing registers -> latency unchanged (ra/rb, s0, s1, s2, s3 = 5).
  (* multstyle = "dsp" *) logic [50:0] alp;
  (* multstyle = "dsp" *) logic [53:0] nsp;
  always_comb alp = s0.my * fp_align_pow(s0.d);      // 24 x 27 one-hot -> one DSP
  always_comb nsp = s2.S  * (27'd1 << s2.lz);         // 27 x 27 one-hot -> one DSP
  always_ff @(posedge clk) begin
    ra <= a; rb <= sub ? {~b[31], b[30:0]} : b;
    s0 <= fp_add_s1a(ra, rb);
    s1 <= fp_add_s1b_prod(s0, alp[49:0]);
    s2 <= fp_add_s2(s1);
    s3 <= fp_add_s3_prod(s2, nsp[26:0]);
  end
  assign y = s3.v; assign exc = s3.exc;
endmodule

module fp_mul5 import fp32_pkg::*; (
  input  logic clk,
  input  logic [31:0] a, b,
  output logic [31:0] y, output logic exc
);
  logic [31:0] ra, rb; fmul1_t s1; logic [47:0] p; fres_t s2, s3, s4;
  always_ff @(posedge clk) begin
    ra <= a; rb <= b;
    s1 <= fp_mul_s1(ra, rb);
    p  <= {1'b1, ra[22:0]} * {1'b1, rb[22:0]};
    s2 <= fp_mul_s2(s1, p);
    s3 <= s2; s4 <= s3;
  end
  assign y = s4.v; assign exc = s4.exc;
endmodule

// a / b, radix 4 (R3e): each clock compares the shifted remainder against den, 2den and 3den IN PARALLEL and keeps
// the largest that fits -- one subtract + select per clock instead of two chained. Same 28 quotient bits, same
// sticky, same pack as fp_rcp_iter; done pulse at the same point (14 iteration clocks).
module fp_rcp4 import fp32_pkg::*; (
  input  logic clk, input logic rst,
  input  logic start, input logic [31:0] a, b,
  output logic done, output logic [31:0] y, output logic exc, output logic busy
);
  logic        s, spec, a_zero, inbit, run, fin;
  logic signed [10:0] e;
  logic [24:0] rem;
  logic [23:0] den;
  logic [25:0] den3;
  logic [27:0] q;
  logic [4:0]  it;
  always_ff @(posedge clk) begin
    done <= 1'b0;
    if (rst) begin run <= 1'b0; fin <= 1'b0; busy <= 1'b0; end
    else if (start) begin
      s <= a[31] ^ b[31];
      spec <= is_special(a) || is_special(b) || is_zero(b);
      a_zero <= is_zero(a);
      e <= 11'(a[30:23]) - 11'(b[30:23]) + 11'sd127;
      den <= {1'b1, b[22:0]};
      den3 <= 26'({1'b1, b[22:0]}) * 26'd3;
      rem <= 25'({1'b1, a[22:1]});
      inbit <= a[0];
      q <= '0; it <= 5'd0; run <= 1'b1; busy <= 1'b1;
    end else if (run) begin : step
      logic [26:0] r4; logic [26:0] d1, d2, d3; logic [1:0] qd;
      r4 = {rem, (it == 5'd0) ? inbit : 1'b0, 1'b0};       // rem * 4 + next two dividend bits
      d1 = r4 - 27'(den); d2 = r4 - 27'({den, 1'b0}); d3 = r4 - 27'(den3);
      if (!d3[26])      begin qd = 2'd3; rem <= d3[24:0]; end
      else if (!d2[26]) begin qd = 2'd2; rem <= d2[24:0]; end
      else if (!d1[26]) begin qd = 2'd1; rem <= d1[24:0]; end
      else              begin qd = 2'd0; rem <= r4[24:0]; end
      q <= {q[25:0], qd};
      it <= it + 5'd1;
      if (it == 5'd13) begin run <= 1'b0; fin <= 1'b1; end
    end else if (fin) begin : pack
      fres_t r; logic [26:0] S; logic signed [10:0] ee; logic stk;
      fin <= 1'b0; busy <= 1'b0; done <= 1'b1;
      stk = q[0] | (rem != 25'd0);
      ee = e;
      if (q[27]) S = {q[27:2], q[1] | stk};
      else begin S = {q[26:1], stk}; ee = ee - 11'sd1; end
      if (spec) begin y <= {s, 8'hff, 23'd0}; exc <= 1'b1; end
      else if (a_zero) begin y <= {s, 31'd0}; exc <= 1'b0; end
      else begin r = round_pack(s, ee, S); y <= r.v; exc <= r.exc; end
    end
  end
endmodule

// a / b. start (1 clock) -> done pulse exactly RCP_LAT = 16 clocks later (14 iteration clocks + 1 round/pack + start).
module fp_rcp_iter import fp32_pkg::*; (
  input  logic clk, input logic ce, input logic rst,
  input  logic start, input logic [31:0] a, b,
  output logic done, output logic [31:0] y, output logic exc, output logic busy
);
  logic        s, spec;
  logic signed [10:0] e;
  logic [24:0] rem;          // partial remainder (< 2*den)
  logic [23:0] den;
  logic [27:0] q;            // 28 quotient bits: q[27] is the 2^26 weight
  logic        a_zero;
  logic [4:0]  it;
  logic        run, fin;
  logic        inbit;        // the single nonzero incoming dividend bit after the initial remainder (ma[0])
  always_ff @(posedge clk) begin
    done <= 1'b0;
    if (rst) begin run <= 1'b0; fin <= 1'b0; busy <= 1'b0; end
    else if (ce) begin
      if (start) begin
        s <= a[31] ^ b[31];
        spec <= is_special(a) || is_special(b) || is_zero(b);
        a_zero <= is_zero(a);
        e <= 11'(a[30:23]) - 11'(b[30:23]) + 11'sd127;
        den <= {1'b1, b[22:0]};
        // dividend {1, ma, 26'b0}: initial remainder = dividend >> 27 = {1, ma} >> 1; then ma[0], then zeros
        rem <= 25'({1'b1, a[22:1]});
        inbit <= a[0];
        q <= '0; it <= 5'd0; run <= 1'b1; busy <= 1'b1;
      end else if (run) begin : step
        logic [25:0] r1, r2; logic q1, q2;
        r1 = {rem, (it == 5'd0) ? inbit : 1'b0};
        q1 = (r1 >= {2'b00, den});
        if (q1) r1 = r1 - {2'b00, den};
        r2 = {r1[24:0], 1'b0};
        q2 = (r2 >= {2'b00, den});
        if (q2) r2 = r2 - {2'b00, den};
        rem <= r2[24:0];
        q <= {q[25:0], q1, q2};
        it <= it + 5'd1;
        if (it == 5'd13) begin run <= 1'b0; fin <= 1'b1; end
      end else if (fin) begin : pack
        fres_t r; logic [26:0] S; logic signed [10:0] ee; logic stk;
        fin <= 1'b0; busy <= 1'b0; done <= 1'b1;
        // 27-bit quotient = q[27:1]; sticky = q[0] | (rem != 0)  (== fp_div's rem != 0)
        stk = q[0] | (rem != 25'd0);
        ee = e;
        if (q[27]) S = {q[27:2], q[1] | stk};
        else begin S = {q[26:1], stk}; ee = ee - 11'sd1; end
        if (spec) begin y <= {s, 8'hff, 23'd0}; exc <= 1'b1; end
        else if (a_zero) begin y <= {s, 31'd0}; exc <= 1'b0; end
        else begin r = round_pack(s, ee, S); y <= r.v; exc <= r.exc; end
      end
    end
  end
endmodule
