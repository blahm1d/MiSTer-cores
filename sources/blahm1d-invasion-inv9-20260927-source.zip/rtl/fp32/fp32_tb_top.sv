// Test wrapper: exposes every fp32_pkg function combinationally for the host-SSE differential check.
module fp32_tb_top (
  input  logic [2:0]  op,        // 0 add, 1 sub, 2 mul, 3 div, 4 i2f(a), 5 round_coord(a), 6 f2i_trunc(a), 7 cmp
  input  logic [31:0] a, b,
  output logic [31:0] r,
  output logic        exc,
  output logic [2:0]  cmp        // {lt, eq, gt}
);
  import fp32_pkg::*;
  fres_t t; logic x;
  always_comb begin
    r = 32'd0; exc = 1'b0; t = '0; x = 1'b0;
    cmp = {fp_lt(a, b), fp_eq(a, b), fp_gt(a, b)};
    case (op)
      3'd0: begin t = fp_add(a, b); r = t.v; exc = t.exc; end
      3'd1: begin t = fp_add(a, {~b[31], b[30:0]}); r = t.v; exc = t.exc; end
      3'd2: begin t = fp_mul(a, b); r = t.v; exc = t.exc; end
      3'd3: begin t = fp_div(a, b); r = t.v; exc = t.exc; end
      3'd4: begin t = fp_i2f(a); r = t.v; exc = t.exc; end
      3'd5: begin r = fp_round_coord(a, x); exc = x; end
      3'd6: begin r = fp_f2i_trunc(a, x); exc = x; end
      default: ;
    endcase
  end
endmodule
