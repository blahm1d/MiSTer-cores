// Streaming check of the staged units (fp_add4, fp_mul4): a new random operand pair every clock, each result compared
// with the host's SSE op exactly 4 clocks later. Same contract as fp32_check.cpp: exact on normal/zero operands with
// normal/zero results, exc on anything else (underflow to 0 from nonzero operands included).
#include "Vfp32_pipe_tb_top.h"   // (verilator --prefix Vfp32_pipe_tb_top for either top)
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <deque>
#include <emmintrin.h>

static uint64_t rs = 0xD1B54A32D192ED03ull;
static uint64_t rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static float bf(uint32_t b) { float f; memcpy(&f, &b, 4); return f; }
static uint32_t fb(float f) { uint32_t b; memcpy(&b, &f, 4); return b; }
static bool nz(uint32_t b) { uint32_t e = (b >> 23) & 0xff; return e != 0xff && !(e == 0 && (b & 0x7fffff)); }   // normal or zero
static uint32_t gen() {
    uint32_t s = (rnd() & 1) << 31, m = rnd() & 0x7fffff;
    switch (rnd() % 6) {
    case 0: return s | ((uint32_t)(100 + rnd() % 60) << 23) | m;
    case 1: return s | ((uint32_t)(1 + rnd() % 254) << 23) | m;
    case 2: return s | ((uint32_t)(127 + rnd() % 8) << 23) | (m & 0x7f0000);
    case 3: return rnd() % 8 == 0 ? s : (s | ((uint32_t)(120 + rnd() % 30) << 23));
    case 4: return (uint32_t)rnd();
    default: return s | ((uint32_t)(127 + rnd() % 24) << 23) | (m & ~((1u << (rnd() % 23)) - 1));
    }
}
struct In { uint32_t a, b; bool sub; };

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    Vfp32_pipe_tb_top* t = new Vfp32_pipe_tb_top;
    size_t LAT = argc > 2 ? (size_t)atoi(argv[2]) : 4;   // issue -> readable, in clocks
    long n = argc > 1 ? atol(argv[1]) : 4000000;
    std::deque<In> q; long fa = 0, fm = 0, ca = 0, cm = 0;
    for (long i = 0; i < n + 4; i++) {
        In in{gen(), gen(), (rnd() & 1) != 0};
        if (rnd() % 4 == 0) in.b = in.a ^ (uint32_t)(rnd() & 3);       // near cancellation
        t->a = in.a; t->b = in.b; t->sub = in.sub;
        t->clk = 0; t->eval(); t->clk = 1; t->eval();
        q.push_back(in);
        if (q.size() == LAT) {          // after the edge ending cycle i+LAT-1 the op issued in cycle i is readable
            In o = q.front(); q.pop_front();
            float x = bf(o.a), y = bf(o.b);
            uint32_t wa = fb(_mm_cvtss_f32(o.sub ? _mm_sub_ss(_mm_set_ss(x), _mm_set_ss(y)) : _mm_add_ss(_mm_set_ss(x), _mm_set_ss(y))));
            uint32_t wm = fb(_mm_cvtss_f32(_mm_mul_ss(_mm_set_ss(x), _mm_set_ss(y))));
            bool ina = nz(o.a) && nz(o.b);
            bool cadd = ina && nz(wa) && (wa & 0x7f800000) != 0x7f800000;
            bool cmul = ina && nz(wm) && (wm & 0x7f800000) != 0x7f800000 && !((wm & 0x7fffffff) == 0 && (o.a & 0x7fffffff) && (o.b & 0x7fffffff));
            if (cadd) { ca++; if (t->add_exc || t->add_y != wa) { if (fa++ < 10) printf("FAIL add%s a %08X b %08X rtl %08X exc %u host %08X\n", o.sub ? "(sub)" : "", o.a, o.b, t->add_y, t->add_exc, wa); } }
            else if (!t->add_exc) { if (fa++ < 10) printf("FAIL add: exc not raised a %08X b %08X host %08X\n", o.a, o.b, wa); }
            if (cmul) { cm++; if (t->mul_exc || t->mul_y != wm) { if (fm++ < 10) printf("FAIL mul a %08X b %08X rtl %08X exc %u host %08X\n", o.a, o.b, t->mul_y, t->mul_exc, wm); } }
            else if (!t->mul_exc) { if (fm++ < 10) printf("FAIL mul: exc not raised a %08X b %08X host %08X\n", o.a, o.b, wm); }
        }
    }
    printf("fp_add4 checked %ld fails %ld | fp_mul4 checked %ld fails %ld\n", ca, fa, cm, fm);
    printf("%s\n", (fa || fm) ? "FAIL" : "PASS");
    delete t; return (fa || fm) ? 1 : 0;
}
