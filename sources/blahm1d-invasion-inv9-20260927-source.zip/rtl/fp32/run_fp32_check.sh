#!/bin/bash
# Build + run the fp32_pkg differential check (Verilator) against host SSE. Build dir on H: scratch.
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/fp32/run_fp32_check.sh [vectors]
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/fp32
B="${ZSCRATCH:-/mnt/h/temp/zeus}/fp32-check-$$"; mkdir -p "$B"; cd "$B" || exit 2
verilator --cc --exe --build -O3 -j 8 --top-module fp32_tb_top -Wno-fatal -Wno-lint -Wno-style \
  -CFLAGS "-O2 -msse2 -mfpmath=sse -ffp-contract=off" \
  "$S/fp32_pkg.sv" "$S/fp32_tb_top.sv" "$S/fp32_check.cpp" -o fp32_check > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/fp32_check "${1:-4000000}"; rc=$?
cd /; rm -rf "$B"; exit $rc
