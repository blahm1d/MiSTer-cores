// Test wrapper for the latency-5 units: fp_add5 (add and sub) and fp_mul5, one new operand pair per clock each.
module fp32_pipe5_tb_top (
  input  logic clk,
  input  logic [31:0] a, b, input logic sub,
  output logic [31:0] add_y, mul_y, output logic add_exc, mul_exc
);
  fp_add5 u_add (.clk, .a, .b, .sub, .y(add_y), .exc(add_exc));
  fp_mul5 u_mul (.clk, .a, .b, .y(mul_y), .exc(mul_exc));
endmodule
