// Differential check of fp32_pkg (via fp32_tb_top) against the host's SSE scalar float ops -- the same arithmetic MAME
// runs on x86-64. Contract (ARCHITECTURE-MK4.md R2): exact on normal/zero operands with normal/zero results; anything
// else must raise exc. A vector outside the contract that does NOT raise exc is a failure too.
#include "Vfp32_tb_top.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cmath>
#include <limits>
#include <emmintrin.h>

static uint64_t rs = 0x9E3779B97F4A7C15ull;
static uint64_t rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static float bf(uint32_t b) { float f; memcpy(&f, &b, 4); return f; }
static uint32_t fb(float f) { uint32_t b; memcpy(&b, &f, 4); return b; }
static bool in_contract(uint32_t b) { uint32_t e = (b >> 23) & 0xff; return e != 0xff && !(e == 0 && (b & 0x7fffff)); }

// operands: mostly normal numbers over a wide but useful exponent range, plus structured edge cases
static uint32_t gen(int kind) {
    uint32_t s = (rnd() & 1) << 31, m = rnd() & 0x7fffff;
    switch (kind % 8) {
    case 0: return s | ((uint32_t)(100 + rnd() % 60) << 23) | m;             // renderer range
    case 1: return s | ((uint32_t)(1 + rnd() % 254) << 23) | m;              // full normal range
    case 2: return s | ((uint32_t)(127 + rnd() % 8) << 23) | (m & 0x7f0000); // short mantissas (cancellation/ties)
    case 3: return s | ((uint32_t)(120 + rnd() % 30) << 23);                 // powers of two
    case 4: return rnd() % 16 == 0 ? s : (s | ((uint32_t)(127 + rnd() % 24) << 23) | (m & ~((1u << (rnd() % 23)) - 1)));  // integers-ish, zeros
    case 5: return fb((float)(int32_t)(rnd() % 1000 - 500) + 0.5f);          // exact halves (round_coordinate ties)
    case 6: return s | ((uint32_t)(150 + rnd() % 12) << 23) | m;             // near 2^31
    default: return (uint32_t)rnd();                                          // anything (incl. specials)
    }
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    Vfp32_tb_top* t = new Vfp32_tb_top;
    long n = argc > 1 ? atol(argv[1]) : 2000000;
    const char* names[8] = {"add", "sub", "mul", "div", "i2f", "round_coord", "f2i_trunc", "cmp"};
    long fails[8] = {0}, checked[8] = {0}, excd[8] = {0};
    for (long i = 0; i < n; i++) {
        int op = (int)(rnd() % 8);
        uint32_t a = gen((int)rnd()), b = gen((int)rnd());
        if (op == 1 && rnd() % 4 == 0) b = a ^ (rnd() & 0x3);                 // near-cancellation
        if (op == 4) a = (uint32_t)rnd() >> (rnd() % 32) ^ ((rnd() & 1) ? 0x80000000u : 0);
        t->op = op; t->a = a; t->b = b; t->eval();
        uint32_t want = 0; bool contract = true;
        float fa = bf(a), fbv = bf(b);
        switch (op) {
        case 0: want = fb(_mm_cvtss_f32(_mm_add_ss(_mm_set_ss(fa), _mm_set_ss(fbv)))); contract = in_contract(a) && in_contract(b) && in_contract(want) && (want & 0x7f800000) != 0x7f800000; break;
        case 1: want = fb(_mm_cvtss_f32(_mm_sub_ss(_mm_set_ss(fa), _mm_set_ss(fbv)))); contract = in_contract(a) && in_contract(b) && in_contract(want) && (want & 0x7f800000) != 0x7f800000; break;
        // a ZERO product/quotient of two NONZERO operands is an underflow (the true result left the normal range), not
        // an in-contract zero: the unit must raise exc there
        case 2: want = fb(_mm_cvtss_f32(_mm_mul_ss(_mm_set_ss(fa), _mm_set_ss(fbv))));
                contract = in_contract(a) && in_contract(b) && in_contract(want) && (want & 0x7f800000) != 0x7f800000 &&
                           !((want & 0x7fffffff) == 0 && (a & 0x7fffffff) && (b & 0x7fffffff)); break;
        case 3: want = fb(_mm_cvtss_f32(_mm_div_ss(_mm_set_ss(fa), _mm_set_ss(fbv))));
                contract = in_contract(a) && in_contract(b) && (b & 0x7fffffff) && in_contract(want) && (want & 0x7f800000) != 0x7f800000 &&
                           !((want & 0x7fffffff) == 0 && (a & 0x7fffffff)); break;
        case 4: want = fb(_mm_cvtss_f32(_mm_cvtsi32_ss(_mm_setzero_ps(), (int32_t)a))); break;
        case 5: {   // poly.h:368-381, verbatim in float
            float value = fa; int32_t r;
            if (!in_contract(a)) { contract = false; break; }
            if (value >= (float)std::numeric_limits<int32_t>::max()) r = std::numeric_limits<int32_t>::max();
            else { const float ipart = std::floor(value);
                   if (ipart < (float)std::numeric_limits<int32_t>::min()) r = std::numeric_limits<int32_t>::min();
                   else { const float fpart = value - ipart; r = (int32_t)ipart + ((fpart > 0.5f) ? 1 : 0); } }
            want = (uint32_t)r; break; }
        case 6: want = (uint32_t)_mm_cvtt_ss2si(_mm_set_ss(fa)); contract = in_contract(a); break;
        case 7: { if (!in_contract(a) || !in_contract(b)) { contract = false; break; }
                  uint32_t c = ((fa < fbv) << 2) | ((fa == fbv) << 1) | (fa > fbv); want = c;
                  if ((uint32_t)t->cmp != c) { if (fails[7]++ < 10) printf("FAIL cmp a %08X b %08X rtl %u host %u\n", a, b, t->cmp, c); }
                  checked[7]++; continue; }
        }
        if (!contract) {
            // outside the contract the unit must say so (when the operands or the true result leave it)
            if (op != 4 && op != 7 && !t->exc) {
                // results that are exactly representable normals despite a special INPUT class would be a contract hole
                if (!(in_contract(a) && in_contract(b))) { if (fails[op]++ < 10) printf("FAIL %s: exc not raised for special operand a %08X b %08X\n", names[op], a, b); }
                else if (!in_contract(want) || (want & 0x7f800000) == 0x7f800000 || (want & 0x7fffffff) == 0) { if (fails[op]++ < 10) printf("FAIL %s: exc not raised for result %08X a %08X b %08X\n", names[op], want, a, b); }
            }
            excd[op]++; continue;
        }
        checked[op]++;
        if (t->exc || t->r != want) {
            if (fails[op]++ < 10) printf("FAIL %s a %08X b %08X: rtl %08X exc %u, host %08X\n", names[op], a, b, t->r, t->exc, want);
        }
    }
    long tf = 0;
    for (int op = 0; op < 8; op++) { printf("%-12s checked %9ld outside-contract %8ld fails %ld\n", names[op], checked[op], excd[op], fails[op]); tf += fails[op]; }
    printf("%s: %ld vectors\n", tf ? "FAIL" : "PASS", n);
    delete t;
    return tf ? 1 : 0;
}
