// fp32_pkg.sv -- IEEE-754 binary32 arithmetic for the Zeus 1 setup engine, bit-exact to x86 SSE scalar ops
// (addss/subss/mulss/divss/cvtsi2ss, round-to-nearest-even, MXCSR default: no FTZ/DAZ) on the value classes the MK4
// renderer USES: normal numbers and signed zeros (tap census, ARCHITECTURE-MK4.md R2: 0 NaN/inf/denormal on any used
// extent). Anything outside that contract raises `exc` (denormal input, denormal/underflow result, overflow, inf/NaN
// operand) so a gate FAILS loudly instead of trusting an unmodelled result. Combinational reference functions; the
// setup datapath registers around them (and fp32_rcp.sv is the iterative divider for synthesis).
package fp32_pkg;

  typedef struct packed { logic [31:0] v; logic exc; } fres_t;

  function automatic logic is_special(input logic [31:0] a);  // inf / NaN / denormal
    return (a[30:23] == 8'hff) || (a[30:23] == 8'h00 && a[22:0] != 23'd0);
  endfunction
  function automatic logic is_zero(input logic [31:0] a);
    return a[30:0] == 31'd0;
  endfunction

  // count leading zeros of a 27-bit value (27 when zero)
  function automatic logic [4:0] clz27(input logic [26:0] x);
    logic [4:0] n; n = 5'd27;
    for (int i = 0; i < 27; i++) if (x[i]) n = 5'(26 - i);
    return n;
  endfunction
  function automatic logic [5:0] clz32(input logic [31:0] x);
    logic [5:0] n; n = 6'd32;
    for (int i = 0; i < 32; i++) if (x[i]) n = 6'(31 - i);
    return n;
  endfunction

  // pack sign / biased exponent (may be out of range) / 27-bit normalised significand {1.m, g, r, s} with RNE
  function automatic fres_t round_pack(input logic s, input logic signed [10:0] e, input logic [26:0] S);
    fres_t r; logic inc; logic [24:0] M; logic signed [10:0] ee;
    inc = S[2] & (S[1] | S[0] | S[3]);
    M = {1'b0, S[26:3]} + 25'(inc);
    ee = e;
    if (M[24]) begin M = M >> 1; ee = ee + 11'sd1; end
    r.exc = 1'b0;
    if (ee >= 11'sd255) begin r.v = {s, 8'hff, 23'd0}; r.exc = 1'b1; end          // overflow -> inf (outside contract)
    else if (ee <= 11'sd0) begin r.v = {s, 31'd0}; r.exc = 1'b1; end              // underflow -> would be denormal
    else r.v = {s, ee[7:0], M[22:0]};
    return r;
  endfunction

  // ---------------- a + b (sub: flip b's sign) ----------------
  function automatic fres_t fp_add(input logic [31:0] a, input logic [31:0] b);
    fres_t r; logic sx, sy, sr; logic [7:0] ex, ey; logic [23:0] mx, my; logic [7:0] d;
    logic [49:0] yw; logic [26:0] X, Y, S; logic [27:0] sum; logic [4:0] lz; logic signed [10:0] e;
    r.exc = 1'b0;
    if (is_special(a) || is_special(b)) begin r.v = 32'hffc00000; r.exc = 1'b1; return r; end
    if (is_zero(a) && is_zero(b)) begin r.v = {a[31] & b[31], 31'd0}; return r; end     // RNE: +0 unless both -0
    if (is_zero(a)) begin r.v = b; return r; end
    if (is_zero(b)) begin r.v = a; return r; end
    // order by magnitude: x = larger
    if (a[30:0] >= b[30:0]) begin sx = a[31]; ex = a[30:23]; mx = {1'b1, a[22:0]}; sy = b[31]; ey = b[30:23]; my = {1'b1, b[22:0]}; end
    else begin sx = b[31]; ex = b[30:23]; mx = {1'b1, b[22:0]}; sy = a[31]; ey = a[30:23]; my = {1'b1, a[22:0]}; end
    d = ex - ey;
    X = {mx, 3'b000};
    yw = {my, 26'd0} >> ((d > 8'd50) ? 8'd50 : d);
    Y = {yw[49:24], |yw[23:0]};                                // 26 bits + sticky of everything shifted out
    e = 11'(ex);
    if (sx == sy) begin
      sum = {1'b0, X} + {1'b0, Y};
      if (sum[27]) begin S = {sum[27:2], sum[1] | sum[0]}; e = e + 11'sd1; end
      else S = sum[26:0];
      sr = sx;
    end else begin
      S = X - Y;
      if (S == 27'd0) begin r.v = 32'h00000000; return r; end   // exact cancellation: +0 under RNE
      lz = clz27(S);
      S = S << lz; e = e - 11'(lz);
      sr = sx;
    end
    return round_pack(sr, e, S);
  endfunction

  // ---------------- fp_add split into three pipeline stages (identical result to fp_add) ----------------
  // stage 1: classify, order by magnitude, align (with sticky)
  typedef struct packed {
    logic done; logic [31:0] dv; logic dexc;        // result already decided (special / zero cases)
    logic sx, sy; logic [7:0] ex; logic [26:0] X, Y;
  } fadd1_t;
  function automatic fadd1_t fp_add_s1(input logic [31:0] a, input logic [31:0] b);
    fadd1_t o; logic [23:0] mx, my; logic [7:0] ey, d; logic [49:0] yw;
    o = '0;
    if (is_special(a) || is_special(b)) begin o.done = 1'b1; o.dv = 32'hffc00000; o.dexc = 1'b1; return o; end
    if (is_zero(a) && is_zero(b)) begin o.done = 1'b1; o.dv = {a[31] & b[31], 31'd0}; return o; end
    if (is_zero(a)) begin o.done = 1'b1; o.dv = b; return o; end
    if (is_zero(b)) begin o.done = 1'b1; o.dv = a; return o; end
    if (a[30:0] >= b[30:0]) begin o.sx = a[31]; o.ex = a[30:23]; mx = {1'b1, a[22:0]}; o.sy = b[31]; ey = b[30:23]; my = {1'b1, b[22:0]}; end
    else begin o.sx = b[31]; o.ex = b[30:23]; mx = {1'b1, b[22:0]}; o.sy = a[31]; ey = a[30:23]; my = {1'b1, a[22:0]}; end
    d = o.ex - ey;
    o.X = {mx, 3'b000};
    yw = {my, 26'd0} >> ((d > 8'd50) ? 8'd50 : d);
    o.Y = {yw[49:24], |yw[23:0]};
    return o;
  endfunction
  // stage 1 split in two for timing (fp_add5): 1a classify / order / exponent difference, 1b align
  typedef struct packed {
    logic done; logic [31:0] dv; logic dexc;
    logic sx, sy; logic [7:0] ex, d; logic [23:0] mx, my;
  } fadd0_t;
  function automatic fadd0_t fp_add_s1a(input logic [31:0] a, input logic [31:0] b);
    fadd0_t o; logic [7:0] ey;
    o = '0;
    if (is_special(a) || is_special(b)) begin o.done = 1'b1; o.dv = 32'hffc00000; o.dexc = 1'b1; return o; end
    if (is_zero(a) && is_zero(b)) begin o.done = 1'b1; o.dv = {a[31] & b[31], 31'd0}; return o; end
    if (is_zero(a)) begin o.done = 1'b1; o.dv = b; return o; end
    if (is_zero(b)) begin o.done = 1'b1; o.dv = a; return o; end
    if (a[30:0] >= b[30:0]) begin o.sx = a[31]; o.ex = a[30:23]; o.mx = {1'b1, a[22:0]}; o.sy = b[31]; ey = b[30:23]; o.my = {1'b1, b[22:0]}; end
    else begin o.sx = b[31]; o.ex = b[30:23]; o.mx = {1'b1, b[22:0]}; o.sy = a[31]; ey = a[30:23]; o.my = {1'b1, a[22:0]}; end
    o.d = o.ex - ey;
    return o;
  endfunction
  function automatic fadd1_t fp_add_s1b(input fadd0_t i);
    fadd1_t o; logic [49:0] yw;
    o = '0; o.done = i.done; o.dv = i.dv; o.dexc = i.dexc; o.sx = i.sx; o.sy = i.sy; o.ex = i.ex;
    if (i.done) return o;
    o.X = {i.mx, 3'b000};
    yw = {i.my, 26'd0} >> ((i.d > 8'd50) ? 8'd50 : i.d);
    o.Y = {yw[49:24], |yw[23:0]};
    return o;
  endfunction

  // ---- shift-by-multiply forms (map the variable shifters to DSP one-hot multiplies) ----
  // The align right-shift {my,26'd0} >> d equals my << (26-d) for d in [0,26]; the left factor is a
  // one-hot power of two so the product maps to a Cyclone V 27x27 DSP (multstyle="dsp" on the module
  // product signal). Bit-exact to fp_add_s1b: same 26-bit field + sticky, same clamp at 50.
  // fp_align_pow: the one-hot multiplicand for the align (d clamped to 0..26).
  function automatic logic [26:0] fp_align_pow(input logic [7:0] d);
    logic [5:0] k;
    k = (d >= 8'd26) ? 6'd0 : (6'd26 - 6'(d));   // d used here only when d<26 -> k=26-d in [1,26]
    return (27'd1 << k);
  endfunction
  // build fadd1 from the ordered fadd0 plus the align product prod = my << (26-min(d,26)).
  // For d in [27,49] every significand bit lands strictly below the 26-bit field => Y = sticky only (1,
  // because my has bit23 set); for d>=50 (clamp) the field is empty => Y = 0. Identical to fp_add_s1b.
  function automatic fadd1_t fp_add_s1b_prod(input fadd0_t i, input logic [49:0] prod);
    fadd1_t o; logic [7:0] dc;
    o = '0; o.done = i.done; o.dv = i.dv; o.dexc = i.dexc; o.sx = i.sx; o.sy = i.sy; o.ex = i.ex;
    if (i.done) return o;
    o.X = {i.mx, 3'b000};
    dc = (i.d > 8'd50) ? 8'd50 : i.d;
    if (dc <= 8'd26)      o.Y = {prod[49:24], |prod[23:0]};
    else if (dc <= 8'd49) o.Y = 27'd1;
    else                  o.Y = 27'd0;
    return o;
  endfunction
  // stage 2: add / subtract, leading-zero count
  typedef struct packed {
    logic done; logic [31:0] dv; logic dexc;
    logic s; logic signed [10:0] e; logic [26:0] S; logic [4:0] lz; logic sub;
  } fadd2_t;
  function automatic fadd2_t fp_add_s2(input fadd1_t i);
    fadd2_t o; logic [27:0] sum;
    o = '0; o.done = i.done; o.dv = i.dv; o.dexc = i.dexc; o.s = i.sx; o.e = 11'(i.ex);
    if (i.done) return o;
    if (i.sx == i.sy) begin
      sum = {1'b0, i.X} + {1'b0, i.Y};
      if (sum[27]) begin o.S = {sum[27:2], sum[1] | sum[0]}; o.e = o.e + 11'sd1; end
      else o.S = sum[26:0];
      o.lz = 5'd0;
    end else begin
      o.S = i.X - i.Y; o.sub = 1'b1;
      if (o.S == 27'd0) begin o.done = 1'b1; o.dv = 32'h00000000; return o; end
      o.lz = clz27(o.S);
    end
    return o;
  endfunction
  // stage 3: normalise, round, pack
  function automatic fres_t fp_add_s3(input fadd2_t i);
    fres_t r;
    if (i.done) begin r.v = i.dv; r.exc = i.dexc; return r; end
    return round_pack(i.s, i.e - 11'(i.lz), i.S << i.lz);
  endfunction
  // normalise left-shift S << lz expressed as S * (1<<lz); Snorm is the low 27 bits of that product.
  // Bit-exact to fp_add_s3 (which passes (i.S << i.lz) as a 27-bit value to round_pack).
  function automatic fres_t fp_add_s3_prod(input fadd2_t i, input logic [26:0] Snorm);
    fres_t r;
    if (i.done) begin r.v = i.dv; r.exc = i.dexc; return r; end
    return round_pack(i.s, i.e - 11'(i.lz), Snorm);
  endfunction

  // ---------------- fp_mul split: classify + multiply (DSP) | normalise + round ----------------
  typedef struct packed { logic done; logic [31:0] dv; logic dexc; logic s; logic signed [10:0] e; } fmul1_t;
  function automatic fmul1_t fp_mul_s1(input logic [31:0] a, input logic [31:0] b);
    fmul1_t o; o = '0; o.s = a[31] ^ b[31];
    if (is_special(a) || is_special(b)) begin o.done = 1'b1; o.dv = 32'hffc00000; o.dexc = 1'b1; return o; end
    if (is_zero(a) || is_zero(b)) begin o.done = 1'b1; o.dv = {o.s, 31'd0}; return o; end
    o.e = 11'(a[30:23]) + 11'(b[30:23]) - 11'sd127;
    return o;
  endfunction
  function automatic fres_t fp_mul_s2(input fmul1_t i, input logic [47:0] P);
    fres_t r; logic [26:0] S; logic signed [10:0] e;
    if (i.done) begin r.v = i.dv; r.exc = i.dexc; return r; end
    e = i.e;
    if (P[47]) begin S = {P[47:22], |P[21:0]}; e = e + 11'sd1; end
    else S = {P[46:21], |P[20:0]};
    return round_pack(i.s, e, S);
  endfunction

  // ---------------- (float) int for |x| < 2^15: the setup's scanline / pixel-column conversions ----------------
  function automatic fres_t fp_i2f16(input logic signed [15:0] x);
    fres_t r; logic s; logic [15:0] m; logic [4:0] lz; logic [15:0] n;
    r.exc = 1'b0;
    if (x == 16'sd0) begin r.v = 32'd0; return r; end
    s = x[15]; m = s ? 16'(-x) : 16'(x);
    lz = 5'd16; for (int i = 0; i < 16; i++) if (m[i]) lz = 5'(15 - i);
    n = m << lz;                                   // n[15] = 1; exact (<= 16 significant bits)
    r.v = {s, 8'(8'd142 - 8'(lz)), n[14:0], 8'd0}; // 127 + 15 - lz
    return r;
  endfunction

  // ---------------- a * b ----------------
  function automatic fres_t fp_mul(input logic [31:0] a, input logic [31:0] b);
    fres_t r; logic s; logic [47:0] P; logic [26:0] S; logic signed [10:0] e;
    r.exc = 1'b0;
    s = a[31] ^ b[31];
    if (is_special(a) || is_special(b)) begin r.v = 32'hffc00000; r.exc = 1'b1; return r; end
    if (is_zero(a) || is_zero(b)) begin r.v = {s, 31'd0}; return r; end
    P = {1'b1, a[22:0]} * {1'b1, b[22:0]};
    e = 11'(a[30:23]) + 11'(b[30:23]) - 11'sd127;
    if (P[47]) begin S = {P[47:22], |P[21:0]}; e = e + 11'sd1; end
    else S = {P[46:21], |P[20:0]};
    return round_pack(s, e, S);
  endfunction

  // ---------------- a / b (the renderer only divides 1.0 and 512.0 by a value; general anyway) ----------------
  function automatic fres_t fp_div(input logic [31:0] a, input logic [31:0] b);
    fres_t r; logic s; logic [49:0] num; logic [23:0] den; logic [49:0] q; logic [23:0] rem; logic [26:0] S;
    logic signed [10:0] e;
    r.exc = 1'b0;
    s = a[31] ^ b[31];
    if (is_special(a) || is_special(b) || is_zero(b)) begin r.v = {s, 8'hff, 23'd0}; r.exc = 1'b1; return r; end
    if (is_zero(a)) begin r.v = {s, 31'd0}; return r; end
    num = {1'b1, a[22:0], 26'd0};              // ma * 2^26
    den = {1'b1, b[22:0]};
    q = num / den; rem = 24'(num % den);        // q in (2^25, 2^27)
    e = 11'(a[30:23]) - 11'(b[30:23]) + 11'sd127;
    if (q[26]) S = {q[26:1], q[0] | (rem != 24'd0)};
    else begin S = {q[25:0], rem != 24'd0}; e = e - 11'sd1; end
    return round_pack(s, e, S);
  endfunction

  // ---------------- (float) int32, cvtsi2ss ----------------
  function automatic fres_t fp_i2f(input logic signed [31:0] x);
    fres_t r; logic s; logic [31:0] m; logic [5:0] lz; logic [31:0] n; logic [26:0] S; logic signed [10:0] e;
    r.exc = 1'b0;
    if (x == 32'sd0) begin r.v = 32'd0; return r; end
    s = x[31]; m = s ? 32'(-x) : 32'(x);
    lz = clz32(m); n = m << lz;                 // n[31] = 1
    e = 11'sd158 - 11'(lz);                     // 127 + 31 - lz
    S = {n[31:6], |n[5:0]};
    return round_pack(s, e, S);
  endfunction

  // ---------------- a < b, a > b, a == b (ordered; +0 == -0) ----------------
  function automatic logic signed [32:0] fkey(input logic [31:0] a);   // monotonic integer key
    if (is_zero(a)) return 33'sd0;
    return a[31] ? -$signed({2'b00, a[30:0]}) : $signed({2'b00, a[30:0]});
  endfunction
  function automatic logic fp_lt(input logic [31:0] a, input logic [31:0] b); return fkey(a) < fkey(b); endfunction
  function automatic logic fp_gt(input logic [31:0] a, input logic [31:0] b); return fkey(a) > fkey(b); endfunction
  function automatic logic fp_eq(input logic [31:0] a, input logic [31:0] b); return fkey(a) == fkey(b); endfunction

  // ---------------- poly.h:368-381 round_coordinate: saturate, floor, +1 if the fraction is > 0.5 ----------------
  // Exact in fixed point: value = 1.m * 2^(e-127). 64-bit magnitude with 32 fraction bits + a sticky of the rest.
  function automatic logic signed [31:0] fp_round_coord(input logic [31:0] a, output logic exc);
    logic s; logic [7:0] e; logic [63:0] mag; logic sticky; logic [31:0] ip, fr; int sh;
    logic signed [32:0] fl; logic up;
    exc = is_special(a);
    if (is_zero(a) || is_special(a)) return 32'sd0;
    s = a[31]; e = a[30:23];
    if (!s && e >= 8'd158) return 32'sh7fffffff;                 // value >= 2^31
    if (s && (e > 8'd158 || (e == 8'd158 && a[22:0] != 23'd0))) return 32'sh80000000;   // value < -2^31
    // mag = 1.m * 2^(e-127) in 32.32 fixed: 24-bit significand at bit position (e - 127 - 23 + 32) = e - 118
    sh = int'(e) - 118;
    if (sh >= 0) begin mag = 64'({1'b1, a[22:0]}) << sh; sticky = 1'b0; end
    else if (sh > -24) begin mag = 64'({1'b1, a[22:0]}) >> (-sh); sticky = (({1'b1, a[22:0]} & ((24'd1 << (-sh)) - 24'd1)) != 24'd0); end
    else begin mag = 64'd0; sticky = 1'b1; end
    ip = mag[63:32]; fr = mag[31:0];
    if (!s) begin
      fl = $signed({1'b0, ip});
      up = fr[31] && (fr[30:0] != 31'd0 || sticky);
    end else begin
      if (fr == 32'd0 && !sticky) begin fl = -$signed({1'b0, ip}); up = 1'b0; end
      else begin
        fl = -$signed({1'b0, ip}) - 33'sd1;
        up = (fr < 32'h80000000);                                   // 1 - (fr + eps) > 1/2  <=>  fr + eps < 1/2
      end
    end
    return 32'(fl + (up ? 33'sd1 : 33'sd0));
  endfunction

  // ---------------- float -> int32 truncation (cvttss2si; out of range -> 0x80000000) ----------------
  function automatic logic signed [31:0] fp_f2i_trunc(input logic [31:0] a, output logic exc);
    logic [7:0] e; logic [55:0] mag; logic [31:0] t; int sh;
    exc = is_special(a);
    if (is_zero(a) || is_special(a)) return is_zero(a) ? 32'sd0 : 32'sh80000000;
    e = a[30:23];
    if (e >= 8'd158) return (a[31] && e == 8'd158 && a[22:0] == 23'd0) ? 32'sh80000000 : 32'sh80000000;
    if (e < 8'd127) return 32'sd0;
    sh = int'(e) - 127 - 23;
    if (sh >= 0) t = 32'({1'b1, a[22:0]} << sh); else t = 32'({1'b1, a[22:0]} >> (-sh));
    return a[31] ? -$signed(t) : $signed(t);
  endfunction

endpackage
