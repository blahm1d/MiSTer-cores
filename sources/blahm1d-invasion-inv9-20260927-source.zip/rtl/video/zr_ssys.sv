// zr_ssys.sv -- scanout + memsys (+ DDR gateway): the scanout gate's device under test. The scanout owns the sc port;
// the pixel-pipe ports (w0 / cw / cr) are driven by the bench as hostile background load; the front end is tied off.
module zr_ssys #(parameter logic [28:0] WR0_BASE = 29'h0600_0000, parameter logic [28:0] WR1_BASE = 29'h0610_0000) (
  input  logic        clk, rst,
  input  logic [31:0] disp_cc,
  // background load
  input  logic        w0_req, input logic [20:0] w0_line, output logic w0_gnt, output logic w0_rvalid,
  input  logic        cw_valid, output logic cw_ready, input logic [31:0] cw_addr, cw_data, input logic [1:0] cw_mask,
  input  logic [15:0] cw_z, input logic cw_zv,                   // ddr-fullbe: a pixel's depth lane (cw_zv low: the memsys reads the word)
  input  logic        cr_req, input logic [31:0] cr_addr, output logic cr_gnt, output logic cr_rvalid,
  // raster
  output logic        ce_pix, hs, vs, hblank, vblank, frame_start,
  output logic [14:0] rgb555, output logic [7:0] r, g, b,
  output logic [31:0] st_skip, st_late,
  // HPS DDR3
  output logic        av_read, av_write, output logic [28:0] av_address, output logic [7:0] av_burstcount,
  output logic [63:0] av_writedata, output logic [7:0] av_byteenable,
  input  logic        av_waitrequest, av_readdatavalid, input logic [63:0] av_readdata,
  output logic        idle, fault
);
  logic sc_req, sc_gnt, sc_rvalid, sc_rlast; logic [19:0] sc_word; logic [5:0] sc_beats; logic [63:0] sc_rdata;
  logic fm_gnt, fm_rvalid; logic [63:0] fm_rdata, w0_data; logic [15:0] cr_data;
  logic [31:0] st_m [4];
  zr_scanout u_s (.clk, .rst, .disp_cc, .sc_req, .sc_word, .sc_beats, .sc_gnt, .sc_rvalid, .sc_rlast, .sc_rdata,
    .ce_pix, .hs, .vs, .hblank, .vblank, .rgb555, .r, .g, .b, .frame_start, .st_skip, .st_late);
  zr_memsys #(.WR0_BASE(WR0_BASE), .WR1_BASE(WR1_BASE)) u_m (.clk, .rst,
    .fm_req(1'b0), .fm_we(1'b0), .fm_ram(1'b0), .fm_blk('0), .fm_lanes('0), .fm_wdata('0), .fm_gnt, .fm_rvalid, .fm_rdata,
    .w0_req, .w0_line, .w0_gnt, .w0_rvalid, .w0_data, .cw_valid, .cw_ready, .cw_addr, .cw_data, .cw_mask, .cw_z, .cw_zv,
    .cr_req, .cr_addr, .cr_gnt, .cr_rvalid, .cr_data,
    .sc_req, .sc_word, .sc_beats, .sc_gnt, .sc_rvalid, .sc_rlast, .sc_rdata,
    .av_read, .av_write, .av_address, .av_burstcount, .av_writedata, .av_byteenable, .av_waitrequest, .av_readdatavalid,
    .av_readdata, .idle, .fault,
    .st_wbursts(st_m[0]), .st_wbeats(st_m[1]), .st_flush_hz(st_m[2]), .st_wait_hz(st_m[3]));
endmodule
