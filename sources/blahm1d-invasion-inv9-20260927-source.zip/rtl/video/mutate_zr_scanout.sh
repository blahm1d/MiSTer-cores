#!/bin/bash
# zr_scanout mutation gate: every req mutant must FAIL tb_zr_ssys. usage: wsl bash mutate_zr_scanout.sh <evidence> [jobs]
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/video; EV="$1"; J="${2:-4}"
T=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}"); export T D EV
LIST="${ZSS_LIST:-$(grep -v "^#" $D/mutants_zr_scanout.txt | cut -f1 | tr "\n" " ")}"
one() { m="$1"; e=$(awk -F"\t" -v m="$m" '$1==m{print $3}' $D/mutants_zr_scanout.txt)
  ZSS_MUT="$e" timeout 1800 bash $D/run_zr_ssys.sh "$EV" 4 20 30 50 > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc"; }
export -f one
printf "%s\n" $LIST | xargs -P "$J" -I{} bash -c "one {}"
bad=0
for m in $LIST; do
  rc=$(cat "$T/$m.rc")
  if grep -q "DID NOT APPLY" "$T/$m.log"; then echo "$m NOT APPLIED"; bad=1; continue; fi
  if grep -q "BUILD FAILED" "$T/$m.log"; then echo "$m BUILD FAILED (not a kill)"; bad=1; continue; fi
  why=$(grep -m1 -E "DIFFERS|FAIL" "$T/$m.log" | cut -c1-110)
  if [ "$rc" = 0 ]; then echo "$m SURVIVED"; bad=1; else echo "$m killed [rc $rc]: $why"; fi
done
rm -rf "$T"; exit $bad
