// Scanout gate: zr_scanout + zr_memsys + DDR gateway -> C++ HPS DDR3 model, vs tools/scanout_golden.py (MAME
// screen_update transcribed independently). Per golden frame N: during vblank the bench stops background traffic,
// waits for the memsys to drain, loads wave RAM 1 = MAME's dump at boundary N, sets register 0xCC = the value in effect
// after N, then captures the next ACTIVE period off the raster outputs (ce_pix strobe, hblank / vblank) and compares
// all 400 x 256 pixels. Also checked: 400 active pixels per line, 256 active lines, 882,372 clocks per frame (529 x 278
// x 6 = MAME set_raw at 50 MHz / 6), zero skipped / late lines. Background load (pixel-pipe clients, hostile): colour
// writes into the OTHER buffer, colour reads, texture reads -- the scanout must hold its deadline under them.
// usage: tb_zr_ssys <render-evidence> <golden-dir> [frames] [ddr-lat] [waitrequest%] [load%]
#include "Vzr_ssys.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <deque>
#include <string>
#include <algorithm>
#include <zlib.h>
typedef uint64_t u64; typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8;
static u64 rs = 0x2545F4914F6CDD1Dull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static std::vector<u8> read_gz(const std::string& p) {
    std::vector<u8> out; gzFile f = gzopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    u8 buf[1 << 16]; int n; while ((n = gzread(f, buf, sizeof buf)) > 0) out.insert(out.end(), buf, buf + n); gzclose(f); return out;
}
static std::vector<u8> read_file(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); std::vector<u8> v(n);
    if (fread(v.data(), 1, n, f) != (size_t)n) exit(2); fclose(f); return v;
}

int main(int argc, char** argv) {
    if (argc < 3) { printf("usage: tb_zr_ssys <evidence> <golden-dir> [frames] [lat] [wait%%] [load%%]\n"); return 2; }
    std::string ev = argv[1], gd = argv[2];
    int maxf = argc > 3 ? atoi(argv[3]) : 1 << 30, DLAT = argc > 4 ? atoi(argv[4]) : 20, DWBP = argc > 5 ? atoi(argv[5]) : 30,
        LOAD = argc > 6 ? atoi(argv[6]) : 50;
    std::vector<std::pair<int, u32>> gl; {
        FILE* f = fopen((gd + "/cc.txt").c_str(), "r"); if (!f) { printf("FAIL: no golden cc.txt\n"); return 2; }
        int fr; unsigned cc; while (fscanf(f, "%d %x", &fr, &cc) == 2) gl.push_back({fr, cc}); fclose(f);
    }
    const u64 WR0 = 0x06000000ull, WR1 = 0x06100000ull; const size_t S0 = 64 * 1024, S1 = 2 * 1024 * 1024;
    std::vector<u8> ddr0(S0), ddr1(S1, 0);
    for (auto& v : ddr0) v = (u8)rnd();
    u64 oob = 0;
    auto dptr = [&](u64 wa) -> u8* {
        if (wa >= WR0 && (wa - WR0) * 8 + 8 <= S0) return &ddr0[(wa - WR0) * 8];
        if (wa >= WR1 && (wa - WR1) * 8 + 8 <= S1) return &ddr1[(wa - WR1) * 8];
        oob++; static u8 junk[8]; return junk;
    };
    Verilated::commandArgs(argc, argv);
    Vzr_ssys* t = new Vzr_ssys;
    struct Beat { u64 due, data; }; std::deque<Beat> rq; bool wb_on = false; u64 wb_addr = 0; unsigned wb_left = 0;
    u64 clocks = 0; bool load_on = false; u32 other = 0;
    bool w0_v = false, cr_v = false, cw_v = false;
    std::vector<u16> cap; cap.reserve(400 * 256);
    int run = 0; std::vector<int> runs; bool in_act = false; long lines_act = 0;
    bool fs = false;
    auto tick = [&]() {
        t->clk = 0;
        // background load: new requests only while enabled; a pending one is held until granted
        if (load_on) {
            if (!w0_v && (int)(rnd() % 100) < LOAD) { w0_v = true; t->w0_line = (u32)(rnd() % (S0 / 8)); }
            if (!cr_v && (int)(rnd() % 100) < LOAD / 2) { cr_v = true; t->cr_addr = (other + (u32)(rnd() % 65536)) * 8 + 2 * (rnd() % 2); }
            if (!cw_v && (int)(rnd() % 100) < LOAD) {
                cw_v = true; u32 y = rnd() % 256, x = rnd() % 200;
                t->cw_addr = (other + y * 256 + x) * 8; t->cw_data = (u32)rnd(); t->cw_mask = 1 + rnd() % 3;
            }
        }
        t->w0_req = w0_v; t->cr_req = cr_v; t->cw_valid = cw_v;
        t->av_readdatavalid = 0;
        if (!rq.empty() && rq.front().due <= clocks) { t->av_readdatavalid = 1; t->av_readdata = rq.front().data; rq.pop_front(); }
        t->av_waitrequest = (int)(rnd() % 100) < DWBP;
        t->eval();
        if (w0_v && t->w0_gnt) w0_v = false;
        if (cr_v && t->cr_gnt) cr_v = false;
        if (cw_v && t->cw_ready) cw_v = false;
        if (!t->av_waitrequest) {
            if (t->av_read) {
                u64 due = std::max<u64>(clocks + (u64)DLAT, rq.empty() ? 0 : rq.back().due + 1);
                for (unsigned k = 0; k < t->av_burstcount; k++) { u64 d; memcpy(&d, dptr(t->av_address + k), 8); rq.push_back({due + k, d}); }
            }
            if (t->av_write) {
                if (!wb_on) { wb_on = true; wb_addr = t->av_address; wb_left = t->av_burstcount; }
                u8* p = dptr(wb_addr); for (int b = 0; b < 8; b++) if (t->av_byteenable >> b & 1) p[b] = (u8)(t->av_writedata >> (8 * b));
                wb_addr++; if (--wb_left == 0) wb_on = false;
            }
        }
        if (t->fault) { printf("FAIL: gateway fault\n"); exit(1); }
        // raster capture (outputs registered: they are stable in the clk after ce)
        if (t->ce_pix) {
            bool act = !t->hblank && !t->vblank;
            if (act) { cap.push_back(t->rgb555); run++; in_act = true; }
            else if (in_act) { runs.push_back(run); run = 0; in_act = false; lines_act++; }
        }
        fs = t->frame_start;
        t->eval(); t->clk = 1; t->eval(); clocks++;
    };
    t->rst = 1; t->disp_cc = gl.empty() ? 0 : gl[0].second; t->w0_req = t->cr_req = t->cw_valid = 0;
    for (int i = 0; i < 4; i++) tick(); t->rst = 0;
    auto wait_fs = [&]() { u64 g = 0; do { tick(); if (++g > 4000000) { printf("FAIL: no frame_start\n"); exit(1); } } while (!fs); return g; };
    wait_fs();
    int ok = 0, bad = 0, nfr = 0; u64 per_frame_bad = 0;
    for (auto& [fr, cc] : gl) {
        if (nfr >= maxf) break;
        // vblank: quiesce background load, drain, load MAME's wave RAM 1 at boundary N, set 0xCC
        u64 t0 = clocks; load_on = false;
        { u64 g = 0; while (w0_v || cr_v || cw_v || !t->idle) { tick(); if (++g > 4000000) { printf("FAIL: memsys never idle\n"); return 1; } } }
        if (clocks - t0 > 21ull * 529 * 6) { printf("FAIL: harness drain took %llu clocks, past the line-0 fetch\n", (unsigned long long)(clocks - t0)); return 1; }
        char nm[512]; snprintf(nm, sizeof nm, "%s/frame_%05d_0_m_waveram_1_.bin.gz", ev.c_str(), fr);
        std::vector<u8> m = read_gz(nm); if (m.size() != S1) { printf("FAIL: dump size %zu\n", m.size()); return 2; }
        ddr1 = m; t->disp_cc = cc;
        u32 blk = (cc % 512) + ((cc >> 16) % 512) * 512; other = blk ^ 0x10000;
        load_on = true;
        cap.clear(); runs.clear(); run = 0; in_act = false; lines_act = 0;
        u64 f0 = clocks; wait_fs(); u64 period = clocks - f0 + (f0 - t0);
        nfr++;
        char gn[512]; snprintf(gn, sizeof gn, "%s/frame_%05d.rgb555", gd.c_str(), fr);
        std::vector<u8> g = read_file(gn);
        u64 diff = 0; long first = -1;
        bool shape = cap.size() == 400 * 256 && runs.size() == 256 && std::all_of(runs.begin(), runs.end(), [](int r) { return r == 400; });
        if (shape) for (size_t i = 0; i < cap.size(); i++) { u16 v; memcpy(&v, &g[2 * i], 2); if (v != cap[i]) { diff++; if (first < 0) first = (long)i; } }
        bool good = shape && diff == 0 && period == 882372ull;
        if (good) ok++; else bad++;
        printf("frame %d (cc %08X): %s -- %zu pixels in %zu lines, %llu differ, frame period %llu clocks\n", fr, cc,
               good ? "IDENTICAL" : "DIFFERS", cap.size(), runs.size(), (unsigned long long)diff, (unsigned long long)period);
        if (first >= 0) { u16 v; memcpy(&v, &g[2 * first], 2); printf("  first diff y %ld x %ld: rtl %04X MAME %04X\n", first / 400, first % 400, cap[first], v); }
        per_frame_bad += diff;
    }
    printf("SCANOUT lines skipped %u, displayed before fetched %u; DDR out-of-range %llu (latency %d, waitrequest %d%%, load %d%%)\n",
           t->st_skip, t->st_late, (unsigned long long)oob, DLAT, DWBP, LOAD);
    bool pass = bad == 0 && ok > 0 && t->st_skip == 0 && t->st_late == 0 && oob == 0;
    printf("%s: %d of %d frames bit-exact vs MAME screen_update (400 x 256, RGB555), raster timing = set_raw\n", pass ? "PASS" : "FAIL", ok, ok + bad);
    delete t; return pass ? 0 : 1;
}
