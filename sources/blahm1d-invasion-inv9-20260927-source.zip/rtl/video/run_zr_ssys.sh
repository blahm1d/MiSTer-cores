#!/bin/bash
# Scanout gate (zr_scanout + zr_memsys + gateway + DDR model vs tools/scanout_golden.py).
# usage: wsl bash run_zr_ssys.sh <render-evidence> [frames] [ddr-lat] [waitrequest%] [load%]
# The golden is (re)built into $ZSCRATCH/scanout-golden/<window> when missing. ZSS_MUT=sed-expression mutates zr_scanout.sv.
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl; Z="${ZSCRATCH:-/mnt/h/temp/zeus}"
EV="$1"; shift
GD="$Z/scanout-golden/$(basename "$EV")"
[ -f "$GD/cc.txt" ] || python3 /mnt/d/deck/fpga/zeus/zeus1/tools/scanout_golden.py "$EV" "$GD" || { echo "GOLDEN FAILED"; exit 2; }
B="$Z/zr-ssys-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC="$S/video/zr_scanout.sv"
if [ -n "${ZSS_MUT:-}" ]; then sed "$ZSS_MUT" "$SRC" > zr_scanout.sv; cmp -s zr_scanout.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zr_scanout.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zr_ssys -DZR_CENSUS -DZR_RDW_HOSTILE -Wno-fatal -Wno-lint -Wno-style -LDFLAGS -lz \
  "$S/setup/zr_sdp.sv" "$S/render/zr_fifo.sv" "$S/render/zr_rfifo.sv" "$S/memsys/zr_ddr_gateway.sv" "$S/memsys/zr_memsys.sv" \
  "$SRC" "$S/video/zr_ssys.sv" "$S/video/tb_zr_ssys.cpp" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$EV" "$GD" "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
