// zr_scanout.sv -- MK4 (Zeus 1) video scanout: wave RAM 1 display buffer -> 400 x 256 RGB555 raster at 15.75 kHz.
//
// Gospel (MAME 0.289): midzeus.cpp:1393 set_raw(66.6667 MHz / 8, 529, 0, 400, 278, 0, 256); midzeus_v.cpp:328-336
// screen_update dest[x] = WAVERAM_READPIX(base, y, x - xoffs) & 0x7fff with base = waveram1_ptr_from_expanded_addr(
// zeusbase[0xcc]) (:133-137: block = (a % 512) + ((a >> 16) % 512) * 512) and READPIX word (y << 10) | ((x & 0x1fe)
// << 1) | (x & 1) (:102). So visible pixel (y, x) is 64-bit wave-RAM-1 word block + y * 256 + x / 2, low 32 bits,
// half x & 1. The MK4 timing registers are constant (C6 = 0211007F: htotal 529, first visible column 127; C8: 256 lines;
// CA: vtotal 278 -- all 4 render windows), so the raster is fixed here, not programmable.
//
// Fit: one M10K line buffer (2 lines x 256 x 32 bits: the colour half of each word), registered read. A line is
// fetched during the line BEFORE it (7 sc bursts, 200 beats, ~3,174 clocks available); the display base is latched at
// each line's fetch -- exact for MK4, whose 0xCC writes all land in the first vblank line (tools/cc_write_timing.py).
// Pixel clock = clk / CE_DIV (50 MHz / 6 = 8.3333 MHz vs MAME 8.3333375 MHz, 5 ppm).
//
// ASSUMPTION (flagged): sync placement. MAME does not model the Zeus sync registers (C0 / C2 / C4), so HS / VS
// positions are parameters chosen for a 15 kHz CRT (front porch 12 px, sync 39 px = 4.7 us; vsync 3 lines).
module zr_scanout #(
  parameter int HTOTAL = 529, HACT = 400, HBEGIN = 127,          // visible columns HBEGIN .. HBEGIN+HACT-1
  parameter int VTOTAL = 278, VACT = 256,
  parameter int HS_BEGIN = 10, HS_W = 39,                        // counted in the blank run after column HBEGIN+HACT-1
  parameter int VS_BEGIN = 259, VS_W = 3,
  parameter int CE_DIV = 6
) (
  input  logic        clk, rst,
  input  logic [31:0] disp_cc,                                   // Zeus register 0xCC (display base, expanded address)
  // memsys scanout port (wave RAM 1 word addresses; grant = accepted when requested)
  output logic        sc_req, output logic [19:0] sc_word, output logic [5:0] sc_beats, input logic sc_gnt,
  input  logic        sc_rvalid, input logic sc_rlast, input logic [63:0] sc_rdata,
  // raster
  output logic        ce_pix, hs, vs, hblank, vblank,
  output logic [14:0] rgb555,
  output logic [7:0]  r, g, b,
  output logic        frame_start,                               // one clk at the first vblank line (MAME VBLANK)
  output logic [9:0]  beam_h, output logic [8:0] beam_v,         // raw counters = MAME screen hpos / vpos (Zeus reads 0xF0-0xF4)
  output logic [31:0] st_skip, st_late                           // lines not fetched / fetched after their display
);
  // ---------------- pixel clock + counters ----------------
  logic [$clog2(CE_DIV)-1:0] div;
  logic [9:0] hc; logic [8:0] vc;
  always_ff @(posedge clk)
    if (rst) begin div <= '0; hc <= '0; vc <= 9'(VACT); end
    else begin
      div <= (div == $clog2(CE_DIV)'(CE_DIV - 1)) ? '0 : div + 1'b1;
      if (div == $clog2(CE_DIV)'(CE_DIV - 1)) begin
        if (hc == 10'(HTOTAL - 1)) begin hc <= '0; vc <= (vc == 9'(VTOTAL - 1)) ? '0 : vc + 1'b1; end
        else hc <= hc + 1'b1;
      end
    end
  logic ce; assign ce = div == $clog2(CE_DIV)'(CE_DIV - 1);
  assign beam_h = hc; assign beam_v = vc;
  logic line_start; assign line_start = ce && hc == 10'(HTOTAL - 1);   // the next ce begins column 0 of the next line
  logic [8:0] vnext; assign vnext = (vc == 9'(VTOTAL - 1)) ? 9'd0 : vc + 1'b1;

  // ---------------- line fetch ----------------
  // during line L, fetch line L+1 (from vtotal-1, line 0); the buffer banks alternate by line parity, so the fetch
  // never writes the bank being displayed. line_start is the last ce of the current line: the fetch that starts there
  // runs during line vnext and targets the line after it (want).
  logic [8:0] ftgt;                                              // line being fetched
  logic       f_busy;                                            // responses still owed
  logic [7:0] f_left, r_left, wi;                                // beats to request / to receive, write index
  logic [19:0] f_word;
  logic        f_bank;
  logic [17:0] base_blk;
  assign base_blk = 18'(disp_cc[8:0]) + {disp_cc[24:16], 9'd0};
  logic [8:0] want; assign want = (vnext == 9'(VTOTAL - 1)) ? 9'd0 : vnext + 1'b1;   // line displayed after vnext
  // fetch target at the start of line vnext: the line that follows it on screen
  always_ff @(posedge clk)
    if (rst) begin f_left <= '0; r_left <= '0; f_busy <= 1'b0; st_skip <= '0; wi <= '0; ftgt <= '0; f_bank <= 1'b0; f_word <= '0; end
    else begin
      // handshakes always count; a new fetch starts only when nothing is owed (then no handshake can be in flight)
      if (sc_req && sc_gnt) begin f_word <= f_word + 20'(sc_beats); f_left <= f_left - 8'(sc_beats); end
      if (sc_rvalid) begin
        wi <= wi + 1'b1; r_left <= r_left - 1'b1;
        if (r_left == 8'd1) f_busy <= 1'b0;
      end
      if (line_start && want < 9'(VACT)) begin
        if (f_busy) st_skip <= st_skip + 1'b1;                   // previous line still arriving: this line is skipped
        else begin
          ftgt <= want; f_bank <= want[0];
          f_word <= 20'(base_blk) + {4'd0, want[7:0], 8'd0};
          f_left <= 8'(HACT / 2); r_left <= 8'(HACT / 2); wi <= '0; f_busy <= 1'b1;
        end
      end
    end
  assign sc_req = f_left != 0;
  assign sc_beats = (f_left >= 8'd32) ? 6'd32 : 6'(f_left);
  assign sc_word = f_word;

  // ---------------- line buffer: {bank, word} x 32 bits (colour half) ----------------
  logic [8:0] lb_ra; logic [31:0] lb_rd;
  zr_sdp #(32, 9) u_lb (.clk, .we(sc_rvalid), .waddr({f_bank, wi}), .wdata(sc_rdata[31:0]), .raddr(lb_ra), .rdata(lb_rd));

  // ---------------- raster: the address follows hc (changed at the previous ce); the registered line-buffer word is
  // valid one clk later, so at this ce it already belongs to column hc -- consume it in the SAME stage as hc's
  // controls (v1 paired it with the previous column's half select: every odd pixel took the next word) ----------------
  logic [9:0] xa; assign xa = hc - 10'(HBEGIN);
  logic act; assign act = hc >= 10'(HBEGIN) && hc < 10'(HBEGIN + HACT) && vc < 9'(VACT);
  logic [9:0] hb_end; assign hb_end = 10'(HBEGIN + HACT);         // first blank column after the active run
  logic [9:0] hrel; assign hrel = (hc >= hb_end) ? hc - hb_end : hc + 10'(HTOTAL) - hb_end;
  assign lb_ra = {vc[0], xa[8:1]};
  always_ff @(posedge clk)
    if (rst) begin hblank <= 1'b1; vblank <= 1'b1; hs <= 1'b0; vs <= 1'b0; rgb555 <= '0; end
    else if (ce) begin
      hblank <= !(hc >= 10'(HBEGIN) && hc < hb_end); vblank <= vc >= 9'(VACT);
      hs <= hrel >= 10'(HS_BEGIN) && hrel < 10'(HS_BEGIN + HS_W);
      vs <= vc >= 9'(VS_BEGIN) && vc < 9'(VS_BEGIN + VS_W);
      rgb555 <= act ? (xa[0] ? lb_rd[30:16] : lb_rd[14:0]) : 15'd0;
    end
  always_ff @(posedge clk) ce_pix <= ce;                          // outputs change on the clk after ce: strobe with them
  assign r = {rgb555[14:10], rgb555[14:12]};
  assign g = {rgb555[9:5], rgb555[9:7]};
  assign b = {rgb555[4:0], rgb555[4:2]};

  // ---------------- census ----------------
  // high for the first clk of (hpos 0, vpos VACT): MAME vblank_begin, the INT0 (display_irq) edge
  always_ff @(posedge clk) frame_start <= !rst && line_start && vnext == 9'(VACT);
  always_ff @(posedge clk)
    if (rst) st_late <= '0;
    else if (ce && hc == 10'(HBEGIN) && vc < 9'(VACT) && f_busy && ftgt == vc) st_late <= st_late + 1'b1;
endmodule
