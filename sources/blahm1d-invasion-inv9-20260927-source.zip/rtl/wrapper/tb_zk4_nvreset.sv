`timescale 1ns/1ps
// tb_zk4_nvreset -- gate for the two blocks behind the OSD Reset + CMOS save (2026-09-23):
//  A. zk4_cmos vs an independent flat model (byte[32768], true values, MAME DEFAULT_ALL_1 at power-on):
//     game-port byte writes/reads, host halfword writes (= NVRAM restore) and reads (= save): host row k is
//     {byte[2k+1], byte[2k]}; untouched bytes read 0xFF on both ports.
//  B. zk4_ram_reload vs midzeus machine_reset (midzeus.cpp:236-237): after start, RAM word k == ROM word k for
//     k = 1..LAST, RAM word 0 == ROM word 0 << 1, nothing else written, and the zk4_sdram glue rule held: a request is
//     never changed while waiting for its ack, and drops for >= 1 clock between transactions. Hostile ack latency.
// Verdict: last line PASS / FAIL.
module tb_zk4_nvreset;
  logic clk = 0; always #5 clk = ~clk;
  int errors = 0, checks = 0;

  // ---------------- A: zk4_cmos ----------------
  logic a_we, b_we; logic [14:0] a_addr; logic [7:0] a_d, a_q; logic [13:0] b_row; logic [15:0] b_d, b_q;
  zk4_cmos u_cmos (.clk, .a_we, .a_addr, .a_d, .a_q, .b_we, .b_row, .b_d, .b_q);
  byte unsigned model [32768];

  task automatic game_wr(input int a, input int d);
    @(negedge clk); a_we = 1; a_addr = 15'(a); a_d = 8'(d); @(negedge clk); a_we = 0; model[a] = 8'(d);
  endtask
  task automatic game_rd(input int a);
    @(negedge clk); a_addr = 15'(a); @(negedge clk); checks++;
    if (a_q !== model[a]) begin errors++; if (errors < 10) $display("FAIL cmos game read [%04h] = %02h, model %02h", a, a_q, model[a]); end
  endtask
  task automatic host_wr(input int k, input int d);
    @(negedge clk); b_we = 1; b_row = 14'(k); b_d = 16'(d); @(negedge clk); b_we = 0;
    model[2*k] = 8'(d); model[2*k+1] = 8'(d >> 8);
  endtask
  task automatic host_rd(input int k);
    @(negedge clk); b_row = 14'(k); @(negedge clk); checks++;
    if (b_q !== {model[2*k+1], model[2*k]}) begin errors++;
      if (errors < 10) $display("FAIL cmos host read row %04h = %04h, model %02h%02h", k, b_q, model[2*k+1], model[2*k]); end
  endtask

  // ---------------- B: zk4_ram_reload ----------------
  localparam int LAST = 511;                                     // bench-sized copy (the RTL default is 0x3FFFF)
  logic por, start, busy, sd_req, sd_we, sd_ack; logic [23:0] sd_addr; logic [31:0] sd_wdata, sd_rdata;
  zk4_ram_reload #(.LAST(18'(LAST))) u_rl (.clk, .por, .start, .busy, .sd_req, .sd_we, .sd_addr, .sd_wdata, .sd_ack, .sd_rdata);
  logic [31:0] rom [LAST+1]; logic [31:0] ram [LAST+1]; logic [31:0] ram_init [LAST+1];
  int stray = 0, glue = 0, txns = 0;
  // SDRAM port model: accepts a request after a random 0..7 clk delay, answers with ack (+ rdata) for one clock;
  // checks the request is held unchanged until ack and dropped for >= 1 clk afterwards.
  initial begin : sdram_model
    logic [23:0] ha; logic hw; logic [31:0] hd; int wait_n;
    sd_ack = 0; sd_rdata = 0;
    forever begin
      @(posedge clk); #1;
      if (sd_req) begin
        ha = sd_addr; hw = sd_we; hd = sd_wdata; wait_n = $urandom_range(0, 7);
        repeat (wait_n) begin @(posedge clk); #1; if (!sd_req || sd_addr != ha || sd_we != hw || (hw && sd_wdata != hd)) glue++; end
        txns++;
        if (hw) begin if (ha <= 24'(LAST)) ram[ha] = hd; else stray++; end
        else if (ha >= 24'hA00000 && ha <= 24'hA00000 + LAST) sd_rdata = rom[ha - 24'hA00000];
        else begin stray++; sd_rdata = 32'hDEADBEEF; end
        sd_ack = 1; @(posedge clk); #1; sd_ack = 0;
        if (sd_req) glue++;                                     // must drop right after its ack
      end
    end
  end

  initial begin
    a_we = 0; b_we = 0; a_addr = 0; a_d = 0; b_row = 0; b_d = 0; por = 1; start = 0;
    for (int i = 0; i < 32768; i++) model[i] = 8'hFF;
    repeat (4) @(negedge clk);
    // A1 power-on: every byte reads all ones on both ports (sampled)
    for (int i = 0; i < 400; i++) game_rd($urandom_range(0, 32767));
    for (int i = 0; i < 200; i++) host_rd($urandom_range(0, 16383));
    // A2 restore (host writes) then the game reads it; A3 game writes then save (host reads) sees them
    for (int i = 0; i < 3000; i++) host_wr($urandom_range(0, 16383), $urandom);
    for (int i = 0; i < 3000; i++) game_rd($urandom_range(0, 32767));
    for (int i = 0; i < 3000; i++) game_wr($urandom_range(0, 32767), $urandom);
    for (int i = 0; i < 3000; i++) host_rd($urandom_range(0, 16383));
    // A4 neighbours: adjacent even/odd bytes written separately keep each other
    for (int i = 0; i < 500; i++) begin int a; a = 2 * $urandom_range(0, 16383);
      game_wr(a, $urandom); game_wr(a + 1, $urandom); game_rd(a); game_rd(a + 1); host_rd(a / 2); end
    // A5 full sweep through the host port (a whole save)
    for (int k = 0; k < 16384; k++) host_rd(k);

    // B: reload, twice (a second reset re-copies over a dirtied RAM)
    for (int i = 0; i <= LAST; i++) begin rom[i] = $urandom; ram[i] = $urandom; end
    @(negedge clk); por = 0;
    for (int pass = 0; pass < 2; pass++) begin
      @(negedge clk); start = 1; @(negedge clk); start = 0;
      checks++; if (!busy) begin errors++; $display("FAIL reload: busy not raised by start"); end
      fork begin wait (!busy); end begin repeat (200000) @(posedge clk); end join_any disable fork;
      checks++; if (busy) begin errors++; $display("FAIL reload: never finished"); end
      for (int k = 0; k <= LAST; k++) begin checks++;
        if (ram[k] !== ((k == 0) ? {rom[0][30:0], 1'b0} : rom[k])) begin errors++;
          if (errors < 20) $display("FAIL reload RAM[%0d] = %08h, want %08h", k, ram[k], (k == 0) ? {rom[0][30:0], 1'b0} : rom[k]); end
      end
      for (int i = 0; i <= LAST; i++) ram[i] = $urandom;         // the game dirties RAM before the next reset
    end
    checks++; if (stray) begin errors++; $display("FAIL reload: %0d transfers outside ROM/RAM", stray); end
    checks++; if (glue) begin errors++; $display("FAIL reload: %0d glue-rule violations (request changed / not dropped)", glue); end
    checks++; if (txns != 2 * 2 * (LAST + 1)) begin errors++; $display("FAIL reload: %0d transfers, want %0d", txns, 4 * (LAST + 1)); end
    $display("NVRESET checks %0d errors %0d transfers %0d", checks, errors, txns);
    $display("%0s", errors == 0 ? "PASS" : "FAIL");
    $finish;
  end
endmodule
