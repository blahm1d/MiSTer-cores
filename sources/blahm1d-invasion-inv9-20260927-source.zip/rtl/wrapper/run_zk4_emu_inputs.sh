#!/bin/bash
# EMU-level input gate: the real zk4_emu + real sys/hps_io.sv + the whole zk4 core (Verilator --timing).
# hps_io.sv needs -Wno-PROCASSWIRE / -Wno-BLKANDNBLK under Verilator (implicit PS2 nets; mixed assignments in
# uio_block ps2skip / info_n / upload_req and video_calc) -- none on the joystick / status path this gate tests.
# usage: wsl bash run_zk4_emu_inputs.sh      ZEI_MUT=sed-expression mutates zk4_emu.sv (refuses if it did not apply)
set -u
Z=/mnt/d/deck/fpga/zeus; R=$Z/zeus1/rtl; Q=$Z/zeus1/quartus
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zk4-emu-in-$$"; mkdir -p "$B"; cd "$B" || exit 2
EMU="$R/wrapper/zk4_emu.sv"
if [ -n "${ZEI_MUT:-}" ]; then sed "$ZEI_MUT" "$EMU" > zk4_emu.sv; cmp -s zk4_emu.sv "$EMU" && { echo "MUTATION DID NOT APPLY"; exit 3; }; EMU=$B/zk4_emu.sv; fi
C=$Z/core/rtl/cpu
verilator --binary --timing -j 8 --top-module tb_zk4_emu_inputs -Wno-fatal -Wno-lint -Wno-style -Wno-PROCASSWIRE -Wno-BLKANDNBLK -I$Q -I$C \
  $Q/sys/hps_io.sv $R/wrapper/sim_bw1_pll.sv \
  $C/c31_core.sv $C/c31_ea.sv $C/c31_shift.sv $C/c31_mpyi.sv $C/c31_cond.sv $C/c31_addsubf.sv $C/c31_mpyf.sv \
  $C/c31_negf.sv $C/c31_absf.sv $C/c31_rnd.sv $C/c31_norm.sv $C/c31_int2float.sv $C/c31_float2int.sv $C/c31_fconv.sv \
  $R/tier/c31_page_cache.sv $R/tier/c31_page_cache_sa.sv $R/tier/c31_bus_adapter.sv $R/tier/zk4_memory_p3.sv $R/tier/zk4_memory_fp.sv \
  $R/fp32/fp32_pkg.sv $R/fp32/fp32_units.sv $R/setup/zr_sdp.sv $R/front/zr_front5.sv $R/setup/zr_setup9.sv \
  $R/pixel/zr_pixel10.sv $R/render/zr_fifo.sv $R/render/zr_rfifo.sv $R/render/zr_cmdq.sv $R/render/zr_render5.sv \
  $R/memsys/zr_ddr_gateway.sv $R/memsys/zr_memsys.sv $R/memsys/zr_rsys.sv \
  $R/video/zr_scanout.sv $R/core/zr_host1.sv $R/core/zk4_c32_ctl.sv \
  $R/board/zk4_pic2.sv $R/board/zk4_ioasic.sv $R/board/zk4_dcs_stub.sv $R/board/zk4_cmos.sv $R/board/zk4_board_io.sv $R/core/zk4_core.sv \
  $R/wrapper/donor/c31_sdram_burst.sv $R/wrapper/donor/c31_sdram_backing.sv $R/wrapper/zk4_sdram.sv \
  $R/wrapper/donor/gm1_hdmi_status.sv $R/wrapper/zk4_ddr_arb.sv $R/wrapper/zk4_status_mirror.sv $R/wrapper/zk4_ram_reload.sv \
  $R/wrapper/zk4_loader.sv $R/wrapper/zk4_top.sv $R/wrapper/zk4_audio_gain.sv "$EMU" $R/wrapper/tb_zk4_emu_inputs.sv -o tb > build.log 2>&1 \
  || { grep -m20 -E "%Error" build.log; echo "BUILD FAILED"; exit 2; }
# One run; verdict = the tb's own PASS line and no FAIL line (Verilator prints its "$finish" notice AFTER the PASS
# line, so a tail -1 verdict was always FAIL -- fixed 2026-09-23).
./obj_dir/tb > run.log 2>&1; trc=$?
grep -E "FAIL|PASS|EMU_INPUTS" run.log | head -40
if [ $trc = 0 ] && grep -qx "PASS" run.log && ! grep -q "^FAIL" run.log; then rc=0; else rc=1; fi
cd /; rm -rf "$B"; exit $rc
