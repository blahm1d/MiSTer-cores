`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// zk4_loader.sv -- maindata loader for the MK4 core: gm1_loader (cruisinusa/bandwidth/gm1/rtl, Cruis'n USA) forked
// to the MK4 layout (MAME 0.289 midzeus.cpp ROM_START(mk4) :1506-1525, machine_reset :234-243).
//
// Power-on-reset domain (P0022): MiSTer Main holds the core reset high through the ROM download, so the capture path
// must not use it; core_reset is only monitored.
//
// MRA rom index 1 is the maindata image in C32 word order, sent by hps_io WIDE=1 as 16-bit halfwords (low half of each
// 32-bit word first): 16 MiB = four ROM_LOAD32_WORD pairs (u10/u11 .. u16/u17, 2 MiB each) of the 24 MiB
// ROM_REGION32_LE. MAME leaves regions > 4 MiB uninitialised, which reads 0 (memory
// mame-large-rom-region-uninitialised; MK4 READS the hole, TSTB3 at 0xFFFFFF), so after the fills the loader writes 0
// to every ROM word the stream did not cover, up to the region's 6 M words.
// Word i lands in board SDRAM through zk4_sdram's loader port:
//   ROM   C32 0xa00000 + i -> SDRAM byte 0x0000000 + i*4
//   main  C32 0x000000 + i -> SDRAM byte 0x1800000 + i*4 for i <= 0x3ffff: main RAM boots as a copy of ROM words
//         0-0x3ffff with word 0 shifted left by one (memcpy + *m_ram_base <<= 1, midzeus.cpp:236-237)
// After the stream closes: fast RAM C32 0x400000-0x41ffff = 0, then `done` (the Cruis'n CMOS fill is parked on one
// unused word: MK4's CMOS lives in zk4_board_io). boot_pc = RAM word 0 = maindata word 0 << 1, the C32 reset vector
// (tms320c3x.cpp device_reset: m_pc = RMEM(0)).
// ioctl_wait comes only from FIFO high-water while the maindata capture is open, never after it closed (bw1 build 3
// cabinet lesson, bandwidth/bw1/rtl/core/bw1_rom_download.sv header); a halfword offered after close is dropped and
// counted. The FIFO read is asynchronous on purpose (64 x 16 bits, MLAB), with full/empty from registered pointers
// only (memory fifo-full-from-next-pointer-is-a-comb-loop).
// CMOS seed (MRA rom index 3, placed BEFORE index 1 in the MRA so Main sends it first). 32 KiB =
// 8192 C31 words, byte-for-byte a MAME nvram image that scripts/verify_cmos_seed.py proved boots
// crusnusa44 into attract, where an all-ones CMOS lands on CALIBRATE CONTROLS. Without it the game
// demands ENTER on that screen at every power-on, and ENTER is the 11th J1 button -- past the end of
// a normal pad. Seed halfwords are captured into their own FIFO and drained to CMOS with priority in
// D_LO; a COMPLETE seed then suppresses the all-ones fill in D_CMOS (a partial one does not, so a
// dropped seed still leaves MAME's documented fresh state rather than a half-written one).
module zk4_loader #(
    parameter [7:0]  IOCTL_SEED_INDEX = 8'hFE,         // MK4: no CMOS seed into SDRAM (CMOS is in zk4_board_io)
    parameter [31:0] SEED_WORDS     = 32'h0000_2000,   // 8192 words = 32 KiB
    parameter [7:0]  IOCTL_INDEX    = 8'd1,
    parameter [31:0] EXPECTED_WORDS = 32'h0040_0000,   // MK4: 16 MiB of ROMs in the 24 MiB maindata region
    parameter [24:0] MAIN_BASE      = 25'h1800000,    // MK4 zk4_sdram map
    parameter [24:0] FAST_BASE      = 25'h1900000,
    parameter [24:0] CMOS_BASE      = 25'h1A00000,    // MK4: an unused word (the one-word CMOS fill lands here)
    parameter [21:0] BOOT_LAST      = 22'h03ffff,    // MK4: memcpy 0x40000 words (midzeus.cpp:236)
    parameter bit    BOOT_SHIFT     = 1'b1,           // MK4: *m_ram_base <<= 1 (midzeus.cpp:237): RAM word 0 and boot_pc
    parameter [16:0] FAST_LAST      = 17'h1ffff,
    parameter [16:0] CMOS_LAST      = 17'h00000
) (
    input  wire        clk,
    input  wire        por,
    input  wire        core_reset,

    input  wire        ioctl_download,
    input  wire        ioctl_wr,
    input  wire [15:0] ioctl_index,
    input  wire [15:0] ioctl_dout,
    output wire        ioctl_wait,

    // gm1_sdram loader port: hold l_req until l_ack; the request drops for one clock between writes
    output reg         l_req,
    output reg  [24:0] l_baddr,
    output reg  [31:0] l_wdata,
    input  wire        l_ack,

    output reg         done,
    output reg  [23:0] boot_pc,
    output reg  [31:0] words_loaded,
    output reg  [31:0] stream_crc,
    output reg  [31:0] dropped_halfwords,
    output reg         stream_seen,
    output reg         stream_closed,
    output wire        size_ok,
    output reg         reset_during_download,
    output reg  [31:0] seed_words,          // CMOS seed words written to SDRAM
    output reg  [31:0] seed_dropped,        // seed halfwords offered while its FIFO was full
    output wire        seed_complete        // the whole 8192-word seed landed
);
    localparam integer FA = 6;                    // 64 halfwords
    localparam [FA:0]  HIGH_WATER = 7'd32;

    function automatic [31:0] crc_byte(input [31:0] prev, input [7:0] val);
        reg [31:0] c; integer n;
        begin c = prev ^ {24'd0, val}; for (n = 0; n < 8; n = n + 1) c = (c >> 1) ^ (c[0] ? 32'hedb88320 : 32'd0); crc_byte = c; end
    endfunction

    (* ramstyle = "MLAB, no_rw_check" *) reg [15:0] fmem [0:(1<<FA)-1];
    reg  [FA:0] fw, fr;
    wire [FA:0] fcnt    = fw - fr;
    wire        f_empty = (fw == fr);
    wire        f_full  = (fcnt == (7'd1 << FA));
    wire [15:0] f_head  = fmem[fr[FA-1:0]];

    wire is_md  = ioctl_download && (ioctl_index[7:0] == IOCTL_INDEX);
    wire offer  = ioctl_wr && is_md;
    wire accept = offer && !stream_closed && !f_full;
    // Backpressure for BOTH captures. The seed needs it for the same reason the maindata does: the
    // drain costs one SDRAM write per two halfwords and cannot match the offered rate, and without
    // it the seed FIFO overflows (measured: 1697 of 16384 halfwords dropped, gm1-sim-20260916T031403).
    // Asserting wait during the seed download does not violate the bw1 build 3 lesson, which is that
    // wait must never be asserted AFTER the maindata capture closed: the seed precedes it entirely.
    // seed_open, not is_seed: backpressure may only be asserted while the drain can actually empty
    // the FIFO. Asserting it when it cannot is what wedges Main and, with ioctl_download stuck high,
    // holds the DDR mux in its loading configuration -- which kills V-unit textures and DCS playback
    // while the SDRAM-side CPU keeps running (cabinet, waived r3: bar 13 red, black picture, no DCS
    // boot tone, 727 frames still presented).
    assign ioctl_wait = (!stream_closed && (fcnt >= HIGH_WATER)) || (seed_open && (scnt >= HIGH_WATER));
    assign size_ok    = (words_loaded == EXPECTED_WORDS);

    always @(posedge clk) if (accept) fmem[fw[FA-1:0]] <= ioctl_dout;

    // ---- CMOS seed capture (its own FIFO; arrives before the maindata stream) ----
    (* ramstyle = "MLAB, no_rw_check" *) reg [15:0] smem [0:(1<<FA)-1];
    reg  [FA:0] sw, sr;
    wire [FA:0] scnt    = sw - sr;
    wire        s_empty = (sw == sr);
    wire        s_full  = (scnt == (7'd1 << FA));
    wire [15:0] s_head  = smem[sr[FA-1:0]];
    // The seed is only capturable while the drain can still serve it, i.e. before `done`. After
    // `done` the core flips SDRAM ownership away from this loader (gm1_core: loader_owns=!loader_done)
    // and gm1_sdram gates l_ack on it, so a late seed could never be written -- and worse, its FIFO
    // would fill and hold ioctl_wait high forever, which HANGS MiSTer Main
    // (memory mister-ioctl-wait-high-hangs-main). So a late seed is dropped and counted instead:
    // seed_complete stays false, D_CMOS keeps MAME's all-ones fresh fill, and the game boots to the
    // calibration screen. A degraded boot, never a wedged one.
    wire        seed_open = ioctl_download && (ioctl_index[7:0] == IOCTL_SEED_INDEX) && !done;
    wire        is_seed  = ioctl_download && (ioctl_index[7:0] == IOCTL_SEED_INDEX);
    wire        s_offer  = ioctl_wr && is_seed;
    wire        s_accept = s_offer && seed_open && !s_full;
    assign      seed_complete = (seed_words == SEED_WORDS);
    always @(posedge clk) if (s_accept) smem[sw[FA-1:0]] <= ioctl_dout;

    localparam [3:0] D_LO=0, D_HI=1, D_ROM=2, D_MAIN=3, D_CMOS=4, D_FAST=5, D_TAIL=6, D_DONE=7,
                     D_SEED_HI=8, D_SEED_WR=9;
    reg [3:0]  ds;
    reg [15:0] slo_q;
    reg [31:0] sword_q;
    reg [12:0] seed_idx;
    reg        fills_done;            // the ROM/CMOS/fast/tail fills are finished; the FSM sits in D_DONE
    reg [15:0] lo_q;
    reg [31:0] word_q;
    reg [22:0] idx;   // 23 bits: MK4 loads exactly 0x400000 words; a 22-bit idx wraps to 0 and the tail fill then zeroes the ROM from word 0
    reg [16:0] fill_idx;
    reg [22:0] tail_idx;

    always @(posedge clk) begin
        if (por) begin
            fw <= '0; fr <= '0; ds <= D_LO; lo_q <= 16'd0; word_q <= 32'd0; idx <= 23'd0; fill_idx <= 17'd0; tail_idx <= 23'd0;
            l_req <= 1'b0; l_baddr <= 25'd0; l_wdata <= 32'd0;
            done <= 1'b0; boot_pc <= 24'd0; words_loaded <= 32'd0; stream_crc <= 32'hffffffff;
            dropped_halfwords <= 32'd0; stream_seen <= 1'b0; stream_closed <= 1'b0; reset_during_download <= 1'b0;
            sw <= '0; sr <= '0; slo_q <= 16'd0; sword_q <= 32'd0; seed_idx <= 13'd0;
            seed_words <= 32'd0; seed_dropped <= 32'd0; fills_done <= 1'b0;
        end else begin
            // ---- seed capture ----
            if (s_accept) sw <= sw + 1'b1;
            else if (s_offer) seed_dropped <= seed_dropped + 32'd1;

            // ---- capture ----
            if (accept) begin
                fw <= fw + 1'b1;
                stream_crc <= crc_byte(crc_byte(stream_crc, ioctl_dout[7:0]), ioctl_dout[15:8]);
            end else if (offer) begin
                dropped_halfwords <= dropped_halfwords + 32'd1;
            end
            if (is_md) stream_seen <= 1'b1;
            if (stream_seen && !is_md) stream_closed <= 1'b1;
            if (is_md && core_reset) reset_during_download <= 1'b1;   // informational: Main holds reset here

            // ---- drain into SDRAM ----
            case (ds)
                // the seed takes priority over the maindata drain: it is small, it arrives first,
                // and its FIFO must not overflow. Entered only with a whole word available so
                // D_SEED_HI cannot stall here holding the maindata drain.
                D_LO: if (scnt >= 7'd2 && !seed_complete) begin
                          slo_q <= s_head; sr <= sr + 1'b1; ds <= D_SEED_HI;
                      end else if (!f_empty) begin
                          lo_q <= f_head; fr <= fr + 1'b1; ds <= D_HI;
                      end else if (stream_closed) begin
                          fill_idx <= 17'd0; ds <= D_CMOS;
                      end
                D_SEED_HI: begin sword_q <= {s_head, slo_q}; sr <= sr + 1'b1; ds <= D_SEED_WR; end
                D_SEED_WR: if (!l_req) begin
                               l_req <= 1'b1; l_baddr <= CMOS_BASE | {6'd0, 4'd0, seed_idx, 2'b00};
                               l_wdata <= sword_q;
                           end else if (l_ack) begin
                               l_req <= 1'b0; seed_idx <= seed_idx + 13'd1;
                               seed_words <= seed_words + 32'd1;
                               ds <= fills_done ? D_DONE : D_LO;   // return to whichever state serves the seed
                           end
                D_HI: if (!f_empty) begin
                          word_q <= {f_head, lo_q}; fr <= fr + 1'b1; ds <= D_ROM;
                      end else if (stream_closed) begin
                          dropped_halfwords <= dropped_halfwords + 32'd1;   // odd trailing halfword
                          fill_idx <= 17'd0; ds <= D_CMOS;
                      end
                D_ROM: if (!l_req) begin
                           l_req <= 1'b1; l_baddr <= {idx, 2'b00}; l_wdata <= word_q;
                       end else if (l_ack) begin
                           l_req <= 1'b0;
                           if (idx == 23'd0) boot_pc <= BOOT_SHIFT ? {word_q[22:0], 1'b0} : word_q[23:0];
                           if (idx <= {1'b0, BOOT_LAST}) ds <= D_MAIN;
                           else begin idx <= idx + 23'd1; words_loaded <= words_loaded + 32'd1; ds <= D_LO; end
                       end
                D_MAIN: if (!l_req) begin
                            l_req <= 1'b1; l_baddr <= MAIN_BASE | {5'd0, idx[17:0], 2'b00};
                            l_wdata <= (BOOT_SHIFT && idx == 23'd0) ? {word_q[30:0], 1'b0} : word_q;
                        end else if (l_ack) begin
                            l_req <= 1'b0; idx <= idx + 23'd1; words_loaded <= words_loaded + 32'd1; ds <= D_LO;
                        end
                // a COMPLETE seed replaces the fresh-CMOS fill; a partial one does not, so a dropped
                // seed still leaves MAME's documented all-ones state (midvunit.cpp:1193)
                D_CMOS: if (seed_complete) begin
                            fill_idx <= 17'd0; ds <= D_FAST;
                        end else if (!l_req) begin
                            l_req <= 1'b1; l_baddr <= CMOS_BASE | {6'd0, fill_idx, 2'b00}; l_wdata <= 32'hffffffff;
                        end else if (l_ack) begin
                            l_req <= 1'b0;
                            if (fill_idx == CMOS_LAST) begin fill_idx <= 17'd0; ds <= D_FAST; end
                            else fill_idx <= fill_idx + 17'd1;
                        end
                D_FAST: if (!l_req) begin
                            l_req <= 1'b1; l_baddr <= FAST_BASE | {6'd0, fill_idx, 2'b00}; l_wdata <= 32'd0;
                        end else if (l_ack) begin
                            l_req <= 1'b0;
                            if (fill_idx == FAST_LAST) begin tail_idx <= idx; ds <= D_TAIL; end
                            else fill_idx <= fill_idx + 17'd1;
                        end
                // ROM words past the stream (MAME region tail) = 0
                D_TAIL: if (tail_idx == 23'h600000) begin              // MK4: the whole 24 MiB region
                            fills_done <= 1'b1; ds <= D_DONE;
                        end else if (!l_req) begin
                            l_req <= 1'b1; l_baddr <= {tail_idx[22:0], 2'b00}; l_wdata <= 32'd0;
                        end else if (l_ack) begin
                            l_req <= 1'b0; tail_idx <= tail_idx + 23'd1;
                        end
                // hold the engine while a seed is still arriving or draining: on the cabinet Main's
                // ioctl is slower than the bench's, so the seed can still be in flight when the
                // fills finish, and the game must not read CMOS before it lands
                // D_DONE still SERVES the seed. `done` is held low while a seed is streaming, so the
                // core has not yet flipped SDRAM ownership away (gm1_core: loader_owns=!loader_done)
                // and these writes still get an l_ack -- which is what lets a seed that arrives in
                // INDEX order (after maindata and DCS) land at all. Without this the FSM parked here,
                // the seed FIFO filled, ioctl_wait latched high, and `done` waited on a stream that
                // could never finish: a deadlock that wedged MiSTer Main and, with ioctl_download
                // stuck high, held the DDR mux in its loading configuration -- black picture, no DCS
                // audio, CPU still running from SDRAM. Reproduced in sim with --seed-last.
                // A late seed simply overwrites the all-ones fill D_CMOS already wrote, so both
                // orderings end with the same CMOS contents.
                D_DONE: if (scnt >= 7'd2 && !seed_complete) begin
                            slo_q <= s_head; sr <= sr + 1'b1; ds <= D_SEED_HI;
                        end else if (!is_seed && (s_empty || seed_complete || seed_dropped != 32'd0)) begin
                            // released by: FIFO empty, seed complete, or a drop already counted -- so
                            // a stranded odd halfword can never hold the engine down forever
                            done <= 1'b1;
                        end
                default: done <= 1'b1;                  // unreachable encodings: fail safe, never hang
            endcase
        end
    end
endmodule
`default_nettype wire
