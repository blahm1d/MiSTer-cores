#!/bin/bash
# mutation check for run_zk4_audio_gain.sh: each defect must FAIL the gate (the part named runs; unit = iverilog,
# mk4 / inv = the emu-level Verilator benches).
#  zk4_audio_gain.sv (unit):
#   G1 no saturation (wraps)            G2 old order (code 0 = +12 dB, code 1 = 0 dB)   G3 negative clamp -32767
#   G4 +18 dB is only +12 dB (x4)       G5 right channel plays the left input            G6 positive clamp 0x7FFE
#   G7 +6 dB (code 1) plays at 0 dB
#  zk4_emu.sv (emu level):
#   E1 Invasion fixed at 0 dB (the inv6 wiring)            E2 the default is 0 dB again (both games)
#   E3 Invasion has no Audio Gain OSD entry                E4 the gain reads status[12:11] (MK4)
#   E5 the non-default entries not ascending (MK4)         E6 the OSD labels in the wrong order (MK4)
#   E7 an Invasion option collides with the gain bits (Sinden Border on O[10])
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; bad=0
run() { out=$(env ZAG_PARTS="$2" "$3=$4" bash $D/run_zk4_audio_gain.sh 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$1 NOT APPLIED / BUILD FAILED"; echo "$out" | tail -5; bad=1
  elif [ $rc = 0 ]; then echo "$1 SURVIVED"; bad=1
  else echo "$1 killed [$2]: $(echo "$out" | grep -m1 FAIL | cut -c1-110)"; fi; }
Q="'"
run G1 unit ZAG_MUT 's/if (w > 19.sd32767)       gain = 16.sh7FFF;/if (1'$Q'b0) gain = 16'$Q'sh7FFF;/'
run G2 unit ZAG_MUT 's/(code == 2.d0) ? 2.d0 : (code == 2.d1) ? 2.d1/(code == 2'$Q'd0) ? 2'$Q'd2 : (code == 2'$Q'd1) ? 2'$Q'd0/'
run G3 unit ZAG_MUT 's/gain = 16.sh8000;/gain = 16'$Q'sh8001;/'
run G4 unit ZAG_MUT 's/(code == 2.d2) ? 2.d2 : 2.d3;/(code == 2'$Q'd2) ? 2'$Q'd2 : 2'$Q'd2;/'
run G7 unit ZAG_MUT 's/(code == 2.d1) ? 2.d1 :/(code == 2'$Q'd1) ? 2'$Q'd0 :/'
run G5 unit ZAG_MUT 's/out_r <= gain(in_r, sh);/out_r <= gain(in_l, sh);/'
run G6 unit ZAG_MUT 's/gain = 16.sh7FFF;/gain = 16'$Q'sh7FFE;/'
run E1 inv ZAG_EMU_MUT 's/^    wire \[1:0\] gain_code = (gain_osd == 2.d0)/`ifdef ZK4_GAME_INVASION\n    wire [1:0] gain_code = 2'$Q'd0;\n`else\n&/;s/^\( *(gain_osd - 2.d1 >= AUDIO_GAIN_DEFAULT) ? gain_osd : gain_osd - 2.d1;\)$/\1\n`endif/'
run E2 "mk4 inv" ZAG_EMU_MUT 's/^`define ZK4_AUDIO_GAIN_DEFAULT 2$/`define ZK4_AUDIO_GAIN_DEFAULT 0/'
run E3 inv ZAG_EMU_MUT '0,/^        AUDIO_GAIN_OSD,$/{/^        AUDIO_GAIN_OSD,$/d}'
run E4 mk4 ZAG_EMU_MUT 's/wire \[1:0\] gain_osd = status\[11:10\];/wire [1:0] gain_osd = status[12:11];/'
run E5 mk4 ZAG_EMU_MUT 's/(gain_osd - 2.d1 >= AUDIO_GAIN_DEFAULT)/(gain_osd >= AUDIO_GAIN_DEFAULT)/'
run E6 mk4 ZAG_EMU_MUT 's/Audio Gain,+12 dB,0 dB,+6 dB,+18 dB;/Audio Gain,+12 dB,+18 dB,0 dB,+6 dB;/'
run E7 inv ZAG_EMU_MUT 's/"P1O\[36\],Sinden Border,Off,On;"/"P1O[10],Sinden Border,Off,On;"/'
echo "MUTANTS: $([ $bad = 0 ] && echo 'ALL KILLED' || echo 'SOME SURVIVED')"; exit $bad
