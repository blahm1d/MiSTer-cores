// zk4_top.sv -- MK4 core below the emu shell: ROM loader + board SDRAM + zk4_core, the MiSTer DDRAM port, and (only
// with `define ZK4_DIAG) the cabinet instruments (the Cruis'n gm1 pattern: a status screen and a DDR3 status mirror
// read by an ARM logger, plus the r5 bank-1 DDR diagnostic unless ZK4_NO_DDR_DIAG).
// ZK4_DIAG (user decision 2026-09-26, s7 / inv7): UNDEFINED by default = no diagnostic hardware at all -- no status
// screen (the game raster is always on the pins), no status mirror (the arbiters' M port is tied off: m_write = 0,
// never granted), no bank-1 DDR tap, no milestone / counter registers. Define it (QSF macro) to bring them all back;
// the OSD Status screen / Status page entries follow the same define in zk4_emu.sv.
// Reset domains (the core doctrine, P0022): the loader and the SDRAM controller run on the power-on reset (2-FF-synced
// ~locked), never the core reset -- MiSTer Main holds the core reset through the ROM download. The game (CPU,
// tier, renderer, devices, scanout) runs on game_reset: held through every download + HOLD, then a MAME machine_reset RAM reload.
// DDRAM: zk4_ddr_arb shares the port between the renderer's memsys (urgent; 29-bit 64-bit-word addresses: wave RAM 0 at
// byte 0x30000000, wave RAM 1 at 0x30800000) and zk4_status_mirror (single-beat writes at 0x30C00000).
// Status screen: wrapper/donor/gm1_hdmi_status.sv AS-IS (640x480 bars; 13 boot-milestone bars + 5 diagnostic rows),
// shown until the game's first display flip and afterwards while the OSD asks for it; the whole video set (CE, sync, DE,
// RGB) switches on one registered select.
//   milestones (green = passed, red = failed, yellow = the next one, grey = not reached):
//    1 ROM stream seen          2 stream complete, 16 MiB     3 stream CRC = EXPECTED_CRC   4 no drops, no reset-in-download
//    5 loaded, no SDRAM fault   6 CPU running (PC left boot)  7 first Zeus register write   8 first FIFO command word
//    9 first DDR write beat    10 first display flip (0xCC)  11 DCS2 answered + read       12 PIC serial read
//   13 no fault anywhere (CPU, renderer, DDR, SDRAM map, scanout skips)
//   rows: A faults {cpu_fault[7:0], map, render, unsupported, skips, late, reset-in-download, drops, crc-bad}
//         B INT0 frames [15:0]   C instructions [31:16]   D sampled CPU PC [23:8] (~3 Hz)   E IN1 live (controls)
module zk4_top #(parameter bit DCS_STUB = 1'b1, parameter logic [31:0] EXPECTED_CRC = 32'hBC1968D5,
                 parameter int HOLD = 1 << 24,         // clocks the game stays in reset after the last download (~0.34 s)
                 parameter bit DCS_SHADOW = 1'b0,   // 1 = FIT B MEASUREMENT: donor DCS engine in shadow (never a cabinet build)
                 parameter int CPU_BTB = 1,        // c31 branch-target buffer (0: -10 % CPU speed, measured bit-exact)
                 parameter bit DCS_FABRIC = 1'b0) ( // 1 = the fabric DCS2 sound board (zk4_dcs2) in place of the stand-in
  input  logic        clk, por, core_reset, show_status,
  input  logic [2:0]  status_page,          // OSD "Status page": 0 Health 1 CPU 2 Render 3 DDR3 4 Sound (Cruis'n pattern)
  // ROM download + NVRAM (index 2) download / upload (hps_io WIDE)
  input  logic        ioctl_download, ioctl_wr, input logic [26:0] ioctl_addr, input logic [15:0] ioctl_dout,
  input  logic [15:0] ioctl_index, output logic ioctl_wait, output logic [15:0] ioctl_din,
  // board SDRAM pins
  inout  wire  [15:0] SDRAM_DQ, output logic [12:0] SDRAM_A, output logic [1:0] SDRAM_BA,
  output logic        SDRAM_DQML, SDRAM_DQMH, SDRAM_nCS, SDRAM_nCAS, SDRAM_nRAS, SDRAM_nWE, SDRAM_CKE,
  // MiSTer DDRAM (HPS DDR3)
  input  logic        DDRAM_BUSY, DDRAM_DOUT_READY, input logic [63:0] DDRAM_DOUT,
  output logic [28:0] DDRAM_ADDR, output logic [7:0] DDRAM_BURSTCNT, output logic [7:0] DDRAM_BE,
  output logic [63:0] DDRAM_DIN, output logic DDRAM_RD, DDRAM_WE,
  // cabinet
  input  logic [15:0] in_port [4], input logic [7:0] rtc [7],
`ifdef ZK4_GAME_INVASION
  // Invasion: MAME gun ports (zk4_gun_input) and the lightgun overlay controls (OSD)
  input  logic [7:0]  gun_xin [2], input logic [7:0] gun_yin [2], input logic [1:0] gun_trigger,
  input  logic [8:0]  gun_cx [2], input logic [8:0] gun_cy [2], input logic [1:0] gun_cross_en,
  input  logic        gun_border_en, input logic [8:0] gun_border_w,
`endif
  // video (game or status screen)
  output logic        ce_pix, hs, vs, de, output logic [7:0] r, g, b,
  // status
  output logic        loader_done, sdram_map_fault, output logic [23:0] cpu_pc, output logic [7:0] cpu_fault,
  output logic        render_fault,
  output logic signed [15:0] audio_l, audio_r
);
  // ---- per-game constants (MAME 0.289 midzeus.cpp; the Invasion RBF is `ZK4_GAME_INVASION, MK4 is the default) ----
`ifdef ZK4_GAME_INVASION
  // invasnab: maindata 10 x 2 MiB = 0x500000 words (ROM_START(invasnab) :1581-1591); loader CRC of that stream and the
  // 8 MiB sound stream CRC (invasion/tools/make_inv_images.py); I/O ASIC set_upper(468), GAME 1999, no
  // set_shuffle_default (:1422-1429, :1986); DCS2 ROM 4 x 2 MiB (:1573-1576)
  localparam logic [31:0] G_CRC = 32'h1A6C9D66, G_WORDS = 32'h0050_0000, G_SND_CRC = 32'h596AD923;
  localparam int G_PIC_UPPER = 468, G_PIC_YEAR = 1999; localparam bit G_SHUFFLE = 1'b0, G_INV_ROM = 1'b1;
  localparam int G_FIRE_EARLY = 0;   // zk4_gun comparator calibration (work item 4; set from the measured ISR latency)
`else
  localparam int G_FIRE_EARLY = 0;
  localparam logic [31:0] G_CRC = EXPECTED_CRC, G_WORDS = 32'h0040_0000, G_SND_CRC = 32'h474599CA;
  localparam int G_PIC_UPPER = 461, G_PIC_YEAR = 1997; localparam bit G_SHUFFLE = 1'b1, G_INV_ROM = 1'b0;
`endif
  // ---- loader ----
  logic l_req, l_ack; logic [24:0] l_baddr; logic [31:0] l_wdata; logic [23:0] boot_pc;
  logic [31:0] words_loaded, stream_crc, dropped; logic stream_seen, stream_closed, size_ok, rst_in_dl;
  logic load_ioctl_wait, dcs_ioctl_wait; assign ioctl_wait = load_ioctl_wait || dcs_ioctl_wait;
  zk4_loader #(.EXPECTED_WORDS(G_WORDS)) u_load (.clk, .por, .core_reset, .ioctl_download, .ioctl_wr, .ioctl_index, .ioctl_dout, .ioctl_wait(load_ioctl_wait),
    .l_req, .l_baddr, .l_wdata, .l_ack, .done(loader_done), .boot_pc, .words_loaded, .stream_crc,
    .dropped_halfwords(dropped), .stream_seen, .stream_closed, .size_ok, .reset_during_download(rst_in_dl),
    .seed_words(), .seed_dropped(), .seed_complete());
  // ---- board SDRAM: loader until done, then the CPU memory tier ----
  // the SDRAM word port belongs to the RAM reload while the game is held, to the CPU tier once it runs
  logic sd_req, sd_burst, sd_we, sd_ack; logic [23:0] sd_addr; logic [31:0] sd_wdata, sd_rdata;   // the core's side
  logic q_req, q_burst, q_we, q_ack; logic [23:0] q_addr; logic [31:0] q_wdata;                    // what zk4_sdram sees
  logic rl_req, rl_we, rl_start, rl_busy; logic [23:0] rl_addr; logic [31:0] rl_wdata;
  zk4_sdram u_sdram (.clk, .por, .loader_owns(!loader_done), .l_req, .l_baddr, .l_wdata, .l_ack,
    .sd_req(q_req), .sd_we(q_we), .sd_burst(q_burst), .sd_addr(q_addr), .sd_wdata(q_wdata), .sd_ack(q_ack),
    .sd_rdata, .map_fault(sdram_map_fault),
    .SDRAM_DQ, .SDRAM_A, .SDRAM_BA, .SDRAM_DQML, .SDRAM_DQMH, .SDRAM_nCS, .SDRAM_nCAS, .SDRAM_nRAS, .SDRAM_nWE, .SDRAM_CKE);
  zk4_ram_reload u_reload (.clk, .por, .start(rl_start), .busy(rl_busy), .sd_req(rl_req), .sd_we(rl_we),
    .sd_addr(rl_addr), .sd_wdata(rl_wdata), .sd_ack(q_ack), .sd_rdata);

  // ---- the game's reset: MAME machine_reset semantics on EVERY release ----
  // held while anything downloads (ROM, then the NVRAM file index 2) plus HOLD clocks after the last one, so the CMOS
  // is restored before the CPU runs; then zk4_ram_reload repeats machine_reset's RAM copy (midzeus.cpp:236-237),
  // first boot included (it rewrites what the loader wrote -- and a broken reload shows on the first power-on).
  typedef enum logic [2:0] {P_HOLD, P_START, P_ARM, P_RELOAD, P_RUN} ph_t;
  ph_t phase; logic [24:0] hold_cnt; logic raw_reset;
  logic ds_rom_loaded; logic [31:0] ds_rom_crc, ds_cache_misses, ds_dac_underruns; logic [13:0] ds_dsp_pc;   // fabric DCS2 status
  // fabric sound: also hold until the sound ROM has fully landed in DDR3 (gm1: game_reset <= !(loader_done && dcs_rom_loaded))
  always_ff @(posedge clk) raw_reset <= por || core_reset || !loader_done || ioctl_download || (DCS_FABRIC && !ds_rom_loaded);
  always_ff @(posedge clk)
    if (por || raw_reset) begin phase <= P_HOLD; hold_cnt <= '0; end
    else case (phase)
      P_HOLD:   if (hold_cnt == 25'(HOLD - 1)) phase <= P_START; else hold_cnt <= hold_cnt + 1'b1;
      P_START:  phase <= P_ARM;                               // rl_start pulses here (ignored if a reload still runs)
      P_ARM:    phase <= P_RELOAD;                            // rl_busy is high from this clock
      P_RELOAD: if (!rl_busy) phase <= P_RUN;
      default:  ;
    endcase
  assign rl_start = phase == P_START;
  logic game_run; assign game_run = phase == P_RUN;
  assign q_req = game_run ? sd_req : rl_req;   assign q_we = game_run ? sd_we : rl_we;
  assign q_burst = game_run && sd_burst;       assign q_addr = game_run ? sd_addr : rl_addr;
  assign q_wdata = game_run ? sd_wdata : rl_wdata;
  assign sd_ack = game_run && q_ack;
  logic game_reset; always_ff @(posedge clk) game_reset <= por || !game_run;
`ifdef ZK4_DIAG
  logic [31:0] reloads; always_ff @(posedge clk) if (por) reloads <= '0; else if (rl_start) reloads <= reloads + 1'b1;
`endif

  // ---- NVRAM (MRA <nvram index="2" size="32768"/>): Main restores the CMOS at load and saves it on request ----
  logic nv_we; logic [15:0] nv_q;
  assign nv_we = ioctl_download && ioctl_wr && ioctl_index[7:0] == 8'd2 && ioctl_addr < 27'd32768;
  assign ioctl_din = nv_q;                                    // hps_io latches it at the next strobe (SPI-paced)
`ifdef ZK4_DIAG
  logic [31:0] nv_words;
  always_ff @(posedge clk) if (por) nv_words <= '0; else if (nv_we) nv_words <= nv_words + 1'b1;
`endif
  logic dcs_data_w, dcs_ack_w, dcs_data_r, dcs_reset_w, dcs_reset_level; logic [15:0] dcs_wdata;
  logic r_read, r_write, r_wait, r_rdv; logic [28:0] r_addr; logic [7:0] r_bc, r_be; logic [63:0] r_wd, r_rd;
  logic g_ce, g_hs, g_vs, g_hb, g_vb; logic [7:0] g_r, g_g, g_b;
  logic [31:0] diag [16]; logic [31:0] scan_skip, scan_late; logic render_unsupported;
  // DCS2 socket: the calibrated stand-in inside zk4_core (DCS_FABRIC = 0), or the fabric sound board zk4_dcs2 below
  logic [15:0] fd_control, fd_data, fd_data2; logic fd_input_empty, fd_output_full;
  zk4_core #(.DCS_STUB(DCS_STUB && !DCS_FABRIC), .CPU_BTB(CPU_BTB), .PIC_UPPER(G_PIC_UPPER), .PIC_YEAR(G_PIC_YEAR),
             .IOASIC_SHUFFLE_DEFAULT(G_SHUFFLE), .GUN_FIRE_EARLY(G_FIRE_EARLY)) u_core (.clk, .rst(game_reset), .boot_pc, .in_port, .rtc,
`ifdef ZK4_GAME_INVASION
    .gun_xin, .gun_yin, .gun_trigger,
`endif
    .sd_req, .sd_burst, .sd_we, .sd_addr, .sd_wdata, .sd_ack, .sd_rdata,
    .av_read(r_read), .av_write(r_write), .av_address(r_addr), .av_burstcount(r_bc), .av_writedata(r_wd),
    .av_byteenable(r_be), .av_waitrequest(r_wait), .av_readdatavalid(r_rdv), .av_readdata(r_rd),
    .ce_pix(g_ce), .hs(g_hs), .vs(g_vs), .hblank(g_hb), .vblank(g_vb), .r(g_r), .g(g_g), .b(g_b),
    .dcs_control_in(fd_control), .dcs_data_in(fd_data), .dcs_data2_in(fd_data2), .dcs_input_empty_in(fd_input_empty),
    .dcs_output_full_in(fd_output_full), .dcs_data_w, .dcs_wdata, .dcs_ack_w, .dcs_data_r, .dcs_reset_w, .dcs_reset_level,
    .cpu_pc, .cpu_fault, .render_fault, .render_unsupported, .scan_skip, .scan_late,
    .nv_we, .nv_row(ioctl_addr[14:1]), .nv_d(ioctl_dout), .nv_q, .diag);

  // ---- DDRAM: renderer (urgent) + status mirror (ZK4_DIAG only; tied off below otherwise) ----
  logic m_write, m_wait; logic [31:0] m_addr, st_m_writes, st_m_wait_max; logic [63:0] m_wd;
`ifndef ZK4_DIAG
  // no mirror: the M port never requests, so the arbiter never grants it (sel_m / O_M only with nothing else offered,
  // and then it offers nothing -- no lock, no census); the arbiter reduces to the renderer (+ DCS2) path
  assign m_write = 1'b0; assign m_addr = '0; assign m_wd = '0;
`endif
  generate if (DCS_FABRIC) begin : g_fabric
    // FIT B: the MK4 DCS2 sound board in fabric (lanes/dcs2-engine/INTEGRATION-CONTRACT.md): host socket = the
    // stand-in's, sound ROM on ioctl index 3 -> DDR 0x31000000, SRAM backing at 0x31800000, zk4_ddr_arb3 S port.
    logic s_read, s_write, s_wait, s_rdv; logic [31:0] s_addr; logic [63:0] s_wd, s_rd; logic [7:0] s_be;
    logic [31:0] st_s_wait_max; logic st_tag_ovf; logic a_ce;
    zk4_dcs2 #(.INV_ROM(G_INV_ROM), .SPORT0_TIMER(G_INV_ROM), .LATCH_STATUS(G_INV_ROM)) u_dcs2 (.clk, .por, .rst(game_reset),
      .data_w(dcs_data_w), .wdata(dcs_wdata), .ack_w(dcs_ack_w), .data_r(dcs_data_r), .reset_w(dcs_reset_w),
      .reset_level(dcs_reset_level), .control(fd_control), .data(fd_data), .data2(fd_data2),
      .input_empty(fd_input_empty), .output_full(fd_output_full),
      .ioctl_download, .ioctl_wr, .ioctl_index, .ioctl_dout, .ioctl_wait(dcs_ioctl_wait),
      .s_read, .s_write, .s_address(s_addr), .s_writedata(s_wd), .s_byteenable(s_be),
      .s_waitrequest(s_wait), .s_readdatavalid(s_rdv), .s_readdata(s_rd),
      .audio_l, .audio_r, .audio_ce(a_ce),
      .rom_loaded(ds_rom_loaded), .rom_bytes(), .rom_crc(ds_rom_crc), .cache_misses(ds_cache_misses),
      .dac_underruns(ds_dac_underruns), .dsp_pc(ds_dsp_pc), .pm_oow());
    // inv-buzz: Invasion caps the renderer read beats in flight so a DCS read never waits behind ~512 renderer beats
    zk4_ddr_arb3 #(.R_RD_CAP(G_INV_ROM ? 64 : 0)) u_arb (.clk, .rst(por),
      .r_read, .r_write, .r_address(r_addr), .r_burstcount(r_bc), .r_writedata(r_wd), .r_byteenable(r_be),
      .r_waitrequest(r_wait), .r_readdatavalid(r_rdv), .r_readdata(r_rd),
      .s_read, .s_write, .s_address(s_addr), .s_writedata(s_wd), .s_byteenable(s_be),
      .s_waitrequest(s_wait), .s_readdatavalid(s_rdv), .s_readdata(s_rd),
      .m_write, .m_address(m_addr), .m_writedata(m_wd), .m_waitrequest(m_wait),
      .d_read(DDRAM_RD), .d_write(DDRAM_WE), .d_address(DDRAM_ADDR), .d_burstcount(DDRAM_BURSTCNT),
      .d_writedata(DDRAM_DIN), .d_byteenable(DDRAM_BE), .d_busy(DDRAM_BUSY), .d_readdatavalid(DDRAM_DOUT_READY),
      .d_readdata(DDRAM_DOUT), .st_m_writes, .st_m_wait_max, .st_s_wait_max, .st_tag_overflow(st_tag_ovf));
  end else if (!DCS_SHADOW) begin : g_arb2
    assign ds_rom_loaded = 1'b0; assign ds_rom_crc = '0; assign ds_cache_misses = '0; assign ds_dac_underruns = '0; assign ds_dsp_pc = '0;
    assign fd_control = 16'h0C00; assign fd_data = 16'd0; assign fd_data2 = 16'd0;
    assign fd_input_empty = 1'b1; assign fd_output_full = 1'b0;
    zk4_ddr_arb u_arb (.clk, .rst(por),
      .r_read, .r_write, .r_address(r_addr), .r_burstcount(r_bc), .r_writedata(r_wd), .r_byteenable(r_be),
      .r_waitrequest(r_wait), .r_readdatavalid(r_rdv), .r_readdata(r_rd),
      .m_write, .m_address(m_addr), .m_writedata(m_wd), .m_waitrequest(m_wait),
      .d_read(DDRAM_RD), .d_write(DDRAM_WE), .d_address(DDRAM_ADDR), .d_burstcount(DDRAM_BURSTCNT),
      .d_writedata(DDRAM_DIN), .d_byteenable(DDRAM_BE), .d_busy(DDRAM_BUSY), .d_readdatavalid(DDRAM_DOUT_READY),
      .d_readdata(DDRAM_DOUT), .st_m_writes, .st_m_wait_max);
    assign dcs_ioctl_wait = 1'b0; assign audio_l = 16'd0; assign audio_r = 16'd0;
  end else begin : g_shadow
    assign ds_rom_loaded = 1'b0; assign ds_rom_crc = '0; assign ds_cache_misses = '0; assign ds_dac_underruns = '0; assign ds_dsp_pc = '0;
    assign fd_control = 16'h0C00; assign fd_data = 16'd0; assign fd_data2 = 16'd0;
    assign fd_input_empty = 1'b1; assign fd_output_full = 1'b0;
    // FIT B MEASUREMENT ONLY (rtl/dcs/donor/PROVENANCE.md): the Cruis'n DCS-2K engine beside the core, fed the same
    // sound writes the stand-in answers; its ROM window at DDR 0x31000000 (ioctl index 3), its audio on the pins.
    logic s_read, s_write, s_wait, s_rdv; logic [31:0] s_addr; logic [63:0] s_wd, s_rd; logic [7:0] s_be;
    logic [3:0] s_bc; logic signed [15:0] s_audio; logic s_audio_ce; logic [31:0] st_s_wait_max; logic st_tag_ovf;
    logic [10:0] dac_div; logic dac_ce;
    always_ff @(posedge clk) if (por) begin dac_ce <= 1'b0; dac_div <= '0; end
      else begin dac_ce <= dac_div == 11'd1599; dac_div <= (dac_div == 11'd1599) ? '0 : dac_div + 1'b1; end
    cusa_dcs_subsystem #(.DCS_DDR_BASE(32'h3100_0000), .DCS_IOCTL_INDEX(8'd3)) u_dcs (
      .clk, .por, .core_reset(game_reset), .dac_ce_31250(dac_ce),
      .dcs_latch_we(dcs_data_w), .dcs_latch_data(dcs_wdata[7:0]), .dcs_run(dcs_reset_level),
      .ioctl_download, .ioctl_wr, .ioctl_index, .ioctl_dout, .ioctl_wait(dcs_ioctl_wait),
      .client_read(s_read), .client_write(s_write), .client_address(s_addr), .client_writedata(s_wd),
      .client_byteenable(s_be), .client_burstcount(s_bc), .client_waitrequest(s_wait),
      .client_readdatavalid(s_rdv), .client_readdata(s_rd), .client_read_error(1'b0),
      .audio(s_audio), .audio_ce(s_audio_ce),
      .rom_loaded(), .bytes_loaded(), .stream_crc(), .dropped_bytes(), .ddr_misses(), .dac_underruns(),
      .reset_during_download(), .dbg_adsp_pc(), .dbg_adsp_valid(), .dbg_adsp_unimpl());
    zk4_ddr_arb3 u_arb (.clk, .rst(por),
      .r_read, .r_write, .r_address(r_addr), .r_burstcount(r_bc), .r_writedata(r_wd), .r_byteenable(r_be),
      .r_waitrequest(r_wait), .r_readdatavalid(r_rdv), .r_readdata(r_rd),
      .s_read, .s_write, .s_address(s_addr), .s_writedata(s_wd), .s_byteenable(s_be),
      .s_waitrequest(s_wait), .s_readdatavalid(s_rdv), .s_readdata(s_rd),
      .m_write, .m_address(m_addr), .m_writedata(m_wd), .m_waitrequest(m_wait),
      .d_read(DDRAM_RD), .d_write(DDRAM_WE), .d_address(DDRAM_ADDR), .d_burstcount(DDRAM_BURSTCNT),
      .d_writedata(DDRAM_DIN), .d_byteenable(DDRAM_BE), .d_busy(DDRAM_BUSY), .d_readdatavalid(DDRAM_DOUT_READY),
      .d_readdata(DDRAM_DOUT), .st_m_writes, .st_m_wait_max, .st_s_wait_max, .st_tag_overflow(st_tag_ovf));
    assign audio_l = s_audio; assign audio_r = s_audio;
  end endgenerate

`ifdef ZK4_DIAG
  // ---- milestones (sticky) ----
  logic [15:0] pass_m, fail_m; logic [63:0] wall; logic pc_moved; logic crc_bad;
  assign crc_bad = stream_closed && stream_crc != G_CRC;
  logic any_fault; assign any_fault = cpu_fault != 8'd0 || render_fault || render_unsupported || sdram_map_fault ||
                                      scan_skip != 32'd0;
  always_ff @(posedge clk)
    if (por) begin pass_m <= '0; fail_m <= '0; wall <= '0; pc_moved <= 1'b0; end
    else begin
      wall <= wall + 1'b1;
      if (stream_seen) pass_m[1] <= 1'b1;
      if (stream_closed) begin
        if (size_ok) pass_m[2] <= 1'b1; else fail_m[2] <= 1'b1;
        if (!crc_bad) pass_m[3] <= 1'b1; else fail_m[3] <= 1'b1;
        if (dropped == 32'd0 && !rst_in_dl) pass_m[4] <= 1'b1; else fail_m[4] <= 1'b1;
      end
      if (loader_done) begin if (!sdram_map_fault) pass_m[5] <= 1'b1; else fail_m[5] <= 1'b1; end
      if (!game_reset && cpu_pc != boot_pc) pc_moved <= 1'b1;
      if (pc_moved && cpu_fault == 8'd0) pass_m[6] <= 1'b1;
      if (cpu_fault != 8'd0) fail_m[6] <= 1'b1;
      if (diag[2] != 0) pass_m[7] <= 1'b1;
      if (diag[4] != 0) pass_m[8] <= 1'b1;
      if (diag[5] != 0) pass_m[9] <= 1'b1;
      if (diag[3] != 0) pass_m[10] <= 1'b1;
      if (diag[9][17] && diag[10] != 0) pass_m[11] <= 1'b1;
      if (diag[8] != 0) pass_m[12] <= 1'b1;
      if (any_fault) fail_m[13] <= 1'b1; else if (pass_m[10]) pass_m[13] <= 1'b1;
    end
  logic [7:0] cur; always_comb begin cur = 8'd14; for (int i = 13; i >= 1; i--) if (!pass_m[i]) cur = 8'(i); end
  // sampled PC (~3 Hz): successive screenshots scatter over the loop the CPU is in
  logic [15:0] pc_s; always_ff @(posedge clk) if (wall[23:0] == 24'd0) pc_s <= cpu_pc[23:8];

  logic [15:0] row_a, row_b, row_c, row_d, row_e;             // status screen rows A-E, muxed by status_page at the end
  // ---- status screen (gm1 donor, as-is) ----
  logic s_ce, s_de, s_hs, s_vs; logic [7:0] s_r, s_g, s_b;
  gm1_hdmi_status u_status (.clk, .reset(por), .done_mask(pass_m | fail_m), .pass_mask(pass_m & ~fail_m), .cur_test(cur),
    .heartbeat(wall), .sdram_mb(8'd32), .audit_ok(pass_m[4]), .audit_valid(stream_closed),
    .diag_a(row_a), .diag_b(row_b), .diag_c(row_c), .diag_d(row_d), .diag_e(row_e),   // rows chosen by status_page (below)
    .ce_pixel(s_ce), .de(s_de), .hs(s_hs), .vs(s_vs), .r(s_r), .g(s_g), .b(s_b));
`endif
  // game video (Invasion: + the lightgun overlay -- Sinden border and crosshairs -- on the game raster only)
  logic [7:0] gv_r, gv_g, gv_b;
`ifdef ZK4_GAME_INVASION
  logic [23:0] ov_rgb;
  zk4_lightgun_overlay u_gunov (.clk, .rst(por), .pxl_cen(g_ce), .hs(g_hs), .vs(g_vs), .de(!(g_hb || g_vb)),
    .screen_width(9'd400), .screen_height(9'd256), .border_width(gun_border_w),
    .gun1_x(gun_cx[0]), .gun1_y(gun_cy[0]), .gun2_x(gun_cx[1]), .gun2_y(gun_cy[1]),
    .gun1_en(gun_cross_en[0]), .gun2_en(gun_cross_en[1]), .border_en(gun_border_en), .crosshair_en(1'b1),
    .rgb_in({g_r, g_g, g_b}), .rgb_out(ov_rgb), .raster_x(), .raster_y());
  assign {gv_r, gv_g, gv_b} = ov_rgb;
`else
  assign gv_r = g_r; assign gv_g = g_g; assign gv_b = g_b;
`endif
`ifdef ZK4_DIAG
  // one registered select switches the whole set (Cruis'n rule): status until the first display flip, then on request
  logic use_game; always_ff @(posedge clk) use_game <= pass_m[10] && !show_status;
  always_ff @(posedge clk) begin
    ce_pix <= use_game ? g_ce : s_ce;
    hs     <= use_game ? g_hs : s_hs;
    vs     <= use_game ? g_vs : s_vs;
    de     <= use_game ? !(g_hb || g_vb) : s_de;
    r      <= use_game ? gv_r : s_r;
    g      <= use_game ? gv_g : s_g;
    b      <= use_game ? gv_b : s_b;
  end
`else
  // no status screen: the game raster, registered once (same pin latency as the diag build's select)
  always_ff @(posedge clk) begin
    ce_pix <= g_ce; hs <= g_hs; vs <= g_vs; de <= !(g_hb || g_vb); r <= gv_r; g <= gv_g; b <= gv_b;
  end
`endif

`ifdef ZK4_DIAG
  // ---- DDR3 status mirror (read on the ARM by tools/cab/zk4_perflog.sh) ----
`ifdef ZK4_NO_DDR_DIAG
  // ZK4_NO_DDR_DIAG (prepared zk4-inv4, NOT enabled anywhere; awaiting user approval): the r5 bank-1 DDR diagnostic is out --
  // no status page 3 (falls back to Health), mirror words 14-16 dropped (NP 14 = a 16-word block), layout id 14.
  localparam int MIRROR_NP = 14; localparam logic [7:0] MIRROR_LAYOUT = 8'd14;
`else
  localparam int MIRROR_NP = 17; localparam logic [7:0] MIRROR_LAYOUT = 8'd13;
`endif
  logic [63:0] payload [MIRROR_NP];                               // r13: back to the r5-r9 layout (19-word block)
  assign payload[0]  = wall;
  assign payload[1]  = {pass_m, fail_m, words_loaded};
  assign payload[2]  = {stream_crc, dropped};
  assign payload[3]  = {MIRROR_LAYOUT, boot_pc, 8'd0, cpu_pc};         // [63:56] layout id (13 = r13: the r5-r9 17-word layout; 0 = r5-r9)
  assign payload[4]  = {diag[15], diag[1]};                     // {faults, INT0 frames}
  assign payload[5]  = {diag[0], diag[2]};                      // {instructions, Zeus writes}
  assign payload[6]  = {diag[3], diag[4]};                      // {display flips, FIFO command words}
  assign payload[7]  = {diag[5], diag[6]};                      // {DDR write beats, command-queue peak}
  assign payload[8]  = {diag[7], diag[8]};                      // {command-queue full clocks, PIC reads}
  assign payload[9]  = {diag[9], diag[10]};                     // {DCS flags + last command, DCS reply reads}
  assign payload[10] = {diag[11], diag[12]};                    // {CPU bus-wait clocks, ext-wait clocks}
  // sound board (fabric builds; zero with the stand-in): ROM stream CRC must be 0x474599CA (u2+u3+u4+u5, standard CRC-32)
  logic ds_crc_ok; assign ds_crc_ok = ds_rom_crc == G_SND_CRC;
  assign payload[11] = {scan_skip[15:0], scan_late[15:0], ds_rom_loaded, ds_crc_ok, ds_dsp_pc, ds_dac_underruns[15:0]};
  assign payload[12] = {in_port[0], in_port[1], in_port[2], in_port[3]};
  assign payload[13] = {reloads[15:0], nv_words[15:0], ds_cache_misses[15:0], st_m_wait_max[15:0]};  // resets, NVRAM halfwords, DCS2 cache misses
`ifndef ZK4_NO_DDR_DIAG
  // ---- r5 bank-1 DDR diagnostic (lanes/cab-r4): the cabinet fails the POST "Wave RAM Bank 1" test that the whole-core
  // sim passes under every DDR model (faithful, hostile, byte-enables ignored), so capture what the REAL port sees and
  // returns. Taps the DDRAM bus as driven by the arbiter. Bank 1 = DDR words [0x0610_0000, 0x0614_0000) (byte
  // 0x30800000, 2 MB); the mirror (0x0618_0000) is outside. The read-back latch takes the first returned beat after the
  // first read COMMAND to the latched address -- a hint only if other reads are in flight (returns are in order, shared).
  logic        dg_in_b1; assign dg_in_b1 = (DDRAM_ADDR >= 29'h0610_0000) && (DDRAM_ADDR < 29'h0614_0000);
  logic [15:0] dg_benotff, dg_rdcnt;
  logic        dg_w_seen, dg_rb_arm, dg_rb_seen; logic [28:0] dg_w_addr; logic [63:0] dg_w_din, dg_rb_val; logic [7:0] dg_w_be;
  always_ff @(posedge clk)
    if (por) begin
      dg_benotff <= '0; dg_rdcnt <= '0; dg_w_seen <= 1'b0; dg_w_addr <= '0; dg_w_din <= '0; dg_w_be <= '0;
      dg_rb_arm <= 1'b0; dg_rb_seen <= 1'b0; dg_rb_val <= '0;
    end else begin
      // r6: count partial-byte-enable writes to ANY DDR address (the HPS f2sdram drops them; after the host RMW fix a
      // non-zero count means another master -- e.g. renderer colour writes -- still emits them)
      if (DDRAM_WE && !DDRAM_BUSY && DDRAM_BE != 8'hFF && dg_benotff != 16'hFFFF) dg_benotff <= dg_benotff + 1'b1;
      if (DDRAM_WE && !DDRAM_BUSY && dg_in_b1) begin
        if (!dg_w_seen && DDRAM_DIN[31:0] != 32'd0) begin
          dg_w_seen <= 1'b1; dg_w_addr <= DDRAM_ADDR; dg_w_din <= DDRAM_DIN; dg_w_be <= DDRAM_BE;
        end
      end
      if (DDRAM_RD && !DDRAM_BUSY && dg_in_b1 && dg_rdcnt != 16'hFFFF) dg_rdcnt <= dg_rdcnt + 1'b1;
      if (dg_w_seen && !dg_rb_seen) begin
        if (DDRAM_RD && !DDRAM_BUSY && DDRAM_ADDR == dg_w_addr) dg_rb_arm <= 1'b1;
        if (dg_rb_arm && DDRAM_DOUT_READY) begin dg_rb_seen <= 1'b1; dg_rb_val <= DDRAM_DOUT; end
      end
    end
  assign payload[14] = dg_w_din;                                  // first bank-1 write with a non-zero low word
  assign payload[15] = dg_rb_val;                                 // the port's return for that address (see above)
  assign payload[16] = {dg_benotff, dg_rdcnt, dg_rb_seen, dg_w_seen, dg_rb_arm, dg_w_be, dg_w_addr[20:0]};  // 16+16+3+8+21 = 64
`endif
  // ---- r13: the r10 wedge instrument, the r12 page-ownership instrument (zr_own) and the DDR read-after-write checker
  // (zk4_raw_check) are out of the core (r12b played clean on the cabinet). The dormant modules + gates live in
  // zk4_diag_dormant.sv; the page-ownership invariant is kept as a sim-only checker in memsys/tb_zr_rsys.cpp. ----
  // ---- status screen pages (OSD "Status page", the Cruis'n gm1 r10/r11 pattern; the milestone bars are the same on every
  // page, only rows A-E change). Counters wrap; difference two screenshots. Decoded in tools/cab/read_zk4_status.md.
  //   0 Health  A faults {cpu_fault[7:0], map, render, unsupported, skips, late, reset-in-download, drops, crc-bad}
  //             B INT0 frames   C instructions[31:16]   D sampled CPU PC[23:8]   E IN1 (controls)
  //   1 CPU     A INT0 frames   B display flips   C CPU bus-wait clocks[31:16]   D ext-wait clocks[31:16]   E Zeus writes
  //   2 Render  A FIFO command words   B command-queue peak   C cmd-queue full clocks[31:16]   D DDR write beats[31:16]
  //             E {scanout skips[7:0], scanout late[7:0]}
  //   3 DDR3    A partial-byte-enable DDR writes (any address; must stay 0 on r6+)   B bank-1 read commands
  //             C {bank-1 read-back seen, first write seen, read-back armed, 5'b0, first write BE[7:0]}
  //             D first bank-1 write DIN[31:16]   E its port read-back [31:16]
  //   4 Sound   A {rom_loaded, crc_ok, dsp_pc[13:0]}   B last DCS command   C DCS reply reads   D DAC underruns
  //             E sound cache misses
  //   5-7       (r13: no page; the r10 Wedge / r12 Pages instruments are out) = Health
  always_comb
    unique case (status_page)
      3'd1: begin row_a = diag[1][15:0]; row_b = diag[3][15:0]; row_c = diag[11][31:16]; row_d = diag[12][31:16];
                  row_e = diag[2][15:0]; end
      3'd2: begin row_a = diag[4][15:0]; row_b = diag[6][15:0]; row_c = diag[7][31:16]; row_d = diag[5][31:16];
                  row_e = {scan_skip[7:0], scan_late[7:0]}; end
`ifndef ZK4_NO_DDR_DIAG
      3'd3: begin row_a = dg_benotff; row_b = dg_rdcnt; row_c = {dg_rb_seen, dg_w_seen, dg_rb_arm, 5'd0, dg_w_be};
                  row_d = dg_w_din[31:16]; row_e = dg_rb_val[31:16]; end
`endif
      3'd4: begin row_a = {ds_rom_loaded, ds_crc_ok, ds_dsp_pc}; row_b = diag[9][15:0]; row_c = diag[10][15:0];
                  row_d = ds_dac_underruns[15:0]; row_e = ds_cache_misses[15:0]; end
      default: begin
                  row_a = {cpu_fault, sdram_map_fault, render_fault, render_unsupported, scan_skip != 0, scan_late != 0,
                           rst_in_dl, dropped != 0, crc_bad};
                  row_b = diag[1][15:0]; row_c = diag[0][31:16]; row_d = pc_s; row_e = in_port[2]; end
    endcase
  zk4_status_mirror #(.NP(MIRROR_NP)) u_mirror (.clk, .por, .enable(1'b1), .payload, .write(m_write), .address(m_addr), .writedata(m_wd),
    .waitrequest(m_wait));
`endif
endmodule
