// zk4_wedge_diag gate (r10 cabinet wedge instrument, zk4_top.sv). Built with -GWD_LOG2=10: a watchdog fires after 1024
// clocks of work without progress, "stuck" = 32. Every scenario starts from a power-on reset. Checked:
//   T1 healthy traffic (random DDRAM_BUSY with commands held, reads returned, every stage progressing): nothing fires,
//      read beats requested - returned == outstanding
//   T2 DDR stall (BUSY stuck high under a held read; the stall then climbs the chain gateway .. queue): fires stage 8,
//      the chain snapshot = the state bus at the fire clock, BUSY run ~ 1024, sticky afterwards
//   T3 lost read response (4-beat read, 3 beats return; the gateway stops on the same clock): stage 8 (tie with 7 ->
//      the downstream stage), 1 beat outstanding latched, BUSY low
//   T4 front-end wedge (only stage 2 has work): fires stage 2
//   T5 protocol: a) ADDR changed under BUSY -> id 3 + the new address  b) DIN changed under a held write -> id 5
//      c) a read beat with none outstanding -> id 7
//   T6 FIFO ring + first-queue-full snapshot (frozen on the FIRST full, the live ring keeps moving)
//   T7 run low (game in reset): a stuck stage never fires
// usage: tb_zk4_wedge_diag
#include "Vzk4_wedge_diag.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <deque>
typedef uint64_t u64; typedef uint32_t u32;
static u64 rs = 0x2545F4914F6CDD1Dull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static Vzk4_wedge_diag* t; static u64 clk = 0; static long errs = 0;
#define CHECK(c, ...) do { if (!(c)) { errs++; printf("ERR [%s] ", cur); printf(__VA_ARGS__); printf("\n"); } } while (0)
static const char* cur = "";
static u32 snapw[6];
static void set_snap(u64 c) { for (int i = 0; i < 6; i++) { snapw[i] = (u32)(c * 0x9E3779B1u + i * 0x1111u); t->snap[i] = snapw[i]; } }
static void edge() { t->clk = 0; t->wall = clk; set_snap(clk); t->eval(); t->clk = 1; t->eval(); clk++; }
static void idle_inputs() {
    t->wd_work = 0; t->wd_prog = 0; t->cq_full = 0; t->fifo_we = 0; t->fifo_wd = 0; t->cpu_pc = 0x01C164; t->zv = 0;
    t->zoff = 0; t->zdata = 0; t->d_busy = 0; t->d_rd = 0; t->d_we = 0; t->d_rdv = 0; t->d_addr = 0; t->d_bc = 1;
    t->d_din = 0; t->d_be = 0xFF;
}
static void por() { idle_inputs(); t->por = 1; t->run = 0; for (int i = 0; i < 4; i++) edge(); t->por = 0; t->run = 1; }
static u32 f(u64 w, int hi, int lo) { return (u32)((w >> lo) & ((1ull << (hi - lo + 1)) - 1)); }
#define W0 (t->w[0])
static u32 wd_id() { return f(W0, 63, 60); } static u32 pf_id() { return f(W0, 59, 56); }
static u32 wd_fired() { return f(W0, 39, 39); } static u32 pf_fired() { return f(W0, 38, 38); }

// a healthy DDR port: one outstanding command at a time offered, held while BUSY, reads returned 12 clocks later
struct Port { std::deque<u64> ret; bool off = false; bool rd = false; u32 addr = 0x06100000; int bc = 1; u64 din = 0; };
static void port_step(Port& p, bool stall_busy, int busy_pct, bool allow_new = true) {
    // drive this clock's command (held unchanged until accepted)
    if (allow_new && !p.off && (rnd() % 4 == 0)) { p.off = true; p.rd = rnd() & 1; p.addr = 0x06000000 + (rnd() & 0xFFFF); p.bc = 1 + rnd() % 8; p.din = rnd(); }
    t->d_rd = p.off && p.rd; t->d_we = p.off && !p.rd; t->d_addr = p.addr; t->d_bc = p.rd ? p.bc : 1; t->d_din = p.din;
    t->d_busy = stall_busy ? 1 : ((int)(rnd() % 100) < busy_pct);
    t->d_rdv = 0;
    if (!p.ret.empty() && p.ret.front() <= clk) { t->d_rdv = 1; p.ret.pop_front(); }
    bool acc = p.off && !t->d_busy;
    if (acc) { if (p.rd) for (int b = 0; b < p.bc; b++) p.ret.push_back(clk + 12 + b); p.off = false; }
}

int main(int argc, char** argv) {
    Verilated::commandArgs(argc, argv);
    t = new Vzk4_wedge_diag;
    // ---------------- T1 healthy ----------------
    cur = "T1 healthy"; por(); { Port p;
        for (int c = 0; c < 40000; c++) { t->wd_work = 0x7F; t->wd_prog = (u32)(rnd() & 0x7F); port_step(p, false, 60); edge(); }
        CHECK(!wd_fired() && !pf_fired(), "fired: wd %u id %u pf %u id %u", wd_fired(), wd_id(), pf_fired(), pf_id());
        u32 rq = f(t->w[4], 63, 32), rr = f(t->w[4], 31, 0), ro = f(t->w[6], 31, 16);
        CHECK(rq - rr == ro && rq > 1000, "read beats req %u ret %u outstanding %u", rq, rr, ro);
        CHECK(f(t->w[5], 31, 0) >= 5, "busy max run %u", f(t->w[5], 31, 0)); }
    // ---------------- T2 DDR stall ----------------
    cur = "T2 DDR stall"; por(); { Port p; u64 s0 = 0; bool seen = false; u32 fs[6];
        for (int c = 0; c < 3000; c++) { t->wd_work = 0x7F; t->wd_prog = (u32)(rnd() & 0x7F) | 1; port_step(p, false, 50); edge(); }
        while (p.off || !p.ret.empty()) { port_step(p, false, 0, false); edge(); }   // finish the held command, drain the returns
        // a held read under a BUSY that never drops; the chain stops upstream of it, stage by stage
        t->d_rd = 1; t->d_we = 0; t->d_addr = 0x06101234; t->d_bc = 4; t->d_busy = 1; t->d_rdv = 0; s0 = clk;
        for (int c = 0; c < 4000; c++) {
            u32 prog = 0;
            for (int s = 0; s < 7; s++) if (clk - s0 < (u64)(50 * (7 - s))) prog |= (rnd() & 1) << s;   // gateway (s=6) stops first
            t->wd_work = 0x7F; t->wd_prog = prog; edge();
            if (!seen && wd_fired()) { seen = true; for (int i = 0; i < 6; i++) fs[i] = snapw[i];
                CHECK(clk - s0 >= 1024 && clk - s0 <= 1026, "fired %llu clocks after the stall", (unsigned long long)(clk - s0)); }
        }
        CHECK(seen && wd_id() == 8, "watchdog id %u (want 8, the DDR port)", wd_id());
        CHECK(!pf_fired(), "protocol violation id %u on a legal held read", pf_id());
        CHECK((f(W0, 55, 48) & 0xC0) == 0xC0, "stuck-at-fire vector %02X lacks stages 7/8", f(W0, 55, 48));
        CHECK(f(W0, 23, 0) == 0x01C164, "pc %06X", f(W0, 23, 0));
        if (seen) for (int i = 0; i < 3; i++) {
            u64 want = ((u64)fs[2 * i + 1] << 32) | fs[2 * i];
            CHECK(t->w[13 + i] == want, "fire snapshot word %d = %016llX, want %016llX (sticky, the fire clock)", i, (unsigned long long)t->w[13 + i], (unsigned long long)want);
        }
        u32 wb = f(t->w[20], 31, 0); CHECK(wb >= 1023 && wb <= 1026, "BUSY run at the fire %u", wb);
        CHECK((t->row_a >> 12) == 8 && ((t->row_a >> 6) & 1) && ((t->row_a >> 8) & 0xF) == 0, "Wedge row A %04X", t->row_a); }
    // ---------------- T3 lost read response ----------------
    cur = "T3 lost read"; por(); {
        for (int c = 0; c < 200; c++) { t->wd_work = 0x7F; t->wd_prog = 0x7F; edge(); }
        t->d_rd = 1; t->d_bc = 4; t->d_addr = 0x06000100; t->d_busy = 0; edge(); t->d_rd = 0;     // accepted: 4 beats owed
        for (int c = 0; c < 12; c++) { t->wd_prog = 0x7F; edge(); }
        for (int b = 0; b < 3; b++) { t->d_rdv = 1; t->wd_prog = 0x7F; edge(); }                   // only 3 return
        t->d_rdv = 0;
        for (int c = 0; c < 3000; c++) { t->wd_work = 0x7F; t->wd_prog = c < 200 ? 0x3F : 0; edge(); }   // gateway (bit 6) stops with the port
        CHECK(wd_fired() && wd_id() == 8, "watchdog id %u (want 8: a read response never came back)", wd_id());
        CHECK(f(t->w[20], 63, 48) == 1, "read beats outstanding at the fire %u (want 1)", f(t->w[20], 63, 48));
        CHECK(!pf_fired(), "protocol id %u", pf_id()); CHECK(t->row_d == 1, "row D %04X", t->row_d); }
    // ---------------- T4 front-end wedge ----------------
    cur = "T4 front wedge"; por(); {
        for (int c = 0; c < 3000; c++) { t->wd_work = 0x02; t->wd_prog = 0; edge(); }
        CHECK(wd_fired() && wd_id() == 2, "watchdog id %u (want 2)", wd_id()); }
    // ---------------- T5 protocol ----------------
    cur = "T5a addr under busy"; por(); {
        t->d_rd = 1; t->d_bc = 2; t->d_addr = 0x06000AAA; t->d_busy = 1; edge(); edge();
        t->d_addr = 0x06000BBB; edge(); t->d_busy = 0; edge(); t->d_rd = 0; for (int c = 0; c < 40; c++) { t->d_rdv = c < 2; edge(); } t->d_rdv = 0;
        CHECK(pf_fired() && pf_id() == 3, "protocol id %u (want 3)", pf_id());
        CHECK(f(t->w[1], 28, 0) == 0x06000BBB, "violation address %07X", f(t->w[1], 28, 0)); }
    cur = "T5b din under busy"; por(); {
        t->d_we = 1; t->d_bc = 1; t->d_addr = 0x06100000; t->d_din = 0x1111; t->d_busy = 1; edge(); edge();
        t->d_din = 0x2222; edge(); t->d_busy = 0; edge(); t->d_we = 0; edge();
        CHECK(pf_fired() && pf_id() == 5, "protocol id %u (want 5)", pf_id()); }
    cur = "T5c stray read beat"; por(); {
        for (int c = 0; c < 5; c++) edge(); t->d_rdv = 1; edge(); t->d_rdv = 0; edge();
        CHECK(pf_fired() && pf_id() == 7, "protocol id %u (want 7)", pf_id()); }
    // ---------------- T6 FIFO ring + first-full snapshot ----------------
    cur = "T6 ring"; por(); { u32 cs[6];
        for (u32 k = 0; k < 10; k++) { t->fifo_we = 1; t->fifo_wd = 0x100 + k; edge(); t->fifo_we = 0; edge(); }
        t->cq_full = 1; edge(); for (int i = 0; i < 6; i++) cs[i] = snapw[i]; t->cq_full = 0; edge();
        for (u32 k = 0; k < 5; k++) { t->fifo_we = 1; t->fifo_wd = 0x200 + k; edge(); } t->fifo_we = 0;
        t->cq_full = 1; for (int c = 0; c < 5; c++) edge(); t->cq_full = 0; edge();
        CHECK(t->w[18] == ((0x109ull << 32) | 0x108) && t->w[19] == ((0x107ull << 32) | 0x106), "frozen ring %016llX %016llX",
              (unsigned long long)t->w[18], (unsigned long long)t->w[19]);
        CHECK(t->w[16] == ((0x204ull << 32) | 0x203) && t->w[17] == ((0x202ull << 32) | 0x201), "live ring %016llX %016llX",
              (unsigned long long)t->w[16], (unsigned long long)t->w[17]);
        CHECK(f(W0, 37, 37) == 1, "cq-full seen flag");
        for (int i = 0; i < 3; i++) { u64 want = ((u64)cs[2 * i + 1] << 32) | cs[2 * i];
            CHECK(t->w[10 + i] == want, "cq-full snapshot word %d = %016llX, want %016llX", i, (unsigned long long)t->w[10 + i], (unsigned long long)want); }
        CHECK(!wd_fired(), "watchdog fired"); }
    // ---------------- T7 run gating ----------------
    cur = "T7 game in reset"; por(); {
        t->run = 0; for (int c = 0; c < 5000; c++) { t->wd_work = 0x7F; t->wd_prog = 0; edge(); }
        CHECK(!wd_fired(), "watchdog fired while the game was held in reset (id %u)", wd_id()); }
    printf("WEDGE_DIAG errors %ld\n%s\n", errs, errs ? "FAIL" : "PASS");
    delete t; return errs ? 1 : 0;
}
