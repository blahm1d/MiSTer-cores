#!/bin/bash
# mutation check for the emu-level input gate: each classic wiring defect in zk4_emu.sv must FAIL run_zk4_emu_inputs.sh
#   E1 P1 up / down swapped              E2 P1 high punch / high kick swapped   E3 P2 reads player 1's pad for low kick
#   E4 coin2 wired to coin1's bit        E5 blood DIP drives the fatalities bit  E6 Test button not wired
#   E7 IN1 / IN2 swapped at the port list      E8 volume up / down swapped         E9 P2 volume buttons not wired
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; bad=0
run() { out=$(ZEI_MUT="$2" bash $D/run_zk4_emu_inputs.sh 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$1 NOT APPLIED / BUILD FAILED"; bad=1
  elif [ $rc = 0 ]; then echo "$1 SURVIVED"; bad=1
  else echo "$1 killed: $(echo "$out" | grep -m1 FAIL | cut -c1-100)"; fi; }
run E1 's/joystick_0\[0\], joystick_0\[1\], joystick_0\[2\], joystick_0\[3\]};/joystick_0[0], joystick_0[1], joystick_0[3], joystick_0[2]};/'
run E2 's/1.b0, joystick_0\[6\], joystick_0\[5\], joystick_0\[4\]/1'"'"'b0, joystick_0[4], joystick_0[5], joystick_0[6]/'
run E3 's/joystick_1\[9\], joystick_1\[8\], joystick_1\[7\]/joystick_1[9], joystick_0[8], joystick_1[7]/'
run E4 's/p1_start, coin2, coin1}/p1_start, coin1, coin1}/'
run E5 's/~(status\[1\] ? 16.h0200 : 16.h0)/~(status[1] ? 16'"'"'h0100 : 16'"'"'h0)/'
run E6 's/wire test_btn = joystick_0\[12\] | joystick_1\[12\]/wire test_btn = 1'"'"'b0/'
run E7 's/assign ports\[2\] = in1; assign ports\[3\] = in2;/assign ports[2] = in2; assign ports[3] = in1;/'
run E8 's/~{3.d0, vol_up, vol_down, 4.d0,/~{3'"'"'d0, vol_down, vol_up, 4'"'"'d0,/'
run E9 's/wire vol_down = joystick_0\[14\] | joystick_1\[14\], vol_up = joystick_0\[15\] | joystick_1\[15\];/wire vol_down = joystick_0[14], vol_up = joystick_0[15];/'
exit $bad

