// tb_zk4_emu_audio_gain.sv -- EMU-LEVEL Audio Gain gate (MK4 and, with +define ZK4_GAME_INVASION, Invasion): the real
// zk4_emu + real sys/hps_io.sv + the whole zk4 core (held in reset; the gain path needs no CPU). Verilator --timing.
// Expected from gen_audio_gain_golden.py's OSD contract (+OSD=<osd.txt>), not from zk4_emu.sv:
//   (1) the CONF_STR carries the exact golden "Audio Gain" entry, exactly once
//   (2) status-bit audit over the WHOLE CONF_STR: no two O/T/R entries share a status bit (so the gain bits 11:10
//       collide with nothing -- Invasion's gun / border / crosshair pages included)
//   (3) OSD status[11:10] = s, sent over HPS_BUS (command 0x1E), reaches zk4_audio_gain's code input as the golden
//       gain code -- with every other status bit 0, then with every other status bit 1 (no cross-talk)
`timescale 1ns/1ps
module tb_zk4_emu_audio_gain;
    logic clk50 = 1'b0;
    always #10 clk50 = ~clk50;
    wire  [45:0] HPS_BUS;
    logic [15:0] io_din = 16'h0000;
    logic        io_strobe = 1'b0, io_enable = 1'b0;
    assign HPS_BUS[45:38] = 8'd0;
    assign HPS_BUS[35]    = 1'b0;
    assign HPS_BUS[34]    = io_enable;
    assign HPS_BUS[33]    = io_strobe;
    assign HPS_BUS[31:16] = io_din;
    wire  [15:0] SDRAM_DQ;
    wire  [3:0]  ADC_BUS;
    logic        emu_reset = 1'b1;
    emu u_emu (
        .CLK_50M(clk50), .RESET(emu_reset), .HPS_BUS(HPS_BUS),
        .CLK_VIDEO(), .CE_PIXEL(), .VIDEO_ARX(), .VIDEO_ARY(),
        .VGA_R(), .VGA_G(), .VGA_B(), .VGA_HS(), .VGA_VS(), .VGA_DE(), .VGA_F1(), .VGA_SL(),
        .VGA_SCALER(), .VGA_DISABLE(),
        .HDMI_WIDTH(12'd0), .HDMI_HEIGHT(12'd0), .HDMI_FREEZE(), .HDMI_BLACKOUT(), .HDMI_BOB_DEINT(),
        .LED_USER(), .LED_POWER(), .LED_DISK(), .BUTTONS(),
        .CLK_AUDIO(1'b0), .AUDIO_L(), .AUDIO_R(), .AUDIO_S(), .AUDIO_MIX(),
        .ADC_BUS(ADC_BUS),
        .SD_SCK(), .SD_MOSI(), .SD_MISO(1'b0), .SD_CS(), .SD_CD(1'b0),
        .DDRAM_CLK(), .DDRAM_BUSY(1'b0), .DDRAM_BURSTCNT(), .DDRAM_ADDR(), .DDRAM_DOUT(64'd0),
        .DDRAM_DOUT_READY(1'b0), .DDRAM_RD(), .DDRAM_DIN(), .DDRAM_BE(), .DDRAM_WE(),
        .SDRAM_CLK(), .SDRAM_CKE(), .SDRAM_A(), .SDRAM_BA(), .SDRAM_DQ(SDRAM_DQ),
        .SDRAM_DQML(), .SDRAM_DQMH(), .SDRAM_nCS(), .SDRAM_nCAS(), .SDRAM_nRAS(), .SDRAM_nWE(),
        .UART_CTS(1'b0), .UART_RTS(), .UART_RXD(1'b0), .UART_TXD(), .UART_DTR(), .UART_DSR(1'b0),
        .USER_IN(7'h7f), .USER_OUT(), .OSD_STATUS(1'b0));

    // ---------------------------------------------------------------- HPS side (tb_zk4_emu_inputs.sv)
    task automatic word(input [15:0] w);
        begin io_din = w; @(negedge clk50); io_strobe = 1'b1; @(negedge clk50); io_strobe = 1'b0; repeat (2) @(negedge clk50); end
    endtask
    task automatic cmd_begin(input [15:0] c);
        begin @(negedge clk50); io_enable = 1'b1; @(negedge clk50); word(c); end
    endtask
    task automatic cmd_end;
        begin @(negedge clk50); io_enable = 1'b0; repeat (12) @(negedge clk50); end
    endtask
    logic [127:0] status = 128'd0;
    task automatic send_status;
        integer k;
        begin cmd_begin(16'h001e); for (k = 0; k < 8; k = k + 1) word(status[k*16 +: 16]); cmd_end(); end
    endtask

    // ---------------------------------------------------------------- CONF_STR parsing
    function automatic int bitchar(input byte c);   // MiSTer legacy option index: 0-9, A-V = 10-31
        if (c >= "0" && c <= "9") return c - "0";
        if (c >= "A" && c <= "V") return c - "A" + 10;
        return -1;
    endfunction
    integer errors = 0, checks = 0;
    string cs, golden_entry, entries [$];

    task automatic audit_bits;
        logic [127:0] used, m; string e; int i, p, lo, hi, base, a, b, colon; byte t;
        used = '0;
        for (i = 1; i < entries.size(); i = i + 1) begin      // entry 0 = the core name
            e = entries[i]; p = 0;
            if (e.len() >= 3 && e.getc(0) == "P" && e.getc(1) >= "0" && e.getc(1) <= "9" && e.getc(2) != ",") p = 2;
            if (e.len() < p + 2) continue;
            t = e.getc(p);
            if (!(t == "O" || t == "T" || t == "R" || t == "o" || t == "t" || t == "r")) continue;
            base = (t == "o" || t == "t" || t == "r") ? 32 : 0;
            if (e.getc(p + 1) == "[") begin
                colon = -1; b = p + 2; while (b < e.len() && e.getc(b) != "]") begin if (e.getc(b) == ":") colon = b; b = b + 1; end
                if (colon < 0) begin hi = e.substr(p + 2, b - 1).atoi(); lo = hi; end
                else begin hi = e.substr(p + 2, colon - 1).atoi(); lo = e.substr(colon + 1, b - 1).atoi(); end
            end else begin
                lo = bitchar(e.getc(p + 1)); hi = lo;
                if ((t == "O" || t == "o") && e.getc(p + 2) != ",") hi = bitchar(e.getc(p + 2));
                if (lo < 0 || hi < 0) begin errors = errors + 1; $display("FAIL unparsed CONF_STR entry '%s'", e); continue; end
                lo = lo + base; hi = hi + base;
            end
            m = '0; for (a = lo; a <= hi; a = a + 1) m[a] = 1'b1;
            checks = checks + 1;
            if ((m & used) != '0) begin errors = errors + 1; $display("FAIL status bit collision: '%s' (bits %0d..%0d)", e, hi, lo); end
            used = used | m;
        end
        $display("AUDIO_GAIN_EMU: %0d O/T/R entries audited, status bits used %032x", checks, used);
    endtask

    // ---------------------------------------------------------------- run
    integer fd, s, code, exp_code [4], n;
    string osd, line;
    task automatic chk_code(input string what, input int st);
        begin
            repeat (8) @(negedge clk50);
            checks = checks + 1;
            if (u_emu.u_gain.code !== exp_code[st][1:0]) begin errors = errors + 1;
                $display("FAIL %0s: OSD status[11:10] = %0d -> gain code %0d, golden %0d", what, st, u_emu.u_gain.code, exp_code[st]); end
        end
    endtask
    initial begin
        int i, start, hits;
        if (!$value$plusargs("OSD=%s", osd)) begin $display("FAIL no +OSD"); $finish; end
        fd = $fopen(osd, "r"); if (fd == 0) begin $display("FAIL cannot open %s", osd); $finish; end
        void'($fgets(golden_entry, fd));
        while (golden_entry.len() > 0 && (golden_entry.getc(golden_entry.len() - 1) inside {8'h0a, 8'h0d, ";"}))
            golden_entry = golden_entry.substr(0, golden_entry.len() - 2);   // drop the line end and the ';'
        n = 0; while ($fscanf(fd, "%d %d\n", s, code) == 2) begin exp_code[s] = code; n = n + 1; end
        $fclose(fd);
        if (n != 4) begin $display("FAIL golden OSD file has %0d rows", n); $finish; end
`ifdef ZK4_GAME_INVASION
        $display("AUDIO_GAIN_EMU variant INVASION");
`else
        $display("AUDIO_GAIN_EMU variant MK4");
`endif
        // (1) + (2): the CONF_STR as the core hands it to hps_io
        cs = $sformatf("%s", u_emu.CONF_STR);
        start = 0; for (i = 0; i <= cs.len(); i = i + 1) if (i == cs.len() || cs.getc(i) == ";") begin
            entries.push_back(cs.substr(start, i - 1)); start = i + 1; end
        hits = 0; foreach (entries[k]) if (entries[k] == golden_entry) hits = hits + 1;
        checks = checks + 1;
        if (hits != 1) begin errors = errors + 1; $display("FAIL CONF_STR has %0d copies of the golden entry '%s'", hits, golden_entry); end
        audit_bits();
        // (3): OSD status through the real hps_io
        repeat (20) @(negedge clk50); emu_reset = 1'b0;
        repeat (200) @(negedge clk50);
        for (s = 0; s < 4; s = s + 1) begin
            status = 128'd0; status[11:10] = s[1:0]; send_status(); chk_code("other bits 0", s);
        end
        for (s = 0; s < 4; s = s + 1) begin
            status = ~128'd0; status[11:10] = s[1:0]; send_status(); chk_code("other bits 1", s);
        end
        $display("AUDIO_GAIN_EMU checks %0d errors %0d", checks, errors);
        $display("%0s", errors == 0 ? "PASS" : "FAIL");
        $finish;
    end
    initial begin #50_000_000; $display("FAIL: timeout"); $finish; end
endmodule
