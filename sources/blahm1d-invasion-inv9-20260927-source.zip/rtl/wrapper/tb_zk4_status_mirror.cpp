// zk4_status_mirror gate: hostile waitrequest; the payload CHANGES every clock (word k = clock * (k+1) + k). Checked:
//   * Avalon: an offered write (address, data) is unchanged while waitrequest is high
//   * each block lands as NP+2 writes (r13: NP = 17, 19 words at BASE .. BASE+144): word 0 = {MAGIC, odd seq}, the last = {MAGIC, seq + 1 (even)}
//   * payload words 1-NP equal the payload as it was at ONE instant (the clock the block opened), all NP the same instant
//   * blocks keep coming (one per PERIOD after acceptance), seq strictly increasing
// usage: tb_zk4_status_mirror [cycles] [wait%]   (built with -GPERIOD=500 so a short run carries many blocks)
#include "Vzk4_status_mirror.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <vector>
#ifndef ZNP
#define ZNP 17                                   // payload words (zk4_top NP; r13 = 17, 19-word block)
#endif
static const int NW = ZNP + 2;
typedef uint64_t u64; typedef uint32_t u32;
static u64 rs = 0x9E3779B97F4A7C15ull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
int main(int argc, char** argv) {
    long N = argc > 1 ? atol(argv[1]) : 200000; int W = argc > 2 ? atoi(argv[2]) : 50;
    Verilated::commandArgs(argc, argv);
    Vzk4_status_mirror* t = new Vzk4_status_mirror;
    const u32 BASE = 0x30C00000u, MAGIC = 0x7A6B3453u;
    auto pay = [](u64 clk, int k) { return clk * (u64)(k + 1) + (u64)k; };
    long errs = 0, blocks = 0; u64 clk = 0;
    bool prev_off = false; u32 p_addr = 0; u64 p_data = 0;
    std::vector<u64> blk; u64 open_clk = 0; u32 last_seq = 0;
    t->por = 1; t->enable = 1; for (int i = 0; i < 4; i++) { t->clk = 0; t->eval(); t->clk = 1; t->eval(); } t->por = 0;
    for (long c = 0; c < N; c++) {
        t->clk = 0;
        for (int k = 0; k < ZNP; k++) t->payload[k] = pay(clk, k);
        t->waitrequest = (int)(rnd() % 100) < W;
        t->eval();
        // the block opens on the first clock its word 0 is offered (payload captured on the edge before)
        if (t->write && blk.empty() && !prev_off && t->address == BASE) open_clk = clk;
        if (prev_off && (!t->write || t->address != p_addr || t->writedata != p_data) && errs++ < 10)
            printf("ERR clk %llu: offered write changed while waitrequest\n", (unsigned long long)clk);
        prev_off = t->write && t->waitrequest; p_addr = t->address; p_data = t->writedata;
        if (t->write && !t->waitrequest) {
            u32 idx = (t->address - BASE) / 8;
            if (t->address < BASE || (t->address - BASE) % 8 || idx >= (u32)NW || idx != blk.size()) {
                if (errs++ < 10) printf("ERR clk %llu: write to %08X out of sequence (expected word %zu)\n", (unsigned long long)clk, t->address, blk.size());
            }
            blk.push_back(t->writedata);
            if ((int)blk.size() == NW) {
                u32 m0 = blk[0] >> 32, s0 = (u32)blk[0], m15 = blk[NW - 1] >> 32, s15 = (u32)blk[NW - 1];
                if (m0 != MAGIC || m15 != MAGIC || !(s0 & 1) || (s15 & 1) || s0 + 1 != s15 || s15 <= last_seq) {
                    if (errs++ < 10) printf("ERR block %ld: seqlock words %016llX / %016llX\n", blocks, (unsigned long long)blk[0], (unsigned long long)blk[NW - 1]);
                }
                last_seq = s15;
                // all ZNP payload words from ONE instant: solve the instant from word 1 (k = 0: clock)
                u64 inst = blk[1];
                for (int k = 0; k < ZNP; k++) if (blk[k + 1] != pay(inst, k) && errs++ < 10)
                    printf("ERR block %ld: payload word %d = %llX, not the instant %llu\n", blocks, k + 1, (unsigned long long)blk[k + 1], (unsigned long long)inst);
                if (inst + 1 != open_clk) { if (errs++ < 10) printf("ERR block %ld: captured at %llu, opened %llu\n", blocks, (unsigned long long)inst, (unsigned long long)open_clk); }
                blocks++; blk.clear();
            }
        }
        t->eval(); t->clk = 1; t->eval(); clk++;
    }
    printf("MIRROR blocks %ld (wait %d%%), errors %ld\n", blocks, W, errs);
    bool pass = errs == 0 && blocks > 50;
    printf("%s\n", pass ? "PASS" : "FAIL");
    delete t; return pass ? 0 : 1;
}
