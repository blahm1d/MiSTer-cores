// zk4_diag_dormant.sv -- cabinet instruments that are NOT in the core (not in quartus/files.qip, not linted with
// zk4_top). Moved out of zk4_top.sv in zk4-r13 once the game ran clean (r12b: 'the game is perfect'); each keeps its own
// standalone gate (run_zk4_wedge_diag.sh / run_zk4_raw_check.sh + mutants) for a future cabinet fault.
//   zk4_wedge_diag  r10 render-chain wedge instrument (519 ALM). Its zr_* probe ports were unwired in r13: re-adding
//                   it means re-adding those taps (see git f7746f4b zr_front5/zr_render5/zr_memsys/zr_ddr_gateway/zr_cmdq).
//   zk4_raw_check   r12 DDRAM read-after-write witness (242 ALM at N=2; 3 mirror words).

// zk4_wedge_diag -- NOT INSTANTIATED since r12 (area: 519 ALM; kept with its gate run_zk4_wedge_diag.sh for a future wedge).
// r10 cabinet WEDGE instrument (register-only: no RAM). r8/r9 on the cabinet: ~20 s after the CPU starts
// the command queue fills and never drains; a 2-hour Verilator cold boot over the same region does not wedge, so the
// fault is silicon-only. This block says WHERE the render chain stopped:
//  * STALL WATCHDOGS (the Model 1 "sticky location" method). Stages 1 command queue, 2 front end, 3 record parser, 4 setup,
//    5 pixel pipe, 6 memsys, 7 DDR gateway (zr_rsys wd_work / wd_prog) and 8 the DDRAM port (here: work = a command
//    offered or read beats outstanding, progress = a command accepted or a read beat returned). Each counts consecutive
//    clocks of work without progress; the first to reach 2**WD_LOG2 latches ONCE (sticky from power-on): its id (the
//    most downstream wins a tie -- a stall propagates upstream, so the first stage stuck is the blocker), which stages
//    had been stuck >= 2**(WD_LOG2-5), the render chain's state bus, the CPU PC, the Zeus write in flight, the DDR port.
//  * DDR AVALON PROTOCOL CHECKER (the Cruis'n gm1 attract-freeze lesson: an offered command that changed while the port
//    held waitrequest killed the port). First violation latched (id + DDRAM_ADDR), count kept. Ids: 1 RD changed while
//    held, 2 WE changed, 3 ADDR changed (command beat), 4 BURSTCNT changed (command beat), 5 DIN changed (held write),
//    6 BE changed, 7 read beat returned with none outstanding, 8 RD offered inside a write burst, 9 RD and WE together,
//    10 BURSTCNT = 0 on a command beat. (Lowest id wins a same-clock tie.)
//  * the DDR port's traffic: read beats requested / returned, write beats accepted, DDRAM_BUSY consecutive-high run
//    (current + max), read beats outstanding.
//  * the last 4 FIFO command words (0xE0) accepted, live, and a copy + the chain's state frozen at the FIRST clock the
//    command queue is full.
// Payload words (zk4_top payload[17 + k] = w[k], mirror word 18 + k); decoded by tools/cab/analyze_zk4_perflog.py.
module zk4_wedge_diag #(parameter int WD_LOG2 = 21, parameter int SW = 192) (
  input  logic        clk, por, run,                           // run: the game is out of reset (watchdogs count only then)
  input  logic [6:0]  wd_work, wd_prog,                        // stages 1..7 (bit k = stage k+1)
  input  logic [SW-1:0] snap,                                  // the render chain's state bus (zr_rsys wd_snap)
  input  logic        cq_full,
  input  logic        fifo_we, input logic [31:0] fifo_wd,
  input  logic [23:0] cpu_pc, input logic zv, input logic [9:0] zoff, input logic [31:0] zdata,
  input  logic [63:0] wall,
  input  logic        d_busy, d_rd, d_we, d_rdv, input logic [28:0] d_addr, input logic [7:0] d_bc,
  input  logic [63:0] d_din, input logic [7:0] d_be,
  output logic [63:0] w [21],
  output logic [15:0] row_a, row_b, row_c, row_d, row_e
);
  localparam int SL = WD_LOG2 - 5;                             // "stuck" threshold for the stuck vectors
  // ---------------- DDR port ----------------
  logic offered, acc; assign offered = d_rd || d_we; assign acc = offered && !d_busy;
  logic [15:0] rd_out; logic [7:0] wl;                         // read beats outstanding, write-burst data beats owed
  logic [31:0] rd_req, rd_ret, wr_acc, busy_cur, busy_max;
  always_ff @(posedge clk)
    if (por) begin rd_out <= '0; wl <= '0; rd_req <= '0; rd_ret <= '0; wr_acc <= '0; busy_cur <= '0; busy_max <= '0; end
    else begin
      rd_out <= rd_out + ((acc && d_rd) ? 16'(d_bc) : 16'd0) - ((d_rdv && rd_out != 16'd0) ? 16'd1 : 16'd0);
      if (acc && d_we) wl <= (wl == 8'd0) ? d_bc - 8'd1 : wl - 8'd1;
      if (acc && d_rd) rd_req <= rd_req + 32'(d_bc);
      if (d_rdv) rd_ret <= rd_ret + 1'b1;
      if (acc && d_we) wr_acc <= wr_acc + 1'b1;
      busy_cur <= !d_busy ? 32'd0 : (&busy_cur ? busy_cur : busy_cur + 1'b1);
      if (d_busy && busy_cur >= busy_max && !(&busy_max)) busy_max <= busy_cur + 1'b1;
    end
  // ---------------- Avalon protocol checker ----------------
  logic p_pend, p_rd, p_we, p_first; logic [28:0] p_addr; logic [7:0] p_bc, p_be; logic [63:0] p_din;
  always_ff @(posedge clk) begin
    p_pend <= !por && offered && d_busy; p_rd <= d_rd; p_we <= d_we; p_first <= wl == 8'd0;
    p_addr <= d_addr; p_bc <= d_bc; p_be <= d_be; p_din <= d_din;
  end
  logic [9:0] pv;
  always_comb begin
    pv = '0;
    if (p_pend) begin
      pv[0] = d_rd != p_rd;
      pv[1] = d_we != p_we;
      if (p_first) begin pv[2] = d_addr != p_addr; pv[3] = d_bc != p_bc; end
      if (p_we) begin pv[4] = d_din != p_din; pv[5] = d_be != p_be; end
    end
    pv[6] = d_rdv && rd_out == 16'd0;
    pv[7] = d_rd && wl != 8'd0;
    pv[8] = d_rd && d_we;
    pv[9] = offered && wl == 8'd0 && d_bc == 8'd0;
  end
  logic [3:0] pv_id; always_comb begin pv_id = 4'd0; for (int i = 9; i >= 0; i--) if (pv[i]) pv_id = 4'(i + 1); end
  logic pf_fired; logic [3:0] pf_id; logic [28:0] pf_addr; logic [15:0] pf_cnt;
  always_ff @(posedge clk)
    if (por) begin pf_fired <= 1'b0; pf_id <= '0; pf_addr <= '0; pf_cnt <= '0; end
    else if (pv_id != 4'd0) begin
      if (!(&pf_cnt)) pf_cnt <= pf_cnt + 1'b1;
      if (!pf_fired) begin pf_fired <= 1'b1; pf_id <= pv_id; pf_addr <= d_addr; end
    end
  // ---------------- stall watchdogs ----------------
  logic [7:0] work, prog;
  assign work = {offered || rd_out != 16'd0, wd_work};
  assign prog = {acc || d_rdv, wd_prog};
  logic [WD_LOG2:0] wc [8]; logic [7:0] fire, stuck; logic [3:0] fire_id;
  always_comb begin
    fire_id = 4'd0;
    for (int i = 0; i < 8; i++) begin
      fire[i] = wc[i][WD_LOG2]; stuck[i] = |wc[i][WD_LOG2:SL];
      if (fire[i]) fire_id = 4'(i + 1);                          // the most downstream stage wins a tie
    end
  end
  always_ff @(posedge clk)
    for (int i = 0; i < 8; i++)
      if (por || !run || !work[i] || prog[i]) wc[i] <= '0;
      else if (!wc[i][WD_LOG2]) wc[i] <= wc[i] + 1'b1;
  logic wd_fired, wd_zv; logic [3:0] wd_id; logic [7:0] wd_stuck, wd_wl; logic [23:0] wd_pc; logic [9:0] wd_zoff;
  logic [31:0] wd_zdata, wd_busy; logic [15:0] wd_rdout; logic [63:0] wd_wall; logic [SW-1:0] wd_snap;
  always_ff @(posedge clk)
    if (por) begin
      wd_fired <= 1'b0; wd_id <= '0; wd_stuck <= '0; wd_pc <= '0; wd_zv <= 1'b0; wd_zoff <= '0; wd_zdata <= '0;
      wd_rdout <= '0; wd_wl <= '0; wd_busy <= '0; wd_wall <= '0; wd_snap <= '0;
    end else if (!wd_fired && fire_id != 4'd0) begin
      wd_fired <= 1'b1; wd_id <= fire_id; wd_stuck <= stuck; wd_pc <= cpu_pc; wd_zv <= zv; wd_zoff <= zoff;
      wd_zdata <= zdata; wd_rdout <= rd_out; wd_wl <= wl; wd_busy <= busy_cur; wd_wall <= wall; wd_snap <= snap;
    end
  // ---------------- FIFO word ring + first-queue-full snapshot ----------------
  logic [31:0] ring [4], cq_ring [4]; logic cqf_seen; logic [63:0] cqf_wall; logic [SW-1:0] cqf_snap;
  always_ff @(posedge clk)
    if (por) begin
      for (int k = 0; k < 4; k++) begin ring[k] <= '0; cq_ring[k] <= '0; end
      cqf_seen <= 1'b0; cqf_wall <= '0; cqf_snap <= '0;
    end else begin
      if (run && fifo_we) begin ring[0] <= fifo_wd; for (int k = 1; k < 4; k++) ring[k] <= ring[k - 1]; end
      if (run && cq_full && !cqf_seen) begin
        cqf_seen <= 1'b1; cqf_wall <= wall; cqf_snap <= snap;
        for (int k = 0; k < 4; k++) cq_ring[k] <= ring[k];
      end
    end
  // ---------------- payload ----------------
  logic [63:0] ages; always_comb for (int i = 0; i < 8; i++) ages[8*i +: 8] = wc[i][WD_LOG2 -: 8];
  logic [191:0] sn_l, sn_c, sn_w;
  assign sn_l = 192'(snap); assign sn_c = 192'(cqf_snap); assign sn_w = 192'(wd_snap);
  assign w[0]  = {wd_id, pf_id, wd_stuck, stuck, wd_fired, pf_fired, cqf_seen, wd_zv, 2'd0, wd_zoff, wd_pc};
  assign w[1]  = {wd_zdata, 3'd0, pf_addr};
  assign w[2]  = {wd_wall[39:8], cqf_wall[39:8]};              // 256-clock units (5.12 us)
  assign w[3]  = ages;                                         // stage k+1 at [8k+7:8k]: counter >> (WD_LOG2-7); 0x80 = fired
  assign w[4]  = {rd_req, rd_ret};
  assign w[5]  = {wr_acc, busy_max};
  assign w[6]  = {busy_cur, rd_out, pf_cnt};
  assign w[7]  = sn_l[63:0];    assign w[8]  = sn_l[127:64];  assign w[9]  = sn_l[191:128];
  assign w[10] = sn_c[63:0];    assign w[11] = sn_c[127:64];  assign w[12] = sn_c[191:128];
  assign w[13] = sn_w[63:0];    assign w[14] = sn_w[127:64];  assign w[15] = sn_w[191:128];
  assign w[16] = {ring[0], ring[1]};                           // newest first
  assign w[17] = {ring[2], ring[3]};
  assign w[18] = {cq_ring[0], cq_ring[1]};
  assign w[19] = {cq_ring[2], cq_ring[3]};
  assign w[20] = {wd_rdout, wd_wl, 8'd0, wd_busy};
  // ---------------- OSD page "Wedge" (status_page 5): the stickies first ----------------
  // view = the chain frozen at the watchdog fire once it fired, else live
  logic [191:0] v; logic [15:0] v_rdout; logic [3:0] live_id;
  assign v = wd_fired ? sn_w : sn_l; assign v_rdout = wd_fired ? wd_rdout : rd_out;
  always_comb begin live_id = 4'd0; for (int i = 0; i < 8; i++) if (stuck[i]) live_id = 4'(i + 1); end
  assign row_a = {wd_id, pf_id, cqf_seen, d_busy, rd_out != 16'd0, cq_full, live_id};
  assign row_b = {wd_stuck, stuck};
  assign row_c = {1'b0, v[6:0], 1'b0, v[50:48], v[18], v[21], v[27], v[31]};   // front st | parser rs | s2_on wk_on e_req o_ready
  assign row_d = v_rdout;
  assign row_e = {3'd0, v[140:136], 3'd0, v[150:146]};                        // gateway used | gateway read_count
endmodule

// zk4_raw_check -- r12 DDRAM READ-AFTER-WRITE witness (register-only: no RAM; r12b: sized to ~200 ALM after the r12 fit
// ran out of LABs -- N 8 -> 2 CAM entries, one check in flight, 16-bit data folds and timestamps, window-relative
// addresses). The renderer's memsys and gateway rely on the MiSTer DDRAM port returning, for a read, the data of every
// write this master issued before it (zr_ddr_gateway S3 comment; PSX / Saturn ddram.sv rely on the same). Sims model it
// (in-order DDR); silicon is the question. This taps the DDRAM bus as the arbiter drives it:
//   * the last N accepted full-BE write BEATS inside the zk4 DDR window (words 0x6000000 + [0, 4M): wave RAM 0 / 1, the
//     mirror, the sound ROM; burst beats get address + k) in a CAM: window address, a 16-bit fold of the data, a 16-bit
//     timestamp. A later write to a CAM address updates it; a BE != 0xFF beat (the port drops those) invalidates it.
//   * a SINGLE-BEAT read accepted at an address in the CAM, with no check in flight, is checked: its expected fold, the
//     write's age and the read's beat index are held until that beat returns, then the fold is compared.
// Words: w0 {checked, mismatches}
//        w1 {have_first, 3'd0, first age (clocks since the write, mod 2**16)[15:0], expected fold[15:0], 6'd0,
//            first DDR word address - 0x6000000 [21:0]}
//        w2 first mismatch actual data (64 bits)
module zk4_raw_check #(parameter int N = 2) (
  input  logic        clk, rst,
  input  logic        d_busy, d_rd, d_we, input logic [28:0] d_addr, input logic [7:0] d_bc,
  input  logic [63:0] d_din, input logic [7:0] d_be,
  input  logic        d_rdv, input logic [63:0] d_dout,
  output logic [63:0] w [3]
);
  localparam int PB = (N > 1) ? $clog2(N) : 1;
  function automatic logic [15:0] fold16(input logic [63:0] d); return d[63:48] ^ d[47:32] ^ d[31:16] ^ d[15:0]; endfunction
  logic [15:0] ts;
  logic        cv [N]; logic [21:0] ca [N]; logic [15:0] cd [N]; logic [15:0] ct [N]; logic [PB-1:0] rp;
  logic [7:0]  wleft; logic [28:0] waddr;
  logic [7:0]  seq_iss, seq_ret;
  logic        pv; logic [7:0] ps; logic [21:0] pa; logic [15:0] pe, pg;
  logic [31:0] n_chk, n_mis; logic have_first; logic [21:0] f_addr; logic [15:0] f_age, f_exp; logic [63:0] f_act;
  logic wbeat, rcmd; logic [28:0] wa;
  assign wbeat = d_we && !d_busy;
  assign rcmd  = d_rd && !d_busy;
  assign wa    = (wleft == 8'd0) ? d_addr : waddr;
  logic win_w, win_r; assign win_w = wa[28:22] == 7'h18; assign win_r = d_addr[28:22] == 7'h18;
  logic whit, rhit; logic [PB-1:0] widx, ridx;
  always_comb begin
    whit = 1'b0; widx = '0; rhit = 1'b0; ridx = '0;
    for (int k = 0; k < N; k++) begin
      if (cv[k] && win_w && ca[k] == wa[21:0]) begin whit = 1'b1; widx = PB'(k); end
      if (cv[k] && win_r && ca[k] == d_addr[21:0]) begin rhit = 1'b1; ridx = PB'(k); end
    end
  end
  logic push, pop; assign pop = d_rdv && pv && ps == seq_ret;
  assign push = rcmd && d_bc == 8'd1 && rhit && (!pv || pop);
  always_ff @(posedge clk)
    if (rst) begin
      ts <= '0; rp <= '0; wleft <= '0; waddr <= '0; seq_iss <= '0; seq_ret <= '0; pv <= 1'b0;
      for (int k = 0; k < N; k++) cv[k] <= 1'b0;
      n_chk <= '0; n_mis <= '0; have_first <= 1'b0; f_addr <= '0; f_age <= '0; f_exp <= '0; f_act <= '0;
    end else begin
      ts <= ts + 1'b1;
      if (wbeat) begin
        if (wleft == 8'd0) begin wleft <= d_bc - 8'd1; waddr <= d_addr + 29'd1; end
        else begin wleft <= wleft - 8'd1; waddr <= waddr + 29'd1; end
        if (d_be == 8'hFF && win_w) begin
          if (whit) begin cd[widx] <= fold16(d_din); ct[widx] <= ts; end
          else begin cv[rp] <= 1'b1; ca[rp] <= wa[21:0]; cd[rp] <= fold16(d_din); ct[rp] <= ts; rp <= (rp == PB'(N - 1)) ? '0 : rp + 1'b1; end
        end else if (whit) cv[widx] <= 1'b0;
      end
      if (rcmd) seq_iss <= seq_iss + d_bc;
      if (d_rdv) seq_ret <= seq_ret + 1'b1;
      if (pop) begin
        n_chk <= n_chk + 1'b1;
        if (fold16(d_dout) != pe) begin
          n_mis <= n_mis + 1'b1;
          if (!have_first) begin have_first <= 1'b1; f_addr <= pa; f_age <= pg; f_exp <= pe; f_act <= d_dout; end
        end
      end
      if (push) begin pv <= 1'b1; ps <= seq_iss; pa <= d_addr[21:0]; pe <= cd[ridx]; pg <= ts - ct[ridx]; end
      else if (pop) pv <= 1'b0;
    end
  assign w[0] = {n_chk, n_mis};
  assign w[1] = {have_first, 3'd0, f_age, f_exp, 6'd0, f_addr};
  assign w[2] = f_act;
endmodule
