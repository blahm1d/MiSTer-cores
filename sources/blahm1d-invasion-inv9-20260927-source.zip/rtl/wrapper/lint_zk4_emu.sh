#!/bin/bash
# Elaborate the whole emu top (zk4_emu + sys/hps_io + zk4_top + core) with Verilator for a variant, fail on any %Error or
# PINMISSING / PINNOTFOUND. lint_zk4_top.sh stops at zk4_top; this catches emu-level wiring (the Invasion gun ports,
# joystick_l_analog / ps2_mouse from hps_io, the OSD status bits).
# usage: wsl bash lint_zk4_emu.sh ["-DZK4_GAME_INVASION -DZK4_DCS_FABRIC=1 ..."]
set -u
Z=/mnt/d/deck/fpga/zeus; R=$Z/zeus1/rtl; Q=$Z/zeus1/quartus; C=$Z/core/rtl/cpu
W=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}")
FS="$Q/sys/hps_io.sv $R/wrapper/sim_bw1_pll.sv"
for f in c31_core c31_ea c31_shift c31_mpyi c31_cond c31_addsubf c31_mpyf c31_negf c31_absf c31_rnd c31_norm c31_int2float c31_float2int c31_fconv; do FS="$FS $C/$f.sv"; done
for f in tier/c31_page_cache tier/c31_page_cache_sa tier/c31_bus_adapter tier/zk4_memory_p3 tier/zk4_memory_fp fp32/fp32_pkg fp32/fp32_units \
         setup/zr_sdp front/zr_front5 setup/zr_setup9 pixel/zr_pixel10 render/zr_fifo render/zr_rfifo render/zr_cmdq render/zr_render5 \
         memsys/zr_ddr_gateway memsys/zr_memsys memsys/zr_rsys video/zr_scanout core/zr_host1 core/zk4_c32_ctl core/zk4_int2 core/zk4_core \
         board/zk4_pic2 board/zk4_ioasic board/zk4_dcs_stub board/zk4_cmos board/zk4_board_io board/zk4_gun \
         wrapper/donor/c31_sdram_burst wrapper/donor/c31_sdram_backing wrapper/zk4_sdram wrapper/donor/gm1_hdmi_status wrapper/zk4_ddr_arb \
         wrapper/zk4_ddr_arb3 wrapper/zk4_status_mirror wrapper/zk4_ram_reload wrapper/zk4_loader wrapper/zk4_top wrapper/zk4_audio_gain wrapper/zk4_emu \
         wrapper/gun/zk4_gun_input wrapper/gun/zk4_lightgun_position wrapper/gun/zk4_lightgun_overlay \
         dcs/donor/cusa_dcs_fifo dcs/donor/cusa_dcs_rom_loader dcs/donor/dcs_mem dcs/donor/adsp2105_packed dcs/donor/cusa_dcs2k_packed \
         dcs/donor/cusa_dcs_ddr_agent dcs/donor/cusa_dcs_subsystem \
         dcs2/dcs2_autobuf dcs2/dcs2_engine dcs2/dcs2_ddr_agent dcs2/dcs2_sram_cache dcs2/dcs2_mailbox dcs2/dcs2_sport_dac dcs2/zk4_dcs2; do
  FS="$FS $R/$f.sv"; done
cd $W; verilator --lint-only -Wall -Wno-fatal -Wno-PROCASSWIRE -Wno-BLKANDNBLK -I$Q -I$C -I$R/fp32 ${1:-} --top-module emu $FS > lint.log 2>&1
# hps_io output pins a core does not use stay open by MiSTer convention: its instance line is excused from PINMISSING only
HL=$(grep -n "hps_io #(" $R/wrapper/zk4_emu.sv | head -1 | cut -d: -f1)
grep -E "^%Error|^%Warning-PIN(MISSING|NOTFOUND)" lint.log | grep -v "zk4_emu.sv:$HL:[0-9]*: Cell has missing pin" | grep -v "/quartus/sys/" | head -20
n=$(grep -E "^%Error|^%Warning-PIN(MISSING|NOTFOUND)" lint.log | grep -v "zk4_emu.sv:$HL:[0-9]*: Cell has missing pin" | grep -vc "/quartus/sys/")   # framework-internal warnings are not ours
echo "EMU LINT [${1:-MK4 default}]: errors+pin issues $n (log $W/lint.log)"; [ "$n" = 0 ]
