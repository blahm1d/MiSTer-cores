// tb_zk4_gun_input.sv -- unit gate for the Invasion gun inputs (iverilog). Expected values from MAME 0.289 midzeus.cpp
// INPUT_PORTS_START( invasn ) (GUNX/GUNY 0..0xFF, centre 0x80, no PORT_REVERSE; 0 / 0xFF = off-screen, invasn_gun_r
// cpp:806; TRIGGER active high) and the MiSTer contract (left analog signed, 0 = centre; joystick[3:0] = right, left,
// down, up; hps_io mouse packet), written here independently of zk4_gun_input.sv:
//   A absolute: GUNX = 0x80 + x, GUNY = 0x80 + y over a value sweep, both players independent
//   A (inv5): an absolute axis at +-127 / -128 (either axis) = off-screen, GUNX 0x00
//   B (inv5) reload, the contract MEASURED on MAME d1e9f7db (invasion/tools/inv_reload_probe.lua; the same-frame
//     off-screen + trigger of inv3 does NOT reload): GUNX 0 at once, TRIGGER from frame 6 for >= 6 frames / while held,
//     2 tail frames off-screen, then the aim returns; Trigger + Reload chord and a rail + same-frame trigger get the
//     delayed edge (B1-B4)
//   C D-pad: +2 per frame for 20 held frames then +6, releases HOLD, clamp at 1 / 254 (never off-screen)
//   D mouse: the lowest player that selects it owns it (the other holds 0x80); dx moves X right, left button = trigger;
//     zk4-inv4: packets while nobody owns it are ignored (D0); one shared position carries over to a new owner (D2)
//   E crosshair: column GUNX * 400 / 255 (<= 399), line GUNY
// usage: iverilog -g2012 -o tb.vvp tb_zk4_gun_input.sv zk4_gun_input.sv zk4_lightgun_position.sv && vvp tb.vvp
`timescale 1ns/1ps
module tb_zk4_gun_input;
  logic clk = 0, rst = 1, vs = 0; always #5 clk = ~clk;
  logic [15:0] analog [2]; logic [3:0] dir [2]; logic [1:0] src [2]; logic [1:0] fire = 0, reload = 0; logic [24:0] mouse = 0;
  logic [7:0] gx [2], gy [2]; logic [1:0] trig; logic [8:0] cx [2], cy [2];
  zk4_gun_input dut (.clk, .rst, .vs, .analog, .dir, .src, .fire_btn(fire), .reload_btn(reload), .ps2_mouse(mouse),
    .gun_x(gx), .gun_y(gy), .trigger(trig), .cx, .cy);
  integer errors = 0, checks = 0;
  task automatic settle; repeat (4) @(posedge clk); #1; endtask
  task automatic frame; vs = 1; repeat (3) @(posedge clk); vs = 0; repeat (3) @(posedge clk); #1; endtask
  // (the ports are read inside the DUT: iverilog does not propagate unpacked-array OUTPUT ports to bench variables)
  task automatic expect_port(input int p, input [7:0] ex, input [7:0] ey, input string what);
    checks++;
    if (dut.gun_x[p] !== ex || dut.gun_y[p] !== ey) begin errors++;
      $display("FAIL %s: P%0d port %02x,%02x expected %02x,%02x", what, p + 1, dut.gun_x[p], dut.gun_y[p], ex, ey); end
  endtask
  initial begin
    int v, k; logic [7:0] ex;
    analog[0] = 0; analog[1] = 0; dir[0] = 0; dir[1] = 0; src[0] = 0; src[1] = 0;
    repeat (3) @(posedge clk); rst = 0; settle();
    // A: absolute sweep, players independent
    foreach (analog[p]) ;
    for (v = -128; v <= 127; v += 17) begin
      analog[0] = {8'(v / 2), 8'(v)}; analog[1] = {8'(-v - 1), 8'(v / 3)}; settle();
      // zk4-inv5: an axis at +-127 or -128 (a rail) = aimed off the screen -> GUNX 0x00, GUNY as delivered
      expect_port(0, (v <= -127 || v >= 127 || v / 2 <= -127 || v / 2 >= 127) ? 8'h00 : 8'(128 + v), 8'(128 + v / 2), $sformatf("A x=%0d", v));
      expect_port(1, (v / 3 <= -127 || v / 3 >= 127 || -v - 1 <= -127 || -v - 1 >= 127) ? 8'h00 : 8'(128 + v / 3), 8'(128 - v - 1), $sformatf("A2 x=%0d", v));
    end
    analog[0] = {8'd127, -8'sd128}; settle(); expect_port(0, 8'h00, 8'hFF, "A rails = off-screen codes");
    analog[0] = {8'd0, -8'sd127}; settle(); expect_port(0, 8'h00, 8'h80, "A left rail -127 = off-screen");
    analog[0] = {8'd127, 8'd0}; settle(); expect_port(0, 8'h00, 8'hFF, "A bottom rail +127 = off-screen");
    analog[0] = {-8'sd127, 8'd0}; settle(); expect_port(0, 8'h00, 8'h01, "A top rail -127 = off-screen");
    analog[0] = {8'd0, -8'sd126}; settle(); expect_port(0, 8'h02, 8'h80, "A -126 on-screen");
    analog[0] = {8'd126, 8'd126}; settle(); expect_port(0, 8'hFE, 8'hFE, "A +126 on-screen");
    // E: crosshair of the current aim
    analog[0] = {8'd10, 8'd50}; settle(); settle();
    checks++; if (dut.cx[0] !== 9'((8'hB2 * 400) / 255) || dut.cy[0] !== 9'h8A) begin errors++; $display("FAIL E: crosshair %0d,%0d", dut.cx[0], dut.cy[0]); end
    analog[0] = {8'd0, 8'd126}; settle(); settle();
    checks++; if (dut.cx[0] !== 9'((254 * 400) / 255)) begin errors++; $display("FAIL E: right edge crosshair %0d", dut.cx[0]); end
    // B (zk4-inv5): the reload contract measured on MAME d1e9f7db (inv_reload_probe.lua): the gun must be off-screen
    // (GUNX 0) for 6 frames BEFORE the trigger rises, the trigger up for >= 6 frames (or while Reload is held), then 2 frames
    // off-screen with the trigger down, then the aim returns. f = frame ticks since the press.
    analog[0] = {8'd0, 8'd20}; analog[1] = 0; settle();
    // B1 Reload tapped (released before the first frame)
    reload = 2'b01; settle(); expect_port(0, 8'h00, 8'h80, "B1 press: off-screen at once");
    checks++; if (trig !== 2'b00) begin errors++; $display("FAIL B1: trigger with no lead (%b)", trig); end
    reload = 2'b00; settle();
    for (k = 1; k <= 16; k++) begin
      frame();
      expect_port(0, (k < 14) ? 8'h00 : 8'h94, 8'h80, $sformatf("B1 f%0d", k));
      checks++; if (trig !== ((k >= 6 && k < 12) ? 2'b01 : 2'b00)) begin errors++; $display("FAIL B1 f%0d: trigger %b", k, trig); end
    end
    // B2 Reload held 20 frames: the trigger stays up until the release, then 2 tail frames
    reload = 2'b01; settle();
    for (k = 1; k <= 25; k++) begin
      frame(); if (k == 20) begin reload = 2'b00; settle(); end
      expect_port(0, (k < 23) ? 8'h00 : 8'h94, 8'h80, $sformatf("B2 f%0d", k));
      checks++; if (trig !== ((k >= 6 && k < 21) ? 2'b01 : 2'b00)) begin errors++; $display("FAIL B2 f%0d: trigger %b", k, trig); end
    end
    // B3 Trigger + Reload pressed together (trigger held throughout): the trigger is masked for the lead, then passes
    fire = 2'b01; reload = 2'b01; settle(); reload = 2'b00;
    checks++; if (trig !== 2'b00) begin errors++; $display("FAIL B3: chord trigger with no lead (%b)", trig); end
    for (k = 1; k <= 16; k++) begin
      frame(); checks++; if (trig !== ((k >= 6) ? 2'b01 : 2'b00)) begin errors++; $display("FAIL B3 f%0d: trigger %b", k, trig); end
    end
    fire = 2'b00; settle();
    // B4 absolute gun leaves the screen (left rail) with the trigger pulled in the same frame: delayed edge
    analog[0] = {8'd0, -8'sd127}; fire = 2'b01; settle();
    checks++; if (trig !== 2'b00) begin errors++; $display("FAIL B4: rail trigger with no lead (%b)", trig); end
    for (k = 1; k <= 8; k++) begin
      frame(); expect_port(0, 8'h00, 8'h80, $sformatf("B4 f%0d", k));
      checks++; if (trig !== ((k >= 6) ? 2'b01 : 2'b00)) begin errors++; $display("FAIL B4 f%0d: trigger %b", k, trig); end
    end
    analog[0] = {8'd0, 8'd20}; settle(); expect_port(0, 8'h94, 8'h80, "B4 back on-screen");
    checks++; if (trig !== 2'b01) begin errors++; $display("FAIL B4: on-screen trigger passes at once (%b)", trig); end
    fire = 2'b00; settle();
    fire = 2'b10; settle(); checks++; if (trig !== 2'b10) begin errors++; $display("FAIL B: P2 fire %b", trig); end
    fire = 2'b00; settle();
    // C: D-pad on player 2
    src[1] = 2'd2; settle(); expect_port(1, 8'h80, 8'h80, "C centre");
    dir[1] = 4'b0001; ex = 8'h80;
    for (k = 0; k < 30; k++) begin frame(); ex = (k < 20) ? ex + 2 : ex + 6; end
    settle(); expect_port(1, ex, 8'h80, "C right 30 frames");
    dir[1] = 4'b0000; repeat (5) frame(); settle(); expect_port(1, ex, 8'h80, "C release holds");
    dir[1] = 4'b0001; repeat (60) frame(); settle(); expect_port(1, 8'hFE, 8'h80, "C clamp 254");
    // a fresh press (after a neutral frame) steps slowly again
    dir[1] = 4'b0000; frame(); dir[1] = 4'b1000; for (k = 0; k < 3; k++) frame(); settle(); expect_port(1, 8'hFE, 8'h7A, "C up");
    dir[1] = 4'b0000;
    // D0 (zk4-inv4): mouse packets while NOBODY selects the mouse are ignored -- the first owner starts at the reset
    // position, the screen centre (200, 128): GUNX = floor(200 * 255 / 399) = 0x7F, GUNY = 128 = 0x80
    src[0] = 2'd0; src[1] = 2'd2;
    for (k = 0; k < 4; k++) begin mouse[15:8] = 8'd40; mouse[4] = 0; mouse[23:16] = 8'd30; mouse[5] = 0; mouse[24] = ~mouse[24]; settle(); end
    src[0] = 2'd1; settle(); settle(); expect_port(0, 8'h7F, 8'h80, "D0 unowned packets ignored");
    // D: mouse, both players select it -> P1 owns
    src[0] = 2'd1; src[1] = 2'd1; settle(); expect_port(1, 8'h80, 8'h80, "D non-owner holds centre");
    for (k = 0; k < 4; k++) begin mouse[15:8] = 8'd40; mouse[4] = 0; mouse[23:16] = 0; mouse[5] = 0; mouse[24] = ~mouse[24]; settle(); end
    settle(); settle();
    checks++; if (!(dut.gun_x[0] > 8'h80) || dut.gun_x[1] !== 8'h80) begin errors++; $display("FAIL D: mouse moved P1 %02x P2 %02x", dut.gun_x[0], dut.gun_x[1]); end
    mouse[0] = 1; settle(); checks++; if (trig !== 2'b01) begin errors++; $display("FAIL D: mouse left = P1 trigger (%b)", trig); end
    mouse[0] = 0; mouse[1] = 1; settle(); checks++; if (dut.gun_x[0] !== 8'h00 || trig !== 2'b00) begin errors++; $display("FAIL D: mouse right = P1 reload start (%02x %b)", dut.gun_x[0], trig); end
    mouse[1] = 0; settle(); repeat (6) frame();
    checks++; if (dut.gun_x[0] !== 8'h00 || trig !== 2'b01) begin errors++; $display("FAIL D: mouse right = P1 reload shot after the lead (%02x %b)", dut.gun_x[0], trig); end
    repeat (10) frame(); settle();
    checks++; if (dut.gun_x[0] === 8'h00 || trig !== 2'b00) begin errors++; $display("FAIL D: mouse reload did not end (%02x %b)", dut.gun_x[0], trig); end
    // D2 (zk4-inv4, documented contract): ownership moves to P2 -> P2 starts at the SHARED mouse position (P1's last)
    begin logic [7:0] lx, ly; lx = dut.gun_x[0]; ly = dut.gun_y[0];
      src[0] = 2'd0; settle(); settle(); expect_port(1, lx, ly, "D2 ownership carry-over");
      for (k = 0; k < 2; k++) begin mouse[15:8] = 8'd20; mouse[4] = 0; mouse[23:16] = 0; mouse[5] = 0; mouse[24] = ~mouse[24]; settle(); end
      settle(); settle(); checks++; if (!(dut.gun_x[1] > lx)) begin errors++; $display("FAIL D2: P2 mouse did not move (%02x vs %02x)", dut.gun_x[1], lx); end
    end
    $display("GUN INPUT GATE checks %0d errors %0d: %s", checks, errors, errors == 0 ? "PASS" : "FAIL");
    $finish;
  end
endmodule
