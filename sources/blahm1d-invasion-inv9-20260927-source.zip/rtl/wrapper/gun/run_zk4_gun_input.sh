#!/bin/bash
# zk4_gun_input unit gate (iverilog) + mutants: the tree must PASS, every mutant must FAIL.
#   U1 X reversed (RevX's 0x80 - x)          U2 reload does not force off-screen      U3 D-pad X polarity swapped
#   U4 the mouse goes to the HIGHER player   U5 crosshair column without the 400/255 scale
#   U6 (inv4) the shared position is strobed with nobody owning the mouse   U7 (inv4) only P1 ownership strobes it
#   inv5 (off-screen / reload): U2 Reload does not force off-screen   U8 no lead (the inv3 same-frame trigger)
#   U9 the -127 left rail reads on-screen   U10 the Y rail is ignored   U11 no minimum trigger hold (tap = 1 clock)
#   U12 no tail frames   U13 a rail off-screen passes the trigger with no lead
# usage: wsl bash run_zk4_gun_input.sh
set -u
G=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper/gun; W=/mnt/h/temp/zeus/invasion/gun_input; mkdir -p $W
run() { iverilog -g2012 -o $W/$1.vvp -s tb_zk4_gun_input $G/tb_zk4_gun_input.sv $2 $G/zk4_lightgun_position.sv > $W/$1.iv 2>&1 || { echo "$1 BUILD FAIL"; return 2; }
        timeout 600 vvp -n $W/$1.vvp > $W/$1.log 2>&1; grep "GUN INPUT GATE" $W/$1.log; grep -q "GUN INPUT GATE.*PASS" $W/$1.log; }
bad=0
run tree $G/zk4_gun_input.sv || bad=1
M=( "U1|s/default: begin px <= analog\[p\]\[7:0\] + 8'h80;/default: begin px <= 8'h80 - analog[p][7:0];/"
    "U2|s/wire off = rs || ab;/wire off = ab;/"
    "U8|s/oa >= 8'(OFF_LEAD)) : tr;/1'b1) : tr;/;s/rc >= 8'(OFF_LEAD) \&\& rc </rc >= 8'd0 \&\& rc </"
    "U9|s/rail = (s <= -r) || (s >= r);/rail = (s < -r) || (s >= r);/"
    "U10|s/(rail(analog\[p\]\[7:0\]) || rail(analog\[p\]\[15:8\]))/rail(analog[p][7:0])/"
    "U11|s/rc < 8'(OFF_LEAD + OFF_HOLD);/rc < 8'(OFF_LEAD + OFF_HOLD) \&\& rl;/"
    "U12|s/rs_end = rc == 8'(OFF_LEAD + OFF_HOLD + OFF_TAIL - 1);/rs_end = rc == 8'(OFF_LEAD + OFF_HOLD - 1);/"
    "U13|s/assign trigger\[p\] = off ?/assign trigger[p] = (off \&\& !ab) ?/"
    "U3|s/if (dir\[p\]\[0\] \&\& !dir\[p\]\[1\])      jx <= (jx >= 8'd254 - rate) ? 8'd254 : jx + rate;/if (dir[p][1] \&\& !dir[p][0])      jx <= (jx >= 8'd254 - rate) ? 8'd254 : jx + rate;/"
    "U4|s/wire own0 = src\[0\] == 2'd1, own1 = (src\[1\] == 2'd1) \&\& !own0;/wire own1 = src[1] == 2'd1, own0 = (src[0] == 2'd1) \&\& !own1;/"
    "U6|s/\.mouse_strobe(mouse_event \&\& (|m_own))/.mouse_strobe(mouse_event)/"
    "U7|s/\.mouse_strobe(mouse_event \&\& (|m_own))/.mouse_strobe(mouse_event \&\& m_own[0])/"
    "U5|s/cx_pk\[9\*p +: 9\] <= (cxp\[22:14\] > SCREEN_W - 9'd1) ? SCREEN_W - 9'd1 : cxp\[22:14\];/cx_pk[9*p +: 9] <= {1'b0, gx_pk[8*p +: 8]};/" )
for m in "${M[@]}"; do n=${m%%|*}; e=${m#*|}; sed "$e" $G/zk4_gun_input.sv > $W/$n.sv
  if cmp -s $W/$n.sv $G/zk4_gun_input.sv; then echo "$n NOT APPLIED"; bad=1; continue; fi
  if run $n $W/$n.sv > /dev/null; then echo "$n SURVIVED"; bad=1; else echo "$n killed: $(grep -m1 FAIL $W/$n.log | cut -c1-90)"; fi
done
echo "GUN INPUT GATE + MUTANTS: $([ $bad = 0 ] && echo PASS || echo FAIL)"; exit $bad
