// SPDX-License-Identifier: GPL-3.0-or-later
// zk4_gun_input.sv -- Invasion builds only: the MiSTer gun inputs of both players -> MAME's gun ports + crosshair.
// ADAPTED from the Revolution X MiSTer core, Arcade-RevX_MiSTer rtl/revx/revx_guns.sv (commit 8d234e7, sha256
// 9d9d341b...6415): the per-player source select (absolute stick / relative mouse / D-pad integrator with anti-snap hold)
// and the mouse contract, re-targeted from RevX's three reversed-X ADC channels to Invasion's two lightgun ports:
//   MAME 0.289 midzeus.cpp INPUT_PORTS_START(invasn): GUNX1/GUNY1/GUNX2/GUNY2 are 8-bit IPT_LIGHTGUN_X/_Y, 0..0xFF, centre
//   0x80, no PORT_REVERSE; PORT_CROSSHAIR(X/Y, 1.0, 0.0, 0) = full visible width / height. TRIGGER bit p = BUTTON1 of
//   player p, active high. invasn_gun_r (cpp:806) treats GUNX 0 or 0xFF as OFF-SCREEN (the reload shot).
//   The game maps the port onto the raster as m_gun_x = GUNX * 400 / 255 + ... (cpp:784), so the crosshair is drawn at
//   visible column GUNX * 400 / 255 and line GUNY * 256 / 255 (the same mapping zk4_gun uses).
// Sources (OSD, per player): 0 = L-Analog / USB gun / Sinden (MiSTer delivers every absolute gun as the left analog stick:
//   GUNX = 0x80 + x, GUNY = 0x80 + y; a gun aimed off-screen reports a rail value 0x00 / 0xFF = MAME's off-screen),
//   1 = Mouse (one mouse: the lowest player that selects it owns it; left button = trigger, right = reload; one shared
//       screen position since zk4-inv4 -- it carries over when ownership moves between players; packets while nobody
//       owns the mouse are ignored),
//   2 = D-Pad (per-frame integrator: slow 2 / fast 6 steps after 20 held frames; releases hold -- no centre snap).
// Relative sources are clamped to 1..254 so they never read as off-screen by accident.
// OFF-SCREEN / RELOAD (zk4-inv5). MAME's only off-screen signal is the X port at 0x00 or 0xFF (invasn_gun_r
// midzeus.cpp:831-839, d1e9f7db: no in-range bit 12/13 for that player); the rest of the gun path is unchanged. MEASURED on
// MAME d1e9f7db with an empty clip ("RELOAD!"), invasion/tools/inv_reload_probe.lua, evidence H:/temp/zeus/invfix/rl_*:
//   GUNX = 0 and the trigger pressed on the SAME frame (the zk4-inv3 reload button) -> NO reload (rl_sim); GUNX = 0 alone
//   -> no reload (rl_xonly); GUNX = 0 first, the trigger 1 frame later -> no reload; 2 / 3 frames later -> reload on one
//   frame phase, not the other (the game runs at 30 Hz); 4 or 6 frames later, held 4 / 6 frames -> reload on both phases,
//   GUNX 0x00 and 0xFF alike (rl_d*, rl_e*). The firmware needs the gun off-screen for a few frames BEFORE the trigger edge.
// So, per player:
//   - Reload (J1 button, or the owning mouse's right button) runs a sequence: GUNX = 0 at once; OFF_LEAD (6) frames later
//     the trigger rises; it stays up for OFF_HOLD (6) frames or as long as Reload is held; then OFF_TAIL (2) frames
//     off-screen with the trigger released, then the aim returns. Reload alone reloads; Trigger + Reload in any order
//     reloads too (the trigger is masked until the lead has elapsed, which creates the edge).
//   - An absolute source (0) with either axis at +-ABS_RAIL (127) or beyond reads off-screen (GUNX = 0): MiSTer delivers an
//     off-screen Sinden / USB gun as a rail value, and the left rail -127 would otherwise be 0x01 = on-screen. Costs the
//     outermost column / row of the aim (+-127 of 255 steps).
//   - Whenever the gun is off-screen the trigger is held low until it has been off-screen OFF_LEAD frames, so a trigger
//     pulled in the same frame the gun leaves the screen still reloads (a delayed edge instead of a lost one).
// Sensitivity: none (a fixed, documented response; RevX's sensitivity option never reached the ports).
module zk4_gun_input #(
  parameter [8:0] SCREEN_W = 9'd400, SCREEN_H = 9'd256,
  parameter [7:0] RATE_SLOW = 8'd2, RATE_FAST = 8'd6, RAMP_FRAMES = 8'd20,
  parameter int   OFF_LEAD = 6, OFF_HOLD = 6, OFF_TAIL = 2,         // reload sequence, frames (zk4-inv5, see the header)
  parameter int   ABS_RAIL = 127                                  // |absolute axis| >= this = aimed off the screen
) (
  input  logic        clk, rst,
  input  logic        vs,                                        // game vsync (frame tick for the D-pad integrator)
  input  logic [15:0] analog [2],                                // MiSTer left analog per player: [7:0] X, [15:8] Y, signed
  input  logic [3:0]  dir [2],                                   // MiSTer joystick[3:0] per player: right, left, down, up
  input  logic [1:0]  src [2],                                   // OSD source per player (0 absolute, 1 mouse, 2 D-pad)
  input  logic [1:0]  fire_btn, reload_btn,                      // J1 Trigger / Reload per player
  input  logic [24:0] ps2_mouse,                                 // hps_io relative mouse
  output logic [7:0]  gun_x [2], output logic [7:0] gun_y [2],      // MAME GUNX / GUNY ports
  output logic [1:0]  trigger,                                   // MAME TRIGGER port
  output logic [8:0]  cx [2], output logic [8:0] cy [2]             // crosshair, visible coordinates
);
  logic vs_d; always_ff @(posedge clk) vs_d <= vs;
  wire frame_tick = vs & ~vs_d;

  // ---- mouse (RevX / T2 contract: [24] toggles per packet, [15:8] dx, [23:16] dy, [4]/[5] sign, [1:0] R/L buttons) ----
  logic mt_d; always_ff @(posedge clk) mt_d <= ps2_mouse[24];
  wire mouse_event = ps2_mouse[24] ^ mt_d;
  wire signed [8:0] mdx = $signed({ps2_mouse[4], ps2_mouse[15:8]}) >>> 1;
  wire signed [8:0] mdy = $signed({ps2_mouse[5], ps2_mouse[23:16]}) >>> 1;
  wire own0 = src[0] == 2'd1, own1 = (src[1] == 2'd1) && !own0;
  logic [1:0] m_own; assign m_own = {own1, own0};

  function automatic [7:0] clamp_on(input [7:0] v);             // keep a relative source on-screen (1..254)
    clamp_on = (v == 8'h00) ? 8'h01 : (v == 8'hFF) ? 8'hFE : v;
  endfunction
  function automatic rail(input [7:0] a);                         // an absolute axis at +-ABS_RAIL or beyond (signed)
    logic signed [8:0] s, r; s = $signed({a[7], a}); r = $signed(9'(ABS_RAIL));
    rail = (s <= -r) || (s >= r);
  endfunction
  // mouse screen position -> port: floor(p * 255 / (W - 1)), exact for p <= W - 1 < 512 with S = 18 (RevX derivation)
  localparam int MS = 18;
  localparam int RX = ((255 << MS) + SCREEN_W - 2) / (SCREEN_W - 1);
  function automatic [7:0] pos_to_port_x(input [8:0] p);
    logic [40:0] pr; pr = {32'd0, p} * 41'(RX);
    pos_to_port_x = (|pr[40:MS+8]) ? 8'hFF : pr[MS +: 8];
  endfunction

  // mouse screen position (zk4_lightgun_position in its mouse mode). zk4-inv4: ONE instance shared by both players, strobed
  // only while a player owns the mouse (own0 / own1 are exclusive, so at most one player reads it). Until zk4-inv3 each
  // player had its own instance. The only behaviour difference: when OSD mouse ownership moves between P1 and P2 the
  // position carries over (the new owner starts where the mouse cursor was) instead of each player keeping its own last
  // position. Harmless (director decision 2026-09-26); ports / crosshair / trigger / reload are otherwise unchanged.
  logic [8:0] mx, my; logic [7:0] ua, ub; logic us;
  zk4_lightgun_position #(.DEFAULT_WIDTH(SCREEN_W), .DEFAULT_HEIGHT(SCREEN_H)) u_pos (
    .clk, .rst, .vs, .screen_width(SCREEN_W), .screen_height(SCREEN_H), .rotate(2'd0), .sensitivity(2'd0),
    .source(2'd1), .joyana(16'd0), .joy_dir(4'd0), .mouse_dx(mdx[7:0]), .mouse_dy(mdy[7:0]),
    .mouse_strobe(mouse_event && (|m_own)), .gun_x(mx), .gun_y(my), .adc_x(ua), .adc_y(ub), .gun_strobe(us));

  logic [15:0] gx_pk, gy_pk; logic [17:0] cx_pk, cy_pk;         // packed per-player results
  genvar p;                                                      // Quartus 17: no inline genvar (Error 10170)
  generate for (p = 0; p < 2; p = p + 1) begin : g_pl
    // D-pad integrator (revx_gun_aim, polarity for an un-reversed X: right / down increase)
    logic [7:0] jx, jy, hold; wire any = |dir[p];
    wire [7:0] rate = (hold >= RAMP_FRAMES) ? RATE_FAST : RATE_SLOW;
    always_ff @(posedge clk)
      if (rst) begin jx <= 8'h80; jy <= 8'h80; hold <= 8'd0; end
      else if (frame_tick) begin
        hold <= any ? ((hold >= RAMP_FRAMES) ? RAMP_FRAMES : hold + 8'd1) : 8'd0;
        if (dir[p][0] && !dir[p][1])      jx <= (jx >= 8'd254 - rate) ? 8'd254 : jx + rate;
        else if (dir[p][1] && !dir[p][0]) jx <= (jx <= 8'd1 + rate)   ? 8'd1   : jx - rate;
        if (dir[p][2] && !dir[p][3])      jy <= (jy >= 8'd254 - rate) ? 8'd254 : jy + rate;
        else if (dir[p][3] && !dir[p][2]) jy <= (jy <= 8'd1 + rate)   ? 8'd1   : jy - rate;
      end
    logic [7:0] px, py; logic rl, tr, ab;                        // (mouse position: the shared u_pos above)
    always_ff @(posedge clk) begin                               // registered ports (values move once per frame / packet)
      case (src[p])
        2'd1:    begin px <= m_own[p] ? clamp_on(pos_to_port_x(mx)) : 8'h80; py <= m_own[p] ? clamp_on(my[7:0]) : 8'h80; end
        2'd2:    begin px <= jx; py <= jy; end
        default: begin px <= analog[p][7:0] + 8'h80; py <= analog[p][15:8] + 8'h80; end
      endcase
      rl <= reload_btn[p] || (m_own[p] && ps2_mouse[1]);
      tr <= fire_btn[p]   || (m_own[p] && ps2_mouse[0]);
      ab <= (src[p] != 2'd1) && (src[p] != 2'd2) && (rail(analog[p][7:0]) || rail(analog[p][15:8]));
    end
    // reload sequence (see the header): OFF_LEAD frames off-screen, then the trigger for >= OFF_HOLD frames (as long as
    // Reload is held), then OFF_TAIL frames off-screen with the trigger released
    logic rs; logic [7:0] rc, oa;
    wire rs_last_hold = rc == 8'(OFF_LEAD + OFF_HOLD - 1), rs_end = rc == 8'(OFF_LEAD + OFF_HOLD + OFF_TAIL - 1);
    wire rs_trig = rs && rc >= 8'(OFF_LEAD) && rc < 8'(OFF_LEAD + OFF_HOLD);
    wire off = rs || ab;
    always_ff @(posedge clk)
      if (rst) begin rs <= 1'b0; rc <= 8'd0; oa <= 8'd0; end
      else begin
        if (!rs) begin if (rl) begin rs <= 1'b1; rc <= 8'd0; end end
        else if (frame_tick) begin
          if (rs_end) rs <= 1'b0;
          else if (!(rs_last_hold && rl)) rc <= rc + 8'd1;          // park in the trigger phase while Reload is held
        end
        if (!off) oa <= 8'd0; else if (frame_tick && oa < 8'(OFF_LEAD)) oa <= oa + 8'd1;
      end
    assign gx_pk[8*p +: 8] = off ? 8'h00 : px;                    // off-screen = GUNX 0 (MAME's off-screen code, cpp:832)
    assign gy_pk[8*p +: 8] = py;
    assign trigger[p] = off ? ((tr || rs_trig) && oa >= 8'(OFF_LEAD)) : tr;
    // crosshair: visible column GUNX * 400 / 255 ((x * 25701) >> 14, exact), line GUNY * 256 / 255
    logic [22:0] cxp; assign cxp = {15'd0, gx_pk[8*p +: 8]} * 23'd25701;
    always_ff @(posedge clk) begin
      cx_pk[9*p +: 9] <= (cxp[22:14] > SCREEN_W - 9'd1) ? SCREEN_W - 9'd1 : cxp[22:14];
      cy_pk[9*p +: 9] <= {1'b0, py};                          // GUNY * 256 / 255 = GUNY (255 -> 256, clipped to 255)
    end
  end endgenerate
  // unpacked output ports driven outside the generate (element assigns inside it are not portable across tools)
  assign gun_x[0] = gx_pk[7:0]; assign gun_x[1] = gx_pk[15:8]; assign gun_y[0] = gy_pk[7:0]; assign gun_y[1] = gy_pk[15:8];
  assign cx[0] = cx_pk[8:0]; assign cx[1] = cx_pk[17:9]; assign cy[0] = cy_pk[8:0]; assign cy[1] = cy_pk[17:9];
endmodule
