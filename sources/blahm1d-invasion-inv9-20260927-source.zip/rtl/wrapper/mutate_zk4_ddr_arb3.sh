#!/bin/bash
# zk4_ddr_arb3 mutants: each must FAIL run_zk4_ddr_arb3.sh at 60 % busy
#   A1 no lock (a refused offer can be replaced)     A2 no burst tracking (S/M slip inside a renderer burst)
#   A3 DCS byte address not converted to a word      A4 the lock records the wrong owner
#   A5 read beats routed to the wrong owner          A6 tag head pops one beat late
#   A7 a DCS read tagged with the renderer's count
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; bad=0
run() { out=$(ZDA3_MUT="$2" bash $D/run_zk4_ddr_arb3.sh 300000 60 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$1 NOT APPLIED / BUILD FAILED"; bad=1
  elif [ $rc = 0 ]; then echo "$1 SURVIVED"; bad=1
  else echo "$1 killed: $(echo "$out" | grep -m1 -E "ERR|FAIL" | cut -c1-110)"; fi; }
run A1 's/    else if (locked)                  sel = owner;/    else if (1'"'"'b0)                  sel = owner;/'
run A2 's/    if (wleft != 8.d0)                sel = O_R;/    if (1'"'"'b0)                sel = O_R;/'
run A3 's/d_address = s_address\[31:3\];/d_address = s_address[28:0];/'
run A4 's/locked <= 1.b1; owner <= sel; end/locked <= 1'"'"'b1; owner <= O_R; end/'
run A5 's/assign r_readdatavalid = d_readdatavalid \&\& !tq_empty \&\& !head_s;/assign r_readdatavalid = d_readdatavalid \&\& !tq_empty \&\& head_s;/'
run A6 's/if (head_left + 8.d1 == head_n)/if (head_left == head_n)/'
run A7 's/sel == O_S ? 8.d1 : r_burstcount/r_burstcount/'
exit $bad
