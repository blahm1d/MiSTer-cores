`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_hdmi_status.sv -- gm1's status screen. Forked from bandwidth/bw1/rtl/core/bw1_hdmi_status.sv
// (the bw1 lane keeps its own copy untouched, fork discipline) and extended with three 16-bit
// DIAGNOSTIC ROWS, because the cabinet has no other instrument: MiSTer holds every input device
// with an exclusive EVIOCGRAB, so nothing on the ARM side can observe a button press, and this
// core carries no text renderer. Bars are the instrument we have -- screen as logic analyser.
//
// Layout, 640x480, 16 columns of 40 px. In every DIAG row column 0 is the MSB (bit 15) and
// column 15 the LSB (bit 0), so a row reads left-to-right as a binary number off a screenshot.
//   vc <340      13 test bars (unchanged)
//   350..380     SDRAM size meter (unchanged)
//   384..400     DIAG A, yellow -- DDR FAULT FORENSICS, latched on the FIRST fault and sticky,
//                so the offending request survives for a screenshot taken minutes later. All
//                dim = no DDR fault (bar 13 green). gm1_core.sv decodes the 16 bits: the mux
//                and adapter fault codes, which of the three fault mechanisms fired, which of
//                the four clients, and which malformed rule. It replaced the sticky IN0 row,
//                which had proved what it was built to prove (the pad reaches in0).
//   404..428     DIAG D, orange -- SAMPLED cpu_pc[23:8], refreshed ~3x a second. It replaced the B7
//                capture-audit bar, whose single pass/fail is already covered by bars 1-4. One LSB is
//                256 C31 words. Successive screenshots scatter across whatever loop the CPU is in,
//                which is how you find out what a black-but-running screen is waiting for.
//   470..478     DIAG E, white -- {dcs_underruns[7:0], dcs_ddr_misses[7:0]}: is the sound board
//                starving on its DDR ROM fetches? All dim = healthy.
//   432..448     DIAG B, cyan -- presented_frames[15:0]. Sample it once a second and difference
//                it to get presented frames per wall second, which is the speed measurement the
//                plan asks for (docs/PLAN-A1D-FULLSPEED.md step 6).
//   452..468     DIAG C, magenta -- instructions[31:16]. One LSB = 65,536 instructions, so the
//                row advances ~102 LSB per wall second at the measured 7.468 clocks/instruction.
//                Difference it the same way to get the CPU rate, hence clocks per instruction.
module gm1_hdmi_status (
    input  wire        clk,           // 50 MHz (CLK_VIDEO)
    input  wire        reset,
    input  wire [15:0] done_mask, pass_mask,
    input  wire [7:0]  cur_test,
    input  wire [63:0] heartbeat,
    input  wire [7:0]  sdram_mb,
    input  wire        audit_ok,      // B7: md landed && !reset_during_download && dropped==0
    input  wire        audit_valid,   // B7 has been finalized
    input  wire [15:0] diag_a,        // DDR fault forensics (active high; see gm1_core.sv)
    input  wire [15:0] diag_b,        // presented_frames[15:0]
    input  wire [15:0] diag_c,        // instructions[31:16]
    input  wire [15:0] diag_d,        // sampled cpu_pc[23:8]  -- where the C31 is executing
    input  wire [15:0] diag_e,        // {dcs_underruns[7:0], dcs_ddr_misses[7:0]}
    output reg         ce_pixel, de, hs, vs,
    output reg  [7:0]  r, g, b
);
    // 640x480@60 (VGA): H 640+16+96+48=800, V 480+10+2+33=525
    reg [9:0] hc; reg [9:0] vc; reg ce;
    reg [5:0] col; reg [5:0] colpix;   // 16 columns of 40 px
    always @(posedge clk) begin
        if (reset) begin hc<=0; vc<=0; ce<=0; end
        else begin
            ce<=~ce;
            if (ce) begin
                if (hc==10'd799) begin hc<=0; if (vc==10'd524) vc<=0; else vc<=vc+1; end
                else hc<=hc+1;
            end
        end
    end
    // per-pixel column tracker
    always @(posedge clk) begin
        if (reset) begin col<=0; colpix<=0; end
        else if (ce) begin
            if (hc==10'd799) begin col<=0; colpix<=0; end
            else if (colpix==6'd39) begin colpix<=0; col<=col+1; end
            else colpix<=colpix+1;
        end
    end

    wire active = (hc<10'd640) && (vc<10'd480);
    wire [4:0] tid = {1'b0,col[3:0]} + 5'd1;         // col 0 -> test 1
    wire in_gap = (colpix>=6'd36) || (col>=6'd13);   // gaps between bars / spare columns
    wire gap16  = (colpix>=6'd36);                   // gap for the full 16-column diag rows
    wire top_region    = (vc<10'd340);
    wire meter_region  = (vc>=10'd350) && (vc<10'd380);
    wire diag_a_region = (vc>=10'd384) && (vc<10'd400);
    wire diag_d_region = (vc>=10'd404) && (vc<10'd428);   // was the B7 capture-audit bar
    wire diag_e_region = (vc>=10'd470) && (vc<10'd478);
    wire diag_b_region = (vc>=10'd432) && (vc<10'd448);
    wire diag_c_region = (vc>=10'd452) && (vc<10'd468);
    wire [7:0] blink = heartbeat[23] ? 8'h20 : 8'h10;

    // column 0 shows the MSB so a row reads as a binary number left to right
    wire [3:0] bitsel = 4'd15 - col[3:0];
    wire diag_a_lit =  diag_a[bitsel];               // active high, like rows B and C
    wire diag_b_lit =  diag_b[bitsel];
    wire diag_c_lit =  diag_c[bitsel];
    wire diag_d_lit =  diag_d[bitsel];
    wire diag_e_lit =  diag_e[bitsel];

    // test-bar color
    reg [7:0] tr,tg,tb;
    always @* begin
        tr=8'h20; tg=8'h20; tb=8'h20; // default gray
        if (col<6'd13) begin
            if ({3'd0,cur_test[4:0]}==tid)      begin tr=8'hd0; tg=8'hd0; tb=8'h10; end // running=yellow
            else if (pass_mask[tid[3:0]])       begin tr=8'h10; tg=8'hc0; tb=8'h20; end // pass=green
            else if (done_mask[tid[3:0]])       begin tr=8'hd0; tg=8'h10; tb=8'h10; end // fail=red
            else                                begin tr=8'h30; tg=8'h30; tb=8'h30; end // not run=gray
        end
    end
    // sdram size meter: lit cells = size_mb/32 (1=32MB,2=64MB,4=128MB); show up to 4 cells
    wire [2:0] meter_cells = (sdram_mb>=8'd128)?3'd4:(sdram_mb>=8'd64)?3'd2:(sdram_mb>=8'd32)?3'd1:3'd0;
    wire meter_lit = (col < {3'd0,meter_cells}) && (col<6'd13) && !in_gap;

    always @(posedge clk) begin
        ce_pixel<=ce;
        de<=active;
        hs<=~((hc>=10'd656)&&(hc<10'd752));
        vs<=~((vc>=10'd490)&&(vc<10'd492));
        if (!active) begin r<=0; g<=0; b<=0; end
        else if (meter_region) begin
            if (meter_lit) begin r<=8'h20; g<=8'h60; b<=8'hf0; end else begin r<=blink; g<=blink; b<=blink; end
        end else if (top_region) begin
            if (in_gap) begin r<=blink; g<=blink; b<=blink; end
            else begin r<=tr; g<=tg; b<=tb; end
        end else if (diag_a_region) begin
            if (gap16)          begin r<=blink; g<=blink; b<=blink; end
            else if (diag_a_lit) begin r<=8'hf0; g<=8'hd0; b<=8'h10; end   // pressed = bright yellow
            else                 begin r<=8'h28; g<=8'h24; b<=8'h10; end   // idle = dim yellow
        end else if (diag_d_region) begin
            if (gap16)          begin r<=blink; g<=blink; b<=blink; end
            else if (diag_d_lit) begin r<=8'hf0; g<=8'h90; b<=8'h20; end   // 1 = bright orange
            else                 begin r<=8'h2c; g<=8'h20; b<=8'h10; end   // 0 = dim orange
        end else if (diag_e_region) begin
            if (gap16)          begin r<=blink; g<=blink; b<=blink; end
            else if (diag_e_lit) begin r<=8'hf0; g<=8'hf0; b<=8'hf0; end   // 1 = white
            else                 begin r<=8'h2c; g<=8'h2c; b<=8'h2c; end   // 0 = dim white
        end else if (diag_b_region) begin
            if (gap16)          begin r<=blink; g<=blink; b<=blink; end
            else if (diag_b_lit) begin r<=8'h10; g<=8'he0; b<=8'hf0; end   // 1 = bright cyan
            else                 begin r<=8'h10; g<=8'h28; b<=8'h2c; end   // 0 = dim cyan
        end else if (diag_c_region) begin
            if (gap16)          begin r<=blink; g<=blink; b<=blink; end
            else if (diag_c_lit) begin r<=8'hf0; g<=8'h30; b<=8'he0; end   // 1 = bright magenta
            else                 begin r<=8'h2c; g<=8'h10; b<=8'h28; end   // 0 = dim magenta
        end else begin r<=blink; g<=blink; b<=blink; end
    end
endmodule
`default_nettype wire
