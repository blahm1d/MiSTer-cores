`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// gm1_status_mirror -- publishes the status-page counters to DDR3 so the ARM side can log them while the user plays
// (no screenshots, no status screen). Uses the CAPTURE client of gm1_core's avalon_shared_mux, idle since r12.
//
// Every PERIOD clocks it writes one 12-word block (64-bit, single-beat writes, non-urgent) at BASE, seqlock-style:
//   word 0  {MAGIC 32'h67_6d_31_53 ("gm1S"), seq}   written FIRST with seq ODD  (block being updated)
//   word 1  wall clocks since por                    word 2  instructions retired
//   word 3  {presented_frames, 16'd0, pc_sample}     word 4  {video_fault_a, video_fault_e, 32'd0}
//   word 5  irq_diag[63:0]                           word 6  {48'd0, irq_diag[79:64]}
//   word 7  render_diag[63:0]                        word 8  {32'd0, render_diag[95:64]}
//   word 9  {q_engine, q_scan}                       word 10 {q_capture, q_busy}
//   word 11 {MAGIC, seq}                             written LAST with seq EVEN (block consistent)
// A reader accepts a block only when word 0 == word 11 and seq is even. Values are captured into a shadow register
// when the block starts, so one block is one instant. Avalon rule (the mux faults on it): a command, once offered, is
// held unchanged until waitrequest drops.
module gm1_status_mirror #(
    parameter [31:0] BASE   = 32'h38700000,
    parameter integer PERIOD = 2_000_000          // 40 ms at 50 MHz
) (
    input  wire         clk,
    input  wire         por,
    input  wire         enable,                   // e.g. all configured (DDR ready)
    input  wire [63:0]  instructions,
    input  wire [31:0]  presented_frames,
    input  wire [15:0]  pc_sample,
    input  wire [15:0]  video_fault_a,
    input  wire [15:0]  video_fault_e,
    input  wire [79:0]  irq_diag,
    input  wire [95:0]  render_diag,
    input  wire [31:0]  q_engine, q_scan, q_capture, q_busy,
    // 2026-09-23: race-speed counters (gm1_board.sv perf_diag): words 11..14; the block is now 16 words, closer = 15
    input  wire [255:0] perf_diag,
    // mux client (CAPTURE)
    output reg          write,
    output reg  [31:0]  address,
    output reg  [63:0]  writedata,
    output wire [7:0]   byteenable,
    output wire [3:0]   burstcount,
    input  wire         waitrequest
);
    localparam [31:0] MAGIC = 32'h676d3153;
    assign byteenable = 8'hff;
    assign burstcount = 4'd1;

    reg [63:0] wall;
    reg [31:0] tick;
    reg [31:0] seq;
    reg [3:0]  idx;             // word being written, 0..15
    reg        busy;
    reg [63:0] s [1:14];        // shadow of words 1..14 (one instant)

    function automatic [63:0] word(input [3:0] i);
        case (i)
            4'd0, 4'd15: word = {MAGIC, seq};
            default:     word = s[i];
        endcase
    endfunction

    integer j;
    always @(posedge clk) begin
        if (por) begin
            wall <= 64'd0; tick <= 32'd0; seq <= 32'd0; idx <= 4'd0; busy <= 1'b0;
            write <= 1'b0; address <= 32'd0; writedata <= 64'd0;
            for (j = 1; j <= 14; j = j + 1) s[j] <= 64'd0;
        end else begin
            wall <= wall + 64'd1;
            if (!busy) begin
                tick <= (tick == PERIOD - 1) ? 32'd0 : tick + 32'd1;
                if (tick == PERIOD - 1 && enable) begin
                    // capture one instant, open the block with an odd sequence number
                    s[1] <= wall;                  s[2] <= instructions;
                    s[3] <= {presented_frames, 16'd0, pc_sample};
                    s[4] <= {video_fault_a, video_fault_e, 32'd0};
                    s[5] <= irq_diag[63:0];        s[6] <= {48'd0, irq_diag[79:64]};
                    s[7] <= render_diag[63:0];     s[8] <= {32'd0, render_diag[95:64]};
                    s[9] <= {q_engine, q_scan};    s[10] <= {q_capture, q_busy};
                    s[11] <= perf_diag[63:0];      s[12] <= perf_diag[127:64];
                    s[13] <= perf_diag[191:128];   s[14] <= perf_diag[255:192];
                    seq <= seq + 32'd1;            // odd
                    busy <= 1'b1; idx <= 4'd0;
                    write <= 1'b1; address <= BASE; writedata <= {MAGIC, seq + 32'd1};
                end
            end else if (write && !waitrequest) begin
                // accepted: offer the next word (the offered command never changes while waitrequest is high)
                if (idx == 4'd15) begin
                    write <= 1'b0; busy <= 1'b0;
                end else if (idx == 4'd14) begin
                    idx <= 4'd15; seq <= seq + 32'd1;     // even: close the block
                    address <= BASE + 32'd120; writedata <= {MAGIC, seq + 32'd1};
                end else begin
                    idx <= idx + 4'd1;
                    address <= BASE + {26'd0, idx + 4'd1, 3'd0};
                    writedata <= word(idx + 4'd1);
                end
            end
        end
    end
endmodule
`default_nettype wire
