# wrapper donors -- copied AS-IS (byte-identical) on 2026-09-23T04:00Z
c31_sdram_backing.sv, c31_sdram_burst.sv: cruisinusa/rtl/c31/mem/sdram (the gm1 cabinet-proven SDRAM controller)
bw1_pll.sv: cruisinusa/bandwidth/bw1/rtl/core (50 MHz core + -3515 ps SDRAM pin clock)
quartus/sys, gm1_template.qsf/.sdc: cruisinusa/build/gm1-quartus-20260923T034636400245200Z/source/quartus

49e11e36b43a66994954b46314fd189df4e79a1b8ba3e24e0c2902658c3e4606 *bw1_pll.sv
88e3fe9e6241c87187bcd966b053fc311db587a6770a547b28a2921412aba562 *c31_sdram_backing.sv
569c3e3d626e54140c00d81ace7960d4cf4d7d43f5d62cce550f452adb57cf11 *c31_sdram_burst.sv

gm1_hdmi_status.sv, gm1_status_mirror.sv: cruisinusa/bandwidth/gm1/rtl (the Cruis'n cabinet status screen + DDR3 status mirror, pointed to by the Cruis'n session 2026-09-23)
tools/cab/: gm1_perflog.sh, analyze_perflog.py, check_status_mirror.py, tb_gm1_status_mirror.sv from cruisinusa/bandwidth/gm1/ladder/diag_mirror
7f943c40e4f95ce7b34ab7016a205335d7c2468db694b6791252f0aaef2aa383 *gm1_hdmi_status.sv
aa61894a678cbcc70e19c6f8c198082d68a8114875ce3acd12f2b6af70a785d1 *gm1_status_mirror.sv
0cdc342b2784f762f8d712b3243b346a78e48502248d39c893fda4a01cebf250 *analyze_perflog.py
c98f4751eaeffcf59f66d6189e931e954f4c17038479e593261ef86648caae56 *check_status_mirror.py
e816c57a8ce17167ce2eefb50b6472d76be970deebb791077350483427c469d9 *gm1_perflog.sh
0b00607a929b7b444c3ec2ffc8e1394756c7f9080f5e6983edb6f074eaf92f2e *tb_gm1_status_mirror.sv
