//
// c31_sdram_burst.sv -- Cruis'n USA C31 memory-tier SDRAM controller. FORK of the bw1
// cabinet-proven controller (doctrine section 4: fork + audit inherited constants).
//
// PROVENANCE (forked 2026-09-15):
//   bandwidth/bw1/rtl/vendor/sdram_burst_bw1.sv  SHA-256
//     eda11f5a7a3551d1afa97d9f24e046cfc99c9e368884f9132ac80915de68c814
//   which is itself the bw1 50 MHz adaptation of the T-unit donor
//   tunit/Arcade-TUnit_MiSTer/rtl/sdram/sdram_burst.sv (open-page, 4-bank). Manifest +
//   audit: rtl/c31/mem/sdram/MANIFEST.json. Original stock controller:
//   Copyright (c) 2015-2019 Sorgelig, GNU GPLv3.
//
// INHERITED CONSTANTS -- AUDITED (kept verbatim from the cabinet-proven bw1 build 3, whose
// B2/B3/B4 single-word latency measured max 19/19/15 clocks on the DE10-Nano at 50 MHz):
//   CAS_LATENCY 2, PIN_LAT 2 (one output + one input pin register outside this module, as in
//   bw1_sdram_subsystem), T_RP 2, T_RCD 2, T_RC 4, STARTUP_CYCLES 12500 (>=200 us @50 MHz),
//   REFRESH_PERIOD 350 (7.0 us/row < 7.8125 us), init = precharge-all + 8 auto-refresh + load
//   mode, MODE = CAS2 no-write-burst BL=1. These are correct for the 20 ns core clock and are
//   UNCHANGED. rd_delay = CAS_LATENCY+PIN_LAT.
//
// MARKED C31 ADAPTATIONS:
//  [C31-1] ADDRESS DECOMPOSITION CHANGED. The bw1/T-unit donor put the low byte-address bits in
//    the ROW (bank=addr[24:23], row=addr[13:1], col=addr[22:14]) -- tuned for the framebuffer's
//    access pattern, where consecutive halfwords land in DIFFERENT rows. For the C31 page cache a
//    256-word (1 KiB) page is a 512-halfword OPEN-PAGE BURST that MUST lie in ONE row's 512
//    columns, so a page fill streams without a precharge/activate per word. C31 decomposition:
//        bank = addr[24:23]   row = addr[22:10] (13 b)   col = addr[9:1] (9 b, 512 columns)
//    A page (byte addr multiple of 1024) has addr[9:0]=0 -> col 0..511 of one row. The model
//    (bandwidth/bw1/tests/bw1_sdram_model.v) keys storage by the (bank,row,col) PINS this
//    controller drives, so any self-consistent decomposition is data-transparent; this one makes
//    the sequential burst an open-page hit. WRITE and single READ use the SAME decomposition, so
//    a fill reads exactly what a write stored.
//  [C31-2] PIPELINED OPEN-PAGE BURST READ added (burst_rd/burst_len/burst_dvalid/burst_dout).
//    After the row is open the controller issues one CMD_READ column command PER CLOCK with an
//    incrementing column, and captures one 16-bit word per clock on rd_delay[0] (the donor's
//    rd_delay shift register already supports multiple in-flight reads -- each issue sets the top
//    bit, each clock shifts, bit 0 fires per returned word). Throughput after the fill latency is
//    1 halfword/clock; a 512-halfword page fill is ~= CAS_LATENCY+PIN_LAT + tRCD + 512 clocks.
//    Refresh is deferred until the burst returns to S_IDLE (a <=11 us burst defers one refresh,
//    which is spec-legal); the burst never crosses a row so no mid-burst precharge occurs.
//  [C31-3] COMMAND BUNDLE PORTS kept from bw1 [BW1-2] (o_A/o_BA/o_ncs/.../o_dq_out/o_dq_oe/i_dq)
//    so the same one-stage pin registration (PIN_LAT=2 total) applies on the board and in the gate.
//
// Single rd/we path (posted write-backs + SDRAM-direct fast/CMOS 32-bit = 2 halfword accesses)
// is the donor's, retimed only by [C31-1]. `ready` is the single-op handshake; bursts use
// burst_dvalid and never touch `ready`.
//
`timescale 1ns/1ps
`default_nettype none
module c31_sdram_burst #(
   parameter integer PIN_LAT = 2   // [C31-3] pin register stages between this controller and the SDRAM
)(
   input             init,
   input             clk,          // 50 MHz core clock (20 ns)

   // command bundle (pins registered one stage outside; DQ registered one stage in)
   input      [15:0] i_dq,
   output     [15:0] o_dq_out,
   output            o_dq_oe,
   output reg [12:0] o_A,
   output            o_dqml,
   output            o_dqmh,
   output reg  [1:0] o_BA,
   output            o_ncs,
   output            o_nwe,
   output            o_nras,
   output            o_ncas,
   output            o_cke,

   // single-word interface (posted write-back, SDRAM-direct)
   input       [1:0] wtbt,
   input      [24:0] addr,         // BYTE address; addr[0]=0 for 16-bit accesses
   output     [15:0] dout,
   input      [15:0] din,
   input             we,
   input             rd,
   output reg        ready,

   // [C31-2] pipelined open-page burst read
   input             burst_rd,     // 1-cycle pulse: start a burst read at burst_addr
   input      [24:0] burst_addr,   // BYTE address of the first halfword (page-aligned)
   input      [9:0]  burst_len,    // number of 16-bit words (512 for a 256-word page)
   output reg        burst_dvalid, // 1-cycle strobe per returned 16-bit word (in order)
   output reg [15:0] burst_dout,
   output reg        burst_busy
);
   localparam [2:0] CAS_LATENCY = 3'd2;
   localparam MODE = {3'b000, 1'b1 /*no wr burst*/, 2'b00, CAS_LATENCY, 1'b0, 3'b000};

   localparam [2:0] CMD_NOP          = 3'b111;
   localparam [2:0] CMD_ACTIVE       = 3'b011;
   localparam [2:0] CMD_READ         = 3'b101;
   localparam [2:0] CMD_WRITE        = 3'b100;
   localparam [2:0] CMD_PRECHARGE    = 3'b010;
   localparam [2:0] CMD_AUTO_REFRESH = 3'b001;
   localparam [2:0] CMD_LOAD_MODE    = 3'b000;

   // [inherited, audited] 50 MHz timing floors
   localparam [3:0] T_RP  = 4'd2;
   localparam [3:0] T_RCD = 4'd2;
   localparam [3:0] T_RC  = 4'd4;
   localparam [14:0] STARTUP_CYCLES = 15'd12500;   // >=200 us @50 MHz
   localparam [12:0] REFRESH_PERIOD = 13'd350;     // 7.0 us

   reg  [2:0]  command;
   reg  [14:0] init_cnt = 0;
   reg         initialized = 0;
   reg  [12:0] refresh_cnt = 0;
   reg         need_refresh = 0;

   reg         bank_open [0:3];
   reg  [12:0] bank_row  [0:3];
   reg  [3:0]  since_active   [0:3];
   reg  [3:0]  since_precharge[0:3];

   reg  [24:0] req_addr;
   reg  [15:0] req_din;
   reg  [1:0]  req_wtbt;
   reg         req_we;
   reg  [15:0] data;

   reg         old_we, old_rd;
   reg         have_req;

   reg  [CAS_LATENCY+PIN_LAT:0] rd_delay;

   reg  [15:0] sdram_dq_out;
   reg         sdram_dq_oe;
   integer bi;

   assign o_dq_out = sdram_dq_out;
   assign o_dq_oe  = sdram_dq_oe;
   assign o_cke    = 1'b1;
   assign o_ncs    = 1'b0;
   assign o_nras   = command[2];
   assign o_ncas   = command[1];
   assign o_nwe    = command[0];
   assign {o_dqmh,o_dqml} = o_A[12:11];
   assign dout = req_addr[0] ? {data[7:0], data[15:8]} : {data[15:8], data[7:0]};

   // [C31-1] C31 decomposition: bank=addr[24:23], row=addr[22:10], col=addr[9:1]
   wire [1:0]  r_bank = req_addr[24:23];
   wire [12:0] r_row  = req_addr[22:10];
   wire [8:0]  r_col  = req_addr[9:1];

   // burst request decomposition (same scheme)
   reg  [1:0]  b_bank;
   reg  [12:0] b_row;
   reg  [8:0]  b_col0;      // starting column
   reg  [9:0]  b_len, b_issue, b_recv;
   wire [8:0]  b_col_now = b_col0 + b_issue[8:0];

   localparam [3:0] S_INIT        = 4'd0,
                    S_IDLE        = 4'd1,
                    S_PRECHARGE   = 4'd2,
                    S_ACTIVATE    = 4'd3,
                    S_COLUMN      = 4'd4,
                    S_READWAIT    = 4'd5,
                    S_REFRESH     = 4'd6,
                    S_INIT_REFWAIT= 4'd7,
                    S_BPRE        = 4'd8,   // [C31-2] burst: precharge wrong row
                    S_BACT        = 4'd9,   // [C31-2] burst: activate + tRCD
                    S_BRUN        = 4'd10,  // [C31-2] burst: issue column reads, capture
                    S_BTAIL       = 4'd11;  // [C31-2] burst: drain the read pipeline
   reg  [3:0]  state = S_INIT;
   reg  [3:0]  wait_cnt;
   wire        burst_active = (state==S_BPRE)||(state==S_BACT)||(state==S_BRUN)||(state==S_BTAIL);

   task issue_column;               // single-word (donor path, [C31-1] decomposition)
      begin
         if (req_we) begin
            command      <= CMD_WRITE;
            o_A          <= { (req_wtbt ? ~req_wtbt[1] : 1'b0),
                              (req_wtbt ? ~req_wtbt[0] : 1'b0),
                              1'b0, 1'b0, r_col };
            sdram_dq_out <= req_wtbt ? req_din : {req_din[7:0], req_din[7:0]};
            sdram_dq_oe  <= 1'b1;
            ready        <= 1'b1;
            have_req     <= 1'b0;
            state        <= S_IDLE;
         end else begin
            command      <= CMD_READ;
            o_A          <= { 2'b00, 1'b0, 1'b0, r_col };
            rd_delay[CAS_LATENCY+PIN_LAT] <= 1'b1;
            state        <= S_READWAIT;
         end
      end
   endtask

   always @(posedge clk) begin
      command      <= CMD_NOP;
      sdram_dq_oe  <= 1'b0;
      burst_dvalid <= 1'b0;

      for (bi=0; bi<4; bi=bi+1) begin
         if (since_active[bi]    != 4'hF) since_active[bi]    <= since_active[bi]    + 1'b1;
         if (since_precharge[bi] != 4'hF) since_precharge[bi] <= since_precharge[bi] + 1'b1;
      end

      refresh_cnt <= refresh_cnt + 1'b1;
      if (refresh_cnt >= REFRESH_PERIOD) begin refresh_cnt <= 0; need_refresh <= 1'b1; end

      // shared CAS read-capture pipeline: single-op sets ready/state; burst emits dvalid.
      rd_delay <= {1'b0, rd_delay[CAS_LATENCY+PIN_LAT:1]};
      if (rd_delay[0]) begin
         if (burst_active) begin
            burst_dout   <= i_dq;
            burst_dvalid <= 1'b1;
            b_recv       <= b_recv + 1'b1;
         end else begin
            data  <= i_dq;
            ready <= 1'b1;
            have_req <= 1'b0;
            state <= S_IDLE;
         end
      end

      old_we <= we; old_rd <= rd;
      if ((we & ~old_we) | (rd & ~old_rd)) begin
         req_addr <= addr; req_din <= din; req_wtbt <= wtbt; req_we <= we & ~old_we;
         have_req <= 1'b1;
         ready    <= 1'b0;
      end

      // burst start latch (only when idle and no pending single op)
      if (burst_rd && state==S_IDLE && !have_req && initialized) begin
         b_bank   <= burst_addr[24:23];
         b_row    <= burst_addr[22:10];
         b_col0   <= burst_addr[9:1];
         b_len    <= burst_len;
         b_issue  <= 10'd0;
         b_recv   <= 10'd0;
         burst_busy <= 1'b1;
         o_BA     <= burst_addr[24:23];
         if (bank_open[burst_addr[24:23]] && bank_row[burst_addr[24:23]]==burst_addr[22:10]
               && since_active[burst_addr[24:23]] >= T_RCD) begin
            state <= S_BRUN;                          // page hit: stream immediately
         end else if (bank_open[burst_addr[24:23]] && bank_row[burst_addr[24:23]]!=burst_addr[22:10]) begin
            command <= CMD_PRECHARGE; o_A[10] <= 1'b0;
            bank_open[burst_addr[24:23]] <= 1'b0; since_precharge[burst_addr[24:23]] <= 4'd0;
            wait_cnt <= T_RP; state <= S_BPRE;
         end else begin
            wait_cnt <= 4'd0; state <= S_BPRE;        // closed: S_BPRE falls through to activate
         end
      end

      case (state)
         S_INIT: begin
            o_A <= 13'd0; o_BA <= 2'd0;
            init_cnt <= init_cnt + 1'b1;
            if (init_cnt == STARTUP_CYCLES - 300) begin command <= CMD_PRECHARGE; o_A[10] <= 1'b1; end
            if (init_cnt == STARTUP_CYCLES - 275 || init_cnt == STARTUP_CYCLES - 250 || init_cnt == STARTUP_CYCLES - 225 ||
                init_cnt == STARTUP_CYCLES - 200 || init_cnt == STARTUP_CYCLES - 175 || init_cnt == STARTUP_CYCLES - 150 ||
                init_cnt == STARTUP_CYCLES - 125 || init_cnt == STARTUP_CYCLES - 100) command <= CMD_AUTO_REFRESH;
            if (init_cnt == STARTUP_CYCLES - 50)  begin command <= CMD_LOAD_MODE; o_A <= MODE; end
            if (init_cnt >= STARTUP_CYCLES) begin
               // zk4: no spurious ready when a single op was latched during init (or arrives this clock):
               // the backing's A_WLOW takes that edge as "low half written" and the high half then
               // overwrites the latched low-half request before its column command -- MK4's first-ever
               // SDRAM write (ROM word 0, issued during init) lost its low half. Found by lanes/coldboot.
               state <= S_IDLE; ready <= ~(have_req | (we & ~old_we) | (rd & ~old_rd)); initialized <= 1'b1;
               for (bi=0; bi<4; bi=bi+1) begin bank_open[bi] <= 1'b0; since_precharge[bi] <= 4'hF; since_active[bi] <= 4'hF; end
            end
         end

         S_IDLE: begin
            if (need_refresh && !have_req && !burst_rd) begin
               command <= CMD_PRECHARGE; o_A[10] <= 1'b1;
               for (bi=0; bi<4; bi=bi+1) begin bank_open[bi] <= 1'b0; since_precharge[bi] <= 4'd0; end
               wait_cnt <= T_RP; state <= S_REFRESH;
            end else if (have_req) begin
               if (bank_open[r_bank] && bank_row[r_bank] == r_row && since_active[r_bank] >= T_RCD) begin
                  o_BA <= r_bank; issue_column();
               end else if (bank_open[r_bank] && bank_row[r_bank] != r_row) begin
                  o_BA <= r_bank; command <= CMD_PRECHARGE; o_A[10] <= 1'b0;
                  bank_open[r_bank] <= 1'b0; since_precharge[r_bank] <= 4'd0;
                  wait_cnt <= T_RP; state <= S_PRECHARGE;
               end else begin
                  if (since_precharge[r_bank] >= T_RP) begin
                     o_BA <= r_bank; command <= CMD_ACTIVE; o_A <= r_row;
                     bank_open[r_bank] <= 1'b1; bank_row[r_bank] <= r_row;
                     since_active[r_bank] <= 4'd0;
                     wait_cnt <= T_RCD; state <= S_ACTIVATE;
                  end
               end
            end
         end

         S_PRECHARGE: begin
            if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
            else if (since_active[r_bank] >= T_RC || since_active[r_bank] == 4'hF) begin
               o_BA <= r_bank; command <= CMD_ACTIVE; o_A <= r_row;
               bank_open[r_bank] <= 1'b1; bank_row[r_bank] <= r_row;
               since_active[r_bank] <= 4'd0;
               wait_cnt <= T_RCD; state <= S_ACTIVATE;
            end
         end

         S_ACTIVATE: begin
            if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
            else begin o_BA <= r_bank; issue_column(); end
         end

         S_COLUMN: begin o_BA <= r_bank; issue_column(); end
         S_READWAIT: ;

         S_REFRESH: begin
            if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
            else begin command <= CMD_AUTO_REFRESH; need_refresh <= 1'b0; wait_cnt <= T_RC; state <= S_INIT_REFWAIT; end
         end

         S_INIT_REFWAIT: begin
            if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
            else state <= S_IDLE;
         end

         // ---- [C31-2] burst read ----
         S_BPRE: begin                                // wait tRP (if we precharged), then activate
            if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
            else if (since_precharge[b_bank] >= T_RP && (since_active[b_bank] >= T_RC || since_active[b_bank]==4'hF)) begin
               o_BA <= b_bank; command <= CMD_ACTIVE; o_A <= b_row;
               bank_open[b_bank] <= 1'b1; bank_row[b_bank] <= b_row;
               since_active[b_bank] <= 4'd0;
               wait_cnt <= T_RCD; state <= S_BACT;
            end
         end

         S_BACT: begin                                // wait tRCD, then stream
            if (wait_cnt != 0) wait_cnt <= wait_cnt - 1'b1;
            else state <= S_BRUN;
         end

         S_BRUN: begin                                // one column read per clock
            o_BA <= b_bank;
            command <= CMD_READ;
            o_A <= { 2'b00, 1'b0, 1'b0, b_col_now };
            rd_delay[CAS_LATENCY+PIN_LAT] <= 1'b1;
            b_issue <= b_issue + 1'b1;
            if (b_issue + 1'b1 == b_len) state <= S_BTAIL;   // all issued; drain the pipe
         end

         S_BTAIL: begin                               // capture handled above; finish when all received
            if (b_recv == b_len) begin
               burst_busy <= 1'b0;
               state <= S_IDLE;
            end
         end

         default: state <= S_IDLE;
      endcase

      if (init) begin
         state <= S_INIT; init_cnt <= 0; ready <= 1'b0; initialized <= 1'b0;
         have_req <= 1'b0; need_refresh <= 1'b0; refresh_cnt <= 0;
         burst_busy <= 1'b0; burst_dvalid <= 1'b0; b_issue <= 0; b_recv <= 0;
      end
   end
endmodule
`default_nettype wire
