// sim_bw1_pll.sv -- SIMULATION stand-in for wrapper/donor/bw1_pll.sv (an altera_pll primitive): both outputs follow
// the 50 MHz reference (the real outclk_1 is the same frequency, -3515 ps -- irrelevant to the input gate) and locked
// rises after a few reference edges, so the emu's P0022 power-on reset runs as on the board.
module bw1_pll(input wire refclk, rst, output wire outclk_0, outclk_1, locked);
    assign outclk_0 = refclk;
    assign outclk_1 = refclk;
    reg [3:0] n = 4'd0;
    always @(posedge refclk) if (n != 4'd15) n <= n + 4'd1;
    assign locked = n == 4'd15;
endmodule
