#!/bin/bash
# AUDIO GAIN gate: gen_audio_gain_golden.py is the oracle for both parts.
#   unit : zk4_audio_gain.sv vs the golden, all int16 inputs x 4 gain codes, L and R driven with different words (iverilog)
#   mk4 / inv : EMU level (tb_zk4_emu_audio_gain.sv, Verilator --timing, real zk4_emu + sys/hps_io + core), MK4 and
#          Invasion (ZK4_GAME_INVASION): the golden OSD entry in CONF_STR exactly once, no status-bit collision in the
#          whole CONF_STR, OSD status[11:10] -> the golden gain code at zk4_audio_gain (default +12 dB first)
# env: ZAG_MUT=sed-expression mutates zk4_audio_gain.sv, ZAG_EMU_MUT=sed-expression mutates zk4_emu.sv (each refuses
#      if it did not apply); ZAG_PARTS="unit mk4 inv" (default all) restricts the parts run.
# usage: wsl bash run_zk4_audio_gain.sh
set -u
Z=/mnt/d/deck/fpga/zeus; R=$Z/zeus1/rtl; Q=$Z/zeus1/quartus; C=$Z/core/rtl/cpu; W=$R/wrapper
B=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}" zag.XXXXXX); cd "$B" || exit 2
M="$W/zk4_audio_gain.sv"; EMU="$W/zk4_emu.sv"; PARTS="${ZAG_PARTS:-unit mk4 inv}"
if [ -n "${ZAG_MUT:-}" ]; then sed "$ZAG_MUT" "$M" > zk4_audio_gain.sv; cmp -s zk4_audio_gain.sv "$M" && { echo "MUTATION DID NOT APPLY"; exit 3; }; M=$B/zk4_audio_gain.sv; fi
if [ -n "${ZAG_EMU_MUT:-}" ]; then sed "$ZAG_EMU_MUT" "$EMU" > zk4_emu.sv; cmp -s zk4_emu.sv "$EMU" && { echo "MUTATION DID NOT APPLY"; exit 3; }; EMU=$B/zk4_emu.sv; fi
python3 $W/gen_audio_gain_golden.py vec.hex osd.txt > gen.log || { echo "GOLDEN FAILED"; exit 2; }
rc=0
if [[ " $PARTS " == *" unit "* ]]; then
  iverilog -g2012 -o tb.vvp $M $W/tb_zk4_audio_gain.sv > build.log 2>&1 || { head -20 build.log; echo "BUILD FAILED"; exit 2; }
  vvp -n tb.vvp +VEC=vec.hex > run.log 2>&1
  grep -E "FAIL|PASS|AUDIO_GAIN" run.log | head -12
  grep -qx "PASS" run.log && ! grep -q "^FAIL" run.log || rc=1
fi
FS="$Q/sys/hps_io.sv $W/sim_bw1_pll.sv"
for f in c31_core c31_ea c31_shift c31_mpyi c31_cond c31_addsubf c31_mpyf c31_negf c31_absf c31_rnd c31_norm c31_int2float c31_float2int c31_fconv; do FS="$FS $C/$f.sv"; done
for f in tier/c31_page_cache tier/c31_page_cache_sa tier/c31_bus_adapter tier/zk4_memory_p3 tier/zk4_memory_fp fp32/fp32_pkg fp32/fp32_units \
         setup/zr_sdp front/zr_front5 setup/zr_setup9 pixel/zr_pixel10 render/zr_fifo render/zr_rfifo render/zr_cmdq render/zr_render5 \
         memsys/zr_ddr_gateway memsys/zr_memsys memsys/zr_rsys video/zr_scanout core/zr_host1 core/zk4_c32_ctl core/zk4_int2 core/zk4_core \
         board/zk4_pic2 board/zk4_ioasic board/zk4_dcs_stub board/zk4_cmos board/zk4_board_io board/zk4_gun \
         wrapper/donor/c31_sdram_burst wrapper/donor/c31_sdram_backing wrapper/zk4_sdram wrapper/donor/gm1_hdmi_status wrapper/zk4_ddr_arb \
         wrapper/zk4_ddr_arb3 wrapper/zk4_status_mirror wrapper/zk4_ram_reload wrapper/zk4_loader wrapper/zk4_top \
         wrapper/gun/zk4_gun_input wrapper/gun/zk4_lightgun_position wrapper/gun/zk4_lightgun_overlay; do FS="$FS $R/$f.sv"; done
for v in mk4 inv; do
  [[ " $PARTS " == *" $v "* ]] || continue
  D=""; [ $v = inv ] && D="-DZK4_GAME_INVASION"
  mkdir -p $v; ( cd $v && verilator --binary --timing -j 8 --top-module tb_zk4_emu_audio_gain -Wno-fatal -Wno-lint -Wno-style \
      -Wno-PROCASSWIRE -Wno-BLKANDNBLK -I$Q -I$C -I$R/fp32 $D $FS $M "$EMU" $W/tb_zk4_emu_audio_gain.sv -o tb > build.log 2>&1 ) \
    || { grep -m20 -E "%Error" $v/build.log; echo "BUILD FAILED ($v)"; exit 2; }
  ( cd $v && ./obj_dir/tb +OSD=$B/osd.txt > run.log 2>&1 ); trc=$?
  grep -E "FAIL|PASS|AUDIO_GAIN_EMU" $v/run.log | head -20
  [ $trc = 0 ] && grep -qx "PASS" $v/run.log && ! grep -q "^FAIL" $v/run.log || rc=1
done
echo "AUDIO GAIN GATE [$PARTS]: $([ $rc = 0 ] && echo PASS || echo FAIL)"
cd /; rm -rf "$B"; exit $rc
