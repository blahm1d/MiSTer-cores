#!/usr/bin/env python3
"""Golden for zk4_audio_gain (written from the OSD spec, independently of the RTL):
OSD code -> gain in dB: 0 = 0 dB (default), 1 = +6 dB, 2 = +12 dB, 3 = +18 dB; linear factor 2**(dB/6) = 1, 2, 4, 8.
out = clamp(in * factor, -32768, 32767) on signed 16-bit PCM, per channel.
Vectors: every int16 x on L with R = the bitwise complement of x (so a crossed channel is caught), all 4 codes.
Line: <code> <in_l> <in_r> <exp_l> <exp_r> as hex (16-bit two's complement).
OSD contract (optional <osd.txt>, for the emu-level check, both games): the OSD entry "Audio Gain" on status[11:10]
lists +12 dB FIRST (status 0 = the default, user decision 2026-09-26: +12 dB for MK4 and Invasion), then 0, +6, +18 dB.
File: line 1 = the exact CONF_STR entry; then 4 lines "<status> <gain code>" (gain code = dB / 6).
usage: gen_audio_gain_golden.py <out.hex> [<osd.txt>]"""
import sys
DB = {0: 0, 1: 6, 2: 12, 3: 18}
OSD_DB = [12, 0, 6, 18]          # OSD status 0..3 -> dB (the user's contract; status 0 = default)

if len(sys.argv) > 2:
    with open(sys.argv[2], "w") as f:
        f.write("O[11:10],Audio Gain," + ",".join(("+%d dB" % d) if d else "0 dB" for d in OSD_DB) + ";\n")
        for s, d in enumerate(OSD_DB):
            f.write(f"{s} {d // 6}\n")

def clamp(v):
    return max(-32768, min(32767, v))

def h(v):
    return "%04X" % (v & 0xFFFF)

with open(sys.argv[1], "w") as f:
    n = 0
    for code in range(4):
        fac = round(2 ** (DB[code] / 6.0))
        for x in range(-32768, 32768):
            r = ~x
            f.write(f"{code:X} {h(x)} {h(r)} {h(clamp(x * fac))} {h(clamp(r * fac))}\n"); n += 1
print(f"golden: {n} vectors")
