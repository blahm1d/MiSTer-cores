#!/bin/bash
# zk4_raw_check mutants: each must FAIL run_zk4_raw_check.sh
#   R1 a write to an address already in the CAM inserts a second entry (stale duplicate)
#   R2 the returning beat is matched against the wrong index (off by one)
#   R3 a partial-BE write (dropped by the port) does not invalidate the CAM entry
#   R4 the compare never reports a mismatch
#   R5 the write-burst beat address does not advance (every beat recorded at the first address)
#   R6 the DDR-window test is dropped (an address outside the window aliases into it)
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; bad=0
run() { out=$(ZRC_MUT="$2" bash $D/run_zk4_raw_check.sh 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$1 NOT APPLIED / BUILD FAILED"; bad=1
  elif [ $rc = 0 ]; then echo "$1 SURVIVED"; bad=1
  else echo "$1 killed: $(echo "$out" | grep -m1 FAIL: | cut -c1-110)"; fi; }
run R1 's/          if (whit) begin cd\[widx\] <= fold16(d_din); ct\[widx\] <= ts; end/          if (1'"'"'b0) begin end/'
run R2 's/  logic push, pop; assign pop = d_rdv \&\& pv \&\& ps == seq_ret;/  logic push, pop; assign pop = d_rdv \&\& pv \&\& ps == seq_ret + 8'"'"'d1;/'
run R3 's/        end else if (whit) cv\[widx\] <= 1.b0;/        end/'
run R4 's/        if (fold16(d_dout) != pe) begin/        if (1'"'"'b0) begin/'
run R5 's/        else begin wleft <= wleft - 8.d1; waddr <= waddr + 29.d1; end/        else begin wleft <= wleft - 8'"'"'d1; end/'
run R6 's/  logic win_w, win_r; assign win_w = wa\[28:22\] == 7.h18; assign win_r = d_addr\[28:22\] == 7.h18;/  logic win_w, win_r; assign win_w = 1'"'"'b1; assign win_r = 1'"'"'b1;/'
exit $bad
