// zk4_ddr_arb3 gate: a hostile DDRAM (random BUSY, reads answered in order after a latency) shared by
//   R  a renderer-like master (random reads and write bursts of 1-63 beats, data beats with random GAPS, reads
//      pipelined: a new read may be issued before earlier data returned),
//   S  a DCS-agent-like master (single-beat reads and writes, byte addresses, ONE read outstanding: it waits for
//      its data), and
//   M  a mirror-like master (single-beat writes, byte addresses).
// Every master holds its command until accepted. Checked every clock:
//   * slave-side stability: a command or data beat offered while BUSY is identical on the next clock (gm1 rule)
//   * burst integrity: no S or M beat is accepted between a renderer burst's first and last beat
//   * reads: every read beat reaches the master that issued it, in order, with the model's data
//   * end: the DDR image equals the shadow; every S and M operation completed
// usage: tb_zk4_ddr_arb3 [cycles] [busy%] [seed]
#include "Vzk4_ddr_arb3.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <deque>
#include <map>
#include <algorithm>
typedef uint64_t u64; typedef uint32_t u32;
static u64 rs = 0x853C49E6748FEA9Bull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
int main(int argc, char** argv) {
    long N = argc > 1 ? atol(argv[1]) : 300000; int BUSY = argc > 2 ? atoi(argv[2]) : 50; if (argc > 3) rs = strtoull(argv[3], 0, 0) | 1;
    Verilated::commandArgs(argc, argv);
    Vzk4_ddr_arb3* t = new Vzk4_ddr_arb3;
    const u32 RB = 0x06000000, RN = 4096, MB = 0x30C00000u >> 3, MN = 64, SB = 0x31000000u >> 3, SN = 512;
    std::map<u32, u64> ddr, shadow;
    auto rd = [&](std::map<u32, u64>& m, u32 a) { auto it = m.find(a); return it == m.end() ? 0ull : it->second; };
    struct Beat { u64 due, data; }; std::deque<Beat> rq; std::deque<u64> r_expect;
    bool r_on = false, r_isw = false; u32 r_addr = 0; unsigned r_n = 0, r_sent = 0; u64 r_data = 0; unsigned char r_be = 0xff;
    bool r_gap = false;
    bool m_on = false; u32 m_word = 0; u64 m_data = 0; long m_done = 0, m_offered = 0;
    const bool M_OFF = getenv("M_OFF") && atoi(getenv("M_OFF"));   // 1 = the no-diag build: mirror port tied off (m_write 0)
    // S (DCS agent) is now MULTI-OUTSTANDING (pipelined single-beat reads, like dcs2_ddr_agent's fill):
    // up to SDEPTH reads may be in flight; each accepted read pushes its expected data, checked in order.
    bool s_on = false, s_isw = false; u32 s_word = 0; u64 s_data = 0; unsigned char s_be = 0xff;
    long s_done = 0, s_offered = 0, s_reads = 0; std::deque<u64> s_expq; size_t s_maxout = 0;
    int SDEPTH = getenv("S_DEPTH") ? atoi(getenv("S_DEPTH")) : 6;
    bool prev_off = false; unsigned p_rd = 0, p_wr = 0; u32 p_addr = 0; unsigned p_bc = 0; u64 p_wd = 0; unsigned p_be = 0;
    long errs = 0, clocks = 0, rbeats = 0, wbursts = 0, rbursts = 0; bool in_rburst = false; unsigned burst_left = 0;
    t->rst = 1; for (int i = 0; i < 4; i++) { t->clk = 0; t->eval(); t->clk = 1; t->eval(); } t->rst = 0;
    for (long c = 0; c < N || r_on || m_on || s_on || !s_expq.empty() || !rq.empty() || !r_expect.empty(); c++) {
        if (c > N + 200000) { printf("FAIL: no drain (r_on %d m_on %d s_on %d s_expq %zu rq %zu r_expect %zu)\n", r_on, m_on, s_on, s_expq.size(), rq.size(), r_expect.size()); return 1; }
        if (!r_on && c < N && rnd() % 100 < 30) {
            r_on = true; r_isw = rnd() % 2; r_addr = RB + (u32)(rnd() % (RN - 64)); r_n = 1 + rnd() % 63; r_sent = 0;
            r_data = rnd(); r_be = (rnd() % 4) ? 0xff : (unsigned char)(rnd() | 1); r_gap = false;
        }
        if (!M_OFF && !m_on && c < N && rnd() % 100 < 10) { m_on = true; m_word = MB + (u32)(rnd() % MN); m_data = rnd(); m_offered++; }
        if (!s_on && c < N && (int)s_expq.size() < SDEPTH && rnd() % 100 < 40) {
            // a write only when no reads are in flight (keeps the shadow RAW-ordering simple); else a read
            s_isw = s_expq.empty() && (rnd() % 5 == 0);
            s_on = true; s_word = SB + (u32)(rnd() % SN); s_data = rnd();
            s_be = (rnd() % 4) ? 0xff : (unsigned char)(rnd() | 1); s_offered++;
        }
        t->clk = 0;
        if (r_gap && rnd() % 100 < 50) r_gap = false;
        t->r_read = r_on && !r_isw && r_sent == 0;
        t->r_write = r_on && r_isw && !r_gap;
        t->r_address = r_addr; t->r_burstcount = r_n; t->r_writedata = r_data; t->r_byteenable = r_be;
        t->m_write = m_on; t->m_address = m_word << 3; t->m_writedata = m_data;
        t->s_read = s_on && !s_isw; t->s_write = s_on && s_isw; t->s_address = s_word << 3; t->s_writedata = s_data;
        t->s_byteenable = s_be;
        t->d_busy = (int)(rnd() % 100) < BUSY;
        t->d_readdatavalid = 0;
        if (!rq.empty() && rq.front().due <= (u64)clocks) { t->d_readdatavalid = 1; t->d_readdata = rq.front().data; rq.pop_front(); }
        t->eval();
        bool off = t->d_read || t->d_write;
        if (prev_off && (!off || t->d_read != p_rd || t->d_write != p_wr || t->d_address != p_addr || t->d_burstcount != p_bc ||
                         (t->d_write && (t->d_writedata != p_wd || t->d_byteenable != p_be)))) {
            if (errs++ < 10) printf("ERR clk %ld: offered command changed while BUSY (addr %07X -> %07X)\n", clocks, p_addr, (u32)t->d_address);
        }
        prev_off = off && t->d_busy; p_rd = t->d_read; p_wr = t->d_write; p_addr = t->d_address; p_bc = t->d_burstcount;
        p_wd = t->d_writedata; p_be = t->d_byteenable;
        if (t->r_readdatavalid && t->s_readdatavalid && errs++ < 10) printf("ERR clk %ld: one beat delivered to two masters\n", clocks);
        if (t->d_readdatavalid && !t->r_readdatavalid && !t->s_readdatavalid && errs++ < 10) printf("ERR clk %ld: read beat delivered to nobody\n", clocks);
        if (t->r_readdatavalid) {
            if (r_expect.empty()) { if (errs++ < 10) printf("ERR clk %ld: renderer got read data it never asked for\n", clocks); }
            else { if (t->r_readdata != r_expect.front() && errs++ < 10) printf("ERR clk %ld: renderer read %016llX want %016llX\n", clocks, (unsigned long long)t->r_readdata, (unsigned long long)r_expect.front()); r_expect.pop_front(); rbeats++; }
        }
        if (t->s_readdatavalid) {
            if (s_expq.empty()) { if (errs++ < 10) printf("ERR clk %ld: DCS got read data it never asked for\n", clocks); }
            else { if (t->s_readdata != s_expq.front() && errs++ < 10) printf("ERR clk %ld: DCS read %016llX want %016llX (in-order)\n", clocks, (unsigned long long)t->s_readdata, (unsigned long long)s_expq.front()); s_expq.pop_front(); s_done++; s_reads++; }
        }
        bool acc = off && !t->d_busy;
        if (acc) {
            u32 a = t->d_address;
            bool is_m = a >= MB && a < MB + MN, is_s = a >= SB && a < SB + SN;
            if (t->d_read) {
                u64 due = std::max<u64>(clocks + 12, rq.empty() ? 0 : rq.back().due + 1);
                for (unsigned k = 0; k < t->d_burstcount; k++) rq.push_back({due + k, rd(ddr, a + k)});
                if (!is_s) rbursts++;
                if (is_s && in_rburst && errs++ < 10) printf("ERR clk %ld: DCS read inside a renderer burst\n", clocks);
            } else {
                if (!is_m && !is_s) { if (burst_left == 0) { burst_left = t->d_burstcount; in_rburst = true; wbursts++; } }
                if ((is_m || is_s) && in_rburst && errs++ < 10) printf("ERR clk %ld: %s write inside a renderer burst\n", clocks, is_m ? "mirror" : "DCS");
                u32 wa = (is_m || is_s) ? a : (u32)(r_addr + (r_n - burst_left));
                u64 nd = rd(ddr, wa);
                for (int b = 0; b < 8; b++) if (t->d_byteenable >> b & 1) nd = (nd & ~(0xffull << (8 * b))) | (t->d_writedata & (0xffull << (8 * b)));
                ddr[wa] = nd;
                if (!is_m && !is_s) { if (--burst_left == 0) in_rburst = false; }
            }
        }
        if (t->r_read && !t->r_waitrequest) { for (unsigned k = 0; k < r_n; k++) r_expect.push_back(rd(shadow, r_addr + k)); r_on = false; }
        if (t->r_write && !t->r_waitrequest) {
            u32 wa = r_addr + r_sent; u64 nd = rd(shadow, wa);
            for (int b = 0; b < 8; b++) if (r_be >> b & 1) nd = (nd & ~(0xffull << (8 * b))) | (r_data & (0xffull << (8 * b)));
            shadow[wa] = nd; r_sent++; r_data = rnd();
            if (r_sent == r_n) r_on = false; else if (rnd() % 100 < 25) r_gap = true;
        }
        if (t->m_write && !t->m_waitrequest) { shadow[m_word] = m_data; m_on = false; m_done++; }
        if ((t->s_read || t->s_write) && !t->s_waitrequest) {
            if (s_isw) { u64 nd = rd(shadow, s_word);
                for (int b = 0; b < 8; b++) if (s_be >> b & 1) nd = (nd & ~(0xffull << (8 * b))) | (s_data & (0xffull << (8 * b)));
                shadow[s_word] = nd; s_done++; }
            else { s_expq.push_back(rd(shadow, s_word)); if (s_expq.size() > s_maxout) s_maxout = s_expq.size(); }   // multi-outstanding: expected data in issue order
            s_on = false;
        }
        t->eval(); t->clk = 1; t->eval(); clocks++;
    }
    long diff = 0;
    for (auto& kv : shadow) if (rd(ddr, kv.first) != kv.second) diff++;
    for (auto& kv : ddr) if (rd(shadow, kv.first) != kv.second) diff++;
    printf("DDR_ARB3 clocks %ld: R read bursts %ld (%ld beats), write bursts %ld; S ops %ld/%ld (%ld reads, max outstanding %zu, longest wait %u); M writes %ld/%ld (longest wait %u); tag overflow %u; image diff %ld\n",
           clocks, rbursts, rbeats, wbursts, s_done, s_offered, s_reads, s_maxout, t->st_s_wait_max, m_done, m_offered, t->st_m_wait_max,
           (unsigned)t->st_tag_overflow, diff);
    bool pass = errs == 0 && diff == 0 && m_done == m_offered && s_done == s_offered && (M_OFF ? m_done == 0 : m_done > 100) && s_reads > 100 &&
                wbursts > 100 && rbeats > 1000 && !t->st_tag_overflow && s_maxout >= 2;  // s_maxout>=2 proves pipelined D reads exercised
    printf("%s (busy %d%%)\n", pass ? "PASS" : "FAIL", BUSY);
    delete t; return pass ? 0 : 1;
}
