#!/bin/bash
# zk4_ddr_arb gate. usage: wsl bash run_zk4_ddr_arb.sh [cycles] [busy%] [seed]; ZDA_MUT=sed-expression mutates zk4_ddr_arb.sv
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; B="${ZSCRATCH:-/mnt/h/temp/zeus}/zk4-ddrarb-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC=$S/zk4_ddr_arb.sv
if [ -n "${ZDA_MUT:-}" ]; then sed "$ZDA_MUT" "$SRC" > zk4_ddr_arb.sv; cmp -s zk4_ddr_arb.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zk4_ddr_arb.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zk4_ddr_arb -Wno-fatal -Wno-lint -Wno-style "$SRC" $S/tb_zk4_ddr_arb.cpp -o tb > build.log 2>&1 || { tail -20 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
