#!/bin/bash
# zk4_cmos / zk4_ram_reload mutants: each must FAIL run_zk4_nvreset.sh
#   C1 host bytes swapped between the banks        C2 host write not inverted (even bank)
#   C3 game bank select inverted (even bank)       C4 game read-back bank select inverted
#   R1 word 0 not shifted (midzeus.cpp:237)        R2 request held across the ack (glue rule)
#   R3 copy stops one word short                   R4 writes land one word off
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; bad=0
run() { out=$(ZNV_FILE="$2" ZNV_MUT="$3" bash $D/run_zk4_nvreset.sh 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$1 NOT APPLIED / BUILD FAILED"; bad=1
  elif [ $rc = 0 ]; then echo "$1 SURVIVED"; bad=1
  else echo "$1 killed: $(echo "$out" | grep -m1 FAIL | cut -c1-100)"; fi; }
run C1 zk4_cmos.sv 's/\.b_we, \.b_row, \.b_d(~b_d\[7:0\]), \.b_q(q_be));/.b_we, .b_row, .b_d(~b_d[15:8]), .b_q(q_be));/'
run C2 zk4_cmos.sv 's/\.b_d(~b_d\[7:0\])/.b_d(b_d[7:0])/'
run C3 zk4_cmos.sv 's/\.a_we(a_we \&\& !a_addr\[0\])/.a_we(a_we \&\& a_addr[0])/'
run C4 zk4_cmos.sv 's/assign a_q = ~(a_odd ? q_ao : q_ae);/assign a_q = ~(a_odd ? q_ae : q_ao);/'
run R1 zk4_ram_reload.sv 's/(SHIFT0 \&\& idx == 18.d0) ?/(1'"'"'b0) ?/'
run R2 zk4_ram_reload.sv 's/S_RDW:  if (sd_ack) begin sd_req <= 1.b0; data <= sd_rdata;/S_RDW:  if (sd_ack) begin data <= sd_rdata;/'
run R3 zk4_ram_reload.sv 's/S_GAP2: if (idx == LAST)/S_GAP2: if (idx == LAST - 1)/'
run R4 zk4_ram_reload.sv 's/sd_addr <= {6.d0, idx};/sd_addr <= {6'"'"'d0, idx + 18'"'"'d1};/'
exit $bad
