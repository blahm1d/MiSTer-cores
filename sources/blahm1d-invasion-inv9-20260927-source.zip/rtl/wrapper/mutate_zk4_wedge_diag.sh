#!/bin/bash
# zk4_wedge_diag mutants: each must FAIL run_zk4_wedge_diag.sh (the gate fails if the watchdog / checker is removed)
#   W1 watchdog counters never count (instrument removed)     W2 a tie goes to the UPSTREAM stage
#   W3 the fire latch is not sticky (re-latches every clock)  D1 DDR stage ignores outstanding read beats (lost response)
#   G1 watchdogs count while the game is held in reset        P1 no ADDR-stability check      P2 no DIN-stability check
#   P3 no stray-read-beat check                               P4 protocol checker removed (never fires)
#   R1 the queue-full snapshot is not sticky                  R2 the FIFO ring never shifts
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; bad=0
run() { out=$(ZWD_MUT="$2" bash $D/run_zk4_wedge_diag.sh 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$1 NOT APPLIED / BUILD FAILED"; bad=1
  elif [ $rc = 0 ]; then echo "$1 SURVIVED"; bad=1
  else echo "$1 killed: $(echo "$out" | grep -m1 -E "ERR|FAIL" | cut -c1-110)"; fi; }
run W1 's/      else if (!wc\[i\]\[WD_LOG2\]) wc\[i\] <= wc\[i\] + 1.b1;/      else ;/'
run W2 's/      if (fire\[i\]) fire_id = 4.(i + 1);  /      if (fire[i] \&\& fire_id == 4'"'"'d0) fire_id = 4'"'"'(i + 1);/'
run W3 's/    end else if (!wd_fired \&\& fire_id != 4.d0) begin/    end else if (fire_id != 4'"'"'d0) begin/'
run D1 's/  assign work = {offered || rd_out != 16.d0, wd_work};/  assign work = {offered, wd_work};/'
run G1 's/      if (por || !run || !work\[i\] || prog\[i\]) wc\[i\] <= .0;/      if (por || !work[i] || prog[i]) wc[i] <= '"'"'0;/'
run P1 's/      if (p_first) begin pv\[2\] = d_addr != p_addr; pv\[3\] = d_bc != p_bc; end/      if (p_first) begin pv[3] = d_bc != p_bc; end/'
run P2 's/      if (p_we) begin pv\[4\] = d_din != p_din; pv\[5\] = d_be != p_be; end/      if (p_we) begin pv[5] = d_be != p_be; end/'
run P3 's/    pv\[6\] = d_rdv \&\& rd_out == 16.d0;/    pv[6] = 1'"'"'b0;/'
run P4 's/    else if (pv_id != 4.d0) begin/    else if (1'"'"'b0) begin/'
run R1 's/      if (run \&\& cq_full \&\& !cqf_seen) begin/      if (run \&\& cq_full) begin/'
run R2 's/      if (run \&\& fifo_we) begin ring\[0\] <= fifo_wd; for (int k = 1; k < 4; k++) ring\[k\] <= ring\[k - 1\]; end/      if (run \&\& fifo_we) ring[0] <= fifo_wd;/'
exit $bad
