// tb_zk4_audio_gain.sv -- zk4_audio_gain vs gen_audio_gain_golden.py (all int16 x 4 OSD codes, L/R independent).
// Vector file: plusarg +VEC=<path> (5 hex fields per line, see the golden). Prints PASS or FAIL lines.
`timescale 1ns/1ps
module tb_zk4_audio_gain;
  reg clk = 0; always #5 clk = ~clk;
  reg [1:0] code; reg signed [15:0] il, ir; wire signed [15:0] ol, or_;
  zk4_audio_gain dut (.clk(clk), .code(code), .in_l(il), .in_r(ir), .out_l(ol), .out_r(or_));
  integer fd, rc, n, bad; reg [31:0] c, a, b, el, er; string vec;
  initial begin
    if (!$value$plusargs("VEC=%s", vec)) begin $display("FAIL no +VEC"); $finish; end
    fd = $fopen(vec, "r"); if (fd == 0) begin $display("FAIL cannot open %s", vec); $finish; end
    n = 0; bad = 0;
    while (!$feof(fd)) begin
      rc = $fscanf(fd, "%h %h %h %h %h\n", c, a, b, el, er);
      if (rc == 5) begin
        code = c[1:0]; il = a[15:0]; ir = b[15:0];
        @(posedge clk); #1;
        if (ol !== el[15:0] || or_ !== er[15:0]) begin
          bad = bad + 1;
          if (bad <= 8) $display("FAIL code %0d in %04h/%04h: got %04h/%04h exp %04h/%04h", c, a[15:0], b[15:0], ol, or_, el[15:0], er[15:0]);
        end
        n = n + 1;
      end
    end
    $display("AUDIO_GAIN: %0d vectors, %0d mismatches", n, bad);
    if (n == 262144 && bad == 0) $display("PASS"); else $display("FAIL");
    $finish;
  end
endmodule
