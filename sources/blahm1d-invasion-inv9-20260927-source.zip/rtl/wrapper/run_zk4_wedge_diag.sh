#!/bin/bash
# zk4_wedge_diag gate (the r10 wedge instrument, since r13 in zk4_diag_dormant.sv, not in the core). WD_LOG2 = 10 so a watchdog fires in 1024
# clocks. usage: wsl bash run_zk4_wedge_diag.sh      ZWD_MUT=sed-expression mutates zk4_diag_dormant.sv (refuses if not applied)
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; B="${ZSCRATCH:-/mnt/h/temp/zeus}/zk4-wedge-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC=$S/zk4_diag_dormant.sv
if [ -n "${ZWD_MUT:-}" ]; then sed "$ZWD_MUT" "$SRC" > zk4_diag_dormant.sv; cmp -s zk4_diag_dormant.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=$B/zk4_diag_dormant.sv; fi
verilator --cc --exe --build -O2 -j 8 --top-module zk4_wedge_diag -GWD_LOG2=10 -Wno-fatal -Wno-lint -Wno-style "$SRC" $S/tb_zk4_wedge_diag.cpp -o tb > build.log 2>&1 \
  || { grep -m20 -E "%Error" build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb; rc=$?
cd /; rm -rf "$B"; exit $rc
