#!/bin/bash
# zk4_raw_check gate (r12 DDRAM read-after-write witness, since r13 in zk4_diag_dormant.sv, not in the core). Legs: in-order port (WVL 0) at 0 / 30 %
# waitrequest, reordering port (WVL 64, 2000) -- see tb_zk4_raw_check.cpp. ZRC_MUT=sed-expression mutates zk4_diag_dormant.sv.
# usage: wsl bash run_zk4_raw_check.sh        (exit 0 = every leg PASS)
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; B="${ZSCRATCH:-/mnt/h/temp/zeus}/zk4-rawchk-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC=$S/zk4_diag_dormant.sv
if [ -n "${ZRC_MUT:-}" ]; then sed "$ZRC_MUT" "$SRC" > zk4_diag_dormant.sv; cmp -s zk4_diag_dormant.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=$B/zk4_diag_dormant.sv; fi
verilator --cc --exe --build -O2 -j 8 --top-module zk4_raw_check -Wno-fatal -Wno-lint -Wno-style "$SRC" $S/tb_zk4_raw_check.cpp -o tb > build.log 2>&1 \
  || { grep -m20 -E "%Error" build.log; echo "BUILD FAILED"; exit 2; }
rc=0
for leg in "0 12 0" "0 12 30" "64 12 30" "2000 30 20"; do ./obj_dir/tb $leg 400000 || rc=1; done
cd /; rm -rf "$B"; exit $rc
