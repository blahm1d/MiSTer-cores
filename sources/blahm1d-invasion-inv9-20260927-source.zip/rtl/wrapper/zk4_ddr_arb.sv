// zk4_ddr_arb.sv -- the MiSTer DDRAM port shared by two Avalon masters: the renderer's memsys (zr_ddr_gateway: reads +
// write bursts up to 63 beats, 29-bit 64-bit-word addresses) and the status mirror (zk4_status_mirror: single-beat
// writes only, byte addresses). Rules (Cruis'n gm1 lessons, memory cruisinusa-gm1-ddr-fault-frontier):
//   1. The command offered to DDRAM stays byte-identical until DDRAM_BUSY drops: once a command is offered and
//      refused, the arbiter LOCKS onto its owner until it is accepted (an unstable offered command froze gm1's attract).
//   2. A renderer write burst is never interleaved: after its first (command) beat is accepted, only the renderer's
//      data beats pass until the burst's count is exhausted.
//   3. The renderer wins every open arbitration (urgent); the mirror fills the gaps. The mirror writes one 64-bit word
//      every ~2.5 us of a 40 ms period, so it is never starved in practice (census st_m_wait_max).
//   4. The mirror never reads: every readdatavalid belongs to the renderer, in order.
module zk4_ddr_arb (
  input  logic        clk, rst,
  // renderer (urgent)
  input  logic        r_read, r_write, input logic [28:0] r_address, input logic [7:0] r_burstcount,
  input  logic [63:0] r_writedata, input logic [7:0] r_byteenable,
  output logic        r_waitrequest, r_readdatavalid, output logic [63:0] r_readdata,
  // mirror (non-urgent, single-beat writes, byte address)
  input  logic        m_write, input logic [31:0] m_address, input logic [63:0] m_writedata,
  output logic        m_waitrequest,
  // DDRAM
  output logic        d_read, d_write, output logic [28:0] d_address, output logic [7:0] d_burstcount,
  output logic [63:0] d_writedata, output logic [7:0] d_byteenable,
  input  logic        d_busy, d_readdatavalid, input logic [63:0] d_readdata,
  output logic [31:0] st_m_writes, st_m_wait_max
);
  logic owner_m, locked; logic [7:0] wleft;                       // wleft: renderer burst data beats still owed
  logic sel_m;                                                    // this clock's grant: 1 = mirror
  always_comb begin
    if (wleft != 8'd0)      sel_m = 1'b0;                          // rule 2
    else if (locked)        sel_m = owner_m;                       // rule 1
    else                    sel_m = !(r_read || r_write) && m_write;   // rule 3
    d_read       = sel_m ? 1'b0 : r_read;
    d_write      = sel_m ? m_write : r_write;
    d_address    = sel_m ? m_address[31:3] : r_address;
    d_burstcount = sel_m ? 8'd1 : r_burstcount;
    d_writedata  = sel_m ? m_writedata : r_writedata;
    d_byteenable = sel_m ? 8'hFF : r_byteenable;
  end
  assign r_waitrequest   = sel_m || d_busy;
  assign m_waitrequest   = !sel_m || d_busy;
  assign r_readdatavalid = d_readdatavalid;                        // rule 4
  assign r_readdata      = d_readdata;
  logic offered, accepted; assign offered = d_read || d_write; assign accepted = offered && !d_busy;
  logic [31:0] m_wait;
  always_ff @(posedge clk)
    if (rst) begin owner_m <= 1'b0; locked <= 1'b0; wleft <= '0; st_m_writes <= '0; st_m_wait_max <= '0; m_wait <= '0; end
    else begin
      // lock onto the owner of a refused offer, release on acceptance (rule 1); burst beats never lock anew
      if (offered && d_busy && wleft == 8'd0) begin locked <= 1'b1; owner_m <= sel_m; end
      else if (accepted) locked <= 1'b0;
      // renderer write burst tracking (rule 2): the first accepted beat carries the count
      if (accepted && !sel_m && r_write) begin
        if (wleft == 8'd0) wleft <= r_burstcount - 8'd1;
        else wleft <= wleft - 8'd1;
      end
      // census: mirror writes, longest mirror wait
      if (accepted && sel_m) begin st_m_writes <= st_m_writes + 1'b1; m_wait <= '0; end
      else if (m_write) begin m_wait <= m_wait + 1'b1; if (m_wait + 1 > st_m_wait_max) st_m_wait_max <= m_wait + 1; end
    end
endmodule
