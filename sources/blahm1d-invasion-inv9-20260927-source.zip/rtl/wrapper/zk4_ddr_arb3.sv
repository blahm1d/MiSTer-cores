// zk4_ddr_arb3.sv -- the MiSTer DDRAM port shared by THREE Avalon masters (fit B: fabric DCS2):
//   R  the renderer's memsys (zr_ddr_gateway): reads + write bursts up to 255 beats, 29-bit 64-bit-word addresses,
//      several reads outstanding;
//   D  the DCS2 sound-ROM agent: single-beat reads (run time) and writes (ROM store at load), byte addresses. Its
//      ROM-window PAGE FILL now PIPELINES several single-beat reads (up to ~6 outstanding); the in-order tag queue
//      (rule 4) routes them, PROVEN by tb_zk4_ddr_arb3 (pipelined S, max outstanding 6-12, no tag overflow, all
//      mutants killed) interleaved with R bursts + M writes. Boot/cache still issue one D read at a time;
//   M  the status mirror (zk4_status_mirror): single-beat writes only, byte addresses.
// Rules (zk4_ddr_arb, Cruis'n gm1 lessons):
//   1. A command offered to DDRAM stays byte-identical until DDRAM_BUSY drops: a refused offer LOCKS the port to its
//      owner until accepted.
//   2. A renderer write burst is never interleaved: after its first beat is accepted, only its data beats pass.
//   3. Open arbitration: D, then R, then M (D's single beats cost R little; M fills the gaps).
//   4. Reads come back in order: every accepted read pushes {owner, beats} into an in-order tag queue; each
//      readdatavalid beat goes to the head's owner, which pops when its beats are done. Depth (TD=32) covers the
//      gateway's outstanding reads (16 slots) plus D's pipelined fill (~6); st_tag_overflow guards it.
module zk4_ddr_arb3 #(parameter int TAG_AW = 5,
  // inv-buzz (2026-09-26): R_RD_CAP (beats, 0 = off) bounds the renderer READ beats in flight (accepted, data not yet
  // returned -- counted exactly: + burstcount at acceptance, - 1 per r_readdatavalid). Read data returns in order (rule 4),
  // so a DCS read (open-arbitration priority, rule 3) then waits behind at most ~R_RD_CAP renderer beats instead of the
  // gateway's 16 descriptors x 32 beats. While the count exceeds the cap a NEW renderer read is not arbitrated; renderer
  // writes, a burst in flight (rule 2) and a locked refused offer (rule 1) are never held. A first read is always allowed
  // (count 0), so a burst longer than the cap cannot deadlock. 64 beats keep > 5x the ~12-clk DDR read latency in flight.
  // MEASURED (lanes/inv-buzz): with the renderer saturating the port every DCS read waited ~512 clk and Invasion's sound
  // missed its half-buffer deadline (stale replays = the cabinet buzz). Invasion builds only (zk4_top); 0 = unchanged.
  parameter int R_RD_CAP = 0) (
  input  logic        clk, rst,
  // R: renderer (bursts)
  input  logic        r_read, r_write, input logic [28:0] r_address, input logic [7:0] r_burstcount,
  input  logic [63:0] r_writedata, input logic [7:0] r_byteenable,
  output logic        r_waitrequest, r_readdatavalid, output logic [63:0] r_readdata,
  // D: DCS agent (single beats, byte address)
  input  logic        s_read, s_write, input logic [31:0] s_address, input logic [63:0] s_writedata,
  input  logic [7:0]  s_byteenable,
  output logic        s_waitrequest, s_readdatavalid, output logic [63:0] s_readdata,
  // M: mirror (single-beat writes, byte address)
  input  logic        m_write, input logic [31:0] m_address, input logic [63:0] m_writedata,
  output logic        m_waitrequest,
  // DDRAM
  output logic        d_read, d_write, output logic [28:0] d_address, output logic [7:0] d_burstcount,
  output logic [63:0] d_writedata, output logic [7:0] d_byteenable,
  input  logic        d_busy, d_readdatavalid, input logic [63:0] d_readdata,
  output logic [31:0] st_m_writes, st_m_wait_max, st_s_wait_max,
  output logic        st_tag_overflow                           // sticky: a read was accepted with the tag queue full
);
  localparam logic [1:0] O_R = 2'd0, O_S = 2'd1, O_M = 2'd2;
  logic [1:0] sel, owner; logic locked; logic [7:0] wleft;
  logic [12:0] r_rd_out;                                                            // renderer read beats in flight
  wire         r_hold = (R_RD_CAP != 0) && (r_rd_out > 13'(R_RD_CAP));
  always_comb begin
    if (wleft != 8'd0)                sel = O_R;                                     // rule 2
    else if (locked)                  sel = owner;                                   // rule 1
    else if (s_read || s_write)       sel = O_S;                                     // rule 3
    else if (r_write || (r_read && !r_hold)) sel = O_R;                            // (R_RD_CAP)
    else                              sel = O_M;
    case (sel)
      O_S:     begin d_read = s_read; d_write = s_write; d_address = s_address[31:3]; d_burstcount = 8'd1;
                     d_writedata = s_writedata; d_byteenable = s_byteenable; end
      O_M:     begin d_read = 1'b0; d_write = m_write; d_address = m_address[31:3]; d_burstcount = 8'd1;
                     d_writedata = m_writedata; d_byteenable = 8'hFF; end
      default: begin d_read = r_read; d_write = r_write; d_address = r_address; d_burstcount = r_burstcount;
                     d_writedata = r_writedata; d_byteenable = r_byteenable; end
    endcase
  end
  assign r_waitrequest = sel != O_R || d_busy;
  assign s_waitrequest = sel != O_S || d_busy;
  assign m_waitrequest = sel != O_M || d_busy;
  logic offered, accepted; assign offered = d_read || d_write; assign accepted = offered && !d_busy;

  // rule 4: in-order read tags {owner is S, beats}
  localparam int TD = 1 << TAG_AW;
  logic [8:0] tq [TD]; logic [TAG_AW:0] tw, tr; logic [7:0] head_left; logic tq_empty, tq_full;
  assign tq_empty = tw == tr;
  assign tq_full  = (tw[TAG_AW] != tr[TAG_AW]) && (tw[TAG_AW-1:0] == tr[TAG_AW-1:0]);
  logic head_s; logic [7:0] head_n; assign {head_s, head_n} = tq[tr[TAG_AW-1:0]];
  assign r_readdatavalid = d_readdatavalid && !tq_empty && !head_s;
  assign s_readdatavalid = d_readdatavalid && !tq_empty &&  head_s;
  assign r_readdata = d_readdata; assign s_readdata = d_readdata;

  logic [31:0] m_wait, s_wait;
  always_ff @(posedge clk)
    if (rst) begin
      owner <= O_R; locked <= 1'b0; wleft <= '0; tw <= '0; tr <= '0; head_left <= '0; r_rd_out <= '0;
      st_m_writes <= '0; st_m_wait_max <= '0; st_s_wait_max <= '0; m_wait <= '0; s_wait <= '0; st_tag_overflow <= 1'b0;
    end else begin
      if (R_RD_CAP != 0)                                                                           // R_RD_CAP count
        r_rd_out <= r_rd_out + ((accepted && sel == O_R && d_read) ? {5'd0, r_burstcount} : 13'd0)
                             - (r_readdatavalid ? 13'd1 : 13'd0);
      if (offered && d_busy && wleft == 8'd0) begin locked <= 1'b1; owner <= sel; end               // rule 1
      else if (accepted) locked <= 1'b0;
      if (accepted && sel == O_R && r_write) wleft <= (wleft == 8'd0) ? r_burstcount - 8'd1 : wleft - 8'd1;  // rule 2
      if (accepted && d_read) begin                                                                // rule 4: push
        tq[tw[TAG_AW-1:0]] <= {sel == O_S, sel == O_S ? 8'd1 : r_burstcount}; tw <= tw + 1'b1;
        if (tq_full) st_tag_overflow <= 1'b1;
      end
      if (d_readdatavalid && !tq_empty) begin                                                      // rule 4: pop
        if (head_left + 8'd1 == head_n) begin tr <= tr + 1'b1; head_left <= '0; end
        else head_left <= head_left + 1'b1;
      end
      // census
      if (accepted && sel == O_M) begin st_m_writes <= st_m_writes + 1'b1; m_wait <= '0; end
      else if (m_write) begin m_wait <= m_wait + 1'b1; if (m_wait + 1 > st_m_wait_max) st_m_wait_max <= m_wait + 1; end
      if (accepted && sel == O_S) s_wait <= '0;
      else if (s_read || s_write) begin s_wait <= s_wait + 1'b1; if (s_wait + 1 > st_s_wait_max) st_s_wait_max <= s_wait + 1; end
    end
endmodule
