// zk4_audio_gain.sv -- OSD "Audio Gain" between the DCS2 DAC words and the MiSTer AUDIO_L/R pins (zk4-s4).
//
// Why (measured 2026-09-26, H:/temp/zeus/level): our DAC words equal MAME 0.289's dmadac input (AUDIOPATH; boot chime
// peak 983 vs 979), and MAME applies no DCS gain (dmadac m_volume 1.0, dmadac.cpp:55; routes 1.0, midzeus.cpp:1401-1402).
// The quiet output is the GAME's own volume: a fresh CMOS gets the factory setting 40 (CMOS byte 1), sent to the DCS as
// 0x55AA / 0x649B, and the DCS ROM plays attract + fight at peak -24.7 dBFS / RMS -41.9 dBFS (setting 100 = 0xFA:
// peak -1.1 dBFS). A real cabinet makes that up in its analog amp; MiSTer has none, so this is a loudness choice, not a
// behaviour fix. The DAC words themselves (and every DCS gate) are untouched.
//
// Gain code (zk4_emu.sv maps the OSD entry status[11:10] onto it; the OSD default is AUDIO_GAIN_DEFAULT there,
// +12 dB for MK4 and Invasion per user decision 2026-09-26):
//   0: 0 dB (x1, bit-exact MAME level)   1: +6 dB (x2)   2: +12 dB (x4)   3: +18 dB (x8)
// Signed shift left with symmetric-range saturation to [-32768, 32767]. One register stage (glitch-free pins).
`default_nettype none
module zk4_audio_gain (
  input  wire               clk,
  input  wire         [1:0] code,
  input  wire signed [15:0] in_l, in_r,
  output reg  signed [15:0] out_l, out_r
);
  wire [1:0] sh = (code == 2'd0) ? 2'd0 : (code == 2'd1) ? 2'd1 : (code == 2'd2) ? 2'd2 : 2'd3;

  function automatic signed [15:0] gain(input signed [15:0] x, input [1:0] s);
    logic signed [18:0] w;
    begin
      w = $signed({{3{x[15]}}, x}) <<< s;
      if (w > 19'sd32767)       gain = 16'sh7FFF;
      else if (w < -19'sd32768) gain = 16'sh8000;
      else                      gain = w[15:0];
    end
  endfunction

  always_ff @(posedge clk) begin
    out_l <= gain(in_l, sh);
    out_r <= gain(in_r, sh);
  end
endmodule
`default_nettype wire
