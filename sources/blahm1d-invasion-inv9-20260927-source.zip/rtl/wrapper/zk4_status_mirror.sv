// zk4_status_mirror.sv -- publishes the core's status counters to DDR3 so an ARM-side logger can record them while the
// user plays (no screenshots). Forked from the Cruis'n gm1_status_mirror (wrapper/donor, cabinet-proven): the same
// seqlock block, the same Avalon discipline; only the payload is generic (NP words captured at one instant, laid out
// by zk4_top) and the magic / base are MK4's own so a logger can never confuse the two cores.
// Every PERIOD clocks it writes one (NP+2)-word block of 64-bit words, single-beat, byteenable 0xFF, at BASE:
//   word 0      {MAGIC "zk4S", seq}  written FIRST with seq ODD (block being updated)
//   words 1-NP  the payload, captured into a shadow when the block starts (one instant)
//   word NP+1   {MAGIC, seq}         written LAST with seq EVEN (block consistent)
// A reader accepts a block only when word NP+1's seq is even AND word 0's seq == word NP+1's seq - 1 (word 0 keeps the
// odd opener). Avalon: an offered command is held unchanged until waitrequest drops (zk4_ddr_arb relies on it).
// NP = 14 through zk4-r4 (16-word block); 17 from r5 (19-word block: + the bank-1 DDR diagnostic, zk4_top); 38 in r10 and
// 36 in r12 (6-bit index; wedge / page-ownership instruments); 17 again from r13 (the r5-r9 module, 5-bit index: NP <= 30).
module zk4_status_mirror #(
  parameter logic [31:0] BASE   = 32'h30C00000,                   // byte address (DDRAM word = BASE >> 3)
  parameter int          PERIOD = 2_000_000,                      // 40 ms at 50 MHz
  parameter int          NP     = 17                              // payload words
) (
  input  logic        clk, por, enable,
  input  logic [63:0] payload [NP],
  output logic        write, output logic [31:0] address, output logic [63:0] writedata,
  input  logic        waitrequest
);
  localparam logic [31:0] MAGIC = 32'h7A6B3453;                   // "zk4S"
  logic [31:0] tick, seq; logic [4:0] idx; logic busy;
  logic [63:0] s [1:NP];
  always_ff @(posedge clk)
    if (por) begin
      tick <= '0; seq <= '0; idx <= '0; busy <= 1'b0; write <= 1'b0; address <= '0; writedata <= '0;
      for (int j = 1; j <= NP; j++) s[j] <= '0;
    end else if (!busy) begin
      tick <= (tick == 32'(PERIOD - 1)) ? '0 : tick + 1'b1;
      if (tick == 32'(PERIOD - 1) && enable) begin
        for (int j = 1; j <= NP; j++) s[j] <= payload[j - 1];     // one instant
        seq <= seq + 1'b1;                                        // odd
        busy <= 1'b1; idx <= '0;
        write <= 1'b1; address <= BASE; writedata <= {MAGIC, seq + 1'b1};
      end
    end else if (write && !waitrequest) begin
      if (idx == 5'(NP + 1)) begin write <= 1'b0; busy <= 1'b0; end
      else if (idx == 5'(NP)) begin
        idx <= 5'(NP + 1); seq <= seq + 1'b1;                     // even: close the block
        address <= BASE + 32'((NP + 1) * 8); writedata <= {MAGIC, seq + 1'b1};
      end else begin
        idx <= idx + 1'b1;
        address <= BASE + {24'd0, idx + 1'b1, 3'd0};
        writedata <= s[idx + 1'b1];
      end
    end
endmodule
