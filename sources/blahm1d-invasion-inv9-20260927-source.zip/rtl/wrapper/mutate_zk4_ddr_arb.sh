#!/bin/bash
# zk4_ddr_arb mutants: each must FAIL run_zk4_ddr_arb.sh at 60 % busy
#   D1 no lock: a refused offer can be replaced by the other master's command (the gm1 attract freeze)
#   D2 no burst tracking: the mirror can slip between a renderer burst's beats
#   D3 mirror byte address not converted to a 64-bit word address
#   D4 the lock records the wrong owner
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; bad=0
run() { out=$(ZDA_MUT="$2" bash $D/run_zk4_ddr_arb.sh 300000 60 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$1 NOT APPLIED / BUILD FAILED"; bad=1
  elif [ $rc = 0 ]; then echo "$1 SURVIVED"; bad=1
  else echo "$1 killed: $(echo "$out" | grep -m1 -E "ERR|FAIL" | cut -c1-110)"; fi; }
run D1 's/    else if (locked)        sel_m = owner_m;                       \/\/ rule 1/    else if (1'"'"'b0)        sel_m = owner_m;/'
run D2 's/    if (wleft != 8.d0)      sel_m = 1.b0;                          \/\/ rule 2/    if (1'"'"'b0)      sel_m = 1'"'"'b0;/'
run D3 's/    d_address    = sel_m ? m_address\[31:3\] : r_address;/    d_address    = sel_m ? m_address[28:0] : r_address;/'
run D4 's/locked <= 1.b1; owner_m <= sel_m; end/locked <= 1'"'"'b1; owner_m <= !sel_m; end/'
exit $bad
