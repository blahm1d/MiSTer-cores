// tb_zk4_emu_inputs.sv -- EMU-LEVEL input gate for the MK4 core (the RevX lesson: a unit gate below hps_io cannot see
// a wiring defect in the emu; revolutionx sim/tb_revx_emu_mouse.sv is the pattern, its HPS_BUS tasks reused).
// DUT: the real emu top (zk4_emu.sv) with the real sys/hps_io.sv and the whole zk4 core (held in reset: no ROM is
// downloaded, so game_reset stays high -- the input path does not need the CPU). The bench plays the HPS side of
// HPS_BUS as sys_top presents it: io_uio framing, one-clk io_strobe per word, status via command 0x1E, joystick 0 / 1
// via 0x02 / 0x03 (low 16 bits, then high).
// OBSERVED at two points, every stimulus, all four 16-bit ports EXACTLY (so a stray bit fails too):
//   (a) emu ports[0..3]   (b) the I/O ASIC's in_port[0..3] deep in the core (u_emu.core.u_core.u_board.u_io)
// EXPECTED from MAME 0.289 midzeus.cpp INPUT_PORTS_START( mk4 ), transcribed here (not from zk4_emu.sv):
//   DIPS   idle 0xFFFF; blood 0x0200, fatalities 0x0100, test switch 0x0080 (active low = On... see OSD rows below),
//          free play = coinage field 0x003e -> 0x0030
//   SYSTEM coin1 0x0001, coin2 0x0002, start1 0x0004, service mode (Test) 0x0010, start2 0x0020, service1 0x0040,
//          volume down 0x0800, volume up 0x1000
//   IN1    P1 up 0x0001, down 0x0002, left 0x0004, right 0x0008, high punch 0x0010, block 0x0020, high kick 0x0040;
//          P2 the same << 8
//   IN2    P1 low punch 0x0001, low kick 0x0002, run 0x0004; P2 the same << 4
// The user-visible contract that names the buttons is the CONF_STR J1 list (zk4_emu.sv): buttons from joystick bit 4
// in the order High Punch, Block, High Kick, Low Punch, Low Kick, Run, Start, Coin, Test, Service, Vol Down, Vol Up
// (SYSTEM 0x0800 / 0x1000); directions bits
// 0 right, 1 left, 2 down, 3 up (MiSTer convention).
`timescale 1ns/1ps
module tb_zk4_emu_inputs;
    logic clk50 = 1'b0;
    always #10 clk50 = ~clk50;
    wire  [45:0] HPS_BUS;                 // this framework (sys/emu_ports.vh:9): 46 bits; strobe 33, enable 34, fp 35, din 31:16
    logic [15:0] io_din = 16'h0000;
    logic        io_strobe = 1'b0, io_enable = 1'b0;
    assign HPS_BUS[45:38] = 8'd0;
    assign HPS_BUS[35]    = 1'b0;
    assign HPS_BUS[34]    = io_enable;
    assign HPS_BUS[33]    = io_strobe;
    assign HPS_BUS[31:16] = io_din;
    wire  [15:0] SDRAM_DQ;
    wire  [3:0]  ADC_BUS;
    logic        emu_reset = 1'b1;
    emu u_emu (
        .CLK_50M(clk50), .RESET(emu_reset), .HPS_BUS(HPS_BUS),
        .CLK_VIDEO(), .CE_PIXEL(), .VIDEO_ARX(), .VIDEO_ARY(),
        .VGA_R(), .VGA_G(), .VGA_B(), .VGA_HS(), .VGA_VS(), .VGA_DE(), .VGA_F1(), .VGA_SL(),
        .VGA_SCALER(), .VGA_DISABLE(),
        .HDMI_WIDTH(12'd0), .HDMI_HEIGHT(12'd0), .HDMI_FREEZE(), .HDMI_BLACKOUT(), .HDMI_BOB_DEINT(),
        .LED_USER(), .LED_POWER(), .LED_DISK(), .BUTTONS(),
        .CLK_AUDIO(1'b0), .AUDIO_L(), .AUDIO_R(), .AUDIO_S(), .AUDIO_MIX(),
        .ADC_BUS(ADC_BUS),
        .SD_SCK(), .SD_MOSI(), .SD_MISO(1'b0), .SD_CS(), .SD_CD(1'b0),
        .DDRAM_CLK(), .DDRAM_BUSY(1'b0), .DDRAM_BURSTCNT(), .DDRAM_ADDR(), .DDRAM_DOUT(64'd0),
        .DDRAM_DOUT_READY(1'b0), .DDRAM_RD(), .DDRAM_DIN(), .DDRAM_BE(), .DDRAM_WE(),
        .SDRAM_CLK(), .SDRAM_CKE(), .SDRAM_A(), .SDRAM_BA(), .SDRAM_DQ(SDRAM_DQ),
        .SDRAM_DQML(), .SDRAM_DQMH(), .SDRAM_nCS(), .SDRAM_nCAS(), .SDRAM_nRAS(), .SDRAM_nWE(),
        .UART_CTS(1'b0), .UART_RTS(), .UART_RXD(1'b0), .UART_TXD(), .UART_DTR(), .UART_DSR(1'b0),
        .USER_IN(7'h7f), .USER_OUT(), .OSD_STATUS(1'b0));

    // ---------------------------------------------------------------- HPS side (tb_revx_emu_mouse.sv)
    task automatic word(input [15:0] w);
        begin io_din = w; @(negedge clk50); io_strobe = 1'b1; @(negedge clk50); io_strobe = 1'b0; repeat (2) @(negedge clk50); end
    endtask
    task automatic cmd_begin(input [15:0] c);
        begin @(negedge clk50); io_enable = 1'b1; @(negedge clk50); word(c); end
    endtask
    task automatic cmd_end;
        begin @(negedge clk50); io_enable = 1'b0; repeat (12) @(negedge clk50); end
    endtask
    logic [127:0] status = 128'd0;
    task automatic send_status;
        integer k;
        begin cmd_begin(16'h001e); for (k = 0; k < 8; k = k + 1) word(status[k*16 +: 16]); cmd_end(); end
    endtask
    task automatic send_joy(input integer player, input [31:0] j);
        begin cmd_begin(player == 0 ? 16'h0002 : 16'h0003); word(j[15:0]); word(j[31:16]); cmd_end(); end
    endtask

    // ---------------------------------------------------------------- expected (MAME INPUT_PORTS, here)
    logic [15:0] e [4];                           // DIPS, SYSTEM, IN1, IN2
    task automatic idle_expect; begin e[0] = 16'hffff; e[1] = 16'hffff; e[2] = 16'hffff; e[3] = 16'hffff; end endtask
    integer checks = 0, errors = 0;
    task automatic chk_ports(input string what);
        integer k;
        begin
            repeat (8) @(negedge clk50);
            for (k = 0; k < 4; k = k + 1) begin
                checks = checks + 2;
                if (u_emu.ports[k] !== e[k]) begin errors = errors + 1;
                    $display("FAIL %0s: emu ports[%0d] = %04x, MAME %04x", what, k, u_emu.ports[k], e[k]); end
                if (u_emu.core.u_core.u_board.u_io.in_port[k] !== e[k]) begin errors = errors + 1;
                    $display("FAIL %0s: I/O ASIC in_port[%0d] = %04x, MAME %04x", what, k, u_emu.core.u_core.u_board.u_io.in_port[k], e[k]); end
            end
        end
    endtask
    // one MAME control per row: {port, mask} for player 1 and player 2
    typedef struct { string name; int joybit; int port1; logic [15:0] m1; int port2; logic [15:0] m2; } row_t;
    row_t rows [16];
    initial begin
        rows[0]  = '{"right",      0, 2, 16'h0008, 2, 16'h0800};
        rows[1]  = '{"left",       1, 2, 16'h0004, 2, 16'h0400};
        rows[2]  = '{"down",       2, 2, 16'h0002, 2, 16'h0200};
        rows[3]  = '{"up",         3, 2, 16'h0001, 2, 16'h0100};
        rows[4]  = '{"high punch", 4, 2, 16'h0010, 2, 16'h1000};
        rows[5]  = '{"block",      5, 2, 16'h0020, 2, 16'h2000};
        rows[6]  = '{"high kick",  6, 2, 16'h0040, 2, 16'h4000};
        rows[7]  = '{"low punch",  7, 3, 16'h0001, 3, 16'h0010};
        rows[8]  = '{"low kick",   8, 3, 16'h0002, 3, 16'h0020};
        rows[9]  = '{"run",        9, 3, 16'h0004, 3, 16'h0040};
        rows[10] = '{"start",     10, 1, 16'h0004, 1, 16'h0020};
        rows[11] = '{"coin",      11, 1, 16'h0001, 1, 16'h0002};
        rows[12] = '{"test",      12, 1, 16'h0010, 1, 16'h0010};
        rows[13] = '{"service",   13, 1, 16'h0040, 1, 16'h0040};
        rows[14] = '{"vol down",  14, 1, 16'h0800, 1, 16'h0800};   // SYSTEM IPT_VOLUME_DOWN (either pad)
        rows[15] = '{"vol up",    15, 1, 16'h1000, 1, 16'h1000};   // SYSTEM IPT_VOLUME_UP
    end

    initial begin
        integer r, p;
        repeat (20) @(negedge clk50); emu_reset = 1'b0;
        repeat (200) @(negedge clk50);
        send_status(); send_joy(0, 32'd0); send_joy(1, 32'd0);
        idle_expect(); chk_ports("idle");
        for (p = 0; p < 2; p = p + 1)
            for (r = 0; r < 16; r = r + 1) begin
                send_joy(p, 32'd1 << rows[r].joybit);
                idle_expect();
                if (p == 0) e[rows[r].port1] = e[rows[r].port1] & ~rows[r].m1;
                else        e[rows[r].port2] = e[rows[r].port2] & ~rows[r].m2;
                chk_ports($sformatf("P%0d %0s", p + 1, rows[r].name));
                send_joy(p, 32'd0);
            end
        // both players, several at once (no cross-talk)
        send_joy(0, (32'd1 << 3) | (32'd1 << 4) | (32'd1 << 9)); send_joy(1, (32'd1 << 0) | (32'd1 << 8) | (32'd1 << 11));
        idle_expect(); e[2] = 16'hffff & ~16'h0001 & ~16'h0010 & ~16'h0800; e[3] = 16'hffff & ~16'h0004 & ~16'h0020;
        e[1] = 16'hffff & ~16'h0002; chk_ports("both players, mixed");
        send_joy(0, 32'd0); send_joy(1, 32'd0);
        // OSD DIP options (status bits; CONF_STR O1 Blood On/Off, O2 Fatalities On/Off, O3 Free Play Off/On,
        // O4 Test Switch Off/On): MAME DIPS blood 0x0200 = 0 Off, fatalities 0x0100 = 0 Off, test switch 0x0080 = 0 On,
        // free play = coinage 0x0030
        status = 128'd0; status[1] = 1'b1; send_status(); idle_expect(); e[0] = 16'hffff & ~16'h0200; chk_ports("OSD blood off");
        status = 128'd0; status[2] = 1'b1; send_status(); idle_expect(); e[0] = 16'hffff & ~16'h0100; chk_ports("OSD fatalities off");
        status = 128'd0; status[4] = 1'b1; send_status(); idle_expect(); e[0] = 16'hffff & ~16'h0080; chk_ports("OSD test switch on");
        status = 128'd0; status[3] = 1'b1; send_status(); idle_expect(); e[0] = (16'hffff & ~16'h003e) | 16'h0030; chk_ports("OSD free play");
        status = 128'd0; send_status();
        $display("EMU_INPUTS checks %0d errors %0d", checks, errors);
        $display("%0s", errors == 0 ? "PASS" : "FAIL");
        $finish;
    end
    initial begin #50_000_000; $display("FAIL: timeout"); $finish; end
endmodule
