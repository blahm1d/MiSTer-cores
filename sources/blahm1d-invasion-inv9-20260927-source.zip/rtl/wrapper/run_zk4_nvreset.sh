#!/bin/bash
# Gate: tb_zk4_nvreset (zk4_cmos + zk4_ram_reload vs independent models). Verilator 5.032 --timing, WSL. Exit 0 = PASS.
# Mutation hook: ZNV_FILE=<zk4_cmos.sv|zk4_ram_reload.sv> ZNV_MUT='sed expr' -- refuses to run if it did not apply.
set -u
R=/mnt/d/deck/fpga/zeus/zeus1/rtl
B=$(mktemp -d /mnt/h/temp/zeus/nvreset.XXXXXX); cd "$B" || exit 2
cp $R/board/zk4_cmos.sv $R/wrapper/zk4_ram_reload.sv $R/wrapper/tb_zk4_nvreset.sv .
if [ -n "${ZNV_MUT:-}" ]; then
  cp "$ZNV_FILE" orig.sv; sed -i "$ZNV_MUT" "$ZNV_FILE"
  if cmp -s "$ZNV_FILE" orig.sv; then echo "MUTATION DID NOT APPLY"; cd /; rm -rf "$B"; exit 3; fi
fi
verilator --binary --timing -j 8 -Wno-fatal -Wno-lint -Wno-style --top-module tb_zk4_nvreset \
  zk4_cmos.sv zk4_ram_reload.sv tb_zk4_nvreset.sv -o tb > build.log 2>&1 \
  || { grep -m20 -E "%Error" build.log; echo "BUILD FAILED"; cd /; rm -rf "$B"; exit 2; }
./obj_dir/tb > run.log 2>&1; trc=$?
grep -E "FAIL|PASS|NVRESET" run.log | head -30
if [ $trc = 0 ] && grep -qx "PASS" run.log && ! grep -q "^FAIL" run.log; then rc=0; else rc=1; fi
cd /; rm -rf "$B"; exit $rc
