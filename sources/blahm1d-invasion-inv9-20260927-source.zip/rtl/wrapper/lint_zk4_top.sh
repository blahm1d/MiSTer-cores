#!/bin/bash
# Lint (elaborate) the whole zk4_top from zeus1/rtl as it stands (lanes/ddr-fullbe/lint_core.sh without the lane
# overlay). Fails on any %Error or on a PINMISSING / PINNOTFOUND warning (an unconnected or misspelt port).
# usage: wsl bash lint_zk4_top.sh      LINT_DEFS="-DZK4_GAME_INVASION ..." lints a variant (Invasion adds its devices,
#        the gun input + overlay modules and their own lint top zk4_gun_input)
set -u
Z=/mnt/d/deck/fpga/zeus; R=$Z/zeus1/rtl; CPU=$Z/core/rtl/cpu
W=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}")
F="wrapper/donor/c31_sdram_burst.sv wrapper/donor/c31_sdram_backing.sv wrapper/donor/gm1_hdmi_status.sv wrapper/zk4_ddr_arb.sv wrapper/zk4_status_mirror.sv wrapper/zk4_ram_reload.sv wrapper/zk4_sdram.sv wrapper/zk4_loader.sv wrapper/zk4_top.sv tier/c31_page_cache.sv tier/c31_page_cache_sa.sv tier/c31_bus_adapter.sv tier/zk4_memory_p3.sv tier/zk4_memory_fp.sv fp32/fp32_pkg.sv fp32/fp32_units.sv setup/zr_sdp.sv front/zr_front5.sv setup/zr_setup9.sv pixel/zr_pixel10.sv render/zr_fifo.sv render/zr_rfifo.sv render/zr_cmdq.sv render/zr_render5.sv memsys/zr_ddr_gateway.sv memsys/zr_memsys.sv memsys/zr_rsys.sv video/zr_scanout.sv core/zr_host1.sv core/zk4_c32_ctl.sv core/zk4_core.sv board/zk4_pic2.sv board/zk4_ioasic.sv board/zk4_dcs_stub.sv board/zk4_cmos.sv board/zk4_board_io.sv board/zk4_gun.sv core/zk4_int2.sv wrapper/gun/zk4_lightgun_overlay.sv"
C="c31_core.sv c31_ea.sv c31_shift.sv c31_mpyi.sv c31_cond.sv c31_addsubf.sv c31_mpyf.sv c31_negf.sv c31_absf.sv c31_rnd.sv c31_norm.sv c31_fconv.sv c31_int2float.sv c31_float2int.sv"
FS=""; for f in $F; do FS="$FS $R/$f"; done; for f in $C; do FS="$FS $CPU/$f"; done
cd $W; verilator --lint-only -Wall -Wno-fatal -I$CPU -I$R/fp32 -DSYNTHESIS ${LINT_DEFS:-} --top-module zk4_top $FS > lint.log 2>&1
# the emu-side gun input block (Invasion builds) linted as its own top
verilator --lint-only -Wall -Wno-fatal -DSYNTHESIS --top-module zk4_gun_input $R/wrapper/gun/zk4_gun_input.sv $R/wrapper/gun/zk4_lightgun_position.sv >> lint.log 2>&1
grep -E "%Error|PINMISSING|PINNOTFOUND|IMPLICIT|WIDTH.*(zk4_wedge|wd_|dbg)" lint.log | head -30
n=$(grep -cE "%Error|PINMISSING|PINNOTFOUND" lint.log)
# r11: declaration-before-use in the renderer (Verilator resolves forward references; Quartus 17.0 synthesised
# zr_render5's forward-referenced oq_pop UNDRIVEN -- the r10 cabinet wedge). Donor tier / loader files not in scope yet.
D="render/zr_render5.sv render/zr_rfifo.sv render/zr_fifo.sv render/zr_cmdq.sv setup/zr_setup9.sv setup/zr_sdp.sv pixel/zr_pixel10.sv
   front/zr_front5.sv memsys/zr_ddr_gateway.sv memsys/zr_memsys.sv memsys/zr_rsys.sv fp32/fp32_units.sv video/zr_scanout.sv core/zr_host1.sv core/zk4_core.sv
   board/zk4_gun.sv core/zk4_int2.sv wrapper/gun/zk4_gun_input.sv"
(cd $R && python3 render/cons/check_decl_order.py $D) > decl.log 2>&1; grep USE-BEFORE decl.log
nd=$(grep -c USE-BEFORE decl.log); n=$((n + nd))
echo "LINT errors+pin issues+use-before-declare: $n (log $W/lint.log, $W/decl.log)"; [ "$n" = 0 ]
