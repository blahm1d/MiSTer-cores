#!/bin/bash
# zk4_status_mirror gate (unit; the mirror is instantiated in zk4_top only with `define ZK4_DIAG since s7 / inv7 --
# this gate stays runnable for diag builds). usage: wsl bash run_zk4_status_mirror.sh [cycles] [wait%]; ZSM_MUT=sed-expression mutates the RTL
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; B="${ZSCRATCH:-/mnt/h/temp/zeus}/zk4-mirror-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC=$S/zk4_status_mirror.sv
if [ -n "${ZSM_MUT:-}" ]; then sed "$ZSM_MUT" "$SRC" > zk4_status_mirror.sv; cmp -s zk4_status_mirror.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zk4_status_mirror.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zk4_status_mirror -GPERIOD=500 -GNP=${ZNP:-17} -CFLAGS -DZNP=${ZNP:-17} -Wno-fatal -Wno-lint -Wno-style "$SRC" $S/tb_zk4_status_mirror.cpp -o tb > build.log 2>&1 || { tail -20 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
