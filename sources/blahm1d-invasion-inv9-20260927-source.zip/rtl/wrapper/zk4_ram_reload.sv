// zk4_ram_reload.sv -- MAME's midzeus machine_reset RAM copy (midzeus.cpp:236-237) for every reset AFTER the first load:
//   memcpy(m_ram_base, maindata, 0x40000*4); *m_ram_base <<= 1;
// MK4 runs its program out of that RAM, so a reset that skips the copy restarts on whatever the last run left there.
// zk4_loader does the copy once at download; this block repeats it from the SDRAM ROM image (maindata word k lives at
// C32 ROM word 0xA00000+k, zk4_sdram map_word) into main RAM (C32 word k) through the tier's sd_* port, while zk4_top
// holds the game in reset and routes the port here. Single transfers only; the zk4_sdram glue rule is honoured: a
// request is held until sd_ack and then dropped for at least one clock before the next.
// ~512 K single transfers: ~0.15 s at 50 MHz, invisible behind a reset.
module zk4_ram_reload #(
  parameter logic [17:0] LAST  = 18'h3FFFF,          // 0x40000 words (midzeus.cpp:236)
  parameter logic [23:0] ROM_W = 24'hA00000,         // maindata word 0 as a C32 word address
  parameter bit          SHIFT0 = 1'b1               // *m_ram_base <<= 1 (midzeus.cpp:237)
) (
  input  logic        clk, por,
  input  logic        start,                          // one-clock pulse; ignored while busy
  output logic        busy,
  output logic        sd_req, sd_we, output logic [23:0] sd_addr, output logic [31:0] sd_wdata,
  input  logic        sd_ack, input logic [31:0] sd_rdata
);
  typedef enum logic [2:0] {S_IDLE, S_RD, S_RDW, S_GAP1, S_WR, S_WRW, S_GAP2} st_t;
  st_t st; logic [17:0] idx; logic [31:0] data;
  always_ff @(posedge clk)
    if (por) begin
      st <= S_IDLE; busy <= 1'b0; sd_req <= 1'b0; sd_we <= 1'b0; sd_addr <= '0; sd_wdata <= '0; idx <= '0; data <= '0;
    end else case (st)
      S_IDLE: if (start) begin busy <= 1'b1; idx <= '0; st <= S_RD; end
      S_RD:   begin sd_req <= 1'b1; sd_we <= 1'b0; sd_addr <= ROM_W + {6'd0, idx}; st <= S_RDW; end
      S_RDW:  if (sd_ack) begin sd_req <= 1'b0; data <= sd_rdata; st <= S_GAP1; end
      S_GAP1: st <= S_WR;
      S_WR:   begin
                sd_req <= 1'b1; sd_we <= 1'b1; sd_addr <= {6'd0, idx};
                sd_wdata <= (SHIFT0 && idx == 18'd0) ? {data[30:0], 1'b0} : data; st <= S_WRW;
              end
      S_WRW:  if (sd_ack) begin sd_req <= 1'b0; st <= S_GAP2; end
      S_GAP2: if (idx == LAST) begin busy <= 1'b0; st <= S_IDLE; end
              else begin idx <= idx + 1'b1; st <= S_RD; end
      default: st <= S_IDLE;
    endcase
endmodule
