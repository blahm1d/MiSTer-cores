#!/bin/bash
# zk4_status_mirror mutants: each must FAIL run_zk4_status_mirror.sh at 50 % waitrequest
#   S1 closer keeps the odd seq (block never marked consistent)   S2 payload read live per word, not the one-instant shadow
#   S3 word addresses advance by 4 bytes instead of 8             S4 the next word is offered even while still waiting
#   S5 closer written one word early (NP-sized block truncated: the r5 NP=14 -> 17 change must be honoured)
#   S6 word index 4 bits (r13: NP = 17 needs 5 -- the 19-word block must not wrap; r10-r12's NP 36/38 needed 6)
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/wrapper; bad=0
run() { out=$(ZSM_MUT="$2" bash $D/run_zk4_status_mirror.sh 100000 50 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$1 NOT APPLIED / BUILD FAILED"; bad=1
  elif [ $rc = 0 ]; then echo "$1 SURVIVED"; bad=1
  else echo "$1 killed: $(echo "$out" | grep -m1 -E "ERR|FAIL" | cut -c1-100)"; fi; }
run S1 's/        idx <= 5.(NP + 1); seq <= seq + 1.b1;                     \/\/ even: close the block/        idx <= 5'"'"'(NP + 1);/'
run S2 's/        writedata <= s\[idx + 1.b1\];/        writedata <= payload[idx];/'
run S3 's/        address <= BASE + {24.d0, idx + 1.b1, 3.d0};/        address <= BASE + {25'"'"'d0, idx + 1'"'"'b1, 2'"'"'d0};/'
run S4 's/    end else if (write \&\& !waitrequest) begin/    end else if (write) begin/'
run S5 's/      else if (idx == 5.(NP)) begin/      else if (idx == 5'"'"'(NP - 1)) begin/'
run S6 's/  logic \[31:0\] tick, seq; logic \[4:0\] idx; logic busy;/  logic [31:0] tick, seq; logic [3:0] idx; logic busy;/'
exit $bad
