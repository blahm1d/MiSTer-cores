// Gate for zk4_raw_check (the r12 DDRAM read-after-write witness, a module in zk4_top.sv; r12b sizing: N = 2 CAM
// entries, one check in flight, 16-bit folds / timestamps, window-relative addresses). Random Avalon traffic on a small
// address window inside the zk4 DDR window (write bursts 1-4 beats, single-beat reads, 4-beat read bursts, ~5 %
// partial-byte-enable writes, ~5 % accesses outside the window, random waitrequest) against a DDR model whose writes
// become visible WVL clocks after acceptance (0 = in order, what the renderer relies on) and whose reads return in order
// LAT clocks after acceptance; a partial-BE write is dropped (the measured f2sdram behaviour, lanes/cab-r4). The
// testbench keeps its own oracle of what the checker must see and requires, independently of the RTL:
//   counts (checked, mismatches) equal the oracle's; checked > 1000 (coverage)
//   WVL = 0 : mismatches == 0
//   WVL > 0 : mismatches > 0, and the first mismatch's address, age, expected fold and actual data equal the oracle's.
// usage: tb [WVL] [LAT] [busy%] [cycles]
#include "Vzk4_raw_check.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <deque>
#include <map>
#include <vector>
#include <algorithm>
typedef uint64_t u64; typedef uint32_t u32;
static u64 rs = 0x9E3779B97F4A7C15ull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
static u32 fold(u64 d) { return (u32)((d >> 48) ^ (d >> 32) ^ (d >> 16) ^ d) & 0xffff; }
static bool inwin(u64 a) { return (a >> 22) == 0x18; }

int main(int argc, char** argv) {
    const u64 WVL = argc > 1 ? strtoull(argv[1], 0, 0) : 0; const int LAT = argc > 2 ? atoi(argv[2]) : 12;
    const int BUSY = argc > 3 ? atoi(argv[3]) : 20; const u64 CYC = argc > 4 ? strtoull(argv[4], 0, 0) : 400000;
    const int N = 2; const u64 A0 = 0x6100000, AOUT = 0x7100000;
    Verilated::commandArgs(argc, argv);
    Vzk4_raw_check* t = new Vzk4_raw_check;
    std::map<u64, u64> mem;
    struct PW { u64 due, a, d; }; std::deque<PW> pw;
    struct RB { u64 due, d; }; std::deque<RB> rq;
    struct CE { bool v; u64 a; u32 f; u64 ts; }; std::vector<CE> cam(N, {false, 0, 0, 0}); int rp = 0;
    struct PC { u64 beat; u64 a; u32 f; u64 age; }; std::deque<PC> pend;   // oracle's check in flight (max 1)
    u64 o_chk = 0, o_mis = 0; bool o_first = false; PC f_pc{}; u64 f_act = 0;
    u64 clk = 0, iss = 0, ret = 0;
    enum { C_NONE, C_WR, C_RD } cmd = C_NONE; u64 c_addr = 0; unsigned c_bc = 1, c_left = 0; u64 c_d = 0; unsigned c_be = 0xff;
    t->clk = 0; t->rst = 1; t->eval(); for (int i = 0; i < 4; i++) { t->clk = 1; t->eval(); t->clk = 0; t->eval(); } t->rst = 0;
    for (clk = 0; clk < CYC; clk++) {
        while (!pw.empty() && pw.front().due <= clk) { mem[pw.front().a] = pw.front().d; pw.pop_front(); }
        if (cmd == C_NONE) {
            u64 r = rnd() % 100; u64 base = (rnd() % 100 < 5) ? AOUT : A0;
            if (r < 30) { cmd = C_WR; c_addr = base + rnd() % 6; c_bc = 1 + rnd() % 4; c_left = c_bc; }
            else if (r < 60) { cmd = C_RD; c_addr = base + rnd() % 6; c_bc = 1; }
            else if (r < 66) { cmd = C_RD; c_addr = base + rnd() % 6; c_bc = 4; }
            if (cmd == C_WR) { c_d = rnd(); c_be = (rnd() % 100 < 5) ? 0x0f : 0xff; }
        }
        bool busy = (int)(rnd() % 100) < BUSY;
        t->d_busy = busy; t->d_rd = cmd == C_RD; t->d_we = cmd == C_WR;
        t->d_addr = (u32)c_addr; t->d_bc = c_bc; t->d_din = c_d; t->d_be = c_be;
        t->d_rdv = 0; t->d_dout = 0;
        if (!rq.empty() && rq.front().due <= clk) { t->d_rdv = 1; t->d_dout = rq.front().d; }
        t->eval();
        bool popped = false;
        if (t->d_rdv) {
            u64 d = rq.front().d; rq.pop_front();
            if (!pend.empty() && pend.front().beat == (ret & 0xff)) {
                o_chk++; if (fold(d) != pend.front().f) { o_mis++; if (!o_first) { o_first = true; f_pc = pend.front(); f_act = d; } }
                pend.pop_front(); popped = true;
            }
            ret++;
        }
        (void)popped;
        if (!busy && cmd == C_WR) {
            u64 a = (c_left == c_bc) ? c_addr : c_addr + (c_bc - c_left);
            int hit = -1; for (int k = 0; k < N; k++) if (cam[k].v && inwin(a) && cam[k].a == a) hit = k;
            if (c_be == 0xff) {
                if (WVL) pw.push_back({clk + WVL, a, c_d}); else mem[a] = c_d;
                if (inwin(a)) { if (hit >= 0) { cam[hit].f = fold(c_d); cam[hit].ts = clk; } else { cam[rp] = {true, a, fold(c_d), clk}; rp = (rp + 1) % N; } }
            } else if (hit >= 0) cam[hit].v = false;
            if (--c_left == 0) cmd = C_NONE; else { c_d = rnd(); }
        } else if (!busy && cmd == C_RD) {
            for (unsigned k = 0; k < c_bc; k++) { auto it = mem.find(c_addr + k); rq.push_back({std::max<u64>(clk + LAT, rq.empty() ? 0 : rq.back().due + 1), it == mem.end() ? 0 : it->second}); }
            if (c_bc == 1 && inwin(c_addr)) {
                int hit = -1; for (int k = 0; k < N; k++) if (cam[k].v && cam[k].a == c_addr) hit = k;
                if (hit >= 0 && pend.empty()) pend.push_back({iss & 0xff, c_addr, cam[hit].f, (clk - cam[hit].ts) & 0xffff});
            }
            iss += c_bc; cmd = C_NONE;
        }
        t->clk = 1; t->eval(); t->clk = 0; t->eval();
    }
    u64 chk = t->w[0] >> 32, mis = t->w[0] & 0xffffffffull, have = t->w[1] >> 63;
    u64 fage = (t->w[1] >> 44) & 0xffff, fexp = (t->w[1] >> 28) & 0xffff, faddr = t->w[1] & 0x3fffff, fact = t->w[2];
    printf("RAWCHK WVL %llu LAT %d busy %d%%: rtl checked %llu mismatches %llu | oracle checked %llu mismatches %llu\n",
           (unsigned long long)WVL, LAT, BUSY, (unsigned long long)chk, (unsigned long long)mis, (unsigned long long)o_chk, (unsigned long long)o_mis);
    int bad = 0;
    if (chk != o_chk || mis != o_mis) { printf("FAIL: counts differ from the oracle\n"); bad++; }
    if (o_chk < 1000) { printf("FAIL: coverage, only %llu reads checked\n", (unsigned long long)o_chk); bad++; }
    if (WVL == 0 && mis != 0) { printf("FAIL: mismatches on an in-order port\n"); bad++; }
    if (WVL != 0) {
        if (o_mis == 0) { printf("FAIL: the reorder model produced no stale checked read (no coverage)\n"); bad++; }
        else if (!have || faddr != (f_pc.a & 0x3fffff) || fage != f_pc.age || fexp != f_pc.f || fact != f_act) {
            printf("FAIL: first mismatch rtl {addr %llx age %llu exp %04llx act %016llx have %llu} oracle {addr %llx age %llu exp %04x act %016llx}\n",
                   (unsigned long long)faddr, (unsigned long long)fage, (unsigned long long)fexp, (unsigned long long)fact, (unsigned long long)have,
                   (unsigned long long)(f_pc.a & 0x3fffff), (unsigned long long)f_pc.age, f_pc.f, (unsigned long long)f_act); bad++; }
    }
    printf("%s\n", bad ? "FAIL" : "PASS");
    delete t; return bad ? 1 : 0;
}
