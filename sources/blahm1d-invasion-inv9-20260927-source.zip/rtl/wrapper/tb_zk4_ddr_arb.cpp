// zk4_ddr_arb gate: a hostile DDRAM (random BUSY, reads answered in order after a latency) shared by a renderer-like
// master (random reads and write bursts of 1-63 beats, data beats with random GAPS, commands held until accepted) and
// a mirror-like master (single-beat writes, byte addresses, held until accepted). Checked every clock:
//   * slave-side stability: a command or data beat offered while BUSY is identical on the next clock (the gm1 rule)
//   * burst integrity: no mirror write is accepted between a renderer burst's first and last beat
//   * reads: every renderer read beat returns the model's data, in order
//   * end: the DDR image equals the shadow for both regions; every mirror write landed
// usage: tb_zk4_ddr_arb [cycles] [busy%] [seed]
#include "Vzk4_ddr_arb.h"
#include "verilated.h"
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <deque>
#include <vector>
#include <map>
typedef uint64_t u64; typedef uint32_t u32;
static u64 rs = 0x853C49E6748FEA9Bull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }
int main(int argc, char** argv) {
    long N = argc > 1 ? atol(argv[1]) : 300000; int BUSY = argc > 2 ? atoi(argv[2]) : 50; if (argc > 3) rs = strtoull(argv[3], 0, 0) | 1;
    Verilated::commandArgs(argc, argv);
    Vzk4_ddr_arb* t = new Vzk4_ddr_arb;
    const u32 RB = 0x06000000, RN = 4096, MB = 0x30C00000u >> 3, MN = 64;    // renderer / mirror word regions
    std::map<u32, u64> ddr, shadow;                                          // word -> data
    auto rd = [&](std::map<u32, u64>& m, u32 a) { auto it = m.find(a); return it == m.end() ? 0ull : it->second; };
    struct Beat { u64 due, data; }; std::deque<Beat> rq; std::deque<u64> r_expect;
    // renderer state
    bool r_on = false, r_isw = false; u32 r_addr = 0; unsigned r_n = 0, r_sent = 0; u64 r_data = 0; unsigned char r_be = 0xff;
    bool r_gap = false;
    // mirror state
    bool m_on = false; u32 m_word = 0; u64 m_data = 0; long m_done = 0, m_offered = 0;
    const bool M_OFF = getenv("M_OFF") && atoi(getenv("M_OFF"));   // 1 = the no-diag build: mirror port tied off (m_write 0)
    // slave-side stability check
    bool prev_off = false; unsigned p_rd = 0, p_wr = 0; u32 p_addr = 0; unsigned p_bc = 0; u64 p_wd = 0; unsigned p_be = 0;
    long errs = 0, clocks = 0, rbeats = 0, wbursts = 0, rbursts = 0; bool in_rburst = false; unsigned burst_left = 0;
    t->rst = 1; for (int i = 0; i < 4; i++) { t->clk = 0; t->eval(); t->clk = 1; t->eval(); } t->rst = 0;
    for (long c = 0; c < N || r_on || m_on || !rq.empty() || !r_expect.empty(); c++) {
        if (c > N + 200000) { printf("FAIL: no drain\n"); return 1; }
        // new requests
        if (!r_on && c < N && rnd() % 100 < 30) {
            r_on = true; r_isw = rnd() % 2; r_addr = RB + (u32)(rnd() % (RN - 64)); r_n = 1 + rnd() % 63; r_sent = 0;
            r_data = rnd(); r_be = (rnd() % 4) ? 0xff : (unsigned char)(rnd() | 1); r_gap = false;
        }
        if (!M_OFF && !m_on && c < N && rnd() % 100 < 20) { m_on = true; m_word = MB + (u32)(rnd() % MN); m_data = rnd(); m_offered++; }
        // drive (negedge)
        t->clk = 0;
        // a gap between data beats may START only right after a beat was accepted (Avalon: a master holds an offered
        // beat until it is taken); it ends at random
        if (r_gap && rnd() % 100 < 50) r_gap = false;
        t->r_read = r_on && !r_isw && r_sent == 0;
        t->r_write = r_on && r_isw && !r_gap;
        t->r_address = r_addr; t->r_burstcount = r_n; t->r_writedata = r_data; t->r_byteenable = r_be;
        t->m_write = m_on; t->m_address = m_word << 3; t->m_writedata = m_data;
        t->d_busy = (int)(rnd() % 100) < BUSY;
        t->d_readdatavalid = 0;
        if (!rq.empty() && rq.front().due <= (u64)clocks) { t->d_readdatavalid = 1; t->d_readdata = rq.front().data; rq.pop_front(); }
        t->eval();
        // slave-side stability
        bool off = t->d_read || t->d_write;
        if (prev_off && (!off || t->d_read != p_rd || t->d_write != p_wr || t->d_address != p_addr || t->d_burstcount != p_bc ||
                         (t->d_write && (t->d_writedata != p_wd || t->d_byteenable != p_be)))) {
            if (errs++ < 10) printf("ERR clk %ld: offered command changed while BUSY (addr %07X -> %07X, rd %u->%u wr %u->%u)\n",
                                   clocks, p_addr, (u32)t->d_address, p_rd, (unsigned)t->d_read, p_wr, (unsigned)t->d_write);
        }
        prev_off = off && t->d_busy; p_rd = t->d_read; p_wr = t->d_write; p_addr = t->d_address; p_bc = t->d_burstcount;
        p_wd = t->d_writedata; p_be = t->d_byteenable;
        if (t->r_readdatavalid) {
            if (r_expect.empty()) { if (errs++ < 10) printf("ERR: unexpected read data\n"); }
            else { if (t->r_readdata != r_expect.front() && errs++ < 10) printf("ERR clk %ld: read data %016llX want %016llX\n", clocks, (unsigned long long)t->r_readdata, (unsigned long long)r_expect.front()); r_expect.pop_front(); rbeats++; }
        }
        // slave accept
        bool acc = off && !t->d_busy;
        if (acc) {
            u32 a = t->d_address;
            if (t->d_read) {
                u64 due = std::max<u64>(clocks + 12, rq.empty() ? 0 : rq.back().due + 1);
                for (unsigned k = 0; k < t->d_burstcount; k++) { rq.push_back({due + k, rd(ddr, a + k)}); }
                rbursts++;
            } else {
                bool is_m = a >= MB && a < MB + MN;
                if (!is_m) {                                   // renderer beat
                    if (burst_left == 0) { burst_left = t->d_burstcount; in_rburst = true; wbursts++; p_addr = a; }
                }
                if (is_m && in_rburst && errs++ < 10) printf("ERR clk %ld: mirror write inside a renderer burst\n", clocks);
                u32 wa = is_m ? a : (u32)(r_addr + (r_n - burst_left));
                u64 old = rd(ddr, wa), nd = old;
                for (int b = 0; b < 8; b++) if (t->d_byteenable >> b & 1) nd = (nd & ~(0xffull << (8 * b))) | (t->d_writedata & (0xffull << (8 * b)));
                ddr[wa] = nd;
                if (!is_m) { if (--burst_left == 0) in_rburst = false; }
            }
        }
        // master bookkeeping (a master sees its own accept through waitrequest)
        if (t->r_read && !t->r_waitrequest) {
            for (unsigned k = 0; k < r_n; k++) r_expect.push_back(rd(shadow, r_addr + k));
            r_on = false;
        }
        if (t->r_write && !t->r_waitrequest) {
            u32 wa = r_addr + r_sent; u64 old = rd(shadow, wa), nd = old;
            for (int b = 0; b < 8; b++) if (r_be >> b & 1) nd = (nd & ~(0xffull << (8 * b))) | (r_data & (0xffull << (8 * b)));
            shadow[wa] = nd; r_sent++; r_data = rnd();
            if (r_sent == r_n) r_on = false;
            else if (rnd() % 100 < 25) r_gap = true;                      // the next beat is not ready yet
        }
        if (t->m_write && !t->m_waitrequest) { shadow[m_word] = m_data; m_on = false; m_done++; }
        t->eval(); t->clk = 1; t->eval(); clocks++;
    }
    long diff = 0;
    for (auto& kv : shadow) if (rd(ddr, kv.first) != kv.second) diff++;
    for (auto& kv : ddr) if (rd(shadow, kv.first) != kv.second) diff++;
    printf("DDR_ARB clocks %ld: renderer read bursts %ld (%ld beats checked), write bursts %ld; mirror writes %ld/%ld (arbiter count %u, longest wait %u clk); image words differing %ld\n",
           clocks, rbursts, rbeats, wbursts, m_done, m_offered, t->st_m_writes, t->st_m_wait_max, diff);
    bool pass = errs == 0 && diff == 0 && m_done == m_offered && (M_OFF ? t->st_m_writes == 0 : m_done > 100) && wbursts > 100 && rbeats > 1000;
    printf("%s (busy %d%%)\n", pass ? "PASS" : "FAIL", BUSY);
    delete t; return pass ? 0 : 1;
}
