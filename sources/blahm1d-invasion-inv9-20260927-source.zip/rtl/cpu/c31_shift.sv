// SPDX-License-Identifier: BSD-3-Clause
// TMS320C31 barrel shifter: ASH (arithmetic) and LSH (logical).
//
// Blind transcription of the pinned MAME macros:
//   ipp = .../tms320c3x/320c3x_ops.ipp
//   - #define ASH(dreg,src,count) ................ ipp:1745-1783
//   - #define LSH(dreg,src,count) ................ ipp:2128-2164
//   - util::sext(count,7) (7-bit signed count) ... ipp:1748, c31.cpp:11-14
//
// The 3-operand forms (ASH3/LSH3, ipp:3356-3388 etc.) reuse the SAME macro;
// only operand routing differs (src and count come from two operands, dest
// is a third), so this combinational unit serves both the 2- and 3-operand
// forms - the caller selects src/count.
//
// count7 is the low 7 bits of the count operand (the macro only looks at
// util::sext(count,7)). result is written to the destination unconditionally;
// flags (N,Z,C; V/UF cleared) update only when the destination is R0-R7
// (dreg_lt8), matching "if (dreg < 8)". For dreg>=8 the core owns any
// update_special side effect; this unit leaves ST unchanged there.
//
// REGOUT selects a registered (1-cycle) output stage.

module c31_shift #(
    parameter bit REGOUT = 1'b0
) (
    input  logic        clk,
    input  logic        is_ash,     // 1 = ASH (arithmetic), 0 = LSH (logical)
    input  logic        dreg_lt8,   // destination is R0-R7 -> update flags
    input  logic [31:0] src,
    input  logic [6:0]  count7,     // low 7 bits of the count operand
    input  logic [15:0] st_in,
    output logic [31:0] result,
    output logic [15:0] st_out
);
    localparam logic [15:0] CFLAG = 16'h0001;
    localparam logic [15:0] VFLAG = 16'h0002;
    localparam logic [15:0] ZFLAG = 16'h0004;
    localparam logic [15:0] NFLAG = 16'h0008;
    localparam logic [15:0] UFFLAG= 16'h0010;
    localparam logic [15:0] CLR_NZCVUF = NFLAG | ZFLAG | VFLAG | CFLAG | UFFLAG; // 0x1F

    logic signed [7:0] sc;   // util::sext(count,7): -64..63
    logic [31:0] res_c;
    logic        carry_c;
    logic [5:0]  amt;        // magnitude of a right shift
    logic [4:0]  ridx, lidx; // bit indices for carry extraction

`ifndef C31_SHIFT_3BARREL
    // sound-area: ONE 34-bit arithmetic right barrel serves all three shifts and both carry extractions (was: arithmetic
    // right + logical right + left barrels and two 32:1 carry muxes). Right shifts shift {fill, src, 0} by k = min(-sc,
    // 32); a left shift is the bit-reverse of a zero-filled right shift of rev(src) by k = min(sc, 32). The bit shifted
    // out last lands in position 0: src[k-1] (right, = ridx) or src[32-k] (left, = lidx). k = 32 gives all-fill with
    // carry src[31] (right) / src[0] (left). Counts past 32 with no carry update (LSH right, any left) force carry 0.
    // Bit-identical to the three-barrel form (C31_SHIFT_3BARREL) over every count: lanes/sound-area/gates/c31_equiv.
    always_comb begin
        logic [31:0] in, rv;
        logic signed [33:0] sh;
        logic [5:0] k;
        logic fill;
        sc   = {count7[6], count7};
        amt  = 6'd0; ridx = 5'd0; lidx = 5'd0;
        for (int i = 0; i < 32; i++) rv[i] = src[31 - i];
        in   = (sc < 0) ? src : rv;
        fill = (sc < 0) && is_ash && src[31];
        if (sc < 0) k = (sc < -8'sd32) ? 6'd32 : 6'(-sc);
        else        k = (sc >  8'sd32) ? 6'd32 : 6'(sc);
        sh   = $signed({fill, in, 1'b0}) >>> k;
        if (sc < 0) res_c = sh[32:1];
        else for (int i = 0; i < 32; i++) res_c[i] = sh[32 - i];
        carry_c = ((sc < -8'sd32 && !is_ash) || sc > 8'sd32) ? 1'b0 : sh[0];
    end
`else
    always_comb begin
        sc      = {count7[6], count7};    // sign-extend 7 -> 8 bits
        res_c   = 32'd0;
        carry_c = 1'b0;
        // Defaults keep this block purely combinational for Quartus (Error 10166, 2026-09-15 unit fit):
        // amt, ridx and lidx are read only on the paths that assign them below, so behaviour is unchanged.
        amt     = 6'd0;
        ridx    = 5'd0;
        lidx    = 5'd0;

        // ---- result ----
        if (sc < 0) begin
            amt = 6'(-sc);                // 1..64; 64 truncates to 0 but amt is only read for sc >= -32
            if (is_ash) begin
                if (sc >= -8'sd31) res_c = $signed(src) >>> amt[4:0]; // arith, 1..31
                else               res_c = $signed(src) >>> 5'd31;    // sign fill
            end else begin
                if (sc >= -8'sd31) res_c = src >> amt[4:0];           // logical, 1..31
                else               res_c = 32'd0;
            end
        end else begin
            if (sc <= 8'sd31) res_c = src << sc[4:0];
            else              res_c = 32'd0;
        end

        // ---- carry (last bit shifted out) ----
        if (sc < 0) begin
            if (sc >= -8'sd32) begin
                ridx    = 5'(amt - 6'd1); // (-sc)-1, in 0..31
                carry_c = src[ridx];
            end else if (is_ash) begin
                carry_c = src[31];        // sc < -32, ASH replicates sign
            end                            // LSH: no carry update (stays 0)
        end else if (sc > 0) begin
            if (sc <= 8'sd32) begin
                lidx    = 5'(6'd32 - sc); // 32-count, in 0..31
                carry_c = src[lidx];
            end                            // count>32: no carry update (stays 0)
        end
    end
`endif

    logic [15:0] st_c;
    always_comb begin
        if (dreg_lt8)
            st_c = (st_in & ~CLR_NZCVUF)
                 | (res_c[31] ? NFLAG : 16'd0)
                 | ((res_c == 32'd0) ? ZFLAG : 16'd0)
                 | (carry_c ? CFLAG : 16'd0);
        else
            st_c = st_in;
    end

    generate if (REGOUT) begin : g_reg
        always_ff @(posedge clk) begin
            result <= res_c;
            st_out <= st_c;
        end
    end else begin : g_comb
        assign result = res_c;
        assign st_out = st_c;
    end endgenerate
endmodule
