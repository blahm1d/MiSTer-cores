// Gate for zr_pixel: replay zr1's R4 command stream (--pixtap) through the RTL pixel pipe from the seeded frame buffer;
// the testbench is the memory (waveram 0 textures/palettes, waveram 1 frame buffer) and performs CLR itself (the clear
// is not the pixel pipe's job). Every FRM point: waveram 1 vs MAME's dump, word-exact. The stream alone reproduces
// MAME (pix_replay), so any difference is the RTL's.
#include "Vzr_pixel.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <zlib.h>

typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8;
static std::vector<u8> read_gz(const std::string& p) {
    std::vector<u8> out; gzFile f = gzopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    u8 buf[1 << 16]; int n; while ((n = gzread(f, buf, sizeof buf)) > 0) out.insert(out.end(), buf, buf + n); gzclose(f); return out;
}
static std::vector<u8> read_file(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); std::vector<u8> v(n); if (fread(v.data(), 1, n, f) != (size_t)n) exit(2); fclose(f); return v;
}

int main(int argc, char** argv) {
    if (argc < 3) { printf("usage: tb_zr_pixel <render-evidence-dir> <pix.bin> [max-frames]\n"); return 2; }
    std::string ev = argv[1]; int maxf = argc > 3 ? atoi(argv[3]) : 1 << 30;
    std::vector<u8> w0 = read_gz(ev + "/seed_item_0_m_waveram_0_.bin.gz"), w1 = read_gz(ev + "/seed_item_0_m_waveram_1_.bin.gz");
    std::vector<u8> regs = read_file(ev + "/seed_zeus1_regs.bin"); u32 reg84; memcpy(&reg84, &regs[0x84 * 4], 4);
    u32 rb = (reg84 & 0x1ff) * 512 * 8;   // w1_expanded(reg84 << 16): block ((reg84 << 16) >> 16) % 512 * 512, 8 bytes each
    std::vector<u8> raw = read_file(argv[2]); const u32* w = (const u32*)raw.data(); size_t n = raw.size() / 4, i = 0;
    Verilated::commandArgs(argc, argv);
    Vzr_pixel* t = new Vzr_pixel;
    bool ack_last = false; unsigned long long clocks = 0, oob = 0, exts = 0, reqs = 0;
    auto tick = [&]() {
        t->clk = 0; t->eval();
        // memory: service the held request once, then drop ack for a cycle (single outstanding, in order)
        t->m_ack = 0;
        if (t->m_req && !ack_last) {
            u32 a = t->m_addr; reqs++;
            switch (t->m_kind) {
            case 0: if (a < w0.size()) t->m_rdata = w0[a]; else { t->m_rdata = 0; oob++; } break;
            case 1: if (a + 1 < w0.size()) { u16 v; memcpy(&v, &w0[a], 2); t->m_rdata = v; } else { t->m_rdata = 0; oob++; } break;
            case 2: if (a + 1 < w1.size()) { u16 v; memcpy(&v, &w1[a], 2); t->m_rdata = v; } else { t->m_rdata = 0; oob++; } break;
            case 3: if (a + 1 < w1.size()) { u16 v = t->m_wdata; memcpy(&w1[a], &v, 2); } else oob++; break;
            }
            t->m_ack = 1;
        }
        ack_last = t->m_ack;
        t->eval(); t->clk = 1; t->eval(); clocks++;
    };
    t->rst = 1; t->ext_valid = 0; tick(); tick(); t->rst = 0; tick();
    u32 ob[14] = {0}; int ok = 0, bad = 0, frames = 0;
    while (i < n && frames < maxf) {
        u32 tag = w[i];
        if (tag == 0x52423031) { rb = w[i + 1]; i += 2; }
        else if (tag == 0x434C5231) {   // CLR: plot_depth(y, x, 0, 0x7fff) over the clip rect at the render base
            int x0 = (int)w[i + 1], x1 = (int)w[i + 2], y0 = (int)w[i + 3], y1 = (int)w[i + 4];
            for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) {
                u32 wd = ((u32)y << 10) | ((x & 0x1fe) << 1) | (x & 1); u16 z = 0, d = 0x7fff;
                memcpy(&w1[rb + 2 * wd], &z, 2); memcpy(&w1[rb + 2 * (wd | 2)], &d, 2);
            }
            i += 5;
        } else if (tag == 0x4F424A31) { memcpy(ob, &w[i], 14 * 4); i += 14; }
        else if (tag == 0x45585431) {
            t->scan = (int32_t)w[i + 1]; t->startx = (int16_t)(w[i + 2] & 0xffff); t->stopx = (int16_t)(w[i + 2] >> 16);
            for (int p = 0; p < 4; p++) { t->p_start[p] = w[i + 3 + 2 * p]; t->p_dpdx[p] = w[i + 4 + 2 * p]; }
            t->o_ctrl = ob[1]; t->o_solid = ob[2]; t->o_zoff = (int16_t)ob[3]; t->o_trans = ob[4]; t->o_texw = ob[5]; t->o_voff = ob[6];
            t->o_alpha = ob[7]; t->o_blend = ob[8]; t->o_dtest = ob[9]; t->o_dwrite = ob[10]; t->o_texfmt = ob[11];
            t->o_texbase = ob[12]; t->o_palbase = ob[13]; t->rb_base = rb;
            t->ext_valid = 1; tick(); t->ext_valid = 0;
            long guard = 0; while (t->busy) { tick(); if (++guard > 10000000) { printf("FAIL: hung at extent %llu\n", exts); return 1; } }
            exts++; i += 11;
        } else if (tag == 0x46524D31) {
            int fr = (int)w[i + 1]; i += 2; frames++;
            char nm[512]; snprintf(nm, sizeof nm, "%s/frame_%05d_0_m_waveram_1_.bin.gz", ev.c_str(), fr);
            std::vector<u8> m = read_gz(nm);
            unsigned long long d = 0, first = ~0ull;
            for (u32 k = 0; k < w1.size() / 2; k++) { u16 a, b; memcpy(&a, &w1[2 * k], 2); memcpy(&b, &m[2 * k], 2); if (a != b) { d++; if (first == ~0ull) first = k; } }
            if (d == 0) ok++; else bad++;
            if (d) { u16 a, b; memcpy(&a, &w1[2 * first], 2); memcpy(&b, &m[2 * first], 2);
                     printf("frame %d: DIFFERS in %llu words; first word %llu: rtl %04X MAME %04X\n", fr, d, first, a, b); }
            else printf("frame %d: IDENTICAL\n", fr);
        } else { printf("FAIL: bad tag %08X\n", tag); return 2; }
    }
    printf("SUMMARY extents %llu memory requests %llu out-of-range %llu clocks %llu\n", exts, reqs, oob, clocks);
    printf("%s: %d of %d frames bit-exact vs MAME waveram 1\n", (bad || !ok) ? "FAIL" : "PASS", ok, ok + bad);
    delete t; return (bad || !ok) ? 1 : 0;
}
