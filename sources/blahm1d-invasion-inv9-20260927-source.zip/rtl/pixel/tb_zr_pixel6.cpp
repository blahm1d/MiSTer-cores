// Gate for zr_pixel6: zr1's --pixtap stream (RB / CLR / OBJ / EXT / FRM) replayed through the RTL from the seeded
// frame buffer. The testbench is the memory: waveram 0 line reads (latency W0LAT), posted colour writes (optionally
// back-pressured), colour reads (latency CRLAT). Every FRM:
//   * colour: every pixel word of waveram 1 (both buffers) vs MAME's dump, word-exact
//   * depth : the RENDER buffer's depth (on chip, read over the debug port) vs MAME's depth words of that buffer
//   * the other buffer's depth words are not compared: on-chip depth holds only the render buffer, and the gate
//     ENFORCES the reason that is sound -- no extent may draw into a render base before that frame's clear (otherwise
//     depth from two frames ago would be read, which the design does not keep). A violation fails the run.
#include "Vzr_pixel6.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <zlib.h>

typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8;
static std::vector<u8> read_gz(const std::string& p) {
    std::vector<u8> out; gzFile f = gzopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    u8 buf[1 << 16]; int n; while ((n = gzread(f, buf, sizeof buf)) > 0) out.insert(out.end(), buf, buf + n); gzclose(f); return out;
}
static std::vector<u8> read_file(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); std::vector<u8> v(n); if (fread(v.data(), 1, n, f) != (size_t)n) exit(2); fclose(f); return v;
}
static uint64_t rs = 0x243F6A8885A308D3ull; static uint64_t rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

int main(int argc, char** argv) {
    if (argc < 3) { printf("usage: tb_zr_pixel6 <render-evidence-dir> <pix.bin> [max-frames] [w0lat] [crlat] [cw_backpressure%%]\n"); return 2; }
    std::string ev = argv[1]; int maxf = argc > 3 ? atoi(argv[3]) : 1 << 30;
    int W0LAT = argc > 4 ? atoi(argv[4]) : 8, CRLAT = argc > 5 ? atoi(argv[5]) : 8, CWBP = argc > 6 ? atoi(argv[6]) : 0;
    std::vector<u8> w0 = read_gz(ev + "/seed_item_0_m_waveram_0_.bin.gz"), w1 = read_gz(ev + "/seed_item_0_m_waveram_1_.bin.gz");
    std::vector<u8> regs = read_file(ev + "/seed_zeus1_regs.bin"); u32 reg84; memcpy(&reg84, &regs[0x84 * 4], 4);
    u32 rb = (reg84 & 0x1ff) * 512 * 8;
    std::vector<u8> raw = read_file(argv[2]); const u32* w = (const u32*)raw.data(); size_t n = raw.size() / 4, i = 0;
    Verilated::commandArgs(argc, argv);
    Vzr_pixel6* t = new Vzr_pixel6;
    int w0_cnt = -1, cr_cnt = -1; unsigned long long clocks = 0; u16 cr_snap = 0;
    // colour reads sample memory when the request is ISSUED (a write still posted at that moment is not seen): the
    // strict model -- the design itself must order a destination read after earlier writes to the same pixel
    auto tick = [&]() {
        t->clk = 0; t->eval();
        // w0 line channel: fixed latency, in order, one outstanding
        t->w0_ack = 0;
        if (t->w0_req) {
            if (w0_cnt < 0) w0_cnt = W0LAT;
            if (w0_cnt == 0) {
                u32 a = t->w0_line * 8u; uint64_t d = 0;
                if (a + 8 <= w0.size()) memcpy(&d, &w0[a], 8); else { printf("FAIL: w0 line out of range %08X\n", a); exit(1); }
                t->w0_data = d; t->w0_ack = 1; w0_cnt = -2;                   // -2: wait for the request to drop
            } else if (w0_cnt > 0) w0_cnt--;
        } else w0_cnt = -1;
        // colour read
        t->cr_ack = 0;
        if (t->cr_req) {
            if (cr_cnt < 0) { cr_cnt = CRLAT; memcpy(&cr_snap, &w1[t->cr_addr], 2); }
            if (cr_cnt == 0) { t->cr_data = cr_snap; t->cr_ack = 1; cr_cnt = -2; }
            else if (cr_cnt > 0) cr_cnt--;
        } else cr_cnt = -1;
        // posted colour writes (applied on acceptance)
        t->cw_ready = (CWBP == 0) || (int)(rnd() % 100) >= CWBP;
        if (t->cw_valid && t->cw_ready) {   // 32-bit word (pixel pair), 16-bit lane mask
            if ((t->cw_addr & 3) || t->cw_addr + 4 > w1.size()) { printf("FAIL: cw address %08X\n", t->cw_addr); exit(1); }
            u16 lo = t->cw_data & 0xffff, hi = t->cw_data >> 16;
            if (t->cw_mask & 1) memcpy(&w1[t->cw_addr], &lo, 2);
            if (t->cw_mask & 2) memcpy(&w1[t->cw_addr + 2], &hi, 2);
        }
        t->eval(); t->clk = 1; t->eval(); clocks++;
    };
    t->rst = 1; t->ext_valid = 0; t->clr_valid = 0; tick(); tick(); t->rst = 0; tick();
    u32 ob[14] = {0}; int ok = 0, bad = 0, frames = 0; bool cleared = false; unsigned long long exts = 0, excluded = 0;
    auto wait_idle = [&]() { long g = 0; while (!t->idle) { tick(); if (++g > 50000000) { printf("FAIL: never idle\n"); exit(1); } } };
    while (i < n && frames < maxf) {
        u32 tag = w[i];
        if (tag == 0x52423031) { wait_idle(); if (w[i + 1] != rb) cleared = false; rb = w[i + 1]; i += 2; }
        else if (tag == 0x434C5231) {
            if (w[i + 1] != 0 || w[i + 2] != 399 || w[i + 3] != 0 || w[i + 4] != 255) { printf("FAIL: clip rect is not 400x256 (on-chip depth geometry)\n"); return 1; }
            t->rb_base = rb; t->clr_valid = 1;
            long g = 0; while (!t->clr_ready) { tick(); if (++g > 50000000) { printf("FAIL: clear never accepted\n"); return 1; } }
            tick(); t->clr_valid = 0; cleared = true; i += 5;
        } else if (tag == 0x4F424A31) { memcpy(ob, &w[i], 14 * 4); i += 14; }
        else if (tag == 0x45585431) {
            int16_t sx = (int16_t)(w[i + 2] & 0xffff), ex = (int16_t)(w[i + 2] >> 16);
            if (sx < ex && !cleared) { printf("FAIL: an extent draws into render base %08X before its frame's clear -- on-chip depth unsound\n", rb); return 1; }
            t->scan = (int32_t)w[i + 1]; t->startx = sx; t->stopx = ex;
            for (int p = 0; p < 4; p++) { t->p_start[p] = w[i + 3 + 2 * p]; t->p_dpdx[p] = w[i + 4 + 2 * p]; }
            t->o_ctrl = ob[1]; t->o_solid = ob[2]; t->o_zoff = (int16_t)ob[3]; t->o_trans = ob[4]; t->o_texw = ob[5]; t->o_voff = ob[6];
            t->o_alpha = ob[7]; t->o_blend = ob[8]; t->o_dtest = ob[9]; t->o_dwrite = ob[10]; t->o_texfmt = ob[11];
            t->o_texbase = ob[12]; t->o_palbase = ob[13]; t->rb_base = rb;
            t->ext_valid = 1;
            long g = 0; while (!t->ext_ready) { tick(); if (++g > 50000000) { printf("FAIL: extent never accepted\n"); return 1; } }
            tick(); t->ext_valid = 0; exts++; i += 11;
        } else if (tag == 0x46524D31) {
            int fr = (int)w[i + 1]; i += 2; frames++;
            wait_idle();
            char nm[512]; snprintf(nm, sizeof nm, "%s/frame_%05d_0_m_waveram_1_.bin.gz", ev.c_str(), fr);
            std::vector<u8> m = read_gz(nm);
            unsigned long long dcol = 0, ddep = 0, first = ~0ull;
            for (u32 k = 0; k < w1.size() / 2; k++) {
                if (k & 2) continue;                                   // depth words handled below
                u16 a, b; memcpy(&a, &w1[2 * k], 2); memcpy(&b, &m[2 * k], 2);
                if (a != b) { dcol++; if (first == ~0ull) first = k; }
            }
            // render buffer depth: on chip, index y*400 + x
            for (u32 yy = 0; yy < 256; yy++) for (u32 xx = 0; xx < 400; xx++) {
                t->dbg_daddr = yy * 400 + xx; tick(); t->clk = 0; t->eval();
                u16 dv = t->dbg_ddata;
                u32 word = (rb / 2) + ((yy << 10) | ((xx & 0x1fe) << 1) | (xx & 1) | 2);
                u16 mv; memcpy(&mv, &m[2 * word], 2);
                if (dv != mv) { ddep++; if (ddep < 4) printf("  depth y %u x %u: rtl %04X MAME %04X\n", yy, xx, dv, mv); }
            }
            excluded += 400 * 256;                                     // the other buffer's depth words
            if (dcol == 0 && ddep == 0) ok++; else bad++;
            printf("frame %d: colour %s (%llu words differ%s), render-buffer depth %s (%llu differ)\n", fr, dcol ? "DIFFERS" : "IDENTICAL", dcol,
                   dcol ? "" : "", ddep ? "DIFFERS" : "IDENTICAL", ddep);
            if (dcol) { u16 a, b; memcpy(&a, &w1[2 * first], 2); memcpy(&b, &m[2 * first], 2); printf("  first colour word %llu: rtl %04X MAME %04X\n", first, a, b); }
        } else { printf("FAIL: bad tag %08X\n", tag); return 2; }
    }
    printf("SUMMARY extents %llu pixels written %u miss lines %u palette loads %u stall clocks %u clocks %llu (w0 latency %d, cr latency %d, cw backpressure %d%%)\n",
           exts, t->st_pixels, t->st_miss_lines, t->st_pal_loads, t->st_stall_clocks, clocks, W0LAT, CRLAT, CWBP);
    printf("%s: %d of %d frames bit-exact vs MAME (colour both buffers + render-buffer depth)\n", (bad || !ok) ? "FAIL" : "PASS", ok, ok + bad);
    delete t; return (bad || !ok) ? 1 : 0;
}
