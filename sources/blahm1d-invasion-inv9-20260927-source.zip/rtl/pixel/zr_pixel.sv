// zr_pixel.sv -- Zeus 1 pixel pipe v1 (functional, one pixel at a time). Lane zeus/zeus1/rtl/pixel, stage R4.
//
// Transcribed from MAME master 61c79406 (copies in zeus/references/mame-master): midzeus_v.cpp render_poly
// (:1235-1440), texel fetch (:201-224), frame-buffer word layout (:102-111); rgbutil.cpp:168-190 bilinear_filter (the
// x86-64 SSE2 path) reduced to integers per channel X in {R, G, B}:
//     top = c01*u + c00*(256-u),  bot = c11*u + c10*(256-u),  X = ((bot >> 1)*v + (top >> 1)*(256-v)) >> 15
// (slli 15 + max_epi16 against srli 1 leaves bot>>1 in the low and top>>1 in the high 16-bit half; madd with
// {v, 256-v}; srli 15; the saturating packs never clip since the maximum is 255).
//
// One extent at a time (ext_valid/ext_ready) with the object state it belongs to. Memory is abstract, in order, one
// request outstanding: tex (waveram 0 byte), pal (waveram 0 16-bit word, palbase-relative index), fb (waveram 1 16-bit
// word, read or write). v1 is the ORDER reference for the pipelined v2.
module zr_pixel (
  input  logic        clk,
  input  logic        rst,
  // extent (poly.h extent_t, params as float bits) + object state (mz_poly_extra_data)
  input  logic        ext_valid,
  output logic        ext_ready,
  input  logic signed [31:0] scan,
  input  logic signed [15:0] startx, stopx,
  input  logic [31:0] p_start [4], p_dpdx [4],
  input  logic [31:0] o_ctrl, o_alpha, o_blend,
  input  logic [15:0] o_solid, o_trans, o_texw, o_voff,
  input  logic signed [15:0] o_zoff,
  input  logic        o_dtest, o_dwrite,
  input  logic [2:0]  o_texfmt,                   // 1 4bit 4x2, 2 8bit 4x2, 3 4bit 2x2, 4 8bit 2x2, 0 none
  input  logic [31:0] o_texbase, o_palbase,       // waveram 0 byte offsets
  input  logic [31:0] rb_base,                    // render base, waveram 1 byte offset
  // memory
  output logic        m_req,
  output logic [1:0]  m_kind,                     // 0 tex byte, 1 pal word, 2 fb read word, 3 fb write word
  output logic [31:0] m_addr,                     // tex: byte offset; pal: byte offset; fb: byte offset
  output logic [15:0] m_wdata,
  input  logic        m_ack,
  input  logic [15:0] m_rdata,
  output logic        busy
);
  import fp32_pkg::*;
  localparam logic [31:0] OPQ1 = 32'h00000000, OPQ2 = 32'h4b23cb00, OPQ3 = 32'h4b23dd00, OPQ4 = 32'h00004800,
                          OPQ5 = 32'hdd23dd00, ADD1 = 32'h40b68800, ADD2 = 32'hc9b78800, MUL1 = 32'h4093c800;

  typedef enum logic [3:0] { S_IDLE, S_PIX, S_DEPTH, S_TEX, S_PAL, S_DST, S_WPIX, S_WDEPTH, S_NEXT } st_t;
  st_t st;

  logic signed [31:0] curz, curu, curv, curi, dz, du, dv, di, y;
  logic [31:0] x, xend;
  logic [31:0] ctrl, alpha, blend, texbase, palbase, rb;
  logic [15:0] solid, trans, texw, voff; logic signed [15:0] zoff;
  logic dtest, dwrite; logic [2:0] tfmt;
  logic [15:0] dcur;
  logic signed [31:0] depth;
  logic [1:0]  k;                                  // texel / palette index 0..3
  logic [7:0]  tex [4];
  logic [15:0] pal [4];
  logic [15:0] dst;
  logic [15:0] outpix;

  // frame-buffer byte offsets (:102-111): word = (y << 10) | ((x & 0x1fe) << 1) | (x & 1); depth = word | 2
  function automatic logic [31:0] pixw(input logic signed [31:0] yy, input logic [31:0] xx);
    return (32'(yy) << 10) | ((xx & 32'h1fe) << 1) | (xx & 32'h1);
  endfunction

  // C integer division truncates toward zero
  function automatic logic signed [31:0] sdiv(input logic signed [31:0] a, input int sh);
    return (a < 0) ? -((-a) >>> sh) : (a >>> sh);
  endfunction
  // texel byte offset (:201-224), int arithmetic, result as uint32
  function automatic logic [31:0] texoff(input logic [2:0] f, input logic signed [31:0] ty, input logic signed [31:0] tx, input logic signed [31:0] w);
    case (f)
      3'd1, 3'd2: return 32'(sdiv(ty, 1) * (w * 2) + ((f == 3'd1 ? sdiv(tx, 3) : sdiv(tx, 2)) <<< 3) + ((ty & 1) <<< 2) + (f == 3'd1 ? (sdiv(tx, 1) & 3) : (tx & 3)));
      default:    return 32'(sdiv(ty, 2) * (w * 4) + ((f == 3'd3 ? sdiv(tx, 2) : sdiv(tx, 1)) <<< 3) + ((ty & 3) <<< 1) + (f == 3'd3 ? (sdiv(tx, 1) & 1) : (tx & 1)));
    endcase
  endfunction

  function automatic logic [7:0] p5(input logic [4:0] b); return {b, b[4:2]}; endfunction

  logic signed [31:0] u0, v0, tu, tv;
  always_comb begin
    u0 = curu >>> 8;
    v0 = 32'(voff) + (curv >>> 8);
    tu = u0 + ((k == 2'd1 || k == 2'd3) ? 32'sd1 : 32'sd0);
    tv = v0 + ((k == 2'd2 || k == 2'd3) ? 32'sd1 : 32'sd0);
  end

  assign ext_ready = (st == S_IDLE);
  assign busy = (st != S_IDLE);

  always_ff @(posedge clk) begin
    if (rst) begin st <= S_IDLE; m_req <= 1'b0; end
    else case (st)
      S_IDLE: if (ext_valid) begin : ld
        logic e;
        curz <= fp_f2i_trunc(p_start[0], e); curu <= fp_f2i_trunc(p_start[1], e);
        curv <= fp_f2i_trunc(p_start[2], e); curi <= fp_f2i_trunc(p_start[3], e);
        dz <= fp_f2i_trunc(p_dpdx[0], e); du <= fp_f2i_trunc(p_dpdx[1], e);
        dv <= fp_f2i_trunc(p_dpdx[2], e); di <= fp_f2i_trunc(p_dpdx[3], e);
        y <= scan; x <= 32'($signed(startx)); xend <= 32'($signed(stopx));
        ctrl <= o_ctrl; alpha <= o_alpha; blend <= o_blend; solid <= o_solid; trans <= o_trans; texw <= o_texw;
        voff <= o_voff; zoff <= o_zoff; dtest <= o_dtest; dwrite <= o_dwrite; tfmt <= o_texfmt;
        texbase <= o_texbase; palbase <= o_palbase; rb <= rb_base;
        st <= S_PIX;
      end
      // :1250 for (uint32_t x = startx; x < stopx; x++)
      S_PIX: begin
        if (x >= xend) st <= S_IDLE;
        else begin
          m_req <= 1'b1; m_kind <= 2'd2; m_addr <= rb + ((pixw(y, x) | 32'd2) << 1); st <= S_DEPTH;
        end
      end
      S_DEPTH: if (m_ack) begin : dp
        logic signed [31:0] d; logic pass;
        m_req <= 1'b0; dcur <= m_rdata;
        d = (curz >>> 16) + 32'(zoff);
        if (d > 32'sh7fff) d = 32'sh7fff;
        depth <= d;
        pass = !dtest || (d >= 0 && d <= $signed({16'd0, m_rdata}));
        if (!pass) st <= S_NEXT;
        else if ((ctrl & 32'h000c0000) == 32'h000c0000) begin
          k <= 2'd0;
          pal[0] <= solid; st <= S_DST;                 // solid colour goes through the same expand/blend path
          tex[0] <= 8'hff; tex[1] <= 8'd0;              // marks "solid" for S_DST (see below)
        end else if (tfmt == 3'd0) begin
          st <= S_NEXT;                                 // untextured non-solid: never occurs on MK4 (zr1 counts it)
        end else begin
          k <= 2'd0; m_req <= 1'b1; m_kind <= 2'd0; st <= S_TEX;
          m_addr <= texbase + texoff(tfmt, v0, u0, 32'(texw));
        end
      end
      S_TEX: if (m_ack) begin : tx
        logic [7:0] t;
        t = (tfmt == 3'd1 || tfmt == 3'd3) ? ((m_rdata[7:0] >> (4 * tu[0])) & 8'h0f) : m_rdata[7:0];
        tex[k] <= t;
        if (k == 2'd0 && {8'd0, t} == trans) begin m_req <= 1'b0; st <= S_NEXT; end    // :1293 texel 0 transparent
        else if (k == 2'd3) begin k <= 2'd0; m_kind <= 2'd1; m_addr <= palbase + (32'(tex[0]) << 1); st <= S_PAL; end
        else begin
          k <= k + 2'd1;
          m_addr <= texbase + texoff(tfmt, v0 + (((k + 2'd1) == 2'd2 || (k + 2'd1) == 2'd3) ? 32'sd1 : 32'sd0),
                                     u0 + (((k + 2'd1) == 2'd1 || (k + 2'd1) == 2'd3) ? 32'sd1 : 32'sd0), 32'(texw));
        end
      end
      S_PAL: if (m_ack) begin
        pal[k] <= m_rdata;
        if (k == 2'd3) begin m_req <= 1'b0; tex[0] <= 8'd0; tex[1] <= 8'd1; st <= S_DST; end   // tex[1]=1: textured
        else begin k <= k + 2'd1; m_addr <= palbase + (32'(tex[k + 2'd1]) << 1); end
      end
      // colour (solid or bilinear), destination read if the blend uses it
      S_DST: begin
        if ((blend & 32'h00800000) != 0 && !m_req) begin
          m_req <= 1'b1; m_kind <= 2'd2; m_addr <= rb + (pixw(y, x) << 1);
        end else if ((blend & 32'h00800000) != 0 && m_ack) begin
          m_req <= 1'b0; dst <= m_rdata; st <= S_WPIX;
        end else if ((blend & 32'h00800000) == 0) begin
          dst <= 16'd0; st <= S_WPIX;
        end
      end
      S_WPIX: begin : wp
        logic [7:0] sr, sg, sb; logic [31:0] dr, dg, db, orr, og, ob, sa, da, i8;
        logic [7:0] cr [4], cg [4], cb [4]; logic [7:0] fu, fv; logic [31:0] top, bot;
        if (tex[1] == 8'd0) begin sr = p5(solid[14:10]); sg = p5(solid[9:5]); sb = p5(solid[4:0]); end
        else begin
          for (int j = 0; j < 4; j++) begin cr[j] = p5(pal[j][14:10]); cg[j] = p5(pal[j][9:5]); cb[j] = p5(pal[j][4:0]); end
          fu = curu[7:0]; fv = curv[7:0];
          top = 32'(cr[1]) * fu + 32'(cr[0]) * (9'd256 - fu); bot = 32'(cr[3]) * fu + 32'(cr[2]) * (9'd256 - fu);
          sr = 8'(((bot >> 1) * fv + (top >> 1) * (9'd256 - fv)) >> 15);
          top = 32'(cg[1]) * fu + 32'(cg[0]) * (9'd256 - fu); bot = 32'(cg[3]) * fu + 32'(cg[2]) * (9'd256 - fu);
          sg = 8'(((bot >> 1) * fv + (top >> 1) * (9'd256 - fv)) >> 15);
          top = 32'(cb[1]) * fu + 32'(cb[0]) * (9'd256 - fu); bot = 32'(cb[3]) * fu + 32'(cb[2]) * (9'd256 - fu);
          sb = 8'(((bot >> 1) * fv + (top >> 1) * (9'd256 - fv)) >> 15);
        end
        dr = 32'({dst[14:10], dst[14:12]}); dg = 32'({dst[9:5], dst[9:7]}); db = 32'({dst[4:0], dst[4:2]});
        if ((blend & 32'h00800000) == 0) begin dr = 0; dg = 0; db = 0; end
        sa = 32'(alpha[7:0]); da = 32'(alpha[15:8]); i8 = 32'(curi >>> 8);
        case (blend)
          OPQ2, OPQ3: begin orr = (32'(sr) * i8) >> 8; og = (32'(sg) * i8) >> 8; ob = (32'(sb) * i8) >> 8; end
          OPQ5: begin orr = (32'(sr) * sa) >> 8; og = (32'(sg) * sa) >> 8; ob = (32'(sb) * sa) >> 8; end
          ADD1: begin orr = ((32'(sr) * sa) >> 8) + dr; og = ((32'(sg) * sa) >> 8) + dg; ob = ((32'(sb) * sa) >> 8) + db; end
          ADD2: begin orr = ((32'(sr) * sa) >> 8) + ((dr * (da << 1)) >> 8); og = ((32'(sg) * sa) >> 8) + ((dg * (da << 1)) >> 8);
                      ob = ((32'(sb) * sa) >> 8) + ((db * (da << 1)) >> 8); end
          MUL1: begin orr = (((32'(sr) * (sa << 1)) >> 8) * dr) >> 8; og = (((32'(sg) * (sa << 1)) >> 8) * dg) >> 8;
                      ob = (((32'(sb) * (sa << 1)) >> 8) * db) >> 8; end
          default: begin orr = 32'(sr); og = 32'(sg); ob = 32'(sb); end     // OPQ1, OPQ4 and unknown modes
        endcase
        if (orr > 32'hff) orr = 32'hff; if (og > 32'hff) og = 32'hff; if (ob > 32'hff) ob = 32'hff;
        outpix = {1'b0, orr[7:3], og[7:3], ob[7:3]};
        m_req <= 1'b1; m_kind <= 2'd3; m_addr <= rb + (pixw(y, x) << 1); m_wdata <= outpix; st <= S_WDEPTH;
      end
      S_WDEPTH: if (m_ack) begin
        if (dwrite) begin m_kind <= 2'd3; m_addr <= rb + ((pixw(y, x) | 32'd2) << 1); m_wdata <= depth[15:0]; st <= S_NEXT; end
        else begin m_req <= 1'b0; st <= S_NEXT; end
      end
      S_NEXT: if (!m_req || m_ack) begin
        m_req <= 1'b0;
        curz <= curz + dz; curu <= curu + du; curv <= curv + dv; curi <= curi + di;
        x <= x + 32'd1; st <= S_PIX;
      end
      default: st <= S_IDLE;
    endcase
  end
endmodule
