#!/bin/bash
# zr_pixel3 coverage: the pipeline / cache / hazard rules v2-v3 introduced, plus two arithmetic misreads. Each mutant
# must FAIL the frame gate (run under hostile memory: w0 23 clk, reads 17 clk, 60 % write back-pressure).
#   H1 depth RAW guard ignores the write S3 retired last clock (the hazard v3 first shipped with)
#   H2 depth RAW guard ignores S3
#   H3 replay holds S1 one clock instead of two -- PERFORMANCE-ONLY: the stale read triggers a redundant refill that
#      converges to the right data (reported, not required)
#   H4 S3 uses the live palette output instead of its latch (palette read address moved on during a stall)
#   H5 palette reload does not wait for S2/S3 to finish with the old palette
#   H6 texture-cache bank from x-block parity only (a 2x2 footprint collides in one bank)
#   H7 destination read allowed before posted colour writes drained
#   H8 a new extent's pixels use the generator's object fields in S3 instead of their own (no per-pixel carry)
#   A1 bilinear bottom row not halved                  A2 depth test strict <
# H7 needs a blend read landing on the pixel just written; MK4 never does that, so run this gate on the SYNTHETIC set
# too (zeus1/golden/pix_synth.cpp, zr1 as oracle). The testbench samples colour reads at REQUEST time (strict model).
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/pixel/mutate_zr_pixel3.sh <evidence> <pix.bin> [frames]
set -u
R=/mnt/d/deck/fpga/zeus/zeus1/rtl/pixel/run_zr_pixel3.sh; T=$(mktemp -d); EV="$1"; PX="$2"; NF="${3:-3}"
declare -A M
M[H1]='s/                                (dp_pend \&\& dp_pix == s0_da);/                                1'"'"'b0;/'
M[H2]='s/ || (s3_ok \&\& s3_da == s0_da) ||/ ||/'
M[H3]='s/rp_cnt <= 2'"'"'d2; end else fill_k <= fill_k + 2'"'"'d1;$/rp_cnt <= 2'"'"'d1; end else fill_k <= fill_k + 2'"'"'d1;/'
M[H4]='s/for (int j = 0; j < 4; j++) pp\[j\] = s3_fresh ? pal_q\[j\] : s3_pal\[j\];/for (int j = 0; j < 4; j++) pp[j] = pal_q[j];/'
M[H5]='s/      if (pal_pend \&\& !s1_ok \&\& !s2_ok \&\& !(s3_ok \&\& s3_fresh)) begin/      if (pal_pend) begin/'
M[H6]='s/    return {by\[0\], bx\[0\]};/    return {1'"'"'b0, bx[0]};/'
M[H7]='s/        if (!cr_req \&\& !cw_valid) begin cr_req <= 1'"'"'b1;/        if (!cr_req) begin cr_req <= 1'"'"'b1;/'
M[H8]='s/          s3_depth <= s2_depth; s3_fu <= s2_fu; s3_fv <= s2_fv; s3_i8 <= s2_i8; s3_o <= s2_o; s3_dst_have <= 1'"'"'b0;/          s3_depth <= s2_depth; s3_fu <= s2_fu; s3_fv <= s2_fv; s3_i8 <= s2_i8; s3_o <= g_obj; s3_dst_have <= 1'"'"'b0;/'
M[A1]='s/      sr = 8'"'"'(((bot >> 1) \* s3_fv/      sr = 8'"'"'(((bot >> 0) * s3_fv/'
M[A2]='s/pass = !s1_o.dtest || (d >= 0 \&\& d <= \$signed({16'"'"'d0, s1_dcur}));/pass = !s1_o.dtest || (d >= 0 \&\& d < $signed({16'"'"'d0, s1_dcur}));/'
LIST="H1 H2 H3 H4 H5 H6 H7 H8 A1 A2"
for m in $LIST; do ( ZP_MUT="${M[$m]}" timeout 3000 bash "$R" "$EV" "$PX" "$NF" 23 17 60 > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc" ) & sleep 1; done
wait
ok=0
for m in $LIST; do
  rc=$(cat "$T/$m.rc")
  if grep -q "DID NOT APPLY" "$T/$m.log"; then echo "$m NOT APPLIED"; ok=1
  elif grep -q "BUILD FAILED" "$T/$m.log"; then echo "$m BUILD FAILED (not a kill)"; ok=1
  elif [ "$rc" = 0 ]; then if [ "$m" = H3 ]; then echo "$m survived: PERFORMANCE-ONLY (redundant refill)"; else echo "$m SURVIVED"; ok=1; fi
  elif [ "$rc" = 124 ]; then echo "$m killed: hung (timeout)"
  else echo "$m killed: $(grep -m1 -E 'DIFFERS|FAIL' "$T/$m.log" | cut -c1-110)"; fi
done
rm -rf "$T"; exit $ok
