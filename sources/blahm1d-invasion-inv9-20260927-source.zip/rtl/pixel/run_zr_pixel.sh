#!/bin/bash
# Build + run the zr_pixel gate: replay zr1's --pixtap stream through the RTL, compare frames with MAME.
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/pixel/run_zr_pixel.sh <render-evidence-dir> <pix.bin> [max-frames]
# ZP_MUT='sed-expression' mutates zr_pixel.sv (refuses to run if it did not apply).
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-pixel-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC="$S/pixel/zr_pixel.sv"
if [ -n "${ZP_MUT:-}" ]; then sed "$ZP_MUT" "$SRC" > zr_pixel.sv; cmp -s zr_pixel.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zr_pixel.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zr_pixel -Wno-fatal -Wno-lint -Wno-style -LDFLAGS -lz \
  "$S/fp32/fp32_pkg.sv" "$SRC" "$S/pixel/tb_zr_pixel.cpp" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
