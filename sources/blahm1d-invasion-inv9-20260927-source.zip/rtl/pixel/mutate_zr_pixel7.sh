#!/bin/bash
# zr_pixel7 coverage: the pipeline / cache / hazard rules v2-v3 introduced, plus two arithmetic misreads. Each mutant
# must FAIL the frame gate (run under hostile memory: w0 23 clk, reads 17 clk, 60 % write back-pressure).
#   H1 depth RAW guard ignores the write S3 retired last clock (the hazard v3 first shipped with)
#   H2 depth RAW guard ignores S3
#   H3 replay holds S1 one clock instead of two -- PERFORMANCE-ONLY: the stale read triggers a redundant refill that
#      converges to the right data (reported, not required)
#   H4 S3 uses the live palette output instead of its latch (palette read address moved on during a stall)
#   H5 palette reload does not wait for S2/S3 to finish with the old palette
#   H6 texture-cache bank from x-block parity only (a 2x2 footprint collides in one bank)
#   H7 destination read allowed before posted colour writes drained
#   H8 a new extent's pixels use the generator's object fields in S3 instead of their own (no per-pixel carry)
#   A1 bilinear bottom row not halved                  A2 depth test strict <
# H7 needs a blend read landing on the pixel just written; MK4 never does that, so run this gate on the SYNTHETIC set
# too (zeus1/golden/pix_synth.cpp, zr1 as oracle). The testbench samples colour reads at REQUEST time (strict model).
# usage: wsl -d Ubuntu -- bash mutate_zr_pixel7.sh <evidence> <pix.bin> [frames]   (ZP7_BP overrides the 92 % back-pressure)
set -u
R=/mnt/d/deck/fpga/zeus/zeus1/rtl/pixel/run_zr_pixel7.sh; T=$(mktemp -d); EV="$1"; PX="$2"; NF="${3:-3}"
declare -A M
M[H1]='s/                                (dp_pend \&\& dp_pix == s0_da);/                                1'"'"'b0;/'
M[H2]='s/ || (s3_ok \&\& s3_da == s0_da) ||/ ||/'
M[H3]='s/rp_cnt <= 2'"'"'d2; end else fill_k <= fill_k + 2'"'"'d1;$/rp_cnt <= 2'"'"'d1; end else fill_k <= fill_k + 2'"'"'d1;/'
M[H4]='s/for (int j = 0; j < 4; j++) pp\[j\] = s3_fresh ? pal_q\[j\] : s3_pal\[j\];/for (int j = 0; j < 4; j++) pp[j] = pal_q[j];/'
M[H5]='s/      if (pal_pend \&\& !s1_ok \&\& !s2_ok \&\& !(s3_ok \&\& s3_fresh)) begin/      if (pal_pend) begin/'
M[H6]='s/    return {by\[0\], bx\[0\]};/    return {1'"'"'b0, bx[0]};/'
M[H7]='s/        if (!cr_req \&\& !cw_valid) begin cr_req <= 1'"'"'b1;/        if (!cr_req) begin cr_req <= 1'"'"'b1;/'
M[H8]='s/s3_i8 <= s2_i8; s3_o <= s2_o;/s3_i8 <= s2_i8; s3_o <= g_obj;/'
M[A1]='s/    th = top\[17:1\]; bh = bot\[17:1\];/    th = top[17:1]; bh = bot[16:0];/'
# v5-only: the algebra the DSP cuts rest on
M[V1]='s/    return 18'"'"'({c0, 8'"'"'d0}) + 18'"'"'(unsigned'"'"'(20'"'"'(d) \* 20'"'"'(fup)));/    return 18'"'"'({c1, 8'"'"'d0}) + 18'"'"'(unsigned'"'"'(20'"'"'(d) * 20'"'"'(fup)));/'
M[V2]='s/    v  = 28'"'"'({th, 8'"'"'d0}) + 28'"'"'(d) \* 28'"'"'(fvp);/    v  = 28'"'"'({bh, 8'"'"'d0}) + 28'"'"'(d) * 28'"'"'(fvp);/'
# v6-only: the S3 | S3B split (u-lerp | v-lerp)
M[B1]='s/          for (int c = 0; c < 3; c++) begin s3b_top\[c\] <= u_top\[c\]; s3b_bot\[c\] <= u_bot\[c\];/          for (int c = 0; c < 3; c++) begin s3b_top[c] <= u_bot[c]; s3b_bot[c] <= u_top[c];/'
M[B2]='s/(s3b_ok \&\& s3b_da == s0_da) || //'
M[B3]='s/s3b_i8 <= s3_i8; s3b_o <= s3_o; s3b_fv <= s3_fv;/s3b_i8 <= s3_i8; s3b_o <= s3_o; s3b_fv <= s3_fu;/'
M[V3]='s/    b2 = is_mul1 ? {1'"'"'b0, dr} : {da, 1'"'"'b0};//'
M[V4]='s/    fa = (s4_o.bm == 3'"'"'d1) ? s4_i8 : (s4_o.bm == 3'"'"'d5) ? 32'"'"'({sa, 1'"'"'b0}) : 32'"'"'(sa);/    fa = (s4_o.bm == 3'"'"'d1) ? s4_i8 : 32'"'"'(sa);/'
# v7-only: the S4 | S5 blend split, the per-extent mode decode, the texel-row shift
#   C1 depth RAW guard ignores S5         C2 S5 writes every pixel         C3 ADD1 decoded as ADD2
#   C4 reads-destination bit never set    C5 texel row shifted one place too far (width * 4 instead of * 2)
M[C1]='s/ (s5_ok \&\& s5_da == s0_da) ||//'
M[C2]='s/s5_ok <= 1'"'"'b1; s5_write <= s4_write;/s5_ok <= 1'"'"'b1; s5_write <= 1'"'"'b1;/'
M[C3]='s/(o_blend == ADD1) ? 3'"'"'d3 :/(o_blend == ADD1) ? 3'"'"'d4 :/'
M[C4]='s/        g_obj.rdst <= (o_blend \& 32'"'"'h00800000) != 0;/        g_obj.rdst <= 1'"'"'b0;/'
M[C5]='s/(sdiv(ty, 1) <<< (l2 + 4'"'"'d1))/(sdiv(ty, 1) <<< (l2 + 4'"'"'d2))/'
# v4-only: the new S3 | S4 stage boundary
M[H9]='s/ (s4_ok \&\& s4_da == s0_da) ||/ /'
M[W1]='s/s4_ok <= 1'"'"'b1; s4_write <= s3b_write;/s4_ok <= 1'"'"'b1; s4_write <= 1'"'"'b1;/'
M[W2]='s/s4_sr <= src_r; s4_sg <= src_g; s4_sb <= src_b;/s4_sr <= src_r; s4_sg <= src_r; s4_sb <= src_b;/'
M[W3]='s/s4_i8 <= s3b_i8; s4_o <= s3b_o; s4_dst_have <= 1'"'"'b0;/s4_i8 <= s3b_i8; s4_o <= s3b_o; s4_dst_have <= 1'"'"'b1;/'
M[A2]='s/pass = !s1_o.dtest || (d >= 0 \&\& d <= \$signed({16'"'"'d0, s1_dcur}));/pass = !s1_o.dtest || (d >= 0 \&\& d < $signed({16'"'"'d0, s1_dcur}));/'
#   H9 depth RAW guard ignores S4 (the blend stage v4 added)   W1 S4 writes every pixel (loses the depth-test verdict)
#   W2 S4 green channel carries red                            W3 S4 starts with "destination already read"
LIST="${ZP7_LIST:-H1 H2 H3 H4 H5 H6 H7 H8 A1 A2 H9 W1 W2 W3 V1 V2 V4 B1 B2 B3 C1 C2 C3 C4 C5}"
BP="${ZP7_BP:-92}"   # v4 default: the S3|S4 split widens the pipeline, so the read-before-drain race (H7) needs a
                     # longer write-pending window than v3 did -- at 60 % H7 SURVIVES (measured), at 92 % it dies
for m in $LIST; do ( ZP7_MUT="${M[$m]}" timeout 3000 bash "$R" "$EV" "$PX" "$NF" 23 17 "$BP" > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc" ) & sleep 1; done
wait
ok=0
for m in $LIST; do
  rc=$(cat "$T/$m.rc")
  if grep -q "DID NOT APPLY" "$T/$m.log"; then echo "$m NOT APPLIED"; ok=1
  elif grep -q "BUILD FAILED" "$T/$m.log"; then echo "$m BUILD FAILED (not a kill)"; ok=1
  elif [ "$rc" = 0 ]; then if [ "$m" = H3 ]; then echo "$m survived: PERFORMANCE-ONLY (redundant refill)"; else echo "$m SURVIVED"; ok=1; fi
  elif [ "$rc" = 124 ]; then echo "$m killed: hung (timeout)"
  else echo "$m killed: $(grep -m1 -E 'DIFFERS|FAIL' "$T/$m.log" | cut -c1-110)"; fi
done
rm -rf "$T"; exit $ok
