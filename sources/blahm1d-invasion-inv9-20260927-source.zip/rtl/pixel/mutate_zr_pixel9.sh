#!/bin/bash
# zr_pixel9 mutation gate. Mutants live in mutants_zr_pixel9.txt (NAME<TAB>class<TAB>sed). Each mutant runs the frame
# gate on TWO stimuli under hostile memory (w0 23 clk, colour read 17 clk, 92 % write back-pressure, 50 % grant
# refusal, hostile read-during-write RAM model): the SYNTHETIC set (every blend mode, same-pixel repeats) and a
# real capture. class req: must FAIL at least one; perf: reported; keep: must PASS both (a property).
# usage: wsl -d Ubuntu -- bash mutate_zr_pixel9.sh <synth-evidence> <real-evidence> <real pix.bin> [real-frames] [jobs]
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/pixel; R=$D/run_zr_pixel9.sh
SY="$1"; EV="$2"; PX="$3"; NF="${4:-3}"; J="${5:-6}"
T=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}"); export T R SY EV PX NF
LIST="${ZP9_LIST:-$(grep -v '^#' $D/mutants_zr_pixel9.txt | cut -f1 | tr '\n' ' ')}"
one() {
  m="$1"; e=$(grep -P "^$m\t" /mnt/d/deck/fpga/zeus/zeus1/rtl/pixel/mutants_zr_pixel9.txt | cut -f3-)
  ZP9_MUT="$e" timeout 3000 bash "$R" "$SY" "$SY/pix.bin" 99 23 17 92 50 > "$T/$m.s.log" 2>&1; echo $? > "$T/$m.s.rc"
  ZP9_MUT="$e" timeout 3000 bash "$R" "$EV" "$PX" "$NF" 23 17 92 50 > "$T/$m.r.log" 2>&1; echo $? > "$T/$m.r.rc"
}
export -f one
printf '%s\n' $LIST | xargs -P "$J" -I{} bash -c 'one {}'
bad=0
for m in $LIST; do
  cls=$(grep -P "^$m\t" $D/mutants_zr_pixel9.txt | cut -f2); rs=$(cat "$T/$m.s.rc"); rr=$(cat "$T/$m.r.rc")
  if grep -q "DID NOT APPLY" "$T/$m.s.log"; then echo "$m NOT APPLIED"; bad=1; continue; fi
  if grep -q "BUILD FAILED" "$T/$m.s.log"; then echo "$m BUILD FAILED (not a kill)"; bad=1; continue; fi
  why=$(grep -h -m1 -E 'DIFFERS|FAIL' "$T/$m.s.log" "$T/$m.r.log" | head -1 | cut -c1-100)
  [ "$rs" = 124 ] || [ "$rr" = 124 ] && why="hung (timeout) $why"
  if [ "$rs" = 0 ] && [ "$rr" = 0 ]; then
    case "$cls" in keep) echo "$m kept (property holds)";; perf) echo "$m survived: performance-only";; *) echo "$m SURVIVED"; bad=1;; esac
  else
    case "$cls" in keep) echo "$m PROPERTY BROKEN: $why"; bad=1;; *) echo "$m killed [synth rc $rs, real rc $rr]: $why";; esac
  fi
done
rm -rf "$T"; exit $bad
