// zr_pixel2.sv -- Zeus 1 pixel pipe v2 (R4b, 50 MHz). Same per-pixel arithmetic as zr_pixel.sv (v1, the ORDER
// reference: MAME master 61c79406 midzeus_v.cpp render_poly :1235-1440, texel fetch :201-224, rgbutil.cpp:168-190
// bilinear as integers), restructured for throughput: one pixel per clock, in order, global stall.
//   S0  pixel generator; issues the depth read and the 4-bank texture-cache reads (tags + data)
//   S1  hit check (a miss freezes the pipe, fills the missing lines over the w0 channel, then REPLAYS S1's reads),
//       depth compare, texel extract, write decision (depth pass, texel 0 not transparent)
//   S2  palette read, addressed by S2's own latched texels (so a stall cannot change it)
//   S3  palette data latched on arrival; bilinear + blend (destination read if the blend needs it, only after posted
//       colour writes drained); posted colour write; depth write
// DEPTH ON CHIP for the render buffer (400 x 256 x 16): MEASURED on the fight window, every frame flips the render
// base, clears, and only then draws (zeus1/golden/pix_order.py), so the other buffer's depth is never read before it is
// cleared; the gate fails if an extent ever arrives before its frame's clear. Depth read-after-write: a pixel does not
// enter S1 while S1..S3 hold its depth word.
// Texture cache: 4 banks chosen by (x-block, y-block) parity of each texel, so a bilinear 2x2 lands in distinct banks
// (or shares one line); 8-byte lines, 512 per bank (16 KB), direct mapped; read-only (waveram 0 is static while drawing).
// Palette: the object's 256 entries in 4 RAM copies (one per texel), reloaded when palbase changes.
module zr_pixel2 (
  input  logic        clk,
  input  logic        rst,
  input  logic        ext_valid,
  output logic        ext_ready,
  input  logic signed [31:0] scan,
  input  logic signed [15:0] startx, stopx,
  input  logic [31:0] p_start [4], p_dpdx [4],
  input  logic [31:0] o_ctrl, o_alpha, o_blend,
  input  logic [15:0] o_solid, o_trans, o_texw, o_voff,
  input  logic signed [15:0] o_zoff,
  input  logic        o_dtest, o_dwrite,
  input  logic [2:0]  o_texfmt,
  input  logic [31:0] o_texbase, o_palbase,
  input  logic [31:0] rb_base,
  input  logic        clr_valid,
  output logic        clr_ready,
  output logic        w0_req,
  output logic [20:0] w0_line,
  input  logic        w0_ack,
  input  logic [63:0] w0_data,
  output logic        cw_valid,
  input  logic        cw_ready,
  output logic [31:0] cw_addr,
  output logic [15:0] cw_data,
  output logic        cr_req,
  output logic [31:0] cr_addr,
  input  logic        cr_ack,
  input  logic [15:0] cr_data,
  input  logic [16:0] dbg_daddr,
  output logic [15:0] dbg_ddata,
  output logic        idle,
  output logic [31:0] st_miss_lines, st_pal_loads, st_stall_clocks, st_pixels
);
  import fp32_pkg::*;
  localparam logic [31:0] OPQ2 = 32'h4b23cb00, OPQ3 = 32'h4b23dd00, OPQ5 = 32'hdd23dd00, ADD1 = 32'h40b68800,
                          ADD2 = 32'hc9b78800, MUL1 = 32'h4093c800;
  localparam int TLINES = 512;

  function automatic logic [7:0] p5(input logic [4:0] b); return {b, b[4:2]}; endfunction
  function automatic logic signed [31:0] sdiv(input logic signed [31:0] a, input int sh);
    return (a < 0) ? -((-a) >>> sh) : (a >>> sh);
  endfunction
  function automatic logic [31:0] texoff(input logic [2:0] f, input logic signed [31:0] ty, input logic signed [31:0] tx, input logic signed [31:0] w);
    case (f)
      3'd1, 3'd2: return 32'(sdiv(ty, 1) * (w * 2) + ((f == 3'd1 ? sdiv(tx, 3) : sdiv(tx, 2)) <<< 3) + ((ty & 1) <<< 2) + (f == 3'd1 ? (sdiv(tx, 1) & 3) : (tx & 3)));
      default:    return 32'(sdiv(ty, 2) * (w * 4) + ((f == 3'd3 ? sdiv(tx, 2) : sdiv(tx, 1)) <<< 3) + ((ty & 3) <<< 1) + (f == 3'd3 ? (sdiv(tx, 1) & 1) : (tx & 1)));
    endcase
  endfunction
  function automatic logic [1:0] tbank(input logic [2:0] f, input logic signed [31:0] ty, input logic signed [31:0] tx);
    logic signed [31:0] bx, by;
    case (f)
      3'd1: begin bx = sdiv(tx, 3); by = sdiv(ty, 1); end
      3'd2: begin bx = sdiv(tx, 2); by = sdiv(ty, 1); end
      3'd3: begin bx = sdiv(tx, 2); by = sdiv(ty, 2); end
      default: begin bx = sdiv(tx, 1); by = sdiv(ty, 2); end
    endcase
    return {by[0], bx[0]};
  endfunction
  function automatic logic [31:0] pix_word(input logic signed [31:0] yy, input logic [31:0] xx);
    return (32'(yy) << 10) | ((xx & 32'h1fe) << 1) | (xx & 32'h1);
  endfunction

  // ================= object / extent state =================
  logic        e_on;
  logic signed [31:0] curz, curu, curv, curi, dz, du, dv, di, y;
  logic [31:0] x, xend;
  logic [31:0] ctrl, alpha, blend, texbase, palbase, rb;
  logic [15:0] solid, trans, texw, voff; logic signed [15:0] zoff;
  logic        dtest, dwrite; logic [2:0] tfmt;
  logic [16:0] rowbase;

  // ================= RAMs =================
  logic        dp_we; logic [16:0] dp_wa, dp_ra; logic [15:0] dp_wd, dp_q;
  zr_dram_depth u_depth (.clk, .we(dp_we), .waddr(dp_wa), .wdata(dp_wd), .raddr(dp_ra), .rdata(dp_q));
  assign dbg_ddata = dp_q;

  logic [63:0] tc_data [4][TLINES]; logic [11:0] tc_tag [4][TLINES]; logic tc_val [4][TLINES];
  logic [8:0]  tc_ri [4]; logic [63:0] tc_q [4]; logic [11:0] tc_tq [4]; logic tc_vq [4];
  logic        tc_we; logic [1:0] tc_wb; logic [8:0] tc_wi; logic [63:0] tc_wd; logic [11:0] tc_wt;
  always_ff @(posedge clk) begin
    for (int b = 0; b < 4; b++) begin tc_q[b] <= tc_data[b][tc_ri[b]]; tc_tq[b] <= tc_tag[b][tc_ri[b]]; tc_vq[b] <= tc_val[b][tc_ri[b]]; end
    if (tc_we) begin tc_data[tc_wb][tc_wi] <= tc_wd; tc_tag[tc_wb][tc_wi] <= tc_wt; end
    if (rst) begin for (int b = 0; b < 4; b++) for (int i = 0; i < TLINES; i++) tc_val[b][i] <= 1'b0; end
    else if (tc_we) tc_val[tc_wb][tc_wi] <= 1'b1;
  end

  logic [15:0] pal_mem [4][256]; logic [7:0] pal_ri [4]; logic [15:0] pal_q [4];
  logic        pal_we; logic [7:0] pal_wi; logic [15:0] pal_wd;
  always_ff @(posedge clk) begin
    for (int k = 0; k < 4; k++) pal_q[k] <= pal_mem[k][pal_ri[k]];
    if (pal_we) for (int k = 0; k < 4; k++) pal_mem[k][pal_wi] <= pal_wd;
  end

  // ================= pipeline =================
  logic        s1_ok; logic [31:0] s1_x; logic signed [31:0] s1_y; logic [16:0] s1_da; logic signed [31:0] s1_depth;
  logic signed [31:0] s1_u, s1_vv, s1_i; logic s1_solid;
  logic [20:0] s1_line [4]; logic [1:0] s1_bank [4]; logic [2:0] s1_byte [4]; logic s1_nib [4]; logic s1_col [4];
  logic        s2_ok, s2_write; logic [31:0] s2_x; logic signed [31:0] s2_y; logic [16:0] s2_da; logic [15:0] s2_depth;
  logic        s2_solid; logic [7:0] s2_fu, s2_fv, s2_tex [4]; logic [31:0] s2_i8;
  logic        s3_ok, s3_write, s3_fresh; logic [31:0] s3_x; logic signed [31:0] s3_y; logic [16:0] s3_da; logic [15:0] s3_depth;
  logic        s3_solid; logic [7:0] s3_fu, s3_fv; logic [31:0] s3_i8; logic [15:0] s3_pal [4];
  logic        s3_dst_have; logic [15:0] s3_dst;

  // S0 addresses
  logic signed [31:0] u0, v0, d0; logic [31:0] tabs [4]; logic [1:0] tb [4];
  always_comb begin
    u0 = curu >>> 8; v0 = 32'(voff) + (curv >>> 8);
    for (int k = 0; k < 4; k++) begin : ta
      logic signed [31:0] tu, tv;
      tu = u0 + ((k == 1 || k == 3) ? 32'sd1 : 32'sd0); tv = v0 + ((k == 2 || k == 3) ? 32'sd1 : 32'sd0);
      tabs[k] = texbase + texoff(tfmt, tv, tu, 32'(texw));
      tb[k] = tbank(tfmt, tv, tu);
    end
    d0 = (curz >>> 16) + 32'(zoff); if (d0 > 32'sh7fff) d0 = 32'sh7fff;
  end
  logic [16:0] s0_da; assign s0_da = rowbase + 17'(x);
  logic raw_hz; assign raw_hz = (s1_ok && s1_da == s0_da) || (s2_ok && s2_da == s0_da) || (s3_ok && s3_da == s0_da);

  // S1 hit check + texel extract
  logic s1_hit [4]; logic s1_allhit; logic [7:0] s1_tex [4];
  always_comb begin
    s1_allhit = 1'b1;
    for (int k = 0; k < 4; k++) begin : hc
      logic [7:0] byt;
      s1_hit[k] = tc_vq[s1_bank[k]] && tc_tq[s1_bank[k]] == s1_line[k][20:9];
      if (s1_ok && !s1_solid && !s1_hit[k]) s1_allhit = 1'b0;
      byt = tc_q[s1_bank[k]][8*s1_byte[k] +: 8];
      s1_tex[k] = s1_nib[k] ? (s1_col[k] ? (byt >> 4) : (byt & 8'h0f)) : byt;
    end
  end

  // control
  logic fill_on, fill_wait, pl_on, pl_wait, clr_on; logic [1:0] rp_cnt; logic replay; assign replay = (rp_cnt != 2'd0);
  logic [1:0] fill_k, pl_sub; logic [5:0] pl_line; logic [63:0] pl_buf; logic [31:0] pal_loaded;
  logic [16:0] clr_i; logic [31:0] clr_x, clr_y;
  logic s3_needdst, s3_block, stall, s0_go;
  assign s3_needdst = s3_ok && s3_write && (blend & 32'h00800000) != 0 && !s3_dst_have;
  assign s3_block = s3_ok && (s3_needdst || (s3_write && cw_valid && !cw_ready));
  assign stall = (s1_ok && !s1_allhit) || fill_on || replay || s3_block;
  assign s0_go = e_on && !stall && !raw_hz && !pl_on;
  logic pipe_empty; assign pipe_empty = !e_on && !s1_ok && !s2_ok && !s3_ok && !fill_on && !pl_on;
  assign ext_ready = pipe_empty && !clr_on;
  assign clr_ready = pipe_empty && !clr_on;
  assign idle = pipe_empty && !clr_on && !cw_valid;

  // RAM read addresses: S0's new pixel, or S1's held pixel (stalled / replaying); palette by S2's texels
  always_comb begin
    dp_ra = dbg_daddr;
    for (int b = 0; b < 4; b++) tc_ri[b] = '0;
    if (s1_ok && (stall || !s0_go)) begin
      dp_ra = s1_da;
      for (int k = 0; k < 4; k++) tc_ri[s1_bank[k]] = s1_line[k][8:0];
    end
    if (s0_go) begin
      dp_ra = s0_da;
      for (int k = 0; k < 4; k++) tc_ri[tb[k]] = 9'(tabs[k] >> 3);
    end
    for (int k = 0; k < 4; k++) pal_ri[k] = s2_tex[k];
  end

  always_ff @(posedge clk) begin
    tc_we <= 1'b0; pal_we <= 1'b0; dp_we <= 1'b0;
    if (rst) begin
      e_on <= 1'b0; s1_ok <= 1'b0; s2_ok <= 1'b0; s3_ok <= 1'b0; fill_on <= 1'b0; rp_cnt <= 2'd0; w0_req <= 1'b0;
      clr_on <= 1'b0; cw_valid <= 1'b0; cr_req <= 1'b0; pl_on <= 1'b0; pal_loaded <= 32'hffffffff;
      st_miss_lines <= 0; st_pal_loads <= 0; st_stall_clocks <= 0; st_pixels <= 0;
    end else begin
      if (cw_valid && cw_ready) cw_valid <= 1'b0;
      if (stall) st_stall_clocks <= st_stall_clocks + 1;

      // ---------- clear ----------
      if (clr_valid && clr_ready) begin clr_on <= 1'b1; clr_i <= '0; clr_x <= 0; clr_y <= 0; end
      else if (clr_on && (!cw_valid || cw_ready)) begin
        dp_we <= 1'b1; dp_wa <= clr_i; dp_wd <= 16'h7fff;
        cw_valid <= 1'b1; cw_data <= 16'd0; cw_addr <= rb_base + (pix_word(clr_y, clr_x) << 1);
        clr_i <= clr_i + 17'd1;
        if (clr_x == 32'd399) begin clr_x <= 0; clr_y <= clr_y + 1; end else clr_x <= clr_x + 1;
        if (clr_i == 17'd102399) clr_on <= 1'b0;
      end

      // ---------- extent start ----------
      if (ext_valid && ext_ready) begin : ld
        logic e;
        curz <= fp_f2i_trunc(p_start[0], e); curu <= fp_f2i_trunc(p_start[1], e);
        curv <= fp_f2i_trunc(p_start[2], e); curi <= fp_f2i_trunc(p_start[3], e);
        dz <= fp_f2i_trunc(p_dpdx[0], e); du <= fp_f2i_trunc(p_dpdx[1], e);
        dv <= fp_f2i_trunc(p_dpdx[2], e); di <= fp_f2i_trunc(p_dpdx[3], e);
        y <= scan; x <= 32'($signed(startx)); xend <= 32'($signed(stopx)); rowbase <= 17'(scan * 400);
        ctrl <= o_ctrl; alpha <= o_alpha; blend <= o_blend; solid <= o_solid; trans <= o_trans; texw <= o_texw;
        voff <= o_voff; zoff <= o_zoff; dtest <= o_dtest; dwrite <= o_dwrite; tfmt <= o_texfmt;
        texbase <= o_texbase; palbase <= o_palbase; rb <= rb_base;
        e_on <= (startx < stopx);
        if (startx < stopx && (o_ctrl & 32'h000c0000) != 32'h000c0000 && o_texfmt != 3'd0 && o_palbase != pal_loaded) begin
          pl_on <= 1'b1; pl_line <= '0; pl_wait <= 1'b0; pl_sub <= 2'd0; pal_loaded <= o_palbase; st_pal_loads <= st_pal_loads + 1;
        end
      end

      // ---------- palette load: 64 lines (256 entries) from palbase ----------
      if (pl_on) begin
        if (pl_sub == 2'd0 && !pl_wait) begin w0_req <= 1'b1; w0_line <= 21'((palbase >> 3) + 32'(pl_line)); pl_wait <= 1'b1; end
        else if (pl_wait) begin
          if (w0_ack) begin
            w0_req <= 1'b0; pl_wait <= 1'b0; pl_buf <= w0_data;
            pal_we <= 1'b1; pal_wi <= {pl_line, 2'd0}; pal_wd <= w0_data[15:0]; pl_sub <= 2'd1;
          end
        end else begin
          pal_we <= 1'b1; pal_wi <= {pl_line, pl_sub}; pal_wd <= pl_buf[16*pl_sub +: 16];
          if (pl_sub == 2'd3) begin pl_sub <= 2'd0; if (pl_line == 6'd63) pl_on <= 1'b0; else pl_line <= pl_line + 6'd1; end
          else pl_sub <= pl_sub + 2'd1;
        end
      end

      // ---------- cache fill for the S1 pixel, then replay its reads ----------
      if (rp_cnt != 2'd0) rp_cnt <= rp_cnt - 2'd1;   // replay: the line lands one edge after the fill, the re-read one more
      if (s1_ok && !s1_allhit && !fill_on && !replay) begin fill_on <= 1'b1; fill_k <= 2'd0; fill_wait <= 1'b0; end
      if (fill_on) begin
        if (!fill_wait) begin
          if (s1_hit[fill_k] || dup(fill_k)) begin
            if (fill_k == 2'd3) begin fill_on <= 1'b0; rp_cnt <= 2'd2; end else fill_k <= fill_k + 2'd1;
          end else begin w0_req <= 1'b1; w0_line <= s1_line[fill_k]; fill_wait <= 1'b1; end
        end else if (w0_ack) begin
          w0_req <= 1'b0; fill_wait <= 1'b0; st_miss_lines <= st_miss_lines + 1;
          tc_we <= 1'b1; tc_wb <= s1_bank[fill_k]; tc_wi <= s1_line[fill_k][8:0]; tc_wd <= w0_data; tc_wt <= s1_line[fill_k][20:9];
          if (fill_k == 2'd3) begin fill_on <= 1'b0; rp_cnt <= 2'd2; end else fill_k <= fill_k + 2'd1;
        end
      end

      // ---------- S3: destination read (only once posted writes drained), then write ----------
      if (s3_ok && s3_fresh) begin s3_pal <= pal_q; s3_fresh <= 1'b0; end
      if (s3_needdst) begin
        if (!cr_req && !cw_valid) begin cr_req <= 1'b1; cr_addr <= rb + (pix_word(s3_y, s3_x) << 1); end
        else if (cr_req && cr_ack) begin cr_req <= 1'b0; s3_dst <= cr_data; s3_dst_have <= 1'b1; end
      end
      if (s3_ok && !s3_block) begin
        if (s3_write) begin
          cw_valid <= 1'b1; cw_addr <= rb + (pix_word(s3_y, s3_x) << 1); cw_data <= s3_color; st_pixels <= st_pixels + 1;
          if (dwrite) begin dp_we <= 1'b1; dp_wa <= s3_da; dp_wd <= s3_depth; end
        end
        s3_ok <= 1'b0;
      end

      // ---------- advance S2 -> S3, S1 -> S2, S0 -> S1 (all hold on stall) ----------
      if (!stall) begin
        if (s2_ok) begin
          s3_ok <= 1'b1; s3_fresh <= 1'b1; s3_write <= s2_write; s3_x <= s2_x; s3_y <= s2_y; s3_da <= s2_da;
          s3_depth <= s2_depth; s3_solid <= s2_solid; s3_fu <= s2_fu; s3_fv <= s2_fv; s3_i8 <= s2_i8; s3_dst_have <= 1'b0;
        end
        s2_ok <= 1'b0;
        if (s1_ok) begin : a12
          logic pass; logic signed [31:0] d;
          d = s1_depth;
          pass = !dtest || (d >= 0 && d <= $signed({16'd0, dp_q}));
          s2_ok <= 1'b1; s2_x <= s1_x; s2_y <= s1_y; s2_da <= s1_da; s2_depth <= d[15:0];
          s2_solid <= s1_solid; s2_fu <= s1_u[7:0]; s2_fv <= s1_vv[7:0]; s2_i8 <= 32'(s1_i >>> 8);
          for (int k = 0; k < 4; k++) s2_tex[k] <= s1_tex[k];
          s2_write <= pass && (s1_solid || (tfmt != 3'd0 && {8'd0, s1_tex[0]} != trans));
        end
        s1_ok <= 1'b0;
        if (s0_go) begin
          s1_ok <= 1'b1; s1_x <= x; s1_y <= y; s1_da <= s0_da; s1_depth <= d0;
          s1_u <= curu; s1_vv <= curv; s1_i <= curi; s1_solid <= (ctrl & 32'h000c0000) == 32'h000c0000;
          for (int k = 0; k < 4; k++) begin : tk
            logic signed [31:0] tu; tu = u0 + ((k == 1 || k == 3) ? 32'sd1 : 32'sd0);
            s1_line[k] <= 21'(tabs[k] >> 3); s1_bank[k] <= tb[k]; s1_byte[k] <= tabs[k][2:0];
            s1_nib[k] <= (tfmt == 3'd1 || tfmt == 3'd3); s1_col[k] <= tu[0];
          end
          curz <= curz + dz; curu <= curu + du; curv <= curv + dv; curi <= curi + di;
          x <= x + 32'd1;
          if (x + 32'd1 >= xend) e_on <= 1'b0;
        end
      end
    end
  end

  function automatic logic dup(input logic [1:0] k);
    logic d; d = 1'b0;
    for (int j = 0; j < 4; j++) if (2'(j) < k && s1_bank[j] == s1_bank[k] && s1_line[j] == s1_line[k]) d = 1'b1;
    return d;
  endfunction

  // S3 colour: palette data straight from the RAM on the first clock, from the latch afterwards
  logic [15:0] s3_color;
  always_comb begin : col
    logic [7:0] sr, sg, sb; logic [31:0] dr, dg, db, orr, og, ob, sa, da; logic [15:0] pp [4];
    logic [7:0] cr [4], cg [4], cb [4]; logic [31:0] top, bot;
    for (int j = 0; j < 4; j++) pp[j] = s3_fresh ? pal_q[j] : s3_pal[j];
    if (s3_solid) begin sr = p5(solid[14:10]); sg = p5(solid[9:5]); sb = p5(solid[4:0]); end
    else begin
      for (int j = 0; j < 4; j++) begin cr[j] = p5(pp[j][14:10]); cg[j] = p5(pp[j][9:5]); cb[j] = p5(pp[j][4:0]); end
      top = 32'(cr[1]) * s3_fu + 32'(cr[0]) * (9'd256 - s3_fu); bot = 32'(cr[3]) * s3_fu + 32'(cr[2]) * (9'd256 - s3_fu);
      sr = 8'(((bot >> 1) * s3_fv + (top >> 1) * (9'd256 - s3_fv)) >> 15);
      top = 32'(cg[1]) * s3_fu + 32'(cg[0]) * (9'd256 - s3_fu); bot = 32'(cg[3]) * s3_fu + 32'(cg[2]) * (9'd256 - s3_fu);
      sg = 8'(((bot >> 1) * s3_fv + (top >> 1) * (9'd256 - s3_fv)) >> 15);
      top = 32'(cb[1]) * s3_fu + 32'(cb[0]) * (9'd256 - s3_fu); bot = 32'(cb[3]) * s3_fu + 32'(cb[2]) * (9'd256 - s3_fu);
      sb = 8'(((bot >> 1) * s3_fv + (top >> 1) * (9'd256 - s3_fv)) >> 15);
    end
    dr = 32'({s3_dst[14:10], s3_dst[14:12]}); dg = 32'({s3_dst[9:5], s3_dst[9:7]}); db = 32'({s3_dst[4:0], s3_dst[4:2]});
    if ((blend & 32'h00800000) == 0) begin dr = 0; dg = 0; db = 0; end
    sa = 32'(alpha[7:0]); da = 32'(alpha[15:8]);
    case (blend)
      OPQ2, OPQ3: begin orr = (32'(sr) * s3_i8) >> 8; og = (32'(sg) * s3_i8) >> 8; ob = (32'(sb) * s3_i8) >> 8; end
      OPQ5: begin orr = (32'(sr) * sa) >> 8; og = (32'(sg) * sa) >> 8; ob = (32'(sb) * sa) >> 8; end
      ADD1: begin orr = ((32'(sr) * sa) >> 8) + dr; og = ((32'(sg) * sa) >> 8) + dg; ob = ((32'(sb) * sa) >> 8) + db; end
      ADD2: begin orr = ((32'(sr) * sa) >> 8) + ((dr * (da << 1)) >> 8); og = ((32'(sg) * sa) >> 8) + ((dg * (da << 1)) >> 8);
                  ob = ((32'(sb) * sa) >> 8) + ((db * (da << 1)) >> 8); end
      MUL1: begin orr = (((32'(sr) * (sa << 1)) >> 8) * dr) >> 8; og = (((32'(sg) * (sa << 1)) >> 8) * dg) >> 8;
                  ob = (((32'(sb) * (sa << 1)) >> 8) * db) >> 8; end
      default: begin orr = 32'(sr); og = 32'(sg); ob = 32'(sb); end
    endcase
    if (orr > 32'hff) orr = 32'hff; if (og > 32'hff) og = 32'hff; if (ob > 32'hff) ob = 32'hff;
    s3_color = {1'b0, orr[7:3], og[7:3], ob[7:3]};
  end
endmodule

module zr_dram_depth (
  input  logic clk, input logic we, input logic [16:0] waddr, input logic [15:0] wdata,
  input  logic [16:0] raddr, output logic [15:0] rdata
);
  logic [15:0] mem [102400];
  always_ff @(posedge clk) begin
    if (we) mem[waddr] <= wdata;
    rdata <= mem[raddr];
  end
endmodule
