#!/bin/bash
# zr_pixel coverage: each mutant misreads one line of render_poly / the texel fetch / the SSE bilinear; the frame
# compare must FAIL each. Runs the first N frames (default 3).
#   P1 bilinear: bottom row not halved            (rgbutil.cpp:183 srli_epi32(color11, 1))
#   P2 bilinear: u and v swapped                  (midzeus_v.cpp:1306)
#   P3 depth test strict <                        (:1263)
#   P4 zoffset ignored                            (:1253)
#   P5 transparency tested on texel 1, not 0      (:1293)
#   P6 destination 5->8 bit expansion w/o the low bits (:1340-1342)
#   P7 4-bit texel nibble chosen by u0, not the fetched column (:204)
#   P8 texel row: floor instead of C truncation   (:203 y / 2 on a signed int)
#   P9 ADD1 ignores source alpha                  (:1390)
#   P10 depth not clamped to 0x7fff               (:1255-1256)
# P8 and P10 are UNREACHABLE on the fight window (zr1 REACH: depth_clamped 0, neg_texcoord 0 over 20 frames):
# reported, not required; re-check them on every new capture window.
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/pixel/mutate_zr_pixel.sh <render-evidence-dir> <pix.bin> [frames]
set -u
R=/mnt/d/deck/fpga/zeus/zeus1/rtl/pixel/run_zr_pixel.sh; T=$(mktemp -d); EV="$1"; PX="$2"; NF="${3:-3}"
declare -A M
M[P1]='s/sr = 8'"'"'(((bot >> 1) \* fv + (top >> 1) \* (9'"'"'d256 - fv)) >> 15);/sr = 8'"'"'(((bot >> 0) * fv + (top >> 1) * (9'"'"'d256 - fv)) >> 15);/'
M[P2]='s/fu = curu\[7:0\]; fv = curv\[7:0\];/fu = curv[7:0]; fv = curu[7:0];/'
M[P3]='s/pass = !dtest || (d >= 0 \&\& d <= \$signed({16'"'"'d0, m_rdata}));/pass = !dtest || (d >= 0 \&\& d < $signed({16'"'"'d0, m_rdata}));/'
M[P4]='s/d = (curz >>> 16) + 32'"'"'(zoff);/d = (curz >>> 16);/'
M[P5]='s/if (k == 2'"'"'d0 \&\& {8'"'"'d0, t} == trans)/if (k == 2'"'"'d1 \&\& {8'"'"'d0, t} == trans)/'
M[P6]='s/dr = 32'"'"'({dst\[14:10\], dst\[14:12\]});/dr = 32'"'"'({dst[14:10], 3'"'"'b000});/'
M[P7]='s/((m_rdata\[7:0\] >> (4 \* tu\[0\])) \& 8'"'"'h0f)/((m_rdata[7:0] >> (4 * u0[0])) \& 8'"'"'h0f)/'
M[P8]='s/return (a < 0) ? -((-a) >>> sh) : (a >>> sh);/return a >>> sh;/'
M[P9]='s/ADD1: begin orr = ((32'"'"'(sr) \* sa) >> 8) + dr;/ADD1: begin orr = 32'"'"'(sr) + dr;/'
M[P10]='s/if (d > 32'"'"'sh7fff) d = 32'"'"'sh7fff;/;/'
LIST="P1 P2 P3 P4 P5 P6 P7 P8 P9 P10"
for m in $LIST; do ( ZP_MUT="${M[$m]}" bash "$R" "$EV" "$PX" "$NF" > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc" ) & sleep 1; done
wait
ok=0
for m in $LIST; do
  rc=$(cat "$T/$m.rc")
  if grep -q "DID NOT APPLY" "$T/$m.log"; then echo "$m NOT APPLIED"; ok=1
  elif grep -q "BUILD FAILED" "$T/$m.log"; then echo "$m BUILD FAILED (not a kill)"; ok=1
  elif [ "$rc" = 0 ]; then case "$m" in P8|P10) echo "$m survived: UNREACHABLE on this window (zr1 REACH counters)";; *) echo "$m SURVIVED"; ok=1;; esac
  else echo "$m killed: $(grep -m1 DIFFERS "$T/$m.log" | cut -c1-110)"; fi
done
rm -rf "$T"; exit $ok
