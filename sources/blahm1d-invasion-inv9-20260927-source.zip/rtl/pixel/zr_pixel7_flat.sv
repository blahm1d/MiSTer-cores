// zr_pixel7_flat.sv -- packed-port wrapper of zr_pixel7 for the standalone unit fit. No logic.
module zr_pixel7_flat (
  input  logic         clk, rst,
  input  logic         ext_valid, output logic ext_ready,
  input  logic signed [31:0] scan, input logic signed [15:0] startx, stopx,
  input  logic [127:0] p_start_flat, p_dpdx_flat,
  input  logic [31:0]  o_ctrl, o_alpha, o_blend,
  input  logic [15:0]  o_solid, o_trans, o_texw, o_voff, input logic signed [15:0] o_zoff,
  input  logic         o_dtest, o_dwrite, input logic [2:0] o_texfmt,
  input  logic [31:0]  o_texbase, o_palbase, rb_base,
  input  logic         clr_valid, output logic clr_ready,
  output logic         w0_req, output logic [20:0] w0_line, input logic w0_ack, input logic [63:0] w0_data,
  output logic         cw_valid, input logic cw_ready, output logic [31:0] cw_addr, cw_data, output logic [1:0] cw_mask,
  output logic         cr_req, output logic [31:0] cr_addr, input logic cr_ack, input logic [15:0] cr_data,
  input  logic [16:0]  dbg_daddr, output logic [15:0] dbg_ddata,
  output logic         idle,
  output logic [31:0]  st_miss_lines, st_pal_loads, st_stall_clocks, st_pixels
);
  logic [31:0] ps [4], pd [4];
  always_comb for (int p = 0; p < 4; p++) begin ps[p] = p_start_flat[p*32 +: 32]; pd[p] = p_dpdx_flat[p*32 +: 32]; end
  zr_pixel7 u (.clk, .rst, .ext_valid, .ext_ready, .scan, .startx, .stopx, .p_start(ps), .p_dpdx(pd), .o_ctrl, .o_alpha,
    .o_blend, .o_solid, .o_trans, .o_texw, .o_voff, .o_zoff, .o_dtest, .o_dwrite, .o_texfmt, .o_texbase, .o_palbase,
    .rb_base, .clr_valid, .clr_ready, .w0_req, .w0_line, .w0_ack, .w0_data, .cw_valid, .cw_ready, .cw_addr, .cw_data,
    .cw_mask, .cr_req, .cr_addr, .cr_ack, .cr_data, .dbg_daddr, .dbg_ddata, .idle, .st_miss_lines, .st_pal_loads,
    .st_stall_clocks, .st_pixels);
endmodule
