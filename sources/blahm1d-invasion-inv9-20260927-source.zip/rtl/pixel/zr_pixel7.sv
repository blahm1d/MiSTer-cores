// zr_pixel5.sv -- Zeus 1 pixel pipe v5 (R4e, BUILD TO FIT): v4 plus two DSP cuts that are exact integer algebra, so
// behaviour is unchanged (same gates, same mutants):
//   * ONE multiply per lerp: a*f + b*(256 - f) == (b << 8) + (a - b) * f -- bilinear 18 multiplies -> 9
//   * the blend MUXES ITS OPERANDS and multiplies twice per channel instead of computing all five modes in parallel
//     (15 multiplies -> 6). v4 measured: see zeus1/area/pixel4_20ns; v3 was 42 DSP / 36.5 MHz.
// MAME master 61c79406 midzeus_v.cpp render_poly :1235-1440, texel fetch :201-224, rgbutil.cpp:168-190 bilinear as
// integers) and structure as zr_pixel2.sv (v2: S0 issue | S1 hit + depth + texels | S2 palette read | S3 colour +
// writes; banked texture cache; palette RAM; depth on chip for the render buffer), plus:
//   * extents FLOW: every pixel carries its object's fields down the pipe, so a new extent starts while the previous
//     one's pixels finish; only a palette change waits until S2/S3 stop reading the old palette
//   * depth RAM 64 bits wide (4 pixels) with 16-bit lane enables: a pixel write is one lane (no read-modify-write),
//     the clear writes 4 depths per clock
//   * colour port 32 bits with a 2-lane mask (MAME's layout puts pixels x and x+1 in adjacent words): the clear
//     writes 2 pixels per clock
module zr_pixel7 (
  input  logic        clk,
  input  logic        rst,
  input  logic        ext_valid,
  output logic        ext_ready,
  input  logic signed [31:0] scan,
  input  logic signed [15:0] startx, stopx,
  input  logic [31:0] p_start [4], p_dpdx [4],
  input  logic [31:0] o_ctrl, o_alpha, o_blend,
  input  logic [15:0] o_solid, o_trans, o_texw, o_voff,
  input  logic signed [15:0] o_zoff,
  input  logic        o_dtest, o_dwrite,
  input  logic [2:0]  o_texfmt,
  input  logic [31:0] o_texbase, o_palbase,
  input  logic [31:0] rb_base,
  input  logic        clr_valid,
  output logic        clr_ready,
  output logic        w0_req,
  output logic [20:0] w0_line,
  input  logic        w0_ack,
  input  logic [63:0] w0_data,
  output logic        cw_valid,
  input  logic        cw_ready,
  output logic [31:0] cw_addr,                     // byte offset of the 32-bit word (pixel pair)
  output logic [31:0] cw_data,
  output logic [1:0]  cw_mask,                     // bit0: low 16 (even x), bit1: high 16 (odd x)
  output logic        cr_req,
  output logic [31:0] cr_addr,
  input  logic        cr_ack,
  input  logic [15:0] cr_data,
  input  logic [16:0] dbg_daddr,                   // pixel index y*400 + x
  output logic [15:0] dbg_ddata,
  output logic        idle,
  output logic [31:0] st_miss_lines, st_pal_loads, st_stall_clocks, st_pixels
);
  import fp32_pkg::*;
  localparam logic [31:0] OPQ2 = 32'h4b23cb00, OPQ3 = 32'h4b23dd00, OPQ5 = 32'hdd23dd00, ADD1 = 32'h40b68800,
                          ADD2 = 32'hc9b78800, MUL1 = 32'h4093c800;
  localparam int TLINES = 512;

  function automatic logic [7:0] p5(input logic [4:0] b); return {b, b[4:2]}; endfunction
  function automatic logic signed [31:0] sdiv(input logic signed [31:0] a, input int sh);
    return (a < 0) ? -((-a) >>> sh) : (a >>> sh);
  endfunction
  // v7: the row term is a SHIFT, not a multiply. MAME's texel fetch multiplies by width * 2 (or * 4), but a textured
  // quad's width is always 512 >> texwshift (midzeus_v.cpp zeus_draw_quad: extra.texwidth = 512 >> texwshift), a
  // power of two, so (y / 2) * (w * 2) == (y / 2) << (log2 w + 1) bit for bit, including the 32-bit wrap. v6 had four
  // 32x32 multipliers here (one per texel of the 2x2) -- most of its 13 wide DSP blocks (zeus1/area/pixel6_20ns).
  function automatic logic [31:0] texoff(input logic [2:0] f, input logic signed [31:0] ty, input logic signed [31:0] tx, input logic [3:0] l2);
    case (f)
      3'd1, 3'd2: return 32'((sdiv(ty, 1) <<< (l2 + 4'd1)) + ((f == 3'd1 ? sdiv(tx, 3) : sdiv(tx, 2)) <<< 3) + ((ty & 1) <<< 2) + (f == 3'd1 ? (sdiv(tx, 1) & 3) : (tx & 3)));
      default:    return 32'((sdiv(ty, 2) <<< (l2 + 4'd2)) + ((f == 3'd3 ? sdiv(tx, 2) : sdiv(tx, 1)) <<< 3) + ((ty & 3) <<< 1) + (f == 3'd3 ? (sdiv(tx, 1) & 1) : (tx & 1)));
    endcase
  endfunction
  // log2 of a power-of-two texture width (4..512); a non-power-of-two width on a textured object is out of contract
  function automatic logic [3:0] log2w(input logic [15:0] w);
    logic [3:0] r; r = 4'd0;
    for (int i = 0; i < 16; i++) if (w[i]) r = 4'(i);
    return r;
  endfunction
  function automatic logic [1:0] tbank(input logic [2:0] f, input logic signed [31:0] ty, input logic signed [31:0] tx);
    logic signed [31:0] bx, by;
    case (f)
      3'd1: begin bx = sdiv(tx, 3); by = sdiv(ty, 1); end
      3'd2: begin bx = sdiv(tx, 2); by = sdiv(ty, 1); end
      3'd3: begin bx = sdiv(tx, 2); by = sdiv(ty, 2); end
      default: begin bx = sdiv(tx, 1); by = sdiv(ty, 2); end
    endcase
    return {by[0], bx[0]};
  endfunction
  function automatic logic [31:0] pix_word(input logic signed [31:0] yy, input logic [31:0] xx);
    return (32'(yy) << 10) | ((xx & 32'h1fe) << 1) | (xx & 32'h1);
  endfunction

  // per-pixel object fields (travel with the pixel)
  typedef struct packed {
    logic dtest, dwrite; logic [15:0] trans; logic [2:0] tfmt; logic solid; logic [15:0] solidc;
    logic [31:0] blend, alpha, rb;
    logic [2:0] bm; logic rdst;               // v7: blend mode decoded ONCE per extent (0 pass, 1 OPQ2/3, 2 OPQ5, 3 ADD1, 4 ADD2, 5 MUL1) + reads-destination
  } pobj_t;

  // ================= generator (S0) =================
  logic        e_on;
  logic signed [31:0] curz, curu, curv, curi, dz, du, dv, di, y;
  logic [31:0] x, xend, texbase, palbase;
  logic [15:0] texw, voff; logic signed [15:0] zoff; logic [2:0] tfmt; logic [3:0] texl2;
  logic [16:0] rowbase;
  pobj_t       g_obj;

  // ================= depth RAM: 25,600 x 64, 16-bit lane enables =================
  logic        dp_we; logic [14:0] dp_wa, dp_ra; logic [63:0] dp_wd; logic [3:0] dp_wl; logic [63:0] dp_q;
  zr_depth64 u_depth (.clk, .we(dp_we), .lanes(dp_wl), .waddr(dp_wa), .wdata(dp_wd), .raddr(dp_ra), .rdata(dp_q));
  logic [1:0] dbg_lane_r;
  always_ff @(posedge clk) dbg_lane_r <= dbg_daddr[1:0];
  assign dbg_ddata = dp_q[16*dbg_lane_r +: 16];

  // ================= texture cache =================
  // one simple-dual-port M10K per bank holding {valid, tag, data}; valid bits cleared by a sweep after reset
  logic [8:0]  tc_ri [4]; logic [63:0] tc_q [4]; logic [11:0] tc_tq [4]; logic tc_vq [4];
  logic        tc_we; logic [1:0] tc_wb; logic [8:0] tc_wi; logic [63:0] tc_wd; logic [11:0] tc_wt;
  logic        tc_init; logic [8:0] tc_ii;                         // reset sweep: entry tc_ii of every bank -> invalid
  genvar gb;
  generate for (gb = 0; gb < 4; gb++) begin : g_tc
    logic [76:0] q; logic we; logic [8:0] wa; logic [76:0] wd;
    assign we = tc_init || (tc_we && tc_wb == 2'(gb));
    assign wa = tc_init ? tc_ii : tc_wi;
    assign wd = tc_init ? 77'd0 : {1'b1, tc_wt, tc_wd};
    zr_sdp #(77, 9) u_bank (.clk, .we, .waddr(wa), .wdata(wd), .raddr(tc_ri[gb]), .rdata(q));
    assign tc_vq[gb] = q[76]; assign tc_tq[gb] = q[75:64]; assign tc_q[gb] = q[63:0];
  end endgenerate
  always_ff @(posedge clk)
    if (rst) begin tc_init <= 1'b1; tc_ii <= '0; end
    else if (tc_init) begin if (tc_ii == 9'(TLINES - 1)) tc_init <= 1'b0; tc_ii <= tc_ii + 9'd1; end

  // ================= palette =================
  logic [15:0] pal_mem [4][256]; logic [7:0] pal_ri [4]; logic [15:0] pal_q [4];
  logic        pal_we; logic [7:0] pal_wi; logic [15:0] pal_wd;
  always_ff @(posedge clk) begin
    for (int k = 0; k < 4; k++) pal_q[k] <= pal_mem[k][pal_ri[k]];
    if (pal_we) for (int k = 0; k < 4; k++) pal_mem[k][pal_wi] <= pal_wd;
  end

  // ================= pipeline =================
  logic        s1_ok; logic [31:0] s1_x; logic signed [31:0] s1_y; logic [16:0] s1_da; logic signed [31:0] s1_depth;
  logic signed [31:0] s1_u, s1_vv, s1_i; pobj_t s1_o;
  logic [20:0] s1_line [4]; logic [1:0] s1_bank [4]; logic [2:0] s1_byte [4]; logic s1_nib [4]; logic s1_col [4];
  logic        s2_ok, s2_write; logic [31:0] s2_x; logic signed [31:0] s2_y; logic [16:0] s2_da; logic [15:0] s2_depth;
  logic [7:0]  s2_fu, s2_fv, s2_tex [4]; logic [31:0] s2_i8; pobj_t s2_o;
  logic        s3_ok, s3_write, s3_fresh; logic [31:0] s3_x; logic signed [31:0] s3_y; logic [16:0] s3_da; logic [15:0] s3_depth;
  logic [7:0]  s3_fu, s3_fv; logic [31:0] s3_i8; logic [15:0] s3_pal [4]; pobj_t s3_o;
  // S4 (v4): the BLEND stage. v3 did bilinear and blend between the same two registers -- four multiply levels in one
  // clock (measured 36.5 MHz, zeus1/area/pixel3c_20ns). S3 now ends at the source colour; S4 blends and writes.
  logic        s4_ok, s4_write; logic [31:0] s4_x; logic signed [31:0] s4_y; logic [16:0] s4_da; logic [15:0] s4_depth;
  logic [7:0]  s4_sr, s4_sg, s4_sb; logic [31:0] s4_i8; pobj_t s4_o;
  logic        s4_dst_have; logic [15:0] s4_dst;
  // S3B (v6): the bilinear's SECOND half. v5 fitted at 37.7 MHz with the worst path running palette RAM -> the whole
  // bilinear -> s4_sg (26.5 ns, zeus1/area/pixel5_20ns paths report): splitting bilinear from blend was not enough,
  // because the bilinear alone holds two multiply levels. S3 now ends after the u-lerp, S3B does the v-lerp.
  logic        s3b_ok, s3b_write; logic [31:0] s3b_x; logic signed [31:0] s3b_y; logic [16:0] s3b_da;
  logic [15:0] s3b_depth; logic [31:0] s3b_i8; pobj_t s3b_o; logic [7:0] s3b_fv;
  logic [17:0] s3b_top [3], s3b_bot [3]; logic [7:0] s3b_solid [3];

  logic signed [31:0] u0, v0, d0; logic [31:0] tabs [4]; logic [1:0] tb [4];
  always_comb begin
    u0 = curu >>> 8; v0 = 32'(voff) + (curv >>> 8);
    for (int k = 0; k < 4; k++) begin : ta
      logic signed [31:0] tu, tv;
      tu = u0 + ((k == 1 || k == 3) ? 32'sd1 : 32'sd0); tv = v0 + ((k == 2 || k == 3) ? 32'sd1 : 32'sd0);
      tabs[k] = texbase + texoff(tfmt, tv, tu, texl2);
      tb[k] = tbank(tfmt, tv, tu);
    end
    d0 = (curz >>> 16) + 32'(zoff); if (d0 > 32'sh7fff) d0 = 32'sh7fff;
  end
  logic [16:0] s0_da; assign s0_da = rowbase + 17'(x);
  // read-after-write on the same PIXEL: S1..S3, plus the write S3 retired last clock (the RAM takes it one edge later)
  logic [16:0] dp_pix; logic dp_pend;
  logic raw_hz; assign raw_hz = (s1_ok && s1_da == s0_da) || (s2_ok && s2_da == s0_da) || (s3_ok && s3_da == s0_da) ||
                                (s3b_ok && s3b_da == s0_da) || (s4_ok && s4_da == s0_da) || (s5_ok && s5_da == s0_da) ||
                                (dp_pend && dp_pix == s0_da);

  logic s1_hit [4]; logic s1_allhit; logic [7:0] s1_tex [4]; logic [15:0] s1_dcur;
  always_comb begin
    s1_allhit = 1'b1;
    for (int k = 0; k < 4; k++) begin : hc
      logic [7:0] byt;
      s1_hit[k] = tc_vq[s1_bank[k]] && tc_tq[s1_bank[k]] == s1_line[k][20:9];
      if (s1_ok && !s1_o.solid && !s1_hit[k]) s1_allhit = 1'b0;
      byt = tc_q[s1_bank[k]][8*s1_byte[k] +: 8];
      s1_tex[k] = s1_nib[k] ? (s1_col[k] ? (byt >> 4) : (byt & 8'h0f)) : byt;
    end
    s1_dcur = dp_q[16*s1_da[1:0] +: 16];
  end

  // ================= control =================
  logic fill_on, fill_wait, pl_on, pl_wait, pal_pend, clr_on; logic [1:0] rp_cnt; logic replay;
  assign replay = (rp_cnt != 2'd0);
  logic [1:0] fill_k, pl_sub; logic [5:0] pl_line; logic [63:0] pl_buf; logic [31:0] pal_loaded;
  logic [14:0] clr_d; logic [8:0] clr_cx, clr_cy;     // depth word (4 px) counter; colour pair position (even x, y)
  logic clr_dd, clr_cd;                              // depth part / colour part done
  // S5 (v7): the blend's SECOND multiply + clamp + pack + the writes. v6 fitted at 38.8 MHz with every worst path
  // running s4_o.blend -> cw_data (zeus1/area/pixel6_20ns paths report): a 32-bit mode compare, an operand mux, the
  // 8x32 product, MUL1's dependent second product, clamp and pack in ONE clock. S4 now ends at the first product.
  logic        s5_ok, s5_write; logic [31:0] s5_x; logic signed [31:0] s5_y; logic [16:0] s5_da; logic [15:0] s5_depth;
  pobj_t       s5_o; logic [31:0] s5_a [3]; logic [7:0] s5_src [3], s5_dst [3];
  logic s4_needdst, s4_block, s5_block, stall, s0_go;
  assign s4_needdst = s4_ok && s4_write && s4_o.rdst && !s4_dst_have;
  assign s4_block = s4_ok && s4_needdst;                                  // S4 waits only for the destination read
  assign s5_block = s5_ok && s5_write && cw_valid && !cw_ready;          // S5 waits only for the write port
  assign stall = (s1_ok && !s1_allhit) || fill_on || replay || s4_block || s5_block;
  assign s0_go = e_on && !stall && !raw_hz && !pl_on && !pal_pend;
  logic pipe_empty; assign pipe_empty = !e_on && !s1_ok && !s2_ok && !s3_ok && !s3b_ok && !s4_ok && !s5_ok && !fill_on && !pl_on && !pal_pend;
  assign ext_ready = !e_on && !pl_on && !pal_pend && !clr_on && !tc_init;
  assign clr_ready = pipe_empty && !clr_on;
  assign idle = pipe_empty && !clr_on && !cw_valid;

  always_comb begin
    dp_ra = dbg_daddr[16:2];
    for (int b = 0; b < 4; b++) tc_ri[b] = '0;
    if (s1_ok && (stall || !s0_go)) begin
      dp_ra = s1_da[16:2];
      for (int k = 0; k < 4; k++) tc_ri[s1_bank[k]] = s1_line[k][8:0];
    end
    if (s0_go) begin
      dp_ra = s0_da[16:2];
      for (int k = 0; k < 4; k++) tc_ri[tb[k]] = 9'(tabs[k] >> 3);
    end
    for (int k = 0; k < 4; k++) pal_ri[k] = s2_tex[k];
  end

  always_ff @(posedge clk) begin
    tc_we <= 1'b0; pal_we <= 1'b0; dp_we <= 1'b0; dp_pend <= 1'b0;
    if (rst) begin
      e_on <= 1'b0; s1_ok <= 1'b0; s2_ok <= 1'b0; s3_ok <= 1'b0; s3b_ok <= 1'b0; s4_ok <= 1'b0; s5_ok <= 1'b0; fill_on <= 1'b0; rp_cnt <= 2'd0; w0_req <= 1'b0;
      clr_on <= 1'b0; cw_valid <= 1'b0; cr_req <= 1'b0; pl_on <= 1'b0; pal_pend <= 1'b0; pal_loaded <= 32'hffffffff;
      st_miss_lines <= 0; st_pal_loads <= 0; st_stall_clocks <= 0; st_pixels <= 0;
    end else begin
      if (cw_valid && cw_ready) cw_valid <= 1'b0;
      if (stall) st_stall_clocks <= st_stall_clocks + 1;

      // ---------- clear: depth 4 px/clk on chip, colour 2 px/clk to memory, in parallel ----------
      if (clr_valid && clr_ready) begin clr_on <= 1'b1; clr_d <= '0; clr_cx <= '0; clr_cy <= '0; clr_dd <= 1'b0; clr_cd <= 1'b0; end
      else if (clr_on) begin
        if (!clr_dd) begin
          dp_we <= 1'b1; dp_wl <= 4'hf; dp_wa <= clr_d; dp_wd <= {4{16'h7fff}};
          if (clr_d == 15'd25599) clr_dd <= 1'b1; else clr_d <= clr_d + 15'd1;
        end
        if (!clr_cd && (!cw_valid || cw_ready)) begin
          cw_valid <= 1'b1; cw_data <= 32'd0; cw_mask <= 2'b11; cw_addr <= rb_base + (pix_word(32'(clr_cy), 32'(clr_cx)) << 1);
          if (clr_cx == 9'd398) begin clr_cx <= '0; if (clr_cy == 9'd255) clr_cd <= 1'b1; else clr_cy <= clr_cy + 9'd1; end
          else clr_cx <= clr_cx + 9'd2;
        end
        if (clr_dd && clr_cd) clr_on <= 1'b0;
      end

      // ---------- extent start (the previous extent's pixels may still be in S1..S3) ----------
      if (ext_valid && ext_ready) begin : ld
        logic e; logic need_pal;
        curz <= fp_f2i_trunc(p_start[0], e); curu <= fp_f2i_trunc(p_start[1], e);
        curv <= fp_f2i_trunc(p_start[2], e); curi <= fp_f2i_trunc(p_start[3], e);
        dz <= fp_f2i_trunc(p_dpdx[0], e); du <= fp_f2i_trunc(p_dpdx[1], e);
        dv <= fp_f2i_trunc(p_dpdx[2], e); di <= fp_f2i_trunc(p_dpdx[3], e);
        y <= scan; x <= 32'($signed(startx)); xend <= 32'($signed(stopx)); rowbase <= 17'(scan * 400);
        texw <= o_texw; texl2 <= log2w(o_texw); voff <= o_voff; zoff <= o_zoff; tfmt <= o_texfmt; texbase <= o_texbase; palbase <= o_palbase;
        g_obj.dtest <= o_dtest; g_obj.dwrite <= o_dwrite; g_obj.trans <= o_trans; g_obj.tfmt <= o_texfmt;
        g_obj.solid <= (o_ctrl & 32'h000c0000) == 32'h000c0000; g_obj.solidc <= o_solid;
        g_obj.blend <= o_blend; g_obj.alpha <= o_alpha; g_obj.rb <= rb_base;
        g_obj.bm <= (o_blend == OPQ2 || o_blend == OPQ3) ? 3'd1 : (o_blend == OPQ5) ? 3'd2 : (o_blend == ADD1) ? 3'd3 :
                    (o_blend == ADD2) ? 3'd4 : (o_blend == MUL1) ? 3'd5 : 3'd0;
        g_obj.rdst <= (o_blend & 32'h00800000) != 0;
        e_on <= (startx < stopx);
        need_pal = startx < stopx && (o_ctrl & 32'h000c0000) != 32'h000c0000 && o_texfmt != 3'd0 && o_palbase != pal_loaded;
        if (need_pal) begin pal_pend <= 1'b1; pal_loaded <= o_palbase; st_pal_loads <= st_pal_loads + 1; end
      end
      // palette change: wait until S2/S3 no longer read the old palette, then reload
      if (pal_pend && !s1_ok && !s2_ok && !(s3_ok && s3_fresh)) begin
        pal_pend <= 1'b0; pl_on <= 1'b1; pl_line <= '0; pl_wait <= 1'b0; pl_sub <= 2'd0;
      end
      if (pl_on) begin
        if (pl_sub == 2'd0 && !pl_wait) begin w0_req <= 1'b1; w0_line <= 21'((palbase >> 3) + 32'(pl_line)); pl_wait <= 1'b1; end
        else if (pl_wait) begin
          if (w0_ack) begin
            w0_req <= 1'b0; pl_wait <= 1'b0; pl_buf <= w0_data;
            pal_we <= 1'b1; pal_wi <= {pl_line, 2'd0}; pal_wd <= w0_data[15:0]; pl_sub <= 2'd1;
          end
        end else begin
          pal_we <= 1'b1; pal_wi <= {pl_line, pl_sub}; pal_wd <= pl_buf[16*pl_sub +: 16];
          if (pl_sub == 2'd3) begin pl_sub <= 2'd0; if (pl_line == 6'd63) pl_on <= 1'b0; else pl_line <= pl_line + 6'd1; end
          else pl_sub <= pl_sub + 2'd1;
        end
      end

      // ---------- cache fill + replay ----------
      if (rp_cnt != 2'd0) rp_cnt <= rp_cnt - 2'd1;
      if (s1_ok && !s1_allhit && !fill_on && !replay) begin fill_on <= 1'b1; fill_k <= 2'd0; fill_wait <= 1'b0; end
      if (fill_on) begin
        if (!fill_wait) begin
          if (s1_hit[fill_k] || dup(fill_k)) begin
            if (fill_k == 2'd3) begin fill_on <= 1'b0; rp_cnt <= 2'd2; end else fill_k <= fill_k + 2'd1;
          end else begin w0_req <= 1'b1; w0_line <= s1_line[fill_k]; fill_wait <= 1'b1; end
        end else if (w0_ack) begin
          w0_req <= 1'b0; fill_wait <= 1'b0; st_miss_lines <= st_miss_lines + 1;
          tc_we <= 1'b1; tc_wb <= s1_bank[fill_k]; tc_wi <= s1_line[fill_k][8:0]; tc_wd <= w0_data; tc_wt <= s1_line[fill_k][20:9];
          if (fill_k == 2'd3) begin fill_on <= 1'b0; rp_cnt <= 2'd2; end else fill_k <= fill_k + 2'd1;
        end
      end

      // ---------- S4: blend + writes ----------
      if (s4_needdst) begin
        if (!cr_req && !cw_valid) begin cr_req <= 1'b1; cr_addr <= s4_o.rb + (pix_word(s4_y, s4_x) << 1); end
        else if (cr_req && cr_ack) begin cr_req <= 1'b0; s4_dst <= cr_data; s4_dst_have <= 1'b1; end
      end
      // ---------- S5: second blend product, clamp, pack, writes ----------
      if (s5_ok && !s5_block) begin
        if (s5_write) begin
          cw_valid <= 1'b1; cw_addr <= s5_o.rb + ((pix_word(s5_y, s5_x) & ~32'd1) << 1);
          cw_data <= {s5_color, s5_color}; cw_mask <= s5_x[0] ? 2'b10 : 2'b01; st_pixels <= st_pixels + 1;
          if (s5_o.dwrite) begin dp_we <= 1'b1; dp_wa <= s5_da[16:2]; dp_wl <= 4'b0001 << s5_da[1:0]; dp_wd <= {4{s5_depth}}; dp_pend <= 1'b1; dp_pix <= s5_da; end
        end
        s5_ok <= 1'b0;
      end
      // ---------- S3: palette latch + bilinear (source colour only) ----------
      if (s3_ok && s3_fresh) begin s3_pal <= pal_q; s3_fresh <= 1'b0; end

      // ---------- advance ----------
      if (!stall) begin
        if (s4_ok) begin                                  // S4 -> S5: the first blend product and the masked destination
          s5_ok <= 1'b1; s5_write <= s4_write; s5_x <= s4_x; s5_y <= s4_y; s5_da <= s4_da; s5_depth <= s4_depth; s5_o <= s4_o;
          for (int c = 0; c < 3; c++) begin s5_a[c] <= a_prod[c]; s5_src[c] <= a_src[c]; s5_dst[c] <= a_dst[c]; end
        end
        s4_ok <= 1'b0;
        if (s3b_ok) begin
          s4_ok <= 1'b1; s4_write <= s3b_write; s4_x <= s3b_x; s4_y <= s3b_y; s4_da <= s3b_da; s4_depth <= s3b_depth;
          s4_i8 <= s3b_i8; s4_o <= s3b_o; s4_dst_have <= 1'b0; s4_sr <= src_r; s4_sg <= src_g; s4_sb <= src_b;
        end
        s3b_ok <= 1'b0;
        if (s3_ok) begin                                  // S3 -> S3B: the u-lerped rows, the solid colour and fv
          s3b_ok <= 1'b1; s3b_write <= s3_write; s3b_x <= s3_x; s3b_y <= s3_y; s3b_da <= s3_da; s3b_depth <= s3_depth;
          s3b_i8 <= s3_i8; s3b_o <= s3_o; s3b_fv <= s3_fv;
          for (int c = 0; c < 3; c++) begin s3b_top[c] <= u_top[c]; s3b_bot[c] <= u_bot[c]; s3b_solid[c] <= u_solid[c]; end
        end
        s3_ok <= 1'b0;
        if (s2_ok) begin
          s3_ok <= 1'b1; s3_fresh <= 1'b1; s3_write <= s2_write; s3_x <= s2_x; s3_y <= s2_y; s3_da <= s2_da;
          s3_depth <= s2_depth; s3_fu <= s2_fu; s3_fv <= s2_fv; s3_i8 <= s2_i8; s3_o <= s2_o;
        end
        s2_ok <= 1'b0;
        if (s1_ok) begin : a12
          logic pass; logic signed [31:0] d;
          d = s1_depth;
          pass = !s1_o.dtest || (d >= 0 && d <= $signed({16'd0, s1_dcur}));
          s2_ok <= 1'b1; s2_x <= s1_x; s2_y <= s1_y; s2_da <= s1_da; s2_depth <= d[15:0]; s2_o <= s1_o;
          s2_fu <= s1_u[7:0]; s2_fv <= s1_vv[7:0]; s2_i8 <= 32'(s1_i >>> 8);
          for (int k = 0; k < 4; k++) s2_tex[k] <= s1_tex[k];
          s2_write <= pass && (s1_o.solid || (s1_o.tfmt != 3'd0 && {8'd0, s1_tex[0]} != s1_o.trans));
        end
        s1_ok <= 1'b0;
        if (s0_go) begin
          s1_ok <= 1'b1; s1_x <= x; s1_y <= y; s1_da <= s0_da; s1_depth <= d0; s1_o <= g_obj;
          s1_u <= curu; s1_vv <= curv; s1_i <= curi;
          for (int k = 0; k < 4; k++) begin : tk
            logic signed [31:0] tu; tu = u0 + ((k == 1 || k == 3) ? 32'sd1 : 32'sd0);
            s1_line[k] <= 21'(tabs[k] >> 3); s1_bank[k] <= tb[k]; s1_byte[k] <= tabs[k][2:0];
            s1_nib[k] <= (tfmt == 3'd1 || tfmt == 3'd3); s1_col[k] <= tu[0];
          end
          curz <= curz + dz; curu <= curu + du; curv <= curv + dv; curi <= curi + di;
          x <= x + 32'd1;
          if (x + 32'd1 >= xend) e_on <= 1'b0;
        end
      end
    end
  end

  function automatic logic dup(input logic [1:0] k);
    logic d; d = 1'b0;
    for (int j = 0; j < 4; j++) if (2'(j) < k && s1_bank[j] == s1_bank[k] && s1_line[j] == s1_line[k]) d = 1'b1;
    return d;
  endfunction

  // ---------------- S3: bilinear -> source colour ----------------
  // Every product carries its TRUE width: the texel / palette channels are 8 bits and the fractions 9 (0..256), so
  // these are 8x9 and 17x9 multiplies. v3 wrote them as 32-bit expressions and Quartus inferred 32x32 multipliers
  // (42 DSP measured, zeus1/area/pixel3c_20ns).
  // ONE multiply per lerp instead of two: a*f + b*(256 - f) == (b << 8) + (a - b) * f, exact integer algebra (no
  // rounding anywhere in this chain), so the result is bit-identical. v4 used six multiplies per channel = 18 for the
  // bilinear; this uses three = 9.
  // S3 half: the u-lerp of one channel's two texel rows. One multiply each, 10x10 signed (a 19-bit operand would
  // cost TWO DSPs per multiply -- v5 measured 36).
  function automatic logic [17:0] ulerp(input logic [7:0] c0, c1, input logic [7:0] fu);
    logic signed [9:0] fup, d;
    fup = 10'(signed'({2'b0, fu}));
    d   = 10'(signed'({2'b0, c1})) - 10'(signed'({2'b0, c0}));      // -255..255
    return 18'({c0, 8'd0}) + 18'(unsigned'(20'(d) * 20'(fup)));     // c0 * 256 + (c1 - c0) * fu  <= 130,560
  endfunction
  // S3B half: the v-lerp of the two u-lerped rows, then MAME's >> 15. (bot>>1) - (top>>1) fits 18 bits signed, so the
  // multiply stays 18x10.
  function automatic logic [7:0] vlerp(input logic [17:0] top, bot, input logic [7:0] fv);
    logic signed [9:0]  fvp;
    logic [16:0] th, bh; logic signed [17:0] d; logic signed [27:0] v;
    fvp = 10'(signed'({2'b0, fv}));
    th = top[17:1]; bh = bot[17:1];                                  // >> 1, as MAME's SSE path does
    d  = 18'(signed'({1'b0, bh})) - 18'(signed'({1'b0, th}));        // -65,280..65,280
    v  = 28'({th, 8'd0}) + 28'(d) * 28'(fvp);                        // th * 256 + (bh - th) * fv
    return 8'(v >>> 15);
  endfunction
  // S3: palette -> the two u-lerped rows per channel (one multiply level)
  logic [17:0] u_top [3], u_bot [3]; logic [7:0] u_solid [3];
  always_comb begin : col
    logic [15:0] pp [4]; logic [7:0] cr [4], cg [4], cb [4];
    for (int j = 0; j < 4; j++) pp[j] = s3_fresh ? pal_q[j] : s3_pal[j];
    for (int j = 0; j < 4; j++) begin cr[j] = p5(pp[j][14:10]); cg[j] = p5(pp[j][9:5]); cb[j] = p5(pp[j][4:0]); end
    u_top[0] = ulerp(cr[0], cr[1], s3_fu); u_bot[0] = ulerp(cr[2], cr[3], s3_fu);
    u_top[1] = ulerp(cg[0], cg[1], s3_fu); u_bot[1] = ulerp(cg[2], cg[3], s3_fu);
    u_top[2] = ulerp(cb[0], cb[1], s3_fu); u_bot[2] = ulerp(cb[2], cb[3], s3_fu);
    u_solid[0] = p5(s3_o.solidc[14:10]); u_solid[1] = p5(s3_o.solidc[9:5]); u_solid[2] = p5(s3_o.solidc[4:0]);
  end

  // S3B: the v-lerp (the second multiply level), or the solid colour passed through
  logic [7:0] src_r, src_g, src_b;
  always_comb begin : col2
    if (s3b_o.solid) begin src_r = s3b_solid[0]; src_g = s3b_solid[1]; src_b = s3b_solid[2]; end
    else begin
      src_r = vlerp(s3b_top[0], s3b_bot[0], s3b_fv);
      src_g = vlerp(s3b_top[1], s3b_bot[1], s3b_fv);
      src_b = vlerp(s3b_top[2], s3b_bot[2], s3b_fv);
    end
  end

  // ---------------- S4: blend -> written colour ----------------
  // i8 (the interpolated intensity) is a full 32-bit value in MAME (render_poly :1258), so OPQ2 / OPQ3 keep an 8x32
  // product; every other factor is 8 or 9 bits.
  // S4 (v7): the FIRST blend product only. The mode was decoded when the extent loaded (s4_o.bm), so no 32-bit
  // compare sits in this path. A = (src * fa) >> 8 with fa = i8 (OPQ2/3: a full 32-bit value, u32 wrap as in MAME
  // render_poly :1258) | 2*alpha (MUL1) | alpha. The destination is unpacked and masked here too, ready for S5.
  logic [31:0] a_prod [3]; logic [7:0] a_src [3], a_dst [3];
  always_comb begin : bl_a
    logic [31:0] fa; logic [7:0] sa;
    sa = s4_o.alpha[7:0];
    fa = (s4_o.bm == 3'd1) ? s4_i8 : (s4_o.bm == 3'd5) ? 32'({sa, 1'b0}) : 32'(sa);
    a_src[0] = s4_sr; a_src[1] = s4_sg; a_src[2] = s4_sb;
    for (int c = 0; c < 3; c++) a_prod[c] = (32'(a_src[c]) * fa) >> 8;
    a_dst[0] = {s4_dst[14:10], s4_dst[14:12]}; a_dst[1] = {s4_dst[9:5], s4_dst[9:7]}; a_dst[2] = {s4_dst[4:0], s4_dst[4:2]};
    if (!s4_o.rdst) for (int c = 0; c < 3; c++) a_dst[c] = '0;
  end

  // S5 (v7): the SECOND product B = (b1 * b2) >> 8 with (b1, b2) = (A, dst) for MUL1, else (dst, 2*dstalpha) for
  // ADD2; then the mode's combine, MAME's clamp to 0xff, and the 5-5-5 pack.
  logic [15:0] s5_color;
  always_comb begin : bl_b
    logic [31:0] o [3]; logic [17:0] b [3]; logic [7:0] da; logic mul1;
    da = s5_o.alpha[15:8]; mul1 = (s5_o.bm == 3'd5);
    for (int c = 0; c < 3; c++) begin
      b[c] = (18'(mul1 ? s5_a[c][17:0] : 18'(s5_dst[c])) * 18'(mul1 ? {1'b0, s5_dst[c]} : {da, 1'b0})) >> 8;
      case (s5_o.bm)
        3'd5:       o[c] = 32'(b[c]);                         // MUL1
        3'd4:       o[c] = s5_a[c] + 32'(b[c]);               // ADD2
        3'd3:       o[c] = s5_a[c] + 32'(s5_dst[c]);          // ADD1
        3'd1, 3'd2: o[c] = s5_a[c];                           // OPQ2/3, OPQ5
        default:    o[c] = 32'(s5_src[c]);                    // OPQ1/4 and unknown modes: the source unchanged
      endcase
      if (o[c] > 32'hff) o[c] = 32'hff;
    end
    s5_color = {1'b0, o[0][7:3], o[1][7:3], o[2][7:3]};
  end
endmodule

// on-chip depth: 25,600 x 64 (4 pixels per word), 16-bit lane write enables, registered read. Built as four plain
// 25,600 x 16 simple-dual-port RAMs (one per lane, own write enable, shared addresses): a single 64-bit memory with
// a byte-enable loop was not recognised by Quartus 17.0 map, which flattened it (8.6 GB, no progress in 20 min).
module zr_depth64 (
  input  logic clk, input logic we, input logic [3:0] lanes, input logic [14:0] waddr, input logic [63:0] wdata,
  input  logic [14:0] raddr, output logic [63:0] rdata
);
  genvar gl;
  generate for (gl = 0; gl < 4; gl++) begin : g_lane
    zr_dlane u_lane (.clk, .we(we && lanes[gl]), .waddr, .wdata(wdata[16*gl +: 16]), .raddr, .rdata(rdata[16*gl +: 16]));
  end endgenerate
endmodule

// one depth lane: 25,600 x 16 simple dual port, registered read (one memory per module for Quartus inference)
module zr_dlane (
  input  logic clk, input logic we, input logic [14:0] waddr, input logic [15:0] wdata,
  input  logic [14:0] raddr, output logic [15:0] rdata
);
  logic [15:0] mem [25600];
  always_ff @(posedge clk) begin
    if (we) mem[waddr] <= wdata;
    rdata <= mem[raddr];
  end
endmodule
