// zr_setup4.sv -- Zeus 1 polygon setup engine v4 (R3f): throughput from OVERLAP at the CPU's 50 MHz clock.
// Arithmetic, operation order and interface identical to zr_setup.sv (v1, the ORDER reference: poly.h
// render_polygon<4,4>, MAME master 61c79406); per-polygon front end (min/max, y clip, edge jobs, left/right) as v3b.
// Scanlines are split at the reciprocal and run as three cooperating machines:
//   PREP  fully (exact i2f16(2c+1), exponent - 1) and the edge advance for the NEXT scanline (its own li/ri)
//   A     x/y path (ldy rdy lt rt sx ex dsx, round sx/ex, order/clip, i2f, ixh, w) + first parameter half
//         (lm rm lp rp d) + reciprocal start; operands read straight from the edge store with A's own li/ri
//   B     dpdx = d*oox, wm = w*dpdx, start = lp + wm on its OWN add/mul pair, then the extent is emitted
// A hands off through a 2-slot buffer; the reciprocal result lands in its scanline's slot, so a stalled output never
// blocks the divider. A(n+1) runs while B(n) finishes. ~28 clocks per scanline.
module zr_setup4
  import fp32_pkg::*;
(
  input  logic        clk,
  input  logic        rst,
  input  logic        start,
  input  logic [31:0] vin [4][6],
  input  logic signed [31:0] clip_min_x, clip_max_x, clip_min_y, clip_max_y,
  output logic        busy,
  output logic        done,
  output logic        rejected,
  output logic        ext_valid,
  input  logic        ext_ready,
  output logic signed [31:0] ext_scan,
  output logic signed [15:0] ext_startx, ext_stopx,
  output logic [31:0] ext_start [4],
  output logic [31:0] ext_dpdx  [4],
  output logic        ext_exc
);
  localparam int L = 4;                                         // fp_add4 / fp_mul4 latency
  localparam logic [31:0] F_ONE = 32'h3f800000, F_HALF = 32'h3f000000;
  localparam int D0 = (3*L + 5 > 2*L + 8) ? 3*L + 5 : 2*L + 8;  // first d = rp - lp issue (A)
  localparam int W0 = (L + 1 > 4) ? L + 1 : 4;                  // wm issue offset (B)
  localparam int A_W = 5*L + 6;                                 // w captured (last A capture)
  localparam int A_END = A_W + 1;
  localparam int B_LAST = W0 + 2*L + 3;

  typedef enum logic [4:0] { S_IDLE, S_MINMAX, S_Y0, S_Y1, S_YW, S_Y2, S_Y3, S_EBUILD, S_JLATCH, S_ERUN, S_LR, S_LR2,
                             S_SCAN, S_DONE } st_t;
  st_t st;

  logic [31:0] v [4][6];
  logic signed [31:0] cminx, cmaxx, cminy, cmaxy, minyclip, maxyclip;
  logic [1:0] minv, maxv, mk;
  logic [31:0] maxy_f;

  // ---- edge store ----
  logic [31:0] e_x1 [2][3], e_y1 [2][3], e_y2 [2][3], e_dxdy [2][3], e_p1 [2][3][4], e_dpdy [2][3][4];
  logic [1:0]  e_v1 [2][3];
  logic        e_exc [2][3];
  logic [1:0]  e_cnt [2];
  logic       side; logic [1:0] cv;
  logic [2:0] nj, jb;
  logic       j_side [4]; logic [1:0] j_idx [4], j_v1 [4], j_v2 [4];
  function automatic logic [1:0] nextv(input logic sd, input logic [1:0] c); return sd ? c - 2'd1 : c + 2'd1; endfunction

  // ---- units: S (A x/y path), P (A parameter half), Q (B) ----
  logic [31:0] as_a, as_b, ms_a, ms_b, ap_a, ap_b, mp_a, mp_b, aq_a, aq_b, mq_a, mq_b;
  logic [31:0] as_y, ms_y, ap_y, mp_y, aq_y, mq_y, rcp_b, rcp_y;
  logic        as_sub, ap_sub, as_x, ms_x, ap_x, mp_x, aq_x, mq_x, rcp_start, rcp_done, rcp_x, rcp_busy;
  fp_add4 u_as (.clk, .a(as_a), .b(as_b), .sub(as_sub), .y(as_y), .exc(as_x));
  fp_mul4 u_ms (.clk, .a(ms_a), .b(ms_b), .y(ms_y), .exc(ms_x));
  fp_add4 u_ap (.clk, .a(ap_a), .b(ap_b), .sub(ap_sub), .y(ap_y), .exc(ap_x));
  fp_mul4 u_mp (.clk, .a(mp_a), .b(mp_b), .y(mp_y), .exc(mp_x));
  fp_add4 u_aq (.clk, .a(aq_a), .b(aq_b), .sub(1'b0), .y(aq_y), .exc(aq_x));
  fp_mul4 u_mq (.clk, .a(mq_a), .b(mq_b), .y(mq_y), .exc(mq_x));
  fp_rcp4 u_rcp (.clk, .rst, .start(rcp_start), .a(F_ONE), .b(rcp_b), .done(rcp_done), .y(rcp_y), .exc(rcp_x), .busy(rcp_busy));

  // ---- shared round_coordinate, 3 stages (as v3b) ----
  logic [31:0] rc_in_r, rc_in; logic signed [31:0] rc_out; logic rc_exc_out;
  logic        rcA_zero, rcA_exc, rcA_satp, rcA_satn, rcA_s, rcA_stk; logic [31:0] rcA_ip, rcA_fr;
  always_ff @(posedge clk) begin : rcu
    logic [7:0] e; logic [63:0] mag; int sh; logic signed [32:0] fl; logic up;
    rc_in_r <= rc_in;
    rcA_exc  <= is_special(rc_in_r);
    rcA_zero <= is_zero(rc_in_r) || is_special(rc_in_r);
    e = rc_in_r[30:23];
    rcA_s    <= rc_in_r[31];
    rcA_satp <= !rc_in_r[31] && e >= 8'd158;
    rcA_satn <= rc_in_r[31] && (e > 8'd158 || (e == 8'd158 && rc_in_r[22:0] != 23'd0));
    sh = int'(e) - 118;
    if (sh >= 0) begin mag = 64'({1'b1, rc_in_r[22:0]}) << sh; rcA_stk <= 1'b0; end
    else if (sh > -24) begin mag = 64'({1'b1, rc_in_r[22:0]}) >> (-sh); rcA_stk <= (({1'b1, rc_in_r[22:0]} & ((24'd1 << (-sh)) - 24'd1)) != 24'd0); end
    else begin mag = 64'd0; rcA_stk <= 1'b1; end
    rcA_ip <= mag[63:32]; rcA_fr <= mag[31:0];
    rc_exc_out <= rcA_exc;
    if (rcA_zero) rc_out <= 32'sd0;
    else if (rcA_satp) rc_out <= 32'sh7fffffff;
    else if (rcA_satn) rc_out <= 32'sh80000000;
    else begin
      if (!rcA_s) begin fl = $signed({1'b0, rcA_ip}); up = rcA_fr[31] && (rcA_fr[30:0] != 31'd0 || rcA_stk); end
      else if (rcA_fr == 32'd0 && !rcA_stk) begin fl = -$signed({1'b0, rcA_ip}); up = 1'b0; end
      else begin fl = -$signed({1'b0, rcA_ip}) - 33'sd1; up = (rcA_fr < 32'h80000000); end
      rc_out <= 32'(fl + (up ? 33'sd1 : 33'sd0));
    end
  end

  // ---- edge jobs ----
  logic [31:0] jx1, jy1, jx2, jy2, jp1 [4], jp2 [4];
  logic [7:0] c, ec; logic post;
  logic [31:0] j_dx, j_dp [4], j_ooy; logic j_x;
  logic lr_shared, lr_slope, lr_x, l_is_f;
  logic ls, rs; assign ls = ~l_is_f; assign rs = l_is_f;   // list side of the left / right edge

  // ---- PREP ----
  typedef enum logic [1:0] { P_FULLY, P_ADVL, P_ADVR, P_RDY } pst_t;
  pst_t pst; logic p_on;
  logic signed [31:0] p_scan; logic [31:0] p_fully; logic [1:0] p_li, p_ri;

  // ---- A ----
  logic a_busy; logic [7:0] ca; logic a_slot;
  logic signed [31:0] a_scan; logic [31:0] a_fully; logic [1:0] a_li, a_ri;
  logic [31:0] ldy, rdy, sx, ixf, a_rp [4]; logic signed [31:0] rsx; logic a_x;

  // ---- handoff buffer (2 slots) ----
  logic [31:0] hb_lp [2][4], hb_dd [2][4], hb_w [2], hb_oox [2];
  logic signed [31:0] hb_sx [2], hb_ex [2], hb_scan [2];
  logic hb_x [2], hb_rx [2], hb_adone [2], hb_ooxv [2];
  logic [1:0] reserved; logic hb_head, rcp_slot;

  // ---- B ----
  logic b_busy, b_emit; logic [7:0] cb;
  logic [31:0] b_lp [4], b_dd [4], b_w, b_oox, b_dpdx [4], b_st [4];
  logic signed [31:0] b_sx, b_ex, b_scan; logic b_x;
  logic signed [31:0] emitted_n, total_n;
  // B takes the head slot once A has finished it and its reciprocal has landed
  logic b_start_now;
  assign b_start_now = (st == S_SCAN) && !b_busy && hb_adone[hb_head] && hb_ooxv[hb_head];

  // ---- op issue ----
  always_comb begin
    as_a = '0; as_b = '0; as_sub = 1'b0; ms_a = '0; ms_b = '0; ap_a = '0; ap_b = '0; ap_sub = 1'b0; mp_a = '0; mp_b = '0;
    aq_a = '0; aq_b = '0; mq_a = '0; mq_b = '0; rcp_start = 1'b0; rcp_b = '0; rc_in = '0;
    if (st == S_Y0) rc_in = v[minv][1];
    if (st == S_Y1) rc_in = v[maxv][1];
    if (st == S_ERUN) begin
      if (!post) begin
        if (c == 0) begin as_a = jy2; as_b = jy1; as_sub = 1'b1; end
        if (c == 1) begin as_a = jx2; as_b = jx1; as_sub = 1'b1; end
        for (int p = 0; p < 4; p++) if (c == 8'(p)) begin ap_a = jp2[p]; ap_b = jp1[p]; ap_sub = 1'b1; end
        if (c == 8'(L)) begin rcp_start = 1'b1; rcp_b = as_y; end
      end else begin
        if (ec == 0) begin ms_a = j_dx; ms_b = j_ooy; end
        for (int p = 0; p < 4; p++) if (ec == 8'(p)) begin mp_a = j_dp[p]; mp_b = j_ooy; end
      end
    end
    if (a_busy) begin
      if (ca == 0) begin as_a = a_fully; as_b = e_y1[ls][a_li]; as_sub = 1'b1; end                        // ldy
      if (ca == 1) begin as_a = a_fully; as_b = e_y1[rs][a_ri]; as_sub = 1'b1; end                        // rdy
      if (ca == 8'(L))     begin ms_a = as_y; ms_b = e_dxdy[ls][a_li]; end                                // lt
      if (ca == 8'(L + 1)) begin ms_a = as_y; ms_b = e_dxdy[rs][a_ri]; end                                // rt
      for (int p = 0; p < 4; p++) begin
        if (ca == 8'(L + p))       begin mp_a = (p == 0) ? as_y : ldy; mp_b = e_dpdy[ls][a_li][p]; end    // lm
        if (ca == 8'(L + 4 + p))   begin mp_a = rdy; mp_b = e_dpdy[rs][a_ri][p]; end                     // rm
        if (ca == 8'(2*L + p))     begin ap_a = e_p1[ls][a_li][p]; ap_b = mp_y; end                      // lp
        if (ca == 8'(2*L + 4 + p)) begin ap_a = e_p1[rs][a_ri][p]; ap_b = mp_y; end                      // rp
        if (ca == 8'(D0 + p))      begin ap_a = a_rp[p]; ap_b = hb_lp[a_slot][p]; ap_sub = 1'b1; end        // d = rp - lp
      end
      if (ca == 8'(2*L))     begin as_a = e_x1[ls][a_li]; as_b = ms_y; end                                // sx
      if (ca == 8'(2*L + 1)) begin as_a = e_x1[rs][a_ri]; as_b = ms_y; end                                // ex
      if (ca == 8'(3*L))     rc_in = as_y;                                                                // round(sx)
      if (ca == 8'(3*L + 1)) begin as_a = as_y; as_b = sx; as_sub = 1'b1; rc_in = as_y; end               // dsx; round(ex)
      if (ca == 8'(3*L + 6)) begin as_a = ixf; as_b = F_HALF; end                                         // ixh
      if (ca == 8'(4*L + 1)) begin rcp_start = 1'b1; rcp_b = as_y; end                                    // oox
      if (ca == 8'(4*L + 6)) begin as_a = as_y; as_b = sx; as_sub = 1'b1; end                             // w = ixh - sx
    end
    if (b_busy && !b_emit) begin
      for (int p = 0; p < 4; p++) begin
        if (cb == 8'(p))          begin mq_a = b_dd[p]; mq_b = b_oox; end                                 // dpdx
        if (cb == 8'(W0 + p))     begin mq_a = b_w; mq_b = b_dpdx[p]; end                                 // wm
        if (cb == 8'(W0 + L + p)) begin aq_a = b_lp[p]; aq_b = mq_y; end                                  // start
      end
    end
  end

  assign busy = (st != S_IDLE);

  always_ff @(posedge clk) begin
    done <= 1'b0;
    if (rst) begin
      st <= S_IDLE; ext_valid <= 1'b0; rejected <= 1'b0; post <= 1'b0;
      a_busy <= 1'b0; b_busy <= 1'b0; b_emit <= 1'b0; p_on <= 1'b0;
      hb_adone[0] <= 1'b0; hb_adone[1] <= 1'b0; hb_ooxv[0] <= 1'b0; hb_ooxv[1] <= 1'b0;
    end else begin
      case (st)
        S_IDLE: if (start) begin
          v <= vin; cminx <= clip_min_x; cmaxx <= clip_max_x; cminy <= clip_min_y; cmaxy <= clip_max_y;
          rejected <= 1'b0; minv <= 2'd0; maxv <= 2'd0; mk <= 2'd1; st <= S_MINMAX;
        end
        S_MINMAX: begin
          if (fp_lt(v[mk][1], v[minv][1])) minv <= mk;
          else if (fp_gt(v[mk][1], v[maxv][1])) maxv <= mk;
          if (mk == 2'd3) st <= S_Y0; else mk <= mk + 2'd1;
        end
        S_Y0: st <= S_Y1;
        S_Y1: begin maxy_f <= v[maxv][1]; st <= S_YW; end
        S_YW: st <= S_Y2;
        S_Y2: begin minyclip <= (rc_out > cminy) ? rc_out : cminy; st <= S_Y3; end
        S_Y3: begin : yc
          logic signed [31:0] b;
          b = (rc_out < cmaxy + 32'sd1) ? rc_out : cmaxy + 32'sd1;
          maxyclip <= b;
          if (b - minyclip <= 32'sd0) begin rejected <= 1'b1; st <= S_DONE; end
          else begin side <= 1'b0; cv <= minv; e_cnt[0] <= 2'd0; e_cnt[1] <= 2'd0; nj <= 3'd0; st <= S_EBUILD; end
        end
        S_EBUILD: begin
          if (cv == maxv) begin
            if (side == 1'b0) begin side <= 1'b1; cv <= minv; end
            else begin jb <= 3'd0; st <= (nj == 3'd0) ? S_LR : S_JLATCH; end
          end else begin
            if (!fp_eq(v[cv][1], v[nextv(side, cv)][1])) begin
              j_side[nj[1:0]] <= side; j_idx[nj[1:0]] <= e_cnt[side]; j_v1[nj[1:0]] <= cv; j_v2[nj[1:0]] <= nextv(side, cv);
              e_v1[side][e_cnt[side]] <= cv;
              e_cnt[side] <= e_cnt[side] + 2'd1; nj <= nj + 3'd1;
            end
            cv <= nextv(side, cv);
          end
        end
        S_JLATCH: begin
          jx1 <= v[j_v1[jb[1:0]]][0]; jy1 <= v[j_v1[jb[1:0]]][1]; jx2 <= v[j_v2[jb[1:0]]][0]; jy2 <= v[j_v2[jb[1:0]]][1];
          for (int p = 0; p < 4; p++) begin jp1[p] <= v[j_v1[jb[1:0]]][2 + p]; jp2[p] <= v[j_v2[jb[1:0]]][2 + p]; end
          c <= '0; post <= 1'b0; st <= S_ERUN;
        end
        S_ERUN: begin
          if (!post) begin
            c <= c + 8'd1;
            if (c == 8'(L)) j_x <= as_x;
            if (c == 8'(L + 1)) begin j_dx <= as_y; if (as_x) j_x <= 1'b1; end
            for (int p = 0; p < 4; p++) if (c == 8'(L + p)) begin j_dp[p] <= ap_y; if (ap_x) j_x <= 1'b1; end
            if (rcp_done) begin j_ooy <= rcp_y; if (rcp_x) j_x <= 1'b1; post <= 1'b1; ec <= '0; end
          end else begin : epost
            logic sd; logic [1:0] ix;
            sd = j_side[jb[1:0]]; ix = j_idx[jb[1:0]];
            ec <= ec + 8'd1;
            if (ec == 8'(L)) begin e_dxdy[sd][ix] <= ms_y; if (ms_x) j_x <= 1'b1; end
            for (int p = 0; p < 4; p++) if (ec == 8'(L + p)) begin e_dpdy[sd][ix][p] <= mp_y; if (mp_x) j_x <= 1'b1; end
            if (ec == 8'(L + 4)) begin
              e_exc[sd][ix] <= j_x;
              e_x1[sd][ix] <= jx1; e_y1[sd][ix] <= jy1; e_y2[sd][ix] <= jy2;
              for (int p = 0; p < 4; p++) e_p1[sd][ix][p] <= jp1[p];
              post <= 1'b0;
              if (jb + 3'd1 == nj) st <= S_LR; else begin jb <= jb + 3'd1; st <= S_JLATCH; end
            end
          end
        end
        S_LR: begin
          lr_shared <= (e_v1[0][0] == e_v1[1][0]);
          lr_slope  <= fp_lt(e_dxdy[0][0], e_dxdy[1][0]);
          lr_x      <= fp_lt(e_x1[0][0], e_x1[1][0]);
          st <= S_LR2;
        end
        S_LR2: begin
          l_is_f <= (lr_shared && lr_slope) || (!lr_shared && lr_x);
          p_li <= 2'd0; p_ri <= 2'd0; p_scan <= minyclip; pst <= P_FULLY; p_on <= 1'b1;
          total_n <= maxyclip - minyclip; emitted_n <= 32'sd0; reserved <= 2'd0; hb_head <= 1'b0;
          st <= S_SCAN;
        end
        S_SCAN: if (emitted_n == total_n) begin p_on <= 1'b0; st <= S_DONE; end
        S_DONE: begin done <= 1'b1; st <= S_IDLE; end
        default: st <= S_IDLE;
      endcase

      // ================= PREP (next scanline) =================
      if (st == S_SCAN && p_on) begin
        case (pst)
          P_FULLY: if (p_scan < maxyclip) begin : fy
            fres_t r; r = fp_i2f16(16'(p_scan * 2 + 32'sd1));
            p_fully <= {r.v[31], r.v[30:23] - 8'd1, r.v[22:0]};
            pst <= P_ADVL;
          end
          P_ADVL: if (fp_gt(p_fully, e_y2[ls][p_li]) && fp_lt(p_fully, maxy_f)) p_li <= p_li + 2'd1; else pst <= P_ADVR;
          P_ADVR: if (fp_gt(p_fully, e_y2[rs][p_ri]) && fp_lt(p_fully, maxy_f)) p_ri <= p_ri + 2'd1; else pst <= P_RDY;
          P_RDY: ;
          default: pst <= P_FULLY;
        endcase
      end

      // ================= A =================
      if (st == S_SCAN && !a_busy && pst == P_RDY && reserved < 2'd2) begin : astart
        logic sl; sl = (reserved == 2'd0) ? hb_head : ~hb_head;   // next free slot in order
        a_busy <= 1'b1; ca <= '0; a_slot <= sl;
        a_scan <= p_scan; a_fully <= p_fully; a_li <= p_li; a_ri <= p_ri;
        a_x <= e_exc[ls][p_li] | e_exc[rs][p_ri];
        reserved <= reserved + 2'd1 - ((b_start_now) ? 2'd1 : 2'd0);
        p_scan <= p_scan + 32'sd1; pst <= P_FULLY;
      end else if (b_start_now) reserved <= reserved - 2'd1;
      if (a_busy) begin
        ca <= ca + 8'd1;
        if (ca == 8'(L))     begin ldy <= as_y; if (as_x) a_x <= 1'b1; end
        if (ca == 8'(L + 1)) begin rdy <= as_y; if (as_x) a_x <= 1'b1; end
        if ((ca == 8'(2*L) || ca == 8'(2*L + 1)) && ms_x) a_x <= 1'b1;
        if (ca == 8'(3*L))     begin sx <= as_y; if (as_x) a_x <= 1'b1; end
        if (ca == 8'(3*L + 1) && as_x) a_x <= 1'b1;
        if (ca == 8'(3*L + 3)) begin rsx <= rc_out; if (rc_exc_out) a_x <= 1'b1; end
        if (ca == 8'(3*L + 4)) begin : oc                                   // :1239-1251 order + clip
          logic signed [31:0] a, b;
          if (rc_exc_out) a_x <= 1'b1;
          a = rsx; b = rc_out;
          if (a > b) begin logic signed [31:0] t; t = a; a = b; b = t; end
          if (a < cminx) a = cminx;
          if (b > cmaxx + 32'sd1) b = cmaxx + 32'sd1;
          hb_sx[a_slot] <= a; hb_ex[a_slot] <= b;
          begin : i2f fres_t r; r = fp_i2f16(16'(a)); ixf <= r.v; if (a > 32'sd32767 || a < -32'sd32768) a_x <= 1'b1; end
        end
        if ((ca == 8'(4*L + 1) || ca == 8'(4*L + 6)) && as_x) a_x <= 1'b1;
        for (int p = 0; p < 4; p++) begin
          if ((ca == 8'(2*L + p) || ca == 8'(2*L + 4 + p)) && mp_x) a_x <= 1'b1;
          if (ca == 8'(3*L + p))     begin hb_lp[a_slot][p] <= ap_y; if (ap_x) a_x <= 1'b1; end
          if (ca == 8'(3*L + 4 + p)) begin a_rp[p] <= ap_y; if (ap_x) a_x <= 1'b1; end
          if (ca == 8'(D0 + L + p))  begin hb_dd[a_slot][p] <= ap_y; if (ap_x) a_x <= 1'b1; end
        end
        if (ca == 8'(4*L + 1)) rcp_slot <= a_slot;
        if (ca == 8'(A_W)) begin hb_w[a_slot] <= as_y; if (as_x) a_x <= 1'b1; end
        if (ca == 8'(A_END)) begin
          hb_x[a_slot] <= a_x; hb_scan[a_slot] <= a_scan; hb_adone[a_slot] <= 1'b1; a_busy <= 1'b0;
        end
      end
      if (rcp_done && st == S_SCAN) begin hb_oox[rcp_slot] <= rcp_y; hb_rx[rcp_slot] <= rcp_x; hb_ooxv[rcp_slot] <= 1'b1; end

      // ================= B =================
      if (b_start_now) begin
        b_busy <= 1'b1; b_emit <= 1'b0; cb <= '0;
        b_lp <= hb_lp[hb_head]; b_dd <= hb_dd[hb_head]; b_w <= hb_w[hb_head]; b_oox <= hb_oox[hb_head];
        b_sx <= hb_sx[hb_head]; b_ex <= hb_ex[hb_head]; b_scan <= hb_scan[hb_head];
        b_x <= hb_x[hb_head] | hb_rx[hb_head];
        hb_adone[hb_head] <= 1'b0; hb_ooxv[hb_head] <= 1'b0; hb_head <= ~hb_head;
      end else if (b_busy && !b_emit) begin
        cb <= cb + 8'd1;
        for (int p = 0; p < 4; p++) begin
          if (cb == 8'(L + p))          begin b_dpdx[p] <= mq_y; if (mq_x) b_x <= 1'b1; end
          if (cb == 8'(W0 + L + p) && mq_x) b_x <= 1'b1;
          if (cb == 8'(W0 + 2*L + p))   begin b_st[p] <= aq_y; if (aq_x) b_x <= 1'b1; end
        end
        if (cb == 8'(B_LAST)) b_emit <= 1'b1;
      end else if (b_busy && b_emit) begin
        if (!ext_valid) begin
          ext_valid <= 1'b1; ext_scan <= b_scan;
          if (b_sx >= b_ex) begin ext_startx <= 16'sd0; ext_stopx <= 16'sd0; end
          else begin ext_startx <= 16'(b_sx); ext_stopx <= 16'(b_ex); end
          ext_start <= b_st; ext_dpdx <= b_dpdx; ext_exc <= b_x;
        end else if (ext_ready) begin
          ext_valid <= 1'b0; b_busy <= 1'b0; b_emit <= 1'b0; emitted_n <= emitted_n + 32'sd1;
        end
      end
    end
  end

endmodule
