#!/bin/bash
# zr_setup coverage: each mutant misreads one line of poly.h render_polygon; the tap gate must FAIL each.
#   S1 fully without the +0.5 centre            (poly.h:1230)
#   S2 edge advance on >= instead of >          (:1231-1234)
#   S3 istartx not clamped before the params    (:1249, "BEFORE calculating parameter start")
#   S4 shared-vertex left/right test inverted   (:1194)
#   S5 horizontal edges not skipped             (:1158, :1179)
#   S6 empty extents not zeroed                 (:1276-1277)
#   S7 start uses stopx instead of startx       (:1270)
#   S8 minv chain: min tie taken by the LATER vertex (<=) (:1113-1114) -- killed only by the synthetic taps
#   (maxv tie with >= is an EQUIVALENT mutant: with tied max-y the advance loop stops at fully < v[maxv].y on the
#    first edge of either list, so both choices give identical extents; 30 K synthetic tie polygons agree)
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/setup/mutate_zr_setup.sh <tapdir> [max-polys]
set -u
R=/mnt/d/deck/fpga/zeus/zeus1/rtl/setup/run_zr_setup.sh; T=$(mktemp -d)
declare -A M
M[S1]='s/S_FULLY:   begin r = fp_add(fully, F_HALF);/S_FULLY:   begin r = fp_add(fully, 32'"'"'h0);/'
M[S2]='s/S_ADV_L: if (fp_gt(fully, v\[lv2\]\[1\])/S_ADV_L: if (!fp_lt(fully, v[lv2][1])/'
M[S3]='s/if (istartx < cminx) istartx <= cminx;/;/'
M[S4]='s/(e_v1\[0\]\[0\] == e_v1\[1\]\[0\] \&\& fp_lt(e_dxdy\[0\]\[0\], e_dxdy\[1\]\[0\]))/(e_v1[0][0] == e_v1[1][0] \&\& fp_gt(e_dxdy[0][0], e_dxdy[1][0]))/'
M[S5]='s/if (fp_eq(v\[cv\]\[1\], v\[nextv(side, cv)\]\[1\]))/if (1'"'"'b0)/'
M[S6]='s/if (istartx >= istopx) begin ext_startx <= 16'"'"'sd0; ext_stopx <= 16'"'"'sd0; end/if (1'"'"'b0) begin end/'
M[S7]='s/S_P_W:    begin r = fp_add(ixh, {~startx\[31\], startx\[30:0\]});/S_P_W:    begin r = fp_add(ixh, {~stopx[31], stopx[30:0]});/'
M[S8]='s/if (fp_lt(v\[k\]\[1\], v\[mn\]\[1\])) mn = 2'"'"'(k);/if (!fp_gt(v[k][1], v[mn][1])) mn = 2'"'"'(k);/'
for m in S1 S2 S3 S4 S5 S6 S7 S8; do
  ( ZR_MUT="${M[$m]}" bash "$R" "$@" > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc" ) &
  sleep 1
done
wait
ok=0
for m in S1 S2 S3 S4 S5 S6 S7 S8; do
  rc=$(cat "$T/$m.rc")
  if grep -q "DID NOT APPLY" "$T/$m.log"; then echo "$m NOT APPLIED"; ok=1
  elif grep -q "BUILD FAILED" "$T/$m.log"; then echo "$m BUILD FAILED (not a kill)"; ok=1
  elif [ "$rc" = 0 ]; then echo "$m SURVIVED"; ok=1
  else echo "$m killed: $(grep -m1 FAIL "$T/$m.log" | cut -c1-120)"; fi
done
rm -rf "$T"; exit $ok
