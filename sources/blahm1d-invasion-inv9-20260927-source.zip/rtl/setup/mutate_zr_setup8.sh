#!/bin/bash
# zr_setup8 mutation gate (mutants_zr_setup8.txt). Each mutant runs the streaming tap gate on two captures: the
# reference fight window (all polygons) and hvpoly (the first NP polygons). req: must FAIL at least one.
# usage: wsl -d Ubuntu -- bash mutate_zr_setup8.sh <tap-ref> <tap-heavy> [NP] [jobs]
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/setup; R=$D/run_zr_setup.sh
TA="$1"; TB="$2"; NP="${3:-30000}"; J="${4:-6}"
T=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}"); export T R TA TB NP D
LIST="${ZS8_LIST:-$(grep -v '^#' $D/mutants_zr_setup8.txt | cut -f1 | tr '\n' ' ')}"
one() {
  m="$1"; line=$(grep -P "^$m\t" $D/mutants_zr_setup8.txt); k=$(echo "$line" | cut -f3); e=$(echo "$line" | cut -f4-)
  if [ "$k" = U ]; then V=ZR_UMUT; else V=ZR_MUT; fi
  env ZR_TOP=zr_setup8 ZR_TB=tb_zr_setup_stream.cpp ZR_GFLAGS="--prefix Vzr_setup" $V="$e" timeout 3000 bash "$R" "$TA" > "$T/$m.a.log" 2>&1; echo $? > "$T/$m.a.rc"
  env ZR_TOP=zr_setup8 ZR_TB=tb_zr_setup_stream.cpp ZR_GFLAGS="--prefix Vzr_setup" $V="$e" timeout 3000 bash "$R" "$TB" "$NP" > "$T/$m.b.log" 2>&1; echo $? > "$T/$m.b.rc"
}
export -f one
printf '%s\n' $LIST | xargs -P "$J" -I{} bash -c 'one {}'
bad=0
for m in $LIST; do
  cls=$(grep -P "^$m\t" $D/mutants_zr_setup8.txt | cut -f2); ra=$(cat "$T/$m.a.rc"); rb=$(cat "$T/$m.b.rc")
  if grep -q "DID NOT APPLY" "$T/$m.a.log"; then echo "$m NOT APPLIED"; bad=1; continue; fi
  if grep -q "BUILD FAILED" "$T/$m.a.log"; then echo "$m BUILD FAILED (not a kill)"; bad=1; continue; fi
  why=$(grep -h -m1 -E 'FAIL|collision' "$T/$m.a.log" "$T/$m.b.log" | head -1 | cut -c1-110)
  { [ "$ra" = 124 ] || [ "$rb" = 124 ]; } && why="hung (timeout) $why"
  if [ "$ra" = 0 ] && [ "$rb" = 0 ]; then
    case "$cls" in perf) echo "$m survived: performance-only / unreachable";; *) echo "$m SURVIVED"; bad=1;; esac
  else echo "$m killed [ref rc $ra, heavy rc $rb]: $why"; fi
done
rm -rf "$T"; exit $bad
