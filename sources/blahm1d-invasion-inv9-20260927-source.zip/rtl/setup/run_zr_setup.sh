#!/bin/bash
# Build + run the zr_setup gate against zr1 taps (make them with: run_zr1.sh <evidence> --tap <dir>).
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/setup/run_zr_setup.sh <tapdir> [max-polys]
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-setup-$$"; mkdir -p "$B"; cd "$B" || exit 2
# ZR_TOP=zr_setup (v1, default) | zr_setup2 (v2). The testbench is shared: it talks to the module as "zr_setup".
TOP="${ZR_TOP:-zr_setup}"
if [ -n "${ZR_MUT:-}" ]; then sed "$ZR_MUT" "$S/setup/$TOP.sv" > "$TOP.sv"; cmp -s "$TOP.sv" "$S/setup/$TOP.sv" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC="$TOP.sv"; else SRC="$S/setup/$TOP.sv"; fi
EXTRA=""; [ "$TOP" != zr_setup ] && EXTRA="$S/fp32/fp32_units.sv $S/setup/zr_sdp.sv"
TB="${ZR_TB:-tb_zr_setup.cpp}"   # tb_zr_setup_stream.cpp for the streaming interface (zr_setup5)
# ZR_UMUT: mutate fp32_units.sv (the pipelined / iterative units) instead
if [ -n "${ZR_UMUT:-}" ]; then sed "$ZR_UMUT" "$S/fp32/fp32_units.sv" > fp32_units.sv; cmp -s fp32_units.sv "$S/fp32/fp32_units.sv" && { echo "MUTATION DID NOT APPLY"; exit 3; }; EXTRA="fp32_units.sv $S/setup/zr_sdp.sv"; fi
verilator --cc --exe --build -O3 -j 8 --top-module "$TOP" --prefix Vzr_setup -DZR_SIM ${ZR_GFLAGS:-} -DZR_CENSUS -Wno-fatal -Wno-lint -Wno-style \
  "$S/fp32/fp32_pkg.sv" $EXTRA "$SRC" "$S/setup/$TB" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
