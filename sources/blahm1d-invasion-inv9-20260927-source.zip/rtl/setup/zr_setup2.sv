// zr_setup2.sv -- Zeus 1 polygon setup engine v2 (fit-driven, R3c). Same arithmetic and interface as zr_setup.sv (v1,
// the operation-ORDER reference: poly.h render_polygon<4,4>, MAME master 61c79406), restructured for throughput:
//   S engine: fp_add_pipe + fp_mul_pipe + fp_rcp_iter (2 bits/clk) + round/clamp + int->float  (the x/y path)
//   P engine: fp_add_pipe + fp_mul_pipe                                                        (the 4 parameters)
// Every op issues at a compile-time cycle of a static schedule (pipe latency L), with operands from small structured
// muxes (no generic register file). The P engine's first half (lparam, rparam, d) overlaps the reciprocal.
// Exact shortcut: fully = float(curscan) + 0.5 = i2f(2*curscan + 1) with the exponent decremented (exact for
// |2*curscan+1| < 2^24, which the y clip guarantees) -- bit-identical to the source's add, without an adder.
// Edges: each geometric edge lies in exactly ONE list (forward minv->maxv or backward), so <= 4 edge jobs/polygon,
// each computed in its list's own orientation (as poly.h does; the two orientations can differ in the sign of a zero).
module zr_setup2
  import fp32_pkg::*;
#(parameter int L = 3)            // fp_add_pipe / fp_mul_pipe latency
(
  input  logic        clk,
  input  logic        rst,
  input  logic        start,
  input  logic [31:0] vin [4][6],
  input  logic signed [31:0] clip_min_x, clip_max_x, clip_min_y, clip_max_y,
  output logic        busy,
  output logic        done,
  output logic        rejected,
  output logic        ext_valid,
  input  logic        ext_ready,
  output logic signed [31:0] ext_scan,
  output logic signed [15:0] ext_startx, ext_stopx,
  output logic [31:0] ext_start [4],
  output logic [31:0] ext_dpdx  [4],
  output logic        ext_exc
);
  localparam logic [31:0] F_ONE = 32'h3f800000, F_HALF = 32'h3f000000;
  // first d = rp - lp issue: rp[p] is registered at 3L+4+p (valid from 3L+5+p) and ADD_P is busy to 2L+7
  localparam int D0 = (3*L + 5 > 2*L + 8) ? 3*L + 5 : 2*L + 8;
  // wm issue offset after oox: dpdx[p] is registered at L+p (valid from L+1+p) and MUL_P is busy to ec 3
  localparam int W0 = (L + 1 > 4) ? L + 1 : 4;
  localparam int SC_LAST = D0 + 3 + L;                              // last pre-reciprocal capture (d3)
  localparam int E_LAST = W0 + 2*L + 3;                             // last post-reciprocal capture (st3)

  typedef enum logic [3:0] { S_IDLE, S_MINMAX, S_YCLIP, S_EBUILD, S_ERUN, S_LR, S_SPREP, S_SRUN, S_EMIT, S_DONE } st_t;
  st_t st;

  logic [31:0] v [4][6];
  logic signed [31:0] cminx, cmaxx, cminy, cmaxy, minyclip, maxyclip, curscan;
  logic [1:0] minv, maxv;

  // ---- edge store: list side x index ----
  logic [1:0] e_v1 [2][3], e_v2 [2][3];
  logic [31:0] e_dxdy [2][3], e_dpdy [2][3][4];
  logic       e_exc [2][3];
  logic [1:0] e_cnt [2];
  // edge jobs (build order: forward list, then backward list)
  logic       side; logic [1:0] cv;
  logic [2:0] nj, jb;                       // jobs built / job running
  logic       j_side [4]; logic [1:0] j_idx [4], j_v1 [4], j_v2 [4];
  function automatic logic [1:0] nextv(input logic sd, input logic [1:0] c); return sd ? c - 2'd1 : c + 2'd1; endfunction

  // ---- units ----
  logic [31:0] as_a, as_b, ms_a, ms_b, ap_a, ap_b, mp_a, mp_b, as_y, ms_y, ap_y, mp_y, rcp_b, rcp_y;
  logic        as_sub, ap_sub, as_x, ms_x, ap_x, mp_x, rcp_start, rcp_done, rcp_x, rcp_busy;
  fp_add_pipe #(L) u_as (.clk, .ce(1'b1), .a(as_a), .b(as_b), .sub(as_sub), .y(as_y), .exc(as_x));
  fp_mul_pipe #(L) u_ms (.clk, .ce(1'b1), .a(ms_a), .b(ms_b), .y(ms_y), .exc(ms_x));
  fp_add_pipe #(L) u_ap (.clk, .ce(1'b1), .a(ap_a), .b(ap_b), .sub(ap_sub), .y(ap_y), .exc(ap_x));
  fp_mul_pipe #(L) u_mp (.clk, .ce(1'b1), .a(mp_a), .b(mp_b), .y(mp_y), .exc(mp_x));
  fp_rcp_iter u_rcp (.clk, .ce(1'b1), .rst, .start(rcp_start), .a(F_ONE), .b(rcp_b), .done(rcp_done), .y(rcp_y), .exc(rcp_x), .busy(rcp_busy));

  // ---- per-edge-job / per-scanline values ----
  logic [7:0] c;                            // cycle within the current job (before the reciprocal)
  logic [7:0] ec;                           // cycle after the reciprocal completed
  logic       post;                         // reciprocal done, in the post phase
  logic [31:0] j_dy, j_dx, j_dp [4], j_ooy;
  logic       j_x;
  // scanline operands (latched at S_SPREP) and intermediates
  logic [31:0] fully, Lx, Ly, Rx, Ry, Ldxdy, Rdxdy, Lp [4], Rp [4], Ldp [4], Rdp [4];
  logic [31:0] ldy, rdy, lt, rt, sx, ex, dsx, ixf, ixh, w, oox, lm [4], rm [4], lp [4], rp [4], dd [4], dpdx [4], wm [4], stv [4];
  logic signed [31:0] istartx, istopx;
  logic       sexc;
  logic       l_is_f; logic [1:0] li, ri;

  // exact fully = float(curscan) + 0.5 via i2f(2c+1) with exponent - 1 (see header)
  function automatic logic [31:0] fully_of(input logic signed [31:0] cs);
    fres_t r; r = fp_i2f(cs * 2 + 32'sd1);
    return {r.v[31], r.v[30:23] - 8'd1, r.v[22:0]};
  endfunction

  // edge-advance (poly.h:1231-1234) evaluated combinationally over <= 3 steps
  function automatic logic [1:0] advance(input logic sd, input logic [1:0] i0, input logic [31:0] fy);
    logic [1:0] i; logic go; i = i0; go = 1'b1;
    for (int k = 0; k < 3; k++)
      if (go && fp_gt(fy, v[e_v2[sd][i]][1]) && fp_lt(fy, v[maxv][1])) i = i + 2'd1; else go = 1'b0;
    return i;
  endfunction

  // ---- op issue (combinational from state/cycle) ----
  always_comb begin
    as_a = '0; as_b = '0; as_sub = 1'b0; ms_a = '0; ms_b = '0; ap_a = '0; ap_b = '0; ap_sub = 1'b0; mp_a = '0; mp_b = '0;
    rcp_start = 1'b0; rcp_b = '0;
    if (st == S_ERUN) begin
      if (!post) begin
        if (c == 0) begin as_a = v[j_v2[jb]][1]; as_b = v[j_v1[jb]][1]; as_sub = 1'b1; end                // dy
        if (c == 1) begin as_a = v[j_v2[jb]][0]; as_b = v[j_v1[jb]][0]; as_sub = 1'b1; end                // dx
        for (int p = 0; p < 4; p++)
          if (c == 8'(p)) begin ap_a = v[j_v2[jb]][2 + p]; ap_b = v[j_v1[jb]][2 + p]; ap_sub = 1'b1; end    // dp
        if (c == 8'(L)) begin rcp_start = 1'b1; rcp_b = as_y; end                                         // ooy
      end else begin
        if (ec == 0) begin ms_a = j_dx; ms_b = j_ooy; end                                                 // dxdy
        for (int p = 0; p < 4; p++) if (ec == 8'(p)) begin mp_a = j_dp[p]; mp_b = j_ooy; end              // dpdy
      end
    end else if (st == S_SRUN) begin
      if (!post) begin
        if (c == 0) begin as_a = fully; as_b = Ly; as_sub = 1'b1; end                                     // ldy
        if (c == 1) begin as_a = fully; as_b = Ry; as_sub = 1'b1; end                                     // rdy
        if (c == 8'(L))     begin ms_a = as_y; ms_b = Ldxdy; end                                          // lt
        if (c == 8'(L + 1)) begin ms_a = as_y; ms_b = Rdxdy; end                                          // rt
        for (int p = 0; p < 4; p++) begin
          if (c == 8'(L + p))         begin mp_a = (p == 0) ? as_y : ldy; mp_b = Ldp[p]; end              // lm (ldy forwarded at c == L)
          if (c == 8'(L + 4 + p))     begin mp_a = rdy; mp_b = Rdp[p]; end                                // rm
          if (c == 8'(2*L + p))       begin ap_a = Lp[p]; ap_b = mp_y; end                                // lp
          if (c == 8'(2*L + 4 + p))   begin ap_a = Rp[p]; ap_b = mp_y; end                                // rp
          if (c == 8'(D0 + p))        begin ap_a = rp[p]; ap_b = lp[p]; ap_sub = 1'b1; end                // d
        end
        if (c == 8'(2*L))     begin as_a = Lx; as_b = ms_y; end                                           // sx
        if (c == 8'(2*L + 1)) begin as_a = Rx; as_b = ms_y; end                                           // ex
        if (c == 8'(3*L + 1)) begin as_a = as_y; as_b = sx; as_sub = 1'b1; end                            // dsx = ex - sx
        if (c == 8'(3*L + 3)) begin as_a = ixf; as_b = F_HALF; end                                        // ixh
        if (c == 8'(4*L + 1)) begin rcp_start = 1'b1; rcp_b = as_y; end                                   // oox
        if (c == 8'(4*L + 3)) begin as_a = as_y; as_b = sx; as_sub = 1'b1; end                            // w = ixh - sx
      end else begin
        for (int p = 0; p < 4; p++) begin
          if (ec == 8'(p))          begin mp_a = dd[p]; mp_b = oox; end                                   // dpdx
          if (ec == 8'(W0 + p))     begin mp_a = w; mp_b = dpdx[p]; end                                   // wm
          if (ec == 8'(W0 + L + p)) begin ap_a = lp[p]; ap_b = mp_y; end                                  // st
        end
      end
    end
  end

  assign busy = (st != S_IDLE);

  always_ff @(posedge clk) begin
    done <= 1'b0;
    if (rst) begin st <= S_IDLE; ext_valid <= 1'b0; rejected <= 1'b0; post <= 1'b0; end
    else case (st)
      S_IDLE: if (start) begin
        v <= vin; cminx <= clip_min_x; cmaxx <= clip_max_x; cminy <= clip_min_y; cmaxy <= clip_max_y;
        rejected <= 1'b0; st <= S_MINMAX;
      end
      S_MINMAX: begin : mm
        logic [1:0] mn, mx; mn = 2'd0; mx = 2'd0;
        for (int k = 1; k < 4; k++) begin
          if (fp_lt(v[k][1], v[mn][1])) mn = 2'(k);
          else if (fp_gt(v[k][1], v[mx][1])) mx = 2'(k);
        end
        minv <= mn; maxv <= mx; st <= S_YCLIP;
      end
      S_YCLIP: begin : yc
        logic signed [31:0] mny, mxy, a, b; logic e1, e2;
        mny = fp_round_coord(v[minv][1], e1); mxy = fp_round_coord(v[maxv][1], e2);
        a = (mny > cminy) ? mny : cminy; b = (mxy < cmaxy + 32'sd1) ? mxy : cmaxy + 32'sd1;
        minyclip <= a; maxyclip <= b;
        if (b - a <= 32'sd0) begin rejected <= 1'b1; st <= S_DONE; end
        else begin side <= 1'b0; cv <= minv; e_cnt[0] <= 2'd0; e_cnt[1] <= 2'd0; nj <= 3'd0; st <= S_EBUILD; end
      end
      // build the edge jobs: walk each list, skip horizontal edges (float ==), one step per clock
      S_EBUILD: begin
        if (cv == maxv) begin
          if (side == 1'b0) begin side <= 1'b1; cv <= minv; end
          else begin jb <= 3'd0; c <= '0; post <= 1'b0; st <= (nj == 3'd0) ? S_LR : S_ERUN; end
        end else begin
          if (!fp_eq(v[cv][1], v[nextv(side, cv)][1])) begin
            j_side[nj[1:0]] <= side; j_idx[nj[1:0]] <= e_cnt[side]; j_v1[nj[1:0]] <= cv; j_v2[nj[1:0]] <= nextv(side, cv);
            e_v1[side][e_cnt[side]] <= cv; e_v2[side][e_cnt[side]] <= nextv(side, cv);
            e_cnt[side] <= e_cnt[side] + 2'd1; nj <= nj + 3'd1;
          end
          cv <= nextv(side, cv);
        end
      end
      // one edge job: dy, dx, dp[4] -> ooy = 1/dy -> dxdy, dpdy[4]  (poly.h:1162-1165 / 1183-1186)
      S_ERUN: begin
        if (!post) begin
          c <= c + 8'd1;
          if (c == 8'(L)) begin j_dy <= as_y; j_x <= as_x; end
          if (c == 8'(L + 1)) begin j_dx <= as_y; if (as_x) j_x <= 1'b1; end
          for (int p = 0; p < 4; p++) if (c == 8'(L + p)) begin j_dp[p] <= ap_y; if (ap_x) j_x <= 1'b1; end
          if (rcp_done) begin j_ooy <= rcp_y; if (rcp_x) j_x <= 1'b1; post <= 1'b1; ec <= '0; end
        end else begin
          ec <= ec + 8'd1;
          if (ec == 8'(L)) begin e_dxdy[j_side[jb[1:0]]][j_idx[jb[1:0]]] <= ms_y; if (ms_x) j_x <= 1'b1; end
          for (int p = 0; p < 4; p++) if (ec == 8'(L + p)) begin e_dpdy[j_side[jb[1:0]]][j_idx[jb[1:0]]][p] <= mp_y; if (mp_x) j_x <= 1'b1; end
          if (ec == 8'(L + 4)) begin
            e_exc[j_side[jb[1:0]]][j_idx[jb[1:0]]] <= j_x;
            post <= 1'b0; c <= '0;
            if (jb + 3'd1 == nj) st <= S_LR; else jb <= jb + 3'd1;
          end
        end
      end
      S_LR: begin
        if ((e_v1[0][0] == e_v1[1][0] && fp_lt(e_dxdy[0][0], e_dxdy[1][0])) ||
            (e_v1[0][0] != e_v1[1][0] && fp_lt(v[e_v1[0][0]][0], v[e_v1[1][0]][0]))) l_is_f <= 1'b1;
        else l_is_f <= 1'b0;
        li <= 2'd0; ri <= 2'd0; curscan <= minyclip; st <= S_SPREP;
      end
      // scanline prep: fully, edge advance, latch the left/right edge operands
      S_SPREP: begin : sp
        logic [31:0] fy; logic [1:0] nli, nri; logic ls, rs;
        if (curscan >= maxyclip) st <= S_DONE;
        else begin
          fy = fully_of(curscan);
          ls = l_is_f ? 1'b0 : 1'b1; rs = ~ls;
          nli = advance(ls, li, fy); nri = advance(rs, ri, fy);
          li <= nli; ri <= nri; fully <= fy;
          Lx <= v[e_v1[ls][nli]][0]; Ly <= v[e_v1[ls][nli]][1]; Ldxdy <= e_dxdy[ls][nli];
          Rx <= v[e_v1[rs][nri]][0]; Ry <= v[e_v1[rs][nri]][1]; Rdxdy <= e_dxdy[rs][nri];
          for (int p = 0; p < 4; p++) begin
            Lp[p] <= v[e_v1[ls][nli]][2 + p]; Ldp[p] <= e_dpdy[ls][nli][p];
            Rp[p] <= v[e_v1[rs][nri]][2 + p]; Rdp[p] <= e_dpdy[rs][nri][p];
          end
          sexc <= e_exc[ls][nli] | e_exc[rs][nri];
          c <= '0; post <= 1'b0; st <= S_SRUN;
        end
      end
      S_SRUN: begin
        if (!post) begin
          c <= c + 8'd1;
          if (c == 8'(L))     begin ldy <= as_y; if (as_x) sexc <= 1'b1; end
          if (c == 8'(L + 1)) begin rdy <= as_y; if (as_x) sexc <= 1'b1; end
          if (c == 8'(2*L))     begin lt <= ms_y; if (ms_x) sexc <= 1'b1; end
          if (c == 8'(2*L + 1)) begin rt <= ms_y; if (ms_x) sexc <= 1'b1; end
          if (c == 8'(3*L))     begin sx <= as_y; if (as_x) sexc <= 1'b1; end
          if (c == 8'(3*L + 1)) begin : rnd                                   // ex captured; round/order/clip (:1239-1251)
            logic signed [31:0] a, b; logic e1, e2;
            ex <= as_y; if (as_x) sexc <= 1'b1;
            a = fp_round_coord(sx, e1); b = fp_round_coord(as_y, e2);
            if (e1 | e2) sexc <= 1'b1;
            if (a > b) begin logic signed [31:0] t; t = a; a = b; b = t; end
            if (a < cminx) a = cminx;
            if (b > cmaxx + 32'sd1) b = cmaxx + 32'sd1;
            istartx <= a; istopx <= b;
          end
          if (c == 8'(3*L + 2)) begin : i2f                                   // ixf = float(istartx)
            fres_t r; r = fp_i2f(istartx); ixf <= r.v; if (r.exc) sexc <= 1'b1;
          end
          if (c == 8'(4*L + 1)) begin dsx <= as_y; if (as_x) sexc <= 1'b1; end
          if (c == 8'(4*L + 3)) begin ixh <= as_y; if (as_x) sexc <= 1'b1; end
          if (c == 8'(5*L + 3)) begin w <= as_y; if (as_x) sexc <= 1'b1; end
          for (int p = 0; p < 4; p++) begin
            if (c == 8'(2*L + p))     begin lm[p] <= mp_y; if (mp_x) sexc <= 1'b1; end
            if (c == 8'(2*L + 4 + p)) begin rm[p] <= mp_y; if (mp_x) sexc <= 1'b1; end
            if (c == 8'(3*L + p))     begin lp[p] <= ap_y; if (ap_x) sexc <= 1'b1; end
            if (c == 8'(3*L + 4 + p)) begin rp[p] <= ap_y; if (ap_x) sexc <= 1'b1; end
            if (c == 8'(D0 + L + p))  begin dd[p] <= ap_y; if (ap_x) sexc <= 1'b1; end
          end
          if (rcp_done) begin oox <= rcp_y; if (rcp_x) sexc <= 1'b1; post <= 1'b1; ec <= '0; end
        end else begin
          ec <= ec + 8'd1;
          for (int p = 0; p < 4; p++) begin
            if (ec == 8'(L + p))          begin dpdx[p] <= mp_y; if (mp_x) sexc <= 1'b1; end
            if (ec == 8'(W0 + L + p))     begin wm[p] <= mp_y; if (mp_x) sexc <= 1'b1; end
            if (ec == 8'(W0 + 2*L + p))   begin stv[p] <= ap_y; if (ap_x) sexc <= 1'b1; end
          end
          if (ec == 8'(E_LAST)) st <= S_EMIT;
        end
      end
      S_EMIT: begin
        if (!ext_valid) begin
          ext_valid <= 1'b1; ext_scan <= curscan;
          if (istartx >= istopx) begin ext_startx <= 16'sd0; ext_stopx <= 16'sd0; end
          else begin ext_startx <= 16'(istartx); ext_stopx <= 16'(istopx); end
          ext_start <= stv; ext_dpdx <= dpdx; ext_exc <= sexc;
        end else if (ext_ready) begin
          ext_valid <= 1'b0; curscan <= curscan + 32'sd1; st <= S_SPREP;
        end
      end
      S_DONE: begin done <= 1'b1; st <= S_IDLE; end
      default: st <= S_IDLE;
    endcase
  end
endmodule
