// Streaming gate for zr_setup5 (polygons overlap): polygons are offered whenever in_ready is high; the extent stream is
// compared IN ORDER with zr1's taps concatenated over every polygon (rejected polygons contribute none, and must each
// raise one `rejected` pulse). Contract as tb_zr_setup.cpp: scanline + x span on every extent, params bit-exact on
// every non-empty extent, no exc on a non-empty extent.
#include "Vzr_setup.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>

static std::vector<uint32_t> load(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    std::vector<uint32_t> v(n / 4); if (fread(v.data(), 4, v.size(), f) != v.size()) exit(2); fclose(f); return v;
}
struct Ext { long poly; int32_t scan; const uint32_t* w; };

int main(int argc, char** argv) {
    if (argc < 2) { printf("usage: tb_zr_setup_stream <tapdir> [max-polys]\n"); return 2; }
    std::vector<uint32_t> in = load(std::string(argv[1]) + "/setup_in.bin"), out = load(std::string(argv[1]) + "/setup_out.bin");
    long np = (long)(in.size() / 30); if (argc > 2 && atol(argv[2]) < np) np = atol(argv[2]);
    // expected extent stream
    std::vector<Ext> exp; long exp_rej = 0; size_t o = 0;
    for (long k = 0; k < np; k++) {
        if (out[o] != 0x5A534F31) { printf("FAIL: tap framing at polygon %ld\n", k); return 2; }
        uint32_t n = out[o + 1]; int32_t miny = (int32_t)out[o + 2]; o += 3;
        if (n == 0) exp_rej++;
        for (uint32_t s = 0; s < n; s++) exp.push_back({k, miny + (int32_t)s, &out[o + 9 * s]});
        o += 9 * n;
    }
    Verilated::commandArgs(argc, argv);
    Vzr_setup* t = new Vzr_setup;
    t->rst = 1; t->start = 0; t->ext_ready = 1;
    for (int i = 0; i < 3; i++) { t->clk = 0; t->eval(); t->clk = 1; t->eval(); }
    t->rst = 0;
    long fed = 0, got = 0, rej = 0, fails = 0, used = 0, exc_unused = 0; unsigned long long clocks = 0, idle_guard = 0;
    while (true) {
        t->clk = 0;
        // offer the next polygon
        if (fed < np) {
            const uint32_t* r = &in[30 * fed];
            t->clip_min_x = r[2]; t->clip_max_x = r[3]; t->clip_min_y = r[4]; t->clip_max_y = r[5];
            for (int vi = 0; vi < 4; vi++) for (int c = 0; c < 6; c++) t->vin[vi][c] = r[6 + 6 * vi + c];
        }
        t->eval();
        bool take = fed < np && t->in_ready;
        t->start = take ? 1 : 0;
        t->eval();
        if (t->ext_valid && t->ext_ready) {
            if ((size_t)got >= exp.size()) { if (fails++ < 20) printf("FAIL: extra extent scan %d\n", (int)t->ext_scan); }
            else {
                const Ext& e = exp[got]; const uint32_t* w = e.w;
                int16_t sx = (int16_t)(w[0] & 0xffff), ex = (int16_t)(w[0] >> 16);
                bool ok = (int32_t)t->ext_scan == e.scan && t->ext_startx == sx && t->ext_stopx == ex;
                if (sx < ex) {
                    used++;
                    for (int p = 0; p < 4; p++) ok = ok && t->ext_start[p] == w[1 + 2 * p] && t->ext_dpdx[p] == w[2 + 2 * p];
                    if (t->ext_exc) ok = false;
                } else if (t->ext_exc) exc_unused++;
                if (!ok && fails++ < 20) {
                    printf("FAIL extent #%ld (poly %ld scan %d): rtl scan %d x %d..%d exc %u, zr1 x %d..%d\n", got, e.poly, e.scan,
                           (int)t->ext_scan, (int)t->ext_startx, (int)t->ext_stopx, t->ext_exc, sx, ex);
                    for (int p = 0; p < 4; p++) printf("   p%d start rtl %08X zr1 %08X  dpdx rtl %08X zr1 %08X\n", p, t->ext_start[p], w[1 + 2 * p], t->ext_dpdx[p], w[2 + 2 * p]);
                }
            }
            got++;
        }
        t->clk = 1; t->eval(); clocks++;
        if (t->rejected) rej++;
        if (take) fed++;
        if (t->hazard) { printf("FAIL: slot ownership hazard (a write hit a slot A still owns) at clock %llu\n", clocks); return 1; }
        if (fed == np && (size_t)got == exp.size() && t->idle) break;
        if (++idle_guard > 400000000ull) { printf("FAIL: no progress (fed %ld/%ld, extents %ld/%zu)\n", fed, np, got, exp.size()); return 1; }
    }
    if (rej != exp_rej && fails++ < 20) printf("FAIL: rejected pulses %ld, expected %ld\n", rej, exp_rej);
    printf("SUMMARY polygons %ld (rejected %ld) extents %ld used %ld exc_on_unused %ld clocks %llu (%.1f per extent)\n",
           np, rej, got, used, exc_unused, clocks, got ? (double)clocks / got : 0.0);
    printf("UTIL clocks %u front-end %u (%.1f%%) phaseA %u (%.1f%%) phaseB %u (%.1f%%)\n", t->st_clk, t->st_fe,
           t->st_clk ? 100.0 * t->st_fe / t->st_clk : 0.0, t->st_a, t->st_clk ? 100.0 * t->st_a / t->st_clk : 0.0,
           t->st_b, t->st_clk ? 100.0 * t->st_b / t->st_clk : 0.0);
    printf("%s\n", fails ? "FAIL" : "PASS: the whole extent stream matches zr1 in order (range + x span on all, params bit-exact on all used)");
    delete t; return fails ? 1 : 0;
}
