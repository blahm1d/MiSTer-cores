// zr_setup3_flat.sv -- packed-port wrapper of zr_setup3 for the standalone unit fit (make_unit_fit.py parses packed
// ports only). No logic.
module zr_setup3_flat (
  input  logic         clk,
  input  logic         rst,
  input  logic         start,
  input  logic [767:0] vin_flat,                 // vertex i, field f at [(i*6+f)*32 +: 32]
  input  logic signed [31:0] clip_min_x, clip_max_x, clip_min_y, clip_max_y,
  output logic         busy, done, rejected, ext_valid,
  input  logic         ext_ready,
  output logic signed [31:0] ext_scan,
  output logic signed [15:0] ext_startx, ext_stopx,
  output logic [127:0] ext_start_flat, ext_dpdx_flat,
  output logic         ext_exc
);
  logic [31:0] vin [4][6];
  logic [31:0] es [4], ed [4];
  always_comb for (int i = 0; i < 4; i++) for (int f = 0; f < 6; f++) vin[i][f] = vin_flat[(i*6 + f)*32 +: 32];
  always_comb for (int p = 0; p < 4; p++) begin ext_start_flat[p*32 +: 32] = es[p]; ext_dpdx_flat[p*32 +: 32] = ed[p]; end
  zr_setup3 u (.clk, .rst, .start, .vin, .clip_min_x, .clip_max_x, .clip_min_y, .clip_max_y,
    .busy, .done, .rejected, .ext_valid, .ext_ready, .ext_scan, .ext_startx, .ext_stopx,
    .ext_start(es), .ext_dpdx(ed), .ext_exc);
endmodule
