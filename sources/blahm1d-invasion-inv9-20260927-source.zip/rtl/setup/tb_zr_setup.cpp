// Gate for zr_setup: every polygon zr1 handed to render_polygon<4,4> in the MK4 fight window (setup_in.bin), driven
// through the RTL; every extent compared with zr1's (setup_out.bin). Contract (ARCHITECTURE-MK4.md R2): scanline range,
// startx and stopx on EVERY extent; the 4 x (start, dpdx) float bit patterns on every NON-EMPTY extent (render_poly
// never reads the params of an empty one, midzeus_v.cpp:1250); ext_exc must be 0 on every non-empty extent.
#include "Vzr_setup.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>

static std::vector<uint32_t> load(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    std::vector<uint32_t> v(n / 4); if (fread(v.data(), 4, v.size(), f) != v.size()) exit(2); fclose(f); return v;
}

int main(int argc, char** argv) {
    if (argc < 2) { printf("usage: tb_zr_setup <tapdir> [max-polys]\n"); return 2; }
    std::vector<uint32_t> in = load(std::string(argv[1]) + "/setup_in.bin"), out = load(std::string(argv[1]) + "/setup_out.bin");
    long maxp = argc > 2 ? atol(argv[2]) : (long)(in.size() / 30);
    Verilated::commandArgs(argc, argv);
    Vzr_setup* t = new Vzr_setup;
    auto tick = [&]() { t->clk = 0; t->eval(); t->clk = 1; t->eval(); };
    t->rst = 1; t->start = 0; t->ext_ready = 1; tick(); tick(); t->rst = 0; tick();
    size_t o = 0; long polys = 0, rejected = 0, exts = 0, used = 0, fails = 0, exc_unused = 0;
    uint64_t clocks = 0;
    for (long k = 0; k < maxp && (size_t)(30 * k) < in.size(); k++) {
        const uint32_t* r = &in[30 * k];
        if (r[0] != 0x5A534931 || out[o] != 0x5A534F31) { printf("FAIL: tap framing at polygon %ld\n", k); return 2; }
        uint32_t nscan = out[o + 1]; int32_t miny = (int32_t)out[o + 2]; o += 3;
        t->clip_min_x = r[2]; t->clip_max_x = r[3]; t->clip_min_y = r[4]; t->clip_max_y = r[5];
        for (int vi = 0; vi < 4; vi++) for (int c = 0; c < 6; c++) t->vin[vi][c] = r[6 + 6 * vi + c];
        t->start = 1; tick(); clocks++; t->start = 0;
        uint32_t got = 0; bool done = false; long guard = 0;
        while (!done) {
            t->clk = 0; t->eval();
            if (t->ext_valid && t->ext_ready) {
                if (got >= nscan) { if (fails++ < 20) printf("FAIL poly %ld: extra extent at scan %d\n", k, (int)t->ext_scan); }
                else {
                    const uint32_t* e = &out[o + 9 * got];
                    int16_t sx = (int16_t)(e[0] & 0xffff), ex = (int16_t)(e[0] >> 16);
                    bool ok = (int32_t)t->ext_scan == miny + (int32_t)got && t->ext_startx == sx && t->ext_stopx == ex;
                    bool isused = sx < ex;
                    if (isused) {
                        used++;
                        for (int p = 0; p < 4; p++) ok = ok && t->ext_start[p] == e[1 + 2 * p] && t->ext_dpdx[p] == e[2 + 2 * p];
                        if (t->ext_exc) ok = false;
                    } else if (t->ext_exc) exc_unused++;
                    if (!ok && fails++ < 20) {
                        printf("FAIL poly %ld scan %d (#%u): rtl x %d..%d exc %u, zr1 x %d..%d%s\n", k, (int)t->ext_scan, got,
                               (int)t->ext_startx, (int)t->ext_stopx, t->ext_exc, sx, ex, isused ? " (used)" : "");
                        for (int p = 0; p < 4; p++) printf("   p%d start rtl %08X zr1 %08X  dpdx rtl %08X zr1 %08X\n", p, t->ext_start[p], e[1 + 2 * p], t->ext_dpdx[p], e[2 + 2 * p]);
                    }
                }
                got++; exts++;
            }
            t->clk = 1; t->eval(); clocks++;
            if (t->done) { done = true; if (t->rejected) rejected++; }
            if (++guard > 1000000) { printf("FAIL: poly %ld hung\n", k); return 1; }
        }
        if (got != nscan && fails++ < 20) printf("FAIL poly %ld: rtl %u extents, zr1 %u\n", k, got, nscan);
        o += 9 * nscan; polys++;
    }
    printf("SUMMARY polygons %ld (rejected %ld) extents %ld used %ld exc_on_unused %ld clocks %llu (%.1f per extent)\n",
           polys, rejected, exts, used, exc_unused, (unsigned long long)clocks, exts ? (double)clocks / exts : 0.0);
    printf("%s\n", fails ? "FAIL" : "PASS: every extent matches zr1 (range + x span on all, params bit-exact on all used)");
    delete t; return fails ? 1 : 0;
}
