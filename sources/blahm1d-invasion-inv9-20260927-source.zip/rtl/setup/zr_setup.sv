// zr_setup.sv -- Zeus 1 polygon setup engine, v1 (functional: one IEEE op per clock). Lane zeus/zeus1/rtl/setup.
//
// Transcribed from MAME master 61c79406 src/devices/video/poly.h (copy in zeus/references/mame-master):
// render_polygon<4, 4> (:1104-1291) and round_coordinate (:368-381), with NumVerts = 4 and ParamCount = 4 as
// midzeus_v.cpp:1218 instantiates them. Float semantics: fp32_pkg (IEEE binary32 RNE, bit-exact to x86 SSE on the
// renderer's value classes). Every IEEE op below is ONE rounding step in the source's evaluation order (no fusion).
//
// Interface: load one polygon (4 vertices x {x, y, p0..p3} as float bits + cliprect) with `start`; the engine emits one
// extent per clipped scanline in scanline order (ext_valid/ext_ready), then `done` (rejected = no scanline survives the
// y clip). `ext_exc` marks an extent whose computation left the fp32 contract (inf/NaN/denormal): allowed ONLY on
// extents with startx >= stopx, whose params render_poly never reads (midzeus_v.cpp:1250) -- the gate enforces that.
//
// v1 is a sequential reference for the operation ORDER. It needs ~55 clocks per scanline (> the 50 MHz frame budget,
// ARCHITECTURE-MK4.md R1); v2 splits the four parameter lanes.
module zr_setup
  import fp32_pkg::*;
(
  input  logic        clk,
  input  logic        rst,
  input  logic        start,
  input  logic [31:0] vin [4][6],          // per vertex: x, y, p0, p1, p2, p3 (float bits)
  input  logic signed [31:0] clip_min_x, clip_max_x, clip_min_y, clip_max_y,
  output logic        busy,
  output logic        done,                // one-clock pulse after the last extent (or the rejection)
  output logic        rejected,            // with done: maxyclip - minyclip <= 0
  output logic        ext_valid,
  input  logic        ext_ready,
  output logic signed [31:0] ext_scan,
  output logic signed [15:0] ext_startx, ext_stopx,
  output logic [31:0] ext_start [4],
  output logic [31:0] ext_dpdx  [4],
  output logic        ext_exc
);
  localparam logic [31:0] F_ONE = 32'h3f800000, F_HALF = 32'h3f000000;

  typedef enum logic [5:0] {
    S_IDLE, S_MINMAX, S_YCLIP,
    S_E_INIT, S_E_CHK, S_E_DY, S_E_OOY, S_E_DX, S_E_DXDY, S_E_DP, S_E_DPDY, S_E_NEXT,
    S_LR, S_SCAN, S_FULLY_I, S_FULLY, S_ADV_L, S_ADV_R,
    S_LDY, S_LT, S_SX, S_RDY, S_RT, S_TX, S_ROUND, S_CLAMP,
    S_DX, S_OOX, S_P_LM, S_P_LA, S_P_RM, S_P_RA, S_P_D, S_P_DPDX, S_P_IX, S_P_IXH, S_P_W, S_P_WM, S_P_ST,
    S_EMIT, S_DONE
  } st_t;
  st_t st;

  logic [31:0] v [4][6];
  logic signed [31:0] cminx, cmaxx, cminy, cmaxy;
  logic [1:0] minv, maxv;
  logic signed [31:0] minyclip, maxyclip, curscan;
  // edges: side 0 = forward (fedgelist), side 1 = backward (bedgelist); up to 3 each
  logic [1:0] e_v1 [2][3], e_v2 [2][3];
  logic [31:0] e_dxdy [2][3];
  logic [31:0] e_dpdy [2][3][4];
  logic       e_exc [2][3];
  logic [1:0] e_cnt [2];
  logic       side;                          // edge list being built
  logic [1:0] cv;                            // curv while building
  logic [31:0] t_dy, t_ooy, t_dx, t_dp;
  logic [2:0] pi;                            // parameter index
  logic       l_is_f;                        // ledge list = forward?
  logic [1:0] li, ri;                        // current ledge / redge index into their lists
  logic [31:0] fully, ldy, rdy, lt, rt, startx, stopx, dsx, oox;
  logic signed [31:0] istartx, istopx;
  logic [31:0] lparam, rparam, dpdxv, ixf, ixh, wv;
  logic        sexc;                         // scanline exc accumulator
  logic [31:0] o_start [4], o_dpdx [4];

  // convenience views of the current edges
  logic [1:0] lv1, lv2, rv1, rv2;
  assign lv1 = e_v1[l_is_f ? 0 : 1][li]; assign lv2 = e_v2[l_is_f ? 0 : 1][li];
  assign rv1 = e_v1[l_is_f ? 1 : 0][ri]; assign rv2 = e_v2[l_is_f ? 1 : 0][ri];
  logic [31:0] ldxdy, rdxdy; logic lexc, rexc;
  assign ldxdy = e_dxdy[l_is_f ? 0 : 1][li]; assign rdxdy = e_dxdy[l_is_f ? 1 : 0][ri];
  assign lexc = e_exc[l_is_f ? 0 : 1][li];   assign rexc = e_exc[l_is_f ? 1 : 0][ri];

  // the next vertex along the list being built (forward: +1 wrapping, backward: -1 wrapping)
  function automatic logic [1:0] nextv(input logic sd, input logic [1:0] c);
    return sd ? c - 2'd1 : c + 2'd1;   // 2-bit wrap = (NumVerts == 4)
  endfunction

  fres_t r;          // op result scratch
  logic  rexc_c;
  logic signed [31:0] rc_min, rc_max; logic rc_e1, rc_e2;

  assign busy = (st != S_IDLE);

  always_ff @(posedge clk) begin
    done <= 1'b0;
    if (rst) begin
      st <= S_IDLE; ext_valid <= 1'b0; rejected <= 1'b0;
    end else begin
      case (st)
        S_IDLE: if (start) begin
          v <= vin; cminx <= clip_min_x; cmaxx <= clip_max_x; cminy <= clip_min_y; cmaxy <= clip_max_y;
          rejected <= 1'b0; st <= S_MINMAX;
        end
        // :1107-1119 min/max Y vertices (the else-if chain is order dependent)
        S_MINMAX: begin : mm
          logic [1:0] mn, mx;
          mn = 2'd0; mx = 2'd0;
          for (int k = 1; k < 4; k++) begin
            if (fp_lt(v[k][1], v[mn][1])) mn = 2'(k);
            else if (fp_gt(v[k][1], v[mx][1])) mx = 2'(k);
          end
          minv <= mn; maxv <= mx; st <= S_YCLIP;
        end
        // :1122-1134
        S_YCLIP: begin : yc
          logic signed [31:0] mny, mxy, a, b;
          mny = fp_round_coord(v[minv][1], rc_e1);
          mxy = fp_round_coord(v[maxv][1], rc_e2);
          a = (mny > cminy) ? mny : cminy;
          b = (mxy < cmaxy + 32'sd1) ? mxy : cmaxy + 32'sd1;
          minyclip <= a; maxyclip <= b;
          if (b - a <= 32'sd0) begin rejected <= 1'b1; st <= S_DONE; end
          else begin side <= 1'b0; cv <= minv; e_cnt[0] <= 2'd0; e_cnt[1] <= 2'd0; st <= S_E_INIT; end
        end
        // :1139-1188 edge lists. S_E_INIT: loop test curv != maxv
        S_E_INIT: begin
          if (cv == maxv) begin
            if (side == 1'b0) begin side <= 1'b1; cv <= minv; end
            else st <= S_LR;
          end else st <= S_E_CHK;
        end
        S_E_CHK: begin   // horizontal edge -> skip (float ==)
          if (fp_eq(v[cv][1], v[nextv(side, cv)][1])) begin cv <= nextv(side, cv); st <= S_E_INIT; end
          else begin
            e_v1[side][e_cnt[side]] <= cv; e_v2[side][e_cnt[side]] <= nextv(side, cv);
            e_exc[side][e_cnt[side]] <= 1'b0;
            st <= S_E_DY;
          end
        end
        S_E_DY:   begin r = fp_add(v[nextv(side, cv)][1], {~v[cv][1][31], v[cv][1][30:0]}); t_dy <= r.v; if (r.exc) e_exc[side][e_cnt[side]] <= 1'b1; st <= S_E_OOY; end
        S_E_OOY:  begin r = fp_div(F_ONE, t_dy); t_ooy <= r.v; if (r.exc) e_exc[side][e_cnt[side]] <= 1'b1; st <= S_E_DX; end
        S_E_DX:   begin r = fp_add(v[nextv(side, cv)][0], {~v[cv][0][31], v[cv][0][30:0]}); t_dx <= r.v; if (r.exc) e_exc[side][e_cnt[side]] <= 1'b1; st <= S_E_DXDY; end
        S_E_DXDY: begin r = fp_mul(t_dx, t_ooy); e_dxdy[side][e_cnt[side]] <= r.v; if (r.exc) e_exc[side][e_cnt[side]] <= 1'b1; pi <= 3'd0; st <= S_E_DP; end
        S_E_DP:   begin r = fp_add(v[nextv(side, cv)][2 + pi], {~v[cv][2 + pi][31], v[cv][2 + pi][30:0]}); t_dp <= r.v; if (r.exc) e_exc[side][e_cnt[side]] <= 1'b1; st <= S_E_DPDY; end
        S_E_DPDY: begin
          r = fp_mul(t_dp, t_ooy); e_dpdy[side][e_cnt[side]][pi[1:0]] <= r.v; if (r.exc) e_exc[side][e_cnt[side]] <= 1'b1;
          if (pi == 3'd3) st <= S_E_NEXT; else begin pi <= pi + 3'd1; st <= S_E_DP; end
        end
        S_E_NEXT: begin e_cnt[side] <= e_cnt[side] + 2'd1; cv <= nextv(side, cv); st <= S_E_INIT; end
        // :1193-1204 left/right: first vertex shared -> compare slopes, else compare first-vertex X
        S_LR: begin
          if ((e_v1[0][0] == e_v1[1][0] && fp_lt(e_dxdy[0][0], e_dxdy[1][0])) ||
              (e_v1[0][0] != e_v1[1][0] && fp_lt(v[e_v1[0][0]][0], v[e_v1[1][0]][0]))) l_is_f <= 1'b1;
          else l_is_f <= 1'b0;
          li <= 2'd0; ri <= 2'd0; curscan <= minyclip; st <= S_SCAN;
        end
        // ---- per scanline (:1210-1282, SCANLINES_PER_BUCKET chunking does not change the arithmetic) ----
        S_SCAN: begin if (curscan >= maxyclip) st <= S_DONE; else st <= S_FULLY_I; end
        S_FULLY_I: begin r = fp_i2f(curscan); fully <= r.v; sexc <= r.exc; st <= S_FULLY; end
        S_FULLY:   begin r = fp_add(fully, F_HALF); fully <= r.v; if (r.exc) sexc <= 1'b1; st <= S_ADV_L; end
        // :1231-1234 advance while fully > edge.v2.y && fully < v[maxv].y
        S_ADV_L: if (fp_gt(fully, v[lv2][1]) && fp_lt(fully, v[maxv][1])) li <= li + 2'd1; else st <= S_ADV_R;
        S_ADV_R: if (fp_gt(fully, v[rv2][1]) && fp_lt(fully, v[maxv][1])) ri <= ri + 2'd1; else st <= S_LDY;
        // startx = l.v1.x + (fully - l.v1.y) * l.dxdy ; stopx likewise (:1235-1236)
        S_LDY: begin r = fp_add(fully, {~v[lv1][1][31], v[lv1][1][30:0]}); ldy <= r.v; if (r.exc | lexc | rexc) sexc <= 1'b1; st <= S_LT; end
        S_LT:  begin r = fp_mul(ldy, ldxdy); lt <= r.v; if (r.exc) sexc <= 1'b1; st <= S_SX; end
        S_SX:  begin r = fp_add(v[lv1][0], lt); startx <= r.v; if (r.exc) sexc <= 1'b1; st <= S_RDY; end
        S_RDY: begin r = fp_add(fully, {~v[rv1][1][31], v[rv1][1][30:0]}); rdy <= r.v; if (r.exc) sexc <= 1'b1; st <= S_RT; end
        S_RT:  begin r = fp_mul(rdy, rdxdy); rt <= r.v; if (r.exc) sexc <= 1'b1; st <= S_TX; end
        S_TX:  begin r = fp_add(v[rv1][0], rt); stopx <= r.v; if (r.exc) sexc <= 1'b1; st <= S_ROUND; end
        // :1239-1251 round, order, clip
        S_ROUND: begin : rnd
          logic signed [31:0] a, b; logic e1, e2;
          a = fp_round_coord(startx, e1); b = fp_round_coord(stopx, e2);
          if (e1 | e2) sexc <= 1'b1;
          if (a > b) begin istartx <= b; istopx <= a; end else begin istartx <= a; istopx <= b; end
          st <= S_CLAMP;
        end
        S_CLAMP: begin
          if (istartx < cminx) istartx <= cminx;
          if (istopx > cmaxx + 32'sd1) istopx <= cmaxx + 32'sd1;
          st <= S_DX;
        end
        // :1258-1272 (ldy/rdy are recomputed identically in the source: same operands, same result)
        S_DX:  begin r = fp_add(stopx, {~startx[31], startx[30:0]}); dsx <= r.v; if (r.exc) sexc <= 1'b1; st <= S_OOX; end
        S_OOX: begin r = fp_div(F_ONE, dsx); oox <= r.v; if (r.exc) sexc <= 1'b1; pi <= 3'd0; st <= S_P_LM; end
        S_P_LM:   begin r = fp_mul(ldy, e_dpdy[l_is_f ? 0 : 1][li][pi[1:0]]); lparam <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_LA; end
        S_P_LA:   begin r = fp_add(v[lv1][2 + pi], lparam); lparam <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_RM; end
        S_P_RM:   begin r = fp_mul(rdy, e_dpdy[l_is_f ? 1 : 0][ri][pi[1:0]]); rparam <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_RA; end
        S_P_RA:   begin r = fp_add(v[rv1][2 + pi], rparam); rparam <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_D; end
        S_P_D:    begin r = fp_add(rparam, {~lparam[31], lparam[30:0]}); dpdxv <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_DPDX; end
        S_P_DPDX: begin r = fp_mul(dpdxv, oox); dpdxv <= r.v; o_dpdx[pi[1:0]] <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_IX; end
        // start = lparam + ((float(istartx) + 0.5) - startx) * dpdx
        S_P_IX:   begin r = fp_i2f(istartx); ixf <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_IXH; end
        S_P_IXH:  begin r = fp_add(ixf, F_HALF); ixh <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_W; end
        S_P_W:    begin r = fp_add(ixh, {~startx[31], startx[30:0]}); wv <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_WM; end
        S_P_WM:   begin r = fp_mul(wv, dpdxv); wv <= r.v; if (r.exc) sexc <= 1'b1; st <= S_P_ST; end
        S_P_ST: begin
          r = fp_add(lparam, wv); o_start[pi[1:0]] <= r.v; if (r.exc) sexc <= 1'b1;
          if (pi == 3'd3) st <= S_EMIT; else begin pi <= pi + 3'd1; st <= S_P_LM; end
        end
        S_EMIT: begin
          if (!ext_valid) begin
            ext_valid <= 1'b1; ext_scan <= curscan;
            if (istartx >= istopx) begin ext_startx <= 16'sd0; ext_stopx <= 16'sd0; end   // :1276-1277
            else begin ext_startx <= 16'(istartx); ext_stopx <= 16'(istopx); end
            ext_start <= o_start; ext_dpdx <= o_dpdx; ext_exc <= sexc;
          end else if (ext_ready) begin
            ext_valid <= 1'b0; curscan <= curscan + 32'sd1; st <= S_SCAN;
          end
        end
        S_DONE: begin done <= 1'b1; st <= S_IDLE; end
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
