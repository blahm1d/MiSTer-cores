#!/bin/bash
# zr_setup2 coverage: v2 restructures the schedule, forwarding and units, so it gets its own mutants (each must FAIL
# the tap gate). T = zr_setup2.sv, U = fp32_units.sv.
#   T1 fully without the exponent decrement (= 2c+1, the exact-shortcut misread)
#   T2 d = lp - rp instead of rp - lp (operand order at the D0 issue)
#   T3 lm0 reads the STALE ldy register instead of the forwarded pipe output (the c == L hazard)
#   T4 edge advance on >= instead of >
#   T5 edge dp in the wrong orientation (v1 - v2)
#   T6 istartx clamp removed before the params
#   T7 min-y tie taken by the later vertex
#   U1 reciprocal sticky drops the remainder
#   U2 reciprocal skips the brought-down dividend bit ma[0] -- EQUIVALENT here: the setup only divides 1.0 (ma = 0);
#      reported, not required; gate the general a/b path where it is first used
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/setup/mutate_zr_setup2.sh <tapdir> [max-polys]
set -u
R=/mnt/d/deck/fpga/zeus/zeus1/rtl/setup/run_zr_setup.sh; T=$(mktemp -d)
declare -A M K
M[T1]='s/return {r.v\[31\], r.v\[30:23\] - 8'"'"'d1, r.v\[22:0\]};/return r.v;/'; K[T1]=T
M[T2]='s/begin ap_a = rp\[p\]; ap_b = lp\[p\]; ap_sub = 1'"'"'b1; end/begin ap_a = lp[p]; ap_b = rp[p]; ap_sub = 1'"'"'b1; end/'; K[T2]=T
M[T3]='s/mp_a = (p == 0) ? as_y : ldy;/mp_a = ldy;/'; K[T3]=T
M[T4]='s/if (go \&\& fp_gt(fy, v\[e_v2\[sd\]\[i\]\]\[1\])/if (go \&\& !fp_lt(fy, v[e_v2[sd][i]][1])/'; K[T4]=T
M[T5]='s/begin ap_a = v\[j_v2\[jb\]\]\[2 + p\]; ap_b = v\[j_v1\[jb\]\]\[2 + p\]; ap_sub = 1'"'"'b1; end/begin ap_a = v[j_v1[jb]][2 + p]; ap_b = v[j_v2[jb]][2 + p]; ap_sub = 1'"'"'b1; end/'; K[T5]=T
M[T6]='s/if (a < cminx) a = cminx;/;/'; K[T6]=T
M[T7]='s/if (fp_lt(v\[k\]\[1\], v\[mn\]\[1\])) mn = 2'"'"'(k);/if (!fp_gt(v[k][1], v[mn][1])) mn = 2'"'"'(k);/'; K[T7]=T
M[U1]='s/stk = q\[0\] | (rem != 25'"'"'d0);/stk = q[0];/'; K[U1]=U
M[U2]='s/r1 = {rem, (it == 5'"'"'d0) ? inbit : 1'"'"'b0};/r1 = {rem, 1'"'"'b0};/'; K[U2]=U
LIST="T1 T2 T3 T4 T5 T6 T7 U1 U2"
for m in $LIST; do
  if [ "${K[$m]}" = T ]; then ( ZR_TOP=zr_setup2 ZR_MUT="${M[$m]}" bash "$R" "$@" > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc" ) &
  else ( ZR_TOP=zr_setup2 ZR_UMUT="${M[$m]}" bash "$R" "$@" > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc" ) & fi
  sleep 1
done
wait
ok=0
for m in $LIST; do
  rc=$(cat "$T/$m.rc")
  if grep -q "DID NOT APPLY" "$T/$m.log"; then echo "$m NOT APPLIED"; ok=1
  elif grep -q "BUILD FAILED" "$T/$m.log"; then echo "$m BUILD FAILED (not a kill)"; ok=1
  elif [ "$rc" = 0 ]; then if [ "$m" = U2 ]; then echo "$m survived: EQUIVALENT (a = 1.0)"; else echo "$m SURVIVED"; ok=1; fi
  else echo "$m killed: $(grep -m1 FAIL "$T/$m.log" | cut -c1-120)"; fi
done
rm -rf "$T"; exit $ok
