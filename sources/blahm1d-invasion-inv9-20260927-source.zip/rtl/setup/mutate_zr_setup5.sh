#!/bin/bash
# zr_setup5 coverage: the arithmetic mutants of v2/v4 plus the hazards v5 introduces (polygon slots, RAM read-ahead,
# shared round unit, handoff slots). Each must FAIL the streaming tap gate.
#   V1 fully without the exponent decrement            V2 d = lp - rp
#   V3 lm0 reads the stale ldy register                V4 edge advance on >=
#   V5 edge dp in the wrong orientation (v1 - v2)       V6 istartx clamp removed
#   V7 min-y tie taken by the later vertex
#   V8 FE round issue not arbitrated against A          V9 slot released at A's START of the last scanline
#      (V9 is timing-benign on the data -- the FE takes 20+ clocks to its first write -- so the gate checks the
#       ownership invariant directly: the sim-only `hazard` flag fails any write to a slot A still owns)
#   V10 edge RAM read one clock late                   V11 handoff slot always the head (slot collision)
#   U1 reciprocal sticky drops the remainder
# usage: wsl -d Ubuntu -- bash /mnt/d/deck/fpga/zeus/zeus1/rtl/setup/mutate_zr_setup5.sh <tapdir> [max-polys]
set -u
R=/mnt/d/deck/fpga/zeus/zeus1/rtl/setup/run_zr_setup.sh; T=$(mktemp -d)
declare -A M K
M[V1]='s/p_fully <= {r.v\[31\], r.v\[30:23\] - 8'"'"'d1, r.v\[22:0\]};/p_fully <= r.v;/'; K[V1]=T
M[V2]='s/begin ap_a = a_rp\[p\]; ap_b = hb_lp\[a_slot\]\[p\]; ap_sub = 1'"'"'b1; end/begin ap_a = hb_lp[a_slot][p]; ap_b = a_rp[p]; ap_sub = 1'"'"'b1; end/'; K[V2]=T
M[V3]='s/mp_a = (p == 0) ? as_y : ldy;/mp_a = ldy;/'; K[V3]=T
M[V4]='s/P_ADVL: if (fp_gt(p_fully, ps_y2\[p_ps\]\[p_ls\]\[p_li\])/P_ADVL: if (!fp_lt(p_fully, ps_y2[p_ps][p_ls][p_li])/'; K[V4]=T
M[V5]='s/begin ea_a = jp2\[p\]; ea_b = jp1\[p\]; end/begin ea_a = jp1[p]; ea_b = jp2[p]; end/'; K[V5]=T
M[V6]='s/if (a < ps_cminx\[a_ps\]) a = ps_cminx\[a_ps\];/;/'; K[V6]=T
M[V7]='s/if (fp_lt(v\[mk\]\[1\], v\[minv\]\[1\])) minv <= mk;/if (!fp_gt(v[mk][1], v[minv][1])) minv <= mk;/'; K[V7]=T
M[V8]='s/assign fe_rc_ok = !(a_busy \&\& (ca == 8'"'"'(3\*L) || ca == 8'"'"'(3\*L + 1)));/assign fe_rc_ok = 1'"'"'b1;/'; K[V8]=T
M[V9]='s/        if (last) begin p_ps <= ~p_ps; pst <= P_WAIT; end /        if (last) begin p_ps <= ~p_ps; pst <= P_WAIT; ps_valid[p_ps] <= 1'"'"'b0; end /'; K[V9]=T
M[V10]='s/else begin k = ca + 8'"'"'d1; s = a_ps;/else begin k = ca; s = a_ps;/'; K[V10]=T
M[V11]='s/sl = (reserved == 2'"'"'d0) ? hb_head : ~hb_head;/sl = hb_head;/'; K[V11]=T
M[U1]='s/stk = q\[0\] | (rem != 25'"'"'d0);/stk = q[0];/'; K[U1]=U
LIST="V1 V2 V3 V4 V5 V6 V7 V8 V9 V10 V11 U1"
for m in $LIST; do
  if [ "${K[$m]}" = T ]; then ( ZR_TOP=zr_setup5 ZR_TB=tb_zr_setup_stream.cpp ZR_MUT="${M[$m]}" bash "$R" "$@" > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc" ) &
  else ( ZR_TOP=zr_setup5 ZR_TB=tb_zr_setup_stream.cpp ZR_UMUT="${M[$m]}" bash "$R" "$@" > "$T/$m.log" 2>&1; echo $? > "$T/$m.rc" ) & fi
  sleep 1
done
wait
ok=0
for m in $LIST; do
  rc=$(cat "$T/$m.rc")
  if grep -q "DID NOT APPLY" "$T/$m.log"; then echo "$m NOT APPLIED"; ok=1
  elif grep -q "BUILD FAILED" "$T/$m.log"; then echo "$m BUILD FAILED (not a kill)"; ok=1
  elif [ "$rc" = 0 ]; then echo "$m SURVIVED"; ok=1
  else echo "$m killed: $(grep -m1 FAIL "$T/$m.log" | cut -c1-120)"; fi
done
rm -rf "$T"; exit $ok
