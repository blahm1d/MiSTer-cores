// zr_setup3.sv -- Zeus 1 polygon setup engine v3 (R3d, fit-driven). Same arithmetic, operation order and interface
// as zr_setup.sv (v1, the ORDER reference: poly.h render_polygon<4,4>, MAME master 61c79406) and zr_setup2.sv (v2, the
// static schedule). v2 was bit-exact but fitted at 26.5 MHz / 8,575 ALM: its control path inlined float compares,
// four round_coordinate copies and nested dynamic indexing v[e_v1[side][i]][field], and its "pipes" were inferred as
// shift-register RAM, so the whole multiply/add sat in front of the first register. v3 changes STRUCTURE only:
//   * staged units fp_add4 / fp_mul4 (latency 4, real logic between every register) -- L = 4 in the v2 schedule
//   * one shared registered round_coordinate unit (latency 2), fed sx then ex on consecutive clocks
//   * small int->float (fp_i2f16) for fully (2c+1) and istartx: exact, no 32-bit clz
//   * min/max and edge advance one compare step per clock (as v1); operands latched through ONE 3:1 edge mux
//   * edge store carries its own copies of v1.x, v1.y, v1.p[4], v2.y (no double indirection at scanline time)
module zr_setup3
  import fp32_pkg::*;
(
  input  logic        clk,
  input  logic        rst,
  input  logic        start,
  input  logic [31:0] vin [4][6],
  input  logic signed [31:0] clip_min_x, clip_max_x, clip_min_y, clip_max_y,
  output logic        busy,
  output logic        done,
  output logic        rejected,
  output logic        ext_valid,
  input  logic        ext_ready,
  output logic signed [31:0] ext_scan,
  output logic signed [15:0] ext_startx, ext_stopx,
  output logic [31:0] ext_start [4],
  output logic [31:0] ext_dpdx  [4],
  output logic        ext_exc
);
  localparam int L = 5;                       // fp_add5 / fp_mul5 latency (R3e timing split)
  localparam logic [31:0] F_ONE = 32'h3f800000, F_HALF = 32'h3f000000;
  localparam int D0 = (3*L + 5 > 2*L + 8) ? 3*L + 5 : 2*L + 8;
  localparam int W0 = (L + 1 > 4) ? L + 1 : 4;
  localparam int E_LAST = W0 + 2*L + 3;

  typedef enum logic [4:0] { S_IDLE, S_MINMAX, S_Y0, S_Y1, S_YW, S_Y2, S_Y3, S_EBUILD, S_JLATCH, S_ERUN, S_LR, S_LR2,
                             S_SP0, S_SADVL, S_SADVR, S_SLATCH, S_SRUN, S_EMIT, S_DONE } st_t;
  st_t st;

  logic [31:0] v [4][6];
  logic signed [31:0] cminx, cmaxx, cminy, cmaxy, minyclip, maxyclip, curscan;
  logic [1:0] minv, maxv, mk;
  logic [31:0] maxy_f;                       // v[maxv].y, registered for the advance compares

  // ---- edge store [side][index]: everything a scanline needs from its edge ----
  logic [31:0] e_x1 [2][3], e_y1 [2][3], e_y2 [2][3], e_dxdy [2][3], e_p1 [2][3][4], e_dpdy [2][3][4];
  logic [1:0]  e_v1 [2][3];                  // vertex id of v1 (left/right choice needs identity)
  logic        e_exc [2][3];
  logic [1:0]  e_cnt [2];
  logic       side; logic [1:0] cv;
  logic [2:0] nj, jb;
  logic       j_side [4]; logic [1:0] j_idx [4], j_v1 [4], j_v2 [4];
  function automatic logic [1:0] nextv(input logic sd, input logic [1:0] c); return sd ? c - 2'd1 : c + 2'd1; endfunction

  // ---- units ----
  logic [31:0] as_a, as_b, ms_a, ms_b, ap_a, ap_b, mp_a, mp_b, as_y, ms_y, ap_y, mp_y, rcp_b, rcp_y;
  logic        as_sub, ap_sub, as_x, ms_x, ap_x, mp_x, rcp_start, rcp_done, rcp_x, rcp_busy;
  fp_add5 u_as (.clk, .a(as_a), .b(as_b), .sub(as_sub), .y(as_y), .exc(as_x));
  fp_mul5 u_ms (.clk, .a(ms_a), .b(ms_b), .y(ms_y), .exc(ms_x));
  fp_add5 u_ap (.clk, .a(ap_a), .b(ap_b), .sub(ap_sub), .y(ap_y), .exc(ap_x));
  fp_mul5 u_mp (.clk, .a(mp_a), .b(mp_b), .y(mp_y), .exc(mp_x));
  fp_rcp4 u_rcp (.clk, .rst, .start(rcp_start), .a(F_ONE), .b(rcp_b), .done(rcp_done), .y(rcp_y), .exc(rcp_x), .busy(rcp_busy));

  // shared round_coordinate (poly.h:368-381), 3 stages (R3e timing split): input register | fixed-point magnitude
  // (integer part, fraction, sticky, saturation) | floor + (fraction > 0.5) + sign. Readable 3 clocks after issue.
  // Same arithmetic as fp32_pkg::fp_round_coord, split at its only wide step.
  logic [31:0] rc_in_r; logic signed [31:0] rc_out; logic rc_exc_out;
  logic [31:0] rc_in;
  logic        rcA_zero, rcA_exc, rcA_satp, rcA_satn, rcA_s, rcA_stk; logic [31:0] rcA_ip, rcA_fr;
  always_ff @(posedge clk) begin : rcu
    logic [7:0] e; logic [63:0] mag; int sh; logic signed [32:0] fl; logic up;
    rc_in_r <= rc_in;
    // stage A
    rcA_exc  <= is_special(rc_in_r);
    rcA_zero <= is_zero(rc_in_r) || is_special(rc_in_r);
    e = rc_in_r[30:23];
    rcA_s    <= rc_in_r[31];
    rcA_satp <= !rc_in_r[31] && e >= 8'd158;
    rcA_satn <= rc_in_r[31] && (e > 8'd158 || (e == 8'd158 && rc_in_r[22:0] != 23'd0));
    sh = int'(e) - 118;
    if (sh >= 0) begin mag = 64'({1'b1, rc_in_r[22:0]}) << sh; rcA_stk <= 1'b0; end
    else if (sh > -24) begin mag = 64'({1'b1, rc_in_r[22:0]}) >> (-sh); rcA_stk <= (({1'b1, rc_in_r[22:0]} & ((24'd1 << (-sh)) - 24'd1)) != 24'd0); end
    else begin mag = 64'd0; rcA_stk <= 1'b1; end
    rcA_ip <= mag[63:32]; rcA_fr <= mag[31:0];
    // stage B
    rc_exc_out <= rcA_exc;
    if (rcA_zero) rc_out <= 32'sd0;
    else if (rcA_satp) rc_out <= 32'sh7fffffff;
    else if (rcA_satn) rc_out <= 32'sh80000000;
    else begin
      if (!rcA_s) begin fl = $signed({1'b0, rcA_ip}); up = rcA_fr[31] && (rcA_fr[30:0] != 31'd0 || rcA_stk); end
      else if (rcA_fr == 32'd0 && !rcA_stk) begin fl = -$signed({1'b0, rcA_ip}); up = 1'b0; end
      else begin fl = -$signed({1'b0, rcA_ip}) - 33'sd1; up = (rcA_fr < 32'h80000000); end
      rc_out <= 32'(fl + (up ? 33'sd1 : 33'sd0));
    end
  end

  // ---- job operands (latched per edge job) ----
  logic [31:0] jx1, jy1, jx2, jy2, jp1 [4], jp2 [4];
  logic [7:0] c, ec; logic post;
  logic [31:0] j_dx, j_dp [4], j_ooy; logic j_x;
  // ---- scanline operands and intermediates ----
  logic [31:0] fully, Lx, Ly, Rx, Ry, Ldxdy, Rdxdy, Lp [4], Rp [4], Ldp [4], Rdp [4];
  logic [31:0] ldy, rdy, sx, ixf, w, oox, lp [4], rp [4], dd [4], dpdx [4], stv [4];
  logic signed [31:0] istartx, istopx, rsx;
  logic       sexc, l_is_f; logic [1:0] li, ri;
  logic       lr_shared, lr_slope, lr_x;

  // ---- op issue ----
  always_comb begin
    as_a = '0; as_b = '0; as_sub = 1'b0; ms_a = '0; ms_b = '0; ap_a = '0; ap_b = '0; ap_sub = 1'b0; mp_a = '0; mp_b = '0;
    rcp_start = 1'b0; rcp_b = '0; rc_in = '0;
    case (st)
      S_Y0: rc_in = v[minv][1];
      S_Y1: rc_in = v[maxv][1];
      S_ERUN: if (!post) begin
        if (c == 0) begin as_a = jy2; as_b = jy1; as_sub = 1'b1; end                                      // dy
        if (c == 1) begin as_a = jx2; as_b = jx1; as_sub = 1'b1; end                                      // dx
        for (int p = 0; p < 4; p++) if (c == 8'(p)) begin ap_a = jp2[p]; ap_b = jp1[p]; ap_sub = 1'b1; end   // dp
        if (c == 8'(L)) begin rcp_start = 1'b1; rcp_b = as_y; end                                         // ooy
      end else begin
        if (ec == 0) begin ms_a = j_dx; ms_b = j_ooy; end                                                 // dxdy
        for (int p = 0; p < 4; p++) if (ec == 8'(p)) begin mp_a = j_dp[p]; mp_b = j_ooy; end              // dpdy
      end
      S_SRUN: if (!post) begin
        if (c == 0) begin as_a = fully; as_b = Ly; as_sub = 1'b1; end                                     // ldy
        if (c == 1) begin as_a = fully; as_b = Ry; as_sub = 1'b1; end                                     // rdy
        if (c == 8'(L))     begin ms_a = as_y; ms_b = Ldxdy; end                                          // lt
        if (c == 8'(L + 1)) begin ms_a = as_y; ms_b = Rdxdy; end                                          // rt
        for (int p = 0; p < 4; p++) begin
          if (c == 8'(L + p))       begin mp_a = (p == 0) ? as_y : ldy; mp_b = Ldp[p]; end                // lm
          if (c == 8'(L + 4 + p))   begin mp_a = rdy; mp_b = Rdp[p]; end                                  // rm
          if (c == 8'(2*L + p))     begin ap_a = Lp[p]; ap_b = mp_y; end                                  // lp
          if (c == 8'(2*L + 4 + p)) begin ap_a = Rp[p]; ap_b = mp_y; end                                  // rp
          if (c == 8'(D0 + p))      begin ap_a = rp[p]; ap_b = lp[p]; ap_sub = 1'b1; end                  // d
        end
        if (c == 8'(2*L))     begin as_a = Lx; as_b = ms_y; end                                           // sx
        if (c == 8'(2*L + 1)) begin as_a = Rx; as_b = ms_y; end                                           // ex
        if (c == 8'(3*L))     rc_in = as_y;                                                               // round(sx)
        if (c == 8'(3*L + 1)) begin as_a = as_y; as_b = sx; as_sub = 1'b1; rc_in = as_y; end              // dsx; round(ex)
        if (c == 8'(3*L + 6)) begin as_a = ixf; as_b = F_HALF; end                                        // ixh
        if (c == 8'(4*L + 1)) begin rcp_start = 1'b1; rcp_b = as_y; end                                   // oox
        if (c == 8'(4*L + 6)) begin as_a = as_y; as_b = sx; as_sub = 1'b1; end                            // w = ixh - sx
      end else begin
        for (int p = 0; p < 4; p++) begin
          if (ec == 8'(p))          begin mp_a = dd[p]; mp_b = oox; end                                   // dpdx
          if (ec == 8'(W0 + p))     begin mp_a = w; mp_b = dpdx[p]; end                                   // wm
          if (ec == 8'(W0 + L + p)) begin ap_a = lp[p]; ap_b = mp_y; end                                  // st
        end
      end
      default: ;
    endcase
  end

  assign busy = (st != S_IDLE);

  always_ff @(posedge clk) begin
    done <= 1'b0;
    if (rst) begin st <= S_IDLE; ext_valid <= 1'b0; rejected <= 1'b0; post <= 1'b0; end
    else case (st)
      S_IDLE: if (start) begin
        v <= vin; cminx <= clip_min_x; cmaxx <= clip_max_x; cminy <= clip_min_y; cmaxy <= clip_max_y;
        rejected <= 1'b0; minv <= 2'd0; maxv <= 2'd0; mk <= 2'd1; st <= S_MINMAX;
      end
      // :1111-1119, one vertex per clock (the else-if chain is order dependent)
      S_MINMAX: begin
        if (fp_lt(v[mk][1], v[minv][1])) minv <= mk;
        else if (fp_gt(v[mk][1], v[maxv][1])) maxv <= mk;
        if (mk == 2'd3) st <= S_Y0; else mk <= mk + 2'd1;
      end
      // :1122-1134 via the shared round unit: issue miny (S_Y0), maxy (S_Y1); results at S_Y2 / S_Y3
      S_Y0: st <= S_Y1;
      S_Y1: begin maxy_f <= v[maxv][1]; st <= S_YW; end
      S_YW: st <= S_Y2;                                                  // round unit latency 3
      S_Y2: begin minyclip <= (rc_out > cminy) ? rc_out : cminy; st <= S_Y3; end
      S_Y3: begin : yc
        logic signed [31:0] b;
        b = (rc_out < cmaxy + 32'sd1) ? rc_out : cmaxy + 32'sd1;
        maxyclip <= b;
        if (b - minyclip <= 32'sd0) begin rejected <= 1'b1; st <= S_DONE; end
        else begin side <= 1'b0; cv <= minv; e_cnt[0] <= 2'd0; e_cnt[1] <= 2'd0; nj <= 3'd0; st <= S_EBUILD; end
      end
      S_EBUILD: begin
        if (cv == maxv) begin
          if (side == 1'b0) begin side <= 1'b1; cv <= minv; end
          else begin jb <= 3'd0; st <= (nj == 3'd0) ? S_LR : S_JLATCH; end
        end else begin
          if (!fp_eq(v[cv][1], v[nextv(side, cv)][1])) begin
            j_side[nj[1:0]] <= side; j_idx[nj[1:0]] <= e_cnt[side]; j_v1[nj[1:0]] <= cv; j_v2[nj[1:0]] <= nextv(side, cv);
            e_v1[side][e_cnt[side]] <= cv;
            e_cnt[side] <= e_cnt[side] + 2'd1; nj <= nj + 3'd1;
          end
          cv <= nextv(side, cv);
        end
      end
      S_JLATCH: begin   // this job's two vertices, through one 4:1 mux each
        jx1 <= v[j_v1[jb[1:0]]][0]; jy1 <= v[j_v1[jb[1:0]]][1]; jx2 <= v[j_v2[jb[1:0]]][0]; jy2 <= v[j_v2[jb[1:0]]][1];
        for (int p = 0; p < 4; p++) begin jp1[p] <= v[j_v1[jb[1:0]]][2 + p]; jp2[p] <= v[j_v2[jb[1:0]]][2 + p]; end
        c <= '0; post <= 1'b0; st <= S_ERUN;
      end
      S_ERUN: begin
        if (!post) begin
          c <= c + 8'd1;
          if (c == 8'(L)) j_x <= as_x;
          if (c == 8'(L + 1)) begin j_dx <= as_y; if (as_x) j_x <= 1'b1; end
          for (int p = 0; p < 4; p++) if (c == 8'(L + p)) begin j_dp[p] <= ap_y; if (ap_x) j_x <= 1'b1; end
          if (rcp_done) begin j_ooy <= rcp_y; if (rcp_x) j_x <= 1'b1; post <= 1'b1; ec <= '0; end
        end else begin : epost
          logic sd; logic [1:0] ix;
          sd = j_side[jb[1:0]]; ix = j_idx[jb[1:0]];
          ec <= ec + 8'd1;
          if (ec == 8'(L)) begin e_dxdy[sd][ix] <= ms_y; if (ms_x) j_x <= 1'b1; end
          for (int p = 0; p < 4; p++) if (ec == 8'(L + p)) begin e_dpdy[sd][ix][p] <= mp_y; if (mp_x) j_x <= 1'b1; end
          if (ec == 8'(L + 4)) begin
            e_exc[sd][ix] <= j_x;
            e_x1[sd][ix] <= jx1; e_y1[sd][ix] <= jy1; e_y2[sd][ix] <= jy2;
            for (int p = 0; p < 4; p++) e_p1[sd][ix][p] <= jp1[p];
            post <= 1'b0;
            if (jb + 3'd1 == nj) st <= S_LR; else begin jb <= jb + 3'd1; st <= S_JLATCH; end
          end
        end
      end
      // :1193-1204, two clocks (R3e): register the three comparisons, then decide
      S_LR: begin
        lr_shared <= (e_v1[0][0] == e_v1[1][0]);
        lr_slope  <= fp_lt(e_dxdy[0][0], e_dxdy[1][0]);
        lr_x      <= fp_lt(e_x1[0][0], e_x1[1][0]);
        st <= S_LR2;
      end
      S_LR2: begin
        l_is_f <= (lr_shared && lr_slope) || (!lr_shared && lr_x);
        li <= 2'd0; ri <= 2'd0; curscan <= minyclip; st <= S_SP0;
      end
      // scanline prep: fully (exact, i2f16(2c+1) with exponent - 1), then advance each edge one step per clock
      S_SP0: begin
        if (curscan >= maxyclip) st <= S_DONE;
        else begin : fy
          fres_t r; r = fp_i2f16(16'(curscan * 2 + 32'sd1));
          fully <= {r.v[31], r.v[30:23] - 8'd1, r.v[22:0]};
          st <= S_SADVL;
        end
      end
      S_SADVL: begin : al   // :1231  while (fully > ledge->v2->y && fully < v[maxv].y) ++ledge;
        logic ls; ls = ~l_is_f;
        if (fp_gt(fully, e_y2[ls][li]) && fp_lt(fully, maxy_f)) li <= li + 2'd1; else st <= S_SADVR;
      end
      S_SADVR: begin : ar
        logic rs; rs = l_is_f;
        if (fp_gt(fully, e_y2[rs][ri]) && fp_lt(fully, maxy_f)) ri <= ri + 2'd1; else st <= S_SLATCH;
      end
      S_SLATCH: begin : lat
        logic ls, rs; ls = ~l_is_f; rs = l_is_f;
        Lx <= e_x1[ls][li]; Ly <= e_y1[ls][li]; Ldxdy <= e_dxdy[ls][li];
        Rx <= e_x1[rs][ri]; Ry <= e_y1[rs][ri]; Rdxdy <= e_dxdy[rs][ri];
        for (int p = 0; p < 4; p++) begin Lp[p] <= e_p1[ls][li][p]; Ldp[p] <= e_dpdy[ls][li][p]; Rp[p] <= e_p1[rs][ri][p]; Rdp[p] <= e_dpdy[rs][ri][p]; end
        sexc <= e_exc[ls][li] | e_exc[rs][ri];
        c <= '0; post <= 1'b0; st <= S_SRUN;
      end
      S_SRUN: begin
        if (!post) begin
          c <= c + 8'd1;
          if (c == 8'(L))     begin ldy <= as_y; if (as_x) sexc <= 1'b1; end
          if (c == 8'(L + 1)) begin rdy <= as_y; if (as_x) sexc <= 1'b1; end
          if (c == 8'(2*L) && ms_x) sexc <= 1'b1;
          if (c == 8'(2*L + 1) && ms_x) sexc <= 1'b1;
          if (c == 8'(3*L))     begin sx <= as_y; if (as_x) sexc <= 1'b1; end
          if (c == 8'(3*L + 1) && as_x) sexc <= 1'b1;                          // ex
          if (c == 8'(3*L + 3)) begin rsx <= rc_out; if (rc_exc_out) sexc <= 1'b1; end
          if (c == 8'(3*L + 4)) begin : oc                                   // :1239-1251 order + clip
            logic signed [31:0] a, b;
            if (rc_exc_out) sexc <= 1'b1;
            a = rsx; b = rc_out;
            if (a > b) begin logic signed [31:0] t; t = a; a = b; b = t; end
            if (a < cminx) a = cminx;
            if (b > cmaxx + 32'sd1) b = cmaxx + 32'sd1;
            istartx <= a; istopx <= b;
          end
          if (c == 8'(3*L + 5)) begin : i2f                                  // ixf = float(istartx), |istartx| < 2^15
            fres_t r; r = fp_i2f16(16'(istartx)); ixf <= r.v;
            if (istartx > 32'sd32767 || istartx < -32'sd32768) sexc <= 1'b1;
          end
          if (c == 8'(4*L + 1) && as_x) sexc <= 1'b1;                          // dsx
          if (c == 8'(4*L + 6) && as_x) sexc <= 1'b1;                          // ixh
          if (c == 8'(5*L + 6)) begin w <= as_y; if (as_x) sexc <= 1'b1; end
          for (int p = 0; p < 4; p++) begin
            if (c == 8'(2*L + p) && mp_x) sexc <= 1'b1;
            if (c == 8'(2*L + 4 + p) && mp_x) sexc <= 1'b1;
            if (c == 8'(3*L + p))     begin lp[p] <= ap_y; if (ap_x) sexc <= 1'b1; end
            if (c == 8'(3*L + 4 + p)) begin rp[p] <= ap_y; if (ap_x) sexc <= 1'b1; end
            if (c == 8'(D0 + L + p))  begin dd[p] <= ap_y; if (ap_x) sexc <= 1'b1; end
          end
          if (rcp_done) begin oox <= rcp_y; if (rcp_x) sexc <= 1'b1; post <= 1'b1; ec <= '0; end
        end else begin
          ec <= ec + 8'd1;
          for (int p = 0; p < 4; p++) begin
            if (ec == 8'(L + p))        begin dpdx[p] <= mp_y; if (mp_x) sexc <= 1'b1; end
            if (ec == 8'(W0 + L + p) && mp_x) sexc <= 1'b1;
            if (ec == 8'(W0 + 2*L + p)) begin stv[p] <= ap_y; if (ap_x) sexc <= 1'b1; end
          end
          if (ec == 8'(E_LAST)) st <= S_EMIT;
        end
      end
      S_EMIT: begin
        if (!ext_valid) begin
          ext_valid <= 1'b1; ext_scan <= curscan;
          if (istartx >= istopx) begin ext_startx <= 16'sd0; ext_stopx <= 16'sd0; end
          else begin ext_startx <= 16'(istartx); ext_stopx <= 16'(istopx); end
          ext_start <= stv; ext_dpdx <= dpdx; ext_exc <= sexc;
        end else if (ext_ready) begin
          ext_valid <= 1'b0; curscan <= curscan + 32'sd1; st <= S_SP0;
        end
      end
      S_DONE: begin done <= 1'b1; st <= S_IDLE; end
      default: st <= S_IDLE;
    endcase
  end
endmodule
