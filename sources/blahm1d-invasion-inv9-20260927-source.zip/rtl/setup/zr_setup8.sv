// zr_setup8.sv -- v7 plus TWO OVERLAPPED SCANLINE (phase A) INSTANCES at an initiation interval of 16 (v7: one at a time,
// 27 clocks each). See the A declarations for the lifetime + modulo-reservation argument. Extents bit-identical.
// zr_setup7.sv -- v6 plus PIPELINED EDGE JOBS in the front end (3 job slots, 2 reciprocal units: PRE of edge j+1 overlaps
// POST of edge j). v6 = v5 plus the empty-extent fast path. Used extents are bit-identical to v5.
// zr_setup6.sv -- v5 plus the EMPTY-EXTENT fast path (Pass 1 measured 45 % of hvpoly's extents empty, each paying A's full 27-clock
// schedule and B's): A decides at 3L+4 and ends at 3L+5, B emits it at once. Used extents are bit-identical to v5.
// zr_setup5.sv -- Zeus 1 polygon setup engine v5 (R3g): polygons overlap too. Arithmetic, operation order and extent
// stream identical to zr_setup.sv (v1, the ORDER reference: poly.h render_polygon<4,4>, MAME master 61c79406).
//
//   FE    front end for polygon k+1 (min/max, y clip, edge build, edge jobs on its OWN E add/mul/reciprocal, left/right)
//         into a free POLYGON SLOT, while the scanline machinery consumes polygon k
//   PREP  next scanline: fully (exact i2f16(2c+1), exponent - 1) + edge advance; walks the slots in order
//   A     x/y path + first parameter half + reciprocal start (as v4); edge operands from M10K, read one clock ahead
//   B     dpdx / wm / start on its own add/mul pair, then the extent is emitted (as v4)
// The scanline stream flows across polygon boundaries: a polygon's first scanline follows the previous one's last.
// Edge data lives in three simple-dual-port M10Ks ({x1, y1, dxdy}, p1[4], dpdy[4]) addressed {slot, side, idx, field};
// FE writes a FREE slot while A reads an OWNED one, so they never touch the same word. Only y2 and the exception flags
// (read by PREP's advance compares) stay in flops. The shared round unit is arbitrated: FE issues only in clocks where
// A does not (A's round results and FE's arrive 3 clocks after their own distinct issue clocks).
// Interface: streaming -- `start` is accepted when `in_ready`; `rejected` pulses once per polygon the y clip removes;
// `idle` when everything has drained.
module zr_setup8
  import fp32_pkg::*;
(
  input  logic        clk,
  input  logic        rst,
  input  logic        start,
  output logic        in_ready,
  input  logic [31:0] vin [4][6],
  input  logic signed [31:0] clip_min_x, clip_max_x, clip_min_y, clip_max_y,
  output logic        idle,
  output logic        rejected,
  output logic        ext_valid,
  input  logic        ext_ready,
  output logic signed [31:0] ext_scan,
  output logic signed [15:0] ext_startx, ext_stopx,
  output logic [31:0] ext_start [4],
  output logic [31:0] ext_dpdx  [4],
  output logic        ext_exc,
  output logic        ext_last,     // the last extent of its polygon (the renderer uses it to pop the object that polygon carries)
  output logic        hazard,      // sim check (ZR_SIM): a write hit a polygon slot A still owns (sticky)
  // utilization counters (area campaign): cycles each engine is busy. v5 carries TEN float units (4 add, 4 mul,
  // 2 divide = 2,021 of its 5,015 ALM, zeus1/area/setup5b_20ns entity table) so that the front end's edge jobs can
  // overlap the scanline phases. Sharing units is the area lever; these say what it would cost.
  output logic [31:0] st_clk, st_fe, st_a, st_b
);
  localparam int L = 4;
  localparam logic [31:0] F_ONE = 32'h3f800000, F_HALF = 32'h3f000000;
  localparam int D0 = (3*L + 5 > 2*L + 8) ? 3*L + 5 : 2*L + 8;
  localparam int W0 = (L + 1 > 4) ? L + 1 : 4;
  localparam int A_W = 5*L + 6, A_END = A_W + 1, B_LAST = W0 + 2*L + 3;
  localparam logic [1:0] FX_X1 = 2'd0, FX_Y1 = 2'd1, FX_DXDY = 2'd2;

  function automatic logic [1:0] nextv(input logic sd, input logic [1:0] c); return sd ? c - 2'd1 : c + 2'd1; endfunction
  function automatic logic [3:0] eid(input logic s, input logic sd, input logic [1:0] ix); return {s, sd, ix}; endfunction

  // ================= polygon slots =================
  logic        ps_valid [2];                                   // owned by the scanline side (ready or in progress)
  logic        ps_issued [2];                                  // v8: PREP has issued every scanline of this occupant
  logic signed [31:0] ps_minyc [2], ps_maxyc [2], ps_cminx [2], ps_cmaxx [2];
  logic [31:0] ps_maxy [2];
  logic        ps_lf [2];
  logic [31:0] ps_y2 [2][2][3];
  logic        ps_exc [2][2][3];

  // ================= edge RAMs =================
  logic        rx_we, rp_we, rd_we;
  logic [5:0]  rx_wa, rp_wa, rd_wa, rx_ra, rp_ra, rd_ra;
  logic [31:0] rx_wd, rp_wd, rd_wd, rx_q, rp_q, rd_q;
  zr_sdp #(32, 6) u_rx (.clk, .we(rx_we), .waddr(rx_wa), .wdata(rx_wd), .raddr(rx_ra), .rdata(rx_q));
  zr_sdp #(32, 6) u_rp (.clk, .we(rp_we), .waddr(rp_wa), .wdata(rp_wd), .raddr(rp_ra), .rdata(rp_q));
  zr_sdp #(32, 6) u_rd (.clk, .we(rd_we), .waddr(rd_wa), .wdata(rd_wd), .raddr(rd_ra), .rdata(rd_q));

  // ================= units =================
  logic [31:0] as_a, as_b, ms_a, ms_b, ap_a, ap_b, mp_a, mp_b, aq_a, aq_b, mq_a, mq_b, ea_a, ea_b, em_a, em_b;
  logic [31:0] as_y, ms_y, ap_y, mp_y, aq_y, mq_y, ea_y, em_y, rcp_b, rcp_y, erc_b, erc_y [2];
  logic as_sub, ap_sub, as_x, ms_x, ap_x, mp_x, aq_x, mq_x, ea_x, em_x, rcp_start, rcp_done, rcp_x, rcp_busy;
  logic erc_start [2], erc_done [2], erc_x [2], erc_busy [2];
  fp_add4 u_as (.clk, .a(as_a), .b(as_b), .sub(as_sub), .y(as_y), .exc(as_x));
  fp_mul4 u_ms (.clk, .a(ms_a), .b(ms_b), .y(ms_y), .exc(ms_x));
  fp_add4 u_ap (.clk, .a(ap_a), .b(ap_b), .sub(ap_sub), .y(ap_y), .exc(ap_x));
  fp_mul4 u_mp (.clk, .a(mp_a), .b(mp_b), .y(mp_y), .exc(mp_x));
  fp_add4 u_aq (.clk, .a(aq_a), .b(aq_b), .sub(1'b0), .y(aq_y), .exc(aq_x));
  fp_mul4 u_mq (.clk, .a(mq_a), .b(mq_b), .y(mq_y), .exc(mq_x));
  fp_add4 u_ea (.clk, .a(ea_a), .b(ea_b), .sub(1'b1), .y(ea_y), .exc(ea_x));        // FE: every edge add is a v2 - v1
  fp_mul4 u_em (.clk, .a(em_a), .b(em_b), .y(em_y), .exc(em_x));
  fp_rcp4 u_rcp (.clk, .rst, .start(rcp_start), .a(F_ONE), .b(rcp_b), .done(rcp_done), .y(rcp_y), .exc(rcp_x), .busy(rcp_busy));
  fp_rcp4 u_erc (.clk, .rst, .start(erc_start[0]), .a(F_ONE), .b(erc_b), .done(erc_done[0]), .y(erc_y[0]), .exc(erc_x[0]), .busy(erc_busy[0]));
  fp_rcp4 u_erc2 (.clk, .rst, .start(erc_start[1]), .a(F_ONE), .b(erc_b), .done(erc_done[1]), .y(erc_y[1]), .exc(erc_x[1]), .busy(erc_busy[1]));   // v7

  // ---- shared round_coordinate, 3 stages ----
  logic [31:0] rc_in_r, rc_in; logic signed [31:0] rc_out; logic rc_exc_out;
  logic        rcA_zero, rcA_exc, rcA_satp, rcA_satn, rcA_s, rcA_stk; logic [31:0] rcA_ip, rcA_fr;
  always_ff @(posedge clk) begin : rcu
    logic [7:0] e; logic [63:0] mag; int sh; logic signed [32:0] fl; logic up;
    rc_in_r <= rc_in;
    rcA_exc  <= is_special(rc_in_r);
    rcA_zero <= is_zero(rc_in_r) || is_special(rc_in_r);
    e = rc_in_r[30:23];
    rcA_s    <= rc_in_r[31];
    rcA_satp <= !rc_in_r[31] && e >= 8'd158;
    rcA_satn <= rc_in_r[31] && (e > 8'd158 || (e == 8'd158 && rc_in_r[22:0] != 23'd0));
    sh = int'(e) - 118;
    if (sh >= 0) begin mag = 64'({1'b1, rc_in_r[22:0]}) << sh; rcA_stk <= 1'b0; end
    else if (sh > -24) begin mag = 64'({1'b1, rc_in_r[22:0]}) >> (-sh); rcA_stk <= (({1'b1, rc_in_r[22:0]} & ((24'd1 << (-sh)) - 24'd1)) != 24'd0); end
    else begin mag = 64'd0; rcA_stk <= 1'b1; end
    rcA_ip <= mag[63:32]; rcA_fr <= mag[31:0];
    rc_exc_out <= rcA_exc;
    if (rcA_zero) rc_out <= 32'sd0;
    else if (rcA_satp) rc_out <= 32'sh7fffffff;
    else if (rcA_satn) rc_out <= 32'sh80000000;
    else begin
      if (!rcA_s) begin fl = $signed({1'b0, rcA_ip}); up = rcA_fr[31] && (rcA_fr[30:0] != 31'd0 || rcA_stk); end
      else if (rcA_fr == 32'd0 && !rcA_stk) begin fl = -$signed({1'b0, rcA_ip}); up = 1'b0; end
      else begin fl = -$signed({1'b0, rcA_ip}) - 33'sd1; up = (rcA_fr < 32'h80000000); end
      rc_out <= 32'(fl + (up ? 33'sd1 : 33'sd0));
    end
  end

  // ================= FE =================
  typedef enum logic [3:0] { F_IDLE, F_MINMAX, F_Y0, F_Y1, F_YW1, F_YW2, F_Y2, F_Y3, F_WSLOT, F_EBUILD, F_JLATCH, F_ERUN,
                             F_LR, F_LR2 } fst_t;
  fst_t fst;
  logic [31:0] v [4][6];
  logic signed [31:0] f_cminx, f_cmaxx, f_cminy, f_cmaxy, f_minyc, f_maxyc;
  logic [1:0] minv, maxv, mk;
  logic fe_ps; logic side; logic [1:0] cv; logic [2:0] nj, jb;
  logic j_side [4]; logic [1:0] j_idx [4], j_v1 [4], j_v2 [4];
  logic [1:0] e_cnt [2]; logic [1:0] f_v1first [2]; logic [31:0] f_x1first [2], f_dxdyfirst [2];
  // v7 pipelined edge jobs: PRE on job pj (slot pre_s, reciprocal unit pre_u), POST on job qj (slot qs)
  logic [2:0] pj, qj; logic [1:0] pre_s, qs, erc_s [2]; logic pre_on, post_on, pre_u;
  logic [31:0] px2, py2, pp2 [4];
  logic [31:0] q_x1 [3], q_y1 [3], q_y2 [3], q_p1 [3][4], q_dx [3], q_dp [3][4], q_ooy [3]; logic q_x [3], q_rdy [3], q_busy [3];
  logic [7:0] c, ec;
  logic lr_shared, lr_slope, lr_x;
  logic fe_rc_ok;                                          // the round unit is free this clock (A not issuing)
  logic y0_issued, y1_issued; logic [1:0] ywait;

  // ================= PREP =================
  typedef enum logic [2:0] { P_WAIT, P_FULLY, P_ADVL, P_ADVR, P_RDY } pst_t;
  pst_t pst; logic p_ps; logic signed [31:0] p_scan; logic [31:0] p_fully; logic [1:0] p_li, p_ri;
  logic p_ls, p_rs; assign p_ls = ~ps_lf[p_ps]; assign p_rs = ps_lf[p_ps];

  // ================= A =================
  // v8: TWO overlapped A instances, initiation interval 16 (a new scanline starts when the other instance reaches
  // offset 16). Per-instance control lives in [2] arrays; the temporaries stay SHARED because each one is written and
  // last read inside a window shorter than 16 clocks (ldy 4..7, rdy 5..11, sx 12..22 < 28, rsx 15..16, a_istart
  // 16..17, ixf 17..18, a_rp 16..20), and the units / RAM read ports / round unit are used at offsets that are
  // distinct modulo 16 (as 0 1 8 9 13 18 22; ms 4 5; mp 4..11; ap 8..15 17..20; rc 12 13; rx 0 1 4 5 8 9; rp 8..15;
  // rd 4..11), so at most one instance drives each of them in any clock. The reciprocal (16 clocks) is started at
  // offset 17, so starts are >= 16 apart. Completion order = start order (an instance ends by 27; the next one
  // started >= 16 later and ends no earlier than its 17).
  logic a_busy [2]; logic [7:0] ca [2]; logic a_slot [2], a_ps [2], a_last [2], a_x [2], a_empty [2];
  logic signed [31:0] a_scan [2]; logic [31:0] a_fully [2]; logic [1:0] a_li [2], a_ri [2];
  logic [31:0] ldy, rdy, sx, ixf, a_rp [4]; logic signed [31:0] rsx, a_istart;
  logic a_ls [2], a_rs [2];
  always_comb for (int i = 0; i < 2; i++) begin a_ls[i] = ~ps_lf[a_ps[i]]; a_rs[i] = ps_lf[a_ps[i]]; end
  logic astart, a_new, a_any;
  assign a_any = a_busy[0] || a_busy[1];
  assign a_new = a_busy[0];                                // the idle instance (both idle: instance 0)

  // ================= handoff + B =================
  logic [31:0] hb_lp [2][4], hb_dd [2][4], hb_w [2], hb_oox [2];
  logic signed [31:0] hb_sx [2], hb_ex [2], hb_scan [2];
  logic hb_x [2], hb_rx [2], hb_adone [2], hb_ooxv [2], hb_last [2];
  logic hb_empty [2];                                      // v6: the extent is empty (istartx >= istopx after the clip)
  logic [1:0] reserved; logic hb_head, rcp_slot;
  logic b_busy, b_emit, b_last; logic [7:0] cb;
  logic [31:0] b_lp [4], b_dd [4], b_w, b_oox, b_dpdx [4], b_st [4];
  logic signed [31:0] b_sx, b_ex, b_scan; logic b_x;
  logic b_start_now;
  assign b_start_now = !b_busy && hb_adone[hb_head] && hb_ooxv[hb_head];
  // v8: a free instance, started at a GAP the adder allows. The adder is the one unit whose use spans more than 16
  // offsets (0 1 8 9 13 18 22); two instances collide on it at start gaps 17, 18, 21, 22 (its pairwise offset
  // differences), so the gap (= the other instance's offset + 1) must be 16, 19, 20 or >= 23. Every other unit and
  // RAM read port spans < 16, and the reciprocal needs >= 16.
  function automatic logic gap_ok(input logic busy, input logic [7:0] c);
    return !busy || c == 8'd15 || c == 8'd18 || c == 8'd19 || c >= 8'd22;
  endfunction
  assign astart = !(a_busy[0] && a_busy[1]) && gap_ok(a_busy[0], ca[0]) && gap_ok(a_busy[1], ca[1]) &&
                  pst == P_RDY && reserved < 2'd2;

  assign in_ready = (fst == F_IDLE);
  assign idle = (fst == F_IDLE) && !ps_valid[0] && !ps_valid[1] && !a_any && !b_busy && reserved == 2'd0;

  // A's round issues (the FE must not issue in these clocks)
  assign fe_rc_ok = !(a_busy[0] && (ca[0] == 8'(3*L) || ca[0] == 8'(3*L + 1))) && !(a_busy[1] && (ca[1] == 8'(3*L) || ca[1] == 8'(3*L + 1)));

  // ================= RAM read addresses: one clock ahead of A's use =================
  // needs at A offset k (data used at k, address presented at k-1): X: 0 y1L, 1 y1R, L dxdyL, L+1 dxdyR, 2L x1L, 2L+1 x1R;
  // D: L+p dpdyL[p], L+4+p dpdyR[p]; P: 2L+p p1L[p], 2L+4+p p1R[p]
  always_comb begin : raddr
    rx_ra = '0; rp_ra = '0; rd_ra = '0;
    for (int i = 0; i < 3; i++) begin : src                // instance 0, instance 1, and the instance starting now
      logic act; logic [7:0] k; logic s, lsd, rsd; logic [1:0] li, ri;
      if (i == 2) begin act = astart; k = 8'd0; s = p_ps; lsd = p_ls; rsd = p_rs; li = p_li; ri = p_ri; end
      else begin act = a_busy[i]; k = ca[i] + 8'd1; s = a_ps[i]; lsd = a_ls[i]; rsd = a_rs[i]; li = a_li[i]; ri = a_ri[i]; end
      if (act) begin
        if (k == 8'd0)          rx_ra = {eid(s, lsd, li), FX_Y1};
        if (k == 8'd1)          rx_ra = {eid(s, rsd, ri), FX_Y1};
        if (k == 8'(L))         rx_ra = {eid(s, lsd, li), FX_DXDY};
        if (k == 8'(L + 1))     rx_ra = {eid(s, rsd, ri), FX_DXDY};
        if (k == 8'(2*L))       rx_ra = {eid(s, lsd, li), FX_X1};
        if (k == 8'(2*L + 1))   rx_ra = {eid(s, rsd, ri), FX_X1};
        for (int p = 0; p < 4; p++) begin
          if (k == 8'(L + p))       rd_ra = {eid(s, lsd, li), 2'(p)};
          if (k == 8'(L + 4 + p))   rd_ra = {eid(s, rsd, ri), 2'(p)};
          if (k == 8'(2*L + p))     rp_ra = {eid(s, lsd, li), 2'(p)};
          if (k == 8'(2*L + 4 + p)) rp_ra = {eid(s, rsd, ri), 2'(p)};
        end
      end
    end
  end

  // ================= op issue =================
  always_comb begin
    as_a = '0; as_b = '0; as_sub = 1'b0; ms_a = '0; ms_b = '0; ap_a = '0; ap_b = '0; ap_sub = 1'b0; mp_a = '0; mp_b = '0;
    aq_a = '0; aq_b = '0; mq_a = '0; mq_b = '0; ea_a = '0; ea_b = '0; em_a = '0; em_b = '0;
    rcp_start = 1'b0; rcp_b = '0; erc_start[0] = 1'b0; erc_start[1] = 1'b0; erc_b = '0; rc_in = '0;
    rx_we = 1'b0; rp_we = 1'b0; rd_we = 1'b0; rx_wa = '0; rp_wa = '0; rd_wa = '0; rx_wd = '0; rp_wd = '0; rd_wd = '0;
    // ---- FE ----
    if (fst == F_Y0 && fe_rc_ok) rc_in = v[minv][1];
    if (fst == F_Y1 && fe_rc_ok) rc_in = v[maxv][1];
    if (fst == F_ERUN) begin
      // v7 PRE (job pj in slot pre_s): one edge add per clock on the E adder -- dy, dx, dp0..dp3 (all v2 - v1) -- and
      // the reciprocal of dy on unit pre_u
      if (pre_on) begin
        if (c == 0) begin ea_a = py2; ea_b = q_y1[pre_s]; end
        if (c == 1) begin ea_a = px2; ea_b = q_x1[pre_s]; end
        for (int p = 0; p < 4; p++) if (c == 8'(2 + p)) begin ea_a = pp2[p]; ea_b = q_p1[pre_s][p]; end
        if (c == 8'(L)) begin erc_start[pre_u] = 1'b1; erc_b = ea_y; end                                  // ooy
      end
      // v7 POST (job qj in slot qs): dxdy and dpdy on the E multiplier, then the edge-store writes
      if (post_on) begin : pw
        logic [3:0] e; e = eid(fe_ps, j_side[qj[1:0]], j_idx[qj[1:0]]);
        if (ec == 0) begin em_a = q_dx[qs]; em_b = q_ooy[qs]; end                                         // dxdy
        for (int p = 0; p < 4; p++) if (ec == 8'(1 + p)) begin em_a = q_dp[qs][p]; em_b = q_ooy[qs]; end  // dpdy
        if (ec == 8'(L)) begin rx_we = 1'b1; rx_wa = {e, FX_DXDY}; rx_wd = em_y; end
        if (ec == 8'd0)  begin rx_we = 1'b1; rx_wa = {e, FX_X1}; rx_wd = q_x1[qs]; end
        if (ec == 8'd1)  begin rx_we = 1'b1; rx_wa = {e, FX_Y1}; rx_wd = q_y1[qs]; end
        for (int p = 0; p < 4; p++) begin
          if (ec == 8'(L + 1 + p)) begin rd_we = 1'b1; rd_wa = {e, 2'(p)}; rd_wd = em_y; end
          if (ec == 8'(p))         begin rp_we = 1'b1; rp_wa = {e, 2'(p)}; rp_wd = q_p1[qs][p]; end
        end
      end
    end
    // ---- A ----
    for (int i = 0; i < 2; i++) if (a_busy[i]) begin : ai
      logic [7:0] q; q = ca[i];
      if (q == 0) begin as_a = a_fully[i]; as_b = rx_q; as_sub = 1'b1; end                               // ldy  (y1 L)
      if (q == 1) begin as_a = a_fully[i]; as_b = rx_q; as_sub = 1'b1; end                               // rdy  (y1 R)
      if (q == 8'(L))     begin ms_a = as_y; ms_b = rx_q; end                                            // lt   (dxdy L)
      if (q == 8'(L + 1)) begin ms_a = as_y; ms_b = rx_q; end                                            // rt   (dxdy R)
      for (int p = 0; p < 4; p++) begin
        if (q == 8'(L + p))       begin mp_a = (p == 0) ? as_y : ldy; mp_b = rd_q; end                   // lm
        if (q == 8'(L + 4 + p))   begin mp_a = rdy; mp_b = rd_q; end                                     // rm
        if (q == 8'(2*L + p))     begin ap_a = rp_q; ap_b = mp_y; end                                    // lp
        if (q == 8'(2*L + 4 + p)) begin ap_a = rp_q; ap_b = mp_y; end                                    // rp
        if (q == 8'(D0 + p))      begin ap_a = a_rp[p]; ap_b = hb_lp[a_slot[i]][p]; ap_sub = 1'b1; end   // d
      end
      if (q == 8'(2*L))     begin as_a = rx_q; as_b = ms_y; end                                          // sx (x1 L)
      if (q == 8'(2*L + 1)) begin as_a = rx_q; as_b = ms_y; end                                          // ex (x1 R)
      if (q == 8'(3*L))     rc_in = as_y;
      if (q == 8'(3*L + 1)) begin as_a = as_y; as_b = sx; as_sub = 1'b1; rc_in = as_y; end
      if (q == 8'(3*L + 6)) begin as_a = ixf; as_b = F_HALF; end
      if (q == 8'(4*L + 1) && !a_empty[i]) begin rcp_start = 1'b1; rcp_b = as_y; end   // v6: 4L+1 == 3L+5 (the empty exit) at L = 4
      if (q == 8'(4*L + 6)) begin as_a = as_y; as_b = sx; as_sub = 1'b1; end
    end
    // ---- B ----
    if (b_busy && !b_emit) begin
      for (int p = 0; p < 4; p++) begin
        if (cb == 8'(p))          begin mq_a = b_dd[p]; mq_b = b_oox; end
        if (cb == 8'(W0 + p))     begin mq_a = b_w; mq_b = b_dpdx[p]; end
        if (cb == 8'(W0 + L + p)) begin aq_a = b_lp[p]; aq_b = mq_y; end
      end
    end
  end

  // Ownership invariant, checked independently of timing: nothing may write a slot while A works on it.
`ifdef ZR_SIM
  // v8: both A instances driving one unit in the same clock is a hazard too (the start-gap rule's check)
  function automatic logic [5:0] a_use(input logic busy, input logic [7:0] q);   // {as, ms, mp, ap, rc, rcp}
    logic [5:0] u; u = '0;
    if (busy) begin
      u[5] = q == 0 || q == 1 || q == 8'(2*L) || q == 8'(2*L + 1) || q == 8'(3*L + 1) || q == 8'(3*L + 6) || q == 8'(4*L + 6);
      u[4] = q == 8'(L) || q == 8'(L + 1);
      u[3] = q >= 8'(L) && q <= 8'(L + 7);
      u[2] = (q >= 8'(2*L) && q <= 8'(2*L + 7)) || (q >= 8'(D0) && q <= 8'(D0 + 3));
      u[1] = q == 8'(3*L) || q == 8'(3*L + 1);
      u[0] = q == 8'(4*L + 1);
    end
    return u;
  endfunction
  always_ff @(posedge clk)
    if (rst) hazard <= 1'b0;
    else begin
      for (int i = 0; i < 2; i++)
        if (a_busy[i] && ((rx_we && rx_wa[5] == a_ps[i]) || (rp_we && rp_wa[5] == a_ps[i]) || (rd_we && rd_wa[5] == a_ps[i]) ||
                           (fst == F_ERUN && fe_ps == a_ps[i]) || (fst == F_LR2 && fe_ps == a_ps[i]))) hazard <= 1'b1;
      if ((a_use(a_busy[0], ca[0]) & a_use(a_busy[1], ca[1])) != 6'd0) begin
        hazard <= 1'b1; $display("A-instance unit collision: offsets %0d %0d", ca[0], ca[1]);
      end
    end
`else
  assign hazard = 1'b0;
`endif

  always_ff @(posedge clk) begin
    rejected <= 1'b0;
    if (rst) begin st_clk <= '0; st_fe <= '0; st_a <= '0; st_b <= '0; end
    else begin
      st_clk <= st_clk + 1;                                  // engine-busy census for the area campaign
      if (fst != F_IDLE) st_fe <= st_fe + 1;                 // FE / edge jobs: owns u_ea, u_em, u_erc
      if (a_any) st_a <= st_a + 1;                          // phase A: owns u_as, u_ms, u_rcp
      if (b_busy) st_b <= st_b + 1;                          // phase B: owns u_ap / u_aq, u_mp / u_mq
    end
    if (rst) begin
      fst <= F_IDLE; fe_ps <= 1'b0; pre_on <= 1'b0; post_on <= 1'b0;
      ps_valid[0] <= 1'b0; ps_valid[1] <= 1'b0; ps_issued[0] <= 1'b0; ps_issued[1] <= 1'b0;
      pst <= P_WAIT; p_ps <= 1'b0;
      a_busy[0] <= 1'b0; a_busy[1] <= 1'b0; b_busy <= 1'b0; b_emit <= 1'b0; ext_valid <= 1'b0;
      hb_adone[0] <= 1'b0; hb_adone[1] <= 1'b0; hb_ooxv[0] <= 1'b0; hb_ooxv[1] <= 1'b0; reserved <= 2'd0; hb_head <= 1'b0;
    end else begin
      // ================= FE =================
      case (fst)
        F_IDLE: if (start) begin
          v <= vin; f_cminx <= clip_min_x; f_cmaxx <= clip_max_x; f_cminy <= clip_min_y; f_cmaxy <= clip_max_y;
          minv <= 2'd0; maxv <= 2'd0; mk <= 2'd1; fst <= F_MINMAX;
        end
        F_MINMAX: begin
          if (fp_lt(v[mk][1], v[minv][1])) minv <= mk;
          else if (fp_gt(v[mk][1], v[maxv][1])) maxv <= mk;
          if (mk == 2'd3) fst <= F_Y0; else mk <= mk + 2'd1;
        end
        // y clip through the shared round unit: each issue waits for a clock A leaves free; result 3 clocks later
        F_Y0:  if (fe_rc_ok) fst <= F_YW1;
        F_YW1: fst <= F_YW2;
        F_YW2: fst <= F_Y2;
        F_Y2:  begin f_minyc <= (rc_out > f_cminy) ? rc_out : f_cminy; fst <= F_Y1; end
        F_Y1:  if (fe_rc_ok) begin ywait <= 2'd0; fst <= F_Y3; end
        F_Y3:  if (ywait != 2'd2) ywait <= ywait + 2'd1; else begin : yc
          logic signed [31:0] b;
          b = (rc_out < f_cmaxy + 32'sd1) ? rc_out : f_cmaxy + 32'sd1;
          f_maxyc <= b;
          if (b - f_minyc <= 32'sd0) begin rejected <= 1'b1; fst <= F_IDLE; end
          else fst <= F_WSLOT;
        end
        F_WSLOT: if (!ps_valid[fe_ps]) begin
          side <= 1'b0; cv <= minv; e_cnt[0] <= 2'd0; e_cnt[1] <= 2'd0; nj <= 3'd0; fst <= F_EBUILD;
        end
        F_EBUILD: begin
          if (cv == maxv) begin
            if (side == 1'b0) begin side <= 1'b1; cv <= minv; end
            else begin fst <= (nj == 3'd0) ? F_LR : F_ERUN; pj <= '0; qj <= '0; pre_s <= '0; qs <= '0; pre_on <= 1'b0; post_on <= 1'b0; for (int k = 0; k < 3; k++) q_busy[k] <= 1'b0; end
          end else begin
            if (!fp_eq(v[cv][1], v[nextv(side, cv)][1])) begin
              j_side[nj[1:0]] <= side; j_idx[nj[1:0]] <= e_cnt[side]; j_v1[nj[1:0]] <= cv; j_v2[nj[1:0]] <= nextv(side, cv);
              if (e_cnt[side] == 2'd0) begin f_v1first[side] <= cv; f_x1first[side] <= v[cv][0]; end
              e_cnt[side] <= e_cnt[side] + 2'd1; nj <= nj + 3'd1;
            end
            cv <= nextv(side, cv);
          end
        end
        // v7: edge jobs PIPELINED. PRE (latch + 6 adds + the reciprocal start) runs job j+1 while POST (5 multiplies +
        // the edge-store writes) finishes job j; three job slots, two reciprocal units (job j uses unit j[0]). v5/v6
        // ran each job to completion before latching the next (~31 clocks per edge, the reciprocal alone 16).
        F_ERUN: begin
          // PRE: start job pj when its slot is free and its reciprocal unit is idle
          if (!pre_on) begin
            if (pj != nj && !q_busy[pre_s] && !erc_busy[pj[0]] && !erc_done[pj[0]]) begin
              q_x1[pre_s] <= v[j_v1[pj[1:0]]][0]; q_y1[pre_s] <= v[j_v1[pj[1:0]]][1]; q_y2[pre_s] <= v[j_v2[pj[1:0]]][1];
              px2 <= v[j_v2[pj[1:0]]][0]; py2 <= v[j_v2[pj[1:0]]][1];
              for (int p = 0; p < 4; p++) begin q_p1[pre_s][p] <= v[j_v1[pj[1:0]]][2 + p]; pp2[p] <= v[j_v2[pj[1:0]]][2 + p]; end
              q_busy[pre_s] <= 1'b1; q_rdy[pre_s] <= 1'b0; pre_u <= pj[0]; pre_on <= 1'b1; c <= '0;
            end
          end else begin
            c <= c + 8'd1;
            if (c == 8'(L)) begin q_x[pre_s] <= ea_x; erc_s[pre_u] <= pre_s; end
            if (c == 8'(L + 1)) begin q_dx[pre_s] <= ea_y; if (ea_x) q_x[pre_s] <= 1'b1; end
            for (int p = 0; p < 4; p++) if (c == 8'(L + 2 + p)) begin q_dp[pre_s][p] <= ea_y; if (ea_x) q_x[pre_s] <= 1'b1; end
            if (c == 8'(L + 5)) begin pre_on <= 1'b0; pj <= pj + 3'd1; pre_s <= (pre_s == 2'd2) ? 2'd0 : pre_s + 2'd1; end
          end
          for (int u = 0; u < 2; u++) if (erc_done[u]) begin
            q_ooy[erc_s[u]] <= erc_y[u]; q_rdy[erc_s[u]] <= 1'b1; if (erc_x[u]) q_x[erc_s[u]] <= 1'b1;
          end
          // POST: finish job qj in order once its reciprocal has landed
          if (!post_on) begin
            if (qj != nj && q_rdy[qs]) begin post_on <= 1'b1; ec <= '0; end
          end else begin : epost
            logic sd; logic [1:0] ix;
            sd = j_side[qj[1:0]]; ix = j_idx[qj[1:0]];
            ec <= ec + 8'd1;
            if (ec == 8'(L)) begin if (em_x) q_x[qs] <= 1'b1; if (ix == 2'd0) f_dxdyfirst[sd] <= em_y; end
            for (int p = 0; p < 4; p++) if (ec == 8'(L + 1 + p) && em_x) q_x[qs] <= 1'b1;
            if (ec == 8'(L + 5)) begin
              ps_exc[fe_ps][sd][ix] <= q_x[qs]; ps_y2[fe_ps][sd][ix] <= q_y2[qs];
              q_busy[qs] <= 1'b0; q_rdy[qs] <= 1'b0; post_on <= 1'b0;
              qj <= qj + 3'd1; qs <= (qs == 2'd2) ? 2'd0 : qs + 2'd1;
              if (qj + 3'd1 == nj) fst <= F_LR;
            end
          end
        end
        F_LR: begin
          lr_shared <= (f_v1first[0] == f_v1first[1]);
          lr_slope  <= fp_lt(f_dxdyfirst[0], f_dxdyfirst[1]);
          lr_x      <= fp_lt(f_x1first[0], f_x1first[1]);
          fst <= F_LR2;
        end
        F_LR2: begin
          ps_lf[fe_ps] <= (lr_shared && lr_slope) || (!lr_shared && lr_x);
          ps_minyc[fe_ps] <= f_minyc; ps_maxyc[fe_ps] <= f_maxyc; ps_maxy[fe_ps] <= v[maxv][1];
          ps_cminx[fe_ps] <= f_cminx; ps_cmaxx[fe_ps] <= f_cmaxx;
          ps_valid[fe_ps] <= 1'b1; ps_issued[fe_ps] <= 1'b0; fe_ps <= ~fe_ps; fst <= F_IDLE;
        end
        default: fst <= F_IDLE;
      endcase

      // ================= PREP =================
      case (pst)
        // v8: with two A instances the previous occupant may still be in A when prep returns here -- ps_issued says it
        // is the OLD polygon (every scanline already issued), not a new one
        P_WAIT: if (ps_valid[p_ps] && !ps_issued[p_ps]) begin
          p_scan <= ps_minyc[p_ps]; p_li <= 2'd0; p_ri <= 2'd0; pst <= P_FULLY;
        end
        P_FULLY: begin : fy
          fres_t r; r = fp_i2f16(16'(p_scan * 2 + 32'sd1));
          p_fully <= {r.v[31], r.v[30:23] - 8'd1, r.v[22:0]};
          pst <= P_ADVL;
        end
        P_ADVL: if (fp_gt(p_fully, ps_y2[p_ps][p_ls][p_li]) && fp_lt(p_fully, ps_maxy[p_ps])) p_li <= p_li + 2'd1; else pst <= P_ADVR;
        P_ADVR: if (fp_gt(p_fully, ps_y2[p_ps][p_rs][p_ri]) && fp_lt(p_fully, ps_maxy[p_ps])) p_ri <= p_ri + 2'd1; else pst <= P_RDY;
        P_RDY: ;
        default: pst <= P_WAIT;
      endcase

      // ================= A =================
      if (astart) begin : as0
        logic sl; logic last;
        sl = (reserved == 2'd0) ? hb_head : ~hb_head;
        last = (p_scan + 32'sd1 >= ps_maxyc[p_ps]);
        a_busy[a_new] <= 1'b1; ca[a_new] <= '0; a_slot[a_new] <= sl; a_ps[a_new] <= p_ps; a_last[a_new] <= last; a_empty[a_new] <= 1'b0;
        a_scan[a_new] <= p_scan; a_fully[a_new] <= p_fully; a_li[a_new] <= p_li; a_ri[a_new] <= p_ri;
        a_x[a_new] <= ps_exc[p_ps][p_ls][p_li] | ps_exc[p_ps][p_rs][p_ri];
        reserved <= reserved + 2'd1 - (b_start_now ? 2'd1 : 2'd0);
        if (last) begin p_ps <= ~p_ps; pst <= P_WAIT; ps_issued[p_ps] <= 1'b1; end   // this polygon fully prepared: move to the next slot
        else begin p_scan <= p_scan + 32'sd1; pst <= P_FULLY; end
      end else if (b_start_now) reserved <= reserved - 2'd1;
      for (int i = 0; i < 2; i++) if (a_busy[i] && !(astart && a_new == 1'(i))) begin : ai
        logic [7:0] q; logic sl; q = ca[i]; sl = a_slot[i];
        ca[i] <= q + 8'd1;
        if (q == 8'(L))     begin ldy <= as_y; if (as_x) a_x[i] <= 1'b1; end
        if (q == 8'(L + 1)) begin rdy <= as_y; if (as_x) a_x[i] <= 1'b1; end
        if ((q == 8'(2*L) || q == 8'(2*L + 1)) && ms_x) a_x[i] <= 1'b1;
        if (q == 8'(3*L))     begin sx <= as_y; if (as_x) a_x[i] <= 1'b1; end
        if (q == 8'(3*L + 1) && as_x) a_x[i] <= 1'b1;
        if (q == 8'(3*L + 3)) begin rsx <= rc_out; if (rc_exc_out) a_x[i] <= 1'b1; end
        if (q == 8'(3*L + 4)) begin : oc
          logic signed [31:0] a, b;
          if (rc_exc_out) a_x[i] <= 1'b1;
          a = rsx; b = rc_out;
          if (a > b) begin logic signed [31:0] t; t = a; a = b; b = t; end
          if (a < ps_cminx[a_ps[i]]) a = ps_cminx[a_ps[i]];
          if (b > ps_cmaxx[a_ps[i]] + 32'sd1) b = ps_cmaxx[a_ps[i]] + 32'sd1;
          hb_sx[sl] <= a; hb_ex[sl] <= b;
          a_istart <= a;                                                    // int->float in the next clock (timing)
          a_empty[i] <= (a >= b);
        end
        if (q == 8'(3*L + 5)) begin : i2f                                   // ixf = float(istartx); ixh issues at 3L+6
          fres_t r; r = fp_i2f16(16'(a_istart)); ixf <= r.v;
          if (a_istart > 32'sd32767 || a_istart < -32'sd32768) a_x[i] <= 1'b1;
        end
        if ((q == 8'(4*L + 1) || q == 8'(4*L + 6)) && as_x) a_x[i] <= 1'b1;
        for (int p = 0; p < 4; p++) begin
          if ((q == 8'(2*L + p) || q == 8'(2*L + 4 + p)) && mp_x) a_x[i] <= 1'b1;
          if (q == 8'(3*L + p))     begin hb_lp[sl][p] <= ap_y; if (ap_x) a_x[i] <= 1'b1; end
          if (q == 8'(3*L + 4 + p)) begin a_rp[p] <= ap_y; if (ap_x) a_x[i] <= 1'b1; end
          if (q == 8'(D0 + L + p))  begin hb_dd[sl][p] <= ap_y; if (ap_x) a_x[i] <= 1'b1; end
        end
        if (q == 8'(4*L + 1) && !a_empty[i]) rcp_slot <= sl;
        if (q == 8'(A_W)) begin hb_w[sl] <= as_y; if (as_x) a_x[i] <= 1'b1; end
        if (q == 8'(A_END) || (q == 8'(3*L + 5) && a_empty[i])) begin
          hb_x[sl] <= a_x[i]; hb_scan[sl] <= a_scan[i]; hb_adone[sl] <= 1'b1; a_busy[i] <= 1'b0; hb_last[sl] <= a_last[i];
          if (a_last[i]) ps_valid[a_ps[i]] <= 1'b0;               // A no longer reads this polygon's edge data
          hb_empty[sl] <= a_empty[i];
          // v6: an EMPTY extent ends A here -- no parameter half, no reciprocal (nothing would read them: MAME never
          // draws an extent with istartx >= istopx, and the renderer drops it). It still flows through B in order,
          // because it carries the scanline and, possibly, its polygon's last-extent mark.
          if (a_empty[i]) hb_ooxv[sl] <= 1'b1;
        end
      end
      if (rcp_done) begin hb_oox[rcp_slot] <= rcp_y; hb_rx[rcp_slot] <= rcp_x; hb_ooxv[rcp_slot] <= 1'b1; end

      // ================= B =================
      if (b_start_now) begin
        b_busy <= 1'b1; b_emit <= hb_empty[hb_head]; cb <= '0;    // v6: an empty extent goes straight to the emit
        b_lp <= hb_lp[hb_head]; b_dd <= hb_dd[hb_head]; b_w <= hb_w[hb_head]; b_oox <= hb_oox[hb_head];
        b_sx <= hb_sx[hb_head]; b_ex <= hb_ex[hb_head]; b_scan <= hb_scan[hb_head];
        b_x <= hb_x[hb_head] | hb_rx[hb_head]; b_last <= hb_last[hb_head];
        hb_adone[hb_head] <= 1'b0; hb_ooxv[hb_head] <= 1'b0; hb_head <= ~hb_head;
      end else if (b_busy && !b_emit) begin
        cb <= cb + 8'd1;
        for (int p = 0; p < 4; p++) begin
          if (cb == 8'(L + p))          begin b_dpdx[p] <= mq_y; if (mq_x) b_x <= 1'b1; end
          if (cb == 8'(W0 + L + p) && mq_x) b_x <= 1'b1;
          if (cb == 8'(W0 + 2*L + p))   begin b_st[p] <= aq_y; if (aq_x) b_x <= 1'b1; end
        end
        if (cb == 8'(B_LAST)) b_emit <= 1'b1;
      end else if (b_busy && b_emit) begin
        if (!ext_valid) begin
          ext_valid <= 1'b1; ext_scan <= b_scan;
          if (b_sx >= b_ex) begin ext_startx <= 16'sd0; ext_stopx <= 16'sd0; end
          else begin ext_startx <= 16'(b_sx); ext_stopx <= 16'(b_ex); end
          ext_start <= b_st; ext_dpdx <= b_dpdx; ext_exc <= b_x; ext_last <= b_last;
        end else if (ext_ready) begin
          ext_valid <= 1'b0; b_busy <= 1'b0; b_emit <= 1'b0;
        end
      end
    end
  end
endmodule
