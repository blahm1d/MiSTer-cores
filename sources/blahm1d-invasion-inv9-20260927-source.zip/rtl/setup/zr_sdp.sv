// zr_sdp.sv -- simple dual-port RAM (one write port, one registered read port) in the Quartus M10K inference shape.
// Read data appears the clock AFTER the address. Callers guarantee write and read never target the same word in the
// same clock (zr_setup5: the front end writes a free polygon slot, phase A reads an owned one).
module zr_sdp #(parameter int W = 32, parameter int AW = 6) (
  input  logic          clk,
  input  logic          we,
  input  logic [AW-1:0] waddr,
  input  logic [W-1:0]  wdata,
  input  logic [AW-1:0] raddr,
  output logic [W-1:0]  rdata
);
  logic [W-1:0] mem [2**AW];
  always_ff @(posedge clk) begin
    if (we) mem[waddr] <= wdata;
`ifdef ZR_RDW_HOSTILE
    // sim only: a same-word read and write in one clock returns WRONG data (the new word, bit 0 flipped) instead of
    // the old word, so a caller that relies on M10K mixed-port read-during-write fails its gate
    if (we && waddr == raddr) rdata <= wdata ^ W'(1); else
`endif
    rdata <= mem[raddr];
  end
endmodule
