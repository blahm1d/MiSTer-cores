// SPDX-License-Identifier: BSD-3-Clause
// c31_memory_p3 -- the P2 request/response memory tier (bandwidth/a1d/rtl/mem_p2/c31_memory_p2.sv, gate
// build/c31-memp2-20260917T024715224345Z) plus a read-only FETCH PORT (docs/PLAN-A1D-PIPELINE-20260917.md section 0,
// step 3). Address map and data-port contract are unchanged; see the P2 header. Blind transcription of the pinned MAME
// crusnusa map midvunit.cpp:666-693.
//
// Fetch port (a pipelined core issues one per clock, speculatively):
//   f_valid/f_addr   fetch request this clock
//   f_accept         combinational: taken. Internal RAM (0x809800-0x809fff) always; main RAM (0x000000-0x01ffff) when
//                    its page is in the main cache's fetch page map. Anything else, or a map miss: the master fetches
//                    through the data port instead, with req_fetch=1 (which installs the page in the map on a hit).
//   f_rsp_valid/f_rdata  next clock: the word. f_rsp_valid is withheld when the port-B read collided with a data-port
//                    write to the same word in the same clock (mixed-port read-during-write is don't-care, no_rw_check),
//                    so a stale word is never delivered; the master re-requests.
// Every executed PC is main or internal RAM (CENSUS.md); ROM is never fetched, so the ROM cache has no fetch port.
`default_nettype none
module c31_memory_p3 #(
   parameter integer NUM_MAIN_PAGES = 172,
   parameter integer NUM_ROM_PAGES  = 16,    // ladder rung 1b
   parameter integer CMOS_WORDS     = 8192,
   parameter integer CMOS_ABITS     = 13,
   parameter integer FETCH_MAP      = 4
)(
   input  wire        clk,
   input  wire        ce,
   input  wire        rst,

   // ---- core data port (request/response) ----
   input  wire        req_valid,
   input  wire        req_write,
   input  wire        req_fetch,
   input  wire [23:0] req_addr,
   input  wire [31:0] req_wdata,
   output logic       req_accept,
   output logic       rsp_valid,
   output logic [31:0] rsp_rdata,
   output logic       guest_pause,

   // ---- core fetch port ----
   input  wire        f_valid,
   input  wire [23:0] f_addr,
   output logic       f_accept,
   output logic       f_rsp_valid,
   output logic [31:0] f_rdata,

   // ---- SDRAM word port ----
   output logic        sd_req,
   output logic        sd_burst,
   output logic        sd_we,
   output logic [23:0] sd_addr,
   output logic [31:0] sd_wdata,
   input  wire         sd_ack,
   input  wire [31:0]  sd_rdata,

   // ---- external passthrough (V-unit windows + peripherals + IO) ----
   output logic        ext_valid,
   output logic        ext_write,
   output logic [23:0] ext_addr,
   output logic [31:0] ext_wdata,
   input  wire         ext_ready,
   input  wire [31:0]  ext_rdata,

   // ---- diagnostics ----
   output logic        nvram_protected,
   output logic [63:0] stat_main_hits, stat_main_misses,
   output logic [63:0] stat_rom_hits,  stat_rom_misses,
   output logic [63:0] stat_pause_clocks,
   output logic [63:0] stat_fetch_accepts,
   output logic [63:0] stat_fetch_rejects,
   output logic [63:0] stat_fetch_stale
);
   // ---- address decode of the LIVE data request (disjoint ranges) ----
   wire is_internal = (req_addr >= 24'h809800) && (req_addr <= 24'h809fff);
   wire is_main     = (req_addr <= 24'h01ffff);
   wire is_fast     = (req_addr >= 24'h400000) && (req_addr <= 24'h41ffff);
   wire is_rom      = (req_addr >= 24'hc00000);
   wire is_cmos     = (req_addr >= 24'h9c0000) && (req_addr <= 24'h9c1fff);
   wire is_cmosprot = (req_addr == 24'h995020);
   wire is_sddirect = is_fast || is_cmos;
   wire is_ext      = !(is_internal || is_main || is_fast || is_rom || is_cmos || is_cmosprot);
   wire [10:0] iram_off = req_addr[10:0];
   wire cmos_wr_blocked = is_cmos && req_write && nvram_protected;

   // ---- owner-latched SDRAM arbiter signals ----
   localparam [1:0] OWN_MAIN=2'd0, OWN_ROM=2'd1, OWN_SDD=2'd2;
   logic       sd_busy;  logic [1:0] sd_owner, grant;  logic grant_valid;
   logic       sd_cool;
   // Replies belong to the registered owner, never the next combinational grant.
   wire        ack_main = sd_ack && sd_busy && (sd_owner == OWN_MAIN);
   wire        ack_rom  = sd_ack && sd_busy && (sd_owner == OWN_ROM);
   wire        ack_sdd  = sd_ack && sd_busy && (sd_owner == OWN_SDD);

   // ---- fetch port decode ----
   wire f_is_internal = (f_addr >= 24'h809800) && (f_addr <= 24'h809fff);

   // ================= main / ROM page caches =================
   logic        main_acc, main_rspv, main_fast, main_pause;  logic [31:0] main_rdata;
   logic        main_sd_burst, main_sd_req, main_sd_we;  logic [23:0] main_sd_addr;  logic [31:0] main_sd_wdata;
   logic        main_f_hit, main_f_stale;  logic [31:0] main_f_rdata;
   c31_page_cache #(.NUM_PAGES(NUM_MAIN_PAGES), .BASE(24'h000000), .PAGE_NUM_BITS(9),  .WRITABLE(1'b1),
                    .FETCH_PORT(1'b1), .FETCH_MAP(FETCH_MAP)) u_main (
      .clk(clk), .ce(ce), .rst(rst),
      .req_valid(req_valid && is_main), .req_write(req_write), .req_fetch(req_fetch), .req_addr(req_addr),
      .req_wdata(req_wdata),
      .req_accept(main_acc), .rsp_valid(main_rspv), .rsp_fast(main_fast), .rsp_rdata(main_rdata),
      .busy_pause(main_pause),
      .f_valid(f_valid && !f_is_internal), .f_addr(f_addr), .f_hit(main_f_hit), .f_rdata(main_f_rdata),
      .f_stale(main_f_stale),
      .sd_burst(main_sd_burst), .sd_req(main_sd_req), .sd_we(main_sd_we), .sd_addr(main_sd_addr), .sd_wdata(main_sd_wdata),
      .sd_ack(ack_main), .sd_rdata(sd_rdata),
      .stat_hits(stat_main_hits), .stat_misses(stat_main_misses), .stat_pause_clocks());

   logic        rom_acc, rom_rspv, rom_fast, rom_pause;  logic [31:0] rom_rdata;
   logic        rom_sd_burst, rom_sd_req, rom_sd_we;  logic [23:0] rom_sd_addr;  logic [31:0] rom_sd_wdata;
   logic        rom_f_hit_unused, rom_f_stale_unused;  logic [31:0] rom_f_rdata_unused;
   c31_page_cache #(.NUM_PAGES(NUM_ROM_PAGES), .BASE(24'hc00000), .PAGE_NUM_BITS(14), .WRITABLE(1'b0),
                    .FETCH_PORT(1'b0)) u_rom (
      .clk(clk), .ce(ce), .rst(rst),
      .req_valid(req_valid && is_rom), .req_write(req_write), .req_fetch(1'b0), .req_addr(req_addr),
      .req_wdata(req_wdata),
      .req_accept(rom_acc), .rsp_valid(rom_rspv), .rsp_fast(rom_fast), .rsp_rdata(rom_rdata),
      .busy_pause(rom_pause),
      .f_valid(1'b0), .f_addr(24'd0), .f_hit(rom_f_hit_unused), .f_rdata(rom_f_rdata_unused),
      .f_stale(rom_f_stale_unused),
      .sd_burst(rom_sd_burst), .sd_req(rom_sd_req), .sd_we(rom_sd_we), .sd_addr(rom_sd_addr), .sd_wdata(rom_sd_wdata),
      .sd_ack(ack_rom), .sd_rdata(sd_rdata),
      .stat_hits(stat_rom_hits), .stat_misses(stat_rom_misses), .stat_pause_clocks());

   // ================= internal RAM (2K x 32, true-dual-port M10K: port A data R/W, port B fetch R) =================
   logic [10:0] iram_raddr, iram_waddr;  logic iram_we;  logic [31:0] iram_wdata, iram_rdata, iram_f_rdata;
   wire  [10:0] iram_addr_a = iram_we ? iram_waddr : iram_raddr;
   (* ramstyle = "M10K, no_rw_check" *) logic [31:0] iram [0:2047];
   always_ff @(posedge clk) begin
      if (iram_we) begin iram[iram_addr_a] <= iram_wdata; iram_rdata <= iram_wdata; end
      else         iram_rdata <= iram[iram_addr_a];
   end
   always_ff @(posedge clk) iram_f_rdata <= iram[f_addr[10:0]];

   // ================= top FSM: internal / cmosprot / SDRAM-direct(fast+CMOS) / ext =====
   localparam [2:0] T_IDLE=3'd0, T_SIMPLE_RD=3'd1, T_SDD=3'd2, T_EXT=3'd3, T_ZERO_RD=3'd4;
   logic [2:0]  tstate;
   logic        top_acc, top_rspv, top_pause;  logic [31:0] top_rdata;
   // External/direct transactions cross a register before reaching side effects.
   // A response can therefore coexist with selecting the next early RAM read.
   logic [23:0] top_addr_q;
   logic [31:0] top_wdata_q;
   logic top_write_q;

   wire fast_rsp_now = main_fast || rom_fast || (tstate == T_SIMPLE_RD);
   wire top_take_new = (tstate == T_IDLE) || (tstate == T_SIMPLE_RD);

   logic        sdd_req, sdd_we;  logic [23:0] sdd_addr;  logic [31:0] sdd_wdata;

   always_comb begin
      top_acc = 1'b0; top_rspv = 1'b0; top_rdata = 32'd0; top_pause = 1'b0;
      iram_we = 1'b0; iram_waddr = '0; iram_wdata = 32'd0; iram_raddr = iram_off;
      sdd_req = 1'b0; sdd_we = 1'b0; sdd_addr = req_addr; sdd_wdata = req_wdata;
      ext_valid = 1'b0; ext_write = top_write_q; ext_addr = top_addr_q; ext_wdata = top_wdata_q;

      if (tstate == T_SIMPLE_RD) begin
         top_rspv = 1'b1;
         top_rdata = iram_rdata;
      end
      if (top_take_new && req_valid) begin
         if (is_internal) begin
            iram_raddr = iram_off;
            top_acc = 1'b1;
            if (req_write) begin
               iram_we = 1'b1; iram_waddr = iram_off; iram_wdata = req_wdata;
            end
         end else if (is_cmosprot) begin
            if (req_write) top_acc = 1'b1;
            else if (!fast_rsp_now) top_acc = 1'b1;
         end else if (is_sddirect) begin
            if (cmos_wr_blocked) top_acc = 1'b1;
            else top_pause = 1'b1;
         end else if (is_ext) begin
            top_pause = 1'b1;
         end
      end
      unique case (tstate)
         T_SDD: begin
            top_pause = 1'b1;
            sdd_req = 1'b1; sdd_we = top_write_q; sdd_addr = top_addr_q; sdd_wdata = top_wdata_q;
            if (ack_sdd) begin
               top_acc = 1'b1;
               if (!top_write_q) begin top_rspv = 1'b1; top_rdata = sd_rdata; end
            end
         end
         T_EXT: begin
            ext_valid = 1'b1;
            if (ext_ready) begin
               top_acc = 1'b1;
               if (!top_write_q) begin top_rspv = 1'b1; top_rdata = ext_rdata; end
            end
         end
         T_ZERO_RD: begin top_rspv = 1'b1; top_rdata = 0; end
         default: ;
      endcase
   end

   always_ff @(posedge clk) begin
      if (rst) begin
         tstate <= T_IDLE; nvram_protected <= 1'b0; top_addr_q <= 0; top_wdata_q <= 0; top_write_q <= 0;
         stat_pause_clocks <= 64'd0;
      end else if (ce) begin
         if (guest_pause) stat_pause_clocks <= stat_pause_clocks + 64'd1;
         if (top_take_new) begin
            tstate <= T_IDLE;
            if (req_valid) begin
               top_addr_q <= req_addr; top_wdata_q <= req_wdata; top_write_q <= req_write;
               if (is_internal && !req_write) tstate <= T_SIMPLE_RD;
               else if (is_cmosprot && req_write) nvram_protected <= ((req_wdata & 32'hc00) != 32'hc00);
               else if (is_cmosprot && !req_write && !fast_rsp_now) tstate <= T_ZERO_RD;
               else if (is_sddirect && !cmos_wr_blocked) tstate <= T_SDD;
               else if (is_ext && !fast_rsp_now) tstate <= T_EXT;
            end
         end else begin
            unique case (tstate)
               T_SDD: if (ack_sdd) tstate <= T_IDLE;
               T_EXT: if (ext_ready) tstate <= T_IDLE;
               default: tstate <= T_IDLE;
            endcase
         end
      end
   end

   // ================= fetch port =================
   logic f_src_int_q, f_rsp_q, iram_f_stale_q;
   always_comb f_accept = f_valid && (f_is_internal || main_f_hit);
   always_ff @(posedge clk) begin
      if (rst) begin
         f_src_int_q <= 1'b0; f_rsp_q <= 1'b0; iram_f_stale_q <= 1'b0;
         stat_fetch_accepts <= 64'd0; stat_fetch_rejects <= 64'd0; stat_fetch_stale <= 64'd0;
      end else if (ce) begin
         f_rsp_q        <= f_accept;
         f_src_int_q    <= f_is_internal;
         iram_f_stale_q <= f_valid && f_is_internal && iram_we && (iram_waddr == f_addr[10:0]);
         if (f_accept) stat_fetch_accepts <= stat_fetch_accepts + 64'd1;
         else if (f_valid) stat_fetch_rejects <= stat_fetch_rejects + 64'd1;
         if (f_rsp_q && (f_src_int_q ? iram_f_stale_q : main_f_stale)) stat_fetch_stale <= stat_fetch_stale + 64'd1;
      end
   end
   always_comb begin
      f_rdata     = f_src_int_q ? iram_f_rdata : main_f_rdata;
      f_rsp_valid = f_rsp_q && !(f_src_int_q ? iram_f_stale_q : main_f_stale);
   end

   // ================= SDRAM port arbitration (unchanged from C2/P2) ========
   always_comb begin
      grant = OWN_MAIN; grant_valid = 1'b1;
      if (sd_cool) begin
         grant_valid = 1'b0;
      end else if (sd_busy) begin
         grant = sd_owner;
      end else if (main_sd_req) begin
         grant = OWN_MAIN;
      end else if (rom_sd_req) begin
         grant = OWN_ROM;
      end else if (sdd_req) begin
         grant = OWN_SDD;
      end else begin
         grant_valid = 1'b0;
      end
      sd_req = 1'b0; sd_we = 1'b0; sd_burst = 1'b0; sd_addr = '0; sd_wdata = 32'd0;
      if (grant_valid) begin
         unique case (grant)
            OWN_MAIN: begin sd_burst = main_sd_burst; sd_req = main_sd_req; sd_we = main_sd_we; sd_addr = main_sd_addr; sd_wdata = main_sd_wdata; end
            OWN_ROM:  begin sd_burst = rom_sd_burst; sd_req = rom_sd_req;  sd_we = rom_sd_we;  sd_addr = rom_sd_addr;  sd_wdata = rom_sd_wdata;  end
            OWN_SDD:  begin sd_req = sdd_req;     sd_we = sdd_we;     sd_addr = sdd_addr;     sd_wdata = sdd_wdata;     end
            default: ;
         endcase
      end
   end

   logic [7:0] sd_words;
   wire sd_last = !sd_burst || sd_words == 8'd255;
   always_ff @(posedge clk) begin
      if (rst) begin
         sd_words <= 0;
         sd_busy <= 1'b0; sd_owner <= OWN_MAIN; sd_cool <= 1'b0;
      end else if (ce) begin
         sd_cool <= (sd_busy && sd_ack && sd_last);
         if (sd_ack) sd_words <= sd_last ? 0 : sd_words + 1'b1;
         if (!sd_busy) begin
            if (grant_valid && sd_req) begin sd_busy <= 1'b1; sd_owner <= grant; end
         end else if (sd_ack && sd_last) begin
            sd_busy <= 1'b0;
         end
      end
   end

   // ================= data accept / response / pause mux (unchanged from P2) =================
   always_comb begin
      if (is_main)      begin req_accept = main_acc; guest_pause = main_pause; end
      else if (is_rom)  begin req_accept = rom_acc;  guest_pause = rom_pause;  end
      else              begin req_accept = top_acc;  guest_pause = top_pause;  end
      rsp_valid = main_rspv || rom_rspv || top_rspv;
      rsp_rdata = main_rspv ? main_rdata : (rom_rspv ? rom_rdata : top_rdata);
   end

`ifndef SYNTHESIS
   always @(posedge clk) if (!rst && ce && ((main_rspv + rom_rspv + top_rspv) > 1))
      $display("C31_MEMORY_P3_ASSERT two responses in one clock main=%0d rom=%0d top=%0d", main_rspv, rom_rspv, top_rspv);
`endif
endmodule
`default_nettype wire
