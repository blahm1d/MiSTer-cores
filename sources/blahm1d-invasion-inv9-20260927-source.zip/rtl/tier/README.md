# rtl/tier -- the CPU memory tier, borrowed AS-IS from Cruis'n gm1

Source: cruisinusa/build/gm1-quartus-20260922T153625410917000Z/source/rtl/c31/mem (the gm1 core that fits at 39,592 ALM,
same c31_core lineage as zeus/core/rtl/cpu). Byte-identical copies; sha256 in PROVENANCE.sha256.

MK4 change: PARAMETERS ONLY -- NUM_MAIN_PAGES 172 -> 64, measured on MK4's own CPU trace (zeus1/tools/memsim.cpp,
rows 'line256'): 64 x 1 KB fully-associative pages hit 99.927 % in the fight window (172: 99.993 %), boot is
compulsory-miss-bound at every size (99.959 %). The MK4 region BASE / page-number widths are set at core integration
from the MK4 map (midzeus.cpp), and re-gated there.
