#!/bin/bash
# Invasion renderer regression gate (run_zr_rsys.sh legs, 4 in parallel): the five Invasion windows captured on the pinned
# MAME master (invasion/MEASURE-20260925.md sec. 2; ROM-derived, H: only). Exit 0 only if every PASS leg passes and every
# mutant FAILS.
#  C  invattract / invtex / invhvpoly / invhvpix / invw0, 24 vblanks, batch + paced, DROP + STRICT + CMP_DEPTHLANES: 10/10
#     bit-exact (both colour buffers + depth)
#  B  the cabinet regime (paced, free run, CQ_AW=12) on the three heavy windows (invtex / invhvpoly / invhvpix): 0 colour
#     writes into the displayed page
#  M  Invasion-only command paths the MK4 windows never run (so the MK4 gates cannot kill these), on invhvpoly batch:
#     I1 palbase set from MODEL data at 0x00c040 ignored (midzeus_v.cpp:453-458; zr_front5 model 0x0c pointer)
#     I2 model 0x19 reg32 taken as a 16-bit write (midzeus_v.cpp:1025-1030)
# usage: wsl bash gate_inv.sh [tag]    logs: ${ZSCRATCH:-/mnt/h/temp/zeus}/gate_inv/<tag>/
set -u
T=${1:-$(date -u +%Y%m%dT%H%M%SZ)}
R=/mnt/d/deck/fpga/zeus/zeus1/rtl; RUN=$R/memsys/run_zr_rsys.sh; W=/mnt/h/temp/zeus/invasion/windows
O=${ZSCRATCH:-/mnt/h/temp/zeus}/gate_inv/$T; mkdir -p "$O"
# oracle2 (zk4-inv3): the windows re-captured on MAME master d1e9f7db (lanes/oracle2/inv_capture_all.sh; the 61c79406
# captures $W/<w>-master-invasnab-* are superseded: #16178 turns 12 fast clears per window into repaint DBQs, #16225 re-keys).
win() { ls -d $W/o2$1-d1e9f7db-invasnab-* 2>/dev/null | grep -v ".segv$" | head -1; }
for w in invattract invtex invhvpoly invhvpix invw0; do [ -n "$(win $w)" ] || { echo "MISSING WINDOW $w under $W"; exit 2; }; done
mut() {   # mut <name> <file> <sed-expr>: a mutated copy in $O, refusing if the expression did not apply
  sed "$3" "$2" > "$O/$1.sv"; if cmp -s "$O/$1.sv" "$2"; then echo "MUTANT $1 DID NOT APPLY"; exit 3; fi; }
mut I1 $R/front/zr_front5.sv "s/^                  24'h00c040: palbase <= m_hi;/                  24'h00c040: ;/"
mut I2 $R/front/zr_front5.sv "s/8'h19: begin rw_off <= {3'd0, md0\[22:16\]}; rw_data <= m_hi; rw32 <= 1'b1;/8'h19: begin rw_off <= {3'd0, md0[22:16]}; rw_data <= {16'd0, md0[15:0]}; rw32 <= 1'b0;/"
EX="ZR_DDR_DROP=1 ZR_DDR_STRICT=1 ZR_CMP_DEPTHLANES=1"
LEGS=()
for w in invattract invtex invhvpoly invhvpix invw0; do
  LEGS+=("C_${w}_batch|PASS|$EX|$(win $w) 24")
  LEGS+=("C_${w}_paced|PASS|ZR_PACE=1 $EX|$(win $w) 24")
done
for w in invtex invhvpoly invhvpix; do LEGS+=("B_${w}_free|PASS|ZR_PACE=1 ZR_FREERUN=1 ZRS_G=-GCQ_AW=12|$(win $w) 24"); done
LEGS+=("M_I1|FAIL|$EX ZRS_FRONT=$O/I1.sv|$(win invhvpoly) 24")
LEGS+=("M_I2|FAIL|$EX ZRS_FRONT=$O/I2.sv|$(win invhvpoly) 24")
echo "gate_inv $T start $(date -u +%FT%TZ): ${#LEGS[@]} legs"
leg() { IFS='|' read -r n x env args <<< "$1"; env $env ZSCRATCH=$O timeout 5000 bash $RUN $args 12 0 > "$O/$n.log" 2>&1; echo $? > "$O/$n.rc"; }
i=0; for l in "${LEGS[@]}"; do leg "$l" & i=$((i + 1)); if [ $((i % 4)) = 0 ]; then wait; fi; done; wait
bad=0
for l in "${LEGS[@]}"; do IFS='|' read -r n x env args <<< "$l"; rc=$(cat "$O/$n.rc")
  got=FAIL; [ "$rc" = 0 ] && got=PASS; grep -q "BUILD FAILED" "$O/$n.log" && got=BUILD
  own=$(grep -m1 "^OWN violations" "$O/$n.log" | cut -d' ' -f3); res=$(grep -m1 -E "^(PASS|FAIL):" "$O/$n.log" | cut -c1-70)
  ok=OK; [ "$got" != "$x" ] && { ok=BAD; bad=1; }
  case $n in B_*) [ "${own:-x}" = 0 ] || { ok=BAD; bad=1; } ;; esac
  printf "%-22s expect %s got %s %s  violations %s  %s\n" "$n" "$x" "$got" "$ok" "${own:--}" "$res"
done
echo "gate_inv $T end $(date -u +%FT%TZ) bad=$bad"
exit $bad
