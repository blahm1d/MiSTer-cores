#!/bin/bash
# Build + run the renderer + memsys gate (zr_rsys: renderer, memory system, zeus_ddr_gateway -> a C++ HPS DDR3 model).
# usage: wsl -d Ubuntu -- bash run_zr_rsys.sh <render-evidence> [frames] [ddr-lat] [ddr-waitrequest%]   (ZR_PACE=1: paced)
# ZRS_MUT=sed-expression mutates zr_memsys.sv (refuses to run if it did not apply); ZRS_G passes extra Verilator flags.
# r12: ZRS_RENDER / ZRS_PIXEL / ZRS_FRONT = another zr_render5.sv / zr_pixel10.sv / zr_front5.sv (mutants); ZR_FREERUN=1 (with ZR_PACE=1, ZRS_G=-GCQ_AW=12): the
# cabinet regime, no drain / compare at frame boundaries, the page-ownership checker (tb, r13) must read 0 violations.
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-rsys-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC="$S/memsys/zr_memsys.sv"
if [ -n "${ZRS_MUT:-}" ]; then sed "$ZRS_MUT" "$SRC" > zr_memsys.sv; cmp -s zr_memsys.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zr_memsys.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zr_rsys ${ZRS_G:-} -DZR_SEED -DZR_SIM -DZR_CENSUS -DZR_OWNCHK -Wno-fatal -Wno-lint -Wno-style -LDFLAGS -lz \
  "$S/fp32/fp32_pkg.sv" "$S/fp32/fp32_units.sv" "$S/setup/zr_sdp.sv" "${ZRS_FRONT:-$S/front/zr_front5.sv}" "$S/setup/zr_setup9.sv" \
  "${ZRS_PIXEL:-$S/pixel/zr_pixel10.sv}" "$S/render/zr_fifo.sv" "$S/render/zr_rfifo.sv" "$S/render/zr_cmdq.sv" "${ZRS_RENDER:-$S/render/zr_render5.sv}" "$S/memsys/zr_ddr_gateway.sv" \
  "$SRC" "$S/memsys/zr_rsys.sv" "$S/memsys/tb_zr_rsys.cpp" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
