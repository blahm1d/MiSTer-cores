#!/bin/bash
# zk4-r12 renderer gate (run_zr_rsys.sh legs, 4 in parallel). Exit 0 only if every PASS leg passes and every mutant FAILS.
#  A  debug quad -> rect clear: o2demofight (11466-11481, 7 repaint DBQs) batch, bit-exact incl. depth;
#     mutants D1 (DBQ ignored = r11) and D2 (no max-x grow = the 0.289 half-open rect, column 399 frozen) must FAIL
#     (r12..s5 D2 was "one column too wide": that is now the correct behaviour, MAME #16225)
#  B  page ownership, the cabinet regime (paced, free run, CQ_AW=12): hvpoly 20 frames + demo fight 12 frames must read
#     0 colour writes into the displayed page; mutants O1 (scanout base applied when parsed = r11) and O2 (RB applied
#     when parsed) must FAIL with violations > 0
#  C  the four heavy windows, batch + paced, 20 frames, DROP + STRICT + CMP_DEPTHLANES: 8/8 bit-exact
# usage: wsl bash gate_r12.sh [tag]    logs: ${ZSCRATCH:-/mnt/h/temp/zeus}/gate_r12/<tag>/
set -u
T=${1:-$(date -u +%Y%m%dT%H%M%SZ)}
R=/mnt/d/deck/fpga/zeus/zeus1/rtl; RUN=$R/memsys/run_zr_rsys.sh; E=/mnt/d/deck/fpga/zeus/evidence
O=${ZSCRATCH:-/mnt/h/temp/zeus}/gate_r12/$T; mkdir -p "$O"
# oracle2 (zk4-s6, 2026-09-26): captures on MAME master d1e9f7db (zeus1/lanes/oracle2: #16225 colour key + solid-quad grow,
# #16178 INT0 at reg 0xC8's line -> MK4 draws the full-screen repaint DBQ every frame). The 61c79406 captures are superseded.
DQ=$E/o2demofight-d1e9f7db-mk4-20260926T074633Z; DF=$E/o2demo9900-d1e9f7db-mk4-20260926T074633Z
HV=$E/o2hvpoly-d1e9f7db-mk4-20260926T074853Z; FI=$E/o2fight-d1e9f7db-mk4-20260926T074853Z
HM=$E/o2hvmodel-d1e9f7db-mk4-20260926T074633Z; AT=$E/o2attract-d1e9f7db-mk4-20260926T074541Z
mut() {   # mut <name> <file> <sed-expr>: a mutated copy in $O, refusing if the expression did not apply
  sed "$3" "$2" > "$O/$1.sv"; if cmp -s "$O/$1.sv" "$2"; then echo "MUTANT $1 DID NOT APPLY"; exit 3; fi; }
mut D1 $R/render/zr_render5.sv "s/              32'h52423031, 32'h434C5231, 32'h44425131: rs <= R_WAITDRAIN;/              32'h52423031, 32'h434C5231: rs <= R_WAITDRAIN;/"
mut D2 $R/render/zr_render5.sv "s/x1 = mxx + 18'sd1 < dq_c\[1\] + 18'sd1 ? mxx + 18'sd1 : dq_c\[1\] + 18'sd1;/x1 = mxx < dq_c[1] + 18'sd1 ? mxx : dq_c[1] + 18'sd1;/"
mut O1 $R/render/zr_render5.sv "s/^  assign cc_go   = pn != 3'd0 \&\& drained \&\& p_idle \&\& (cc_diff != 16'd0 ? !cc_diff\[15\] : rs == R_TAG);/  assign cc_go   = pn != 3'd0;/"
mut O2 $R/render/zr_render5.sv "s/          if (tag == 32'h52423031 \&\& wi == 0) rbv <= f_word;/          if (tag == 32'h52423031 \&\& wi == 0) begin rbv <= f_word; rb <= f_word; end/"
# name|expect(PASS/FAIL)|env|evidence frames
LEGS=(
 "A_dbq|PASS||$DQ 16"
 "A_D1|FAIL|ZRS_RENDER=$O/D1.sv|$DQ 16"
 "A_D2|FAIL|ZRS_RENDER=$O/D2.sv|$DQ 16"
 "B_hvpoly|PASS|ZR_PACE=1 ZR_FREERUN=1 ZRS_G=-GCQ_AW=12|$HV 20"
 "B_demo|PASS|ZR_PACE=1 ZR_FREERUN=1 ZRS_G=-GCQ_AW=12|$DF 12"
 "B_O1|FAIL|ZR_PACE=1 ZR_FREERUN=1 ZRS_G=-GCQ_AW=12 ZRS_RENDER=$O/O1.sv|$HV 20"
 "B_O2|FAIL|ZR_PACE=1 ZR_FREERUN=1 ZRS_G=-GCQ_AW=12 ZRS_RENDER=$O/O2.sv|$HV 20"
)
for w in fight:$FI hvpoly:$HV hvmodel:$HM attract:$AT; do
  LEGS+=("C_${w%%:*}_batch|PASS|ZR_DDR_DROP=1 ZR_DDR_STRICT=1 ZR_CMP_DEPTHLANES=1|${w#*:} 20")
  LEGS+=("C_${w%%:*}_paced|PASS|ZR_PACE=1 ZR_DDR_DROP=1 ZR_DDR_STRICT=1 ZR_CMP_DEPTHLANES=1|${w#*:} 20")
done
echo "gate_r12 $T start $(date -u +%FT%TZ): ${#LEGS[@]} legs"
leg() { IFS='|' read -r n x env args <<< "$1"; env $env timeout 5000 bash $RUN $args 12 0 > "$O/$n.log" 2>&1; echo $? > "$O/$n.rc"; }
i=0; for l in "${LEGS[@]}"; do leg "$l" & i=$((i + 1)); if [ $((i % 4)) = 0 ]; then wait; fi; done; wait
bad=0
for l in "${LEGS[@]}"; do IFS='|' read -r n x env args <<< "$l"; rc=$(cat "$O/$n.rc")
  got=FAIL; [ "$rc" = 0 ] && got=PASS; grep -q "BUILD FAILED" "$O/$n.log" && got=BUILD
  own=$(grep -m1 "^OWN violations" "$O/$n.log" | cut -d' ' -f3); res=$(grep -m1 -E "^(PASS|FAIL):" "$O/$n.log" | cut -c1-60)
  ok=OK; [ "$got" != "$x" ] && { ok=BAD; bad=1; }
  case $n in B_O*) [ "${own:-0}" = 0 ] && { ok=BAD; bad=1; } ;; esac
  printf "%-18s expect %s got %s %s  violations %s  %s\n" "$n" "$x" "$got" "$ok" "${own:--}" "$res"
done
echo "gate_r12 $T end $(date -u +%FT%TZ) bad=$bad"
exit $bad
