#!/bin/bash
# zr_memsys directed-random unit gate. usage: run_zr_memsys.sh [cycles] [ddr-lat] [ddr-waitrequest%] [seed]; ZMU_MUT mutates zr_memsys.sv
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-memsys-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC="$S/memsys/zr_memsys.sv"
if [ -n "${ZMU_MUT:-}" ]; then sed "$ZMU_MUT" "$SRC" > zr_memsys.sv; cmp -s zr_memsys.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zr_memsys.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zr_memsys -DZR_CENSUS -DZR_RDW_HOSTILE -Wno-fatal -Wno-lint -Wno-style \
  "$S/setup/zr_sdp.sv" "$S/render/zr_fifo.sv" "$S/render/zr_rfifo.sv" "$S/memsys/zr_ddr_gateway.sv" "$SRC" "$S/memsys/tb_zr_memsys.cpp" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
