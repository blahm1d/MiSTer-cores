#!/bin/bash
# zr_memsys mutation gate (mutants_zr_memsys.txt): each mutant runs the zr_rsys gate (renderer + memsys + gateway +
# DDR model) on attract and the reference window, NF frames each, hostile DDR (latency 30, 30 % waitrequest).
# usage: wsl -d Ubuntu -- bash mutate_zr_memsys.sh <evidence-A> <evidence-B> [frames] [jobs]
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/memsys; R=$D/run_zr_rsys.sh; U=$D/run_zr_memsys.sh
EA="$1"; EB="$2"; NF="${3:-3}"; J="${4:-6}"
T=$(mktemp -d -p "${ZSCRATCH:-/mnt/h/temp/zeus}"); export T R U EA EB NF D
LIST="${ZMS_LIST:-$(grep -v "^#" $D/mutants_zr_memsys.txt | cut -f1 | tr "\n" " ")}"
one() {
  m="$1"; e=$(awk -F"\t" -v m="$m" '$1==m{print $3}' $D/mutants_zr_memsys.txt)
  ZRS_MUT="$e" timeout 3000 bash "$R" "$EA" "$NF" 30 30 > "$T/$m.a.log" 2>&1; echo $? > "$T/$m.a.rc"
  ZRS_MUT="$e" timeout 3000 bash "$R" "$EB" "$NF" 30 30 > "$T/$m.b.log" 2>&1; echo $? > "$T/$m.b.rc"
  ZMU_MUT="$e" timeout 3000 bash "$U" 400000 20 60 > "$T/$m.u.log" 2>&1; echo $? > "$T/$m.u.rc"
}
export -f one
printf "%s\n" $LIST | xargs -P "$J" -I{} bash -c "one {}"
bad=0
for m in $LIST; do
  cls=$(awk -F"\t" -v m="$m" '$1==m{print $2}' $D/mutants_zr_memsys.txt); ra=$(cat "$T/$m.a.rc"); rb=$(cat "$T/$m.b.rc"); ru=$(cat "$T/$m.u.rc")
  if grep -q "DID NOT APPLY" "$T/$m.a.log" "$T/$m.u.log"; then echo "$m NOT APPLIED"; bad=1; continue; fi
  if grep -q "BUILD FAILED" "$T/$m.a.log" "$T/$m.u.log"; then echo "$m BUILD FAILED (not a kill)"; bad=1; continue; fi
  why=$(grep -h -m1 -E "DIFFERS|FAIL|ERR" "$T/$m.u.log" "$T/$m.a.log" "$T/$m.b.log" | head -1 | cut -c1-100)
  { [ "$ra" = 124 ] || [ "$rb" = 124 ] || [ "$ru" = 124 ]; } && why="hung (timeout) $why"
  if [ "$ra" = 0 ] && [ "$rb" = 0 ] && [ "$ru" = 0 ]; then case "$cls" in perf) echo "$m survived: performance-only";; equiv) echo "$m survived: equivalent (see list header)";; *) echo "$m SURVIVED"; bad=1;; esac
  else echo "$m killed [A rc $ra, B rc $rb, unit rc $ru]: $why"; fi
done
rm -rf "$T"; exit $bad
