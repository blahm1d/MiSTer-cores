// zr_rsys.sv -- renderer + memory system: zr_render4 with its four wave-RAM ports on zr_memsys, one HPS DDR3 Avalon port
// out (plus the scanout client port of the memsys). Gate: tb_zr_rsys.cpp (the renderer gate with a DDR model behind).
module zr_rsys import fp32_pkg::*; #(parameter logic [28:0] WR0_BASE = 29'h0600_0000, parameter logic [28:0] WR1_BASE = 29'h0610_0000,
    parameter int SB_AW = 13, parameter int EQ_AW = 8, parameter int OQ_AW = 8,     // paced sweep 2026-09-22: real time on hvpoly at DDR latency 12
    parameter int CQ_AW = 0,                                                        // CPU command queue depth 2**CQ_AW (0 = none: zr_cmdq)
    parameter int GW_SLOTS = 16) (                                                  // DDR gateway descriptors in flight
  input  logic        clk, rst,
  input  logic        wr_valid, output logic wr_ready, input logic [9:0] wr_off, input logic [31:0] wr_data,
  output logic        cq_empty, output logic [31:0] st_cq_max, st_cq_full,          // command queue: drained / census
  input  logic [9:0]  rd_off, output logic [31:0] rd_data,
  output logic [31:0] reg_cc, reg_b6, output logic mode32,
  output logic        rd_ok,                                                          // a host register read may issue this clock (queue drained, front end idle, port free)
  input  logic [31:0] rb_init,
  input  logic [16:0] dbg_daddr, output logic [15:0] dbg_ddata,
  output logic [31:0] rb_now,
  output logic        idle, unsupported, fault,
  // r12 cabinet census (zr_render5): clears started / completed, debug quads drawn / empty / not rectangles; pipe_idle =
  // nothing behind the front end (setup, object queue, pixel pipe, memsys) is working
  output logic [31:0] st_clears, st_clr_done, st_dbq, output logic [15:0] st_dbq_empty, st_dbq_bad, output logic pipe_idle,
  output logic [31:0] disp_cc, output logic disp_ovf,                               // r12: the display base for scanout (zr_render5)
`ifdef ZR_OWNCHK
  // r13 sim-only (run_zr_rsys.sh): the colour-write handshake, for the testbench's page-ownership checker (tb_zr_rsys.cpp;
  // replaces the r12 cabinet instrument zr_own, removed from the core in r13)
  output logic        chk_cw_fire, output logic [31:0] chk_cw_addr,
`endif
  // scanout client (memsys port)
  input  logic        sc_req, input logic [19:0] sc_word, input logic [5:0] sc_beats, output logic sc_gnt,
  output logic        sc_rvalid, output logic sc_rlast, output logic [63:0] sc_rdata,
  // HPS DDR3
  output logic        av_read, av_write, output logic [28:0] av_address, output logic [7:0] av_burstcount,
  output logic [63:0] av_writedata, output logic [7:0] av_byteenable,
  input  logic        av_waitrequest, av_readdatavalid, input logic [63:0] av_readdata,
`ifdef ZR_SEED
  input  logic        sd_we, input logic [3:0] sd_sel, input logic [9:0] sd_idx, input logic [31:0] sd_data,
  output logic [31:0] dbg_state [20],
  output logic [31:0] st_cen [21],
  output logic [31:0] st_mem [8],
`endif
  output logic [31:0] st_quads, st_polys, st_rejected, st_extents,
  output logic [31:0] st_clk, st_wsetup, st_wdrain, st_extstall, st_pixstarve, st_frontwait
);
  logic fm_req, fm_we, fm_ram, fm_gnt, fm_rvalid; logic [20:0] fm_blk; logic [3:0] fm_lanes; logic [63:0] fm_wdata, fm_rdata;
  logic w0_req, w0_gnt, w0_rvalid; logic [20:0] w0_line; logic [63:0] w0_data;
  logic cw_valid, cw_ready; logic [31:0] cw_addr, cw_data; logic [1:0] cw_mask; logic [15:0] cw_z; logic cw_zv;
  logic cr_req, cr_gnt, cr_rvalid; logic [31:0] cr_addr; logic [15:0] cr_data;
  logic r_idle, m_idle, host_rd_ok, r_pipe_idle, m_wr_idle;
  logic [31:0] m_wb, m_wbt, m_fh, m_wh, m_bcw, m_pcw, m_bfm, m_pfm;
  // the CPU command queue: writes accepted at once, drained into the front end as it becomes ready
  logic q_wr_valid, q_wr_ready; logic [9:0] q_wr_off; logic [31:0] q_wr_data;
  zr_cmdq #(.AW(CQ_AW)) u_cq (.clk, .rst, .in_valid(wr_valid), .in_ready(wr_ready), .in_off(wr_off), .in_data(wr_data),
    .out_valid(q_wr_valid), .out_ready(q_wr_ready), .out_off(q_wr_off), .out_data(q_wr_data), .empty(cq_empty),
    .st_max_occ(st_cq_max), .st_full_clk(st_cq_full));
  zr_render5 #(.SB_AW(SB_AW), .EQ_AW(EQ_AW), .OQ_AW(OQ_AW)) u_r (.clk, .rst, .wr_valid(q_wr_valid), .wr_ready(q_wr_ready), .wr_off(q_wr_off), .wr_data(q_wr_data), .rd_off, .rd_data, .reg_cc, .reg_b6, .mode32, .host_rd_ok,
    .fm_req, .fm_we, .fm_ram, .fm_blk, .fm_lanes, .fm_wdata, .fm_gnt, .fm_rvalid, .fm_rdata,
    .w0_req, .w0_line, .w0_gnt, .w0_rvalid, .w0_data, .cw_valid, .cw_ready, .cw_addr, .cw_data, .cw_mask, .cw_z, .cw_zv,
    .cr_req, .cr_addr, .cr_gnt, .cr_rvalid, .cr_data, .rb_init, .dbg_daddr, .dbg_ddata, .rb_now, .idle(r_idle), .unsupported,
    .st_clears, .st_clr_done, .st_dbq, .st_dbq_empty, .st_dbq_bad, .pipe_idle(r_pipe_idle), .disp_cc, .disp_ovf,
`ifdef ZR_SEED
    .sd_we, .sd_sel, .sd_idx, .sd_data, .dbg_state, .st_cen,
`endif
    .st_quads, .st_polys, .st_rejected, .st_extents, .st_clk, .st_wsetup, .st_wdrain, .st_extstall, .st_pixstarve, .st_frontwait);
  zr_memsys #(.WR0_BASE(WR0_BASE), .WR1_BASE(WR1_BASE), .GW_SLOTS(GW_SLOTS)) u_m (.clk, .rst,
    .fm_req, .fm_we, .fm_ram, .fm_blk, .fm_lanes, .fm_wdata, .fm_gnt, .fm_rvalid, .fm_rdata,
    .w0_req, .w0_line, .w0_gnt, .w0_rvalid, .w0_data, .cw_valid, .cw_ready, .cw_addr, .cw_data, .cw_mask, .cw_z, .cw_zv,
    .cr_req, .cr_addr, .cr_gnt, .cr_rvalid, .cr_data,
    .sc_req, .sc_word, .sc_beats, .sc_gnt, .sc_rvalid, .sc_rlast, .sc_rdata,
    .av_read, .av_write, .av_address, .av_burstcount, .av_writedata, .av_byteenable, .av_waitrequest, .av_readdatavalid,
    .av_readdata, .idle(m_idle), .fault, .wr_idle(m_wr_idle), .st_wbursts(m_wb), .st_wbeats(m_wbt), .st_flush_hz(m_fh), .st_wait_hz(m_wh), .st_bcw(m_bcw), .st_pcw(m_pcw), .st_bfm(m_bfm), .st_pfm(m_pfm));
  assign idle = r_idle && m_idle && cq_empty;                       // a queued command is work not yet done
  assign pipe_idle = r_pipe_idle && m_wr_idle;
  assign rd_ok = cq_empty && host_rd_ok;                                     // zr_front5 host_rd_ok: the register-file port is the host's
`ifdef ZR_OWNCHK
  assign chk_cw_fire = cw_valid && cw_ready; assign chk_cw_addr = cw_addr;
`endif
`ifdef ZR_SEED
  assign st_mem = '{m_wb, m_wbt, m_fh, m_wh, m_bcw, m_pcw, m_bfm, m_pfm};
`endif
endmodule
