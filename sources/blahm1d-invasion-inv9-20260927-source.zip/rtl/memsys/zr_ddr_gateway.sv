// zr_ddr_gateway.sv -- zeus_ddr_gateway (performance/replace-rtl-v28, sha256 bb869e8d...) with the descriptor count a
// PARAMETER (SLOTS, default 16; v28 was 8). MK4 measured on zr_rsys: 8 descriptors shared by the texture, colour-read,
// front-end and write clients capped read concurrency at ~8 per DDR round trip (texture waits 116-181 K clocks/frame on
// hvpoly / hvmodel at 12-clock latency). Logic unchanged; the read buffer grows to SLOTS x 32 beats (M10K).
// Standalone source slice. Eight ordered descriptors, eight reserved read slots.
// The backend must return accepted reads in order, at least one clock later.
// Writes require an external visibility fence acknowledgement before release.
// Reset is cold/domain reset only; warm reset uses quiesce -> idle -> reset.
module zr_ddr_gateway #(parameter int SLOTS = 16) (
 input wire clk, reset, quiesce,
 input wire req_valid, output wire req_ready,
 input wire req_write, req_publish, input wire [28:0] req_address,
 input wire [5:0] req_beats, input wire [15:0] req_tag,
 input wire w_valid, output wire w_ready,
 input wire [63:0] w_data, input wire [7:0] w_mask,
 output reg rsp_valid, input wire rsp_ready,
 output wire [63:0] rsp_data, output reg [15:0] rsp_tag,
 output reg rsp_last, output reg rsp_write,
 output wire av_read, output wire av_write,
 output wire [28:0] av_address, output wire [7:0] av_burstcount,
 output reg [63:0] av_writedata, output reg [7:0] av_byteenable,
 input wire av_waitrequest, input wire av_readdatavalid,
 input wire [63:0] av_readdata,
 output reg fence_req, input wire fence_ack,
 output wire idle,write_slot_free, output reg fault,
 output wire [$clog2(SLOTS):0] occupied
);
 localparam int SB = $clog2(SLOTS);
 reg [28:0] address [0:SLOTS-1];
 reg [5:0] length [0:SLOTS-1], received [0:SLOTS-1];
 (* ramstyle = "MLAB, no_rw_check" *) reg [15:0] tag [0:SLOTS-1];   // G2: read through one registered port (below); MLAB: the chip has no spare M10K
 reg is_write [0:SLOTS-1], complete [0:SLOTS-1], publish [0:SLOTS-1];
 reg [63:0] read_data [0:SLOTS*32-1];
 // Registered output of the read buffer. Kept in its own always block with a
 // single read enable so the array matches a RAM template; the write/read mux
 // that previously sat inside it now sits outside, on the registered value.
 reg [63:0] ram_q;
 // sound-area G1: the write-beat buffer is read through ONE registered port. v28..r13 read it at write_index (reload)
 // AND at write_index+1 (look-ahead) from two statements; Quartus 17 inferred a RAM for one and kept the whole array in
 // flops for the other (map: 'RAM logic write_data is uninferred due to asynchronous read logic': 2,304 registers + a
 // 72-bit 32:1 mux). The two loads are exclusive (look-ahead needs an accepted beat, the reload excludes one), so one
 // address mux + one enable is the same load in the same clock. The buffer is never read at the word being written
 // (reads are below `gathered`, the write is at gather_index), hence no_rw_check (no pass-through logic).
 (* ramstyle = "no_rw_check" *) reg [71:0] write_data [0:31];
 reg [SB-1:0] alloc_ptr, issue_ptr, retire_ptr;
 reg [SB:0] used, pending;
 reg [SB-1:0] read_owner [0:SLOTS-1];
 reg [5:0] read_debt [0:SLOTS-1];
 reg [SB-1:0] read_head, read_tail;
 reg [SB:0] read_count;
 reg write_reserved, gathering, write_active, beat_valid;
 reg [SB-1:0] write_slot;
 reg [5:0] gather_index, write_index, deliver_index;
 wire admit=req_valid && req_ready;
 wire retire=rsp_valid && rsp_ready && rsp_last;
 wire issue_read=av_read && !av_waitrequest;
 // Beats the client has delivered for the burst now issuing. Once gathering has
 // finished the whole burst is available.
 wire [5:0] gathered=(gathering && write_slot==issue_ptr) ? gather_index : length[issue_ptr];
 wire issue_write_end=av_write && !av_waitrequest && write_index+1==length[issue_ptr];
 wire read_end=av_readdatavalid && read_count!=0 && read_debt[read_head]==1;
 wire issue_write_done=av_write && !av_waitrequest && issue_write_end && !publish[issue_ptr];
 wire issue_done=issue_read || (fence_req && fence_ack) || issue_write_done;
 wire [SB-1:0] output_slot=retire ? retire_ptr+1'b1 : retire_ptr;
 wire [5:0] output_index=retire ? 6'd0 :
             (rsp_valid && rsp_ready ? deliver_index+6'd1 : deliver_index);
 wire output_exists=used>(retire ? 1 : 0);
 // A write response carries no payload; only a read returns buffer contents.
 assign rsp_data=rsp_write ? 64'd0 : ram_q;
 assign occupied=used;
 assign write_slot_free=!write_reserved;
 // Reads no longer wait for a write to finish gathering; only another WRITE does,
 // because there is one write data buffer.
 assign req_ready=!reset && !quiesce && !fault && used<SLOTS &&
                  (!req_write || (!write_reserved && !gathering)) && req_beats>=1 && req_beats<=32;
 assign w_ready=gathering && !reset;
 assign av_read=pending!=0 && !is_write[issue_ptr] && !write_active && !fence_req && !reset;
 assign av_write=write_active && beat_valid && !reset;
 assign av_address=address[issue_ptr];
 assign av_burstcount={2'b0,length[issue_ptr]};
 assign idle=used==0 && !rsp_valid && !gathering && !write_active && !fence_req && read_count==0;
 // G1: the write-beat buffer's single registered read port (RAM template; no reset -- the beat is only presented
 // under av_write, which reset clears). Reload: a burst's first / resumed beat; look-ahead: the next beat as the
 // current one is accepted. Exactly v28's two load conditions, now on one address.
 wire wd_acc = av_write && !av_waitrequest;
 wire wd_rl  = write_active && !beat_valid && write_index<gathered && !wd_acc;
 wire wd_la  = wd_acc && !issue_write_end && (write_index+6'd1<gathered);
 always @(posedge clk) if(!reset && (wd_rl || wd_la))
  {av_byteenable,av_writedata}<=write_data[wd_acc ? write_index[4:0]+5'd1 : write_index[4:0]];
 // G2: the response tag through one registered read port (map: 'RAM logic tag is uninferred due to asynchronous read
 // logic' -- the reset of rsp_tag kept it out of the RAM output register). Loaded under exactly the two conditions that
 // load rsp_valid below; no reset (the tag is only meaningful with rsp_valid, which reset clears). The slot read is a
 // queued one and the slot written is the free one at alloc_ptr: never the same word in one clock.
 always @(posedge clk) if(!reset && (!rsp_valid || rsp_ready) && output_exists &&
                          ((is_write[output_slot] && complete[output_slot]) ||
                           (!is_write[output_slot] && received[output_slot]>output_index)))
  rsp_tag<=tag[output_slot];
 // RAM read template -- do not fold this back into the output block.
 always @(posedge clk) if(!rsp_valid || rsp_ready)
  ram_q<=read_data[{output_slot,output_index[4:0]}];
 integer i;
 always @(posedge clk) begin
  if(reset) begin
   alloc_ptr<=0;issue_ptr<=0;retire_ptr<=0;used<=0;pending<=0;
   read_head<=0;read_tail<=0;read_count<=0;
   write_reserved<=0;gathering<=0;write_active<=0;beat_valid<=0;write_slot<=0;
   gather_index<=0;write_index<=0;deliver_index<=0;
   rsp_valid<=0;rsp_last<=0;rsp_write<=0;
   fence_req<=0;fault<=0;
   for(i=0;i<SLOTS;i=i+1)begin received[i]<=0;complete[i]<=0;publish[i]<=0;end
  end else begin
   case({admit,retire}) 2'b10:used<=used+1'b1;2'b01:used<=used-1'b1;default:;endcase
   case({admit,issue_done}) 2'b10:pending<=pending+1'b1;2'b01:pending<=pending-1'b1;default:;endcase
   case({issue_read,read_end}) 2'b10:read_count<=read_count+1'b1;2'b01:read_count<=read_count-1'b1;default:;endcase
   if(admit)begin
    address[alloc_ptr]<=req_address;length[alloc_ptr]<=req_beats;tag[alloc_ptr]<=req_tag;
    is_write[alloc_ptr]<=req_write;received[alloc_ptr]<=0;complete[alloc_ptr]<=0;
    publish[alloc_ptr]<=req_write && req_publish;
    alloc_ptr<=alloc_ptr+1'b1;
    if(req_write)begin
     write_reserved<=1;write_slot<=alloc_ptr;gathering<=1;gather_index<=0;
    end
   end
   if(w_valid && w_ready)begin
    write_data[gather_index[4:0]]<={w_mask,w_data};
    gather_index<=gather_index+1'b1;
    if(gather_index+1==length[write_slot])gathering<=0;
   end
   if(issue_read)begin
    read_owner[read_tail]<=issue_ptr;read_debt[read_tail]<=length[issue_ptr];
    read_tail<=read_tail+1'b1;issue_ptr<=issue_ptr+1'b1;
   end
   if(av_readdatavalid)begin
    if(read_count==0)fault<=1;
    else begin
     read_data[{read_owner[read_head],received[read_owner[read_head]][4:0]}]<=av_readdata;
     received[read_owner[read_head]]<=received[read_owner[read_head]]+1'b1;
     read_debt[read_head]<=read_debt[read_head]-1'b1;
     if(read_end)begin complete[read_owner[read_head]]<=1;read_head<=read_head+1'b1;end
    end
   end
   // S3 (2026-09-21): a write is NO LONGER a global barrier. v14 required every older
   // descriptor to be retired (delivered to the client) and every read to have returned
   // before a write could issue, then fenced after it. Measured cost: 920,117 clocks,
   // 38.3% of the DDR window, with work waiting on 100% of them.
   //
   // The barrier is not needed for fabric-internal ordering. Descriptors still ISSUE in
   // order (issue_ptr advances one at a time), so the port sees this master's commands in
   // program order, and the MiSTer DDRAM port maintains read-after-write order for a
   // single master. Two shipped cores depend on exactly that: PSX `ddram.sv` issues a
   // write and invalidates its own cache line, relying on the next read to return the new
   // data, with no fence anywhere; Saturn `ddram.sv` likewise has no fence.
   //
   // Writes carry no read returns, so interleaving them with outstanding reads cannot
   // disturb the read-return FIFO.
   // S3b: issue as soon as the FIRST beat exists. The command goes out while the client
   // is still delivering, so the payload costs one set of clocks instead of two.
   if(pending!=0 && is_write[issue_ptr] &&
      !write_active && !fence_req && !complete[issue_ptr] && gathered!=0)begin
    write_active<=1;write_index<=0;beat_valid<=0;
   end
   // Load the output register with the beat we are waiting to present. One clock of
   // latency, so beat_valid gates av_write rather than the buffer being read async.
   if(write_active && !beat_valid && write_index<gathered && !(av_write && !av_waitrequest))begin
    beat_valid<=1;   // G1: the beat itself is loaded by the single read port below
   end
   if(av_write && !av_waitrequest)begin
    // The fence is now an EPOCH boundary, not a per-burst reflex. Only a request the
    // client marked req_publish -- a frame handed to scanout, a CPU-visible readback --
    // waits for backend visibility. Everything else completes on acceptance.
    if(issue_write_end)begin
     write_active<=0;
     if(publish[issue_ptr])fence_req<=1;
     else begin complete[issue_ptr]<=1;issue_ptr<=issue_ptr+1'b1;write_reserved<=0;end   // ddr-fullbe: buffer free once issued
    end
    else begin
     write_index<=write_index+1'b1;
     // Look ahead one beat so a ready burst streams at one beat per clock. Clearing
     // beat_valid and reloading instead would halve the write rate -- measured 2026-09-21
     // as +235,082 clocks in the census 'other' bucket.
     if(write_index+6'd1<gathered)begin
      beat_valid<=1;   // G1: look-ahead beat loaded by the single read port below
     end else beat_valid<=0;
    end
   end
   if(fence_req && fence_ack)begin
    fence_req<=0;complete[issue_ptr]<=1;issue_ptr<=issue_ptr+1'b1;write_reserved<=0;
   end
   // One registered RAM read port; replace an accepted output every clock.
   if(rsp_valid && rsp_ready)begin
    rsp_valid<=0;
    if(rsp_last)begin
     retire_ptr<=retire_ptr+1'b1;deliver_index<=0;
     // ddr-fullbe: write_reserved is released when the write has ISSUED (above), not when its in-order response retires
    end else deliver_index<=deliver_index+1'b1;
   end
   if(!rsp_valid || rsp_ready)begin
    rsp_valid<=0;
    if(output_exists && is_write[output_slot] && complete[output_slot])begin
     rsp_valid<=1;rsp_last<=1;rsp_write<=1;
    end else if(output_exists && !is_write[output_slot] && received[output_slot]>output_index)begin
     rsp_valid<=1;
     rsp_last<=output_index+1==length[output_slot];rsp_write<=0;
    end
   end
  end
 end
endmodule
