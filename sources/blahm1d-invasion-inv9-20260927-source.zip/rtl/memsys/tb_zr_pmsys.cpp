// Gate for zr_pmsys: zr1's --pixtap stream (RB / CLR / OBJ / EXT / FRM) replayed through the RTL from the seeded
// frame buffer. The testbench is the memory: waveram 0 line reads (latency W0LAT), posted colour writes (optionally
// back-pressured), colour reads (latency CRLAT). Every FRM:
//   * colour: every pixel word of waveram 1 (both buffers) vs MAME's dump, word-exact
//   * depth : the RENDER buffer's depth (on chip, read over the debug port) vs MAME's depth words of that buffer
//   * the other buffer's depth words are not compared: on-chip depth holds only the render buffer, and the gate
//     ENFORCES the reason that is sound -- no extent may draw into a render base before that frame's clear (otherwise
//     depth from two frames ago would be read, which the design does not keep). A violation fails the run.
#include "Vzr_pmsys.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <zlib.h>
#include <deque>
#include <algorithm>

typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8;
static std::vector<u8> read_gz(const std::string& p) {
    std::vector<u8> out; gzFile f = gzopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    u8 buf[1 << 16]; int n; while ((n = gzread(f, buf, sizeof buf)) > 0) out.insert(out.end(), buf, buf + n); gzclose(f); return out;
}
static std::vector<u8> read_file(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); std::vector<u8> v(n); if (fread(v.data(), 1, n, f) != (size_t)n) exit(2); fclose(f); return v;
}
static uint64_t rs = 0x243F6A8885A308D3ull; static uint64_t rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

int main(int argc, char** argv) {
    if (argc < 3) { printf("usage: tb_zr_pmsys <render-evidence-dir> <pix.bin> [max-frames] [w0lat] [crlat] [cw_backpressure%%]\n"); return 2; }
    std::string ev = argv[1]; int maxf = argc > 3 ? atoi(argv[3]) : 1 << 30;
    int W0LAT = argc > 4 ? atoi(argv[4]) : 8, CRLAT = argc > 5 ? atoi(argv[5]) : 8, CWBP = argc > 6 ? atoi(argv[6]) : 0, GBP = argc > 7 ? atoi(argv[7]) : 0;
    unsigned long long w0_lines = 0, cr_reads = 0;
    std::vector<u8> w0 = read_gz(ev + "/seed_item_0_m_waveram_0_.bin.gz"), w1 = read_gz(ev + "/seed_item_0_m_waveram_1_.bin.gz");
    std::vector<u8> regs = read_file(ev + "/seed_zeus1_regs.bin"); u32 reg84; memcpy(&reg84, &regs[0x84 * 4], 4);
    u32 rb = (reg84 & 0x1ff) * 512 * 8;
    std::vector<u8> raw = read_file(argv[2]); const u32* w = (const u32*)raw.data(); size_t n = raw.size() / 4, i = 0;
    Verilated::commandArgs(argc, argv);
    Vzr_pmsys* t = new Vzr_pmsys;
    unsigned long long clocks = 0;
    // v8 ports: request / grant, many outstanding, responses IN ORDER after the latency. GBP% of clocks refuse the
    // grant (hostile arbitration). Colour reads sample memory when the request is ACCEPTED (a write still posted at
    // that moment is not seen): the strict model -- the design must order a destination read after earlier writes.
    // HPS DDR3 model (as tb_zr_rsys): argument 4 = read latency, argument 5 = waitrequest %; reads IN ORDER, one beat per
    // clock, data snapshotted at acceptance; a write beat lands when accepted.
    const int DLAT = W0LAT, DWBP = CRLAT;
    const uint64_t WR0 = 0x06000000ull, WR1 = 0x06100000ull;
    auto wptr = [&](uint64_t wa) -> u8* {
        if (wa >= WR0 && (wa - WR0) * 8 + 8 <= w0.size()) return &w0[(wa - WR0) * 8];
        if (wa >= WR1 && (wa - WR1) * 8 + 8 <= w1.size()) return &w1[(wa - WR1) * 8];
        printf("FAIL: DDR word address %09llX outside both wave RAMs\n", (unsigned long long)wa); exit(1);
    };
    struct Beat { unsigned long long due; uint64_t data; };
    std::deque<Beat> rq;
    bool wb_on = false; uint64_t wb_addr = 0; unsigned wb_left = 0;
    auto tick = [&]() {
        t->clk = 0; t->eval();
        t->av_readdatavalid = 0;
        if (!rq.empty() && rq.front().due <= clocks) { t->av_readdatavalid = 1; t->av_readdata = rq.front().data; rq.pop_front(); }
        t->av_waitrequest = (DWBP != 0) && (int)(rnd() % 100) < DWBP;
        t->eval();
        if (!t->av_waitrequest) {
            if (t->av_read) {
                uint64_t base = t->av_address; unsigned n = t->av_burstcount;
                unsigned long long due = std::max<unsigned long long>(clocks + (unsigned long long)DLAT, rq.empty() ? 0 : rq.back().due + 1);
                for (unsigned k = 0; k < n; k++) { uint64_t d; memcpy(&d, wptr(base + k), 8); rq.push_back({due + k, d}); }
                cr_reads += n;
            }
            if (t->av_write) {
                if (!wb_on) { wb_on = true; wb_addr = t->av_address; wb_left = t->av_burstcount; }
                u8* p = wptr(wb_addr); uint64_t d = t->av_writedata;
                for (int b = 0; b < 8; b++) if (t->av_byteenable >> b & 1) p[b] = (u8)(d >> (8 * b));
                wb_addr++; w0_lines++;
                if (--wb_left == 0) wb_on = false;
            }
        }
        if (t->fault) { printf("FAIL: gateway fault\n"); exit(1); }
        t->eval(); t->clk = 1; t->eval(); clocks++;
    };
    t->rst = 1; t->ext_valid = 0; t->clr_valid = 0; tick(); tick(); t->rst = 0; tick();
    u32 ob[14] = {0}; int ok = 0, bad = 0, frames = 0; bool cleared = false; unsigned long long exts = 0, excluded = 0;
    auto wait_idle = [&]() { long g = 0; while (!t->idle) { tick(); if (++g > 50000000) { printf("FAIL: never idle\n"); exit(1); } } };
    while (i < n && frames < maxf) {
        u32 tag = w[i];
        if (tag == 0x52423031) { wait_idle(); if (w[i + 1] != rb) cleared = false; rb = w[i + 1]; i += 2; }
        else if (tag == 0x434C5231) {
            if (w[i + 1] != 0 || w[i + 2] != 399 || w[i + 3] != 0 || w[i + 4] != 255) { printf("FAIL: clip rect is not 400x256 (on-chip depth geometry)\n"); return 1; }
            t->rb_base = rb; t->clr_valid = 1;
            long g = 0; while (!t->clr_ready) { tick(); if (++g > 50000000) { printf("FAIL: clear never accepted\n"); return 1; } }
            tick(); t->clr_valid = 0; cleared = true; i += 5;
        } else if (tag == 0x4F424A31) { memcpy(ob, &w[i], 14 * 4); i += 14; }
        else if (tag == 0x45585431) {
            int16_t sx = (int16_t)(w[i + 2] & 0xffff), ex = (int16_t)(w[i + 2] >> 16);
            if (sx < ex && !cleared) { printf("FAIL: an extent draws into render base %08X before its frame's clear -- on-chip depth unsound\n", rb); return 1; }
            t->scan = (int32_t)w[i + 1]; t->startx = sx; t->stopx = ex;
            for (int p = 0; p < 4; p++) { t->p_start[p] = w[i + 3 + 2 * p]; t->p_dpdx[p] = w[i + 4 + 2 * p]; }
            t->o_ctrl = ob[1]; t->o_solid = ob[2]; t->o_zoff = (int16_t)ob[3]; t->o_trans = ob[4]; t->o_texw = ob[5]; t->o_voff = ob[6];
            t->o_alpha = ob[7]; t->o_blend = ob[8]; t->o_dtest = ob[9]; t->o_dwrite = ob[10]; t->o_texfmt = ob[11];
            t->o_texbase = ob[12]; t->o_palbase = ob[13]; t->rb_base = rb;
            t->ext_valid = 1;
            long g = 0; while (!t->ext_ready) { tick(); if (++g > 50000000) { printf("FAIL: extent never accepted\n"); return 1; } }
            tick(); t->ext_valid = 0; exts++; i += 11;
        } else if (tag == 0x46524D31) {
            int fr = (int)w[i + 1]; i += 2; frames++;
            wait_idle();
            char nm[512]; snprintf(nm, sizeof nm, "%s/frame_%05d_0_m_waveram_1_.bin.gz", ev.c_str(), fr);
            std::vector<u8> m = read_gz(nm);
            unsigned long long dcol = 0, ddep = 0, first = ~0ull;
            for (u32 k = 0; k < w1.size() / 2; k++) {
                if (k & 2) continue;                                   // depth words handled below
                u16 a, b; memcpy(&a, &w1[2 * k], 2); memcpy(&b, &m[2 * k], 2);
                if (a != b) { dcol++; if (first == ~0ull) first = k; }
            }
            // render buffer depth: on chip, index y*400 + x
            for (u32 yy = 0; yy < 256; yy++) for (u32 xx = 0; xx < 400; xx++) {
                t->dbg_daddr = yy * 400 + xx; tick(); t->clk = 0; t->eval();
                u16 dv = t->dbg_ddata;
                u32 word = (rb / 2) + ((yy << 10) | ((xx & 0x1fe) << 1) | (xx & 1) | 2);
                u16 mv; memcpy(&mv, &m[2 * word], 2);
                if (dv != mv) { ddep++; if (ddep < 4) printf("  depth y %u x %u: rtl %04X MAME %04X\n", yy, xx, dv, mv); }
            }
            excluded += 400 * 256;                                     // the other buffer's depth words
            if (dcol == 0 && ddep == 0) ok++; else bad++;
            printf("frame %d: colour %s (%llu words differ%s), render-buffer depth %s (%llu differ)\n", fr, dcol ? "DIFFERS" : "IDENTICAL", dcol,
                   dcol ? "" : "", ddep ? "DIFFERS" : "IDENTICAL", ddep);
            if (dcol) { u16 a, b; memcpy(&a, &w1[2 * first], 2); memcpy(&b, &m[2 * first], 2); printf("  first colour word %llu: rtl %04X MAME %04X\n", first, a, b); }
        } else { printf("FAIL: bad tag %08X\n", tag); return 2; }
    }
    printf("MEMSYS write runs %u beats %u hazard flushes %u hazard-wait clocks %u\n", t->st_mem[0], t->st_mem[1], t->st_mem[2], t->st_mem[3]);
    printf("SUMMARY extents %llu pixels written %u clocks %llu DDR write beats %llu read beats %llu (DDR latency %d, waitrequest %d%%)\n",
           exts, t->st_pixels, clocks, w0_lines, cr_reads, DLAT, DWBP);
    printf("%s: %d of %d frames bit-exact vs MAME (colour both buffers + render-buffer depth)\n", (bad || !ok) ? "FAIL" : "PASS", ok, ok + bad);
    delete t; return (bad || !ok) ? 1 : 0;
}
