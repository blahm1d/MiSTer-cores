// Gate for zr_rsys -- the WHOLE renderer (front end -> setup -> pixel pipe) against MAME, end to end.
// Input: the capture's CPU writes to the Zeus 1 window (io.log.gz), replayed from the capture's seed. Output compared:
// at every frame boundary (frames.txt, the point MAME's frame buffer was dumped), wave RAM 1 -- the colour words of
// BOTH frame buffers -- and the render buffer's depth (on chip, read over the debug port), against MAME's dump,
// word-exact. No golden model in the loop: this is the RTL against MAME.
// The testbench is the wave RAM, shared by three ports: the front end's (pipelined, in-order responses: models and
// host access), the pixel pipe's texture-line reads (fixed latency) and its colour writes / reads.
// usage: tb_zr_rsys <render-evidence> [frames] [ddr-read-latency] [ddr-waitrequest%]
#include "Vzr_rsys.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <deque>
#include <algorithm>
#include <zlib.h>

typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8; typedef int32_t s32; typedef uint64_t u64;
static std::vector<u8> read_gz(const std::string& p) {
    std::vector<u8> out; gzFile f = gzopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    u8 buf[1 << 16]; int n; while ((n = gzread(f, buf, sizeof buf)) > 0) out.insert(out.end(), buf, buf + n); gzclose(f); return out;
}
static std::vector<u8> read_file(const std::string& p) {
    FILE* f = fopen(p.c_str(), "rb"); if (!f) { printf("FAIL: cannot open %s\n", p.c_str()); exit(2); }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET); std::vector<u8> v(n); if (fread(v.data(), 1, n, f) != (size_t)n) exit(2); fclose(f); return v;
}
template <class T> static T item(const std::string& ev, const char* name) {
    std::vector<u8> v = read_gz(ev + "/seed_item_0_" + name + ".bin.gz"); T t; memcpy(&t, v.data(), sizeof(T)); return t;
}
static u64 rs = 0x243F6A8885A308D3ull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

int main(int argc, char** argv) {
    if (argc < 2) { printf("usage: tb_zr_rsys <evidence> [frames] [ddr-lat] [ddr-waitrequest%%]\n"); return 2; }
    std::string ev = argv[1]; int maxf = argc > 2 ? atoi(argv[2]) : 1 << 30;
    int DLAT = argc > 3 ? atoi(argv[3]) : 12, DWBP = argc > 4 ? atoi(argv[4]) : 0;   // DDR read latency (clocks), waitrequest %
    std::vector<u8> w[2] = {read_gz(ev + "/seed_item_0_m_waveram_0_.bin.gz"), read_gz(ev + "/seed_item_0_m_waveram_1_.bin.gz")};
    std::vector<u8> regs = read_file(ev + "/seed_zeus1_regs.bin");
    std::vector<u8> fifo = read_gz(ev + "/seed_item_0_m_zeus_fifo.bin.gz");
    std::vector<u8> mtx = read_gz(ev + "/seed_item_0_m_zeus_matrix.bin.gz"), pnt = read_gz(ev + "/seed_item_0_m_zeus_point.bin.gz");
    struct Fr { int fr; u64 n; u64 t; }; std::vector<Fr> frames;
    { FILE* f = fopen((ev + "/frames.txt").c_str(), "r"); int fr; unsigned long long n, s, a;
      while (f && fscanf(f, "%d %llu %llu %llu", &fr, &n, &s, &a) == 4) frames.push_back({fr, (u64)n, (u64)a}); if (f) fclose(f); }
    std::vector<u8> io = read_gz(ev + "/io.log.gz"); io.push_back(0);
    u32 reg84; memcpy(&reg84, &regs[0x84 * 4], 4);

    {   // r12: seed the on-chip render-buffer depth with MAME's (zr_dlane +ZR_DEPTH_SEED): lane l of word p>>2 = pixel p
        u32 rbw = (reg84 & 0x1ff) * 512 * 8 / 2;               // the render buffer's first 16-bit word in wave RAM 1
        for (int l = 0; l < 4; l++) {
            char nm[64]; snprintf(nm, sizeof nm, "dseed_%d.hex", l); FILE* f = fopen(nm, "w"); if (!f) { printf("FAIL: %s\n", nm); return 2; }
            for (u32 p = (u32)l; p < 400 * 256; p += 4) {
                u32 y = p / 400, x = p % 400, word = rbw + ((y << 10) | ((x & 0x1fe) << 1) | (x & 1) | 2); u16 d;
                memcpy(&d, &w[1][2 * word], 2); fprintf(f, "%04x\n", d);
            }
            fclose(f);
        }
    }
    std::vector<char*> av(argv, argv + argc); static char dsa[] = "+ZR_DEPTH_SEED=dseed_"; av.push_back(dsa);
    Verilated::commandArgs((int)av.size(), av.data());
    Vzr_rsys* t = new Vzr_rsys;
    struct Pend { u64 data, due; };
    u64 clocks = 0, oob = 0;
    // PACED mode (ZR_PACE=1): every CPU write is presented no earlier than its MAME timestamp converted to 50 MHz
    // fabric clocks (1 clock = 2e10 attoseconds), so the renderer sees the command stream at the CPU's real pace
    // instead of back to back. Reported: how long the CPU would have stalled on the front end, and how long after
    // each frame boundary the renderer finished draining.
    const bool PACE = getenv("ZR_PACE") && atoi(getenv("ZR_PACE"));
    // r12 FREE RUN (ZR_FREERUN=1, with ZR_PACE=1 and the core's queue: ZRS_G=-GCQ_AW=12): the frame boundary neither waits
    // for the renderer to drain nor compares, so a backlog carries across frames exactly as on the cabinet (the drain-and-
    // compare at every boundary is a sim mercy that resets the backlog). Measured: the page-ownership checker below (r13: in this testbench; r12's RTL instrument zr_own left the core).
    const bool FREE = getenv("ZR_FREERUN") && atoi(getenv("ZR_FREERUN"));
    bool in_readback = false; u64 rt = 0, cpu_stall = 0, cpu_stall_max = 0; long long drain_max = -1; u64 drain_sum = 0;
    // HPS DDR3 model (Avalon-MM, 64-bit words): wave RAM 0 at WR0 and wave RAM 1 at WR1 (word addresses). Reads return
    // IN ORDER, one beat per clock, DLAT clocks after acceptance, data snapshotted AT ACCEPTANCE (a later write cannot
    // change it); a write beat lands when accepted. DWBP % of clocks assert waitrequest (hostile arbitration / refresh).
    // A write burst's address and burstcount are taken from its first beat.
    const u64 WR0 = 0x06000000ull, WR1 = 0x06100000ull;
    auto wptr = [&](u64 wa) -> u8* {
        if (wa >= WR0 && (wa - WR0) * 8 + 8 <= w[0].size()) return &w[0][(wa - WR0) * 8];
        if (wa >= WR1 && (wa - WR1) * 8 + 8 <= w[1].size()) return &w[1][(wa - WR1) * 8];
        printf("FAIL: DDR word address %09llX outside both wave RAMs\n", (unsigned long long)wa); exit(1);
    };
    struct Beat { u64 due, data; };
    std::deque<Beat> rq;
    bool wb_on = false; u64 wb_addr = 0; unsigned wb_left = 0;
    u64 ddr_rd_beats = 0, ddr_wr_beats = 0, ddr_rd_cmds = 0, ddr_wr_cmds = 0;
    // ddr-fullbe lane: the Cyclone V HPS f2sdram port DROPS a write beat whose byte enable is not 0xFF (cabinet r5/r6,
    // lanes/cab-r4/RESUME.md "MECHANISM" + WRMODE sweep). ZR_DDR_DROP=1 models it: such a beat has NO effect.
    // ZR_DDR_STRICT=1 additionally FAILS the run if any write beat carries BE != 0xFF (independent of whether the drop
    // happened to change a compared word). Census (always): write beats by byte-enable class, per frame and total.
    const bool DROP = getenv("ZR_DDR_DROP") && atoi(getenv("ZR_DDR_DROP"));
    const bool STRICT = getenv("ZR_DDR_STRICT") && atoi(getenv("ZR_DDR_STRICT"));
    // ZR_CMP_DEPTHLANES=1: the DDR image's depth lanes of wave RAM 1 must ALSO equal MAME's (the whole wave RAM 1 word-exact)
    const bool CMPDL = getenv("ZR_CMP_DEPTHLANES") && atoi(getenv("ZR_CMP_DEPTHLANES"));
    u64 be_full = 0, be_cpair = 0, be_c1 = 0, be_other = 0, be_dropped = 0;   // FF / colour pair (0F,F0) / one colour lane (03,0C,30,C0) / else
    u64 f_full = 0, f_cpair = 0, f_c1 = 0, f_other = 0;                        // at the previous frame
    auto fnv = [](const std::vector<u8>& v) { u64 h = 0xcbf29ce484222325ull; for (u8 c : v) { h ^= c; h *= 0x100000001b3ull; } return h; };
    // r12 FLIP census (meaningful when paced): a CPU 0xCC write while the renderer still has work (command queue not
    // empty or the chain not idle); the flip's latency to the scanout-visible base (zr_render5 disp_cc, r12); and whether the
    // chain behind the front end (pipe_idle) was still drawing when it changed, with the clocks until it was idle --
    // the time scanout could show a buffer whose last polygons have not landed.
    u64 fl_cpu = 0, fl_cpu_busy = 0, fl_lat_max = 0, fl_lat_sum = 0, fl_sc = 0, fl_sc_busy = 0, fl_dr_max = 0, fl_dr_sum = 0;
    std::deque<u64> fl_pend; u32 fl_cc = 0; bool fl_cc_init = false, fl_drain = false; u64 fl_dr_t0 = 0;
    // r13 PAGE-OWNERSHIP CHECKER (sim-only; replaces the r12 RTL instrument zr_own). MAME: every frame writes RB then CC,
    // RB page != CC page (2006/2006), and the displayed buffer is never drawn into. Invariant: no colour write (pixel or
    // clear: the zr_memsys cw handshake, zr_rsys chk_cw_* under ZR_OWNCHK) lands in the 512 KB page (256 rows x 2 KB)
    // at the base scanout is showing (zr_render5 disp_cc). Byte address of the base = ((cc & 0x1ff) + (cc[24:16] << 9)) * 8
    // (zr_scanout's word address); the window is not wrapped (stricter than zr_own's 21-bit compare).
    u64 own_viol = 0, own_frame = 0, own_first_frame = 0, own_first_addr = 0, own_first_cc = 0; bool own_have = false;
    auto tick = [&]() {
        t->clk = 0; t->eval();
        t->av_readdatavalid = 0;
        if (!rq.empty() && rq.front().due <= clocks) { t->av_readdatavalid = 1; t->av_readdata = rq.front().data; rq.pop_front(); }
        t->av_waitrequest = (DWBP != 0) && (int)(rnd() % 100) < DWBP;
        t->sc_req = 0;
        t->eval();
        if (!t->av_waitrequest) {
            if (t->av_read) {
                u64 base = t->av_address; unsigned n = t->av_burstcount;
                u64 due = std::max<u64>(clocks + (u64)DLAT, rq.empty() ? 0 : rq.back().due + 1);
                for (unsigned k = 0; k < n; k++) { u64 d; memcpy(&d, wptr(base + k), 8); rq.push_back({due + k, d}); }
                ddr_rd_beats += n; ddr_rd_cmds++;
            }
            if (t->av_write) {
                if (!wb_on) { wb_on = true; wb_addr = t->av_address; wb_left = t->av_burstcount; ddr_wr_cmds++; }
                u8* p = wptr(wb_addr); u64 d = t->av_writedata;
                unsigned be = t->av_byteenable & 0xff;
                if (be == 0xff) be_full++;
                else if (be == 0x0f || be == 0xf0) be_cpair++;
                else if (be == 0x03 || be == 0x0c || be == 0x30 || be == 0xc0) be_c1++;
                else be_other++;
                if (DROP && be != 0xff) be_dropped++;
                else for (int b = 0; b < 8; b++) if (be >> b & 1) p[b] = (u8)(d >> (8 * b));
                wb_addr++; ddr_wr_beats++;
                if (--wb_left == 0) wb_on = false;
            }
        }
        if (t->fault) { printf("FAIL: gateway fault\n"); exit(1); }
        if (t->chk_cw_fire) {                                      // pre-edge values: the write this clock + the base shown
            u64 cc = t->disp_cc, blk = (cc & 0x1ff) + (((cc >> 16) & 0x1ff) << 9), base = (blk << 3) & 0x1fffff;
            u64 a = t->chk_cw_addr & 0x1fffff;
            if (a >= base && a < base + 0x80000) {
                if (!own_have) { own_have = true; own_first_frame = own_frame; own_first_addr = t->chk_cw_addr; own_first_cc = cc; }
                own_viol++;
            }
        }
        t->eval(); t->clk = 1; t->eval(); clocks++;
        if (!in_readback) rt++;                                    // real time: frozen while the testbench reads depth
        if (!fl_cc_init) { fl_cc = t->disp_cc; fl_cc_init = true; }
        if (t->disp_cc != fl_cc) {
            fl_cc = t->disp_cc; fl_sc++;
            if (!fl_pend.empty()) { u64 l = rt - fl_pend.front(); fl_pend.pop_front(); fl_lat_sum += l; if (l > fl_lat_max) fl_lat_max = l; }
            if (!t->pipe_idle) { fl_sc_busy++; fl_drain = true; fl_dr_t0 = rt; }
        }
        if (fl_drain && t->pipe_idle) { u64 d = rt - fl_dr_t0; fl_dr_sum += d; if (d > fl_dr_max) fl_dr_max = d; fl_drain = false; }
    };
    t->rb_init = (reg84 & 0x1ff) * 512 * 8;
    t->rst = 1; t->wr_valid = 0; t->sd_we = 0; tick(); tick(); t->rst = 0; tick();
    auto seed = [&](int sel, int idx, u32 d) { t->sd_we = 1; t->sd_sel = sel; t->sd_idx = idx; t->sd_data = d; tick(); t->sd_we = 0; };
    for (int k = 0; k < 0x400; k++) { u32 v; memcpy(&v, &regs[4 * k], 4); seed(0, k, v); }
    for (int k = 0; k < 20; k++) { u32 v; memcpy(&v, &fifo[4 * k], 4); seed(1, k, v); }
    seed(2, 0, item<u8>(ev, "m_zeus_fifo_words"));
    for (int k = 0; k < 9; k++) { int16_t v; memcpy(&v, &mtx[2 * k], 2); seed(3, k, (u32)(s32)v); }
    for (int k = 0; k < 3; k++) { u32 v; memcpy(&v, &pnt[4 * k], 4); seed(4, k, v); }
    seed(5, 0, item<u32>(ev, "m_zeus_palbase")); seed(6, 0, item<u32>(ev, "m_zeus_objdata"));
    seed(7, 0, (u32)item<s32>(ev, "m_zeus_cliprect_min_x")); seed(7, 1, (u32)item<s32>(ev, "m_zeus_cliprect_max_x"));
    seed(7, 2, (u32)item<s32>(ev, "m_zeus_cliprect_min_y")); seed(7, 3, (u32)item<s32>(ev, "m_zeus_cliprect_max_y"));

    auto wait_idle = [&]() { u64 g = 0; while (!t->idle) { tick(); if (++g > 400000000ull) { printf("FAIL: renderer never idle\n"); exit(1); } } };
    const char* p = (const char*)io.data(); u64 rec = 0; size_t fi = 1; int ok = 0, bad = 0, nfr = 0;
    u64 busy_start = 0;
    auto frame = [&](int fr) {
        own_frame++; tick();                                       // (r12's vblank-pulse clock kept: same timing)
        if (FREE) { nfr++; return; }                              // free run: no drain, no compare (buffers in flux)
        wait_idle(); nfr++;
        if (PACE) {   // drain = when the renderer went idle, relative to this frame's MAME boundary time
            long long bclk = (long long)((frames[fi].t - frames[0].t) / 20000000000ull);
            long long d = (long long)rt - bclk; if (d < 0) d = 0;
            drain_sum += (u64)d; if (d > drain_max) drain_max = d;
            printf("  frame %d: renderer idle %lld clocks after the frame boundary (%.1f %% of a frame)\n", fr, d, 100.0 * d / 882300.0);
        }
        in_readback = true;
        char nm[512]; snprintf(nm, sizeof nm, "%s/frame_%05d_0_m_waveram_1_.bin.gz", ev.c_str(), fr);
        std::vector<u8> m = read_gz(nm);
        u64 dcol = 0, ddep = 0, first = ~0ull, dlane = 0, dfirst = ~0ull;
        for (u32 k = 0; k < w[1].size() / 2; k++) {
            u16 a, b; memcpy(&a, &w[1][2 * k], 2); memcpy(&b, &m[2 * k], 2);
            if (k & 2) { if (a != b) { dlane++; if (dfirst == ~0ull) dfirst = k; } continue; }   // DDR depth lanes (census; gated by ZR_CMP_DEPTHLANES)
            if (a != b) { dcol++; if (first == ~0ull) first = k; }
        }
        printf("DEPTHLANES frame %d: DDR wave-RAM-1 depth lanes differing from MAME %llu", fr, (unsigned long long)dlane);
        if (dlane) { u16 a, b; memcpy(&a, &w[1][2 * dfirst], 2); memcpy(&b, &m[2 * dfirst], 2); printf(" (first word %llu: rtl %04X MAME %04X)", (unsigned long long)dfirst, a, b); }
        printf("\n");
        if (CMPDL) dcol += dlane;
        u32 rb = t->rb_now;
        for (u32 yy = 0; yy < 256; yy++) for (u32 xx = 0; xx < 400; xx++) {
            t->dbg_daddr = yy * 400 + xx; tick(); t->clk = 0; t->eval();
            u16 dv = t->dbg_ddata;
            u32 word = (rb / 2) + ((yy << 10) | ((xx & 0x1fe) << 1) | (xx & 1) | 2);
            u16 mv; memcpy(&mv, &m[2 * word], 2);
            if (dv != mv) { ddep++; if (ddep < 4) printf("  depth y %u x %u: rtl %04X MAME %04X\n", yy, xx, dv, mv); }
        }
        in_readback = false;
        printf("DDRW frame %d: write beats %llu, BE!=FF %llu (colour-pair %llu, one-colour-lane %llu, other %llu); image w0 %016llx w1 %016llx\n",
               fr, (unsigned long long)(be_full + be_cpair + be_c1 + be_other - f_full - f_cpair - f_c1 - f_other),
               (unsigned long long)(be_cpair + be_c1 + be_other - f_cpair - f_c1 - f_other),
               (unsigned long long)(be_cpair - f_cpair), (unsigned long long)(be_c1 - f_c1), (unsigned long long)(be_other - f_other),
               (unsigned long long)fnv(w[0]), (unsigned long long)fnv(w[1]));
        f_full = be_full; f_cpair = be_cpair; f_c1 = be_c1; f_other = be_other;
        if (dcol == 0 && ddep == 0) ok++; else bad++;
        printf("frame %d: colour %s (%llu words differ), render-buffer depth %s (%llu differ); quads %u polys %u rejected %u extents %u, clocks %llu\n",
               fr, dcol ? "DIFFERS" : "IDENTICAL", (unsigned long long)dcol, ddep ? "DIFFERS" : "IDENTICAL", (unsigned long long)ddep,
               t->st_quads, t->st_polys, t->st_rejected, t->st_extents, (unsigned long long)clocks);
        if (dcol && first != ~0ull) { u16 a, b; memcpy(&a, &w[1][2 * first], 2); memcpy(&b, &m[2 * first], 2); printf("  first colour word %llu: rtl %04X MAME %04X\n", (unsigned long long)first, a, b); }
    };
    while (*p && fi < frames.size() && nfr < maxf) {
        char kind; unsigned addr, data;
        if (sscanf(p, "%c %x %x", &kind, &addr, &data) != 3) { printf("FAIL: io parse at record %llu\n", (unsigned long long)rec); return 2; }
        if (kind == 'W' && addr >= 0x880000 && addr <= 0x8803FF) {
            if (PACE) {   // wait for this write's real time: io.log columns are kind addr data pc ? time_as
                unsigned long long pc, x, tas;
                if (sscanf(p, "%*c %*x %*x %llx %llu %llu", &pc, &x, &tas) == 3 && tas > frames[0].t) {
                    u64 target = (tas - frames[0].t) / 20000000000ull;
                    while (rt < target) tick();
                }
            }
            if (addr == 0x8800CC) {                                 // r12 FLIP census: the CPU's flip
                static u32 last_cc = ~0u; fl_cpu++; if (!t->idle) fl_cpu_busy++;
                if (data != last_cc) { fl_pend.push_back(rt); last_cc = data; }
            }
            t->wr_off = addr - 0x880000; t->wr_data = data; t->wr_valid = 1;
            u64 g = 0; while (!t->wr_ready) { tick(); if (++g > 400000000ull) { printf("FAIL: write never accepted\n"); return 1; } }
            cpu_stall += g; if (g > cpu_stall_max) cpu_stall_max = g;
            tick(); t->wr_valid = 0;
        }
        rec++;
        while (*p && *p != '\n') p++;
        if (*p) p++;
        while (fi < frames.size() && rec == frames[fi].n && nfr < maxf) { frame(frames[fi].fr); fi++; }
    }
    if (t->unsupported) { printf("FAIL: a debug quad (unsupported) reached the renderer\n"); bad++; }
    printf("COUPLING clocks %u: quad-waits-for-setup %u, drain-for-RB/CLR %u, extent-waits-for-pixel %u, pixel-starved %u, CPU-waits-for-front %u\n",
           t->st_clk, t->st_wsetup, t->st_wdrain, t->st_extstall, t->st_pixstarve, t->st_frontwait);
    printf("CMDQ peak occupancy %u words, CPU refused (queue full) %u clocks\n", t->st_cq_max, t->st_cq_full);
    printf("CLEARS started %u completed %u; debug quads drawn %u, empty %u, not-a-rectangle %u\n",
           t->st_clears, t->st_clr_done, t->st_dbq, (unsigned)t->st_dbq_empty, (unsigned)t->st_dbq_bad);
    printf("FLIP cpu 0xCC writes %llu, while renderer busy %llu; scanout base changes %llu, latency cpu->scanout max %llu mean %.0f clk; "
           "base changed while the chain was still drawing %llu, drain after it max %llu mean %.0f clk%s\n",
           (unsigned long long)fl_cpu, (unsigned long long)fl_cpu_busy, (unsigned long long)fl_sc, (unsigned long long)fl_lat_max,
           fl_sc ? (double)fl_lat_sum / fl_sc : 0.0, (unsigned long long)fl_sc_busy, (unsigned long long)fl_dr_max,
           fl_sc_busy ? (double)fl_dr_sum / fl_sc_busy : 0.0, PACE ? "" : " (batch: not real time)");
    {   // per-block census, per frame
        const char* nm[21] = {"f.quads", "f.busy", "f.mem", "f.tr", "f.zc", "f.proj", "f.emit", "f.dec", "s.clk", "s.fe", "s.a", "s.b",
                              "p.misslines", "p.palloads", "p.stall", "p.pixels", "p.cr_clk", "p.w0_clk", "p.busy", "f.notidle", "p.pflines"};
        printf("CENSUS per frame:");
        for (int k = 0; k < 21; k++) printf(" %s %.0f", nm[k], nfr ? (double)t->st_cen[k] / nfr : 0.0);
        printf("\n");
    }
    printf("MEMSYS write runs %u (%u beats, %.2f beats/run), hazard flushes %u, hazard-wait clocks %u; DDR read cmds %llu beats %llu, write cmds %llu beats %llu; per frame: %.0f DDR beats\n",
           t->st_mem[0], t->st_mem[1], t->st_mem[0] ? (double)t->st_mem[1] / t->st_mem[0] : 0.0, t->st_mem[2], t->st_mem[3],
           (unsigned long long)ddr_rd_cmds, (unsigned long long)ddr_rd_beats, (unsigned long long)ddr_wr_cmds, (unsigned long long)ddr_wr_beats,
           nfr ? (double)(ddr_rd_beats + ddr_wr_beats) / nfr : 0.0);
    printf("SUMMARY frames %d clocks %llu (%.0f per frame) out-of-range %llu (DDR read latency %d, waitrequest %d%%)\n",
           nfr, (unsigned long long)clocks, nfr ? (double)clocks / nfr : 0.0, (unsigned long long)oob, DLAT, DWBP);
    if (PACE) printf("REALTIME cpu stalled %llu clocks total (%.2f %% of %llu), worst single write %llu; drain after frame boundary max %lld (%.1f %% of a frame), mean %.0f\n",
                     (unsigned long long)cpu_stall, rt ? 100.0 * cpu_stall / rt : 0.0, (unsigned long long)rt, (unsigned long long)cpu_stall_max,
                     drain_max, 100.0 * drain_max / 882300.0, nfr ? (double)drain_sum / nfr : 0.0);
    printf("DDRW total: write beats %llu, BE==FF %llu, BE!=FF %llu (colour-pair %llu, one-colour-lane %llu, other %llu), dropped %llu (DROP %d STRICT %d); memsys: coalescer beats %u partial %u, front-end beats %u partial %u\n",
           (unsigned long long)(be_full + be_cpair + be_c1 + be_other), (unsigned long long)be_full,
           (unsigned long long)(be_cpair + be_c1 + be_other), (unsigned long long)be_cpair, (unsigned long long)be_c1, (unsigned long long)be_other,
           (unsigned long long)be_dropped, (int)DROP, (int)STRICT, t->st_mem[4], t->st_mem[5], t->st_mem[6], t->st_mem[7]);
    if (STRICT && (be_cpair + be_c1 + be_other) != 0) { printf("FAIL: STRICT: %llu DDR write beats carried BE != 0xFF\n", (unsigned long long)(be_cpair + be_c1 + be_other)); bad++; }
    if (FREE) { u64 g = 0; while (!t->idle) { tick(); if (++g > 400000000ull) break; } }
    {   // r13 page-ownership checker (above)
        printf("OWN violations %llu (colour writes into the displayed page); scanout-base changes %llu, while the chain was drawing %llu; base queue overflow %d\n",
               (unsigned long long)own_viol, (unsigned long long)fl_sc, (unsigned long long)fl_sc_busy, (int)t->disp_ovf);
        if (own_have) printf("OWN first violation: frame %llu disp_cc %08llX addr %08llX\n", (unsigned long long)own_first_frame,
                             (unsigned long long)own_first_cc, (unsigned long long)own_first_addr);
        if (own_viol) { printf("FAIL: %llu colour writes landed in the page scanout was showing (page-ownership invariant, MAME: 0)\n", (unsigned long long)own_viol); bad++; }
    }
    bool pass = bad == 0 && (ok > 0 || FREE);
    printf("%s: %d of %d frames bit-exact vs MAME (both colour buffers + render-buffer depth), CPU writes in, RTL renderer end to end\n",
           pass ? "PASS" : "FAIL", ok, nfr);
    delete t; return pass ? 0 : 1;
}
