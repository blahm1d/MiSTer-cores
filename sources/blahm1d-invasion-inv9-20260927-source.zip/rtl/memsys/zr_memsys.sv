// zr_memsys.sv -- MK4 renderer memory system: the renderer's four wave-RAM ports + scanout -> ONE HPS DDR3 port
// through zeus_ddr_gateway (performance/replace-rtl-v28: the S3 write path -- no per-write barrier, streaming write
// bursts, epoch fences only -- and the read buffer in M10K). Brief: zeus1/MEMSYS-MK4-DDR-BRIEF.md.
//
//   fm   front end: 64-bit blocks of wave RAM 0 or 1, read / lane-masked write, request/grant + in-order rvalid
//   w0   pixel texture / palette lines (wave RAM 0), 64-bit read, request/grant + in-order rvalid
//   cr   pixel destination read (wave RAM 1), 16-bit, request/grant + in-order rvalid
//   cw   pixel colour write + clear (wave RAM 1), posted 32-bit with a 2-lane (16-bit) mask
//   sc   scanout, bursts of up to 32 64-bit words of wave RAM 1, request/grant + in-order rvalid / rlast
//
// Every client enters through a 2-entry FIFO whose ready is a REGISTERED count (zr_fifo), so no grant the renderer
// sees is combinational through this block (the pixel pipe's cr_gnt / cw_ready feed its global stall).
//
// WRITE COALESCER. The gateway holds ONE write in flight (write_reserved until it retires), so single-pixel writes would
// serialise on its retire loop. MAME's wave RAM 1 layout puts colour x, x+1 and depth x, x+1 in one 64-bit word (the
// pixel pipe writes the colour half), so a span's writes are consecutive 64-bit words in one row: they merge into one
// open beat per word and one burst of up to 32 beats per contiguous run. Closed runs queue as descriptors
// (address, beats) with their beats in an M10K FIFO; the gateway gathers the beats straight from that FIFO.
//
// ORDERING CONTRACT (zr_pixel8/9 header): a colour write accepted before a colour read is accepted is visible to that
// read. The gateway issues in admission order and the MiSTer DDRAM port keeps read-after-write order for one master
// (S3 licence: PSX / Saturn ddram.sv), so a write ADMITTED to the gateway before a read is safe. A write still inside
// this block is not: a wave-RAM-1 read (cr, sc) whose word falls in the input queue, the open run or a queued
// descriptor waits, and the coalescer is flushed. Across clients, ordering is decided by AGE (zr_age2, see AGES below):
// every hazard compares only against OLDER accesses and a younger access waits in its own queue, so no wait cycle can
// form. (Reading a NEWER write than required is harmless: the pixel pipe never has a later write to the same pixel in
// flight while that pixel's own read is outstanding -- raw_hz.) Brief: MEMSYS-MK4-DDR-BRIEF.md "Ordering design".
module zr_memsys #(
  parameter logic [28:0] WR0_BASE = 29'h0600_0000,   // DDR word (8-byte) addresses: wave RAM 0 = 8 MB at 0x30000000, wave RAM 1 = 2 MB at 0x30800000
  parameter logic [28:0] WR1_BASE = 29'h0610_0000,
  parameter int          IDLE_FLUSH = 16,            // clocks without a colour write before an open run is flushed
  parameter int          GW_SLOTS = 16,              // gateway descriptors in flight (zr_ddr_gateway SLOTS)
  parameter int          DQ = 4                      // closed runs queued (hazard-checked, read-modify-write pipelined over them)
) (
  input  logic        clk, rst,
  // front end
  input  logic        fm_req, fm_we, fm_ram, input logic [20:0] fm_blk, input logic [3:0] fm_lanes,
  input  logic [63:0] fm_wdata, output logic fm_gnt, output logic fm_rvalid, output logic [63:0] fm_rdata,
  // pixel pipe
  input  logic        w0_req, input logic [20:0] w0_line, output logic w0_gnt, output logic w0_rvalid, output logic [63:0] w0_data,
  input  logic        cw_valid, output logic cw_ready, input logic [31:0] cw_addr, input logic [31:0] cw_data, input logic [1:0] cw_mask,
  input  logic [15:0] cw_z, input logic cw_zv,        // the written pixel's depth AFTER the write (render buffer, on chip), if known
  input  logic        cr_req, input logic [31:0] cr_addr, output logic cr_gnt, output logic cr_rvalid, output logic [15:0] cr_data,
  // scanout
  input  logic        sc_req, input logic [19:0] sc_word, input logic [5:0] sc_beats, output logic sc_gnt,
  output logic        sc_rvalid, output logic sc_rlast, output logic [63:0] sc_rdata,
  // HPS DDR3 (Avalon-MM, 64-bit words)
  output logic        av_read, av_write, output logic [28:0] av_address, output logic [7:0] av_burstcount,
  output logic [63:0] av_writedata, output logic [7:0] av_byteenable,
  input  logic        av_waitrequest, av_readdatavalid, input logic [63:0] av_readdata,
  output logic        idle, fault,
  output logic        wr_idle,                   // r12: every accepted colour write has left this block for the gateway (scanout reads ignored)
  output logic [31:0] st_wbursts, st_wbeats, st_flush_hz, st_wait_hz,
  output logic [31:0] st_bcw, st_pcw, st_bfm, st_pfm   // census: write beats to the gateway from the coalescer / front end; of them BE != 0xFF
);
`ifdef ZR_CENSUS
  localparam logic [31:0] CEN = 32'd1;
`else
  localparam logic [31:0] CEN = 32'd0;
`endif
  localparam logic [2:0] C_FM = 3'd0, C_W0 = 3'd1, C_CR = 3'd2, C_SC = 3'd3, C_WR = 3'd4, C_RM = 3'd5, C_FR = 3'd6;   // C_RM: read half of a run's read-modify-write

  // ================= client input queues (registered ready) =================
  logic [1:0] n_fm, n_w0, n_cr, n_sc, n_cw;
  logic qfm_v, qfm_pop; logic [90:0] qfm;                       // {we, ram, blk, lanes, wdata}
  logic qw0_v, qw0_pop; logic [20:0] qw0;
  logic qcr_v, qcr_pop; logic [31:0] qcr;
  logic qsc_v, qsc_pop; logic [25:0] qsc;                       // {word, beats}
  logic qcw_v, qcw_pop; logic [82:0] qcw;                       // {addr, data, mask, z, zv}
  zr_fifo #(91, 1) u_qfm (.clk, .rst, .in_valid(fm_req), .in_ready(fm_gnt), .in_data({fm_we, fm_ram, fm_blk, fm_lanes, fm_wdata}),
    .out_valid(qfm_v), .out_ready(qfm_pop), .out_data(qfm), .count(n_fm));
  zr_fifo #(21, 1) u_qw0 (.clk, .rst, .in_valid(w0_req), .in_ready(w0_gnt), .in_data(w0_line),
    .out_valid(qw0_v), .out_ready(qw0_pop), .out_data(qw0), .count(n_w0));
  zr_fifo #(32, 1) u_qcr (.clk, .rst, .in_valid(cr_req), .in_ready(cr_gnt), .in_data(cr_addr),
    .out_valid(qcr_v), .out_ready(qcr_pop), .out_data(qcr), .count(n_cr));
  zr_fifo #(26, 1) u_qsc (.clk, .rst, .in_valid(sc_req), .in_ready(sc_gnt), .in_data({sc_word, sc_beats}),
    .out_valid(qsc_v), .out_ready(qsc_pop), .out_data(qsc), .count(n_sc));
  logic cw_hold, qcw_ir;                                         // v2: new colour writes held while a read waits on a hazard
  zr_fifo #(83, 1) u_qcw (.clk, .rst, .in_valid(cw_valid && !cw_hold), .in_ready(qcw_ir), .in_data({cw_addr, cw_data, cw_mask, cw_z, cw_zv}),
    .out_valid(qcw_v), .out_ready(qcw_pop), .out_data(qcw), .count(n_cw));
  // the grants are "accepted into the queue" pulses: a request is granted when offered and the queue had room
  // (fm_gnt / w0_gnt / cr_gnt / sc_gnt are the queues' in_ready, which the clients AND with their own request)

  // ================= gateway =================
  logic g_req_valid, g_req_ready, g_req_write; logic [28:0] g_req_addr; logic [5:0] g_req_beats; logic [15:0] g_req_tag;
  logic g_w_valid, g_w_ready; logic [63:0] g_w_data; logic [7:0] g_w_mask;
  logic g_rsp_valid, g_rsp_ready, g_rsp_last, g_rsp_write;   // r11: g_rsp_ready declared before the gateway port that uses it
  logic [63:0] g_rsp_data; logic [15:0] g_rsp_tag;
  logic g_fence_req, g_idle, g_wfree, g_fault; logic [$clog2(GW_SLOTS):0] g_occ;
  zr_ddr_gateway #(.SLOTS(GW_SLOTS)) u_gw (.clk, .reset(rst), .quiesce(1'b0),
    .req_valid(g_req_valid), .req_ready(g_req_ready), .req_write(g_req_write), .req_publish(1'b0),
    .req_address(g_req_addr), .req_beats(g_req_beats), .req_tag(g_req_tag),
    .w_valid(g_w_valid), .w_ready(g_w_ready), .w_data(g_w_data), .w_mask(g_w_mask),
    .rsp_valid(g_rsp_valid), .rsp_ready(g_rsp_ready), .rsp_data(g_rsp_data), .rsp_tag(g_rsp_tag), .rsp_last(g_rsp_last),
    .rsp_write(g_rsp_write),
    .av_read, .av_write, .av_address, .av_burstcount, .av_writedata, .av_byteenable,
    .av_waitrequest, .av_readdatavalid, .av_readdata,
    .fence_req(g_fence_req), .fence_ack(g_fence_req), .idle(g_idle), .write_slot_free(g_wfree), .fault(g_fault),
    .occupied(g_occ));
  localparam int DB = $clog2(DQ + 1);
  logic [DB-1:0] rm_col; logic [5:0] rm_got; logic rm_wr_go, rm_wmode, pr_go, pr_hi;   // FULL-BE RUNS (partial-beat read-modify-write)
  logic rm_fault;
  typedef enum logic [1:0] { FR_NONE, FR_WAIT, FR_RDY } fr_t;     // front-end partial write read-modify-write state
  fr_t fr_st; logic [63:0] fr_d; logic fm_part, fm_rmw_rd;
  assign fault = g_fault || rm_fault;
  logic [2:0] r_cl; assign r_cl = g_rsp_tag[4:2];
  logic rm_hold;                                                   // rm_hold: a partial-beat read returned before its beat reached the head
  assign g_rsp_ready = !(g_rsp_valid && !g_rsp_write && r_cl == C_RM && rm_hold);
  logic rd; assign rd = g_rsp_valid && g_rsp_ready && !g_rsp_write;

  // ================= write coalescer =================
  logic        ob_v; logic [28:0] ob_word; logic [63:0] ob_data; logic [7:0] ob_mask;   // open beat
  logic [28:0] bu_start; logic [5:0] bu_n;                       // beats of the open beat's run already in the FIFO
  logic [7:0]  idle_cnt;
  logic bf_iv, bf_ir, bf_ov, bf_pop, bf_empty; logic [71:0] bf_in, bf_out;
  zr_rfifo #(72, 6) u_bf (.clk, .rst, .in_valid(bf_iv), .in_ready(bf_ir), .in_data(bf_in),
    .out_valid(bf_ov), .out_ready(bf_pop), .out_data(bf_out), .empty(bf_empty));
  logic df_iv, df_ov, df_pop; logic [34:0] df_in, df_out; logic [DB-1:0] df_cnt;
  logic [34:0] df_q [DQ];                                         // closed runs, head df_q[0]

  // the queued colour write as a 64-bit beat
  logic [31:0] q_addr; logic [31:0] q_data; logic [1:0] q_mask; logic [15:0] q_z; logic q_zv;
  assign {q_addr, q_data, q_mask, q_z, q_zv} = qcw;
  logic [28:0] cw_word; logic [63:0] cw_d64; logic [7:0] cw_m8;
  always_comb begin
    cw_word = WR1_BASE + 29'(q_addr >> 3);
    // DEPTH LANES (ddr-fullbe). MAME's word is {depth x+1, depth x, colour x+1, colour x} (midzeus_v.cpp:105-111) and
    // MAME writes a pixel's depth with its colour (plot_depth :158, the clear :916-918 depth 0x7fff, a textured pixel
    // :1428-1431 when depth_write_enable). The pixel pipe keeps the render buffer's depth on chip and sends the pixel's
    // depth after the write (cw_z, cw_zv); it lands in the word's depth lane, so a pixel pair written together is a FULL
    // beat (BE 0xFF) that needs no read, and DDR's depth lanes follow MAME's. (The colour pair is the low half: cw_addr[2]
    // is 0 for every MK4 colour write -- mutant C4 equivalence; a high-half write carries no depth.)
    cw_d64 = q_addr[2] ? {q_data, 32'd0} : {q_z, q_z, q_data};
    cw_m8  = q_addr[2] ? {{2{q_mask[1]}}, {2{q_mask[0]}}, 4'd0}
                       : {{2{q_zv && q_mask[1]}}, {2{q_zv && q_mask[0]}}, {2{q_mask[1]}}, {2{q_mask[0]}}};
  end
  logic co_empty; assign co_empty = !ob_v && df_cnt == 0 && n_cw == 0;   // every accepted colour write is admitted

  // hazard: a read word inside the input queue, the open run / beat, or a queued descriptor
  function automatic logic in_run(input logic [28:0] w, input logic [28:0] s, input logic [5:0] n);
    return w >= s && w < s + 29'(n);
  endfunction
  function automatic logic overlap(input logic [28:0] a, input logic [5:0] an, input logic [28:0] b, input logic [5:0] bn);
    return a < b + 29'(bn) && b < a + 29'(an);
  endfunction
  logic [28:0] cr_word, sc_w29, fm_word; logic [5:0] sc_n;
  logic fm_ram1, fm_we_q;
  assign cr_word = WR1_BASE + 29'(qcr >> 3);
  assign sc_w29 = WR1_BASE + 29'(qsc[25:6]); assign sc_n = qsc[5:0];
  assign fm_ram1 = qfm[89]; assign fm_we_q = qfm[90];
  assign fm_word = (fm_ram1 ? WR1_BASE : WR0_BASE) + 29'(qfm[88:68]);
  // PRECISE hazards (v1 waited for ANY queued colour write, or for an EMPTY coalescer before a front-end access to wave
  // RAM 1: both livelocked under a continuous write stream -- tb_zr_memsys). A read or a front-end access waits only on
  // an OLDER write to its own word(s) still inside this block:
  //   colour writes: the 2-entry input queue (qw_*), the open run, the 2 queued descriptors
  //   front-end writes: the 2-entry front-end queue (fq_*) -- a texture, colour or scanout read never passes an older
  //   front-end write of its word (the front end's own reads and writes are one in-order queue)
  // AGES. Every queue here is 2 deep and in order, so "older than" is a 2-bit count per entry of the other queue's
  // entries queued ahead of it (zr_age2). Each hazard compares only against OLDER entries, and a younger entry that must
  // not overtake waits in its queue -- so no wait is ever on a younger access, and no wait cycle can form. (v3 compared
  // words regardless of age: a read then waited on a YOUNGER colour write to the other lane of its word, which waited
  // on an older front-end write, which waited on the read -- tb_zr_memsys deadlock.)
  logic [28:0] qw_word [2]; logic [1:0] qw_n;
  logic [28:0] fq_word [2]; logic fq_we [2]; logic [1:0] fq_n;
  logic [1:0] qwf [2], qwc [2], qws [2];                          // colour-write entries vs front-end / cr / sc queues
  zr_age2 u_awf (.clk, .rst, .push(cw_valid && cw_ready), .pop(qcw_pop), .opop(qfm_pop), .on(fq_n), .y0(qwf[0]), .y1(qwf[1]));
  zr_age2 u_awc (.clk, .rst, .push(cw_valid && cw_ready), .pop(qcw_pop), .opop(qcr_pop), .on(n_cr), .y0(qwc[0]), .y1(qwc[1]));
  zr_age2 u_aws (.clk, .rst, .push(cw_valid && cw_ready), .pop(qcw_pop), .opop(qsc_pop), .on(n_sc), .y0(qws[0]), .y1(qws[1]));
  logic qcw_young; assign qcw_young = qwf[0] != 2'd0;             // head is younger than a queued front-end access
  logic hz_cr, hz_sc, hz_fm, hz_w0;
  // read heads vs the front-end queue: a read waits only on front-end writes OLDER than it (the first *_y entries);
  // a front-end write waits until every OLDER read of its wave RAM is admitted.
  logic [1:0] w0_y, cr_y, sc_y, w0_y1, cr_y1, sc_y1;
  zr_age2 u_aw0 (.clk, .rst, .push(w0_req && w0_gnt), .pop(qw0_pop), .opop(qfm_pop), .on(fq_n), .y0(w0_y), .y1(w0_y1));
  zr_age2 u_acr (.clk, .rst, .push(cr_req && cr_gnt), .pop(qcr_pop), .opop(qfm_pop), .on(fq_n), .y0(cr_y), .y1(cr_y1));
  zr_age2 u_asc (.clk, .rst, .push(sc_req && sc_gnt), .pop(qsc_pop), .opop(qfm_pop), .on(fq_n), .y0(sc_y), .y1(sc_y1));
  logic older_rd;
  assign older_rd = fm_ram1 ? ((qcr_v && cr_y == 2'd0) || (qsc_v && sc_y == 2'd0)) : (qw0_v && w0_y == 2'd0);
  always_comb begin
    hz_cr = 1'b0; hz_sc = 1'b0; hz_fm = 1'b0; hz_w0 = 1'b0;
    for (int k = 0; k < 2; k++) if (2'(k) < qw_n) begin
      if (cr_word == qw_word[k] && qwc[k] == 2'd0) hz_cr = 1'b1;
      if (in_run(qw_word[k], sc_w29, sc_n) && qws[k] == 2'd0) hz_sc = 1'b1;
      if (fm_word == qw_word[k] && qwf[k] == 2'd0) hz_fm = 1'b1;
    end
    if (ob_v) begin                                               // the run INCLUDING the open beat (bu_start + bu_n)
      if (in_run(cr_word, bu_start, bu_n + 6'd1)) hz_cr = 1'b1;
      if (overlap(sc_w29, sc_n, bu_start, bu_n + 6'd1)) hz_sc = 1'b1;
      if (in_run(fm_word, bu_start, bu_n + 6'd1)) hz_fm = 1'b1;
    end
    for (int k = 0; k < DQ; k++) if (DB'(k) < df_cnt) begin
      if (in_run(cr_word, df_q[k][34:6], df_q[k][5:0])) hz_cr = 1'b1;
      if (overlap(sc_w29, sc_n, df_q[k][34:6], df_q[k][5:0])) hz_sc = 1'b1;
      if (in_run(fm_word, df_q[k][34:6], df_q[k][5:0])) hz_fm = 1'b1;
    end
    for (int k = 0; k < 2; k++) if (fq_we[k]) begin
      if (2'(k) < cr_y && cr_word == fq_word[k]) hz_cr = 1'b1;
      if (2'(k) < sc_y && in_run(fq_word[k], sc_w29, sc_n)) hz_sc = 1'b1;
      if (2'(k) < w0_y && WR0_BASE + 29'(qw0) == fq_word[k]) hz_w0 = 1'b1;
    end
    if (!fm_ram1) hz_fm = 1'b0;                                   // colour writes only touch wave RAM 1
  end
  logic flush_req;
  assign cw_ready = qcw_ir && !cw_hold;
  // hold new colour writes (REGISTERED) while a read or a front-end access waits on one, and while a front-end WRITE to
  // wave RAM 1 is queued: only writes accepted before it drain, so nothing is starved and no later colour write
  // overtakes the front-end write
  always_ff @(posedge clk) cw_hold <= !rst && ((qcr_v && hz_cr) || (qsc_v && hz_sc) || (qfm_v && hz_fm));
  // mirrors of the queued colour words and the queued front-end accesses
  always_ff @(posedge clk)
    if (rst) begin qw_n <= 2'd0; fq_n <= 2'd0; end
    else begin : qwm
      logic push, pop, fpush, fpop; logic [28:0] w, fw;
      push = cw_valid && cw_ready; pop = qcw_pop; w = WR1_BASE + 29'(cw_addr >> 3);
      fpush = fm_req && fm_gnt; fpop = qfm_pop; fw = (fm_ram ? WR1_BASE : WR0_BASE) + 29'(fm_blk);
      if (pop) begin qw_word[0] <= qw_word[1]; if (push) qw_word[qw_n == 2'd2 ? 1 : 0] <= w; end
      else if (push) qw_word[qw_n[0]] <= w;
      qw_n <= qw_n + 2'(push) - 2'(pop);
      if (fpop) begin
        fq_word[0] <= fq_word[1]; fq_we[0] <= fq_we[1];
        if (fpush) begin fq_word[fq_n == 2'd2 ? 1 : 0] <= fw; fq_we[fq_n == 2'd2 ? 1 : 0] <= fm_we; end
      end else if (fpush) begin fq_word[fq_n[0]] <= fw; fq_we[fq_n[0]] <= fm_we; end
      fq_n <= fq_n + 2'(fpush) - 2'(fpop);
    end
  assign flush_req = (qcr_v && hz_cr) || (qsc_v && hz_sc) || (qfm_v && hz_fm) || (ob_v && idle_cnt >= 8'(IDLE_FLUSH));

  // coalescer step: take the queued colour write, or flush the open run. One beat + one descriptor per clock at most.
  logic cw_merge, cw_cont, cw_take, do_flush;
  always_comb begin
    cw_merge = ob_v && cw_word == ob_word;
    cw_cont  = ob_v && cw_word == ob_word + 29'd1 && bu_n < 6'd31;
    // colour writes queued AHEAD of a waiting read are taken first; the open run is flushed once the queue is empty.
    // (The pixel pipe cannot keep the queue full while its read waits: the read stalls it after one more write.)
    do_flush = flush_req && ob_v && (!qcw_v || qcw_young) && bf_ir && df_cnt < DB'(DQ);
    cw_take  = qcw_v && !qcw_young && bf_ir && (cw_merge || cw_cont || !ob_v || df_cnt < DB'(DQ));
    bf_iv = 1'b0; bf_in = {ob_mask, ob_data};
    df_iv = 1'b0; df_in = {bu_start, bu_n + 6'd1};                 // the run + the open beat
    if (cw_take && !cw_merge && ob_v) begin
      bf_iv = 1'b1;                                                // the open beat joins its run
      if (!cw_cont) df_iv = 1'b1;                                  // a non-contiguous word closes the run
    end
    if (do_flush) begin bf_iv = 1'b1; df_iv = 1'b1; end
  end
  assign qcw_pop = cw_take;
  always_ff @(posedge clk) begin
    if (rst) begin ob_v <= 1'b0; bu_n <= '0; idle_cnt <= '0; end
    else begin
      idle_cnt <= cw_take ? 8'd0 : (idle_cnt == 8'hff ? idle_cnt : idle_cnt + 8'd1);
      if (cw_take) begin
        if (cw_merge) begin
          for (int b = 0; b < 8; b++) if (cw_m8[b]) ob_data[8*b +: 8] <= cw_d64[8*b +: 8];
          ob_mask <= ob_mask | cw_m8;
        end else begin
          if (!ob_v || !cw_cont) begin bu_start <= cw_word; bu_n <= '0; end
          else bu_n <= bu_n + 6'd1;
          ob_v <= 1'b1; ob_word <= cw_word; ob_data <= cw_d64; ob_mask <= cw_m8;
        end
      end else if (do_flush) begin
        ob_v <= 1'b0; bu_n <= '0;
      end
    end
  end
  // the closed-run queue: DQ entries, shift on pop (a run leaves it -- and the hazard set -- when its write is admitted)
  assign df_ov = df_cnt != '0; assign df_out = df_q[0];
  always_ff @(posedge clk)
    if (rst) begin df_cnt <= '0; for (int k = 0; k < DQ; k++) df_q[k] <= '0; end
    else begin : dfq
      logic [DB-1:0] n; n = df_cnt;
      if (df_pop) begin
        for (int k = 0; k < DQ - 1; k++) df_q[k] <= df_q[k+1];
        n = n - 1'b1;
      end
      if (df_iv) begin df_q[n] <= df_in; n = n + 1'b1; end
      df_cnt <= n;
    end
  // PARTIAL BEATS. A beat leaving the open beat with BE != 0xFF (a span-edge pixel pair with one pixel, or a pixel whose
  // depth is unknown) queues its word for a 1-beat READ (pr_q, in beat order). Every run in df is OLDER than the beat
  // (the beat's own run is still open or closes this clock); if one of them covers the word (pr_dep) the read waits
  // until that many runs have been written (gpop, a count of df pops, reaches the recorded target), so it returns the
  // older write's data. Front-end writes older than the beat were admitted before it entered (qcw_young).
  logic [7:0] gpop;                                                // df pops, wrapping
  logic pr_iv, pr_ir, pr_ov, pr_pop, pr_empty, pr_dep; logic [36:0] pr_in, pr_out;   // {word, target}
  always_comb begin
    pr_dep = 1'b0;
    for (int k = 0; k < DQ; k++) if (DB'(k) < df_cnt && in_run(ob_word, df_q[k][34:6], df_q[k][5:0])) pr_dep = 1'b1;
    pr_iv = bf_iv && bf_in[71:64] != 8'hff;
    pr_in = {ob_word, pr_dep ? gpop + 8'(df_cnt) : gpop};
  end
  zr_rfifo #(37, 6) u_pr (.clk, .rst, .in_valid(pr_iv), .in_ready(pr_ir), .in_data(pr_in),
    .out_valid(pr_ov), .out_ready(pr_pop), .out_data(pr_out), .empty(pr_empty));
  always_ff @(posedge clk) if (rst) gpop <= '0; else if (df_pop) gpop <= gpop + 8'd1;

  // ================= arbitration -> gateway request =================
  // scanout (deadline) > write run > colour read > texture > front end; a client waiting 32 clocks goes first
  logic [5:0] w0_age, fm_age;
  logic sel_sc, sel_wr, sel_cr, sel_w0, sel_fm, ok_sc, ok_wr, ok_cr, ok_w0, ok_fm;
  logic q_fm_we; logic [20:0] q_fm_blk;
  assign q_fm_we = qfm[90]; assign q_fm_blk = qfm[88:68];
  assign fm_part = q_fm_we && qfm[67:64] != 4'hf;              // a lane-masked front-end write ...
  assign fm_rmw_rd = fm_part && fr_st == FR_NONE;               // ... is first a READ of its block (C_FR)
  always_comb begin
    ok_sc = qsc_v && !hz_sc;
    ok_wr = pr_go || rm_wr_go;                                 // a partial beat's read, or the head run's full-BE write
    ok_cr = qcr_v && !hz_cr;
    ok_w0 = qw0_v && !hz_w0;
    ok_fm = qfm_v && !hz_fm && !(fm_we_q && older_rd) && fr_st != FR_WAIT;   // FR_WAIT: its RMW read is in flight
    rm_wmode = 1'b0;
    sel_sc = 1'b0; sel_wr = 1'b0; sel_cr = 1'b0; sel_w0 = 1'b0; sel_fm = 1'b0;
    if (ok_fm && fm_age[5]) sel_fm = 1'b1;
    else if (ok_w0 && w0_age[5]) sel_w0 = 1'b1;
    else if (ok_sc) sel_sc = 1'b1;
    else if (pr_hi) begin sel_wr = 1'b1; rm_wmode = 1'b0; end        // a partial-beat read the collection is waiting on
    else if (rm_wr_go) begin sel_wr = 1'b1; rm_wmode = 1'b1; end     // the head run's full-BE write
    else if (ok_cr) sel_cr = 1'b1;
    else if (ok_w0) sel_w0 = 1'b1;
    else if (pr_go) begin sel_wr = 1'b1; rm_wmode = 1'b0; end        // read-ahead BELOW the latency-critical cr / texture reads
    else if (ok_fm) sel_fm = 1'b1;
    g_req_valid = sel_sc || sel_wr || sel_cr || sel_w0 || sel_fm;
    g_req_write = (sel_wr && rm_wmode) || (sel_fm && q_fm_we && !fm_rmw_rd);
    g_req_beats = sel_wr ? (rm_wmode ? df_out[5:0] : 6'd1) : sel_sc ? sc_n : 6'd1;
    g_req_addr  = sel_wr ? (rm_wmode ? df_out[34:6] : pr_out[36:8]) : sel_sc ? sc_w29 : sel_cr ? cr_word :
                  sel_w0 ? WR0_BASE + 29'(qw0) : (fm_ram1 ? WR1_BASE : WR0_BASE) + 29'(q_fm_blk);
    g_req_tag   = {11'd0, sel_sc ? C_SC : sel_wr ? (rm_wmode ? C_WR : C_RM) : sel_cr ? C_CR : sel_w0 ? C_W0 : fm_rmw_rd ? C_FR : C_FM, sel_cr ? qcr[2:1] : 2'd0};
  end
  logic admit; assign admit = g_req_valid && g_req_ready;
  assign qsc_pop = sel_sc && admit; assign qcr_pop = sel_cr && admit; assign qw0_pop = sel_w0 && admit;
  assign qfm_pop = sel_fm && admit && !fm_rmw_rd; assign df_pop = sel_wr && admit && rm_wmode;   // the run leaves the hazard set when its WRITE is admitted
  always_ff @(posedge clk)
    if (rst) begin w0_age <= '0; fm_age <= '0; end
    else begin
      w0_age <= (qw0_v && !qw0_pop) ? (w0_age[5] ? w0_age : w0_age + 6'd1) : 6'd0;
      fm_age <= (qfm_v && !qfm_pop) ? (fm_age[5] ? fm_age : fm_age + 6'd1) : 6'd0;
    end

  // write data: a run's beats from the beat FIFO; a front-end write's single beat from a holding register
  logic fw_v, w_src_fm; logic [63:0] fw_d; logic [7:0] fw_m;
  always_ff @(posedge clk)
    if (rst) begin fw_v <= 1'b0; w_src_fm <= 1'b0; end
    else begin
      if (admit && g_req_write) w_src_fm <= sel_fm;
      if (qfm_pop && q_fm_we) begin
        fw_v <= 1'b1; fw_d <= fm_part ? fr_d : qfm[63:0];
        fw_m <= 8'hff;                                             // FULL-BE: a partial one was merged over its read (fr_d)
      end else if (fw_v && g_w_ready && w_src_fm) fw_v <= 1'b0;
    end
  // FULL-BE FRONT-END WRITES: a lane-masked front-end write (fm_lanes != 0xF) first READS its block (tag C_FR, the
  // request stays at the head of the front-end queue, so every hazard and age involving it is unchanged), merges its
  // enabled lanes over the returned word (fr_d), then goes out as a full-BE write. zr_front5 S_HWA already does this
  // for host writes; here the invariant "no write beat leaves zr_memsys with BE != 0xFF" holds for any client.
  always_ff @(posedge clk)
    if (rst) fr_st <= FR_NONE;
    else begin
      if (sel_fm && admit && fm_rmw_rd) fr_st <= FR_WAIT;
      if (rd && r_cl == C_FR) begin
        fr_st <= FR_RDY;
        for (int l = 0; l < 4; l++) fr_d[16*l +: 16] <= qfm[64+l] ? qfm[16*l +: 16] : g_rsp_data[16*l +: 16];
      end
      if (qfm_pop) fr_st <= FR_NONE;
    end
  // FULL-BE RUNS (ddr-fullbe lane). The Cyclone V HPS f2sdram port DROPS a write beat whose byte enable is not 0xFF
  // (cabinet r5/r6: lanes/cab-r4/RESUME.md "MECHANISM"). With the depth lanes (above), a beat is full once both pixels
  // of its pair are written; the rest -- span-edge pairs with one pixel, pixels whose depth is unknown -- are PARTIAL.
  // Beats leave the beat FIFO in order into the merge FIFO (mf): a full beat moves as is; a partial beat waits for its
  // 1-beat READ (issued from pr_q in the same order, tag C_RM) and is merged over it (bytes the coalescer wrote win).
  // A run's full-BE WRITE is admitted once all its beats are in mf; it leaves df (the hazard set) then, so every read /
  // front-end hazard is unchanged. A partial-beat read that returns before its beat reaches the head of bf is held
  // (g_rsp_ready) -- bounded: the beats ahead of it are full and move one per clock, and mf has room for them
  // (mf holds at most DQ closed runs + the open run + bf's contents).
  localparam int PR_MAX = 8;                                       // partial-beat reads outstanding
  logic mf_ov, mf_ir, mf_empty, rm_beat, rm_done, mv_beat, col_beat, bf_part; logic [63:0] mf_in, mf_out;
  logic [3:0] pr_n;
  assign bf_part  = bf_out[71:64] != 8'hff;
  assign rm_hold  = !(bf_ov && bf_part && mf_ir);
  assign rm_beat  = rd && r_cl == C_RM;
  assign mv_beat  = bf_ov && !bf_part && mf_ir;
  assign col_beat = rm_beat || mv_beat;
  assign rm_done  = col_beat && rm_col < df_cnt && rm_got + 6'd1 == df_q[rm_col][5:0];
  assign rm_wr_go = rm_col != '0;
  assign pr_go    = pr_ov && $signed(gpop - pr_out[7:0]) >= 0 && pr_n < 4'(PR_MAX);
  assign pr_hi    = pr_go && pr_n == 4'd0;                         // nothing in flight: the merge will wait on this one
  assign pr_pop   = sel_wr && admit && !rm_wmode;
  always_comb for (int b = 0; b < 8; b++) mf_in[8*b +: 8] = (bf_out[64+b] || !rm_beat) ? bf_out[8*b +: 8] : g_rsp_data[8*b +: 8];
  zr_rfifo #(64, 8) u_mf (.clk, .rst, .in_valid(col_beat), .in_ready(mf_ir), .in_data(mf_in),
    .out_valid(mf_ov), .out_ready(!w_src_fm && g_w_ready), .out_data(mf_out), .empty(mf_empty));
  always_ff @(posedge clk)
    if (rst) begin rm_col <= '0; rm_got <= '0; pr_n <= '0; rm_fault <= 1'b0; end
    else begin
      if ((rm_beat && pr_n == 4'd0) || (pr_iv && !pr_ir)) rm_fault <= 1'b1;   // cannot happen
      pr_n   <= pr_n + 4'(pr_pop) - 4'(rm_beat);
      rm_col <= rm_col + DB'(rm_done) - DB'(df_pop);
      if (col_beat) rm_got <= rm_done ? 6'd0 : rm_got + 6'd1;
    end
  always_comb begin
    g_w_valid = w_src_fm ? fw_v : mf_ov;
    g_w_data  = w_src_fm ? fw_d : mf_out;
    g_w_mask  = w_src_fm ? fw_m : 8'hff;
  end
  assign bf_pop = col_beat;

  // ================= responses =================
  assign fm_rvalid = rd && r_cl == C_FM; assign fm_rdata = g_rsp_data;
  assign w0_rvalid = rd && r_cl == C_W0; assign w0_data  = g_rsp_data;
  assign cr_rvalid = rd && r_cl == C_CR; assign cr_data  = g_rsp_data[16*g_rsp_tag[1:0] +: 16];
  assign sc_rvalid = rd && r_cl == C_SC; assign sc_rdata = g_rsp_data; assign sc_rlast = g_rsp_last;

  assign wr_idle = co_empty && bf_empty && mf_empty && pr_empty && pr_n == 4'd0 && rm_col == '0;
  assign idle = co_empty && bf_empty && mf_empty && pr_empty && pr_n == 4'd0 && rm_col == '0 && g_idle && !fw_v && n_fm == 0 && n_w0 == 0 && n_cr == 0 && n_sc == 0;

  always_ff @(posedge clk)
    if (rst) begin st_wbursts <= 0; st_wbeats <= 0; st_flush_hz <= 0; st_wait_hz <= 0; end
    else begin
      if (df_pop) begin st_wbursts <= st_wbursts + CEN; st_wbeats <= st_wbeats + (CEN * 32'(df_out[5:0])); end
      if (do_flush && !(ob_v && idle_cnt >= 8'(IDLE_FLUSH))) st_flush_hz <= st_flush_hz + CEN;
      if ((qcr_v && hz_cr) || (qsc_v && hz_sc) || (qfm_v && hz_fm) || (qw0_v && hz_w0)) st_wait_hz <= st_wait_hz + CEN;
    end
`ifdef ZR_MEMSYS_DBG
  int dbg_quiet = 0;
  always_ff @(posedge clk) begin
    dbg_quiet <= admit ? 0 : dbg_quiet + 1;
    if (dbg_quiet == 3000)
      $display("MSDBG t=%0t fm v%0d we%0d r1%0d hz%0d old%0d | w0 v%0d y%0d hz%0d | cr v%0d y%0d hz%0d | sc v%0d y%0d hz%0d | cw n%0d y%0d/%0d hold%0d ob%0d df%0d fq_n%0d | gw rdy%0d wfree%0d occ%0d",
        $time, qfm_v, fm_we_q, fm_ram1, hz_fm, older_rd, qw0_v, w0_y, hz_w0, qcr_v, cr_y, hz_cr, qsc_v, sc_y, hz_sc,
        qw_n, qwf[0], qwf[1], cw_hold, ob_v, df_cnt, fq_n, g_req_ready, g_wfree, g_occ);
  end
`endif
  always_ff @(posedge clk)
    if (rst) begin st_bcw <= 0; st_pcw <= 0; st_bfm <= 0; st_pfm <= 0; end
    else if (g_w_valid && g_w_ready) begin
      if (w_src_fm) begin st_bfm <= st_bfm + CEN; if (g_w_mask != 8'hff) st_pfm <= st_pfm + CEN; end
      else begin st_bcw <= st_bcw + CEN; if (g_w_mask != 8'hff) st_pcw <= st_pcw + CEN; end
    end
endmodule

// Ages of a 2-entry queue's entries against ANOTHER 2-entry queue: how many of the other queue's entries were queued
// AHEAD of each one (a same-clock pair counts this entry first). Every pop of the other queue retires one. y == 0: the
// entry is older than everything still in the other queue. y0 = head, y1 = second entry (valid when two are queued).
module zr_age2 (
  input  logic clk, rst,
  input  logic push, pop, opop, input logic [1:0] on,
  output logic [1:0] y0, y1
);
  logic [1:0] y [2]; logic [1:0] n;
  assign y0 = y[0]; assign y1 = y[1];
  always_ff @(posedge clk)
    if (rst) begin n <= 2'd0; y[0] <= 2'd0; y[1] <= 2'd0; end
    else begin : st
      logic [1:0] ya [2]; logic [1:0] yn;
      yn = on - 2'(opop);
      for (int k = 0; k < 2; k++) ya[k] = (opop && y[k] != 2'd0) ? y[k] - 2'd1 : y[k];
      if (pop) begin
        y[0] <= ya[1]; y[1] <= ya[1];
        if (push) y[n == 2'd2 ? 1 : 0] <= yn;
      end else begin
        y[0] <= ya[0]; y[1] <= ya[1];
        if (push) y[n[0]] <= yn;
      end
      n <= n + 2'(push) - 2'(pop);
    end
endmodule
