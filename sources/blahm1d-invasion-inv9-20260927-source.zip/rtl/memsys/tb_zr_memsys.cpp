// Directed-random unit gate for zr_memsys (+ zr_ddr_gateway + HPS DDR3 model). The renderer-level gates never land a
// destination read on a word that is still inside the write coalescer (mutants H1-H3 survive there), and MK4's
// windows carry no host wave-RAM accesses (H4, R3). This bench makes those cases COMMON:
//   * colour writes (cw) walk short runs in a small window of wave RAM 1, so runs merge, close and queue;
//   * colour reads (cr) mostly aim at lanes written a few clocks earlier; front-end reads/writes (fm) hit both wave
//     RAMs (also recently written lanes); texture reads (w0) and scanout bursts (sc) add load; DDR waitrequest backs
//     everything up.
// ORACLE (the memsys contract): a read returns every write ACCEPTED BEFORE the read was accepted and none accepted
// after it. Colour writes never target a lane a read still has outstanding (the pixel pipe's raw_hz guarantee);
// front-end writes MAY (the memsys orders them after older reads), and texture reads share wave-RAM-0 lines with
// front-end writes. Only same-clock pairs to one lane are excluded (order undefined) -- any mismatch is a defect. Shadow memory is updated at write acceptance; a read's expected value is taken
// at its acceptance and compared when its in-order response arrives. At the end the DDR image must equal the shadow.
// usage: tb_zr_memsys [cycles] [ddr-latency] [ddr-waitrequest%] [seed]
#include "Vzr_memsys.h"
#include "verilated.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <deque>
#include <map>
#include <algorithm>
typedef uint64_t u64; typedef uint32_t u32; typedef uint16_t u16; typedef uint8_t u8;
static u64 rs = 0x9E3779B97F4A7C15ull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

int main(int argc, char** argv) {
    const bool DROP = getenv("ZR_DDR_DROP") && atoi(getenv("ZR_DDR_DROP")), STRICT = getenv("ZR_DDR_STRICT") && atoi(getenv("ZR_DDR_STRICT")); u64 part_beats = 0;
    long N = argc > 1 ? atol(argv[1]) : 400000; int DLAT = argc > 2 ? atoi(argv[2]) : 20, DWBP = argc > 3 ? atoi(argv[3]) : 50;
    if (argc > 4) rs = strtoull(argv[4], 0, 0) | 1;
    const u64 WR0 = 0x06000000ull, WR1 = 0x06100000ull;
    const size_t S0 = 64 * 1024, S1 = 64 * 1024;               // bytes of each wave RAM exercised
    std::vector<u8> ddr0(S0), ddr1(S1), sh0(S0), sh1(S1);        // DDR model contents, and the shadow (contract) memory
    for (size_t i = 0; i < S0; i++) ddr0[i] = sh0[i] = (u8)rnd();
    for (size_t i = 0; i < S1; i++) ddr1[i] = sh1[i] = (u8)rnd();
    auto dptr = [&](u64 wa) -> u8* {
        if (wa >= WR0 && (wa - WR0) * 8 + 8 <= S0) return &ddr0[(wa - WR0) * 8];
        if (wa >= WR1 && (wa - WR1) * 8 + 8 <= S1) return &ddr1[(wa - WR1) * 8];
        printf("FAIL: DDR address %09llX out of the model\n", (unsigned long long)wa); exit(1);
    };
    Verilated::commandArgs(argc, argv);
    Vzr_memsys* t = new Vzr_memsys;
    struct Beat { u64 due, data; }; std::deque<Beat> rq; bool wb_on = false; u64 wb_addr = 0; unsigned wb_left = 0;
    // expected responses per client, in order; each carries the wave-RAM-1 lanes it locks (byte offsets, even)
    struct Exp { u64 v; std::vector<u32> lanes; };
    std::deque<Exp> exp_fm, exp_w0, exp_sc, exp_cr;
    std::map<u32, int> lock;
    auto locked = [&](u32 off) { auto it = lock.find(off & ~1u); return it != lock.end() && it->second > 0; };
    auto release = [&](const Exp& e) { for (u32 l : e.lanes) if (--lock[l] == 0) lock.erase(l); };
    u64 clocks = 0, errs = 0, n_cw = 0, n_cr = 0, n_fm = 0, n_w0 = 0, n_sc = 0, n_fmw = 0;
    bool cw_v = false; u32 cw_a = 0, cw_d = 0; u8 cw_m = 0; bool cw_zv = false; u16 cw_z = 0;   // ddr-fullbe: + the pixels' depth lanes (a+4, a+6)
    auto cw_hit = [&](u32 off) { off &= ~1u; for (int l = 0; l < 2; l++) if (cw_m >> l & 1) { if (off == cw_a + 2 * l) return true; if (cw_zv && off == cw_a + 4 + 2 * l) return true; } return false; };
    bool cr_v = false; u32 cr_a = 0; bool w0_v = false; u32 w0_l = 0;
    bool fm_v = false, fm_we = false, fm_r1 = false; u32 fm_b = 0; u8 fm_ln = 0; u64 fm_wd = 0;
    bool sc_v = false; u32 sc_w = 0; u8 sc_n = 0;
    u32 run_off = 0; int run_left = 0;
    std::deque<u32> recent0;                                     // recently touched wave-RAM-0 lines
    std::deque<u32> recent;                                      // recently written wave-RAM-1 lanes (read-after-write bait)
    t->rst = 1; for (int i = 0; i < 4; i++) { t->clk = 0; t->eval(); t->clk = 1; t->eval(); } t->rst = 0;
    auto check = [&](std::deque<Exp>& q, u64 got, u64 mask, const char* who) {
        if (q.empty()) { if (errs++ < 10) printf("ERR %s: response with none outstanding @%llu\n", who, (unsigned long long)clocks); return; }
        if ((got & mask) != (q.front().v & mask) && errs++ < 10)
            printf("ERR %s read @%llu: got %016llX want %016llX\n", who, (unsigned long long)clocks, (unsigned long long)(got & mask), (unsigned long long)(q.front().v & mask));
        release(q.front()); q.pop_front();
    };
    // pending-pair rule: a read and a write to the same lane are never PENDING together, so a same-clock acceptance of
    // both (whose order the contract does not define) cannot happen
    auto pend_w = [&](u32 off) {
        off &= ~1u;
        if (cw_v && cw_hit(off)) return true;
        if (fm_v && fm_we && fm_r1 && off / 8 == fm_b && ((fm_ln >> ((off % 8) / 2)) & 1)) return true;
        return false;
    };
    auto pend_r = [&](u32 off) {
        off &= ~1u;
        if (cr_v && off == cr_a) return true;
        if (fm_v && !fm_we && fm_r1 && off / 8 == fm_b) return true;
        if (sc_v && off / 8 >= sc_w && off / 8 < sc_w + sc_n) return true;
        return false;
    };
    for (long c = 0; ; c++) {
        bool gen = c < N;
        bool busy = cw_v || cr_v || w0_v || fm_v || sc_v || !exp_fm.empty() || !exp_cr.empty() || !exp_w0.empty() || !exp_sc.empty() || !t->idle;
        if (!gen && !busy) break;
        if (c > N + 2000000) { printf("FAIL: no drain (fm %zu cr %zu w0 %zu sc %zu idle %d)\n", exp_fm.size(), exp_cr.size(), exp_w0.size(), exp_sc.size(), t->idle); return 1; }
        // ---- new requests (held until granted) ----
        if (gen && !cw_v && rnd() % 100 < 45) {
            if (run_left == 0) { run_off = (u32)(rnd() % (S1 / 8 - 40)) * 8; run_left = 1 + rnd() % 24; }
            u32 off = run_off; run_off += (rnd() % 4 == 0) ? 0 : 8; run_left--;                 // the same word again, or the next
            // (pend_w here sees only a pending front-end write: a same-clock write-write pair is order-undefined too)
            u8 m = 1 + rnd() % 3; if (locked(off) || pend_r(off) || pend_w(off)) m &= ~1; if (locked(off + 2) || pend_r(off + 2) || pend_w(off + 2)) m &= ~2;
            bool zv = rnd() % 4 != 0;                                                 // depth known (clear, depth-writing pixel) 3 in 4
            for (int l = 0; l < 2; l++) if ((m >> l & 1) && (locked(off + 4 + 2 * l) || pend_r(off + 4 + 2 * l) || pend_w(off + 4 + 2 * l))) zv = false;
            if (m) { cw_v = true; cw_a = off; cw_d = (u32)rnd(); cw_m = m; cw_zv = zv; cw_z = (u16)rnd(); }
        }
        if (gen && !cr_v && rnd() % 100 < 35) {
            u32 off = (!recent.empty() && rnd() % 100 < 70) ? recent[rnd() % recent.size()] : (u32)(rnd() % (S1 / 8)) * 8 + 2 * (rnd() % 2);
            if (!pend_w(off)) { cr_v = true; cr_a = off & ~1u; }
        }
        // wave RAM 0 lines shared by texture reads and front-end accesses (collision bait: 8 K random lines never meet)
        if (gen && !w0_v && rnd() % 100 < 20) {
            u32 l = (!recent0.empty() && rnd() % 2) ? recent0[rnd() % recent0.size()] : (u32)(rnd() % (S0 / 8));
            if (!(fm_v && fm_we && !fm_r1 && fm_b == l)) { w0_v = true; w0_l = l; recent0.push_back(l); if (recent0.size() > 8) recent0.pop_front(); }
        }
        if (gen && !fm_v && rnd() % 100 < 6) {
            fm_v = true; fm_we = rnd() % 3 == 0; fm_r1 = rnd() % 2; fm_b = (u32)(rnd() % ((fm_r1 ? S1 : S0) / 8));
            if (fm_r1 && !recent.empty() && rnd() % 2) fm_b = recent[rnd() % recent.size()] / 8;
            if (!fm_r1 && !recent0.empty() && rnd() % 2) fm_b = recent0[rnd() % recent0.size()];
            if (!fm_r1 && fm_we && w0_v && w0_l == fm_b) fm_v = false;        // same-clock pair: order undefined
            fm_ln = 1 + rnd() % 15; fm_wd = rnd();
            // a front-end write MAY target a lane with an outstanding read (the memsys orders it after OLDER reads);
            // only a same-clock pair with a pending read or colour write is excluded (order undefined)
            if (fm_we && fm_r1) for (int l = 0; l < 4; l++) if ((fm_ln >> l & 1) && (pend_r(fm_b * 8 + 2 * l) || (cw_v && cw_hit(fm_b * 8 + 2 * l)))) fm_ln &= ~(1 << l);
            if (!fm_we && fm_r1) for (int l = 0; l < 4; l++) if (pend_w(fm_b * 8 + 2 * l)) fm_v = false;
            if (fm_we && fm_ln == 0) fm_v = false;
        }
        if (gen && !sc_v && rnd() % 1000 < 8) {
            sc_n = 1 + rnd() % 32; sc_w = (u32)(rnd() % (S1 / 8 - 32)); bool ok = true;
            for (u32 k = 0; k < sc_n; k++) for (int l = 0; l < 4; l++) if (pend_w((sc_w + k) * 8 + 2 * l)) ok = false;
            sc_v = ok;
        }
        t->clk = 0;
        t->cw_valid = cw_v; t->cw_addr = cw_a; t->cw_data = cw_d; t->cw_mask = cw_m; t->cw_z = cw_z; t->cw_zv = cw_zv;
        t->cr_req = cr_v; t->cr_addr = cr_a; t->w0_req = w0_v; t->w0_line = w0_l;
        t->fm_req = fm_v; t->fm_we = fm_we; t->fm_ram = fm_r1; t->fm_blk = fm_b; t->fm_lanes = fm_ln; t->fm_wdata = fm_wd;
        t->sc_req = sc_v; t->sc_word = sc_w; t->sc_beats = sc_n;
        t->av_readdatavalid = 0;
        if (!rq.empty() && rq.front().due <= clocks) { t->av_readdatavalid = 1; t->av_readdata = rq.front().data; rq.pop_front(); }
        t->av_waitrequest = (int)(rnd() % 100) < DWBP;
        t->eval();
        // ---- responses (in order per client) ----
        if (t->fm_rvalid) check(exp_fm, t->fm_rdata, ~0ull, "fm");
        if (t->w0_rvalid) check(exp_w0, t->w0_data, ~0ull, "w0");
        if (t->sc_rvalid) check(exp_sc, t->sc_rdata, ~0ull, "sc");
        if (t->cr_rvalid) check(exp_cr, t->cr_data, 0xffffull, "cr");
        // ---- acceptances: the contract snapshot happens HERE ----
        if (cw_v && t->cw_ready) {
            for (int l = 0; l < 2; l++) if (cw_m >> l & 1) { u16 v = (u16)(cw_d >> (16 * l)); memcpy(&sh1[cw_a + 2 * l], &v, 2); recent.push_back(cw_a + 2 * l); }
            if (cw_zv) for (int l = 0; l < 2; l++) if (cw_m >> l & 1) { memcpy(&sh1[cw_a + 4 + 2 * l], &cw_z, 2); recent.push_back(cw_a + 4 + 2 * l); }
            while (recent.size() > 16) recent.pop_front();
            cw_v = false; n_cw++;
        }
        if (cr_v && t->cr_gnt) { u16 v; memcpy(&v, &sh1[cr_a], 2); exp_cr.push_back({v, {cr_a}}); lock[cr_a]++; cr_v = false; n_cr++; }
        if (w0_v && t->w0_gnt) { u64 v; memcpy(&v, &sh0[w0_l * 8], 8); exp_w0.push_back({v, {}}); w0_v = false; n_w0++; }
        if (fm_v && t->fm_gnt) {
            std::vector<u8>& sh = fm_r1 ? sh1 : sh0;
            if (fm_we) { for (int l = 0; l < 4; l++) if (fm_ln >> l & 1) { u16 v = (u16)(fm_wd >> (16 * l)); memcpy(&sh[fm_b * 8 + 2 * l], &v, 2); } n_fmw++; }
            else {
                u64 v; memcpy(&v, &sh[fm_b * 8], 8); Exp e{v, {}};
                if (fm_r1) for (int l = 0; l < 4; l++) { e.lanes.push_back(fm_b * 8 + 2 * l); lock[fm_b * 8 + 2 * l]++; }
                exp_fm.push_back(e);
            }
            fm_v = false; n_fm++;
        }
        if (sc_v && t->sc_gnt) {
            for (int k = 0; k < sc_n; k++) {
                u64 v; memcpy(&v, &sh1[(sc_w + k) * 8], 8); Exp e{v, {}};
                for (int l = 0; l < 4; l++) { e.lanes.push_back((sc_w + k) * 8 + 2 * l); lock[(sc_w + k) * 8 + 2 * l]++; }
                exp_sc.push_back(e);
            }
            sc_v = false; n_sc++;
        }
        // ---- DDR accept ----
        if (!t->av_waitrequest) {
            if (t->av_read) {
                u64 due = std::max<u64>(clocks + (u64)DLAT, rq.empty() ? 0 : rq.back().due + 1);
                for (unsigned k = 0; k < t->av_burstcount; k++) { u64 d; memcpy(&d, dptr(t->av_address + k), 8); rq.push_back({due + k, d}); }
            }
            if (t->av_write) {
                if (!wb_on) { wb_on = true; wb_addr = t->av_address; wb_left = t->av_burstcount; }
                u8* p = dptr(wb_addr); unsigned be = t->av_byteenable & 0xff; if (be != 0xff) part_beats++;   // ddr-fullbe: ZR_DDR_DROP drops BE != FF beats
                if (!(DROP && be != 0xff)) for (int b = 0; b < 8; b++) if (be >> b & 1) p[b] = (u8)(t->av_writedata >> (8 * b));
                wb_addr++; if (--wb_left == 0) wb_on = false;
            }
        }
        if (t->fault) { printf("FAIL: gateway fault\n"); return 1; }
        t->eval(); t->clk = 1; t->eval(); clocks++;
    }
    // the final DDR image must equal the shadow (every accepted write landed, nothing else changed)
    u64 img = 0; for (size_t i = 0; i < S1; i++) if (ddr1[i] != sh1[i]) img++; for (size_t i = 0; i < S0; i++) if (ddr0[i] != sh0[i]) img++;
    printf("MEMSYS-UNIT cycles %llu: cw %llu cr %llu w0 %llu fm %llu (writes %llu) sc bursts %llu; hazard flushes %u wait clocks %u runs %u beats %u; image bytes differing %llu\n",
           (unsigned long long)clocks, (unsigned long long)n_cw, (unsigned long long)n_cr, (unsigned long long)n_w0, (unsigned long long)n_fm,
           (unsigned long long)n_fmw, (unsigned long long)n_sc, t->st_flush_hz, t->st_wait_hz, t->st_wbursts, t->st_wbeats, (unsigned long long)img);
    printf("DDRW-UNIT write beats with BE != FF: %llu (DROP %d STRICT %d)\n", (unsigned long long)part_beats, (int)DROP, (int)STRICT);
    bool pass = errs == 0 && img == 0 && !(STRICT && part_beats != 0);
    printf("%s: %llu read errors (DDR latency %d, waitrequest %d%%)\n", pass ? "PASS" : "FAIL", (unsigned long long)errs, DLAT, DWBP);
    delete t; return pass ? 0 : 1;
}
