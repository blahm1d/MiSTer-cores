#!/bin/bash
# pixel v10 + memsys + DDR model on the pixel stimulus (zr1 --pixtap / pix_synth): the memsys ordering-hazard bench.
# usage: wsl -d Ubuntu -- bash run_zr_pmsys.sh <evidence> <pix.bin> [frames] [ddr-lat] [ddr-waitrequest%]   ZPM_MUT mutates zr_memsys.sv
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl
B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-pmsys-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC="$S/memsys/zr_memsys.sv"
if [ -n "${ZPM_MUT:-}" ]; then sed "$ZPM_MUT" "$SRC" > zr_memsys.sv; cmp -s zr_memsys.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zr_memsys.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zr_pmsys -DZR_CENSUS -DZR_RDW_HOSTILE -Wno-fatal -Wno-lint -Wno-style -LDFLAGS -lz \
  "$S/fp32/fp32_pkg.sv" "$S/setup/zr_sdp.sv" "$S/render/zr_fifo.sv" "$S/render/zr_rfifo.sv" "$S/pixel/zr_pixel10.sv" \
  "$S/memsys/zr_ddr_gateway.sv" "$SRC" "$S/memsys/zr_pmsys.sv" "$S/memsys/tb_zr_pmsys.cpp" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
