// zr_pmsys.sv -- pixel pipe v10 + memsys (+ DDR gateway): the bench that drives the memsys ordering hazards directly.
// The renderer gate's real windows never put a destination read on a word still inside the write coalescer (mutants
// H1-H3 survive there); the synthetic pixel stimulus (zeus1/golden/pix_synth.cpp: 2,125 same-pixel repeats, every
// blend mode) does. Front end and scanout ports are tied off.
module zr_pmsys #(parameter logic [28:0] WR0_BASE = 29'h0600_0000, parameter logic [28:0] WR1_BASE = 29'h0610_0000) (
  input  logic        clk, rst,
  input  logic        ext_valid, output logic ext_ready,
  input  logic signed [31:0] scan, input logic signed [15:0] startx, stopx,
  input  logic [31:0] p_start [4], p_dpdx [4],
  input  logic [31:0] o_ctrl, o_alpha, o_blend,
  input  logic [15:0] o_solid, o_trans, o_texw, o_voff, input logic signed [15:0] o_zoff,
  input  logic        o_dtest, o_dwrite, input logic [2:0] o_texfmt,
  input  logic [31:0] o_texbase, o_palbase, rb_base,
  input  logic        clr_valid, output logic clr_ready,
  input  logic [16:0] dbg_daddr, output logic [15:0] dbg_ddata,
  output logic        idle, fault,
  output logic        av_read, av_write, output logic [28:0] av_address, output logic [7:0] av_burstcount,
  output logic [63:0] av_writedata, output logic [7:0] av_byteenable,
  input  logic        av_waitrequest, av_readdatavalid, input logic [63:0] av_readdata,
  output logic [31:0] st_miss_lines, st_pal_loads, st_stall_clocks, st_pixels, st_pf_lines,
  output logic [31:0] st_mem [4]
);
  logic w0_req, w0_gnt, w0_rvalid; logic [20:0] w0_line; logic [63:0] w0_data;
  logic cw_valid, cw_ready; logic [31:0] cw_addr, cw_data; logic [1:0] cw_mask; logic [15:0] cw_z; logic cw_zv;
  logic cr_req, cr_gnt, cr_rvalid; logic [31:0] cr_addr; logic [15:0] cr_data;
  logic p_idle, m_idle, fm_gnt, fm_rvalid, sc_gnt, sc_rvalid, sc_rlast; logic [63:0] fm_rdata, sc_rdata;
  zr_pixel10 u_p (.clk, .rst, .ext_valid, .ext_ready, .scan, .startx, .stopx, .p_start, .p_dpdx, .o_ctrl, .o_alpha,
    .o_blend, .o_solid, .o_trans, .o_texw, .o_voff, .o_zoff, .o_dtest, .o_dwrite, .o_texfmt, .o_texbase, .o_palbase,
    .rb_base, .clr_valid, .clr_ready, .clr_rect(1'b0), .clr_color(16'd0), .clr_x0(9'd0), .clr_x1(9'd0), .clr_y0(9'd0), .clr_y1(9'd0), .clr_done(),
    .w0_req, .w0_line, .w0_gnt, .w0_rvalid, .w0_data, .cw_valid, .cw_ready, .cw_addr,
    .cw_data, .cw_mask, .cw_z, .cw_zv, .cr_req, .cr_addr, .cr_gnt, .cr_rvalid, .cr_data, .dbg_daddr, .dbg_ddata, .idle(p_idle),
    .st_miss_lines, .st_pal_loads, .st_stall_clocks, .st_pixels, .st_pf_lines);
  zr_memsys #(.WR0_BASE(WR0_BASE), .WR1_BASE(WR1_BASE)) u_m (.clk, .rst,
    .fm_req(1'b0), .fm_we(1'b0), .fm_ram(1'b0), .fm_blk('0), .fm_lanes('0), .fm_wdata('0), .fm_gnt, .fm_rvalid, .fm_rdata,
    .w0_req, .w0_line, .w0_gnt, .w0_rvalid, .w0_data, .cw_valid, .cw_ready, .cw_addr, .cw_data, .cw_mask, .cw_z, .cw_zv,
    .cr_req, .cr_addr, .cr_gnt, .cr_rvalid, .cr_data,
    .sc_req(1'b0), .sc_word('0), .sc_beats('0), .sc_gnt, .sc_rvalid, .sc_rlast, .sc_rdata,
    .av_read, .av_write, .av_address, .av_burstcount, .av_writedata, .av_byteenable, .av_waitrequest, .av_readdatavalid,
    .av_readdata, .idle(m_idle), .fault,
    .st_wbursts(st_mem[0]), .st_wbeats(st_mem[1]), .st_flush_hz(st_mem[2]), .st_wait_hz(st_mem[3]));
  assign idle = p_idle && m_idle;
endmodule
