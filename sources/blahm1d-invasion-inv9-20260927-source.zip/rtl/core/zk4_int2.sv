// zk4_int2.sv -- Zeus 1 INT2 source for Invasion builds (instantiated under `ZK4_GAME_INVASION in zk4_core; MK4 keeps the
// line low: it never sets reg 0x80 bit 25, ARCHITECTURE-MK4.md sec. 3, and the MK4 text is unchanged).
// MAME 0.289 midzeus_v.cpp:
//   zeus_w (:420-431)              32-bit mode = zeusbase[0x80] bit 17 (the value BEFORE this write)
//   zeus_register32_w (:534-557)   zeusbase[off & ~1] = data (even an odd offset writes the whole word); update on even offsets
//   zeus_register16_w (:510-531)   odd offset -> high half, even -> low half; update on even offsets only
//   zeus_register_update 0x80 (:639-647): bit 25 set -> set_input_line(2, ASSERT) ("FIFO empty" IRQ, "invasn needs this")
// FIFO register writes (commands 0x17 / 0x18, model 0x19) mask the register index with 0x7f (:774, :784, v:1027), so 0x80
// is reachable only by a CPU write to 0x880080 / 0x880081 -- which is all this block watches.
// The C32 runs Invasion in edge mode (ST.INTCONFIG = 1, invasion/MEASURE-20260925.md sec. 4): every ASSERT call sets IF
// bit 2 (tms320c3x.cpp:942-956) and the CLEAR calls do nothing, so int2 is a one-clock EVENT per update with bit 25 set.
// Interface: wr = the CPU's Zeus write completing this clock (ext_valid && ext_ready), off = its word offset.
module zk4_int2 (
  input  logic        clk, rst,
  input  logic        wr, input logic [9:0] off, input logic [31:0] wdata,
  output logic        int2,                                      // one-clock INT2 ASSERT event (the clock after the write)
  output logic [31:0] reg80                                      // MAME's zeusbase[0x80] (observability / bench seed)
);
  always_ff @(posedge clk)
    if (rst) begin reg80 <= 32'd0; int2 <= 1'b0; end
    else begin : upd
      logic [31:0] v;
      v = reg80;
      int2 <= 1'b0;
      if (wr && off[9:1] == 9'h040) begin
        if (reg80[17])  v = wdata;                                            // 32-bit mode
        else if (off[0]) v = {wdata[15:0], reg80[15:0]};                      // 16-bit mode, odd: high half
        else             v = {reg80[31:16], wdata[15:0]};                     // 16-bit mode, even: low half
        reg80 <= v;
        if (!off[0] && v[25]) int2 <= 1'b1;                                   // update (even offset) with bit 25 -> ASSERT
      end
    end
endmodule
