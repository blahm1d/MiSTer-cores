// zk4_core.sv -- the MK4 (Midway Zeus 1) core, fabric side, below the MiSTer wrapper:
//   CPU      c31_core (zeus/core/rtl/cpu, MK4-gated Z1/Z2) -- FREE-RUNNING on clk: no guest pacer. MK4 paces itself on
//            the beam (70 % of its instructions poll 0xF2 / 0xF4, zeus1/tools/cpu_work_census.py), its only interrupt
//            is INT0 at vblank (Z2 golden: 20/20 takes on line 0), and its timer reads measure real time on the board.
//   tier     zk4_memory_fp (the Cruis'n P3 tier forked to the MK4 map, zeus1/rtl/tier): main RAM / fast RAM / ROM on
//            the SDRAM word port, C32 internal RAM on chip; everything else on its ext port, decoded here:
//   0x808000-0x80807F  zk4_c32_ctl   timers + control page (midzeus.cpp tms320c32_control_r / _w)
//   0x880000-0x8803FF  Zeus 1        writes -> zr_rsys (front end), reads -> zr_host1 (zeus_r)
//   0x8D0000-0x9FFFFF  zk4_board_io  disk_asic_jr, I/O ASIC (+ PIC2), watchdog, CMOS, CMOS protect, unmapped
//   anything else      unmapped: reads 0xFFFFFFFF (zeus_map unmap_value_high, midzeus.cpp:828), writes dropped
//   video    zr_scanout (400 x 256 RGB555, 529 x 278 at clk / 6 = MAME set_raw) on the memsys scanout port; its
//            INT0 = zk4_vsync (oracle2: reg 0xC8 line, MAME d1e9f7db #16178; 0.289 fired at vblank_begin).
//   renderer zr_rsys (front end + setup + pixel pipe + memsys + DDR gateway) -> the HPS DDR3 Avalon port.
//   sound    the DCS2 ports of the I/O ASIC; DCS_STUB = 1 wires the calibrated stand-in (zk4_dcs_stub), else they are
//            exported for the ARM transport / a fabric DCS2.
// Boot: MAME machine_reset copies maindata[0..0x3FFFF] to main RAM and shifts word 0 left (midzeus.cpp:236-241); the
// loader does that into SDRAM, and boot_pc = RAM[0] after the shift (tms320c3x device_reset PC = RMEM(0)).
module zk4_core #(
  parameter int  NUM_MAIN_PAGES = 64, NUM_ROM_PAGES = 16,
  parameter bit  DCS_STUB = 1'b1,
  parameter logic [7:0] PIC_RAND12 = 8'hF2, PIC_RAND13 = 8'hBE,   // MAME's rand() bytes of the captured cold boot
  parameter logic [28:0] WR0_BASE = 29'h0600_0000, WR1_BASE = 29'h0610_0000,
  parameter int  CPU_LOOKAHEAD = 1, CPU_FUSE = 1, CPU_BTB = 1, CPU_LDSKIP = 1, CPU_EARLY_EA = 1, // c31 speed stages
  parameter int  PIC_UPPER = 461, PIC_YEAR = 1997,               // I/O ASIC PIC serial (MK4: set_upper(461), GAME 1997)
  parameter bit  IOASIC_SHUFFLE_DEFAULT = 1'b1,                   // MK4: set_shuffle_default(1) (midzeus.cpp:1417)
  parameter int  GUN_FIRE_EARLY = 0,                             // Invasion only: zk4_gun comparator calibration
  parameter int  CQ_AW = 12                                      // CPU command queue: 4,096 words (peak measured 3,311, attract;
                                                                  // 0 CPU refusals on hvpoly / hvmodel / attract, paced L12)
) (
  input  logic        clk, rst,
  input  logic [23:0] boot_pc,
  input  logic [15:0] in_port [4],                               // DIPS, SYSTEM, IN1, IN2 (active-low, MAME's ports)
  input  logic [7:0]  rtc [7],                                   // BCD sec, min, hour, weekday+1, mday, month+1, year-1994
`ifdef ZK4_GAME_INVASION
  // Invasion: MAME ports GUNX1/GUNY1/GUNX2/GUNY2 (0..0xFF; 0 / 0xFF = off-screen) and TRIGGER (bit p = player p, active high)
  input  logic [7:0]  gun_xin [2], input logic [7:0] gun_yin [2], input logic [1:0] gun_trigger,
`endif
  // SDRAM word port (C31 word addresses; the wrapper maps them to the chip)
  output logic        sd_req, sd_burst, sd_we, output logic [23:0] sd_addr, output logic [31:0] sd_wdata,
  input  logic        sd_ack, input logic [31:0] sd_rdata,
  // HPS DDR3 (renderer + scanout)
  output logic        av_read, av_write, output logic [28:0] av_address, output logic [7:0] av_burstcount,
  output logic [63:0] av_writedata, output logic [7:0] av_byteenable,
  input  logic        av_waitrequest, av_readdatavalid, input logic [63:0] av_readdata,
  // video
  output logic        ce_pix, hs, vs, hblank, vblank, output logic [7:0] r, g, b,
  // DCS2 ports (used when DCS_STUB = 0)
  input  logic [15:0] dcs_control_in, dcs_data_in, dcs_data2_in, input logic dcs_input_empty_in, dcs_output_full_in,
  output logic        dcs_data_w, output logic [15:0] dcs_wdata, output logic dcs_ack_w, dcs_data_r,
  output logic        dcs_reset_w, dcs_reset_level,
  // status
  output logic [23:0] cpu_pc, output logic [7:0] cpu_fault, output logic render_fault, render_unsupported,
  output logic [31:0] scan_skip, scan_late,
  // cabinet diagnostics (status screen + DDR3 status mirror): 0 instructions retired, 1 INT0 frames, 2 Zeus writes,
  // 3 display flips (0xCC writes), 4 FIFO command words (0xE0 writes), 5 DDR write beats (pixels / clears landing),
  // 6 command-queue peak, 7 command-queue full clocks, 8 PIC reads,
  // 9 {DCS flags, last sound command}, 10 DCS reply reads, 11 CPU bus-wait clocks, 12 ext-wait clocks (devices + Zeus),
  // 13 scan skips, 14 scan late, 15 {cpu_fault, 22 zero, render_unsupported, render_fault}
  // MiSTer NVRAM host port on the CMOS (zk4_board_io / zk4_cmos); not reset-gated
  input  logic        nv_we, input logic [13:0] nv_row, input logic [15:0] nv_d, output logic [15:0] nv_q,
  output logic [31:0] diag [16]
);
  // ================= CPU =================
  logic        c_read_ahead; logic [23:0] c_read_ahead_addr;
  logic        c_bus_valid, c_bus_write, c_bus_ready; logic [2:0] c_bus_kind; logic [23:0] c_bus_addr;
  logic [31:0] c_bus_wdata, c_bus_rdata;
  logic        c_f_valid, c_f_accept, c_f_rsp_valid; logic [23:0] c_f_addr; logic [31:0] c_f_rdata;
  logic        irq_int0, c_retire;
`ifdef ZK4_GAME_INVASION
  logic        gun_irq3, z_int2;                                 // Invasion: IRQ3 (zk4_gun) and INT2 (zk4_int2) ASSERT events
  logic [31:0] c_retire_cyc;                                     // guest (MAME H1) cycles of each retired instruction
  logic        g_vact; logic [9:0] g_vh; logic [8:0] g_vv;       // zk4_gun virtual beam (IRQ3 handler hpos / vpos)
`endif
  logic [31:0] z_cq_max, z_cq_full;
  logic        rst_q; always_ff @(posedge clk) rst_q <= rst;
  logic        boot_load; assign boot_load = rst_q && !rst;      // first clock out of reset: PC = RMEM(0)
`ifdef ZK4_GAME_INVASION
  localparam int C32_EDGE = 1;     // Invasion runs ST.INTCONFIG = 1 (edge mode): no level re-trigger after a take
`else
  localparam int C32_EDGE = 0;     // MK4: ST.INTCONFIG = 0 (level mode) -- the core as borrowed
`endif
  c31_core #(.LOOKAHEAD(CPU_LOOKAHEAD), .FUSE(CPU_FUSE), .BTB(CPU_BTB), .LDSKIP(CPU_LDSKIP), .EARLY_EA(CPU_EARLY_EA),
             .C32_INTCONFIG(C32_EDGE)) u_cpu (
    .clk, .rst, .ce(1'b1),
    .read_ahead_valid(c_read_ahead), .read_ahead_addr(c_read_ahead_addr),
    .bus_valid(c_bus_valid), .bus_kind(c_bus_kind), .bus_write(c_bus_write), .bus_addr(c_bus_addr),
    .bus_wdata(c_bus_wdata), .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata),
`ifdef ZK4_GAME_INVASION
    .retire(c_retire), .retire_pc(), .retire_cyc(c_retire_cyc), .retire_fault(), .guest_step(), .at_sample(), .sample_now(), .sample_cyc(),
`else
    .retire(c_retire), .retire_pc(), .retire_cyc(), .retire_fault(), .guest_step(), .at_sample(), .sample_now(), .sample_cyc(),
`endif
    .fuse_allow(1'b1),                                            // no guest-time model to protect: fusion always allowed
    .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
`ifdef ZK4_GAME_INVASION
    .irq_level({7'd0, gun_irq3, z_int2, 1'b0, irq_int0}), .fault_code(cpu_fault),
`else
    .irq_level({10'd0, irq_int0}), .fault_code(cpu_fault),
`endif
    .load_en(boot_load), .load_pc(boot_pc), .load_state(1152'd0),
    .snap_pc(cpu_pc), .snap_state());

  // ================= memory tier (MK4 map) =================
  logic        ext_valid, ext_write, ext_ready; logic [23:0] ext_addr; logic [31:0] ext_wdata, ext_rdata;
  zk4_memory_fp #(.READ_OVERLAP(0), .NUM_MAIN_PAGES(NUM_MAIN_PAGES), .NUM_ROM_PAGES(NUM_ROM_PAGES)) u_mem (
    .clk, .ce(1'b1), .rst,
    .read_ahead_valid(c_read_ahead), .read_ahead_addr(c_read_ahead_addr),
    .bus_valid(c_bus_valid), .bus_write(c_bus_write), .bus_fetch(c_bus_kind == 3'd0),
    .bus_addr(c_bus_addr), .bus_wdata(c_bus_wdata), .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata), .guest_pause(),
    .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
    .sd_req, .sd_burst, .sd_we, .sd_addr, .sd_wdata, .sd_ack, .sd_rdata,
    .ext_valid, .ext_write, .ext_addr, .ext_wdata, .ext_ready, .ext_rdata,
    .nvram_protected(),
    .stat_main_hits(), .stat_main_misses(), .stat_rom_hits(), .stat_rom_misses(), .stat_pause_clocks(),
    .stat_fetch_accepts(), .stat_fetch_rejects(), .stat_fetch_stale());

  // ================= ext decode =================
  logic is_ctl, is_zeus, is_board;
  assign is_ctl   = ext_addr[23:7] == 17'(24'h808000 >> 7);
  assign is_zeus  = ext_addr[23:10] == 14'(24'h880000 >> 10);
`ifdef ZK4_GAME_INVASION
  logic is_gun; assign is_gun = ext_addr == 24'h9C0000;         // invasnab_map (midzeus.cpp:843-847): the gun word
  assign is_board = ext_addr >= 24'h8D0000 && ext_addr <= 24'h9FFFFF && !is_gun;
`else
  assign is_board = ext_addr >= 24'h8D0000 && ext_addr <= 24'h9FFFFF;
`endif
  // pulse-request devices (one-clk req, rvalid one or two clks later): issue once per held ext request
  logic busy; logic issue;
  assign issue = ext_valid && !busy;
  // a Zeus register read (anything but the beam specials 0xF0-0xF5) must see every earlier write: it is issued only once
  // the command queue has drained; beam reads never wait (MK4 polls them). A held read leaves ext_ready low.
  logic cq_empty, z_rd_ok; logic zrd_hold;
  // ddr-fullbe: ... and only while the front end is idle with its register-file port free (z_rd_ok = zr_rsys rd_ok):
  // zr_host1 samples the front end's register file, whose read port the front end drives while it works (r8 cabinet F9).
  assign zrd_hold = is_zeus && !ext_write && !(ext_addr[9:1] >= 9'h078 && ext_addr[9:1] <= 9'h07a) && !z_rd_ok;
  logic issue_ok; assign issue_ok = issue && !zrd_hold;
  always_ff @(posedge clk) if (rst) busy <= 1'b0; else if (ext_ready) busy <= 1'b0; else if (issue_ok && !ext_write) busy <= 1'b1;

  // CPU control page (timers)
  logic ctl_rv; logic [31:0] ctl_q;
  zk4_c32_ctl u_ctl (.clk, .rst, .req(issue && is_ctl), .we(ext_write), .off(ext_addr[6:0]), .wdata(ext_wdata),
    .rvalid(ctl_rv), .rdata(ctl_q));
  // board devices
  logic bd_rv; logic [31:0] bd_q;
  logic [15:0] dcs_control, dcs_data, dcs_data2; logic dcs_input_empty, dcs_output_full;
  zk4_board_io #(.RAND12(PIC_RAND12), .RAND13(PIC_RAND13), .PIC_UPPER(PIC_UPPER), .PIC_YEAR(PIC_YEAR),
    .SHUFFLE_DEFAULT(IOASIC_SHUFFLE_DEFAULT)) u_board (.clk, .rst, .req(issue && is_board), .we(ext_write),
    .addr(ext_addr), .wdata(ext_wdata), .rvalid(bd_rv), .rdata(bd_q), .in_port, .rtc,
    .dcs_control, .dcs_data, .dcs_data2, .dcs_input_empty, .dcs_output_full, .dcs_data_w, .dcs_wdata, .dcs_ack_w,
    .dcs_data_r, .dcs_reset_w, .dcs_reset_level, .ioasic_irq(), .h_we(nv_we), .h_row(nv_row), .h_d(nv_d), .h_q(nv_q));
  generate if (DCS_STUB) begin : g_stub
    zk4_dcs_stub u_dcs (.clk, .rst, .data_w(dcs_data_w), .wdata(dcs_wdata), .ack_w(dcs_ack_w), .data_r(dcs_data_r),
      .reset_w(dcs_reset_w), .reset_level(dcs_reset_level), .control(dcs_control), .data(dcs_data), .data2(dcs_data2),
      .input_empty(dcs_input_empty), .output_full(dcs_output_full));
  end else begin : g_ext
    assign dcs_control = dcs_control_in; assign dcs_data = dcs_data_in; assign dcs_data2 = dcs_data2_in;
    assign dcs_input_empty = dcs_input_empty_in; assign dcs_output_full = dcs_output_full_in;
  end endgenerate

  // Zeus 1: writes to the front end (valid / ready), reads through zr_host1
  logic        z_wr_ready, h_rd_valid; logic [31:0] h_rd_data; logic [9:0] h_rf_off; logic [31:0] z_rd_data;
  logic [31:0] reg_cc, reg_b6; logic mode32;
  logic [31:0] disp_cc;                                           // r12: scanout base = reg_cc once everything before it is drawn
  logic        sc_req, sc_gnt, sc_rvalid, sc_rlast; logic [19:0] sc_word; logic [5:0] sc_beats; logic [63:0] sc_rdata;
  logic        frame_start; logic [9:0] beam_h; logic [8:0] beam_v; logic [14:0] rgb555;
  zr_rsys #(.WR0_BASE(WR0_BASE), .WR1_BASE(WR1_BASE), .CQ_AW(CQ_AW)) u_zeus (.clk, .rst, .cq_empty, .rd_ok(z_rd_ok), .st_cq_max(z_cq_max), .st_cq_full(z_cq_full),
    .wr_valid(ext_valid && is_zeus && ext_write), .wr_ready(z_wr_ready), .wr_off(ext_addr[9:0]), .wr_data(ext_wdata),
    .rd_off(h_rf_off), .rd_data(z_rd_data), .reg_cc, .reg_b6, .mode32,
    .rb_init(32'd0), .dbg_daddr('0), .dbg_ddata(), .rb_now(), .idle(), .unsupported(render_unsupported), .fault(render_fault),
    .st_clears(), .st_clr_done(), .st_dbq(), .st_dbq_empty(), .st_dbq_bad(), .pipe_idle(), .disp_cc, .disp_ovf(),   // r12
    .sc_req, .sc_word, .sc_beats, .sc_gnt, .sc_rvalid, .sc_rlast, .sc_rdata,
    .av_read, .av_write, .av_address, .av_burstcount, .av_writedata, .av_byteenable,
    .av_waitrequest, .av_readdatavalid, .av_readdata,
    .st_quads(), .st_polys(), .st_rejected(), .st_extents(),     // census-gated (CEN): 0 in synthesis
    .st_clk(), .st_wsetup(), .st_wdrain(), .st_extstall(), .st_pixstarve(), .st_frontwait());
  zr_host1 u_host (.clk, .rst, .rd_req(issue_ok && is_zeus && !ext_write), .rd_off(ext_addr[9:0]),
`ifdef ZK4_GAME_INVASION
    // Invasion: while the gun's virtual beam is active (IRQ3 handler), hpos / vpos reads see it (zk4_gun VBEAM)
    .rd_valid(h_rd_valid), .rd_data(h_rd_data), .rf_off(h_rf_off), .rf_data(z_rd_data), .reg_b6, .mode32,
    .beam_h(g_vact ? g_vh : beam_h), .beam_v(g_vact ? g_vv : beam_v));
`else
    .rd_valid(h_rd_valid), .rd_data(h_rd_data), .rf_off(h_rf_off), .rf_data(z_rd_data), .reg_b6, .mode32, .beam_h, .beam_v);
`endif
  zr_scanout u_scan (.clk, .rst, .disp_cc, .sc_req, .sc_word, .sc_beats, .sc_gnt, .sc_rvalid, .sc_rlast, .sc_rdata,
    .ce_pix, .hs, .vs, .hblank, .vblank, .rgb555, .r, .g, .b, .frame_start, .beam_h, .beam_v,
    .st_skip(scan_skip), .st_late(scan_late));

  // INT0 = vertical sync (oracle2, MAME d1e9f7db #16178): a pulse at (hpos 0, the line in reg 0xC8's high half) -- MK4 259
  // -- else vblank start (0.289: always vblank start, line 256). 2 clks: the core's edge accumulator runs every clock.
  logic vs_evt, vs_q;
  zk4_vsync u_vsync (.clk, .rst, .wr(ext_valid && ext_ready && is_zeus && ext_write), .off(ext_addr[9:0]), .wdata(ext_wdata),
    .beam_v, .evt(vs_evt), .tgt(), .c8hi());
  always_ff @(posedge clk) vs_q <= vs_evt;
  assign irq_int0 = vs_evt || vs_q;
`ifdef ZK4_GAME_INVASION
  // Invasion: the lightgun at 0x9C0000 (beam timers on the scanout counters) and INT2 from Zeus reg 0x80 bit 25
  logic gun_rv; logic [31:0] gun_q;
  zk4_gun #(.FIRE_EARLY(GUN_FIRE_EARLY)) u_gun (.clk, .rst, .req(issue && is_gun), .we(ext_write), .wdata(ext_wdata),
    .rvalid(gun_rv), .rdata(gun_q), .rd_now(), .beam_h, .beam_v, .gun_xin, .gun_yin, .trigger(gun_trigger), .irq3(gun_irq3),
    .retire(c_retire), .retire_cyc(c_retire_cyc), .vactive(g_vact), .vbeam_h(g_vh), .vbeam_v(g_vv),
    .gun_x(), .gun_y(), .armed(), .irq_state(), .control());
  zk4_int2 u_int2 (.clk, .rst, .wr(ext_valid && ext_ready && is_zeus && ext_write), .off(ext_addr[9:0]), .wdata(ext_wdata),
    .int2(z_int2), .reg80());
`endif

  // ================= ext response mux =================
  logic unmapped; assign unmapped = !(is_ctl || is_zeus || is_board);
  always_comb begin
    ext_ready = 1'b0; ext_rdata = 32'hFFFFFFFF;
    if (is_zeus) begin
      if (ext_write) ext_ready = z_wr_ready;
      else begin ext_ready = h_rd_valid; ext_rdata = h_rd_data; end
    end else if (is_ctl) begin
      if (ext_write) ext_ready = ext_valid;
      else begin ext_ready = ctl_rv; ext_rdata = ctl_q; end
    end else if (is_board) begin
      if (ext_write) ext_ready = ext_valid;
      else begin ext_ready = bd_rv; ext_rdata = bd_q; end
`ifdef ZK4_GAME_INVASION
    end else if (is_gun) begin
      if (ext_write) ext_ready = ext_valid;
      else begin ext_ready = gun_rv; ext_rdata = gun_q; end
`endif
    end else ext_ready = ext_valid;                               // unmapped: reads 0xFFFFFFFF, writes dropped
  end

  // ================= cabinet diagnostics (always counted: none of these depend on the census CEN) =================
  logic ext_acc; assign ext_acc = ext_valid && ext_ready;         // an ext access completing this clock
  logic [31:0] n_instr, n_int0, n_zw, n_flip, n_fifo, n_ddrw, n_pic, n_dcsr, n_buswait, n_extwait;
  logic [15:0] dcs_last; logic [15:0] dcs_flags;
  always_ff @(posedge clk)
    if (rst) begin
      n_instr <= '0; n_int0 <= '0; n_zw <= '0; n_flip <= '0; n_fifo <= '0; n_ddrw <= '0; n_pic <= '0; n_dcsr <= '0;
      n_buswait <= '0; n_extwait <= '0; dcs_last <= '0; dcs_flags <= '0;
    end else begin
      if (c_retire) n_instr <= n_instr + 1'b1;
      if (vs_evt) n_int0 <= n_int0 + 1'b1;                  // oracle2: INT0 events (vsync line)
      if (ext_acc && is_zeus && ext_write) begin
        n_zw <= n_zw + 1'b1;
        if (ext_addr[9:1] == 9'h066) n_flip <= n_flip + 1'b1;     // 0xCC / 0xCD: display base (screen_update)
        if (ext_addr[9:1] == 9'h070) n_fifo <= n_fifo + 1'b1;     // 0xE0 / 0xE1: the command FIFO word
      end
      if (av_write && !av_waitrequest) n_ddrw <= n_ddrw + 1'b1;
      if (ext_acc && is_board && !ext_write && ext_addr == 24'h99000D) n_pic <= n_pic + 1'b1;
      if (ext_acc && is_board && !ext_write && ext_addr == 24'h99000B) n_dcsr <= n_dcsr + 1'b1;
      if (ext_acc && is_board && ext_write && ext_addr == 24'h990009) dcs_last <= ext_wdata[15:0];
      if (dcs_reset_w) dcs_flags[0] <= 1'b1;                      // the game reset the sound board
      if (dcs_output_full) dcs_flags[1] <= 1'b1;                  // the (stand-in) sound board answered
      if (c_bus_valid && !c_bus_ready) n_buswait <= n_buswait + 1'b1;
      if (ext_valid && !ext_ready) n_extwait <= n_extwait + 1'b1;
    end
  assign diag[0] = n_instr;  assign diag[1] = n_int0;  assign diag[2] = n_zw;     assign diag[3] = n_flip;
  assign diag[4] = n_fifo;   assign diag[5] = n_ddrw;  assign diag[6] = z_cq_max; assign diag[7] = z_cq_full;
  assign diag[8] = n_pic;    assign diag[9] = {dcs_flags, dcs_last};              assign diag[10] = n_dcsr;
  assign diag[11] = n_buswait; assign diag[12] = n_extwait; assign diag[13] = scan_skip; assign diag[14] = scan_late;
  assign diag[15] = {cpu_fault, 22'd0, render_unsupported, render_fault};
endmodule

// ---------------------------------------------------------------------------------------------------------------------
// zk4_vsync.sv -- oracle2: Zeus 1 INT0 (vertical sync) at the line the game programs in register 0xC8's high half.
// MAME master d1e9f7db (#16178, 2026-09-18), midzeus.cpp:
//   time_until_vsync   line = zeusbase[0xc8] >> 16; if (line > visible max_y && line < screen height) time_until_pos(line)
//                      (hpos 0), else time_until_vblank_start()
//   vsync_start        pulse IRQ0 for clocks_to_attotime(2), then rearm_vsync() (re-reads 0xC8)
//   rearm_vsync        on machine_reset, after every fire, and on every register_update of 0xC0..0xCA (even offsets)
// 0.289 fired at vblank start (line 256) always. MK4 programs 0xC8 = 0x010300FF -> line 259 (seed register file, all
// windows); the game tests the line counter for == 256 to choose repaint vs fast clear (midzeus.cpp comment).
// Writes: zeus_w 32-bit mode = reg 0x80 bit 17 BEFORE the write (midzeus_v.cpp:427-430); 16-bit: odd offset -> high half,
// update on even offsets only (:510-557). FIFO register writes mask the index with 0x7f, so 0x80 / 0xC8 change only by a
// CPU write -- all this block watches. ASSUMPTION (flagged): visible max_y = VACT-1 and height = VTOTAL, the constants of
// zr_scanout (MK4's 0xC6 / 0xC8 / 0xCA are constant; a game that reprograms the raster would need them live).
// Output: evt = one clk at (hpos 0, vpos tgt) -- the same clk zr_scanout's frame_start marks for line VACT.
module zk4_vsync #(parameter int VACT = 256, VTOTAL = 278) (
  input  logic       clk, rst,
  input  logic       wr, input logic [9:0] off, input logic [31:0] wdata,   // a CPU Zeus write completing this clock
  input  logic [8:0] beam_v,                                                 // zr_scanout vc
  output logic       evt,
  output logic [8:0] tgt,                                                    // the armed line (observability)
  output logic [15:0] c8hi
);
  logic m32; logic [8:0] v_q;
  function automatic logic [8:0] line_of(input logic [15:0] l);
    return (l > 16'(VACT - 1) && l < 16'(VTOTAL)) ? 9'(l) : 9'(VACT);
  endfunction
  assign evt = !rst && beam_v == tgt && v_q != tgt;
  always_ff @(posedge clk)
    if (rst) begin m32 <= 1'b0; c8hi <= '0; tgt <= 9'(VACT); v_q <= 9'(VACT); end
    else begin : upd
      logic [15:0] c; logic rearm;
      v_q <= beam_v;
      c = c8hi; rearm = evt;                                                 // vsync_start -> rearm_vsync
      if (wr && off[9:1] == 9'h040) begin                                    // reg 0x80: track bit 17 (mode)
        if (m32) m32 <= wdata[17]; else if (off[0]) m32 <= wdata[1];
      end
      if (wr && off[9:1] == 9'h064) begin                                    // reg 0xC8
        if (m32) c = wdata[31:16]; else if (off[0]) c = wdata[15:0];
      end
      if (wr && !off[0] && off[9:1] >= 9'h060 && off[9:1] <= 9'h065) rearm = 1'b1;   // update 0xC0..0xCA
      c8hi <= c;
      if (rearm) tgt <= line_of(c);
    end
endmodule
