// zk4_c32_ctl.sv -- MK4's 0x808000-0x80807F control page as the DRIVER models it (MAME 0.289 midzeus.cpp
// tms320c32_control_r / _w :621-660; the C3x core in MAME has no timer of its own):
//   read 0x24 / 0x34 : timer[which]->elapsed() * 1e7, truncated ("timer is clocked at 100ns", :625-627)
//   write 0x20 / 0x30 with data bit 6 : timer[which] restarted (adjust(never) resets its start time, :652-654)
//   anything else    : a 128-word register file (the share m_tms320c32_control, COMBINE_DATA :646)
// Timers start at machine start (timer_alloc :211-212), i.e. reset here. At 50 MHz, floor(elapsed * 1e7) =
// floor(clocks / 5): a mod-5 prescaler and a 32-bit counter per timer, no divider.
// Bus: one-clk req (we, word offset 0..7F, wdata); rvalid + rdata one clk later.
module zk4_c32_ctl #(parameter int CLK_PER_TICK = 5) (
  input  logic        clk, rst,
  input  logic        req, we, input logic [6:0] off, input logic [31:0] wdata,
  output logic        rvalid, output logic [31:0] rdata
);
  logic [31:0] cnt [2]; logic [$clog2(CLK_PER_TICK)-1:0] pre [2];
  logic [31:0] rf [128];                                          // M10K / MLAB, registered read
  logic [31:0] rf_q; logic is_cnt_q; logic which_q; logic [31:0] cnt_q;
  always_ff @(posedge clk) begin
    if (req && we) rf[off] <= wdata;
    rf_q <= rf[off];
  end
  always_ff @(posedge clk)
    if (rst) begin
      for (int k = 0; k < 2; k++) begin cnt[k] <= '0; pre[k] <= '0; end
      rvalid <= 1'b0;
    end else begin
      for (int k = 0; k < 2; k++) begin
        if (pre[k] == ($clog2(CLK_PER_TICK))'(CLK_PER_TICK - 1)) begin pre[k] <= '0; cnt[k] <= cnt[k] + 1'b1; end
        else pre[k] <= pre[k] + 1'b1;
      end
      if (req && we && (off == 7'h20 || off == 7'h30) && wdata[6]) begin
        cnt[off[4]] <= '0; pre[off[4]] <= '0;
      end
      rvalid <= req && !we;
      is_cnt_q <= off == 7'h24 || off == 7'h34; which_q <= off[4];
      cnt_q <= cnt[off[4]];
    end
  assign rdata = is_cnt_q ? cnt_q : rf_q;
endmodule
