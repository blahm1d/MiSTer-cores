#!/bin/bash
# zr_host1 mutation gate: every mutant in mutants_zr_host1.txt must FAIL run_zr_host1.sh. usage: wsl bash mutate_zr_host1.sh
set -u
D=/mnt/d/deck/fpga/zeus/zeus1/rtl/core; bad=0
while IFS=$'\t' read -r m e; do
  case "$m" in \#*|"") continue;; esac
  out=$(ZH1_MUT="$e" bash $D/run_zr_host1.sh 50000 2>&1); rc=$?
  if echo "$out" | grep -q "DID NOT APPLY\|BUILD FAILED"; then echo "$m NOT APPLIED / BUILD FAILED"; bad=1
  elif [ $rc = 0 ]; then echo "$m SURVIVED"; bad=1
  else echo "$m killed: $(echo "$out" | grep -m1 -E "ERR|FAIL" | cut -c1-100)"; fi
done < $D/mutants_zr_host1.txt
exit $bad
