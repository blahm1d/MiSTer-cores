// zr_host1.sv -- Zeus 1 CPU READ path (zeus_r, MAME 0.289 midzeus_v.cpp:351-410).
//   result = zeusbase[off & ~1], except 0xF0 hpos, 0xF2 vpos, 0xF4 6 | (vblank ? 0x800 : 0), 0xF6 0x9600 | (zeusbase[0xB6]
//   == 0x80040000); then 32-bit mode (zeusbase[0x80] bit 17): odd offset >> 16; 16-bit mode: odd >> 16, even & 0xFFFF.
// The beam is the scanout's raw counters (zr_scanout beam_h / beam_v = MAME screen hpos / vpos; vblank = vpos >= 256).
// Measured MK4 use (tools/zeus_read_census.py): boot reads only 0xF6 (21,493), gameplay only 0xF2 / 0xF4 (221,119);
// the register-file path exists for completeness (front end's raw read port, valid while the front end is idle).
// Interface: rd_req (one clk, CPU read of 0x880000 + rd_off) -> rd_valid + rd_data two clks later (register file 1-clk
// latency + output register). The beam is sampled in the request clk.
module zr_host1 #(parameter int VACT = 256) (
  input  logic        clk, rst,
  input  logic        rd_req, input logic [9:0] rd_off,
  output logic        rd_valid, output logic [31:0] rd_data,
  // front end
  output logic [9:0]  rf_off, input logic [31:0] rf_data,        // raw register file read (1-clk latency)
  input  logic [31:0] reg_b6, input logic mode32,
  // beam
  input  logic [9:0]  beam_h, input logic [8:0] beam_v
);
  logic [9:0] w; assign w = {rd_off[9:1], 1'b0};
  assign rf_off = w;
  logic        q_v, q_odd; logic [9:0] q_w; logic [31:0] q_spec; logic q_is_spec;
  always_ff @(posedge clk)
    if (rst) begin q_v <= 1'b0; rd_valid <= 1'b0; end
    else begin
      // stage 1: capture the request and the beam
      q_v <= rd_req; q_w <= w; q_odd <= rd_off[0];
      q_is_spec <= w == 10'h0f0 || w == 10'h0f2 || w == 10'h0f4 || w == 10'h0f6;
      case (w)
        10'h0f0: q_spec <= 32'(beam_h);
        10'h0f2: q_spec <= 32'(beam_v);
        10'h0f4: q_spec <= 32'h6 | ((beam_v >= 9'(VACT)) ? 32'h800 : 32'h0);
        default: q_spec <= 32'h9600 | ((reg_b6 == 32'h80040000) ? 32'h1 : 32'h0);
      endcase
      // stage 2: the register-file word has arrived; select and apply the 16 / 32-bit rule
      rd_valid <= q_v;
      if (q_v) begin : sel
        logic [31:0] r;
        r = q_is_spec ? q_spec : rf_data;
        if (mode32) rd_data <= q_odd ? r >> 16 : r;
        else        rd_data <= q_odd ? r >> 16 : (r & 32'h0000FFFF);
      end
    end
endmodule
