// SPDX-License-Identifier: BSD-3-Clause
// zc2_top -- the MK4 (Zeus 1) CPU + forked memory tier under test for the zeus/core zc2 bench.
//
// It wires the fabric C31 CPU (c31_core, rtl/cpu, borrowed AS-IS) to the FORKED MK4 memory tier
// (zk4_memory_fp = the gated held-until-ready wrapper over zk4_memory_p3 = c31_page_cache x2 + iram),
// EXACTLY as the donor master core wires them (cruisinusa/bandwidth/gm1/rtl/gm1_board.sv:145-194,
// READ_OVERLAP(0), bus_fetch = bus_kind==0, tier ce tied high, read_ahead gated by the core ce).
//
// The zc2 bench (zeus/core/tb/zc2_main.cpp) drives the SDRAM word port (sd_*) from the Board arrays
// and the tier's external passthrough port (ext_*) with the SAME device/IO/time-map logic the ideal-
// memory bench (zc1_main.cpp) applied to the CPU bus. The CPU data bus and fetch port are now INTERNAL
// (served by the tier); a few monitor copies of the data-bus signals are exposed for the bench's
// fetch/read/write counters and memory trace only.
//
// ce: the bench pauses the CORE (ce=0) for interrupt pulse injection while the TIER keeps running
// (u_mem ce tied to 1, as in gm1). The tier's held-until-ready data port re-heals a paused-clock
// handshake (the core holds bus_valid until bus_ready; with READ_OVERLAP=0 the tier carries no
// speculative saved word), so a paused core cannot consume a lost answer.
`default_nettype none
module zc2_top #(
    parameter integer NUM_MAIN_PAGES = 64,   // MK4 sizing (zeus/core memory tier)
    parameter integer NUM_ROM_PAGES  = 16,
    // c31_core speed stages (Cruis'n speed march); 0 = the earlier, smaller core for that stage
    parameter integer CPU_LOOKAHEAD = 1, CPU_FUSE = 1, CPU_BTB = 1, CPU_LDSKIP = 1, CPU_EARLY_EA = 1
)(
    input  wire         clk,
    input  wire         rst,
    input  wire         ce,                    // CORE clock-enable (the bench pauses the core here)

    // ---- CPU control / observation the bench uses ----
    input  wire [10:0]  irq_level,
    input  wire         fuse_allow,
    input  wire         load_en,
    input  wire [23:0]  load_pc,
    input  wire [32*36-1:0] load_state,

    output wire         retire,
    output wire [23:0]  retire_pc,
    output wire [31:0]  retire_cyc,
    output wire         retire_fault,
    output wire         guest_step,
    output wire         at_sample,
    output wire         sample_now,
    output wire [15:0]  sample_cyc,
    output wire [7:0]   fault_code,
    output wire [23:0]  snap_pc,
    output wire [32*36-1:0] snap_state,

    // ---- SDRAM word port (served by the bench from the Board arrays) ----
    output wire         sd_req,
    output wire         sd_burst,
    output wire         sd_we,
    output wire [23:0]  sd_addr,
    output wire [31:0]  sd_wdata,
    input  wire         sd_ack,
    input  wire [31:0]  sd_rdata,

    // ---- external passthrough (served by the bench: device/IO/CMOS windows) ----
    output wire         ext_valid,
    output wire         ext_write,
    output wire [23:0]  ext_addr,
    output wire [31:0]  ext_wdata,
    input  wire         ext_ready,
    input  wire [31:0]  ext_rdata,

    // ---- data-bus monitors (counters / memory trace only; NOT driven by the bench) ----
    output wire         mon_bus_valid,
    output wire         mon_bus_ready,
    output wire         mon_bus_write,
    output wire [2:0]   mon_bus_kind,
    output wire [23:0]  mon_bus_addr,

    // ---- tier diagnostics ----
    output wire [63:0]  stat_main_hits, stat_main_misses,
    output wire [63:0]  stat_rom_hits,  stat_rom_misses,
    output wire [63:0]  stat_pause_clocks,
    output wire [63:0]  stat_fetch_accepts, stat_fetch_rejects, stat_fetch_stale
);
    // ---- core <-> tier internal wiring (gm1_board.sv:120-157, 180-194) ----
    wire        c_read_ahead;  wire [23:0] c_read_ahead_addr;
    wire        c_bus_valid, c_bus_write;
    wire [2:0]  c_bus_kind;
    wire [23:0] c_bus_addr;
    wire [31:0] c_bus_wdata;
    wire        c_bus_ready;
    wire [31:0] c_bus_rdata;
    wire        c_f_valid, c_f_accept, c_f_rsp_valid;
    wire [23:0] c_f_addr;
    wire [31:0] c_f_rdata;
    wire        guest_pause;

    c31_core #(.LOOKAHEAD(CPU_LOOKAHEAD), .FUSE(CPU_FUSE), .BTB(CPU_BTB), .LDSKIP(CPU_LDSKIP), .EARLY_EA(CPU_EARLY_EA)) u_cpu (
        .clk(clk), .rst(rst), .ce(ce),
        .read_ahead_valid(c_read_ahead), .read_ahead_addr(c_read_ahead_addr),
        .bus_valid(c_bus_valid), .bus_kind(c_bus_kind), .bus_write(c_bus_write),
        .bus_addr(c_bus_addr), .bus_wdata(c_bus_wdata), .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata),
        .retire(retire), .retire_pc(retire_pc), .retire_cyc(retire_cyc), .retire_fault(retire_fault),
        .guest_step(guest_step), .at_sample(at_sample),
        .sample_now(sample_now), .sample_cyc(sample_cyc), .fuse_allow(fuse_allow),
        .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
        .irq_level(irq_level), .fault_code(fault_code),
        .load_en(load_en), .load_pc(load_pc), .load_state(load_state),
        .snap_pc(snap_pc), .snap_state(snap_state)
    );

    // MK4 forked tier. READ_OVERLAP=0 and tier ce=1 exactly as gm1_board.sv:180-181.
    zk4_memory_fp #(.READ_OVERLAP(0), .NUM_MAIN_PAGES(NUM_MAIN_PAGES), .NUM_ROM_PAGES(NUM_ROM_PAGES)) u_mem (
        .clk(clk), .ce(1'b1), .rst(rst),
        .read_ahead_valid(c_read_ahead && ce), .read_ahead_addr(c_read_ahead_addr),
        .bus_valid(c_bus_valid), .bus_write(c_bus_write), .bus_fetch(c_bus_kind == 3'd0),
        .bus_addr(c_bus_addr), .bus_wdata(c_bus_wdata),
        .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata), .guest_pause(guest_pause),
        .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
        .sd_req(sd_req), .sd_burst(sd_burst), .sd_we(sd_we), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sd_ack), .sd_rdata(sd_rdata),
        .ext_valid(ext_valid), .ext_write(ext_write), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
        .ext_ready(ext_ready), .ext_rdata(ext_rdata),
        .nvram_protected(),
        .stat_main_hits(stat_main_hits), .stat_main_misses(stat_main_misses),
        .stat_rom_hits(stat_rom_hits), .stat_rom_misses(stat_rom_misses), .stat_pause_clocks(stat_pause_clocks),
        .stat_fetch_accepts(stat_fetch_accepts), .stat_fetch_rejects(stat_fetch_rejects),
        .stat_fetch_stale(stat_fetch_stale)
    );

    assign mon_bus_valid = c_bus_valid;
    assign mon_bus_ready = c_bus_ready;
    assign mon_bus_write = c_bus_write;
    assign mon_bus_kind  = c_bus_kind;
    assign mon_bus_addr  = c_bus_addr;
endmodule
`default_nettype wire
