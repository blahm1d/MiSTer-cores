#!/bin/bash
# zr_host1 unit gate. usage: wsl bash run_zr_host1.sh [reads] [seed]; ZH1_MUT=sed-expression mutates zr_host1.sv
set -u
S=/mnt/d/deck/fpga/zeus/zeus1/rtl; B="${ZSCRATCH:-/mnt/h/temp/zeus}/zr-host1-$$"; mkdir -p "$B"; cd "$B" || exit 2
SRC="$S/core/zr_host1.sv"
if [ -n "${ZH1_MUT:-}" ]; then sed "$ZH1_MUT" "$SRC" > zr_host1.sv; cmp -s zr_host1.sv "$SRC" && { echo "MUTATION DID NOT APPLY"; exit 3; }; SRC=zr_host1.sv; fi
verilator --cc --exe --build -O3 -j 8 --top-module zr_host1 -Wno-fatal -Wno-lint -Wno-style -CFLAGS -I/mnt/d/deck/fpga/zeus/core/tb \
  "$SRC" "$S/core/tb_zr_host1.cpp" -o tb > build.log 2>&1 || { tail -30 build.log; echo "BUILD FAILED"; exit 2; }
./obj_dir/tb "$@"; rc=$?
cd /; rm -rf "$B"; exit $rc
