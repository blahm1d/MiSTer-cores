// zr_host1 unit gate: the RTL read path vs zeus1_host.h (the Z3-MK4 host model, transcribed from MAME zeus_r /
// register16_w / register32_w / register_update and already bit-exact on MK4's 21,493 boot reads). The bench plays the
// front end: random writes go through the model (16 / 32-bit rules, side effects, both modes), the RTL's register-file
// port is answered from the model's registers, reg_b6 / mode32 from the model. Every read is compared:
//   * non-timing registers and 0xF6: zeus1_host.h read() (skipped only where the model reports an unmodelled state);
//   * 0xF0 / 0xF2 / 0xF4: MAME screen hpos / vpos / vblank for the beam the bench drives (the model gets these from its
//     CPU time map, which this unit bench does not have), then the model's 16 / 32-bit half rule.
// usage: tb_zr_host1 [reads] [seed]
#include "Vzr_host1.h"
#include "verilated.h"
#include "zeus1_host.h"
#include <cstdio>
#include <cstdlib>
typedef uint64_t u64; typedef uint32_t u32;
static u64 rs = 0xD1B54A32D192ED03ull; static u64 rnd() { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

int main(int argc, char** argv) {
    long N = argc > 1 ? atol(argv[1]) : 200000; if (argc > 2) rs = strtoull(argv[2], 0, 0) | 1;
    Verilated::commandArgs(argc, argv);
    Vzr_host1* t = new Vzr_host1; Zeus1Host m;
    // registers the bench writes: a spread incl. 0x80 (mode), 0xB6 (status), 0xCC, and the specials' own words
    const u32 pool[] = {0x00, 0x02, 0x10, 0x3E, 0x7E, 0x80, 0x84, 0xA0, 0xB6, 0xC0, 0xCC, 0xF0, 0xF2, 0xF4, 0xF6, 0x1FE, 0x3FE};
    auto tick = [&]() { t->clk = 0; t->eval(); t->rf_data = m.reg[t->rf_off & 0x3FF]; t->reg_b6 = m.reg[0xB6];
                        t->mode32 = m.mode32(); t->eval(); t->clk = 1; t->eval(); };
    t->rst = 1; t->rd_req = 0; tick(); tick(); t->rst = 0; tick();
    long errs = 0, checked = 0, skipped = 0, spec = 0, m32 = 0;
    for (long i = 0; i < N; i++) {
        // a few writes (never 0xE0: the FIFO path is not this block's business)
        int nw = rnd() % 3;
        for (int k = 0; k < nw; k++) {
            u32 w = pool[rnd() % (sizeof pool / sizeof pool[0])], off = w | (u32)(rnd() % 2);
            u32 d = (rnd() % 8 == 0 && w == 0xB6) ? 0x80040000u : (w == 0x80 ? (u32)(rnd() & 0x00020000) | (u32)(rnd() & 0xFFFF) : (u32)rnd());
            if (w == 0x80 || w == 0xB6) { if (rnd() % 2) d = (off & 1) ? d >> 16 : d; }
            m.write(off, d);
        }
        // one read
        u32 w = (rnd() % 3 == 0) ? (0xF0 + 2 * (u32)(rnd() % 4)) : pool[rnd() % (sizeof pool / sizeof pool[0])];
        u32 off = w | (u32)(rnd() % 2);
        u32 hp = (u32)(rnd() % 529), vp = (u32)(rnd() % 278);
        t->beam_h = hp; t->beam_v = vp; t->rd_off = off; t->rd_req = 1; tick(); t->rd_req = 0;
        tick();                                        // rd_valid is a one-clk pulse, two edges after the request
        if (!t->rd_valid) { printf("FAIL: no rd_valid\n"); return 1; }
        u32 exp;
        if (w == 0xF0 || w == 0xF2 || w == 0xF4) {
            u32 r = w == 0xF0 ? hp : w == 0xF2 ? vp : (6u | (vp >= 256 ? 0x800u : 0u));
            if (m.mode32()) exp = (off & 1) ? r >> 16 : r; else exp = (off & 1) ? r >> 16 : (r & 0xFFFF);
            spec++;
        } else {
            std::string why;
            if (m.read(off, exp, why) == Zeus1Host::READ_UNKNOWN) { skipped++; continue; }
        }
        checked++; if (m.mode32()) m32++;
        if (t->rd_data != exp && errs++ < 10)
            printf("ERR read %03X (mode32 %d, b6 %08X, beam %u/%u): rtl %08X model %08X\n", off, (int)m.mode32(), m.reg[0xB6], hp, vp, t->rd_data, exp);
    }
    printf("HOST1 reads checked %ld (beam %ld, 32-bit mode %ld), skipped (model unknown) %ld, errors %ld\n", checked, spec, m32, skipped, errs);
    bool pass = errs == 0 && checked > N / 2 && m32 > checked / 10 && spec > checked / 10;
    printf("%s\n", pass ? "PASS" : "FAIL");
    delete t; return pass ? 0 : 1;
}
