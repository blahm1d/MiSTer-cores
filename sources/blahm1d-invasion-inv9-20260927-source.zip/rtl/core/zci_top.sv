// SPDX-License-Identifier: BSD-3-Clause
// zci_top -- the Invasion (invasnab) CPU bench DUT: zc2_top (c31_core + the MK4 tier, wired exactly as zc2_top.sv) plus the
// two Invasion interrupt sources as they sit in zk4_core under `ZK4_GAME_INVASION: zk4_gun (0x9C0000, IRQ3) and zk4_int2
// (Zeus reg 0x80 bit 25, INT2). Their bus side sees the tier's ext port as zk4_core does (an access completes when the
// bench raises ext_ready); the bench drives the scanout counters (beam_h / beam_v = MAME hpos / vpos from MAME time) and
// the gun ports from the capture. The CPU's IRQ lines = the bench's injections (INT0) OR the RTL's events (lines 2, 3).
`default_nettype none
module zci_top #(
    parameter integer NUM_MAIN_PAGES = 64,   // MK4 sizing (zeus/core memory tier)
    parameter integer NUM_ROM_PAGES  = 16,
    // c31_core speed stages (Cruis'n speed march); 0 = the earlier, smaller core for that stage
    parameter integer CPU_LOOKAHEAD = 1, CPU_FUSE = 1, CPU_BTB = 1, CPU_LDSKIP = 1, CPU_EARLY_EA = 1
)(
    input  wire         clk,
    input  wire         rst,
    input  wire         ce,                    // CORE clock-enable (the bench pauses the core here)

    // ---- CPU control / observation the bench uses ----
    input  wire [10:0]  irq_level,             // bench-injected lines (INT0); ORed with the RTL's INT2 / IRQ3
    // ---- Invasion devices ----
    input  wire [9:0]   beam_h,
    input  wire [8:0]   beam_v,
    input  wire [7:0]   gun_x0, gun_y0, gun_x1, gun_y1,
    input  wire [1:0]   gun_trigger,
    output wire [31:0]  gun_rd_now,
    output wire         gun_irq3,
    output wire         z_int2,
    output wire [31:0]  int2_reg80,
    output wire         gun_vactive,
    output wire [9:0]   gun_vbeam_h,
    output wire [8:0]   gun_vbeam_v,
    input  wire         fuse_allow,
    input  wire         load_en,
    input  wire [23:0]  load_pc,
    input  wire [32*36-1:0] load_state,

    output wire         retire,
    output wire [23:0]  retire_pc,
    output wire [31:0]  retire_cyc,
    output wire         retire_fault,
    output wire         guest_step,
    output wire         at_sample,
    output wire         sample_now,
    output wire [15:0]  sample_cyc,
    output wire [7:0]   fault_code,
    output wire [23:0]  snap_pc,
    output wire [32*36-1:0] snap_state,

    // ---- SDRAM word port (served by the bench from the Board arrays) ----
    output wire         sd_req,
    output wire         sd_burst,
    output wire         sd_we,
    output wire [23:0]  sd_addr,
    output wire [31:0]  sd_wdata,
    input  wire         sd_ack,
    input  wire [31:0]  sd_rdata,

    // ---- external passthrough (served by the bench: device/IO/CMOS windows) ----
    output wire         ext_valid,
    output wire         ext_write,
    output wire [23:0]  ext_addr,
    output wire [31:0]  ext_wdata,
    input  wire         ext_ready,
    input  wire [31:0]  ext_rdata,

    // ---- data-bus monitors (counters / memory trace only; NOT driven by the bench) ----
    output wire         mon_bus_valid,
    output wire         mon_bus_ready,
    output wire         mon_bus_write,
    output wire [2:0]   mon_bus_kind,
    output wire [23:0]  mon_bus_addr,

    // ---- tier diagnostics ----
    output wire [63:0]  stat_main_hits, stat_main_misses,
    output wire [63:0]  stat_rom_hits,  stat_rom_misses,
    output wire [63:0]  stat_pause_clocks,
    output wire [63:0]  stat_fetch_accepts, stat_fetch_rejects, stat_fetch_stale
);
    // ---- core <-> tier internal wiring (gm1_board.sv:120-157, 180-194) ----
    wire        c_read_ahead;  wire [23:0] c_read_ahead_addr;
    wire        c_bus_valid, c_bus_write;
    wire [2:0]  c_bus_kind;
    wire [23:0] c_bus_addr;
    wire [31:0] c_bus_wdata;
    wire        c_bus_ready;
    wire [31:0] c_bus_rdata;
    wire        c_f_valid, c_f_accept, c_f_rsp_valid;
    wire [23:0] c_f_addr;
    wire [31:0] c_f_rdata;
    wire        guest_pause;

    c31_core #(.LOOKAHEAD(CPU_LOOKAHEAD), .FUSE(CPU_FUSE), .BTB(CPU_BTB), .LDSKIP(CPU_LDSKIP), .EARLY_EA(CPU_EARLY_EA), .C32_INTCONFIG(1)) u_cpu (   // Invasion: C32 edge mode
        .clk(clk), .rst(rst), .ce(ce),
        .read_ahead_valid(c_read_ahead), .read_ahead_addr(c_read_ahead_addr),
        .bus_valid(c_bus_valid), .bus_kind(c_bus_kind), .bus_write(c_bus_write),
        .bus_addr(c_bus_addr), .bus_wdata(c_bus_wdata), .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata),
        .retire(retire), .retire_pc(retire_pc), .retire_cyc(retire_cyc), .retire_fault(retire_fault),
        .guest_step(guest_step), .at_sample(at_sample),
        .sample_now(sample_now), .sample_cyc(sample_cyc), .fuse_allow(fuse_allow),
        .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
        .irq_level(irq_level | {7'd0, gun_irq3, z_int2, 2'd0}), .fault_code(fault_code),
        .load_en(load_en), .load_pc(load_pc), .load_state(load_state),
        .snap_pc(snap_pc), .snap_state(snap_state)
    );

    // MK4 forked tier. READ_OVERLAP=0 and tier ce=1 exactly as gm1_board.sv:180-181.
    zk4_memory_fp #(.READ_OVERLAP(0), .NUM_MAIN_PAGES(NUM_MAIN_PAGES), .NUM_ROM_PAGES(NUM_ROM_PAGES)) u_mem (
        .clk(clk), .ce(1'b1), .rst(rst),
        .read_ahead_valid(c_read_ahead && ce), .read_ahead_addr(c_read_ahead_addr),
        .bus_valid(c_bus_valid), .bus_write(c_bus_write), .bus_fetch(c_bus_kind == 3'd0),
        .bus_addr(c_bus_addr), .bus_wdata(c_bus_wdata),
        .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata), .guest_pause(guest_pause),
        .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
        .sd_req(sd_req), .sd_burst(sd_burst), .sd_we(sd_we), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sd_ack), .sd_rdata(sd_rdata),
        .ext_valid(ext_valid), .ext_write(ext_write), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
        .ext_ready(ext_ready), .ext_rdata(ext_rdata),
        .nvram_protected(),
        .stat_main_hits(stat_main_hits), .stat_main_misses(stat_main_misses),
        .stat_rom_hits(stat_rom_hits), .stat_rom_misses(stat_rom_misses), .stat_pause_clocks(stat_pause_clocks),
        .stat_fetch_accepts(stat_fetch_accepts), .stat_fetch_rejects(stat_fetch_rejects),
        .stat_fetch_stale(stat_fetch_stale)
    );

    // ---- Invasion devices, bus side as in zk4_core (`ZK4_GAME_INVASION) ----
    wire is_gun  = ext_addr == 24'h9C0000;
    wire is_zeus = ext_addr[23:10] == 14'(24'h880000 >> 10);
    wire [7:0] gxi [2]; wire [7:0] gyi [2];
    assign gxi[0] = gun_x0; assign gxi[1] = gun_x1; assign gyi[0] = gun_y0; assign gyi[1] = gun_y1;
    zk4_gun #(.FIRE_EARLY(0), .VBEAM(1'b1)) u_gun (.clk(clk), .rst(rst), .req(ext_valid && ext_ready && is_gun), .we(ext_write),
        .wdata(ext_wdata), .rvalid(), .rdata(), .rd_now(gun_rd_now), .beam_h(beam_h), .beam_v(beam_v),
        .gun_xin(gxi), .gun_yin(gyi), .trigger(gun_trigger), .irq3(gun_irq3),
        .retire(retire), .retire_cyc(retire_cyc), .vactive(gun_vactive), .vbeam_h(gun_vbeam_h), .vbeam_v(gun_vbeam_v),
        // (retire is a one-clock pulse, set only on enabled clocks and cleared on every clock: c31_core)
        .gun_x(), .gun_y(), .armed(), .irq_state(), .control());
    zk4_int2 u_int2 (.clk(clk), .rst(rst), .wr(ext_valid && ext_ready && is_zeus && ext_write), .off(ext_addr[9:0]),
        .wdata(ext_wdata), .int2(z_int2), .reg80(int2_reg80));

    assign mon_bus_valid = c_bus_valid;
    assign mon_bus_ready = c_bus_ready;
    assign mon_bus_write = c_bus_write;
    assign mon_bus_kind  = c_bus_kind;
    assign mon_bus_addr  = c_bus_addr;
endmodule
`default_nettype wire
