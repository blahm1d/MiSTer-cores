// Cruis'n USA DCS Audio 2K wrapper (PACKED core), fabric variant.
//
// Differs from tunit_dcs2k.sv (donor) in the host ABI, which is Cruis'n's:
//   * data latch:  C31 write 0x9A0000 -> data_w(data & 0xff) (midvunit.cpp:265-268).
//                  We feed host_cmd_data = {8'h00, host_data[7:0]} on host_data_wr;
//                  the core raises ADSP IRQ2 + SET_INPUT_FULL (dcs.cpp:1503-1520).
//   * reset:       0x994000 bit 1 -> reset_w(BIT(control,1)) (midvunit.cpp:237-238);
//                  active-HIGH run (dcs.cpp:1456-1471). Here dcs_run is a SEPARATE
//                  level input = control[1], NOT a bit of the data write (that is the
//                  T-unit ABI). Not inverted (that is midxunit/RevX, P0020).
//   * no host read path: Cruis'n never reads DCS status/output (write-only), so the
//                  host_status/host_response/host_resp_rd read ports are tied off.
//   * mono audio out (midvunit.cpp:1206), 31.25 kHz, gated by dcs_run.
//
// Clock scheme (donor): ADSP on clk with a 1-in-2 core clock enable (P0019-clean).
`default_nettype none
module cusa_dcs2k_packed #(
  parameter EXT_ROM = 1,
  parameter PF_LINES = 512
)(
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        dac_ce_31250,   // 31.25 kHz sample-slot enable
  input  wire logic        host_data_wr,   // 1-clk strobe: C31 wrote 0x9A0000
  input  wire logic [7:0]  host_data,      // the 8-bit sound byte (data & 0xff)
  input  wire logic        dcs_run,        // level = control[1] (1=run, 0=reset), active-high

  output logic             rom_req,
  output logic [19:0]      rom_addr,
  input  wire logic        rom_ready,
  input  wire logic [63:0] rom_rdata,

  output logic signed [15:0] audio,
  output logic             audio_ce,
  output logic             audio_underrun,
  output logic             audio_overrun,
  output logic [13:0]      adsp_pc,
  output logic             adsp_valid,
  output logic             adsp_unimplemented
);
  logic core_ce, core_phase;
  logic host_cmd_w, host_cmd_pending;
  logic [15:0] host_cmd_data;
  logic [15:0] host_status, host_response;   // unused (write-only board)
  logic dac_pending;
  logic [15:0] dac_sample;
  logic dac_strobe;

  assign core_ce    = core_phase;
  assign host_cmd_w = core_ce && host_cmd_pending;
  assign audio      = dcs_run ? $signed(dac_sample) : 16'sd0;
  assign audio_ce   = dcs_run && dac_strobe;

  // Reset polarity: core held in reset while !dcs_run (active-high run). The
  // reset-release edge starts the bank-0 boot inside the core.
`ifdef MUT_RST_INV
  wire core_rst = rst || dcs_run;     // MUTATION (c): inverted reset polarity
`else
  wire core_rst = rst || !dcs_run;
`endif

  always_ff @(posedge clk) begin
    if (rst) begin
      core_phase       <= 1'b0;
      host_cmd_pending <= 1'b0;
      host_cmd_data    <= 16'h0000;
      dac_pending      <= 1'b0;
    end else begin
      core_phase <= ~core_phase;
      if (!dcs_run) begin
        host_cmd_pending <= 1'b0;
        dac_pending      <= 1'b0;
      end else begin
        if (core_ce && host_cmd_pending) host_cmd_pending <= 1'b0;
        if (core_ce && dac_pending)      dac_pending      <= 1'b0;
        if (host_data_wr) begin
          host_cmd_data    <= {8'h00, host_data};
          host_cmd_pending <= 1'b1;
        end
        if (dac_ce_31250) dac_pending <= 1'b1;
      end
    end
  end

  adsp2105_packed #(
    .DCS_2K(1), .EXT_ROM(EXT_ROM), .PF_LINES(PF_LINES), .PRELOAD_PM(0), .CORE_CE_EN(1)
  ) cpu (
    .clk(clk), .rst(core_rst), .core_ce(core_ce), .host_rst(1'b0),
    .host_cmd_w(host_cmd_w), .host_cmd_data(host_cmd_data),
    .host_status_r(host_status), .host_response_r(host_response), .host_resp_rd(1'b0),
    .rom_ddr_req(rom_req), .rom_ddr_addr(rom_addr),
    .rom_ddr_rdy(rom_ready), .rom_ddr_q(rom_rdata),
    .dac_ce_in(core_ce && dac_pending),
    .o_ppc(adsp_pc), .o_valid(adsp_valid), .o_unimpl(adsp_unimplemented),
    .dac_sample(dac_sample), .dac_ce(dac_strobe),
    .audio_underrun(audio_underrun), .audio_overrun(audio_overrun)
  );
endmodule
`default_nettype wire
