`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// cusa_dcs_ddr_agent.sv -- the DCS sound-ROM DDR3 agent: one avalon_shared_mux client (same
// client signature as bw1_ddr_stream, so it drops into the shipped DDRAM mux + mister_ddram_adapter).
// It does two temporally-disjoint jobs on a single avalon master:
//
//   LOAD (write, boot-time): consume the loader's 16-bit stream, pack 4 words little-first into a
//     64-bit beat (word0->[15:0], word1->[31:16], word2->[47:32], word3->[63:48]) and single-beat
//     write it at DCS_DDR_BASE + widx*8. The store is therefore a byte-for-byte linear copy of the
//     ioctl stream (u2..u9 concatenated, part k at k*0x80000). widx counts beats to EXPECTED_BEATS.
//
//   SERVE (read, run-time): the packed DCS core's dcs_mem presents rom_ddr_req + rom_ddr_addr[19:0]
//     (a BEAT index = byte/8 into the 8 MiB dcs region) and expects rom_ddr_q[63:0] (byte k at
//     [8*k+:8]). Translation to the packed store (midvunit.cpp:1403-1411 ROM_LOAD16_BYTE at k*0x200000
//     region bytes -> low-byte index part k at k*0x100000, populated 0x80000, ERASEFF above):
//        chip     = rom_ddr_addr[19:17]          (0..7 = u2..u9)
//        populated = (rom_ddr_addr[16] == 0)     (within-chip byte offset < 0x80000)
//        DDR byte = DCS_DDR_BASE + {chip, rom_ddr_addr[15:0], 3'b000}   (part k at k*0x80000 packed)
//     A populated beat is read from DDR and passed through UNSWAPPED (the store is in stream-byte
//     order, exactly what the core wants). An unpopulated beat (bit16=1) is served as all-0xFF with
//     no DDR access (the ERASEFF gap; the "populated-length check"). rom_ddr_rdy is a LEVEL held
//     while the core holds the request at the served address (dcs_mem contract, dcs_mem.sv:177-181).
//
// LOAD and SERVE never overlap on silicon: MiSTer Main holds the core reset high through the ioctl
// download (P0022), so the core issues no ROM reads until after the store is complete. A single-FSM
// arbiter gives writes priority in S_IDLE; either way only one avalon transaction is live at a time.
// Reset = por: the loaded DDR content and this agent survive a warm core_reset (the DCS core reboots
// on core_reset and re-reads the still-resident store).
module cusa_dcs_ddr_agent #(
    parameter [31:0] DCS_DDR_BASE  = 32'h3900_0000,   // 4 MiB window above the 16 MiB video region
    parameter [31:0] EXPECTED_BYTES = 32'h0040_0000    // 4 MiB
) (
    input  wire        clk,
    input  wire        por,
    // 16-bit load stream from the loader
    input  wire        in_valid,
    input  wire [15:0] in_data,
    output wire        in_ready,
    input  wire        stream_end,
    // packed-core DDR beat port (dcs_mem ext port)
    input  wire        rom_ddr_req,
    input  wire [19:0] rom_ddr_addr,
    output wire        rom_ddr_rdy,
    output wire [63:0] rom_ddr_q,
    // status
    output reg         rom_loaded,
    output reg  [31:0] ddr_reads,       // populated DDR read transactions ("DDR misses")
    // avalon client (bw1_ddr_stream signature)
    output reg         client_read,
    output reg         client_write,
    output reg  [31:0] client_address,
    output reg  [63:0] client_writedata,
    output reg  [7:0]  client_byteenable,
    output reg  [3:0]  client_burstcount,
    input  wire        client_waitrequest,
    input  wire        client_readdatavalid,
    input  wire [63:0] client_readdata,
    input  wire        client_read_error
);
    localparam [31:0] EXPECTED_BEATS = EXPECTED_BYTES >> 3;   // 0x80000 = 524288

    // ---- write gather (pack 4 x 16 -> 64, little-first) ----
    reg [1:0]  sub;
    reg [63:0] wbuf;
    reg        wbeat_valid;
    reg [31:0] widx;               // 64-bit beat index within the store
    assign in_ready = !wbeat_valid && !rom_loaded;

    // ---- read serve ----
    reg [19:0] srv_addr;
    reg [63:0] srv_beat;
    localparam [2:0] S_IDLE=3'd0, S_WR=3'd1, S_RD=3'd2, S_RDWAIT=3'd3, S_SERVE=3'd4;
    reg [2:0]  st;

    // populated iff the within-chip byte offset < 0x80000 (bit16 of the beat index == 0).
    // SUBSYS_MUT_NOPOP drops the check: every beat reads DDR, so an ERASEFF gap read returns
    // the aliased low-half data instead of 0xFF (D3 populated-length-check mutant).
`ifdef SUBSYS_MUT_NOPOP
    wire       rd_populated = 1'b1;
`else
    wire       rd_populated = ~rom_ddr_addr[16];
`endif
    // Packed store stride: part k at k*0x80000. SUBSYS_MUT_STRIDE uses 0x100000 (chip<<20)
    // instead of 0x80000 (chip<<19) -> wrong DDR address for chips >=1 (D3 stride mutant).
`ifdef SUBSYS_MUT_STRIDE
    wire [31:0] rd_byte_addr = DCS_DDR_BASE +
                {9'd0, rom_ddr_addr[19:17], 1'b0, rom_ddr_addr[15:0], 3'b000};
`else
    wire [31:0] rd_byte_addr = DCS_DDR_BASE +
                {10'd0, rom_ddr_addr[19:17], rom_ddr_addr[15:0], 3'b000};
`endif

    assign rom_ddr_rdy = (st == S_SERVE) && rom_ddr_req && (rom_ddr_addr == srv_addr);
    // Beat byte k at [8*k+:8] (stream-byte order, what the core expects). SUBSYS_MUT_BYTESWAP
    // reverses the 8 bytes (D3 byte-order mutant).
`ifdef SUBSYS_MUT_BYTESWAP
    assign rom_ddr_q = {srv_beat[7:0], srv_beat[15:8], srv_beat[23:16], srv_beat[31:24],
                        srv_beat[39:32], srv_beat[47:40], srv_beat[55:48], srv_beat[63:56]};
`else
    assign rom_ddr_q   = srv_beat;
`endif

    always @(posedge clk) begin
        if (por) begin
            sub<=2'd0; wbuf<=64'd0; wbeat_valid<=1'b0; widx<=32'd0; rom_loaded<=1'b0;
            ddr_reads<=32'd0; srv_addr<=20'd0; srv_beat<=64'd0; st<=S_IDLE;
            client_read<=1'b0; client_write<=1'b0; client_address<=32'd0; client_writedata<=64'd0;
            client_byteenable<=8'hff; client_burstcount<=4'd1;
        end else begin
            // gather load words into the 64-bit beat
            if (in_valid && in_ready) begin
                wbuf[sub*16 +: 16] <= in_data;
                if (sub == 2'd3) begin sub<=2'd0; wbeat_valid<=1'b1; end
                else sub <= sub + 2'd1;
            end else if (stream_end && !wbeat_valid && !rom_loaded && sub != 2'd0) begin
                // flush a partial beat (does not occur for a 4 MiB stream: 4 MiB % 8 == 0)
                wbeat_valid <= 1'b1; sub <= 2'd0;
            end

            // single-transaction avalon FSM: write priority, then serve a read
            case (st)
                S_IDLE: begin
                    if (wbeat_valid) begin
                        client_write     <= 1'b1;
                        client_address   <= DCS_DDR_BASE + {widx, 3'b000};
                        client_writedata <= wbuf;
                        client_byteenable<= 8'hff;
                        client_burstcount<= 4'd1;
                        st <= S_WR;
                    end else if (rom_ddr_req) begin
                        srv_addr <= rom_ddr_addr;
                        if (rd_populated) begin
                            client_read      <= 1'b1;
                            client_address   <= rd_byte_addr;
                            client_burstcount<= 4'd1;
                            st <= S_RD;
                        end else begin
                            srv_beat <= 64'hffff_ffff_ffff_ffff;   // ERASEFF gap, no DDR access
                            st <= S_SERVE;
                        end
                    end
                end
                S_WR: if (client_write && !client_waitrequest) begin
                    client_write <= 1'b0;
                    wbeat_valid  <= 1'b0;
                    widx <= widx + 32'd1;
                    if (widx + 32'd1 >= EXPECTED_BEATS) rom_loaded <= 1'b1;
                    st <= S_IDLE;
                end
                S_RD: if (client_read && !client_waitrequest) begin
                    client_read <= 1'b0;
                    st <= S_RDWAIT;
                end
                S_RDWAIT: if (client_readdatavalid) begin
                    srv_beat  <= client_readdata;
                    ddr_reads <= ddr_reads + 32'd1;
                    st <= S_SERVE;
                end
                S_SERVE: if (!rom_ddr_req || (rom_ddr_addr != srv_addr)) st <= S_IDLE;
                default: st <= S_IDLE;
            endcase
        end
    end
endmodule
`default_nettype wire
