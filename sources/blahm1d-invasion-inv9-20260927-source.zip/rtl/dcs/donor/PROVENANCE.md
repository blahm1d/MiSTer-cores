# rtl/dcs/donor — Cruis'n USA fabric DCS (DCS-2K, ADSP-2105), borrowed AS-IS for fit B MEASUREMENT

Source (2026-09-23): `D:/deck/fpga/cruisinusa/build/gm1-quartus-20260923T060600043845200Z/source/rtl/dcs_fabric` —
the DCS engine in Cruis'n's shipping gm1 build (their fit: cusa_dcs_subsystem 7,831 ALM, 34 M10K, 2 DSP; engine
adsp2105_packed 7,568 ALM). Copied byte-identical; sha256 below.

Status in zk4: **SHADOW / MEASUREMENT ONLY** (zk4_top DCS_SHADOW = 1). It is NOT MK4's sound board:
- MK4 is DCS2 on an ADSP-2104 (dcs.cpp DCS2_AUDIO_2104, midzeus.cpp:1400-1403): 16 MHz, stereo, SDRC ASIC ROM
  banking, 512-word internal PM, 16-bit I/O-ASIC data path with a READ-BACK path (the game waits for the 0x79 boot
  reply). This donor is DCS-2K (ADSP-2105, 10 MHz, mono, 8-bit write-only latch, u2..u9 4 MiB ROM).
- In the shadow build the calibrated zk4_dcs_stub still answers the game; this engine sees the same writes, reads its
  ROM window through zk4_ddr_arb3 and drives the audio pins so synthesis keeps it. The number it gives is the
  integrated AREA / TIMING of a DCS-class engine beside the whole core — the fit B question — not sound.
- Cabinet builds never set DCS_SHADOW.

Fork audit (for the real DCS2 port): DCS_DDR_BASE default 0x39000000 is overridden to 0x31000000 (zk4 DDR map:
wave RAM 0x30000000-0x309FFFFF, mirror 0x30C00000); ioctl index default 2 collides with the MK4 NVRAM (index 2) —
zk4 uses 3; EXPECTED_BYTES 4 MiB (MK4's sound ROM is 7 MiB populated in a 16 MiB region, midzeus.cpp:1507-1511).

```
8f994ff3c05dcb2a4b9a95705fca47fab12f9bd179b9546f876c52647939a35d *adsp2105_packed.sv
b7a6c7ad51ec1daa5870e89254fd76d6835cd586e6d287f83d5d9eb995f8d33b *cusa_dcs2k_packed.sv
28ba52fc55a64608f280d587baca4c44f904ea7093637f7aa600d0ad2c8378e6 *cusa_dcs_ddr_agent.sv
7dfd2c98ddaa0e5661ad48ee40d969c5baddafc07dc5369e38f5292f47e733dd *cusa_dcs_fifo.sv
e3d4a55943b80c8a551da09f45935448b08267046a768223067f071a4618ed06 *cusa_dcs_rom_loader.sv
42045b3bed78b7c576089d4a17022e8fb9914f2d98bcec8d96a432331bb3c713 *cusa_dcs_subsystem.sv
57ea3ef76a29b50f1b6bf4724df120f9c8735a3ca7c741a93b8884d66b2a6e85 *dcs_mem.sv
```
