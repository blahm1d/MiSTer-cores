# zk4.sdc -- MK4 (Midway Zeus 1) core. The framework sys/sys_top.sdc owns the board clocks, derive_pll_clocks and the
# cross-framework clock groups. Everything in the core runs on the one 50 MHz core clock (bw1_pll outclk_0) with data
# enables. This file adds exactly the board-SDRAM pin constraints of the cabinet-proven bw1 / gm1 builds, unchanged
# (general[1] = outclk_1 = 50 MHz, -3515 ps, forwarded to SDRAM_CLK; zk4_sdram keeps the SDRAM_DQ_in_q register name).
# No DCS multicycles: fit A has no fabric DCS. Names carrying [N] are never double-quoted, and no constraint uses
# get_clocks on a PLL output: this file is read before sys_top.sdc derives the PLL clocks (memory
# mister-sdc-read-order-pll-clocks).
create_generated_clock -name SDRAM_CLK \
  -source [get_pins -compatibility_mode {emu|pll|pll_inst|altera_pll_i|general[1].gpll~PLL_OUTPUT_COUNTER|divclk}] \
  [get_ports {SDRAM_CLK}]
set_input_delay -clock SDRAM_CLK -max 6.0 [get_ports {SDRAM_DQ[*]}]
set_input_delay -clock SDRAM_CLK -min 2.5 [get_ports {SDRAM_DQ[*]}]
set_output_delay -clock SDRAM_CLK -max 1.5  [get_ports {SDRAM_A[*] SDRAM_BA[*] SDRAM_DQ[*] SDRAM_DQML SDRAM_DQMH SDRAM_CKE SDRAM_nCS SDRAM_nRAS SDRAM_nCAS SDRAM_nWE}]
set_output_delay -clock SDRAM_CLK -min -0.8 [get_ports {SDRAM_A[*] SDRAM_BA[*] SDRAM_DQ[*] SDRAM_DQML SDRAM_DQMH SDRAM_CKE SDRAM_nCS SDRAM_nRAS SDRAM_nCAS SDRAM_nWE}]
# Read capture: SDRAM_CLK is phase-advanced, so data launched by an SDRAM_CLK edge is captured one core-clock period
# after the nearest following edge: setup multicycle 2, applied by node.
set_multicycle_path -setup -end -from [get_ports {SDRAM_DQ[*]}] -to [get_registers {*|SDRAM_DQ_in_q[*]}] 2
