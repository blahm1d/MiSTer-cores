#!/usr/bin/env python3
"""Static release gate for Wolf's native-refresh CRT Adjust integration."""

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
TOP = (ROOT / "Arcade-SmashTV.sv").read_text(encoding="utf-8")
BUILD = (ROOT / "quartus/build_sv2v.sh").read_text(encoding="utf-8")
MODULE = (ROOT / "rtl/video/crt_adjust.sv").read_text(encoding="utf-8")
WRAPPER = (ROOT / "rtl/video/wolf_crt_adjust.sv").read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"FAIL: {message}")


require("59.9" not in TOP and "CRT_RETIME" not in TOP,
        "retired 59.9 Hz frame-retimer remains in the emu wrapper")
require('"P1,CRT Adjust;"' in TOP,
        "CRT Adjust page header is missing; P1 options would be hidden")
require('"P1O[16],CRT Adjust,Off,On;"' in TOP,
        "CRT Adjust on/off option is missing")
require('"H1P1O[21:17],CRT H-Size,0,-1,-2,-3,-4,-5,-6,-7,-8;"' in TOP,
        "Wolf H-size menu must stay within the qualified -8..0 cross-product")
require('"H1P1O[33:29],CRT V-Shift,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1;"' in TOP,
        "Wolf V-shift menu must stay within the qualified -13..+15 range")
require("wolf_crt_adjust u_wolf_crt_adjust" in TOP,
        "Wolf-specific phase-safe CRT wrapper is not instantiated")
require(".VTOTAL   (V_TOTAL)" in WRAPPER and
        ".HTOTAL   (H_TOTAL)" in WRAPPER and
        ".HPOS_MODE(`HPOS_SYNCSHIFT)" in WRAPPER,
        "Wolf geometry must use native 506x289 SYNCSHIFT")
require("7'sd40 + hsize_q" in WRAPPER,
        "80 MHz / 8 MHz read-rate base is not 40 quarter-clocks")
require("if (hs_ref_rise)" in WRAPPER,
        "read accumulator is not reset from hs_ref_out")
require(".hs_ref_out(hs_ref)" in WRAPPER,
        "CRT Adjust reference is not wired to the read-rate generator")
require(".hoffset   (9'sd0)" in WRAPPER and ".voffset   (6'sd0)" in WRAPPER,
        "generic runtime-tap offsets were not pruned by the Wolf phase wrapper")
require("assign hs_out = active_q ? hs_ref : hs_in;" in WRAPPER,
        "HSync is not emitted at native pixel cadence")
require("vb_active_q ? (hb_in | hs_ref)" in WRAPPER,
        "vertical blank does not preserve arcade_video HBlank sampling edges")
require("crt_fb_ddr.sv" not in BUILD and "crt_retime.sv" not in BUILD,
        "retired full-frame retimer sources remain in the synthesis list")
require("wolf_crt_adjust.sv" in BUILD,
        "Wolf CRT wrapper is missing from the synthesis list")
require("31f7cccff76053c15e40f30fa1663665596bf18a" in MODULE,
        "vendored CRT Adjust source provenance is missing")

match = re.search(
    r'"H1P1O\[28:22\],CRT H-Position,([^"]+);"', TOP
)
require(match is not None, "H-position OSD option is missing")
labels = match.group(1).split(",")
expected = (
    ["0"]
    + [f"+{value}" for value in range(1, 49)]
    + [f"-{value}" for value in range(4, 0, -1)]
)
require(labels == expected,
        "H-position must enumerate the qualified 0,+1..+48,-4..-1 range")

decoded = [
    code if code <= 48 else code - 53
    for code in range(len(labels))
]
require(decoded == [0] + list(range(1, 49)) + list(range(-4, 0)),
        "H-position code-to-signed mapping is not bijective")
require("9'd453 + {2'b00, hpos_code}" in WRAPPER,
        "wrapper does not implement the validated dense H-position phase map")
require("hsize_code <= 5'd8" in WRAPPER,
        "wrapper does not fail invalid H-size status values back to zero")
require("vshift_code <= 5'd28" in WRAPPER and
        "9'd260 + {4'd0, vshift_code}" in WRAPPER,
        "wrapper does not implement the validated dense V-shift phase map")

print("PASS: Wolf CRT Adjust native-refresh integration")
