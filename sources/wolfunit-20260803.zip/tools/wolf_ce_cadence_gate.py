#!/usr/bin/env python3
"""Gate: Wolf's SDC multicycle claim must be backed by the cpu_ce cadence.

WHY THIS EXISTS
---------------
Two Wolf safety properties live in the CE GENERATOR (wolf_top.sv), not in the
core, and nothing enforced either of them:

  1. TIMING. rtl/sdram.sdc claims `set_multicycle_path -setup 4` on the CPU
     register group, i.e. the long CPU combinational path is given 4 clk
     periods. That claim is only TRUE because cpu_ce is a uniform modulo
     divider whose every gap is exactly N. T-unit (Arcade-TUnit_MiSTer) took
     the same P0019 architecture with a FRACTIONAL, average-exact enable
     (acc += 125, fire at >= 384). Its gaps alternate 3 and 4, so its honest
     multicycle is 3, and it fails setup by -1.835 ns -- almost exactly the one
     clock period a uniform 1-in-4 enable would have given it. Measured by
     T-unit over 651,041 fires: minimum gap 3.
     If Wolf ever swaps to a fractional cadence to hit a board frequency more
     exactly, EVERY long CPU path silently loses a clock period, in one commit,
     with no existing test failing.

  2. RESET. The shared tms34010 gates 21 `always_ff @(posedge clk)` blocks with
     `if (ce_cpu !== 1'b0)`, which also swallows the reset (Y-unit P0028).
     Wolf never executes that bug ONLY because `if (rst) ce_div <= 0` pins the
     divider to its active phase, holding cpu_ce HIGH for the whole reset
     window. A free-running divider -- a natural "this counter needs no reset"
     cleanup -- arms the defect at all 21 sites at once. First symptom would be
     a warm reset on a cabinet that restores nothing.

Both hazards are silent: no simulation fails, the core is untouched, and the
damage appears only on hardware. This gate makes them loud.

It is a STRUCTURAL gate, deliberately. It does not re-simulate the divider
(checking the RTL against a copy of itself proves nothing -- CLAUDE.md section 5
bans self-consistency-only checks). It asserts the two properties the SDC and
the reset argument actually depend on, read out of the shipping sources.

Run:      python tools/wolf_ce_cadence_gate.py
Mutate:   python tools/wolf_ce_cadence_gate.py --self-test
          (applies each hazard to a scratch copy; every one MUST be caught, or
           the gate is decorative)
Exit 0 = PASS, 1 = FAIL.
"""

from __future__ import annotations
import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOP = ROOT / "rtl" / "wolf" / "wolf_top.sv"
SDC = ROOT / "rtl" / "sdram.sdc"


def fail(msg: str) -> None:
    print(f"FAIL {msg}")


def sdc_setup_claim(sdc_text: str) -> int | None:
    """Strictest -setup N claimed on the CPU register group."""
    claims = []
    for line in sdc_text.splitlines():
        s = line.strip()
        if s.startswith("#") or "set_multicycle_path" not in s:
            continue
        if "-setup" not in s or "cpu_regs" not in s:
            continue
        m = re.search(r"-setup\s+(\d+)", s)
        if m:
            claims.append(int(m.group(1)))
    return min(claims) if claims else None


def divider_moduli(top_text: str) -> list[int]:
    """Every modulus the ce_div comparator can wrap at."""
    m = re.search(r"ce_div\s*==\s*\(([^)]*)\)", top_text)
    if m:
        return [int(x) for x in re.findall(r"3'd(\d+)", m.group(1))]
    m = re.search(r"ce_div\s*==\s*3'd(\d+)", top_text)
    return [int(m.group(1))] if m else []


def check(verbose: bool = True) -> list[str]:
    errs: list[str] = []
    top = TOP.read_text(encoding="utf-8", errors="replace")
    sdc = SDC.read_text(encoding="utf-8", errors="replace")

    # --- Property 1: the enable must be a UNIFORM modulo divider ------------
    # A fractional/average-exact enable (accumulator + threshold) produces
    # non-uniform gaps and silently invalidates the multicycle claim.
    ce_block = re.search(
        r"always_ff @\(posedge clk\) begin\s*\n\s*if \(rst\)\s*\n?\s*ce_div\s*<=.*?\n\s*end",
        top, re.S)
    if ce_block is None:
        errs.append("cpu_ce generator not found in the expected reset-pinned "
                    "modulo form at wolf_top.sv (structure changed?)")
    else:
        body = ce_block.group(0)
        if re.search(r"ce_div\s*<=\s*ce_div\s*\+\s*\d+'d(?!1\b)\d+", body):
            errs.append("cpu_ce divider increments by more than 1 -- this is a "
                        "FRACTIONAL cadence; gaps are non-uniform and the SDC "
                        "multicycle claim is no longer honest (see T-unit)")
        if re.search(r"\bacc\b|accumulat", body, re.I):
            errs.append("cpu_ce generator looks like an accumulator (fractional "
                        "cadence). Gaps will not be uniform; the SDC -setup "
                        "claim becomes false without any test failing")

        # --- Property 2: reset must PIN the divider (P0028 immunity) --------
        if not re.search(r"if \(rst\)\s*\n?\s*ce_div\s*<=\s*3'd0", body):
            errs.append("`if (rst) ce_div <= 3'd0` is GONE. Wolf's immunity to "
                        "the P0028 reset-swallow (21 ce_cpu-gated always_ff "
                        "blocks in the shared core) depends on reset pinning "
                        "the divider so cpu_ce is held HIGH across reset. "
                        "Without it a WARM reset restores nothing on silicon")

    # --- Property 3: SDC claim must not exceed the guaranteed gap ----------
    claim = sdc_setup_claim(sdc)
    moduli = divider_moduli(top)
    if claim is None:
        errs.append("no `-setup N` multicycle found on cpu_regs in rtl/sdram.sdc "
                    "(P0019 requires it; without it STA times the long CPU cone "
                    "at one clk period)")
    elif not moduli:
        errs.append("could not read the ce_div modulus from wolf_top.sv")
    else:
        # ce_div wraps at M, so pulses are M+1 clk apart.
        min_gap = min(m + 1 for m in moduli)
        if verbose:
            print(f"  cpu_ce moduli {moduli} -> guaranteed min gap {min_gap} clk")
            print(f"  rtl/sdram.sdc claims -setup {claim} on cpu_regs")
        if claim > min_gap:
            errs.append(f"SDC claims -setup {claim} but the cpu_ce cadence only "
                        f"guarantees a gap of {min_gap} clk. STA is being told "
                        f"the path has more time than it does")
    return errs


SELF_TESTS = [
    ("fractional cadence (T-unit's shape)",
     lambda t: t.replace("ce_div <= ce_div + 3'd1;", "ce_div <= ce_div + 3'd2;")),
    ("reset pin removed (arms P0028 at 21 sites)",
     lambda t: t.replace("if (rst)\n      ce_div <= 3'd0;", "if (1'b0)\n      ce_div <= 3'd0;")),
    ("divider sped up past the SDC claim",
     lambda t: t.replace("3'd4 : 3'd3", "3'd2 : 3'd1")),
]


def self_test() -> int:
    """Every mutation must be CAUGHT. A gate nothing kills is decorative."""
    original = TOP.read_text(encoding="utf-8", errors="replace")
    survivors = []
    try:
        for name, mutate in SELF_TESTS:
            mutated = mutate(original)
            if mutated == original:
                survivors.append(f"{name} (mutation did not apply -- stale gate)")
                continue
            TOP.write_text(mutated, encoding="utf-8", newline="")
            if not check(verbose=False):
                survivors.append(name)
                print(f"  SURVIVED (bad): {name}")
            else:
                print(f"  killed: {name}")
    finally:
        TOP.write_text(original, encoding="utf-8", newline="")
    if survivors:
        print(f"\nRESULT FAIL: {len(survivors)} mutation(s) survived -- "
              f"the gate does not actually discriminate:")
        for s in survivors:
            print(f"  - {s}")
        return 1
    print("\nRESULT PASS: every mutation killed; the gate discriminates")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--self-test", action="store_true",
                    help="mutation-test the gate itself")
    args = ap.parse_args()

    if args.self_test:
        print("wolf_ce_cadence_gate SELF-TEST (mutation)")
        return self_test()

    print("wolf_ce_cadence_gate: cpu_ce cadence vs SDC multicycle + P0028 immunity")
    errs = check()
    if errs:
        for e in errs:
            fail(e)
        print(f"RESULT FAIL: {len(errs)} violation(s)")
        return 1
    print("RESULT PASS: cadence uniform, reset-pinned, and SDC claim is honest")
    return 0


if __name__ == "__main__":
    sys.exit(main())
