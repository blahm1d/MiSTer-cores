#!/usr/bin/env bash
# run_ddr3.sh — VRAM->DDR3 iverilog gates (no license needed). Both expect "RESULT: PASS".
#   P0 loopback : agent + FAITHFUL f2sdram oracle, 9 assertions + mutation coverage.
#   P1 xdiff    : DDR3 VRAM subsystem bit-exact vs the proven SDRAM-backed vram_sdram_top.
#   ./run_ddr3.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="${TMPDIR:-/tmp}"

run_and_filter() {
  local image="$1"
  local filter="$2"
  local output status

  if output="$(vvp "$image" 2>&1)"; then
    status=0
  else
    status=$?
  fi

  grep -iE "$filter" <<<"$output" || true
  if (( status != 0 )); then
    return "$status"
  fi
  if grep -qiE 'RESULT:[[:space:]]*FAIL' <<<"$output"; then
    return 1
  fi
  if ! grep -qiE 'RESULT:[[:space:]]*PASS' <<<"$output"; then
    echo "FAIL: simulator exited without a RESULT: PASS verdict" >&2
    return 1
  fi
}

run_mutant_expect() {
  local image="$1"
  local marker="$2"
  local output status

  set +e
  output="$(vvp "$image" 2>&1)"
  status=$?
  set -e
  grep -E 'POSTED-RANGE ERROR|BURST-GUARD ERROR|SCAN|PUBLICATION|FENCE|BOUNDARY-PAGE|RESET-ORPHAN|RESULT:' <<<"$output" || true
  if ! grep -Fq 'RESULT: FAIL' <<<"$output" || ! grep -Fq "$marker" <<<"$output"; then
    echo "FAIL: mutation survived or failed for the wrong reason (wanted: $marker)" >&2
    return 1
  fi
}

echo "== P0 loopback =="
iverilog -g2012 -o "$T/tb_vram_ddr.vvp" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_loopback.sv"
run_and_filter "$T/tb_vram_ddr.vvp" "RESULT|\[tb\]|main model"

echo "== P1 cross-diff (DDR3 vs SDRAM golden) =="
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
run_and_filter "$T/tb_vram_ddr_xdiff.vvp" "RESULT|MISMATCH|FAIL"

echo "== P1 mutation: newest burst must not replace an older posted range =="
MUT_RANGE="$T/stv_vram_ddr_top_latest_range.sv"
cp "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$MUT_RANGE"
sed -i "0,/if (posted_guard != 8'd0) begin/s//if (1'b0) begin/" "$MUT_RANGE"
grep -q "if (1'b0) begin" "$MUT_RANGE" || { echo "FAIL: posted-range mutation did not apply" >&2; exit 1; }
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff_latest_range.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$MUT_RANGE" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
run_mutant_expect "$T/tb_vram_ddr_xdiff_latest_range.vvp" "POSTED-RANGE ERROR"

echo "== P1 mutation: posted-range read interlock must cause a real multi-cycle wait =="
MUT_GUARD="$T/stv_vram_ddr_top_no_guard.sv"
cp "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$MUT_GUARD"
sed -i 's/else if (c_start && (c_wr || !c_posted_hazard)) begin/else if (c_start) begin/' "$MUT_GUARD"
grep -q 'else if (c_start) begin' "$MUT_GUARD" || { echo "FAIL: posted-guard mutation did not apply" >&2; exit 1; }
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff_no_guard.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$MUT_GUARD" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
run_mutant_expect "$T/tb_vram_ddr_xdiff_no_guard.vvp" "BURST-GUARD ERROR"

echo "== P1 mutation: scan row fill must wait for overlapping posted writes =="
MUT_SCAN="$T/stv_vram_ddr_top_no_scan_guard.sv"
cp "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$MUT_SCAN"
sed -i 's/wire b_publication_pending = scan_dirty\[b_fill_row\[9:8\]\];/wire b_publication_pending = 1\x27b0;/' "$MUT_SCAN"
grep -Fq "wire b_publication_pending = 1'b0;" "$MUT_SCAN" || { echo "FAIL: posted-scan mutation did not apply" >&2; exit 1; }
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff_no_scan_guard.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$MUT_SCAN" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
run_mutant_expect "$T/tb_vram_ddr_xdiff_no_scan_guard.vvp" "TIMED SCAN MISMATCH row=13 col=1"

echo "== P1 mutation: rejected 2047-cycle timer must fail beyond its assumed publication bound =="
MUT_SCAN_TIMER="$T/stv_vram_ddr_top_legacy_scan_timer.sv"
cp "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$MUT_SCAN_TIMER"
sed -i 's/wire b_publication_pending = scan_dirty\[b_fill_row\[9:8\]\];/wire b_publication_pending = |scan_legacy_guard[b_fill_row[9:8]];/' "$MUT_SCAN_TIMER"
sed -i "s/if (1'b1) begin \/\/ ISSUE_PUBLICATION_READBACK/if (1'b0) begin \/\/ ISSUE_PUBLICATION_READBACK/" "$MUT_SCAN_TIMER"
grep -Fq 'wire b_publication_pending = |scan_legacy_guard[b_fill_row[9:8]];' "$MUT_SCAN_TIMER" || { echo "FAIL: legacy-timer mutation did not apply" >&2; exit 1; }
grep -Fq "if (1'b0) begin // ISSUE_PUBLICATION_READBACK" "$MUT_SCAN_TIMER" || { echo "FAIL: legacy-timer readback-disable mutation did not apply" >&2; exit 1; }
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff_legacy_scan_timer.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$MUT_SCAN_TIMER" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
run_mutant_expect "$T/tb_vram_ddr_xdiff_legacy_scan_timer.vvp" "TIMED SCAN MISMATCH row=13 col=1"

echo "== P1 mutation: hidden-page traffic must not hold the visible-page scan guard =="
MUT_SCAN_PAGE="$T/stv_vram_ddr_top_global_scan_guard.sv"
cp "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$MUT_SCAN_PAGE"
sed -i 's/wire b_publication_pending = scan_dirty\[b_fill_row\[9:8\]\];/wire b_publication_pending = |scan_dirty;/' "$MUT_SCAN_PAGE"
grep -Fq 'wire b_publication_pending = |scan_dirty;' "$MUT_SCAN_PAGE" || { echo "FAIL: independent-page scan mutation did not apply" >&2; exit 1; }
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff_global_scan_guard.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$MUT_SCAN_PAGE" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
run_mutant_expect "$T/tb_vram_ddr_xdiff_global_scan_guard.vvp" "TIMED SCAN WEDGE row=256 col=0"

echo "== P1 mutation: a boundary burst must guard both 256-row regions =="
MUT_SCAN_BOUNDARY="$T/stv_vram_ddr_top_first_page_only.sv"
cp "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$MUT_SCAN_BOUNDARY"
sed -i 's/(4\x27b0001 << retired_page_last)/(4\x27b0001 << retired_page_first)/' "$MUT_SCAN_BOUNDARY"
grep -Fq "(4'b0001 << retired_page_first);" "$MUT_SCAN_BOUNDARY" || { echo "FAIL: boundary-page mutation did not apply" >&2; exit 1; }
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff_first_page_only.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$MUT_SCAN_BOUNDARY" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
run_mutant_expect "$T/tb_vram_ddr_xdiff_first_page_only.vvp" "BOUNDARY-PAGE GUARD ERROR"

echo "== P1 mutation: reset must hold guards while the persistent agent drains =="
MUT_SCAN_RESET="$T/stv_vram_ddr_top_no_orphan_hold.sv"
cp "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$MUT_SCAN_RESET"
sed -i 's/if (tst_wr_done)$/if (tst_wr_done \&\& (ls == L_RUN))/' "$MUT_SCAN_RESET"
grep -Fq 'if (tst_wr_done && (ls == L_RUN))' "$MUT_SCAN_RESET" || { echo "FAIL: reset-orphan mutation did not apply" >&2; exit 1; }
iverilog -g2012 -o "$T/tb_vram_ddr_xdiff_no_orphan_hold.vvp" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$MUT_SCAN_RESET" \
  "$ROOT/sim/sdram_model.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_xdiff.sv"
run_mutant_expect "$T/tb_vram_ddr_xdiff_no_orphan_hold.vvp" "RESET-ORPHAN FENCE ERROR"

echo "PASS: P1 posted-range and readback-publication mutants killed for the intended reasons"
