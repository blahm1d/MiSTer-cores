#!/bin/bash
# run_wolf_pic.sh -- standalone iverilog unit test for the Wolf-unit serial-PIC
# security wrapper (rtl/wolf/wolf_pic.sv) against the WOLF_PIC_SPEC.md oracles:
#   §3 17-byte serial read-back (picpoll.txt SEC_R #1..#17, byte-exact),
#   §2d status = clock-bit mirror + read side-effect,
#   §2d self-test echo (0x1F/0x0F -> low-nibble F),
#   §2a reset_w(state) zeroes idx/status/buff.
# No Questa, no wolf_mem, no boot golden touched.
#
# Usage: bash sim/run_wolf_pic.sh
# Exit 0 iff the TB prints PASS (all oracles green).

set -u
cd "$(dirname "$0")/.." || exit 1        # repo root (Arcade-UMK3_MiSTer)

IVERILOG=/c/iverilog/bin/iverilog
VVP=/c/iverilog/bin/vvp
OUT=sim/build/tb_wolf_pic.vvp
LOG=sim/build/tb_wolf_pic.log
mkdir -p sim/build

# T5 input: regenerate the RWT captured-exchange event list from the gospel
# (fails loudly if the exchange shape is not the captured 37W/17R).
RWT_GOSPEL="${RWT_PIC_GOSPEL:-D:/deck/fpga/rampageworldtour/gospel/rmpgwt_pic_exchange_run1.txt}"
python sim/make_rwt_pic_events.py "$RWT_GOSPEL" sim/build/rwt_pic_events.txt \
  || { echo "FATAL: make_rwt_pic_events.py failed"; exit 1; }

$IVERILOG -g2012 -o "$OUT" rtl/wolf/wolf_pic.sv sim/tb_wolf_pic.sv \
  || { echo "FATAL: iverilog compile failed"; exit 1; }

"$VVP" -n "$OUT" > "$LOG" 2>&1
cat "$LOG"

echo "----------------------------------------------------------------------"
if grep -q "^PASS wolf_pic" "$LOG" && ! grep -q "^FAIL" "$LOG"; then
    echo "RESULT: PASS"
    exit 0
else
    echo "RESULT: FAIL"
    exit 1
fi
