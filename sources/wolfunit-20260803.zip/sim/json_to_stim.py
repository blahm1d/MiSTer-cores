#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
json_to_stim.py -- convert wolf_video_vectors.json into the token STIM stream that
tb_wolf_video.sv parses (CASE/ROWADDR/COLADDR/NPIX/V/P/ENDCASE), and print the
per-case npix list (name,npix) so the runner can split the TB's single OUT stream.

Usage: python json_to_stim.py <vectors.json> <stim.txt> <manifest.txt>
  stim.txt     -> token stream, one CASE block per vector (in JSON order)
  manifest.txt -> "<name> <npix>" per line, JSON order (for splitting OUT)
"""
import sys, json

def main(argv):
    vj, stim, manifest = argv[1], argv[2], argv[3]
    cases = json.load(open(vj))
    with open(stim, "w", newline="\n") as f:
        for c in cases:
            f.write("CASE\n")
            f.write("ROWADDR %X\n" % c["rowaddr"])
            f.write("COLADDR %X\n" % c["coladdr"])
            f.write("NPIX %d\n" % c["npix"])
            for a, v in c["vram"]:    f.write("V %X %X\n" % (a, v))
            for a, v in c["palette"]: f.write("P %X %X\n" % (a, v))
            f.write("ENDCASE\n")
    with open(manifest, "w", newline="\n") as f:
        for c in cases:
            f.write("%s %d\n" % (c["name"], c["npix"]))
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
