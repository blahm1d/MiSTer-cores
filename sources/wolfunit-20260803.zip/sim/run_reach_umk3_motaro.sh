#!/usr/bin/env bash
# Reach the UMK3 Motaro fight and save a MAME state there.  MAME only.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-C:/tools/mame/mame.exe}"
ROMS="${UMK3_ROMS:-D:/deck/fpga/umk3/roms}"
SCRIPT="$ROOT/sim/reach_umk3_motaro.lua"
OUT="${OUT:-$BUILD/motaro_reach.txt}"
SNAPDIR="${SNAPDIR:-$BUILD/motaro_reach_snaps}"
STATEDIR="${STATEDIR:-$BUILD/motaro_states}"

mkdir -p "$BUILD" "$SNAPDIR" "$STATEDIR"
NVDIR="$(mktemp -d "$BUILD/motaro_reach_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
rm -f "$OUT"
# Seed a VALID CMOS so the game boots straight to attract instead of the
# CMOS-invalid factory-restore sequence (which consumed the early inputs and
# dropped every prior attempt into attract-mode AI demos).
NVSEED="${NVSEED:-D:/deck/fpga/wolf-nvram-80/by-setname/umk3.nvm}"
if [ -f "$NVSEED" ]; then
  mkdir -p "$NVDIR/umk3"
  cp "$NVSEED" "$NVDIR/umk3/nvram"
  echo "seeded CMOS from $NVSEED"
else
  echo "WARNING: no NVRAM seed at $NVSEED -- boot will hit the CMOS-invalid screen"
fi

export MOTARO_REACH_OUT="$OUT"
export MOTARO_AREA="${MOTARO_AREA:-14000}"
"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -snapshot_directory "$SNAPDIR" -state_directory "$STATEDIR" \
  -nowindow -video none -sound none -seconds_to_run "${SECS:-260}" \
  -autoboot_delay 0 -nothrottle -autoboot_script "$SCRIPT"

grep -q '^DONE' "$OUT" && tail -1 "$OUT"
echo "max_area seen (top 8 frames):"
grep '^FRAME' "$OUT" | sort -t= -k3 -n | tail -8
echo "states:"; ls -la "$STATEDIR" 2>/dev/null
grep -E '^SAVESTATE|^PHASE' "$OUT"
