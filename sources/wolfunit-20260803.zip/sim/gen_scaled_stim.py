#!/usr/bin/env python3
# gen_scaled_stim.py -- build a wolf_dma replay stim for the captured SCALED select-screen blit.
# Reads mame-gospel/trace/scaled/scaled_blit.txt (the "REGS r0..r17" line = full register file at
# the bit15 COMMAND write), emits sim/build/wolf_dma_scaled_stim.txt in the exact bank-aware write
# order the realgfx TB replays. KEEPS the real OFFSETHI/LO (r2/r3) so the DDR3-preloaded real 32MB
# gfx is read at the true source -- this is a REAL scaled blit, not an offset-folded stub.
import os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "..", "mame-gospel", "trace", "scaled", "scaled_blit.txt")
OUT = os.path.join(ROOT, "sim", "build", "wolf_dma_scaled_stim.txt")

r = None
for line in open(SRC):
    if line.startswith("REGS"):
        r = [int(x, 16) for x in line.split()[1:19]]
        break
assert r and len(r) == 18, "no REGS line (18 values) in scaled_blit.txt"

writes = [
    ("f", 0x0020),           # bank1: offsets 12/13 -> TOP/BOTCLIP
    ("c", r[12]), ("d", r[13]),
    ("f", 0x0000),           # bank0: offsets 12/13 -> LEFT/RIGHTCLIP
    ("c", r[16]), ("d", r[17]),
    ("0", r[0]),             # LRSKIP
    ("2", r[2]), ("3", r[3]),  # REAL source offset (real gfx)
    ("4", r[4]), ("5", r[5]), ("6", r[6]), ("7", r[7]),
    ("8", r[8]), ("9", r[9]),
    ("a", r[10]), ("b", r[11]),  # SCALEX / SCALEY -- the untested path
    ("e", r[14]),
    ("f", r[15]),            # final CONFIG = captured value
    ("1", r[1]),             # captured COMMAND (bit15) -> trigger
]
with open(OUT, "w", newline="\n") as f:
    for reg, data in writes:
        f.write("W %s %04x\n" % (reg, data & 0xffff))
print("scaled stim -> %s" % OUT)
print("  cmd=%04X X=%d Y=%d W=%d H=%d SCALEX=%04X SCALEY=%04X pal=%04X off=%04X%04X"
      % (r[1], r[4] & 0x3ff, r[5] & 0x1ff, r[6] & 0x3ff, r[7] & 0x3ff, r[10], r[11], r[8], r[3], r[2]))
