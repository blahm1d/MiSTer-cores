#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-C:/tools/mame/mame.exe}"
ROMS="${UMK3_ROMS:-D:/deck/fpga/umk3/roms}"
SCRIPT="$ROOT/sim/capture_umk3_peak_fight_regs.lua"
OUT="$BUILD/umk3_peak_attract_regs.txt"

mkdir -p "$BUILD"
NVDIR="$(mktemp -d "$BUILD/umk3_peak_attract_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
rm -f "$OUT"

export UMK3_CAPTURE_MODE=attract
export UMK3_CAPTURE_OUT="$OUT"
"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 12 -autoboot_delay 0

"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 90 -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"

grep -q '^DONE$' "$OUT"
grep '^CANDIDATE' "$OUT"
