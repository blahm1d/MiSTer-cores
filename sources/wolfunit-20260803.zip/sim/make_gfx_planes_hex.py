#!/usr/bin/env python3
# Extract the RAW 6bpp gfx planes (as the MRA delivers them) into one contiguous
# hex byte stream for the on-chip unpacker test (tb_gfx_unpack) and the real MRA
# layout. Three planes, each 0x60000 bytes, concatenated:
#   plane0 = u111 u112 u113   (region 0x000000 in MAME init_gfxrom)
#   plane1 = u95  u96  u97     (region 0x200000)
#   plane2 = u106 u107 u108    (region 0x400000)
# yunit_gfx_unpack reads plane0/1/2 word w and emits pixel = p0|p1<<2|p2<<4 — the
# SAME math make_gfx_hex.py applies, so the FSM output must equal smashtv_gfx.hex.
import sys, zipfile
ZIP = sys.argv[1] if len(sys.argv) > 1 else r"D:/deck/fpga/smash tv/roms/smashtv.zip"
DST = "sim/build/smashtv_gfx_planes.hex"
PLANES = [
    ["la1_smash_tv_game_rom_u111.u111", "la1_smash_tv_game_rom_u112.u112", "la1_smash_tv_game_rom_u113.u113"],
    ["la1_smash_tv_game_rom_u95.u95",   "la1_smash_tv_game_rom_u96.u96",   "la1_smash_tv_game_rom_u97.u97"],
    ["la1_smash_tv_game_rom_u106.u106", "la1_smash_tv_game_rom_u107.u107", "la1_smash_tv_game_rom_u108.u108"],
]
z = zipfile.ZipFile(ZIP)
out = bytearray()
for plane in PLANES:
    blk = bytearray()
    for name in plane:
        d = z.read(name)
        assert len(d) == 0x20000, f"{name}: expected 128KB, got {len(d)}"
        blk += d
    assert len(blk) == 0x60000
    out += blk
assert len(out) == 0x120000, len(out)
with open(DST, "w", newline="\n") as f:
    f.write("\n".join(f"{b:02x}" for b in out) + "\n")
print(f"wrote {DST}: {len(out)} bytes (3 planes x 0x60000)")
