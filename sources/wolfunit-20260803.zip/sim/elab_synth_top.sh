#!/usr/bin/env bash
# Fast, licence-free production seam check:
#   Quartus-native Arcade-SmashTV.sv -> sv2v-generated wolf_top blob.
# Missing MiSTer chassis modules are intentionally ignored here; Quartus owns
# those sources. This check exists to catch syntax and conditional-port drift.
set -euo pipefail
export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/sim/build/emu_synth_elab.vvp"
mkdir -p "$ROOT/sim/build"

iverilog -g2012 -i -s emu ${SV2V_EXTRA:-} -I"$ROOT" -o "$OUT" \
  "$ROOT/Arcade-SmashTV.sv" \
  "$ROOT/rtl/wolf/wolf_game_inputs.sv" \
  "$ROOT/build_syn/smashtv_core.v"
echo "PASS: production wrapper binds the converted wolf_top"
