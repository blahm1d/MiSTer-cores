#!/usr/bin/env bash
# run_wolf_gfx_ddr_roundtrip.sh -- write/read round-trip gate for wolf_gfx_ddr_top's
# WRITE-COMBINE + RMW full-beat (be=FF) download write path. Two stimulus sections:
# sequential AND stride-4 (interleave-shaped, the pattern that killed the first cut).
# DDR3 model runs cfg_ignore_be=1 (measured bridge behavior, STV P1.5).
# Expect "RESULT: PASS".
set -e
cd "$(dirname "$0")/.."
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
T="${TMPDIR:-/tmp}"

"$IVERILOG" -g2012 -o "$T/tb_wolf_gfx_ddr_roundtrip.vvp" \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv \
  sim/ddr3_avalon_model.sv \
  sim/tb_wolf_gfx_ddr_top_roundtrip.sv

"$VVP" "$T/tb_wolf_gfx_ddr_roundtrip.vvp" | tee "$T/wolf_gfx_ddr_roundtrip.log" | grep -E "RESULT|FAIL|\[tb\]|TIMEOUT"
grep -q "RESULT: PASS" "$T/wolf_gfx_ddr_roundtrip.log"
