#!/usr/bin/env bash
set -euo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/sim/build/tb_wolf_gfx_demand_first.vvp"
LOG="$ROOT/sim/build/tb_wolf_gfx_demand_first.log"

cd "$ROOT"
mkdir -p sim/build
/c/iverilog/bin/iverilog -g2012 -s tb_wolf_gfx_demand_first -o "$OUT" \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv \
  sim/ddr3_avalon_model.sv \
  sim/tb_wolf_gfx_demand_first.sv
/c/iverilog/bin/vvp "$OUT" | tee "$LOG"
grep -q '^PASS:' "$LOG"
! grep -q '^FAIL:' "$LOG"
