#!/usr/bin/env python3
# Build the UMK3 (Wolf-unit) CMOS/NVRAM $readmemh seed hex from a captured MAME
# nvram image (a "warm" battery image that already holds the factory signature).
#
# MAME gospel — CMOS is a FLAT byte-lane store:
#   midwunit_m.cpp:48-51  cmos_r(offset)  -> return m_nvram[offset];
#   midwunit_m.cpp:32-44  cmos_w(offset,data,mask) -> COMBINE_DATA(m_nvram+offset)
#   (m_nvram is a uint16_t array whose entries are byte-valued: each 34010 CMOS
#    word carries ONE byte in its low lane; see cmosdisc.txt CMOS_W lines, all
#    values 0x00XX with mask=FFFF, and the read side returns them verbatim.)
#
# wolf_mem.sv mirrors this exactly (wolf_pkg.sv:20 WMAP_CMOS_BASE=0x01400000,
# wolf_mem.sv:224 WB_CMOS = base>>4, wolf_mem.sv:403 read_word R_CMOS:
#   rel = gw - WB_CMOS;  read_word = nvram[rel];):
#   34010 CMOS word i  ==  nvram[i]  ==  MAME m_nvram[i]  ==  byte-valued entry i.
#
# FILE PACKING (MEASURED, do not assume): MAME's m_nvram is a uint16_t[0x6000]
# array of BYTE-VALUED entries (high lane always 0). Its on-disk save is 2 bytes
# per entry, little-endian, so the file is 0x6000*2 = 0xC000 = 49152 bytes:
#   file[2*i]   = low byte  = m_nvram[i] value  (0x00..0xFF)
#   file[2*i+1] = high byte = 0x00              (verified: ALL 0x6000 high bytes 0)
# Therefore CMOS word i = {8'h00, file[2*i]}. Reading the file flat (byte i) is
# WRONG — it would fold two entries per word and shift the factory signature.
# (Verified against the FF-trailer factory signature at entry 0x11E/0x11F and the
# per-record 0xFF markers; 236 of 0x6000 entries carry battery data.)
#
# Output = one 16-bit word per line, hex, 0x6000 words, in $readmemh index order
# (line k -> nvram[k]). Identical file format to the maindata/gfx hex the wolf TBs
# already $readmemh (make_maindata_hex.py).
#
# Usage:  python sim/make_cmos_hex.py <nvram.warm.bak> <out_hex>
import sys

CMOS_WORDS = 0x6000   # wolf_mem.sv:90 CMOS_WORDS

def main():
    src, out = sys.argv[1], sys.argv[2]
    data = open(src, "rb").read()
    assert len(data) == CMOS_WORDS * 2, \
        f"nvram size {len(data):#x} != {CMOS_WORDS*2:#x} (0x6000 uint16 LE entries)"
    # entries are byte-valued: every high byte must be 0, else the packing model
    # is wrong and the seed would be garbage — fail loudly rather than paper over.
    bad = [i for i in range(CMOS_WORDS) if data[2*i+1] != 0]
    assert not bad, f"{len(bad)} entries have a nonzero high byte (first @0x{bad[0]:X}) — not byte-valued"
    with open(out, "w", newline="\n") as f:
        for i in range(CMOS_WORDS):
            f.write(f"{data[2*i] & 0xff:04x}\n")   # {8'h00, low_byte(entry i)}
    print(f"wrote {out}: {CMOS_WORDS:#x} words ({CMOS_WORDS} = 0x{CMOS_WORDS:x})")
    nz = sum(1 for i in range(CMOS_WORDS) if data[2*i] != 0)
    print(f"  {nz} nonzero CMOS entries (battery state)")
    # echo the factory-signature trailer entries (warm image should hold the
    # per-record FF-marker + checksum trailer; entry 0x11E/0x11F etc.).
    for bi in (0x11D, 0x11E, 0x11F, 0x1A0, 0x1A7, 0x1A8, 0x1A9):
        print(f"  nvram[0x{bi:03X}] = {data[2*bi] & 0xff:02X}")

if __name__ == "__main__":
    main()
