#!/usr/bin/env python3
"""Turn a validated MAME HUD capture into RTL golden-diff stimulus.

MAME never exhibits the HUD flash -- it is the behavioral ground truth, so its
captured RGB is the GOLDEN reference, not the reproduction.  The flash lives in
our scanout path, so the failing regression must run wolf_video against the real
framebuffer/palette contents and diff its emitted pixels against MAME's.

This tool emits, per fully-validated capture frame:
    <out>/f<NNN>_vram.hex    framebuffer words (full 0x80000 space, sparse fill)
    <out>/f<NNN>_pal.hex     palette words (32768 entries)
    <out>/f<NNN>_expect.txt   MAME RGB, one line per HUD row: "<y> <RRGGBB>*"
    <out>/frames.txt          per-frame meta: <frame> <row0> <col0> <nrows>

Only frames the capture proved reproduce MAME's own scanout (best_pct >= 99) are
emitted; anything else is not a golden reference and is skipped with a note.

Usage:
    python gen_wolf_hud_golden.py <capture.txt> <outdir>
"""

import sys
import os
import collections

FB_WORDS = 0x80000
PAL_ENTRIES = 32768


def parse(path):
    frames = collections.OrderedDict()
    val = {}

    def rec(f):
        if f not in frames:
            frames[f] = {"pal": {}, "screen": {}, "vrow": {}}
        return frames[f]

    with open(path) as fh:
        for line in fh:
            p = line.split()
            if not p:
                continue
            if p[0] == "FRAME":
                rec(int(p[1]))
            elif p[0] == "VROW":
                rec(int(p[1]))["vrow"][int(p[2])] = [int(v, 16) for v in p[3:]]
            elif p[0] == "PALETTE":
                pal = rec(int(p[1]))["pal"]
                for kv in p[2:]:
                    i, v = kv.split(":")
                    pal[int(i, 16)] = int(v, 16)
            elif p[0] == "SCREEN":
                rec(int(p[1]))["screen"][int(p[2])] = [int(v, 16) for v in p[3:]]
            elif p[0] == "VALIDATE":
                val[int(p[1])] = dict(kv.split("=", 1) for kv in p[2:])
    return frames, val


def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    cap, outdir = argv[1], argv[2]
    frames, val = parse(cap)
    os.makedirs(outdir, exist_ok=True)

    good, skipped = [], []
    for f in frames:
        v = val.get(f)
        if v and float(v.get("best_pct", 0)) >= 99.0:
            good.append(f)
        else:
            skipped.append((f, v.get("best_pct", "?") if v else "?"))

    if not good:
        print("ERROR: no fully-validated frames in this capture; "
              "nothing here is a golden reference.")
        return 1

    meta = []
    for f in good:
        rec = frames[f]
        v = val[f]
        row0, col0 = int(v["best_row0"]), int(v["best_col0"])
        rows = sorted(rec["screen"])

        vram = [0] * FB_WORDS
        for vrow, ent in rec["vrow"].items():
            base = (vrow << 9) & 0x3FE00
            for i, e in enumerate(ent):
                if base + i < FB_WORDS:
                    vram[base + i] = e
        with open(f"{outdir}/f{f}_vram.hex", "w", newline="\n") as fh:
            fh.write("\n".join(f"{w:04X}" for w in vram) + "\n")

        pal = [0] * PAL_ENTRIES
        for i, w in rec["pal"].items():
            if i < PAL_ENTRIES:
                pal[i] = w
        with open(f"{outdir}/f{f}_pal.hex", "w", newline="\n") as fh:
            fh.write("\n".join(f"{w:04X}" for w in pal) + "\n")

        with open(f"{outdir}/f{f}_expect.txt", "w", newline="\n") as fh:
            for y in rows:
                px = " ".join(f"{c:06X}" for c in rec["screen"][y])
                fh.write(f"{y} {px}\n")

        meta.append((f, row0, col0, len(rows)))

    with open(f"{outdir}/frames.txt", "w", newline="\n") as fh:
        for f, row0, col0, n in meta:
            fh.write(f"{f} {row0} {col0} {n}\n")

    print(f"wrote {len(good)} validated frames to {outdir}")
    for f, row0, col0, n in meta:
        print(f"  frame {f}: row0={row0} col0={col0} rows={n}")
    if skipped:
        print(f"skipped {len(skipped)} unvalidated frames "
              f"(not golden): {[f'{f}@{p}%' for f, p in skipped[:8]]}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
