#!/usr/bin/env bash
# Discriminating gate for the sprite-load page-repeat seen on the cabinet.
# The captured Motaro frame must miss one native frame with the reuse cache
# disabled, then finish byte-exact inside that same deadline with it enabled.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
GFX="${GFX:-sim/build/umk3_gfx.hex}"
TRACE="sim/traces/umk3_motaro_real_frame_regs.txt"
B="sim/build/motaro_cache_deadline"
mkdir -p "$B"

test -f "$GFX" || {
  echo "$GFX missing; generate the UMK3 graphics hex before this gate"
  exit 1
}

SRC=(
  rtl/pkg/wolf_pkg.sv
  rtl/wolf/wolf_dma.sv
  rtl/yunit/vram_sdram.sv
  rtl/yunit/vram_sdram_top.sv
  rtl/sdram/stv_vram_ddr_agent.sv
  rtl/sdram/stv_vram_ddr_top.sv
  rtl/sdram/wolf_gfx_ddr_top.sv
  rtl/sdram/wolf_ddr3_arb.sv
  sim/ddr3_avalon_model.sv
  sim/tb_wolf_peak_fight_budget.sv
)

COMMON=(
  "+TRACE=$TRACE" "+GFX=$GFX" +RANK=1
  +EXPECT_BLITS=299 +EXPECT_WRITES=136001
  +EXPECT_HASH=500e91d0ff8ae88f
  +TIMED_REPLAY=1 +CBUSY=2 +CRLAT=45 +CGAP=7
  +ALLOW_TIMER_OVERRUN=1
)

"$IVERILOG" -g2012 -s tb_wolf_peak_fight_budget \
  -o "$B/cache.vvp" "${SRC[@]}"
"$IVERILOG" -g2012 -s tb_wolf_peak_fight_budget \
  -Ptb_wolf_peak_fight_budget.GFX_L2_ENABLE=0 \
  -o "$B/no_cache.vvp" "${SRC[@]}"

"$VVP" "$B/cache.vvp" "${COMMON[@]}" | tee "$B/cache.log"
"$VVP" "$B/no_cache.vvp" "${COMMON[@]}" | tee "$B/no_cache.log"

ORACLE='WRITE ORACLE: blits=299 writes=136001 fnv64=500e91d0ff8ae88f'
grep -q "^$ORACLE$" "$B/cache.log"
grep -q "^$ORACLE$" "$B/no_cache.log"
grep -Eq '^GFX L2: hits=[1-9][0-9]* fills=[1-9][0-9]*$' "$B/cache.log"
grep -q '^GFX L2: hits=0 fills=0$' "$B/no_cache.log"
grep -q '^PASS: live-fight frame retires inside the production frame budget$' "$B/cache.log"
grep -q '^RESULT: FAIL -- live-fight render missed one-frame deadline by ' "$B/no_cache.log"

CACHE_MARGIN="$(sed -n 's/^DEADLINE:.* margin=\(-\{0,1\}[0-9][0-9]*\) cycles$/\1/p' "$B/cache.log")"
NO_CACHE_MARGIN="$(sed -n 's/^DEADLINE:.* margin=\(-\{0,1\}[0-9][0-9]*\) cycles$/\1/p' "$B/no_cache.log")"
test -n "$CACHE_MARGIN" && test "$CACHE_MARGIN" -gt 0
test -n "$NO_CACHE_MARGIN" && test "$NO_CACHE_MARGIN" -lt 0

echo "PASS: Motaro cache deadline A/B (cache margin=$CACHE_MARGIN; mutation margin=$NO_CACHE_MARGIN)"
