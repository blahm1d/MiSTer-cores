#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAME="${MAME:-C:/tools/mame/mame.exe}"
ROMS="${UMK3_ROMS:-D:/deck/fpga/umk3/roms}"
OUT="$ROOT/sim/build/umk3_select_timed.txt"
NVDIR="$(mktemp -d "$ROOT/sim/build/umk3_select_timed_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
rm -f "$OUT"
export UMK3_SELECT_TIMED_OUT="$OUT"
"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 12 -autoboot_delay 0
"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 30 -autoboot_delay 0 \
  -nothrottle -autoboot_script "$ROOT/sim/capture_umk3_select_timed.lua"
grep -q '^DONE ' "$OUT"
head -n 3 "$OUT"
tail -n 3 "$OUT"
