#!/usr/bin/env python3
"""Build a production-RTL replay and final-VRAM oracle for one MAME frame.

Unlike the startup oracle, the predictive gameplay capture is a flat stream
of ``BLIT phase=... frame=...`` records.  Preserve that recorded GO order so
the generated trace exercises the same clear/background/object composition
that MAME performed for the selected frame.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import wolf_dma_model as model
from analyze_nbahangt_dma_ledger import parse_job
from gen_nbahangt_startup_frame_replay import (
    FNV_OFFSET,
    FNV_PRIME,
    MASK64,
    load_register_writes,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--frame", type=int, required=True)
    parser.add_argument("--gfx", type=Path, required=True)
    parser.add_argument("--trace-out", type=Path, required=True)
    parser.add_argument("--oracle-out", type=Path, required=True)
    parser.add_argument("--vram-out", type=Path, required=True)
    args = parser.parse_args()

    jobs = []
    with args.events.open(encoding="ascii") as source:
        for raw in source:
            job = parse_job(raw.rstrip("\n"))
            if job is not None and job.frame == args.frame:
                jobs.append(job)
    if not jobs:
        raise SystemExit(f"no DMA jobs captured for frame {args.frame}")

    gfx = args.gfx.read_bytes()
    model.GFX_SIZE = len(gfx)
    model._GFX = gfx

    args.trace_out.parent.mkdir(parents=True, exist_ok=True)
    trace_lines: list[str] = []
    oracle_lines: list[str] = []
    final_vram = [0] * 0x80000
    fnv = FNV_OFFSET
    pages = set()
    backdrop_jobs = []
    for index, job in enumerate(jobs, 1):
        regs = job.regs
        trace_lines.append(
            f"BLIT 1 {args.frame} {index} "
            + " ".join(f"{word:04X}" for word in regs)
        )
        pages.add((regs[5] >> 8) & 1)
        if job.source == 0x001F509F:
            backdrop_jobs.append(index)
        lines = model.run_case(load_register_writes(regs))
        oracle_lines.extend(lines)
        for line in lines:
            addr_text, data_text = line.split()
            addr = int(addr_text, 16)
            data = int(data_text, 16)
            final_vram[addr] = data
            token = (addr << 16) | data
            fnv = ((fnv ^ token) * FNV_PRIME) & MASK64

    args.trace_out.write_text(
        "\n".join(trace_lines) + "\n", encoding="ascii", newline="\n"
    )
    args.oracle_out.write_text(
        "\n".join(oracle_lines) + "\n", encoding="ascii", newline="\n"
    )
    args.vram_out.write_text(
        "\n".join(f"{word:04X}" for word in final_vram) + "\n",
        encoding="ascii",
        newline="\n",
    )
    print(
        f"HANGTIME_GAMEPLAY_FRAME frame={args.frame} jobs={len(jobs)} "
        f"writes={len(oracle_lines)} fnv64={fnv:016X} "
        f"pages={','.join(str(page) for page in sorted(pages))} "
        f"backdrop_jobs={','.join(str(index) for index in backdrop_jobs)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
