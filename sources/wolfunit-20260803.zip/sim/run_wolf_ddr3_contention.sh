#!/usr/bin/env bash
# run_wolf_ddr3_contention.sh — ARB-UNDER-CONCURRENT-LOAD gate (iverilog).
# The cab's fuzzy-snow + periodic-black-frame symptom appeared on the first build where
# VRAM (stv_vram_ddr_top) and GFX (wolf_gfx_ddr_top) share the one HPS DDR3 port through
# wolf_ddr3_arb — the arb had never been exercised with the REAL subsystems under
# concurrent, sustained load. Two runs, both must PASS:
#   CONTENTION : A = real scanout row-bursts + blitter RMW writes + CPU field ops,
#                B = real wolf_dma-cadence gfx byte reads, ~10 frames of wolf timing.
#   CONTROL    : same, B idle (+nogfx) — the A-side-only latency baseline.
# Compare the two [stat] blocks for the contention-added latency.
#   FRAMES=N ./run_wolf_ddr3_contention.sh   (default 10)
set -e
cd "$(dirname "$0")/.."
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
B="sim/build/ddr3_contention"
mkdir -p "$B"
FRAMES=${FRAMES:-10}

# The repo is under active parallel development — record EXACTLY which RTL this gate ran
# against (a mid-session rewrite of wolf_gfx_ddr_top was caught this way once already).
echo "== DUT snapshot (git hash-object) ==" | tee "$B/rtl_snapshot.txt"
for f in rtl/sdram/stv_vram_ddr_agent.sv rtl/sdram/stv_vram_ddr_top.sv \
         rtl/sdram/wolf_gfx_ddr_top.sv rtl/sdram/wolf_ddr3_arb.sv \
         rtl/yunit/vram_sdram.sv rtl/yunit/vram_sdram_top.sv sim/ddr3_avalon_model.sv; do
  echo "$(git hash-object "$f")  $f" | tee -a "$B/rtl_snapshot.txt"
done

"$IVERILOG" -g2012 -o "$B/tb.vvp" \
  rtl/yunit/vram_sdram.sv \
  rtl/yunit/vram_sdram_top.sv \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/stv_vram_ddr_top.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv \
  rtl/sdram/wolf_ddr3_arb.sv \
  sim/ddr3_avalon_model.sv \
  sim/tb_wolf_ddr3_contention.sv

echo "== CONTENTION run (A=VRAM scanout+RMW, B=GFX byte reads), frames=$FRAMES =="
"$VVP" "$B/tb.vvp" +frames=$FRAMES | tee "$B/contention.log" | grep -E "RESULT|FAIL|WARN|\[stat\]|\[tb\]|\[verdict\]"
echo
echo "== CONTROL run (B idle), frames=$FRAMES =="
"$VVP" "$B/tb.vvp" +frames=$FRAMES +nogfx | tee "$B/control.log" | grep -E "RESULT|FAIL|WARN|\[stat\]|\[tb\]|\[verdict\]"
echo

grep -q "RESULT: PASS" "$B/contention.log" || { echo "GATE: FAIL (contention run)"; exit 1; }
grep -q "RESULT: PASS" "$B/control.log"    || { echo "GATE: FAIL (control run)"; exit 1; }
echo "GATE: BOTH RUNS PASS (logs: $B/contention.log, $B/control.log)"
