#!/usr/bin/env bash
# Full Open Ice frame-1783 assembly/DMA/page oracle.
set -e
TB=tb_wolf_hangtime_irq_replay
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
RUN="$ROOT/sim/build/wolf_hangtime_irq_replay"

. "$(dirname "$0")/questa_lock.sh"

find_bin() {
  local name="$1"; local env="$2"
  if [ -n "$env" ] && [ -x "$env" ]; then echo "$env"; return; fi
  for d in /c/altera_pro/*/questa_fse/win64 /c/intelFPGA_pro/*/questa_fse/win64 \
           /c/altera/*/questa_fse/win64 /c/intelFPGA/*/questa_fse/win64; do
    [ -x "$d/$name.exe" ] && { echo "$d/$name"; return; }
    [ -x "$d/$name" ] && { echo "$d/$name"; return; }
  done
  command -v "$name" 2>/dev/null || true
}

VLIB="$(find_bin vlib "$VLIB")"
VLOG="$(find_bin vlog "$VLOG")"
VSIM="$(find_bin vsim "$VSIM")"
if [ -z "$VLOG" ] || [ -z "$VSIM" ]; then
  echo "ERROR: Questa FPGA Starter Edition not found"; exit 1
fi
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\\altera\\LR-175212_License.dat;C:\\altera\\LR-175213_License.dat}"
export SALT_LICENSE_SERVER
trap questa_release EXIT
questa_acquire || { echo "BLOCKED: Questa license slot unavailable"; exit 75; }

rm -rf "$RUN"
mkdir -p "$RUN"
cd "$RUN"
"$VLIB" work >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv"
       "$ROOT/rtl/yunit/yunit_mem_cdc.sv"
       "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv"
       "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_memsys.sv"
       "$ROOT/sim/$TB.sv" )

"$VLOG" -sv -quiet -svinputport=var "${SRC[@]}"
LOG="$ROOT/sim/build/${TB}.vsim.log"
set +e
"$VSIM" -c -quiet -suppress 7061 -do "run -all; quit" "$TB" "$@" 2>&1 | tee "$LOG" | \
  grep -iE "RESULT|FAIL|OPENICE_|Error"
set -e
questa_check_result "$LOG" "RESULT PASS"
