#!/usr/bin/env bash
# P0028 gate: reset must land with ce_cpu held LOW. iverilog only (no licence).
#
# This is the gate tools/wolf_ce_cadence_gate.py CANNOT be: that one reads only
# rtl/wolf/wolf_top.sv + rtl/sdram.sdc, so it is structurally blind to the core.
# This one drives the core leaf modules directly.
#
#   ./sim/run_tms34010_reset_ce_low_gate.sh          -> must PASS on patched RTL
#   REVERT=1 ./sim/run_tms34010_reset_ce_low_gate.sh -> must FAIL on HEAD RTL
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IV="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
OUT="$ROOT/sim/build/reset_ce_low"; rm -rf "$OUT"; mkdir -p "$OUT"

PC="$ROOT/rtl/tms34010/rtl/core/tms34010_pc.sv"
ST="$ROOT/rtl/tms34010/rtl/core/tms34010_status_reg.sv"
if [ -n "$REVERT" ]; then
  ( cd "$ROOT" && git show HEAD:rtl/tms34010/rtl/core/tms34010_pc.sv )         > "$OUT/tms34010_pc.sv"
  ( cd "$ROOT" && git show HEAD:rtl/tms34010/rtl/core/tms34010_status_reg.sv ) > "$OUT/tms34010_status_reg.sv"
  PC="$OUT/tms34010_pc.sv"; ST="$OUT/tms34010_status_reg.sv"
  echo "(REVERT mode: HEAD sources -- this run is EXPECTED to fail)"
fi

"$IV" -g2012 -o "$OUT/gate.vvp" \
  "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" "$PC" "$ST" \
  "$ROOT/sim/tb_tms34010_reset_ce_low.sv"

LOG="$OUT/gate.log"
"$VVP" "$OUT/gate.vvp" 2>&1 | tee "$LOG"
grep -q "^RESULT PASS" "$LOG" || { echo "GATE FAILED"; exit 1; }
echo "GATE PASSED"
