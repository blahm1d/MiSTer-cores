#!/usr/bin/env bash
# Exact-output frame replay through the production outer DCS arbiter. The
# working music trace measured about 205 DCS cache fills per video frame; a
# 1500-cycle gap drives roughly four times that rate as release headroom.
set -euo pipefail

cd "$(dirname "$0")/.."
IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
OUT="sim/build/tb_wolf_peak_fight_dcs_contention.vvp"
LOG="${LOG:-sim/build/tb_wolf_peak_fight_dcs_contention.log}"
TRACE="${TRACE:-sim/traces/umk3_peak_attract_regs.txt}"
RANK="${RANK:-1}"

"$IVERILOG" -g2012 -s tb_wolf_peak_fight_budget -o "$OUT" \
  rtl/pkg/wolf_pkg.sv \
  rtl/wolf/wolf_dma.sv \
  rtl/yunit/vram_sdram.sv \
  rtl/yunit/vram_sdram_top.sv \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/stv_vram_ddr_top.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv \
  rtl/sdram/wolf_ddr3_arb.sv \
  sim/ddr3_avalon_model.sv \
  sim/tb_wolf_peak_fight_budget.sv

"$VVP" "$OUT" "+TRACE=$TRACE" "+RANK=$RANK" +TIMED_REPLAY=1 \
  +CBUSY=2 +CRLAT=30 +CGAP=7 +DCS_STRESS=1 +DCS_GAP=1500 \
  +ALLOW_TIMER_OVERRUN=1 +EXPECT_BLITS=198 +EXPECT_WRITES=150546 \
  +EXPECT_HASH=0bc2983e86e3a0ea | tee "$LOG"

grep -q '^DCS CONTENTION: enabled=1 gap=1500 completed_reads=' "$LOG"
grep -Eq '^QUEUE TELEMETRY: highwater=[0-9]+ overflow=0' "$LOG"
grep -q '^WRITE ORACLE: blits=198 writes=150546 fnv64=0bc2983e86e3a0ea' "$LOG"
grep -q '^PASS: live-fight frame retires' "$LOG"
! grep -q '^RESULT: FAIL' "$LOG"
