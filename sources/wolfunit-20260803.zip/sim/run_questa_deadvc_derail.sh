#!/usr/bin/env bash
# VERIFIER: run the boot-follow TB with a DEAD-VCOUNT mutant io_regs (BUG-2 reverted)
# to see if reverting the live-VCOUNT fix breaks the boot (hang/diverge) in-window.
set -e
TB="tb_wolf_boot_derail"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
MUT="$1"   # path to mutant io_regs
. "$(dirname "$0")/questa_lock.sh"
find_bin(){ local n="$1" e="$2"; if [ -n "$e" ]&&[ -x "$e" ]; then echo "$e"; return; fi
  for d in /c/altera_pro/*/questa_fse/win64 /c/intelFPGA_pro/*/questa_fse/win64 /c/altera/*/questa_fse/win64 /c/intelFPGA/*/questa_fse/win64; do
    [ -x "$d/$n.exe" ]&&{ echo "$d/$n"; return; }; [ -x "$d/$n" ]&&{ echo "$d/$n"; return; }; done
  local p; p="$(command -v "$n" 2>/dev/null||true)"; case "$p" in *modelsim_ase*) p="";; esac; [ -n "$p" ]&&echo "$p"; }
VLIB="$(find_bin vlib "$VLIB")"; VLOG="$(find_bin vlog "$VLOG")"; VSIM="$(find_bin vsim "$VSIM")"
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\altera\LR-175212_License.dat;C:\altera\LR-175213_License.dat}"; export SALT_LICENSE_SERVER
trap questa_release EXIT
questa_acquire || { echo "BLOCKED"; exit 75; }
cd "$ROOT/sim"; rm -rf work; "$VLIB" work >/dev/null
SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' ! -name 'tms34010_io_regs.sv' | sort)
SRC+=( "$MUT" )   # dead-VCOUNT mutant io_regs
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv" "$ROOT/rtl/wolf/ram_sdram.sv" "$ROOT/sim/sdram_model.sv" \
       "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv" "$ROOT/rtl/wolf/wolf_pic.sv" \
       "$ROOT/rtl/wolf/wolf_memsys.sv" "$ROOT/sim/$TB.sv" )
echo "compiling ${#SRC[@]} sources (DEAD-VCOUNT mutant)..."
"$VLOG" -sv -quiet -svinputport=var "${SRC[@]}"
echo "simulating $TB (dead-vcount, MAXCYC=6000000)..."
LOG="$ROOT/sim/build/${TB}.deadvc.vsim.log"; mkdir -p "$ROOT/sim/build"
set +e
"$VSIM" -c -quiet -do "run -all; quit" "$TB" +MAXCYC=6000000 2>&1 | tee "$LOG" | grep -iE "PASS|FAIL|FRONTIER|DERAIL|DIVERGE|----|retired_pcs|Error|license"
set -e
questa_check_result "$LOG" "PASS" || echo "(non-PASS exit expected if BUG-2 breaks boot)"
