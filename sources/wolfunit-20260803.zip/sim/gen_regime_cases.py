#!/usr/bin/env python3
"""Turn MEASURED blitter regimes into golden cross-diff cases.

sim/run_wolf_dma_regime.sh taps all seven Wolf titles in MAME and histograms
every blit by (bpp, mode, skip, lrsplit, yflip, scaled, endskip). This reads
those histograms, subtracts what the existing matrix already covers, and emits
generator lines for the uncovered regimes ordered by real-world frequency.

Why: the 119 hand-authored cases covered SIX of the 87 regimes the ROMs issue.
91.8% of all real blits sat in regimes the cross-diff had never exercised. The
black ice bug was one visible symptom of that.
"""
import re, glob, json, collections, os, sys

ROOT = os.path.dirname(os.path.abspath(__file__))


def load_observed():
    obs = collections.Counter()
    per = collections.defaultdict(set)
    wid = {}
    for f in glob.glob(os.path.join(ROOT, "build", "regimes", "*.regimes.txt")):
        title = os.path.basename(f).split(".")[0]
        for ln in open(f, encoding="utf-8", errors="ignore"):
            ln = ln.strip()
            m = re.match(r"REGIME (.+) count=(\d+)", ln)
            if m:
                obs[m.group(1)] += int(m.group(2))
                per[m.group(1)].add(title)
            m2 = re.match(r"WIDEST bpp=(\d+) endskip=(\S+) w=(\d+) h=(\d+) endskip=(\d+)", ln)
            if m2:
                key = (int(m2.group(1)), m2.group(2))
                w = int(m2.group(3))
                if key not in wid or w > wid[key][0]:
                    wid[key] = (w, int(m2.group(4)), int(m2.group(5)))
    return obs, per, wid


def regime_of(writes):
    w = dict(writes)
    cmd = w.get(1, 0)
    lr = w.get(0, 0)
    bppf = (cmd >> 12) & 7
    bpp = 8 if bppf == 0 else bppf
    lrsplit = 1 if cmd & 0x40 else 0
    endskip = (lr >> 8) if lrsplit else lr
    sx, sy = w.get(10, 0), w.get(11, 0)
    scaled = 1 if (sx not in (0, 0x100) or sy not in (0, 0x100)) else 0
    return "bpp=%d mode=%02X skip=%d lrsplit=%d yflip=%d scaled=%d endskip=%s" % (
        bpp, cmd & 0x1F, 1 if cmd & 0x80 else 0, lrsplit,
        1 if cmd & 0x20 else 0, scaled, "0" if endskip == 0 else "NONZERO")


def main():
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else 34
    obs, per, wid = load_observed()
    if not obs:
        print("TEST-INVALID: no regime captures found -- run "
              "sim/run_wolf_dma_regime.sh first. NOT a negative result.")
        return 2
    cases = json.load(open(os.path.join(ROOT, "wolf_dma_vectors.json")))
    covered = {regime_of(c["writes"]) for c in cases}
    holes = [(k, v) for k, v in obs.most_common() if k not in covered]

    total = sum(obs.values())
    unc = sum(v for _, v in holes)
    print("observed regimes: %d | covered by matrix: %d | UNCOVERED: %d"
          % (len(obs), len(obs) - len(holes), len(holes)))
    print("blits in uncovered regimes: %d of %d (%.1f%%)" % (unc, total, 100.0 * unc / total))

    out = []
    for key, _cnt in holes[:limit]:
        d = dict(p.split("=") for p in key.split())
        bpp = int(d["bpp"]); mode = int(d["mode"], 16)
        skip = int(d["skip"]); lrsplit = int(d["lrsplit"])
        yflip = int(d["yflip"]); scaled = int(d["scaled"])
        has_es = d["endskip"] != "0"
        W, H, ES = wid.get((bpp, "NONZERO" if has_es else "0"), (120, 6, 0))
        W = min(max(W, 16), 860)
        H = min(max(H, 2), 6)
        # Extents come from the WIDEST measured blit in this (bpp, endskip)
        # class: the ice defect needed w=860 AND endskip!=0 TOGETHER, so a
        # narrow case in the right regime would still have missed it.
        lrskip = (ES if ES else 40) if has_es else 0
        if lrsplit and lrskip:
            lrskip = ((lrskip & 0xFF) << 8) | 0x02
        name = "rom_b%d_m%02X_s%d_l%d_y%d_c%d_e%d" % (
            bpp, mode, skip, lrsplit, yflip, scaled, 1 if has_es else 0)
        sc = "scalex=0x80, scaley=0x80, " if scaled else ""
        out.append(
            '    cases.append(case("%s", mode=%d, bpp=%d, skip=%d, lrsplit=%d,\n'
            '                      yflip=%d, x=8, y=4, w=%d, h=%d, lrskip=%d,\n'
            '                      %sofflo=0x0010, pal=0x0700))'
            % (name, mode, 0 if bpp == 8 else bpp, skip, lrsplit, yflip, W, H, lrskip, sc))

    open(os.path.join(ROOT, "regime_cases.gen.txt"), "w", newline="\n").write("\n".join(out) + "\n")
    print("wrote %d generator lines -> sim/regime_cases.gen.txt" % len(out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
