#!/usr/bin/env python3
"""Validate the assembly-visible NBA Hangtime DMA interrupt contract.

Input is produced by capture_nbahangt_first_dma.lua.  This checker deliberately
tests software-visible order and state, not pixels:

* dma_irq's six long writes appear as logical registers
  10,11,8,9,6,7,4,5,2,3,0,1;
* the executing PCs map to NDSP1.ASM lines 158-164;
* COMMAND is last and has DGO set;
* the first ten-command drain has B13 = 0,8,7,...,0, demonstrating that each
  completion interrupt launches exactly the next queued element.
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from pathlib import Path


FIELD_RE = re.compile(r"([A-Z0-9_]+)=([0-9A-F]+)")
EXPECTED_REGS = [10, 11, 8, 9, 6, 7, 4, 5, 2, 3, 0, 1]
EXPECTED_PCS = [
    0xFF800010, 0xFF800010,
    0xFF800020, 0xFF800020,
    0xFF800030, 0xFF800030,
    0xFF800040, 0xFF800040,
    0xFF800060, 0xFF800060,
    0xFF800070, 0xFF800070,
]
EXPECTED_B13_DRAIN = [0, 8, 7, 6, 5, 4, 3, 2, 1, 0]


@dataclass(frozen=True)
class Write:
    line_number: int
    pc: int
    b13: int
    reg: int
    data: int


def fields(line: str) -> dict[str, int]:
    return {name: int(value, 16) for name, value in FIELD_RE.findall(line)}


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trace", type=Path)
    args = parser.parse_args()

    writes: list[Write] = []
    bursts: list[list[Write]] = []
    gos: list[dict[str, int]] = []

    for line_number, raw in enumerate(args.trace.read_text(encoding="ascii").splitlines(), 1):
        if raw.startswith("W "):
            f = fields(raw)
            reg_match = re.search(r"\bREG=(\d+)\b", raw)
            if reg_match is None:
                fail(f"write at line {line_number} has no logical REG field")
            writes.append(Write(
                line_number, f["PC"], f["B13"], int(reg_match.group(1)), f["DATA"]
            ))
        elif raw.startswith("GO "):
            f = fields(raw)
            gos.append(f)
            if len(writes) < 12:
                fail(f"GO at line {line_number} has fewer than 12 preceding writes")
            bursts.append(writes[-12:])

    if len(gos) < 10:
        fail(f"expected at least one ten-command queue drain, found {len(gos)} GO records")

    for index, burst in enumerate(bursts, 1):
        got_regs = [write.reg for write in burst]
        got_pcs = [write.pc for write in burst]
        if got_regs != EXPECTED_REGS:
            fail(f"GO {index}: register order {got_regs}, expected {EXPECTED_REGS}")
        if got_pcs != EXPECTED_PCS:
            fail(f"GO {index}: PC order {[hex(pc) for pc in got_pcs]}")
        if not (burst[-1].data & 0x8000):
            fail(f"GO {index}: final COMMAND write lacks DGO: {burst[-1].data:04X}")

    first_b13 = [entry[0].b13 & 0xFFFFFFFF for entry in bursts[:10]]
    if first_b13 != EXPECTED_B13_DRAIN:
        fail(f"first queue B13 sequence {first_b13}, expected {EXPECTED_B13_DRAIN}")

    print(
        "PASS nbahangt DMA contract: "
        f"gos={len(gos)} bursts={len(bursts)} "
        "order=10,11,8,9,6,7,4,5,2,3,0,1 "
        "pc=FF800010..FF800070 b13=0,8..0"
    )


if __name__ == "__main__":
    main()
