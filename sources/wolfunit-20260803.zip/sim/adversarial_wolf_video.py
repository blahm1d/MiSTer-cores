#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
adversarial_wolf_video.py -- inject deliberate GOSPEL-MISREADINGS into the golden
model's per-pixel algorithm and confirm the vector matrix KILLS each (i.e. at least
one named case diverges from the gospel-faithful golden). This proves the matrix
has discriminating power for each semantic decision cited from midtunit_v.cpp /
midwunit.cpp -- a mutation that survived would mean an untested decision.

We reimplement the gospel-faithful golden here (the ORACLE), then for each mutation
recompute and require at least one case to differ. Named sentinel cases are asserted
to be among the killers so the KILL is attributed to the intended vector.

Gospel cited per mutation:
  M1 col-mask 0x1ff->0xfff  : midtunit_v.cpp:854  src[coladdr++ & 0x1ff]
  M2 drop &0x7fff (bit15)   : midtunit_v.cpp:854  ... & 0x7fff
  M3 row-mask 0x3fe00->none : midtunit_v.cpp:848  (rowaddr<<9) & 0x3fe00
  M4 pal5bit zero-extend    : midwunit.cpp:643 xRGB_555 + emupal pal5bit replicate
  M5 vram-as-RGB direct     : midwunit.cpp:122 IND16 idx -> palette[idx] (indirection)
"""
import sys, json

def rep5to8(v): return ((v & 0x1f) << 3) | ((v & 0x1f) >> 2)

def golden(case, mut=None):
    vram = dict((a, v) for a, v in case["vram"])
    pal  = dict((a, v) for a, v in case["palette"])
    rowaddr = case["rowaddr"]; coladdr = case["coladdr"]; npix = case["npix"]

    ROWMASK = 0x3fe00 if mut != "M3" else 0x7ffff        # M3: drop row mask
    COLMASK = 0x1ff   if mut != "M1" else 0xfff          # M1: wrong col mask
    IDXMASK = 0x7fff  if mut != "M2" else 0xffff         # M2: bit15 leaks

    base = (rowaddr << 9) & ROWMASK
    ca = coladdr << 1
    out = []
    for i in range(npix):
        idx = vram.get(base + ((ca + i) & COLMASK), 0) & IDXMASK
        if mut == "M5":
            c = idx & 0x7fff                              # M5: vram word IS the color
        else:
            c = pal.get(idx & 0x7fff, 0)                  # gospel: index -> palette
        if mut == "M4":                                   # M4: zero-extend not replicate
            r = ((c >> 10) & 0x1f) << 3
            g = ((c >> 5) & 0x1f) << 3
            b = (c & 0x1f) << 3
        else:
            r = rep5to8((c >> 10) & 0x1f)
            g = rep5to8((c >> 5) & 0x1f)
            b = rep5to8(c & 0x1f)
        out.append("%04X %02X%02X%02X" % (idx & 0x7fff if mut != "M2" else idx & 0xffff, r, g, b))
    return out

MUTS = {
    "M1_colmask_0xfff": ("M1", "midtunit_v.cpp:854 & 0x1ff",
                         ["col_0xFF_ca0x1FE_wrap", "npix_300_wraps", "col_0_full512"]),
    "M2_drop_0x7fff":   ("M2", "midtunit_v.cpp:854 & 0x7fff",
                         ["st_rtl_direct_index_and_mask", "vram_bit15_always_set_masked",
                          "vram_0xFFFF_to_idx7FFF"]),
    "M3_row_mask_drop": ("M3", "midtunit_v.cpp:848 & 0x3fe00",
                         ["row_0x200_masktrunc_to0", "row_0x3FFF_max_masked",
                          "rowmasktrunc_colwrap"]),
    "M4_pal5_zeroext":  ("M4", "midwunit.cpp:643 xRGB_555 pal5bit replicate",
                         ["pal_white_saturated", "rep5to8_red_ramp", "pal_bit15_set_ignored"]),
    "M5_vram_as_rgb":   ("M5", "midwunit.cpp:122 palette indirection",
                         ["st_model_case1_copy_row0", "pal_white_saturated", "vram_all_zero_to_pal0"]),
}

def main(argv):
    cases = json.load(open(argv[1] if len(argv) > 1 else "wolf_video_vectors.json"))
    by_name = {c["name"]: c for c in cases}
    allpass = True
    for label, (mut, cite, sentinels) in MUTS.items():
        killers = []
        for c in cases:
            base_out = golden(c, None)
            mut_out  = golden(c, mut)
            if base_out != mut_out:
                killers.append(c["name"])
        killed = len(killers) > 0
        # require at least one intended sentinel among killers
        sentinel_hit = [s for s in sentinels if s in killers]
        ok = killed and len(sentinel_hit) > 0
        allpass = allpass and ok
        print("[%s] %-28s cite=%s" % ("KILLED" if ok else "SURVIVED", label, cite))
        print("       killers: %d case(s); sentinels hit: %s"
              % (len(killers), sentinel_hit if sentinel_hit else "NONE"))
        if not ok:
            print("       !!! mutation NOT caught by an intended sentinel -> matrix gap")
    print("-" * 50)
    print("ADVERSARIAL %s (%d mutations)" % ("PASS" if allpass else "FAIL", len(MUTS)))
    return 0 if allpass else 1

if __name__ == "__main__":
    sys.exit(main(sys.argv))
