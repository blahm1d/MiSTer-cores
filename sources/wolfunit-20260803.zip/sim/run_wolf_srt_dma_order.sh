#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MS="${MS:-/c/intelFPGA_lite/17.0/modelsim_ase/win32aloem}"
WORK="$ROOT/sim/build/srt_dma_order_work"
MUTATE="${MUTATE:-0}"
mkdir -p "$WORK" "$ROOT/sim/build"
printf '0000\n' > "$ROOT/sim/build/srt2_empty_rom.hex"

cd "$WORK"
rm -rf work
"$MS/vlib.exe" work >/dev/null

DEFS=( +define+USE_SDRAM_VRAM +define+USE_DDR3_VRAM )
if [ "$MUTATE" = 1 ]; then
  DEFS+=( +define+MUTATE_SRT_DMA_ORDER )
fi

"$MS/vlog.exe" -sv -quiet -svinputport=var \
  "${DEFS[@]}" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/rtl/wolf/ram_sdram.sv" \
  "$ROOT/rtl/wolf/wolf_mem.sv" \
  "$ROOT/rtl/wolf/wolf_dma.sv" \
  "$ROOT/rtl/wolf/wolf_pic.sv" \
  "$ROOT/rtl/wolf/wolf_memsys.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_wolf_srt_dma_order.sv" \
  > compile.log 2>&1

"$MS/vsim.exe" -c -do "run -all; quit -f" work.tb_wolf_srt_dma_order \
  > sim.log 2>&1 || true
grep -E "SRT_DMA_ORDER|PASS:|Fatal:" sim.log
if [ "$MUTATE" = 1 ]; then
  grep -q "SRT acknowledged while the private DMA renderer was still busy" sim.log
else
  grep -q "^# PASS: SRT page erase stays ordered" sim.log
fi
