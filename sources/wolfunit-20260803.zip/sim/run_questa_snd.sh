#!/usr/bin/env bash
# Compile + run the Williams CVSD sound-board sim (mixed VHDL/Verilog, Questa).
#   ./run_questa_snd.sh [tb_snd_board] [+ARGS...]
set -e
TB="${1:-tb_snd_board}"; shift || true
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SND="$ROOT/rtl/sound"

# --- single-instance lock + orphan reaper + real pass/fail (nodelocked FSE) ---
. "$(dirname "$0")/questa_lock.sh"

for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -n "$VLOG" ] || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

# Acquire the single nodelocked-license slot BEFORE any vlib/vlog/vsim, and make
# sure we release it (and reap our own vsim) on ANY exit — timeout, kill, error.
trap questa_release EXIT
if ! questa_acquire; then
  echo "BLOCKED: could not acquire the Questa nodelocked license (orphan vsim?)."
  exit 75   # EX_TEMPFAIL — BLOCKED, distinct from a real test FAIL. Never a fake pass.
fi

cd "$ROOT/sim"
rm -rf work_snd; "$VLIB" work_snd >/dev/null

# jt51 (Verilog): top + everything it pulls in (hdl/*.v, no filter/deprecated).
JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)

"$VLOG" -quiet -work work_snd "${JT51[@]}" \
  "$SND/williams_cvsd/mc6809is.v" \
  "$SND/smashtv_snd_rom.sv" \
  "$ROOT/sim/$TB.sv"

"$VCOM" -2008 -quiet -work work_snd \
  "$SND/williams_cvsd/gen_ram.vhd" \
  "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" \
  "$SND/williams_cvsd/williams_cvsd_board.vhd"

echo "running $TB ..."
# Capture the FULL vsim output to a log for questa_check_result, while still
# showing the filtered lines. set +e so a vsim/grep failure does not abort
# before we inspect the log.
LOG="$ROOT/sim/build/${TB}.vsim.log"
mkdir -p "$ROOT/sim/build"
set +e
"$VSIM" -c -quiet -work work_snd -do "run -all; quit -f" "$TB" "$@" 2>&1 | tee "$LOG" | grep -vE "^# (Loading|//|\*\* Note)"
set -e

# Propagate vsim's REAL pass/fail. exit code reflects the true outcome; a
# license error / elaboration error / FAIL / missing PASS is NON-zero.
questa_check_result "$LOG" "PASS"
exit $?
