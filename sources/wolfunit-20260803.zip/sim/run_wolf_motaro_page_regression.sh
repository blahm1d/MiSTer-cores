#!/usr/bin/env bash
# run_wolf_motaro_page_regression.sh -- Motaro page-publication + early-completion
# regression.  iverilog + MAME only.  NO Quartus, NO RTL edits, NO build.
#
# Consumes REAL Motaro data (per HANDOFF-2026-07-30-motaro-flashing item 1):
#   * phase anchor  : sim/capture_umk3_motaro_flip_phase.lua  (VSBLNK/DPYADR/GO)
#   * render_busy   : the REAL captured 250-blit Motaro fight frame, replayed
#                     through the real wolf_dma + gfx-DDR + arbiter + DDR model
#                     (tb_wolf_peak_fight_budget + tb_render_busy_probe).
#
# Two independent claims, each gated:
#   A. PAGE FENCE HOLDS.  At the conservative DDR read latency the physical
#      render of the heaviest real Motaro frame still fits the native frame
#      budget, and the flip FSM commits every frame at the measured phase with
#      the double-buffer base_row alternating.  => the displayed page is never
#      published while its render is outstanding.  A mutation that stretches
#      every busy run MUST flip the flip-gate to STARVED (discrimination proof).
#   B. EARLY-COMPLETION TELEMETRY.  The CPU-visible completion cadence
#      (TIMED_IRQ_PUMP, MAME 105/32 clk/px) runs AHEAD of physical rendering,
#      by a lead that grows with DDR latency; the DMA queue high-water grows
#      with it.  Reported, not yet gated to a fix -- see the findings doc.
#
# This gate does NOT assert the >=500k conservative margin target (open work),
# and it does NOT claim the flash is fixed or that early completion is the
# proven visual cause: the page-fence result is a NEGATIVE on that theory.
set -uo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
IV=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
PY=${PY:-python}
B="sim/build"
GFX="${GFX:-$B/umk3_gfx.hex}"
# REAL Motaro (reached live via the cheat harness -- snapshot-proven Kitana vs
# Motaro, 299 GOs/frame). The earlier generic-fight proxy (motaro_frame_trace /
# umk3_motaro_flipphase, 250 GOs) is retained only for comparison.
PHASE="${PHASE:-$B/umk3_motaro_live.txt}"
FRAME_TRACE="${FRAME_TRACE:-$B/motaro_real_frame_trace.txt}"
CRLAT="${CRLAT:-30}"                 # conservative DDR read-response latency
EXPECT_HASH="${EXPECT_HASH:-500e91d0ff8ae88f}"
FAIL=0

test -f "$GFX"   || { echo "MISSING $GFX (build umk3 gfx hex first)"; exit 90; }
test -f "$PHASE" || { echo "MISSING $PHASE -- run sim/run_umk3_motaro_flip_phase.sh"; exit 90; }
test -f "$FRAME_TRACE" || { echo "MISSING $FRAME_TRACE -- run sim/run_umk3_motaro_flip_phase.sh + the frame extractor"; exit 90; }

echo "=== [A1] REAL Motaro frame render @ conservative latency $CRLAT ==="
PROBE="$B/tb_peak_rbprobe.vvp"
if [ ! -f "$PROBE" ]; then
  "$IV" -g2012 -s tb_wolf_peak_fight_budget -s tb_render_busy_probe -o "$PROBE" \
    rtl/pkg/wolf_pkg.sv rtl/wolf/wolf_dma.sv rtl/yunit/vram_sdram.sv \
    rtl/yunit/vram_sdram_top.sv rtl/sdram/stv_vram_ddr_agent.sv \
    rtl/sdram/stv_vram_ddr_top.sv rtl/sdram/wolf_gfx_ddr_top.sv \
    rtl/sdram/wolf_ddr3_arb.sv sim/ddr3_avalon_model.sv \
    sim/tb_wolf_peak_fight_budget.sv sim/tb_render_busy_probe.sv \
    2>"$B/motaro_probe_compile.log" || { echo "compile fail"; cat "$B/motaro_probe_compile.log"; exit 92; }
fi
RB="$B/rb_motaro_realframe_lat${CRLAT}.txt"
LOG="$B/motaro_page_regression.log"
"$VVP" "$PROBE" +TRACE="$FRAME_TRACE" +GFX="$GFX" +RANK=1 +TIMED_REPLAY=1 \
  +CBUSY=2 +CRLAT="$CRLAT" +CGAP=7 +RBLOG="$RB" | tee "$LOG"

# Claim A: the physical render fits the NATIVE FRAME BUDGET (the page-fence
# signal).  This is the DEADLINE margin ONLY -- NOT the composite "PASS: live-
# fight frame retires" line, which additionally requires the CPU-visible Wolf
# completion cadence (Claim B) and so is expected to be absent here.
DL=$(grep -oE '^DEADLINE: render=[0-9]+ cycles budget=[0-9]+ margin=-?[0-9]+' "$LOG" | tail -1)
DLM=$(echo "$DL" | grep -oE 'margin=-?[0-9]+' | cut -d= -f2)
echo "PAGE-FENCE[A]: $DL"
if [ -z "$DLM" ] || [ "$DLM" -le 0 ]; then
  echo "FAIL[A]: physical render did NOT fit the native frame budget at latency $CRLAT (margin=$DLM)"; FAIL=1
fi
# Determinism: the accepted-write hash is stable.
grep -q "^WRITE ORACLE: blits=299 writes=136001 fnv64=${EXPECT_HASH}\$" "$LOG" || {
  echo "FAIL[A]: write oracle drifted (expected fnv64=$EXPECT_HASH)"; FAIL=1; }
# No queue overflow (dropped work would itself corrupt the frame).
grep -Eq '^QUEUE TELEMETRY: highwater=[0-9]+ overflow=0' "$LOG" || {
  echo "FAIL[A]: DMA queue overflowed"; FAIL=1; }

# Claim B telemetry (reported, not gated): early-completion lead + queue high-water.
WT=$(grep -oE 'WOLF TIMER: pixels=[0-9]+ modeled=[0-9]+ busy=[0-9]+ margin=-?[0-9]+' "$LOG" | tail -1)
QH=$(grep -oE 'highwater=[0-9]+' "$LOG" | tail -1)
echo "TELEMETRY[B]: $WT  $QH  (negative WOLF-TIMER margin = physical behind the CPU-visible model)"

echo "=== [A2] flip FSM at the measured Motaro phase (offline FSM criterion + real render_busy) ==="
# The offline cross-check in the stim generator applies the EXACT wolf_video
# commit criterion (deadline d<=15658 ce ticks, derived in the TB header) to the
# real render_busy waveform at the measured VSBLNK phase. It is deterministic and
# fast (the RTL FSM bench is O(frame) slow on a full-frame busy run). Every frame
# must COMMIT; a single STARVED here means the page would publish stale.
STIM="$B/flipreplay_motaro_reg"
"$PY" sim/gen_wolf_flip_replay_stim.py "$PHASE" "$RB" "$STIM" > "$B/motaro_flipstim.log" 2>&1
grep -E 'frame [0-9]+ VS=' "$B/motaro_flipstim.log" | tail -12
if grep -q 'STARVED' "$B/motaro_flipstim.log"; then
  echo "FAIL[A]: a frame STARVED at the measured phase -- page WOULD publish stale"; FAIL=1
fi
NC=$(grep -c 'COMMIT' "$B/motaro_flipstim.log")
NW=$(grep -c 'frame [0-9]* VS=' "$B/motaro_flipstim.log")
echo "PAGE-FENCE[A2]: $NC/$NW measured frames commit before their flip deadline"

echo "=== [A3] discrimination: the flip FSM bench + a stretched-busy mutation ==="
# Prove the FSM bench is discriminating using the FAST latency-10 render_busy
# shape (a full-frame lat-30 busy run makes the RTL bench O(minutes)); the
# criterion is latency-independent. Anchored must not starve; mutation must.
FLIPTB="$B/tb_fliprep.vvp"
"$IV" -g2012 -o "$FLIPTB" rtl/pkg/wolf_pkg.sv rtl/wolf/wolf_video.sv \
  sim/tb_wolf_video_flip_replay.sv 2>"$B/fliprep_compile.log" || { echo "flip compile fail"; cat "$B/fliprep_compile.log"; exit 92; }
FAST="$B/flipreplay_motaro_fast"
"$PY" sim/gen_wolf_flip_replay_stim.py "$PHASE" "$B/rb_motaro_realframe_lat10.txt" "$FAST" > "$B/motaro_fast_stim.log" 2>&1 || \
  "$PY" sim/gen_wolf_flip_replay_stim.py "$PHASE" "$B/rb_motaro_rank1_lat10.txt" "$FAST" > "$B/motaro_fast_stim.log" 2>&1
"$VVP" "$FLIPTB" +dir="$FAST" +frames=12 +tag=motaro | tee "$B/motaro_flip.log"
grep -q 'VERDICT motaro: STARVED' "$B/motaro_flip.log" && { echo "FAIL[A]: flip FSM STARVED at measured phase"; FAIL=1; }
"$VVP" "$FLIPTB" +dir="$FAST" +frames=12 +mut=2000000 +tag=motaromut | tee "$B/motaro_flip_mut.log"
grep -q 'VERDICT motaromut: STARVED' "$B/motaro_flip_mut.log" || {
  echo "FAIL[A]: mutation did NOT starve -- the flip gate cannot detect a stale page"; FAIL=1; }

if [ "$FAIL" -eq 0 ]; then
  echo "PASS wolf_motaro_page_regression -- page fence holds at latency $CRLAT; early-completion lead reported (Claim B)"
else
  echo "RESULT: FAIL wolf_motaro_page_regression"
fi
exit "$FAIL"
