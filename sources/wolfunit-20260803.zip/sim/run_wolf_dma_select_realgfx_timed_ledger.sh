#!/usr/bin/env bash
# Captured select cadence through the real UMK3 graphics ROM and production
# DDR3 graphics wrapper. Defaults through the first Kitana component pair.
set -euo pipefail
cd "$(dirname "$0")/.."

IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
OUT="sim/build/tb_wolf_dma_select_realgfx_timed_ledger.vvp"
LOG="${LOG:-sim/build/tb_wolf_dma_select_realgfx_timed_ledger.log}"

test -f sim/build/umk3_select_timed.txt || {
  echo "missing sim/build/umk3_select_timed.txt; run sim/run_umk3_select_timed_capture.sh" >&2
  exit 1
}
test -f sim/build/umk3_gfx.hex || {
  echo "missing sim/build/umk3_gfx.hex; run sim/make_wolf_gfx_hex.py" >&2
  exit 1
}

"$IVERILOG" -g2012 -DREAL_GFX -s tb_wolf_dma_select_timed_ledger -o "$OUT" \
  rtl/pkg/wolf_pkg.sv rtl/wolf/wolf_dma.sv \
  rtl/sdram/stv_vram_ddr_agent.sv rtl/sdram/wolf_gfx_ddr_top.sv \
  sim/ddr3_avalon_model.sv sim/tb_wolf_dma_select_timed_ledger.sv
"$VVP" "$OUT" "+MAX_BLITS=${MAX_BLITS:-100}" "+TIMEOUT_CYCLES=${TIMEOUT_CYCLES:-12000000}" | tee "$LOG"
grep -q '^LEDGER:' "$LOG"
grep -q '^LATENCY:' "$LOG"
grep -q '^PASS:' "$LOG"
! grep -q '^FAIL:' "$LOG"
