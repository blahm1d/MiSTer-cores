#!/usr/bin/env python3
"""diff_replay_f200.py — scene-level replay diff: MAME frame-200 oracle vs RTL replay.

Inputs:
  mame-gospel/trace/replay_f200_{base,post}_{pix,pal}.hex  (0x40000 lines of %04X:
      CPU-space VRAM word reads; pix plane = two pixel low-bytes per word,
      pal plane = two palette-base high-bytes per word)
  sim/build/out_f200.txt   (fb-write log from tb_wolf_dma_ddr3_realgfx:
      "AAAAA DDDD" = local_videoram entry index + 16-bit entry {pal,pix})
  mame-gospel/trace/replay_blits.txt  (frame-200 blit register files, for attribution)

Compose: entries = base; apply fb writes in order; diff vs post entries.
Report: mismatch count, first examples, per-blit attribution by dest rect,
and PNGs (expected / got / diff-mask) for visual evidence.
"""
import sys, collections

TR = r"D:/deck/fpga/umk3/mame-gospel/trace"
BD = r"D:/deck/fpga/umk3/Arcade-UMK3_MiSTer/sim/build"

def load_plane(fn):
    return [int(l, 16) for l in open(fn)]

def entries_from_planes(pix, pal):
    ent = [0] * (len(pix) * 2)
    for i, (px, pl) in enumerate(zip(pix, pal)):
        ent[2 * i]     = ((pl & 0xFF) << 8)        | (px & 0xFF)
        ent[2 * i + 1] = (pl & 0xFF00)             | ((px >> 8) & 0xFF)
    return ent

base = entries_from_planes(load_plane(f"{TR}/replay_f200_base_pix.hex"),
                           load_plane(f"{TR}/replay_f200_base_pal.hex"))
post = entries_from_planes(load_plane(f"{TR}/replay_f200_post_pix.hex"),
                           load_plane(f"{TR}/replay_f200_post_pal.hex"))

# apply RTL fb writes
got = list(base)
writes = 0
last_writer = {}          # entry -> fb-write ordinal (for attribution)
for ln in open(f"{BD}/out_f200.txt"):
    a_s, d_s = ln.split()
    a, d = int(a_s, 16), int(d_s, 16)
    got[a] = d
    last_writer[a] = writes
    writes += 1

diffs = [a for a in range(len(post)) if got[a] != post[a]]
print(f"fb writes applied: {writes}")
print(f"entries differing from MAME post: {len(diffs)} / {len(post)}")

# how much did MAME itself change this frame? (sanity: blits actually drew)
mame_changed = sum(1 for a in range(len(post)) if post[a] != base[a])
print(f"entries MAME changed base->post: {mame_changed}")

for a in diffs[:15]:
    x, y = a & 0x1FF, a >> 9
    print(f"  entry {a:05X} (x={x:3d} y={y:3d}): base={base[a]:04X} post={post[a]:04X} got={got[a]:04X}"
          f"{'  [RTL wrote]' if a in last_writer else '  [RTL never wrote]'}")

# ---- visual evidence: expected / got / diff PNGs (pixel bytes as grayscale) ----
try:
    import zlib, struct
    def png(fn, ent, W=512, H=256, diffset=None):
        rows = b""
        for y in range(H):
            row = b"\x00"
            for x in range(W):
                v = ent[y * 512 + x] & 0xFF
                if diffset is not None:
                    row += bytes((255, 0, 0) if (y * 512 + x) in diffset else (v, v, v))
                else:
                    row += bytes((v, v, v))
            rows += row
        def chunk(t, d):
            c = t + d
            return struct.pack(">I", len(d)) + c + struct.pack(">I", zlib.crc32(c))
        hdr = struct.pack(">IIBBBBB", W, H, 8, 2, 0, 0, 0)
        open(fn, "wb").write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", hdr)
                             + chunk(b"IDAT", zlib.compress(rows)) + chunk(b"IEND", b""))
    ds = set(diffs)
    png(f"{BD}/replay_f200_expected.png", post)
    png(f"{BD}/replay_f200_got.png", got)
    png(f"{BD}/replay_f200_diff.png", got, diffset=ds)
    print("PNGs: replay_f200_expected.png / _got.png / _diff.png")
except Exception as e:
    print("png render skipped:", e)

print("PASS" if not diffs else "FAIL")
sys.exit(0 if not diffs else 1)
