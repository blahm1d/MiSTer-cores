#!/usr/bin/env python3
"""Assemble MAME's 32 MiB NBA Hangtime video region from nbahangt.zip."""

from __future__ import annotations

import sys
import zipfile
import zlib
from pathlib import Path


ZIP_PATH = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    r"D:/deck/fpga/umk3/nba-hangtime/nbahangt.zip"
)
OUT_HEX = Path("sim/build/nbahangt_gfx.hex")
OUT_BIN = Path("sim/build/nbahangt_gfx.bin")
REGION_SIZE = 0x2000000
CHIP_SIZE = 0x100000

GROUPS = [
    (0x0000000, [133, 132, 131, 130]),
    (0x0400000, [129, 128, 127, 126]),
    (0x0800000, [125, 124, 123, 122]),
    (0x0C00000, [121, 120, 119, 118]),
    # U114-U117 are unpopulated; MAME leaves 0x1000000..0x13fffff zero.
    (0x1400000, [113, 112, 111, 110]),
]
CRCS = {
    133: 0x3163FEED, 132: 0x428EAF44, 131: 0x5F7C5111, 130: 0xC7C0C514,
    129: 0xB3D0DAA0, 128: 0x3704EE69, 127: 0x4EA64D5A, 126: 0x0C5C19B7,
    125: 0x46C43D67, 124: 0xED495156, 123: 0xB48AA5DA, 122: 0xB18CD181,
    121: 0x5ACB267A, 120: 0x28E05F86, 119: 0xB4F604EA, 118: 0xA257B973,
    113: 0xD712A779, 112: 0x644E1BCA, 111: 0x10D3B768, 110: 0x8575AEB2,
}


def name(socket: int) -> str:
    return f"l1.0_nba_hangtime_u_{socket}_image_rom.u{socket}"


def main() -> None:
    region = bytearray(REGION_SIZE)
    with zipfile.ZipFile(ZIP_PATH) as archive:
        for base, sockets in GROUPS:
            for lane, socket in enumerate(sockets):
                payload = archive.read(name(socket))
                assert len(payload) == CHIP_SIZE
                assert zlib.crc32(payload) & 0xFFFFFFFF == CRCS[socket]
                region[base + lane : base + lane + 4 * CHIP_SIZE : 4] = payload

    OUT_HEX.parent.mkdir(parents=True, exist_ok=True)
    OUT_BIN.write_bytes(region)
    with OUT_HEX.open("w", encoding="ascii", newline="\n") as output:
        output.write("\n".join(f"{byte:02x}" for byte in region))
        output.write("\n")
    print(f"wrote {OUT_BIN} and {OUT_HEX}: {len(region)} bytes")


if __name__ == "__main__":
    main()
