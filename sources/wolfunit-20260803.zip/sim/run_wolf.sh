#!/usr/bin/env bash
# Run a Wolf-unit (UMK3) testbench under Icarus Verilog.
#   ./run_wolf.sh tb_wolf_memsys
#   ./run_wolf.sh tb_wolf_boot_memsys      (best-effort boot smoke; needs the maindata hex)
# Keep every path quoted (the repo tree may contain spaces).
set -e
TB="${1:-tb_wolf_memsys}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"

SRC=( "$ROOT/rtl/pkg/wolf_pkg.sv" )
DEFS=()

case "$TB" in
  tb_wolf_memsys)
    # HW backends: palette write-tap -> wolf_palram, VRAM -> vram_sdram_top -> sdram_model.
    DEFS=( -DUSE_HW_RAM -DUSE_SDRAM_VRAM )
    SRC+=( "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv" \
           "$ROOT/rtl/wolf/wolf_pic.sv" \
           "$ROOT/rtl/wolf/wolf_memsys.sv" "$ROOT/rtl/wolf/wolf_palram.sv" \
           "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
           "$ROOT/sim/sdram_model.sv" ) ;;
  tb_wolf_boot_memsys)
    # Real TMS34010 core + wolf_memsys, functional memory path (internal ROM array).
    SRC+=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" )
    # all core/io/video sources
    for f in \
      core/tms34010_alu core/tms34010_shifter core/tms34010_divider \
      core/tms34010_status_reg core/tms34010_regfile core/tms34010_pc \
      core/tms34010_int_ctrl core/tms34010_decode core/tms34010_core \
      io/tms34010_io_regs video/tms34010_refresh video/tms34010_video ; do
      SRC+=( "$ROOT/rtl/tms34010/rtl/$f.sv" )
    done
    SRC+=( "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv" \
           "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_memsys.sv" ) ;;
esac
SRC+=( "$ROOT/sim/$TB.sv" )

mkdir -p "$ROOT/sim/build"
OUT="$ROOT/sim/build/$TB.vvp"
echo "compiling: $TB  (defs: ${DEFS[*]})"
iverilog -g2012 "${DEFS[@]}" -s "$TB" -o "$OUT" "${SRC[@]}"
echo "running:   $TB"
cd "$ROOT/sim"
vvp "$OUT"
