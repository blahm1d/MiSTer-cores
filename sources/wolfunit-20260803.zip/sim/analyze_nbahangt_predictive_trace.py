#!/usr/bin/env python3
"""Join MAME's retired Hangtime PCs to ROM opcodes and the RTL illegal bitmap."""

from __future__ import annotations

import argparse
import re
from collections import Counter
from pathlib import Path


ILLEGAL_RE = re.compile(rb"ILLEGAL\s+([0-9A-Fa-f]{4})")
ROM_BASE = 0xFF800000


def load_illegal(path: Path) -> set[int]:
    data = path.read_bytes()
    return {int(match.group(1), 16) for match in ILLEGAL_RE.finditer(data)}


def load_rom_words(path: Path) -> list[int]:
    return [int(line, 16) for line in path.read_text().splitlines() if line.strip()]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--rom-hex", type=Path, required=True)
    parser.add_argument("--decoder-log", type=Path, required=True)
    parser.add_argument("--all-out", type=Path, required=True)
    parser.add_argument("--illegal-out", type=Path, required=True)
    args = parser.parse_args()

    illegal = load_illegal(args.decoder_log)
    rom = load_rom_words(args.rom_hex)
    counts: Counter[int] = Counter()
    first_ordinal: dict[int, int] = {}
    first_disasm: dict[int, str] = {}
    retired = 0

    with args.trace.open("rb", buffering=8 * 1024 * 1024) as source:
        for raw in source:
            if len(raw) < 10 or raw[8:9] != b":" or not all(
                c in b"0123456789ABCDEFabcdef" for c in raw[:8]
            ):
                continue
            pc = int(raw[:8], 16)
            retired += 1
            counts[pc] += 1
            if pc not in first_ordinal:
                first_ordinal[pc] = retired
                first_disasm[pc] = raw[10:].decode("utf-8", "replace").strip()

    rows: list[tuple[int, int, int, int, str]] = []
    for pc, count in counts.items():
        if pc < ROM_BASE or ((pc - ROM_BASE) & 0xF):
            continue
        index = (pc - ROM_BASE) >> 4
        if index >= len(rom):
            continue
        rows.append((first_ordinal[pc], pc, rom[index], count, first_disasm[pc]))
    rows.sort()

    header = "first_retired\tpc\topcode\tcount\tdisassembly\n"
    args.all_out.parent.mkdir(parents=True, exist_ok=True)
    with args.all_out.open("w", newline="\n") as out:
        out.write(header)
        for first, pc, opcode, count, disasm in rows:
            out.write(f"{first}\t{pc:08X}\t{opcode:04X}\t{count}\t{disasm}\n")

    mismatches = [row for row in rows if row[2] in illegal]
    with args.illegal_out.open("w", newline="\n") as out:
        out.write(header)
        for first, pc, opcode, count, disasm in mismatches:
            out.write(f"{first}\t{pc:08X}\t{opcode:04X}\t{count}\t{disasm}\n")

    print(
        "PREDICTIVE_AUDIT "
        f"retired={retired} unique_rom_pcs={len(rows)} "
        f"unique_illegal_pcs={len(mismatches)} "
        f"unique_illegal_opcodes={len({row[2] for row in mismatches})}"
    )
    for first, pc, opcode, count, disasm in mismatches:
        print(f"MISMATCH {first} {pc:08X} {opcode:04X} {count} {disasm}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
