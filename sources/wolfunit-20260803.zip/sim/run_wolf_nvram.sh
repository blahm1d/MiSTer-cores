#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build/nvram"
IVERILOG="${IVERILOG:-iverilog}"
VVP="${VVP:-vvp}"
mkdir -p "$BUILD"

grep -Fq '"TE,Save NVRAM;"' "$ROOT/Arcade-SmashTV.sv"
grep -Eq 'manual_save[[:space:]]*\(status\[14\]\)' \
  "$ROOT/Arcade-SmashTV.sv"
if grep -Fq 'Autosave NVRAM' "$ROOT/Arcade-SmashTV.sv" ||
   grep -Eq '\.(autosave|osd_status)[[:space:]]*\(' \
     "$ROOT/Arcade-SmashTV.sv"; then
  echo "FAIL: Wolf OSD/wrapper still contains an automatic NVRAM save path" >&2
  exit 1
fi
echo "PASS: Save NVRAM is the sole OSD upload action"

"$IVERILOG" -g2012 -s tb_wolf_nvram_bridge \
  -o "$BUILD/bridge.vvp" \
  "$ROOT/rtl/wolf/wolf_nvram_bridge.sv" \
  "$ROOT/sim/tb_wolf_nvram_bridge.sv"
"$VVP" "$BUILD/bridge.vvp" | tee "$BUILD/bridge.log"
grep -q '^PASS tb_wolf_nvram_bridge$' "$BUILD/bridge.log"

# Prove that the cabinet-reported loop is covered: resurrecting any background
# save request from a game-side CMOS write must fail specifically at the
# manual-only assertion.
"$IVERILOG" -g2012 -DMUTATE_WOLF_NVRAM_AUTOSAVE \
  -s tb_wolf_nvram_bridge \
  -o "$BUILD/bridge_autosave_mutation.vvp" \
  "$ROOT/rtl/wolf/wolf_nvram_bridge.sv" \
  "$ROOT/sim/tb_wolf_nvram_bridge.sv"
if "$VVP" "$BUILD/bridge_autosave_mutation.vvp" \
    >"$BUILD/bridge_autosave_mutation.log" 2>&1; then
  echo "FAIL: background autosave mutation survived the regression" >&2
  exit 1
fi
grep -q 'gameplay CMOS changes caused an automatic save' \
  "$BUILD/bridge_autosave_mutation.log"
echo "PASS: background autosave policy rejected"

"$IVERILOG" -g2012 -DUSE_EXT_ROM -DUSE_EXT_GFX \
  -s tb_wolf_cmos_persistence \
  -o "$BUILD/cmos.vvp" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/wolf/wolf_mem.sv" \
  "$ROOT/sim/tb_wolf_cmos_persistence.sv"
"$VVP" "$BUILD/cmos.vvp" | tee "$BUILD/cmos.log"
grep -q '^PASS tb_wolf_cmos_persistence$' "$BUILD/cmos.log"

# The production image enables the clocked BRAM backend. Run the same
# changed-only dirty-pulse contract there as well; a functional-model pass is
# not sufficient for the MiSTer "Saving" loop regression.
"$IVERILOG" -g2012 -DUSE_EXT_ROM -DUSE_EXT_GFX -DUSE_HW_RAM \
  -s tb_wolf_cmos_persistence \
  -o "$BUILD/cmos_hw.vvp" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/wolf/wolf_mem.sv" \
  "$ROOT/sim/tb_wolf_cmos_persistence.sv"
"$VVP" "$BUILD/cmos_hw.vvp" | tee "$BUILD/cmos_hw.log"
grep -q '^PASS tb_wolf_cmos_persistence$' "$BUILD/cmos_hw.log"

python "$ROOT/sim/wolf_nvram_seeds.py" |
  tee "$BUILD/seeds.log"
grep -q '^PASS Ultimate Mortal Kombat 3.nvm: volume=0xFF' "$BUILD/seeds.log"

echo "PASS: Wolf NVRAM bridge and CMOS persistence"
