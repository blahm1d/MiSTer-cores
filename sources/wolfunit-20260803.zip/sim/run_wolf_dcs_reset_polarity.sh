#!/usr/bin/env bash
# Focused Icarus gate for the observed UMK3 DCS reset sequence.
set -euo pipefail

# Keep the runner usable when launched by PowerShell as well as an interactive
# Git Bash, whose inherited PATH formats differ.
export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_wolf_dcs_reset_polarity
OUT="$ROOT/sim/build/$TB.vvp"
LOG="$ROOT/sim/build/$TB.log"

mkdir -p "$ROOT/sim/build"
iverilog -g2012 -s "$TB" -o "$OUT" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/wolf/wolf_mem.sv" \
  "$ROOT/sim/$TB.sv"

cd "$ROOT/sim"
vvp "$OUT" | tee "$LOG"
grep -q '^PASS wolf_dcs_reset_polarity$' "$LOG"
