#!/usr/bin/env bash
# run_ddr_burst_write.sh — keystone gate for the DDR3 burst-WRITE path
# (stv_vram_ddr_agent burst-write + ddr3_avalon_model write-burst + cfg_maxburst enforce).
#
#   ./run_ddr_burst_write.sh            normal: MUST print PASS (exit 0)
#   MUTATE=1 ./run_ddr_burst_write.sh   coverage: temp model copy with the write-path
#                                       cfg_maxburst enforcement DISABLED (wlim=cB) — the
#                                       exact "forgot the 32-cap" bug; T3 MUST FAIL.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
TB=tb_ddr_burst_write
MODEL="$ROOT/sim/ddr3_avalon_model.sv"
mkdir -p "$ROOT/sim/build"

if [ "${MUTATE:-0}" = "1" ]; then
  MODEL="$ROOT/sim/build/ddr3_model_nomaxb.sv"
  sed "s/wlim  <= (cfg_maxburst != 8'd0 \&\& cB > cfg_maxburst) ? cfg_maxburst : cB;/wlim  <= cB;  \/\/ MUTANT: cap ignored/" \
      "$ROOT/sim/ddr3_avalon_model.sv" > "$MODEL"
  if cmp -s "$ROOT/sim/ddr3_avalon_model.sv" "$MODEL"; then
    echo "MUTATION ERROR: sed did not change the model (pattern drifted?)"; exit 2
  fi
  echo "== MUTATION RUN: write cfg_maxburst enforcement removed; T3 must FAIL =="
fi

OUT="$ROOT/sim/build/$TB.vvp"
iverilog -g2012 -s "$TB" -o "$OUT" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$MODEL" "$ROOT/sim/$TB.sv"
cd "$ROOT/sim"
LOG="$ROOT/sim/build/$TB.log"
vvp "$OUT" 2>/dev/null | tee "$LOG"
if [ "${MUTATE:-0}" = "1" ]; then
  if grep -q "^PASS:" "$LOG"; then echo "MUTATION GATE FAIL: passed with the cap removed"; exit 1
  else echo "MUTATION GATE OK: T3 correctly FAILED with maxburst enforcement removed"; exit 0; fi
else
  grep -q "^PASS:" "$LOG"
fi
