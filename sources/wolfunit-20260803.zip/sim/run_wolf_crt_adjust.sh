#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_wolf_crt_adjust
OUT="$ROOT/sim/build/$TB.vvp"
LOG="$ROOT/sim/build/$TB.log"

mkdir -p "$ROOT/sim/build"
export PATH="/c/iverilog/bin:$PATH"

iverilog -g2012 -s "$TB" -o "$OUT" \
  "$ROOT/rtl/video/crt_adjust.sv" \
  "$ROOT/rtl/video/wolf_crt_adjust.sv" \
  "$ROOT/sim/$TB.sv"
vvp "$OUT" 2>&1 | tee "$LOG"
grep -q '^PASS: tb_wolf_crt_adjust ' "$LOG"
