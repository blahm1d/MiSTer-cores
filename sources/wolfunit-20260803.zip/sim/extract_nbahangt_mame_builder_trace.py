#!/usr/bin/env python3
"""Extract an instruction window after the Nth Hangtime dma_irq entry.

The predictive MAME trace is multi-gigabyte, so this deliberately streams it
once instead of loading it.  Output is one primary instruction PC per line,
matching the bounded RTL CORE_FETCH trace.
"""

from __future__ import annotations

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trace", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--occurrence", type=int, default=3581)
    parser.add_argument("--count", type=int, default=200_000)
    args = parser.parse_args()

    marker = b"FF800000:"
    seen = 0
    copied = 0
    with args.trace.open("rb", buffering=16 * 1024 * 1024) as source, \
            args.output.open("w", encoding="ascii", newline="\n") as output:
        for line in source:
            if copied == 0:
                if line.startswith(marker):
                    seen += 1
                    if seen == args.occurrence:
                        output.write("FF800000\n")
                        copied = 1
                continue

            pc, sep, _ = line.partition(b":")
            if sep and len(pc) == 8:
                output.write(pc.decode("ascii") + "\n")
                copied += 1
                if copied >= args.count:
                    break

    if seen < args.occurrence:
        raise SystemExit(
            f"only found {seen} dma_irq entries; requested {args.occurrence}"
        )
    print(
        f"extracted {copied} PCs after dma_irq occurrence {args.occurrence} "
        f"to {args.output}"
    )


if __name__ == "__main__":
    main()
