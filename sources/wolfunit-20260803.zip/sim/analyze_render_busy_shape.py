#!/usr/bin/env python3
"""LENS D offline pass.

Input : sim/build/rb_openice_rank<N>.txt  (render_busy RLE from tb_render_busy_probe.sv,
        measured on the REAL wolf_dma + stv_vram_ddr_top + wolf_ddr3_arb + DDR3 model)
Output: the discriminating numbers for the two lethal patterns.

Raster constants (cited):
  V_TOTAL=289, V_ACT=254            rtl/wolf/wolf_top.sv:27-28
  CLK_PER_FRAME=1462340, /289 = 5060 clk/line exactly
  ce_pix = 1-in-10 of 80 MHz        (PX_CYC=10, sim/tb_wolf_peak_fight_budget.sv:30)
  FLIP_SETTLE_CYCLES=128            rtl/wolf/wolf_video.sv:112
  FLIP_COMMIT_LIMIT = 289-4 = 285   rtl/wolf/wolf_video.sv:114
  commit predicate  s0_vb && vc<285 rtl/wolf/wolf_video.sv:176

Derived commit criterion (exact restatement of the FSM at wolf_video.sv:150-181):
  at frame_start the FSM latches flip_wait_drain <= wr_busy_i; it then needs the FIRST
  ce_pix tick with render_busy==0 at-or-after frame_start, then 128 settle ticks, then
  one commit tick, all while vc<285.  Window = 31 lines = 15686 ce_pix ticks.
  => COMMIT iff  t_drain_tick + 129 < 15686   (t in ce_pix ticks from frame_start)
  => COMMIT iff  the render_busy run covering frame_start ends within 155570 clk.
"""
import sys, os, bisect

CLK_FRAME = 1462340
CLK_LINE  = 5060
V_ACT, V_TOTAL, LIMIT = 254, 289, 285
CE_DIV = 10
WIN_TICKS = (LIMIT - V_ACT) * 506          # 15686
SETTLE = 128
DEADLINE_CLK = (WIN_TICKS - SETTLE - 1) * CE_DIV   # 155570


def load(path):
    runs, meta = [], {}
    for ln in open(path):
        if ln.startswith('#'):
            for tok in ln[1:].split():
                k, v = tok.split('=')
                meta[k] = int(v)
            continue
        k, s, l = ln.split()
        if k in ('F', 'E'):
            meta[k] = int(s)
            continue
        runs.append((int(s), int(l), k))
    runs.sort()
    return runs, meta


def analyse(path, anchor_clk, label):
    runs, meta = load(path)
    busy = [(s, s + l) for s, l, k in runs if k == 'B']
    idle = [(s, s + l) for s, l, k in runs if k == 'I']
    total = runs[-1][0] + runs[-1][1]
    bstarts = [b[0] for b in busy]
    blen = sorted(e - s for s, e in busy)
    ilen = sorted(e - s for s, e in idle)

    print('=' * 78)
    print('%s   (%s)' % (label, os.path.basename(path)))
    print('  observed clk       : %d  (%.3f frames of %d clk)' % (total, total / CLK_FRAME, CLK_FRAME))
    print('  render_busy duty   : %.2f%%   busy=%d idle=%d' %
          (100.0 * sum(e - s for s, e in busy) / total, sum(e - s for s, e in busy),
           sum(e - s for s, e in idle)))
    print('  busy runs          : n=%d  max=%d clk  p90=%d  median=%d  min=%d' %
          (len(blen), blen[-1], blen[int(.9 * len(blen))], blen[len(blen) // 2], blen[0]))
    print('  idle gaps          : n=%d  max=%d clk  median=%d  min=%d' %
          (len(ilen), ilen[-1], ilen[len(ilen) // 2], ilen[0]))
    # --- lethal pattern (1): ce_pix SAMPLING ALIASING (gap < one ce_pix period)
    sub = [g for g in ilen if g < CE_DIV]
    print('  [P1 aliasing]  idle gaps < %d clk (invisible to a /%d ce_pix at some phase): %d / %d'
          % (CE_DIV, CE_DIV, len(sub), len(ilen)))
    # --- NARC satisfiability question
    print('  [SAT] longest busy run %d clk vs commit deadline %d clk  -> %s'
          % (blen[-1], DEADLINE_CLK,
             'UNSATISFIABLE for some raster alignments' if blen[-1] > DEADLINE_CLK
             else 'satisfiable at EVERY raster alignment'))

    # --- lethal pattern (2): drain never lands inside the commit window.
    # Exhaustive sweep of the frame origin (raster phase) over every evaluable offset.
    ends = [e for s, e in busy]
    def drain_delay(o):
        """clk from o until render_busy first reads 0 (0 if already idle)."""
        i = bisect.bisect_right(bstarts, o) - 1
        if i >= 0 and busy[i][0] <= o < busy[i][1]:
            return busy[i][1] - o
        return 0
    lo, hi = 0, total - WIN_TICKS * CE_DIV
    fails = 0
    worst = 0
    step = 1
    for o in range(lo, hi, step):
        d = drain_delay(o)
        if d > worst:
            worst = d
        if d > DEADLINE_CLK:
            fails += 1
    n = len(range(lo, hi, step))
    print('  [P2 origin sweep] %d/%d frame origins (%.4f%%) cannot commit; worst drain wait %d clk'
          % (fails, n, 100.0 * fails / n, worst))

    # --- the MAME-anchored origin(s) actually present in this replay
    print('  [MAME-anchored] first blit sits %d clk after the MAME frame_done edge' % anchor_clk)
    k = 0
    while True:
        o = k * CLK_FRAME - anchor_clk
        k += 1
        if o + WIN_TICKS * CE_DIV > total:
            break
        if o < 0:
            continue
        d = drain_delay(o)
        print('     frame origin at probe clk %8d : drain wait %7d clk -> %s'
              % (o, d, 'COMMIT (margin %d clk)' % (DEADLINE_CLK - d) if d <= DEADLINE_CLK
                 else 'STARVED (over by %d clk)' % (d - DEADLINE_CLK)))


if __name__ == '__main__':
    # phase= first field from the CANDIDATE line of sim/build/openice_peak_regs.txt
    anchors = {'1': 0.002644370, '2': 0.002642610, '5': 0.002326180, '11': 0.002269260}
    for r in sys.argv[1:]:
        analyse('sim/build/rb_openice_rank%s.txt' % r,
                int(round(anchors[r] * 80e6)),
                'Open Ice peak-display frame, rank %s' % r)
