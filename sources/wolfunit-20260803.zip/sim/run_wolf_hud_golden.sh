#!/usr/bin/env bash
# Diff the REAL wolf_video scanout against MAME's captured HUD pixels.
# iverilog only -- no Questa licence, no Quartus.
set -uo pipefail
cd "$(dirname "$0")"
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
DIR=${DIR:-build/hud_golden_motaro}
BUILD=build/hud_golden
mkdir -p "$BUILD"
[ -f "$DIR/frames.txt" ] || { echo "no $DIR/frames.txt -- run gen_wolf_hud_golden.py first"; exit 90; }

echo "=== compile ==="
"$IVERILOG" -g2012 -o "$BUILD/tb.vvp" \
  ../rtl/pkg/wolf_pkg.sv ../rtl/wolf/wolf_video.sv tb_wolf_hud_golden.sv || exit 91

TOTPASS=0; TOTFAIL=0; NF=0; BAD=0
while read -r F ROW0 COL0 NROWS; do
  [ -n "$F" ] || continue
  NF=$((NF+1))
  OUT="$BUILD/f${F}_diff.txt"
  "$VVP" "$BUILD/tb.vvp" \
    +VRAM="$DIR/f${F}_vram.hex" +PAL="$DIR/f${F}_pal.hex" \
    +EXPECT="$DIR/f${F}_expect.txt" +ROW0="$ROW0" +NROWS="$NROWS" \
    +OUT="$OUT" > "$BUILD/f${F}.log" 2>&1
  R=$(grep -o 'RESULT pass=[0-9]* fail=[0-9]*' "$BUILD/f${F}.log" | tail -1)
  P=$(echo "$R" | sed -n 's/.*pass=\([0-9]*\).*/\1/p')
  FA=$(echo "$R" | sed -n 's/.*fail=\([0-9]*\).*/\1/p')
  P=${P:-0}; FA=${FA:-0}
  TOTPASS=$((TOTPASS+P)); TOTFAIL=$((TOTFAIL+FA))
  if [ "$FA" != "0" ]; then
    BAD=$((BAD+1))
    echo "frame $F: pass=$P FAIL=$FA   $(grep -m1 '^FIRST' "$OUT" 2>/dev/null)"
  else
    echo "frame $F: pass=$P fail=0"
  fi
done < "$DIR/frames.txt"

echo
echo "=== SUMMARY: $NF frames, $BAD with mismatches, pass=$TOTPASS fail=$TOTFAIL ==="
if [ "$TOTFAIL" != "0" ]; then
  echo "DIVERGENCE: our scanout does not reproduce MAME's HUD pixels."
  exit 1
fi
echo "MATCH: our scanout reproduces MAME's HUD pixels on every golden frame."
