#!/usr/bin/env bash
# run_wolf_dma_realgfx_rtl.sh -- RTL-level counterpart to run_wolf_dma_realpixels.sh: run the
# ACTUAL wolf_dma.sv (not just the Python model) against UMK3's real captured first blit
# (sim/build/wolf_dma_realblit1_stim.txt, hex offsets, from mame-gospel/trace/wolfblits.txt
# line 1) with the real 32MB gfx ROM (sim/build/umk3_gfx.hex), then diff the resulting
# framebuffer-write stream against MAME's own captured post-blit VRAM.
set -e
cd "$(dirname "$0")/.."
IVERILOG=/c/iverilog/bin/iverilog
VVP=/c/iverilog/bin/vvp
T="${TMPDIR:-/tmp}"

if [ ! -f sim/build/umk3_gfx.hex ]; then
  echo "sim/build/umk3_gfx.hex missing -- run: python sim/make_wolf_gfx_hex.py"
  exit 1
fi

echo "== compile (loads 32MB gfx ROM via \$readmemh, may take a few seconds) =="
"$IVERILOG" -g2012 -o "$T/tb_wolf_dma_realgfx.vvp" \
  rtl/pkg/wolf_pkg.sv rtl/wolf/wolf_dma.sv sim/tb_wolf_dma_realgfx.sv

echo "== run real captured blit (CMD=C002 W=10 H=12 OFFLO=AFE6 OFFHI=0BD9 XPOS=346 YPOS=80) =="
"$VVP" "$T/tb_wolf_dma_realgfx.vvp" \
  +STIM=sim/build/wolf_dma_realblit1_stim.txt +OUT=sim/build/wolf_dma_realblit1_out.txt

echo "== diff RTL framebuffer writes vs MAME real captured post-blit VRAM =="
python sim/diff_dma_out_vs_mame.py sim/build/wolf_dma_realblit1_out.txt
