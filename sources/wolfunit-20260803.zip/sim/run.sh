#!/usr/bin/env bash
# Run a Y-unit testbench under Icarus Verilog.
#   ./run.sh tb_yunit_dma
# Toolchain note: birdybro's SV subset + this wrapper need Questa or Icarus.
# ModelSim ASE 17.0 (bundled with Quartus 17.0) is too old — it rejects
# `input logic` under `default_nettype none`. Icarus 12 works (constant selects
# are hoisted to continuous assigns; see rtl/yunit/yunit_dma.sv).
# NOTE: the repo path contains a space ("smash tv") — keep every path quoted.
set -e
TB="${1:-tb_yunit_dma}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"

SRC=( "$ROOT/rtl/pkg/yunit_pkg.sv" )
case "$TB" in
  tb_yunit_dma) SRC+=( "$ROOT/rtl/yunit/yunit_dma.sv" ) ;;
  tb_yunit_dma_matrix) SRC+=( "$ROOT/rtl/yunit/yunit_dma.sv" ) ;;
  tb_yunit_mem) SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" ) ;;
  tb_yunit_autoerase) SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" ) ;;
  tb_yunit_memsys) SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" \
                          "$ROOT/rtl/yunit/yunit_memsys.sv" ) ;;
esac
SRC+=( "$ROOT/sim/$TB.sv" )

mkdir -p "$ROOT/sim/build"
OUT="$ROOT/sim/build/$TB.vvp"
echo "compiling: $TB"
iverilog -g2012 -s "$TB" -o "$OUT" "${SRC[@]}"
echo "running:   $TB"
# run from sim/ so $readmemh("build/...") resolves
cd "$ROOT/sim"
vvp "$OUT" | grep -iE "PASS|FAIL|RESULT|FAIL:" || { echo "no PASS/FAIL printed"; exit 1; }
