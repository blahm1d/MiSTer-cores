#!/usr/bin/env bash
# Walk the MK3 1P ladder, saving a state + snapshot at every opponent.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
ROMS="${MK3_ROMS:-D:/deck/fpga/mk3}"
SCRIPT="$ROOT/sim/reach_mk3_ladder.lua"
OUT="${MK3_LADDER_OUT:-$BUILD/mk3_ladder.txt}"
SECS="${MK3_LADDER_SECONDS:-600}"
mkdir -p "$BUILD"; rm -f "$OUT"
export MK3_LADDER_OUT="$OUT"
export MK3_LADDER_FRAMES="${MK3_LADDER_FRAMES:-20000}"
"$MAME" mk3 -rompath "$ROMS" -statename "mk3_ladder" \
  -nowindow -video none -sound none -nothrottle \
  -seconds_to_run "$SECS" -autoboot_delay 0 -autoboot_script "$SCRIPT"
grep -q '^DONE ' "$OUT" || { echo "FAIL: harness did not complete"; exit 1; }
N=$(grep -c '^ROUNDSTART ' "$OUT" || true)
[ "$N" -ge 8 ] || { echo "FAIL: only $N opponents reached"; sed -n '1,40p' "$OUT"; exit 1; }
echo "reached $N opponents; states in $ROOT/sta/mk3_ladder/"
