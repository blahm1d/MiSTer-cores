#!/usr/bin/env python3
"""Build a ten-band Hangtime replay and MAME write oracle from the live trace."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import wolf_dma_model as model


GO_RE = re.compile(r"^GO \d+ (\d+) \d+ .* REGS=((?:[0-9A-F]{4} ?){18})$")
FNV_OFFSET = 0xCBF29CE484222325
FNV_PRIME = 0x00000100000001B3
MASK64 = (1 << 64) - 1


def load_register_writes(regs: tuple[int, ...]) -> list[tuple[int, int]]:
    """Use the same banked-register sequence as the real RTL replay harness."""
    return [
        (15, regs[15] & 0xFFDF), (12, regs[16]), (13, regs[17]),
        (15, regs[15] | 0x0020), (12, regs[12]), (13, regs[13]),
        (0, regs[0]), (2, regs[2]), (3, regs[3]), (4, regs[4]),
        (5, regs[5]), (6, regs[6]), (7, regs[7]), (8, regs[8]),
        (9, regs[9]), (10, regs[10]), (11, regs[11]), (14, regs[14]),
        (15, regs[15] | 0x0020), (1, regs[1]),
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--capture", type=Path, required=True)
    parser.add_argument("--gfx", type=Path, required=True)
    parser.add_argument("--trace-out", type=Path, required=True)
    parser.add_argument("--oracle-out", type=Path, required=True)
    parser.add_argument("--vram-out", type=Path, required=True)
    args = parser.parse_args()

    jobs: list[tuple[int, tuple[int, ...]]] = []
    for raw in args.capture.read_text(encoding="ascii").splitlines():
        match = GO_RE.match(raw)
        if match:
            jobs.append((int(match.group(1)), tuple(int(x, 16) for x in match.group(2).split())))
            if len(jobs) == 10:
                break
    if len(jobs) != 10:
        raise SystemExit(f"expected first ten-command queue, found {len(jobs)} jobs")

    gfx = args.gfx.read_bytes()
    model.GFX_SIZE = len(gfx)
    model._GFX = gfx

    args.trace_out.parent.mkdir(parents=True, exist_ok=True)
    trace_lines: list[str] = []
    oracle_lines: list[str] = []
    final_vram = [0] * 0x80000
    fnv = FNV_OFFSET
    for index, (mame_frame, regs) in enumerate(jobs, 1):
        trace_lines.append(
            f"BLIT 1 {mame_frame} {index} " + " ".join(f"{word:04X}" for word in regs)
        )
        lines = model.run_case(load_register_writes(regs))
        oracle_lines.extend(lines)
        for line in lines:
            addr_text, data_text = line.split()
            addr = int(addr_text, 16)
            data = int(data_text, 16)
            final_vram[addr] = data
            token = (addr << 16) | data
            fnv = ((fnv ^ token) * FNV_PRIME) & MASK64

    args.trace_out.write_text("\n".join(trace_lines) + "\n", encoding="ascii", newline="\n")
    args.oracle_out.write_text("\n".join(oracle_lines) + "\n", encoding="ascii", newline="\n")
    args.vram_out.write_text(
        "\n".join(f"{word:04X}" for word in final_vram) + "\n",
        encoding="ascii", newline="\n",
    )
    print(
        f"HANGTIME_TRANSITION jobs={len(jobs)} writes={len(oracle_lines)} "
        f"fnv64={fnv:016X} first_frame={jobs[0][0]} last_frame={jobs[-1][0]}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
