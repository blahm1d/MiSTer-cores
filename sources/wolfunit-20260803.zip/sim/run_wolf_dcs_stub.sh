#!/bin/bash
# run_wolf_dcs_stub.sh -- standalone iverilog unit test for the new DCS sound-status latch
# model (rtl/wolf/wolf_dcs_stub.sv), which replaces the frozen 16'h0C00 constant previously
# wired into wolf_top.sv's snd_stat port. See tb_wolf_dcs_stub.sv for the oracle list
# (idle-at-reset, write->FULL, modeled auto-ack->idle, reset holds idle, re-arm on 2nd write,
# mutation-kill vs the old frozen constant).
# No Questa, no wolf_mem/wolf_top, no boot golden touched.
#
# Usage: bash sim/run_wolf_dcs_stub.sh
# Exit 0 iff the TB prints PASS (all oracles green).

set -u
cd "$(dirname "$0")/.." || exit 1        # repo root (Arcade-UMK3_MiSTer)

IVERILOG=/c/iverilog/bin/iverilog
VVP=/c/iverilog/bin/vvp
OUT=sim/build/tb_wolf_dcs_stub.vvp
LOG=sim/build/tb_wolf_dcs_stub.log
mkdir -p sim/build

$IVERILOG -g2012 -o "$OUT" rtl/wolf/wolf_dcs_stub.sv sim/tb_wolf_dcs_stub.sv \
  || { echo "FATAL: iverilog compile failed"; exit 1; }

"$VVP" -n "$OUT" > "$LOG" 2>&1
cat "$LOG"

echo "----------------------------------------------------------------------"
if grep -q "^PASS wolf_dcs_stub" "$LOG" && ! grep -q "^FAIL" "$LOG"; then
    echo "RESULT: PASS"
    exit 0
else
    echo "RESULT: FAIL"
    exit 1
fi
