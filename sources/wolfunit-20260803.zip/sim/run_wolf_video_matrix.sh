#!/usr/bin/env bash
# run_wolf_video_matrix.sh -- cross-validate the two independent wolf_video pixel-
# path transcriptions against each other, both derived from the SAME gospel
# (midway/midtunit_v.cpp scanline_update:846-854 + midway/midwunit.cpp:643).
#
#   Python golden model : sim/wolf_video_model.py   (-> per-case .golden.txt)
#   RTL DUT + TB        : rtl/wolf/wolf_video.sv driven by sim/tb_wolf_video.sv
#
# Flow:
#   1. model  : wolf_video_model.py wolf_video_vectors.json  -> golden/<name>.golden.txt
#   2. convert: json_to_stim.py  -> matrix_stim.txt + matrix_manifest.txt
#   3. compile: iverilog once (wolf_pkg first)
#   4. run    : vvp +STIM +OUT   -> matrix_out.txt (all cases concatenated)
#   5. split+diff: order-sensitive per-case diff vs golden; PASS/FAIL + totals
#
# Exit != 0 on ANY case failure or short capture.
set -u
cd "$(dirname "$0")"

IVERILOG=/c/iverilog/bin/iverilog
VVP=/c/iverilog/bin/vvp
PY=python

VEC=wolf_video_vectors.json
GOLDDIR=golden
STIM=matrix_stim.txt
MANIFEST=matrix_manifest.txt
OUT=matrix_out.txt
VVPOUT=tb_wolf_video_matrix.vvp

echo "=== [0] regenerate vector matrix ==="
$PY gen_wolf_video_matrix.py "$VEC" || exit 90

echo "=== [1] Python golden model -> $GOLDDIR/ ==="
rm -rf "$GOLDDIR"; mkdir -p "$GOLDDIR"
$PY wolf_video_model.py "$VEC" "$GOLDDIR" 2>model_gen.log || { echo "model FAILED"; cat model_gen.log; exit 91; }

echo "=== [2] JSON -> TB stim + manifest ==="
$PY json_to_stim.py "$VEC" "$STIM" "$MANIFEST" || exit 92

echo "=== [3] compile TB (wolf_pkg first) ==="
$IVERILOG -g2012 -o "$VVPOUT" \
  ../rtl/pkg/wolf_pkg.sv ../rtl/wolf/wolf_video.sv tb_wolf_video.sv \
  2>compile.log
rc=$?
grep -i "error" compile.log && { echo "COMPILE ERROR"; exit 93; }
[ $rc -ne 0 ] && { echo "iverilog rc=$rc"; cat compile.log; exit 93; }

echo "=== [4] run TB ==="
$VVP "$VVPOUT" +STIM="$STIM" +OUT="$OUT" 2>&1 | tee run.log | grep -Ei "WARN|FAIL|DONE" || true
[ -f "$OUT" ] || { echo "no OUT produced"; exit 94; }

echo "=== [5] split + order-sensitive per-case diff ==="
$PY split_and_diff.py "$MANIFEST" "$OUT" "$GOLDDIR"
exit $?
