#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
ROMS="${OPENICE_ROMS:-D:/deck/fpga/openice}"
SCRIPT="$ROOT/sim/capture_openice_peak_regs.lua"
OUT="$BUILD/openice_peak_regs.txt"
SEED="${OPENICE_NVRAM_SEED:-D:/deck/fpga/wolf-nvram-80/by-setname/openice.nvm}"

mkdir -p "$BUILD"
NVDIR="$(mktemp -d "$BUILD/openice_peak_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
mkdir -p "$NVDIR/openice"
cp "$SEED" "$NVDIR/openice/nvram"
rm -f "$OUT"

export OPENICE_CAPTURE_OUT="$OUT"
"$MAME" openice -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 85 -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"

grep -q '^DONE$' "$OUT"
grep '^CANDIDATE' "$OUT"
