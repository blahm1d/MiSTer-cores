#!/usr/bin/env bash
# 3-way DDR3 arbitration gate. Derived from tb_wolf_ddr3_arb with the A/B halves
# UNCHANGED, so a difference is attributable to the new framebuffer port.
set -euo pipefail
export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_wolf_ddr3_arb3
OUT="$ROOT/sim/build/$TB.vvp"
LOG="$ROOT/sim/build/$TB.log"
mkdir -p "$ROOT/sim/build"
iverilog -g2012 -s "$TB" -o "$OUT" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/wolf_ddr3_arb.sv" \
  "$ROOT/rtl/sdram/wolf_ddr3_arb3.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/$TB.sv"
cd "$ROOT"
vvp -n "$OUT" | tee "$LOG"
if grep -q 'TEST-INVALID' "$LOG"; then echo "TEST-INVALID -- not a verdict" >&2; exit 4; fi
grep -q 'RESULT: PASS3' "$LOG"
