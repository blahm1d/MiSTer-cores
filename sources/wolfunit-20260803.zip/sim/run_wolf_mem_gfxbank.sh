#!/usr/bin/env bash
# run_wolf_mem_gfxbank.sh — discriminating gate for the USE_DDR3_GFX gfxbank offset
# on wolf_mem's CPU gfx-window external fetch (ext_base = {gfxbank,23'd0} + ...).
#
#   ./run_wolf_mem_gfxbank.sh            normal gate: MUST print PASS (exit 0)
#   MUTATE=1 ./run_wolf_mem_gfxbank.sh   coverage proof: compiles a temp copy of
#                                        wolf_mem.sv with the bank term DELETED
#                                        (ext_base = (widx-WB_GFX)<<1 only); the TB
#                                        MUST FAIL -> script exits 0 iff it failed.
#
# iverilog only. Compiles wolf_mem standalone (functional backing stores) with
# -DUSE_EXT_GFX (external fetch port) -DUSE_DDR3_GFX (the 3 lines under test).
# Keep every path quoted (the repo tree may contain spaces).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"

TB=tb_wolf_mem_gfxbank
WOLF_MEM="$ROOT/rtl/wolf/wolf_mem.sv"
mkdir -p "$ROOT/sim/build"

if [ "${MUTATE:-0}" = "1" ]; then
  # Mutant: delete the gfxbank term (revert to the unbanked base) in a TEMP COPY.
  WOLF_MEM="$ROOT/sim/build/wolf_mem_gfxbank_mutant.sv"
  sed "s/ext_base  = {gfxbank, 23'd0} + 26'((widx - WB_GFX) << 1);/ext_base  = 26'((widx - WB_GFX) << 1);/" \
      "$ROOT/rtl/wolf/wolf_mem.sv" > "$WOLF_MEM"
  # refuse to run a no-op mutation (sed silently matching nothing = fake coverage)
  if cmp -s "$ROOT/rtl/wolf/wolf_mem.sv" "$WOLF_MEM"; then
    echo "MUTATION ERROR: sed did not change wolf_mem.sv (pattern drifted?)"; exit 2
  fi
  echo "== MUTATION RUN: bank term deleted from a temp copy; the TB must FAIL =="
fi

OUT="$ROOT/sim/build/$TB.vvp"
echo "compiling: $TB  (defs: -DUSE_EXT_GFX -DUSE_DDR3_GFX; wolf_mem: $WOLF_MEM)"
iverilog -g2012 -DUSE_EXT_GFX -DUSE_DDR3_GFX -s "$TB" -o "$OUT" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" "$WOLF_MEM" "$ROOT/sim/$TB.sv"

echo "running:   $TB"
cd "$ROOT/sim"
LOG="$ROOT/sim/build/$TB.log"
vvp "$OUT" | tee "$LOG"

# REAL pass/fail (vvp exits 0 regardless): gate on the TB's PASS line.
if [ "${MUTATE:-0}" = "1" ]; then
  if grep -q "PASS: tb_wolf_mem_gfxbank" "$LOG"; then
    echo "MUTATION NOT DETECTED: TB passed with the bank term deleted -> the gate does NOT exercise the change"
    exit 1
  fi
  echo "MUTATION DETECTED: TB failed with the bank term deleted (gate exercises the change)"
  exit 0
fi
grep -q "PASS: tb_wolf_mem_gfxbank" "$LOG" || { echo "GATE FAILED"; exit 1; }
