#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-C:/tools/mame/mame.exe}"
ROMS="${UMK3_ROMS:-D:/deck/fpga/umk3/roms}"
SCRIPT="$ROOT/sim/capture_umk3_bio_transition_timed.lua"
OUT="${UMK3_TRANSITION_OUT:-$BUILD/umk3_bio_transition_timed.txt}"

mkdir -p "$BUILD"
NVDIR="$(mktemp -d "$BUILD/umk3_bio_transition_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
rm -f "$OUT"

"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 12 -autoboot_delay 0

export UMK3_TRANSITION_OUT="$OUT"
export UMK3_TRANSITION_START="${UMK3_TRANSITION_START:-2950}"
export UMK3_TRANSITION_END="${UMK3_TRANSITION_END:-3060}"
"$MAME" umk3 -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 70 -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"

grep -q '^DONE ' "$OUT"
grep -E '^(FRAME|TBLIT|DONE)' "$OUT" | tail -20
