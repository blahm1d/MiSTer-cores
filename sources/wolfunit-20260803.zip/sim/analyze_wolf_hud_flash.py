#!/usr/bin/env python3
"""Classify the Wolf/T-unit HUD flash from a self-validating capture.

Input: sim/capture_wolf_hud_pixels.lua output (FRAME/VROW/PALETTE/SCREEN/
VALIDATE/PALW/SUMMARY records).  Unlike the older capture format, every record
here carries the geometry needed to map a screen pixel to the framebuffer entry
that produced it:

    vrow  = (ROW0 + y) & 0x1ff          # ROW0 = ((DPYSTRT>>4)+1), per frame
    entry = VROW[vrow][(col0 + x) & 0x1ff]

The capture validates that mapping against MAME's own scanout before this tool
runs, so a classification here is anchored rather than assumed.

Method: a flash is a pixel that COMES BACK -- screen[f-1][y][x] ==
screen[f+1][y][x] != screen[f][y][x].  Animation essentially never reverts
exactly, so this separates the bug from ordinary motion (the thing a
"differs from frame 0" comparison cannot do).  Each reverting pixel is then
classified by whether the framebuffer entry behind it also reverted:

    entry reverted too  -> DATA-SIDE   (blit / scanline refill / arbitration)
    entry unchanged     -> PALETTE-SIDE (palette written under live scanout)

Usage:
    python analyze_wolf_hud_flash.py <capture.txt> [<capture.txt> ...]
"""

import sys
import collections


def parse(path):
    frames = collections.OrderedDict()
    palw = []

    def rec(f):
        if f not in frames:
            frames[f] = {"regs": {}, "vrow": {}, "palette": {}, "screen": {},
                         "validate": {}}
        return frames[f]

    with open(path) as fh:
        for line in fh:
            p = line.split()
            if not p:
                continue
            t = p[0]
            if t == "FRAME":
                r = rec(int(p[1]))
                for kv in p[2:]:
                    if "=" in kv:
                        k, v = kv.split("=", 1)
                        r["regs"][k] = int(v, 16) if not k.startswith("ROW") \
                            and not k.startswith("COL") else int(v)
            elif t == "VROW":
                rec(int(p[1]))["vrow"][int(p[2])] = \
                    tuple(int(v, 16) for v in p[3:])
            elif t == "PALETTE":
                pal = rec(int(p[1]))["palette"]
                for kv in p[2:]:
                    i, v = kv.split(":")
                    pal[int(i, 16)] = int(v, 16)
            elif t == "SCREEN":
                rec(int(p[1]))["screen"][int(p[2])] = \
                    tuple(int(v, 16) for v in p[3:])
            elif t == "VALIDATE":
                r = rec(int(p[1]))
                for kv in p[2:]:
                    k, v = kv.split("=", 1)
                    r["validate"][k] = v
            elif t == "PALW":
                palw.append({"f": int(p[1]), "t": float(p[2]),
                             "off": int(p[3], 16), "data": int(p[4], 16),
                             "pc": int(p[6], 16)})
    return frames, palw


def entry_at(rec, col0, y, x):
    """Framebuffer entry that produced screen pixel (y, x) in this frame."""
    row0 = rec["regs"].get("ROW0")
    if row0 is None:
        return None
    ent = rec["vrow"].get((row0 + y) & 0x1FF)
    if not ent:
        return None
    return ent[(col0 + x) & 0x1FF]


def analyze(path):
    frames, palw = parse(path)
    order = list(frames)
    print("=" * 76)
    print(path)
    print("=" * 76)
    if len(order) < 3:
        print("  need >=3 frames to detect reversion")
        return

    v0 = frames[order[0]]["validate"]
    col0 = int(v0.get("best_col0", "56"))
    pct = float(v0.get("best_pct", "0"))
    print(f"frames   : {order[0]}..{order[-1]} ({len(order)})")
    print(f"geometry : col0={col0}  scanout reproduced {pct:.2f}%")
    if pct < 99.0:
        print("  REFUSING: capture does not reproduce MAME scanout.")
        return

    rows = sorted(frames[order[0]]["screen"])
    tot = data_side = pal_side = to_black = 0
    by_frame = collections.Counter()
    by_row = collections.Counter()
    examples = []

    for i in range(1, len(order) - 1):
        fp, f, fn = order[i - 1], order[i], order[i + 1]
        A, B, C = frames[fp], frames[f], frames[fn]
        for y in rows:
            a, b, c = A["screen"].get(y), B["screen"].get(y), C["screen"].get(y)
            if not (a and b and c):
                continue
            for x in range(min(len(a), len(b), len(c))):
                if a[x] != c[x] or a[x] == b[x]:
                    continue
                tot += 1
                by_frame[f] += 1
                by_row[y] += 1
                if b[x] == 0:
                    to_black += 1
                ea = entry_at(A, col0, y, x)
                eb = entry_at(B, col0, y, x)
                ec = entry_at(C, col0, y, x)
                if None in (ea, eb, ec):
                    continue
                if ea == ec and ea != eb:
                    data_side += 1
                    kind = "DATA"
                else:
                    pal_side += 1
                    kind = "PALETTE"
                if len(examples) < 8:
                    examples.append((f, y, x, a[x], b[x], ea, eb, kind))

    print(f"\nreverting pixel-samples: {tot}")
    if not tot:
        print("  NO FLASH in this window.")
        return
    print(f"  to black            : {to_black}")
    print(f"  DATA-SIDE  (entry reverted too) : {data_side}")
    print(f"  PALETTE-SIDE (entry unchanged)  : {pal_side}")
    hot = sorted(by_row)
    print(f"  rows affected       : y={hot[0]}..{hot[-1]} ({len(hot)})")
    print(f"  worst frames        : "
          f"{[f'{a}:{b}' for a, b in by_frame.most_common(5)]}")
    for (f, y, x, was, now, ea, eb, kind) in examples:
        print(f"    f{f} y{y:3d} x{x:3d}: rgb {was:06X}->{now:06X}  "
              f"entry {ea:04X}->{eb:04X}  [{kind}]")

    if palw:
        pens = collections.Counter((w["off"] - 0x01880000) // 0x10 for w in palw)
        print(f"\npalette writes in window: {len(palw)}")
        for pen, n in pens.most_common(8):
            pcs = sorted({w["pc"] for w in palw
                          if (w["off"] - 0x01880000) // 0x10 == pen})
            print(f"    pen {pen:04X}: {n}  pc={[f'{p:08X}' for p in pcs]}")

    print("\n[VERDICT]")
    if data_side and not pal_side:
        print("  DATA-SIDE: every reverting pixel had a reverting framebuffer")
        print("  entry. Look at blit / scanline refill / arbitration.")
    elif pal_side and not data_side:
        print("  PALETTE-SIDE: framebuffer entries were IDENTICAL while the")
        print("  emitted color changed. Look at palette writes vs scanout.")
    else:
        print(f"  MIXED: {data_side} data-side / {pal_side} palette-side.")


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    for p in argv[1:]:
        analyze(p)
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
