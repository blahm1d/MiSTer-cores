#!/usr/bin/env bash
# wolf_mem SRT unit checks on the NON-DDR3 backends: (1) functional behavioral
# memcpy branch, (2) USE_HW_VRAM sequential 2-port-BRAM engine (M_SRB).
# (The DDR3 D-lane has its own gate: run_wolf_vram_srt_dlane.sh; the end-to-end
# shipping-config proof is run_wolf_srt2_contract.sh.)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
BUILD="$ROOT/sim/build/wolf_mem_srt_units"
mkdir -p "$BUILD"

run_cfg() {
  local tag="$1"; shift
  "$IVERILOG" -g2012 -s tb_wolf_mem_srt_units -o "$BUILD/$tag.vvp" "$@" \
    "$ROOT/rtl/pkg/wolf_pkg.sv" "$ROOT/rtl/wolf/wolf_mem.sv" \
    "$ROOT/sim/tb_wolf_mem_srt_units.sv"
  "$VVP" "$BUILD/$tag.vvp" > "$BUILD/$tag.log" 2>&1 || true
  grep -E "WARNING|TEST_RESULT" "$BUILD/$tag.log" || true
  grep -q "TEST_RESULT: PASS" "$BUILD/$tag.log" || { echo "GATE: FAIL ($tag)"; exit 1; }
}

echo "== functional (behavioral memcpy) =="
run_cfg functional
echo "== USE_HW_VRAM (sequential BRAM engine) =="
run_cfg hw_vram -DUSE_HW_VRAM=1
echo "GATE: PASS -- both non-DDR3 SRT backends"
