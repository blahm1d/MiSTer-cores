#!/usr/bin/env bash
set -euo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
cd "$(dirname "$0")/.."
IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
OUT="sim/build/tb_wolf_peak_fight_budget.vvp"
LOG="${LOG:-sim/build/tb_wolf_peak_fight_budget.log}"
TRACE="${TRACE:-sim/traces/umk3_peak_fight_regs.txt}"
GFX="${GFX:-sim/build/umk3_gfx.hex}"
RANK="${RANK:-1}"
EXPECT_BLITS="${EXPECT_BLITS:-0}"
EXPECT_WRITES="${EXPECT_WRITES:-0}"
EXPECT_HASH="${EXPECT_HASH:-0}"

test -f "$GFX" || {
  echo "$GFX missing; generate the selected game's graphics hex first"
  exit 1
}

"$IVERILOG" -g2012 -s tb_wolf_peak_fight_budget -o "$OUT" \
  rtl/pkg/wolf_pkg.sv \
  rtl/wolf/wolf_dma.sv \
  rtl/yunit/vram_sdram.sv \
  rtl/yunit/vram_sdram_top.sv \
  rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/stv_vram_ddr_top.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv \
  rtl/sdram/wolf_ddr3_arb.sv \
  sim/ddr3_avalon_model.sv \
  sim/tb_wolf_peak_fight_budget.sv

"$VVP" "$OUT" "+TRACE=$TRACE" "+GFX=$GFX" "+RANK=$RANK" \
  "+EXPECT_BLITS=$EXPECT_BLITS" "+EXPECT_WRITES=$EXPECT_WRITES" \
  "+EXPECT_HASH=$EXPECT_HASH" | tee "$LOG"
grep -q '^PASS: live-fight frame retires' "$LOG"
