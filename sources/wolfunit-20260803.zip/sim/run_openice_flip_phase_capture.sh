#!/usr/bin/env bash
# Capture the Open Ice black-rink scene with an EXACT VSBLNK phase anchor.
# Derived from sim/run_openice_dpy_probe.sh (same MAME, same NVRAM seeding).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build"
MAME="${MAME:-D:/deck/fpga/starwars/sw/starwars-mister/.tools/mame0287/mame.exe}"
ROMS="${OPENICE_ROMS:-D:/deck/fpga/openice}"
SCRIPT="$ROOT/sim/capture_openice_flip_phase.lua"
OUT="${OPENICE_FLIPPHASE_OUT:-$BUILD/openice_flipphase.txt}"
SEED="${OPENICE_NVRAM_SEED:-D:/deck/fpga/wolf-nvram-80/by-setname/openice.nvm}"
FIRST="${OPENICE_FLIPPHASE_FIRST:-1783}"
FRAMES="${OPENICE_FLIPPHASE_FRAMES:-10}"

mkdir -p "$BUILD"
NVDIR="$(mktemp -d "$BUILD/openice_fp_nv.XXXXXX")"
trap 'rm -rf "$NVDIR"' EXIT
mkdir -p "$NVDIR/openice"
[ -f "$SEED" ] && cp "$SEED" "$NVDIR/openice/nvram"
rm -f "$OUT"

export OPENICE_FLIPPHASE_OUT="$OUT"
export OPENICE_FLIPPHASE_FIRST="$FIRST"
export OPENICE_FLIPPHASE_FRAMES="$FRAMES"
"$MAME" openice -rompath "$ROMS" -nvram_directory "$NVDIR" \
  -nowindow -video none -sound none -seconds_to_run 45 -autoboot_delay 0 \
  -nothrottle -autoboot_script "$SCRIPT"

grep -q '^DONE$' "$OUT"
echo "wrote $OUT ($(grep -c '^VS ' "$OUT") VSBLNK edges, $(grep -c '^BLIT ' "$OUT") blits, $(grep -c '^DPYADR ' "$OUT") DPYADR writes)"
