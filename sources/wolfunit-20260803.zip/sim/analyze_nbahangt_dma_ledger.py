#!/usr/bin/env python3
"""Summarize Hangtime DMA jobs using MAME's exact 41 ns scaled-pixel cost."""

from __future__ import annotations

import argparse
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path


BLIT_RE = re.compile(
    r"^BLIT phase=(\S+) frame=(\d+) n=(\d+) pc=([0-9A-Fa-f]{8}) regs=(.*)$"
)


def s16(value: int) -> int:
    return value - 0x10000 if value & 0x8000 else value


@dataclass(frozen=True)
class Job:
    phase: str
    frame: int
    number: int
    pc: int
    regs: tuple[int, ...]
    source: int
    pixels: int
    cost_ns: int


def parse_job(line: str) -> Job | None:
    match = BLIT_RE.match(line)
    if not match:
        return None
    regs = tuple(int(word, 16) for word in match.group(5).split())
    if len(regs) != 18:
        raise ValueError(f"expected 18 DMA registers, got {len(regs)}: {line[:120]}")
    width = regs[6] & 0x3FF
    height = regs[7] & 0x3FF
    xstep = regs[10] or 0x100
    ystep = regs[11] or 0x100
    if xstep == 0x100 and ystep == 0x100:
        pixels = width * height
    elif xstep and ystep:
        pixels = ((width << 8) // xstep) * ((height << 8) // ystep)
    else:
        pixels = 0
    return Job(
        phase=match.group(1),
        frame=int(match.group(2)),
        number=int(match.group(3)),
        pc=int(match.group(4), 16),
        regs=regs,
        source=(regs[3] << 16) | regs[2],
        pixels=pixels,
        cost_ns=41 * pixels,
    )


def signature(job: Job) -> tuple[int, ...]:
    r = job.regs
    return (r[1], job.source, r[6] & 0x3FF, r[7] & 0x3FF, r[8], r[9],
            r[0], r[10] or 0x100, r[11] or 0x100)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--frames-out", type=Path, required=True)
    parser.add_argument("--signatures-out", type=Path, required=True)
    parser.add_argument("--transition-out", type=Path, required=True)
    args = parser.parse_args()

    jobs: list[Job] = []
    with args.events.open() as source:
        for line in source:
            job = parse_job(line.rstrip("\n"))
            if job is not None:
                jobs.append(job)

    phase_jobs: Counter[str] = Counter()
    phase_pixels: Counter[str] = Counter()
    frame_jobs: Counter[tuple[str, int]] = Counter()
    frame_pixels: Counter[tuple[str, int]] = Counter()
    signatures: Counter[tuple[int, ...]] = Counter()
    signature_pixels: Counter[tuple[int, ...]] = Counter()
    first_seen: dict[tuple[int, ...], tuple[str, int, int]] = {}

    for job in jobs:
        key = (job.phase, job.frame)
        sig = signature(job)
        phase_jobs[job.phase] += 1
        phase_pixels[job.phase] += job.pixels
        frame_jobs[key] += 1
        frame_pixels[key] += job.pixels
        signatures[sig] += 1
        signature_pixels[sig] += job.pixels
        first_seen.setdefault(sig, (job.phase, job.frame, job.number))

    args.frames_out.parent.mkdir(parents=True, exist_ok=True)
    with args.frames_out.open("w", newline="\n") as out:
        out.write("phase\tframe\tjobs\tscaled_pixels\tmame_cost_ns\tframe_fraction_54_5hz\n")
        for key in sorted(frame_jobs, key=lambda item: (item[1], item[0])):
            pixels = frame_pixels[key]
            cost = 41 * pixels
            fraction = cost / (1_000_000_000 / 54.5)
            out.write(f"{key[0]}\t{key[1]}\t{frame_jobs[key]}\t{pixels}\t{cost}\t{fraction:.6f}\n")

    ordered_signatures = sorted(
        signatures,
        key=lambda sig: (first_seen[sig][1], first_seen[sig][2], sig),
    )
    with args.signatures_out.open("w", newline="\n") as out:
        out.write("first_phase\tfirst_frame\tfirst_n\tcount\ttotal_pixels\tcmd\tsource\twidth\theight\tpalette\tcolor\tlrskip\txstep\tystep\n")
        for sig in ordered_signatures:
            phase, frame, number = first_seen[sig]
            cmd, source, width, height, palette, color, lrskip, xstep, ystep = sig
            out.write(
                f"{phase}\t{frame}\t{number}\t{signatures[sig]}\t"
                f"{signature_pixels[sig]}\t{cmd:04X}\t{source:08X}\t"
                f"{width}\t{height}\t{palette:04X}\t{color:04X}\t"
                f"{lrskip:04X}\t{xstep:04X}\t{ystep:04X}\n"
            )

    # The purple basketball wipe first appears at frame 1750 as ten 0x8002
    # slice images. Preserve every matching job from the first 80 frames so
    # order, position and exact cost can be replayed in RTL.
    transition_jobs = [
        job for job in jobs
        if job.phase == "coin_start" and 1750 <= job.frame <= 1830
    ]
    with args.transition_out.open("w", newline="\n") as out:
        out.write("frame\tn\tcmd\tsource\tx\ty\twidth\theight\tpalette\tlrskip\txstep\tystep\tscaled_pixels\tmame_cost_ns\tregs\n")
        for job in transition_jobs:
            r = job.regs
            out.write(
                f"{job.frame}\t{job.number}\t{r[1]:04X}\t{job.source:08X}\t"
                f"{s16(r[4])}\t{s16(r[5])}\t{r[6] & 0x3FF}\t{r[7] & 0x3FF}\t"
                f"{r[8]:04X}\t{r[0]:04X}\t{(r[10] or 0x100):04X}\t"
                f"{(r[11] or 0x100):04X}\t{job.pixels}\t{job.cost_ns}\t"
                f"{' '.join(f'{word:04X}' for word in r)}\n"
            )

    print(f"DMA_LEDGER jobs={len(jobs)} phases={len(phase_jobs)} frames={len(frame_jobs)}")
    for phase in phase_jobs:
        print(
            f"PHASE {phase} jobs={phase_jobs[phase]} "
            f"pixels={phase_pixels[phase]} cost_ns={41 * phase_pixels[phase]}"
        )
    for (phase, frame), count in sorted(
        frame_jobs.items(), key=lambda item: frame_pixels[item[0]], reverse=True
    )[:12]:
        pixels = frame_pixels[(phase, frame)]
        print(
            f"PEAK phase={phase} frame={frame} jobs={count} "
            f"pixels={pixels} cost_ns={41 * pixels}"
        )
    print(f"TRANSITION jobs={len(transition_jobs)} frames=1750..1830")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
