#!/usr/bin/env python3
"""Map a MAME-captured Hangtime frame back to the DMA jobs that remain visible.

This is a draw-order oracle, not a renderer: it replays each command through
the existing MAME-derived Wolf DMA model, records the last job to write every
framebuffer entry, and reports which jobs survive in a requested screen band.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import wolf_dma_model as model
from analyze_nbahangt_dma_ledger import parse_job
from gen_nbahangt_startup_frame_replay import load_register_writes


VRAM_WORDS = 0x80000
ROW_WORDS = 512
PAGE_LINES = 256


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", type=Path, required=True)
    parser.add_argument("--frame", type=int, required=True)
    parser.add_argument("--gfx", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--page", type=int, choices=(0, 1), required=True)
    parser.add_argument("--x0", type=int, default=0)
    parser.add_argument("--x1", type=int, default=399)
    parser.add_argument("--y0", type=int, default=0)
    parser.add_argument("--y1", type=int, default=253)
    args = parser.parse_args()

    jobs = []
    with args.events.open(encoding="ascii") as source:
        for raw in source:
            job = parse_job(raw.rstrip("\n"))
            if job is not None and job.frame == args.frame:
                jobs.append(job)
    if not jobs:
        raise SystemExit(f"no DMA jobs captured for frame {args.frame}")

    gfx = args.gfx.read_bytes()
    model.GFX_SIZE = len(gfx)
    model._GFX = gfx

    last_writer = [-1] * VRAM_WORDS
    write_counts = [0] * len(jobs)
    bounds = [None] * len(jobs)
    for index, job in enumerate(jobs):
        writes = model.run_case(load_register_writes(job.regs))
        write_counts[index] = len(writes)
        xmin = ROW_WORDS
        xmax = -1
        ymin = PAGE_LINES
        ymax = -1
        for line in writes:
            addr_text, _ = line.split()
            addr = int(addr_text, 16)
            if not 0 <= addr < VRAM_WORDS:
                continue
            last_writer[addr] = index
            row, x = divmod(addr, ROW_WORDS)
            if row // PAGE_LINES == args.page:
                y = row % PAGE_LINES
                xmin = min(xmin, x)
                xmax = max(xmax, x)
                ymin = min(ymin, y)
                ymax = max(ymax, y)
        if xmax >= 0:
            bounds[index] = (xmin, ymin, xmax, ymax)

    survivors = [0] * len(jobs)
    band_survivors = [0] * len(jobs)
    page_base = args.page * PAGE_LINES * ROW_WORDS
    for y in range(PAGE_LINES):
        for x in range(ROW_WORDS):
            index = last_writer[page_base + y * ROW_WORDS + x]
            if index < 0:
                continue
            survivors[index] += 1
            if args.x0 <= x <= args.x1 and args.y0 <= y <= args.y1:
                band_survivors[index] += 1

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="ascii", newline="\n") as out:
        out.write(
            "index\tn\tcmd\tsource\tx\ty\twidth\theight\tpalette\t"
            "writes\tsurvivors\tband_survivors\tbbox\n"
        )
        for index, job in enumerate(jobs):
            if band_survivors[index] == 0:
                continue
            r = job.regs
            bbox = bounds[index]
            bbox_text = "-" if bbox is None else ",".join(str(v) for v in bbox)
            out.write(
                f"{index + 1}\t{job.number}\t{r[1]:04X}\t{job.source:08X}\t"
                f"{r[4] & 0x3ff}\t{r[5] & 0x1ff}\t{r[6] & 0x3ff}\t"
                f"{r[7] & 0x3ff}\t{r[8]:04X}\t{write_counts[index]}\t"
                f"{survivors[index]}\t{band_survivors[index]}\t{bbox_text}\n"
            )

    print(
        f"FRAME_LAYER_MAP frame={args.frame} jobs={len(jobs)} page={args.page} "
        f"band={args.x0},{args.y0}..{args.x1},{args.y1} "
        f"contributors={sum(value != 0 for value in band_survivors)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
