#!/usr/bin/env bash
set -euo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build/game_profiles"
IVERILOG="${IVERILOG:-iverilog}"
VVP="${VVP:-vvp}"
mkdir -p "$BUILD"

"$IVERILOG" -g2012 -s tb_wolf_game_inputs \
  -o "$BUILD/inputs.vvp" \
  "$ROOT/rtl/wolf/wolf_game_inputs.sv" \
  "$ROOT/sim/tb_wolf_game_inputs.sv"
"$VVP" "$BUILD/inputs.vvp" | tee "$BUILD/inputs.log"
grep -q '^PASS: tb_wolf_game_inputs$' "$BUILD/inputs.log"

"$IVERILOG" -g2012 -s tb_wolf_ejb_injector \
  -o "$BUILD/ejb.vvp" \
  "$ROOT/rtl/wolf/wolf_game_inputs.sv" \
  "$ROOT/sim/tb_wolf_ejb_injector.sv"
"$VVP" "$BUILD/ejb.vvp" | tee "$BUILD/ejb.log"
grep -q '^PASS: tb_wolf_ejb_injector$' "$BUILD/ejb.log"

"$IVERILOG" -g2012 -DMUTATE_EJB_LAST3 -s tb_wolf_ejb_injector \
  -o "$BUILD/ejb_mutant.vvp" \
  "$ROOT/rtl/wolf/wolf_game_inputs.sv" \
  "$ROOT/sim/tb_wolf_ejb_injector.sv"
set +e
"$VVP" "$BUILD/ejb_mutant.vvp" >"$BUILD/ejb_mutant.log" 2>&1
mutant_rc=$?
set -e
if [ "$mutant_rc" -eq 0 ] ||
   ! grep -q '^MUTANT_CAUGHT: final P2 group ended before frame 120$' "$BUILD/ejb_mutant.log"; then
  cat "$BUILD/ejb_mutant.log"
  echo "FAIL: EJB final-count mutation escaped" >&2
  exit 1
fi
echo "PASS: EJB final-P2-count mutation rejected"

"$IVERILOG" -g2012 -s tb_wolf_gfx_interleave_mk3 \
  -o "$BUILD/mk3_gfx.vvp" \
  "$ROOT/rtl/wolf/wolf_gfx_interleave.sv" \
  "$ROOT/sim/tb_wolf_gfx_interleave_mk3.sv"
"$VVP" "$BUILD/mk3_gfx.vvp" | tee "$BUILD/mk3_gfx.log"
grep -q '^PASS: tb_wolf_gfx_interleave_mk3$' "$BUILD/mk3_gfx.log"

"$IVERILOG" -g2012 -DUSE_EXT_ROM -DUSE_EXT_GFX -s tb_wolf_wwf_io_shuffle \
  -o "$BUILD/wwf_io.vvp" \
  "$ROOT/rtl/pkg/wolf_pkg.sv" \
  "$ROOT/rtl/wolf/wolf_mem.sv" \
  "$ROOT/sim/tb_wolf_wwf_io_shuffle.sv"
"$VVP" "$BUILD/wwf_io.vvp" | tee "$BUILD/wwf_io.log"
grep -q '^PASS: tb_wolf_wwf_io_shuffle$' "$BUILD/wwf_io.log"

echo "PASS: all Wolf game-profile gates"
