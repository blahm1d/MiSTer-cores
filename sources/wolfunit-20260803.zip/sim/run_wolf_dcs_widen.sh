#!/usr/bin/env bash
# DCS download-window widening gate (4 MB -> 8 MB): five-chip sets land without
# wrap, >=4 MB readback is byte-exact, four-chip sets map bit-identically to the
# legacy window. No Quartus build.
set -euo pipefail

export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_wolf_dcs_widen
OUT="$ROOT/sim/build/$TB.vvp"
LOG="$ROOT/sim/build/$TB.log"

mkdir -p "$ROOT/sim/build"
iverilog -g2012 -s "$TB" -o "$OUT" \
  "$ROOT/rtl/wolf/wolf_gfxdl_fifo.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/wolf_dcs_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/$TB.sv"

cd "$ROOT"
vvp -n "$OUT" | tee "$LOG"
grep -q '^PASS wolf_dcs_widen$' "$LOG"
