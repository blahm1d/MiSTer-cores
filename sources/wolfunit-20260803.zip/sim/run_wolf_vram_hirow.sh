#!/usr/bin/env bash
# run_wolf_vram_hirow.sh — discriminating gate for the 19-bit VRAM entry-address fix
# (the rows>=512 aliasing = the cab attract gfx corruption). See tb_wolf_vram_hirow.sv.
#
#   ./run_wolf_vram_hirow.sh            normal: MUST print PASS (exit 0)
#   MUTATE=1 ./run_wolf_vram_hirow.sh   coverage: temp copy of stv_vram_ddr_top.sv with
#                                       fb_addr/scan_addr re-narrowed to [17:0] (the
#                                       exact shipped bug); the TB MUST FAIL.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
TB=tb_wolf_vram_hirow
mkdir -p "$ROOT/sim/build"

TOP="$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
if [ "${MUTATE:-0}" = "1" ]; then
  TOP="$ROOT/sim/build/stv_vram_ddr_top_mutant.sv"
  sed -e "s/input  logic \[18:0\]  fb_addr,/input  logic [17:0]  fb_addr,/" \
      -e "s/input  logic \[18:0\]  scan_addr,/input  logic [17:0]  scan_addr,/" \
      "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" > "$TOP"
  if cmp -s "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" "$TOP"; then
    echo "MUTATION ERROR: sed did not change the file"; exit 2
  fi
  echo "== MUTATION RUN: ports re-narrowed to [17:0]; the TB must FAIL =="
fi

OUT="$ROOT/sim/build/$TB.vvp"
iverilog -g2012 -s "$TB" -o "$OUT" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$TOP" \
  "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/$TB.sv"
cd "$ROOT/sim"
LOG="$ROOT/sim/build/$TB.log"
vvp "$OUT" | tee "$LOG"
if [ "${MUTATE:-0}" = "1" ]; then
  if grep -q "^PASS:" "$LOG"; then echo "MUTATION GATE FAIL: passed with the bug present"; exit 1
  else echo "MUTATION GATE OK: TB correctly FAILED"; exit 0; fi
else
  grep -q "^PASS:" "$LOG"
fi
