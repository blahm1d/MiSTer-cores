#!/usr/bin/env bash
# INTPEND (SHARED-P0016) distribution comparison on the ONE bench that actually
# REACHES the interrupt-servicing regime: the Hangtime heavy-IRQ assembly replay
# (real TMS34010 taking every DMA interrupt, real blitter, 186 blits, production
# 80MHz:20MHz cpu_ce ratio).
#
# The boot-stack harness (run_intpend_distribution.sh) never leaves POST -- it
# reports INT1_ASSERT=0 / BLITS=0 for BOTH variants, which is an instrument
# limit, not a null result. This bench is seeded past that.
#
# Runs the SAME bench twice, varying ONLY tms34010_io_regs.sv (HEAD vs working
# tree), and prints the paired counters. ModelSim ASE (license-free) is tried
# first; NEVER touches Questa FSE or Quartus.
set -uo pipefail

MS="${MS:-/c/intelFPGA_lite/17.0/modelsim_ase/win32aloem}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
TB=tb_wolf_hangtime_heavy_irq_replay
OUT="$ROOT/sim/build/intpend_heavy_dist"
mkdir -p "$OUT"

BASE_IO="$OUT/base_io/tms34010_io_regs.sv"
mkdir -p "$OUT/base_io"
( cd "$ROOT" && git show HEAD:rtl/tms34010/rtl/io/tms34010_io_regs.sv ) > "$BASE_IO"

run_one() {
  local variant="$1" io_override="$2"
  local wl="$OUT/work_$variant"
  local log="$OUT/$variant.log"

  SRC=( "$CORE/rtl/tms34010_pkg.sv" )
  while IFS= read -r f; do
    case "$f" in
      */tms34010_pkg.sv) continue;;
      */io/tms34010_io_regs.sv) [ -n "$io_override" ] && continue;;
    esac
    SRC+=( "$f" )
  done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
  [ -n "$io_override" ] && SRC+=( "$io_override" )
  SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv"
         "$ROOT/rtl/yunit/yunit_mem_cdc.sv"
         "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv"
         "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_memsys.sv"
         "$ROOT/sim/$TB.sv" )

  # MUST be a direct child of sim/build: the TB opens its seed as
  # "../nbahangt_heavy_irq_seed/..." relative to the run directory.
  local rd="$ROOT/sim/build/intpend_heavy_run_$variant"
  mkdir -p "$rd"
  ( cd "$rd" || exit 1
    rm -rf "$wl"; "$MS/vlib.exe" "$wl" >/dev/null
    "$MS/vlog.exe" -sv -quiet -svinputport=var -work "$wl" "${SRC[@]}" \
      > "$OUT/$variant.vlog.log" 2>&1 || {
        echo "COMPILE FAILED ($variant) -- see $OUT/$variant.vlog.log" >&2
        grep -m5 "^\*\* Error" "$OUT/$variant.vlog.log" >&2; exit 1; }
    "$MS/vsim.exe" -c -quiet -lib "$wl" -do "run -all; quit -f" "$TB" > "$log" 2>&1
  ) || return 1
  echo "---- $variant ----"
  sed -n 's/^# //p' "$log" | grep -iE "RESULT|INT1|BLIT|INTPEND|X1P|ASSEMBLY_ORACLE|PAGE_ORACLE|blits" | head -40
}

echo "=== INTPEND distribution: Hangtime heavy-IRQ assembly replay ==="
run_one base "$BASE_IO" || echo "(base run failed)"
run_one fix  ""         || echo "(fix run failed)"
