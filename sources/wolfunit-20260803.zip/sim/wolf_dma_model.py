#!/usr/bin/env python3
"""
wolf_dma_model.py -- PYTHON GOLDEN MODEL of the Midway T/Wolf-unit DMA blitter
(as used by UMK3), transcribed line-by-line from MAME 0.280.

GOSPEL (all file:line citations below refer to these vendored files):
  D:/deck/fpga/umk3/mame-gospel/midway/midtunit_v.cpp   (dma_w :695-836, dma_draw :431-610)
  D:/deck/fpga/umk3/mame-gospel/midway/midtunit_v.h     (DMA enum :88-108, masks :76-77, op_type_t :55-60)
  D:/deck/fpga/umk3/mame-gospel/midway/midtunit_v.ipp   (dispatch-table builder :11-81)
      NOTE: midtunit_v.ipp was NOT originally vendored; it was fetched from the
      mamedev/mame `mame0280` tag (src/mame/midway/midtunit_v.ipp) and added to
      the gospel directory.  midtunit_v.cpp:12 includes it; INIT_TEMPLATED_DMA_
      DRAW_GROUP is invoked at midtunit_v.cpp:216-219.

gfx_rom_large FINDING (cited):
  Wolf-unit machines instantiate MIDWUNIT_VIDEO (midwunit.cpp:627
  "MIDWUNIT_VIDEO(config, m_video, m_palette);").  The midwunit_video_device
  constructor sets m_gfx_rom_large = true (midtunit_v.cpp:70).  (T-unit also
  calls set_gfx_rom_large(true) at midtunit.cpp:656 for later games, but the
  Wolf path is the constructor.)  Therefore the small-ROM normalization at
  midtunit_v.cpp:753-754 ("if (!m_gfx_rom_large && gfxoffset >= 0x2000000)
  gfxoffset -= 0x2000000;") does NOT apply -> GFX_ROM_LARGE = True below.

PINNED SHARED CONTRACT (sibling RTL agent implements counterpart from same gospel):
  - vectors JSON: [{"name": "...", "writes": [[offset, value], ...]}, ...]
    offset = CPU-visible dma_w register offset 0..15, mem_mask always 0xffff,
    writes applied strictly in order, ALL 18 registers reset to 0 per case.
  - gfx stub: GFX_SIZE = 65536; gfx[i] = (i*7 + 3) & 0xff; out-of-range -> 0x00.
  - output: one line per framebuffer word write, in exact write order,
    '%05X %04X' % (sy*512 + sx, data)  -- sx is post-XPOSMASK (0x3ff), NOT
    re-masked to 511; LF endings.
  - blit-completion side effects (COMMAND bit15 clear at dma_done
    midtunit_v.cpp:624-628, IRQ line, 41ns/pixel timer :835) are NOT in the
    stream.

CLI:
  python wolf_dma_model.py <vectors.json> <outdir>   -> <outdir>/<name>.golden.txt
  python wolf_dma_model.py --selftest                -> run embedded hand-walked cases
"""

import json
import os
import sys

# ---------------------------------------------------------------------------
# Constants for the DMA chip -- midtunit_v.h:76-77
# ---------------------------------------------------------------------------
XPOSMASK = 0x3ff        # midtunit_v.h:76
YPOSMASK = 0x1ff        # midtunit_v.h:77

# op_type_t -- midtunit_v.h:55-60
PIXEL_SKIP  = 0         # midtunit_v.h:57
PIXEL_COLOR = 1         # midtunit_v.h:58
PIXEL_COPY  = 2         # midtunit_v.h:59

# DMA register enum -- midtunit_v.h:88-108
DMA_LRSKIP    = 0       # midtunit_v.h:90
DMA_COMMAND   = 1       # midtunit_v.h:91
DMA_OFFSETLO  = 2       # midtunit_v.h:92
DMA_OFFSETHI  = 3       # midtunit_v.h:93
DMA_XSTART    = 4       # midtunit_v.h:94
DMA_YSTART    = 5       # midtunit_v.h:95
DMA_WIDTH     = 6       # midtunit_v.h:96
DMA_HEIGHT    = 7       # midtunit_v.h:97
DMA_PALETTE   = 8       # midtunit_v.h:98
DMA_COLOR     = 9       # midtunit_v.h:99
DMA_SCALE_X   = 10      # midtunit_v.h:100
DMA_SCALE_Y   = 11      # midtunit_v.h:101
DMA_TOPCLIP   = 12      # midtunit_v.h:102
DMA_BOTCLIP   = 13      # midtunit_v.h:103
DMA_UNKNOWN_E = 14      # midtunit_v.h:104 (MK1/2 never write; NBA writes 0)
DMA_CONFIG    = 15      # midtunit_v.h:105
DMA_LEFTCLIP  = 16      # midtunit_v.h:106 (pseudo-register)
DMA_RIGHTCLIP = 17      # midtunit_v.h:107 (pseudo-register)

# Wolf-unit uses MIDWUNIT_VIDEO whose ctor sets m_gfx_rom_large = true
# (midtunit_v.cpp:70; instantiated at midwunit.cpp:627).
GFX_ROM_LARGE = True

# ---------------------------------------------------------------------------
# Mode dispatch table.
#
# Transcribed from INIT_TEMPLATED_DMA_DRAW_GROUP, midtunit_v.ipp:49-81.
# dma_w indexes the draw-function tables as (command & 0x1f)*8 + bpp
# (midtunit_v.cpp:814/:816/:823/:825), so the group index is command&0x1f:
# bit4 of the command (0x10) IS the XFlip selector (groups 16..31 use the
# *_XF macros = XFlip template arg true, .ipp:40-47/66-81), and bits 3..0
# pick the (Zero, NonZero) pixel-op pair.  Within a group, entry i+0 is the
# BitsPerPixel=8 template and i+1..i+7 are 1..7 bpp (.ipp:11-19), matching
# bpp = (command >> 12) & 7 (midtunit_v.cpp:722) with field value 0 -> 8bpp.
#
# CROSS-CHECK: this table agrees exactly with the switch(command & 0xf)
# mapping in log_bitmap, midtunit_v.cpp:876-893 (cases 4&5 -> C0, 6&7 -> C0P1,
# 8&10 -> C1, 9&11 -> P0C1, 12..15 -> C0C1, 0 -> none).  The '0x0D decode bug'
# claimed by a prior agent is a FALSE ALARM: .ipp:63 gives group 13 = C0C1,
# identical to case 13 at midtunit_v.cpp:890.
#
# Entry: None => dma_draw_none (no pixels drawn, midtunit_v.h:80),
#        else (XFlip, Zero, NonZero).
MODE_TABLE = [
    None,                                # 0x00 NONE      .ipp:50
    (False, PIXEL_COPY,  PIXEL_SKIP ),   # 0x01 P0        .ipp:51 (macro .ipp:31)
    (False, PIXEL_SKIP,  PIXEL_COPY ),   # 0x02 P1        .ipp:52 (macro .ipp:32)
    (False, PIXEL_COPY,  PIXEL_COPY ),   # 0x03 P0P1      .ipp:53 (macro .ipp:35)
    (False, PIXEL_COLOR, PIXEL_SKIP ),   # 0x04 C0        .ipp:54 (macro .ipp:33)
    (False, PIXEL_COLOR, PIXEL_SKIP ),   # 0x05 C0        .ipp:55
    (False, PIXEL_COLOR, PIXEL_COPY ),   # 0x06 C0P1      .ipp:56 (macro .ipp:37)
    (False, PIXEL_COLOR, PIXEL_COPY ),   # 0x07 C0P1      .ipp:57
    (False, PIXEL_SKIP,  PIXEL_COLOR),   # 0x08 C1        .ipp:58 (macro .ipp:34)
    (False, PIXEL_COPY,  PIXEL_COLOR),   # 0x09 P0C1      .ipp:59 (macro .ipp:38)
    (False, PIXEL_SKIP,  PIXEL_COLOR),   # 0x0A C1        .ipp:60
    (False, PIXEL_COPY,  PIXEL_COLOR),   # 0x0B P0C1      .ipp:61
    (False, PIXEL_COLOR, PIXEL_COLOR),   # 0x0C C0C1      .ipp:62 (macro .ipp:36)
    (False, PIXEL_COLOR, PIXEL_COLOR),   # 0x0D C0C1      .ipp:63
    (False, PIXEL_COLOR, PIXEL_COLOR),   # 0x0E C0C1      .ipp:64
    (False, PIXEL_COLOR, PIXEL_COLOR),   # 0x0F C0C1      .ipp:65
    None,                                # 0x10 NONE      .ipp:66
    (True,  PIXEL_COPY,  PIXEL_SKIP ),   # 0x11 P0_XF     .ipp:67 (macro .ipp:40)
    (True,  PIXEL_SKIP,  PIXEL_COPY ),   # 0x12 P1_XF     .ipp:68 (macro .ipp:41)
    (True,  PIXEL_COPY,  PIXEL_COPY ),   # 0x13 P0P1_XF   .ipp:69 (macro .ipp:44)
    (True,  PIXEL_COLOR, PIXEL_SKIP ),   # 0x14 C0_XF     .ipp:70 (macro .ipp:42)
    (True,  PIXEL_COLOR, PIXEL_SKIP ),   # 0x15 C0_XF     .ipp:71
    (True,  PIXEL_COLOR, PIXEL_COPY ),   # 0x16 C0P1_XF   .ipp:72 (macro .ipp:46)
    (True,  PIXEL_COLOR, PIXEL_COPY ),   # 0x17 C0P1_XF   .ipp:73
    (True,  PIXEL_SKIP,  PIXEL_COLOR),   # 0x18 C1_XF     .ipp:74 (macro .ipp:43)
    (True,  PIXEL_COPY,  PIXEL_COLOR),   # 0x19 P0C1_XF   .ipp:75 (macro .ipp:47)
    (True,  PIXEL_SKIP,  PIXEL_COLOR),   # 0x1A C1_XF     .ipp:76
    (True,  PIXEL_COPY,  PIXEL_COLOR),   # 0x1B P0C1_XF   .ipp:77
    (True,  PIXEL_COLOR, PIXEL_COLOR),   # 0x1C C0C1_XF   .ipp:78 (macro .ipp:45)
    (True,  PIXEL_COLOR, PIXEL_COLOR),   # 0x1D C0C1_XF   .ipp:79
    (True,  PIXEL_COLOR, PIXEL_COLOR),   # 0x1E C0C1_XF   .ipp:80
    (True,  PIXEL_COLOR, PIXEL_COLOR),   # 0x1F C0C1_XF   .ipp:81
]

# ---------------------------------------------------------------------------
# gfx source stub -- PINNED SHARED CONTRACT (both sides hardcode this)
# ---------------------------------------------------------------------------
GFX_SIZE = 65536
_GFX = bytes(((i * 7 + 3) & 0xff) for i in range(GFX_SIZE))


def gfx_byte(i):
    """Byte fetch from the shared gfx stub; out-of-range reads as 0x00."""
    if 0 <= i < GFX_SIZE:
        return _GFX[i]
    return 0x00


class dma_state_t(object):
    """m_dma_state -- midtunit_v.h:121-145 (fields used by dma_draw only;
    rowbits is never written by dma_w and never read by dma_draw)."""

    def __init__(self):
        self.offset    = 0   # source offset, IN BITS (midtunit_v.h:125)
        self.xpos      = 0
        self.ypos      = 0
        self.width     = 0
        self.height    = 0
        self.palette   = 0
        self.color     = 0
        self.yflip     = 0
        self.preskip   = 0
        self.postskip  = 0
        self.topclip   = 0
        self.botclip   = 0
        self.leftclip  = 0
        self.rightclip = 0
        self.startskip = 0
        self.endskip   = 0
        self.xstep     = 0
        self.ystep     = 0


class WolfDMA(object):
    """One blitter instance: 18-entry register file + dma_state + write stream.

    The framebuffer itself is not modeled (contract); every d[sx] = ... store
    in dma_draw is instead emitted to self.stream as (sy*512 + sx, data).
    """

    def __init__(self):
        # m_dma_register[18], zero at reset (midtunit_v.cpp:59 std::fill(...,0)
        # -- and the shared contract resets all 18 to 0 per case)
        self.m_dma_register = [0] * 18
        self.m_dma_state = dma_state_t()
        self.stream = []   # ordered (addr, data) framebuffer word writes

    # -- fast pixel extractor ------------------------------------------------
    # EXTRACTGEN(m) -- midtunit_v.cpp:427 (generic form):
    #   (((base[o >> 3] | (base[(o >> 3) + 1] << 8)) >> (o & 7)) & (m))
    # base = m_dma_state.gfxrom (a BYTE array); o is a BIT offset.
    def EXTRACTGEN(self, o, m):
        return ((gfx_byte(o >> 3) | (gfx_byte((o >> 3) + 1) << 8)) >> (o & 7)) & m

    # -- DMA reader quirk (not used by the vector contract, kept for fidelity)
    def dma_r(self, offset):
        # midtunit_v.cpp:638-645: rmpgwt/openice sometimes read register 0
        # expecting DMA status; register 0 maps to register 1.
        if offset == 0:
            offset = 1
        return self.m_dma_register[offset]

    # -- core blitter routine -- dma_draw template, midtunit_v.cpp:431-610 ---
    def dma_draw(self, BitsPerPixel, XFlip, Skip, Scale, Zero, NonZero):
        st = self.m_dma_state
        height = st.height << 8                      # :434
        # base = m_dma_state.gfxrom                  # :435 (gfx stub here)
        offset = st.offset & 0xFFFFFFFF              # :436 uint32_t
        pal = st.palette                             # :437
        color = (pal | st.color) & 0xFFFF            # :438 uint16_t
        sy = st.ypos                                 # :439
        iy = 0                                       # :440
        mask = (1 << BitsPerPixel) - 1               # :442
        xstep = st.xstep if Scale else 0x100         # :443

        # loop over the height                       # :445
        while iy < height:                           # :446
            startskip = st.startskip << 8            # :448
            endskip = st.endskip << 8                # :449 [[maybe_unused]] local
            width = st.width << 8                    # :450
            sx = st.xpos                             # :451
            ix = 0                                   # :452
            o = offset                               # :454 uint32_t o = offset
            pre = 0                                  # :456 (int pre, post; -- only
            post = 0                                 #  read when Skip, which also
                                                     #  always writes them first)

            # handle skipping                        # :458
            if Skip:                                 # :459-460
                value = self.EXTRACTGEN(o, 0xff)     # :461
                o = (o + 8) & 0xFFFFFFFF             # :462

                # adjust for preskip                 # :464
                pre = (value & 0x0f) << (st.preskip + 8)   # :465  (note the +8)
                tx = pre // xstep                    # :466 (both non-negative -> C
                                                     #  truncation == floor)
                if XFlip:                            # :467
                    sx = (sx - tx) & XPOSMASK        # :468
                else:
                    sx = (sx + tx) & XPOSMASK        # :470
                ix += tx * xstep                     # :471

                # adjust for postskip                # :473
                post = ((value >> 4) & 0x0f) << (st.postskip + 8)  # :474
                width -= post                        # :475
                endskip -= post                      # :476 (local; never read after)

            # handle Y clipping                      # :479
            # ':480-481  if (sy < topclip || sy > botclip) goto clipy;'
            if not (sy < st.topclip or sy > st.botclip):
                # handle start skip                  # :483
                if ix < startskip:                   # :484
                    tx = ((startskip - ix) // xstep) * xstep   # :486
                    ix += tx                                   # :487
                    o = (o + (tx >> 8) * BitsPerPixel) & 0xFFFFFFFF  # :488

                # handle end skip                    # :491
                # (uses m_dma_state.endskip, NOT the post-adjusted local) :492
                if (width >> 8) > st.width - st.endskip:       # :492
                    width = (st.width - st.endskip) << 8       # :493

                # determine destination pointer      # :495
                dbase = sy * 512                     # :499 d = &m_local_videoram[sy*512]

                # loop until we draw the entire width  # :502
                while ix < width:                    # :503
                    # only process if not clipped    # :505
                    if sx >= st.leftclip and sx <= st.rightclip:  # :506
                        if Zero == NonZero:          # :508
                            # special case similar handling of zero/non-zero :510
                            if Zero == PIXEL_COLOR:                    # :511
                                self.stream.append((dbase + sx, color))       # :512 d[sx] = color
                            elif Zero == PIXEL_COPY:                   # :513
                                self.stream.append((dbase + sx,
                                    (self.EXTRACTGEN(o, mask) | pal) & 0xFFFF))  # :514
                        else:
                            # otherwise, read the pixel and look       # :518
                            pixel = self.EXTRACTGEN(o, mask)           # :519

                            # non-zero pixel case                      # :521
                            if pixel:                                  # :522
                                if NonZero == PIXEL_COLOR:             # :524
                                    self.stream.append((dbase + sx, color))   # :525
                                elif NonZero == PIXEL_COPY:            # :526
                                    self.stream.append((dbase + sx,
                                        (pixel | pal) & 0xFFFF))              # :527
                            # zero pixel case                          # :530
                            else:
                                if Zero == PIXEL_COLOR:                # :533
                                    self.stream.append((dbase + sx, color))   # :534
                                elif Zero == PIXEL_COPY:               # :535
                                    self.stream.append((dbase + sx,
                                        pal & 0xFFFF))                        # :536

                    # update pointers                # :541
                    if XFlip:                        # :542
                        sx = (sx - 1) & XPOSMASK     # :543
                    else:
                        sx = (sx + 1) & XPOSMASK     # :545

                    # advance to the next pixel      # :547
                    if not Scale:                    # :548
                        ix += 0x100                  # :550
                        o = (o + BitsPerPixel) & 0xFFFFFFFF   # :551
                    else:
                        tx = ix >> 8                 # :555
                        ix += xstep                  # :556
                        tx = (ix >> 8) - tx          # :557
                        o = (o + BitsPerPixel * tx) & 0xFFFFFFFF  # :558

            # clipy:                                 # :562
            # advance to the next row                # :563
            if st.yflip:                             # :564
                sy = (sy - 1) & YPOSMASK             # :565
            else:
                sy = (sy + 1) & YPOSMASK             # :567
            if not Scale:                            # :568
                iy += 0x100                          # :570
                width = st.width                     # :571 (pixel count, NOT <<8)
                if Skip:                             # :572
                    offset = (offset + 8) & 0xFFFFFFFF        # :574
                    width -= (pre + post) >> 8       # :575 (pre/post from THIS
                                                     #  row's :465/:474, i.e. the
                                                     #  '+8'-shifted values)
                    if width > 0:                    # :576
                        offset = (offset + width * BitsPerPixel) & 0xFFFFFFFF
                else:
                    offset = (offset + width * BitsPerPixel) & 0xFFFFFFFF  # :580
            else:
                ty = iy >> 8                         # :585
                iy += st.ystep                       # :586
                ty = (iy >> 8) - ty                  # :587
                if not Skip:                         # :588
                    offset = (offset + ty * st.width * BitsPerPixel) & 0xFFFFFFFF  # :590
                else:
                    # ':592  else if (ty--)' -- post-decrement: test old value,
                    # then decrement.  If ty was 0, offset is NOT advanced at
                    # all this row (faithful; do not 'fix').
                    _t = ty
                    ty -= 1
                    if _t:                           # :592
                        o = (offset + 8) & 0xFFFFFFFF                 # :594
                        width = st.width - ((pre + post) >> 8)        # :595
                        if width > 0:                                 # :596
                            o = (o + width * BitsPerPixel) & 0xFFFFFFFF
                        while True:                  # :597 'while (ty--)'
                            _t2 = ty
                            ty -= 1
                            if not _t2:
                                break
                            value = self.EXTRACTGEN(o, 0xff)          # :599
                            o = (o + 8) & 0xFFFFFFFF                  # :600
                            # NOTE the GOSPEL INCONSISTENCY, transcribed
                            # EXACTLY: here pre is '<< preskip' (:601) with NO
                            # +8, unlike ':465 << (preskip + 8)'.  post likewise
                            # ':602 << postskip' vs ':474 << (postskip + 8)'.
                            pre = (value & 0x0f) << st.preskip        # :601
                            post = ((value >> 4) & 0x0f) << st.postskip  # :602
                            width = st.width - pre - post             # :603
                            if width > 0:                             # :604
                                o = (o + width * BitsPerPixel) & 0xFFFFFFFF
                        offset = o                   # :606

    # -- DMA write handler -- dma_w, midtunit_v.cpp:695-836 ------------------
    def dma_w(self, offset, data, mem_mask=0xffff):
        # register_map -- midtunit_v.cpp:697-701: bank 0 (CONFIG bit5 clear)
        # aliases CPU offsets 12/13 onto pseudo-regs 16/17 (LEFT/RIGHTCLIP);
        # bank 1 maps them to 12/13 (TOP/BOTCLIP).
        register_map = (
            (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 16, 17, 14, 15),  # :699
            (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15),  # :700
        )
        regbank = (self.m_dma_register[DMA_CONFIG] >> 5) & 1          # :702
        # pixels = 0                                                  # :703 (timer only)

        # blend with the current register contents                    # :705
        regnum = register_map[regbank][offset]                        # :706
        # COMBINE_DATA(&m_dma_register[regnum])                       # :707
        self.m_dma_register[regnum] = (
            (self.m_dma_register[regnum] & ~mem_mask & 0xFFFF) | (data & mem_mask))

        # only writes to DMA_COMMAND actually cause actions           # :709
        if regnum != DMA_COMMAND:                                     # :710
            return                                                    # :711

        # high bit triggers action                                    # :713
        command = self.m_dma_register[DMA_COMMAND]                    # :714
        # m_dma_irq_cb(CLEAR_LINE)                                    # :715 (not in stream)
        if not (command & 0x8000):                                    # :716
            return                                                    # :717

        st = self.m_dma_state

        # determine bpp                                               # :721
        bpp = (command >> 12) & 7                                     # :722

        # fill in the basic data                                      # :724
        st.xpos = self.m_dma_register[DMA_XSTART] & XPOSMASK          # :725
        st.ypos = self.m_dma_register[DMA_YSTART] & YPOSMASK          # :726
        st.width = self.m_dma_register[DMA_WIDTH] & 0x3ff             # :727
        st.height = self.m_dma_register[DMA_HEIGHT] & 0x3ff           # :728
        st.palette = self.m_dma_register[DMA_PALETTE] & 0x7f00        # :729
        st.color = self.m_dma_register[DMA_COLOR] & 0xff              # :730

        # fill in the rev 2 data                                      # :732
        st.yflip = (command & 0x20) >> 5                              # :733
        st.preskip = (command >> 8) & 3                               # :734
        st.postskip = (command >> 10) & 3                             # :735
        # xstep/ystep: 0 -> 0x100 (unmasked 16-bit register value otherwise)
        st.xstep = self.m_dma_register[DMA_SCALE_X] if self.m_dma_register[DMA_SCALE_X] else 0x100  # :736
        st.ystep = self.m_dma_register[DMA_SCALE_Y] if self.m_dma_register[DMA_SCALE_Y] else 0x100  # :737

        # clip the clippers                                           # :739
        st.topclip = self.m_dma_register[DMA_TOPCLIP] & 0x1ff         # :740
        st.botclip = self.m_dma_register[DMA_BOTCLIP] & 0x1ff         # :741
        st.leftclip = self.m_dma_register[DMA_LEFTCLIP] & 0x3ff       # :742
        st.rightclip = self.m_dma_register[DMA_RIGHTCLIP] & 0x3ff     # :743

        # determine the offset                                        # :745
        gfxoffset = (self.m_dma_register[DMA_OFFSETLO]
                     | (self.m_dma_register[DMA_OFFSETHI] << 16))     # :746

        # special case: drawing mode C doesn't need to know about any pixel data :748
        if (command & 0x0f) == 0x0c:                                  # :749
            gfxoffset = 0                                             # :750

        # determine the location                                      # :752
        # :753-754 gated on !m_gfx_rom_large -- Wolf-unit is MIDWUNIT_VIDEO
        # (midwunit.cpp:627) whose ctor sets m_gfx_rom_large = true
        # (midtunit_v.cpp:70), so this branch is dead here:
        if not GFX_ROM_LARGE and gfxoffset >= 0x2000000:              # :753
            gfxoffset -= 0x2000000                                    # :754
        if gfxoffset >= 0xf8000000:                                   # :755
            gfxoffset -= 0xf8000000                                   # :756
        if gfxoffset < 0x10000000:                                    # :757
            st.offset = gfxoffset                                     # :758
        else:
            # 'DMA source out of range' -> goto skipdma               # :761-762
            # (skipdma only arms the 0-pixel done-timer :834-835; not in stream)
            return

        # :765-780 LOG_DMA / debug logging -- compiled out (LOG_DMA 0), skipped.

        # there seems to be two types of behavior for the DMA chip    # :782
        # for MK1 and MK2, the upper byte of the LRSKIP is the        # :783
        # starting skip value, and the lower byte is the ending       # :784
        # skip value; for the NBA Jam, Hangtime, and Open Ice, the    # :785
        # full word seems to be the starting skip value.              # :786
        if command & 0x40:                                            # :787
            st.startskip = self.m_dma_register[DMA_LRSKIP] & 0xff     # :789
            st.endskip = self.m_dma_register[DMA_LRSKIP] >> 8         # :790
        else:
            st.startskip = 0                                          # :794
            st.endskip = self.m_dma_register[DMA_LRSKIP]              # :795

        # :798-808 log_bitmap (PNG debug logging) -- disabled (m_log_png false).

        # then draw                                                   # :810
        # :811 noscale iff xstep == 0x100 && ystep == 0x100; :813/:822 Skip =
        # command & 0x80; table index = (command & 0x1f)*8 + bpp (:814 etc.).
        Skip = bool(command & 0x80)
        Scale = not (st.xstep == 0x100 and st.ystep == 0x100)         # :811
        entry = MODE_TABLE[command & 0x1f]                            # :814/:816/:823/:825
        if entry is not None:
            XFlip, Zero, NonZero = entry
            # within a group, index+0 = 8bpp, +1..+7 = 1..7 bpp (.ipp:11-19)
            BitsPerPixel = 8 if bpp == 0 else bpp
            self.dma_draw(BitsPerPixel, XFlip, Skip, Scale, Zero, NonZero)
        # else: dma_draw_none (midtunit_v.h:80) -- draws nothing.

        # :817-830 pixel counting and :834-835 done-timer (41ns/pixel) +
        # dma_done (:624-628, clears COMMAND bit15 + raises IRQ) are blit-
        # completion side effects -- NOT part of the stream per the contract.


# ---------------------------------------------------------------------------
# Case runner
# ---------------------------------------------------------------------------
def run_case(writes):
    """Fresh blitter (all 18 regs = 0), apply [offset, value] writes in order,
    return the stream as contract-format lines."""
    dma = WolfDMA()
    for off, val in writes:
        dma.dma_w(off & 0xf, val & 0xffff, 0xffff)
    return ["%05X %04X" % (addr, data) for (addr, data) in dma.stream]


def _num(v):
    return v if isinstance(v, int) else int(str(v), 0)


def main_vectors(vec_path, outdir):
    with open(vec_path, "r") as f:
        cases = json.load(f)
    os.makedirs(outdir, exist_ok=True)
    for case in cases:
        name = case["name"]
        writes = [(_num(w[0]), _num(w[1])) for w in case["writes"]]
        lines = run_case(writes)
        out_path = os.path.join(outdir, name + ".golden.txt")
        with open(out_path, "w", newline="\n") as f:
            for line in lines:
                f.write(line + "\n")
        print("%s: %d writes -> %s" % (name, len(lines), out_path))


# ---------------------------------------------------------------------------
# Embedded self-test: micro cases verified by HAND-WALKING the C++.
# ---------------------------------------------------------------------------
#
# Case (a) selftest_mode_c_fill: mode 0xC solid fill, 4x2 at (5,3), noscale.
#   Writes: CONFIG=0x0020 (bank1, :702) then offsets 12/13 -> TOPCLIP=0,
#   BOTCLIP=511; CONFIG=0 (bank0) then 12/13 -> LEFTCLIP=0, RIGHTCLIP=1023
#   (register_map :697-701).  XSTART=5, YSTART=3, WIDTH=4, HEIGHT=2,
#   PALETTE=0x2100, COLOR=0x37, COMMAND=0x800C.
#   HAND WALK:
#     command=0x800C: bit15 set (:716); bpp=(>>12)&7=0 -> BitsPerPixel=8
#     (.ipp:12); Skip=(0x800C&0x80)=0; SCALE_X/Y regs=0 -> xstep=ystep=0x100
#     (:736-737) -> noscale (:811); mode=command&0x1f=0x0C -> C0C1 =
#     (Zero,NonZero)=(COLOR,COLOR), XFlip=false (.ipp:62).
#     (command&0x0f)==0x0c -> gfxoffset=0 (:749-750); in range -> offset=0.
#     command&0x40=0 -> startskip=0, endskip=reg0=0 (:794-795).
#     dma_draw: height=2<<8=0x200; color=0x2100|0x37=0x2137 (:438).
#     Row iy=0: sy=3, in [0,511] (:480); startskip=0; endskip check:
#       width>>8=4 > 4-0? no (:492). d base=3*512=1536.
#       4 pixels sx=5..8, all in [0,1023] (:506); Zero==NonZero==COLOR ->
#       d[sx]=0x2137 (:511-512).  Addrs 1541..1544 = 0x00605..0x00608.
#     clipy: sy=4 (:567); iy=0x100; width=4 (:571); offset += 4*8=32 (:580).
#     Row iy=0x100: sy=4 -> base 4*512=2048; addrs 2053..2056 =
#       0x00805..0x00808, data 0x2137.  iy=0x200 == height -> done.
SELFTEST_A = {
    "name": "selftest_mode_c_fill",
    "writes": [
        [15, 0x0020],   # CONFIG: bit5=1 -> bank 1 for offsets 12/13 (:702)
        [12, 0x0000],   # -> DMA_TOPCLIP = 0    (:700)
        [13, 0x01FF],   # -> DMA_BOTCLIP = 511  (:700)
        [15, 0x0000],   # CONFIG: bit5=0 -> bank 0
        [12, 0x0000],   # -> DMA_LEFTCLIP  (pseudo-reg 16) = 0    (:699)
        [13, 0x03FF],   # -> DMA_RIGHTCLIP (pseudo-reg 17) = 1023 (:699)
        [4, 5], [5, 3], [6, 4], [7, 2],
        [8, 0x2100], [9, 0x0037],
        [1, 0x800C],
    ],
    "expect": [
        "00605 2137", "00606 2137", "00607 2137", "00608 2137",
        "00805 2137", "00806 2137", "00807 2137", "00808 2137",
    ],
}

# Case (b) selftest_bpp8_copy: bpp=8 noscale copy (mode 3 = P0P1: Zero==
#   NonZero==COPY), 3x1 at (10,7), palette 0x1200, gfxoffset=0x100 bits.
#   HAND WALK:
#     command=0x8003: bpp=0 -> 8bpp; mode 3 -> (COPY,COPY) no flip (.ipp:53);
#     Skip=0, noscale.  gfxoffset=reg2|reg3<<16=0x100 (:746), <0x10000000 ->
#     offset=0x100 bits = byte 0x20.
#     gfx stub: gfx[0x20]=(32*7+3)&0xff=227=0xE3; gfx[0x21]=234=0xEA;
#       gfx[0x22]=241=0xF1; gfx[0x23]=248=0xF8.
#     Row sy=7 (in clip), 3 pixels, Zero==NonZero==COPY -> d[sx]=
#       EXTRACTGEN(0xff)|pal (:513-514):
#       o=0x100: (gfx[0x20]|gfx[0x21]<<8)>>0 &0xff = 0xE3 -> 0x12E3 @ 7*512+10
#         = 3594 = 0x00E0A
#       o=0x108: 0xEA -> 0x12EA @ 0x00E0B
#       o=0x110: 0xF1 -> 0x12F1 @ 0x00E0C
SELFTEST_B = {
    "name": "selftest_bpp8_copy",
    "writes": [
        [15, 0x0020], [12, 0x0000], [13, 0x01FF],
        [15, 0x0000], [12, 0x0000], [13, 0x03FF],
        [2, 0x0100], [3, 0x0000],
        [4, 10], [5, 7], [6, 3], [7, 1],
        [8, 0x1200],
        [1, 0x8003],
    ],
    "expect": [
        "00E0A 12E3", "00E0B 12EA", "00E0C 12F1",
    ],
}

# Case (c) selftest_clipped_copy: same copy but 3x2 with TOPCLIP=8 (row at
#   sy=7 fully Y-clipped, :480) and LEFTCLIP=11 (sx=10 X-clipped, :506).
#   HAND WALK:
#     Row0: sy=7 < topclip 8 -> goto clipy (:480-481): NO writes, but the
#       row advance still runs: sy->8, iy=0x100, width=st.width=3 (:571),
#       offset += 3*8=24 -> offset=0x118 (:580).
#     Row1: sy=8 in [8,511].  d base=8*512=4096.
#       sx=10: 10 < leftclip 11 -> clipped, no write (:506); o += 8 -> 0x120.
#       sx=11: o=0x120 -> byte 0x24: gfx[0x24]=(36*7+3)&0xff=255=0xFF ->
#         0x12FF @ 4096+11=4107=0x0100B.
#       sx=12: o=0x128 -> byte 0x25: gfx[0x25]=(37*7+3)&0xff=262&0xff=0x06 ->
#         0x1206 @ 0x0100C.
#     iy=0x200 == height (2<<8) -> done.
SELFTEST_C = {
    "name": "selftest_clipped_copy",
    "writes": [
        [15, 0x0020], [12, 0x0008], [13, 0x01FF],
        [15, 0x0000], [12, 0x000B], [13, 0x03FF],
        [2, 0x0100], [3, 0x0000],
        [4, 10], [5, 7], [6, 3], [7, 2],
        [8, 0x1200],
        [1, 0x8003],
    ],
    "expect": [
        "0100B 12FF", "0100C 1206",
    ],
}


def main_selftest():
    ok = True
    for case in (SELFTEST_A, SELFTEST_B, SELFTEST_C):
        got = run_case([(w[0], w[1]) for w in case["writes"]])
        if got == case["expect"]:
            print("PASS %s (%d writes)" % (case["name"], len(got)))
        else:
            ok = False
            print("FAIL %s" % case["name"])
            print("  expect: %r" % (case["expect"],))
            print("  got:    %r" % (got,))
    print("selftest: %s" % ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


def main(argv):
    if len(argv) == 2 and argv[1] == "--selftest":
        return main_selftest()
    if len(argv) != 3:
        sys.stderr.write(
            "usage: python wolf_dma_model.py <vectors.json> <outdir>\n"
            "       python wolf_dma_model.py --selftest\n")
        return 2
    main_vectors(argv[1], argv[2])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
