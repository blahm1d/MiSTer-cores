#!/usr/bin/env bash
# cg starvation liveness gate. Runs BOTH the production build and the mutant in
# ONE invocation, so the kill is demonstrated in the same run that reports the
# pass (the standard agreed across the Wolf/Y/T/Z sessions 2026-07-27).
# Licence-free: iverilog only.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_wolf_gfx_cg_starve
B="$ROOT/sim/build/cg_starve"; rm -rf "$B"; mkdir -p "$B"
SRC=("$ROOT/rtl/pkg/wolf_pkg.sv" "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
     "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/$TB.sv")

echo "== PRODUCTION =="
iverilog -g2012 -o "$B/prod.vvp" -s $TB "${SRC[@]:0:2}" "$ROOT/rtl/sdram/wolf_gfx_ddr_top.sv" "${SRC[@]:2}" 2>&1 | grep -viE "sorry:|warning" || true
vvp "$B/prod.vvp" | tee "$B/prod.log" | tail -3
grep -q "^PASS:" "$B/prod.log" || { echo "GATE FAILED: production does not pass"; exit 1; }

echo "== MUTANT (starvation escape removed) -- MUST FAIL =="
python - "$ROOT/rtl/sdram/wolf_gfx_ddr_top.sv" "$B/mut.sv" <<'PY'
import sys
s=open(sys.argv[1],encoding='utf-8').read()
old="wire cg_safe_w = !USE_STREAM_HINT || !src_active || dcs_safe || src_stalled_w;"
new="wire cg_safe_w = !USE_STREAM_HINT || !src_active || dcs_safe;"
assert s.count(old)==1, "MUTATION ANCHOR MISSING -- refusing to grade an unmutated build"
open(sys.argv[2],'w',encoding='utf-8',newline='').write(s.replace(old,new))
PY
iverilog -g2012 -o "$B/mut.vvp" -s $TB "${SRC[@]:0:2}" "$B/mut.sv" "${SRC[@]:2}" 2>&1 | grep -viE "sorry:|warning" || true
vvp "$B/mut.vvp" | tee "$B/mut.log" | tail -3
grep -q "^FAIL: cg STARVED" "$B/mut.log" || { echo "MUTANT SURVIVED: the gate does not exercise the change"; exit 1; }
echo "GATE PASSED (production PASS + mutant killed in the same run)"
