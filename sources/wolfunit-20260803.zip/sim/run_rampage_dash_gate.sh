#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build/rampage_dash_gate"
mkdir -p "$BUILD"
IV="${IVERILOG:-/c/iverilog/bin/iverilog.exe}"
VVP="${VVP:-/c/iverilog/bin/vvp.exe}"

run_case() {
  local name="$1" define="$2"
  "$IV" -g2012 -s tb_rampage_dash_gate $define -o "$BUILD/$name.vvp" \
    "$ROOT/rtl/wolf/wolf_video_post.sv" "$ROOT/sim/tb_rampage_dash_gate.sv"
  "$VVP" "$BUILD/$name.vvp" | tee "$BUILD/$name.log"
}

echo "PRODUCTION:"
run_case production ""
grep -Fq "RESULT: PASS" "$BUILD/production.log"
grep -Fq "INTERIOR_BLACK=0" "$BUILD/production.log"

echo "MUT_PIXEL_RATE_VLINE:"
run_case mutation "-DMUT_PIXEL_RATE_VLINE"
grep -Fq "RESULT: FAIL" "$BUILD/mutation.log"
if grep -Fq "INTERIOR_BLACK=0" "$BUILD/mutation.log"; then
  echo "GATE: FAIL -- mutation did not reproduce the cabinet-shaped blanking"
  exit 1
fi

echo "GATE: PASS"
