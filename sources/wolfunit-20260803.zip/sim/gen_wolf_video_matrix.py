#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
gen_wolf_video_matrix.py -- author sim/wolf_video_vectors.json, a broad matrix that
exercises the shared wolf_video PIXEL-PATH contract (gospel: midway/midtunit_v.cpp
scanline_update:846-854 + midway/midwunit.cpp:643 xRGB_555 palette_device).

Contract per pixel i in [0,npix):
  base  = (rowaddr << 9) & 0x3fe00          (midtunit_v.cpp:848)
  ca    = coladdr << 1                        (midtunit_v.cpp:850)
  idx15 = vram[base + ((ca + i) & 0x1ff)] & 0x7fff   (midtunit_v.cpp:854)
  c     = palette[idx15]                       (midwunit.cpp:122 index -> palette)
  R8 = rep5to8(c[14:10]); G8 = rep5to8(c[9:5]); B8 = rep5to8(c[4:0])
  rep5to8(v5) = (v5<<3)|(v5>>2)                (standard MAME emupal pal5bit)

JSON schema (pinned): array of
  {"name","vram":[[idx,val],...],"palette":[[idx,xrgb1555],...],
   "rowaddr":<int 0..0x3fff>,"coladdr":<int>,"npix":<int>}  -- all decimal.

Run:  python gen_wolf_video_matrix.py [out.json]
"""
import sys, json

def rep5to8(v): return ((v & 0x1f) << 3) | ((v & 0x1f) >> 2)

cases = []

def add(name, rowaddr, coladdr, npix, vram, palette):
    cases.append({
        "name": name,
        "rowaddr": rowaddr,
        "coladdr": coladdr,
        "npix": npix,
        "vram": sorted((int(a) & 0x7ffff, int(v) & 0xffff) for a, v in vram.items()),
        "palette": sorted((int(a) & 0x7fff, int(v) & 0xffff) for a, v in palette.items()),
    })

def base_of(rowaddr): return (rowaddr << 9) & 0x3fe00

# =====================================================================
# EXACT hand-walked self-test cases (both transcriptions) — must be present.
# =====================================================================
# model self-test CASE 1
add("st_model_case1_copy_row0", 0, 0, 3,
    {0: 0x1234, 1: 0x0001, 2: 0x0000},
    {0x1234: 0x7FFF, 1: 0x0400})
# model self-test CASE 2 (column wrap)
add("st_model_case2_colwrap", 0, 0xFF, 3,
    {0x1FE: 0x0002, 0x1FF: 0x0003, 0: 0x0004},
    {2: 0x001F, 3: 0x03E0, 4: 0x7C00})
# model self-test CASE 3 (buffer B row 256)
add("st_model_case3_bufferB_row256", 0x100, 0, 2,
    {0x20000: 0x5678},
    {0x5678: 0x0421})

# RTL gen smoke case 1 (direct index + bit15 mask)
_pal = {0x0000:0x0000, 0x0001:0x7FFF, 0x001F:0x001F, 0x03E0:0x03E0,
        0x7C00:0x7C00, 0x7FFF:0x1234, 0x2AAA:0x2AAA}
_vr = {0:0x0001, 1:0x0000, 2:0x001F, 3:0x03E0, 4:0x7C00, 5:0xFFFF, 6:0xAAAA, 7:0x2AAA}
add("st_rtl_direct_index_and_mask", 0, 0, 8, _vr, _pal)

# RTL gen smoke case 2 (buffer B + coladdr wrap)
_r2 = 0x100; _b2 = base_of(_r2); _ca2 = 0xFD << 1
_pal2 = {0x0100:0x7C00,0x0200:0x03E0,0x0300:0x001F,0x0400:0x7FFF,0x0500:0x421F,0x1000:0x2222}
_seq = [0x0100,0x0200,0x0300,0x0400,0x0500,0x1000,0x0100,0x0200,0x0300,0x0400]
_vr2 = {}
for i, idx in enumerate(_seq):
    _vr2[_b2 + ((_ca2 + i) & 0x1ff)] = idx
add("st_rtl_bufferB_coladdr_wrap", _r2, 0xFD, len(_seq), _vr2, _pal2)

# =====================================================================
# 1) rowaddr sweep — 0, buffer B (256), and &0x3fe00 mask-truncation values.
# =====================================================================
# Palette used broadly: identity-ish plus channel isolators + boundaries.
PAL_COMMON = {
    0x0000: 0x0000,   # black
    0x0001: 0x7FFF,   # white
    0x0002: 0x7C00,   # pure red
    0x0003: 0x03E0,   # pure green
    0x0004: 0x001F,   # pure blue
    0x0005: 0x4210,   # mid grey-ish (R=0x10 G=0x10 B=0x10)
    0x0006: 0x0000,   # black again (dup index maps to black)
    0x0007: 0x1234,   # arbitrary
    0x4000: 0x2AAA,   # boundary index 0x4000
    0x7FFF: 0x7FFF,   # top boundary index -> white
    0x2AAA: 0x2AAA,   # mid entry
    0x1555: 0x1555,
}

# rowaddr=0
add("row_0", 0, 0, 6, {i: (i % 8) for i in range(6)}, PAL_COMMON)

# rowaddr=256 (buffer B, base 0x20000)
add("row_256_bufferB", 0x100, 0, 6,
    {0x20000 + i: (i % 8) for i in range(6)}, PAL_COMMON)

# rowaddr=1 (base 0x200)
add("row_1", 1, 0, 4, {0x200 + i: (i % 8) for i in range(4)}, PAL_COMMON)

# rowaddr just below the mask cap: 0x1FF -> base=(0x1FF<<9)&0x3fe00 = 0x3FE00
r = 0x1FF; b = base_of(r)
add("row_0x1FF_maskcap", r, 0, 4, {b + i: (i % 8) for i in range(4)}, PAL_COMMON)

# rowaddr=0x200 -> raw (0x200<<9)=0x40000; &0x3fe00 => 0. MASK TRUNCATION: base=0.
# (bit9 of rowaddr is dropped by the mask.) Verifies the & 0x3fe00 is honored.
r = 0x200; b = base_of(r)
add("row_0x200_masktrunc_to0", r, 0, 4, {b + i: (i % 8) for i in range(4)}, PAL_COMMON)
assert base_of(0x200) == 0, base_of(0x200)

# rowaddr=0x201 -> (0x201<<9)=0x40200; &0x3fe00 = 0x200 (== row 1's base). truncation.
r = 0x201; b = base_of(r)
add("row_0x201_masktrunc_to_row1", r, 0, 4, {b + i: (i % 8) for i in range(4)}, PAL_COMMON)
assert base_of(0x201) == base_of(1)

# rowaddr=0x300 -> (0x300<<9)=0x60000; &0x3fe00 = 0x20000 (== row 256). truncation.
r = 0x300; b = base_of(r)
add("row_0x300_masktrunc_to_row256", r, 0, 4, {b + i: (i % 8) for i in range(4)}, PAL_COMMON)
assert base_of(0x300) == base_of(0x100)

# rowaddr=0x3FFF (max input) -> (0x3FFF<<9)=0x7FFE00; &0x3fe00 = 0x3FE00.
r = 0x3FFF; b = base_of(r)
add("row_0x3FFF_max_masked", r, 0, 4, {b + i: (i % 8) for i in range(4)}, PAL_COMMON)
assert base_of(0x3FFF) == 0x3FE00

# =====================================================================
# 2) coladdr sweep — 0, near 0x100, near 0x1ff so (ca<<1 + i) wraps mid-scanline.
# =====================================================================
def fill_row(base, coladdr, npix, idxfn):
    """Place vram so that contract read at pixel i yields idxfn(i)."""
    ca = coladdr << 1
    d = {}
    for i in range(npix):
        d[base + ((ca + i) & 0x1ff)] = idxfn(i)
    return d

# coladdr=0
add("col_0", 0, 0, 8, fill_row(0, 0, 8, lambda i: (i % 8)), PAL_COMMON)

# coladdr=0x40 -> ca=0x80
add("col_0x40", 0, 0x40, 8, fill_row(0, 0x40, 8, lambda i: (i % 8)), PAL_COMMON)

# coladdr=0x80 -> ca=0x100
add("col_0x80_ca0x100", 0, 0x80, 8, fill_row(0, 0x80, 8, lambda i: (i % 8)), PAL_COMMON)

# coladdr=0xFF -> ca=0x1FE (from model selftest #2 territory), wrap after 2 px
add("col_0xFF_ca0x1FE_wrap", 0, 0xFF, 10, fill_row(0, 0xFF, 10, lambda i: (i % 8)), PAL_COMMON)

# coladdr=0x100 -> ca=0x200; ca&... starts effectively at (0x200)&0x1ff? NO: wrap is
# on (ca+i)&0x1ff, ca=0x200 -> (0x200+0)&0x1ff=0. So col starts at 0 (ca wraps whole).
add("col_0x100_ca0x200_fullwrap", 0, 0x100, 8, fill_row(0, 0x100, 8, lambda i: (i % 8)), PAL_COMMON)

# coladdr=0xFE -> ca=0x1FC; wrap after 3
add("col_0xFE_ca0x1FC", 0, 0xFE, 8, fill_row(0, 0xFE, 8, lambda i: (i % 8)), PAL_COMMON)

# coladdr near 0x1ff -> ca=0x3FE; (0x3FE)&0x1ff=0x1FE, wrap after 2
add("col_0x1FF_ca0x3FE", 0, 0x1FF, 8, fill_row(0, 0x1FF, 8, lambda i: (i % 8)), PAL_COMMON)

# coladdr full-scanline wrap across all 512 within npix (npix>512 not needed; do 512)
add("col_0_full512", 0, 0, 512, fill_row(0, 0, 512, lambda i: (i * 3) % 0x8000), PAL_COMMON)

# rowaddr B + coladdr near-wrap combined
rb = 0x100; bb = base_of(rb)
add("row256_col0xFC_wrap", rb, 0xFC, 12, fill_row(bb, 0xFC, 12, lambda i: (i % 8)), PAL_COMMON)

# =====================================================================
# 3) npix sweep — 1, small, up to ~410 visible (H_ACT=400 + margin).
# =====================================================================
add("npix_1", 0, 0, 1, {0: 0x0001}, PAL_COMMON)
add("npix_2", 0, 0, 2, {0: 0x0001, 1: 0x0002}, PAL_COMMON)
add("npix_400_hact", 0, 0, 400, fill_row(0, 0, 400, lambda i: (i * 7) % 0x8000), PAL_COMMON)
add("npix_410_overscan", 0, 0, 410, fill_row(0, 0, 410, lambda i: (i * 5 + 1) % 0x8000), PAL_COMMON)
# npix that forces a wrap: coladdr=0xFF (ca=0x1FE) + npix 300 -> wraps 0x1ff->0
add("npix_300_wraps", 0, 0xFF, 300, fill_row(0, 0xFF, 300, lambda i: (i * 11) % 0x8000), PAL_COMMON)

# =====================================================================
# 4) palette sweep — saturated white, black, mid greys, boundary 0/0x7fff/0x4000.
# =====================================================================
# All-idx-1 pixels but different palette entry per case.
def solid(color_idx, palentry, npix=4):
    return ({i: color_idx for i in range(npix)}, {color_idx: palentry})

v, p = solid(0x0001, 0x7FFF); add("pal_white_saturated", 0, 0, 4, v, p)
v, p = solid(0x0001, 0x0000); add("pal_black", 0, 0, 4, v, p)
v, p = solid(0x0001, 0x4210); add("pal_midgrey_4210", 0, 0, 4, v, p)  # R=G=B=0x10
v, p = solid(0x0001, 0x3DEF); add("pal_grey_3DEF", 0, 0, 4, v, p)     # R=0x0F G=0x0F B=0x0F
v, p = solid(0x0001, 0x7C00); add("pal_pure_red", 0, 0, 4, v, p)
v, p = solid(0x0001, 0x03E0); add("pal_pure_green", 0, 0, 4, v, p)
v, p = solid(0x0001, 0x001F); add("pal_pure_blue", 0, 0, 4, v, p)
# bit15 set in palette entry (x-bit) must be IGNORED by rgb555 (only [14:0] used).
v, p = solid(0x0001, 0xFFFF); add("pal_bit15_set_ignored", 0, 0, 4, v, p)  # -> white, x-bit dropped
v, p = solid(0x0001, 0x8000); add("pal_bit15only_black", 0, 0, 4, v, p)   # -> black, x-bit dropped

# palette boundary INDICES: 0, 0x4000, 0x7FFF
add("palidx_0", 0, 0, 2, {0: 0x0000, 1: 0x0000}, {0x0000: 0x1F00})  # idx0 -> that entry
add("palidx_0x4000", 0, 0, 2, {0: 0x4000, 1: 0x4000}, {0x4000: 0x03FF})
add("palidx_0x7FFF", 0, 0, 2, {0: 0x7FFF, 1: 0x7FFF}, {0x7FFF: 0x7FFF})

# every 5-bit channel level in R, G, B individually (0..31), to exercise rep5to8.
palr = {}; vrr = {}
for lvl in range(32):
    palr[0x100 + lvl] = (lvl << 10)   # pure red at level lvl
    vrr[lvl] = 0x100 + lvl
add("rep5to8_red_ramp", 0, 0, 32, vrr, palr)
palg = {}; vrg = {}
for lvl in range(32):
    palg[0x100 + lvl] = (lvl << 5)
    vrg[lvl] = 0x100 + lvl
add("rep5to8_green_ramp", 0, 0, 32, vrg, palg)
palb = {}; vrb = {}
for lvl in range(32):
    palb[0x100 + lvl] = lvl
    vrb[lvl] = 0x100 + lvl
add("rep5to8_blue_ramp", 0, 0, 32, vrb, palb)

# =====================================================================
# 5) vram value coverage — idx bits 14..0, bit15 mask, all-zero vram.
# =====================================================================
# bit15 set on many words -> must be masked to 15-bit idx before palette lookup.
_p = {i & 0x7fff: ((i & 0x7fff) | ((i & 0x7fff) << 0)) & 0x7fff for i in range(8)}
# make palette identity-ish for the masked indices we will hit:
_p = {}
_v = {}
for i in range(16):
    word = 0x8000 | (i * 0x111)        # bit15 always set
    idx = word & 0x7fff
    _v[i] = word
    _p[idx] = (idx & 0x7fff)           # palette entry = idx (arbitrary but deterministic)
add("vram_bit15_always_set_masked", 0, 0, 16, _v, _p)

# walking-one through idx bits 14..0 (each vram word = 1<<bit, palette identity)
_v = {}; _p = {}
for bit in range(15):
    idx = (1 << bit)
    _v[bit] = idx
    _p[idx] = idx    # palette entry equals index -> deterministic color
add("vram_walking_one_idx_bits", 0, 0, 15, _v, _p)

# walking-one INCLUDING bit15 (bit15 word 0x8000 -> idx 0 -> palette[0])
_v = {}; _p = {0: 0x1234}
for bit in range(16):
    _v[bit] = (1 << bit)
    idx = (1 << bit) & 0x7fff
    if idx: _p[idx] = idx
add("vram_walking_one_incl_bit15", 0, 0, 16, _v, _p)

# all-zero vram -> every pixel idx15=0 -> palette[0]; set palette[0] to a color.
add("vram_all_zero_to_pal0", 0, 0, 8, {}, {0: 0x03FF})   # palette[0] = teal-ish

# all-zero vram AND palette[0]=0 -> all black
add("vram_all_zero_pal0_black", 0, 0, 8, {}, {})

# idx exactly 0x7FFF from vram 0xFFFF -> palette[0x7FFF]
add("vram_0xFFFF_to_idx7FFF", 0, 0, 4, {i: 0xFFFF for i in range(4)}, {0x7FFF: 0x2468})

# mixed: alternating bit15 and clean words hitting same idx (must match)
_v = {0: 0x2AAA, 1: 0xAAAA, 2: 0x2AAA, 3: 0xAAAA}   # 0xAAAA&0x7fff=0x2AAA
add("vram_bit15_pairs_same_idx", 0, 0, 4, _v, {0x2AAA: 0x55AA})

# =====================================================================
# 6) col-wrap WITHIN a row combined with double-buffer base (stress).
# =====================================================================
rb = 0x100; bb = base_of(rb)
add("row256_colwrap_stress", rb, 0x1F8, 24,
    fill_row(bb, 0x1F8, 24, lambda i: ((i * 13) % 0x7fff)), PAL_COMMON)

# row mask-trunc combined with col wrap
r = 0x300; b = base_of(r)   # -> 0x20000 (== row256)
add("rowmasktrunc_colwrap", r, 0x1FC, 16,
    fill_row(b, 0x1FC, 16, lambda i: ((i * 17) % 0x7fff)), PAL_COMMON)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "wolf_video_vectors.json"
    with open(out, "w", newline="\n") as f:
        json.dump(cases, f, indent=1)
        f.write("\n")
    print("wrote %s (%d cases)" % (out, len(cases)))
