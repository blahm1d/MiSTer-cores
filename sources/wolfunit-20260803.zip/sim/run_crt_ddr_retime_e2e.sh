#!/usr/bin/env bash
set -euo pipefail
export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TB=tb_crt_ddr_retime_e2e
OUT="$ROOT/sim/build/$TB.vvp"
LOG="$ROOT/sim/build/$TB.log"
mkdir -p "$ROOT/sim/build"
iverilog -g2012 -s "$TB" -o "$OUT" \
  "$ROOT/rtl/video/crt_fb_ddr.sv" \
  "$ROOT/rtl/video/crt_retime.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/$TB.sv"
cd "$ROOT"
vvp -n "$OUT" | tee "$LOG"
if grep -q 'TEST-INVALID' "$LOG"; then exit 4; fi
grep -q '^PASS: CRT DDR retimer end-to-end' "$LOG"
