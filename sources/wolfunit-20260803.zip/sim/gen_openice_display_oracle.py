#!/usr/bin/env python3
"""Generate MAME-model write, rink-strip, and final-VRAM Open Ice oracles."""

from __future__ import annotations

import argparse
from pathlib import Path

import wolf_dma_model as model
from gen_nbahangt_startup_frame_replay import (
    FNV_OFFSET,
    FNV_PRIME,
    MASK64,
    load_register_writes,
)


VRAM_WORDS = 0x80000


def parse_trace(path: Path, rank: int) -> list[tuple[int, tuple[int, ...]]]:
    blits: list[tuple[int, tuple[int, ...]]] = []
    for line_number, raw_line in enumerate(
        path.read_text(encoding="ascii").splitlines(), 1
    ):
        fields = raw_line.split()
        if not fields or fields[0] != "BLIT" or int(fields[1]) != rank:
            continue
        if len(fields) not in (22, 23):
            raise ValueError(
                f"{path}:{line_number}: expected 22 or 23 BLIT fields"
            )
        blits.append(
            (
                int(fields[3]),
                tuple(int(word, 16) & 0xFFFF for word in fields[4:22]),
            )
        )
    if not blits:
        raise ValueError(f"{path}: rank {rank} has no BLIT records")
    return blits


def hash_writes(lines: list[str], initial: int = FNV_OFFSET) -> int:
    value = initial
    for line in lines:
        address_text, data_text = line.split()
        token = (int(address_text, 16) << 16) | int(data_text, 16)
        value = ((value ^ token) * FNV_PRIME) & MASK64
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--rank", type=int, required=True)
    parser.add_argument("--gfx-hex", type=Path, required=True)
    parser.add_argument("--writes-out", type=Path, required=True)
    parser.add_argument("--rink-out", type=Path, required=True)
    parser.add_argument("--vram-out", type=Path, required=True)
    args = parser.parse_args()

    gfx = bytes.fromhex(args.gfx_hex.read_text(encoding="ascii"))
    model.GFX_SIZE = len(gfx)
    model._GFX = gfx

    final_vram = [0] * VRAM_WORDS
    all_writes: list[str] = []
    rink_records: list[str] = []
    rink_rows = 0

    for ordinal, registers in parse_trace(args.trace, args.rank):
        writes = model.run_case(load_register_writes(registers))
        all_writes.extend(writes)
        for line in writes:
            address_text, data_text = line.split()
            final_vram[int(address_text, 16)] = int(data_text, 16)

        if (
            registers[1] == 0x8023
            and (registers[6] & 0x3FF) == 860
            and registers[0] == 0x01CC
        ):
            height = registers[7] & 0x3FF
            rink_rows += height
            rink_records.append(
                f"{ordinal} y={registers[5] & 0x1FF} rows={height} "
                f"writes={len(writes)} fnv64={hash_writes(writes):016X}"
            )

    frame_hash = hash_writes(all_writes)
    args.writes_out.parent.mkdir(parents=True, exist_ok=True)
    args.writes_out.write_text(
        "\n".join(all_writes) + "\n", encoding="ascii", newline="\n"
    )
    args.rink_out.write_text(
        (
            f"# strips={len(rink_records)} rows={rink_rows} "
            f"writes={sum(int(line.split('writes=')[1].split()[0]) for line in rink_records)}\n"
            + "\n".join(rink_records)
            + "\n"
        ),
        encoding="ascii",
        newline="\n",
    )
    args.vram_out.write_text(
        "\n".join(f"{word:04X}" for word in final_vram) + "\n",
        encoding="ascii",
        newline="\n",
    )

    print(
        f"OPENICE_DISPLAY_ORACLE rank={args.rank} blits={len(parse_trace(args.trace, args.rank))} "
        f"writes={len(all_writes)} fnv64={frame_hash:016X} "
        f"rink_strips={len(rink_records)} rink_rows={rink_rows}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
