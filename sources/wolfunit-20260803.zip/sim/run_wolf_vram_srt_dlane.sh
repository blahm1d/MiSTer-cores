#!/usr/bin/env bash
# D-lane (SRT row-pair engine) unit gate: directed oracles + 2 mutation kills.
# Fork of run_wolf_vram_aba_partial.sh conventions: only temp copies under
# sim/build are mutated; repository RTL is never edited.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IVERILOG=${IVERILOG:-/c/iverilog/bin/iverilog}
VVP=${VVP:-/c/iverilog/bin/vvp}
BUILD="$ROOT/sim/build/wolf_vram_srt_dlane"
TB="$ROOT/sim/tb_wolf_vram_srt_dlane.sv"
RTL_TOP="$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
mkdir -p "$BUILD"

compile_case() {
  local tag="$1"
  local top="$2"
  "$IVERILOG" -g2012 -s tb_wolf_vram_srt_dlane -o "$BUILD/$tag.vvp" \
    "$ROOT/rtl/yunit/vram_sdram.sv" \
    "$ROOT/rtl/yunit/vram_sdram_top.sv" \
    "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
    "$top" \
    "$ROOT/sim/ddr3_avalon_model.sv" \
    "$TB"
}

run_case() {
  local tag="$1"
  set +e
  "$VVP" "$BUILD/$tag.vvp" > "$BUILD/$tag.log" 2>&1
  set -e
  grep -E '^\[case\]|^\[oracle\]|^\[stats\]|^RESULT:' "$BUILD/$tag.log" || true
}

echo "== RTL snapshot =="
for file in rtl/sdram/stv_vram_ddr_top.sv rtl/sdram/stv_vram_ddr_agent.sv sim/ddr3_avalon_model.sv; do
  printf '%s  %s\n' "$(git -C "$ROOT" hash-object "$ROOT/$file")" "$file"
done

echo
echo "== Baseline: real RTL, posted writes + 32-beat cap =="
compile_case baseline "$RTL_TOP"
run_case baseline
grep -q '^RESULT: PASS' "$BUILD/baseline.log" || {
  echo "GATE: FAIL -- baseline did not pass (see $BUILD/baseline.log)"
  exit 1
}

echo
echo "== M1: skip the D-lane scan-cache invalidation =="
MUT1="$BUILD/stv_vram_ddr_top_no_d_inval.sv"
cp "$RTL_TOP" "$MUT1"
sed -i \
  's/assign cache_wr_evt  = a_cache_wr_evt || c_cache_wr_evt || d_cache_wr_evt;/assign cache_wr_evt  = a_cache_wr_evt || c_cache_wr_evt;/' \
  "$MUT1"
if [ "$(grep -c 'assign cache_wr_evt  = a_cache_wr_evt || c_cache_wr_evt;' "$MUT1")" != "1" ]; then
  echo "GATE: FAIL -- M1 mutation did not apply exactly once"
  exit 1
fi
compile_case no_d_inval "$MUT1"
run_case no_d_inval
grep -q '^RESULT: FAIL' "$BUILD/no_d_inval.log" || {
  echo "GATE: FAIL -- skip-invalidation mutant survived (see $BUILD/no_d_inval.log)"
  exit 1
}
grep -q '^\[oracle\] STALE-SCAN' "$BUILD/no_d_inval.log" || {
  echo "GATE: FAIL -- skip-invalidation mutant died for the wrong reason"
  exit 1
}
echo "PASS: skip-invalidation mutant killed by the directed scan check"

echo
echo "== M2: drop the last transfer sub-burst =="
MUT2="$BUILD/stv_vram_ddr_top_drop_last_sub.sv"
cp "$RTL_TOP" "$MUT2"
sed -i \
  "s/dst <= ((d_fill + 9'd1) >= 9'd256) ? D_FIN : D_WREQ;/dst <= ((d_fill + 9'd1) >= 9'd224) ? D_FIN : D_WREQ;/" \
  "$MUT2"
if [ "$(grep -c "9'd224) ? D_FIN : D_WREQ;" "$MUT2")" != "1" ]; then
  echo "GATE: FAIL -- M2 mutation did not apply exactly once"
  exit 1
fi
compile_case drop_last_sub "$MUT2"
run_case drop_last_sub
grep -q '^RESULT: FAIL' "$BUILD/drop_last_sub.log" || {
  echo "GATE: FAIL -- drop-last-sub-burst mutant survived (see $BUILD/drop_last_sub.log)"
  exit 1
}
grep -Eq '^\[oracle\] (DATA-MISMATCH|MISMATCH cpuvis)' "$BUILD/drop_last_sub.log" || {
  echo "GATE: FAIL -- drop-last-sub-burst mutant died for the wrong reason"
  exit 1
}
echo "PASS: drop-last-sub-burst mutant killed by the data check"

echo
echo "GATE: PASS -- D-lane unit oracles green; both mutants killed"
echo "Logs: $BUILD/baseline.log $BUILD/no_d_inval.log $BUILD/drop_last_sub.log"
