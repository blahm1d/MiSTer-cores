#!/usr/bin/env bash
# SHARED-CORE gate: INTPEND write semantics. MUST FAIL on the unfixed core.
set -e
TB=tb_tms34010_intpend_write
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RUN="$ROOT/sim/build/intpend_gate"
. "$(dirname "$0")/questa_lock.sh"
find_bin() {
  local n="$1" e="$2"
  [ -n "$e" ] && [ -x "$e" ] && { echo "$e"; return; }
  for d in /c/altera_pro/*/questa_fse/win64 /c/intelFPGA_pro/*/questa_fse/win64 \
           /c/altera/*/questa_fse/win64 /c/intelFPGA/*/questa_fse/win64; do
    [ -x "$d/$n.exe" ] && { echo "$d/$n"; return; }
    [ -x "$d/$n" ] && { echo "$d/$n"; return; }
  done
  command -v "$n" 2>/dev/null || true
}
VLIB="$(find_bin vlib "$VLIB")"; VLOG="$(find_bin vlog "$VLOG")"; VSIM="$(find_bin vsim "$VSIM")"
[ -z "$VLOG" ] && { echo "ERROR: Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\altera\LR-175212_License.dat;C:\altera\LR-175213_License.dat}"
export SALT_LICENSE_SERVER
trap questa_release EXIT
questa_acquire || { echo "BLOCKED: Questa licence slot unavailable"; exit 3; }
rm -rf "$RUN"; mkdir -p "$RUN"; cd "$RUN"
"$VLIB" work >/dev/null
"$VLOG" -sv -quiet -svinputport=var \
  "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
  "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
  "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" \
  "$ROOT/sim/$TB.sv"
LOG="$ROOT/sim/build/${TB}.vsim.log"
set +e
"$VSIM" -c -quiet -do "run -all; quit" "$TB" 2>&1 | tee "$LOG"
set -e
# ORDER MATTERS (Y-unit): a licence death also exits non-zero. Check it FIRST or
# a reap is misreported as a real RTL failure. 1=fail 2=inconclusive 3=no licence.
if grep -qE "Exiting VSIM license process|lost connection|Kernel lost connection" "$LOG"; then
  echo "INCONCLUSIVE: simulator/licence death, NOT an RTL result"; exit 2
fi
grep -q "^RESULT PASS" "$LOG" || { echo "GATE FAILED"; exit 1; }
echo "GATE PASSED"
