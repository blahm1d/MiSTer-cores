#!/usr/bin/env python
# gen_wolf_video_vectors.py — build wolf_video contract cases, emit:
#   (1) a token STIM file the TB parses
#   (2) the golden expected stream (contract algorithm) for a self-check diff
#
# Contract per pixel i in [0,npix):
#   base=(rowaddr<<9)&0x3fe00 ; ca=coladdr<<1
#   idx15 = vram[base+((ca+i)&0x1ff)] & 0x7fff
#   c=palette[idx15]; R=rep5to8(c[14:10]); G=rep5to8(c[9:5]); B=rep5to8(c[4:0])
import sys

def rep5to8(v): return ((v & 0x1f) << 3) | ((v & 0x1f) >> 2)

def golden(case):
    vram = dict(case["vram"]); pal = dict(case["palette"])
    rowaddr = case["rowaddr"]; coladdr = case["coladdr"]; npix = case["npix"]
    base = (rowaddr << 9) & 0x3fe00
    ca = coladdr << 1
    out = []
    for i in range(npix):
        idx15 = vram.get(base + ((ca + i) & 0x1ff), 0) & 0x7fff
        c = pal.get(idx15, 0)
        r = rep5to8((c >> 10) & 0x1f); g = rep5to8((c >> 5) & 0x1f); b = rep5to8(c & 0x1f)
        out.append("%04X %02X%02X%02X" % (idx15, r, g, b))
    return out

def emit_stim(cases, f):
    for c in cases:
        f.write("CASE\n")
        f.write("ROWADDR %X\n" % c["rowaddr"])
        f.write("COLADDR %X\n" % c["coladdr"])
        f.write("NPIX %d\n" % c["npix"])
        for a, v in c["vram"]:    f.write("V %X %X\n" % (a, v))
        for a, v in c["palette"]: f.write("P %X %X\n" % (a, v))
        f.write("ENDCASE\n")

# ---- two smoke cases -------------------------------------------------------
cases = []

# Case 1: rowaddr=0, coladdr=0. Direct 15-bit index, a handful of colors, incl.
# the 0x7fff mask (a vram word with bit15 set must have bit15 dropped for idx).
base1 = (0 << 9) & 0x3fe00  # 0
pal1 = {
    0x0000: 0x0000,  # black
    0x0001: 0x7FFF,  # white
    0x001F: 0x001F,  # blue
    0x03E0: 0x03E0,  # green
    0x7C00: 0x7C00,  # red
    0x7FFF: 0x1234,  # arbitrary at the top index (tests idx=0x7fff path)
    0x2AAA: 0x2AAA,  # mid palette entry -> mixed color
}
vram1 = {
    base1 + 0: 0x0001,           # -> white
    base1 + 1: 0x0000,           # -> black
    base1 + 2: 0x001F,           # -> blue
    base1 + 3: 0x03E0,           # -> green
    base1 + 4: 0x7C00,           # -> red
    base1 + 5: 0xFFFF,           # bit15 set -> idx 0x7FFF -> pal 0x1234
    base1 + 6: 0xAAAA,           # bit15 set -> idx 0x2AAA -> pal 0x2AAA
    base1 + 7: 0x2AAA,           # idx 0x2AAA -> pal 0x2AAA (same color, no bit15)
}
cases.append({"name":"direct_index_and_mask","rowaddr":0,"coladdr":0,"npix":8,
              "vram":sorted(vram1.items()), "palette":sorted(pal1.items())})

# Case 2: nonzero rowaddr (double-buffer B = row 256) + nonzero coladdr + col wrap.
# rowaddr=0x100 (256) -> base=(256<<9)&0x3fe00=0x20000. coladdr=0xFD -> ca=0x1FA.
# npix chosen to wrap past 0x1ff: start col 0x1FA, +8 pixels wraps to col 0x002.
rowaddr2 = 0x100
base2 = (rowaddr2 << 9) & 0x3fe00
ca2 = 0xFD << 1  # 0x1FA
pal2 = {
    0x0100: 0x7C00,  # red
    0x0200: 0x03E0,  # green
    0x0300: 0x001F,  # blue
    0x0400: 0x7FFF,  # white
    0x0500: 0x421F,  # some mix
    0x1000: 0x2222,
}
# lay contract vram at the exact columns (ca2+i)&0x1ff for i=0..9
seq = [0x0100,0x0200,0x0300,0x0400,0x0500,0x1000,0x0100,0x0200,0x0300,0x0400]
vram2 = {}
for i, idx in enumerate(seq):
    col = (ca2 + i) & 0x1ff
    vram2[base2 + col] = idx
cases.append({"name":"buffer_b_coladdr_wrap","rowaddr":rowaddr2,"coladdr":0xFD,"npix":len(seq),
              "vram":sorted(vram2.items()), "palette":sorted(pal2.items())})

if __name__ == "__main__":
    stim = sys.argv[1] if len(sys.argv) > 1 else "stim_wolf_video.txt"
    gold = sys.argv[2] if len(sys.argv) > 2 else "exp_wolf_video.txt"
    with open(stim, "w", newline="\n") as f: emit_stim(cases, f)
    with open(gold, "w", newline="\n") as f:
        for c in cases:
            for line in golden(c): f.write(line + "\n")
    print("wrote", stim, "and", gold, "(%d cases)" % len(cases))
