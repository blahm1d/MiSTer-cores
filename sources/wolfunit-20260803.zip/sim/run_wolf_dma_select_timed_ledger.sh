#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
IVERILOG="${IVERILOG:-/c/iverilog/bin/iverilog}"
VVP="${VVP:-/c/iverilog/bin/vvp}"
OUT="sim/build/tb_wolf_dma_select_timed_ledger.vvp"
LOG="${LOG:-sim/build/tb_wolf_dma_select_timed_ledger.log}"
test -f sim/build/umk3_select_timed.txt || {
  echo "missing sim/build/umk3_select_timed.txt; run sim/run_umk3_select_timed_capture.sh" >&2
  exit 1
}
"$IVERILOG" -g2012 -s tb_wolf_dma_select_timed_ledger -o "$OUT" \
  rtl/pkg/wolf_pkg.sv rtl/wolf/wolf_dma.sv sim/tb_wolf_dma_select_timed_ledger.sv
"$VVP" "$OUT" "+MAX_BLITS=${MAX_BLITS:-50}" | tee "$LOG"
grep -q '^LEDGER:' "$LOG"
grep -q '^PASS:' "$LOG"
! grep -q '^FAIL:' "$LOG"
