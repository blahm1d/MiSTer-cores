#!/usr/bin/env python3
"""Assemble Open Ice's packed Wolf graphics region for the RTL replay."""

import sys
import zipfile

zip_path = (
    sys.argv[1]
    if len(sys.argv) > 1
    else r"D:/deck/fpga/openice/openice.zip"
)
dst = "sim/build/openice_gfx.hex"
region_size = 0x1800000
chip_size = 0x100000
groups = [
    (0x0000000, [
        "open_ice_l1.2.u133", "open_ice_l1.2.u132",
        "open_ice_l1.2.u131", "open_ice_l1.2.u130",
    ]),
    (0x0400000, [
        "open_ice_l1.2.u129", "open_ice_l1.2.u128",
        "open_ice_l1.2.u127", "open_ice_l1.2.u126",
    ]),
    (0x0800000, [
        "open_ice_l1.u125", "open_ice_l1.u124",
        "open_ice_l1.u123", "open_ice_l1.u122",
    ]),
    (0x0C00000, [
        "open_ice_l1.2.u121", "open_ice_l1.2.u120",
        "open_ice_l1.2.u119", "open_ice_l1.2.u118",
    ]),
]

with zipfile.ZipFile(zip_path) as archive:
    region = bytearray(region_size)
    for base, chips in groups:
        for lane, name in enumerate(chips):
            data = archive.read(name)
            if len(data) != chip_size:
                raise ValueError(
                    f"{name}: expected {chip_size} bytes, got {len(data)}"
                )
            region[base + lane:base + lane + 4 * chip_size:4] = data

with open(dst, "w", newline="\n", encoding="ascii") as output:
    output.write("\n".join(f"{byte:02x}" for byte in region))
    output.write("\n")

print(
    f"wrote {dst}: {region_size} bytes, "
    f"{sum(byte != 0 for byte in region)} non-zero"
)
