#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/sim/build/wolf_faceoff_diag"
IV="${IVERILOG:-/c/iverilog/bin/iverilog.exe}"
VVP="${VVP:-/c/iverilog/bin/vvp.exe}"
mkdir -p "$BUILD"

"$IV" -g2012 -s tb_wolf_faceoff_diag -o "$BUILD/tb.vvp" \
  "$ROOT/rtl/diag/wolf_faceoff_diag_overlay.sv" \
  "$ROOT/rtl/wolf/wolf_video_post.sv" \
  "$ROOT/sim/tb_wolf_faceoff_diag.sv"
"$VVP" "$BUILD/tb.vvp" | tee "$BUILD/tb.log"
grep -Fq "RESULT: PASS" "$BUILD/tb.log"
