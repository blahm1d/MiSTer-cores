#!/usr/bin/env python3
"""Extract a bounded TMS34010 PC ledger from a MAME debugger trace."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


PC_LINE = re.compile(r"^([0-9A-Fa-f]{8}):")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trace", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--count", type=int, default=8000)
    args = parser.parse_args()

    pcs: list[str] = []
    with args.trace.open("r", encoding="utf-8", errors="replace") as src:
        for line in src:
            match = PC_LINE.match(line)
            if not match:
                continue
            pcs.append(match.group(1).upper())
            if len(pcs) == args.count:
                break

    if len(pcs) != args.count:
        raise SystemExit(
            f"trace ended after {len(pcs)} PCs; requested {args.count}"
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(pcs) + "\n", encoding="ascii")
    print(
        f"wrote {args.output}: {len(pcs)} PCs, "
        f"first={pcs[0]} last={pcs[-1]}"
    )


if __name__ == "__main__":
    main()
