#!/usr/bin/env python3
"""Generate the MAME-model write stream for Hangtime's first captured DMA."""

from __future__ import annotations

import hashlib
from pathlib import Path

import wolf_dma_model as model


GFX = Path("sim/build/nbahangt_gfx.bin")
STIM = Path("sim/build/nbahangt_first_dma_stim.txt")
GOLDEN = Path("sim/build/nbahangt_first_dma_golden.txt")

# MAME frame 224, GO 1.  Clip/config state comes from DISPLAY; the remaining
# registers are the six-long-write NDSP1.ASM:dma_irq cell at FF800010..70.
WRITES = [
    (15, 0x0000), (12, 0x0000), (13, 0x01FF),
    (15, 0x0030), (12, 0x0100), (13, 0x01FD),
    (10, 0x0100), (11, 0x0100),
    (8, 0x0A0A), (9, 0x0000),
    (6, 0x0064), (7, 0x007B),
    (4, 0x0164), (5, 0x0100),
    (2, 0x0857), (3, 0x05D4),
    (0, 0x0000), (1, 0x8002),
]


def main() -> None:
    gfx = GFX.read_bytes()
    model.GFX_SIZE = len(gfx)
    model._GFX = gfx

    STIM.write_text(
        "".join(f"W {offset:02X} {value:04X}\n" for offset, value in WRITES),
        encoding="ascii",
    )
    lines = model.run_case(WRITES)
    GOLDEN.write_text("\n".join(lines) + "\n", encoding="ascii")
    digest = hashlib.sha256(GOLDEN.read_bytes()).hexdigest()
    print(f"writes={len(lines)} sha256={digest}")


if __name__ == "__main__":
    main()
