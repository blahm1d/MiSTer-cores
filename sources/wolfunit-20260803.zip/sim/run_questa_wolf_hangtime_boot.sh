#!/usr/bin/env bash
# Run NBA Hangtime L1.3 on the shared Wolf CPU/memory RTL without touching HW outputs.
set -e
TB="${1:-tb_wolf_hangtime_boot}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
RUN_DIR="$ROOT/sim/build/nbahangt_questa"

. "$(dirname "$0")/questa_lock.sh"

find_bin() {
  local name="$1"; local override="$2"
  if [ -n "$override" ] && [ -x "$override" ]; then echo "$override"; return; fi
  for d in \
    /c/altera_pro/*/questa_fse/win64 /c/intelFPGA_pro/*/questa_fse/win64 \
    /c/altera/*/questa_fse/win64     /c/intelFPGA/*/questa_fse/win64 ; do
    [ -x "$d/$name.exe" ] && { echo "$d/$name"; return; }
    [ -x "$d/$name" ] && { echo "$d/$name"; return; }
  done
}

VLIB="$(find_bin vlib "$VLIB")"
VLOG="$(find_bin vlog "$VLOG")"
VSIM="$(find_bin vsim "$VSIM")"
[ -n "$VLOG" ] && [ -n "$VSIM" ] || { echo "ERROR: Questa not found"; exit 1; }

unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\\altera\\LR-175212_License.dat;C:\\altera\\LR-175213_License.dat}"
export SALT_LICENSE_SERVER
trap questa_release EXIT
questa_acquire || { echo "BLOCKED: Questa license unavailable"; exit 75; }

mkdir -p "$RUN_DIR"
cd "$RUN_DIR"
rm -rf work
"$VLIB" work >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv"
       "$ROOT/rtl/wolf/ram_sdram.sv" "$ROOT/sim/sdram_model.sv"
       "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv"
       "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_dcs_stub.sv"
       "$ROOT/rtl/wolf/wolf_memsys.sv"
       "$ROOT/sim/$TB.sv" )

"$VLOG" -sv -quiet -svinputport=var "${SRC[@]}"
LOG="$ROOT/sim/build/${TB}.vsim.log"
set +e
"$VSIM" -c -quiet -do "run -all; quit" "$TB" ${VSIM_ARGS:-} 2>&1 | tee "$LOG" | grep -iE "CONFIG|MILESTONE|FRONTIER|SUMMARY|TAIL_PC|DONE|FAIL|RESULT[: ]|ASM_DMA_WRITE|MAME_FETCH_STATE|loaded MAME|released MAME|^# ok |Error|license"
sim_rc=${PIPESTATUS[0]}
set -e
[ "$sim_rc" -eq 0 ] || exit "$sim_rc"
if [ "$TB" = "tb_wolf_hangtime_boot" ]; then
  grep -Fq "DONE tb_wolf_hangtime_boot" "$LOG"
else
  grep -Fq "RESULT PASS" "$LOG"
fi
