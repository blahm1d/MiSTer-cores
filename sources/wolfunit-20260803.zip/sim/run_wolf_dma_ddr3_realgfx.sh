#!/usr/bin/env bash
# run_wolf_dma_ddr3_realgfx.sh -- full-loop proof of the gfx DDR3 hardware path: wolf_dma ->
# wolf_gfx_ddr_top -> stv_vram_ddr_agent (reused verbatim) -> ddr3_avalon_model (the SAME
# faithful oracle already cab-confirmed on the VRAM path), preloaded with the real 32MB umk3
# gfx ROM, replaying UMK3's real captured first blit and diffing against MAME ground truth.
set -e
cd "$(dirname "$0")/.."
IVERILOG=/c/iverilog/bin/iverilog
VVP=/c/iverilog/bin/vvp
T="${TMPDIR:-/tmp}"
STIM=sim/traces/wolf_dma_realblit1_stim.txt
OUT=sim/build/wolf_dma_realblit1_ddr3_out.txt

if [ ! -f sim/build/umk3_gfx.hex ]; then
  echo "sim/build/umk3_gfx.hex missing -- run: python sim/make_wolf_gfx_hex.py"
  exit 1
fi

mkdir -p sim/build
[ -f "$STIM" ] || { echo "missing exact MAME stimulus: $STIM"; exit 1; }

echo "== compile (32MB gfx preload takes a few seconds) =="
"$IVERILOG" -g2012 -o "$T/tb_dma_ddr3_realgfx.vvp" \
  rtl/pkg/wolf_pkg.sv rtl/wolf/wolf_dma.sv rtl/sdram/stv_vram_ddr_agent.sv \
  rtl/sdram/wolf_gfx_ddr_top.sv sim/ddr3_avalon_model.sv sim/tb_wolf_dma_ddr3_realgfx.sv

echo "== run real captured blit through the full DDR3 gfx path =="
"$VVP" "$T/tb_dma_ddr3_realgfx.vvp" \
  "+STIM=$STIM" "+OUT=$OUT"

echo "== diff vs MAME real captured post-blit VRAM =="
python sim/diff_dma_out_vs_mame.py "$OUT"
