#!/usr/bin/env python3
"""Project the MAME-captured Wolf blit-trigger stream onto the DUT clock timeline and
measure how many ce_pix-aligned IDLE samples the flip FSM sees inside its commit window.

Inputs : sim/build/wolf_flipphase_raw_<set>.txt  (from capture_wolf_flip_phase.lua)
Outputs: sim/build/wolf_flipphase_<set>.txt

Constants (all cited, none re-derived here):
  CLK_PER_FRAME  = 1462340   sim/build/tb_wolf_peak_fight_budget.log
  V_TOTAL        = 289       rtl/wolf/wolf_top.sv:27-28  (== MAME's 289 total lines)
  V_ACT          = 254       rtl/wolf/wolf_top.sv:27-28  (== MAME screen height 254)
  CLK_PER_LINE   = 1462340/289 = 5060 exactly
  CYC_PER_PIXEL  = 2.4966    sim/build/tb_wolf_peak_fight_budget.log
  FLIP_COMMIT_LIMIT = V_TOTAL - FLIP_PREFETCH_LINES = 285   rtl/wolf/wolf_video.sv:114
  commit window  = s0_vb && vc < 285  -> vc in [254,284]     rtl/wolf/wolf_video.sv:176
  ce_pix         = 1-in-10 of 80 MHz  Arcade-SmashTV.sv:243,252-253

PROXY WARNING: MAME retires a blit instantly; the DUT's busy duration is PROJECTED as
dst_pixels * 2.4966 clk, serialized FIFO-style (busy_end = max(busy_end, issue) + dur).
This is an UPPER BOUND on occupancy and is applied IDENTICALLY to both titles, so the
ORDERING between titles is the load-bearing result, not the absolute numbers.
"""
import sys, os

CLK_PER_FRAME = 1462340
V_TOTAL = 289
V_ACT = 254
CLK_PER_LINE = CLK_PER_FRAME // V_TOTAL      # 5060 exactly
assert CLK_PER_LINE * V_TOTAL == CLK_PER_FRAME
CYC_PER_PIXEL = 2.4966
COMMIT_LO_VC = V_ACT                         # 254
COMMIT_HI_VC = 285                           # exclusive (FLIP_COMMIT_LIMIT)
CE_DIV = 10


def count_multiples(a, b, p, m=CE_DIV):
    """count of k in [a,b) with k % m == p"""
    if b <= a:
        return 0
    # smallest k >= a with k%m==p
    k0 = a + ((p - a) % m)
    if k0 >= b:
        return 0
    return (b - 1 - k0) // m + 1


def main(path_in, path_out, label):
    scan_period = None
    events = []          # (global_clk_issue, dst_pixels)
    nb = 0
    with open(path_in) as f:
        for line in f:
            if line.startswith("GEOM"):
                for tok in line.split()[1:]:
                    k, v = tok.split("=")
                    if k == "scan_period":
                        scan_period = float(v)
            elif line.startswith("B "):
                _, fr, tuvbs, dst, cmd, t = line.split()
                fr = int(fr); tuvbs = float(tuvbs); dst = int(dst)
                lf = V_ACT - tuvbs / scan_period
                if lf < 0:
                    lf += V_TOTAL
                if lf < 0 or lf >= V_TOTAL:      # numeric guard
                    lf = lf % V_TOTAL
                events.append((fr * CLK_PER_FRAME + lf * CLK_PER_LINE, dst))
                nb += 1
    assert scan_period, "no GEOM header"
    events.sort()

    # --- serialized busy projection -> merged, disjoint, sorted intervals
    busy = []
    end = 0.0
    for issue, dst in events:
        s = max(end, issue)
        e = s + dst * CYC_PER_PIXEL
        if busy and s <= busy[-1][1] + 1e-9:
            busy[-1][1] = max(busy[-1][1], e)
        else:
            busy.append([s, e])
        end = e

    frames = sorted({int(ev[0] // CLK_PER_FRAME) for ev in events})
    f0, f1 = frames[0], frames[-1]

    # --- per-line busy coverage profile (clk of busy per vc, summed over frames)
    line_busy = [0.0] * V_TOTAL
    for s, e in busy:
        ls = int(s // CLK_PER_LINE)
        le = int((e - 1e-9) // CLK_PER_LINE)
        for L in range(ls, le + 1):
            a = max(s, L * CLK_PER_LINE)
            b = min(e, (L + 1) * CLK_PER_LINE)
            if b > a:
                line_busy[L % V_TOTAL] += (b - a)

    # --- per-frame ce_pix-aligned idle count inside the commit window
    bi = 0
    rows = []
    for fr in range(f0, f1 + 1):
        w0 = fr * CLK_PER_FRAME + COMMIT_LO_VC * CLK_PER_LINE
        w1 = fr * CLK_PER_FRAME + COMMIT_HI_VC * CLK_PER_LINE
        # gather busy intervals overlapping [w0,w1)
        while bi < len(busy) and busy[bi][1] <= w0:
            bi += 1
        j = bi
        segs = []
        while j < len(busy) and busy[j][0] < w1:
            segs.append((max(busy[j][0], w0), min(busy[j][1], w1)))
            j += 1
        # idle gaps
        gaps = []
        cur = w0
        for s, e in segs:
            if s > cur:
                gaps.append((cur, s))
            cur = max(cur, e)
        if cur < w1:
            gaps.append((cur, w1))
        idle = [0] * CE_DIV
        for a, b in gaps:
            ai = int(a) if a == int(a) else int(a) + 1     # ceil
            bi2 = int(b) + (1 if b != int(b) else 0)       # ceil (exclusive bound)
            for p in range(CE_DIV):
                idle[p] += count_multiples(ai, bi2, p)
        busy_clk = sum(e - s for s, e in segs)
        rows.append((fr, min(idle), sum(1 for x in idle if x == 0), busy_clk))

    nfr = len(rows)
    starved = sum(1 for r in rows if r[1] == 0)
    allphase = sum(1 for r in rows if r[2] == CE_DIV)
    win_clk = (COMMIT_HI_VC - COMMIT_LO_VC) * CLK_PER_LINE
    tot_frames = f1 - f0 + 1

    with open(path_out, "w") as o:
        w = o.write
        w("== wolf flip-phase analysis: %s ==\n" % label)
        w("source        : %s\n" % path_in)
        w("blit triggers : %d\n" % nb)
        w("frames        : %d  (MAME frame %d..%d)\n" % (nfr, f0, f1))
        w("commit window : vc [%d,%d]  = %d lines = %d clk = %d ce_pix samples/phase\n"
          % (COMMIT_LO_VC, COMMIT_HI_VC - 1, COMMIT_HI_VC - COMMIT_LO_VC,
             win_clk, win_clk // CE_DIV))
        w("projection    : dst_px * %.4f clk, FIFO-serialized (UPPER-BOUND PROXY)\n"
          % CYC_PER_PIXEL)
        w("\n-- discriminating numbers --\n")
        w("frames with min-across-phase idle == 0 : %d / %d = %.3f%%\n"
          % (starved, nfr, 100.0 * starved / nfr))
        w("frames with ALL 10 phases idle == 0    : %d / %d = %.3f%%\n"
          % (allphase, nfr, 100.0 * allphase / nfr))
        vals = sorted(r[1] for r in rows)
        w("min idle ce_pix samples in window : min=%d p01=%d median=%d mean=%.1f max=%d"
          " (of %d possible)\n"
          % (vals[0], vals[len(vals) // 100], vals[len(vals) // 2],
             sum(vals) / len(vals), vals[-1], win_clk // CE_DIV))
        cov = sum(r[3] for r in rows) / nfr
        w("mean busy clk inside commit window : %.1f / %d = %.3f%% coverage\n"
          % (cov, win_clk, 100.0 * cov / win_clk))
        act = sum(line_busy[0:V_ACT]) / tot_frames
        blk = sum(line_busy[V_ACT:V_TOTAL]) / tot_frames
        w("mean busy clk per frame: ACTIVE(vc 0..253)=%.1f  BLANK(vc 254..288)=%.1f"
          "  -> %.2f%% of burst in blank\n"
          % (act, blk, 100.0 * blk / (act + blk) if (act + blk) else 0.0))
        w("mean busy clk per frame TOTAL = %.1f (%.3f%% of %d clk frame duty)\n"
          % (act + blk, 100.0 * (act + blk) / CLK_PER_FRAME, CLK_PER_FRAME))
        w("\n-- per-line busy coverage (mean clk busy per frame, of %d clk/line) --\n"
          % CLK_PER_LINE)
        for L in range(0, V_TOTAL, 1):
            if L < V_ACT and L % 16 and L != V_ACT - 1:
                continue
            tag = "ACT " if L < V_ACT else ("CMT " if L < COMMIT_HI_VC else "PRE ")
            w("  vc=%3d %s %8.1f  (%6.2f%%)\n"
              % (L, tag, line_busy[L] / tot_frames,
                 100.0 * line_busy[L] / tot_frames / CLK_PER_LINE))
        w("\n-- worst 12 frames by min-across-phase idle --\n")
        for r in sorted(rows, key=lambda x: x[1])[:12]:
            w("  frame %5d  min_idle=%6d  phases_zero=%2d  busy_in_win=%9.1f\n" % r)
    print(open(path_out).read())


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
