#!/usr/bin/env python3
"""Self-check a HUD capture: does palette[VRAM entry] reproduce MAME's RGB?

analyze_hud_flash_capture.py classifies a reverting pixel as "palette-only" when
the framebuffer entry behind it did not revert.  That classification is only
meaningful if the capture's VRAM entry index actually corresponds to the screen
x it is being compared against.  If the mapping is off by a constant, or the
visible page is picked wrong, every reversion would be mislabelled palette-only.

This tool refuses to assume.  It sweeps page and x-offset, reconstructs RGB from
the captured framebuffer entry + captured palette word, and reports which
combination reproduces MAME's captured scanout.  Only an exact, high-coverage
match licenses the palette-only verdict.

Wolf palette words are xRRRRRGGGGGBBBBB expanded by MAME's pal5bit().
"""

import sys
import collections

sys.path.insert(0, __file__.rsplit("/", 1)[0] if "/" in __file__ else ".")
from analyze_hud_flash_capture import parse  # noqa: E402


def pal5(v):
    """MAME pal5bit(): 5-bit component -> 8-bit."""
    v &= 0x1F
    return (v << 3) | (v >> 2)


def word_to_rgb(w):
    return (pal5(w >> 10) << 16) | (pal5(w >> 5) << 8) | pal5(w)


def score(frames, f, page, off):
    """Fraction of the row band where palette[entry] == emitted RGB."""
    rec = frames[f]
    hit = tot = 0
    for (p, y), entries in rec["vram"].items():
        if p != page:
            continue
        scr = rec["screen"].get(y)
        if not scr:
            continue
        for x in range(len(scr)):
            xi = x + off
            if not (0 <= xi < len(entries)):
                continue
            pen = entries[xi] & 0x7FFF
            w = rec["palette"].get(pen)
            if w is None:
                continue
            tot += 1
            if word_to_rgb(w) == (scr[x] & 0xFFFFFF):
                hit += 1
    return hit, tot


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    for path in argv[1:]:
        frames, _ = parse(path)
        order = list(frames)
        print("=" * 74)
        print(path)
        print("=" * 74)
        if not order:
            print("  empty")
            continue
        pages = sorted({p for (p, _) in frames[order[0]]["vram"]})

        # Use a mid-window frame; sweep a generous offset range.
        f = order[len(order) // 2]
        best = []
        for page in pages:
            for off in range(-8, 9):
                hit, tot = score(frames, f, page, off)
                if tot:
                    best.append((hit / tot, page, off, hit, tot))
        best.sort(reverse=True)
        print(f"  probe frame {f}: best page/offset combinations")
        for frac, page, off, hit, tot in best[:5]:
            print(f"    page {page} off {off:+d}: {100*frac:6.2f}% "
                  f"({hit}/{tot})")

        top = best[0]
        print()
        if top[0] > 0.99:
            print(f"  ALIGNED: page {top[1]}, offset {top[2]:+d} reproduces "
                  f"{100*top[0]:.2f}% of emitted RGB.")
            print("  -> per-x framebuffer/screen correspondence is VALID; the")
            print("     palette-only classification can be trusted (with this")
            print("     page/offset applied).")
        else:
            print(f"  NOT ALIGNED: best is only {100*top[0]:.2f}%.")
            print("  -> palette[entry] does NOT reproduce the emitted pixel, so")
            print("     the capture's VRAM band and SCREEN band are not a")
            print("     per-x match. Any 'palette-only' verdict from")
            print("     analyze_hud_flash_capture.py is an ARTIFACT of that")
            print("     mismatch and must not be used.")

        # Which page does each frame actually match?  (visible-page truth)
        print("\n  per-frame best page (offset fixed at the winner):")
        off = top[2]
        rowline = []
        for f in order:
            cand = []
            for page in pages:
                hit, tot = score(frames, f, page, off)
                cand.append((hit / tot if tot else 0.0, page))
            cand.sort(reverse=True)
            rowline.append(f"{cand[0][1]}({100*cand[0][0]:.0f}%)")
        print("    " + " ".join(rowline))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
