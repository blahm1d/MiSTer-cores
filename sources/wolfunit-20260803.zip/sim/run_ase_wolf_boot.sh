#!/usr/bin/env bash
# ASE port of run_questa_wolf_boot.sh: the Wolf boot smoke (real TMS34010 core +
# wolf_memsys, 8000-PC MAME golden) under ModelSim ASE 17.0 — license-free, safe
# alongside a foreign Questa FSE vsim (NEVER launch Questa FSE from here).
set -euo pipefail

MS=${MS:-/c/intelFPGA_lite/17.0/modelsim_ase/win32aloem}
TB="tb_wolf_boot_memsys"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"

cd "$ROOT/sim"
rm -rf work
"$MS/vlib.exe" work >/dev/null

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/wolf_pkg.sv" \
       "$ROOT/rtl/wolf/ram_sdram.sv" "$ROOT/sim/sdram_model.sv" \
       "$ROOT/rtl/wolf/wolf_mem.sv" "$ROOT/rtl/wolf/wolf_dma.sv" \
       "$ROOT/rtl/wolf/wolf_pic.sv" "$ROOT/rtl/wolf/wolf_memsys.sv" \
       "$ROOT/sim/$TB.sv" )

echo "compiling ${#SRC[@]} sources ..."
"$MS/vlog.exe" -sv -quiet -svinputport=var ${EXTRA_VLOG:-} "${SRC[@]}"

LOG="$ROOT/sim/build/${TB}.ase.log"
mkdir -p "$ROOT/sim/build"
set +e
"$MS/vsim.exe" -c -quiet -do "run -all; quit -f" "work.$TB" > "$LOG" 2>&1
set -e
grep -iE "PASS|FAIL|FRONTIER|golden|Error" "$LOG" | head -20 || true
if grep -q "PASS" "$LOG" && ! grep -q "FAIL" "$LOG"; then
  echo "BOOT SMOKE (ASE): PASS"
else
  echo "BOOT SMOKE (ASE): FAIL (see $LOG)"
  exit 1
fi
