// Final MiSTer audio-pin guard for Wolf Unit.
//
// The real DCS boot trace emits digital zero before it becomes audible. The
// cabinet pop occurs earlier, at the output path coming online, so the guard
// must sit after the complete core rather than inside the ADSP/DAC model.
`default_nettype none
module wolf_audio_guard #(
    parameter integer CLK_HZ = 80000000,
    parameter integer SAMPLE_HZ = 31250,
    parameter integer RAMP_BITS = 12
) (
    input  wire logic               clk,
    input  wire logic               hold_zero,
    input  wire logic signed [15:0] audio_l_in,
    input  wire logic signed [15:0] audio_r_in,
    output      logic signed [15:0] audio_l_out = 16'sd0,
    output      logic signed [15:0] audio_r_out = 16'sd0
);
    localparam integer SAMPLE_DIV = CLK_HZ / SAMPLE_HZ;
    localparam logic [RAMP_BITS:0] GAIN_FULL =
        {1'b1, {RAMP_BITS{1'b0}}};

    logic [$clog2(SAMPLE_DIV)-1:0] sample_div = '0;
    logic [RAMP_BITS:0] gain = '0;
    wire sample_ce = (sample_div == SAMPLE_DIV-1);
    wire signed [RAMP_BITS+1:0] gain_signed = $signed({1'b0, gain});
    wire signed [RAMP_BITS+17:0] product_l = audio_l_in * gain_signed;
    wire signed [RAMP_BITS+17:0] product_r = audio_r_in * gain_signed;
    wire input_audible = (audio_l_in != 16'sd0) || (audio_r_in != 16'sd0);

    always_ff @(posedge clk) begin
        if (hold_zero) begin
            sample_div  <= '0;
            gain        <= '0;
            audio_l_out <= 16'sd0;
            audio_r_out <= 16'sd0;
        end else begin
            if (sample_ce) sample_div <= '0;
            else           sample_div <= sample_div + 1'b1;

            if (sample_ce) begin
                // Keep the physical pins at exact signed zero for the entire
                // silent DCS boot. Start the release only when real program
                // audio arrives, so the envelope cannot expire too early.
                if (gain == '0 && !input_audible) begin
                    audio_l_out <= 16'sd0;
                    audio_r_out <= 16'sd0;
                end else if (gain != GAIN_FULL) begin
                    audio_l_out <= product_l >>> RAMP_BITS;
                    audio_r_out <= product_r >>> RAMP_BITS;
                    gain <= gain + 1'b1;
                end else begin
                    audio_l_out <= audio_l_in;
                    audio_r_out <= audio_r_in;
                end
            end
        end
    end
endmodule
`default_nettype wire
