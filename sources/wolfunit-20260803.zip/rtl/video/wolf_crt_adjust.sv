// Wolf-unit core-side glue for rmonic79/MiSTer-CRT-Adjust.
//
// Wolf's native raster remains 506 x 289 at an 8 MHz pixel rate from the
// 80 MHz system clock (54.70684 Hz). This wrapper replaces the generic
// runtime-tap sync muxes with small phase counters, applies menu changes only
// at safe raster boundaries, and adapts blanking for arcade_video.
`timescale 1ns/1ps
`default_nettype none

module wolf_crt_adjust (
    input  wire       clk,
    input  wire       ce_pix,

    input  wire       active_in,
    input  wire [4:0] hsize_code,
    input  wire [6:0] hpos_code,
    input  wire [4:0] vshift_code,

    input  wire [7:0] r_in,
    input  wire [7:0] g_in,
    input  wire [7:0] b_in,
    input  wire       hs_in,
    input  wire       vs_in,
    input  wire       hb_in,
    input  wire       vb_in,

    output wire       ce_pix_out,
    output wire [7:0] r_out,
    output wire [7:0] g_out,
    output wire [7:0] b_out,
    output wire       hs_out,
    output wire       vs_out,
    output wire       hb_out,
    output wire       vb_out
);

    localparam integer H_TOTAL = 506;
    localparam integer V_TOTAL = 289;
    localparam integer H_SYNC  = 43;
    localparam integer V_SYNC  = 3;
    localparam [6:0] READ_PERIOD_BASE = 7'd40; // (80 MHz / 8 MHz) * 4

    // Full-cross-product safe range: H-size 0,-1,...,-8. Invalid persisted
    // values fail to zero rather than reaching an unqualified geometry.
    wire signed [5:0] hsize_request_wide =
        -$signed({1'b0, hsize_code});
    wire signed [4:0] hsize_request =
        (hsize_code <= 5'd8) ? hsize_request_wide[4:0] : 5'sd0;

    // Dense Wolf SYNCSHIFT map: 0,+1,...,+48,-4,...,-1.
    // Codes 49..52 decode as code-53.
    wire [8:0] hpos_phase_request =
        (hpos_code <= 7'd48) ? {2'b00, hpos_code} :
        (hpos_code <= 7'd52) ? (9'd453 + {2'b00, hpos_code}) :
                              9'd0;

    // Dense vertical map: 0,+1,...,+15,-13,...,-1. The wrapper and line
    // buffer consume two lines of the nominal 15-line front porch; -14 is the
    // first setting that reaches active output. Codes 16..28 decode as code-29.
    wire [8:0] vshift_phase_request =
        (vshift_code <= 5'd15) ? {4'd0, vshift_code} :
        (vshift_code <= 5'd28) ? (9'd260 + {4'd0, vshift_code}) :
                                9'd0;

    reg              active_pending = 1'b0;
    reg signed [4:0] hsize_pending = 5'sd0;
    reg              active_q = 1'b0;
    reg signed [4:0] hsize_q = 5'sd0;
    reg        [8:0] hpos_phase_q = 9'd0;
    reg        [8:0] vshift_phase_q = 9'd0;

    // Horizontal phase zero is the native HSync rising edge. Pre-shifting the
    // sync here lets synthesis prune crt_adjust's 506-bit runtime-tap mux:
    // the byte-exact engine receives constant hoffset=0 while retaining
    // HPOS_SYNCSHIFT line-reference semantics.
    reg native_hs_d = 1'b0;
    reg native_vs_d = 1'b0;
    reg native_hb_d = 1'b1;
    reg [8:0] hphase_q = 9'd0;
    wire native_hs_rise = ce_pix && hs_in && !native_hs_d;
    wire native_vs_rise = ce_pix && vs_in && !native_vs_d;
    wire native_active_start = ce_pix && !hb_in && native_hb_d;
    wire [8:0] hphase_now =
        native_hs_rise ? 9'd0 :
        (hphase_q == 9'd505) ? 9'd0 : hphase_q + 9'd1;
    wire [9:0] hsync_end = {1'b0, hpos_phase_q} + H_SYNC;
    wire hs_pre =
        (hsync_end <= H_TOTAL) ?
            ((hphase_now >= hpos_phase_q) &&
             ({1'b0, hphase_now} < hsync_end)) :
            ((hphase_now >= hpos_phase_q) ||
             ({1'b0, hphase_now} < (hsync_end - H_TOTAL)));
    reg hs_pre_d = 1'b0;
    wire hs_pre_rise = ce_pix && hs_pre && !hs_pre_d;

    always @(posedge clk) if (ce_pix) begin
        native_hs_d <= hs_in;
        native_vs_d <= vs_in;
        native_hb_d <= hb_in;
        hs_pre_d     <= hs_pre;
        hphase_q     <= hphase_now;

        // Wolf x=0 is phase 101 from native HS. Every qualified shifted pulse
        // has ended by phase 90, so H-position can change here without a runt
        // or duplicate pulse. Size/enable become active on the next shifted HS.
        if (native_active_start) begin
            hpos_phase_q   <= hpos_phase_request;
            hsize_pending  <= hsize_request;
            active_pending <= active_in;
        end
        if (hs_pre_rise) begin
            hsize_q <= hsize_pending;
            active_q <= active_pending;
        end

        if (native_vs_rise)
            vshift_phase_q <= vshift_phase_request;
    end

    // Counter-based V-shift replaces the generic 289-bit runtime-tap mux. It
    // advances once per shifted line and keeps the native three-line pulse.
    reg       native_vs_line_d = 1'b0;
    reg [8:0] vphase_q = 9'd0;
    reg       vs_pre_q = 1'b0;
    wire native_vs_line_rise = vs_in && !native_vs_line_d;
    wire [8:0] vphase_now =
        native_vs_line_rise ? 9'd0 :
        (vphase_q == 9'd288) ? 9'd0 : vphase_q + 9'd1;
    wire [9:0] vsync_end = {1'b0, vshift_phase_q} + V_SYNC;
    wire vs_pre_now =
        (vsync_end <= V_TOTAL) ?
            ((vphase_now >= vshift_phase_q) &&
             ({1'b0, vphase_now} < vsync_end)) :
            ((vphase_now >= vshift_phase_q) ||
             ({1'b0, vphase_now} < (vsync_end - V_TOTAL)));
    always @(posedge clk) if (hs_pre_rise) begin
        native_vs_line_d <= vs_in;
        vphase_q <= vphase_now;
        vs_pre_q <= vs_pre_now;
    end

    wire [7:0] stretch_r;
    wire [7:0] stretch_g;
    wire [7:0] stretch_b;
    wire       stretch_hs_unused;
    wire       stretch_vs_unused;
    wire       stretch_hb;
    wire       stretch_vb_unused;
    wire       hs_ref;

    // Quarter-cycle read rate. Every line restarts from hs_ref_out, never raw
    // native HSync, so the resized stream cannot drift between lines.
    reg hs_ref_d = 1'b0;
    always @(posedge clk)
        hs_ref_d <= hs_ref;
    wire hs_ref_rise = hs_ref && !hs_ref_d;

    wire signed [6:0] read_period_s = 7'sd40 + hsize_q;
    wire        [6:0] read_period = read_period_s[6:0];
    reg         [6:0] read_acc = 7'd0;
    wire        [7:0] read_sum = {1'b0, read_acc} + 8'd4;
    wire              read_tick = read_sum >= {1'b0, read_period};
    always @(posedge clk) begin
        if (hs_ref_rise)
            read_acc <= 7'd0;
        else if (read_tick)
            read_acc <= read_sum - {1'b0, read_period};
        else
            read_acc <= read_sum[6:0];
    end

    assign ce_pix_out = active_q ? read_tick : ce_pix;

    crt_adjust #(
        .VTOTAL   (V_TOTAL),
        .HTOTAL   (H_TOTAL),
        .HPOS_MODE(`HPOS_SYNCSHIFT)
    ) u_crt_adjust (
        .clk       (clk),
        .pxl_cen   (ce_pix),
        .pxl2_cen  (ce_pix_out),
        .active    (active_q),
        .hsize     (hsize_q),
        .hoffset   (9'sd0),
        .voffset   (6'sd0),
        .r_in      (r_in),
        .g_in      (g_in),
        .b_in      (b_in),
        .hs_in     (hs_pre),
        .vs_in     (vs_pre_q),
        .hb_in     (hb_in | vb_in),
        .vb_in     (vb_in),
        .r_out     (stretch_r),
        .g_out     (stretch_g),
        .b_out     (stretch_b),
        .hs_out    (stretch_hs_unused),
        .vs_out    (stretch_vs_unused),
        .hb_out    (stretch_hb),
        .vb_out    (stretch_vb_unused),
        .hs_ref_out(hs_ref)
    );

    // Preserve an HBlank edge on every vertical-blank line. arcade_video
    // samples VBlank at an HBlank edge, while crt_adjust intentionally keeps
    // its pass window closed for the entire vertical blank.
    reg hs_ref_pix_d = 1'b0;
    reg vb_line_q = 1'b0;
    reg vb_active_q = 1'b0;
    always @(posedge clk) if (ce_pix) begin
        hs_ref_pix_d <= hs_ref;
        if (hs_ref && !hs_ref_pix_d) begin
            vb_line_q   <= vb_in;
            vb_active_q <= vb_line_q;
        end
    end

    // Off is an external bit-exact passthrough. When On, sync leaves at the
    // native pixel cadence (not the variable read cadence), and retrace is
    // always explicitly blanked before the DAC boundary.
    wire adjusted_retrace = vb_active_q | hs_ref;
    assign r_out  = active_q ? (adjusted_retrace ? 8'd0 : stretch_r) : r_in;
    assign g_out  = active_q ? (adjusted_retrace ? 8'd0 : stretch_g) : g_in;
    assign b_out  = active_q ? (adjusted_retrace ? 8'd0 : stretch_b) : b_in;
    assign hs_out = active_q ? hs_ref : hs_in;
    assign vs_out = active_q ? vs_pre_q : vs_in;
    assign hb_out = active_q ?
        (vb_active_q ? (hb_in | hs_ref) : (stretch_hb | hs_ref)) :
        hb_in;
    assign vb_out = active_q ? vb_active_q : vb_in;

endmodule

`default_nettype wire
