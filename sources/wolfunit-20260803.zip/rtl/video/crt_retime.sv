// ============================================================================
// crt_retime.sv — core-agnostic frame retimer for CRT / PVM output
// ============================================================================
//
// PROBLEM
//   Arcade cores run at whatever rate the original hardware ran at. The Wolf
//   unit is ~54.7 Hz. A PVM (or any CRT expecting broadcast-ish timing) will
//   not lock to that: the picture rolls, scrolls, or drops sync entirely.
//
//   The tempting fix is to retune the core's PLL until the output rate is
//   friendly. DO NOT. Core pixel timing sets game speed, DMA/blitter budgets
//   and audio cadence; altering it desynchronises everything the emulation is
//   accurate about, and every gate that measured cycle counts becomes a lie.
//
// WHAT THIS DOES
//   Fully decouples the two. The core keeps its exact native timing and writes
//   frames into a buffer. A completely independent output timing generator
//   scans that buffer out at a rate the display is happy with. Nothing on the
//   core side is altered, delayed, or throttled -- the write side never applies
//   backpressure, by construction.
//
//   input  (core domain)   -> write port -> frame buffer -> read port -> output
//   clk_in, native rate                                              clk_out, display rate
//
// FRAME RATE CONVERSION IS NOT FREE — READ THIS BEFORE INTEGRATING
//   When in_rate != out_rate the reader must occasionally show a frame twice
//   (out faster than in) or skip one (out slower). That is JUDDER, and it is
//   unavoidable in any scheme that keeps core timing intact and also holds a
//   fixed output rate. You are choosing WHICH artifact you get:
//       retime  -> rock-solid sync, periodic judder      (this module)
//       native  -> perfectly smooth, display may not lock
//   At 54.7 -> 59.94 Hz that is ~5.2 repeated frames/second. On a PVM showing
//   mostly-static arcade art this is far less objectionable than a rolling
//   picture, but it IS visible on smooth scrollers. Ship both and let the user
//   pick -- see BYPASS below.
//
// BYPASS
//   PASSTHROUGH=1 (or the runtime `bypass` input) wires the input straight to
//   the output with zero buffering and zero added latency, so a single build
//   can offer "native timing" and "PVM timing" as a menu option. When bypassed
//   the buffer is not read and the output generator is idle.
//
// PORTING TO ANOTHER CORE
//   Everything core-specific is a parameter or is derived from the incoming
//   sync signals. The module never looks at pixel content and never assumes a
//   resolution -- it measures the active window from de_in. To port:
//     1. Set HACT/VACT to the core's active area (or leave the defaults and
//        let AUTO_SIZE latch them from the first complete frame).
//     2. Set the OUT_* timing parameters to your target mode.
//     3. Give it a clk_out at OUT_PIXCLK_HZ.
//   Nothing else. It has no knowledge of Wolf, blitters or palettes.
//
// TEARING
//   With BUFFERS=2 the writer owns one buffer and the reader the other, and
//   they swap only when the writer finishes a frame AND the reader is in
//   vblank -- so a torn frame is never displayed. BUFFERS=1 halves the memory
//   and WILL tear; it exists for cores too large to afford two.
//
// MEMORY COST — CHECK THIS FIRST, IT IS USUALLY THE BINDING CONSTRAINT
//   bits = HACT * VACT * (3*CDEPTH) * BUFFERS
//   Wolf at 400x254, CDEPTH=4 (12bpp), BUFFERS=2:
//       400 * 254 * 12 * 2 = 2,438,400 bits = ~2.44 Mbit
//   A 5CSEBA6 has ~5.5 Mbit of M10K TOTAL and the core already uses much of it.
//   If it does not fit: drop CDEPTH to 4, drop BUFFERS to 1, or retarget the
//   buffer at SDRAM/DDR3 (the write/read ports here are deliberately simple
//   enough to swap for an external-memory agent).
//
// `default_nettype none

module crt_retime #(
    // ---- source geometry -----------------------------------------------
    parameter int HACT      = 400,   // active pixels per line
    parameter int VACT      = 254,   // active lines per frame
    parameter int CDEPTH    = 4,     // bits per colour channel stored
    parameter int BUFFERS   = 2,     // 2 = tear-free, 1 = half the memory
    parameter bit AUTO_SIZE = 1'b1,  // latch actual active window from de_in

    // ---- output mode (defaults: 15.734 kHz / 59.94 Hz 240p, PVM-friendly) --
    parameter int OUT_HACT  = 400,
    parameter int OUT_HFP   = 24,
    parameter int OUT_HSYNC = 48,
    parameter int OUT_HBP   = 40,
    parameter int OUT_VACT  = 254,
    parameter int OUT_VFP   = 6,
    parameter int OUT_VSYNC = 3,
    parameter int OUT_VBP   = tex_vbp_default(),
    parameter bit OUT_HS_POL = 1'b0, // 0 = active low
    parameter bit OUT_VS_POL = 1'b0,

    parameter bit PASSTHROUGH = 1'b0, // compile-time hard bypass

    // FB_DDR=1: the frame lives in DDR3 (crt_fb_ddr) and this module sources
    // pixels from a LINE BUFFER instead of an on-chip frame array.
    //
    // MEASURED, and the reason this parameter exists: a 400x254 12bpp double
    // buffered frame is 2,438,400 bits = 239 M10K blocks. The Wolf core already
    // uses 414 of 553, leaving 139. Not tight -- IMPOSSIBLE. In DDR3 the
    // on-chip cost falls to two line buffers, ~2 blocks, a 100x reduction, and
    // double buffering becomes free because DDR3 has gigabytes.
    parameter bit FB_DDR = 1'b0
)(
    // ---- core side (write) — NEVER back-pressured -------------------------
    input  wire                    clk_in,
    input  wire                    ce_in,      // pixel enable in the core domain
    input  wire                    rst_in,
    input  wire [CDEPTH-1:0]       r_in,
    input  wire [CDEPTH-1:0]       g_in,
    input  wire [CDEPTH-1:0]       b_in,
    input  wire                    de_in,      // active-video
    input  wire                    hs_in,      // used only for edge detection
    input  wire                    vs_in,

    // ---- display side (read) ---------------------------------------------
    input  wire                    clk_out,
    input  wire                    ce_out,     // output pixel enable
    input  wire                    rst_out,
    input  wire                    bypass,     // runtime: 1 = native passthrough

    // ---- geometry controls (runtime, wire to the OSD) --------------------
    // INTEGER REPLICATION ONLY. There is no interpolator here and there will
    // not be one: on a CRT the entire point is a crisp 1:1 (or exact N:N)
    // pixel. A resampler that turns 254 lines into 240 softens every edge and
    // every character cell, which is the artifact people buy a PVM to avoid.
    // If the source does not fit, we CROP and let the user AIM -- we do not
    // blend.
    input  wire [2:0]              scale_h,    // 1..7 horizontal pixel repeat (0 treated as 1)
    input  wire [2:0]              scale_v,    // 1..7 vertical line repeat   (0 treated as 1)
    input  wire [11:0]             crop_x,     // first SOURCE column shown
    input  wire [11:0]             crop_y,     // first SOURCE line shown
    input  wire signed [11:0]      pos_h,      // nudge right(+)/left(-), output pixels
    input  wire signed [11:0]      pos_v,      // nudge down(+)/up(-),  output lines
    output logic [CDEPTH-1:0]      r_out,
    output logic [CDEPTH-1:0]      g_out,
    output logic [CDEPTH-1:0]      b_out,
    output logic                   de_out,
    output logic                   hs_out,
    output logic                   vs_out,
    output logic                   hb_out,
    output logic                   vb_out,

    // ---- external line-buffer interface (FB_DDR=1) ------------------------
    // The display side asks for a SOURCE line and reads pixels back from the
    // buffer crt_fb_ddr filled. Requests are per SOURCE line, so vertical
    // scaling costs no extra DDR3 traffic.
    output logic                   lb_line_req,
    output logic                   lb_frame_start,
    output logic [11:0]            lb_line_num,
    output logic                   lb_buf_sel,
    input  wire                    lb_line_ready,
    output logic [11:0]            lb_rd_x,
    output logic                   lb_rd_buf,
    input  wire [15:0]             lb_rd_data,

    // ---- observability (tie off if unused) --------------------------------
    output logic [15:0]            dbg_frames_written,
    output logic [15:0]            dbg_frames_shown,
    output logic [15:0]            dbg_frames_repeated,
    output logic [15:0]            dbg_frames_dropped,
    output logic [15:0]            dbg_lines_late
);

    function automatic int tex_vbp_default();
        // Chosen so total lines land near a 15.734 kHz line rate for the
        // default 240p-ish mode; override for any other display.
        tex_vbp_default = 17;
    endfunction

    localparam int PIXW  = 3 * CDEPTH;
    localparam int AW    = $clog2(HACT * VACT);
    localparam int BUFW  = (BUFFERS > 1) ? 1 : 0;

    // ======================================================================
    // WRITE SIDE — core domain. Coordinates come from the sync signals, never
    // from an assumed resolution, so this ports without modification.
    // ======================================================================
    logic [$clog2(HACT+1)-1:0] wx;
    logic [$clog2(VACT+1)-1:0] wy;
    logic                      de_q, vs_q;
    logic                      wbuf;          // buffer the writer owns
    logic                      wframe_done;   // 1-clk pulse at end of frame

    // Measured active window (AUTO_SIZE): the first complete frame tells us
    // the real geometry, so a core whose active area differs from the
    // parameters still lands in the buffer correctly instead of wrapping.
    logic [$clog2(HACT+1)-1:0] meas_hact;
    logic [$clog2(VACT+1)-1:0] meas_vact;
    logic                      meas_valid;

    wire de_rise = de_in & ~de_q;
    wire de_fall = ~de_in & de_q;
    wire vs_rise = vs_in & ~vs_q;

    always_ff @(posedge clk_in) begin
        if (rst_in) begin
            wx <= '0; wy <= '0; de_q <= 1'b0; vs_q <= 1'b0;
            wbuf <= 1'b0; wframe_done <= 1'b0;
            meas_hact <= HACT[$bits(meas_hact)-1:0];
            meas_vact <= VACT[$bits(meas_vact)-1:0];
            meas_valid <= ~AUTO_SIZE;
            dbg_frames_written <= '0;
        end else begin
            wframe_done <= 1'b0;
            if (ce_in) begin
                de_q <= de_in;
                vs_q <= vs_in;

                if (de_in) begin
                    if (wx < HACT[$bits(wx)-1:0]) wx <= wx + 1'b1;
                end
                if (de_fall) begin
                    // end of an active line: record width, advance row
                    if (AUTO_SIZE && !meas_valid) meas_hact <= wx;
                    wx <= '0;
                    if (wy < VACT[$bits(wy)-1:0]) wy <= wy + 1'b1;
                end
                if (vs_rise) begin
                    // end of frame: record height, publish, swap buffers
                    if (AUTO_SIZE && !meas_valid) begin
                        meas_vact  <= wy;
                        meas_valid <= 1'b1;
                    end
                    wx <= '0; wy <= '0;
                    wframe_done <= 1'b1;
                    dbg_frames_written <= dbg_frames_written + 1'b1;
                    if (BUFFERS > 1) wbuf <= ~wbuf;
                end
            end
        end
    end

    wire              wr_en   = ce_in && de_in && !rst_in;
    wire [AW-1:0]     wr_addr = wy * meas_hact + wx;
    wire [PIXW-1:0]   wr_data = {r_in, g_in, b_in};

    // ======================================================================
    // FRAME BUFFER — true dual-port, one clock per side. This is the ONLY
    // clock crossing in the module and it is a proper dual-clock RAM, not an
    // ad-hoc handshake. Read latency is 1 clk_out.
    // ======================================================================
    // The on-chip frame array and BOTH its access ports live inside one
    // generate: when the frame is in DDR3 none of it is built, which is the
    // whole point (239 M10K blocks vs 139 free).
    logic [PIXW-1:0] rd_q;

    // ---- FB_DDR line sourcing -------------------------------------------
    // Fetch a source line ONCE, when src_y changes, into the buffer the display
    // is not currently reading. Vertical replication (scale_v) reuses it, so N
    // output lines cost ONE fetch.
    wire use_bypass = PASSTHROUGH || bypass;
    logic [11:0] lb_last_req_y, lb_ready_y, lb_show_y;
    logic        lb_fill, lb_show, lb_inflight, lb_complete;
    logic        lb_new_frame_pending;
    wire         lb_enter_vblank = ce_out &&
                                   (ox == OUT_HACT[$bits(ox)-1:0] - 1'b1) &&
                                   (oy == OUT_VACT[$bits(oy)-1:0] - 1'b1);
    wire         lb_line_boundary = ce_out &&
                                    (ox == OUT_HTOT[$bits(ox)-1:0] - 1'b1);
    wire         lb_next_active = (oy == OUT_VTOT[$bits(oy)-1:0] - 1'b1) ||
                                  (oy + 1'b1 < OUT_VACT[$bits(oy)-1:0]);
    always_ff @(posedge clk_out) begin
        if (rst_out) begin
            lb_last_req_y <= 12'hFFF; lb_ready_y <= 12'hFFF; lb_show_y <= 12'hFFF;
            lb_fill <= 1'b1; lb_show <= 1'b0;
            lb_inflight <= 1'b0; lb_complete <= 1'b0;
            lb_new_frame_pending <= 1'b1;
            lb_line_req <= 1'b0; lb_frame_start <= 1'b0;
            lb_line_num <= '0; lb_buf_sel <= 1'b0;
            dbg_lines_late <= '0;
        end else begin
            lb_line_req <= 1'b0;
            lb_frame_start <= 1'b0;

            if (!FB_DDR || use_bypass) begin
                // Native mode must generate no CRT read traffic. Re-arm the
                // first request so enabling PVM mode starts from a fresh frame.
                lb_last_req_y <= 12'hFFF;
                lb_ready_y <= 12'hFFF;
                lb_show_y <= 12'hFFF;
                lb_inflight <= 1'b0;
                lb_complete <= 1'b0;
                lb_new_frame_pending <= 1'b1;
            end else begin
                // The first source line of the next output frame is fetched
                // through the whole vertical blank and marks the DDR reader's
                // frame-buffer publication boundary.
                if (lb_enter_vblank) lb_new_frame_pending <= 1'b1;

                if (lb_line_ready && lb_inflight) begin
                    lb_inflight <= 1'b0;
                    lb_complete <= 1'b1;
                    lb_ready_y  <= lb_last_req_y;
                end

                // Promote a completed fill only at a line boundary. A fill
                // that misses its deadline can therefore repeat one complete
                // old line, but can never switch buffers halfway across it.
                if (lb_line_boundary) begin
                    if ((lb_complete && (lb_ready_y == src_y)) ||
                        (lb_line_ready && lb_inflight && (lb_last_req_y == src_y))) begin
                        lb_show <= lb_fill;
                        lb_show_y <= src_y;
                        lb_complete <= 1'b0;
                        lb_inflight <= 1'b0;
                    end else if (lb_next_active && (lb_show_y != src_y)) begin
                        dbg_lines_late <= dbg_lines_late + 16'd1;
                    end
                end

                // If an old request returned after its line was already
                // skipped, discard it and immediately chase the current line.
                if (lb_complete && (lb_ready_y != src_y))
                    lb_complete <= 1'b0;

                if (!lb_inflight && !lb_complete &&
                    (lb_new_frame_pending || (src_y != lb_last_req_y))) begin
                    lb_fill       <= ~lb_show;
                    lb_buf_sel    <= ~lb_show;
                    lb_line_num   <= src_y;
                    lb_line_req   <= 1'b1;
                    lb_frame_start<= lb_new_frame_pending;
                    lb_last_req_y <= src_y;
                    lb_inflight   <= 1'b1;
                    lb_new_frame_pending <= 1'b0;
                end
            end
        end
    end
    assign lb_rd_x   = src_x;
    assign lb_rd_buf = lb_show;

    wire [AW+BUFW-1:0] wr_full = (BUFFERS > 1) ? {wbuf, wr_addr} : wr_addr;



    // ======================================================================
    // READ SIDE — display domain. Free-running standard timing, completely
    // independent of the core. Never waits for the writer.
    // ======================================================================
    localparam int OUT_HTOT = OUT_HACT + OUT_HFP + OUT_HSYNC + OUT_HBP;
    localparam int OUT_VTOT = OUT_VACT + OUT_VFP + OUT_VSYNC + OUT_VBP;

    logic [$clog2(OUT_HTOT)-1:0] ox;
    logic [$clog2(OUT_VTOT)-1:0] oy;
    logic                        rbuf;

    // Writer's frame-done pulse, brought into the read domain with a 2-FF
    // synchroniser on a toggle (a pulse cannot survive a domain crossing).
    logic wtog;
    always_ff @(posedge clk_in) if (rst_in) wtog <= 1'b0; else if (wframe_done) wtog <= ~wtog;
    logic wtog_s0, wtog_s1, wtog_s2;
    always_ff @(posedge clk_out) begin
        wtog_s0 <= wtog; wtog_s1 <= wtog_s0; wtog_s2 <= wtog_s1;
    end
    wire new_frame_ready = wtog_s1 ^ wtog_s2;
    logic frame_pending;

    wire in_vblank = (oy >= OUT_VACT[$bits(oy)-1:0]);
    wire out_de    = (ox < OUT_HACT[$bits(ox)-1:0]) && (oy < OUT_VACT[$bits(oy)-1:0]);

    always_ff @(posedge clk_out) begin
        if (rst_out) begin
            ox <= '0;
            // DDR mode powers up in vertical blank, giving the first line
            // request a full blanking interval before frame 0 becomes active.
            oy <= FB_DDR ? OUT_VACT[$bits(oy)-1:0] : '0;
            rbuf <= 1'b1; frame_pending <= 1'b0;
            dbg_frames_shown <= '0; dbg_frames_repeated <= '0; dbg_frames_dropped <= '0;
        end else begin
            // Latch that a new frame exists. If a second arrives before we
            // consumed the first, the older one is DROPPED -- counted, not
            // hidden, because a silently dropped frame looks like judder of
            // unknown origin when someone debugs this later.
            if (new_frame_ready) begin
                if (frame_pending) dbg_frames_dropped <= dbg_frames_dropped + 1'b1;
                frame_pending <= 1'b1;
            end

            if (ce_out) begin
                if (ox == OUT_HTOT[$bits(ox)-1:0] - 1) begin
                    ox <= '0;
                    if (oy == OUT_VTOT[$bits(oy)-1:0] - 1) begin
                        oy <= '0;
                        // Swap at the frame boundary only, and only if the
                        // writer has actually finished one: never show a torn
                        // frame, and never stall waiting for one either.
                        if (BUFFERS > 1) begin
                            if (frame_pending) begin
                                rbuf <= ~rbuf;
                                frame_pending <= 1'b0;
                                dbg_frames_shown <= dbg_frames_shown + 1'b1;
                            end else begin
                                // Output is faster than the core: re-show the
                                // same buffer. THIS IS THE JUDDER, and it is
                                // the designed trade, not a fault.
                                dbg_frames_repeated <= dbg_frames_repeated + 1'b1;
                            end
                        end else begin
                            frame_pending <= 1'b0;
                            dbg_frames_shown <= dbg_frames_shown + 1'b1;
                        end
                    end else begin
                        oy <= oy + 1'b1;
                    end
                end else begin
                    ox <= ox + 1'b1;
                end
            end
        end
    end

    // ======================================================================
    // GEOMETRY: integer scale + crop + nudge.
    //
    // Source pixel for output pixel ox is
    //     src_x = crop_x + (ox - pos_h) / scale_h
    // but the division is never performed: a phase counter advances src_x once
    // every scale_h output pixels, which is exact, cheap, and is precisely what
    // "pixel replication" means. Same for lines. NOTHING IS BLENDED.
    //
    // WHEN THE SOURCE IS TOO BIG FOR THE DISPLAY (Wolf: 254 active lines will
    // not fit a 262.5-line 59.94 Hz frame with room to retrace) the excess is
    // simply not addressed -- src_x/src_y stop advancing past the stored
    // extent and those output pixels read black. Combined with crop_x/crop_y
    // the user chooses WHICH WINDOW of an oversized picture is shown, and with
    // pos_h/pos_v they centre it. That is a crop with aim, not a squeeze.
    wire [2:0] sh = (scale_h == 3'd0) ? 3'd1 : scale_h;
    wire [2:0] sv = (scale_v == 3'd0) ? 3'd1 : scale_v;

    // Output position relative to where the image starts, after the nudge.
    wire signed [12:0] rel_x = $signed({1'b0, ox}) - pos_h;
    wire signed [12:0] rel_y = $signed({1'b0, oy}) - pos_v;
    wire               x_before = (rel_x < 0);
    wire               y_before = (rel_y < 0);

    logic [11:0] src_x, src_y;
    logic [2:0]  ph_x, ph_y;
    logic        x_past, y_past;      // ran off the end of the stored image

    always_ff @(posedge clk_out) begin
        if (rst_out) begin
            src_x <= '0;
            src_y <= FB_DDR ? crop_y : 12'd0;
            ph_x <= 3'd0; ph_y <= 3'd0;
            x_past <= 1'b0; y_past <= 1'b0;
        end else if (ce_out) begin
            // ---- horizontal: restart every line ----------------------------
            if (ox == OUT_HTOT[$bits(ox)-1:0] - 1) begin
                src_x  <= crop_x;
                ph_x   <= 3'd0;
                x_past <= 1'b0;
            end else if (!x_before) begin
                if (ph_x == sh - 3'd1) begin
                    ph_x <= 3'd0;
                    if (src_x + 12'd1 >= {4'd0, meas_hact}) x_past <= 1'b1;
                    else                                    src_x <= src_x + 12'd1;
                end else begin
                    ph_x <= ph_x + 3'd1;
                end
            end

            // ---- vertical: choose the NEXT source line at the start of
            // horizontal blank. DDR then has the complete blanking interval to
            // fetch it before the following active line begins.
            if ((ox == OUT_HACT[$bits(ox)-1:0] - 1) &&
                (oy == OUT_VACT[$bits(oy)-1:0] - 1)) begin
                src_y  <= crop_y;
                ph_y   <= 3'd0;
                y_past <= 1'b0;
            end else if ((ox == OUT_HACT[$bits(ox)-1:0] - 1) &&
                         (oy < OUT_VACT[$bits(oy)-1:0] - 1'b1) && !y_before) begin
                if (ph_y == sv - 3'd1) begin
                    ph_y <= 3'd0;
                    if (src_y + 12'd1 >= {4'd0, meas_vact}) y_past <= 1'b1;
                    else                                    src_y <= src_y + 12'd1;
                end else begin
                    ph_y <= ph_y + 3'd1;
                end
            end
        end
    end

    // A pixel is drawn only where the scaled, nudged, cropped image actually
    // lands. Everywhere else is black -- pillarbox/letterbox, not stretch.
    wire in_image = !x_before && !y_before && !x_past && !y_past;

    wire [AW-1:0]      rd_addr = src_y * meas_hact + src_x;
    wire [AW+BUFW-1:0] rd_full = (BUFFERS > 1) ? {~rbuf, rd_addr} : rd_addr;

    generate if (!FB_DDR) begin : g_fb_onchip
        (* ramstyle = "M10K" *) logic [PIXW-1:0] fb [0:(HACT*VACT*BUFFERS)-1];
        always_ff @(posedge clk_in)  if (wr_en) fb[wr_full] <= wr_data;
        always_ff @(posedge clk_out)             rd_q       <= fb[rd_full];
    end else begin : g_fb_ddr
        // frame lives in DDR3; rd_q is unused, pixels come from lb_rd_data
        always_ff @(posedge clk_out) rd_q <= '0;
    end endgenerate

    logic in_image_q;
    always_ff @(posedge clk_out) in_image_q <= in_image; // matches RAM latency

    // ======================================================================
    // OUTPUT MUX — retimed or native passthrough
    // ======================================================================
    // TIMING MUST BE DELAYED TO MATCH THE RAM, NOT THE OTHER WAY ROUND.
    // fb[] has 1 clk of read latency, so rd_q describes the address presented
    // on the PREVIOUS cycle. Driving de/hs/vs combinationally from the CURRENT
    // ox/oy therefore puts the picture one pixel out of step with its own sync
    // -- the image shifts and the last column is wrong. Registering the timing
    // through one stage realigns them. (Caught by the geometry gate: at 2x,
    // source column 7 was landing at output 14,15 as "6,7" instead of "7,7".)
    logic out_de_q, in_vblank_q, hs_raw_q, vs_raw_q;
    wire  hs_raw = ((ox >= (OUT_HACT + OUT_HFP)) &&
                    (ox <  (OUT_HACT + OUT_HFP + OUT_HSYNC))) ? OUT_HS_POL : ~OUT_HS_POL;
    wire  vs_raw = ((oy >= (OUT_VACT + OUT_VFP)) &&
                    (oy <  (OUT_VACT + OUT_VFP + OUT_VSYNC))) ? OUT_VS_POL : ~OUT_VS_POL;
    always_ff @(posedge clk_out) begin
        out_de_q    <= out_de;
        in_vblank_q <= in_vblank;
        hs_raw_q    <= hs_raw;
        vs_raw_q    <= vs_raw;
    end

    always_comb begin
        if (use_bypass) begin
            r_out  = r_in;  g_out = g_in;  b_out = b_in;
            de_out = de_in; hs_out = hs_in; vs_out = vs_in;
            hb_out = ~de_in; vb_out = 1'b0;
        end else begin
            // FB_DDR sources from the line buffer (16 bits stored, RGB444 in
            // the low 12); otherwise from the on-chip frame array.
            {r_out, g_out, b_out} = (out_de_q && in_image_q)
                                    ? (FB_DDR ? lb_rd_data[PIXW-1:0] : rd_q)
                                    : {PIXW{1'b0}};
            de_out = out_de_q;
            hb_out = ~out_de_q;
            vb_out = in_vblank_q;
            hs_out = hs_raw_q;
            vs_out = vs_raw_q;
        end
    end

endmodule

`default_nettype wire
