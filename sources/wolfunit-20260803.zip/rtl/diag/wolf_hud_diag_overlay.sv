// wolf_hud_diag_overlay.sv -- cabinet instrument for the MK3/UMK3 HUD flash.
//
// OBSERVATION ONLY. It never changes DMA requests, framebuffer writes, page
// publication, scanout addresses, or audio; it only paints a hex panel over the
// finished video.
//
// Why this exists: the read side is now measured clean and can be excluded.
//   * static scanout: real wolf_video vs MAME golden RGB = 89,600 px, 0 bad
//     (sim/tb_wolf_hud_golden.sv), mutation-proven.
//   * scanout starvation: blocking the scan channel for 3600 of every 5060 clks
//     (71% of a line) still yields 0 bad pixels; cliff at 3800
//     (sim/tb_wolf_hud_starve.sv).  yunit_sdram_arb.sv:103 already ranks scanout
//     above CPU and blitter, so that regime is unreachable.
// What remains is the WRITE side: blit traffic landing in the page that is
// currently being scanned out.  This panel measures exactly that on silicon,
// because sim holds wr_busy/blit_busy at 0 and cannot see it.
//
// Panel rows (3 hex digits each, top-left, over the live game):
//   row0 YELLOW  VPW = writes into the VISIBLE page's HUD rows WHILE the raster
//                      is inside the HUD band          <- the smoking gun
//   row1 CYAN    VPF = writes into the VISIBLE page's HUD rows anywhere in frame
//   row2 GREEN   HWR = writes into EITHER page's HUD rows this frame
//                      (instrument-alive control: must be nonzero in a fight)
//   row3 WHITE   TWR = total framebuffer writes this frame, >>8 (load context)
//
// Reading it on the cab: if VPW stays 0 while the bars flash, the flash is NOT
// visible-page repaint and the write side is excluded too.  If VPW is nonzero
// and tracks the flashing characters, that is the mechanism, measured.
// HWR is the control that proves the counters are live -- a panel of zeros with
// HWR==0 means the instrument is broken, not that the core is clean.
//
// Counters are per-frame: accumulated during the frame, latched at vblank rise,
// and the LATCHED values are displayed (so the panel is stable and readable).
// They saturate at 0xFFF rather than wrapping, so a large count reads as "many"
// instead of aliasing to a small number.

`default_nettype none
module wolf_hud_diag_overlay #(
  parameter int HUD_ROWS = 32,       // HUD band height in display lines
  parameter int FB_ADDR_W = 19
)(
  input  logic        clk, ce_pix, rst,

  // finished game video (passthrough underneath the panel)
  input  logic [7:0]  g_r, g_g, g_b,
  input  logic        g_hs, g_vs, g_hb, g_vb, g_de,

  // blitter framebuffer write taps (wolf_memsys dbg_fb_*)
  input  logic        fb_we,
  input  logic        fb_ack,
  input  logic [18:0] fb_addr,       // VRAM entry index: {row[8:0], col[8:0]}

  // page currently committed to scanout (wolf_video_top active_row0_diag)
  input  logic [FB_ADDR_W-1:0] active_row0,

  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de
);
  // ---- 3x5 hex font (shared shape with wolf_diag_geom_overlay) --------------
  function automatic [14:0] glyph(input [3:0] v);
    case (v)
      4'h0: glyph=15'b111_101_101_101_111;  4'h1: glyph=15'b010_110_010_010_111;
      4'h2: glyph=15'b111_001_111_100_111;  4'h3: glyph=15'b111_001_111_001_111;
      4'h4: glyph=15'b101_101_111_001_001;  4'h5: glyph=15'b111_100_111_001_111;
      4'h6: glyph=15'b111_100_111_101_111;  4'h7: glyph=15'b111_001_001_010_010;
      4'h8: glyph=15'b111_101_111_101_111;  4'h9: glyph=15'b111_101_111_001_111;
      4'hA: glyph=15'b111_101_111_101_101;  4'hB: glyph=15'b110_101_110_101_110;
      4'hC: glyph=15'b111_100_100_100_111;  4'hD: glyph=15'b110_101_101_101_110;
      4'hE: glyph=15'b111_100_111_100_111;  default: glyph=15'b111_100_111_100_100;
    endcase
  endfunction
  function automatic logic fpix(input [3:0] d, input [1:0] col, input [2:0] row);
    logic [14:0] g; logic [2:0] rb; g=glyph(d);
    case (row) 3'd0:rb=g[14:12]; 3'd1:rb=g[11:9]; 3'd2:rb=g[8:6];
               3'd3:rb=g[5:3];   default:rb=g[2:0]; endcase
    fpix = (col==2'd0)?rb[2] : (col==2'd1)?rb[1] : rb[0];
  endfunction

  // ---- raster tracking (active-space column/line), same shape as geom overlay
  logic [11:0] gx, gy;
  logic de_q, vb_q;
  wire  vb_rise = g_vb & ~vb_q;

  // ---- write classification -------------------------------------------------
  // fb_addr is a VRAM entry index; VRAM rows are 512 entries (row<<9 | col).
  wire [8:0] wr_row = fb_addr[17:9];
  // Distance from the committed display base, wrapped into the 512-row space:
  // a write is in the VISIBLE page's HUD band when that distance is < HUD_ROWS.
  wire [8:0] vis_off = wr_row - active_row0[8:0];
  wire       wr_fire = fb_we && fb_ack;
  wire       in_vis_hud = (vis_off < HUD_ROWS[8:0]);
  // Either page: the same row offset within whichever 256-row page it lands in.
  wire [7:0] pg_off = wr_row[7:0];
  wire       in_any_hud = (pg_off < HUD_ROWS[7:0]);
  // Raster currently inside the HUD band (and in active video).
  wire       raster_in_hud = g_de && (gy < HUD_ROWS[11:0]);

  logic [11:0] a_vpw, a_vpf, a_hwr;
  logic [19:0] a_twr;
  logic [11:0] m_vpw, m_vpf, m_hwr, m_twr;

  // PIPELINE the write classification.  Doing the 9-bit subtract, the two range
  // compares and the saturating increments in one clk cost -0.847 ns on clk_sys
  // (96 MHz) and failed the timing gate -- an instrument must not perturb the
  // core it is measuring.  Registering the decision first costs one clock of
  // latency, which is irrelevant for counters that are only read once per frame.
  logic q_fire, q_vis, q_any, q_rast;
  always_ff @(posedge clk) begin
    if (rst) begin
      q_fire<=1'b0; q_vis<=1'b0; q_any<=1'b0; q_rast<=1'b0;
    end else begin
      q_fire <= wr_fire;
      q_vis  <= in_vis_hud;
      q_any  <= in_any_hud;
      q_rast <= raster_in_hud;
    end
  end
  // Saturation as a single flag compare rather than a full 12-bit !=.
  wire sat_vpw = &a_vpw;
  wire sat_vpf = &a_vpf;
  wire sat_hwr = &a_hwr;
  wire sat_twr = &a_twr;

  always_ff @(posedge clk) begin
    if (rst) begin
      gx<=0; gy<=0; de_q<=0; vb_q<=0;
      a_vpw<=0; a_vpf<=0; a_hwr<=0; a_twr<=0;
      m_vpw<=0; m_vpf<=0; m_hwr<=0; m_twr<=0;
    end else begin
      // Write events are on the system clock, NOT ce_pix -- count them every
      // clock or the instrument silently undercounts by the clock ratio.
      if (q_fire) begin
        if (!sat_twr) a_twr <= a_twr + 20'd1;
        if (q_any && !sat_hwr) a_hwr <= a_hwr + 12'd1;
        if (q_vis) begin
          if (!sat_vpf) a_vpf <= a_vpf + 12'd1;
          if (q_rast && !sat_vpw) a_vpw <= a_vpw + 12'd1;
        end
      end

      if (ce_pix) begin
        de_q <= g_de; vb_q <= g_vb;
        if (g_de) gx <= gx + 12'd1;
        if (de_q && !g_de) begin gx <= 12'd0; gy <= gy + 12'd1; end
        if (vb_rise) begin
          // latch + restart the per-frame accumulation
          m_vpw <= a_vpw; m_vpf <= a_vpf; m_hwr <= a_hwr;
          m_twr <= a_twr[19:8];
          a_vpw <= 12'd0; a_vpf <= 12'd0; a_hwr <= 12'd0; a_twr <= 20'd0;
          gx <= 12'd0; gy <= 12'd0;
        end
      end
    end
  end

  // ---- hex panel (top-left): 4 rows x 3 digits, 4x-scaled 3x5 font ----------
  localparam int PX=6, PY=6;
  wire in_box = (gx>=PX) && (gx<PX+48) && (gy>=PY) && (gy<PY+4*28);
  wire [11:0] lx = gx - PX[11:0];
  wire [11:0] ly = gy - PY[11:0];
  wire [1:0]  digit = lx[5:4];
  wire [3:0]  dx    = lx[3:0];
  logic [11:0] rowval; logic [2:0] rowsel; logic in_rowband; logic [11:0] rytop;
  always_comb begin
    in_rowband=1'b0; rowsel=3'd0; rytop=12'd0; rowval=12'd0;
    if      (ly<12'd20)                begin in_rowband=1; rowsel=0; rytop=12'd0;  rowval=m_vpw; end
    else if (ly>=12'd28 && ly<12'd48)  begin in_rowband=1; rowsel=1; rytop=12'd28; rowval=m_vpf; end
    else if (ly>=12'd56 && ly<12'd76)  begin in_rowband=1; rowsel=2; rytop=12'd56; rowval=m_hwr; end
    else if (ly>=12'd84 && ly<12'd104) begin in_rowband=1; rowsel=3; rytop=12'd84; rowval=m_twr; end
  end
  wire [11:0] ry   = ly - rytop;
  wire [2:0]  frow = ry[4:2];
  wire [1:0]  fcol = dx[3:2];
  wire [3:0]  nyb  = rowval >> ({1'b0,(2'd2-digit)}<<2);
  wire        glyph_on = in_box && in_rowband && (digit<2'd3) && (dx<4'd12)
                         && (frow<3'd5) && fpix(nyb, fcol, frow);
  logic [23:0] rowcol;
  always_comb case (rowsel)
    3'd0: rowcol=24'hFFFF00;   // VPW yellow
    3'd1: rowcol=24'h00FFFF;   // VPF cyan
    3'd2: rowcol=24'h00FF00;   // HWR green
    default: rowcol=24'hFFFFFF;// TWR white
  endcase

  // PIPELINE the panel render as well.  in_box compares -> row-band selector ->
  // barrel shift (rowval >> ...) -> fpix() glyph lookup -> output mux is a long
  // combinational chain at 96 MHz, and the baseline master build closes with NO
  // negative slack, so the -0.847 ns regression is this instrument's to fix.
  // The whole bundle (video AND syncs) is delayed by one ce_pix together, so
  // de/hs/vs/hb/vb stay mutually aligned -- downstream sees a uniform one-pixel
  // shift, which is cosmetically irrelevant for a diagnostic.
  logic [7:0] s1_r, s1_g, s1_b;
  logic       s1_de, s1_hs, s1_vs, s1_hb, s1_vb;
  logic       s1_inbox, s1_glyph;
  logic [23:0] s1_col;
  always_ff @(posedge clk) begin
    if (rst) begin
      s1_de<=0; s1_hs<=0; s1_vs<=0; s1_hb<=0; s1_vb<=0;
      s1_r<=0; s1_g<=0; s1_b<=0; s1_inbox<=0; s1_glyph<=0; s1_col<=0;
    end else if (ce_pix) begin
      s1_de<=g_de; s1_hs<=g_hs; s1_vs<=g_vs; s1_hb<=g_hb; s1_vb<=g_vb;
      s1_r<=g_r;   s1_g<=g_g;   s1_b<=g_b;
      s1_inbox<=in_box; s1_glyph<=glyph_on; s1_col<=rowcol;
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      de<=0; hsync<=0; vsync<=0; hblank<=0; vblank<=0;
      vid_r<=0; vid_g<=0; vid_b<=0;
    end else if (ce_pix) begin
      de<=s1_de; hsync<=s1_hs; vsync<=s1_vs; hblank<=s1_hb; vblank<=s1_vb;
      if (!s1_de) begin
        vid_r<=8'h00; vid_g<=8'h00; vid_b<=8'h00;
      end else if (s1_inbox) begin
        if (s1_glyph) begin vid_r<=s1_col[23:16]; vid_g<=s1_col[15:8]; vid_b<=s1_col[7:0]; end
        else          begin vid_r<=8'h00; vid_g<=8'h00; vid_b<=8'h30; end
      end else begin
        vid_r<=s1_r; vid_g<=s1_g; vid_b<=s1_b;
      end
    end
  end
endmodule
`default_nettype wire
