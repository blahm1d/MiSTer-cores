#!/usr/bin/env bash
# Quartus-free release gates for the seven-title Wolf Unit master image.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

bash "$ROOT/sim/run_wolf_game_profiles.sh"
bash "$ROOT/sim/run_wolf_nvram.sh"
bash "$ROOT/sim/run_wolf_dcs_board.sh"
bash "$ROOT/sim/run_wolf_dcs_host_reset_fade.sh"
bash "$ROOT/sim/run_wolf_dcs_online_pop.sh"
python "$ROOT/tools/wolf_crt_adjust_gate.py"
bash "$ROOT/sim/run_wolf_crt_adjust.sh"
bash "$ROOT/sim/run_wolf_pic.sh"
bash "$ROOT/sim/run_wolf_srt2_contract.sh"
bash "$ROOT/sim/run_wolf_srt_dma_order.sh"
bash "$ROOT/sim/run_wolf_dma_matrix.sh"
bash "$ROOT/sim/run_wolf_gfx_ddr_roundtrip.sh"
bash "$ROOT/sim/run_wolf_motaro_cache_deadline.sh"
# Video/page-flip path. NOTE: before this was added, NO release gate compiled
# wolf_video at all -- the scanout and page-flip logic shipped unprotected, which
# is how the MK3/UMK3 HUD flash (flip missing its blanking commit window on heavy
# scenes) could regress silently. Self-contained, ~22 s, and asserts BOTH that
# production commits at 33 scanlines of drain AND that it still misses at 35, so
# it cannot pass by the flip being made unconditional.
bash "$ROOT/sim/run_wolf_flip_late_gate.sh"
bash "$ROOT/sim/run_wolf_gfxdl_e2e.sh"
bash "$ROOT/sim/run_wolf_gfxdl_full.sh"
bash "$ROOT/sim/run_ase_wolf_profile_boots.sh"
bash "$ROOT/sim/run_ase_rwt_boot.sh"

echo "PASS: Wolf Unit release gates"
