#!/usr/bin/env bash
# WOLF_MASTER release with a fitter seed override, applied SAFELY.
#
# WHY: the master release at cf2315f failed the timing gate at -0.038 ns on
# pll_hdmi|...|divclk (TNS -0.254) -- the shared sys/ ascal-HDMI cone. The core
# clock (emu|pll) was clean at +0.841, so the RTL change (FLIP_PREFETCH_LINES
# 4->1, entirely inside wolf_video) is timing-neutral in its own domain. That
# cone moves with ANY placement perturbation regardless of what changed; prior
# master builds closed at SEED 4 by luck of placement, not by margin. The same
# cone failed the DIAG_HUD build at -0.070 and closed on a reseed 4 -> 3.
#
# HOW, and why not `quartus_fit --seed=N`: the T-unit session MEASURED that the
# command-line seed is PERSISTED back into the .qsf (SEED 10 -> SEED 3). The
# project file then stops hashing to what preflight recorded, and every artifact
# built from it -- including images an earlier build produced that the seeded
# fit never touched -- fails its provenance check. So: snapshot the QSF, edit
# the existing SEED assignment in place, and restore unconditionally on exit.
#
# This wrapper deliberately does NOT modify quartus/build_wolfunit.sh. That
# script stays the canonical release path; the seed is a property of this
# attempt, not of the release definition. Record the seed used in the release
# notes for the image that ships.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

WOLF_SEED="${WOLF_SEED:-3}"
QSF="$ROOT/Arcade-SmashTV.qsf"
QSF_BAK="$(mktemp "${TMPDIR:-/tmp}/wolfmaster_qsf.XXXXXX")"
cp -p "$QSF" "$QSF_BAK"
restore_qsf() {
  cp -p "$QSF_BAK" "$QSF"
  rm -f "$QSF_BAK"
  if [ -n "$(cd "$ROOT" && git status --porcelain -- Arcade-SmashTV.qsf)" ]; then
    echo "WARNING: QSF did not restore cleanly -- check before any further build" >&2
  fi
}
trap restore_qsf EXIT INT TERM

OLD_SEED="$(sed -n 's/^set_global_assignment -name SEED \([0-9]*\).*/\1/p' "$QSF" | head -1)"
sed -i "s/^set_global_assignment -name SEED .*/set_global_assignment -name SEED $WOLF_SEED/" "$QSF"
echo "fitter seed: $OLD_SEED -> $WOLF_SEED (QSF restored on exit)"

bash "$ROOT/quartus/build_wolfunit.sh"
