#!/usr/bin/env bash
# Canonical one-RBF Midway Wolf Unit master build.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUTNAME="Arcade-WolfUnit-CRT-Adjust"
PACKAGE="$ROOT/releases/WolfUnit-Master"
export PRODUCTION_RELEASE=wolf-master

# A release build must not inherit a diagnostic overlay or a per-game macro.
unset SV2V_EXTRA

bash "$ROOT/quartus/run_wolfunit_release_gates.sh"

bash "$ROOT/quartus/build_hw.sh" \
  WOLF_MASTER=1,CRT_ADJUST=1,USE_DDR3_GFX=1,USE_DDR3_VRAM=1 \
  "$OUTNAME"

mkdir -p "$PACKAGE"
cp -f "$ROOT/releases/$OUTNAME.rbf" "$PACKAGE/$OUTNAME.rbf"
echo "Wolf Unit master package: $PACKAGE"
