#!/usr/bin/env bash
# Split-lock Wolf build runner: run the ~30-min release-gate suite UNLOCKED
# (it needs only the Questa node-lock, NOT the Quartus box), and take the
# shared Quartus lock ONLY for map/fit/sta/asm. This stops a build from
# holding the fitter idle-but-locked for half an hour of ASE sims while other
# sessions wait to fit.
#
# Usage: wolf_split_build.sh <TAG>
set -u
TAG="${1:-wolf:split-build}"
ROOT=/d/deck/fpga/wolf-crt
Q=/tmp/fpga_quartus.queue
LOCK=/tmp/fpga_quartus.lock
OUTNAME="Arcade-WolfUnit-CRT-Adjust"
PACKAGE="$ROOT/releases/WolfUnit-Master"
MACROS="WOLF_MASTER=1,CRT_ADJUST=1,USE_DDR3_GFX=1,USE_DDR3_VRAM=1"
GATELOG=/tmp/${TAG//[:\/]/_}_gates.log
BUILDLOG=/tmp/${TAG//[:\/]/_}_quartus.log

cd "$ROOT" || exit 2
export PATH="/c/iverilog/bin:$PATH"
unset SV2V_EXTRA

# ---- Phase 1: GATES, NO Quartus lock (Questa node-lock is taken internally) --
"$Q/_notify.sh" note "$TAG" "running release gates UNLOCKED (Quartus box free for others)" || true
if ! bash quartus/run_wolfunit_release_gates.sh > "$GATELOG" 2>&1; then
  "$Q/_notify.sh" note "$TAG" "GATES FAILED (see $GATELOG) -- no Quartus slot taken" || true
  echo "GATES FAILED"; tail -5 "$GATELOG"; exit 1
fi
"$Q/_notify.sh" note "$TAG" "gates GREEN; now queueing for the Quartus box" || true

# ---- Phase 2: acquire the Quartus lock ONLY for the fit ----------------------
"$Q/_notify.sh" enqueue "$TAG" $$ || true
release() {
  if [ -d "$LOCK" ] && grep -q "$TAG" "$LOCK/owner" 2>/dev/null; then
    rm -rf "$LOCK"; "$Q/_notify.sh" release "$TAG" "${1:-}" || true
  fi
  "$Q/_notify.sh" dequeue "$TAG" || true
}
trap 'release' EXIT
while :; do
  if "$Q/_notify.sh" myturn "$TAG" >/dev/null 2>&1; then
    "$Q/_notify.sh" holds "$TAG" >/dev/null 2>&1 || { "$Q/_notify.sh" enqueue "$TAG" $$ || true; sleep 5; continue; }
    if [ ! -d "$LOCK" ] && ! tasklist 2>/dev/null | grep -qiE '^quartus_(map|fit|sta|asm|sh|cdb)'; then
      if mkdir "$LOCK" 2>/dev/null; then
        { echo "$$"; echo "session=$TAG"; echo "started=$(date -Is)"; echo "cmd=build_hw.sh (Quartus-only, gates already green)"; } > "$LOCK/owner"
        "$Q/_notify.sh" acquire "$TAG" || true
        break
      fi
    fi
  fi
  sleep 20
done

# Quartus only -- gates already passed above, so build_hw does map/fit/sta/asm.
bash quartus/build_hw.sh "$MACROS" "$OUTNAME" > "$BUILDLOG" 2>&1
RC=$?
if [ "$RC" -eq 0 ]; then
  mkdir -p "$PACKAGE"; cp -f "$ROOT/releases/$OUTNAME.rbf" "$PACKAGE/$OUTNAME.rbf"
fi
"$Q/_notify.sh" note "$TAG" "build_hw exit=$RC (log $BUILDLOG)" || true
release "$RC"
exit "$RC"
