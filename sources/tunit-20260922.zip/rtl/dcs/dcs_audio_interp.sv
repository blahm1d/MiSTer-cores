// ---------------------------------------------------------------------------
// DCS output reconstruction (MK2 "crunchy audio").
//
// The ADSP-2105 presents one sample per 31.25 kHz DAC slot (adsp2105.sv:2509
// registers dac_sample only on dac_ce_in; midway/dcs.cpp:2028 external-clock
// sample_period = 1/31250 s).  sys/audio_out.v:45,128 then samples that HELD
// value at a FIXED 48 kHz sample_ce -- there is no sample-rate converter, only
// an IIR low-pass applied AFTER sampling.
//
// A raw zero-order hold resampled at 48000/31250 = 1.536 measures -17.0 dB
// error-to-signal against an ideal band-limited resample, with 75% of the
// error energy below 6 kHz.  That part is IN-BAND, so the downstream IIR
// cannot remove it -- it must be fixed at the source.  Linear interpolation
// measures -35.0 dB on the same track: +18.0 dB.
//
// This is the same defect class already cured on the OKI path by
// jt6295 INTERPOL(1) (tunit_adpcm_board.sv:444, "which is what 'crunchy
// samples' is").  DCS was the last output path with no reconstruction stage,
// which is why only MK2 is affected.
//
// Self-calibrating: the sample interval is MEASURED in clk cycles rather than
// derived from a clk_sys parameter, so there is no constant to get wrong if
// the clock changes.  STEPS is a power of two, so both the amplitude step
// (delta >>> STEPS_LOG2) and the sub-step period (period >> STEPS_LOG2) are
// shifts -- no divider and no DSP block is consumed.
//
// Costs one sample period (32 us) of latency: the ramp walks toward the newly
// arrived sample.  Inaudible, and irrelevant to any gate.
// ---------------------------------------------------------------------------
module dcs_audio_interp #(
    parameter int STEPS_LOG2 = 4            // 16 sub-steps -> 500 kHz
)(
    input  wire               clk,
    input  wire               rst,
    input  wire signed [15:0] sample_in,
    input  wire               sample_ce,    // 31.25 kHz DAC slot strobe
    output wire signed [15:0] audio_out
);
    localparam int STEPS = 1 << STEPS_LOG2;

    reg signed [15:0] s_prev;               // sample we are ramping FROM
    reg signed [15:0] s_next;               // sample we are ramping TO
    reg signed [16:0] step;                 // (s_next - s_prev) / STEPS
    reg signed [21:0] acc;                  // headroom for STEPS accumulations

    reg [15:0] period_cnt, period;          // measured clks between strobes
    reg [15:0] sub_cnt;
    reg [STEPS_LOG2-1:0] step_idx;
    reg        step_done;

    wire [15:0] sub_period = period >> STEPS_LOG2;

    always @(posedge clk) begin
        if (rst) begin
            s_prev <= '0; s_next <= '0; step <= '0; acc <= '0;
            period_cnt <= '0; period <= '0; sub_cnt <= '0;
            step_idx <= '0; step_done <= 1'b1;
        end else begin
            // SATURATE, do not wrap: sample_ce pauses whenever the DCS stops
            // emitting, and a wrapped counter would hand the next ramp a bogus
            // short interval. Saturated, a long gap just yields a slow ramp that
            // the next sample_ce retires onto the correct value.
            if (!(&period_cnt)) period_cnt <= period_cnt + 1'b1;

            if (sample_ce) begin
                // latch the interval, retire the ramp exactly onto s_next so
                // truncation in `step` can never accumulate across samples
                period     <= period_cnt;
                period_cnt <= 16'd0;
                s_prev     <= s_next;
                s_next     <= sample_in;
                acc        <= {{6{s_next[15]}}, s_next};
                step       <= ($signed({sample_in[15], sample_in})
                             - $signed({s_next[15],    s_next})) >>> STEPS_LOG2;
                sub_cnt    <= 16'd0;
                step_idx   <= '0;
                step_done  <= 1'b0;
            end else if (!step_done) begin
                if (sub_cnt >= sub_period) begin
                    sub_cnt <= 16'd0;
                    acc     <= acc + {{5{step[16]}}, step};
                    step_idx <= step_idx + 1'b1;
                    if (&step_idx) step_done <= 1'b1;   // STEPS-1 -> last step
                end else
                    sub_cnt <= sub_cnt + 1'b1;
            end
        end
    end

    // Saturate rather than wrap: truncation in `step` can leave acc a few LSBs
    // outside 16-bit range at the end of a ramp on a full-scale transient.
    //
    // REGISTERED, and that is load-bearing, not stylistic.  sys/audio_out.v
    // samples AUDIO_L/R in ITS OWN clock domain at a fixed 48 kHz sample_ce,
    // asynchronously to this clock.  An async sampler can capture a
    // combinational output MID-SETTLE, so driving these 22-bit comparators
    // straight at AUDIO_L/R makes every glitch capturable as a full-scale
    // transient -- wideband crackle laid over otherwise correct audio.
    // Y-unit hit exactly this with a combinational always_comb mix and cured it
    // with one flop in the source domain; the defect is CAB-CONFIRMED there and
    // RTL sim CANNOT reproduce it, because no async sampler exists in sim.
    // A green gate is therefore not evidence against it -- register uncondi-
    // tionally.
    reg signed [15:0] audio_q;
    always @(posedge clk) begin
        if (rst) audio_q <= 16'sd0;
        else     audio_q <= (acc >  22'sd32767) ?  16'sd32767 :
                            (acc < -22'sd32768) ? -16'sd32768 : acc[15:0];
    end
    assign audio_out = audio_q;
endmodule
