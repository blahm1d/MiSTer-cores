// Line-cached request/response bridge between the 12 MHz Williams ADPCM board
// and the 80 MHz sound-DDR client.  The board holds snd_addr stable until
// snd_ok; toggle handshakes make that bundled-data contract explicit.
//
// WHY A LINE CACHE (2026-08-09).
//
// The previous revision cached exactly ONE byte at ONE address, so every change
// of snd_addr cost a full CDC round trip plus a DDR3 round trip, with the 6809's
// entire E/Q generator frozen for the duration (tunit_adpcm_board.sv:105).  That
// is the worst possible shape of client for the DDR3 port it sits on, where it
// still sits behind the hard-real-time framebuffer requester
// (tunit_ddr3_arb.sv:37-63).
//
// Two measurements drove this change:
//
//  * jt6295 re-presents the SAME byte address on two consecutive visits of a
//    voice (jt6295_serial.v:174,195 -- rom_addr is cnt[18:1] and the nibble
//    select is cnt[0]), and four voices plus the phrase-header stream interleave
//    between those visits.  A single-entry cache is therefore evicted before the
//    second visit every time, so the hardware paid two round trips for every
//    byte it actually needed once.
//  * tunit_sound_ddr_multi.sv:178 ALREADY fetches a full 64-bit DDR3 word for
//    every one of those bytes (agent_addr = adpcm_addr[20:3]) and then discards
//    seven eighths of it at :205.  The line was always being paid for.
//
// So this holds NLINE 8-byte demand lines, filled from the 64-bit word the
// sound-DDR client already reads.  Once the requested line is resident, the
// same one-outstanding bridge fetches the following aligned line in the
// background.  That ports Y-unit's current+next-word runway: the first byte of
// a sequential line is normally a cache hit instead of paying the CDC+DDR
// round trip inside jt6295's hard data slot.  DDR3 traffic per fill is
// unchanged; the number of demand fills drops by up to 8x on sequential sample
// data and by 7x on a phrase header, whose seven bytes (jt6295_ctrl.v:122
// {phrase, addr_lsb}) all land inside one aligned line.
//
// Eight demand lines, not one, because five OKI streams interleave: four ADPCM
// voices and the control-table reader.  Production reserves two associative
// demand lines for the stallable 6809 and searches six recency-ranked OKI lines
// associatively; arbitrary voice addresses therefore cannot evict each other
// merely because [5:3] matches.  Eight separate speculative entries hold each
// stream's next line.
//
// The proven precedent is the Y-unit core, whose cabinet-clean Williams sound
// path proves the separate current/next-word runway policy (not T's 2+6 demand
// partition):
// "Keep the current word and prefetch the following word so sequential 6809/OKI
//  traffic normally completes without stretching the 12 MHz board clock"
// (Arcade-SmashTV_MiSTer rtl/yunit/yunit_sound_rom_cache.sv:1-6).

`default_nettype none
module tunit_adpcm_rom_cdc #(
  // 8 lines x 8 bytes.  One line is exactly one DDR3 beat.
  parameter int NLINE_LG2 = 3
)(
  input  wire logic        clk_snd,
  input  wire logic        clk_sys,
  input  wire logic        rst_pon,
  // System-domain ROM-image epoch fence. This is deliberately separate from
  // the Williams board's FE/FF reset: a board reset must not evict immutable
  // ROM, while a same-RBF loader transaction must evict every preimage line.
  input  wire logic        epoch_reset_sys,

  input  wire logic [20:0] snd_addr,
  output logic [7:0]       snd_data,
  output logic             snd_ok,

  output logic             sys_req,
  output logic [20:0]      sys_addr,
  input  wire logic [63:0] sys_line,
  input  wire logic        sys_ack
);
  localparam int NLINE  = 1 << NLINE_LG2;
  // byte-in-line = [2:0]; [2+NLINE_LG2:3] remains only the focused legacy
  // direct-map mutation's ownership index.
  localparam int IDX_HI = 2 + NLINE_LG2;

`ifdef MUT_TUNIT_ADPCM_CACHE_EPOCH_REVERT
  // Mutation arm: restore the stale-cache failure by ignoring image epochs.
  wire logic cache_reset = rst_pon;
`else
  wire logic cache_reset = rst_pon || epoch_reset_sys;
`endif

  logic [2:0] snd_rst_pipe = 3'b111;
  wire logic snd_rst = snd_rst_pipe[2];

  // BUNDLED-DATA PAYLOADS ARE PRESERVED.  set_clock_groups -asynchronous makes
  // STA ignore this crossing entirely, INCLUDING the skew between payload bits,
  // so the only protection is an explicit set_max_skew -- and that collection
  // silently comes back empty if the fitter merges or duplicates these
  // registers.  A Y-unit RBF shipped with exactly that: sndrom_max_skew rows=0
  // expected=2, constraint skipped, crossing unconstrained on silicon.
  logic req_toggle;
  (* preserve *) logic [20:0] request_addr;
  logic request_pending;
  logic request_is_prefetch;
  logic [NLINE_LG2-1:0] request_prefetch_slot;
  logic [NLINE_LG2-1:0] request_demand_slot;
  (* preserve, async_reg = "true" *) logic [1:0] rsp_sync;
  logic rsp_seen;

  (* preserve, async_reg = "true" *) logic [1:0] req_sync;
  logic req_seen;
  logic rsp_toggle;
  (* preserve *) logic [63:0] response_line;

  logic [63:0]      line_data [0:NLINE-1];
  logic [17:0]      line_tag  [0:NLINE-1];
  logic             line_valid[0:NLINE-1];
  logic [2:0]       line_lru  [0:NLINE-1];
  logic             cpu_replace;
  // Speculation never evicts a resident demand line.  The fully-associative
  // shadow has one slot per demand-cache line: enough for four OKI voices plus
  // the phrase-header stream without direct-map conflict.  A shadow line is
  // promoted only when it becomes the live request, matching Y-unit's separate
  // current/prefetch storage.
  logic [63:0]      prefetch_data [0:NLINE-1];
  logic [17:0]      prefetch_line [0:NLINE-1];
`ifdef MUT_TUNIT_ADPCM_SOURCE_EVICT
  logic [17:0]      prefetch_source_line [0:NLINE-1];
`endif
  logic             prefetch_valid[0:NLINE-1];
  logic [NLINE_LG2-1:0] prefetch_replace;

  wire [NLINE_LG2-1:0] req_idx = snd_addr[IDX_HI:3];
  wire [2:0]           req_off = snd_addr[2:0];
  wire [17:0]          req_line = snd_addr[20:3];
  // Exact external-address partition from tunit_adpcm_board: banked 6809 ROM is
  // below 0x40000; mapped OKI traffic is above it and the populated image ends
  // at 0x13ffff.
  wire snd_is_oki = snd_addr >= 21'h040000;
  wire snd_is_populated_oki = snd_is_oki && (snd_addr < 21'h140000);

  // Y-unit precedent: after serving the current word, use otherwise-idle ROM
  // bandwidth to fetch the immediately following word.  T's physical word is
  // one 64-bit/8-byte DDR3 line, so align the speculative address accordingly.
  // The shadow adds no second transaction or CDC payload.
  wire [17:0] next_line_num = snd_addr[20:3] + 18'd1;
  wire [20:0] next_line_addr = {next_line_num, 3'b000};
  wire [NLINE_LG2-1:0] next_line_idx = next_line_addr[IDX_HI:3];

`ifdef MUT_ADPCM_BYTE_CACHE
  // Preserve the older one-byte mutation's direct placement of returned data.
  wire line_hit = line_valid[req_idx] &&
                  (line_tag[req_idx] == req_line);
  wire [NLINE_LG2-1:0] line_hit_idx = req_idx;
  wire [NLINE_LG2-1:0] demand_alloc_idx = req_idx;
  wire next_line_main_hit = line_valid[next_line_idx] &&
                            (line_tag[next_line_idx] == next_line_num);
`elsif MUT_TUNIT_ADPCM_DIRECT_MAP
  // Focused collision rollback: restore the old [5:3]-owned demand cache while
  // leaving prefetch, CDC, epoch, and request serialization intact.
  wire line_hit = line_valid[req_idx] &&
                  (line_tag[req_idx] == req_line);
  wire [NLINE_LG2-1:0] line_hit_idx = req_idx;
  wire [NLINE_LG2-1:0] demand_alloc_idx = req_idx;
  wire next_line_main_hit = line_valid[next_line_idx] &&
                            (line_tag[next_line_idx] == next_line_num);
`else
  // Production demand partition: slots 0..1 are the stallable 6809; slots 2..7
  // are fully associative OKI/header storage.  First-invalid allocation means
  // the five simultaneous OKI streams fit with one spare boundary slot.  Once
  // full, recency rank evicts the least-recently-hit line, so a dephased voice
  // replaces an abandoned prior line instead of an active interleaved stream.
  logic line_hit;
  logic [NLINE_LG2-1:0] line_hit_idx;
  logic [NLINE_LG2-1:0] demand_alloc_idx;
  logic demand_alloc_found;
  logic [2:0] demand_oldest_rank;
  logic next_line_main_hit;
  integer dhi;
  always_comb begin
    line_hit = 1'b0;
    line_hit_idx = snd_is_oki ? 2 : '0;
    demand_alloc_idx = snd_is_oki ? 2 : cpu_replace;
    demand_alloc_found = 1'b0;
    demand_oldest_rank = 3'd0;
    next_line_main_hit = 1'b0;
    if (!snd_is_oki) begin
      for (dhi = 0; dhi < 2; dhi = dhi + 1) begin
        if (!line_hit && line_valid[dhi] &&
            (line_tag[dhi] == req_line)) begin
          line_hit = 1'b1;
          line_hit_idx = dhi;
        end
        if (!demand_alloc_found && !line_valid[dhi]) begin
          demand_alloc_idx = dhi;
          demand_alloc_found = 1'b1;
        end
      end
    end else begin
      for (dhi = 2; dhi < NLINE; dhi = dhi + 1) begin
        if (!line_hit && line_valid[dhi] &&
            (line_tag[dhi] == req_line)) begin
          line_hit = 1'b1;
          line_hit_idx = dhi;
        end
        if (line_valid[dhi] && (line_tag[dhi] == next_line_num))
          next_line_main_hit = 1'b1;
        if (!demand_alloc_found) begin
          if (!line_valid[dhi]) begin
            demand_alloc_idx = dhi;
            demand_alloc_found = 1'b1;
          end else if (line_lru[dhi] >= demand_oldest_rank) begin
            demand_alloc_idx = dhi;
            demand_oldest_rank = line_lru[dhi];
          end
        end
      end
    end
  end
`endif

  logic prefetch_hit;
  logic [NLINE_LG2-1:0] prefetch_hit_idx;
  integer phi;
  always_comb begin
    prefetch_hit = 1'b0;
    prefetch_hit_idx = '0;
    for (phi = 0; phi < NLINE; phi = phi + 1) begin
      if (!prefetch_hit && prefetch_valid[phi] &&
          (prefetch_line[phi] == req_line)) begin
        prefetch_hit = 1'b1;
        prefetch_hit_idx = phi;
      end
    end
  end

`ifdef MUT_TUNIT_ADPCM_SOURCE_EVICT
  // Focused rejected-policy mutation: assume the predecessor identifies this
  // stream and evict it on promotion.  Two voices can share that source line,
  // so the collision gate must kill this arm while production remains LRU.
  logic [NLINE_LG2-1:0] promotion_alloc_idx;
  logic promotion_source_found;
  integer psi;
  always_comb begin
    promotion_alloc_idx = demand_alloc_idx;
    promotion_source_found = 1'b0;
    if (prefetch_hit && snd_is_oki) begin
      for (psi = 2; psi < NLINE; psi = psi + 1) begin
        if (!promotion_source_found && line_valid[psi] &&
            (line_tag[psi] == prefetch_source_line[prefetch_hit_idx])) begin
          promotion_alloc_idx = psi;
          promotion_source_found = 1'b1;
        end
      end
    end
  end
`else
  // Promotion is an ordinary demand insertion.  In production that means the
  // same invalid-first/LRU choice as a DDR demand fill; do not infer stream
  // identity from a predecessor line that another voice may also be using.
  wire [NLINE_LG2-1:0] promotion_alloc_idx = demand_alloc_idx;
`endif

`ifdef MUT_ADPCM_BYTE_CACHE
  // MUTATION ARM = the shipped behaviour this change replaces: one entry keyed
  // on the exact BYTE address, so any change of snd_addr is a miss.  The gate
  // must show this arm taking many more DDR3 round trips and losing the 6809
  // rate at a latency the production arm survives.  If it does not, the
  // production cache is not doing the work its comment claims.
  logic [20:0] byte_tag;
  logic        byte_valid;
  wire hit = byte_valid && (byte_tag == snd_addr);
  wire use_prefetch_data = 1'b0;
`else
  wire hit = line_hit || prefetch_hit;
  wire use_prefetch_data = !line_hit && prefetch_hit;
`endif

  logic next_line_prefetch_hit;
  logic [NLINE_LG2-1:0] prefetch_alloc_idx;
  logic prefetch_alloc_found;
  integer pfi;
  always_comb begin
    next_line_prefetch_hit = 1'b0;
    prefetch_alloc_idx = prefetch_replace;
    prefetch_alloc_found = 1'b0;
    for (pfi = 0; pfi < NLINE; pfi = pfi + 1) begin
      if (prefetch_valid[pfi] &&
          (prefetch_line[pfi] == next_line_num))
        next_line_prefetch_hit = 1'b1;
      if (!prefetch_alloc_found && !prefetch_valid[pfi]) begin
        prefetch_alloc_idx = pfi;
        prefetch_alloc_found = 1'b1;
      end
    end
  end
  wire next_line_hit = next_line_main_hit || next_line_prefetch_hit;
  wire prefetch_in_range = snd_is_populated_oki &&
                           (next_line_addr < 21'h140000);

`ifdef MUT_TUNIT_ADPCM_NO_PREFETCH
  // Focused rollback: retain the production 8-line cache and every CDC/epoch
  // invariant, but restore demand-only fills so the latency gate can expose the
  // first-byte discontinuity at a sequential line boundary.
  wire prefetch_needed = 1'b0;
`elsif MUT_ADPCM_BYTE_CACHE
  // Keep the older byte-cache mutation exact; speculative aligned-line fills
  // would otherwise give that independent rollback an unintended runway.
  wire prefetch_needed = 1'b0;
`else
  wire prefetch_needed = prefetch_in_range && hit && !next_line_hit;
`endif

  assign snd_ok   = hit;
  assign snd_data = use_prefetch_data
      ? prefetch_data[prefetch_hit_idx][8*req_off +: 8]
      : line_data[line_hit_idx][8*req_off +: 8];

  // A demand that arrives behind a speculative transaction may wait for only
  // that one frozen prefetch.  If the prefetch is for another line, chain the
  // urgent demand as soon as the response reaches clk_snd; if it is already for
  // the demanded line, publishing the shadow satisfies it without a refetch.
  wire prefetch_covers_live = request_is_prefetch &&
                              (request_addr[20:3] == req_line);
  wire prefetch_urgent_demand = request_pending && request_is_prefetch &&
                                !hit && !prefetch_covers_live;
  wire response_arrived = rsp_sync[1] != rsp_seen;
  wire demand_response_arrived = response_arrived && !request_is_prefetch;

  // Assert immediately when the system-domain image fence rises; release only
  // after three clk_snd edges. The cache, request toggle and pending bundled
  // payload are therefore all dead for the complete loader/backend epoch.
  always_ff @(posedge clk_snd or posedge cache_reset) begin
    if (cache_reset) snd_rst_pipe <= 3'b111;
    else snd_rst_pipe <= {snd_rst_pipe[1:0], 1'b0};
  end

  integer li;
  integer lu;
  always_ff @(posedge clk_snd) begin
    if (snd_rst) begin
      req_toggle <= 1'b0;
      request_addr <= 21'd0;
      request_pending <= 1'b0;
      request_is_prefetch <= 1'b0;
      request_prefetch_slot <= '0;
      request_demand_slot <= '0;
      prefetch_replace <= '0;
      cpu_replace <= 1'b0;
      rsp_sync <= 2'b00;
      rsp_seen <= 1'b0;
      for (li = 0; li < NLINE; li = li + 1) begin
        line_valid[li] <= 1'b0;
        line_tag[li]   <= '0;
        line_data[li]  <= 64'd0;
        line_lru[li]   <= 3'd0;
        prefetch_valid[li] <= 1'b0;
        prefetch_line[li]  <= 18'd0;
`ifdef MUT_TUNIT_ADPCM_SOURCE_EVICT
        prefetch_source_line[li] <= 18'd0;
`endif
        prefetch_data[li]  <= 64'd0;
      end
`ifdef MUT_ADPCM_BYTE_CACHE
      byte_tag <= 21'd0;
      byte_valid <= 1'b0;
`endif
    end else begin
      rsp_sync <= {rsp_sync[0], rsp_toggle};

`ifndef MUT_ADPCM_BYTE_CACHE
`ifndef MUT_TUNIT_ADPCM_DIRECT_MAP
      // True recency rank for the six OKI demand residents.  Repeated clocks on
      // one stable hit are harmless: once its old rank is zero no peer moves.
      // The two CPU lines use a one-bit MRU/victim selector instead.
      // Only a demand response also writes the demand-cache recency vector.
      // A normal background-prefetch response must not suppress this live hit.
      if (line_hit && !demand_response_arrived) begin
        if (!snd_is_oki) begin
          cpu_replace <= ~line_hit_idx[0];
        end else begin
          for (lu = 2; lu < NLINE; lu = lu + 1) begin
            if (lu == line_hit_idx)
              line_lru[lu] <= 3'd0;
            else if (line_valid[lu] &&
                     (line_lru[lu] < line_lru[line_hit_idx]))
              line_lru[lu] <= line_lru[lu] + 1'b1;
          end
        end
      end
`endif
`endif

      // Demand wins selection of an idle request slot.  Once it is a hit, fetch
      // the following aligned line through the SAME slot.  request_addr, rather
      // than live snd_addr, remains the bundled payload for both kinds of fill;
      // the OKI may rotate to another voice while a speculative fill is
      // outstanding without relabelling its response.
      if (!request_pending) begin
        if (!hit) begin
          request_addr <= snd_addr;
          request_pending <= 1'b1;
          request_is_prefetch <= 1'b0;
          request_demand_slot <= demand_alloc_idx;
          req_toggle <= ~req_toggle;
        end else if (prefetch_needed) begin
          request_addr <= next_line_addr;
          request_pending <= 1'b1;
          request_is_prefetch <= 1'b1;
          request_prefetch_slot <= prefetch_alloc_idx;
          // Reserve the frozen destination immediately.  If the shadow is
          // full, the round-robin victim can no longer be consumed while an
          // in-flight response is committed to overwrite that exact slot.
          prefetch_valid[prefetch_alloc_idx] <= 1'b0;
          req_toggle <= ~req_toggle;
        end
      end

      // A shadow hit is already safe to consume combinationally.  Promote it
      // on this edge so later visits retain the line even if another stream's
      // speculative fill eventually reuses the same shadow slot.
      // A background-prefetch response only writes its reserved shadow slot,
      // so it cannot suppress this one-shot live promotion.  A demand response
      // owns the demand insertion/LRU port on the rare coincident edge.
      if (use_prefetch_data && !demand_response_arrived) begin
        line_data[promotion_alloc_idx]  <= prefetch_data[prefetch_hit_idx];
        line_tag[promotion_alloc_idx]   <= req_line;
        line_valid[promotion_alloc_idx] <= 1'b1;
        prefetch_valid[prefetch_hit_idx] <= 1'b0;
`ifndef MUT_ADPCM_BYTE_CACHE
`ifndef MUT_TUNIT_ADPCM_DIRECT_MAP
        if (snd_is_oki) begin
          for (lu = 2; lu < NLINE; lu = lu + 1) begin
            if (lu == promotion_alloc_idx)
              line_lru[lu] <= 3'd0;
            else if (line_valid[lu] &&
                     (!line_valid[promotion_alloc_idx] ||
                      (line_lru[lu] < line_lru[promotion_alloc_idx])))
              line_lru[lu] <= line_lru[lu] + 1'b1;
          end
        end
`endif
`endif
      end

      if (response_arrived) begin
        rsp_seen <= rsp_sync[1];
        if (request_is_prefetch) begin
          prefetch_data[request_prefetch_slot]  <= response_line;
          prefetch_line[request_prefetch_slot]  <= request_addr[20:3];
`ifdef MUT_TUNIT_ADPCM_SOURCE_EVICT
          prefetch_source_line[request_prefetch_slot] <=
              request_addr[20:3] - 18'd1;
`endif
          prefetch_valid[request_prefetch_slot] <= 1'b1;
          prefetch_replace <= request_prefetch_slot + 1'b1;
        end else begin
          line_data[request_demand_slot]  <= response_line;
          line_tag[request_demand_slot]   <= request_addr[20:3];
          line_valid[request_demand_slot] <= 1'b1;
`ifndef MUT_ADPCM_BYTE_CACHE
`ifndef MUT_TUNIT_ADPCM_DIRECT_MAP
          if (request_addr >= 21'h040000) begin
            for (lu = 2; lu < NLINE; lu = lu + 1) begin
              if (lu == request_demand_slot)
                line_lru[lu] <= 3'd0;
              else if (line_valid[lu] &&
                       (!line_valid[request_demand_slot] ||
                        (line_lru[lu] < line_lru[request_demand_slot])))
                line_lru[lu] <= line_lru[lu] + 1'b1;
            end
          end else
            cpu_replace <= ~request_demand_slot[0];
`endif
`endif
        end
        if (prefetch_urgent_demand) begin
          // The completed speculative response is already frozen into its
          // tagged shadow slot above.  Reuse the one request channel only after
          // that completion and freeze the urgent live address as a demand.
          request_addr <= snd_addr;
          request_pending <= 1'b1;
          request_is_prefetch <= 1'b0;
          request_demand_slot <= demand_alloc_idx;
          req_toggle <= ~req_toggle;
        end else begin
          request_pending <= 1'b0;
          request_is_prefetch <= 1'b0;
        end
`ifdef MUT_ADPCM_BYTE_CACHE
        byte_tag <= request_addr;
        byte_valid <= 1'b1;
`endif
      end
    end
  end

  always_ff @(posedge clk_sys) begin
    if (cache_reset) begin
      req_sync <= 2'b00;
      req_seen <= 1'b0;
      rsp_toggle <= 1'b0;
      sys_req <= 1'b0;
      sys_addr <= 21'd0;
      response_line <= 64'd0;
    end else begin
      req_sync <= {req_sync[0], req_toggle};

      if (!sys_req && (req_sync[1] != req_seen)) begin
        req_seen <= req_sync[1];
        sys_addr <= request_addr;
        sys_req <= 1'b1;
      end

      if (sys_req && sys_ack) begin
        response_line <= sys_line;
        sys_req <= 1'b0;
        rsp_toggle <= req_seen;
      end
    end
  end
endmodule
`default_nettype wire
