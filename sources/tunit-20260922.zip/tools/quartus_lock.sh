#!/usr/bin/env bash
# Machine-wide Quartus mutex, shared by every core session on this box.
#
# THE PATH IS THE CONTRACT: /tmp/fpga_quartus.lock
#
# Several core sessions (T-unit, Wolf, Y-unit/Smash T.V., NARC/Z-unit, Gladiator)
# share one machine. A fit is ~25 min and ~2.5 GB, and concurrent fits kill each
# other. Etiquette alone already failed once here, and it failed SILENTLY: the
# Questa mutex had T-unit on /tmp/tunit-questa.lock while three other sessions
# were on /tmp/umk3_questa.lock, so four sessions each believed they were
# interlocked while one of them was interlocked with nobody. A second
# implementation of this lock would recreate exactly that, so do NOT write
# another one -- adopt this path verbatim.
#
# Usage:
#   tools/quartus_lock.sh <command> [args...]
#   tools/quartus_lock.sh --status
#
#   tools/quartus_lock.sh bash -c '
#     quartus_map.exe Arcade-TUnit && quartus_fit.exe Arcade-TUnit && quartus_sta.exe Arcade-TUnit'
#
# DELIBERATE DIFFERENCE FROM questa_lock.sh: that runner REAPS orphaned vsim,
# because a wedged vsim holds a nodelocked licence and costs everyone. This one
# NEVER kills a running Quartus. A live fit is up to 25 minutes of someone's
# work, and it may belong to a session that started legitimately before this
# lock existed. If a Quartus process is running we WAIT, whatever the lock says.
# Stale locks are broken only when the owner process is gone AND no Quartus is
# running -- both conditions, never one.

set -u

LOCK_DIR="${FPGA_QUARTUS_LOCK:-/tmp/fpga_quartus.lock}"
OWNER_FILE="$LOCK_DIR/owner"
WAIT_LIMIT_S=${FPGA_QUARTUS_WAIT_S:-5400}   # 90 min: three back-to-back fits
POLL_S=15

log() { printf '[quartus-lock] %s\n' "$*" >&2; }

# Process state return codes: 0 RUNNING, 1 IDLE, 2 UNKNOWN. Never collapse a
# detector failure into IDLE: doing that would let acquisition or release lie
# about a box whose allocator state they could not observe.
quartus_tasklist_state() {
  local listing
  local state
  if ! listing=$(tasklist 2>/dev/null); then
    return 2
  fi
  [ -n "$listing" ] || return 2
  # Broad prefixes deliberately cover quartus itself; map, fit, sta, asm, sh,
  # cdb, syn, ipgenerate, eda, pow, cpf, pgm, stp, sim, drc; every qsys worker;
  # and the shared sopc_builder allocator.
  printf '%s\n' "$listing" \
    | grep -qiE '^(quartus[^[:space:]]*|qsys[^[:space:]]*|sopc_builder)\.exe([[:space:]]|$)'
  state=$?
  case "$state" in
    0) return 0 ;;
    1) return 1 ;;
    *) return 2 ;;
  esac
}

quartus_powershell_state() {
  powershell.exe -NoProfile -NonInteractive -Command '
    try {
      $q = @(Get-Process -ErrorAction Stop | Where-Object {
        ($_.ProcessName -like "quartus*") -or ($_.ProcessName -like "qsys*") -or
        ($_.ProcessName -eq "sopc_builder")
      })
      if ($q.Count -gt 0) { exit 0 }
      exit 1
    } catch {
      exit 2
    }
  ' >/dev/null 2>&1
  case $? in
    0) return 0 ;;
    1) return 1 ;;
    *) return 2 ;;
  esac
}

quartus_running() {
  local state
  quartus_tasklist_state
  state=$?
  case "$state" in
    0|1) return "$state" ;;
  esac

  # Some managed Windows sessions allow Get-Process but deny tasklist. Use the
  # independent query only as a fallback; if it also fails, state stays UNKNOWN.
  quartus_powershell_state
}

owner_alive() {
  [ -f "$OWNER_FILE" ] || return 1
  local pid
  pid=$(awk 'NR==1{print $1}' "$OWNER_FILE" 2>/dev/null)
  [ -n "$pid" ] || return 1
  kill -0 "$pid" 2>/dev/null
}

show_owner() {
  if [ -f "$OWNER_FILE" ]; then
    log "held by: $(cat "$OWNER_FILE" 2>/dev/null | tr '\n' ' ')"
  else
    log "held, but no owner file yet (a race, or a crashed acquirer)"
  fi
}

# --status: report and exit, so a session can check before announcing.
if [ "${1:-}" = "--status" ]; then
  if [ -d "$LOCK_DIR" ]; then
    show_owner
    owner_alive && log "owner is ALIVE" || log "owner is GONE (stale unless Quartus is running)"
  else
    log "lock is FREE"
  fi
  quartus_running
  case $? in
    0) log "a Quartus process IS running right now" ;;
    1) log "no Quartus process running" ;;
    *)
      log "ERROR: Quartus process state is UNKNOWN (both detectors failed)"
      exit 75
      ;;
  esac
  exit 0
fi

if [ $# -eq 0 ]; then
  log "ERROR: no command given (use --status to query)"
  exit 2
fi

# INVARIANT -- BOTH CONDITIONS, PERMANENTLY. DO NOT "SIMPLIFY" THIS TO THE PID CHECK.
#
# The owner PID is a claim about a PROCESS, not about the BOX (Y-unit, 2026-07-27).
# Any build that relaunches its top-level script -- a seed sweep, a retry loop --
# kills the PID in the owner file while the box stays legitimately occupied. That
# happened here today: the lock named `wolf:openice-rc2` with a dead PID while
# quartus_fit 96232 was alive and the session had moved on to RC4. The owner PID had
# been dead "by design" for two relaunches.
#
# So the rule that LOOKS most precise -- "owner PID dead => the lock is stale" -- is
# the one that would have cleared a live claim and corrupted a running fit. The PID
# check is the tempting refactor precisely because it looks exact. It is not: it is
# exact about the wrong subject. Only the live-Quartus check speaks about the box.
stale_lock_layout() {
  local had_dotglob=0
  local had_nullglob=0
  local -a entries

  [ -d "$LOCK_DIR" ] || return 1
  [ ! -L "$LOCK_DIR" ] || return 1
  shopt -q dotglob && had_dotglob=1
  shopt -q nullglob && had_nullglob=1
  shopt -s dotglob nullglob
  entries=("$LOCK_DIR"/*)
  [ "$had_dotglob" -eq 1 ] || shopt -u dotglob
  [ "$had_nullglob" -eq 1 ] || shopt -u nullglob

  if [ "${#entries[@]}" -eq 0 ]; then
    printf 'empty\n'
    return 0
  fi
  if [ "${#entries[@]}" -ne 1 ] || [ "${entries[0]}" != "$OWNER_FILE" ]; then
    return 1
  fi
  [ -f "$OWNER_FILE" ] || return 1
  [ ! -L "$OWNER_FILE" ] || return 1
  printf 'owner\n'
}

stale_lock_identity() {
  local dir_key
  local dir_snapshot
  local dir_snapshot_after
  local layout
  local layout_after
  local owner_id=''
  local owner_id_after
  local owner_sha=''

  [ -d "$LOCK_DIR" ] || return 1
  [ ! -L "$LOCK_DIR" ] || return 1
  dir_snapshot=$(stat -c '%d:%i:%f|%y:%z' -- "$LOCK_DIR" 2>/dev/null) || return 1
  [ -n "$dir_snapshot" ] || return 1
  dir_key=${dir_snapshot%%|*}
  layout=$(stale_lock_layout) || return 1

  if [ "$layout" = "owner" ]; then
    owner_id=$(stat -c '%d:%i:%s:%y:%z' -- "$OWNER_FILE" 2>/dev/null) || return 1
    [ -n "$owner_id" ] || return 1
    owner_sha=$(sha256sum -- "$OWNER_FILE" 2>/dev/null) || return 1
    owner_sha=${owner_sha%% *}
    [ -n "$owner_sha" ] || return 1
    owner_id_after=$(stat -c '%d:%i:%s:%y:%z' -- "$OWNER_FILE" 2>/dev/null) || return 1
    [ "$owner_id_after" = "$owner_id" ] || return 1
  fi

  dir_snapshot_after=$(stat -c '%d:%i:%f|%y:%z' -- "$LOCK_DIR" 2>/dev/null) || return 1
  layout_after=$(stale_lock_layout) || return 1
  [ "$dir_snapshot_after" = "$dir_snapshot" ] || return 1
  [ "$layout_after" = "$layout" ] || return 1

  if [ "$layout" = "empty" ]; then
    printf '%s|%s|empty\n' "$dir_key" "${dir_snapshot#*|}"
  else
    printf '%s|%s|owner|%s|%s\n' "$dir_key" "${dir_snapshot#*|}" "$owner_id" "$owner_sha"
  fi
}

break_if_stale() {
  local current_identity
  local dir_id
  local expected_identity
  local expected_layout
  local identity_tail
  local state
  [ -d "$LOCK_DIR" ] || return 0
  if owner_alive; then
    return 1                        # legitimately held
  fi
  quartus_running
  state=$?
  case "$state" in
    0)
      log "owner process is gone but Quartus is STILL RUNNING -- not breaking the lock"
      return 1                      # never race a live fit
      ;;
    1) ;;
    *)
      log "ERROR: Quartus process state is UNKNOWN -- refusing to break the lock"
      return 2
      ;;
  esac
  if ! expected_identity=$(stale_lock_identity); then
    log "ERROR: stale lock has an unsafe directory, entry set, or owner identity -- refusing removal"
    return 1
  fi
  dir_id=${expected_identity%%|*}
  identity_tail=${expected_identity#*|}
  expected_layout=${identity_tail#*|}
  expected_layout=${expected_layout%%|*}
  if owner_alive; then
    log "owner reappeared before the stale audit -- not breaking the lock"
    return 1
  fi
  # SUSTAINED absence, not a single sample. A build that relaunches its top-level
  # script between seeds has GAPS with no Quartus process alive while the claim is
  # entirely valid. On 2026-07-27 this exact combination -- a dead owner PID from a
  # superseded relaunch plus a momentary gap between seeds -- let this runner break
  # a LIVE Wolf-unit lock, because both conditions were true at the instant sampled.
  # A point-in-time observation is not a durable fact (Y-unit). Require the box to
  # stay quiet across several spaced checks before believing it.
  local q=0
  while [ "$q" -lt 4 ]; do
    sleep 10
    quartus_running
    state=$?
    case "$state" in
      0)
        log "Quartus reappeared during the stale-check (a relaunch gap, not a stale lock) -- backing off"
        return 1
        ;;
      1) ;;
      *)
        log "ERROR: Quartus process state became UNKNOWN during the stale-check -- refusing to break the lock"
        return 2
        ;;
    esac
    if ! current_identity=$(stale_lock_identity); then
      log "ERROR: stale-lock directory, entry set, or owner identity became unreadable -- refusing removal"
      return 1
    fi
    if [ "$current_identity" != "$expected_identity" ]; then
      log "ERROR: stale-lock directory, entry set, or owner identity changed during audit -- refusing removal"
      return 1
    fi
    if owner_alive; then
      log "owner reappeared during the stale-check -- not breaking the lock"
      return 1
    fi
    q=$((q + 1))
  done

  if ! current_identity=$(stale_lock_identity); then
    log "ERROR: stale-lock identity became unreadable before removal -- refusing removal"
    return 1
  fi
  if [ "$current_identity" != "$expected_identity" ]; then
    log "ERROR: stale-lock identity changed before removal -- refusing removal"
    return 1
  fi

  case "$expected_layout" in
    empty)
      if ! rmdir -- "$LOCK_DIR"; then
        log "ERROR: unchanged empty stale-lock directory could not be removed"
        return 1
      fi
      ;;
    owner)
      if ! rm -- "$OWNER_FILE"; then
        log "ERROR: unchanged sole stale owner file could not be removed"
        return 1
      fi
      if ! current_identity=$(stale_lock_identity); then
        log "ERROR: stale-lock directory identity was lost after owner removal; refusing further removal"
        return 1
      fi
      identity_tail=${current_identity#*|}
      identity_tail=${identity_tail#*|}
      if [ "${current_identity%%|*}" != "$dir_id" ] || [ "$identity_tail" != "empty" ]; then
        log "ERROR: stale-lock directory or entry set changed after owner removal; refusing further removal"
        return 1
      fi
      if ! rmdir -- "$LOCK_DIR"; then
        log "ERROR: unchanged empty stale-lock directory could not be removed after owner removal"
        return 1
      fi
      ;;
    *)
      log "ERROR: internal stale-lock layout state is invalid; refusing removal"
      return 1
      ;;
  esac
  log "removed exact stale lock (owner gone AND no Quartus for 40s of spaced checks)"
  return 0
}

acquire() {
  local waited=0
  local state
  local stale_rc
  # An unheld lock does NOT mean a free box. Killing a Quartus parent orphans its
  # internal workers: stopping one map run here released the lock (the EXIT trap
  # fired) while SIXTEEN quartus_map.exe processes kept running. A session that
  # trusted the lock file alone would have started straight into those orphans.
  # So refuse to acquire while ANY Quartus is alive, whatever the lock says.
  while true; do
    quartus_running
    state=$?
    case "$state" in
      0)
        if [ "$waited" -eq 0 ]; then
          # Do not assert the lock state here: this loop has only checked for live
          # Quartus processes, so claiming "lock is free" is a statement the code
          # never verified. It printed exactly that while the lock was in fact held
          # by another session -- a tool reporting a state it cannot see, which is
          # the defect class this whole runner exists to prevent.
          if [ -d "$LOCK_DIR" ]; then
            log "a Quartus process is RUNNING and the lock is HELD -- waiting"
            show_owner
          else
            log "a Quartus process is RUNNING with NO lock held (orphan or an unlocked build) -- refusing to start"
          fi
        fi
        if [ "$waited" -ge "$WAIT_LIMIT_S" ]; then
          log "ERROR: Quartus still running after ${waited}s; clear it before building"
          return 75
        fi
        sleep "$POLL_S"; waited=$((waited + POLL_S))
        ;;
      1) break ;;
      *)
        log "ERROR: Quartus process state is UNKNOWN; refusing to acquire or launch"
        return 75
        ;;
    esac
  done
  # REFUSE, DO NOT WAIT (2026-08-10).  This used to poll for up to WAIT_LIMIT_S
  # for the lock, and that is a race, not a queue: a lock gives mutual exclusion,
  # never ordering, so two sessions both waiting can both take it in whatever
  # order they happen to poll.  The shared convention says refuse; that is what
  # /tmp/fpga_quartus.queue is for.
  #
  # MEASURED COST OF WAITING, today: the owner told me another session had the
  # box, so I stood down -- but this loop kept polling in the background, silently
  # took the lock ~60s later when the Y-unit fit finished, and had spawned
  # quartus_map before anyone noticed.  Yielding then required killing the process
  # tree and the Quartus binary, which left MY dead pid owning the lock, i.e. a
  # stale lock that would have stranded the box for everyone.  A runner that can
  # acquire the box after you believe you have stopped is worse than one that
  # simply fails.
  #
  # QUARTUS_LOCK_WAIT=1 restores the old behaviour for a deliberate,
  # supervised march where blocking is the intent.
  if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    break_if_stale
    stale_rc=$?
    if [ "$stale_rc" -eq 0 ]; then
      mkdir "$LOCK_DIR" 2>/dev/null || { log "ERROR: lost the race after breaking a stale lock"; return 75; }
    elif [ "$stale_rc" -eq 2 ]; then
      log "ERROR: Quartus process state is UNKNOWN; refusing stale-lock recovery"
      return 75
    elif [ "${QUARTUS_LOCK_WAIT:-0}" = "1" ]; then
      waited=0
      while ! mkdir "$LOCK_DIR" 2>/dev/null; do
        break_if_stale
        stale_rc=$?
        if [ "$stale_rc" -eq 0 ]; then continue; fi
        if [ "$stale_rc" -eq 2 ]; then
          log "ERROR: Quartus process state is UNKNOWN; refusing stale-lock recovery"
          return 75
        fi
        if [ "$waited" -eq 0 ]; then log "box is busy, waiting (QUARTUS_LOCK_WAIT=1)"; show_owner; fi
        if [ "$waited" -ge "$WAIT_LIMIT_S" ]; then
          log "ERROR: timed out after ${waited}s waiting for the box"
          return 75
        fi
        sleep "$POLL_S"; waited=$((waited + POLL_S))
        [ $((waited % 300)) -eq 0 ] && log "still waiting (${waited}s)"
      done
    else
      log "REFUSING: the box is busy. Queue via /tmp/fpga_quartus.queue and retry,"
      log "or set QUARTUS_LOCK_WAIT=1 if blocking here is genuinely what you want."
      show_owner
      return 75                     # distinct code: never got the box
    fi
  fi
  # The lock wait/stale check can be long. Re-observe the allocator after the
  # atomic mkdir so a late detector failure or unlocked worker cannot launch
  # through a state sampled before this directory was acquired.
  quartus_running
  state=$?
  case "$state" in
    0)
      log "ERROR: a Quartus process appeared while acquiring; refusing to launch"
      if ! rmdir -- "$LOCK_DIR" 2>/dev/null; then
        log "ERROR: newly-created lock directory was not empty or could not be removed; leaving it fail-closed"
      fi
      return 75
      ;;
    1) ;;
    *)
      log "ERROR: Quartus process state is UNKNOWN after lock acquisition; refusing to launch"
      if ! rmdir -- "$LOCK_DIR" 2>/dev/null; then
        log "ERROR: newly-created lock directory was not empty or could not be removed; leaving it fail-closed"
      fi
      return 75
      ;;
  esac
  local started
  if ! started=$(date -Is); then
    log "ERROR: failed to create exact owner timestamp; refusing to launch"
    if ! rmdir -- "$LOCK_DIR" 2>/dev/null; then
      log "ERROR: newly-created lock directory was not empty or could not be removed; leaving it fail-closed"
    fi
    return 75
  fi
  if ! printf '%s\n' "$$" "session=${FPGA_SESSION:-unknown}" "started=$started" \
      "cmd=$*" > "$OWNER_FILE"; then
    log "ERROR: failed to create exact owner metadata; refusing to launch"
    if ! rmdir -- "$LOCK_DIR" 2>/dev/null; then
      log "ERROR: newly-created lock directory was not empty or could not be removed; leaving it fail-closed"
    fi
    return 75
  fi
  if ! lock_is_mine; then
    log "ERROR: exact owner metadata did not verify after creation; refusing to launch"
    if ! rmdir -- "$LOCK_DIR" 2>/dev/null; then
      log "ERROR: newly-created lock directory was not empty or could not be removed; leaving it fail-closed"
    fi
    return 75
  fi
  return 0
}

lock_is_mine() {
  [ -d "$LOCK_DIR" ] || return 1
  [ -f "$OWNER_FILE" ] || return 1
  [ "$(awk 'NR==1{print $1}' "$OWNER_FILE" 2>/dev/null)" = "$$" ]
}

release() {
  local rc=$?
  local cleanup_rc=$rc
  local waited=0
  local state
  trap - EXIT INT TERM

  if ! lock_is_mine; then
    if [ ! -d "$LOCK_DIR" ]; then
      log "ERROR: lock path disappeared before exact-owned release"
    else
      log "ERROR: lock ownership changed before release; refusing removal"
      show_owner
    fi
    exit 97
  fi

  # NARC's rule: do not tell a lie about the resource. Killing a parent leaves
  # its Quartus children running, so an unconditional release announces a free
  # box while the box is fully occupied -- the same class as a GC'd MAME tap
  # reporting a low count, or a grep reporting a test result. All three report
  # a state they cannot actually observe. Verify before releasing.
  while true; do
    quartus_running
    state=$?
    case "$state" in
      0)
        if ! lock_is_mine; then
          log "ERROR: lock disappeared or ownership changed while waiting for Quartus to exit; refusing removal"
          exit 97
        fi
        if [ "$waited" -eq 0 ]; then
          log "NOT releasing: a Quartus process remains alive after this run"
          log "The machine-wide lock will stay held; this wrapper never kills a potentially foreign fit"
        fi
        if [ "$waited" -ge 120 ]; then
          log "ERROR: Quartus is still alive; lock HELD deliberately so nobody starts into it"
          exit 97
        fi
        sleep 3; waited=$((waited + 3))
        ;;
      1) break ;;
      *)
        log "ERROR: Quartus process state is UNKNOWN; exact-owned lock remains held"
        exit 97
        ;;
    esac
  done

  if ! lock_is_mine; then
    log "ERROR: lock disappeared or ownership changed before removal; refusing removal"
    exit 97
  fi
  if ! rm -- "$OWNER_FILE"; then
    log "ERROR: failed to remove exact-owned owner file; lock remains held"
    cleanup_rc=97
  elif ! rmdir -- "$LOCK_DIR"; then
    log "ERROR: failed to remove exact-owned lock directory; lock remains held"
    cleanup_rc=97
  else
    log "released (verified: no Quartus running)"
  fi
  exit "$cleanup_rc"
}

acquire "$@" || exit $?
trap release EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

log "acquired (session=${FPGA_SESSION:-unknown}); running: $*"
export FPGA_QUARTUS_LOCK_HELD=1
"$@"
rc=$?
log "command exited rc=$rc"
exit $rc
