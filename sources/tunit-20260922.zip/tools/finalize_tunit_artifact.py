#!/usr/bin/env python3
"""Name and bind a timing-gated T-unit artifact after Quartus assembly."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output_files"
ASCAL_ARTIFACT_IDS = {
    "nearest": "NBA-ASCAL-A-NEAREST",
    "bilinear": "NBA-ASCAL-B-BILINEAR",
}
DIAG_ARTIFACT_IDS = frozenset(
    ("NBA-FLASH-DIAG", "NBA-FLASH-SRT-ORDER-DIAG")
)
SAFE_ARTIFACT_ID = re.compile(r"^[A-Z0-9][A-Z0-9._-]{0,63}$")
ASCAL_A_REFERENCE = (
    "output_files/"
    "Arcade-TUnit-ADPCM-ENGINEERING-NBA-ASCAL-A-NEAREST.manifest.json"
)
BASE_REQUIRED_REPORTS = (
    "Arcade-TUnit.map.rpt",
    "Arcade-TUnit.fit.rpt",
    "Arcade-TUnit.sta.summary",
    "build_map.log",
    "build_fit.log",
    "build_sta.log",
    "build_scanline_sta.log",
    "build_asm.log",
    "tunit_scanline_map_physical_receipt.txt",
    "tunit_scanline_fit_physical_receipt.txt",
    "tunit_scanline_snoop_timing_receipt.txt",
)
# 156 = 164 minus the 8 pll_hdmi Recovery/Removal checks (4 corners x 2): the ascal output stage reset is synchronous since R7D, so the HDMI domain has no async-reset endpoints left.
CANONICAL_TIMING_CHECKS = {"universal": 156, "adpcm": 156, "dcs": 136}


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def copy_artifact(source: Path, target: Path, *, exclusive: bool) -> None:
    if not exclusive:
        shutil.copy2(source, target)
        return
    # The earlier collision checks save build time, but only an exclusive
    # create closes the check-to-copy race and makes labelled evidence truly
    # immutable if an external process writes the destination concurrently.
    created = False
    try:
        with source.open("rb") as input_stream, target.open("xb") as output_stream:
            created = True
            shutil.copyfileobj(input_stream, output_stream)
        shutil.copystat(source, target)
    except BaseException:
        if created:
            target.unlink(missing_ok=True)
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--variant", required=True, choices=("universal", "adpcm", "dcs")
    )
    args = parser.parse_args()

    provenance_path = ROOT / "build_syn" / "tunit_core.manifest.json"
    provenance_bytes = provenance_path.read_bytes()
    provenance_digest = sha256(provenance_bytes).hexdigest()
    provenance = json.loads(provenance_bytes.decode("utf-8"))
    expected_provenance_digest = os.environ.get(
        "TUNIT_CANDIDATE_PROVENANCE_SHA256"
    )
    if (
        expected_provenance_digest
        and expected_provenance_digest != provenance_digest
    ):
        raise SystemExit(
            "in-memory provenance does not match the candidate digest"
        )
    if provenance.get("variant") != args.variant:
        raise SystemExit(
            f"refusing to label {provenance.get('variant')!r} netlist as "
            f"{args.variant!r}"
        )

    ascal_policy = os.environ.get("TUNIT_ASCAL_POLICY", "")
    artifact_id = os.environ.get("TUNIT_ARTIFACT_ID", "")
    diag_build_raw = os.environ.get("TUNIT_DIAG_BUILD", "0")
    if diag_build_raw not in {"0", "1"}:
        raise SystemExit("TUNIT_DIAG_BUILD must be exactly 0 or 1")
    diag_requested = diag_build_raw == "1"
    if ascal_policy not in {"main", *ASCAL_ARTIFACT_IDS}:
        raise SystemExit(
            "refusing artifact with absent/invalid TUNIT_ASCAL_POLICY"
        )
    if artifact_id and not SAFE_ARTIFACT_ID.fullmatch(artifact_id):
        raise SystemExit(
            "TUNIT_ARTIFACT_ID must begin with A-Z/0-9 and contain only "
            "A-Z, 0-9, dot, underscore, or dash (64 characters maximum)"
        )
    expected_artifact_id = ASCAL_ARTIFACT_IDS.get(ascal_policy)
    if expected_artifact_id and artifact_id != expected_artifact_id:
        raise SystemExit(
            f"ascal policy {ascal_policy!r} requires artifact id "
            f"{expected_artifact_id!r}, got {artifact_id!r}"
        )
    if not expected_artifact_id and artifact_id in ASCAL_ARTIFACT_IDS.values():
        raise SystemExit(
            "reserved NBA-ASCAL A/B artifact id requires its fixed policy"
        )
    if ascal_policy != "main" and args.variant != "adpcm":
        raise SystemExit("NBA ascal A/B policies require the ADPCM variant")
    if ascal_policy != "main" and os.environ.get("TUNIT_DIAG_BUILD", "0") != "0":
        raise SystemExit("NBA ascal A/B policies forbid the diagnostic overlay")
    diag_flattened = "-DTUNIT_DIAG" in (provenance.get("extra_defines") or [])
    if diag_flattened != diag_requested:
        raise SystemExit(
            "diagnostic overlay mismatch between finalized provenance and environment"
        )
    if diag_requested:
        if artifact_id not in DIAG_ARTIFACT_IDS:
            raise SystemExit(
                "TUNIT_DIAG_BUILD=1 requires a reserved NBA flashing diagnostic ID"
            )
        if args.variant != "adpcm" or ascal_policy != "main":
            raise SystemExit(
                "NBA flashing diagnostics require the ADPCM variant and main ascal policy"
            )
    elif artifact_id in DIAG_ARTIFACT_IDS:
        raise SystemExit(
            "reserved NBA flashing diagnostic IDs require TUNIT_DIAG_BUILD=1"
        )

    ab_reference = os.environ.get("TUNIT_AB_REFERENCE_MANIFEST", "")
    if ascal_policy == "bilinear":
        if ab_reference != ASCAL_A_REFERENCE:
            raise SystemExit(
                "bilinear ascal policy requires the exact finalized A manifest"
            )
    elif ab_reference:
        raise SystemExit(
            "only the bilinear ascal policy accepts an A/B reference manifest"
        )

    post_fifo = os.environ.get("TUNIT_POST_FIFO_FINALIZE", "0") == "1"
    expected_checks_raw = os.environ.get("TUNIT_EXPECTED_TIMING_CHECKS", "")
    if not expected_checks_raw.isdigit() or int(expected_checks_raw) < 1:
        raise SystemExit(
            "artifact finalization requires a positive "
            "TUNIT_EXPECTED_TIMING_CHECKS"
        )
    expected_checks = int(expected_checks_raw)
    variant_expected_checks = CANONICAL_TIMING_CHECKS[args.variant]
    if expected_checks != variant_expected_checks:
        raise SystemExit(
            "expected timing count disagrees with the variant: "
            f"got {expected_checks}, required {variant_expected_checks}"
        )
    physical_receipt: dict[str, str] | None = None
    physical_receipt_record: dict[str, str] | None = None
    physical_receipt_source: Path | None = None
    physical_receipt_digest: str | None = None
    required_sentinels = {"TUNIT_BUILD_VARIANT": args.variant}
    if not post_fifo:
        required_sentinels.update(
            {
                "TUNIT_BUILD_WRAPPER_ACTIVE": "1",
                "TUNIT_FIFO_TICKET_HELD": "1",
                "FPGA_QUARTUS_LOCK_HELD": "1",
                "TUNIT_ASSEMBLY_COMPLETE": "1",
            }
        )
    invalid_sentinels = [
        name for name, wanted in required_sentinels.items()
        if os.environ.get(name) != wanted
    ]
    if not os.environ.get("FPGA_SESSION", "").strip():
        invalid_sentinels.append("FPGA_SESSION")
    if invalid_sentinels:
        raise SystemExit(
            "refusing standalone/stale artifact finalization; missing build "
            "ordering sentinel(s): " + ", ".join(invalid_sentinels)
        )
    if post_fifo:
        receipt_value = os.environ.get("TUNIT_PHYSICAL_RECEIPT", "")
        receipt_path = Path(receipt_value)
        if not receipt_path.is_absolute():
            receipt_path = ROOT / receipt_path
        if not receipt_path.is_file():
            raise SystemExit("post-FIFO finalization requires its physical receipt")
        receipt_bytes = receipt_path.read_bytes()
        receipt_digest = sha256(receipt_bytes).hexdigest()
        physical_receipt_source = receipt_path
        physical_receipt_digest = receipt_digest
        receipt: dict[str, str] = {}
        for line in receipt_bytes.decode("utf-8").splitlines():
            if "=" not in line:
                raise SystemExit("malformed post-FIFO physical receipt")
            key, value = line.split("=", 1)
            if key in receipt:
                raise SystemExit(
                    f"duplicate key in post-FIFO physical receipt: {key}"
                )
            receipt[key] = value
        expected_receipt = {
            "schema": "tunit-physical-v2",
            "variant": args.variant,
            "artifact_id": artifact_id,
            "diag_build": diag_build_raw,
            "ascal_policy": ascal_policy,
            "build_date": str(provenance.get("build_date") or ""),
            "session": os.environ.get("FPGA_SESSION", ""),
            "candidate_provenance_sha256": os.environ.get(
                "TUNIT_CANDIDATE_PROVENANCE_SHA256", ""
            ),
            "timing_checks": str(expected_checks),
            "timing_gate": "pass",
            "assembly": "pass",
        }
        mismatches = [
            key for key, wanted in expected_receipt.items()
            if not wanted or receipt.get(key) != wanted
        ]
        if mismatches or not receipt.get("ticket"):
            raise SystemExit(
                "post-FIFO physical receipt mismatch: "
                + ", ".join(mismatches or ["ticket"])
            )
        if receipt.get("fitter_seed_override") != os.environ.get("TUNIT_SEED", ""):
            raise SystemExit(
                "post-FIFO physical receipt mismatch: fitter_seed_override"
            )
        required_for_receipt = BASE_REQUIRED_REPORTS
        if args.variant != "dcs":
            required_for_receipt += ("tunit_postfit_cdc_receipt.txt",)
        evidence = {
            "netlist_sha256": provenance_path.parent / "tunit_core.v",
            "generic_rbf_sha256": OUT / "Arcade-TUnit.rbf",
            "generic_sof_sha256": OUT / "Arcade-TUnit.sof",
            **{
                f"report_sha256.{name}": OUT / name
                for name in required_for_receipt
            },
        }
        evidence_mismatches = [
            key
            for key, path in evidence.items()
            if not path.is_file() or receipt.get(key) != digest(path)
        ]
        if evidence_mismatches:
            raise SystemExit(
                "post-FIFO physical evidence changed after ticket release: "
                + ", ".join(evidence_mismatches)
            )
        if digest(receipt_path) != receipt_digest:
            raise SystemExit(
                "post-FIFO physical receipt changed during verification"
            )
        try:
            relative_receipt = receipt_path.resolve().relative_to(ROOT).as_posix()
        except ValueError:
            relative_receipt = str(receipt_path.resolve())
        physical_receipt_record = {
            "path": relative_receipt,
            "sha256": receipt_digest,
            "schema": receipt["schema"],
            "ticket": receipt["ticket"],
            "fitter_seed_override": receipt["fitter_seed_override"],
        }
        physical_receipt = receipt

    # Verify the release receipt before copying any assembled bitstream into a
    # variant-named location.  A late verification failure must not leave a new
    # RBF that looks ready to flash despite having no valid manifest.
    engineering = bool(provenance.get("git_dirty")) or (
        os.environ.get("TUNIT_ENGINEERING_BUILD", "0") == "1"
    )
    if ascal_policy != "main" and not engineering:
        raise SystemExit(
            "fixed ascal policies are engineering-only until cabinet acceptance"
        )
    if artifact_id and not engineering:
        raise SystemExit("labelled diagnostic artifacts must be engineering builds")
    if engineering and not artifact_id:
        raise SystemExit(
            "engineering artifacts require an immutable TUNIT_ARTIFACT_ID"
        )
    if diag_requested and not engineering:
        raise SystemExit("NBA flashing diagnostics must remain engineering artifacts")

    provenance_command = [
        sys.executable,
        str(ROOT / "tools" / "verify_tunit_candidate_provenance.py"),
        "--variant", args.variant,
    ]
    if ab_reference:
        provenance_command.extend(["--reference", ab_reference])
    provenance_result = subprocess.run(
        provenance_command,
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    if provenance_result.returncode:
        raise SystemExit(
            "source mutation/reference gate failed at artifact finalization:\n"
            + (provenance_result.stdout or "")
            + (provenance_result.stderr or "")
        )
    if digest(provenance_path) != provenance_digest:
        raise SystemExit(
            "candidate provenance changed during finalization verification"
        )
    source_finalization_verification = (provenance_result.stdout or "").strip()

    # The flattened-core provenance map intentionally tracks selected chassis
    # files, while sys.qip/files.qip compile a larger pinned MiSTer framework
    # closure. Re-run that complete snapshot at finalization so a chassis/QIP
    # mutation during map/fit/asm cannot be bound to an otherwise unchanged
    # dirty-tree boolean or stale preflight receipt.
    framework_result = subprocess.run(
        [sys.executable, str(ROOT / "tools" / "verify_framework_snapshot.py")],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    if framework_result.returncode:
        raise SystemExit(
            "framework/QIP closure changed after preflight:\n"
            + (framework_result.stdout or "")
            + (framework_result.stderr or "")
        )
    framework_finalization_verification = (
        framework_result.stdout or ""
    ).strip()

    ab_reference_record = None
    if ab_reference:
        reference_path = (ROOT / ab_reference).resolve()
        ab_reference_record = {
            "path": ab_reference,
            "sha256": digest(reference_path),
        }
    qualification_record = None
    qualification_value = os.environ.get("TUNIT_QUALIFICATION_RECEIPT")
    if not engineering:
        if not qualification_value:
            raise SystemExit(
                "refusing to finalize a production artifact without "
                "TUNIT_QUALIFICATION_RECEIPT"
            )
        qualification_path = Path(qualification_value)
        if not qualification_path.is_absolute():
            qualification_path = ROOT / qualification_path
        qualification_path = qualification_path.resolve()
        result = subprocess.run(
            [
                sys.executable,
                str(ROOT / "tools" / "verify_tunit_qualification_receipt.py"),
                "--receipt", str(qualification_path),
                "--variant", args.variant,
            ],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        if result.returncode:
            raise SystemExit(
                "qualification receipt stopped matching before artifact "
                "finalization:\n" + (result.stdout or "") + (result.stderr or "")
            )
        qualification_json = json.loads(
            qualification_path.read_text(encoding="utf-8")
        )
        if (
            provenance.get("git_commit") != qualification_json.get("source_commit")
            or provenance.get("netlist_sha256")
            != qualification_json.get("netlist_sha256")
            or provenance.get("git_dirty")
            != qualification_json.get("source_dirty")
        ):
            raise SystemExit(
                "assembled-netlist provenance does not match the bound "
                "qualification receipt"
            )
        try:
            relative_qualification = qualification_path.relative_to(ROOT).as_posix()
        except ValueError:
            relative_qualification = str(qualification_path)
        qualification_record = {
            "path": relative_qualification,
            "sha256": digest(qualification_path),
            "source_commit": qualification_json.get("source_commit"),
            "netlist_sha256": qualification_json.get("netlist_sha256"),
            "verification": (result.stdout or "").strip(),
        }

    required_reports = BASE_REQUIRED_REPORTS
    if args.variant != "dcs":
        required_reports += ("tunit_postfit_cdc_receipt.txt",)
    missing_reports = [name for name in required_reports if not (OUT / name).is_file()]
    if missing_reports:
        raise SystemExit(
            "refusing to finalize without the complete physical-build evidence: "
            + ", ".join(missing_reports)
        )
    generic_rbf = OUT / "Arcade-TUnit.rbf"
    if not generic_rbf.is_file():
        raise SystemExit(f"missing assembled artifact: {generic_rbf}")

    label = args.variant.upper()
    artifact_label = f"{label}-ENGINEERING" if engineering else label
    if artifact_id:
        artifact_label = f"{artifact_label}-{artifact_id}"

    target_manifest = OUT / f"Arcade-TUnit-{artifact_label}.manifest.json"
    report_dir = OUT / f"reports-{artifact_label}"
    planned_outputs = [target_manifest, report_dir]
    for extension in ("sof", "rbf"):
        if (OUT / f"Arcade-TUnit.{extension}").is_file():
            planned_outputs.append(OUT / f"Arcade-TUnit-{artifact_label}.{extension}")
    if engineering:
        planned_outputs.append(
            OUT / f"Arcade-TUnit-{artifact_label}-DO-NOT-FLASH.txt"
        )
    collisions = [path for path in planned_outputs if path.exists()]
    if artifact_id and collisions:
        raise SystemExit(
            "refusing to overwrite an immutable finalized artifact/evidence path: "
            + ", ".join(path.name for path in collisions)
        )

    # Stage and verify the complete artifact set before publishing any
    # cabinet-facing path. If publication itself fails, roll back only paths
    # this invocation created so a retry is not blocked by a partial RBF.
    with tempfile.TemporaryDirectory(
        prefix=f".finalize-{artifact_label}-", dir=OUT
    ) as staging_value:
        staging = Path(staging_value)
        publications: list[tuple[Path, Path]] = []
        publication_hashes: dict[Path, str] = {}
        artifact_hashes: dict[str, str] = {}
        for extension in ("sof", "rbf"):
            source = OUT / f"Arcade-TUnit.{extension}"
            if not source.is_file():
                if post_fifo:
                    raise SystemExit(
                        f"post-FIFO {extension} disappeared before staging"
                    )
                continue
            target = OUT / f"Arcade-TUnit-{artifact_label}.{extension}"
            staged = staging / target.name
            shutil.copy2(source, staged)
            if post_fifo:
                if physical_receipt is None:
                    raise SystemExit("post-FIFO receipt state was lost")
                receipt_key = f"generic_{extension}_sha256"
                if digest(staged) != physical_receipt.get(receipt_key):
                    raise SystemExit(
                        f"post-FIFO {extension} changed while it was being staged"
                    )
            artifact_hashes[target.name] = digest(staged)
            publications.append((staged, target))
            publication_hashes[target] = artifact_hashes[target.name]

        engineering_warning = None
        if engineering:
            warning_path = OUT / f"Arcade-TUnit-{artifact_label}-DO-NOT-FLASH.txt"
            staged_warning = staging / warning_path.name
            staged_warning.write_text(
                "DO NOT FLASH OR PACKAGE THIS ENGINEERING ARTIFACT.\n"
                "It bypassed the production candidate qualification receipt.\n",
                encoding="utf-8",
            )
            engineering_warning = {
                "path": warning_path.name,
                "sha256": digest(staged_warning),
            }
            publications.append((staged_warning, warning_path))
            publication_hashes[warning_path] = engineering_warning["sha256"]

        # Archive the bound evidence under a per-variant directory. Quartus
        # writes every report to the same generic names, so every copy is first
        # checked against the in-ticket physical receipt.
        staged_report_dir = staging / report_dir.name
        staged_report_dir.mkdir()
        report_hashes: dict[str, str] = {}
        for name in required_reports:
            path = OUT / name
            archived = staged_report_dir / name
            shutil.copy2(path, archived)
            if post_fifo:
                if physical_receipt is None:
                    raise SystemExit("post-FIFO receipt state was lost")
                receipt_key = f"report_sha256.{name}"
                if digest(archived) != physical_receipt.get(receipt_key):
                    raise SystemExit(
                        f"post-FIFO report changed while it was being staged: {name}"
                    )
            report_hashes[f"{report_dir.name}/{name}"] = digest(archived)
            publication_hashes[report_dir / name] = digest(archived)
        publications.append((staged_report_dir, report_dir))

        staged_summary = staged_report_dir / "Arcade-TUnit.sta.summary"
        slacks = [
            float(value)
            for value in re.findall(
                r"^Slack\s*:\s*(-?\d+\.\d+)",
                staged_summary.read_text(encoding="utf-8", errors="replace"),
                re.MULTILINE,
            )
        ]
        if not slacks or min(slacks) < 0:
            raise SystemExit(
                "refusing to finalize absent or negative timing checks; rerun "
                "the ordered build and assemble gate"
            )
        if len(slacks) != expected_checks:
            raise SystemExit(
                "refusing to publish an incomplete timing summary: "
                f"got {len(slacks)} checks, expected {expected_checks}"
            )

        # An image whose placement cannot be reproduced from the recorded inputs
        # is not provenanced. Record the fitter-only seed override explicitly.
        seed_override = os.environ.get("TUNIT_SEED") or None
        artifact_manifest = {
            "schema": 1,
            "variant": args.variant,
            "ascal_policy": ascal_policy,
            "artifact_id": artifact_id or None,
            "diagnostic_overlay": diag_requested,
            "ab_reference_manifest": ab_reference_record,
            "fitter_seed_override": seed_override,
            "build_date": provenance.get("build_date"),
            "engineering": engineering,
            "artifact_class": "engineering-do-not-package" if engineering else "cabinet-test-candidate",
            "engineering_warning": engineering_warning,
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "shared_build_session": os.environ.get("FPGA_SESSION"),
            "source_provenance": provenance,
            "source_provenance_manifest_sha256": os.environ.get(
                "TUNIT_CANDIDATE_PROVENANCE_SHA256"
            ),
            "quartus_toolchain": provenance.get("quartus_toolchain"),
            "source_finalization_verification": source_finalization_verification,
            "framework_finalization_verification": framework_finalization_verification,
            "qualification_receipt": qualification_record,
            "physical_receipt": physical_receipt_record,
            "artifacts_sha256": artifact_hashes,
            "reports_sha256": report_hashes,
            "timing_checks": len(slacks),
            "worst_slack": min(slacks) if slacks else None,
        }
        staged_manifest = staging / target_manifest.name
        staged_manifest.write_text(
            json.dumps(artifact_manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        publications.append((staged_manifest, target_manifest))
        publication_hashes[target_manifest] = digest(staged_manifest)

        created: list[tuple[Path, int, int, bool]] = []
        try:
            ordered_publications = [
                publication
                for publication in publications
                if publication[1].suffix.lower() != ".rbf"
            ] + [
                publication
                for publication in publications
                if publication[1].suffix.lower() == ".rbf"
            ]
            for staged, target in ordered_publications:
                if staged.is_dir():
                    if artifact_id:
                        target.mkdir()
                        identity = target.stat(follow_symlinks=False)
                        created.append(
                            (target, identity.st_dev, identity.st_ino, True)
                        )
                        for source in staged.iterdir():
                            child = target / source.name
                            os.link(source, child)
                            child_identity = child.stat(follow_symlinks=False)
                            created.append(
                                (
                                    child,
                                    child_identity.st_dev,
                                    child_identity.st_ino,
                                    False,
                                )
                            )
                    else:
                        target.mkdir(parents=True, exist_ok=True)
                        for source in staged.iterdir():
                            shutil.copy2(source, target / source.name)
                else:
                    if artifact_id:
                        os.link(staged, target)
                        identity = target.stat(follow_symlinks=False)
                        created.append(
                            (target, identity.st_dev, identity.st_ino, False)
                        )
                    else:
                        copy_artifact(staged, target, exclusive=False)
            publication_failures: list[str] = []
            for path, device, inode, _ in created:
                try:
                    identity = path.stat(follow_symlinks=False)
                except FileNotFoundError:
                    publication_failures.append(f"{path.name}: disappeared")
                    continue
                except OSError:
                    publication_failures.append(f"{path.name}: disappeared")
                    continue
                if (identity.st_dev, identity.st_ino) != (device, inode):
                    publication_failures.append(
                        f"{path.name}: identity changed"
                    )
            for path, wanted in publication_hashes.items():
                if not path.is_file() or digest(path) != wanted:
                    publication_failures.append(f"{path.name}: hash changed")
            if digest(provenance_path) != provenance_digest:
                publication_failures.append(
                    "tunit_core.manifest.json: provenance changed"
                )
            if post_fifo and (
                physical_receipt_source is None
                or physical_receipt_digest is None
                or not physical_receipt_source.is_file()
                or digest(physical_receipt_source) != physical_receipt_digest
            ):
                publication_failures.append(
                    "physical receipt changed during artifact publication"
                )
            if publication_failures:
                raise RuntimeError(
                    "published artifact verification failed: "
                    + "; ".join(publication_failures)
                )
        except BaseException as exc:
            cleanup_failures: list[str] = []
            for path, device, inode, is_directory in reversed(created):
                try:
                    identity = path.stat(follow_symlinks=False)
                except FileNotFoundError:
                    continue
                except OSError as cleanup_exc:
                    cleanup_failures.append(f"{path.name}: {cleanup_exc}")
                    continue
                try:
                    if (identity.st_dev, identity.st_ino) != (device, inode):
                        cleanup_failures.append(
                            f"{path.name}: ownership changed; not removed"
                        )
                        continue
                    if is_directory:
                        path.rmdir()
                    else:
                        path.unlink()
                except OSError as cleanup_exc:
                    cleanup_failures.append(f"{path.name}: {cleanup_exc}")
            if cleanup_failures:
                raise SystemExit(
                    "artifact publication failed and exact-owned rollback was "
                    "incomplete: " + "; ".join(cleanup_failures)
                ) from exc
            raise
    print(
        f"ARTIFACT: variant={args.variant} manifest={target_manifest.name} "
        f"files={len(artifact_hashes)} reports={len(report_hashes)} "
        f"worst_slack={artifact_manifest['worst_slack']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
