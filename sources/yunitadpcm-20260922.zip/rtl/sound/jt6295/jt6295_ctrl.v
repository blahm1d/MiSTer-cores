/*  This file is part of JT6295.
    JT6295 program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    JT6295 program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with JT6295.  If not, see <http://www.gnu.org/licenses/>.

    Author: Jose Tejada Gomez. Twitter: @topapate
    Version: 1.0
    Date: 6-1-2020 */

module jt6295_ctrl(
    input                  rst,
    input                  clk,
    input                  cen4,
    input                  cen1,
    // CPU
    input                  wrn,
    input      [ 7:0]      din,
    // Channel address
    output reg [17:0]      start_addr,
    output reg [17:0]      stop_addr,
    // Attenuation
    output reg [ 3:0]      att,
    // ROM interface
    output     [ 9:0]      rom_addr,
    input      [ 7:0]      rom_data,
    input                  rom_ok,
    // Debug
    input                  debug_capture_enable,
    output reg [47:0]      debug_table_bytes,
    output reg [47:0]      debug_decode_bytes,
    output reg             debug_capture_done,
    // flow control
    output reg [ 3:0]      start,
    output reg [ 3:0]      stop,
    input      [ 3:0]      busy,
    input      [ 3:0]      ack,
    input                  zero
);

reg  last_wrn;
wire negedge_wrn  = !wrn && last_wrn;

// new request
reg [6:0] phrase;
reg       push, pull;
reg [3:0] ch, new_att;
reg       cmd;

always @(posedge clk) begin
    last_wrn <= wrn;
end

reg stop_clr;

`ifdef JT6295_DUMP
integer fdump;
integer ticks=0;
initial begin
    fdump=$fopen("jt6295.log");
end
always @(posedge zero) ticks<=ticks+1;
always @(posedge clk ) begin
    if( negedge_wrn ) begin
        if( !cmd && !din[7] ) begin
            $fwrite(fdump,"@%0d - Mute %1X\n", ticks, din[6:3]);
        end
        if( cmd ) begin
            $fwrite(fdump,"@%0d - Start %1X, phrase %X, Att %X\n",
                ticks, din[7:4], phrase, din[3:0] );
        end
    end
end
`endif


// Bus interface
always @(posedge clk) begin
    if( rst ) begin
        cmd      <= 1'b0;
        stop     <= 4'd0;
        ch       <= 4'd0;
        pull     <= 1'b1;
        phrase   <= 7'd0;
    end else begin
        if( cen4 ) begin
            stop <= stop & busy;
        end
        if( push ) pull <= 1'b0;
        if( negedge_wrn  ) begin // new write
            if( cmd ) begin // 2nd byte
                ch      <= din[7:4];
                new_att <= din[3:0];
                cmd     <= 1'b0;
                pull    <= 1'b1;
            end
            else if( din[7] ) begin // channel start
                phrase <= din[6:0];
                cmd    <= 1'b1; // wait for second byte
                stop   <= 4'd0;
            end else begin // stop data
                stop   <= din[6:3];
            end
        end
    end
end

reg [17:0] new_start;
reg [17:8] new_stop;
reg [ 2:0] st, addr_lsb;
reg        wrom;
reg        debug_capture_active;

assign rom_addr = { phrase, addr_lsb };

// Request phrase address
always @(posedge clk) begin
    if( rst ) begin
        st <= 3'd7;
        att <= 4'd0;
        start_addr <= 18'd0;
        stop_addr  <= 18'd0;
        start  <= 4'd0;
        push      <= 1'b0;
        addr_lsb  <= 3'b0;
        debug_table_bytes <= 48'h000000000000;
        debug_decode_bytes <= 48'h000000000000;
        debug_capture_active <= 1'b0;
        debug_capture_done <= 1'b0;
    end else begin
        if( negedge_wrn && cmd && debug_capture_enable && !debug_capture_active && !debug_capture_done ) begin
            debug_capture_active <= 1'b1;
            debug_table_bytes <= 48'h000000000000;
            debug_decode_bytes <= 48'h000000000000;
        end

        if(st!=3'd7) begin
            wrom <= 1'b0;
            if( !wrom && rom_ok ) begin
                st       <= st+3'd1;
                addr_lsb <= st;
                wrom     <= 1'b1;
            end
        end
        case(st)
            3'd7: begin
                start    <= start & ~ack;
                addr_lsb <= 3'd0;
                if(pull) begin
                    st       <= 3'd0;
                    wrom     <= 1'b1;
                    push     <= 1'b1;
                end
            end
            3'd0:;
            3'd1: begin
                new_start[17:16] <= rom_data[1:0];
                if( debug_capture_active ) debug_table_bytes[7:0] <= rom_data;
            end
            3'd2: begin
                new_start[15: 8] <= rom_data;
                if( debug_capture_active ) debug_table_bytes[15:8] <= rom_data;
            end
            3'd3: begin
                new_start[ 7: 0] <= rom_data;
                if( debug_capture_active ) debug_table_bytes[23:16] <= rom_data;
            end
            3'd4: begin
                new_stop [17:16] <= rom_data[1:0];
                if( debug_capture_active ) debug_table_bytes[31:24] <= rom_data;
            end
            3'd5: begin
                new_stop [15: 8] <= rom_data;
                if( debug_capture_active ) debug_table_bytes[39:32] <= rom_data;
            end
            3'd6: begin
                if( debug_capture_active ) begin
                    debug_table_bytes[47:40] <= rom_data;
                    debug_decode_bytes <= {
                        rom_data,
                        new_stop[15:8],
                        {6'b000000, new_stop[17:16]},
                        new_start[7:0],
                        new_start[15:8],
                        {6'b000000, new_start[17:16]}
                    };
                    debug_capture_active <= 1'b0;
                    debug_capture_done <= 1'b1;
                end
                start       <= ch;
                start_addr  <= new_start;
                stop_addr   <= {new_stop[17:8], rom_data} ;
                att         <= new_att;
                push        <= 1'b0;
            end
        endcase
    end
end

endmodule

