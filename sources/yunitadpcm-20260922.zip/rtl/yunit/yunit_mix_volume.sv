// yunit_mix_volume.sv -- OSD Music / SFX volume for the Williams ADPCM sound board.
//
// Port of the T-unit ADPCM board mixer (tunit_adpcm_board.sv, native-pipeline-20260914),
// which is the same Williams board (YM2151 + DAC + OKI6295). Grouping measured there on MK:
// music = YM2151 + DAC, speech / most effects = OKI -- the board mixes per chip, not per
// sound, so short FM-only effects follow the music slider.
//
// att: 0 = 100%, 1..8 = minus n eighths (8 = mute), any other value = 100%.
// Eight eighths is the identity: (x*8)>>>3 == x exactly for the magnitudes here (each sum is
// well inside +/-2^27), so with both sliders at 100% the mix is BIT-IDENTICAL to the
// unscaled release board. That is the backing-out property: default = release audio.
//
// The att codes come from the OSD in clk_sys; this module runs on the sound clock, so each
// code is double-synchronised. The codes are quasi-static (they move only on an OSD edit),
// so a code seen mid-transition for one sample is harmless.
`default_nettype none
module yunit_mix_volume (
  input  wire               clk,
  input  wire        [3:0]  music_att,
  input  wire        [3:0]  sfx_att,
  input  wire signed [31:0] music_sum,
  input  wire signed [31:0] sfx_sum,
  output wire signed [31:0] mix
);
  function automatic [3:0] eighths(input [3:0] att);
    case (att)
      4'd1: eighths = 4'd7;  4'd2: eighths = 4'd6;  4'd3: eighths = 4'd5;  4'd4: eighths = 4'd4;
      4'd5: eighths = 4'd3;  4'd6: eighths = 4'd2;  4'd7: eighths = 4'd1;  4'd8: eighths = 4'd0;
      default: eighths = 4'd8;
    endcase
  endfunction
  (* ASYNC_REG = "TRUE" *) reg [3:0] music_s1 = 4'd0, music_s2 = 4'd0;
  (* ASYNC_REG = "TRUE" *) reg [3:0] sfx_s1   = 4'd0, sfx_s2   = 4'd0;
  reg [3:0] music8 = 4'd8, sfx8 = 4'd8;
  always @(posedge clk) begin
    music_s1 <= music_att; music_s2 <= music_s1; music8 <= eighths(music_s2);
    sfx_s1   <= sfx_att;   sfx_s2   <= sfx_s1;   sfx8   <= eighths(sfx_s2);
  end
  assign mix = ((music_sum * $signed({1'b0, music8})) >>> 3) +
               ((sfx_sum   * $signed({1'b0, sfx8}))   >>> 3);
endmodule
`default_nettype wire
