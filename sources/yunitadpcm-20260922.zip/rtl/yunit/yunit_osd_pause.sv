// yunit_osd_pause.sv -- "Pause when OSD open".
//
// Engages and releases ONLY at the start of vblank. Y-unit autoerase clears each displayed
// row one line behind the beam, so a mid-frame freeze would show a page whose upper rows are
// already erased. At vblank, just after the page flip latches, the newly displayed page is
// intact. The board freezes the CPU (cpu_ce gated -- the live video counters run on the dot
// clock enable, so raster timing and sync are unaffected, exactly as the existing CPU-speed
// divider relies on) and suspends autoerase for the same span; the wrapper mutes audio.
//
// Correct for page-flipping titles (the back buffer was erased before the freeze, so resume
// draws onto a clean page). A single-buffered title retains only the rows not yet erased.
// Default Off: with the option Off pause_active is constantly 0 and the board is unchanged.
`default_nettype none
module yunit_osd_pause (
  input  wire clk,
  input  wire rst,
  input  wire enable,        // OSD option
  input  wire osd_open,      // hps_io OSD_STATUS
  input  wire vblank,        // board vblank, clk domain
  output reg  pause_active = 1'b0
);
  (* ASYNC_REG = "TRUE" *) reg osd_s1 = 1'b0, osd_s2 = 1'b0;
  reg vbl_q = 1'b0;
  always @(posedge clk) begin
    osd_s1 <= osd_open; osd_s2 <= osd_s1;
    vbl_q  <= vblank;
    if (rst)                   pause_active <= 1'b0;
    else if (vblank && !vbl_q) pause_active <= enable && osd_s2;
  end
endmodule
`default_nettype wire
