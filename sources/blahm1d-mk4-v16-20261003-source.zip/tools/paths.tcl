project_open zk4
create_timing_netlist -model slow
read_sdc
set local_reset [get_registers -nowarn {*|o_div_reset_na}]
set global_reset [get_registers -nowarn {*|o_reset_na}]
if {[get_collection_size $local_reset] != 1 || [get_collection_size $global_reset] != 1} {
 error "SCALER_RESET_GATE: expected distinct local divider and global scaler reset registers"
}
puts "SCALER_RESET_GATE=PASS distinct reset sources"
set bypass [get_registers -nowarn {*|o_h_poly_bypass_a.*}]
set adaptive [get_registers -nowarn {*|o_h_poly_phase_a.*}]
set delay [get_registers -nowarn {*|o_h_poly_phase_a2.*}]
set bypass_count [get_collection_size $bypass]
set adaptive_count [get_collection_size $adaptive]
set delay_count [get_collection_size $delay]
puts "COEFF_PROFILE_COUNTS bypass=$bypass_count adaptive=$adaptive_count delay=$delay_count"
if {$bypass_count != 40 || $adaptive_count != 0 || $delay_count != 40} {
 error "COEFF_PROFILE_GATE: disabled-adaptive profile must retain 40 bypass and delay bits and no dead adaptive bank"
}
puts "COEFF_PROFILE_GATE=PASS disabled-adaptive profile"
foreach temp {-40 100} {
 set_operating_conditions -model slow -speed 7 -temperature $temp -voltage 1100
 update_timing_netlist
 set paths [get_timing_paths -setup -from $bypass -to $delay -npaths 40 -nworst 1]
 set dests [list]
 foreach_in_collection p $paths {
  set src [get_node_info -name [get_path_info -from $p]]
  set dst [get_node_info -name [get_path_info -to $p]]
  set expected [string map {o_h_poly_bypass_a o_h_poly_phase_a2} $src]
  set slack [get_path_info -slack $p]
  if {$dst ne $expected || $slack <= 0.0} {error "COEFF_ROUTE_GATE: unexpected or failing coefficient route $src -> $dst: $slack"}
  lappend dests $dst
  puts "COEFF_ROUTE temperature=$temp from=$src to=$dst slack=$slack"
 }
 if {[llength [lsort -unique $dests]] != 40} {error "COEFF_ROUTE_GATE: expected all 40 unique coefficient destinations"}
 puts "COEFF_ROUTE_GATE=PASS temperature=$temp paths=40"
 report_timing -setup -from $bypass -to $delay -npaths 5 -detail full_path -stdout
 puts "CORNER temperature=$temp"
 report_timing -setup -npaths 40 -detail summary -stdout
 foreach_in_collection c [get_clocks *] {
  puts "CLOCK [get_clock_info -name $c]"
  report_timing -setup -to_clock $c -npaths 10 -detail full_path -stdout
 }
}
delete_timing_netlist
project_close
