from pathlib import Path
import json, math, re, sys
root = Path(__file__).resolve().parent
folder = Path(sys.argv[1])
report = (folder / "zk4.sta.rpt").read_text(errors="replace")
summary = (folder / "zk4.sta.summary").read_text(errors="replace")
rows = re.findall(r"Type\s*:\s*([^\r\n]+)\s+Slack\s*:\s*([^\r\n]+)\s+TNS\s*:\s*([^\r\n]+)", summary)
assert rows, "No complete STA rows"
assert len(rows)==len({t.strip() for t,s,n in rows}), "Duplicate STA check types"
actual = {t.strip() for t,s,n in rows}
expected = set(json.loads((root / "expected-sta-types.json").read_text()))
assert expected <= actual, "Missing corner/clock/check types: " + str(sorted(expected-actual))
bad=[]
for typ, slack, tns in rows:
    s, n = float(slack), float(tns)
    if not (math.isfinite(s) and math.isfinite(n) and s > 0 and n == 0): bad.append((typ,s,n))
print(json.dumps({"rows":len(rows),"failures":bad},indent=2))
assert not bad and "Timing requirements not met" not in report, "STA requirements unmet"
print("STA_GATE=PASS rows=" + str(len(rows)) + " all expected corner/clock checks present; positive slack; zero TNS")
