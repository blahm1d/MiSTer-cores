from pathlib import Path
import re,sys
text=Path(sys.argv[1]).read_text(errors='replace')
assert 'vga_out:vga_scaler_out' in text, 'Missing scaler output hierarchy'
bad=re.findall(r'vga_out:vga_(?:scaler_out|out)\|altshift_taps:[^\r\n]+',text)
assert not bad, 'VGA delay still inferred as RAM shift register: '+str(bad[:3])
print('SCALER_MAP_GATE=PASS no RAM shift replacement in either VGA output instance')

mask_rows=[line for line in text.splitlines() if "L_mask_dag" in line and "; MLAB" in line]
assert mask_rows, "Cached DAG mask was not inferred as MLAB storage"
print("DCS_MASK_MAP_GATE=PASS cached mask MLAB rows="+str(len(mask_rows)))

# Reject the actual V13 failing topology before spending time in fitting.
assert 'ascal:ascal' in text, 'Missing Avalon scaler hierarchy'
bad_scaler=re.findall(r'ascal:ascal\|altshift_taps:[^\r\n]+',text)
assert not bad_scaler, 'Avalon scaler delay inferred as RAM shift: '+str(bad_scaler[:3])
print('ASCAL_SHIFT_MAP_GATE=PASS no RAM shift replacement in Avalon scaler')

scaler_rows=[l for l in text.splitlines() if re.match(r'^;\s+\|ascal:ascal\|\s*;',l)]
assert len(scaler_rows)==1,'Missing or ambiguous scaler resource row'
memory_bits=int(scaler_rows[0].split(';')[4].strip().replace(',',''))
assert memory_bits==305152,'Coefficient copies changed scaler memory storage: '+str(memory_bits)
print('ASCAL_MEMORY_GATE=PASS unchanged 305152 memory bits')
