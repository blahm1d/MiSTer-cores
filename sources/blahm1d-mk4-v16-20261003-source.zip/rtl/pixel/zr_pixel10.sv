// zr_pixel10.sv -- v9 plus the S3B -> S4 QUEUE: the front stages run on their own stall, so destination reads for up to
// CRMAX pixels are in flight (v9: four) -- the DDR round trip is hidden instead of paid per blended pixel. See v10 block.
// Gouraud intensity is stepped with each pixel and carried through both queues.
// p_start / p_dpdx are signed integers for all four parameters (setup ext_*_i).
// zr_pixel8.sv -- Zeus 1 pixel pipe v8: v7's arithmetic (S1..S5, bit-identical) behind a LATENCY-TOLERANT front.
// Pass 1 of zeus1/OPTIMIZATION-PASSES-MK4.md measured v7 at 1.89 M clocks per 882 K frame on attract (destination
// reads: one pixel at a time, 1.08 M clocks waiting) and 1.38 M on hvmodel (texture fills: blocking, one line at a
// time, 666 K clocks waiting). v8 changes WHEN memory is asked, never WHAT a pixel computes:
//   * GENERATOR decoupled: G steps the extent (v7's S0 arithmetic, unchanged) into a per-pixel FIFO and runs ahead of
//     the blend pipe. While it runs ahead it PREFETCHES texture lines: a private copy of the cache tags (a HINT --
//     it is never trusted for data) says which lines to request. Prefetched lines land in the real cache exactly like
//     a demand fill ({valid, tag, data} in one write), and the main pipe's own S1 hit check stays authoritative: a
//     prefetch can make a pixel faster or slower, never different.
//   * FILL PORT pipelined: w0 is request / grant with IN-ORDER responses, many outstanding. Demand misses issue all
//     their lines back to back (priority demand > palette > prefetch); a palette load is 64 pipelined line reads, one
//     64-bit palette line written per response (the palette RAM is now 64 x 64 per read copy).
//   * DESTINATION READ pipelined: issued when a pixel enters S2 (its write decision is known there), answered into an
//     in-order FIFO that S4 consumes; up to CRMAX in flight. Ordering: v7's raw_hz already keeps an earlier pixel at
//     the same address out of S1..S5 when a pixel is issued; the read additionally waits while a POSTED colour write
//     to the same 32-bit word is still pending. MEMORY CONTRACT: a colour write accepted before a colour read is
//     accepted is visible to that read.
//   * Area: the pobj fields that were only decode inputs (blend, 32 bits) or constant between drains (rb) no longer
//     ride every stage. CONTRACT (unchanged in practice): rb_base changes only while idle (zr_render: RB waits drain).
// Cache coherence (unchanged from v7, recorded here): the texture cache is never invalidated after reset, so host
// writes to waveram 0 during rendering are not seen; MK4's windows measured so far never do this. Integration must
// invalidate (and drain prefetches) on a host waveram-0 write before that changes.
module zr_pixel10 #(parameter int CRMAX = 24, parameter bit PARTICLE_LIGHTING = 1'b0) (
  input  logic        clk,
  input  logic        rst,
  input  logic        ext_valid,
  output logic        ext_ready,
  input  logic signed [31:0] scan,
  input  logic signed [15:0] startx, stopx,
  input  logic [31:0] p_start [4], p_dpdx [4],
  input  logic [31:0] o_ctrl, o_alpha, o_blend,
  input  logic [15:0] o_solid, o_trans, o_texw, o_voff,
  input  logic signed [15:0] o_zoff,
  input  logic        o_dtest, o_dwrite,
  input  logic        o_shade, // sampled by front end; travels with the object
  input  logic [2:0]  o_texfmt,
  input  logic [31:0] o_texbase, o_palbase,
  input  logic [31:0] rb_base,
  input  logic        clr_valid,
  output logic        clr_ready,
  // r12: a RECT clear (clr_rect = 1) fills x in [clr_x0, clr_x1), y in [clr_y0, clr_y1) with colour clr_color and depth
  // 0x7fff -- MK4's full-screen debug quad (midzeus_v.cpp:575-620 -> render_poly_solid_fixedz :1444-1451 -> plot_depth
  // :153-158; zr_render5 derives the rectangle). clr_rect = 0: the MAME hack clear (:914-921) as before, colour 0 over
  // 400 x 256. A rect is non-empty and inside 400 x 256 (zr_render5 guarantees it).
  input  logic        clr_rect,
  input  logic [15:0] clr_color,
  input  logic [8:0]  clr_x0, clr_x1, clr_y0, clr_y1,
  output logic        clr_done,                    // r12 census: one pulse when a clear has issued its last write
  output logic        w0_req,                      // line read: request held until w0_gnt; responses in order
  output logic [20:0] w0_line,
  input  logic        w0_gnt,
  input  logic        w0_rvalid,
  input  logic [63:0] w0_data,
  output logic        cw_valid,
  input  logic        cw_ready,
  output logic [31:0] cw_addr,                     // byte offset of the 32-bit word (pixel pair)
  output logic [31:0] cw_data,
  output logic [1:0]  cw_mask,                     // bit0: low 16 (even x), bit1: high 16 (odd x)
  output logic [15:0] cw_z,                        // ddr-fullbe: the pixel's depth after this write (the word's depth lane) ...
  output logic        cw_zv,                       // ... valid: a clear (0x7fff) or a depth-writing pixel
  output logic        cr_req,                      // colour read: request held until cr_gnt; responses in order
  output logic [31:0] cr_addr,
  input  logic        cr_gnt,
  input  logic        cr_rvalid,
  input  logic [15:0] cr_data,
  input  logic [16:0] dbg_daddr,                   // pixel index y*400 + x
  output logic [15:0] dbg_ddata,
  output logic        idle,
  output logic [31:0] st_miss_lines, st_pal_loads, st_stall_clocks, st_pixels, st_pf_lines
);
  import fp32_pkg::*;
  // census counters count only when ZR_CENSUS is defined (every simulation runner); synthesis removes them
`ifdef ZR_CENSUS
  localparam logic [31:0] CEN = 32'd1;
`else
  localparam logic [31:0] CEN = 32'd0;
`endif
  localparam logic [31:0] OPQ2 = 32'h4b23cb00, OPQ3 = 32'h4b23dd00, OPQ5 = 32'hdd23dd00, ADD1 = 32'h40b68800,
                          ADD2 = 32'hc9b78800, MUL1 = 32'h4093c800;
  localparam int TLINES = 512;
  localparam logic [1:0] K_DEM = 2'd0, K_PAL = 2'd1, K_PF = 2'd2;

  function automatic logic [7:0] p5(input logic [4:0] b); return {b, b[4:2]}; endfunction
  function automatic logic signed [31:0] sdiv(input logic signed [31:0] a, input int sh);
    return (a < 0) ? -((-a) >>> sh) : (a >>> sh);
  endfunction
  // v7: the row term is a SHIFT, not a multiply (a textured quad's width is 512 >> texwshift, a power of two)
  function automatic logic [31:0] texoff(input logic [2:0] f, input logic signed [31:0] ty, input logic signed [31:0] tx, input logic [3:0] l2);
    case (f)
      3'd1, 3'd2: return 32'((sdiv(ty, 1) <<< (l2 + 4'd1)) + ((f == 3'd1 ? sdiv(tx, 3) : sdiv(tx, 2)) <<< 3) + ((ty & 1) <<< 2) + (f == 3'd1 ? (sdiv(tx, 1) & 3) : (tx & 3)));
      default:    return 32'((sdiv(ty, 2) <<< (l2 + 4'd2)) + ((f == 3'd3 ? sdiv(tx, 2) : sdiv(tx, 1)) <<< 3) + ((ty & 3) <<< 1) + (f == 3'd3 ? (sdiv(tx, 1) & 1) : (tx & 1)));
    endcase
  endfunction
  function automatic logic [3:0] log2w(input logic [15:0] w);
    logic [3:0] r; r = 4'd0;
    for (int i = 0; i < 16; i++) if (w[i]) r = 4'(i);
    return r;
  endfunction
  function automatic logic [1:0] tbank(input logic [2:0] f, input logic signed [31:0] ty, input logic signed [31:0] tx);
    logic signed [31:0] bx, by;
    case (f)
      3'd1: begin bx = sdiv(tx, 3); by = sdiv(ty, 1); end
      3'd2: begin bx = sdiv(tx, 2); by = sdiv(ty, 1); end
      3'd3: begin bx = sdiv(tx, 2); by = sdiv(ty, 2); end
      default: begin bx = sdiv(tx, 1); by = sdiv(ty, 2); end
    endcase
    return {by[0], bx[0]};
  endfunction
  function automatic logic [31:0] pix_word(input logic signed [31:0] yy, input logic [31:0] xx);
    return (32'(yy) << 10) | ((xx & 32'h1fe) << 1) | (xx & 32'h1);
  endfunction
  function automatic logic [1:0] low1(input logic [3:0] m);      // index of the lowest set bit
    return m[0] ? 2'd0 : m[1] ? 2'd1 : m[2] ? 2'd2 : 2'd3;
  endfunction

  // per-pixel object fields (travel with the pixel)
  typedef struct packed {
    logic dtest, dwrite, shade; logic [15:0] trans; logic [2:0] tfmt; logic solid; logic [15:0] solidc;
    logic [31:0] alpha;
    logic [2:0] bm; logic rdst;               // blend mode decoded once per extent (0 pass, 1 OPQ2/3, 2 OPQ5, 3 ADD1, 4 ADD2, 5 MUL1)
  } pobj_t;
  // one record per non-empty extent (G -> main): the object, the scanline, the palette it needs
  typedef struct packed { pobj_t o; logic signed [31:0] y; logic [31:0] palbase; logic texpal; } xrec_t;
  // one record per pixel (G -> main): exactly what v7's S0 handed S1, in its true widths
  //   depth: {neg, d[15:0]} is exact for S1's test (d >= 0 && d <= dcur, with d <= 0x7fff) and for the written d[15:0]
  //   i: s1_i[31:8] -- S2 only ever uses s1_i >>> 8
  typedef struct packed {
    logic [23:0] i; logic first; logic [16:0] x, da; logic dneg; logic [15:0] d; logic [7:0] fu, fv;
    logic [3:0][20:0] line; logic [3:0][1:0] bank; logic [3:0][2:0] byt; logic col;
  } prec_t;

  // ================= generator G (v7's S0 stepping, unchanged arithmetic) =================
  logic        g_on, g_first, g_solid;
  logic signed [31:0] curz, curu, curv, curi, dz, du, dv, di;
  logic [31:0] x, xend, texbase;
  logic [15:0] voff; logic signed [15:0] zoff; logic [2:0] tfmt; logic [3:0] texl2;
  logic [16:0] rowbase;

  logic signed [31:0] u0, v0, d0; logic [31:0] tabs [4]; logic [1:0] tb [4];
  always_comb begin
    u0 = curu >>> 8; v0 = 32'(voff) + (curv >>> 8);
    for (int k = 0; k < 4; k++) begin : ta
      logic signed [31:0] tu, tv;
      tu = u0 + ((k == 1 || k == 3) ? 32'sd1 : 32'sd0); tv = v0 + ((k == 2 || k == 3) ? 32'sd1 : 32'sd0);
      tabs[k] = texbase + texoff(tfmt, tv, tu, texl2);
      tb[k] = tbank(tfmt, tv, tu);
    end
    d0 = (curz >>> 16) + 32'(zoff); if (d0 > 32'sh7fff) d0 = 32'sh7fff;
  end
  prec_t g_rec;
  always_comb begin
    g_rec.i = curi[31:8];
    g_rec.first = g_first; g_rec.x = x[16:0]; g_rec.da = rowbase + 17'(x);
    g_rec.dneg = d0[31]; g_rec.d = d0[15:0]; g_rec.fu = curu[7:0]; g_rec.fv = curv[7:0];
    for (int k = 0; k < 4; k++) begin g_rec.line[k] = 21'(tabs[k] >> 3); g_rec.bank[k] = tb[k]; g_rec.byt[k] = tabs[k][2:0]; end
    g_rec.col = u0[0];
  end

  // pixel FIFO (M10K) and extent-record FIFO
  logic px_iv, px_ir, px_v, px_pop, px_empty; prec_t px;
  logic xr_iv, xr_ir, xr_v, xr_pop, xr_empty; xrec_t xr, xr_in;
  zr_rfifo #($bits(prec_t), 5) u_pxq (.clk, .rst, .in_valid(px_iv), .in_ready(px_ir), .in_data(g_rec),
    .out_valid(px_v), .out_ready(px_pop), .out_data(px), .empty(px_empty));
  zr_rfifo #($bits(xrec_t), 3) u_xrq (.clk, .rst, .in_valid(xr_iv), .in_ready(xr_ir), .in_data(xr_in),
    .out_valid(xr_v), .out_ready(xr_pop), .out_data(xr), .empty(xr_empty));

  // ---- prefetch: private tag copy (hint), G1 = the pixel G just pushed, issuing its missing lines one per clock ----
  logic [8:0]  pt_ri [4]; logic [12:0] pt_q [4];
  logic        pt_we [4]; logic [8:0] pt_wa [4]; logic [12:0] pt_wd [4];
  logic        fw_v [4]; logic [8:0] fw_a [4]; logic [12:0] fw_d [4];     // the write each bank took last edge
  logic        g1_new, g1_solid; logic [3:0][20:0] g1_line; logic [3:0][1:0] g1_bank; logic [3:0] g1_rem;
  logic [3:0]  g1_mask, g1_after; logic [1:0] g1_k; logic g1_issue, g1_free, g_adv, g_last;
  logic        pfq_iv, pfq_ir, pfq_v, pfq_pop; logic [22:0] pfq_d; logic [2:0] pfq_cnt;
  zr_fifo #(23, 2) u_pfq (.clk, .rst, .in_valid(pfq_iv), .in_ready(pfq_ir), .in_data({g1_line[g1_k], g1_bank[g1_k]}),
    .out_valid(pfq_v), .out_ready(pfq_pop), .out_data(pfq_d), .count(pfq_cnt));
  always_comb begin
    g1_mask = g1_rem;
    if (g1_new) begin
      g1_mask = '0;
      for (int k = 0; k < 4; k++) begin : pm
        logic [1:0] b; logic [12:0] tv; logic dup;
        b = g1_bank[k];
        tv = (fw_v[b] && fw_a[b] == g1_line[k][8:0]) ? fw_d[b] : pt_q[b];
        dup = 1'b0; for (int j = 0; j < 4; j++) if (j < k && g1_bank[j] == b) dup = 1'b1;
        g1_mask[k] = !g1_solid && !dup && !(tv[12] && tv[11:0] == g1_line[k][20:9]);
      end
    end
    g1_k = low1(g1_mask);
    g1_issue = (g1_mask != 0) && pfq_ir;
    g1_after = g1_mask & ~(g1_issue ? (4'b1 << g1_k) : 4'b0);
    g1_free = (g1_after == 0);
    g_adv  = g_on && px_ir && g1_free;
    g_last = g_adv && (x + 32'd1 >= xend);
  end
  assign pfq_iv = g1_issue;
  assign px_iv = g_adv;

  // ================= depth RAM: 25,600 x 64, 16-bit lane enables =================
  logic        dp_we; logic [14:0] dp_wa, dp_ra; logic [63:0] dp_wd; logic [3:0] dp_wl; logic [63:0] dp_q;
  zr_depth64 u_depth (.clk, .we(dp_we), .lanes(dp_wl), .waddr(dp_wa), .wdata(dp_wd), .raddr(dp_ra), .rdata(dp_q));
  logic [1:0] dbg_lane_r;
  always_ff @(posedge clk) dbg_lane_r <= dbg_daddr[1:0];
  assign dbg_ddata = dp_q[16*dbg_lane_r +: 16];

  // ================= texture cache =================
  // one simple-dual-port M10K per bank holding {valid, tag, data}; valid bits cleared by a sweep after reset. A read
  // that meets a write to the same entry in the same clock is treated as a MISS (tc_col) -- M10K mixed-port
  // read-during-write data is not relied on.
  logic [8:0]  tc_ri [4]; logic [63:0] tc_q [4]; logic [11:0] tc_tq [4]; logic tc_vq [4]; logic tc_col [4];
  logic        tc_we; logic [1:0] tc_wb; logic [8:0] tc_wi; logic [63:0] tc_wd; logic [11:0] tc_wt;
  logic        tc_init; logic [8:0] tc_ii;
  genvar gb;
  generate for (gb = 0; gb < 4; gb++) begin : g_tc
    logic [76:0] q; logic we; logic [8:0] wa; logic [76:0] wd;
    assign we = tc_init || (tc_we && tc_wb == 2'(gb));
    assign wa = tc_init ? tc_ii : tc_wi;
    assign wd = tc_init ? 77'd0 : {1'b1, tc_wt, tc_wd};
    zr_sdp #(77, 9) u_bank (.clk, .we, .waddr(wa), .wdata(wd), .raddr(tc_ri[gb]), .rdata(q));
    assign tc_vq[gb] = q[76]; assign tc_tq[gb] = q[75:64]; assign tc_q[gb] = q[63:0];
    always_ff @(posedge clk) tc_col[gb] <= we && wa == tc_ri[gb];
    // the prefetcher's private tag copy
    logic ptwe; logic [8:0] ptwa; logic [12:0] ptwd;
    assign ptwe = tc_init || pt_we[gb]; assign ptwa = tc_init ? tc_ii : pt_wa[gb]; assign ptwd = tc_init ? 13'd0 : pt_wd[gb];
    zr_sdp #(13, 9) u_ptag (.clk, .we(ptwe), .waddr(ptwa), .wdata(ptwd), .raddr(pt_ri[gb]), .rdata(pt_q[gb]));
    always_ff @(posedge clk) begin fw_v[gb] <= ptwe; fw_a[gb] <= ptwa; fw_d[gb] <= ptwd; end
  end endgenerate
  always_ff @(posedge clk)
    if (rst) begin tc_init <= 1'b1; tc_ii <= '0; end
    else if (tc_init) begin if (tc_ii == 9'(TLINES - 1)) tc_init <= 1'b0; tc_ii <= tc_ii + 9'd1; end
  always_comb begin
    for (int b = 0; b < 4; b++) pt_ri[b] = '0;
    for (int k = 0; k < 4; k++) pt_ri[tb[k]] = 9'(tabs[k] >> 3);
  end

  // ================= palette: 64 lines x 64 bits per read copy =================
  logic [63:0] pal_mem [4][64]; logic [7:0] pal_ri [4]; logic [63:0] pal_q64 [4]; logic [1:0] pal_sel [4]; logic [15:0] pal_q [4];
  logic        pal_we; logic [5:0] pal_wi; logic [63:0] pal_wd;
  always_ff @(posedge clk) begin
    for (int k = 0; k < 4; k++) begin pal_q64[k] <= pal_mem[k][pal_ri[k][7:2]]; pal_sel[k] <= pal_ri[k][1:0]; end
    if (pal_we) for (int k = 0; k < 4; k++) pal_mem[k][pal_wi] <= pal_wd;
  end
  always_comb for (int k = 0; k < 4; k++) pal_q[k] = pal_q64[k][16*pal_sel[k] +: 16];

  // ================= pipeline =================
  logic        s1_ok; logic [31:0] s1_x; logic signed [31:0] s1_y; logic [16:0] s1_da; logic signed [31:0] s1_depth;
  logic [7:0]  s1_fu, s1_fv; logic [23:0] s1_i24; pobj_t s1_o;
  logic [20:0] s1_line [4]; logic [1:0] s1_bank [4]; logic [2:0] s1_byte [4]; logic s1_nib [4]; logic s1_col [4];
  logic        s2_ok, s2_write; logic [31:0] s2_x; logic signed [31:0] s2_y; logic [16:0] s2_da; logic [15:0] s2_depth;
  logic [7:0]  s2_fu, s2_fv, s2_tex [4]; logic [31:0] s2_i8; pobj_t s2_o;
  logic        s3_ok, s3_write, s3_fresh; logic [31:0] s3_x; logic signed [31:0] s3_y; logic [16:0] s3_da; logic [15:0] s3_depth;
  logic [7:0]  s3_fu, s3_fv; logic [31:0] s3_i8; logic [15:0] s3_pal [4]; pobj_t s3_o;
  logic        s4_ok, s4_write; logic [31:0] s4_x; logic signed [31:0] s4_y; logic [16:0] s4_da; logic [15:0] s4_depth;
  logic [7:0]  s4_sr, s4_sg, s4_sb; logic [31:0] s4_i8; pobj_t s4_o;
  logic        s4_dst_have; logic [15:0] s4_dst;
  logic        s3b_ok, s3b_write; logic [31:0] s3b_x; logic signed [31:0] s3b_y; logic [16:0] s3b_da;
  logic [15:0] s3b_depth; logic [31:0] s3b_i8; pobj_t s3b_o; logic [7:0] s3b_fv;
  logic [17:0] s3b_top [3], s3b_bot [3]; logic [7:0] s3b_solid [3];
  logic        s5_ok, s5_write; logic [31:0] s5_x; logic signed [31:0] s5_y; logic [16:0] s5_da; logic [15:0] s5_depth;
  logic s5_shade; logic [7:0] s5_factor;
  pobj_t       s5_o; logic [31:0] s5_a [3]; logic [7:0] s5_src [3], s5_dst [3];

  // main-side extent state: the object and scanline of the extent whose pixels S0 is issuing
  pobj_t m_obj; logic signed [31:0] m_y; logic [31:0] pal_loaded, palbase_m;
  pobj_t cur_o; logic signed [31:0] cur_y; logic needpal;
  always_comb begin
    cur_o = px.first ? xr.o : m_obj; cur_y = px.first ? xr.y : m_y;
    needpal = px_v && px.first && xr_v && xr.texpal && xr.palbase != pal_loaded;
  end

  // ================= v10: the S3B -> S4 queue =================
  // v9 measured on DDR (zr_rsys, attract): a destination read could only be in flight for the pixels in S2..S4 (four),
  // so each blended pixel paid most of the DDR round trip -- 657 K -> 986 K pixel-busy clocks per frame at 12-clock
  // latency, 1.25 M at 20. The front stages (S0..S3B: texels, palette, bilinear) do not depend on the destination,
  // so they now run on their OWN stall and hand pixels to S4 through a 16-deep queue (M10K); up to CRMAX reads are in
  // flight. A pixel in the queue has not written yet, so the same-pixel guard (raw_hz) covers it through a shadow
  // of the queued pixels' depth addresses.
  logic [7:0] src_r, src_g, src_b;
  typedef struct packed {
    logic [31:0] i8; logic write; logic [15:0] x, y; logic [16:0] da; logic [15:0] depth; pobj_t o; logic [7:0] sr, sg, sb;
  } qrec_t;
  qrec_t q_in, q_out; logic q_push, q_ir, q_v, q_pop, q_empty;
  always_comb begin
    q_in.write = s3b_write; q_in.x = s3b_x[15:0]; q_in.y = s3b_y[15:0]; q_in.da = s3b_da; q_in.depth = s3b_depth;
    q_in.i8 = s3b_i8; q_in.o = s3b_o; q_in.sr = src_r; q_in.sg = src_g; q_in.sb = src_b;
  end
  zr_rfifo #($bits(qrec_t), 4) u_q (.clk, .rst, .in_valid(q_push), .in_ready(q_ir), .in_data(q_in),
    .out_valid(q_v), .out_ready(q_pop), .out_data(q_out), .empty(q_empty));
  // shadow of the queued depth addresses (the rfifo holds up to 16 + 3 in its output stage: 32 slots is room)
  logic [16:0] qs_da [32]; logic qs_v [32]; logic [4:0] qs_w, qs_r;
  always_ff @(posedge clk)
    if (rst) begin qs_w <= '0; qs_r <= '0; for (int k = 0; k < 32; k++) qs_v[k] <= 1'b0; end
    else begin
      if (q_push) begin qs_da[qs_w] <= s3b_da; qs_v[qs_w] <= 1'b1; qs_w <= qs_w + 5'd1; end
      if (q_pop) begin qs_v[qs_r] <= 1'b0; qs_r <= qs_r + 5'd1; end
    end
  logic q_hz;
  always_comb begin
    q_hz = 1'b0;
    for (int k = 0; k < 32; k++) if (qs_v[k] && qs_da[k] == px.da) q_hz = 1'b1;
  end

  // read-after-write on the same PIXEL: S1..S5, plus the depth write S5 retired last clock
  logic [16:0] dp_pix; logic dp_pend;
  logic raw_hz; assign raw_hz = (s1_ok && s1_da == px.da) || (s2_ok && s2_da == px.da) || (s3_ok && s3_da == px.da) ||
                                (s3b_ok && s3b_da == px.da) || (s4_ok && s4_da == px.da) || (s5_ok && s5_da == px.da) ||
                                (dp_pend && dp_pix == px.da) || q_hz;

  // oracle2 (MAME d1e9f7db, #16225 zeus_apply_color_key): the colour key tests the NEAREST of the four taps (u / v fraction
  // > 0x80 rounds up, ties down: index {fv > 0x80, fu > 0x80}), and every keyed tap takes the nearest texel before the
  // palette / bilinear stages (s1_texk). 0.289 keyed texels[0] only -> transparent (pure green) neighbours bled into edges.
  logic s1_hit [4]; logic s1_allhit; logic [7:0] s1_tex [4], s1_texk [4], s1_near; logic [15:0] s1_dcur; logic s1_pass, s1_wr;
  logic [1:0] s1_ni;
  always_comb begin
    s1_allhit = 1'b1;
    for (int k = 0; k < 4; k++) begin : hc
      logic [7:0] byt;
      s1_hit[k] = tc_vq[s1_bank[k]] && tc_tq[s1_bank[k]] == s1_line[k][20:9] && !tc_col[s1_bank[k]];
      if (s1_ok && !s1_o.solid && !s1_hit[k]) s1_allhit = 1'b0;
      byt = tc_q[s1_bank[k]][8*s1_byte[k] +: 8];
      s1_tex[k] = s1_nib[k] ? (s1_col[k] ? (byt >> 4) : (byt & 8'h0f)) : byt;
    end
    s1_ni = {s1_fv > 8'h80, s1_fu > 8'h80};
    s1_near = s1_tex[s1_ni];
    for (int k = 0; k < 4; k++) s1_texk[k] = ({8'd0, s1_tex[k]} == s1_o.trans) ? s1_near : s1_tex[k];
    s1_dcur = dp_q[16*s1_da[1:0] +: 16];
    s1_pass = !s1_o.dtest || (s1_depth >= 0 && s1_depth <= $signed({16'd0, s1_dcur}));
    s1_wr = s1_pass && (s1_o.solid || (s1_o.tfmt != 3'd0 && {8'd0, s1_near} != s1_o.trans));
  end

  // ================= control =================
  logic fill_on, pl_on, pal_pend, clr_on; logic [1:0] rp_cnt; logic replay;
  assign replay = (rp_cnt != 2'd0);
  logic [3:0] fill_mask, fill_iss; logic [2:0] dem_out;
  logic [6:0] pl_iss; logic [5:0] pl_rcv;
  logic [14:0] clr_d; logic [8:0] clr_cx, clr_cy; logic clr_dd, clr_cd;
  // r12 rect clear: the depth side walks (row clr_dy, word clr_dw), clr_d = row base clr_drow + word; colour walks pairs
  logic [8:0] clr_dy, cl_x0, cl_x1m, cl_y1m; logic [6:0] clr_dw, cl_w0, cl_w1; logic [15:0] cl_col; logic [14:0] clr_drow;

  // ---- w0 port: one request register, a kind FIFO for the in-order responses ----
  logic w0r_v; logic [1:0] w0r_kind, w0r_bank; logic [8:0] w0r_set; logic [11:0] w0r_tag;
  logic kq_v; logic [24:0] kq_d; logic [4:0] kq_cnt; logic kq_ir;
  zr_fifo #(25, 4) u_kq (.clk, .rst, .in_valid(w0r_v && w0_gnt), .in_ready(kq_ir), .in_data({w0r_kind, w0r_bank, w0r_set, w0r_tag}),
    .out_valid(kq_v), .out_ready(w0_rvalid), .out_data(kq_d), .count(kq_cnt));
  assign w0_req = w0r_v;
  logic w0_load_ok, dem_src, pal_src; logic [1:0] dem_k;
  always_comb begin
    w0_load_ok = (!w0r_v || w0_gnt) && kq_cnt <= 5'd13;
    dem_src = fill_on && ((fill_mask & ~fill_iss) != 0);
    dem_k = low1(fill_mask & ~fill_iss);
    pal_src = pl_on && pl_iss != 7'd64;
  end
  assign pfq_pop = w0_load_ok && !dem_src && !pal_src && pfq_v;
  logic dem_issue, dem_resp; assign dem_issue = w0_load_ok && dem_src;
  assign dem_resp = w0_rvalid && kq_d[24:23] == K_DEM;

  // ---- colour read port: one request register, an in-order response FIFO ----
  // v10: up to CRMAX destination reads in flight -- the pipe S2..S3B plus the S3B->S4 queue -- answered into an M10K
  // FIFO (32 deep, never overfull: cr_out <= CRMAX < 32)
  logic crr_v; logic [5:0] cr_out; logic crq_v, crq_pop, crq_empty; logic [15:0] crq_d;
  zr_rfifo #(16, 5) u_crq (.clk, .rst, .in_valid(cr_rvalid), .in_ready(), .in_data(cr_data),
    .out_valid(crq_v), .out_ready(crq_pop), .out_data(crq_d), .empty(crq_empty));
  assign cr_req = crr_v;
  logic [31:0] s1_craddr; assign s1_craddr = rb_base + (pix_word(s1_y, s1_x) << 1);
  logic cr_need, cr_block;
  assign cr_need  = s1_ok && s1_wr && s1_o.rdst;
  assign cr_block = cr_need && ((crr_v && !cr_gnt) || cr_out >= 6'(CRMAX) || (cw_valid && cw_addr == (s1_craddr & ~32'd3)));

  logic s4_needdst, s4_block, s5_block, stall, fstall, bstall, s0_go;
  assign s4_needdst = s4_ok && s4_write && s4_o.rdst && !s4_dst_have;
  assign s4_block = s4_needdst;                                           // S4 waits only for the destination read
  assign s5_block = s5_ok && s5_write && cw_valid && !cw_ready;          // S5 waits only for the write port
  // v10: the front stages (S0..S3B) stall on texels, fills, the read port and a full queue; the back (S4, S5) on the
  // destination read and the write port
  assign fstall = (s1_ok && !s1_allhit) || fill_on || replay || cr_block || (s3b_ok && !q_ir);
  assign bstall = s4_block || s5_block;
  assign stall = fstall;
  assign q_push = s3b_ok && !fstall;
  assign q_pop = q_v && !bstall;
  assign s0_go = px_v && (!px.first || xr_v) && !stall && !raw_hz && !pl_on && !pal_pend && !needpal;
  assign px_pop = s0_go;
  assign xr_pop = s0_go && px.first;
  logic w0_quiet; assign w0_quiet = !w0r_v && !kq_v && !pfq_v;
  logic pipe_empty; assign pipe_empty = !g_on && !g1_new && g1_rem == 0 && px_empty && xr_empty &&
                                        !s1_ok && !s2_ok && !s3_ok && !s3b_ok && !s4_ok && !s5_ok &&
                                        !fill_on && !pl_on && !pal_pend && !crr_v && cr_out == 0 && w0_quiet && q_empty;
  assign ext_ready = (!g_on || g_last) && xr_ir && !clr_on && !tc_init;
  assign clr_ready = pipe_empty && !clr_on;
  assign idle = pipe_empty && !clr_on && !cw_valid;
  assign xr_iv = ext_valid && ext_ready && (startx < stopx);
  always_comb begin
    xr_in.o.dtest = o_dtest; xr_in.o.dwrite = o_dwrite; xr_in.o.trans = o_trans; xr_in.o.tfmt = o_texfmt;
    xr_in.o.solid = (o_ctrl & 32'h000c0000) == 32'h000c0000; xr_in.o.solidc = o_solid; xr_in.o.alpha = o_alpha;
    xr_in.o.bm = (o_blend == OPQ2 || o_blend == OPQ3) ? 3'd1 : (o_blend == OPQ5) ? 3'd2 : (o_blend == ADD1) ? 3'd3 :
                 (o_blend == ADD2) ? 3'd4 : (o_blend == MUL1) ? 3'd5 : 3'd0;
    xr_in.o.shade = o_shade;
    xr_in.o.rdst = (o_blend & 32'h00800000) != 0;
    xr_in.y = scan; xr_in.palbase = o_palbase;
    xr_in.texpal = (o_ctrl & 32'h000c0000) != 32'h000c0000 && o_texfmt != 3'd0;
  end

  always_comb begin
    dp_ra = dbg_daddr[16:2];
    for (int b = 0; b < 4; b++) tc_ri[b] = '0;
    if (s1_ok && (stall || !s0_go)) begin
      dp_ra = s1_da[16:2];
      for (int k = 0; k < 4; k++) tc_ri[s1_bank[k]] = s1_line[k][8:0];
    end
    if (s0_go) begin
      dp_ra = px.da[16:2];
      for (int k = 0; k < 4; k++) tc_ri[px.bank[k]] = px.line[k][8:0];
    end
    for (int k = 0; k < 4; k++) pal_ri[k] = s2_tex[k];
  end

  // private-tag writes: the prefetcher's request (G1) first, a demand request's line otherwise (hint only)
  always_comb begin
    for (int b = 0; b < 4; b++) begin pt_we[b] = 1'b0; pt_wa[b] = '0; pt_wd[b] = '0; end
    if (dem_issue) begin pt_we[s1_bank[dem_k]] = 1'b1; pt_wa[s1_bank[dem_k]] = s1_line[dem_k][8:0]; pt_wd[s1_bank[dem_k]] = {1'b1, s1_line[dem_k][20:9]}; end
    if (g1_issue) begin pt_we[g1_bank[g1_k]] = 1'b1; pt_wa[g1_bank[g1_k]] = g1_line[g1_k][8:0]; pt_wd[g1_bank[g1_k]] = {1'b1, g1_line[g1_k][20:9]}; end
  end

  // r11: declared BEFORE the pipeline block that reads them (S3 / S4 / S5 datapath results below). SystemVerilog needs
  // declaration before use; Verilator resolves the forward reference, Quartus 17.0 is not guaranteed to (zr_render5's
  // forward-referenced oq_pop was synthesised undriven -- render/cons/check_decl_order.py).
  logic [17:0] u_top [3], u_bot [3]; logic [7:0] u_solid [3];
  logic [31:0] a_prod [3]; logic [7:0] a_src [3], a_dst [3];
  logic [15:0] s5_color;

  always_ff @(posedge clk) begin
    tc_we <= 1'b0; pal_we <= 1'b0; dp_we <= 1'b0; dp_pend <= 1'b0;
    if (rst) begin
      g_on <= 1'b0; g1_new <= 1'b0; g1_rem <= '0;
      s1_ok <= 1'b0; s2_ok <= 1'b0; s3_ok <= 1'b0; s3b_ok <= 1'b0; s4_ok <= 1'b0; s5_ok <= 1'b0; fill_on <= 1'b0; rp_cnt <= 2'd0;
      clr_on <= 1'b0; clr_done <= 1'b0; cw_valid <= 1'b0; pl_on <= 1'b0; pal_pend <= 1'b0; pal_loaded <= 32'hffffffff;
      w0r_v <= 1'b0; dem_out <= '0; crr_v <= 1'b0; cr_out <= '0; s4_dst_have <= 1'b0;
      st_miss_lines <= 0; st_pal_loads <= 0; st_stall_clocks <= 0; st_pixels <= 0; st_pf_lines <= 0;
    end else begin
      if (cw_valid && cw_ready) cw_valid <= 1'b0;
      if (fstall || bstall) st_stall_clocks <= st_stall_clocks + CEN;

      // ---------- clear: depth 4 px/clk on chip, colour 2 px/clk to memory, in parallel ----------
      clr_done <= 1'b0;
      if (clr_valid && clr_ready) begin : cst
        logic [8:0] x0, x1m, y0, y1m;                                // first / last x and y (inclusive)
        x0 = clr_rect ? clr_x0 : 9'd0; x1m = clr_rect ? clr_x1 - 9'd1 : 9'd399;
        y0 = clr_rect ? clr_y0 : 9'd0; y1m = clr_rect ? clr_y1 - 9'd1 : 9'd255;
        clr_on <= 1'b1; clr_dd <= 1'b0; clr_cd <= 1'b0;
        cl_x0 <= x0; cl_x1m <= x1m; cl_y1m <= y1m; cl_col <= clr_rect ? clr_color : 16'd0;
        cl_w0 <= 7'(x0 >> 2); cl_w1 <= 7'(x1m >> 2);
        clr_dy <= y0; clr_dw <= 7'(x0 >> 2); clr_drow <= 15'(y0) * 15'd100; clr_d <= 15'(y0) * 15'd100 + 15'(x0 >> 2);
        clr_cy <= y0; clr_cx <= {x0[8:1], 1'b0};
      end
      else if (clr_on) begin
        if (!clr_dd) begin : cdp
          logic [1:0] lo, hi; logic [3:0] m;
          lo = (clr_dw == cl_w0) ? cl_x0[1:0] : 2'd0; hi = (clr_dw == cl_w1) ? cl_x1m[1:0] : 2'd3;
          for (int l = 0; l < 4; l++) m[l] = (2'(l) >= lo) && (2'(l) <= hi);
          dp_we <= 1'b1; dp_wl <= m; dp_wa <= clr_d; dp_wd <= {4{16'h7fff}};
          if (clr_dw == cl_w1) begin
            if (clr_dy == cl_y1m) clr_dd <= 1'b1;
            else begin clr_dy <= clr_dy + 9'd1; clr_dw <= cl_w0; clr_drow <= clr_drow + 15'd100; clr_d <= clr_drow + 15'd100 + 15'(cl_w0); end
          end else begin clr_dw <= clr_dw + 7'd1; clr_d <= clr_d + 15'd1; end
        end
        if (!clr_cd && (!cw_valid || cw_ready)) begin
          cw_valid <= 1'b1; cw_data <= {cl_col, cl_col}; cw_mask <= {clr_cx + 9'd1 <= cl_x1m, clr_cx >= cl_x0};
          cw_addr <= rb_base + (pix_word(32'(clr_cy), 32'(clr_cx)) << 1);
          cw_z <= 16'h7fff; cw_zv <= 1'b1;                            // MAME: depth 0x7fff (clear :916-918, debug quad zoffset :617)
          if (clr_cx + 9'd1 >= cl_x1m) begin clr_cx <= {cl_x0[8:1], 1'b0}; if (clr_cy == cl_y1m) clr_cd <= 1'b1; else clr_cy <= clr_cy + 9'd1; end
          else clr_cx <= clr_cx + 9'd2;
        end
        if (clr_dd && clr_cd) begin clr_on <= 1'b0; clr_done <= 1'b1; end
      end

      // ---------- generator ----------
      g1_rem <= g1_after; g1_new <= g_adv;
      if (g_adv) begin
        for (int k = 0; k < 4; k++) begin g1_line[k] <= 21'(tabs[k] >> 3); g1_bank[k] <= tb[k]; end
        g1_solid <= g_solid;
        curz <= curz + dz; curu <= curu + du; curv <= curv + dv; curi <= curi + di;
        x <= x + 32'd1; g_first <= 1'b0;
        if (g_last) g_on <= 1'b0;
      end
      if (ext_valid && ext_ready) begin : ld
        logic e;
        // sound-area L6: p_start / p_dpdx [0..3] arrive ALREADY truncated to int (zr_setup9 ext_*_i: fp_f2i_trunc
        // applied in setup's B stage as each parameter is produced) -- the six parallel converters are gone
        curz <= $signed(p_start[0]); curu <= $signed(p_start[1]); curv <= $signed(p_start[2]); curi <= $signed(p_start[3]);
        dz <= $signed(p_dpdx[0]); du <= $signed(p_dpdx[1]); dv <= $signed(p_dpdx[2]); di <= $signed(p_dpdx[3]);
        x <= 32'($signed(startx)); xend <= 32'($signed(stopx)); rowbase <= 17'(scan * 400);
        texl2 <= log2w(o_texw); voff <= o_voff; zoff <= o_zoff; tfmt <= o_texfmt; texbase <= o_texbase;
        g_solid <= (o_ctrl & 32'h000c0000) == 32'h000c0000;
        g_on <= (startx < stopx); g_first <= 1'b1;
      end

      // ---------- palette: an extent start that needs a different palette waits for S2/S3, then 64 line reads ----------
      if (needpal && !pal_pend && !pl_on) begin pal_pend <= 1'b1; pal_loaded <= xr.palbase; palbase_m <= xr.palbase; st_pal_loads <= st_pal_loads + CEN; end
      if (pal_pend && !s1_ok && !s2_ok && !(s3_ok && s3_fresh)) begin pal_pend <= 1'b0; pl_on <= 1'b1; pl_iss <= '0; pl_rcv <= '0; end

      // ---------- w0 request register (demand > palette > prefetch) ----------
      if (w0_load_ok) begin
        if (dem_src) begin
          w0r_v <= 1'b1; w0_line <= s1_line[dem_k]; w0r_kind <= K_DEM; w0r_bank <= s1_bank[dem_k];
          w0r_set <= s1_line[dem_k][8:0]; w0r_tag <= s1_line[dem_k][20:9]; fill_iss[dem_k] <= 1'b1;
        end else if (pal_src) begin
          w0r_v <= 1'b1; w0_line <= 21'((palbase_m >> 3) + 32'(pl_iss)); w0r_kind <= K_PAL; pl_iss <= pl_iss + 7'd1;
        end else if (pfq_v) begin
          w0r_v <= 1'b1; w0_line <= pfq_d[22:2]; w0r_kind <= K_PF; w0r_bank <= pfq_d[1:0];
          w0r_set <= pfq_d[10:2]; w0r_tag <= pfq_d[22:11];
        end else w0r_v <= 1'b0;
      end else if (w0_gnt) w0r_v <= 1'b0;
      dem_out <= dem_out + 3'(dem_issue) - 3'(dem_resp);

      // ---------- w0 responses, in order ----------
      if (w0_rvalid) begin
        if (kq_d[24:23] == K_PAL) begin
          pal_we <= 1'b1; pal_wi <= pl_rcv; pal_wd <= w0_data; pl_rcv <= pl_rcv + 6'd1;
          if (pl_rcv == 6'd63) pl_on <= 1'b0;
        end else begin
          tc_we <= 1'b1; tc_wb <= kq_d[22:21]; tc_wi <= kq_d[20:12]; tc_wd <= w0_data; tc_wt <= kq_d[11:0];
          if (kq_d[24:23] == K_DEM) st_miss_lines <= st_miss_lines + CEN; else st_pf_lines <= st_pf_lines + CEN;
        end
      end

      // ---------- demand fill: every missing line of the S1 pixel, back to back, then replay ----------
      if (rp_cnt != 2'd0) rp_cnt <= rp_cnt - 2'd1;
      if (s1_ok && !s1_allhit && !fill_on && !replay) begin : fs
        logic [3:0] m;
        for (int k = 0; k < 4; k++) begin : fk
          logic dup; dup = 1'b0;
          for (int j = 0; j < 4; j++) if (j < k && s1_bank[j] == s1_bank[k] && s1_line[j] == s1_line[k]) dup = 1'b1;
          m[k] = !s1_hit[k] && !dup;
        end
        fill_on <= 1'b1; fill_mask <= m; fill_iss <= '0;
      end
      if (fill_on && fill_iss == fill_mask && (dem_out == 3'd0 || (dem_out == 3'd1 && dem_resp))) begin
        fill_on <= 1'b0; rp_cnt <= 2'd2;
      end

      // ---------- colour read issue (S1 -> S2) and the S4 wait ----------
      if (crr_v && cr_gnt) crr_v <= 1'b0;
      if (!stall && cr_need) begin crr_v <= 1'b1; cr_addr <= s1_craddr; end
      cr_out <= cr_out + 6'(!stall && cr_need) - 6'(crq_pop);
      if (s4_needdst && crq_v) begin s4_dst <= crq_d; s4_dst_have <= 1'b1; end

      // ---------- S5: second blend product, clamp, pack, writes ----------
      if (s5_ok && !s5_block) begin
        if (s5_write) begin
          cw_valid <= 1'b1; cw_addr <= rb_base + ((pix_word(s5_y, s5_x) & ~32'd1) << 1);
          cw_data <= {s5_color, s5_color}; cw_mask <= s5_x[0] ? 2'b10 : 2'b01; st_pixels <= st_pixels + CEN;
          cw_z <= s5_depth; cw_zv <= s5_o.dwrite;                          // MAME :1430-1431 writes depth only if depth_write_enable
          if (s5_o.dwrite) begin dp_we <= 1'b1; dp_wa <= s5_da[16:2]; dp_wl <= 4'b0001 << s5_da[1:0]; dp_wd <= {4{s5_depth}}; dp_pend <= 1'b1; dp_pix <= s5_da; end
        end
        s5_ok <= 1'b0;
      end
      // ---------- S3: palette latch ----------
      if (s3_ok && s3_fresh) begin s3_pal <= pal_q; s3_fresh <= 1'b0; end

      // ---------- advance ----------
      // back stages: S4 -> S5, and S4 takes the queue's head
      if (!bstall) begin
        if (s4_ok) begin
          s5_ok <= 1'b1; s5_write <= s4_write; s5_x <= s4_x; s5_y <= s4_y; s5_da <= s4_da; s5_depth <= s4_depth; s5_o <= s4_o;
          // Reuse S5's existing multiply after S4's texture/light product.
          // A 255 material byte bypasses exactly: combat remains unchanged.
          // OPQ5 uses the front-end depth intensity; no new per-pixel Z math.
          s5_shade <= s4_o.shade &&
              ((s4_o.bm == 3'd1 && s4_o.alpha[7:0] != 8'hff) ||
               (s4_o.bm == 3'd2 && s4_i8 < 32'd255));
          s5_factor <= s4_o.bm == 3'd1 ? s4_o.alpha[7:0] : s4_i8[7:0];
          for (int c = 0; c < 3; c++) begin s5_a[c] <= a_prod[c]; s5_src[c] <= a_src[c]; s5_dst[c] <= a_dst[c]; end
        end
        s4_ok <= 1'b0;
        if (q_v) begin
          s4_ok <= 1'b1; s4_write <= q_out.write; s4_x <= 32'(q_out.x); s4_y <= 32'($signed(q_out.y)); s4_da <= q_out.da;
          s4_i8 <= q_out.i8; s4_depth <= q_out.depth; s4_o <= q_out.o; s4_sr <= q_out.sr; s4_sg <= q_out.sg; s4_sb <= q_out.sb;
          s4_dst_have <= 1'b0;
          if (q_out.write && q_out.o.rdst && crq_v) begin s4_dst <= crq_d; s4_dst_have <= 1'b1; end
        end
      end
      // front stages
      if (!stall) begin
        s3b_ok <= 1'b0;                                   // S3B's pixel went into the queue (q_push)
        if (s3_ok) begin
          s3b_ok <= 1'b1; s3b_write <= s3_write; s3b_x <= s3_x; s3b_y <= s3_y; s3b_da <= s3_da; s3b_depth <= s3_depth;
          s3b_i8 <= s3_i8; s3b_o <= s3_o; s3b_fv <= s3_fv;
          // Video-guided additive-source response. This independent 8x8 product
          // registers beside the first bilinear step, before the source-colour
          // multiply in S4. Keep the unlit 65535 sentinel (i8=255) byte-exact;
          // short-format UI and zero-normal effects consequently bypass it.
          if (PARTICLE_LIGHTING && (s3_o.bm == 3'd3 || s3_o.bm == 3'd4) && s3_i8 < 32'd255)
            s3b_o.alpha[7:0] <= 8'((16'(s3_o.alpha[7:0]) * 16'(s3_i8[7:0])) >> 8);
          for (int c = 0; c < 3; c++) begin s3b_top[c] <= u_top[c]; s3b_bot[c] <= u_bot[c]; s3b_solid[c] <= u_solid[c]; end
        end
        s3_ok <= 1'b0;
        if (s2_ok) begin
          s3_ok <= 1'b1; s3_fresh <= 1'b1; s3_write <= s2_write; s3_x <= s2_x; s3_y <= s2_y; s3_da <= s2_da;
          s3_depth <= s2_depth; s3_fu <= s2_fu; s3_fv <= s2_fv; s3_i8 <= s2_i8; s3_o <= s2_o;
        end
        s2_ok <= 1'b0;
        if (s1_ok) begin
          s2_ok <= 1'b1; s2_x <= s1_x; s2_y <= s1_y; s2_da <= s1_da; s2_depth <= s1_depth[15:0]; s2_o <= s1_o;
          s2_fu <= s1_fu; s2_fv <= s1_fv; s2_i8 <= {{8{s1_i24[23]}}, s1_i24}; // preserve signed stepping through queue stalls
          for (int k = 0; k < 4; k++) s2_tex[k] <= s1_texk[k];   // oracle2: keyed taps substituted
          s2_write <= s1_wr;
        end
        s1_ok <= 1'b0;
        if (s0_go) begin
          s1_ok <= 1'b1; s1_x <= 32'(px.x); s1_y <= cur_y; s1_da <= px.da; s1_depth <= {{16{px.dneg}}, px.d}; s1_o <= cur_o;
          s1_fu <= px.fu; s1_fv <= px.fv; s1_i24 <= px.i;
          for (int k = 0; k < 4; k++) begin
            s1_line[k] <= px.line[k]; s1_bank[k] <= px.bank[k]; s1_byte[k] <= px.byt[k];
            s1_nib[k] <= (cur_o.tfmt == 3'd1 || cur_o.tfmt == 3'd3); s1_col[k] <= px.col ^ k[0];
          end
          if (px.first) begin m_obj <= xr.o; m_y <= xr.y; end
        end
      end
    end
  end
  assign crq_pop = (s4_needdst && crq_v) || (!bstall && q_v && q_out.write && q_out.o.rdst && crq_v);

  // ---------------- S3: bilinear -> source colour ----------------
  // Every product carries its TRUE width: the texel / palette channels are 8 bits and the fractions 9 (0..256), so
  // these are 8x9 and 17x9 multiplies. v3 wrote them as 32-bit expressions and Quartus inferred 32x32 multipliers
  // (42 DSP measured, zeus1/area/pixel3c_20ns).
  // ONE multiply per lerp instead of two: a*f + b*(256 - f) == (b << 8) + (a - b) * f, exact integer algebra (no
  // rounding anywhere in this chain), so the result is bit-identical. v4 used six multiplies per channel = 18 for the
  // bilinear; this uses three = 9.
  // S3 half: the u-lerp of one channel's two texel rows. One multiply each, 10x10 signed (a 19-bit operand would
  // cost TWO DSPs per multiply -- v5 measured 36).
  function automatic logic [17:0] ulerp(input logic [7:0] c0, c1, input logic [7:0] fu);
    logic signed [9:0] fup, d;
    fup = 10'(signed'({2'b0, fu}));
    d   = 10'(signed'({2'b0, c1})) - 10'(signed'({2'b0, c0}));      // -255..255
    return 18'({c0, 8'd0}) + 18'(unsigned'(20'(d) * 20'(fup)));     // c0 * 256 + (c1 - c0) * fu  <= 130,560
  endfunction
  // S3B half: the v-lerp of the two u-lerped rows, then MAME's >> 15. (bot>>1) - (top>>1) fits 18 bits signed, so the
  // multiply stays 18x10.
  function automatic logic [7:0] vlerp(input logic [17:0] top, bot, input logic [7:0] fv);
    logic signed [9:0]  fvp;
    logic [16:0] th, bh; logic signed [17:0] d; logic signed [27:0] v;
    fvp = 10'(signed'({2'b0, fv}));
    th = top[17:1]; bh = bot[17:1];                                  // >> 1, as MAME's SSE path does
    d  = 18'(signed'({1'b0, bh})) - 18'(signed'({1'b0, th}));        // -65,280..65,280
    v  = 28'({th, 8'd0}) + 28'(d) * 28'(fvp);                        // th * 256 + (bh - th) * fv
    return 8'(v >>> 15);
  endfunction
  // S3: palette -> the two u-lerped rows per channel (one multiply level)
  always_comb begin : col
    logic [15:0] pp [4]; logic [7:0] cr [4], cg [4], cb [4];
    for (int j = 0; j < 4; j++) pp[j] = s3_fresh ? pal_q[j] : s3_pal[j];
    for (int j = 0; j < 4; j++) begin cr[j] = p5(pp[j][14:10]); cg[j] = p5(pp[j][9:5]); cb[j] = p5(pp[j][4:0]); end
    u_top[0] = ulerp(cr[0], cr[1], s3_fu); u_bot[0] = ulerp(cr[2], cr[3], s3_fu);
    u_top[1] = ulerp(cg[0], cg[1], s3_fu); u_bot[1] = ulerp(cg[2], cg[3], s3_fu);
    u_top[2] = ulerp(cb[0], cb[1], s3_fu); u_bot[2] = ulerp(cb[2], cb[3], s3_fu);
    u_solid[0] = p5(s3_o.solidc[14:10]); u_solid[1] = p5(s3_o.solidc[9:5]); u_solid[2] = p5(s3_o.solidc[4:0]);
  end

  // S3B: the v-lerp (the second multiply level), or the solid colour passed through
  always_comb begin : col2
    if (s3b_o.solid) begin src_r = s3b_solid[0]; src_g = s3b_solid[1]; src_b = s3b_solid[2]; end
    else begin
      src_r = vlerp(s3b_top[0], s3b_bot[0], s3b_fv);
      src_g = vlerp(s3b_top[1], s3b_bot[1], s3b_fv);
      src_b = vlerp(s3b_top[2], s3b_bot[2], s3b_fv);
    end
  end

  // ---------------- S4: blend -> written colour ----------------
  // i8 (the interpolated intensity) is a full 32-bit value in MAME (render_poly :1258), so OPQ2 / OPQ3 keep an 8x32
  // product; every other factor is 8 or 9 bits.
  // S4 (v7): the FIRST blend product only. The mode was decoded when the extent loaded (s4_o.bm), so no 32-bit
  // compare sits in this path. A = (src * fa) >> 8 with fa = i8 (OPQ2/3: a full 32-bit value, u32 wrap as in MAME
  // render_poly :1258) | 2*alpha (MUL1) | alpha. The destination is unpacked and masked here too, ready for S5.
  always_comb begin : bl_a
    logic [31:0] fa; logic [7:0] sa;
    sa = s4_o.alpha[7:0];
    fa = (s4_o.bm == 3'd1) ? s4_i8 : (s4_o.bm == 3'd5) ? 32'({sa, 1'b0}) : 32'(sa);   // OPQ2/3 consume interpolated intensity
    a_src[0] = s4_sr; a_src[1] = s4_sg; a_src[2] = s4_sb;
    for (int c = 0; c < 3; c++) a_prod[c] = (32'(a_src[c]) * fa) >> 8;
    a_dst[0] = {s4_dst[14:10], s4_dst[14:12]}; a_dst[1] = {s4_dst[9:5], s4_dst[9:7]}; a_dst[2] = {s4_dst[4:0], s4_dst[4:2]};
    if (!s4_o.rdst) for (int c = 0; c < 3; c++) a_dst[c] = '0;
  end

  // S5 (v7): the SECOND product B = (b1 * b2) >> 8 with (b1, b2) = (A, dst) for MUL1, else (dst, 2*dstalpha) for
  // ADD2; then the mode's combine, MAME's clamp to 0xff, and the 5-5-5 pack.
  always_comb begin : bl_b
    logic [31:0] o [3]; logic [17:0] b [3]; logic [7:0] da; logic mul1;
    da = s5_o.alpha[15:8]; mul1 = (s5_o.bm == 3'd5);
    for (int c = 0; c < 3; c++) begin
      b[c] = (18'((mul1 || s5_shade) ? s5_a[c][17:0] : 18'(s5_dst[c])) *
              18'(mul1 ? {1'b0, s5_dst[c]} : s5_shade ? {1'b0, s5_factor} : {da, 1'b0})) >> 8;
      case (s5_o.bm)
        3'd5:       o[c] = 32'(b[c]);                         // MUL1
        3'd4:       o[c] = s5_a[c] + 32'(b[c]);               // ADD2
        3'd3:       o[c] = s5_a[c] + 32'(s5_dst[c]);          // ADD1
        3'd1, 3'd2: o[c] = s5_shade ? 32'(b[c]) : s5_a[c];                           // OPQ2/3, OPQ5
        default:    o[c] = 32'(s5_src[c]);                    // OPQ1/4 and unknown modes: the source unchanged
      endcase
      if (o[c] > 32'hff) o[c] = 32'hff;
    end
    s5_color = {1'b0, o[0][7:3], o[1][7:3], o[2][7:3]};
  end
endmodule

// on-chip depth: 25,600 x 64 (4 pixels per word), 16-bit lane write enables, registered read. Built as four plain
// 25,600 x 16 simple-dual-port RAMs (one per lane, own write enable, shared addresses): a single 64-bit memory with
// a byte-enable loop was not recognised by Quartus 17.0 map, which flattened it (8.6 GB, no progress in 20 min).
module zr_depth64 (
  input  logic clk, input logic we, input logic [3:0] lanes, input logic [14:0] waddr, input logic [63:0] wdata,
  input  logic [14:0] raddr, output logic [63:0] rdata
);
  genvar gl;
  generate for (gl = 0; gl < 4; gl++) begin : g_lane
    zr_dlane #(.LANE(gl)) u_lane (.clk, .we(we && lanes[gl]), .waddr, .wdata(wdata[16*gl +: 16]), .raddr, .rdata(rdata[16*gl +: 16]));
  end endgenerate
endmodule

// one depth lane: 25,600 x 16 simple dual port, registered read (one memory per module for Quartus inference)
module zr_dlane #(parameter int LANE = 0) (
  input  logic clk, input logic we, input logic [14:0] waddr, input logic [15:0] wdata,
  input  logic [14:0] raddr, output logic [15:0] rdata
);
  logic [15:0] mem [25600];
`ifdef ZR_SEED
  // r12 bench seed (simulation only): the render buffer's depth as MAME had it at the seed (tb_zr_rsys writes one hex
  // file per lane and passes +ZR_DEPTH_SEED=<prefix>; lane LANE reads <prefix><LANE>.hex). A window that starts without
  // a clear (renderdemofight: the debug quad at 11474 is its first) otherwise compares against unseeded depth.
  initial begin : dseed
    string pre;
    if ($value$plusargs("ZR_DEPTH_SEED=%s", pre)) $readmemh($sformatf("%s%0d.hex", pre, LANE), mem);
  end
`endif
  always_ff @(posedge clk) begin
    if (we) mem[waddr] <= wdata;
    rdata <= mem[raddr];
  end
endmodule
