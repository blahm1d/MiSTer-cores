Mortal Kombat 4 / Zeus 1 - v16 - blahm1d

Corresponding integration source for the supplied RBF.
RBF SHA-256: 6bfbc384e3748bf0fa65ea33661c09fe9207265ab905b4973315508434f85fab
Target: DE10-Nano / Cyclone V 5CSEBA6U23I7.
Toolchain: Quartus Prime Lite 17.0.2, build 602; seed 13.

The rtl/ and quartus/ trees come from the exact successful build snapshot.
HDL and timing constraints are unchanged. Two absolute QSF search paths were
made relative for portability. The private host queue launcher was omitted.
Other non-functional export changes are recorded in SOURCE-MANIFEST.json.
Original third-party copyright and license notices are retained in the files.

To rebuild on your own machine, open quartus/zk4.qpf in Quartus 17.0.2.
For staged command-line compilation, from quartus/ run quartus_map zk4,
python ../tools/scaler_map_gate.py output_files/zk4.map.rpt, quartus_fit zk4,
quartus_sta zk4, quartus_sta -t ../tools/paths.tcl, then
python ../tools/check_timing.py output_files. Only after all checks pass,
run quartus_asm zk4. A rebuild must be timing-qualified independently.

The game ROM is loaded by MiSTer at runtime and is not included. No fitted
database, personal settings, game traces, keys or game ROM payloads are here.
The lighting curve is empirical; it is not a decoded Zeus silicon equation.
