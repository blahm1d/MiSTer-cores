#!/usr/bin/env bash
# Reproducible, fail-closed Y-unit hardware build.
#
# Usage:
#   ./quartus/build_hw.sh [VERILOG_MACRO|-] [OUTNAME]
#
# Explicit, manifested overrides:
#   ALLOW_DIRTY_BUILD=1          build an uncommitted timing candidate
#   BOARD_IO_WAIVER_POLICY=none  require every top-level I/O to be constrained
#   ALLOW_UNPINNED_TOOLS=1       use a non-release tool build
#   ALLOW_UNPROVEN_SDRAM_VRAM=1  offline memory-path engineering only
#   ALLOW_EXPERIMENTAL_FAMILY_CORE=1  offline family-core engineering only
#   QUARTUS_PARALLEL=N           fixed worker count (default 3)
#
# CVSD SOUND REVERT. Production streams CVSD sound ROM from SDRAM; the three
# 64 KiB BRAMs it replaces measured 192 of 553 device M10Ks. Smash T.V.'s sound
# is cabinet-proven on the BRAM path, so if a cabinet test shows a CVSD sound
# regression, revert with:
#
#   SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND" \
#     quartus/build_hw.sh YUNIT_FAMILY2 Arcade-SmashTV-YUnit-Family2
#
# The choice is recorded in the manifest and cross-checked against the fitted
# M10K count by quartus/ram_release_gate.py, so the two can never disagree.
#
# The assembler is deliberately the final, unreachable-until-proven stage:
# map, fit, the constraint audit, and every timing check must pass first.
# This script owns a project-directory lock only. The caller must separately
# hold the shared-machine FIFO ticket and authoritative Quartus process lock.
set -Eeuo pipefail

# Codex/PowerShell may start Git Bash without its normal POSIX utility paths.
# /c/iverilog/bin is here because a recovery build runs the emu elaboration gate,
# and this script's own iverilog presence check has to see the same PATH the gate
# will run under (sim/elab_top.sh exports the identical prefix).
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

QBIN="${QBIN:-/c/intelFPGA_lite/17.0/quartus/bin64}"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
PYTHON="${PYTHON:-python}"
REV=Arcade-SmashTV
# Production defaults to the isolated cabinet-good Smash datapath. The shared
# family core remains available only with its named waiver and an explicit
# non-recovery output name.
MACRO="${1:-YUNIT_SMASH_RECOVERY}"
EXPECTED_RECOVERY_OUTNAME="Arcade-SmashTV-YUnit-Recovery"
EXPECTED_FAMILY2_OUTNAME="Arcade-SmashTV-YUnit-Family2"
EXPECTED_FULL_OUTNAME="Arcade-SmashTV-YUnit-Full"
# Audio-split sibling: MK / T2 / Total Carnage only, no CVSD board.
EXPECTED_ADPCM_OUTNAME="Arcade-SmashTV-YUnit-ADPCM"
OUTNAME="${2:-$EXPECTED_RECOVERY_OUTNAME}"
[[ "$MACRO" == "-" ]] && MACRO=""

# Defined here rather than further down because the SV2V_EXTRA default below is
# now flavor-dependent and calls has_token. Bash resolves functions at call
# time, so a definition after that point would be a runtime "command not found".
die() {
  echo "ERROR: $*" >&2
  exit 1
}

has_token() {
  local haystack="$1" needle="$2"
  case " $haystack " in
    *" $needle "*) return 0 ;;
    *) return 1 ;;
  esac
}

# Pin the normal hardware variant to the cabinet-proven framebuffer backend.
# The SDRAM framebuffer's burst-write/arbiter integration is not complete and
# its single-pixel write lane is far below the Y-unit beam deadline.
# Callers may explicitly request that engineering configuration only with the
# named waiver below; the exact choice is recorded in the manifest.
if [[ -z "${SV2V_EXTRA+x}" ]] && has_token "$MACRO" "YUNIT_ADPCM"; then
  # The ADPCM sibling's macro must reach sv2v too: yunit_top_family2.sv drops the CVSD board
  # under `ifndef YUNIT_ADPCM, and that file goes through sv2v. Without the define the
  # translation would keep the CVSD board and the split would silently not happen.
  SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_ADPCM -DYUNIT_FULL"
elif [[ -z "${SV2V_EXTRA+x}" ]] && has_token "$MACRO" "YUNIT_FULL"; then
  # The all-title flavour needs its macro as an sv2v define as well, because
  # yunit_top_family2.sv adds the ADPCM board beside CVSD under YUNIT_FULL and
  # that file goes through sv2v. Without the define the translation silently
  # drops the ADPCM half of the runtime-selected sound hardware.
  # Defaulted here so callers do not have to know that; the production guard
  # below still checks it explicitly.
  SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_FULL"
  # The service instrument spans the sv2v/Quartus seam, so default its sv2v half
  # from the macro. The both-or-neither check below still verifies it explicitly.
  has_token "$MACRO" "DIAG_SERVICE" && SV2V_EXTRA="$SV2V_EXTRA -DDIAG_SERVICE"
elif [[ -z "${SV2V_EXTRA+x}" ]]; then
  # Exact cabinet-stable firefix_mixboot memory/completion flavor. The
  # renderer still cannot report X1 before every pixel is accepted into the
  # coherent BSNOOP/write-through path; NO_COMMITGATE only avoids waiting for
  # the final posted bridge drain, which is fenced separately from CPU VRAM.
  SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE"
fi
export SV2V SV2V_EXTRA

QUARTUS_PARALLEL="${QUARTUS_PARALLEL:-3}"
ALLOW_DIRTY_BUILD="${ALLOW_DIRTY_BUILD:-0}"
BOARD_IO_WAIVER_POLICY="${BOARD_IO_WAIVER_POLICY:-mister-standard-framework-io-v1}"
ALLOW_UNPINNED_TOOLS="${ALLOW_UNPINNED_TOOLS:-0}"
ALLOW_UNPROVEN_SDRAM_VRAM="${ALLOW_UNPROVEN_SDRAM_VRAM:-0}"
ALLOW_EXPERIMENTAL_FAMILY_CORE="${ALLOW_EXPERIMENTAL_FAMILY_CORE:-0}"

EXPECTED_QUARTUS_VERSION="Version 17.0.2 Build 602 07/19/2017 SJ Lite Edition"
EXPECTED_QUARTUS_SH_SHA256="360039B0B0F2870A6B098DCB4BAEEFC040AF9285162018882B8030334FA9C21B"
EXPECTED_QUARTUS_MAP_SHA256="3DFB729AF88E2EF6217EC6EA0DBAD305485814B84B46610A1CFD41EFF5DBCD45"
EXPECTED_QUARTUS_FIT_SHA256="D7C802E80E332AEF0D5D711077B033FE8BEB9E58A2302A3B3F2C5C8CCD7A0917"
EXPECTED_QUARTUS_STA_SHA256="5CD28F77B246F2B1324D76E01D15575FD5AB8E9B9297284126701278B8E325A9"
EXPECTED_QUARTUS_ASM_SHA256="F49DBD0C9659AEA524E013B65F69C612B87D715256E904B10C8D7BEFF32FF6CF"
EXPECTED_SV2V_VERSION="sv2v v0.0.13"
EXPECTED_SV2V_SHA256="1F3C2B96E212592E6F4A2ECFF3209F211277834540D8A9309ECEE50A45ADC699"
EXPECTED_DEVICE="5CSEBA6U23I7"
# QSF_SEED is what Arcade-SmashTV.qsf literally contains and must keep
# containing: the cabinet-confirmed recovery RBF was fitted at seed 2, so the
# shared project file stays pinned there and a recovery rebuild reproduces it.
#
# FIT_SEED is the seed THIS flavor actually fits with, passed to quartus_fit on
# the command line so one flavor's placement choice can never silently move
# another's. family2's fits are placement-limited, not logic-depth-limited, and
# two measured points prove that rather than assume it:
#   seed 2: WNS -0.215, 17 of the 20 worst paths from vram_sdram_top|er_row[5]
#   seed 4: WNS -0.032, er_row absent entirely, 15 of 20 now from c_burstlen[0]
# The critical net changed IDENTITY between placements, so there is no fixed wall
# to restructure -- only congestion in stv_vram_ddr_top's erase/fill/test block,
# which is cabinet-proven RTL and not worth reshaping for 32 ps. This is the one
# case where the seed is the correct lever. It is CAPPED, not a sweep: if seed 7
# does not close, the next move is structural or fitter-effort with the
# accumulated path evidence -- not seed 9.
QSF_SEED=2
EXPECTED_SEED=$QSF_SEED


[[ -n "$OUTNAME" ]] || die "OUTNAME must not be empty"
[[ "$OUTNAME" != *"/"* && "$OUTNAME" != *"\\"* && "$OUTNAME" != "." && "$OUTNAME" != ".." ]] \
  || die "OUTNAME must be a file name, not a path: $OUTNAME"
[[ "$QUARTUS_PARALLEL" =~ ^[1-9][0-9]*$ ]] \
  || die "QUARTUS_PARALLEL must be a positive integer"
[[ "$ALLOW_DIRTY_BUILD" =~ ^[01]$ ]] \
  || die "ALLOW_DIRTY_BUILD must be 0 or 1"
[[ "$BOARD_IO_WAIVER_POLICY" == "none" || \
   "$BOARD_IO_WAIVER_POLICY" == "mister-standard-framework-io-v1" ]] \
  || die "unknown BOARD_IO_WAIVER_POLICY: $BOARD_IO_WAIVER_POLICY"
[[ -z "${ALLOW_UNCONSTRAINED_IO+x}" ]] \
  || die "ALLOW_UNCONSTRAINED_IO was removed; use the exact named BOARD_IO_WAIVER_POLICY"
[[ "$ALLOW_UNPINNED_TOOLS" =~ ^[01]$ ]] \
  || die "ALLOW_UNPINNED_TOOLS must be 0 or 1"
[[ "$ALLOW_UNPROVEN_SDRAM_VRAM" =~ ^[01]$ ]] \
  || die "ALLOW_UNPROVEN_SDRAM_VRAM must be 0 or 1"
[[ "$ALLOW_EXPERIMENTAL_FAMILY_CORE" =~ ^[01]$ ]] \
  || die "ALLOW_EXPERIMENTAL_FAMILY_CORE must be 0 or 1"
if { ! has_token "$SV2V_EXTRA" "-DUSE_DDR3_VRAM" || \
     ! has_token "$SV2V_EXTRA" "-DYUNIT_NO_COMMITGATE"; } && \
   [[ "$ALLOW_UNPROVEN_SDRAM_VRAM" != 1 ]]; then
  die "production requires the cabinet-stable -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE flavor; set ALLOW_UNPROVEN_SDRAM_VRAM=1 only for offline memory-path engineering"
fi
if has_token "$MACRO" "YUNIT_SMASH_RECOVERY"; then
  recovery_macro_count=0
  for token in $MACRO; do
    [[ "$token" == "YUNIT_SMASH_RECOVERY" ]] \
      || die "recovery production accepts only the exact YUNIT_SMASH_RECOVERY macro token, not: $token"
    recovery_macro_count=$((recovery_macro_count + 1))
  done
  [[ "$recovery_macro_count" == 1 ]] \
    || die "recovery production requires YUNIT_SMASH_RECOVERY exactly once"
  [[ "$OUTNAME" == "$EXPECTED_RECOVERY_OUTNAME" ]] \
    || die "recovery production OUTNAME must be $EXPECTED_RECOVERY_OUTNAME, got: $OUTNAME"

  if [[ "$ALLOW_UNPROVEN_SDRAM_VRAM" != 1 ]]; then
    recovery_sv2v_count=0
    for token in $SV2V_EXTRA; do
      case "$token" in
        -DUSE_DDR3_VRAM|-DYUNIT_NO_COMMITGATE) ;;
        *) die "recovery production accepts only the two cabinet-stable sv2v tokens, not: $token" ;;
      esac
      recovery_sv2v_count=$((recovery_sv2v_count + 1))
    done
    [[ "$recovery_sv2v_count" == 2 ]] \
      || die "recovery production requires exactly two sv2v tokens"
  fi
elif has_token "$MACRO" "YUNIT_FAMILY2"; then
  # family2 (PLAN-family2-rebase.md): the rebased family production flavor.
  # Same shape of guards as recovery: exactly one macro token, its own output
  # stem (never the recovery one), and the same two cabinet-stable sv2v tokens.
  family2_macro_count=0
  family2_diag=0
  for token in $MACRO; do
    case "$token" in
      YUNIT_FAMILY2) family2_macro_count=$((family2_macro_count + 1)) ;;
      # Display-base instrument (DIAG_BOOT overlay + the DIAG_DISPBASE row set).
      # Same guard shape as the FULL flavour's DIAG_BOOT/DIAG_DLAUDIT: the
      # experimental waiver is required and the release stem is FORBIDDEN, so an
      # instrument image can never ship as the release. Emu-half ONLY --
      # dbg_disp_flips/dbg_disp_rows are unconditional ports on
      # yunit_top_family2, so the macro must NOT be added to SV2V_EXTRA; only
      # quartus_map needs it. Not full_diag either: that flag drives the
      # DIAG_SERVICE two-half consistency check, which does not apply here.
      DIAG_BOOT|DIAG_DISPBASE)
        [[ "$ALLOW_EXPERIMENTAL_FAMILY_CORE" == 1 ]] \
          || die "$token is a diagnostic build; set ALLOW_EXPERIMENTAL_FAMILY_CORE=1"
        family2_diag=1 ;;
      *) die "family2 production accepts only the exact YUNIT_FAMILY2 macro token, not: $token" ;;
    esac
  done
  [[ "$family2_macro_count" == 1 ]] \
    || die "family2 production requires YUNIT_FAMILY2 exactly once"
  if [[ "$family2_diag" == 1 || "$SV2V_EXTRA" == *-DYUNIT_DISPLAY_SEQ* ]]; then
    [[ "$OUTNAME" != "$EXPECTED_FAMILY2_OUTNAME" ]] \
      || die "a diagnostic/display-seq build must NOT use the release stem $EXPECTED_FAMILY2_OUTNAME; give it a unique stem"
  else
    [[ "$OUTNAME" == "$EXPECTED_FAMILY2_OUTNAME" ]] \
      || die "family2 production OUTNAME must be $EXPECTED_FAMILY2_OUTNAME, got: $OUTNAME"
  fi
  if [[ "$ALLOW_UNPROVEN_SDRAM_VRAM" != 1 ]]; then
    # The two cabinet-stable tokens are mandatory. -DYUNIT_CVSD_BRAM_SOUND is
    # the named, optional revert that puts CVSD sound ROM back in BRAM (see the
    # header). It is recorded in the manifest and cross-checked against the
    # fitted M10K count by ram_release_gate.py, so it cannot be used silently.
    family2_ddr3=0; family2_commit=0; family2_bramsnd=0; family2_smashbramsnd=0; family2_dispseq=0; family2_srtfill=0
    for token in $SV2V_EXTRA; do
      case "$token" in
        -DUSE_DDR3_VRAM)         family2_ddr3=1 ;;
        -DYUNIT_NO_COMMITGATE)   family2_commit=1 ;;
        -DYUNIT_CVSD_BRAM_SOUND) family2_bramsnd=1 ;;
        -DYUNIT_SMASH_BRAM_SOUND)
          [[ "$ALLOW_EXPERIMENTAL_FAMILY_CORE" == 1 ]] \
            || die "$token requires ALLOW_EXPERIMENTAL_FAMILY_CORE=1"
          family2_smashbramsnd=1 ;;
        # The SF/Saurian scanout-column fix: FULL display sequencer, no ADPCM
        # board (M10K economy). Its own OUTNAME + cvsdseq-icarus elab mode.
        -DYUNIT_DISPLAY_SEQ)     family2_dispseq=1 ;;
        -DYUNIT_SRT_FILL_BURST)
          [[ "$ALLOW_EXPERIMENTAL_FAMILY_CORE" == 1 ]] \
            || die "$token is an experimental SF command backend; set ALLOW_EXPERIMENTAL_FAMILY_CORE=1"
          family2_srtfill=1 ;;
        *) die "family2 production accepts only the cabinet-stable sv2v tokens (optionally -DYUNIT_CVSD_BRAM_SOUND / -DYUNIT_DISPLAY_SEQ / -DYUNIT_SMASH_BRAM_SOUND, or approved experimental -DYUNIT_SRT_FILL_BURST), not: $token" ;;
      esac
    done
    [[ "$family2_bramsnd" != 1 || "$family2_smashbramsnd" != 1 ]] \
      || die "choose only one CVSD BRAM sound residence option"
    if [[ "$family2_smashbramsnd" == 1 ]]; then
      [[ "$family2_dispseq" == 1 && "$OUTNAME" == Arcade-SmashTV-YUnit-Family2Seq-?* ]] \
        || die "Smash BRAM diagnostic requires YUNIT_DISPLAY_SEQ and a Family2Seq-<suffix> output stem"
      echo "NOTE: Smash-only BRAM sound diagnostic (+192 M10K projected); other profiles keep SDRAM"
    fi
    [[ "$family2_ddr3" == 1 && "$family2_commit" == 1 ]] \
      || die "family2 production requires -DUSE_DDR3_VRAM and -DYUNIT_NO_COMMITGATE"
    if [[ "$family2_srtfill" == 1 ]]; then
      [[ "$family2_ddr3" == 1 && "$family2_dispseq" == 1 ]] \
        || die "-DYUNIT_SRT_FILL_BURST requires -DUSE_DDR3_VRAM and -DYUNIT_DISPLAY_SEQ"
      [[ "$OUTNAME" != "$EXPECTED_FAMILY2_OUTNAME" ]] \
        || die "-DYUNIT_SRT_FILL_BURST must use a unique non-release OUTNAME"
    fi
    [[ "$family2_bramsnd" == 1 ]] \
      && echo "NOTE: CVSD sound reverted to BRAM images (+192 M10K); recorded in the manifest"
  fi
elif has_token "$MACRO" "YUNIT_ADPCM"; then
  # ADPCM sibling: Mortal Kombat / Terminator 2 / Total Carnage. Same rebased family2
  # datapath and 8 MB map as FULL (YUNIT_ADPCM defines YUNIT_FULL in the emu), but with NO
  # CVSD board -- its sound ROM cannot be BRAM-resident at any budget (MK alone is 768 KiB),
  # so this sibling keeps the SDRAM sound path and is where the per-client cache fix lands.
  adpcm_macro_count=0
  adpcm_diag=0
  for token in $MACRO; do
    case "$token" in
      YUNIT_ADPCM) adpcm_macro_count=$((adpcm_macro_count + 1)) ;;
      # Thin-blit census instrument (T2 black-transition + TC road triage).
      # Same guard shape as the family2 DIAG arm: experimental waiver
      # required, the release stem FORBIDDEN. Emu-half ONLY -- the
      # dbg_blit_total/dbg_blit_thin counters are unconditional ports on the
      # top, so the macros must NOT be added to SV2V_EXTRA; only quartus_map
      # needs them for the Arcade-SmashTV.sv overlay.
      DIAG_BOOT|DIAG_THINBLIT)
        [[ "$ALLOW_EXPERIMENTAL_FAMILY_CORE" == 1 ]] \
          || die "$token is a diagnostic build; set ALLOW_EXPERIMENTAL_FAMILY_CORE=1"
        adpcm_diag=1 ;;
      *) die "adpcm production accepts only YUNIT_ADPCM (plus DIAG_BOOT/DIAG_THINBLIT for an instrument image), not: $token" ;;
    esac
  done
  [[ "$adpcm_macro_count" == 1 ]] \
    || die "adpcm production requires YUNIT_ADPCM exactly once"
  if [[ "$adpcm_diag" == 1 ]]; then
    [[ "$OUTNAME" != "$EXPECTED_ADPCM_OUTNAME" ]] \
      || die "a diagnostic build must NOT use the release stem $EXPECTED_ADPCM_OUTNAME; give it a unique diagnostic stem"
  else
    [[ "$OUTNAME" == "$EXPECTED_ADPCM_OUTNAME" ]] \
      || die "adpcm production OUTNAME must be $EXPECTED_ADPCM_OUTNAME, got: $OUTNAME"
  fi
  if [[ "$ALLOW_UNPROVEN_SDRAM_VRAM" != 1 ]]; then
    adpcm_ddr3=0; adpcm_commit=0; adpcm_flavour=0; adpcm_full=0
    for token in $SV2V_EXTRA; do
      case "$token" in
        -DUSE_DDR3_VRAM)       adpcm_ddr3=1 ;;
        -DYUNIT_NO_COMMITGATE) adpcm_commit=1 ;;
        -DYUNIT_ADPCM)         adpcm_flavour=1 ;;
        # Required: the emu's `define YUNIT_FULL does not cross into the sv2v'd core.
        -DYUNIT_FULL)          adpcm_full=1 ;;
        # No -DYUNIT_CVSD_BRAM_SOUND here, deliberately: this sibling has no CVSD board to
        # put in BRAM, so accepting the token would be a silent no-op that reads as a choice.
        *) die "adpcm production accepts only the cabinet-stable sv2v tokens plus -DYUNIT_ADPCM, not: $token" ;;
      esac
    done
    # -DYUNIT_FULL is REQUIRED, not merely accepted. The ADPCM board and the audio mux live
    # under `ifdef YUNIT_FULL while the CVSD board is removed under `ifndef YUNIT_ADPCM, so a
    # build given YUNIT_ADPCM alone compiles out BOTH sound boards and produces a SILENT core
    # that still passes map, fit, the RAM gate and timing. That shipped: the fitted netlist had
    # no sound entity, general[2] matched no clock, and audio_l/audio_r were hard zero.
    # This guard previously PARSED the token and never checked it -- an untested gate path.
    [[ "$adpcm_ddr3" == 1 && "$adpcm_commit" == 1 && "$adpcm_flavour" == 1 && "$adpcm_full" == 1 ]] \
      || die "adpcm production requires -DUSE_DDR3_VRAM, -DYUNIT_NO_COMMITGATE, -DYUNIT_ADPCM and -DYUNIT_FULL (without the last, both sound boards compile out and the core is silent)"
  fi
elif has_token "$MACRO" "YUNIT_FULL"; then
  # YUNIT_FULL: the single all-title build. Same rebased family2 datapath and
  # mappers, 8 MB graphics region (MK/T2 need PLANE_WORDS 0x100000), and both
  # sound boards with the active one selected by game_id.
  full_macro_count=0
  full_diag=0
  full_diag_emu=0
  for token in $MACRO; do
    case "$token" in
      YUNIT_FULL) full_macro_count=$((full_macro_count + 1)) ;;
      # F4 cabinet service instrument (yunit_service_counters +
      # yunit_diag_service_overlay). Permitted ONLY as a named diagnostic: it
      # requires the experimental waiver AND is forbidden from taking the
      # release stem below, so a counter image can never be installed as the
      # release. This tightens the guard rather than loosening it.
      DIAG_SERVICE)
        [[ "$ALLOW_EXPERIMENTAL_FAMILY_CORE" == 1 ]] \
          || die "DIAG_SERVICE is a diagnostic build; set ALLOW_EXPERIMENTAL_FAMILY_CORE=1"
        full_diag=1 ;;
      # P0020 download audit (DIAG_BOOT overlay + the DIAG_DLAUDIT row set).
      # Unlike DIAG_SERVICE this instrument lives ENTIRELY on the emu half:
      # dbg_iol_drop/dbg_iol_wrs are unconditional ports on yunit_top_family2
      # and smashtv_diag2_overlay is unconditionally in the sv2v blob, so the
      # macro must NOT be added to SV2V_EXTRA -- only quartus_map needs it.
      # Same shape of guard as DIAG_SERVICE: experimental waiver required and
      # the release stem forbidden, so an instrument image can never ship as
      # the release.
      DIAG_BOOT|DIAG_DLAUDIT)
        [[ "$ALLOW_EXPERIMENTAL_FAMILY_CORE" == 1 ]]           || die "$token is a diagnostic build; set ALLOW_EXPERIMENTAL_FAMILY_CORE=1"
        # NOT full_diag: that flag drives the DIAG_SERVICE two-half consistency
        # check, and this instrument has no core half to be consistent with.
        full_diag_emu=1 ;;
      *) die "full production accepts only the exact YUNIT_FULL macro token, not: $token" ;;
    esac
  done
  [[ "$full_macro_count" == 1 ]] \
    || die "full production requires YUNIT_FULL exactly once"
  if [[ "$full_diag" == 1 || "$full_diag_emu" == 1 ]]; then
    [[ "$OUTNAME" != "$EXPECTED_FULL_OUTNAME" ]] \
      || die "a diagnostic build must NOT use the release stem $EXPECTED_FULL_OUTNAME; give it a unique diagnostic stem"
  else
    [[ "$OUTNAME" == "$EXPECTED_FULL_OUTNAME" ]] \
      || die "full production OUTNAME must be $EXPECTED_FULL_OUTNAME, got: $OUTNAME"
  fi
  if [[ "$ALLOW_UNPROVEN_SDRAM_VRAM" != 1 ]]; then
    # THREE tokens here, not two: this flavour's macro must also reach sv2v.
    full_ddr3=0; full_commit=0; full_has_flavour=0; full_bramsnd=0; full_diagsv=0
    for token in $SV2V_EXTRA; do
      case "$token" in
        -DUSE_DDR3_VRAM)         full_ddr3=1 ;;
        -DYUNIT_NO_COMMITGATE)   full_commit=1 ;;
        -DYUNIT_FULL)           full_has_flavour=1 ;;
        -DYUNIT_CVSD_BRAM_SOUND) full_bramsnd=1 ;;
        -DDIAG_SERVICE)          full_diagsv=1 ;;
        *) die "full production accepts only the cabinet-stable sv2v tokens (optionally -DYUNIT_CVSD_BRAM_SOUND), not: $token" ;;
      esac
    done
    [[ "$full_ddr3" == 1 && "$full_commit" == 1 && "$full_has_flavour" == 1 ]] \
      || die "full production requires -DUSE_DDR3_VRAM, -DYUNIT_NO_COMMITGATE and -DYUNIT_FULL"
    # BOTH-OR-NEITHER. The core is sv2v'd and the emu top is Quartus-native, so
    # DIAG_SERVICE has to be defined twice, by two different mechanisms. Half of
    # it is the worst outcome: counters with no overlay paints nothing, and an
    # overlay with no counters paints a screen full of zeros that reads as a
    # measured result. Fail closed on the mismatch instead.
    [[ "$full_diagsv" == "$full_diag" ]] \
      || die "DIAG_SERVICE must be in BOTH \$MACRO (Quartus, for the emu overlay) and \$SV2V_EXTRA (-DDIAG_SERVICE, for the core counters); got macro=$full_diag sv2v=$full_diagsv"
    [[ "$full_bramsnd" == 1 ]] \
      && echo "NOTE: CVSD sound reverted to BRAM images (+192 M10K); recorded in the manifest"
  fi
else
  [[ "$ALLOW_EXPERIMENTAL_FAMILY_CORE" == 1 ]] \
    || die "production requires the exact YUNIT_SMASH_RECOVERY, YUNIT_FAMILY2, YUNIT_ADPCM or YUNIT_FULL macro token; set ALLOW_EXPERIMENTAL_FAMILY_CORE=1 only for offline family-core engineering"
  [[ "$OUTNAME" != "$EXPECTED_RECOVERY_OUTNAME" && "$OUTNAME" != "$EXPECTED_FAMILY2_OUTNAME" \
     && "$OUTNAME" != "$EXPECTED_FULL_OUTNAME" ]] \
    || die "an experimental family build must provide an explicit non-production OUTNAME"
fi

if has_token "$MACRO" "YUNIT_FAMILY2"; then
  FIT_SEED="${FIT_SEED:-4}"
else
  FIT_SEED="${FIT_SEED:-$QSF_SEED}"
fi
[[ "$FIT_SEED" =~ ^[0-9]+$ ]] || die "FIT_SEED must be an integer, got: $FIT_SEED"
EXPECTED_SEED="$FIT_SEED"

for tool in "$QBIN/quartus_sh" "$QBIN/quartus_map" "$QBIN/quartus_fit" \
            "$QBIN/quartus_sta" "$QBIN/quartus_asm" "$SV2V"; do
  [[ -x "$tool" || -x "$tool.exe" ]] || die "required tool is not executable: $tool"
done
command -v "$PYTHON" >/dev/null 2>&1 || die "Python interpreter not found: $PYTHON"
command -v sha256sum >/dev/null 2>&1 || die "sha256sum is required"
# Every production family build runs the licence-free emu elaboration gate before map/fit.
# Check for its compiler here so a missing toolchain fails in the first seconds
# rather than after the FIFO ticket and the sv2v stage are already spent.
if has_token "$MACRO" "YUNIT_SMASH_RECOVERY" \
   || has_token "$MACRO" "YUNIT_FAMILY2" \
   || has_token "$MACRO" "YUNIT_ADPCM" \
   || has_token "$MACRO" "YUNIT_FULL"; then
  command -v iverilog >/dev/null 2>&1 \
    || die "iverilog is required for the emu elaboration gate"
fi

QUARTUS_VERSION="$("$QBIN/quartus_sh" --version | tr -d '\r' | sed -n '2p')"
SV2V_VERSION="$("$SV2V" --version | tr -d '\r' | sed -n '1p')"
QUARTUS_SH_SHA256="$(sha256sum "$QBIN/quartus_sh.exe" | awk '{print toupper($1)}')"
QUARTUS_MAP_SHA256="$(sha256sum "$QBIN/quartus_map.exe" | awk '{print toupper($1)}')"
QUARTUS_FIT_SHA256="$(sha256sum "$QBIN/quartus_fit.exe" | awk '{print toupper($1)}')"
QUARTUS_STA_SHA256="$(sha256sum "$QBIN/quartus_sta.exe" | awk '{print toupper($1)}')"
QUARTUS_ASM_SHA256="$(sha256sum "$QBIN/quartus_asm.exe" | awk '{print toupper($1)}')"
SV2V_SHA256="$(sha256sum "$SV2V" | awk '{print toupper($1)}')"
PYTHON_VERSION="$("$PYTHON" --version 2>&1 | tr -d '\r')"

if [[ "$ALLOW_UNPINNED_TOOLS" != 1 ]]; then
  [[ "$QUARTUS_VERSION" == "$EXPECTED_QUARTUS_VERSION" ]] \
    || die "Quartus mismatch: expected '$EXPECTED_QUARTUS_VERSION', got '$QUARTUS_VERSION'"
  [[ "$QUARTUS_SH_SHA256" == "$EXPECTED_QUARTUS_SH_SHA256" ]] \
    || die "quartus_sh binary hash mismatch: $QUARTUS_SH_SHA256"
  [[ "$QUARTUS_MAP_SHA256" == "$EXPECTED_QUARTUS_MAP_SHA256" ]] \
    || die "quartus_map binary hash mismatch: $QUARTUS_MAP_SHA256"
  [[ "$QUARTUS_FIT_SHA256" == "$EXPECTED_QUARTUS_FIT_SHA256" ]] \
    || die "quartus_fit binary hash mismatch: $QUARTUS_FIT_SHA256"
  [[ "$QUARTUS_STA_SHA256" == "$EXPECTED_QUARTUS_STA_SHA256" ]] \
    || die "quartus_sta binary hash mismatch: $QUARTUS_STA_SHA256"
  [[ "$QUARTUS_ASM_SHA256" == "$EXPECTED_QUARTUS_ASM_SHA256" ]] \
    || die "quartus_asm binary hash mismatch: $QUARTUS_ASM_SHA256"
  [[ "$SV2V_VERSION" == "$EXPECTED_SV2V_VERSION" ]] \
    || die "sv2v mismatch: expected '$EXPECTED_SV2V_VERSION', got '$SV2V_VERSION'"
  [[ "$SV2V_SHA256" == "$EXPECTED_SV2V_SHA256" ]] \
    || die "sv2v binary hash mismatch: $SV2V_SHA256"
fi

RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)-$$"
RUN_DIR="$ROOT/build_syn/runs/$RUN_ID"
MANIFEST="$RUN_DIR/manifest.json"
TIMING_JSON="$RUN_DIR/timing.json"
RAM_JSON="$RUN_DIR/ram.json"
MARKER="$RUN_DIR/build-start.marker"
mkdir -p "$RUN_DIR"

DIRTY_ARGS=()
[[ "$ALLOW_DIRTY_BUILD" == 1 ]] && DIRTY_ARGS+=(--allow-dirty)

"$PYTHON" quartus/release_gate.py manifest-start \
  --root "$ROOT" \
  --output "$MANIFEST" \
  --run-id "$RUN_ID" \
  --revision "$REV" \
  --outname "$OUTNAME" \
  --macro="$MACRO" \
  --sv2v-extra="$SV2V_EXTRA" \
  --quartus-bin "$QBIN" \
  --quartus-version "$QUARTUS_VERSION" \
  --quartus-sha256 "$QUARTUS_SH_SHA256" \
  --quartus-map-sha256 "$QUARTUS_MAP_SHA256" \
  --quartus-fit-sha256 "$QUARTUS_FIT_SHA256" \
  --quartus-sta-sha256 "$QUARTUS_STA_SHA256" \
  --quartus-asm-sha256 "$QUARTUS_ASM_SHA256" \
  --sv2v-bin "$SV2V" \
  --sv2v-version "$SV2V_VERSION" \
  --sv2v-sha256 "$SV2V_SHA256" \
  --python-version "$PYTHON_VERSION" \
  --parallel "$QUARTUS_PARALLEL" \
  --expected-device "$EXPECTED_DEVICE" \
  --expected-seed "$EXPECTED_SEED" \
  --qsf-seed "$QSF_SEED" \
  --allow-unpinned-tools "$ALLOW_UNPINNED_TOOLS" \
  --board-io-waiver-policy "$BOARD_IO_WAIVER_POLICY" \
  "${DIRTY_ARGS[@]}"

BUILD_PUBLISHED=0
LOCK_DIR="$ROOT/build_syn/.quartus-build.lock"
LOCK_HELD=0
on_exit() {
  local rc=$?
  if [[ -f "$MANIFEST" && "$BUILD_PUBLISHED" != 1 ]]; then
    "$PYTHON" quartus/release_gate.py mark \
      --manifest "$MANIFEST" --status failed --exit-code "$rc" >/dev/null 2>&1 || true
  fi
  # A seeded fit rewrites the QSF; restore it here rather than from a second EXIT trap.
  # Installing `trap restore_qsf EXIT` separately REPLACED this handler, so a build that died
  # at a gate never released the project lock and the NEXT variant failed instantly with
  # "another Quartus build owns .quartus-build.lock". Measured: the cvsd sibling died at the
  # RAM gate and took the adpcm sibling down with it one second after it acquired the box.
  if declare -F restore_qsf >/dev/null 2>&1; then restore_qsf || true; fi
  if [[ "$LOCK_HELD" == 1 ]]; then
    rmdir -- "$LOCK_DIR" >/dev/null 2>&1 || true
  fi
  exit "$rc"
}
trap on_exit EXIT

# Prove the recovery selector, isolated hierarchy, exact single-stream ROM ABI,
# cabinet controls, retained TMS fixes, MAME behavior, and assembly contracts
# before claiming the project lock or spending a map/fit attempt.
if has_token "$MACRO" "YUNIT_SMASH_RECOVERY" \
   || has_token "$MACRO" "YUNIT_FAMILY2" \
   || has_token "$MACRO" "YUNIT_ADPCM" \
   || has_token "$MACRO" "YUNIT_FULL"; then
  # The transfer audit is repo-level and pins the wrapper shape all family
  # flavors share; no sibling build may regress the frozen recovery pins.
  RECOVERY_AUDIT_LOG="$RUN_DIR/recovery_transfer_audit.log"
  if "$PYTHON" tools/audit_smashtv_recovery_transfer.py \
      >"$RECOVERY_AUDIT_LOG" 2>&1; then
    tail -3 "$RECOVERY_AUDIT_LOG"
  else
    rc=$?
    tail -40 "$RECOVERY_AUDIT_LOG" >&2 || true
    exit "$rc"
  fi
  "$PYTHON" quartus/release_gate.py record \
    --manifest "$MANIFEST" --label recovery_transfer_audit \
    --file "$RECOVERY_AUDIT_LOG"

  # POST-CONVERSION gate. Every .sv-side bench passed while the shipped core
  # had stuck direction bits, because sv2v lowers a SystemVerilog `inout`
  # subroutine argument (copy-in/copy-out) to a Verilog `output` (copy-out
  # only). This gate checks the mappers on the Verilog Quartus actually reads,
  # and self-proves against a frozen copy of the broken conversion.
  POSTCONV_LOG="$RUN_DIR/postconv_gate.log"
  if bash sim/postconv/run_postconv_gate.sh >"$POSTCONV_LOG" 2>&1; then
    tail -2 "$POSTCONV_LOG"
  else
    rc=$?
    tail -40 "$POSTCONV_LOG" >&2 || true
    exit "$rc"
  fi
  "$PYTHON" quartus/release_gate.py record \
    --manifest "$MANIFEST" --label postconv_input_gate \
    --file "$POSTCONV_LOG"
fi

mkdir -p "$ROOT/build_syn"
if ! mkdir "$LOCK_DIR"; then
  die "another Quartus build owns $LOCK_DIR"
fi
LOCK_HELD=1

# Only these exact generated trees may be recursively removed. output_files is
# moved into this run's quarantine so prior reports remain recoverable.
safe_remove_generated_tree() {
  local target="$1"
  case "$target" in
    "$ROOT/db"|"$ROOT/incremental_db"|"$ROOT/greybox_tmp") ;;
    *) die "refusing to remove unexpected tree: $target" ;;
  esac
  [[ ! -L "$target" ]] || die "refusing to remove generated-tree symlink: $target"
  [[ ! -e "$target" ]] || rm -rf -- "$target"
}

if [[ -d "$ROOT/output_files" ]]; then
  mv -- "$ROOT/output_files" "$RUN_DIR/prior-output_files"
fi
safe_remove_generated_tree "$ROOT/db"
safe_remove_generated_tree "$ROOT/incremental_db"
safe_remove_generated_tree "$ROOT/greybox_tmp"

if [[ -f "$ROOT/build_syn/smashtv_core.v" ]]; then
  mv -- "$ROOT/build_syn/smashtv_core.v" "$RUN_DIR/prior-smashtv_core.v"
fi
mkdir -p "$ROOT/build_syn"
touch "$MARKER"
# build_id.tcl intentionally avoids rewriting identical minute stamps. Remove
# its two generated files so even a retry in the same minute is fresh.
rm -f -- "$ROOT/build_id.v" "$ROOT/jtag.cdf"

require_fresh_file() {
  local file="$1"
  [[ -s "$file" ]] || die "expected fresh non-empty output is missing: $file"
  [[ "$file" -nt "$MARKER" ]] || die "output is not newer than this build: $file"
}

require_summary_status() {
  local file="$1" expected="$2"
  require_fresh_file "$file"
  grep -Fq "$expected" "$file" \
    || die "expected status '$expected' not found in $file"
}

require_assembler_success() {
  local report="$1"
  require_fresh_file "$report"
  grep -Eq '^; Assembler Status[[:space:]]*; Successful -' "$report" \
    || die "positive Assembler Summary status is missing from $report"
  grep -Eq '^Info: Quartus Prime Assembler was successful\. 0 errors, [0-9]+ warnings' "$report" \
    || die "Assembler terminal success marker is missing from $report"
}

# PER-VARIANT REPORT ARCHIVE.
# MEASURED by the T-unit session 2026-08-02: Quartus writes every report to the SAME names
# (Arcade-SmashTV.fit.rpt, .map.rpt, .sta.summary ...). This repo now builds MULTIPLE variants
# from one project directory -- recovery, family2/CVSD, full, adpcm -- and the two audio
# siblings are queued back to back. Recording a manifest against output_files/<REV>.fit.rpt
# means the NEXT variant's build silently destroys the previous variant's bound evidence: its
# RBF still hashes and is still genuine, but it becomes UNPACKAGEABLE because the manifest's
# report hashes no longer match anything on disk. That cost T-unit two rebuilds to find and fix.
#
# So archive the bound file under output_files/reports-<OUTNAME>/ and record THAT path. The
# key stays relative to output_files/, so the verifier needs no change. This ARCHIVES the
# evidence rather than relaxing the check.
record_artifact() {
  local label="$1" file="$2"
  require_fresh_file "$file"
  "$PYTHON" quartus/release_gate.py record \
    --manifest "$MANIFEST" --label "$label" --file "$file"
}

# PRESERVE THIS VARIANT'S BOUND REPORTS.
# MEASURED by the T-unit session 2026-08-02: Quartus writes every report to the SAME names
# (Arcade-SmashTV.fit.rpt, .map.rpt, .sta.summary ...). This repo builds MULTIPLE variants from
# one project directory and the two audio siblings are queued BACK TO BACK, so the second
# build silently destroys the first's bound evidence: its RBF still hashes and is still
# genuine, but it becomes UNPACKAGEABLE because the manifest's report hashes no longer match
# anything on disk. That cost T-unit two rebuilds.
#
# NOTE the thing that makes the obvious fix wrong: ram_release_gate.py cross-checks the
# manifest record's PATH as well as its hash (its manifest-input verification errors with
# "path disagrees with build manifest"), so re-pointing record_artifact at an archive
# directory FAILS THE BUILD. Archive as a COPY alongside instead, leaving every recorded path
# exactly where the gates expect it.
archive_variant_reports() {
  local archive_dir="$ROOT/output_files/reports-$OUTNAME"
  mkdir -p "$archive_dir" || return 0
  local f
  for f in "$ROOT/output_files/$REV".*; do
    [[ -f "$f" ]] && cp -p "$f" "$archive_dir/" 2>/dev/null || true
  done
  echo "=== archived this variant's reports to output_files/reports-$OUTNAME/ ===" >&2
}

run_stage() {
  local name="$1" log="$2"
  shift 2
  echo "=== $name ==="
  if "$@" >"$log" 2>&1; then
    :
  else
    local rc=$?
    echo "!!! $name FAILED (exit $rc); tail of $log:" >&2
    tail -40 "$log" >&2 || true
    return "$rc"
  fi
  if grep -q "Error (" "$log"; then
    echo "!!! $name emitted a Quartus error despite exit status 0:" >&2
    grep "Error (" "$log" | tail -10 >&2 || true
    return 1
  fi
  grep -iE "Worst-case .* slack is|Was (successful|unsuccessful)|Status :|Error \\(" \
    "$log" | tail -12 || true
}

require_worker_count() {
  local log="$1"
  if [[ "$QUARTUS_PARALLEL" == 1 ]]; then
    grep -Eqi "Parallel compilation is disabled|will use 1( |$)" "$log" \
      || die "could not verify one-worker Quartus execution in $log"
  else
    grep -Eqi "will use (up to )?$QUARTUS_PARALLEL( |$)" "$log" \
      || die "Quartus did not confirm $QUARTUS_PARALLEL workers in $log"
  fi
}

echo "=== pinned build identity ==="
echo "Quartus: $QUARTUS_VERSION ($QUARTUS_SH_SHA256)"
echo "  map:   $QUARTUS_MAP_SHA256"
echo "  fit:   $QUARTUS_FIT_SHA256"
echo "  sta:   $QUARTUS_STA_SHA256"
echo "  asm:   $QUARTUS_ASM_SHA256"
echo "sv2v:    $SV2V_VERSION ($SV2V_SHA256)"
echo "workers: $QUARTUS_PARALLEL"
echo "run:     $RUN_ID"

# quartus_map is invoked directly, so refresh build_id before sv2v consumes the
# top-level include. This output is also recorded as a build artifact.
run_stage build_identity "$RUN_DIR/build_identity.log" \
  "$QBIN/quartus_sh" -t "$ROOT/sys/build_id.tcl" "$REV" "$REV"
record_artifact build_id "$ROOT/build_id.v"
grep -Fq "File(\"$REV.sof\")" "$ROOT/jtag.cdf" \
  || die "generated jtag.cdf does not name revision $REV"
record_artifact jtag_cdf "$ROOT/jtag.cdf"

echo "=== sv2v (always regenerated) ==="
if bash "$ROOT/quartus/build_sv2v.sh" >"$RUN_DIR/sv2v.log" 2>&1; then
  sed -n '1,5p' "$RUN_DIR/sv2v.log"
else
  rc=$?
  tail -40 "$RUN_DIR/sv2v.log" >&2 || true
  exit "$rc"
fi
record_artifact generated_netlist "$ROOT/build_syn/smashtv_core.v"

# Elaborate the complete emu top against the netlist just generated, BEFORE
# spending a map/fit attempt on it. This is licence-free (Icarus, seconds) and it
# is the only gate that can catch an emu<->core port/width mismatch or a wrong
# CORE_TOP selection; the recovery transfer audit reads source text, and Quartus
# would not report either until it had already consumed the build slot. The gate
# asserts the ELABORATED hierarchy: the recovery top selected, every recovery
# module present, and every family block absent.
if has_token "$MACRO" "YUNIT_FAMILY2"; then
  if [[ "$SV2V_EXTRA" == *-DYUNIT_DISPLAY_SEQ* ]]; then
    ELAB_MODE=cvsdseq-icarus
  else
    ELAB_MODE=family2-icarus
  fi
elif has_token "$MACRO" "YUNIT_ADPCM"; then
  ELAB_MODE=adpcm-icarus
elif has_token "$MACRO" "YUNIT_FULL"; then
  ELAB_MODE=full-icarus
else
  ELAB_MODE=recovery-icarus
fi
if has_token "$MACRO" "YUNIT_SMASH_RECOVERY" || has_token "$MACRO" "YUNIT_FAMILY2" \
   || has_token "$MACRO" "YUNIT_ADPCM" || has_token "$MACRO" "YUNIT_FULL"; then
  ELAB_LOG="$RUN_DIR/recovery_elaboration.log"
  # A diagnostic flavour must be elaborated WITH its define, or the gate proves nothing
  # about the image actually being fitted (the emu overlay would be compiled out while the
  # core blob already carries the counters).
  ELAB_EXTRA=""
  has_token "$MACRO" "DIAG_SERVICE" && ELAB_EXTRA="-DDIAG_SERVICE"
  if ELAB_SKIP_SV2V=1 ELAB_EXTRA_DEFINES="$ELAB_EXTRA" bash "$ROOT/sim/elab_top.sh" "$ELAB_MODE" \
      >"$ELAB_LOG" 2>&1; then
    grep -E "elaborated-hierarchy gate PASS" "$ELAB_LOG"
  else
    rc=$?
    tail -40 "$ELAB_LOG" >&2 || true
    die "emu elaboration gate ($ELAB_MODE) failed (exit $rc); see $ELAB_LOG"
  fi
  "$PYTHON" quartus/release_gate.py record \
    --manifest "$MANIFEST" --label recovery_elaboration \
    --file "$ELAB_LOG"
fi

# DISPLAY-BASE gates. Licence-free iverilog, seconds each, Family2 only. They
# guard the DPYSTRT producer -- the thing that decides WHICH VRAM page scanout
# reads, i.e. whether a page-flipping title renders or flashes.
#   dispbase_wired : the runtime-base capability is compiled into the SHIPPING
#                    flavour (not just into a -DYUNIT_FULL bench that never ships)
#   dispbase_phase : the producer reproduces the GOSPEL row (tms34010.cpp:
#                    1149-1152) for every title's MEASURED DPYSTRT values, with
#                    the old delta form re-derived as the mutation control
#
# NEITHER was wired into a build before 2026-08-16. gate_family2_dpystrt_wired.sh
# sat RED from b3cdae0 onward -- it checked a video binding that commit had just
# replaced -- and nothing noticed, because nothing ran it. An unrun gate reports
# the same as a passing one.
if has_token "$MACRO" "YUNIT_FAMILY2"; then
  for spec in "sim/gate_family2_dpystrt_wired.sh:dispbase_wired" \
              "sim/probe/dispbase-phase/run_gate.sh:dispbase_phase" \
              "sim/probe/crtc-width/run_gate.sh:crtc_width" \
              "sim/probe/crtc-track/run_gate.sh:crtc_track" \
              "sim/probe/erase-base/run_gate.sh:erase_base" \
              "sim/probe/display-tap/run_gate.sh:display_tap"; do
    gpath="${spec%%:*}"; glabel="${spec##*:}"
    # A malformed entry in this list is otherwise an exit-127 "no such file"
    # deep in a build: a mangled line continuation once put a bare "n" in here
    # and bash -n passed it, because a bogus loop item is valid SYNTAX.
    [ -f "$ROOT/$gpath" ] \
      || die "display-base gate list is malformed: no such gate '$gpath' (from spec '$spec')"
    glog="$RUN_DIR/${glabel}.log"
    if bash "$ROOT/$gpath" >"$glog" 2>&1; then
      tail -1 "$glog"
    else
      rc=$?
      tail -25 "$glog" >&2 || true
      # 77 is INCONCLUSIVE (missing tool / broken search). It is NOT a pass:
      # a gate that could not run must never wave a build through.
      [ "$rc" -eq 77 ] && die "display-base gate $gpath INCONCLUSIVE (exit 77); see $glog"
      die "display-base gate $gpath failed (exit $rc); see $glog"
    fi
    "$PYTHON" quartus/release_gate.py record \
      --manifest "$MANIFEST" --label "$glabel" --file "$glog"
  done
fi

# ADPCM flavour: same discipline for the DYNAMIC video path it actually ships.
# dispbase_phase guards the shared DPYSTRT producer; dyn_width guards the
# runtime CRTC width on yunit_video (mkla1 400 / term2 404 vs the raster's 410,
# measured MAME 0.289 crtc_geom 2026-08-16). Wired here the day the fix landed
# so it can never sit unrun (the gate_family2_dpystrt_wired.sh lesson above).
if has_token "$MACRO" "YUNIT_ADPCM"; then
  for spec in "sim/probe/dispbase-phase/run_gate.sh:dispbase_phase" \
              "sim/probe/dyn-width/run_gate.sh:dyn_width" \
              "sim/run_adpcm_starve_gate.sh:adpcm_starve" \
              "sim/run_adpcm_pace_gate.sh:adpcm_pace" \
              "sim/probe/erase-base/run_gate.sh:erase_base" \
              "sim/probe/display-tap/run_gate.sh:display_tap"; do
    gpath="${spec%%:*}"; glabel="${spec##*:}"
    [ -f "$ROOT/$gpath" ] \
      || die "adpcm display gate list is malformed: no such gate '$gpath' (from spec '$spec')"
    glog="$RUN_DIR/${glabel}.log"
    if bash "$ROOT/$gpath" >"$glog" 2>&1; then
      tail -1 "$glog"
    else
      rc=$?
      tail -25 "$glog" >&2 || true
      [ "$rc" -eq 77 ] && die "adpcm display gate $gpath INCONCLUSIVE (exit 77); see $glog"
      die "adpcm display gate $gpath failed (exit $rc); see $glog"
    fi
    "$PYTHON" quartus/release_gate.py record \
      --manifest "$MANIFEST" --label "$glabel" --file "$glog"
  done
fi

MACROARG=()
for m in $MACRO; do
  MACROARG+=(--verilog_macro="$m")
done

run_stage quartus_map "$RUN_DIR/quartus_map.log" \
  "$QBIN/quartus_map" "$REV" -c "$REV" --parallel="$QUARTUS_PARALLEL" \
  --read_settings_files=on --write_settings_files=off \
  "${MACROARG[@]}"
require_worker_count "$RUN_DIR/quartus_map.log"
require_summary_status "$ROOT/output_files/$REV.map.summary" \
  "Analysis & Synthesis Status : Successful"
record_artifact map_summary "$ROOT/output_files/$REV.map.summary"
record_artifact map_report "$ROOT/output_files/$REV.map.rpt"
record_artifact map_log "$RUN_DIR/quartus_map.log"

# QSF SNAPSHOT/RESTORE AROUND A SEEDED FIT.
# MEASURED by the T-unit session 2026-08-02: `quartus_fit --seed=N` is NOT transient --
# Quartus PERSISTS the override back into the project file, rewriting
# `set_global_assignment -name SEED`. The QSF is a hashed provenance input, so a seeded fit
# silently invalidates EVERY artifact recorded against the previous QSF, including images
# built earlier that the fit never touched. In this repo that blast radius includes the
# CABINET-CONFIRMED Recovery manifest, because QSF_SEED is pinned at 2 while the family2 /
# CVSD flavour fits at seed 4 -- and the two sibling builds run back to back, so without this
# they would also churn the file against each other.
# Restored on EVERY exit path, so a build that dies mid-fit cannot leave the shared project
# file mutated for the next session.
QSF_PATH="$ROOT/$REV.qsf"
QSF_SNAPSHOT="$RUN_DIR/$REV.qsf.preseed"
if [[ "$FIT_SEED" != "$QSF_SEED" ]]; then
  cp -p "$QSF_PATH" "$QSF_SNAPSHOT" || die "could not snapshot $QSF_PATH before a seeded fit"
  restore_qsf() {
    if [[ -f "$QSF_SNAPSHOT" ]] && ! cmp -s "$QSF_SNAPSHOT" "$QSF_PATH"; then
      cp -p "$QSF_SNAPSHOT" "$QSF_PATH" \
        && echo "=== restored $REV.qsf: the seeded fit rewrote it; QSF stays pinned at SEED $QSF_SEED ===" >&2
    fi
  }
fi

run_stage quartus_fit "$RUN_DIR/quartus_fit.log" \
  "$QBIN/quartus_fit" "$REV" -c "$REV" --parallel="$QUARTUS_PARALLEL" \
  --seed="$FIT_SEED" \
  --read_settings_files=on --write_settings_files=off
require_worker_count "$RUN_DIR/quartus_fit.log"
require_summary_status "$ROOT/output_files/$REV.fit.summary" \
  "Fitter Status : Successful"
# The fitter reports the seed it actually used. Check that, not our intent:
# a --seed the tool silently ignored would otherwise look like a real placement
# change and send the next failure down the wrong branch of the ladder.
grep -Eq "^; Fitter Initial Placement Seed[[:space:]]*;[[:space:]]*$FIT_SEED[[:space:]]*;" \
  "$ROOT/output_files/$REV.fit.rpt" \
  || die "fitter did not use seed $FIT_SEED (see Fitter Initial Placement Seed in $REV.fit.rpt)"
echo "=== fitter placement seed: $FIT_SEED (QSF pins $QSF_SEED) ==="
# Restore the QSF NOW, explicitly, rather than trusting the EXIT trap: this script sets other
# EXIT traps later (the release-pair rollback) and ends with `trap - EXIT`, either of which
# would discard ours. Doing it here means everything downstream -- the constraint audit, STA,
# packaging, and the next variant's build -- sees the pinned project file.
if [[ "$FIT_SEED" != "$QSF_SEED" ]] && declare -F restore_qsf >/dev/null; then
  restore_qsf
fi
record_artifact fit_summary "$ROOT/output_files/$REV.fit.summary"
record_artifact fit_report "$ROOT/output_files/$REV.fit.rpt"
record_artifact fit_log "$RUN_DIR/quartus_fit.log"
record_artifact pin_report "$ROOT/output_files/$REV.pin"

# Fitted evidence is authoritative for the CRT line buffer. Refuse to spend a
# TimeQuest/assembler pass if it did not become exactly three M10Ks, if total
# M10K use exceeds the release ceiling, or if game-side RAM semantics are
# undefined/unprotected.
"$PYTHON" quartus/ram_release_gate.py \
  --fit-report "$ROOT/output_files/$REV.fit.rpt" \
  --map-log "$RUN_DIR/quartus_map.log" \
  --map-report "$ROOT/output_files/$REV.map.rpt" \
  --output "$RAM_JSON" \
  --manifest "$MANIFEST"
record_artifact ram_gate "$RAM_JSON"

# Consume the authoritative RAM-gate receipt dynamically.  Fitter-equivalent
# shift-register implementations can legitimately change the measured total by
# one M10K; the safety policy is the gate's 512/553 ceiling plus its exact CRT,
# summary-consistency, and RAM-semantics checks.  The verifier also rejects any
# numeric fitted-total assertion copied into this wrapper, so a stale observed
# value cannot block a later safe fit after the real gate has passed.
RAM_RECEIPT_LINE="$(
  "$PYTHON" quartus/verify_ram_release_receipt.py \
    --receipt "$RAM_JSON" \
    --fit-report "$ROOT/output_files/$REV.fit.rpt" \
    --map-log "$RUN_DIR/quartus_map.log" \
    --map-report "$ROOT/output_files/$REV.map.rpt" \
    --consumer-script "$0"
)" || die "RAM release receipt verification failed"
if [[ "$RAM_RECEIPT_LINE" =~ ^RAM_GATE_RECEIPT_V1\ total_m10ks=([0-9]+)\ hierarchy_total_m10ks=([0-9]+)\ device_m10ks=([0-9]+)\ max_release_m10ks=([0-9]+)$ ]]; then
  RAM_TOTAL_M10KS="${BASH_REMATCH[1]}"
  RAM_HIERARCHY_TOTAL_M10KS="${BASH_REMATCH[2]}"
  RAM_DEVICE_M10KS="${BASH_REMATCH[3]}"
  RAM_MAX_RELEASE_M10KS="${BASH_REMATCH[4]}"
else
  die "RAM release receipt emitted an invalid result line"
fi
echo "$RAM_RECEIPT_LINE"

run_stage quartus_sta "$RUN_DIR/quartus_sta.log" \
  "$QBIN/quartus_sta" "$REV" -c "$REV" --parallel="$QUARTUS_PARALLEL"
require_worker_count "$RUN_DIR/quartus_sta.log"
record_artifact sta_summary "$ROOT/output_files/$REV.sta.summary"
record_artifact sta_report "$ROOT/output_files/$REV.sta.rpt"
record_artifact sta_log "$RUN_DIR/quartus_sta.log"

# This opens the fitted timing netlist and asserts that every release-critical
# SDC collection still resolves. Optional production-only diagnostic nodes are
# reported, but are not required.
audit_macro="$MACRO"
for token in $SV2V_EXTRA; do
  case "$token" in
    -D*) audit_macro="$audit_macro ${token#-D}" ;;
  esac
done
run_stage constraint_audit "$RUN_DIR/constraint_audit.log" \
  env YUNIT_BUILD_MACRO="$audit_macro" \
  "$QBIN/quartus_sta" -t "$ROOT/quartus/audit_release_constraints.tcl"
grep "SDC_AUDIT" "$RUN_DIR/constraint_audit.log" || true
record_artifact constraint_audit_log "$RUN_DIR/constraint_audit.log"

"$PYTHON" quartus/release_gate.py timing-gate \
  --sta-log "$RUN_DIR/quartus_sta.log" \
  --sta-report "$ROOT/output_files/$REV.sta.rpt" \
  --fit-report "$ROOT/output_files/$REV.fit.rpt" \
  --macro="$MACRO" \
  --output "$TIMING_JSON" \
  --manifest "$MANIFEST" \
  --board-io-waiver-policy "$BOARD_IO_WAIVER_POLICY"
record_artifact timing_gate "$TIMING_JSON"
"$PYTHON" quartus/release_gate.py verify-inputs --manifest "$MANIFEST"

# quartus_sta exits zero on negative slack. The Python gate above is therefore
# the sole path to this point, and it requires all five checks at all four
# operating corners to be non-negative.
[[ ! -e "$ROOT/output_files/$REV.rbf" ]] \
  || die "stale RBF appeared before assembler: output_files/$REV.rbf"
run_stage quartus_asm "$RUN_DIR/quartus_asm.log" \
  "$QBIN/quartus_asm" "$REV" -c "$REV" \
  --read_settings_files=on --write_settings_files=off
require_assembler_success "$ROOT/output_files/$REV.asm.rpt"
record_artifact asm_log "$RUN_DIR/quartus_asm.log"
record_artifact rbf "$ROOT/output_files/$REV.rbf"
record_artifact sof "$ROOT/output_files/$REV.sof"
record_artifact asm_report "$ROOT/output_files/$REV.asm.rpt"

mkdir -p "$ROOT/releases"
DEST_RBF="$ROOT/releases/$OUTNAME.rbf"
DEST_MANIFEST="$ROOT/releases/$OUTNAME.manifest.json"

TMP_RBF="$DEST_RBF.$RUN_ID.tmp"
TMP_MANIFEST="$DEST_MANIFEST.$RUN_ID.tmp"
cp -- "$ROOT/output_files/$REV.rbf" "$TMP_RBF"
cmp -s -- "$ROOT/output_files/$REV.rbf" "$TMP_RBF" \
  || die "release copy verification failed: $TMP_RBF"
"$PYTHON" quartus/release_gate.py mark \
  --manifest "$MANIFEST" --status passed --exit-code 0
cp -- "$MANIFEST" "$TMP_MANIFEST"

# Publish the RBF first and the manifest last: a visible passed manifest is the
# commit point. Retain and restore the prior pair if either move or the
# byte-exact post-publish verification fails.
PRIOR_RBF_SAVED=0
PRIOR_MANIFEST_SAVED=0
NEW_RBF_INSTALLED=0
NEW_MANIFEST_INSTALLED=0
rollback_release_pair() {
  if [[ "$NEW_RBF_INSTALLED" == 1 ]]; then
    rm -f -- "$DEST_RBF"
  fi
  if [[ "$NEW_MANIFEST_INSTALLED" == 1 ]]; then
    rm -f -- "$DEST_MANIFEST"
  fi
  rm -f -- "$TMP_RBF" "$TMP_MANIFEST"
  if [[ "$PRIOR_RBF_SAVED" == 1 ]]; then
    mv -- "$RUN_DIR/prior-release.rbf" "$DEST_RBF" || true
  fi
  if [[ "$PRIOR_MANIFEST_SAVED" == 1 ]]; then
    mv -- "$RUN_DIR/prior-release.manifest.json" "$DEST_MANIFEST" || true
  fi
}
publish_release_pair() {
  if [[ -e "$DEST_RBF" ]]; then
    mv -- "$DEST_RBF" "$RUN_DIR/prior-release.rbf" || return
    PRIOR_RBF_SAVED=1
  fi
  if [[ -e "$DEST_MANIFEST" ]]; then
    mv -- "$DEST_MANIFEST" "$RUN_DIR/prior-release.manifest.json" || return
    PRIOR_MANIFEST_SAVED=1
  fi
  mv -- "$TMP_RBF" "$DEST_RBF" || return
  NEW_RBF_INSTALLED=1
  mv -- "$TMP_MANIFEST" "$DEST_MANIFEST" || return
  NEW_MANIFEST_INSTALLED=1
  "$PYTHON" quartus/release_gate.py verify-release-pair \
    --manifest "$DEST_MANIFEST" --rbf "$DEST_RBF" || return
}
if ! publish_release_pair; then
  rollback_release_pair
  die "release pair publication or post-publish verification failed"
fi

if ! rmdir -- "$LOCK_DIR"; then
  # Do not leave a newly-published passed pair behind when the build itself
  # cannot complete cleanly. The publication state is still available here,
  # so restore the prior release pair before reporting failure.
  rollback_release_pair
  die "could not release Quartus build lock: $LOCK_DIR"
fi
LOCK_HELD=0
BUILD_PUBLISHED=1
trap - EXIT
archive_variant_reports
echo "=== release passed every gate ==="
echo "RBF:      $DEST_RBF"
echo "manifest: $DEST_MANIFEST"
echo "run logs: $RUN_DIR"
