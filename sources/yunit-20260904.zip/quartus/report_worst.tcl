project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist -model slow
read_sdc
update_timing_netlist
puts "===== WORST SETUP PATHS (slow corner) ====="
report_timing -setup -npaths 4 -detail summary -stdout
puts "===== WORST SETUP PATH FULL DETAIL ====="
report_timing -setup -npaths 1 -detail full_path -stdout
puts "===== WORST HOLD PATHS (slow corner) ====="
report_timing -hold -npaths 4 -detail summary -stdout
puts "===== WORST HOLD PATH FULL DETAIL ====="
report_timing -hold -npaths 1 -detail full_path -stdout
project_close
