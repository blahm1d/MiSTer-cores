# Read-only fitted-netlist audit of every external SDRAM_DQ input capture path.
# Emits one setup and one hold row per fitted dq_r bit at every operating corner.

project_open -force -revision Arcade-SmashTV Arcade-SmashTV
create_timing_netlist -no_report

set out_path "quartus/sdram_dq_input.tsv"
set out [open $out_path w]
puts $out "record\tcorner\tcheck\tsource\tdestination\tslack_ns\tdata_delay_ns\tlogic_levels\tfrom_clock\tto_clock"

set dq_ports [get_ports -nowarn {SDRAM_DQ[*]}]
set dq_regs [get_registers -no_duplicates -nowarn {*sdram_stock:u_sdram|dq_r*}]

puts $out "META\tALL\tDQ_PORTS\t[get_collection_size $dq_ports]\t\t\t\t\t\t"
puts $out "META\tALL\tDQ_REGISTERS\t\t[get_collection_size $dq_regs]\t\t\t\t\t"

proc emit_check {out corner check dq_ports destination} {
    if {$check eq "setup"} {
        set paths [get_timing_paths -setup -from $dq_ports -to $destination -npaths 1 -nworst 1]
    } else {
        set paths [get_timing_paths -hold -from $dq_ports -to $destination -npaths 1 -nworst 1]
    }

    if {[get_collection_size $paths] == 0} {
        set destination_name [get_node_info $destination -name]
        puts $out "MISSING\t$corner\t$check\t<none>\t$destination_name\t\t\t\t\t"
        return 0
    }

    foreach_in_collection path $paths {
        set source [get_node_info [get_path_info -from $path] -name]
        set destination_name [get_node_info [get_path_info -to $path] -name]
        set slack [get_path_info -slack $path]
        set data_delay [get_path_info -data_delay $path]
        set levels [get_path_info -num_logic_levels $path]
        set from_clock [get_clock_info -name [get_path_info -from_clock $path]]
        set to_clock [get_clock_info -name [get_path_info -to_clock $path]]
        puts $out "PATH\t$corner\t$check\t$source\t$destination_name\t$slack\t$data_delay\t$levels\t$from_clock\t$to_clock"
    }
    return 1
}

set total_paths 0
set operating_conditions [get_available_operating_conditions -all]
foreach_in_collection op $operating_conditions {
    set_operating_conditions $op
    read_sdc
    update_timing_netlist
    set corner [get_operating_conditions_info $op -display_name]
    regsub -all {\t} $corner { } corner
    puts "Auditing SDRAM DQ input capture at corner: $corner"

    foreach_in_collection destination $dq_regs {
        incr total_paths [emit_check $out $corner setup $dq_ports $destination]
        incr total_paths [emit_check $out $corner hold $dq_ports $destination]
    }
    flush $out
}

puts $out "META\tALL\tTOTAL_PATH_ROWS\t$total_paths\t\t\t\t\t\t"
close $out
puts "Wrote $total_paths SDRAM DQ setup/hold rows to $out_path"
project_close
