#!/usr/bin/env python3
"""Provenance and fail-closed checks for the Y-unit Quartus release build."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone
from typing import Any, Iterable


EXPECTED_CORNERS = (
    "Slow 1100mV 100C Model",
    "Slow 1100mV -40C Model",
    "Fast 1100mV 100C Model",
    "Fast 1100mV -40C Model",
)
METRICS = ("setup", "hold", "recovery", "removal", "minimum_pulse_width")

# Cabinet thermal-reachability waiver.  A DE10-Nano inside an arcade cabinet
# never reaches a -40C die temperature, so a SETUP miss confined to the cold
# slow corner is not a physically reachable failure.  Like BOARD_IO_WAIVER_
# POLICIES this is an EXACT allow-list of (corner, metric) pairs -- never a
# switch that accepts arbitrary violations.  Deliberately excluded: hold,
# recovery, removal and minimum_pulse_width at every corner (hold failures are
# not temperature-excusable), and the hot slow corner Slow 1100mV 100C, which
# the cabinet genuinely does reach.
SETUP_CORNER_WAIVER_POLICIES: dict[str, frozenset[tuple[str, str]]] = {
    "cabinet-thermal-unreachable-slow-cold-v1": frozenset(
        {("Slow 1100mV -40C Model", "setup")}
    ),
}


def corner_violation_is_waived(corner: str, metric: str, policy: str | None) -> bool:
    """True only for an exact (corner, metric) pair in the named policy."""
    if not policy:
        return False
    allowed = SETUP_CORNER_WAIVER_POLICIES.get(policy)
    if allowed is None:
        raise KeyError(f"unknown setup corner waiver policy: {policy}")
    return (corner, metric) in allowed


MIN_STA_REPORT_BYTES = 100_000
STA_REPORT_REQUIRED_MARKERS = (
    "TimeQuest Timing Analyzer report for Arcade-SmashTV",
    "; TimeQuest Timing Analyzer Summary",
    "; Unconstrained Paths Summary",
    "; TimeQuest Timing Analyzer Messages",
)
BUILD_INPUT_SUFFIXES = {
    ".hex",
    ".mif",
    ".mra",
    ".py",
    ".qip",
    ".qpf",
    ".qsf",
    ".sdc",
    ".sh",
    ".sv",
    ".tcl",
    ".v",
    ".vhd",
    ".vhdl",
}
IMPORTANT_INPUTS = (
    "Arcade-SmashTV.qpf",
    "Arcade-SmashTV.qsf",
    "files.qip",
    "quartus/build_hw.sh",
    "quartus/build_sv2v.sh",
    "quartus/release_gate.py",
    "quartus/ram_release_gate.py",
    "quartus/audit_release_constraints.tcl",
    "rtl/sdram.sdc",
    "sys/build_id.tcl",
    "sys/sys_top.sdc",
    "tools/audit_smashtv_recovery_transfer.py",
    "releases/recovery/Smash T.V. (rev 8.00) [Y-unit firefix recovery].mra",
)
MODEL_RE = re.compile(r"^Info: Analyzing (.+ Model)\s*$")
SLACK_RE = re.compile(
    r"Worst-case (setup|hold|recovery|removal|minimum pulse width) "
    r"slack is\s+([-+]?(?:\d+(?:\.\d*)?|\.\d+))"
)
IGNORED_FILTER_RE = re.compile(
    r"Warning \(332174\): Ignored filter at .*?\(\d+\): "
    r"(.*?) could not be matched"
)
UNCONSTRAINED_INPUT_ROW_RE = re.compile(
    r"^\s*;\s*([^;]+?)\s*;\s*No input delay,", re.MULTILINE
)
UNCONSTRAINED_OUTPUT_ROW_RE = re.compile(
    r"^\s*;\s*([^;]+?)\s*;\s*(?:No output delay,|Partially constrained\s*;)",
    re.MULTILINE,
)
EXPECTED_HDMI_FAST_OUTPUTS = frozenset(
    {
        *(f"HDMI_TX_D[{index}]" for index in range(24)),
        "HDMI_TX_DE",
        "HDMI_TX_HS",
        "HDMI_TX_VS",
    }
)

# These are the only top-level ports that the MiSTer framework intentionally
# leaves without external board timing. The HDMI video outputs follow the
# current MiSTer template policy: their source-synchronous forwarded-clock
# interface is enforced structurally by requiring all 27 final registers to be
# packed into their output cells. The policy remains an exact allow-list, not a
# switch that accepts arbitrary unconstrained I/O. Every observed waived port
# and path count is retained in the release manifest.
BOARD_IO_WAIVER_POLICIES: dict[str, dict[str, Any]] = {
    "mister-standard-framework-io-v1": {
        "inputs": frozenset(
            {
                # Open-drain/asynchronous framework management inputs.
                "HDMI_I2C_SDA",
                "IO_SDA",
                # Shared card-detect / S/PDIF framework pin.
                "SDCD_SPDIF",
            }
        ),
        "outputs": frozenset(
            {
                # Open-drain framework management outputs.
                "HDMI_I2C_SCL",
                "HDMI_I2C_SDA",
                "IO_SCL",
                "IO_SDA",
                # ADV7513 audio/control serial pins; no board capture
                # relationship is specified by the MiSTer reference SDC.
                "HDMI_I2S",
                "HDMI_LRCLK",
                "HDMI_MCLK",
                "HDMI_SCLK",
                # Registered ADV7513 video bus. See
                # validate_hdmi_fast_output_registers().
                *EXPECTED_HDMI_FAST_OUTPUTS,
                # Forwarded source-synchronous clock. TimeQuest recognizes
                # its internal source but reports the board pin as partially
                # constrained under the modern MiSTer template policy.
                "HDMI_TX_CLK",
                # Framework-owned removable-storage and user-I/O pins.
                "SDCD_SPDIF",
                "SDIO_CLK",
                "SDIO_CMD",
                "SDIO_DAT[0]",
                "SDIO_DAT[1]",
                "SDIO_DAT[2]",
                "SDIO_DAT[3]",
                "SD_SPI_CS",
                "USER_IO[2]",
                "USER_IO[4]",
                "USER_IO[5]",
            }
        ),
    }
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def run_git(root: Path, *args: str, binary: bool = False) -> bytes | str:
    result = subprocess.run(
        ["git", *args],
        cwd=root,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.stdout if binary else result.stdout.decode("utf-8", "replace")


def atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def load_manifest(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def source_inventory(root: Path) -> dict[str, Any]:
    tracked_raw = run_git(root, "ls-files", "-z", binary=True)
    untracked_raw = run_git(
        root, "ls-files", "--others", "--exclude-standard", "-z", binary=True
    )
    assert isinstance(tracked_raw, bytes)
    assert isinstance(untracked_raw, bytes)
    candidates: set[str] = set()
    for raw in (tracked_raw, untracked_raw):
        for entry in raw.split(b"\0"):
            if not entry:
                continue
            rel = entry.decode("utf-8", "surrogateescape")
            if Path(rel).suffix.lower() in BUILD_INPUT_SUFFIXES:
                candidates.add(rel)
    # Package descriptors under releases/ may be deliberately git-ignored.
    # Important inputs are still build-contract inputs and must participate in
    # the start/end digest even when Git does not enumerate them.
    for rel in IMPORTANT_INPUTS:
        if Path(rel).suffix.lower() in BUILD_INPUT_SUFFIXES:
            candidates.add(rel)

    aggregate = hashlib.sha256()
    total_bytes = 0
    existing = 0
    for rel in sorted(candidates):
        path = root / rel
        if not path.is_file():
            continue
        file_hash = sha256_file(path)
        size = path.stat().st_size
        aggregate.update(rel.encode("utf-8", "surrogateescape"))
        aggregate.update(b"\0")
        aggregate.update(file_hash.encode("ascii"))
        aggregate.update(b"\0")
        aggregate.update(str(size).encode("ascii"))
        aggregate.update(b"\n")
        total_bytes += size
        existing += 1
    return {
        "algorithm": "SHA256(path\\0SHA256\\0size\\n, sorted by path)",
        "digest": aggregate.hexdigest().upper(),
        "file_count": existing,
        "total_bytes": total_bytes,
    }


def artifact_record(root: Path, path: Path) -> dict[str, Any]:
    resolved = path.resolve()
    try:
        relative = resolved.relative_to(root.resolve()).as_posix()
    except ValueError:
        relative = str(resolved)
    stat = resolved.stat()
    return {
        "path": relative,
        "sha256": sha256_file(resolved),
        "size": stat.st_size,
        "mtime_utc": datetime.fromtimestamp(
            stat.st_mtime, timezone.utc
        ).isoformat().replace("+00:00", "Z"),
    }


def evidence_record(path: Path) -> tuple[str, dict[str, Any]]:
    """Read one physical-tool artifact and retain byte-exact identity."""

    resolved = path.resolve()
    data = resolved.read_bytes()
    return data.decode("utf-8", errors="replace"), {
        "path": str(resolved),
        "sha256": hashlib.sha256(data).hexdigest().upper(),
        "size": len(data),
    }


def validate_manifest_artifacts(
    manifest: dict[str, Any],
    observed: dict[str, dict[str, Any]],
) -> list[str]:
    """Bind gate inputs to the exact files recorded earlier in the run."""

    errors: list[str] = []
    root_value = manifest.get("root")
    if not isinstance(root_value, str) or not root_value:
        errors.append("build manifest has no valid root")
        root = None
    else:
        root = Path(root_value).resolve()

    artifacts = manifest.get("artifacts")
    if not isinstance(artifacts, dict):
        errors.append("build manifest has no artifacts object")
        artifacts = {}

    for label, actual in observed.items():
        expected = artifacts.get(label)
        if not isinstance(expected, dict):
            errors.append(f"build manifest has no {label} artifact record")
            continue

        expected_path_value = expected.get("path")
        if not isinstance(expected_path_value, str) or not expected_path_value:
            errors.append(f"build manifest {label} artifact has no valid path")
        elif root is not None:
            expected_path = Path(expected_path_value)
            if not expected_path.is_absolute():
                expected_path = root / expected_path
            if os.path.normcase(str(expected_path.resolve())) != os.path.normcase(
                actual["path"]
            ):
                errors.append(
                    f"{label} path disagrees with build manifest: "
                    f"{actual['path']} vs {expected_path.resolve()}"
                )

        if expected.get("size") != actual["size"]:
            errors.append(
                f"{label} size disagrees with build manifest: "
                f"{actual['size']} vs {expected.get('size')}"
            )
        expected_hash = expected.get("sha256")
        if (
            not isinstance(expected_hash, str)
            or expected_hash.upper() != actual["sha256"]
        ):
            errors.append(
                f"{label} SHA256 disagrees with build manifest: "
                f"{actual['sha256']} vs {expected_hash}"
            )
    return errors


def parse_qsf(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8", errors="replace")

    def last_value(name: str) -> str | None:
        matches = re.findall(
            rf"set_global_assignment\s+-name\s+{re.escape(name)}\s+\"?([^\"\r\n]+?)\"?\s*$",
            text,
            flags=re.MULTILINE,
        )
        return matches[-1].strip() if matches else None

    seed = last_value("SEED")
    return {
        "device": last_value("DEVICE"),
        "family": last_value("FAMILY"),
        "last_quartus_version": last_value("LAST_QUARTUS_VERSION"),
        "seed": int(seed) if seed and seed.isdigit() else seed,
        "smart_recompile": last_value("SMART_RECOMPILE"),
        "qsf_parallel_assignment": last_value("NUM_PARALLEL_PROCESSORS"),
    }


def important_input_records(root: Path) -> dict[str, Any]:
    records: dict[str, Any] = {}
    for rel in IMPORTANT_INPUTS:
        path = root / rel
        if path.is_file():
            records[rel] = artifact_record(root, path)
    return records


def optional_sdc_filter(filter_text: str, macro: str) -> bool:
    always_optional = (
        "arc*",
        "general[3].gpll~PLL_OUTPUT_COUNTER|divclk",
    )
    diagnostic_only = (
        "*yunit_top:yunit_top|ack_q*",
        "*yunit_top:yunit_top|d_prevpc*",
        "*yunit_top:yunit_top|d_started*",
        "*yunit_top:yunit_top|dbg_culprit_instr*",
        "*yunit_top:yunit_top|dbg_culprit_pc*",
        "*yunit_top:yunit_top|dbg_derail_pc*",
        "*yunit_top:yunit_top|dbg_derailed*",
        "*yunit_top:yunit_top|rd_cnt*",
        "*yunit_top_smash_firefix:yunit_top|ack_q*",
        "*yunit_top_smash_firefix:yunit_top|d_prevpc*",
        "*yunit_top_smash_firefix:yunit_top|d_started*",
        "*yunit_top_smash_firefix:yunit_top|dbg_culprit_instr*",
        "*yunit_top_smash_firefix:yunit_top|dbg_culprit_pc*",
        "*yunit_top_smash_firefix:yunit_top|dbg_derail_pc*",
        "*yunit_top_smash_firefix:yunit_top|dbg_derailed*",
        "*yunit_top_smash_firefix:yunit_top|rd_cnt*",
    )
    macro_names = frozenset(
        token.split("=", 1)[0] for token in macro.split()
    )
    if any(token in filter_text for token in always_optional):
        return True
    if (
        any(token in filter_text for token in diagnostic_only)
        and "DIAG_BOOT" not in macro_names
    ):
        return True
    if (
        "*smashtv_diag2_overlay:u_diag2|*" in filter_text
        and "DIAG_BOOT" not in macro_names
    ):
        return True
    return False


def parse_unconstrained_summary(text: str) -> dict[str, int]:
    names = (
        "Illegal Clocks",
        "Unconstrained Clocks",
        "Unconstrained Input Ports",
        "Unconstrained Input Port Paths",
        "Unconstrained Output Ports",
        "Unconstrained Output Port Paths",
    )
    result: dict[str, int] = {}
    for name in names:
        match = re.search(
            rf";\s*{re.escape(name)}\s*;\s*(\d+)\s*;\s*(\d+)\s*;",
            text,
        )
        if match:
            # Setup and hold counts are normally equal. Conservatively retain
            # the larger value in the release manifest.
            result[name] = max(int(match.group(1)), int(match.group(2)))
    return result


def parse_unconstrained_ports(text: str) -> dict[str, list[str]]:
    """Return unique I/O names from both setup and hold coverage tables."""

    return {
        "inputs": sorted(set(UNCONSTRAINED_INPUT_ROW_RE.findall(text))),
        "outputs": sorted(set(UNCONSTRAINED_OUTPUT_ROW_RE.findall(text))),
    }


def validate_hdmi_fast_output_registers(fit_report: str) -> dict[str, Any]:
    """Require the modern MiSTer HDMI video bus to remain packed into IOEs."""

    expected_sources = {
        **{f"HDMI_TX_D[{index}]": f"hdmi_out_d[{index}]" for index in range(24)},
        "HDMI_TX_DE": "hdmi_out_de",
        "HDMI_TX_HS": "hdmi_out_hs",
        "HDMI_TX_VS": "hdmi_out_vs",
    }
    observed: dict[str, list[str]] = {}
    forwarded_clock_output_registers: list[str] = []

    for line in fit_report.splitlines():
        fields = [field.strip() for field in line.split(";")]
        if (
            len(fields) >= 9
            and fields[1] == "HDMI_TX_CLK"
            and fields[7] in {"yes", "no"}
        ):
            forwarded_clock_output_registers.append(fields[7])
        if len(fields) < 9 or fields[2] != "Packed Register":
            continue
        if fields[4] != "Fast Output Register assignment":
            continue
        target = fields[7].removesuffix("~output")
        if target not in EXPECTED_HDMI_FAST_OUTPUTS:
            continue
        observed.setdefault(target, []).append(fields[1])

    errors: list[str] = []
    missing = sorted(EXPECTED_HDMI_FAST_OUTPUTS - set(observed))
    unexpected_sources = {
        target: sources
        for target, sources in observed.items()
        if sources != [expected_sources[target]]
    }
    if missing:
        errors.append(
            "HDMI video outputs missing packed fast-output registers: "
            + ", ".join(missing)
        )
    if unexpected_sources:
        details = ", ".join(
            f"{target}={sources}"
            for target, sources in sorted(unexpected_sources.items())
        )
        errors.append(f"HDMI fast-output register mapping mismatch: {details}")
    if forwarded_clock_output_registers != ["yes"]:
        errors.append(
            "HDMI_TX_CLK is not implemented by exactly one output register: "
            f"{forwarded_clock_output_registers}"
        )

    return {
        "passed": not errors,
        "expected_count": len(EXPECTED_HDMI_FAST_OUTPUTS),
        "observed_count": len(observed),
        "outputs": {target: observed[target] for target in sorted(observed)},
        "forwarded_clock_output_register": (
            forwarded_clock_output_registers == ["yes"]
        ),
        "errors": errors,
    }


def parse_timing(
    sta_log: str,
    sta_report: str,
    macro: str = "",
    board_io_waiver_policy: str = "none",
    setup_corner_waiver_policy: str | None = None,
    fit_report: str | None = None,
) -> dict[str, Any]:
    corners: dict[str, dict[str, float]] = {}
    current_corner: str | None = None
    ignored_filters: list[dict[str, Any]] = []
    errors: list[str] = []

    for line in sta_log.splitlines():
        model_match = MODEL_RE.match(line.strip())
        if model_match:
            current_corner = model_match.group(1)
            corners.setdefault(current_corner, {})
            continue

        slack_match = SLACK_RE.search(line)
        if slack_match:
            metric = slack_match.group(1).replace(" ", "_")
            if current_corner is None:
                errors.append(f"slack reported before operating corner: {line.strip()}")
                continue
            if metric in corners[current_corner]:
                errors.append(
                    f"duplicate {metric} slack for operating corner {current_corner}"
                )
                continue
            value = float(slack_match.group(2))
            corners[current_corner][metric] = value
            continue

        if "Warning (332174): Ignored filter" in line:
            ignored_match = IGNORED_FILTER_RE.search(line)
            filter_text = ignored_match.group(1) if ignored_match else line.strip()
            optional = optional_sdc_filter(filter_text, macro)
            ignored_filters.append({"filter": filter_text, "optional": optional})

    waived_corner_violations: list[dict[str, Any]] = []
    expected = set(EXPECTED_CORNERS)
    observed = set(corners)
    for missing in sorted(expected - observed):
        errors.append(f"missing operating corner: {missing}")
    for extra in sorted(observed - expected):
        errors.append(f"unexpected operating corner: {extra}")

    for corner in EXPECTED_CORNERS:
        values = corners.get(corner, {})
        for metric in METRICS:
            if metric not in values:
                errors.append(f"missing {metric} slack for {corner}")
                continue
            value = values[metric]
            if not math.isfinite(value):
                errors.append(f"non-finite {metric} slack for {corner}: {value}")
            # Quartus prints three decimals. Treat textual "-0.000" as a
            # violation too; it represents a negative value rounded for display.
            elif value < 0.0 or math.copysign(1.0, value) < 0.0:
                detail = f"negative {metric} slack for {corner}: {value:.3f} ns"
                if corner_violation_is_waived(
                    corner, metric, setup_corner_waiver_policy
                ):
                    waived_corner_violations.append(
                        {"corner": corner, "metric": metric, "slack_ns": value}
                    )
                else:
                    errors.append(detail)

    unapproved = [item["filter"] for item in ignored_filters if not item["optional"]]
    for filter_text in unapproved:
        errors.append(f"required or unknown SDC filter did not match: {filter_text}")

    if "Quartus Prime TimeQuest Timing Analyzer was successful." not in sta_log:
        errors.append("TimeQuest success marker is missing")
    if re.search(r"^Error \(", sta_log, flags=re.MULTILINE):
        errors.append("TimeQuest log contains a Quartus error")

    critical_warning_ids = sorted(
        set(
            re.findall(
                r"Critical Warning \((\d+)\)",
                f"{sta_log}\n{sta_report}",
            )
        )
    )
    # Critical Warning 332148 is "Timing requirements not met" -- Quartus emits it
    # as the DIRECT CONSEQUENCE of a setup miss and then restates the same
    # worst-case slack. When a cold-corner setup violation has been explicitly
    # waived above, 332148 is that same fact reported by another instrument, not
    # a second defect. Tolerate ONLY that id, ONLY when a waiver actually fired,
    # and record it in the result so it can never pass silently. Every other
    # critical-warning id still errors, and with no waiver 332148 still errors.
    tolerated_ids = {"332148"} if waived_corner_violations else set()
    waived_critical_warning_ids = [
        i for i in critical_warning_ids if i in tolerated_ids
    ]
    remaining_critical_warning_ids = [
        i for i in critical_warning_ids if i not in tolerated_ids
    ]
    if remaining_critical_warning_ids:
        errors.append(
            "TimeQuest evidence contains critical warning(s): "
            + ", ".join(remaining_critical_warning_ids)
        )

    sta_report_bytes = len(sta_report.encode("utf-8", errors="replace"))
    if sta_report_bytes < MIN_STA_REPORT_BYTES:
        errors.append(
            f"STA report is {sta_report_bytes} bytes "
            f"(< {MIN_STA_REPORT_BYTES}); truncated evidence is inconclusive"
        )
    for marker in STA_REPORT_REQUIRED_MARKERS:
        if marker not in sta_report:
            errors.append(f"STA report is missing completeness marker: {marker}")
    terminal_report = re.search(
        r"Info: Quartus Prime TimeQuest Timing Analyzer was successful\. "
        r"0 errors, \d+ warnings\s*\n"
        r"\s*Info: Peak virtual memory:.*\n"
        r"\s*Info: Processing ended:.*\n"
        r"\s*Info: Elapsed time:.*\n"
        r"\s*Info: Total CPU time \(on all processors\):.*\s*$",
        sta_report,
    )
    if terminal_report is None:
        errors.append("STA report terminal success sequence is missing")

    unconstrained = parse_unconstrained_summary(sta_report)
    unconstrained_ports = parse_unconstrained_ports(sta_report)
    for required_summary in (
        "Illegal Clocks",
        "Unconstrained Clocks",
        "Unconstrained Input Ports",
        "Unconstrained Input Port Paths",
        "Unconstrained Output Ports",
        "Unconstrained Output Port Paths",
    ):
        if required_summary not in unconstrained:
            errors.append(
                f"STA report is missing constraint summary row: {required_summary}"
            )
    if unconstrained.get("Illegal Clocks", 0) != 0:
        errors.append(f"illegal clocks reported: {unconstrained['Illegal Clocks']}")
    if unconstrained.get("Unconstrained Clocks", 0) != 0:
        errors.append(
            f"unconstrained clocks reported: {unconstrained['Unconstrained Clocks']}"
        )

    not_fully_constrained = "Design is not fully constrained" in sta_log
    unconstrained_io_count = sum(
        unconstrained.get(name, 0)
        for name in (
            "Unconstrained Input Ports",
            "Unconstrained Input Port Paths",
            "Unconstrained Output Ports",
            "Unconstrained Output Port Paths",
        )
    )
    has_unconstrained_io = not_fully_constrained or unconstrained_io_count != 0
    waiver: dict[str, Any] | None = None
    if board_io_waiver_policy == "none":
        if has_unconstrained_io:
            errors.append(
                "design is not fully constrained; either constrain every board "
                "I/O or select an explicit BOARD_IO_WAIVER_POLICY"
            )
    elif board_io_waiver_policy not in BOARD_IO_WAIVER_POLICIES:
        errors.append(f"unknown board I/O waiver policy: {board_io_waiver_policy}")
    else:
        allowed = BOARD_IO_WAIVER_POLICIES[board_io_waiver_policy]
        observed_inputs = set(unconstrained_ports["inputs"])
        observed_outputs = set(unconstrained_ports["outputs"])
        unexpected_inputs = sorted(observed_inputs - allowed["inputs"])
        unexpected_outputs = sorted(observed_outputs - allowed["outputs"])
        missing_inputs = sorted(allowed["inputs"] - observed_inputs)
        missing_outputs = sorted(allowed["outputs"] - observed_outputs)

        summary_input_count = unconstrained.get("Unconstrained Input Ports", 0)
        summary_output_count = unconstrained.get("Unconstrained Output Ports", 0)
        if summary_input_count != len(observed_inputs):
            errors.append(
                "unconstrained input table/count mismatch: "
                f"summary={summary_input_count}, parsed={len(observed_inputs)}"
            )
        if summary_output_count != len(observed_outputs):
            errors.append(
                "unconstrained output table/count mismatch: "
                f"summary={summary_output_count}, parsed={len(observed_outputs)}"
            )
        if unexpected_inputs:
            errors.append(
                "unconstrained input ports outside "
                f"{board_io_waiver_policy}: {', '.join(unexpected_inputs)}"
            )
        if unexpected_outputs:
            errors.append(
                "unconstrained output ports outside "
                f"{board_io_waiver_policy}: {', '.join(unexpected_outputs)}"
            )
        if missing_inputs:
            errors.append(
                "expected unconstrained input ports absent from "
                f"{board_io_waiver_policy}: {', '.join(missing_inputs)}"
            )
        if missing_outputs:
            errors.append(
                "expected unconstrained output ports absent from "
                f"{board_io_waiver_policy}: {', '.join(missing_outputs)}"
            )

        waiver = {
            "policy": board_io_waiver_policy,
            "waived_input_ports": unconstrained_ports["inputs"],
            "waived_output_ports": unconstrained_ports["outputs"],
            "input_path_count": unconstrained.get(
                "Unconstrained Input Port Paths", 0
            ),
            "output_path_count": unconstrained.get(
                "Unconstrained Output Port Paths", 0
            ),
        }

    hdmi_fast_outputs = (
        validate_hdmi_fast_output_registers(fit_report)
        if fit_report is not None
        else None
    )
    if hdmi_fast_outputs is not None:
        errors.extend(hdmi_fast_outputs["errors"])

    return {
        "passed": not errors,
        "corners": corners,
        "waived_corner_violations": waived_corner_violations,
        "waived_critical_warning_ids": waived_critical_warning_ids,
        "setup_corner_waiver_policy": setup_corner_waiver_policy,
        "ignored_sdc_filters": ignored_filters,
        "unconstrained_summary": unconstrained,
        "unconstrained_ports": unconstrained_ports,
        "board_io_waiver": waiver,
        "hdmi_fast_output_registers": hdmi_fast_outputs,
        "errors": errors,
    }


def print_timing_result(result: dict[str, Any]) -> None:
    print("Timing gate (ns):")
    print(
        f"{'corner':29} {'setup':>9} {'hold':>9} {'recovery':>9} "
        f"{'removal':>9} {'min-pulse':>10}"
    )
    for corner in EXPECTED_CORNERS:
        values = result["corners"].get(corner, {})
        formatted = [
            f"{values[metric]:9.3f}" if metric in values else f"{'MISSING':>9}"
            for metric in METRICS[:-1]
        ]
        last = (
            f"{values['minimum_pulse_width']:10.3f}"
            if "minimum_pulse_width" in values
            else f"{'MISSING':>10}"
        )
        print(f"{corner:29} {' '.join(formatted)} {last}")

    optional_count = sum(
        1 for item in result["ignored_sdc_filters"] if item["optional"]
    )
    print(
        "SDC ignored filters: "
        f"{optional_count} optional, "
        f"{len(result['ignored_sdc_filters']) - optional_count} unapproved"
    )
    if result["unconstrained_summary"]:
        summary = ", ".join(
            f"{key}={value}"
            for key, value in sorted(result["unconstrained_summary"].items())
        )
        print(f"Constraint coverage: {summary}")
    hdmi_fast_outputs = result.get("hdmi_fast_output_registers")
    if hdmi_fast_outputs is not None:
        print(
            "HDMI fast-output registers: "
            f"{hdmi_fast_outputs['observed_count']}/"
            f"{hdmi_fast_outputs['expected_count']}"
        )
    if result["passed"]:
        waived = result.get("waived_corner_violations") or []
        if waived:
            for item in waived:
                print(
                    "TIMING_GATE WAIVED: "
                    f"{item['corner']} {item['metric']} "
                    f"{item['slack_ns']:.3f} ns "
                    f"policy={result.get('setup_corner_waiver_policy')}"
                )
            for cw in result.get("waived_critical_warning_ids") or []:
                print(
                    f"TIMING_GATE WAIVED-CRITICAL-WARNING: {cw} "
                    "(timing-requirements-not-met, consequence of the waived corner)"
                )
            print("TIMING_GATE RESULT: PASS-WITH-CORNER-WAIVER")
        else:
            print("TIMING_GATE RESULT: PASS")
    else:
        print("TIMING_GATE RESULT: FAIL", file=sys.stderr)
        for error in result["errors"]:
            print(f"  - {error}", file=sys.stderr)


def command_manifest_start(args: argparse.Namespace) -> int:
    root = Path(args.root).resolve()
    output = Path(args.output)
    qsf = parse_qsf(root / "Arcade-SmashTV.qsf")
    status = run_git(root, "status", "--porcelain=v1", "--untracked-files=all")
    assert isinstance(status, str)
    dirty_lines = [line for line in status.splitlines() if line]

    manifest: dict[str, Any] = {
        "schema": 1,
        "status": "started",
        "run_id": args.run_id,
        "started_at_utc": utc_now(),
        "root": str(root),
        "project": {
            "revision": args.revision,
            "outname": args.outname,
            "macro": args.macro,
            "sv2v_extra": args.sv2v_extra,
            "parallel_processors": args.parallel,
            "board_io_waiver_policy": args.board_io_waiver_policy,
            "allow_unpinned_tools": args.allow_unpinned_tools == "1",
            "qsf": qsf,
        },
        "git": {
            "commit": str(run_git(root, "rev-parse", "HEAD")).strip(),
            "branch": str(
                run_git(root, "rev-parse", "--abbrev-ref", "HEAD")
            ).strip(),
            "dirty": bool(dirty_lines),
            "dirty_waived": bool(dirty_lines and args.allow_dirty),
            "status": dirty_lines,
            "diff_sha256": hashlib.sha256(
                run_git(root, "diff", "--binary", "HEAD", binary=True)
            ).hexdigest().upper(),
        },
        "tools": {
            "quartus": {
                "bin_dir": args.quartus_bin,
                "version": args.quartus_version,
                "stage_sha256": {
                    "quartus_sh": args.quartus_sha256,
                    "quartus_map": args.quartus_map_sha256,
                    "quartus_fit": args.quartus_fit_sha256,
                    "quartus_sta": args.quartus_sta_sha256,
                    "quartus_asm": args.quartus_asm_sha256,
                },
            },
            "sv2v": {
                "path": args.sv2v_bin,
                "version": args.sv2v_version,
                "sha256": args.sv2v_sha256,
            },
            "python": {"version": args.python_version},
        },
        "source_inventory": source_inventory(root),
        "important_inputs": important_input_records(root),
        "artifacts": {},
    }
    atomic_write_json(output, manifest)

    problems: list[str] = []
    if dirty_lines and not args.allow_dirty:
        problems.append(
            "working tree is dirty; commit inputs or set ALLOW_DIRTY_BUILD=1 "
            "for a manifested non-release candidate"
        )
    if qsf.get("device") != args.expected_device:
        problems.append(
            f"device mismatch: expected {args.expected_device}, got {qsf.get('device')}"
        )
    # The QSF seed is the project's pinned default (recovery's proven value).
    # A flavor may fit with a different seed via quartus_fit --seed, which
    # build_hw.sh verifies against the fitter's own report; in that case the
    # manifest records both and only the QSF pin is checked here.
    expected_qsf_seed = (
        args.qsf_seed if args.qsf_seed is not None else args.expected_seed
    )
    if qsf.get("seed") != expected_qsf_seed:
        problems.append(
            f"QSF seed mismatch: expected {expected_qsf_seed}, "
            f"got {qsf.get('seed')}"
        )
    if problems:
        manifest["status"] = "rejected"
        manifest["errors"] = problems
        atomic_write_json(output, manifest)
        for problem in problems:
            print(f"ERROR: {problem}", file=sys.stderr)
        return 2
    return 0


def command_record(args: argparse.Namespace) -> int:
    manifest_path = Path(args.manifest)
    manifest = load_manifest(manifest_path)
    root = Path(manifest["root"])
    file_path = Path(args.file)
    if not file_path.is_absolute():
        file_path = root / file_path
    if not file_path.is_file() or file_path.stat().st_size == 0:
        print(f"ERROR: artifact is missing or empty: {file_path}", file=sys.stderr)
        return 2
    manifest.setdefault("artifacts", {})[args.label] = artifact_record(root, file_path)
    manifest["updated_at_utc"] = utc_now()
    atomic_write_json(manifest_path, manifest)
    return 0


def command_timing_gate(args: argparse.Namespace) -> int:
    sta_log, sta_log_record = evidence_record(Path(args.sta_log))
    sta_report, sta_report_record = evidence_record(Path(args.sta_report))
    fit_report, fit_report_record = evidence_record(Path(args.fit_report))
    result = parse_timing(
        sta_log,
        sta_report,
        macro=args.macro,
        board_io_waiver_policy=args.board_io_waiver_policy,
        setup_corner_waiver_policy=(
            None
            if getattr(args, "setup_corner_waiver_policy", "none") == "none"
            else args.setup_corner_waiver_policy
        ),
        fit_report=fit_report,
    )
    input_records = {
        "sta_log": sta_log_record,
        "sta_report": sta_report_record,
        "fit_report": fit_report_record,
    }
    manifest: dict[str, Any] | None = None
    manifest_errors: list[str] = []
    if args.manifest:
        try:
            manifest = load_manifest(Path(args.manifest))
            if not isinstance(manifest, dict):
                raise ValueError("build manifest root is not a JSON object")
            manifest_errors = validate_manifest_artifacts(manifest, input_records)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            manifest_errors = [f"could not validate build manifest: {exc}"]
    if manifest_errors:
        result["errors"] = [*manifest_errors, *result["errors"]]
        result["passed"] = False
    result["inputs"] = input_records
    result["manifest_input_verification"] = {
        "requested": bool(args.manifest),
        "passed": bool(args.manifest) and not manifest_errors,
    }
    atomic_write_json(Path(args.output), result)
    if args.manifest:
        manifest_path = Path(args.manifest)
        if manifest is not None:
            manifest["timing_gate"] = result
            manifest["updated_at_utc"] = utc_now()
            atomic_write_json(manifest_path, manifest)
    print_timing_result(result)
    return 0 if result["passed"] else 2


def verify_release_pair(manifest_path: Path, rbf_path: Path) -> dict[str, Any]:
    """Verify that a published passed manifest names this exact RBF."""

    errors: list[str] = []
    try:
        manifest = load_manifest(manifest_path)
    except (OSError, json.JSONDecodeError) as exc:
        return {"passed": False, "errors": [f"could not read release manifest: {exc}"]}
    if not isinstance(manifest, dict):
        return {"passed": False, "errors": ["release manifest root is not an object"]}

    if manifest.get("status") != "passed" or manifest.get("exit_code") != 0:
        errors.append(
            "release manifest is not a successful build: "
            f"status={manifest.get('status')!r}, exit_code={manifest.get('exit_code')!r}"
        )
    expected = manifest.get("artifacts", {}).get("rbf")
    if not isinstance(expected, dict):
        errors.append("release manifest has no RBF artifact record")
        expected = {}
    try:
        actual_size = rbf_path.stat().st_size
        actual_hash = sha256_file(rbf_path)
    except OSError as exc:
        errors.append(f"could not read published RBF: {exc}")
        actual_size = None
        actual_hash = None
    if expected.get("size") != actual_size:
        errors.append(
            f"published RBF size disagrees with manifest: "
            f"{actual_size} vs {expected.get('size')}"
        )
    expected_hash = expected.get("sha256")
    if (
        actual_hash is not None
        and (
            not isinstance(expected_hash, str)
            or expected_hash.upper() != actual_hash
        )
    ):
        errors.append(
            f"published RBF SHA256 disagrees with manifest: "
            f"{actual_hash} vs {expected_hash}"
        )
    return {
        "passed": not errors,
        "rbf": {
            "path": str(rbf_path.resolve()),
            "size": actual_size,
            "sha256": actual_hash,
        },
        "errors": errors,
    }


def command_verify_release_pair(args: argparse.Namespace) -> int:
    result = verify_release_pair(Path(args.manifest), Path(args.rbf))
    if result["passed"]:
        print(
            "Release pair verified: "
            f"{result['rbf']['size']} bytes, {result['rbf']['sha256']}"
        )
        return 0
    for error in result["errors"]:
        print(f"ERROR: {error}", file=sys.stderr)
    return 2


def command_verify_inputs(args: argparse.Namespace) -> int:
    path = Path(args.manifest)
    manifest = load_manifest(path)
    root = Path(manifest["root"])
    expected = manifest["source_inventory"]
    observed = source_inventory(root)
    if observed["digest"] != expected["digest"]:
        print(
            "ERROR: build inputs changed after the manifest was captured "
            f"(expected {expected['digest']}, observed {observed['digest']})",
            file=sys.stderr,
        )
        return 2
    manifest["inputs_verified_at_utc"] = utc_now()
    manifest["source_inventory_verified"] = observed
    atomic_write_json(path, manifest)
    print(f"Build input digest verified: {observed['digest']}")
    return 0


def command_mark(args: argparse.Namespace) -> int:
    path = Path(args.manifest)
    manifest = load_manifest(path)
    manifest["status"] = args.status
    manifest["exit_code"] = args.exit_code
    manifest["finished_at_utc"] = utc_now()
    atomic_write_json(path, manifest)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)

    start = subparsers.add_parser("manifest-start")
    start.add_argument("--root", required=True)
    start.add_argument("--output", required=True)
    start.add_argument("--run-id", required=True)
    start.add_argument("--revision", required=True)
    start.add_argument("--outname", required=True)
    start.add_argument("--macro", default="")
    start.add_argument("--sv2v-extra", default="")
    start.add_argument("--quartus-bin", required=True)
    start.add_argument("--quartus-version", required=True)
    start.add_argument("--quartus-sha256", required=True)
    start.add_argument("--quartus-map-sha256", required=True)
    start.add_argument("--quartus-fit-sha256", required=True)
    start.add_argument("--quartus-sta-sha256", required=True)
    start.add_argument("--quartus-asm-sha256", required=True)
    start.add_argument("--sv2v-bin", required=True)
    start.add_argument("--sv2v-version", required=True)
    start.add_argument("--sv2v-sha256", required=True)
    start.add_argument("--python-version", required=True)
    start.add_argument("--parallel", type=int, required=True)
    start.add_argument("--expected-device", required=True)
    start.add_argument("--expected-seed", type=int, required=True)
    start.add_argument("--qsf-seed", type=int, default=None)
    start.add_argument("--allow-unpinned-tools", choices=("0", "1"), default="0")
    start.add_argument(
        "--board-io-waiver-policy",
        choices=("none", *BOARD_IO_WAIVER_POLICIES),
        default="none",
    )
    start.add_argument("--allow-dirty", action="store_true")
    start.set_defaults(func=command_manifest_start)

    record = subparsers.add_parser("record")
    record.add_argument("--manifest", required=True)
    record.add_argument("--label", required=True)
    record.add_argument("--file", required=True)
    record.set_defaults(func=command_record)

    timing = subparsers.add_parser("timing-gate")
    timing.add_argument("--sta-log", required=True)
    timing.add_argument("--sta-report", required=True)
    timing.add_argument("--fit-report", required=True)
    timing.add_argument("--macro", default="")
    timing.add_argument("--output", required=True)
    timing.add_argument("--manifest")
    timing.add_argument(
        "--board-io-waiver-policy",
        choices=("none", *BOARD_IO_WAIVER_POLICIES),
        default="none",
    )
    timing.add_argument(
        "--setup-corner-waiver-policy",
        choices=("none", *SETUP_CORNER_WAIVER_POLICIES),
        default="none",
    )
    timing.set_defaults(func=command_timing_gate)

    release_pair = subparsers.add_parser("verify-release-pair")
    release_pair.add_argument("--manifest", required=True)
    release_pair.add_argument("--rbf", required=True)
    release_pair.set_defaults(func=command_verify_release_pair)

    verify = subparsers.add_parser("verify-inputs")
    verify.add_argument("--manifest", required=True)
    verify.set_defaults(func=command_verify_inputs)

    mark = subparsers.add_parser("mark")
    mark.add_argument("--manifest", required=True)
    mark.add_argument("--status", required=True)
    mark.add_argument("--exit-code", type=int, required=True)
    mark.set_defaults(func=command_mark)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (OSError, subprocess.CalledProcessError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
