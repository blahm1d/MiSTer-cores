# Audit the cpu_ce multicycle collection against the currently fitted netlist.
# This is a read-only TimeQuest report: it does not compile or fit the design.
project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist
read_sdc
update_timing_netlist

proc node_names {coll} {
  set result {}
  foreach_in_collection node $coll {
    lappend result [get_node_info $node -name]
  }
  return $result
}

set raw_cpu [get_registers {*tms34010_core:u_core|* *u_memcdc|cst* *u_memcdc|req_tgl* *u_memcdc|c_ack* *u_memcdc|c_rdata* *u_memcdc|ackt_sync* *u_memcdc|p_we* *u_memcdc|p_addr* *u_memcdc|p_size* *u_memcdc|p_wdata* *yunit_top:yunit_top|rd_cnt* *yunit_top:yunit_top|ack_q* *yunit_top:yunit_top|d_started* *yunit_top:yunit_top|d_prevpc* *yunit_top:yunit_top|dbg_derailed* *yunit_top:yunit_top|dbg_culprit_pc* *yunit_top:yunit_top|dbg_culprit_instr* *yunit_top:yunit_top|dbg_derail_pc*}]
set io_fullrate [get_registers {*tms34010_core:u_core|*u_io_regs|*}]
set cpu_final [remove_from_collection $raw_cpu $io_fullrate]
set hv_regs [get_registers {*tms34010_core:u_core|*u_io_regs|*u_video|hcount* *tms34010_core:u_core|*u_io_regs|*u_video|vcount*}]
set timing_regs [get_registers {*tms34010_core:u_core|*u_io_regs|*timing_start*}]
set boundary_addr_regs [get_registers {*tms34010_core:u_core|*u_io_write_boundary|wr_addr*}]
set boundary_data_regs [get_registers {*tms34010_core:u_core|*u_io_write_boundary|wr_data*}]
set boundary_valid_regs [get_registers {*tms34010_core:u_core|*u_io_write_boundary|wr_valid*}]
set boundary_guard_regs [get_registers {*tms34010_core:u_core|*u_io_write_boundary|wr_status_guard*}]
set event_dpy_q_regs [get_registers {*tms34010_core:u_core|*u_io_regs|dpyint_event_q*}]
set event_wvp_q_regs [get_registers {*tms34010_core:u_core|*u_io_regs|wvp_set_q*}]
set event_nmi_q_regs [get_registers {*tms34010_core:u_core|*u_io_regs|nmi_clear_q*}]
set config_psize_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_config|psize*}]
set config_convdp_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_config|convdp*}]
set config_convsp_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_config|convsp*}]
set config_control_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_config|control*}]
set config_pmask_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_config|pmask*}]
set status_intenb_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_status|intenb*}]
set status_intpend_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_status|intpend*}]
set status_hstctlh_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_status|hstctlh*}]
set status_intenb_bridge_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_status|intenb_write_bridge*}]
set status_intpend_bridge_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_status|intpend_write_bridge*}]
set status_hstctlh_bridge_regs [get_registers {*tms34010_core:u_core|*u_io_cpu_status|hstctlh_write_bridge*}]
set state_regs [get_registers {*tms34010_core:u_core|state_q*}]
set regfile_regs [get_registers {*tms34010_core:u_core|*u_regfile|*}]

set raw_names [node_names $raw_cpu]
set final_names [node_names $cpu_final]
set io_names [node_names $io_fullrate]
set hv_names [node_names $hv_regs]
set timing_names [node_names $timing_regs]
set boundary_addr_names [node_names $boundary_addr_regs]
set boundary_data_names [node_names $boundary_data_regs]
set boundary_valid_names [node_names $boundary_valid_regs]
set boundary_guard_names [node_names $boundary_guard_regs]
set event_dpy_q_names [node_names $event_dpy_q_regs]
set event_wvp_q_names [node_names $event_wvp_q_regs]
set event_nmi_q_names [node_names $event_nmi_q_regs]
set config_psize_names [node_names $config_psize_regs]
set config_convdp_names [node_names $config_convdp_regs]
set config_convsp_names [node_names $config_convsp_regs]
set config_control_names [node_names $config_control_regs]
set config_pmask_names [node_names $config_pmask_regs]
set status_intenb_names [node_names $status_intenb_regs]
set status_intpend_names [node_names $status_intpend_regs]
set status_hstctlh_names [node_names $status_hstctlh_regs]
set status_intenb_bridge_names [node_names $status_intenb_bridge_regs]
set status_intpend_bridge_names [node_names $status_intpend_bridge_regs]
set status_hstctlh_bridge_names [node_names $status_hstctlh_bridge_regs]
set state_names [node_names $state_regs]
set regfile_names [node_names $regfile_regs]

set io_leaks 0
foreach name $io_names {
  if {[lsearch -exact $final_names $name] >= 0} { incr io_leaks }
}
set hv_leaks 0
foreach name $hv_names {
  if {[lsearch -exact $final_names $name] >= 0} { incr hv_leaks }
}
set timing_leaks 0
foreach name $timing_names {
  if {[lsearch -exact $final_names $name] >= 0} { incr timing_leaks }
}
set boundary_missing 0
foreach name [concat $boundary_addr_names $boundary_data_names $boundary_valid_names \
                     $boundary_guard_names] {
  if {[lsearch -exact $final_names $name] < 0} { incr boundary_missing }
}
set event_q_missing_from_io 0
set event_q_cpu_leaks 0
foreach name [concat $event_dpy_q_names $event_wvp_q_names $event_nmi_q_names] {
  if {[lsearch -exact $io_names $name] < 0} { incr event_q_missing_from_io }
  if {[lsearch -exact $final_names $name] >= 0} { incr event_q_cpu_leaks }
}
set config_missing 0
foreach name [concat $config_psize_names $config_convdp_names $config_convsp_names \
                     $config_control_names $config_pmask_names] {
  if {[lsearch -exact $final_names $name] < 0} { incr config_missing }
}
set status_missing 0
foreach name [concat $status_intenb_names $status_intpend_names $status_hstctlh_names] {
  if {[lsearch -exact $final_names $name] < 0} { incr status_missing }
}
set status_bridge_missing 0
foreach name [concat $status_intenb_bridge_names $status_intpend_bridge_names \
                     $status_hstctlh_bridge_names] {
  if {[lsearch -exact $final_names $name] < 0} { incr status_bridge_missing }
}
set state_missing 0
foreach name $state_names {
  if {[lsearch -exact $final_names $name] < 0} { incr state_missing }
}
set regfile_missing 0
foreach name $regfile_names {
  if {[lsearch -exact $final_names $name] < 0} { incr regfile_missing }
}

puts "CPU_COLLECTION raw=[llength $raw_names] excluded_io=[llength $io_names] final=[llength $final_names]"
puts "CPU_COLLECTION hv=[llength $hv_names] hv_leaks=$hv_leaks timing_start=[llength $timing_names] timing_leaks=$timing_leaks"
puts "CPU_COLLECTION io_boundary_addr=[llength $boundary_addr_names] io_boundary_data=[llength $boundary_data_names] io_boundary_valid=[llength $boundary_valid_names] status_guard=[llength $boundary_guard_names] boundary_missing=$boundary_missing"
puts "CPU_COLLECTION io_event_q_dpy=[llength $event_dpy_q_names] wvp=[llength $event_wvp_q_names] nmi=[llength $event_nmi_q_names] missing_from_io=$event_q_missing_from_io cpu_leaks=$event_q_cpu_leaks"
puts "CPU_COLLECTION io_config_psize=[llength $config_psize_names] convdp=[llength $config_convdp_names] convsp=[llength $config_convsp_names] control=[llength $config_control_names] pmask=[llength $config_pmask_names] config_missing=$config_missing"
puts "CPU_COLLECTION io_status_intenb=[llength $status_intenb_names] intpend=[llength $status_intpend_names] hstctlh=[llength $status_hstctlh_names] status_missing=$status_missing bridges=[llength $status_intenb_bridge_names]/[llength $status_intpend_bridge_names]/[llength $status_hstctlh_bridge_names] bridge_missing=$status_bridge_missing"
puts "CPU_COLLECTION state_q=[llength $state_names] state_missing=$state_missing regfile=[llength $regfile_names] regfile_missing=$regfile_missing"

if {$io_leaks != 0 || $hv_leaks != 0 || $timing_leaks != 0 ||
    [llength $boundary_addr_names] == 0 || [llength $boundary_data_names] == 0 ||
    [llength $boundary_valid_names] == 0 || [llength $boundary_guard_names] == 0 ||
    $boundary_missing != 0 ||
    [llength $event_dpy_q_names] == 0 || [llength $event_wvp_q_names] == 0 ||
    [llength $event_nmi_q_names] == 0 || $event_q_missing_from_io != 0 ||
    $event_q_cpu_leaks != 0 ||
    [llength $config_psize_names] == 0 || [llength $config_convdp_names] == 0 ||
    [llength $config_convsp_names] == 0 || [llength $config_control_names] == 0 ||
    [llength $config_pmask_names] == 0 || $config_missing != 0 ||
    [llength $status_intenb_names] == 0 || [llength $status_intpend_names] == 0 ||
    [llength $status_hstctlh_names] == 0 || $status_missing != 0 ||
    [llength $status_intenb_bridge_names] == 0 ||
    [llength $status_intpend_bridge_names] == 0 ||
    [llength $status_hstctlh_bridge_names] == 0 ||
    $status_bridge_missing != 0 ||
    $state_missing != 0 || $regfile_missing != 0} {
  puts "CPU_COLLECTION RESULT: FAIL io_leaks=$io_leaks"
  project_close
  qexit -error
}
puts "CPU_COLLECTION RESULT: PASS"
project_close
