project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist -model slow
read_sdc
update_timing_netlist

set fb_src [get_registers {*stv_vram_ddr_top:u_vram_sdram|*}]
set dma_dst [get_registers {*yunit_dma:u_dma|*}]
puts "===== FB READY CONE: VRAM REGISTERS -> DMA REGISTERS (SLOW CORNER) ====="
puts "source registers: [get_collection_size $fb_src]"
puts "destination registers: [get_collection_size $dma_dst]"
report_timing -setup -from $fb_src -to $dma_dst -npaths 20 -detail summary -stdout
report_timing -hold  -from $fb_src -to $dma_dst -npaths 10 -detail summary -stdout

project_close
