#!/usr/bin/env python
"""DENSE_R29_CLOCK gate -- prove the system-clock rung is internally coherent.

The Y-unit core expresses every EMULATED rate as a ratio against clk_sys:

    arch_rate = clk_sys * arch_step / DEN        (arch_step in {20,24,25})
    ce_micro  = clk_sys * 100 / DEN
    ce_pix    = clk_sys / CEDIV

so clk_sys is a free parameter PROVIDED every denominator moves with it.  The
invariant that makes the rung exact is clk_sys / DEN == 0.25 MHz per phase unit.

The denominator exists in THREE files with no shared source of truth, and five
    further constants are denominated in clk_sys ticks.  Editing one and missing
another produces a build that synthesises, fits, and runs at the wrong emulated
speed -- silently.  That is the failure mode this gate exists to catch.

Run:  python quartus/check_clock_rung.py [--self-test]
"""
from __future__ import annotations

import argparse
import re
import sys
from fractions import Fraction
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent

# Reference rates from the earlier 96 MHz rung and the board/software contracts.
# They are ratio references, not a claim that any prior RBF is a whole-core
# behavioral control. These values must NOT move when clk_sys changes.
REF_ARCH_MHZ = {20: Fraction(5), 24: Fraction(6), 25: Fraction(25, 4)}
REF_CE_MICRO_MHZ = Fraction(25)
REF_PIXEL_MHZ = Fraction(8)
REF_PHASE_QUOTIENT = Fraction(1, 4)      # clk_sys / DEN
REF_CLK_SND_MHZ = Fraction(12)
REF_REFRESH_US = Fraction(780, 96)       # 8.125 us, the interval shipped at 96 MHz
BLIT_NS_PER_PIXEL = Fraction(41)         # authored Y-unit blitter pixel pace
REF_SOUND_HOLD_US = Fraction(128, 96)    # old physical CDC minimum, not old tick count
H_TOTAL, V_TOTAL = 506, 289

# (label, path, regex capturing one integer)
SITES = [
    ("pll_outclk0", "rtl/pll/pll_0002.v",
     r'\.output_clock_frequency0\("(\d+)\.\d+ MHz"\)'),
    ("pll_outclk1", "rtl/pll/pll_0002.v",
     r'\.output_clock_frequency1\("(\d+)\.\d+ MHz"\)'),
    ("pll_outclk2", "rtl/pll/pll_0002.v",
     r'\.output_clock_frequency2\("(\d+)\.\d+ MHz"\)'),
    ("ce_pix_last", "Arcade-SmashTV.sv",
     r"cediv <= \(cediv == 4'd(\d+)\)"),
    ("den_cadence", "rtl/yunit/yunit_cpu_cadence.sv",
     r"PHASE_DEN = 10'd(\d+);"),
    ("den_deadline", "rtl/tms34010/rtl/dense/tms34010_dense_deadline.sv",
     r"PHASE_PER_CYCLE = 9'd(\d+);"),
    ("den_scheduler", "rtl/tms34010/rtl/core/tms34010_cycle_scheduler.sv",
     r"PHASE_PER_CYCLE  = 10'd(\d+);"),
    ("phase_mod_cycles", "rtl/tms34010/rtl/core/tms34010_cycle_scheduler.sv",
     r"PHASE_MOD_CYCLES = 18'd(\d+);"),
    ("phase_mod_frac", "rtl/tms34010/rtl/core/tms34010_cycle_scheduler.sv",
     r"PHASE_MOD_FRAC   = 10'd(\d+);"),
    ("crt_read_period", "rtl/video/yunit_crt_adjust.sv",
     r"READ_PERIOD_BASE = 8'd(\d+);"),
    ("blit_milli_px", "rtl/yunit/yunit_dma_logical_timer.sv",
     r"MILLI_PER_PIXEL = 31'd(\d+);"),
    ("family2_blit_pixel_quanta", "rtl/yunit/family2/yunit_dma_family2.sv",
     r"PACE_PIXEL_QUANTA = 7'd(\d+);"),
    ("family2_blit_clock_quanta", "rtl/yunit/family2/yunit_dma_family2.sv",
     r"PACE_CLOCK_QUANTA = 7'd(\d+);"),
    ("sound_hold_cycles", "rtl/yunit/yunit_sound_cdc.sv",
     r"SYS_HOLD_CYCLES = (\d+)"),
    ("sdram_refresh", "rtl/sdram/sdram_stock.sv",
     r"cycles_per_refresh  = 14'd(\d+);"),
]


def scrape(overrides: dict[str, int] | None = None) -> dict[str, int]:
    overrides = overrides or {}
    out: dict[str, int] = {}
    for label, rel, pattern in SITES:
        text = (REPO / rel).read_text(encoding="utf-8", errors="replace")
        hits = re.findall(pattern, text)
        if len(hits) != 1:
            raise SystemExit(
                f"CLOCK_RUNG_FAIL {label}: expected exactly 1 match in {rel}, got {len(hits)}"
            )
        out[label] = int(hits[0])
    out.update(overrides)
    return out


def check(v: dict[str, int]) -> list[str]:
    bad: list[str] = []

    def req(ok: bool, msg: str) -> None:
        if not ok:
            bad.append(msg)

    clk = Fraction(v["pll_outclk0"])
    den = v["den_cadence"]
    cediv = v["ce_pix_last"] + 1          # wrap value N means divide by N+1

    # 1. the two core-clock PLL taps agree, and the sound tap has not moved
    req(v["pll_outclk0"] == v["pll_outclk1"],
        f"clk_sys {v['pll_outclk0']} != clk_sdram {v['pll_outclk1']}")
    req(Fraction(v["pll_outclk2"]) == REF_CLK_SND_MHZ,
        f"clk_snd moved: {v['pll_outclk2']} MHz != {REF_CLK_SND_MHZ}")

    # 2. all three denominators are the same number
    dens = {k: v[k] for k in ("den_cadence", "den_deadline", "den_scheduler")}
    req(len(set(dens.values())) == 1, f"phase denominators disagree: {dens}")

    # 3. THE invariant -- phase quotient preserved, so every arch rate is exact
    req(Fraction(clk, den) == REF_PHASE_QUOTIENT,
        f"phase quotient {Fraction(clk, den)} != {REF_PHASE_QUOTIENT} "
        f"(clk_sys {clk} MHz / DEN {den})")
    for step, want in REF_ARCH_MHZ.items():
        got = clk * step / den
        req(got == want, f"arch_step {step}: {got} MHz != {want} MHz")
    req(clk * 100 / den == REF_CE_MICRO_MHZ,
        f"ce_micro {clk * 100 / den} MHz != {REF_CE_MICRO_MHZ} MHz")

    # 4. pixel clock and therefore the whole raster are unchanged
    pix = Fraction(clk, cediv)
    req(pix == REF_PIXEL_MHZ, f"pixel clock {pix} MHz != {REF_PIXEL_MHZ} MHz (cediv {cediv})")
    frame = pix * 1_000_000 / (H_TOTAL * V_TOTAL)
    ref_frame = REF_PIXEL_MHZ * 1_000_000 / (H_TOTAL * V_TOTAL)
    req(frame == ref_frame, f"frame rate {float(frame):.4f} != {float(ref_frame):.4f} Hz")

    # 5. modulo decomposition of the legacy scheduler's 2^26 wrap
    lhs = v["phase_mod_cycles"] * v["den_scheduler"] + v["phase_mod_frac"]
    req(lhs == 2 ** 26,
        f"2^26 != {v['phase_mod_cycles']}*{v['den_scheduler']}+{v['phase_mod_frac']} = {lhs}")
    req(v["phase_mod_frac"] < v["den_scheduler"],
        f"PHASE_MOD_FRAC {v['phase_mod_frac']} must be < DEN {v['den_scheduler']}")
    req(v["phase_mod_cycles"] < 2 ** 18, "PHASE_MOD_CYCLES overflows its 18-bit declaration")

    # 6. clk_sys-denominated constants outside the cadence layer
    req(Fraction(v["crt_read_period"]) == clk / REF_PIXEL_MHZ * 4,
        f"READ_PERIOD_BASE {v['crt_read_period']} != {clk / REF_PIXEL_MHZ * 4}")
    req(Fraction(v["blit_milli_px"]) == BLIT_NS_PER_PIXEL * clk,
        f"MILLI_PER_PIXEL {v['blit_milli_px']} != {BLIT_NS_PER_PIXEL * clk}")
    family2_milli_px = Fraction(
        1000 * v["family2_blit_pixel_quanta"],
        v["family2_blit_clock_quanta"],
    )
    req(family2_milli_px == BLIT_NS_PER_PIXEL * clk,
        f"Family2 DMA pace {family2_milli_px} milli-clocks/pixel != "
        f"{BLIT_NS_PER_PIXEL * clk}")
    req(Fraction(v["sdram_refresh"], 1) / clk == REF_REFRESH_US,
        f"refresh interval {float(Fraction(v['sdram_refresh']) / clk):.4f} us "
        f"!= {float(REF_REFRESH_US):.4f} us")
    # Preserve or slightly exceed the old physical CDC width. ceil(80*128/96)
    # is 107; retaining 128 would be safe but slower and one counter bit wider.
    hold = Fraction(v["sound_hold_cycles"], 1) / clk
    req(hold >= REF_SOUND_HOLD_US and
        Fraction(v["sound_hold_cycles"] - 1, 1) / clk < REF_SOUND_HOLD_US,
        f"sound CDC hold {v['sound_hold_cycles']} cycles ({float(hold):.6f} us) "
        f"is not ceil({clk}*{REF_SOUND_HOLD_US})")

    # 7. declaration-width sanity for the denominators themselves
    req(v["den_deadline"] < 2 ** 9, "DEN overflows the 9-bit dense deadline declaration")
    req(v["den_cadence"] < 2 ** 10, "DEN overflows the 10-bit cadence declaration")
    return bad


# Each mutant misreads exactly one site; every one must be killed.
MUTANTS = {
    # the headline failure: the clock was retuned and the whole cadence layer
    # was left at its old denominator, so every emulated rate silently scales
    "MUT_CLOCK_ONLY": {"den_cadence": 384, "den_deadline": 384, "den_scheduler": 384,
                       "phase_mod_cycles": 174762, "phase_mod_frac": 256},
    "MUT_SDRAM_TAP_SPLIT": {"pll_outclk1": 96},                        # core and SDRAM taps diverge
    "MUT_DEN_SPLIT": {"den_deadline": 384},                            # one denominator left behind
    "MUT_CEPIX_STALE": {"ce_pix_last": 11},                            # pixel divider left behind
    "MUT_CRT_STALE": {"crt_read_period": 48},
    "MUT_BLIT_STALE": {"blit_milli_px": 3936},
    "MUT_FAMILY2_BLIT_STALE": {"family2_blit_pixel_quanta": 100},
    "MUT_REFRESH_STALE": {"sdram_refresh": 780},
    "MUT_SOUND_HOLD_STALE": {"sound_hold_cycles": 128},
    "MUT_PHASE_MOD_STALE": {"phase_mod_cycles": 174762, "phase_mod_frac": 256},
    "MUT_SND_DRIFT": {"pll_outclk2": 13},
}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()

    live = scrape()
    failures = check(live)
    if failures:
        for f in failures:
            print(f"CLOCK_RUNG_FAIL {f}", file=sys.stderr)
        return 1

    if args.self_test:
        survivors = []
        for name, override in MUTANTS.items():
            base = dict(live)
            # a mutant that does not actually change the live value proves nothing
            if all(base.get(k) == val for k, val in override.items()):
                survivors.append(f"{name} (inert -- matches the live value)")
                continue
            base.update(override)
            if not check(base):
                survivors.append(f"{name} (survived)")
        if survivors:
            for s in survivors:
                print(f"CLOCK_RUNG_FAIL mutant not killed: {s}", file=sys.stderr)
            return 1
        print(f"CLOCK_RUNG_SELFTEST_PASS mutants={len(MUTANTS)} killed={len(MUTANTS)}")

    clk = live["pll_outclk0"]
    den = live["den_cadence"]
    print(
        f"DENSE_R29_CLOCK_PASS clk_sys={clk}MHz clk_sdram={live['pll_outclk1']}MHz "
        f"clk_snd={live['pll_outclk2']}MHz den={den} quotient={Fraction(clk, den)} "
        f"cediv={live['ce_pix_last'] + 1} pixel=8MHz arch=5.00/6.00/6.25MHz "
        f"ce_micro=25MHz frame=54.7068Hz read_period={live['crt_read_period']} "
        f"milli_px={live['blit_milli_px']} "
        f"family2_pace={live['family2_blit_pixel_quanta']}/"
        f"{live['family2_blit_clock_quanta']}clk_per_px refresh={live['sdram_refresh']} "
        f"sound_hold={live['sound_hold_cycles']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
