#!/usr/bin/env python3
"""Emit a Verilog elaboration stub from a VHDL entity declaration.

WHY THIS EXISTS AND WHY IT IS GENERATED, NOT CHECKED IN
-------------------------------------------------------
The Williams CVSD sound board is VHDL and is the only language boundary the
Y-unit core crosses.  Questa/Quartus bind it natively; Icarus cannot read VHDL
at all.  The licence-free `recovery-icarus` elaboration in sim/elab_top.sh
therefore needs a Verilog module of the same name.

A hand-written stub is a liability: if the VHDL entity gains a port, the stub
keeps elaborating and silently reports a PASS on a seam that no longer binds.
Generating the stub from the entity text makes that failure mode impossible --
a renamed or resized port changes the stub, and the Verilog side then fails to
bind exactly as Quartus would.

The stub drives every output to zero.  It is only ever used for
compile-and-elaborate (run 0); the Questa leg exercises the real VHDL.

Usage:  gen_vhdl_stub.py <entity.vhd> <entity_name> > stub.v
"""

from __future__ import annotations

import re
import sys
from pathlib import Path


def strip_comments(text: str) -> str:
    return "\n".join(line.split("--", 1)[0] for line in text.splitlines())


def entity_ports(text: str, entity: str) -> list[tuple[str, str, str]]:
    """Return [(name, direction, verilog_range)] for one VHDL entity."""
    body = re.search(
        rf"\bentity\s+{re.escape(entity)}\s+is\b(.*?)\bend\b", text,
        re.IGNORECASE | re.DOTALL)
    if body is None:
        raise SystemExit(f"entity {entity} not found")
    decl = re.search(r"\bport\s*\((.*)\)\s*;\s*$", body.group(1).strip(),
                     re.IGNORECASE | re.DOTALL)
    if decl is None:
        raise SystemExit(f"entity {entity} has no port clause")

    ports: list[tuple[str, str, str]] = []
    for item in decl.group(1).split(";"):
        item = " ".join(item.split())
        if not item:
            continue
        names, _, typ = item.partition(":")
        m = re.match(r"\s*(in|out|inout|buffer)\s+(.*)$", typ,
                     re.IGNORECASE)
        if m is None:
            raise SystemExit(f"cannot parse port direction in: {item!r}")
        direction, vhdl_type = m.group(1).lower(), m.group(2).strip()

        vec = re.match(
            r"std_logic_vector\s*\(\s*(\d+)\s+(downto|to)\s+(\d+)\s*\)",
            vhdl_type, re.IGNORECASE)
        if vec is not None:
            hi, lo = int(vec.group(1)), int(vec.group(3))
            if vec.group(2).lower() == "to":
                hi, lo = lo, hi
            rng = f"[{hi}:{lo}]"
        elif re.fullmatch(r"std_logic", vhdl_type, re.IGNORECASE):
            rng = ""
        else:
            raise SystemExit(f"unsupported VHDL port type: {vhdl_type!r}")

        for name in names.split(","):
            name = name.strip()
            if name:
                ports.append((name, direction, rng))
    if not ports:
        raise SystemExit(f"entity {entity} produced no ports")
    return ports


def emit(entity: str, ports: list[tuple[str, str, str]], source: str) -> str:
    kind = {"in": "input  wire", "out": "output wire",
            "inout": "inout  wire", "buffer": "output wire"}
    decls = [f"  {kind[d]} {r + ' ' if r else ''}{n}" for n, d, r in ports]
    lines = [
        f"// GENERATED from {source} by tools/gen_vhdl_stub.py -- do not edit.",
        "// Elaboration-only Verilog stand-in for a VHDL entity.  Outputs are 0.",
        f"module {entity}(",
        ",\n".join(decls),
        ");",
    ]
    for name, direction, rng in ports:
        if direction in ("out", "buffer"):
            width = 1 if not rng else int(rng[1:-1].split(":")[0]) - \
                int(rng[1:-1].split(":")[1]) + 1
            lines.append(f"  assign {name} = {width}'b0;")
    lines.append("endmodule")
    return "\n".join(lines) + "\n"


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print(__doc__.strip().splitlines()[-1], file=sys.stderr)
        return 2
    path, entity = Path(argv[1]), argv[2]
    text = strip_comments(path.read_text(encoding="utf-8", errors="replace"))
    sys.stdout.write(emit(entity, entity_ports(text, entity), path.as_posix()))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
