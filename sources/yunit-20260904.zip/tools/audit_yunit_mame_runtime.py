#!/usr/bin/env python3
"""Run a short MAME boot fingerprint across every supported Y-unit profile."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import re
import subprocess
import tempfile


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROBE = PROJECT_ROOT / "tools" / "mame_yunit_runtime_probe.lua"
GAMES = (
    "trog",
    "smashtv",
    "hiimpact",
    "shimpact",
    "strkforc",
    "saurnfrnt",
    "mkla4",
    "term2",
    "totcarn",
    "yunittst",
)
SOURCE_ONLY_RUNTIME = {"saurnfrnt", "yunittst"}
RESULT_RE = re.compile(r"^YUNIT_RUNTIME\s+(.+)$", re.MULTILINE)
FIELD_RE = re.compile(r"([a-z_]+)=([^\s]+)")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "rom_dir",
        type=Path,
        help="MAME ROM directory containing the merged Y-unit archives",
    )
    parser.add_argument(
        "--mame",
        type=Path,
        default=Path(r"C:\tools\mame\mame.exe"),
        help="MAME 0.280 executable",
    )
    parser.add_argument("--frames", type=int, default=180)
    parser.add_argument(
        "--games",
        nargs="+",
        choices=GAMES,
        default=list(GAMES),
        help="optional subset to probe",
    )
    args = parser.parse_args()

    if not args.mame.is_file():
        raise SystemExit(f"MAME executable not found: {args.mame}")
    if not args.rom_dir.is_dir():
        raise SystemExit(f"ROM directory not found: {args.rom_dir}")
    if not PROBE.is_file():
        raise SystemExit(f"runtime probe not found: {PROBE}")

    failures: list[str] = []
    skipped: list[str] = []
    rows: list[str] = []
    with tempfile.TemporaryDirectory(prefix="yunit-mame-audit-") as temp_name:
        temp = Path(temp_name)
        for game in args.games:
            env = os.environ.copy()
            env["YUNIT_PROBE_FRAMES"] = str(args.frames)
            command = [
                str(args.mame),
                game,
                "-rompath",
                str(args.rom_dir),
                "-cfg_directory",
                str(temp / "cfg"),
                "-nvram_directory",
                str(temp / "nvram"),
                "-snapshot_directory",
                str(temp / "snap"),
                "-video",
                "none",
                "-sound",
                "none",
                "-nothrottle",
                "-skip_gameinfo",
                "-autoboot_script",
                str(PROBE),
            ]
            result = subprocess.run(
                command,
                cwd=temp,
                env=env,
                capture_output=True,
                text=True,
                timeout=90,
                check=False,
            )
            combined = result.stdout + "\n" + result.stderr
            match = RESULT_RE.search(combined)
            if (
                "No matching systems found" in combined
                or (game in SOURCE_ONLY_RUNTIME and result.returncode == 5)
            ):
                # These two archival definitions landed after the installed
                # MAME 0.280 binary.  They remain covered by the pinned-source
                # and ROM-layout audits.
                skipped.append(f"{game}: absent from installed MAME binary")
                continue
            if result.returncode != 0 or match is None:
                failures.append(
                    f"{game}: MAME exit {result.returncode}; no runtime fingerprint"
                )
                continue

            fields = dict(FIELD_RE.findall(match.group(1)))
            timing = int(fields.get("timing", "0"))
            display = int(fields.get("display", "0"))
            if timing == 0:
                failures.append(f"{game}: never established valid raster timing")
            if display == 0:
                failures.append(f"{game}: never enabled display output")
            rows.append(match.group(0))

    for row in rows:
        print(row)
    for skip in skipped:
        print(f"MAME RUNTIME SKIP: {skip}")
    if failures:
        print(f"MAME RUNTIME AUDIT: FAIL ({len(failures)})")
        for failure in failures:
            print(f"  {failure}")
        return 1
    print(
        "MAME RUNTIME AUDIT: PASS "
        f"({len(rows)} runtime profiles, {len(skipped)} pinned-source-only profiles)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
