#!/usr/bin/env python3
"""Fail-closed offline audit for the Y-unit CRT Adjust release boundary.

This checks the source/provenance/menu/build contracts that simulation alone
cannot prove.  With --generated it also verifies the fresh sv2v blob, and with
--elaborate-emu it asks Icarus to elaborate the real emu wrapper against that
generated blob.  It never invokes Quartus or TimeQuest.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
UPSTREAM = ROOT / "rtl" / "video" / "crt_adjust.sv"
WRAPPER = ROOT / "rtl" / "video" / "yunit_crt_adjust.sv"
PROVENANCE = ROOT / "rtl" / "video" / "MiSTer-CRT-Adjust.UPSTREAM.md"
LICENSE_NOTE = ROOT / "rtl" / "video" / "LICENSE.md"
FULL_GPL = ROOT / "rtl" / "sound" / "jt6295" / "LICENSE"
TOP = ROOT / "Arcade-SmashTV.sv"
VENDOR = ROOT / "VENDOR.md"
BUILD_SV2V = ROOT / "quartus" / "build_sv2v.sh"
SIM_ELAB = ROOT / "sim" / "elab_top.sh"
FULL_QIP = ROOT / "files.qip"
FULL_QSF = ROOT / "Arcade-SmashTV.qsf"
SYN_QIP = ROOT / "quartus" / "files.qip"
DEFAULT_GENERATED = ROOT / "build_syn" / "smashtv_core.v"

PINNED_REPOSITORY = "https://github.com/rmonic79/MiSTer-CRT-Adjust"
PINNED_COMMIT = "9616f9295c807b95a9cd0961981ebf08dbbabf08"
PINNED_BLOB = "31f7cccff76053c15e40f30fa1663665596bf18a"


class Audit:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.checks = 0

    def require(self, condition: bool, message: str) -> None:
        self.checks += 1
        if not condition:
            self.failures.append(message)

    def equal(self, actual: object, expected: object, label: str) -> None:
        self.require(
            actual == expected,
            f"{label}: expected {expected!r}, got {actual!r}",
        )


def read_text(path: Path, audit: Audit) -> str:
    if not path.is_file():
        audit.require(False, f"missing required file: {path.relative_to(ROOT)}")
        return ""
    try:
        return path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        audit.require(False, f"cannot read {path.relative_to(ROOT)}: {exc}")
        return ""


def repository_blob_sha1(data: bytes) -> str:
    """Hash the Git blob committed by this Windows checkout.

    The pinned upstream blob uses LF.  core.autocrlf may materialize CRLF in a
    working tree, so normalize only CRLF line endings before applying Git's
    blob framing.  Bare CR or any content change still changes the digest.
    """

    clean = data.replace(b"\r\n", b"\n")
    header = f"blob {len(clean)}\0".encode("ascii")
    return hashlib.sha1(header + clean).hexdigest()


def module_count(text: str, module: str) -> int:
    return len(
        re.findall(
            rf"(?m)^\s*module\s+(?:automatic\s+)?{re.escape(module)}\b",
            text,
        )
    )


def compact(text: str) -> str:
    return re.sub(r"\s+", "", text)


def audit_menu(top: str, audit: Audit) -> None:
    match = re.search(r"localparam\s+CONF_STR\s*=\s*\{(.*?)\n\};", top, re.S)
    audit.require(match is not None, "Arcade-SmashTV.sv: CONF_STR block not found")
    if not match:
        return

    entries = re.findall(r'"([^"]*)"', match.group(1))
    audit.equal(entries.count("P1,CRT Adjust;"), 1, "CRT submenu selector count")
    audit.equal(
        entries.count("P1O[10],Enable,Off,On;"),
        1,
        "CRT enable option count",
    )

    expected_options = {
        "CRT H-Size": (
            "H1P1O[15:11]",
            ["0", "-1", "-2", "-3", "-4"],
        ),
        "CRT H-Position": (
            "H1P1O[22:16]",
            ["0"]
            + [f"+{value}" for value in range(1, 45)]
            + ["-4", "-3", "-2", "-1"],
        ),
        "CRT V-Shift": (
            "H1P1O[27:23]",
            ["0"]
            + [f"+{value}" for value in range(1, 14)]
            + [f"-{value}" for value in range(12, 0, -1)],
        ),
    }

    for label, (expected_prefix, expected_values) in expected_options.items():
        matches = [
            entry
            for entry in entries
            if len(entry.split(",")) >= 2 and entry.split(",")[1] == label
        ]
        audit.equal(len(matches), 1, f"{label} option count")
        if len(matches) != 1:
            continue
        fields = matches[0].removesuffix(";").split(",")
        audit.equal(fields[0], expected_prefix, f"{label} status range")
        audit.equal(fields[2:], expected_values, f"{label} enumeration")

    top_flat = compact(top)
    required_top_tokens = (
        "wire[31:0]status;",
        ".status_menumask({14'd0,~status[10],direct_video})",
        "yunit_crt_adjustu_yunit_crt_adjust(",
        ".active_in(status[10])",
        ".hsize_code(status[15:11])",
        ".hpos_code(status[22:16])",
        ".vshift_code(status[27:23])",
        ".ce_pix(crt_ce_pix)",
        ".HBlank(crt_hb)",
        ".VBlank(crt_vb)",
        ".HSync(crt_hs)",
        ".VSync(crt_vs)",
        "wirece_pix=(cediv==4'd0);",
        "(cediv==4'd11)?4'd0:cediv+4'd1;",
    )
    for token in required_top_tokens:
        audit.require(token in top_flat, f"top-level CRT contract missing: {token}")
    audit.equal(
        top_flat.count("yunit_crt_adjustu_yunit_crt_adjust("),
        1,
        "top-level yunit_crt_adjust instance count",
    )


def audit_wrapper(wrapper: str, audit: Audit) -> None:
    wrapper_flat = compact(wrapper)
    required_tokens = (
        "localparamintegerH_TOTAL=506;",
        "localparamintegerV_TOTAL=289;",
        "localparam[7:0]READ_PERIOD_BASE=8'd48;",
        "localparamintegerCRT_HPOS_SYNCSHIFT=0;",
        "(hsize_code<=5'd4)?hsize_request_wide[4:0]:5'sd0;",
        "(hpos_code<=7'd44)?$signed({2'b00,hpos_code}):",
        "(hpos_code<=7'd48)?$signed({2'b00,hpos_code})-9'sd49:",
        "(vshift_code<=5'd13)?$signed({1'b0,vshift_code}):",
        "(vshift_code<=5'd25)?$signed({1'b0,vshift_code})-6'sd26:",
        "(hphase_q==9'd505)?9'd0:hphase_q+9'd1;",
        "(vphase_q==9'd288)?9'd0:vphase_q+9'd1;",
        "wire[9:0]hsync_end={1'b0,hpos_phase_q}+10'd44;",
        "wire[9:0]vsync_end={1'b0,vshift_phase_q}+10'd4;",
        ".VTOTAL(V_TOTAL)",
        ".HTOTAL(H_TOTAL)",
        ".HPOS_MODE(CRT_HPOS_SYNCSHIFT)",
        ".hoffset(9'sd0)",
        ".voffset(6'sd0)",
        "wirerate_hs_ref=hs_ref;",
        "assignhs_out=sync_active_q?hs_ref:hs_in;",
        "assignvs_out=sync_active_q?vs_sync_q:vs_in;",
        "assignvb_out=active_q?vb_active_q:vb_in;",
    )
    for token in required_tokens:
        audit.require(token in wrapper_flat, f"wrapper contract missing: {token}")

    audit.equal(
        module_count(wrapper, "yunit_crt_adjust"),
        1,
        "wrapper module definition count",
    )
    audit.equal(
        len(re.findall(r"(?m)^\s*crt_adjust\s*#\s*\(", wrapper)),
        1,
        "upstream crt_adjust instance count",
    )
    audit.equal(
        wrapper_flat.count(".hoffset(9'sd0)"),
        1,
        "constant upstream H-offset connection count",
    )
    audit.equal(
        wrapper_flat.count(".voffset(6'sd0)"),
        1,
        "constant upstream V-offset connection count",
    )


def audit_provenance_and_license(
    upstream: str,
    provenance: str,
    license_note: str,
    full_gpl: str,
    vendor: str,
    audit: Audit,
) -> None:
    if UPSTREAM.is_file():
        try:
            actual_blob = repository_blob_sha1(UPSTREAM.read_bytes())
        except OSError as exc:
            audit.require(False, f"cannot hash {UPSTREAM.relative_to(ROOT)}: {exc}")
        else:
            audit.equal(actual_blob, PINNED_BLOB, "vendored upstream Git blob")

    audit.equal(
        module_count(upstream, "crt_adjust"),
        1,
        "upstream crt_adjust module definition count",
    )
    for token in (
        PINNED_REPOSITORY,
        PINNED_COMMIT,
        "Source path: `rtl/crt_adjust.sv`",
        PINNED_BLOB,
        "GNU GPL v3 or later",
        "intentionally unchanged",
        "constant zero H/V offsets",
    ):
        audit.require(token in provenance, f"provenance missing: {token}")

    for token in (
        "GNU General Public License",
        "version 3 or later",
        "rtl/sound/jt6295/LICENSE",
        "MiSTer-CRT-Adjust.UPSTREAM.md",
    ):
        audit.require(token in license_note, f"CRT license note missing: {token}")
    audit.require(
        "GNU GENERAL PUBLIC LICENSE" in full_gpl and "Version 3, 29 June 2007" in full_gpl,
        "referenced full GPLv3 text is missing or not GPLv3",
    )

    for token in (
        "`rtl/video/crt_adjust.sv`",
        "github.com/rmonic79/MiSTer-CRT-Adjust",
        PINNED_COMMIT,
        PINNED_BLOB,
        "GPL-3.0-or-later",
        "`rtl/video/yunit_crt_adjust.sv`",
    ):
        audit.require(token in vendor, f"VENDOR.md CRT row missing: {token}")


def audit_build_sources(
    build_sv2v: str,
    sim_elab: str,
    full_qip: str,
    full_qsf: str,
    syn_qip: str,
    audit: Audit,
) -> None:
    source_literals = (
        "$ROOT/rtl/video/crt_adjust.sv",
        "$ROOT/rtl/video/yunit_crt_adjust.sv",
    )
    for source in source_literals:
        audit.equal(
            build_sv2v.count(source),
            1,
            f"sv2v source count for {source}",
        )
        audit.equal(
            sim_elab.count(source),
            1,
            f"simulation elaboration source count for {source}",
        )

    audit.equal(
        full_qip.count(
            "set_global_assignment -name VERILOG_FILE build_syn/smashtv_core.v"
        ),
        1,
        "full files.qip generated-blob assignment count",
    )
    audit.equal(
        full_qsf.count(
            "set_global_assignment -name VERILOG_FILE build_syn/smashtv_core.v"
        ),
        1,
        "full QSF generated-blob assignment count",
    )
    audit.equal(
        syn_qip.count(
            "set_global_assignment -name VERILOG_FILE ../build_syn/smashtv_core.v"
        ),
        1,
        "synthesis-harness generated-blob assignment count",
    )

    raw_sources = (
        "rtl/video/crt_adjust.sv",
        "rtl/video/yunit_crt_adjust.sv",
    )
    qsf_qip_files = sorted(ROOT.rglob("*.qsf")) + sorted(ROOT.rglob("*.qip"))
    for config in qsf_qip_files:
        try:
            config_text = config.read_text(encoding="utf-8-sig", errors="replace")
        except OSError as exc:
            audit.require(False, f"cannot inspect {config.relative_to(ROOT)}: {exc}")
            continue
        normalized = config_text.replace("\\", "/")
        for source in raw_sources:
            audit.require(
                source not in normalized,
                f"raw CRT source must not be assigned by QSF/QIP: "
                f"{config.relative_to(ROOT)} -> {source}",
            )

    # No CRT module belongs in MiSTer's shared sys framework.
    for path in sorted((ROOT / "sys").rglob("*")):
        if not path.is_file() or path.suffix.lower() not in {
            ".sv",
            ".v",
            ".vh",
            ".qip",
            ".qsf",
            ".tcl",
            ".sdc",
        }:
            continue
        try:
            text = path.read_text(encoding="utf-8-sig", errors="replace")
        except OSError as exc:
            audit.require(False, f"cannot inspect {path.relative_to(ROOT)}: {exc}")
            continue
        audit.require(
            re.search(r"\b(?:yunit_)?crt_adjust\b", text, re.I) is None,
            f"CRT Adjust reference leaked into sys/: {path.relative_to(ROOT)}",
        )


def audit_no_retimer(
    relevant: dict[Path, str],
    audit: Audit,
) -> None:
    forbidden_patterns = (
        re.compile(r"\bcrt_retime\b", re.I),
        re.compile(r"\bframe[-_ ]?retim(?:e|er|ing)\b", re.I),
        re.compile(r"\bframe[-_ ]?rate[-_ ]?convert", re.I),
        re.compile(r"\b59\s*\.\s*9(?:0|4)?\b"),
    )
    for path, text in relevant.items():
        for pattern in forbidden_patterns:
            audit.require(
                pattern.search(text) is None,
                f"retimer/converted-refresh token {pattern.pattern!r} in "
                f"{path.relative_to(ROOT)}",
            )

    for path in (UPSTREAM, WRAPPER):
        text = relevant.get(path, "")
        audit.require(
            re.search(r"\b(?:DDRAM|DDR3|SDRAM)\b", text) is None,
            f"CRT line-buffer source unexpectedly references external frame memory: "
            f"{path.relative_to(ROOT)}",
        )


def audit_generated(path: Path, text: str, audit: Audit) -> None:
    audit.equal(module_count(text, "crt_adjust"), 1, "generated crt_adjust count")
    audit.equal(
        module_count(text, "yunit_crt_adjust"),
        1,
        "generated yunit_crt_adjust count",
    )
    audit.equal(module_count(text, "yunit_top"), 1, "generated yunit_top count")
    audit.equal(module_count(text, "emu"), 0, "generated native emu count")
    audit.equal(
        module_count(text, "crt_adjust_sys"),
        0,
        "generated sys-side CRT Adjust count",
    )
    audit.require(
        re.search(r"\bcrt_retime\b", text, re.I) is None,
        "generated blob contains retired CRT retimer logic",
    )

    if path.is_file():
        newest_input = max(
            source.stat().st_mtime
            for source in (UPSTREAM, WRAPPER, BUILD_SV2V)
            if source.is_file()
        )
        audit.require(
            path.stat().st_mtime >= newest_input,
            "generated smashtv_core.v is older than a CRT source/build input",
        )


def elaborate_emu(generated: Path, audit: Audit) -> None:
    iverilog = shutil.which("iverilog")
    if not iverilog and sys.platform == "win32":
        fallback = Path(r"C:\iverilog\bin\iverilog.exe")
        if fallback.is_file():
            iverilog = str(fallback)
    audit.require(iverilog is not None, "iverilog was not found for emu elaboration")
    if not iverilog:
        return

    with tempfile.TemporaryDirectory(prefix="yunit-crt-audit-") as temp_dir:
        # build_id.v is intentionally ignored/generated.  This include makes
        # the offline gate work in a clean clone without mutating the tree.
        Path(temp_dir, "build_id.v").write_text(
            '`define BUILD_DATE "CRT-AUDIT"\n',
            encoding="ascii",
        )
        command = [
            iverilog,
            "-g2012",
            "-i",
            "-s",
            "emu",
            "-I",
            str(ROOT),
            "-I",
            temp_dir,
            "-tnull",
            str(TOP),
            str(generated),
        ]
        result = subprocess.run(
            command,
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
    if result.returncode != 0:
        detail = "\n".join(
            part.strip() for part in (result.stdout, result.stderr) if part.strip()
        )
        audit.require(
            False,
            f"generated emu elaboration failed (exit {result.returncode})"
            + (f":\n{detail}" if detail else ""),
        )
    else:
        audit.require(True, "generated emu elaboration")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--generated",
        nargs="?",
        const=DEFAULT_GENERATED,
        type=Path,
        help="also audit a freshly generated smashtv_core.v",
    )
    parser.add_argument(
        "--elaborate-emu",
        action="store_true",
        help="elaborate Arcade-SmashTV.sv against --generated using Icarus",
    )
    args = parser.parse_args()
    if args.elaborate_emu and args.generated is None:
        parser.error("--elaborate-emu requires --generated")

    audit = Audit()
    paths = (
        UPSTREAM,
        WRAPPER,
        PROVENANCE,
        LICENSE_NOTE,
        FULL_GPL,
        TOP,
        VENDOR,
        BUILD_SV2V,
        SIM_ELAB,
        FULL_QIP,
        FULL_QSF,
        SYN_QIP,
    )
    texts = {path: read_text(path, audit) for path in paths}

    audit_menu(texts[TOP], audit)
    audit_wrapper(texts[WRAPPER], audit)
    audit_provenance_and_license(
        texts[UPSTREAM],
        texts[PROVENANCE],
        texts[LICENSE_NOTE],
        texts[FULL_GPL],
        texts[VENDOR],
        audit,
    )
    audit_build_sources(
        texts[BUILD_SV2V],
        texts[SIM_ELAB],
        texts[FULL_QIP],
        texts[FULL_QSF],
        texts[SYN_QIP],
        audit,
    )
    audit_no_retimer(
        {
            path: texts[path]
            for path in (
                UPSTREAM,
                WRAPPER,
                PROVENANCE,
                TOP,
                BUILD_SV2V,
                FULL_QIP,
                FULL_QSF,
            )
        },
        audit,
    )

    generated_path: Path | None = None
    if args.generated is not None:
        generated_path = args.generated
        if not generated_path.is_absolute():
            generated_path = ROOT / generated_path
        generated_text = read_text(generated_path, audit)
        audit_generated(generated_path, generated_text, audit)
        if args.elaborate_emu and generated_path.is_file():
            elaborate_emu(generated_path, audit)

    if audit.failures:
        print(f"CRT RELEASE AUDIT: FAIL ({len(audit.failures)} finding(s))")
        for failure in audit.failures:
            print(f"  - {failure}")
        return 1

    suffix = " + generated emu elaboration" if args.elaborate_emu else ""
    print(f"CRT RELEASE AUDIT: PASS ({audit.checks} checks{suffix})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
