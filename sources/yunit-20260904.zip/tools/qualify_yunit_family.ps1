param(
    [Parameter(Mandatory = $true)]
    [string]$RomDirectory,
    [ValidateRange(1, 100000)]
    [int]$RuntimeFrames = 180
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$BashPath = "C:\Program Files\Git\bin\bash.exe"

if (-not (Test-Path -LiteralPath $RomDirectory)) {
    throw "ROM directory was not found: $RomDirectory"
}
if (-not (Test-Path -LiteralPath $BashPath)) {
    throw "Git Bash was not found at $BashPath"
}

function Invoke-NativeChecked {
    param(
        [scriptblock]$Command,
        [string]$Label
    )

    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Label failed with exit code $LASTEXITCODE"
    }
}

function Invoke-BashChecked {
    param(
        [string]$Command,
        [string]$Label
    )

    & $BashPath -lc $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Label failed with exit code $LASTEXITCODE"
    }
}

$FocusedTests = @(
    "tb_yunit_profiles",
    "tb_family2_inputs",
    "tb_family2_protection",
    "tb_family2_dma_queue",
    "tb_yunit_dma_term2_flip",
    "tb_family2_pageflip_coherent",
    "tb_family2_cmos_nvram",
    "tb_family2_rom_layout",
    "tb_yunit_input_bus",
    "tb_yunit_download_mapper",
    "tb_yunit_production_rom_contract",
    "tb_yunit_cpu_cadence",
    "tb_tms34010_cycle_scheduler",
    "tb_sched_equiv",
    "tb_tms34010_cycle_budget",
    "tb_tms34010_gfx_cycle_counter",
    "tb_yunit_dpyint_schedule",
    "tb_tms34010_sync_endpoints",
    "tb_yunit_display_address_sequencer",
    "tb_tms34010_display_contract",
    "tb_hq2x_blend_pipeline",
    "tb_yunit_crt_adjust",
    "tb_yunit_dynamic_video_cache",
    "tb_yunit_native_frame_contract",
    "tb_yunit_protection",
    "tb_gfx_unpack",
    "tb_yunit_gfx_unpack4",
    "tb_yunit_palfold",
    "tb_yunit_hwram",
    "tb_yunit_adpcm_map",
    "tb_audio_mix",
    "tb_sound_rom_cache",
    "tb_yunit_sound_service",
    "tb_yunit_cmos_nvram",
    "tb_yunit_mem_cdc",
    "tb_yunit_mem",
    "tb_yunit_hps_nvram",
    "tb_yunit_dma_logical_timer",
    "tb_yunit_dma_descriptor_fifo",
    "tb_yunit_dma_matrix",
    "tb_yunit_dma",
    "tb_yunit_dma_queue",
    "tb_yunit_dma_stop",
    "tb_yunit_memsys",
    "tb_yunit_memsys_trigburst",
    "tb_yunit_memsys_logical_dma",
    "tb_yunit_memsys_snapshot",
    "tb_yunit_autoerase_scheduler",
    "tb_sdram_burst_write",
    "tb_sdram_raster",
    "tb_yunit_autoerase_sdram_backend",
    "tb_yunit_sdram_burst_arb",
    "tb_yunit_shiftreg_engine",
    "tb_yunit_shiftreg_command_bridge",
    "tb_yunit_vram_word_arb",
    "tb_vram_ddr_shiftreg",
    "tb_vram_bsnoop",
    "tb_yunit_page_publish_smear",
    "tb_tms34010_io_fs32",
    "tb_tms34010_sub_cflag",
    "tb_yunit_romfetch",
    "tb_yunit_vramcheck",
    "tb_family2_palette_alias"
)

$TmsCoreTests = @(
    "tb_video",
    "tb_video_ce_rate",
    "tb_pixt",
    "tb_pixt_xy",
    "tb_pixt_pmask",
    "tb_pixt_srt",
    "tb_move_off_ni",
    "tb_smoke"
)

Push-Location $ProjectRoot
try {
    Invoke-NativeChecked {
        python -B tools/check_mutation_gates.py
    } "static mutation coverage (no declared mutant may be orphaned)"

    Invoke-NativeChecked {
        python tools/audit_yunit_crt_release.py
    } "CRT release source/provenance audit"

    Invoke-NativeChecked {
        python -B -m unittest discover
    } "offline Quartus release/parser unit tests"

    # unittest's root discovery stops at non-package directories. tools/tests
    # therefore needs an explicit start directory or its release contracts are
    # silently skipped while the qualifier reports green.
    Invoke-NativeChecked {
        python -B -m unittest discover -s tools/tests
    } "offline tools release-contract unit tests"

    Invoke-NativeChecked {
        python tools/audit_yunit_mame_contract.py --strict
    } "MAME/source contract audit"

    Invoke-NativeChecked {
        python tools/generate_yunit_mras.py $RomDirectory --out releases/yunit
    } "MRA generation"

    Invoke-NativeChecked {
        python tools/package_yunit_release.py --mra-dir releases/yunit `
            --variant production --release-id 0000000 --dry-run
    } "generated MRA ROM/NVRAM/input release audit"

    Invoke-NativeChecked {
        python tools/audit_yunit_roms.py $RomDirectory
    } "MAME byte-layout audit"

    $SmashArchive = Join-Path $RomDirectory "smashtv.zip"
    if (-not (Test-Path -LiteralPath $SmashArchive)) {
        throw "Smash TV ROM archive was not found: $SmashArchive"
    }
    Invoke-NativeChecked {
        python sim/make_stv_maindata_hex.py $SmashArchive sim/build/smashtv_maindata.hex
    } "Smash TV unpatched program simulation image"
    Invoke-NativeChecked {
        python sim/make_ffwd_hex.py
    } "Smash TV assembly-POST fast-forward simulation image"
    Invoke-NativeChecked {
        python sim/make_gfx_planes_hex.py $SmashArchive
    } "Smash TV raw MRA graphics-plane simulation image"
    Invoke-NativeChecked {
        python sim/make_gfx_hex.py $SmashArchive
    } "Smash TV MAME-unpacked graphics golden"
    Invoke-NativeChecked {
        python sim/make_snd_hex.py $SmashArchive sim/build
    } "Smash TV CVSD sound simulation images"
    Invoke-NativeChecked {
        python tools/audit_yunit_mame_runtime.py $RomDirectory --frames $RuntimeFrames
    } "MAME runtime audit"

    foreach ($Test in $FocusedTests) {
        Invoke-BashChecked `
            "export PATH=/usr/bin:/mingw64/bin:/c/iverilog/bin:`$PATH; ./sim/run.sh $Test" `
            $Test
    }

    $QuestaDirectory = Get-ChildItem `
        -Path "C:\altera\*\questa_fse\win64", "C:\altera_pro\*\questa_fse\win64" `
        -Directory -ErrorAction SilentlyContinue |
        Where-Object {
            (Test-Path -LiteralPath (Join-Path $_.FullName "vlog.exe")) -and
            (Test-Path -LiteralPath (Join-Path $_.FullName "vsim.exe")) -and
            (Test-Path -LiteralPath (Join-Path $_.FullName "vlib.exe"))
        } |
        Sort-Object FullName -Descending |
        Select-Object -First 1

    if (-not $QuestaDirectory) {
        throw "Questa was not found for the TMS34010 core regressions"
    }

    $OriginalPath = $env:PATH
    try {
        $env:PATH = "$($QuestaDirectory.FullName);$OriginalPath"
        Invoke-BashChecked `
            "bash ./sim/run_family2_profile_boot_questa.sh '$RomDirectory'" `
            "all ten profiles reach a completed first draw through the FULL hierarchy"
        foreach ($Test in $TmsCoreTests) {
            Invoke-BashChecked `
                "./rtl/tms34010/scripts/sim.sh $Test" `
                "TMS34010 $Test"
        }
        Invoke-BashChecked `
            "./sim/run_questa.sh tb_tms34010_decode_snapshot" `
            "TMS34010 registered decode boundary"
        Invoke-BashChecked `
            "./sim/run_top.sh tb_yunit_e2e" `
            "graphics download, final drain, unpack, and boot"
        Invoke-BashChecked `
            "./sim/run_top.sh tb_yunit_e2e +EARLY" `
            "early graphics download across SDRAM initialization"
        Invoke-BashChecked `
            "./sim/run_top.sh tb_yunit_realboot +DLBOOT +RSTDL +FFWD +MAXK=4000" `
            "RESET-high program byte lanes, final drain, reset vector, and boot"
        Invoke-BashChecked `
            "export EXTRA_DEFINES=+define+RELEASE_GAMELOOP; ./sim/run_top.sh tb_yunit_top_boot +MAXK=90000" `
            "Smash TV assembly POST through GAMELOOP"
        Invoke-BashChecked `
            "export EXTRA_DEFINES='+define+PC_TRACE +define+ROM_UNPATCHED'; ./sim/run_top.sh tb_yunit_top_boot +MAXK=4000" `
            "unpatched Smash TV boot instruction trace"
        Invoke-BashChecked `
            "python tools/run_pc_diff.py '/d/deck/fpga/smash tv/mame-trace/stv_bootnl.log' sim/build/rtl_bootpc.log" `
            "unpatched Smash TV MAME instruction-prefix oracle"
        Invoke-BashChecked `
            "./sim/run_questa_snd.sh tb_snd_e2e" `
            "Smash TV production external-CVSD end-to-end boot and command"
        Invoke-NativeChecked {
            python tools/run_mutation_gates.py
        } "mutation contracts (production passes and every mutant fails)"
    }
    finally {
        $env:PATH = $OriginalPath
    }

    # 20 mutation contracts are armed ONLY by this script. It was not invoked by
    # the release gate at all, so the family qualification carried a coverage story
    # nobody executed -- weaker than an orphan, because the green line implies it.
    Invoke-BashChecked `
        "export PATH=/usr/bin:/mingw64/bin:/c/iverilog/bin:`$PATH; ./sim/run_ddr3.sh" `
        "DDR3/VRAM gate suite (36 sections, 20 mutation contracts)"

    Invoke-BashChecked `
        "export PATH=/usr/bin:/mingw64/bin:/c/iverilog/bin:`$PATH; bash ./sim/run_scene_replay.sh" `
        "five MAME-captured Smash TV frames through release DDR3/NO_COMMITGATE path"

    Invoke-BashChecked `
        "export PATH=/usr/bin:/mingw64/bin:`$PATH; ./sim/run_cvsd.sh" `
        "CVSD decay/reset gate + MUT_HC55564_NO_DECAY_RESET contract"
    Invoke-BashChecked `
        "export PATH=/usr/bin:/mingw64/bin:/d/tools/ghdl/bin:`$PATH; ./sim/run_cvsd_prot.sh" `
        "CVSD boot protection window + mutation contract"

    Invoke-BashChecked `
        "export PATH=/usr/bin:/mingw64/bin:/c/iverilog/bin:`$PATH; ./quartus/build_sv2v.sh" `
        "SystemVerilog translation"

    Invoke-BashChecked `
        "export PATH=/usr/bin:/mingw64/bin:/c/iverilog/bin:`$PATH; python tools/audit_yunit_crt_release.py --generated --elaborate-emu" `
        "generated CRT modules + emu elaboration"

    Invoke-BashChecked "./sim/elab_top.sh sdram" "SDRAM top elaboration"
    Invoke-BashChecked "./sim/elab_top.sh ddr3" "DDR3 top elaboration"
    Invoke-BashChecked "./sim/elab_top.sh full-icarus" "FULL family top elaboration"

    Write-Host ""
    Write-Host "PASS: Y-unit pre-Quartus family qualification"
    Write-Host "Quartus was not started. Ask the user for explicit permission before the final build."
}
finally {
    Pop-Location
}
