#!/usr/bin/env python
"""Run the Y-unit game's OWN power-up ROM checksum test, in software.

WHY THIS EXISTS
---------------
Every simulation gate in this tree preloads ROM with `$readmemh`, which bypasses
the entire delivery chain: MRA -> hps_io ioctl -> SDRAM write -> arbiter ->
adapter -> unpack -> CPU/blitter read.  That chain is invisible to sim and is
exactly where "sim green, cab wrong" lives (project doctrine section 6).

The games ship their own per-chip ROM checksum test.  `DIAG.ASM` carries a
`ROM_CHIP` table giving, for every physical ROM, an address range and the exact
16-bit checksum the game expects.  On the cabinet a failure names the chip.  That
makes it a two-sided oracle over the one path nothing else can see -- and it
needs no MAME, no licence and no debugger.

This tool reimplements that checksum bit-for-bit so it can be run against:
  * the MRA-assembled image  (proves the DATA and the MRA recipe), and
  * a readback dump from sim or hardware  (proves DELIVERY).

Same oracle, two inputs.  A pass on the first and a fail on the second isolates
the defect to the delivery chain with no cabinet in the loop.

THE ALGORITHM (smashtv-src/DIAG.ASM ROMCHECK, ~:1688-1760)
----------------------------------------------------------
Image ROMs (WIDTH != 0) -- the graphics region, stored one 6bpp pixel per byte:
    count = (END - START)/32 + 1          # 32-bit longwords
    per longword, shifted right by 2*INTERLEAVE to select the plane:
        sum += (w & 3) | (w>>6 & 0xC) | (w>>12 & 0x30) | (w>>18 & 0xC0)
    checksum = sum & 0xFFFF
  i.e. 2 bits from each of the 4 bytes -- one plane's contribution to 4 pixels.

Program ROMs (WIDTH == 0) -- 8-bit devices interleaved in a 16-bit space:
    count = (END - START)>>4 + 1
    read one byte every 16 bit-addresses, sum, & 0xFFFF

VALIDATION
----------
Reproduced exactly, from the shipped ROM sets:
  Smash T.V.      9/9 image ROMs  + 2/2 program ROMs (source tree = rev LA5)
  Total Carnage  12/12 image ROMs                    (source tree != shipped LA1)

Program-ROM checksums are revision-specific: DIAG.ASM carries CHECKSUM ADJUST
words baked into the image so the sum lands on target, so a source tree of a
different revision than the shipped ROM disagrees by a few counts.  Graphics
ROMs carry no adjust words and match across revisions -- which is what makes
them the useful signal here.
"""
from __future__ import annotations

import argparse
import pathlib
import sys
import zipfile

# ROM_CHIP tables transcribed from each title's DIAG.ASM.
# (label, interleave, start_bit_addr, end_bit_addr, expected_checksum)
IROM_TABLES = {
    "smashtv": [  # smashtv-src/DIAG.ASM:2463-2473  (rev LA5 tree)
        ("IROM13 u111", 0, 0x2000000, 0x23FFFFF, 0x6FC0),
        ("IROM5  u95",  1, 0x2000000, 0x23FFFFF, 0xD367),
        ("IROM9  u106", 2, 0x2000000, 0x23FFFFF, 0xA9DE),
        ("IROM14 u112", 0, 0x2400000, 0x27FFFFF, 0x373E),
        ("IROM6  u96",  1, 0x2400000, 0x27FFFFF, 0xBD14),
        ("IROM10 u107", 2, 0x2400000, 0x27FFFFF, 0x1C6C),
        ("IROM15 u113", 0, 0x2800000, 0x2BFFFFF, 0x6525),
        ("IROM7  u97",  1, 0x2800000, 0x2BFFFFF, 0x0C91),
        ("IROM11 u108", 2, 0x2800000, 0x2BFFFFF, 0x14F6),
    ],
    "totcarn": [  # totcarn-src/DIAG.ASM:2475-2489
        ("IROM13 u111", 0, 0x2000000, 0x27FFFFF, 0x12FC),
        ("IROM5  u95",  1, 0x2000000, 0x27FFFFF, 0xA18E),
        ("IROM9  u106", 2, 0x2000000, 0x27FFFFF, 0xF000),
        ("IROM14 u112", 0, 0x2800000, 0x2FFFFFF, 0x0B1E),
        ("IROM6  u96",  1, 0x2800000, 0x2FFFFFF, 0xEFBA),
        ("IROM10 u107", 2, 0x2800000, 0x2FFFFFF, 0x078D),
        ("IROM15 u113", 0, 0x3000000, 0x37FFFFF, 0x0513),
        ("IROM7  u97",  1, 0x3000000, 0x37FFFFF, 0x967C),
        ("IROM11 u108", 2, 0x3000000, 0x37FFFFF, 0x09A1),
        ("IROM16 u114", 0, 0x3800000, 0x3FFFFFF, 0x588D),
        ("IROM8  u98",  1, 0x3800000, 0x3FFFFFF, 0xC806),
        ("IROM12 u109", 2, 0x3800000, 0x3FFFFFF, 0xC622),
    ],
}

# Graphics plane order, matching the MRA index-0 part order.
# plane 0 = bits[1:0] of each pixel, plane 1 = bits[3:2], plane 2 = bits[5:4].
GFX_PLANES = {
    "smashtv": (
        "la1_smash_tv_game_rom_{c}.{c}",
        [["u111", "u112", "u113"], ["u95", "u96", "u97"], ["u106", "u107", "u108"]],
    ),
    "totcarn": (
        "la1_total_carnage_game_rom_{c}.{c}",
        [["u111", "u112", "u113", "u114"],
         ["u95", "u96", "u97", "u98"],
         ["u106", "u107", "u108", "u109"]],
    ),
    # Merged-set path names: the cabinet MRA pulls these exact parts from
    # mk.zip (Y-unit Mortal Kombat rev 1.0 -- the set the ADPCM core boots).
    # No historicalsource tree exists for MK, so there is no DIAG.ASM ROM_CHIP
    # table; mkla1 is validated by FULL byte-diff (--diff-zip) instead, which
    # is strictly stronger than the 12 checksums anyway.
    "mkla1": (
        "mkla1/l1_mortal_kombat_game_rom_u-{n}.{c}",
        [["u111", "u112", "u113", "u114"],
         ["u95", "u96", "u97", "u98"],
         ["u106", "u107", "u108", "u109"]],
    ),
    # Terminator 2 LA4 (midyunit.cpp:3547-3561). Like MK there is no
    # historicalsource DIAG.ASM for T2, so validate by FULL byte-diff
    # (--diff-zip), strictly stronger than the checksum table.
    "term2": (
        "la1_terminator_2_game_rom_{c}.{c}",
        [["u111", "u112", "u113", "u114"],
         ["u95", "u96", "u97", "u98"],
         ["u106", "u107", "u108", "u109"]],
    ),
    # Strike Force LA1: the family's 4bpp TWO-plane outlier (midyunit.cpp:
    # 2867-2879; init_strkforc passes bpp=4). Plane 1 sits at the region's
    # gfx_chunk stride (0x200000, midyunit_m.cpp:249). No historicalsource
    # tree -> validated by FULL byte-diff like mkla1.
    "strkforc": (
        "la1_strike_force_game_rom_{c}.{c}",
        [["u111", "u112", "u113", "u114", "u106", "u107"],
         ["u95", "u96", "u97", "u98", "u90", "u91"]],
    ),
}

GFX_BASE = 0x2000000  # bit address of the graphics region in TMS34010 space


def build_unpacked_gfx(zip_path: pathlib.Path, title: str) -> bytes:
    """Assemble the 6bpp graphics image exactly as the MRA + FPGA unpack produce it."""
    pattern, planes_spec = GFX_PLANES[title]
    with zipfile.ZipFile(zip_path) as zf:
        planes = [
            b"".join(zf.read(pattern.format(c=chip, n=chip.lstrip("u"))) for chip in row)
            for row in planes_spec
        ]
    if len({len(p) for p in planes}) != 1:
        raise SystemExit(f"ROM_SELFTEST_FAIL {title}: plane spans differ "
                         f"{[hex(len(p)) for p in planes]}")
    out = bytearray()
    if len(planes) == 2:
        # 4bpp expansion, transcribed from midyunit_m.cpp:256-266 (case 4):
        # pixel = plane0 2 bits | plane1 2 bits << 2. Same per-byte indexing
        # as the 6bpp case, one fewer plane.
        for b0, b1 in zip(*planes):
            for shift in (0, 2, 4, 6):
                out.append(((b0 >> shift) & 3)
                           | (((b1 >> shift) & 3) << 2))
    else:
        for b0, b1, b2 in zip(*planes):
            for shift in (0, 2, 4, 6):
                out.append(((b0 >> shift) & 3)
                           | (((b1 >> shift) & 3) << 2)
                           | (((b2 >> shift) & 3) << 4))
    return bytes(out)


def image_checksum(pixels: bytes, interleave: int, start: int, end: int) -> int:
    """The game's own image-ROM checksum (DIAG.ASM RCILP)."""
    base = (start - GFX_BASE) // 8
    count = ((end - start) // 32) + 1
    if base + count * 4 > len(pixels):
        raise SystemExit(f"ROM_SELFTEST_FAIL range {start:#x}-{end:#x} "
                         f"exceeds image ({len(pixels):#x} bytes)")
    shift = 2 * interleave
    acc = 0
    for k in range(count):
        o = base + k * 4
        w = (pixels[o] | (pixels[o + 1] << 8)
             | (pixels[o + 2] << 16) | (pixels[o + 3] << 24)) >> shift
        acc += (w & 3) | ((w & 0x300) >> 6) | ((w & 0x30000) >> 12) | ((w & 0x3000000) >> 18)
    return acc & 0xFFFF


def run(title: str, pixels: bytes, source: str) -> int:
    table = IROM_TABLES[title]
    print(f"ROM_SELFTEST title={title} source={source} image={len(pixels):#x} bytes")
    bad = 0
    for label, itlv, start, end, expected in table:
        got = image_checksum(pixels, itlv, start, end)
        if got == expected:
            print(f"  PASS {label:12s} {start:#09x}-{end:#09x} itlv={itlv} cksum={got:#06x}")
        else:
            bad += 1
            print(f"  FAIL {label:12s} {start:#09x}-{end:#09x} itlv={itlv} "
                  f"cksum={got:#06x} expected={expected:#06x} "
                  f"delta={(got - expected) & 0xFFFF:#06x}")
    total = len(table)
    if bad:
        print(f"ROM_SELFTEST_FAIL {title}: {bad}/{total} image ROMs mismatch")
    else:
        print(f"ROM_SELFTEST_PASS {title}: {total}/{total} image ROMs match")
    return 1 if bad else 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("title", choices=sorted(GFX_PLANES))
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--zip", type=pathlib.Path,
                     help="MAME ROM zip -- proves the DATA and the MRA recipe")
    src.add_argument("--readback", type=pathlib.Path,
                     help="raw unpacked-pixel dump from sim or hardware -- proves DELIVERY")
    ap.add_argument("--diff-zip", type=pathlib.Path,
                    help="with --readback: FULL byte-diff of the dump against the "
                         "python-built expected image (independent transcription of "
                         "init_gfxrom). Required for titles with no DIAG.ASM table.")
    ap.add_argument("--self-test", action="store_true",
                    help="verify the oracle reproduces both titles from their shipped zips")
    args = ap.parse_args()

    if args.readback:
        pixels = args.readback.read_bytes()
        if args.diff_zip:
            expected = build_unpacked_gfx(args.diff_zip, args.title)
            n = min(len(pixels), len(expected))
            print(f"ROM_SELFTEST title={args.title} source=bytediff "
                  f"readback={len(pixels):#x} expected={len(expected):#x} bytes")
            if len(pixels) < len(expected):
                print(f"ROM_SELFTEST_FAIL {args.title}: readback shorter than expected image")
                return 1
            bad = 0
            for i in range(n):
                if pixels[i] != expected[i]:
                    if bad < 16:
                        print(f"  MISMATCH @0x{i:07x} got=0x{pixels[i]:02x} "
                              f"want=0x{expected[i]:02x}  (image MB {i >> 20})")
                    bad += 1
            if bad:
                print(f"ROM_SELFTEST_FAIL {args.title}: {bad}/{n} bytes mismatch")
                return 1
            print(f"ROM_SELFTEST_PASS {args.title}: {n:#x} bytes identical "
                  f"(full-image diff, delivery chain exact)")
            return 0
        if args.title not in IROM_TABLES:
            print(f"ROM_SELFTEST_FAIL {args.title}: no DIAG.ASM checksum table; "
                  f"pass --diff-zip for the full byte-diff oracle")
            return 1
        return run(args.title, pixels, f"readback:{args.readback.name}")
    if args.title not in IROM_TABLES:
        print(f"ROM_SELFTEST_FAIL {args.title}: no DIAG.ASM checksum table for --zip mode")
        return 1
    return run(args.title, build_unpacked_gfx(args.zip, args.title), f"zip:{args.zip.name}")


if __name__ == "__main__":
    raise SystemExit(main())
