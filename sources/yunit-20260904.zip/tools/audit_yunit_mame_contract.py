#!/usr/bin/env python3
"""Audit shared Y-unit contracts against a pinned MAME source snapshot.

Normal mode verifies the source facts and reports known RTL divergences.
--strict also makes every known family-level divergence fatal.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PINNED_MAME_COMMIT = "c531ffa701750a5345a856ec205c6428057aa63a"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def require(text: str, token: str, label: str, failures: list[str]) -> None:
    if token not in text:
        failures.append(f"{label}: missing {token!r}")


def require_order(
    text: str, tokens: tuple[str, ...], label: str, failures: list[str]
) -> None:
    positions = [text.find(token) for token in tokens]
    if any(position < 0 for position in positions):
        missing = [token for token, position in zip(tokens, positions) if position < 0]
        failures.append(f"{label}: missing ordered token(s) {missing}")
    elif positions != sorted(positions):
        failures.append(f"{label}: tokens are not in the required order")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mame-ref",
        type=Path,
        default=PROJECT_ROOT / "docs" / "mame-ref",
        help="directory containing midyunit*.cpp and tms34010.cpp",
    )
    parser.add_argument(
        "--smashtv-source",
        type=Path,
        default=PROJECT_ROOT.parent / "smashtv-src",
        help="historicalsource/smashtv checkout (audited when present)",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="fail when any known RTL/MAME family divergence remains",
    )
    args = parser.parse_args()

    ref = args.mame_ref.resolve()
    required_files = {
        "driver": ref / "midyunit.cpp",
        "machine": ref / "midyunit_m.cpp",
        "video": ref / "midyunit_v.cpp",
        "tms": ref / "tms34010.cpp",
        "sound": ref / "williamssound.cpp",
    }
    missing_files = [str(path) for path in required_files.values() if not path.is_file()]
    if missing_files:
        print("MAME CONTRACT: FAIL")
        for path in missing_files:
            print(f"  missing: {path}")
        return 1

    driver = read(required_files["driver"])
    machine = read(required_files["machine"])
    video = read(required_files["video"])
    tms = read(required_files["tms"])
    sound = read(required_files["sound"])
    failures: list[str] = []

    # Master/pixel clocks and the common Y-unit raster.
    require(driver, "SLOW_MASTER_CLOCK   = XTAL(40'000'000)", "slow clock", failures)
    require(driver, "FAST_MASTER_CLOCK   = XTAL(48'000'000)", "fast clock", failures)
    require(driver, "FASTER_MASTER_CLOCK = XTAL(50'000'000)", "faster clock", failures)
    require(driver, "STDRES_PIXEL_CLOCK = (XTAL(24'000'000) / 6)", "pixel clock", failures)
    require(driver, "m_maincpu->set_pixels_per_clock(2)", "two pixels/clock", failures)
    require(
        driver,
        "screen.set_raw(STDRES_PIXEL_CLOCK*2, 506, 90, 500, 289, 20, 276)",
        "Y-unit raster",
        failures,
    )

    # Parent/recommended title -> machine configuration. These are board data,
    # not reasons to fork RTL.
    game_configs = {
        "trog": "yunit_cvsd_4bit_slow",
        "smashtv": "yunit_cvsd_6bit_slow",
        "hiimpact": "yunit_cvsd_6bit_slow",
        "shimpact": "yunit_cvsd_6bit_slow",
        "strkforc": "yunit_cvsd_4bit_fast",
        "saurnfrnt": "yunit_cvsd_4bit_fast",
        "term2": "term2",
        "mkla4": "yunit_adpcm_6bit_fast",
        "totcarn": "yunit_adpcm_6bit_fast",
        "yunittst": "yunit_cvsd_6bit_slow",
    }
    for game, config in game_configs.items():
        candidates = [
            line
            for line in driver.splitlines()
            if "GAME(" in line and f", {game}," in line
        ]
        if not candidates or config not in candidates[0]:
            failures.append(f"{game}: expected machine configuration {config}")

    # Blitter command, logical completion, and X1 contract.
    require(video, "m_maincpu->set_input_line(0, CLEAR_LINE)", "DMA IRQ clear", failures)
    require(video, "dma_draw(command)", "DMA draw trigger", failures)
    require(
        video,
        "attotime::from_nsec(41 * m_dma_state.width * m_dma_state.height)",
        "DMA completion timer",
        failures,
    )
    require(video, "m_dma_register[DMA_COMMAND] &= ~0x8000", "DMA busy clear", failures)
    require(video, "m_maincpu->set_input_line(0, ASSERT_LINE)", "DMA IRQ assert", failures)

    # Autoerase is one row behind the beam and alternates template rows 510/511.
    require(video, "autoerase_line(params->rowaddr - 1)", "beam-locked autoerase", failures)
    require(video, "510 + (scanline & 1)", "autoerase template parity", failures)

    # Palette, CMOS/control, protection, and sound-board contracts.
    require(video, "m_palette_mask = 0x00ff", "4bpp palette mask", failures)
    require(video, "m_palette_mask = 0x0fff", "6bpp palette mask", failures)
    require(machine, "offset + m_cmos_page", "paged CMOS addressing", failures)
    require(video, "m_cmos_page = BIT(data, 6, 2) * 0x1000", "CMOS page select", failures)
    require(video, "m_videobank_select = BIT(data, 5)", "video bank select", failures)
    require(video, "m_autoerase_enable = BIT(~data, 4)", "autoerase polarity", failures)
    require(machine, "data &= 0x0f00", "protection data mask", failures)
    require(machine, "space.read_word(0x10a4390) << 4", "Strike protection", failures)
    for token, label in (
        ("{ 0x0f00, 0x0f00, 0x0f00 }", "Trog/Term2/Total Carnage protection reset"),
        ("{ 0x0b00, 0x0b00, 0x0b00 }", "High Impact protection reset"),
        ("{ 0x0f00, 0x0e00, 0x0d00 }", "Super High Impact protection reset"),
        ("{ 0x0d00, 0x0c00, 0x0900 }", "Mortal Kombat protection reset"),
        ("{ 0x1234 }", "Strike/Saurian protection personality"),
    ):
        require(machine, token, label, failures)
    require(machine, "m_cvsd_sound->reset_write(BIT(~data, 8))", "CVSD reset", failures)
    require(
        machine,
        "m_cvsd_sound->write((data & 0xff) | ((data & 0x200) >> 1))",
        "CVSD command/CB1",
        failures,
    )
    require(machine, "m_adpcm_sound->reset_write(BIT(~data, 8))", "ADPCM reset", failures)
    require(machine, "m_adpcm_sound->write(data)", "ADPCM command", failures)
    require(sound, "if (!(param & 0x200))", "ADPCM active-low IRQ command", failures)

    # TMS34010 SRT pixel-read selection and interrupt priority.
    require(tms, "read_pixel_shiftreg", "shift-register pixel read", failures)
    require(tms, "IOREG(REG_DPYCTL) & 0x0800", "DPYCTL.SRT selection", failures)
    require_order(
        tms,
        (
            "if (irq & TMS34010_HI)",
            "else if (irq & TMS34010_DI)",
            "else if (irq & TMS34010_WV)",
            "else if (irq & TMS34010_INT1)",
            "else if (irq & TMS34010_INT2)",
        ),
        "TMS34010 interrupt priority",
        failures,
    )

    # Original Smash T.V. source supplies the game-programmed DPYINT schedule.
    historical = args.smashtv_source.resolve()
    historical_checked = historical.is_dir()
    if historical_checked:
        gsp = read(historical / "GSP.INC")
        main_asm = read(historical / "MAIN.ASM")
        require(gsp, "HSINT\t.SET\t127+1BH", "Smash TV HSINT", failures)
        require(gsp, "EOSINT\t.SET\t255+1BH", "Smash TV EOSINT", failures)
        require_order(
            main_asm,
            (
                "MOVE\t@DPYINT,A2",
                "MOVI\tEOSINT,A1",
                "MOVE\tA1,@DPYINT",
                "MOVI\tHSINT,A0",
                "MOVE\tA0,@DPYINT",
                "ORI\tSRT,A0",
                "ANDNI\tSRT,A0",
            ),
            "Smash TV half/end-screen ISR",
            failures,
        )

    if failures:
        print("MAME CONTRACT: FAIL")
        for failure in failures:
            print(f"  {failure}")
        return 1

    # Report current shared architectural divergences separately from source
    # extraction. This prevents a green component test from being misread as a
    # healthy family core.
    wrapper = read(PROJECT_ROOT / "Arcade-SmashTV.sv")
    top = read(PROJECT_ROOT / "rtl" / "yunit" / "yunit_top.sv")
    memsys = read(PROJECT_ROOT / "rtl" / "yunit" / "yunit_memsys.sv")
    build_hw = read(PROJECT_ROOT / "quartus" / "build_hw.sh")
    core = read(
        PROJECT_ROOT
        / "rtl"
        / "tms34010"
        / "rtl"
        / "core"
        / "tms34010_core.sv"
    )
    tms_rtl_text = "\n".join(
        read(path)
        for path in (PROJECT_ROOT / "rtl" / "tms34010" / "rtl").rglob("*.sv")
    ).lower()
    blockers: list[str] = []

    if "CPU Speed" in wrapper or "yunit_cpu_cadence u_cpu_cadence" not in top:
        blockers.append("CPU cadence is not exclusively owned by the board profile")
    if (
        "cpu_arch_cycle" not in top
        or "tms34010_cycle_scheduler" not in tms_rtl_text
    ):
        blockers.append(
            "profile CPU target is not enforced by an instruction-retirement "
            "scheduler with TMS34010 per-opcode cycle budgets"
        )
    if (
        "tms34010_gfx_cycle_counter" not in core
        or ".gfx_cycles_valid(1'b0)" in core
    ):
        blockers.append(
            "dynamic FILL/PIXBLT retirement budgets are not connected to the "
            "exact MAME graphics-cycle counter"
        )
    if "yunit_display_address_sequencer" not in top:
        blockers.append(
            "scanout is not driven by the live DPYADR/DPYTAP display sequencer"
        )
    if (
        ".erase_start(vblank_irq)" in top
        or "yunit_autoerase_scheduler" not in top
        or "yunit_autoerase_sdram_backend" not in top
    ):
        blockers.append(
            "SDRAM autoerase is a bulk vblank sweep, not the one-row-behind scanline copy"
        )
    if "yunit_shiftreg_engine" not in top or "shiftreg_req" not in core:
        blockers.append("TMS34010 DPYCTL.SRT/shift-register pixel-read path is missing")
    if (
        "yunit_dma_logical_timer" not in memsys
        or "logical_completion_pulse" not in memsys
        or ".completion_ready(physical_completion_ready)" not in memsys
        or "assign physical_completion_ready = !dma_descriptor_active" not in memsys
    ):
        blockers.append(
            "DMA COMMAND/X1 is not fenced behind both the replaceable 41 ns/pixel "
            "minimum timer and physical renderer/write-behind completion"
        )
    if (
        'SV2V_EXTRA="-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE"' not in build_hw
        or "ALLOW_UNPROVEN_SDRAM_VRAM" not in build_hw
    ):
        blockers.append(
            "the production build is not fail-closed on the cabinet-proven DDR3 "
            "framebuffer backend"
        )
    if (
        "ioctl_upload" not in wrapper
        or "yunit_nvram_bridge" not in wrapper
    ):
        blockers.append("CMOS is volatile; no MiSTer persistent NVRAM upload/download path")

    print(f"MAME CONTRACT: PASS (pinned upstream commit {PINNED_MAME_COMMIT})")
    print("  profiles: 10 parent/recommended recipes match MAME machine classes")
    print("  CPU: profile-owned 5.0/6.0/6.25 MHz architectural targets extracted")
    print("  raster: 4 MHz TMS pixel clock, two pixels/clock, 506 x 289 raw")
    print(
        "  DMA: command/X1 waits for both 41 ns * clipped width * height and "
        "coherent physical framebuffer acceptance"
    )
    print("  autoerase: previous-row copy from parity template rows 510/511 extracted")
    print("  board I/O: palette, CMOS/control, protection, and sound contracts extracted")
    print("  TMS: SRT selection and HI>DI>WV>X1>X2 priority extracted")
    if historical_checked:
        print("  Smash TV source: DPYINT 154/282 and SRT sequence extracted")
    else:
        print(f"  Smash TV source: SKIP (checkout not found at {historical})")

    if blockers:
        print(f"RELEASE READINESS: BLOCKED ({len(blockers)} shared divergence(s))")
        for blocker in blockers:
            print(f"  BLOCKER: {blocker}")
        return 2 if args.strict else 0

    print("RELEASE READINESS: PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
