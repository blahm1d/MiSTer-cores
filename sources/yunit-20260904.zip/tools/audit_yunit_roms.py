#!/usr/bin/env python3
"""Byte-audit every generated Y-unit ROM recipe against the local MAME driver.

This is intentionally independent of MRA XML.  It builds the byte streams that
the wrapper receives from the same declarative recipes, reconstructs MAME's
canonical ROM regions, and proves program placement plus planar graphics order
before an RBF can be called a family candidate.
"""
from __future__ import annotations

import argparse
import hashlib
import re
import zipfile
from pathlib import Path

from generate_yunit_mras import GAMES, PROFILE_PLANE_WORDS

SOURCE_SET = {
    "mk": "mkla4",
}


def rom_block(source: str, setname: str) -> str:
    match = re.search(
        rf"ROM_START\(\s*{re.escape(setname)}\s*\)(.*?)ROM_END",
        source,
        flags=re.S,
    )
    if not match:
        raise ValueError(f"MAME ROM definition not found: {setname}")
    return match.group(1)


def region_text(block: str, tag: str) -> str:
    region = re.search(
        rf'ROM_REGION(?:16_LE)?\s*\([^,\n]+,\s*"{re.escape(tag)}"[^)]*\)',
        block,
    )
    if not region:
        raise ValueError(f"MAME region not found: {tag}")
    tail = block[region.end():]
    next_region = re.search(r"\bROM_REGION", tail)
    return tail[:next_region.start()] if next_region else tail


def loads(text: str, kind: str) -> list[tuple[str, int, int, int]]:
    pattern = re.compile(
        rf"{kind}\s*\(\s*\"([^\"]+)\"\s*,\s*(0x[0-9a-fA-F]+)\s*,"
        rf"\s*(0x[0-9a-fA-F]+)\s*,\s*CRC\(([0-9a-fA-F]+)\)",
    )
    return [
        (name, int(offset, 16), int(size, 16), int(crc, 16))
        for name, offset, size, crc in pattern.findall(text)
    ]


def zip_member_by_crc(
    zf: zipfile.ZipFile, expected_name: str, expected_crc: int
) -> zipfile.ZipInfo:
    matches = [
        info for info in zf.infolist()
        if info.CRC == expected_crc and Path(info.filename).name == expected_name
    ]
    if len(matches) != 1:
        raise ValueError(
            f"{expected_name}: expected one archive member with CRC "
            f"{expected_crc:08x}, found {len(matches)}"
        )
    return matches[0]


def current_gfx_stream(zf: zipfile.ZipFile, recipe: dict) -> bytes:
    stream = bytearray()
    for item in recipe["gfx"]:
        stream.extend(bytes(item) if isinstance(item, int) else zf.read(item))
    return bytes(stream)


def mame_gfx_region(zf: zipfile.ZipFile, block: str) -> bytes:
    region = bytearray(0x800000)
    for name, offset, size, crc in loads(region_text(block, "gfx"), "ROM_LOAD"):
        info = zip_member_by_crc(zf, name, crc)
        image = zf.read(info)
        if len(image) != size:
            raise ValueError(f"{name}: size {len(image):#x} != MAME {size:#x}")
        region[offset:offset + size] = image
    return bytes(region)


def unpack_hash(planes: list[memoryview], bpp: int) -> str:
    digest = hashlib.sha256()
    out = bytearray(0x10000)
    used = 0
    for values in zip(*planes):
        b0, b1 = values[0], values[1]
        b2 = values[2] if bpp == 6 else 0
        for shift in (0, 2, 4, 6):
            out[used] = (
                ((b0 >> shift) & 3)
                | (((b1 >> shift) & 3) << 2)
                | (((b2 >> shift) & 3) << 4)
            )
            used += 1
            if used == len(out):
                digest.update(out)
                used = 0
    if used:
        digest.update(memoryview(out)[:used])
    return digest.hexdigest()


def audit_gfx(zf: zipfile.ZipFile, block: str, recipe: dict) -> tuple[int, str]:
    profile = recipe["profile"]
    bpp = 4 if profile in (1, 4, 9) else 6
    nplanes = bpp // 2
    span = PROFILE_PLANE_WORDS[profile] * 2
    current = current_gfx_stream(zf, recipe)
    canonical = mame_gfx_region(zf, block)
    expected_stream = b"".join(
        canonical[plane * 0x200000:plane * 0x200000 + span]
        for plane in range(nplanes)
    )
    if current != expected_stream:
        mismatch = next(
            (i for i, pair in enumerate(zip(current, expected_stream))
             if pair[0] != pair[1]),
            min(len(current), len(expected_stream)),
        )
        raise ValueError(f"graphics plane stream mismatch at {mismatch:#x}")

    current_planes = [
        memoryview(current)[plane * span:(plane + 1) * span]
        for plane in range(nplanes)
    ]
    canonical_planes = [
        memoryview(canonical)[plane * 0x200000:plane * 0x200000 + span]
        for plane in range(nplanes)
    ]
    current_hash = unpack_hash(current_planes, bpp)
    canonical_hash = unpack_hash(canonical_planes, bpp)
    if current_hash != canonical_hash:
        raise ValueError("unpacked graphics hash differs from MAME algorithm")
    return span * 4, current_hash


def audit_program(zf: zipfile.ZipFile, block: str, recipe: dict) -> str:
    canonical = bytearray(0x100000)
    for name, offset, size, crc in loads(
        region_text(block, "maindata"), "ROM_LOAD16_BYTE"
    ):
        info = zip_member_by_crc(zf, name, crc)
        image = zf.read(info)
        if len(image) != size:
            raise ValueError(f"{name}: size {len(image):#x} != MAME {size:#x}")
        canonical[offset:offset + size * 2:2] = image

    lo_name, hi_name, lane_offset = recipe["prog"]
    lo = bytearray(0x80000)
    hi = bytearray(0x80000)
    lo_image = zf.read(lo_name)
    hi_image = zf.read(hi_name)
    lo[lane_offset:lane_offset + len(lo_image)] = lo_image
    hi[lane_offset:lane_offset + len(hi_image)] = hi_image
    current = bytearray(0x100000)
    current[0::2] = lo
    current[1::2] = hi
    if current != canonical:
        mismatch = next(i for i, pair in enumerate(zip(current, canonical))
                        if pair[0] != pair[1])
        raise ValueError(f"program placement mismatch at {mismatch:#x}")
    return hashlib.sha256(current).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("rom_dir", type=Path)
    parser.add_argument(
        "--mame-source",
        type=Path,
        default=Path("docs/mame-ref/midyunit.cpp"),
    )
    args = parser.parse_args()
    source = args.mame_source.read_text(encoding="utf-8")

    failures = 0
    for setname, recipe in GAMES.items():
        source_set = SOURCE_SET.get(setname, setname)
        archive_set = recipe.get("archive", setname)
        try:
            block = rom_block(source, source_set)
            with zipfile.ZipFile(args.rom_dir / f"{archive_set}.zip") as zf:
                program_hash = audit_program(zf, block, recipe)
                if setname == "yunittst":
                    # MAME marks the whole graphics region NO_DUMP. The MRA's
                    # zero placeholder is verified by the generator's length
                    # check, but cannot be compared to absent source bytes.
                    gfx_result = "NO_DUMP placeholder"
                else:
                    gfx_bytes, gfx_hash = audit_gfx(zf, block, recipe)
                    gfx_result = f"{gfx_bytes:#x} bytes sha256={gfx_hash[:12]}"
            print(
                f"PASS {setname:9s} program={program_hash[:12]} "
                f"gfx={gfx_result}"
            )
        except (KeyError, OSError, ValueError, zipfile.BadZipFile) as exc:
            failures += 1
            print(f"FAIL {setname:9s} {exc}")

    if failures:
        raise SystemExit(f"{failures} Y-unit ROM audit(s) failed")
    print(f"PASS all {len(GAMES)} Y-unit ROM recipes match MAME byte layout")


if __name__ == "__main__":
    main()
