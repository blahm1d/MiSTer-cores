#!/usr/bin/env python3
r"""Find memory ARRAYS driven from more procedural blocks than hardware allows.

WHY THIS EXISTS
---------------
On 2026-07-27 quartus_map died with 21 x

    Error (10028): Can't resolve multiple constant drivers for net "nvram[0][15]"

`nvram` had THREE procedural writers (CPU word write, HPS/CMOS bridge byte-lane
write, and a sim-init block). SIMULATION RESOLVES THAT SILENTLY, so every
testbench passed; only synthesis rejects it. The offending block arrived with an
inherited family checkpoint that had NEVER BEEN SYNTHESISED, so it was latent
from the moment it landed and nothing license-free could see it.

That matters more than usual now: Quartus is frozen after one more build, and a
map that dies on this class costs the whole build.

THE ACTUAL RULE, which is NOT "two drivers are bad":
  An M10K has TWO write ports. TWO procedural writers on an array is the normal
  true-dual-port idiom and synthesises fine (rtl/sound/jt6295/jtframe_dual_ram.v
  does exactly this). THREE OR MORE cannot map onto two ports -> Error (10028).
  That is precisely why pre-fix nvram (3 writers) failed and post-fix (2) passes.

WHAT THIS DECIDES, AND WHAT IT DOES NOT
  DECIDES : memory arrays. They must be module-level to infer BRAM, so a textual
            scan sees their whole driver set.
  ADVISORY: scalars. SystemVerilog allows block-local declarations inside
            `begin : label`, which a textual scan cannot scope -- sys/hps_io.sv
            legally declares `old_vs` twice in two labelled blocks. Failing on
            those produced 51 false positives, so they are printed, not failed.

VALIDATED BOTH WAYS. A positive control proves an instrument CAN fire; it never
proves the instrument is wired to the right thing. Both were needed here: an
early draft passed its self-test and still reported the real pre-fix commit as
clean, because its exclusivity rule treated any two DIFFERENT ifdef contexts as
mutually exclusive.
    --self-test        replays the known-bad 3-writer shape, must FIRE
    --regress <commit> must FAIL on <commit>~1 and PASS on <commit>

  python tools/check_multi_driver.py
  python tools/check_multi_driver.py --self-test
  python tools/check_multi_driver.py --regress c63262b
"""

import re
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

ALWAYS_RE = re.compile(r"\balways(?:_ff|_comb|_latch)?\b")
MODULE_RE = re.compile(r"^\s*(?:module|primitive)\s+(\w+)")
ENDMODULE_RE = re.compile(r"^\s*endmodule\b")
COND_RE = re.compile(r"^\s*`(ifdef|ifndef|else|elsif|endif)\b(?:\s+(\w+))?")

# Index brackets NEST: nvram[addr[14:1]][7:0]. A flat [^\]]* stops at the inner
# ']' and the match fails -- which is how an early draft missed the second nvram
# writer, i.e. the exact defect this tool exists to find.
IDX = r"(?:\s*\[(?:[^\[\]]|\[[^\[\]]*\])*\])*"
ASSIGN_RE = re.compile(r"^\s*([A-Za-z_]\w*)" + IDX + r"\s*(?:<=|=)(?!=)")

# Statements do not only begin at column 0: `if (we) mem[a] <= d;` hides the
# assignment behind a condition.
CTRL_RE = re.compile(
    r"^\s*(?:end\s+)?(?:else\s+)?(?:if|for|while|repeat|case[xz]?|foreach)\s*"
    r"\((?:[^()]|\([^()]*\))*\)\s*|^\s*else\s+|^\s*begin\s+|^\s*end\s+")

# A memory array has an UNPACKED dimension AFTER the identifier:
#   logic [15:0] nvram [0:16383];   <- array
#   logic [15:0] sig;               <- packed vector, not an array
# Anchoring on the TAIL beats modelling the whole declaration: attributes,
# packed dims and typedefs vary too much, and an over-specified pattern matched
# NOTHING tree-wide, silently demoting every array verdict to advisory.
ARRAY_TAIL_RE = re.compile(r"(\w+)\s*\[[^\[\]]*\]\s*;\s*$")
TYPE_RE = re.compile(r"\b(?:logic|reg|wire|bit)\b")


def statements(line):
    for frag in line.split(";"):
        prev = None
        while frag != prev:
            prev, frag = frag, CTRL_RE.sub("", frag, count=1)
        yield frag


def array_names(text):
    out = set()
    for line in text.splitlines():
        line = re.sub(r"//.*$", "", line).rstrip()
        if TYPE_RE.search(line):
            m = ARRAY_TAIL_RE.search(line)
            if m:
                out.add(m.group(1))
    return out


def scan_text(text):
    """-> {(module, signal): set((block_id, ifdef_context))}, scoped per module.

    Per MODULE, not per file: sys/hps_io.sv holds several modules and the same
    signal NAME in two of them is not two drivers (that keying produced 51 false
    positives).
    """
    drivers = defaultdict(set)
    module, blk = "<top>", 0
    in_always, depth, seen_begin = False, 0, False
    ifdef_stack = []

    for line in text.splitlines():
        line = re.sub(r"//.*$", "", line)

        mm = MODULE_RE.match(line)
        if mm:
            module, blk, in_always = mm.group(1), 0, False
        elif ENDMODULE_RE.match(line):
            module, in_always = "<top>", False

        c = COND_RE.match(line)
        if c:
            kind = c.group(1)
            if kind in ("ifdef", "ifndef"):
                ifdef_stack.append("%s %s" % (kind, c.group(2)))
            elif kind in ("else", "elsif") and ifdef_stack:
                ifdef_stack[-1] += "/else"
            elif kind == "endif" and ifdef_stack:
                ifdef_stack.pop()
            continue

        if not in_always and ALWAYS_RE.search(line):
            in_always, blk, depth, seen_begin = True, blk + 1, 0, False

        if in_always:
            nb = len(re.findall(r"\bbegin\b", line))
            ne = len(re.findall(r"\bend\b(?!case|module|function|task|generate)", line))
            if nb:
                seen_begin = True
            depth += nb - ne
            for frag in statements(line):
                a = ASSIGN_RE.match(frag)
                if a:
                    drivers[(module, a.group(1))].add((blk, " & ".join(ifdef_stack)))
            if (seen_begin and depth <= 0) or (not seen_begin and ";" in line):
                in_always = False
    return drivers


def _guard(ctx):
    """(macro, is_negative_arm) for the innermost guard of a context string."""
    if not ctx:
        return (None, None)
    last = ctx.split(" & ")[-1]
    neg = last.endswith("/else")
    if neg:
        last = last[:-5]
    parts = last.split()
    if len(parts) != 2:
        return (None, None)
    kind, name = parts
    return (name, (kind == "ifndef") != neg)


def complementary(ctxs):
    """Exclusive ONLY if every arm guards the SAME macro with both polarities.

    "The contexts differ" is NOT exclusivity: `ifndef SYNTHESIS` (a sim-init
    block) and `ifdef USE_HW_RAM` are different axes and can both be active. An
    early draft used the loose test and therefore reported the real pre-fix
    nvram (3 writers) as legal, missing the defect it was written for.
    """
    g = {_guard(c) for c in ctxs}
    if any(m is None for m, _ in g):
        return False
    return len({m for m, _ in g}) == 1 and len({p for _, p in g}) == 2


def audit(paths):
    findings = []
    for p in paths:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        arrays = array_names(text)
        for (mod, sig), drv in scan_text(text).items():
            blocks = {b for b, _ in drv}
            if len(blocks) < 2:
                continue
            ctxs = {c for _, c in drv}
            if len(blocks) == len(ctxs) and complementary(ctxs):
                kind = "IFDEF-ARMS"
            elif sig in arrays:
                kind = "DUAL-PORT-OK" if len(blocks) == 2 else "ARRAY>2"
            else:
                kind = "SCALAR"
            findings.append((p, "%s.%s" % (mod, sig), sorted(blocks),
                             sorted(ctxs), kind))
    return findings


KNOWN_BAD = """
module m;
  logic [15:0] nvram [0:16383];
  always @(posedge clk) begin
    nv_cpu_q <= nvram[nv_cpu_addr];
    if (nv_cpu_we) nvram[nv_cpu_addr] <= nv_cpu_wdata;
  end
  always @(posedge clk) begin
    if (nvram_ext_wr_on) nvram[nvram_ext_addr[14:1]][7:0] <= nvram_ext_wdata;
  end
  always @(posedge clk) begin
    if (init) nvram[i] <= 16'h0000;
  end
endmodule
"""


def sources():
    out = []
    for pat in ("*.sv", "*.v"):
        out += [p for p in ROOT.rglob(pat)
                if not {".claude", "worktrees", "build_syn"} & set(p.parts)
                and p.parent.name != "sim"]
    return out


def report(findings):
    real = [f for f in findings if f[4] == "ARRAY>2"]
    dual = [f for f in findings if f[4] == "DUAL-PORT-OK"]
    guard = [f for f in findings if f[4] == "IFDEF-ARMS"]
    scal = [f for f in findings if f[4] == "SCALAR"]

    print("arrays with >2 procedural writers (WILL FAIL map) : %d" % len(real))
    print("arrays with 2 writers (true-dual-port, legal)     : %d" % len(dual))
    print("mutually exclusive ifdef arms (legal)             : %d" % len(guard))
    print("scalars (ADVISORY -- block-local scope unparsed)  : %d" % len(scal))
    for p, sig, blocks, _c, _k in real:
        print("\n  ARRAY>2  %s  '%s'  %d procedural writers"
              % (p.relative_to(ROOT).as_posix(), sig, len(blocks)))
    if real:
        print("\nFAIL: more writers than the two write ports an M10K provides.")
        return 1
    print("\nPASS: every array has at most 2 procedural writers.")
    return 0


def regress(commit):
    ok = True
    for tag, ref in (("PRE-FIX (map died)", commit + "~1"),
                     ("CURRENT (map ok)  ", commit)):
        blob = subprocess.run(["git", "show", ref + ":rtl/yunit/yunit_mem.sv"],
                              cwd=str(ROOT), capture_output=True, text=True)
        if blob.returncode != 0:
            print("%s: could not read blob" % tag)
            ok = False
            continue
        fh = tempfile.NamedTemporaryFile("w", suffix=".sv", delete=False,
                                         encoding="utf-8")
        fh.write(blob.stdout)
        fh.close()
        tmp = Path(fh.name)
        res = audit([tmp])
        tmp.unlink()
        nv = [(len(x[2]), x[4]) for x in res if x[1].endswith(".nvram")]
        bad = [x for x in res if x[4] == "ARRAY>2"]
        print("%s: nvram=%s  ARRAY>2=%d" % (tag, nv, len(bad)))
        if tag.startswith("PRE-FIX") and not bad:
            print("   ATTACHMENT FAIL: does not fire on the real defect.")
            ok = False
        if tag.startswith("CURRENT") and bad:
            print("   FALSE POSITIVE: fires on a tree that maps cleanly.")
            ok = False
    print("REGRESS PASS" if ok else "REGRESS FAIL")
    return 0 if ok else 1


def main():
    if "--self-test" in sys.argv:
        d = scan_text(KNOWN_BAD)
        blocks = {b for k, v in d.items() if k[1] == "nvram" for b, _ in v}
        arrays = array_names(KNOWN_BAD)
        if len(blocks) >= 3 and "nvram" in arrays:
            print("SELF-TEST PASS: %d writers detected on array 'nvram'."
                  % len(blocks))
            return 0
        print("SELF-TEST FAIL: writers=%d array_detected=%s"
              % (len(blocks), "nvram" in arrays))
        print("  Refusing to report: a zero from a blind instrument is")
        print("  indistinguishable from a clean tree.")
        return 1

    if "--regress" in sys.argv:
        i = sys.argv.index("--regress")
        return regress(sys.argv[i + 1] if len(sys.argv) > i + 1 else "HEAD")

    files = sources()
    print("scanned %d source files" % len(files))
    return report(audit(files))


if __name__ == "__main__":
    sys.exit(main())
