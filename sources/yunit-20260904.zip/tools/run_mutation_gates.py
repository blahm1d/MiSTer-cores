#!/usr/bin/env python3
"""Run each mutation contract and REQUIRE the mutant to fail its gate.

WHY THIS EXISTS
---------------
tools/check_mutation_gates.py catches a define that no runner ever sets. This
catches the worse case: a mutant that IS invoked but never actually turns the
suite red. An orphan is at least honestly absent; an invoked mutant that always
passes emits a green line, which is an active false statement about coverage.
(Distinction owed to the NARC/Z-unit session.)

A mutation contract is only real if BOTH hold:
  (a) production passes the gate, and
  (b) the mutant FAILS it.
Checking only (a) proves nothing about the mutant. Checking only (b) would let a
gate that fails for an unrelated reason look like coverage.

REFUSES TO REPORT ON A BAD ANCHOR. If a define is not actually present in the
sources the gate compiles, the mutant silently compiles to production and
"fails to fail" for a reason that has nothing to do with the design. That is
indistinguishable from real coverage loss unless it is checked, so this errors
out instead of grading. (Design owed to the T-unit session, whose runner refuses
to report when its mutation anchor is missing.)

USAGE
    python tools/run_mutation_gates.py            # all contracts
    python tools/run_mutation_gates.py --list     # show the table, run nothing
"""

import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BASH = r"C:\Program Files\Git\bin\bash.exe"

# (testbench, mutation define, one-line description of what the mutant restores)
CONTRACTS = [
    ("tb_yunit_romfetch", "PERF_INVALIDATE_ANY_WRITE",
     "restores invalidate-on-ANY-write; must fail the write-dense scenario C"),
    ("tb_yunit_romfetch", "PERF_NO_STREAMBUF",
     "removes the 8-word ROM stream buffer; must fail the throughput gate"),
    ("tb_yunit_romfetch", "PERF_NO_WORDFETCH",
     "restores the byte-serial fetch path; must fail the throughput gate"),
    ("tb_yunit_hwram", "MUT_WRITE_RDATA_CLEAR",
     "restores the address-conditioned fallback-write read-data clear; must fail "
     "the write-response hold contract that removes a_q -> mem_rdata"),
    ("tb_tms34010_intpend_rmw", "MUT_IO_INTPEND_WHOLE_WRITE",
     "restores the unmasked INTPEND store; must fail the read-only/w0c gate"),
    ("tb_tms34010_sync_endpoints", "MUT_TMS_SYNC_EXCLUSIVE",
     "restores exclusive HESYNC/VESYNC endpoint compares; must fail the TI "
     "duration-minus-one and Smash assembly pulse-width gate"),
    ("tb_yunit_native_frame_contract", "MUT_DISPLAY_START_REPLAY_LINE0",
     "restores the zero-VTOTAL wrap at HTOTAL timing start; must blank native "
     "line zero and fail the assembly-defined 410x256 active-frame gate"),
    ("tb_tms34010_io_fs32", "MUT_IO_NO_FS32_SPAN",
     "drops the FS>16 high half again; must fail the two-register span gate"),
    # Replaces the old tb_smashtv_input_guard / MUT_SMASHTV_INPUT_UNSAFE pair.
    # That contract was GREEN while describing nothing that ships: it tested
    # smashtv_input_guard.sv, a module Quartus reports as "Found entity" but
    # NEVER elaborates -- the fix was folded into yunit_input_mapper instead.
    # This one mutates the line that is actually in the design.
    ("tb_yunit_profiles", "MUT_SMASHTV_ROTARY_ON",
     "restores the unsupported rotary DIP (drops the |0x4000 force); must fail "
     "'Smash rotary DIP must be forced off' -- half 1 of the cab-confirmed fire fix"),
    ("tb_family2_inputs", "MUT_F2_START_FIXED_10",
     "restores the fixed joy[10]/joy[11] Start/Coin positions; must fail "
     "Total Carnage's four-action joy[8]/joy[9] cabinet contract"),
    ("tb_family2_inputs", "MUT_F2_SMASHTV_ROTARY_ON",
     "restores Smash TV's unsupported rotary DIP; must fail the Family2 "
     "cabinet input gate's forced-off contract"),
    ("tb_family2_dma_queue", "MUT_DMA_NO_BUSY_QUEUE",
     "restores Family2 busy-time DMA trigger stalling instead of the one-entry "
     "pending snapshot; must fail the exact production-path queue gate"),
    ("tb_audio_mix", "MUT_AUDIO_YM_020",
     "restores the un-scaled JT51 level; must fail the MAME-ratio mix gate"),
    ("tb_vram_bsnoop", "MUT_NO_BSNOOP",
     "restores the pre-repair B-side design; must TIME OUT (unbounded fill wait)"),
    ("tb_vram_bsnoop", "MUT_NO_BMERGE",
     "keeps the new FSM but disables in-flight merge; must fail C2 with stale data"),
    ("tb_yunit_page_publish_smear", "MUT_B_SCAN_NO_PROOF",
     "removes only the exact retired-write readback proof while retaining the "
     "cabinet-rejected bounded shadow; tall background/sprite writes must go stale"),
    ("tb_family2_pageflip_coherent", "MUT_BASE_LATCH_SKEW",
     "moves pixel-page ownership three pixel stages later than prefetch-page "
     "ownership; the row-cache-shaped page-boundary stress must diverge"),
    ("tb_yunit_sound_cdc", "MUT_SND_CDC_RAW_LEVEL",
     "restores the raw 2-FF level crossing; the game's close write pair is then "
     "lost or corrupted at many clock phases (measured 72 of 72 combinations)"),
    ("tb_yunit_sound_service", "MUT_SOUND_LOW_PRIORITY",
     "restores external sound below the continuously requesting CPU ROM client; "
     "must starve the first production-cache refill and fail bounded service"),
    ("tb_yunit_dynamic_video_cache", "MUT_DYNAMIC_FULL_ROW_REFILL",
     "restores the 512-word dynamic scanline refill that exceeds the physical "
     "line budget; must violate the exact wrapped visible-window read count"),
    ("tb_yunit_display_address_sequencer", "MUT_DYNAMIC_ROW_ZERO",
     "collapses every live display descriptor onto physical row zero; must fail "
     "the E00C family origin and normal row-progression contracts"),
    ("tb_yunit_sf_display_replay", "MUT_FLIP_BUSY_COMMIT_GATE",
     "restores the refuted global-fb_busy binding at the production seam; an "
     "alternating A->B->A title then loses every B flip while a full-screen fill "
     "crosses VSBLNK and must fail scenario D's page-sentinel checks"),
    ("tb_dma_dpy_ratio", "MUT_BAD_CE",
     "ties the CRTC ce high (the old differential rig) instead of clk_sys/24; the "
     "production arm must then span multiple DPYINTs in one DMA and fail"),
    ("tb_yunit_vramcheck", "PERF_NO_BEATCACHE2",
     "removes the second-level beat cache; must fail the DDR3 throughput gate "
     "(measured: U33 191->636 against a 414 budget, U29 258->707 against 600)"),
    ("tb_family2_palette_alias", "MUT_FAMILY2_PALETTE_6BPP_FOLD",
     "restores the FULL path's unconditional 0x0fff palette fold; must fail "
     "Trog's observed raw 0x1f00 -> visible pen 0x00 alias contract"),
    ("tb_family2_cmos_nvram", "MUT_FAMILY2_NVRAM_DROP_WR",
     "drops index-4 restore writes at the Family2 memory boundary; must fail "
     "the four-page byte-lane restore/readback contract"),
    ("tb_family2_cmos_nvram", "MUT_NVRAM_RESET_DROPS_FORWARD",
     "clears the byte-merge forwarder while nvram_loading holds the game in "
     "reset; must fail the cabinet-shaped consecutive-byte restore contract"),
    ("tb_yunit_cmos_nvram", "MUT_NVRAM_RESET_DROPS_FORWARD",
     "clears the byte-merge forwarder in the legacy Y memory hierarchy while "
     "reset-time index-4 restore is active; must fail the same adjacent-lane "
     "cabinet contract"),
    ("tb_family2_protection", "MUT_FAMILY2_PROTECTION_DROP",
     "drops Family2's title-protection memory-map seam; must fail High Impact, "
     "MK, and Strike Force response checks"),
    ("tb_yunit_adpcm_prot", "MUT_ADPCM_PROT_BLANKET64",
     "sizes every hidden-RAM window at the 64-entry array instead of the gospel "
     "prot_end; must fail on the addresses past each window (Term2 worst, 48 over)"),
    ("tb_yunit_adpcm_map", "MUT_JT51_ACC_PARTIAL_RESET",
     "restores JT51's partial accumulator reset; must leave the exact PCM "
     "outputs unknown instead of deterministic zero during board reset"),
    ("tb_yunit_adpcm_map", "MUT_ADPCM_CHILD_RESET_COUPLED",
     "restores the pre-fix host-reset coupling into JT51/OKI and their clock "
     "dividers; must fail the MAME reset-domain split assertion"),
    ("tb_yunit_adpcm_map", "MUT_ADPCM_MIX_NARROW",
     "restores the 20-bit mixer accumulator that overflows/sign-flips on loud FM "
     "(ym_left*26 > 20-bit signed max); must fail the full-scale FM mix-correctness "
     "check (the cabinet FM-crunch root cause)"),
    ("tb_yunit_shiftreg_command_bridge", "MUT_SHIFTREG_RAW_COMMAND",
     "restores the full decode cone directly into the full-rate shift-register "
     "engine; must fail the registered cpu_ce command-boundary gate"),
    ("tb_yunit_shiftreg_command_bridge", "MUT_SHIFTREG_DIRECT_ACK",
     "restores the live engine completion bypass around the CPU-CE response "
     "register; must fail the registered return-boundary gate"),
    ("tb_vram_ddr_shiftreg", "MUT_SRT_EARLY_DONE",
     "acknowledges each SRT command after its first 32-beat sub-burst; must "
     "fail the per-command 256-beat bridge-acceptance and ready-at-done contract"),
    ("tms:tb_fill_srt", "MUT_SRT_FILL_AS_ORDINARY",
     "restores the rejected behavior where SRT FILL uses ordinary writes; "
     "must fail the exact 105-command core-side cadence contract"),
    ("tb_yunit_crt_adjust", "MUT_CRT_RAW_HSYNC_RESET",
     "restarts the variable read-rate accumulator from raw native HS instead of "
     "the shifted hs_ref_out contract; must fail the far-shift phase assertion"),
    ("tb_yunit_crt_adjust", "MUT_CRT_HPOS_MINUS5",
     "re-admits Y's measured first clipped -5 H-position boundary; must fail "
     "the dynamic full-row/blanking gate"),
    ("tb_yunit_crt_adjust", "MUT_CRT_HPOS_PLUS45",
     "re-admits the first positive H-position that overlaps sync at H-size -4; "
     "must fail the globally coherent 49x5 control rectangle"),
    ("tb_yunit_crt_adjust", "MUT_CRT_HSIZE_MINUS5",
     "re-admits the first H-size that overlaps sync at H-position +44; must fail "
     "the globally coherent 49x5 control rectangle"),
    ("tb_yunit_crt_adjust", "MUT_CRT_VSHIFT_MINUS13",
     "re-admits the first unsafe upward V-shift; must fail when shifted VSync "
     "appears outside VBlank at the active-line boundary"),
    ("tb_yunit_crt_adjust", "MUT_CRT_VSHIFT_PLUS18",
     "re-admits the first unsafe positive V-shift; must fail when shifted VSync "
     "wraps outside VBlank at the top-of-frame boundary"),
    ("tb_yunit_crt_adjust", "MUT_CRT_VB_NO_HB_EDGES",
     "routes combined buffered blank through VBlank lines; arcade_video can no "
     "longer sample VBlank because no HBlank falling edge remains"),
    ("tms:tb_move_off_ni", "MUT_MOVE_OFF_NI_OFFSET_DEST",
     "incorrectly applies the source displacement to the destination; must fail "
     "the TMS34010 MOVE *Rs(S),*Rd+ field-store contract"),
    ("tms:tb_move_off_ni", "MUT_MOVE_OFF_NI_FIXED32",
     "hardcodes the destination post-increment to 32 instead of FS; must fail "
     "the non-32-bit field-size case"),
    ("tms:tb_io_write_boundary", "MUT_IO_BOUNDARY_UNSHIFTED_LOW_DATA",
     "registers right-justified low data without positioning it at addr[3:0]; "
     "must fail the seeded offset-three one-bit physical write"),
    ("tms:tb_io_write_boundary", "MUT_IO_BOUNDARY_FULL_LOW_MASK",
     "registers a full-word mask for every low field; must clobber the seeded "
     "PSIZE bits outside the offset-three one-bit write"),
    ("tms:tb_io_write_boundary", "MUT_IO_BOUNDARY_NO_SPAN",
     "drops the registered FS32 span bit; must fail the adjacent physical "
     "high-word commit"),
    ("tms:tb_io_subword_field", "MUT_IO_REG_RAW_FIELD_WRITE",
     "restores whole-register replacement for sub-word I/O writes; must fail "
     "the physical T2/Strike Force INTENB and PMASK field-write checks"),
    ("tms:tb_io_subword_field", "MUT_IO_STATUS_RAW_FIELD_FORWARD",
     "leaves the CPU status shadow on raw whole-register writes; must fail "
     "the retirement-edge INTENB shadow checks"),
    ("tms:tb_io_subword_field", "MUT_IO_CONFIG_RAW_FIELD_FORWARD",
     "leaves the CPU config shadow on raw whole-register writes; must fail "
     "the retirement-edge PMASK shadow check"),
    ("tms:tb_io_subword_field", "MUT_IO_INTPEND_RAW_FIELD_WRITE",
     "applies a one-bit INTPEND clear as a raw whole-register value; must fail "
     "the physical and CPU-shadow WV-preservation checks"),
    ("tms:tb_dirq_rearm_liveness", "MUT_IO_REG_RAW_FIELD_WRITE",
     "clobbers physical INTENB during a one-bit re-arm; must fail the second "
     "real display-interrupt entry"),
]


def run(cmd: str, timeout: int = 900):
    return subprocess.run([BASH, "-lc", cmd], capture_output=True, text=True,
                          timeout=timeout, cwd=str(ROOT))


def gate_command(tb: str, define: str | None = None) -> str:
    if tb.startswith("tms:"):
        actual = tb.removeprefix("tms:")
        defines = []
        if actual == "tb_fill_srt":
            defines.append("+define+YUNIT_SRT_FILL_BURST")
        if define:
            defines.append(f"+define+{define}")
        extra = f'EXTRA_DEFINES="{" ".join(defines)}" ' if defines else ""
        return f'{extra}./rtl/tms34010/scripts/sim.sh {actual}'
    mutation = (
        f"SV2V_EXTRA_DEFINE={define} MUTATE={define} " if define else ""
    )
    return (
        "export PATH=/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH && "
        f"{mutation}./sim/run.sh {tb}"
    )


def gate_sources(tb: str) -> str:
    """Ask run.sh which sources a gate compiles, so the anchor check is honest."""
    out = run(f'cd "{ROOT.as_posix()}" && SV2V_FIRST=0 bash -c '
              f"\"grep -A8 '  {tb})' sim/run.sh\"")
    return out.stdout


def anchor_present(tb: str, define: str) -> bool:
    """The define must appear in some source this gate could plausibly compile.

    Deliberately broad: we are guarding against a define that has been renamed
    or deleted out from under the contract, not policing which file holds it.
    """
    for pattern in ("rtl/**/*.sv", "rtl/**/*.v",
                    "sim/**/*.sv", "sim/**/*.v"):
        for p in ROOT.glob(pattern):
            try:
                if define in p.read_text(encoding="utf-8", errors="replace"):
                    return True
            except OSError:
                continue
    return False


def main() -> int:
    if "--list" in sys.argv:
        for tb, define, why in CONTRACTS:
            print(f"{tb:32s} {define:28s} {why}")
        return 0

    failures = []
    print(f"mutation contracts to verify: {len(CONTRACTS)}\n")

    # (a) production must pass every gate that carries a contract.
    for tb in sorted({t for t, _, _ in CONTRACTS}):
        r = run(gate_command(tb))
        if r.returncode != 0:
            print(f"[prod ] {tb:32s} FAIL (exit {r.returncode}) -- production must pass first")
            failures.append(f"{tb} production")
        else:
            print(f"[prod ] {tb:32s} ok")

    print()

    # (b) every mutant must FAIL its gate.
    for tb, define, why in CONTRACTS:
        if not anchor_present(tb, define):
            print(f"[ANCHOR] {tb:32s} {define}")
            print(f"         define not found in any source -- REFUSING to grade this contract.")
            print(f"         A missing anchor makes the mutant compile to production, so")
            print(f"         'failed to fail' would be meaningless rather than a finding.")
            failures.append(f"{define} anchor missing")
            continue

        r = run(gate_command(tb, define))
        # run.sh exits non-zero when the gate fails, which is what we WANT here.
        if r.returncode == 0:
            print(f"[mutant] {tb:32s} {define:28s} STILL PASSES -- contract is not real")
            print(f"         expected: {why}")
            failures.append(f"{define} did not fail")
        else:
            print(f"[mutant] {tb:32s} {define:28s} dies as required")

    print()
    if failures:
        print(f"FAIL: {len(failures)} mutation contract(s) unproven:")
        for f in failures:
            print(f"  - {f}")
        return 1
    print(f"PASS: all {len(CONTRACTS)} mutation contracts proven "
          f"(production passes AND each mutant fails).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
