// yunit_diag_service_overlay.sv — F4 SERVICE INSTRUMENT (+define+DIAG_SERVICE).
//
// Screen-as-logic-analyzer for the three questions the e519fcf cabinet rejection left open
// (see SHIP-SPEC-yunit-2026-08-02.md §4 and yunit_service_counters.sv). Same compositing
// contract as the proven smashtv_diag2_overlay: the instrument paints into the top-left
// QUADRANT and the real game shows everywhere else, so you can read the numbers AND see which
// scene the game is on. DIAG_BOOT's overlay is deliberately left untouched -- this is a
// separate module behind its own define, so the proven boot instrument cannot regress.
//
// HOW TO READ IT ON THE CAB (one photo per title):
//
//   LED strip, left to right:
//     0 core released   1 sdram ready    2 download done   3 SOUND REGION HAS DATA
//     4 sound board out of reset         5 CVSD 6809 alive 6 ADPCM board alive
//     7 CPU getting SDRAM grants         8 no blanked pixels                9 CPU_CE alive
//
//   Hex rows, top to bottom:
//     A  CPU grants (hi) | SOUND grants (lo)     <- Q1. SOUND >> CPU = the port is sound's.
//     B  worst CPU stall, clks                   <- Q1. Thousands = starvation, not a tax.
//     C  sound cache misses (hi) | snd_rd busy/16 (lo)
//                                                <- Q1. Compare misses against row D: misses
//                                                   ~= address changes means ~0% hit rate,
//                                                   which is the ADPCM thrash signature.
//     D  CVSD addr changes (hi) | ADPCM addr changes (lo)
//                                                <- Q2. Which board is actually executing.
//                                                   Expect CVSD non-zero even on ADPCM titles.
//     E  first two words read back from the sound region
//                                                <- Q2. 00000000 or FFFFFFFF = the region was
//                                                   never populated: a download/mapper bug,
//                                                   NOT a codec bug. This one number decides
//                                                   where the silence hunt goes next.
//     F  total sound SDRAM acks (free-running)   <- Q2. Stuck at 0 = never served at all.
//     G  blanked pixels in active window (hi) | warm-restart count (lo)
//                                                <- Q3 + the reboot.
//     H  CPU PC transitions this frame           <- is the game running at all, and how fast.
//
// Everything here is observation only. Nothing in this file drives the datapath.
`default_nettype none

module yunit_diag_service_overlay
#(
  parameter int H_ACT=410, H_FP=6,  H_SYNC=44, H_BP=46,
  parameter int V_ACT=256, V_FP=13, V_SYNC=4,  V_BP=16
)(
  input  logic        clk, ce_pix, rst,

  // boot-gate levels (same taps the boot overlay uses)
  input  logic        core_rst, sdram_ready, ioctl_download, cpu_ce,

  // service counters (all latched per frame by yunit_service_counters)
  input  logic [15:0] cnt_cgfx_grants,
  input  logic [15:0] cnt_snd_grants,
  input  logic [31:0] cnt_cgfx_maxwait,
  input  logic [15:0] cnt_snd_miss,
  input  logic [15:0] cnt_snd_busy16,
  input  logic [15:0] cnt_cvsd_moves,
  input  logic [15:0] cnt_adpcm_moves,
  input  logic [15:0] cnt_blank_pix,
  input  logic [31:0] cnt_cpu_pc_moves,
  input  logic [31:0] cnt_snd_acks,
  input  logic [31:0] snd_first_words,
  input  logic        snd_region_seen,
  input  logic        snd_board_rst,
  input  logic [15:0] restart_cnt,

  // GAME VIDEO passthrough (composited: diag in the top-left quadrant, game elsewhere)
  input  logic [7:0]  g_r, g_g, g_b,
  input  logic        g_hs, g_vs, g_hb, g_vb, g_de,
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de
);

  function automatic [14:0] glyph(input [3:0] v);
    case (v)
      4'h0: glyph=15'b111_101_101_101_111;  4'h1: glyph=15'b010_110_010_010_111;
      4'h2: glyph=15'b111_001_111_100_111;  4'h3: glyph=15'b111_001_111_001_111;
      4'h4: glyph=15'b101_101_111_001_001;  4'h5: glyph=15'b111_100_111_001_111;
      4'h6: glyph=15'b111_100_111_101_111;  4'h7: glyph=15'b111_001_001_010_010;
      4'h8: glyph=15'b111_101_111_101_111;  4'h9: glyph=15'b111_101_111_001_111;
      4'hA: glyph=15'b111_101_111_101_101;  4'hB: glyph=15'b110_101_110_101_110;
      4'hC: glyph=15'b111_100_100_100_111;  4'hD: glyph=15'b110_101_101_101_110;
      4'hE: glyph=15'b111_100_111_100_111;  default: glyph=15'b111_100_111_100_100; // F
    endcase
  endfunction
  function automatic fpix(input [3:0] d, input [2:0] col, input [2:0] row);
    logic [14:0] g; logic [2:0] rb; g=glyph(d);
    case (row) 3'd0:rb=g[14:12]; 3'd1:rb=g[11:9]; 3'd2:rb=g[8:6]; 3'd3:rb=g[5:3]; default:rb=g[2:0]; endcase
    fpix = (col==3'd0)?rb[2] : (col==3'd1)?rb[1] : (col==3'd2)?rb[0] : 1'b0;
  endfunction

  // Track the GAME's active raster and render into the top-left quadrant using virtual
  // full-frame coords, exactly as the boot overlay does.
  logic [11:0] gx, gy; logic de_q, vb_q; logic [23:0] frame;
  always_ff @(posedge clk) begin
    if (rst) begin gx<=12'd0; gy<=12'd0; de_q<=1'b0; vb_q<=1'b0; frame<=24'd0; end
    else if (ce_pix) begin
      de_q<=g_de; vb_q<=g_vb;
      if (g_vb && !vb_q)          begin gy<=12'd0; gx<=12'd0; frame<=frame+24'd1; end
      else if (g_de)              gx<=gx+12'd1;
      else if (de_q && !g_de)     begin gx<=12'd0; gy<=gy+12'd1; end
    end
  end
  wire [11:0] hc = gx << 1;
  wire [11:0] vc = gy << 1;
  wire s0_de = (hc<H_ACT) && (vc<V_ACT);

  // ---- CPU_CE liveness (toggled both ways within a frame = alive) ----
  wire frame_tick = ce_pix && g_vb && !vb_q;
  logic a1_ce, a0_ce, alive_ce;
  always_ff @(posedge clk) begin
    if (rst) begin a1_ce<=1'b0; a0_ce<=1'b0; alive_ce<=1'b0; end
    else begin
      if (cpu_ce) a1_ce<=1'b1; else a0_ce<=1'b1;
      if (frame_tick) begin alive_ce<=a1_ce&a0_ce; a1_ce<=1'b0; a0_ce<=1'b0; end
    end
  end

  // ---- LED strip: 10 service lanes ----
  localparam int LEDW = H_ACT/10;
  wire in_leds = (vc>=12'd44) && (vc<12'd52);
  wire [3:0] led_lane = (hc<LEDW)?4'd0:(hc<2*LEDW)?4'd1:(hc<3*LEDW)?4'd2:(hc<4*LEDW)?4'd3:
                        (hc<5*LEDW)?4'd4:(hc<6*LEDW)?4'd5:(hc<7*LEDW)?4'd6:(hc<8*LEDW)?4'd7:
                        (hc<9*LEDW)?4'd8:4'd9;
  wire [11:0] led_x = hc - (led_lane*LEDW);
  wire led_body = (led_x>=12'd2) && (led_x < (LEDW-2));
  logic led_good;
  always_comb case (led_lane)
    4'd0: led_good = ~core_rst;
    4'd1: led_good =  sdram_ready;
    4'd2: led_good = ~ioctl_download;
    4'd3: led_good =  snd_region_seen;                 // the sound region holds real data
    4'd4: led_good = ~snd_board_rst;                   // the sound board was released
    4'd5: led_good = (cnt_cvsd_moves  != 16'd0);       // CVSD 6809 executing
    4'd6: led_good = (cnt_adpcm_moves != 16'd0);       // ADPCM board executing
    4'd7: led_good = (cnt_cgfx_grants >  16'd64);      // CPU is getting real SDRAM service
    4'd8: led_good = (cnt_blank_pix   == 16'd0);       // nothing blanked in the active window
    default: led_good = alive_ce;
  endcase

  // color bars (top strip) — video/clock sanity
  localparam int HE=H_ACT/8;
  logic [7:0] cbr,cbg,cbb;
  wire [2:0] barx=(hc<HE)?3'd0:(hc<2*HE)?3'd1:(hc<3*HE)?3'd2:(hc<4*HE)?3'd3:
                  (hc<5*HE)?3'd4:(hc<6*HE)?3'd5:(hc<7*HE)?3'd6:3'd7;
  always_comb case (barx)
    3'd0:{cbr,cbg,cbb}={8'hFF,8'hFF,8'hFF}; 3'd1:{cbr,cbg,cbb}={8'hFF,8'hFF,8'h00};
    3'd2:{cbr,cbg,cbb}={8'h00,8'hFF,8'hFF}; 3'd3:{cbr,cbg,cbb}={8'h00,8'hFF,8'h00};
    3'd4:{cbr,cbg,cbb}={8'hFF,8'h00,8'hFF}; 3'd5:{cbr,cbg,cbb}={8'hFF,8'h00,8'h00};
    3'd6:{cbr,cbg,cbb}={8'h00,8'h00,8'hFF}; default:{cbr,cbg,cbb}={8'h20,8'h20,8'h20};
  endcase

  // ---- 8 hex rows at 24px pitch, 20px tall (glyph 5 rows x 4px) ----
  logic [31:0] rowval; logic in_hex; logic [11:0] ry0;
  always_comb begin
    in_hex=1'b0; rowval=32'd0; ry0=12'd0;
    if      (vc>=12'd52  && vc<12'd72 ) begin in_hex=1'b1; ry0=12'd52;  rowval={cnt_cgfx_grants, cnt_snd_grants};  end
    else if (vc>=12'd76  && vc<12'd96 ) begin in_hex=1'b1; ry0=12'd76;  rowval=cnt_cgfx_maxwait;                   end
    else if (vc>=12'd100 && vc<12'd120) begin in_hex=1'b1; ry0=12'd100; rowval={cnt_snd_miss, cnt_snd_busy16};     end
    else if (vc>=12'd124 && vc<12'd144) begin in_hex=1'b1; ry0=12'd124; rowval={cnt_cvsd_moves, cnt_adpcm_moves};  end
    else if (vc>=12'd148 && vc<12'd168) begin in_hex=1'b1; ry0=12'd148; rowval=snd_first_words;                    end
    else if (vc>=12'd172 && vc<12'd192) begin in_hex=1'b1; ry0=12'd172; rowval=cnt_snd_acks;                       end
    else if (vc>=12'd196 && vc<12'd216) begin in_hex=1'b1; ry0=12'd196; rowval={cnt_blank_pix, restart_cnt};       end
    else if (vc>=12'd220 && vc<12'd240) begin in_hex=1'b1; ry0=12'd220; rowval=cnt_cpu_pc_moves;                   end
  end
  // 8 digits x 16px = 128px wide, starting at column 8.
  localparam int PX0=8;
  wire        hxin  = (hc>=PX0) && (hc<PX0+128);
  wire [7:0]  hrx   = hc - PX0[11:0];
  wire [2:0]  hdig  = hrx[6:4];
  wire [1:0]  hfcol = hrx[3:2];
  wire [11:0] hry12 = vc - ry0;
  wire [2:0]  hfrow = hry12[4:2];
  wire [4:0]  hsh   = {2'b0,(3'd7-hdig)} << 2;
  wire [3:0]  hnyb  = rowval >> hsh;
  wire        hex_on= in_hex && hxin && (hfcol<2'd3) && (hfrow<3'd5) && fpix(hnyb, {1'b0,hfcol}, hfrow);

  // Status bar: green only if the CPU is BOTH executing and being served.
  wire healthy   = (cnt_cpu_pc_moves != 32'd0) && (cnt_cgfx_grants > 16'd64);
  wire in_status = (vc>=12'd24) && (vc<12'd44);
  wire live_col  = (hc == frame[8:0]);

  always_ff @(posedge clk) if (ce_pix) begin
    de<=g_de; hsync<=g_hs; vsync<=g_vs; hblank<=g_hb; vblank<=g_vb;   // GAME timing passthrough
    if (!g_de)               begin vid_r<=8'd0; vid_g<=8'd0; vid_b<=8'd0; end
    else if (!s0_de)         begin vid_r<=g_r;  vid_g<=g_g;  vid_b<=g_b;  end  // GAME outside the quadrant
    else if (vc<12'd20)      begin vid_r<=cbr;  vid_g<=cbg;  vid_b<=cbb;  end
    else if (live_col)       begin vid_r<=8'hFF; vid_g<=8'hFF; vid_b<=8'hFF; end
    else if (in_status) begin
      if (healthy) begin vid_r<=8'h00; vid_g<=8'hC0; vid_b<=8'h00; end
      else         begin vid_r<=8'hC0; vid_g<=8'h00; vid_b<=8'h00; end
    end
    else if (in_leds) begin
      if (led_body) begin
        if (led_good) begin vid_r<=8'h00; vid_g<=8'hE0; vid_b<=8'h00; end
        else          begin vid_r<=8'hE0; vid_g<=8'h00; vid_b<=8'h00; end
      end else        begin vid_r<=8'h00; vid_g<=8'h00; vid_b<=8'h00; end
    end
    else if (in_hex) begin
      if (hex_on)  begin vid_r<=8'hFF; vid_g<=8'hFF; vid_b<=8'h00; end
      else         begin vid_r<=8'h10; vid_g<=8'h10; vid_b<=8'h30; end
    end
    else           begin vid_r<=8'h08; vid_g<=8'h08; vid_b<=8'h08; end
  end
endmodule

`default_nettype wire
