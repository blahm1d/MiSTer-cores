# MiSTer CRT Adjust license

`crt_adjust.sv` is distributed under the GNU General Public License,
version 3 or later, by Umberto Parisi (`rmonic79`).

The complete GPLv3 license text is already distributed in this source tree at
`rtl/sound/jt6295/LICENSE`. The upstream source notice and exact provenance are
preserved in `crt_adjust.sv` and `MiSTer-CRT-Adjust.UPSTREAM.md`.
