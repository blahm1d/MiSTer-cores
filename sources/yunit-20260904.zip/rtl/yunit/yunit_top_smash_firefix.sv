// yunit_top_smash_firefix.sv — Phase 6 W2: the synthesizable Y-unit core (everything below the
// Template_MiSTer chassis). Composes the proven pieces into one top the emu wraps:
//
//   tms34010_core  <-> yunit_memsys_smash_firefix (CPU + DMA blitter + memory map; SYNTHESIS
//                      selects the external gfx/ROM/VRAM SDRAM ports)
//   yunit_sdram_arb + sdram_phy  : all SDRAM traffic (gfx ROM, prog ROM, VRAM,
//                      + ioctl ROM download) onto one MT48LC16M16 word port
//   yunit_video_top_smash_firefix : VRAM(SDRAM) -> line buffer -> pen_map6 -> palette -> RGB
//   yunit_palram    : palette mirror (video read port, fed by CPU palette writes)
//   williams_cvsd_board : Y-unit sound (6809 + YM2151 + CVSD), on its own ~12 MHz
//                      clock; the sound latch is crossed clk -> clk_snd (CDC).
//
// Clocking: `clk` runs the CPU / memory / SDRAM / video logic; `ce_pix` gates the
// raster; `clk_snd` (~12 MHz) runs the sound board. Game/CPU speed calibration
// (the real 34010 runs far slower than the SDRAM clock) is a later tuning knob.
`default_nettype none
module yunit_top_smash_firefix
  import yunit_pkg::*;
  import tms34010_pkg::*;
#(
  parameter ROM_HEX = "smashtv_maindata.hex",
  // video geometry (Smash T.V. stdres; see yunit_video_smash_firefix)
  parameter int H_ACT=410, H_FP=6,  H_SYNC=40, H_BP=50,
  parameter int V_ACT=256, V_FP=13, V_SYNC=8,  V_BP=12,
  parameter int DISP_ROW0=0,
  // SDRAM word-address map (see rtl/sdram/yunit_sdram_arb.sv, tb_sdram_full)
  parameter [24:0] GFXW_BASE = 25'h000000,
  parameter [24:0] ROMW_BASE = 25'h0C0000,
  parameter [24:0] VRAMW_BASE= 25'h0E0000,
  parameter [23:0] GFX_BYTES = 24'h180000,
  parameter [24:0] SCRATCH_WBASE = 25'h120000,   // raw gfx planes (boot scratch)
  // Present only to match the current multi-MRA wrapper.  The cabinet-good
  // Smash path downloads CVSD bytes directly into the sound-board BRAMs.
  parameter [24:0] SOUNDW_BASE   = 25'h120000,
  parameter [23:0] PLANE_WORDS   = 24'h30000     // words/plane (E2E sim overrides small)
)(
  input  logic        clk,        // core clock (memory + SDRAM + video logic), ~96 MHz
  input  logic        clk_cpu,    // UNUSED since P0019: the CPU now runs on `clk` gated by the
                                   // selected cpu_ce divisor instead of this async /4 tap.
                                   // Port kept so the emu wiring is unchanged (easy revert).
  input  logic        ce_pix,     // pixel-clock enable (video raster)
  input  logic  [2:0] cpu_div_sel,// OSD CPU-speed: 0=/4(default headroom), 1=/6, 2=/8, 3=/10, 4=/12, 5=/14, 6=/16, 7=/20(stock)
  input  logic        clk_snd,    // ~12 MHz sound-board clock
  input  logic        rst,        // core reset (active high)
  input  logic        rst_pon,    // power-on reset (sound board full init)
  input  logic        sdram_por,  // P0022: TRUE power-on (synchronized ~locked) for the PERSISTENT
                                  // SDRAM/download subsystem. Unlike `rst`/`rst_pon` it is LOW during
                                  // any ROM download (which always follows PLL lock), so the capture
                                  // path (FIFO+arb+adapter+phy) keeps running even if the framework
                                  // holds RESET high across the download -> the black-screen root cause.

  input  logic [63:0] inputs,     // {DSW, IN2, IN1, IN0}, active-low
  // Current runtime-profile wrapper compatibility.  This dedicated module is
  // selected only for Smash, whose already-mapped `inputs` bus is authoritative.
  input  logic [3:0]  game_id,
  input  logic [31:0] term2_analog,

  // Current index-4 CMOS side-port compatibility.  The exact firefix memory
  // image had no external persistence port; outputs are tied safely below.
  input  logic        cmos_quiesce,
  input  logic        nvram_ext_en,
  input  logic        nvram_ext_wr,
  input  logic [14:0] nvram_ext_addr,
  input  logic [7:0]  nvram_ext_wdata,
  output logic [7:0]  nvram_ext_rdata,
  output logic        cmos_cpu_busy,
  output logic        cmos_cpu_write_pulse,

  // ioctl ROM download -> SDRAM word writes (gfx@GFXW_BASE, prog ROM@ROMW_BASE).
  // The MRA/loader presents a linear WORD address matching the SDRAM layout.
  input  logic        ioctl_download,  // held high during ROM load (holds the CPU in reset)
  input  logic        gfx_download,
  input  logic        sound_download,
  input  logic        ioctl_wr,
  input  logic [24:0] ioctl_addr,   // SDRAM word address (gfx planes -> scratch, prog ROM)
  input  logic [15:0] ioctl_dout,
  input  logic [1:0]  ioctl_be,     // byte lane(s): 11=packed plane word, 01/10=interleaved ROM
  output logic        ioctl_wait,

  // MRA sound-ROM download (BYTE stream, clk domain). addr[17:16]=chip (0=U4 1=U19
  // 2=U20), addr[15:0]=byte within the 64KB chip. Routed to the CVSD board's BRAMs.
  input  logic        snd_dl_wr,
  input  logic [17:0] snd_dl_addr,
  input  logic [7:0]  snd_dl_data,

  // SDRAM (MT48LC16M16) pins
  inout  wire  [15:0] SDRAM_DQ,
  output logic [12:0] SDRAM_A,
  output logic [1:0]  SDRAM_BA,
  output logic        SDRAM_DQML, SDRAM_DQMH,
  output logic        SDRAM_nCS, SDRAM_nRAS, SDRAM_nCAS, SDRAM_nWE,
  output logic        SDRAM_CKE,
  // NOTE: SDRAM_CLK is NOT a port here — the emu forwards it from clk_sdram (outclk_1,
  // -3515ps) directly to the pin, matching rtl/sdram.sdc (general[1]) and the proven
  // tecmo/jtframe cores. Keeping it out of the core avoids double-driving the pin.

  // HPS DDR3 (f2h_sdram1) Avalon master. Ports are UNCONDITIONAL (the emu is Quartus-native,
  // NOT sv2v'd, so it cannot see USE_DDR3_VRAM) — under USE_DDR3_VRAM they carry VRAM traffic;
  // otherwise they are tied off to 0 inside. DDRAM_CLK is driven by the emu (= clk_sys, no CDC).
  output logic [28:0] DDRAM_ADDR,
  output logic [7:0]  DDRAM_BURSTCNT,
  output logic        DDRAM_RD,
  output logic [63:0] DDRAM_DIN,
  output logic [7:0]  DDRAM_BE,
  output logic        DDRAM_WE,
  input  logic        DDRAM_BUSY,
  input  logic [63:0] DDRAM_DOUT,
  input  logic        DDRAM_DOUT_READY,

  // video out
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de,

  // audio out (signed PCM)
  output logic signed [15:0] audio_l, audio_r,
  output logic               adpcm_irq,

  // debug
  output logic [31:0] pc_dbg,
  output logic        illegal_dbg,
  // boot-instrument taps (observability only; read by the DIAG_BOOT overlay). Unconnected
  // in the normal build — pure outputs, no behavioral effect.
  output logic        dbg_core_rst,
  output logic        dbg_sdram_ready,
  output logic        dbg_unp_done,
  output logic        dbg_cpu_req,
  output logic        dbg_mem_ack,
  output logic        dbg_int1,
  output logic        dbg_vblank_irq,
  output logic        dbg_cpu_ce,          // P0019: CPU clock-enable pulse (liveness tap for the
                                           // DIAG_BOOT overlay — proves the /4 CE is actually pulsing)
  output logic [31:0] dbg_p1ctrl,          // fire-chain watch: {P1CTRL last value, write count}
  output logic [31:0] dbg_bdir,            // fire-chain watch: {B_DIR last value, write count}
  output logic [7:0]  dbg_snd_select,      // sound-latch command byte (live copy)
  output logic        dbg_snd_trig,        // sound-latch strobe (count edges at the consumer)
  // derail capture (frozen at the FIRST time the PC leaves R_ROM = the wild jump)
  output logic        dbg_derailed,
  output logic [31:0] dbg_culprit_pc,     // last valid code PC = the instruction that jumped
  output logic [15:0] dbg_culprit_instr,  // opcode at the culprit
  output logic [31:0] dbg_derail_pc,       // where it jumped TO (the bad target)
  // Display-base instrument (DIAG_DISPBASE) + the runtime autoerase kill (OSD bit). Both are
  // family2-only features. The PORTS are unconditional across every core top because the emu
  // binds ONE port list for all flavours (see the F4 block below for the same rule); this
  // frozen recovery datapath implements neither, so the outputs tie to 0 and the input is
  // unused. A zero here reads as "not instrumented in this flavour", not "the tap is dead".
  output logic [31:0] dbg_disp_flips,
  output logic [31:0] dbg_disp_rows,
  input  wire         autoerase_off,
  // P0020 download audit: dropped vs accepted FIFO pushes (see the iol_* block below).
  output logic [31:0] dbg_iol_drop,        // # download words DROPPED on FIFO overflow (>0 = hps_io outran backpressure)
  output logic [31:0] dbg_iol_wrs,         // # download words ACCEPTED into the FIFO (should reach ~0xD0000)
  // cont.24 splash-capture diag taps (DIAG_SPLASHCAP): the DMA reg-write stream + the blitter's
  // first source byte + the scanout stream, so the emu overlay can capture the title-splash blit
  // commands (LEFT/RIGHT column) and the boot-noise scanout on the cab.
  output logic        dbg_dma_we,
  output logic  [3:0] dbg_dma_addr,
  output logic [15:0] dbg_dma_wdata,
  output logic  [7:0] dbg_src_data,
  output logic        dbg_src_ack,
  output logic [15:0] dbg_scan_data,
  output logic        dbg_scan_ack,
  // ---- F4 cabinet service instrument (SHIP-SPEC-yunit-2026-08-02.md §4) --------------
  // Same unconditional-port rule as yunit_top_family2: the emu binds these for every
  // flavour and gates the overlay behind its own Quartus macro. yunit_service_counters is
  // a family2 block and the recovery datapath has no service instrument at all, so every
  // counter ties to 0 here -- there is no DIAG_SERVICE variant of this flavour to build.
  output logic [15:0] dbg_cgfx_grants,
  output logic [15:0] dbg_snd_grants,
  output logic [31:0] dbg_cgfx_maxwait,
  output logic [15:0] dbg_snd_miss,
  output logic [15:0] dbg_snd_busy16,
  output logic [15:0] dbg_cvsd_moves,
  output logic [15:0] dbg_adpcm_moves,
  output logic [15:0] dbg_blank_pix,
  output logic [31:0] dbg_cpu_pc_moves,
  output logic [31:0] dbg_snd_acks,
  output logic [31:0] dbg_snd_first_words,
  output logic        dbg_snd_region_seen,
  output logic        dbg_snd_board_rst,
  output logic [15:0] dbg_restart_cnt
);
  // Wrapper-only compatibility signals.  Keeping them explicit prevents an
  // accidental X from reaching the chassis while preserving the cabinet-good
  // CVSD and internal-CMOS implementation bit-for-bit.
  assign nvram_ext_rdata       = 8'h00;
  assign cmos_cpu_busy         = 1'b0;
  assign cmos_cpu_write_pulse  = 1'b0;
  assign adpcm_irq             = 1'b0;
  wire unused_wrapper_inputs = ^{game_id, term2_analog, cmos_quiesce,
                                 nvram_ext_en, nvram_ext_wr, nvram_ext_addr,
                                 nvram_ext_wdata, gfx_download, sound_download,
                                 SOUNDW_BASE, GFX_BYTES};
  // Hold the CPU / memory / video in reset until the SDRAM controller has finished
  // its power-up init (the real MiSTer pattern: the core waits for SDRAM ready +
  // ROM load). Without this the CPU's first fetch rises DURING init and the phy's
  // rising-edge accept misses it -> the held request deadlocks. The SDRAM phy +
  // arbiter run on the raw `rst` so init can proceed while the core is held.
  // sdram_ready is driven by the stock-SDRAM adapter (sticky: it latches the controller's
  // first `ready` = power-up init complete). The adapter + sdram_stock run on raw `rst`.
  logic sdram_ready;
  // Boot-time SDRAM scratch for the raw gfx planes (see yunit_gfx_unpack): plane0 @
  // SCRATCH_WBASE, plane1 @ +PLANE_WORDS, plane2 @ +2*PLANE_WORDS (module parameters).
  // unp_done: gfx unpack complete. 1 in sim (the tb preloads flat gfx directly);
  // in synth it rises only after the boot-time planar->flat pass finishes.
  logic unp_done;
  // Hold the core during ROM download AND the subsequent gfx-unpack pass: SDRAM stays
  // initialized (ready) so the ioctl/unpack channels can write it, while the CPU/video
  // wait until the ROMs are loaded and the gfx is unpacked.
  wire  core_rst = rst | ~sdram_ready | ioctl_download | ~unp_done;

  // ---- CPU on clk + clock-enable (P0019: NO separate async clk_cpu) -----------
  // HISTORY: the CPU used to run on a separate clk_cpu (~24 MHz) PLL tap, with
  // yunit_mem_cdc as a real clock-domain crossing to memsys (clk 96 MHz). That
  // passed zero-delay sim but FAILED on silicon. clk_cpu is clk/4 from the SAME PLL
  // (phase-locked, NOT truly async), yet the SDC declared it asynchronous, so STA
  // never timed the CPU<->memsys crossing and the fitter routed those paths freely
  // -> the CPU read back garbage for its reset vector on the cab while the live PC
  // (clk-sampled) marched. FIX: run the CPU on `clk` gated by a 1-in-4 clock-enable
  // (cpu_ce) so it advances at the identical ~24 MHz rate but on a SINGLE clock.
  // The CDC's cpu-side FSM is gated by the SAME cpu_ce (its clk_cpu port is driven
  // by clk), so the 2-phase toggle handshake is behaviorally identical to the proven
  // /4-clock sim, but now single-clock: STA times everything and no metastability is
  // possible. The long CPU combinational path (~30 MHz max) gets 4 clk periods via a
  // 4:1 multicycle in rtl/sdram.sdc (cpu_ce -> memsys and back).
  // CPU-SPEED SELECTOR: this non-cycle-accurate core shares DDR3 with scanout and
  // pays much higher VRAM latency than the original board. Cab A/B is decisive:
  // /20 reaches the software deadline late and warps/restarts; /4 reaches attract.
  // Therefore status 0 defaults to /4 headroom and /20 remains the last, explicitly
  // labelled stock-rate experiment. This only addresses the independent deadline/
  // watchdog failure; it does not claim to fix missing or broken sprites. Every
  // selectable divisor is >=4, so the 4:1 cpu_ce multicycle remains conservative.
  logic [4:0] cpu_ce_div;
  always_comb case (cpu_div_sel)
    3'd0: cpu_ce_div = 5'd4;  3'd1: cpu_ce_div = 5'd6;  3'd2: cpu_ce_div = 5'd8;  3'd3: cpu_ce_div = 5'd10;
    3'd4: cpu_ce_div = 5'd12; 3'd5: cpu_ce_div = 5'd14; 3'd6: cpu_ce_div = 5'd16; default: cpu_ce_div = 5'd20;
  endcase
  logic [4:0] ce_div;
  always_ff @(posedge clk) if (rst) ce_div <= 5'd0;
                           else     ce_div <= (ce_div == cpu_ce_div - 5'd1) ? 5'd0 : ce_div + 5'd1;
  wire cpu_ce = (ce_div == 5'd0);          // 1 clk-wide pulse every cpu_ce_div'th clk

  // Reset synchronizer into clk, shared by the core AND the CDC (both single-clock now).
  // core_rst is a raw combinational term; reclocking its deassertion into clk gives clean
  // recovery/removal on all CPU-side flops. memsys/arb keep raw core_rst (never crossed).
  logic core_rst_sys_m, core_rst_sys;
  always_ff @(posedge clk) begin core_rst_sys_m <= core_rst; core_rst_sys <= core_rst_sys_m; end
  // int1 (DMA-done LINT1, the blit-queue pump) is generated by u_sys on clk — already in
  // the CPU's clock domain now, so it drives the core directly (sampled on cpu_ce edges).
  logic int1;

  // CPU memory interface (clk, advanced by cpu_ce)
  logic cpu_req, cpu_we; logic [ADDR_WIDTH-1:0] cpu_addr; logic [FIELD_SIZE_WIDTH-1:0] cpu_size;
  logic [DATA_WIDTH-1:0] cpu_wdata, cpu_rdata; logic cpu_ack;
  core_state_t state_w; instr_word_t instr_w;

  // .ce_pix = P0023 (ported from UMK3): the core's internal tms34010_video counters
  // advance at the DOT rate (8 MHz enable), not raw clk. Without it DPYINT fired ~12x
  // too fast at meaningless scanline positions -- lethal at the boot's first EINT
  // (cab: warm-restart cycle through CLSCRACH/INTENB-enable, PC samples FFE0DEC0/
  // FFE0E7D0/FFE01970 = init -> enable DPYINT -> die -> restart, decoded vs ROM dasm).
  //
  // cont.23 — the LAST 2x (pixels_per_clock=2): MAME midyunit.cpp:1291-1306 sets the 34010's
  // set_pixel_clock(4 MHz) + set_pixels_per_clock(2), screen dot clock = 8 MHz. So the video
  // COUNTERS tick at 4 MHz (each tick = 2 screen dots), NOT the 8 MHz dot rate. P0023 fixed 12x->2x
  // but left the counters at the full 8 MHz ce_pix -> DPYINT/DIRQ/@TIMER ran at 110 Hz vs the 55 Hz
  // display (yunit_video_smash_firefix 506x289 @ 8 MHz) = a 2:1 mismatch. That ONE bug = overspeed (110 Hz DIRQ,
  // NOT a cpu_ce issue) + flashing (draw/erase chase a 110 Hz phantom beam) + dropped sprites (DIRQ
  // at wrong displayed rows) + START->bonus warp (watchdog @TIMER>=200 climbs 2x fast). FIX: feed
  // the CORE's video counters ce_pix/2 (= the 4 MHz pixel clock); yunit_video_smash_firefix KEEPS the full 8 MHz
  // ce_pix (it paints 506 real dots/line). Scoped to the 34010 counters only. VERIFIED in sim
  // (tb_video_2x): 2.000 DPYINT/display-frame at full ce_pix -> 1.000 at ce_pix/2.
  logic ce_pix_ph;
  logic timing_start;
  always_ff @(posedge clk) begin
`ifdef MUT_TIMING_NO_DIV_RESYNC
    if (core_rst_sys) ce_pix_ph <= 1'b0;
`else
    // HTOTAL activates the previously-zero internal raster. Reset the /2 dot
    // phase on that exact write edge, including when it coincides with ce_pix.
    if (core_rst_sys || timing_start) ce_pix_ph <= 1'b0;
`endif
    else if (ce_pix) ce_pix_ph <= ~ce_pix_ph;
  end
  wire ce_pix_cnt = ce_pix & ce_pix_ph;   // 4 MHz pixel clock = every 2nd 8 MHz ce_pix tick
  tms34010_core u_core (
    .clk(clk), .ce_cpu(cpu_ce), .ce_pix(ce_pix_cnt), .rst(core_rst_sys),
    .mem_req(cpu_req), .mem_we(cpu_we), .mem_addr(cpu_addr), .mem_size(cpu_size),
    .mem_wdata(cpu_wdata), .mem_rdata(cpu_rdata), .mem_ack(cpu_ack),
    .state_o(state_w), .pc_o(pc_dbg), .instr_word_o(instr_w),
    .illegal_opcode_o(illegal_dbg),
    .srt_fill_ack_i(1'b0),
    // Retain the later core's decode/interrupt/timing correctness fixes while
    // explicitly declining the universal-Y scheduler/display/SRT sidebands.
    // The firefix top continues to use its proven /4 CE, fixed scanout row
    // sequencing, and ordinary memory path.
    .instruction_start_o(), .instruction_retire_o(),
    .instruction_cycles_o(), .instruction_cycles_valid_o(),
    .timing_start_o(timing_start),
    .display_wr_valid_o(), .display_wr_idx_o(), .display_wr_data_o(),
    .display_line_wrap_o(),
    .display_dpyadr_live_i(16'd0), .display_dpyadr_live_valid_i(1'b0),
    .srt_fill_exact_enable_i(1'b0),
    .shiftreg_req_o(), .shiftreg_write_o(), .shiftreg_bit_addr_o(),
    .lint1_in(int1));

  // memsys-domain memory interface (clk); fed by the CDC's memsys side
  logic mem_req, mem_we; logic [ADDR_WIDTH-1:0] mem_addr; logic [FIELD_SIZE_WIDTH-1:0] mem_size;
  logic [DATA_WIDTH-1:0] mem_wdata, mem_rdata; logic mem_ack;

  yunit_mem_cdc #(.AW(ADDR_WIDTH), .DW(DATA_WIDTH), .SW(FIELD_SIZE_WIDTH)) u_memcdc (
    .clk_cpu(clk), .ce_cpu(cpu_ce), .rst_cpu(core_rst_sys),
    .c_req(cpu_req), .c_we(cpu_we), .c_addr(cpu_addr), .c_size(cpu_size), .c_wdata(cpu_wdata),
    .c_ack(cpu_ack), .c_rdata(cpu_rdata),
    .clk_sys(clk), .rst_sys(core_rst_sys),
    .m_req(mem_req), .m_we(mem_we), .m_addr(mem_addr), .m_size(mem_size), .m_wdata(mem_wdata),
    .m_rdata(mem_rdata), .m_ack(mem_ack));

  // ---- memsys external channels ----------------------------------------------
  logic        src_req;  logic [23:0] src_addr;  logic [7:0] src_data;  logic src_ack;
  logic        cgfx_rd;  logic [23:0] cgfx_addr; logic [15:0] cgfx_data; logic cgfx_ack;  // PERF: word-wide cgfx
  logic        scan_req; logic [17:0] scan_addr; logic [15:0] scan_data; logic scan_ack;
`ifndef USE_DDR3_VRAM
  logic [24:0] vsd_addr; logic [15:0] vsd_din, vsd_dout; logic [1:0] vsd_be;
  logic        vsd_rd, vsd_wr, vsd_ack;
  // VRAM stays on SDRAM -> DDR3 master is unused: tie it off (mirrors the emu's old tie-off).
  assign DDRAM_ADDR=29'd0; assign DDRAM_BURSTCNT=8'd0; assign DDRAM_RD=1'b0;
  assign DDRAM_DIN=64'd0;  assign DDRAM_BE=8'd0;       assign DDRAM_WE=1'b0;
`endif
  logic [7:0]  snd_select; logic snd_trig, snd_reset;
  assign dbg_snd_select = snd_select;   // fire-chain/sound diag copies (always-on, no cost)
  assign dbg_snd_trig   = snd_trig;
  logic        erase_busy, blit_busy;
  logic        fb_snoop_we;
  logic [17:0] fb_snoop_addr;
  logic [15:0] fb_snoop_data;
  // palette write-tap
  logic        palv_we_a, palv_we_b; logic [12:0] palv_aa, palv_ba; logic [15:0] palv_awd, palv_bwd;

  // autoerase: whole-frame sweep triggered at vblank (post-scanout model, frame-
  // gate verified). row0 = DISP_ROW0, lines = V_ACT.
  logic vblank_irq;

  yunit_memsys_smash_firefix #(.ROM_HEX(ROM_HEX)) u_sys (
    .clk(clk), .rst(core_rst),
    .mem_req(mem_req), .mem_we(mem_we), .mem_addr(mem_addr), .mem_size(mem_size),
    .mem_wdata(mem_wdata), .mem_rdata(mem_rdata), .mem_ack(mem_ack),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .inputs(inputs), .int1(int1),
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .dbg_p1ctrl(dbg_p1ctrl), .dbg_bdir(dbg_bdir),
`ifdef DIAG_NO_AUTOERASE
    .erase_start(1'b0),                 // DIAG probe: kill autoerase -> confirm it is the flicker source
`else
    .erase_start(vblank_irq),
`endif
    .erase_row0(9'(DISP_ROW0)), .erase_lines(10'(V_ACT)),
    .erase_busy(erase_busy), .blit_busy(blit_busy),
    .fb_snoop_we(fb_snoop_we), .fb_snoop_addr(fb_snoop_addr), .fb_snoop_data(fb_snoop_data),
    .dbg_dma_we(dbg_dma_we), .dbg_dma_addr(dbg_dma_addr), .dbg_dma_wdata(dbg_dma_wdata),   // cont.24 splash-capture
    // external gfx/ROM read (CPU gfx window)
    .cpu_gfx_rd(cgfx_rd), .cpu_gfx_raddr(cgfx_addr), .cpu_gfx_rdata(cgfx_data), .cpu_gfx_rack(cgfx_ack),
    // VRAM SDRAM channel + video scanout (memsys's fb_ack is internal — not a port)
`ifdef USE_DDR3_VRAM
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
    .sdram_por(sdram_por),
    .ddram_addr(DDRAM_ADDR), .ddram_burstcnt(DDRAM_BURSTCNT), .ddram_rd(DDRAM_RD), .ddram_we(DDRAM_WE),
    .ddram_din(DDRAM_DIN), .ddram_be(DDRAM_BE),
    .ddram_busy(DDRAM_BUSY), .ddram_dout(DDRAM_DOUT), .ddram_dout_ready(DDRAM_DOUT_READY),
`else
 `ifdef USE_SDRAM_VRAM
  `ifdef SDRAM_SINGLEBEAT_SCANOUT
    // ISOLATION (cont.23 HW bring-up): page-mode u_scanout DISABLED -> vram_sdram_top serves scanout
    // via its own single-beat path (VSD). Tests whether the page-mode burst scanout is the HW-corruption.
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
  `else
    // SDRAM: scanout is served by the P2 page-mode row-cache (u_scanout) below, NOT vram_sdram_top's
    // single-beat scanout (which oversubscribed the line budget, P0023). Tie memsys's scanout off.
    .scan_req(1'b0), .scan_addr(18'd0), .scan_data(), .scan_ack(),
  `endif
    .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr),
    .vsd_dout(vsd_dout), .vsd_ack(vsd_ack),
 `endif  // USE_SDRAM_VRAM -- under USE_HW_VRAM memsys has no scan_*/vsd_* ports (BRAM framebuffer)
`endif
    // palette write-tap
    .palv_we_a(palv_we_a), .palv_aa(palv_aa), .palv_awd(palv_awd),
    .palv_we_b(palv_we_b), .palv_ba(palv_ba), .palv_bwd(palv_bwd));

  // ---- video subsystem -------------------------------------------------------
  logic [11:0] pal_raddr; logic [15:0] pal_rdata;
`ifdef MUT_YVIDEO_RAW_RESET
  wire video_rst = core_rst;
`else
  // Keep the physical raster and the 34010 counters on the same reset-release
  // edge.  core_rst can fall within two sys clocks of ce_pix; using it directly
  // could let yunit_video_smash_firefix consume an 8 MHz tick while the synchronized 34010
  // counter and its /2 phase divider are still held reset.
  wire video_rst = core_rst_sys;
`endif
`ifdef MUT_TIMING_NO_HTOTAL_RESYNC
  wire video_phase_rst = video_rst;
`else
  // Reset the complete video_top (raster + scanline ownership) on the same
  // first-HTOTAL write that starts the internal 34010 timing generator.
  wire video_phase_rst = video_rst | timing_start;
`endif
  yunit_video_top_smash_firefix #(
    .H_ACT(H_ACT), .H_FP(H_FP), .H_SYNC(H_SYNC), .H_BP(H_BP),
    .V_ACT(V_ACT), .V_FP(V_FP), .V_SYNC(V_SYNC), .V_BP(V_BP),
    // P0023 (VRAM-bandwidth stopgap): prefetch only the VISIBLE columns (H_ACT=410), not a full
    // 512-word VRAM row. The scanline loader refetched all 512 cols/line as burst-less single reads
    // (~6144 sys-clk) vs a ~6072-clk line budget -> 1.012x oversubscribed -> scanout owned the port
    // ~100% of every active line and starved the CPU's VRAM writes to the vblank sliver (~11% duty),
    // which is why the POST full-screen clears crawled. Smash T.V. shows cols 0..409 (yunit_video_smash_firefix.sv:27,
    // col = s0_x&0x1ff, s0_x<=409), so 410..511 were pure over-fetch. 410*12=4920 < 6072 -> fits in a
    // line with headroom. Real fix (burst) follows; this is the near-zero-risk direction-confirm.
    .DISP_ROW0(DISP_ROW0), .NCOL(H_ACT)
  ) u_video (
    .clk(clk), .rst(video_phase_rst), .ce_pix(ce_pix),
    .snoop_we(fb_snoop_we), .snoop_addr(fb_snoop_addr), .snoop_data(fb_snoop_data),
    .pal_raddr(pal_raddr), .pal_rdata(pal_rdata),
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
    .vid_r(vid_r), .vid_g(vid_g), .vid_b(vid_b),
    .hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank), .de(de),
    .vblank_irq(vblank_irq));

  // ---- palette mirror (video read port) --------------------------------------
  yunit_palram #(.AW(13)) u_pal (
    .clk(clk), .rst(core_rst),
    .we_a(palv_we_a), .aa(palv_aa), .awd(palv_awd),
    .we_b(palv_we_b), .ba(palv_ba), .bwd(palv_bwd),
    .raddr({1'b0, pal_raddr}), .rdata(pal_rdata));

  // ---- SDRAM arbiter + physical controller -----------------------------------
  logic [24:0] sd_addr; logic [15:0] sd_din, sd_dout; logic [1:0] sd_be; logic sd_rd, sd_wr, sd_ack;
  logic        iol_ack;

  // ioctl SDRAM-write path + HPS backpressure via a FIFO. hps_io does NOT gate its byte
  // stream on ioctl_wait — the ARM polls ioctl_wait (HPS_BUS[37]) and pauses with a ROUND-
  // TRIP LATENCY of many clks (bus + software). Meanwhile sdram_stock writes each ROM byte
  // slowly (ACTIVATE+WRITE+auto-precharge, ~12 clk). During that latency MANY bytes arrive:
  // a single latch (or a 1-deep skid) DROPS them — measured with +IOLSTRESS: 33% lost at
  // latency 2, 50% at 3, 72% at 6 -> Swiss-cheesed program ROM -> the CPU reads ~0 and
  // marches from 0 (the exact cab capture). So buffer the download in a FIFO deep enough to
  // absorb the HPS round-trip, and assert ioctl_wait at a high-water mark that leaves enough
  // headroom for the still-in-flight bytes. (+IOLSTRESS shows this FIFO loses 0 up to L~256.)
  localparam int IOL_AW  = 9;                       // 512-deep
  localparam int IOL_HWM = 256;                     // wait high-water mark (256 slots headroom)
  logic [42:0] iol_fifo [0:(1<<IOL_AW)-1];          // {addr[24:0], din[15:0], be[1:0]}
  logic [IOL_AW:0] iol_wp, iol_rp;
  wire  [IOL_AW:0] iol_occ   = iol_wp - iol_rp;
  wire             iol_full  = (iol_occ == (1<<IOL_AW));
  wire             iol_empty = (iol_wp == iol_rp);
  logic        iol_hold;
  logic        unp_owner;
  logic [24:0] iol_addr_r; logic [15:0] iol_din_r; logic [1:0] iol_be_r;
  // P0020 download audit: dbg_iol_drop counts pushes DROPPED on FIFO overflow (should be 0 if
  // ioctl_wait backpressure holds); dbg_iol_wrs counts pushes ACCEPTED (should reach the total
  // FIFO-bound download word count ~0xD0000). Displayed on the DIAG_BOOT overlay to prove/refute
  // "the program ROM reads 0 because the download drops words on real hps_io latency".
  logic [31:0] iol_drop_cnt, iol_wr_cnt;
  always_ff @(posedge clk) begin
    if (sdram_por) begin iol_wp <= '0; iol_rp <= '0; iol_hold <= 1'b0; iol_drop_cnt <= '0; iol_wr_cnt <= '0; end
    else begin
      // PUSH a download word (dropped only on true overflow — prevented by ioctl_wait)
      if (ioctl_wr && !iol_full) begin
        iol_fifo[iol_wp[IOL_AW-1:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
        iol_wp <= iol_wp + 1'b1;
        iol_wr_cnt <= iol_wr_cnt + 1'b1;                 // accepted push
      end
      else if (ioctl_wr && iol_full) iol_drop_cnt <= iol_drop_cnt + 1'b1;  // OVERFLOW DROP
      // DRAIN only while the FIFO owns the shared boot channel. The unpacker
      // holds ownership across its NXT bubbles; otherwise an iol_ack belonging
      // to an unpack request could retire a queued ROM word, or a queued ROM
      // request could replace the address beneath an in-flight unpack grant.
      // (Ported from the universal top, rtl/yunit/yunit_top.sv:669. This top's
      // single-stream ABI -- rom_download = ioctl_index 0 only,
      // smashtv_legacy_download_mapper.sv:41 -- means the download is always
      // fully drained before unp_start fires, so this is HARDENING here and
      // measurably cycle-identical on that stream; it is load-bearing for any
      // multi-stream download, which is how the family fork loses ROM words.)
      if (!unp_owner) begin
        if (iol_hold && iol_ack) iol_hold <= 1'b0;
        if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin
          {iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[IOL_AW-1:0]];
          iol_hold <= 1'b1;
          iol_rp   <= iol_rp + 1'b1;
        end
      end
    end
  end
  assign ioctl_wait = (iol_occ >= IOL_HWM[IOL_AW:0]);

  // gfx-unpack master (boot only). unp_rd/wr/addr/din come FROM the unpack FSM; its
  // dout/ack are driven from the shared boot iol channel below.
  logic        unp_rd, unp_wr, unp_ack;
  logic [24:0] unp_addr; logic [15:0] unp_din, unp_dout;

  // Boot SDRAM channel = ioctl download (write, via the iol_hold latch) MUXED WITH the
  // gfx-unpack (rd+wr). Ownership is held for the complete unpack SESSION, including
  // its request-free NXT bubbles (yunit_gfx_unpack.sv:53,123 -- NXT drives neither
  // unp_rd nor unp_wr), so an arbiter grant can never see its address/control bus
  // change owners before acknowledgement. Selecting on the combinational
  // (unp_rd | unp_wr) instead drops the mux back to the download every bubble.
  // Folding both boot users into the single iol channel keeps the run-time address
  // mux short.
  wire        b_iol_rd   = unp_owner ? unp_rd   : 1'b0;
  wire        b_iol_wr   = unp_owner ? unp_wr   : iol_hold;
  wire [24:0] b_iol_addr = unp_owner ? unp_addr : iol_addr_r;
  wire [15:0] b_iol_din  = unp_owner ? unp_din  : iol_din_r;
  wire [1:0]  b_iol_be   = unp_owner ? 2'b11    : iol_be_r;
  wire [15:0] iol_dout;
  assign unp_dout = iol_dout;
  assign unp_ack  = iol_ack & unp_owner & (unp_rd | unp_wr);

  yunit_sdram_arb #(
    .SD_AW(25), .GFXW_BASE(GFXW_BASE), .ROMW_BASE(ROMW_BASE),
    // The current wrapper reserves a larger universal-Y SDRAM aperture and
    // therefore passes GFX_BYTES=0x800000.  The firefix CPU read stream places
    // ROM immediately after Smash's real 0x180000-byte flat-gfx image; retain
    // that proven split while still accepting the wrapper parameter above.
    .VRAMW_BASE(VRAMW_BASE), .GFX_BYTES(24'h180000)
  ) u_arb (
    .clk(clk), .rst(sdram_por),                 // P0022: persistent SDRAM subsystem -> POR, not core rst
`ifdef USE_DDR3_VRAM
    // VRAM moved to DDR3 -> the SDRAM arbiter's VRAM channel is unused (this is the whole point:
    // SDRAM now serves only cgfx/prog-ROM/boot-IOL, so scanout no longer starves the CPU).
    .vsd_addr(25'd0), .vsd_din(16'd0), .vsd_be(2'd0), .vsd_rd(1'b0), .vsd_wr(1'b0),
    .vsd_dout(), .vsd_ack(),
`else
    .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr),
    .vsd_dout(vsd_dout), .vsd_ack(vsd_ack),
`endif
    .cgfx_rd(cgfx_rd), .cgfx_addr(cgfx_addr), .cgfx_data(cgfx_data), .cgfx_ack(cgfx_ack),
`ifdef USE_DDR3_VRAM
    // cont.24: blitter src is served by yunit_src_cache via the brd_* burst port -- the arb's
    // single-word src channel is bypassed (would double-drive src_data/src_ack if connected).
    .src_rd(1'b0), .src_addr(24'd0), .src_data(), .src_ack(),
`else
    .src_rd(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
`endif
    // Later universal-Y arbiter extension; disabled for the firefix CVSD path.
    .snd_rd(1'b0), .snd_addr(21'd0), .snd_data(), .snd_ack(),
    .iol_rd(b_iol_rd), .iol_wr(b_iol_wr), .iol_addr(b_iol_addr), .iol_din(b_iol_din),
    .iol_be(b_iol_be), .iol_dout(iol_dout), .iol_ack(iol_ack),
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
    .sd_dout(sd_dout), .sd_ack(sd_ack));

  // ---- gfx planar->flat unpack (boot only) -----------------------------------
  // Synth: run the pass once when the ROM download drops, holding the core (via
  // unp_done) until it completes. Sim: the tb preloads the flat gfx directly, so we
  // tie unp_done=1 and leave the unp channel idle (identical to the proven boot tb).
`ifdef SYNTHESIS
  logic dl_q, dl_seen, unp_pending, unp_start, unp_fsm_done, unp_done_q;
  always_ff @(posedge clk) begin
    dl_q      <= ioctl_download;
    unp_start <= 1'b0;
    unp_done_q <= unp_fsm_done;
    if (sdram_por) begin dl_seen <= 1'b0; unp_pending <= 1'b0; unp_owner <= 1'b0;
                       unp_done_q <= 1'b0; end
                                                                    // P0022: dl_seen must be SET during
                                                                    // download (rst is high then) -> POR
    else begin
      if (ioctl_download) dl_seen <= 1'b1;                 // a ROM download occurred
      if (dl_q & ~ioctl_download)      unp_pending <= 1'b1; // download just ended
      else if (unp_pending & ~iol_hold & ~unp_owner) begin // last iol write drained ->
        unp_pending <= 1'b0; unp_start <= 1'b1;             // fire the unpack (1-cyc pulse)
        unp_owner   <= 1'b1;                                // ACQUIRE the shared boot channel
      end


      // RELEASE on the COMPLETION EDGE, never on the level.  unp_fsm_done is a LEVEL
      // (yunit_gfx_unpack.sv:82, done = (st == FINI)) and it is ALREADY HIGH when a
      // re-arm acquires ownership out of FINI -- the title-switch path that
      // yunit_gfx_unpack.sv:125-142 exists to support (every Y-unit MRA names the same
      // rbf, so a title change is another ioctl download into the RUNNING core).  A
      // level release drops ownership one cycle after acquiring it: unp_ack is gated
      // off forever, the FSM stalls in RD0, unp_done never rises and core_rst is held
      // -- a black screen on every title change after the first.  Measured by
      // sim/probe/impl-tc-hi/tb_iol_ownership.sv (serial scenario, unpack pass 2).
      if (unp_owner && unp_fsm_done && !unp_done_q) unp_owner <= 1'b0;
    end
  end
  yunit_gfx_unpack #(
    .SD_AW(25), .SCRATCH_WBASE(SCRATCH_WBASE), .GFXW_BASE(GFXW_BASE),
    .PLANE_WORDS(PLANE_WORDS)
  ) u_unpack (
    // Explicitly select the legacy 3-plane/6bpp path added as the default/X
    // fallback by the later universal unpacker.
    .clk(clk), .rst(sdram_por), .start(unp_start),
    .plane_words(PLANE_WORDS), .bpp4(1'b0),
    .busy(), .done(unp_fsm_done),  // P0022: runs during the
                                                                                  // RESET-high post-download window
    .unp_rd(unp_rd), .unp_wr(unp_wr), .unp_addr(unp_addr), .unp_din(unp_din),
    .unp_dout(unp_dout), .unp_ack(unp_ack));
  // Only REQUIRE the unpack once a download has actually happened. With no download
  // (a soft reset that keeps the already-unpacked gfx in SDRAM, or a preloaded sim),
  // dl_seen=0 -> unp_done=1 so the CPU boots on the existing flat gfx.
  assign unp_done = ~dl_seen | unp_fsm_done;
`else
  assign unp_owner = 1'b0;
  assign unp_done = 1'b1;
  assign unp_rd = 1'b0; assign unp_wr = 1'b0; assign unp_addr = 25'd0; assign unp_din = 16'd0;
`endif

  // ---- P2 (cont.23) page-mode scanout row-cache (SDRAM path) ---------------------
  // Serves the video's scan_req from a per-scanline BRAM cache, burst-filling each row from SDRAM
  // in ONE ACTIVATE via sdram_stock's brd_* port (8% of the line budget, vs the single-beat
  // scanout's 76% oversubscription — P0023). Replaces vram_sdram_top's single-beat scanout (tied
  // off above). DDR3 build keeps its own row-cache in stv_vram_ddr_top -> brd_* tied off there.
  wire        brd_req;  wire [24:0] brd_addr;  wire [9:0] brd_len;
  wire [15:0] brd_dout;  wire brd_dvalid, brd_done;
`ifndef USE_DDR3_VRAM
 `ifdef USE_SDRAM_VRAM
  `ifdef SDRAM_SINGLEBEAT_SCANOUT
  assign brd_req = 1'b0; assign brd_addr = 25'd0; assign brd_len = 10'd0;   // ISOLATION: page-mode off
  `else
  vram_sdram_scanout #(.VRAM_WBASE(VRAMW_BASE)) u_scanout (
    .clk(clk), .rst(sdram_por),
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
    .brd_req(brd_req), .brd_addr(brd_addr), .brd_len(brd_len),
    .brd_dout(brd_dout), .brd_dvalid(brd_dvalid), .brd_done(brd_done));
  `endif
 `else
  // USE_HW_VRAM PROBE STUB: the BRAM framebuffer (yunit_mem_smash_firefix.vram) has no scanout READ port yet.
  // Feed the video a constant black pixel (scan_data=0, scan_ack=1) so it builds, and tie the SDRAM
  // page-mode burst port off. NOT a real scanout -- M10K-count probe only. No second BRAM port added.
  assign brd_req = 1'b0; assign brd_addr = 25'd0; assign brd_len = 10'd0;
  assign scan_data = 16'd0; assign scan_ack = 1'b1;
 `endif
`else
  // cont.24: DDR3 build -- the scanout row-cache lives in stv_vram_ddr_top, so the SDRAM
  // page-mode burst port is FREE. It now feeds the blitter SOURCE-READ streaming cache
  // (16-word ring, 8-word page-mode sub-bursts): readmode source bytes stream at ~3 clk/px
  // instead of one full lowest-priority single-word round trip per PIXEL -- the title-splash
  // "sprites missing / flashing in and out" root cause (DMAQ overflow cans the OBJLST tail;
  // NDSP1.ASM:646-648). The arb's src channel is bypassed entirely (tied off below).
  yunit_src_cache #(.GFXW_BASE(GFXW_BASE[23:0])) u_srccache (
    .clk(clk), .rst(core_rst),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .brd_req(brd_req), .brd_addr(brd_addr), .brd_len(brd_len),
    .brd_dout(brd_dout), .brd_dvalid(brd_dvalid), .brd_done(brd_done));
`endif

  // ---- stock SDRAM controller (Sorgelig) + arbiter adapter ----------------------
  // Replaces the hand-rolled sdram_phy. The stock controller forwards SDRAM_CLK via a DDIO
  // I/O cell (not a fabric assign) and uses the DE10-proven CAS-latency read capture — the
  // fix for reads landing in the wrong window on real silicon. The adapter bridges the
  // arbiter's held sd_rd/sd_wr/ack handshake to the controller's edge we/rd + `ready` level.
  // `init`=rst (level high during reset); the controller runs its power-up sequence when it
  // drops. sdram_ready comes from the adapter (latches the controller's first ready).
  logic [24:0] ctl_addr; logic [15:0] ctl_din, ctl_dout; logic [1:0] ctl_wtbt;
  logic        ctl_rd, ctl_we, ctl_ready;

  yunit_sdram_adapter u_sdadapt (
    .clk(clk), .rst(sdram_por),                 // P0022: persistent SDRAM subsystem -> POR, not core rst
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
    .sd_dout(sd_dout), .sd_ack(sd_ack), .sdram_ready(sdram_ready),
    .ctl_addr(ctl_addr), .ctl_din(ctl_din), .ctl_wtbt(ctl_wtbt),
    .ctl_rd(ctl_rd), .ctl_we(ctl_we), .ctl_dout(ctl_dout), .ctl_ready(ctl_ready));

  sdram_stock u_sdram (
    .init(sdram_por), .clk(clk),                // P0022: SDRAM inits once at true power-on, not core rst
    .addr(ctl_addr), .din(ctl_din), .wtbt(ctl_wtbt), .we(ctl_we), .rd(ctl_rd),
    .dout(ctl_dout), .ready(ctl_ready),
    .brd_req(brd_req), .brd_addr(brd_addr), .brd_len(brd_len),   // P2b page-mode scanout burst
    .brd_dout(brd_dout), .brd_dvalid(brd_dvalid), .brd_done(brd_done),
    // Later universal-Y page-mode write extension; the exact firefix source
    // cache is read-only on this SDRAM port.
    .bwr_req(1'b0), .bwr_addr(25'd0), .bwr_len(10'd0),
    .bwr_din(16'd0), .bwr_wtbt(2'b00), .bwr_valid(1'b0),
    .bwr_ready(), .bwr_done(),
    .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA),
    .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH),
    .SDRAM_nCS(SDRAM_nCS), .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nCAS(SDRAM_nCAS),
    .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE));

  // ---- sound-latch CDC: clk -> clk_snd ---------------------------------------
  // MAME passes D[9] as the PIA CB1 level and ~D[8] as the sound-CPU reset
  // (midyunit_m.cpp:650-663). The game emits close write pairs (FDxx->FFxx and
  // FE00->FFFF); a raw 2-FF level crossing can miss the intervening low/high
  // level entirely at 12 MHz. Stretch those active levels in clk_sys, then
  // synchronize them while preserving the board-visible CB1 protocol.
  logic [7:0] sel_sync;
  logic       strig_snd, srst_snd;
  yunit_sound_cdc u_sound_cdc (
    .clk_sys(clk), .clk_snd(clk_snd), .rst_pon(rst_pon),
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .sel_snd(sel_sync), .trig_snd(strig_snd), .reset_snd(srst_snd));

  logic [7:0]  pia_audio; logic [15:0] speech_out;
  logic signed [15:0] ym_l, ym_r; logic [31:0] snd_dbg;
  williams_cvsd_board u_board (
    .clock_12(clk_snd), .reset(srst_snd), .reset_pon(rst_pon),
    .sound_select(sel_sync), .sound_trig(strig_snd), .game_id(4'd0),
    .pia_audio(pia_audio), .speech_out(speech_out),
    .ym2151_left(ym_l), .ym2151_right(ym_r), .dbg_out(snd_dbg),
    // MRA sound-ROM load (ioctl clk domain -> board's dual-clock ROM BRAMs)
    .snd_dl_clk(clk), .snd_dl_addr(snd_dl_addr),
    .snd_dl_data(snd_dl_data), .snd_dl_we(snd_dl_wr),
    // Smash uses the three cabinet-proven 64 KiB CVSD BRAM images. The
    // current board also supports large CVSD sets from SDRAM, but that path
    // must remain disabled here.
    .use_ext_rom(1'b0), .ext_rom_addr(),
    .ext_rom_data(8'h00), .ext_rom_ok(1'b0));

  // ---- Williams CVSD-board mono mix -----------------------------------------
  // The real board and MAME device have one mono mixer. yunit_audio_mix sums
  // both YM outputs at x0.10 each, normalizes the unsigned MC1408 before x0.25,
  // applies CVSD x0.60 with DC removal, saturates, and duplicates mono to L/R.
  yunit_audio_mix u_audio_mix (
    .clk(clk_snd), .rst(rst_pon), .ym_l(ym_l), .ym_r(ym_r),
    .speech_u(speech_out), .pia_u(pia_audio), .audio_l(audio_l), .audio_r(audio_r));

  // ---- boot-instrument taps (DIAG_BOOT overlay reads these; harmless in normal build) ----
  assign dbg_core_rst    = core_rst;
  assign dbg_sdram_ready = sdram_ready;
  assign dbg_unp_done    = unp_done;
  assign dbg_cpu_req     = cpu_req;
  assign dbg_mem_ack     = mem_ack;
  assign dbg_int1        = int1;         // DMA-done interrupt to the CPU (blit-queue pump)
  assign dbg_vblank_irq  = vblank_irq;   // display/vblank interrupt (per-frame)
  // cont.24 splash-capture: blitter first-source byte + scanout stream (both are yunit_top_smash_firefix wires).
  assign dbg_src_data    = src_data;
  assign dbg_src_ack     = src_ack;
  assign dbg_scan_data   = scan_data;
  assign dbg_scan_ack    = scan_ack;
  assign dbg_cpu_ce      = cpu_ce;       // P0019: /4 CPU clock-enable pulse (liveness)
  assign dbg_iol_drop    = iol_drop_cnt; // P0020: download words dropped on FIFO overflow
  assign dbg_iol_wrs     = iol_wr_cnt;   // P0020: download words accepted into the FIFO

  // ---- family2-only instrument ports, tied off ----------------------------------------
  // Declared so this top matches the single port list the emu binds for every flavour (see
  // the port-list comments). None of these instruments exists in the recovery datapath, so
  // they are constant 0 and synthesis prunes them; `autoerase_off` is intentionally unread.
  assign dbg_disp_flips  = 32'd0;
  assign dbg_disp_rows   = 32'd0;
  assign dbg_cgfx_grants = 16'd0;
  assign dbg_snd_grants  = 16'd0;
  assign dbg_cgfx_maxwait= 32'd0;
  assign dbg_snd_miss    = 16'd0;
  assign dbg_snd_busy16  = 16'd0;
  assign dbg_cvsd_moves  = 16'd0;
  assign dbg_adpcm_moves = 16'd0;
  assign dbg_blank_pix   = 16'd0;
  assign dbg_cpu_pc_moves= 32'd0;
  assign dbg_snd_acks    = 32'd0;
  assign dbg_snd_first_words = 32'd0;
  assign dbg_snd_region_seen = 1'b0;
  assign dbg_snd_board_rst   = 1'b0;
  assign dbg_restart_cnt = 16'd0;

  // ---- COMBINED reset-vector + derail capture (clk + cpu_ce, i.e. the CPU's step) -------
  // After the FIFO download fix, answer BOTH questions in one flash. Overlay 4 hex rows:
  //   row1 dbg_culprit_pc    = RESET-VECTOR VALUE the CPU read (first ack'd read).
  //                            FFE0F5C0 => ROM finally LANDED + CPU reads it (download fixed);
  //                            0000/garbage => ROM still not reaching the CPU (download or read).
  //   row2 dbg_culprit_instr = derail CULPRIT PC[15:0] (last valid code PC before it jumped)
  //   row3 dbg_derail_pc     = derail TARGET (where PC jumped OUT of the R_ROM code region)
  //   row4 (overlay live PC) = where the CPU is NOW
  //   status: GREEN = running / not derailed (if PC advances in-region, CPU runs -> video bug);
  //           RED   = derailed (rows 2/3 show the death site).
  logic [1:0]  rd_cnt;
  logic        ack_q;
  logic        d_started;
  logic [31:0] d_prevpc;
  always_ff @(posedge clk) if (cpu_ce) begin
    if (core_rst_sys) begin
      dbg_derailed<=1'b0; rd_cnt<=2'd0; ack_q<=1'b0; d_started<=1'b0; d_prevpc<=32'hFFFFFFFF;
      dbg_culprit_pc<=32'hDEADBEEF; dbg_culprit_instr<=16'h0000; dbg_derail_pc<=32'hDEADBEEF;
    end else begin
      // (A) RESET-VECTOR value = the FIRST ack'd read (row1: did the ROM land?)
      ack_q <= cpu_ack;
      if (cpu_ack && !ack_q && !cpu_we && rd_cnt==2'd0) begin
        dbg_culprit_pc <= cpu_rdata; rd_cnt <= 2'd1;
      end
      // (B) DERAIL: freeze the first time PC leaves the R_ROM code region (pc[31:23]==9'h1FF)
      if (pc_dbg !== d_prevpc) begin
        // (C) WARM-RESTART SOURCE CAPTURE (names the loop mechanism). FFE0F5C0 is the
        // warm-restart vector. The watchdog jumps here from FFE0E9E0 (JANC, frame-count>=200,
        // MAME dasm). If the jump SOURCE (d_prevpc, still the pre-transition PC this cycle) is
        // FFE0E9E0 -> watchdog/starvation confirmed. ANY OTHER source names a different cause
        // (CALLERR process-error, or a wild jump) -> explains why every watchdog-assumption fix
        // failed. This restart is IN-region so (B)'s leave-region derail never catches it.
        if (pc_dbg == 32'hFFE0F5C0) begin
          dbg_derail_pc     <= d_prevpc;                   // row3: WHO jumped to the restart
          dbg_culprit_instr <= dbg_culprit_instr + 16'd1;  // row2: restart COUNT (climbs = looping)
        end
        d_prevpc <= pc_dbg;
        if (pc_dbg[31:23]==9'h1FF) d_started <= 1'b1;
      end
    end
  end
endmodule
`default_nettype wire
