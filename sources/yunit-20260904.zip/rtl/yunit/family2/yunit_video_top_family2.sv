// yunit_video_top_family2.sv — Phase 6 W3: video subsystem. Combines yunit_video_family2 (VRAM word ->
// pen_map6 -> palette -> RGB, external raster) with yunit_scanline_family2 (double-buffered VRAM
// line fetch over the SDRAM scan_* channel). yunit_video_family2 is UNCHANGED — the line-buffer
// transparently serves its per-pixel 1-clk VRAM read from SDRAM. The palette read port
// (pal_raddr/pal_rdata) passes through to a palette BRAM the emu provides.
`timescale 1ns/1ps
`default_nettype none
module yunit_video_top_family2
  import yunit_pkg::*;
#(
  parameter int H_ACT=410, H_FP=6, H_SYNC=40, H_BP=50,
  parameter int V_ACT=256, V_FP=13, V_SYNC=8, V_BP=12,
  parameter int DISP_ROW0=0,
  parameter int NCOL=512
)(
  input  logic        clk,
  input  logic        rst,
  input  logic        ce_pix,
  input  logic        bpp4,         // runtime profile pen map (family2 P1)
  // Live display base (page flip). See the census in yunit_top_family2:
  // 7 of 8 Y-unit titles move DPYSTRT every frame; DISP_ROW0 is only the
  // reset default now. Drives BOTH the pixel address and the prefetcher --
  // they must agree or the loader primes a different page than scanout reads.
  // COMBINATIONAL next display base. It is latched HERE, once per frame, so the
  // pixel address and the line prefetcher cannot disagree.
  //
  // The first version of this fix latched the base in yunit_top_family2 off
  // `vblank` (s3) while the prefetcher primes off `vblank_raw` (s0), three pixel
  // stages EARLIER. The prefetcher therefore filled its line buffers from the
  // OLD page while the pixel address asked for the NEW one -- every frame, for
  // any title that actually flips. Smash T.V. was unaffected (delta always 0, so
  // old == new) which is exactly what the cabinet reported: control fine, High
  // Impact still flashing.
  input  logic [8:0]  disp_row_next,
  // Runtime visible width from the CRTC (HSBLNK-HEBLNK)*2. Passed straight
  // through to the pixel stage; the prefetcher still fills NCOL columns, so
  // this only blanks what is painted, never what is fetched.
  input  logic [11:0] visible_px,
  // DPYCTL bit 15 (ENV): low = the game asked for a blank scanline
  input  logic        disp_enable,
  // Accepted DMA framebuffer write-through for prefetched-line coherency.
  input  logic        snoop_we,
  input  logic [17:0] snoop_addr,
  input  logic [15:0] snoop_data,
  // palette read (to the emu's palette BRAM; 1-clk registered)
  output logic [11:0] pal_raddr,
  input  logic [15:0] pal_rdata,
  // SDRAM scanout read channel (to yunit_sdram_arb / vram_sdram_top)
  output logic        scan_req,
  output logic [17:0] scan_addr,
  input  logic [15:0] scan_data,
  input  logic        scan_ack,
  // video output
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de,
  output logic        vblank_irq
);
  // yunit_video_family2 <-> yunit_scanline_family2 VRAM read
  logic [FB_ADDR_W-1:0] vram_raddr; logic [15:0] vram_rdata;
  logic vblank_i, vblank_scan;

  // One latch, one edge, both consumers. vblank_scan is the s0 flag the
  // prefetcher uses, so the base is settled for the frame being primed.
  logic [8:0] disp_row_q;
  logic       vbl_scan_q;
  always_ff @(posedge clk) begin
    if (rst) begin
      disp_row_q <= 9'd0;
      vbl_scan_q <= 1'b0;
    end else begin
`ifdef MUT_BASE_LATCH_SKEW
      // MUTANT: reproduce the shipped defect exactly -- latch the pixel-path
      // base off the DELAYED vblank (s3) while the prefetcher primes off the
      // raw one (s0). Cabinet symptom: Smash fine, High Impact still flashing.
      vbl_scan_q <= vblank_i;
      if (vblank_i && !vbl_scan_q) disp_row_q <= disp_row_next;
`else
      vbl_scan_q <= vblank_scan;
      if (vblank_scan && !vbl_scan_q) disp_row_q <= disp_row_next;
`endif
    end
  end

  yunit_video_family2 #(
    .H_ACT(H_ACT), .H_FP(H_FP), .H_SYNC(H_SYNC), .H_BP(H_BP),
    .V_ACT(V_ACT), .V_FP(V_FP), .V_SYNC(V_SYNC), .V_BP(V_BP), .DISP_ROW0(DISP_ROW0)
  ) u_video (
    .clk(clk), .rst(rst), .ce_pix(ce_pix), .bpp4(bpp4),
    .disp_row_dyn(disp_row_q),
    .visible_px(visible_px),
    .disp_enable(disp_enable),
    .vram_raddr(vram_raddr), .vram_rdata(vram_rdata),
    .pal_raddr(pal_raddr), .pal_rdata(pal_rdata),
    .vid_r(vid_r), .vid_g(vid_g), .vid_b(vid_b),
    .hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank_i), .de(de),
    .vblank_raw(vblank_scan),
    .vblank_irq(vblank_irq));
  assign vblank = vblank_i;

`ifdef MUT_SCANLINE_DELAYED_VBLANK
  wire scanline_vblank = vblank_i;
`else
  // vram_raddr is stage 0, so line-buffer freeze/ownership must be stage 0 too.
  // vblank_i is intentionally three ce_pix stages late for RGB alignment.
  wire scanline_vblank = vblank_scan;
`endif

  yunit_scanline_family2 #(.FB_ADDR_W(FB_ADDR_W), .NCOL(NCOL), .FIRST_ROW(DISP_ROW0)) u_scan (
    .clk(clk), .rst(rst), .ce_pix(ce_pix), .vblank(scanline_vblank),
    .first_row_dyn(disp_row_next),
    .vram_raddr(vram_raddr), .vram_rdata(vram_rdata),
    .snoop_we(snoop_we), .snoop_addr(snoop_addr), .snoop_data(snoop_data),
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack));
endmodule
`default_nettype wire

