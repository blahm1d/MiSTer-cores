// family2 runtime control mapper -- P1.3 port of the PROVEN family
// yunit_input_mapper under the family2 name (PLAN-family2-rebase.md).
// Gated by tb_family2_inputs: cycle-lockstep against the family mapper for
// all ten profiles, AND game-side-ABI equivalence against the FROZEN
// smashtv_cabinet_inputs for profile 0 under the controller-bit remap. Three deliberate additive
// deltas vs the recovery module, all operator-facing and all inactive when
// the extra buttons are unpressed and test mode is off: coin 3, Smash
// service credit (Button 5), and the test-mode Start mirror.
`default_nettype none
module family2_cabinet_inputs
  import yunit_pkg::*;
(
  input  logic [3:0]  game_id,
  input  logic [15:0] joy0, joy1, joy2, joy3,
  input  logic [15:0] dsw_raw,
  input  logic        adpcm_irq,
  output logic [63:0] inputs
);
  logic [15:0] in0, in1, in2, dsw;
  logic test_mode;
  logic [3:0] start_bit, coin_bit;

  // DIRECTIONS ARE WRITTEN FLAT, ON PURPOSE -- DO NOT REINTRODUCE A TASK.
  //
  // This module previously used `task automatic map_dirs(..., inout logic
  // [15:0] dst)`.  SystemVerilog `inout` task arguments are copy-in/copy-out,
  // so read-modify-write of a shared vector is correct in the .sv source, and
  // every iverilog/Questa bench passed.  But Quartus reads the sv2v-converted
  // Verilog, and sv2v lowers `inout` to a plain Verilog `output` -- which is
  // copy-OUT ONLY.  The copy-in vanished, so each call started from X and wrote
  // back all 16 bits, meaning the SECOND call in a branch clobbered the FIRST
  // call's nibble.  On the cabinet that stuck P1's direction bits (Smash walked
  // to the bottom-left) and, in the Trog/HIF/SHI/Test branch, wiped in1[10:0]
  // -- COIN1/START1/START2/SERVICE/TILT -- and in2.  Fire survived only because
  // it is assigned after the task calls.
  //
  // MiSTer joystick convention is R,L,D,U in bits 0..3; the game side wants
  // U,D,L,R ascending, matching the cabinet-proven smashtv_cabinet_inputs.

  always_comb begin
    in0 = 16'hffff; in1 = 16'hffff; in2 = 16'hffff;
    dsw = dsw_raw;
    test_mode = yunit_test_mode(game_id, dsw_raw);
`ifdef MUT_F2_START_FIXED_10
    // MUTANT: restore the failed padded-six-button ABI for every title.
    start_bit = 4'd10;
    coin_bit  = 4'd11;
`else
    start_bit = yunit_start_bit(game_id);
    coin_bit  = yunit_coin_bit(game_id);
`endif

    // Common cabinet inputs.
    in1[0]=~joy0[coin_bit]; in1[1]=~joy1[coin_bit];
    // Most Y-unit diagnostic menus use Start1/Start2/Service as their BUTTONS
    // mask, so their first action is mirrored onto Start while Test is active.
    // T2 is the exception documented by its operator manual: P1 Start moves
    // up, P2 Start moves down, and either gun Trigger selects.  Mirroring T2's
    // Trigger onto Start therefore performs two operations at once.  Give a
    // one-pad operator explicit D-pad Up/Down aliases instead while preserving
    // both cabinets' native Start buttons.
    in1[2]=~(joy0[start_bit]
             | (test_mode && ((game_id == YG_TERM2)
                              ? (joy0[3] | joy1[3]) : joy0[4])));
    in1[5]=~(joy1[start_bit]
             | (test_mode && ((game_id == YG_TERM2)
                              ? (joy0[2] | joy1[2]) : joy1[4])));
    // Only Smash exposes Service Credit as a named fifth action. Mapping a
    // nominal "free" bit for every title aliases real per-title controls: for
    // Total Carnage joy0[8] is Start, so the old common mapping pressed Start
    // and Service together and the game returned to attract.
    if (game_id == YG_SMASHTV) in1[6]=~joy0[8];

    case (game_id)
      YG_SMASHTV, YG_TOTCARN: begin
        in0[0]=~joy0[3]; in0[1]=~joy0[2]; in0[2]=~joy0[1]; in0[3]=~joy0[0];
        in0[8]=~joy1[3]; in0[9]=~joy1[2]; in0[10]=~joy1[1]; in0[11]=~joy1[0];
        in0[4]=~joy0[4]; in0[5]=~joy0[5]; in0[6]=~joy0[6]; in0[7]=~joy0[7];
        in0[12]=~joy1[4]; in0[13]=~joy1[5]; in0[14]=~joy1[6]; in0[15]=~joy1[7];
        in1[9]=~joy2[coin_bit]; // coin 3
        // SERVICE1 / IN1[6] is now wired for the whole family in the common
        // block above, on the same joy0[8] the cabinet-good Smash MRA used.
        // SHIPPING FIRE FIX, half 1 of 2 (cab-confirmed). This core has no rotary
        // encoder, so DS2:2 must read Off or the game selects rotary fire decode.
        // Half 2 is structural rather than conditional: this module has NO analog
        // port at all, so the analog right stick cannot reach the fire nibble.
        // That mattered because the cabinet's idle right-stick Y measured +119,
        // well past the +48 deadzone the old guard used, which pinned the analog
        // "fire down" bit permanently on -- FIRE_DIRECTION (SHOTS.ASM:892) then
        // scored bit5 = +2 = DOWN and nothing else, i.e. "only fires downwards".
        // The mutant restores the pre-fix rotary DIP so tb_yunit_profiles proves
        // this line is load-bearing rather than decorative.
        if (game_id == YG_SMASHTV)
`ifdef MUT_F2_SMASHTV_ROTARY_ON
          dsw = dsw_raw;                    // MUTANT: unsupported rotary mode ON
`else
          dsw = dsw_raw | 16'h4000; // unsupported rotary mode must remain off
`endif
        if (game_id == YG_TOTCARN) in1[14] = ~adpcm_irq;
      end

      YG_TROG, YG_HIIMPACT, YG_SHIMPACT, YG_YUNITTST: begin
        in0[0]=~joy0[3]; in0[1]=~joy0[2]; in0[2]=~joy0[1]; in0[3]=~joy0[0];
        in0[8]=~joy1[3]; in0[9]=~joy1[2]; in0[10]=~joy1[1]; in0[11]=~joy1[0];
        in0[4]=~joy0[4]; in0[12]=~joy1[4];
        in1[9]=~joy2[start_bit]; in1[10]=~joy3[start_bit];
        in1[11]=~joy2[3]; in1[12]=~joy2[2]; in1[13]=~joy2[1]; in1[14]=~joy2[0];
        in1[15]=~joy2[4];
        in2[0]=~joy3[3]; in2[1]=~joy3[2]; in2[2]=~joy3[1]; in2[3]=~joy3[0];
        in2[4]=~joy3[4];
        if (game_id == YG_TROG) in2[5]=~joy2[coin_bit];
        else begin in1[7]=~joy2[coin_bit]; in2[5]=~joy3[coin_bit]; end
      end

      YG_STRKFORC, YG_SAURNFRNT: begin
        in0[0]=~joy0[3]; in0[1]=~joy0[2]; in0[2]=~joy0[1]; in0[3]=~joy0[0];
        in0[8]=~joy1[3]; in0[9]=~joy1[2]; in0[10]=~joy1[1]; in0[11]=~joy1[0];
        in0[4]=~joy0[4]; in0[5]=~joy0[5]; in0[6]=~joy0[6];
        in0[12]=~joy1[4]; in0[13]=~joy1[5]; in0[14]=~joy1[6];
        in1[7]=~joy2[coin_bit]; in1[9]=~joy3[coin_bit];
      end

      YG_MK: begin
        in0[0]=~joy0[3]; in0[1]=~joy0[2]; in0[2]=~joy0[1]; in0[3]=~joy0[0];
        in0[8]=~joy1[3]; in0[9]=~joy1[2]; in0[10]=~joy1[1]; in0[11]=~joy1[0];
        // HP, LP, Block, HK, LK, Block2 are MiSTer buttons 4..9.
        in0[4]=~joy0[4]; in0[5]=~joy0[6]; in0[6]=~joy0[7];
        in0[12]=~joy1[4]; in0[13]=~joy1[6]; in0[14]=~joy1[7];
        in1[8]=~joy2[coin_bit]; // MAME mkla4 IN1 bit 8: coin 3
        in1[9]=~joy1[5]; in1[10]=~joy1[8]; in1[11]=~joy1[9];
        in1[12]=~joy0[5]; in1[13]=~joy0[8]; in1[14]=~adpcm_irq; in1[15]=~joy0[9];
      end

      YG_TERM2: begin
        // P2's trigger/bomb also live on pad 0's dedicated buttons 6/7,
        // pairing with the P2-gun-on-right-stick mix in the emu so one pad can
        // complete two-gun calibration.  These are real named actions now;
        // Start/Coin follow on 8/9 and can no longer fire gun 2 accidentally.
        in0[4]=~joy0[4]; in0[5]=~joy0[5];
        in0[12]=~(joy1[4]|joy0[6]); in0[13]=~(joy1[5]|joy0[7]);
        in1[7]=~joy2[coin_bit]; in1[9]=~joy3[coin_bit]; in1[14]=~adpcm_irq;
      end

      default: ;
    endcase
    inputs = {dsw, in2, in1, in0};
  end
endmodule
`default_nettype wire
