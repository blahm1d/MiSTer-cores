// family2 MRA byte streams -> Y-unit SDRAM/sound download transactions.
//
// P1.2 (PLAN-family2-rebase.md): this is the family MULTI-STREAM layout, a
// port of the proven yunit_download_mapper semantics under the family2 name:
//
//   ioctl_index 0 : raw graphics planes, byte pairs packed to 16-bit words at
//                   SCRATCH_WBASE (the unpack pass consumes them from SDRAM)
//   ioctl_index 1 : program ROM, TWO 0x80000-byte lanes -> opposite byte
//                   enables of the same TMS34010 word at ROMW_BASE
//                   (first half U105 low lane be=01, second half U89 high
//                   lane be=10 -- the deterministic on-chip interleave)
//   ioctl_index 2 : sound ROM, packed pairs to SOUNDW_BASE for SDRAM-backed
//                   boards AND streamed byte-wise to the small-CVSD BRAMs
//   ioctl_index 3 : byte 0 = the runtime board profile (game_id)
//
// The coherent triple is family MRAs + THIS mapper + the family physical map
// passed as the family2 emu parameters.  Mixing any leg of it with the legacy
// single-stream Smash layout is exactly section-3 failure #4 of
// HANDOFF-yunit-smash-recovery-2026-07-29.md -- do not.
//
// This module intentionally has no game-reset input: ROM download must remain
// live while the framework holds the emulated board in reset.
`timescale 1ns/1ps
`default_nettype none

module family2_download_mapper #(
  parameter [24:0] DL_ROMHI_BASE = 25'h080000,
  parameter [24:0] SCRATCH_WBASE = 25'h500000,
  parameter [24:0] ROMW_BASE     = 25'h400000,
  parameter [24:0] SOUNDW_BASE   = 25'h800000
) (
  input  wire        clk,
  input  wire        ioctl_download,
  input  wire        ioctl_wr,
  input  wire  [7:0] ioctl_index,
  input  wire [24:0] ioctl_addr,
  input  wire  [7:0] ioctl_dout,

  output reg   [3:0] game_id,
  output wire        gfx_download,
  output wire        rom_download,

  output reg         mapped_wr,
  output reg  [24:0] mapped_addr,
  output reg  [15:0] mapped_dout,
  output reg   [1:0] mapped_be,

  output reg         snd_wr,
  output reg  [17:0] snd_addr,
  output reg   [7:0] snd_data
);
  initial game_id = 4'd0;

  wire prog_download = ioctl_download && (ioctl_index == 8'd1);
  wire snd_download  = ioctl_download && (ioctl_index == 8'd2);

`ifdef MUT_SNDADDR_TRUNC18
  // MUTANT (gate discrimination only): the shipped 2026-08-19 behaviour --
  // every index-2 byte rides the byte tap and the 18-bit alias clobbers the
  // ADPCM fixbank. tb_adpcm_fixbank_seam MUST die on this.
  wire adpcm_snd_tap_ok = 1'b1;
`else
  // ADPCM byte-tap qualifier: U3 CPU-ROM region only (< 25'h40000). See the
  // comment at the snd_download block below.
  wire adpcm_snd_tap_ok = (ioctl_addr[24:18] == 7'd0);
`endif
  assign gfx_download = ioctl_download && (ioctl_index == 8'd0);
  assign rom_download = gfx_download || prog_download || snd_download;

  reg [7:0] pair_lo;

  always @(posedge clk) begin
    mapped_wr <= 1'b0;
    snd_wr    <= 1'b0;

    if (ioctl_download && ioctl_wr &&
        (ioctl_index == 8'd3) && (ioctl_addr == 25'd0))
      game_id <= ioctl_dout[3:0];

    if (ioctl_wr) begin
      if (gfx_download) begin
        if (!ioctl_addr[0])
          pair_lo <= ioctl_dout;
        else begin
          mapped_addr <= SCRATCH_WBASE + {1'b0, ioctl_addr[24:1]};
          mapped_dout <= {ioctl_dout, pair_lo};
          mapped_be   <= 2'b11;
          mapped_wr   <= 1'b1;
        end
      end
      else if (prog_download && (ioctl_addr < DL_ROMHI_BASE)) begin
        // MRA index 1 first half: U105, low byte of each TMS word.
        mapped_addr <= ROMW_BASE + ioctl_addr;
        mapped_dout <= {8'h00, ioctl_dout};
        mapped_be   <= 2'b01;
        mapped_wr   <= 1'b1;
      end
      else if (prog_download) begin
        // MRA index 1 second half: U89, high byte of the same TMS word.
        mapped_addr <= ROMW_BASE + (ioctl_addr - DL_ROMHI_BASE);
        mapped_dout <= {ioctl_dout, 8'h00};
        mapped_be   <= 2'b10;
        mapped_wr   <= 1'b1;
      end
      else if (snd_download) begin
        if (!ioctl_addr[0])
          pair_lo <= ioctl_dout;
        else begin
          mapped_addr <= SOUNDW_BASE + {1'b0, ioctl_addr[24:1]};
          mapped_dout <= {ioctl_dout, pair_lo};
          mapped_be   <= 2'b11;
          mapped_wr   <= 1'b1;
        end
      end
    end

    // Small CVSD profiles also consume every canonical sound byte directly.
    //
    // ADPCM titles: ONLY the U3 CPU-ROM region (index-2 bytes 0x00000-0x3FFFF)
    // goes out on this byte tap -- its sole ADPCM consumer is the board's 16 KiB
    // fixed-bank BRAM, filled by decode snd_dl_addr[17:14]==4'hF (the U3 tail
    // 0x3C000-0x3FFFF = 6809 0xC000-0xFFFF vectors/FIRQ/driver). The OKI sample
    // region (0x40000-0x13FFFF) is served from SDRAM via SOUNDW_BASE above and
    // must NEVER ride this tap: snd_addr is 18 bits, so the 1.25 MB stream
    // aliases 5x onto the fixbank decode (0x3C000 correct, then 0x7C000/0xBC000/
    // 0xFC000/0x13C000 = OKI data) and the LAST write wins -- the 6809's reset
    // vector became sample bytes: dead board, MK/TC silent, T2 hung at the
    // post-CMOS sound check (cab 2026-08-19, RBF 3240c43). Replaying the real MK
    // stream through this exact decode measured 81,920 writes into the 16,384-
    // byte bank. The 2026-08-19 "raw 18-bit" form AND the CVSD compaction before
    // it both delivered bit-identical garbage (four aliased OKI windows each).
    // Gate: tb_adpcm_fixbank_seam (mapper->board seam, full-length stream).
    if (snd_download && ioctl_wr) begin
      if (yunit_pkg::yunit_sound_type(game_id) == yunit_pkg::YS_ADPCM) begin
        snd_addr <= ioctl_addr[17:0];
        snd_data <= ioctl_dout;
        snd_wr   <= adpcm_snd_tap_ok;
      end else begin
        snd_addr <= {ioctl_addr[18:17], ioctl_addr[15:0]};
        snd_data <= ioctl_dout;
        snd_wr   <= 1'b1;
      end
    end
  end

endmodule

`default_nettype wire
