// yunit_audio_mix.sv -- Williams CVSD-board mono mixer and source normalization.
//
// MAME's williams_cvsd_sound_device is a mono device_mixer_interface. Normalize
// the FPGA source formats, sum once, then duplicate the board's mono result to
// L/R. Cabinet validation found JT51's nominal x0.10 routes about 6 dB too low
// against the decoder/DAC sources, so they are compensated to x0.20 here. CVSD
// and MC1408 retain their foreground/midground x0.60 and x0.25 priorities.
`timescale 1ns/1ps
`default_nettype none
module yunit_audio_mix (
  input  logic               clk,
  input  logic               rst,
  input  logic signed [15:0] ym_l,
  input  logic signed [15:0] ym_r,
  input  logic        [15:0] speech_u,
  input  logic         [7:0] pia_u,
  output logic signed [15:0] audio_l,
  output logic signed [15:0] audio_r
);
  // The HC55564 model emits an unsigned integrator value whose resting centre
  // follows the encoded speech. Track only its sub-audio DC and subtract it.
  logic signed [24:0] cvsd_dc;
  wire  signed [16:0] cvsd_x = $signed({1'b0, speech_u});
  always_ff @(posedge clk) begin
    if (rst)
      cvsd_dc <= 25'sd0;
    else
      cvsd_dc <= cvsd_dc + (($signed({cvsd_x, 8'd0}) - cvsd_dc) >>> 18);
  end
  wire signed [17:0] speech_ac = $signed({cvsd_x[16], cvsd_x}) - $signed(cvsd_dc[24:8]);
  wire signed [15:0] speech_s  = (speech_ac >  18'sd32767) ?  16'sd32767 :
                                 (speech_ac < -18'sd32768) ? -16'sd32768 : speech_ac[15:0];

`ifdef MUT_AUDIO_OLD_ROUTING
  // Discriminating mutation: the former stereo split and signed-8 x64 DAC
  // conversion. tb_audio_mix must reject both format/routing mistakes.
  wire signed [16:0] ym_mix_l = $signed(ym_l);
  wire signed [16:0] ym_mix_r = $signed(ym_r);
  wire signed [16:0] pia_s = $signed({{8{pia_u[7]}}, pia_u}) <<< 6;
`else
  // The physical board is mono: both YM outputs feed the same mixer.
  wire signed [16:0] ym_mono = $signed({ym_l[15], ym_l}) + $signed({ym_r[15], ym_r});
  wire signed [16:0] ym_mix_l = ym_mono;
  wire signed [16:0] ym_mix_r = ym_mono;
  // MAME's MC1408 uses dac_mapper_unsigned with the default -1..+1 range.
  // Convert 0..255 to approximately -32768..+32767 before applying x0.25.
  wire signed [16:0] pia_s = ($signed({1'b0, pia_u}) - 17'sd128) <<< 8;
`endif

  // ---- MAME-exact gains (mixer-gain audit, 2026-08-18) ----------------------
  // williamssound.cpp:200-205: YM 0.10/output, MC1408 0.25, HC55516 route 0.60.
  // CRITICAL: MAME's HC55516 also applies an INTERNAL SAMPLE_GAIN of
  // 10000/32768 = 0.305 (hc55516.cpp:38,487) before that route -- its CVSD
  // stream never exceeds ~0.3 of full scale. Our decoder swings the full
  // 16 bits, so the old x0.60 coefficient ran the crowd channel 3.3x (10 dB)
  // HOT: High Impact / Super HI "crowd washes out all the other samples", and
  // the same excess is why the YM once measured "6 dB too low" on the cabinet
  // and got compensated to x0.20 -- the YM was right, the crowd was hot. With
  // the CVSD term corrected the YM returns to MAME's own 0.10 per output,
  // consistent with the ADPCM board's (cabinet-consistent) 26/256.
  //   YM   : 0.10            -> 26/256
  //   CVSD : 0.60 x 0.305    -> 47/256
  //   DAC  : 0.25            -> 64/256
`ifdef MUT_AUDIO_YM_020
  localparam signed [31:0] YM_COEFF = 32'sd52; // the retired hot-crowd-era compensation
`else
  localparam signed [31:0] YM_COEFF = 32'sd26; // MAME x0.10 per YM output
`endif
`ifdef MUT_AUDIO_HOT_CVSD
  localparam signed [31:0] CVSD_COEFF = 32'sd154; // the 3.3x-hot pre-audit value
`else
  localparam signed [31:0] CVSD_COEFF = 32'sd47;  // 0.60 route x 0.305 SAMPLE_GAIN
`endif
  wire signed [31:0] ym_term_l = ($signed(ym_mix_l) * YM_COEFF) >>> 8;
  wire signed [31:0] ym_term_r = ($signed(ym_mix_r) * YM_COEFF) >>> 8;
  wire signed [31:0] cvsd_term = ($signed(speech_s) * CVSD_COEFF) >>> 8;
  wire signed [31:0] pia_term  = ($signed(pia_s)    * 32'sd64)  >>> 8; // MC1408 x0.25
  wire signed [31:0] mix_l = ym_term_l + cvsd_term + pia_term;
  wire signed [31:0] mix_r = ym_term_r + cvsd_term + pia_term;

  always_ff @(posedge clk) begin
    if (rst) begin
      audio_l <= 16'sd0;
      audio_r <= 16'sd0;
    end else begin
      audio_l <= (mix_l >  32'sd32767) ?  16'sd32767 :
                 (mix_l < -32'sd32768) ? -16'sd32768 : mix_l[15:0];
      audio_r <= (mix_r >  32'sd32767) ?  16'sd32767 :
                 (mix_r < -32'sd32768) ? -16'sd32768 : mix_r[15:0];
    end
  end
endmodule
`default_nettype wire
