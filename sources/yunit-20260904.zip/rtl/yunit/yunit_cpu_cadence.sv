// Profile-owned TMS34010 architectural-cycle target plus RTL microstep clock.
//
// MAME models Y-unit TMS34010 master clocks at 40, 48, or 50 MHz. The device
// converts eight master clocks to one execution cycle, giving exactly
// 5.0, 6.0, or 6.25 MHz. With the MiSTer core clock at 96 MHz, a denominator of
// 384 gives exact integer phase steps:
//   5.00 / 96 = 20 / 384
//   6.00 / 96 = 24 / 384
//   6.25 / 96 = 25 / 384
//
// IMPORTANT: tms34010_core is a multi-state implementation. ce_micro advances
// one implementation state; it is NOT one TMS34010 architectural cycle.
// ce_micro is an exact 25/96 MHz phase enable: fast enough for the 50 MHz
// board's 6.25 MHz one-cycle instruction stream (four microsteps/instruction).
// arch_cycle is the exact profile target consumed by the retirement scheduler.
// Neither output is user tunable.
`default_nettype none

module yunit_cpu_cadence
  import yunit_pkg::*;
(
  input  logic       clk,
  input  logic       rst,
  input  logic [3:0] game,
  output logic       ce_micro,
  output logic       arch_cycle,
  output logic [5:0] arch_step
);
  localparam logic [9:0] PHASE_DEN = 10'd384;

  // Preserve the timing boundary: ce_micro_q is intentionally redundant with
  // the legacy current-phase wrap expression at sampling edges.
  (* preserve *) logic ce_micro_q;
  logic [8:0] phase;
  logic [9:0] phase_sum;
  logic [8:0] micro_phase;
  logic [9:0] micro_sum;
  logic [8:0] micro_phase_next;
  logic [9:0] micro_sum_next;
  logic       micro_wrap;
  logic       micro_tick_next;

  always_comb begin
    case (yunit_clock_class(game))
      YC_FAST:   arch_step = 6'd24; // 48 MHz / 8 = 6.00 MHz
      YC_FASTER: arch_step = 6'd25; // 50 MHz / 8 = 6.25 MHz
      default:   arch_step = 6'd20; // 40 MHz / 8 = 5.00 MHz
    endcase
  end

  assign phase_sum = {1'b0, phase} + {4'b0000, arch_step};
  assign micro_sum = {1'b0, micro_phase} + 10'd100;
  assign arch_cycle = (phase_sum >= PHASE_DEN);
  assign ce_micro = ce_micro_q;
  assign micro_wrap = (micro_sum >= PHASE_DEN);
  assign micro_phase_next = micro_wrap
                          ? 9'(micro_sum - PHASE_DEN)
                          : micro_sum[8:0];
  assign micro_sum_next = {1'b0, micro_phase_next} + 10'd100;
  assign micro_tick_next = (micro_sum_next >= PHASE_DEN);

  always_ff @(posedge clk) begin
    if (rst) begin
      phase <= 9'd0;
      micro_phase <= 9'd0;
      ce_micro_q <= 1'b0;
    end else begin
      if (arch_cycle)
        phase <= 9'(phase_sum - PHASE_DEN);
      else
        phase <= phase_sum[8:0];
      micro_phase <= micro_phase_next;
      // Register the pulse one edge ahead.  ce_micro at a sampling edge is
      // therefore bit-for-bit identical to the former combinational
      // (micro_phase + 100 >= 384) result, but its path to the CPU scheduler
      // now starts at this flop rather than at an adder/comparator.
      ce_micro_q <= micro_tick_next;
    end
  end

`ifndef SYNTHESIS
  // The lookahead registration must never move a microengine edge.  This
  // assertion compares the registered pulse with the original expression.
  always_ff @(posedge clk) begin
    if (!rst && (ce_micro_q !== micro_wrap))
      $fatal(1, "yunit_cpu_cadence: registered ce_micro changed pulse phase");
  end
`endif
endmodule

`default_nettype wire
