// yunit_video.sv — Williams Y-unit video scanout: frame buffer -> RGB.
//
// Faithful to MAME midyunit_v.cpp scanline_update (:543):
//   src   = local_videoram[(rowaddr << 9) & 0x3fe00]   // row base (pixel idx)
//   pixel = src[coladdr++ & 0x1ff]                      // 512-col wrap
//   dest  = pen_map[pixel]                              // 6bpp: pen_map6()
// then the pen indexes palette RAM (xRGB1555) -> RGB888 (paletteram_w:250,
// pal5bit). The Y-unit uses EXTERNAL video timing (the game never programs the
// 34010 timing regs — measured 2026-07-04), so this block owns the raster.
//
// Two-stage read pipeline: addr -> vram_rdata (1 clk) -> pen_map6 -> pal_raddr
// -> pal_rdata (1 clk) -> RGB. de/sync are delayed to match.
//
// Geometry is parameterized (Smash T.V. = stdres). DISP_ROW0 is the first VRAM
// row displayed (the 34010 DPYSTRT fallback; the live display sequencer supplies
// the assembly-programmed row/column descriptor in production).

`default_nettype none

module yunit_video
  import yunit_pkg::*;
#(
  // Timing reconciled to MAME 0.280 `smashtv` set_raw (measured via -listxml):
  //   pixclock 8 MHz, htotal 506, hbend 90, hbstart 500, vtotal 289, vbend 20,
  //   vbstart 276, width 410, height 256, refresh 54.706840 Hz, rotate 0.
  //   => active 410x256; H_TOTAL 506, V_TOTAL 289; 8e6/(506*289)=54.71 Hz. ✓
  // (Phase 6 W3: was 512/616 x 256/288 = 616x288 which gave the wrong refresh.)
  parameter int H_ACT   = 410,   // visible pixels (MAME width; VRAM is 512 cols, cols 0..409 shown)
  parameter int H_FP    = 6,     // 506 - 410 active = 96 blank
  parameter int H_SYNC  = 44,    // (HESYNC 0x15 + 1) * 2 pixels/VCLK
  parameter int H_BP    = 46,
  parameter int V_ACT   = 256,   // visible lines
  parameter int V_FP    = 13,    // 289 - 256 active = 33 blank
  parameter int V_SYNC  = 4,     // VESYNC 3 + 1 scanlines
  parameter int V_BP    = 16,
  parameter int DISP_ROW0 = 0    // first displayed VRAM row (DPYSTRT)
)(
  input  logic        clk,
  input  logic        rst,
  input  logic        ce_pix,       // pixel-clock enable
  input  logic        bpp4,         // runtime board profile: 4bpp pen map
  // Live TMS34010 display descriptor.  line_event is registered and aligned
  // with line_desc_valid by yunit_display_address_sequencer.
  input  logic        use_dynamic_display,
  input  logic        display_contract_valid,
  input  logic        line_event,
  input  logic        line_desc_valid,
  input  logic [8:0]  line_desc_row_phys,
  input  logic [8:0]  line_desc_col_word,
  input  logic        line_cache_ready,

  // RUNTIME visible width, in pixels, from the CRTC: (HSBLNK-HEBLNK)*2.
  // MEASURED per title on MAME 0.289 (crtc_geom 2026-08-16): the ADPCM trio
  // all ask for LESS than the raster's H_ACT=410 -- mkla1 400, totcarn 400,
  // term2 404 -- so a compile-time width paints right-edge columns the game
  // never draws (stale, page-alternating). Same defect class and same remedy
  // as yunit_video_family2 (806dde5): the RASTER stays at H_ACT, pixels at or
  // beyond visible_px are blanked. Clamped to H_ACT by the top; reset default
  // is H_ACT so behaviour before the CRTC is programmed is unchanged.
  input  logic [11:0] visible_px,

  // Presentation mirror (term2 is ORIENTATION_FLIP_X, midyunit.cpp:3886).
  // Reflects the pixel X across the CRTC visible window; the width blank
  // itself stays on raw s0_x so the blanked columns remain at the right
  // edge of the output. Z-safe: an unconnected legacy-bench input means OFF.
  input  logic        flip_x,

  // Frame-buffer read (registered, 1-clk latency): pixel index -> videoram word.
  output logic [FB_ADDR_W-1:0] vram_raddr,
  input  logic [15:0]          vram_rdata,
  // Palette read (registered, 1-clk latency): 12-bit pen -> xRGB1555.
  output logic [11:0]          pal_raddr,
  input  logic [15:0]          pal_rdata,

  // Video output (aligned with the 2-stage pipeline).
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync,
  output logic        hblank, vblank,
  output logic        de,
  // Stage-0 vertical blank aligned with vram_raddr.  The public vblank output
  // is delayed three pixel clocks to match RGB; scanline-buffer ownership must
  // use this raw flag or row 0 is already being read while blank still appears
  // asserted at the output pipeline.
  output logic        vblank_raw,
  output logic        vblank_irq    // 1-clk pulse at start of vertical blank
);

  localparam int H_TOTAL = H_ACT + H_FP + H_SYNC + H_BP;
  localparam int V_TOTAL = V_ACT + V_FP + V_SYNC + V_BP;

  // ---- raster counters (stage 0) ---------------------------------------
  logic [11:0] hc, vc;
  logic        s0_de, s0_hs, s0_vs, s0_hb, s0_vb;
  logic [11:0] s0_x, s0_y;
  logic [8:0]  display_row;
  logic [8:0]  display_col;
  logic        display_line_valid;
  wire dynamic_display = (use_dynamic_display === 1'b1);
  wire dynamic_contract_ok = (display_contract_valid === 1'b1);
  wire dynamic_cache_ok = (line_cache_ready === 1'b1);

  always_ff @(posedge clk) begin
    if (rst) begin
      display_row        <= 9'(DISP_ROW0);
      display_col        <= 9'd0;
      display_line_valid <= 1'b0;
    end else if (dynamic_display && (line_event === 1'b1)) begin
      display_line_valid <= (line_desc_valid === 1'b1);
      if (line_desc_valid === 1'b1) begin
        display_row <= line_desc_row_phys;
        display_col <= line_desc_col_word;
      end
    end
  end

  always_ff @(posedge clk) begin
    if (rst) begin
`ifdef MUT_YVIDEO_ZERO_PHASE
      hc <= '0; vc <= '0; vblank_irq <= 1'b0;
`else
      // The 34010 counters reset at the start of sync (HCOUNT=VCOUNT=0),
      // while this raster's zero is the first active pixel.  Horizontal
      // preload is the matching sync origin.  Vertical is one line earlier:
      // the 34010 advances VCOUNT at HCOUNT wrap (90 physical pixels before
      // active x=0), while this active-origin raster advances vc at x=0.
      hc <= 12'(H_ACT + H_FP);
      vc <= 12'(V_ACT + V_FP - 1);
      vblank_irq <= 1'b0;
`endif
    end else if (ce_pix) begin
      vblank_irq <= 1'b0;
      if (hc == H_TOTAL-1) begin
        hc <= '0;
        if (vc == V_TOTAL-1) vc <= '0;
        else begin
          vc <= vc + 12'd1;
          if (vc == V_ACT-1) vblank_irq <= 1'b1;   // entering vblank
        end
      end else hc <= hc + 12'd1;
    end
  end

  // active-region flags + pixel (x,y) at stage 0
  always_comb begin
    s0_x  = hc;
    s0_y  = vc;
    s0_de = (hc < H_ACT) && (vc < V_ACT)
          && (!dynamic_display
              || (display_line_valid && dynamic_contract_ok
                  && dynamic_cache_ok));
    s0_hb = (hc >= H_ACT);
    s0_vb = (vc >= V_ACT);
    // sync sits after the front porch
    s0_hs = (hc >= H_ACT + H_FP) && (hc < H_ACT + H_FP + H_SYNC);
    s0_vs = (vc >= V_ACT + V_FP) && (vc < V_ACT + V_FP + V_SYNC);
  end

  // MAME midyunit_v.cpp:
  //   src = videoram[(rowaddr << 9) & 0x3fe00]
  //   pixel = src[(coladdr << 1 + x) & 0x1ff]
  // The sequencer has already applied ORG and produced coladdr<<1.
  // flip_x mirrors within [0, visible_px): out(x) shows fb(visible-1-x).
  // TIMING (r3 fit 2026-08-17, setup -3.6 ns): once HEBLNK/HSBLNK became
  // live registers (the display-tap fix), a combinational
  // tracker-sub/clamp -> mirror-sub -> vram_raddr -> 512:1 line-buffer-valid
  // cone materialized and failed at 96 MHz. The width values are QUASI-STATIC
  // (written once at CRTC init), so: register them, and form the mirrored X
  // as a per-pixel DOWN-COUNTER -- zero arithmetic in the address path, which
  // returns raddr to the exact depth that closed in every prior build.
  wire [11:0] vis_w_c = (^visible_px === 1'bx) ? 12'(H_ACT) : visible_px;
  logic [11:0] vis_w, vis_last_q;
  always_ff @(posedge clk) begin
    vis_w     <= vis_w_c;
    vis_last_q <= vis_w_c - 12'd1;
  end
  logic [11:0] x_mirror;
  // Same-D scanline-local launch.  The canonical counter remains for an
  // inductive simulation proof; this spatial copy ends the measured
  // x_mirror -> line-overlay-valid route without adding a pixel of latency.
  (* preserve, dont_merge *) logic [11:0] scan_x_mirror_q;
  always_ff @(posedge clk) begin
    if (rst) begin x_mirror <= 12'd0; scan_x_mirror_q <= 12'd0; end
    else if (ce_pix) begin
      if (hc == H_TOTAL-1) begin
        x_mirror        <= vis_last_q;  // next tick is x=0
        scan_x_mirror_q <= vis_last_q;
      end else begin
        x_mirror        <= x_mirror - 12'd1;
        scan_x_mirror_q <= x_mirror - 12'd1;
      end
    end
  end
`ifndef SYNTHESIS
  always_ff @(posedge clk)
    if (!rst && (scan_x_mirror_q !== x_mirror))
      $fatal(1, "scanline mirror locality copy diverged");
`endif
`ifdef MUT_NO_FLIPX
  // MUTANT (sim/probe/dyn-width flip leg kill control): ignore the mirror.
  wire [11:0] x_eff = s0_x;
`else
  wire [11:0] x_eff = (flip_x === 1'b1) ? scan_x_mirror_q : s0_x;
`endif
  always_comb begin
    if (dynamic_display)
      vram_raddr = {display_row, (display_col + x_eff[8:0])};
    else
      vram_raddr = FB_ADDR_W'(((DISP_ROW0 + s0_y) << FB_ROWSHIFT)
                           + (x_eff & 12'h1ff));
  end
  assign vblank_raw = s0_vb;

  // The color path has THREE register stages from s0: vram_rdata (external),
  // pal_rdata (external), and the vid_* output register. Delay the control
  // signals by three to keep de/sync aligned with the pixel color.
  logic s1_de,s1_hs,s1_vs,s1_hb,s1_vb;
  logic s2_de,s2_hs,s2_vs,s2_hb,s2_vb;
  always_ff @(posedge clk) begin
    if (rst) begin
      s1_de<=0;s1_hs<=0;s1_vs<=0;s1_hb<=0;s1_vb<=0;
      s2_de<=0;s2_hs<=0;s2_vs<=0;s2_hb<=0;s2_vb<=0;
    end else if (ce_pix) begin
      s1_de<=s0_de; s1_hs<=s0_hs; s1_vs<=s0_vs; s1_hb<=s0_hb; s1_vb<=s0_vb;
      s2_de<=s1_de; s2_hs<=s1_hs; s2_vs<=s1_vs; s2_hb<=s1_hb; s2_vb<=s1_vb;
    end
  end

  // An unconnected legacy-testbench input is Z and therefore selects the
  // established 6bpp path.
  assign pal_raddr = (bpp4 === 1'b1) ? pen_map4(vram_rdata)
                                      : pen_map6(vram_rdata);

  logic [23:0] rgb;
  assign rgb = rgb555_to_888(pal_rdata);            // stage: xRGB1555 -> 888 (comb)

  // ---- runtime visible-width blank (gospel [heblnk, hsblnk) window) ----
  // Unconnected legacy-testbench input is Z: X/Z-safe compare keeps those
  // benches on the full-H_ACT behaviour.
  // Compare against the REGISTERED width (see the timing note above): the
  // X-guard is folded into vis_w's own default, and a flop startpoint keeps
  // the tracker's subtract/clamp cone out of this per-pixel compare.
  wire s0_vis = (s0_x < vis_w);
  logic s1_vis, s2_vis;
  always_ff @(posedge clk) begin
    if (rst)          begin s1_vis <= 1'b1; s2_vis <= 1'b1; end
    else if (ce_pix)  begin s1_vis <= s0_vis; s2_vis <= s1_vis; end
  end
  wire pix_on = s2_de && s2_vis;

  // ---- final output register (aligned with s2_*) -----------------------
  always_ff @(posedge clk) begin
    if (rst) begin
      de<=0; hsync<=0; vsync<=0; hblank<=0; vblank<=0;
      vid_r<=0; vid_g<=0; vid_b<=0;
    end else if (ce_pix) begin
      de<=s2_de; hsync<=s2_hs; vsync<=s2_vs; hblank<=s2_hb; vblank<=s2_vb;
      vid_r <= pix_on ? rgb[23:16] : 8'h00;
      vid_g <= pix_on ? rgb[15:8]  : 8'h00;
      vid_b <= pix_on ? rgb[7:0]   : 8'h00;
    end
  end

endmodule

`default_nettype wire
