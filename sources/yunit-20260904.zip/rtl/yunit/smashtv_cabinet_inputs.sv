// Cabinet-recovery input map for the proven firefix/mixboot Smash T.V. path.
//
// This deliberately uses the legacy Smash-only CONF_STR convention:
//   joystick bits 4..7 = fire Up/Down/Left/Right
//   joystick bit 8     = Start
//   joystick bit 9     = Coin
//
// MAME midyunit.cpp INPUT_PORTS_START(smashtv) and the original game's
// AUDIT.ASM SWTAB agree on the resulting active-low IN0/IN1 bit positions.
// There are no analog-fire inputs here: the cabinet-good build proved that an
// uncalibrated right-analog idle value can otherwise hold a fire direction on.
`timescale 1ns/1ps
`default_nettype none

module smashtv_cabinet_inputs (
  input  logic [15:0] joy0,
  input  logic [15:0] joy1,
  input  logic [15:0] dsw_raw,
  output logic [63:0] inputs
);
  logic [15:0] in0;
  logic [15:0] in1;
  logic [15:0] dsw;

  always_comb begin
    // IN0: P1 in bits 0..7, P2 in bits 8..15. MiSTer direction
    // convention is R,L,D,U in joystick bits 0..3.
    in0 = 16'hffff;
    in0[0]  = ~joy0[3]; // P1 move up
    in0[1]  = ~joy0[2]; // P1 move down
    in0[2]  = ~joy0[1]; // P1 move left
    in0[3]  = ~joy0[0]; // P1 move right
    in0[4]  = ~joy0[4]; // P1 fire up
    in0[5]  = ~joy0[5]; // P1 fire down
    in0[6]  = ~joy0[6]; // P1 fire left
    in0[7]  = ~joy0[7]; // P1 fire right
    in0[8]  = ~joy1[3]; // P2 move up
    in0[9]  = ~joy1[2]; // P2 move down
    in0[10] = ~joy1[1]; // P2 move left
    in0[11] = ~joy1[0]; // P2 move right
    in0[12] = ~joy1[4]; // P2 fire up
    in0[13] = ~joy1[5]; // P2 fire down
    in0[14] = ~joy1[6]; // P2 fire left
    in0[15] = ~joy1[7]; // P2 fire right

    // IN1: the working Smash-only wrapper exposed the two player coin/start
    // lines. All other cabinet lines remain released.
    in1 = 16'hffff;
    in1[0] = ~joy0[9]; // coin 1
    in1[1] = ~joy1[9]; // coin 2
    in1[2] = ~joy0[8]; // start 1
    in1[5] = ~joy1[8]; // start 2

    // Smash rev 8 actually executes its rotary-fire branch when DS2:2 is On.
    // This core has no rotary encoder, so preserve every DIP except bit 14,
    // which must read Off (1). This is the cabinet-confirmed fire fix.
    dsw = dsw_raw | 16'h4000;

    inputs = {dsw, 16'hffff, in1, in0};
  end
endmodule

`default_nettype wire
