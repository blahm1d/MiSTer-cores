// yunit_autoerase_scheduler.sv -- beam-locked Y-unit autoerase job queue.
//
// MAME's midyunit scanline callback copies the previously displayed physical
// row after each scanline, using row 510 for even destinations and row 511 for
// odd destinations.  This module deliberately knows nothing about raster
// timing: line_consumed_valid must be a one-cycle event emitted only after the
// supplied physical row has been fully displayed.
//
// Autoerase enable is sampled for each event.  Disabled events are discarded
// immediately and are never reconstructed as catch-up work after re-enable.
// Rows 510 and 511 are the erase templates and can never be destinations.
//
// A backend accepts one immutable 512-word row-copy job with the usual
// job_valid/job_ready handshake, then pulses job_done when the copy has
// completed.  Only one job may be in flight; two more can wait in the FIFO.
// Overflow diagnostics make a missed scanline event visible instead of
// silently coalescing or replacing work.

`default_nettype none

module yunit_autoerase_scheduler (
  input  logic       clk,
  input  logic       rst,                  // synchronous, active high

  // Post-displayed-line event from the raster owner.
  input  logic       line_consumed_valid,
  input  logic [8:0] line_phys_row,
  input  logic       autoerase_enable,

  // Row-copy backend.  Job fields are stable while valid is waiting for ready.
  output logic       job_valid,
  input  logic       job_ready,
  output logic [8:0] job_src_row,
  output logic [8:0] job_dst_row,
  input  logic       job_done,
  output logic       job_inflight,

  // Queue/diagnostic visibility.
  output logic [1:0] pending_count,
  output logic       overflow_pulse,
  output logic       overflow_sticky
);

  localparam logic [1:0] FIFO_DEPTH = 2'd2;

  logic [8:0] src_fifo [0:1];
  logic [8:0] dst_fifo [0:1];
  logic       rd_ptr;
  logic       wr_ptr;
  logic [1:0] fifo_count;

  wire event_eligible = line_consumed_valid && autoerase_enable
                      && (line_phys_row < 9'd510);
  wire launch_job = job_valid && job_ready;
  // A same-cycle dequeue frees a full FIFO slot for the new line event.
  wire fifo_has_room = (fifo_count < FIFO_DEPTH) || launch_job;
  wire enqueue_event = event_eligible && fifo_has_room;
  wire drop_event = event_eligible && !fifo_has_room;

  assign pending_count = fifo_count;
  assign job_valid = !job_inflight && (fifo_count != 2'd0);
  assign job_src_row = job_valid ? src_fifo[rd_ptr] : 9'd0;
  assign job_dst_row = job_valid ? dst_fifo[rd_ptr] : 9'd0;

  always_ff @(posedge clk) begin
    if (rst) begin
      rd_ptr          <= 1'b0;
      wr_ptr          <= 1'b0;
      fifo_count      <= 2'd0;
      job_inflight    <= 1'b0;
      overflow_pulse  <= 1'b0;
      overflow_sticky <= 1'b0;
    end else begin
      overflow_pulse <= drop_event;
      if (drop_event)
        overflow_sticky <= 1'b1;

      if (enqueue_event) begin
        src_fifo[wr_ptr] <= line_phys_row[0] ? 9'd511 : 9'd510;
        dst_fifo[wr_ptr] <= line_phys_row;
        wr_ptr           <= ~wr_ptr;
      end

      if (launch_job)
        rd_ptr <= ~rd_ptr;

      case ({enqueue_event, launch_job})
        2'b10: fifo_count <= fifo_count + 2'd1;
        2'b01: fifo_count <= fifo_count - 2'd1;
        default: fifo_count <= fifo_count;
      endcase

      if (job_inflight) begin
        if (job_done)
          job_inflight <= 1'b0;
      end else if (launch_job) begin
        job_inflight <= 1'b1;
      end
    end
  end

endmodule

`default_nettype wire
