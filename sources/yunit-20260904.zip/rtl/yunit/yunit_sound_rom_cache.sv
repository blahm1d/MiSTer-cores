// Shared external sound-ROM word cache.
//
// The physical SDRAM returns 16 bits, while both Williams sound boards request
// bytes.  Keep the current word and prefetch the following word so sequential
// 6809/OKI traffic normally completes without stretching the 12 MHz board
// clock.  The request remains asserted, with a stable address, until mem_ack.
`timescale 1ns/1ps
`default_nettype none

module yunit_sound_rom_cache (
  input  logic        clk,
  input  logic        rst,
  input  logic        active,
  input  logic [20:0] client_addr,
  output logic [7:0]  client_data,
  output logic        client_ok,

  output logic        mem_rd,
  output logic [20:0] mem_addr,
  input  logic [15:0] mem_rdata,
  input  logic        mem_ack
);
  logic [19:0] current_addr, prefetch_addr;
  logic [15:0] current_word, prefetch_word;
  logic        current_valid, prefetch_valid;
  logic        fetch_is_prefetch;

  wire [19:0] wanted_word = client_addr[20:1];
  wire current_hit = current_valid && (current_addr == wanted_word);
  wire prefetch_hit = prefetch_valid && (prefetch_addr == wanted_word);
  wire [15:0] hit_word = current_hit ? current_word : prefetch_word;

  always_comb begin
    client_ok = active && (current_hit || prefetch_hit);
    client_data = client_addr[0] ? hit_word[15:8] : hit_word[7:0];
  end

  always_ff @(posedge clk) begin
    if (rst || !active) begin
      mem_rd <= 1'b0;
      mem_addr <= 21'd0;
      current_valid <= 1'b0;
      prefetch_valid <= 1'b0;
      fetch_is_prefetch <= 1'b0;
      current_addr <= 20'd0;
      prefetch_addr <= 20'd0;
      current_word <= 16'd0;
      prefetch_word <= 16'd0;
    end else if (mem_rd) begin
      if (mem_ack) begin
        mem_rd <= 1'b0;
        if (fetch_is_prefetch) begin
          prefetch_addr <= mem_addr[20:1];
          prefetch_word <= mem_rdata;
          prefetch_valid <= 1'b1;
        end else begin
          current_addr <= mem_addr[20:1];
          current_word <= mem_rdata;
          current_valid <= 1'b1;
          prefetch_valid <= 1'b0;
        end
      end
    end else if (prefetch_hit) begin
      current_addr <= prefetch_addr;
      current_word <= prefetch_word;
      current_valid <= 1'b1;
      prefetch_valid <= 1'b0;
    end else if (!current_hit) begin
      mem_addr <= {wanted_word, 1'b0};
      fetch_is_prefetch <= 1'b0;
      mem_rd <= 1'b1;
    end else if (!prefetch_valid) begin
      mem_addr <= {(current_addr + 20'd1), 1'b0};
      fetch_is_prefetch <= 1'b1;
      mem_rd <= 1'b1;
    end
  end
endmodule

`default_nettype wire
