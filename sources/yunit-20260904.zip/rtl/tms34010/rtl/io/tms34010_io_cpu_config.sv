// -----------------------------------------------------------------------------
// tms34010_io_cpu_config.sv
//
// CPU-domain shadows of the five software-programmed graphics I/O registers.
//
// The full-rate I/O register file is retained for architectural readback and
// video/device behavior.  At the retiring CPU ack, this block write-forwards
// the already-stable command directly into CE-gated shadows.  Long graphics
// cones therefore launch from genuine CPU registers, with no io_reg-Q path.
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_io_cpu_config
  import tms34010_pkg::*;
(
  input  wire logic                  clk,
  input  wire logic                  rst,
  input  wire logic                  ce_cpu,
  input  wire logic                  req,
  input  wire logic                  we,
  input  wire logic                  is_io,
  input  wire logic                  ack,
  input  wire logic [ADDR_WIDTH-1:0] addr,
  input  wire logic [15:0]           wdata,
  input  wire logic [FIELD_SIZE_WIDTH-1:0] size,

  // Live taps exist only for mutation coverage.  Production shadows never
  // sample them; synthesis removes these unused paths.
  input  wire logic [15:0]           live_psize,
  input  wire logic [15:0]           live_convdp,
  input  wire logic [15:0]           live_convsp,
  input  wire logic [15:0]           live_control,
  input  wire logic [15:0]           live_pmask,

  output logic [15:0]                psize,
  output logic [15:0]                convdp,
  output logic [15:0]                convsp,
  output logic [15:0]                control,
  output logic [15:0]                pmask
);

`ifdef MUT_IO_LIVE_TAPS
  // Mutation: restore the rejected full-rate io_reg-Q -> CPU combinational
  // paths that produced the post-fit PSIZE -> p_wdata setup violation.
  assign psize   = live_psize;
  assign convdp  = live_convdp;
  assign convsp  = live_convsp;
  assign control = live_control;
  assign pmask   = live_pmask;
`else
  wire [IO_REG_IDX_W-1:0] wr_idx = addr[IO_REG_IDX_W+3:4];
  wire config_write = (ce_cpu !== 1'b0) && req && we && is_io && ack;
  wire [15:0] psize_merged   = io_field_merge(psize,   wdata, addr[3:0], size);
  wire [15:0] convdp_merged  = io_field_merge(convdp,  wdata, addr[3:0], size);
  wire [15:0] convsp_merged  = io_field_merge(convsp,  wdata, addr[3:0], size);
  wire [15:0] control_merged = io_field_merge(control, wdata, addr[3:0], size);
  wire [15:0] pmask_merged   = io_field_merge(pmask,   wdata, addr[3:0], size);

  always_ff @(posedge clk) begin
    if (rst) begin
      psize   <= 16'h0000;
      convdp  <= 16'h0000;
      convsp  <= 16'h0000;
      control <= 16'h0000;
      pmask   <= 16'h0000;
    end else if (config_write) begin
      unique case (wr_idx)
`ifdef MUT_IO_CONFIG_RAW_FIELD_FORWARD
        IO_IDX_PSIZE:   psize   <= wdata;
        IO_IDX_CONVDP:  convdp  <= wdata;
        IO_IDX_CONVSP:  convsp  <= wdata;
        IO_IDX_CONTROL: control <= wdata;
        IO_IDX_PMASK:   pmask   <= wdata;
`else
        IO_IDX_PSIZE:   psize   <= psize_merged;
        IO_IDX_CONVDP:  convdp  <= convdp_merged;
        IO_IDX_CONVSP:  convsp  <= convsp_merged;
        IO_IDX_CONTROL: control <= control_merged;
        IO_IDX_PMASK:   pmask   <= pmask_merged;
`endif
        default: ;
      endcase
    end
  end
`endif

endmodule : tms34010_io_cpu_config
`default_nettype wire
