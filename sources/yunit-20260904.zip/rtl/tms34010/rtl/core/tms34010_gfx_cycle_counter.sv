// TMS34010 block-graphics architectural cycle counter.
//
// This module reproduces the cycle accounting in the pinned MAME TMS34010
// implementation for the graphics instructions currently decoded by the RTL:
// FILL L/XY, PIXBLT L/L, L/XY, XY/L, XY/XY, and PIXBLT B L/XY.
//
// The datapath snapshots one operation on start, applies MAME's signed window
// adjustment, then accumulates one MAME row per enabled clock.  Walking rows
// explicitly is required because ordinary/reverse PIXBLT timing depends on the
// low address bits after each (possibly non-word-aligned) pitch update.
//
// Source cross-check (MAME c531ffa701750a5345a856ec205c6428057aa63a):
//   src/devices/cpu/tms34010/34010gfx.hxx
//     apply_window(), compute_fill_cycles(), compute_pixblt_cycles(),
//     compute_pixblt_b_cycles(), and the active per-row read/write counter.
//
// There is no RAM, divider, modulo operator, or runtime loop.  Power-of-two
// divisions are explicit shifts.  Latency is one enabled clock to snapshot
// plus one enabled clock per positive post-window row.  done remains asserted
// until the next start.  Reset is synchronous active-high.
`default_nettype none

module tms34010_gfx_cycle_counter (
  input  wire logic        clk,
  input  wire logic        rst,
  input  wire logic        ce,
  input  wire logic        start,

  input  wire logic        is_fill,
  input  wire logic        is_binary,
  input  wire logic        src_xy,
  input  wire logic        dst_xy,
  input  wire logic [31:0] saddr,
  input  wire logic [31:0] daddr,
  input  wire logic [31:0] dydx,
  input  wire logic [31:0] sptch,
  input  wire logic [31:0] dptch,
  input  wire logic [31:0] offset,
  input  wire logic [31:0] wstart,
  input  wire logic [31:0] wend,
  input  wire logic [15:0] convsp,
  input  wire logic [15:0] convdp,
  input  wire logic [15:0] psize,
  input  wire logic [15:0] control,

  output logic        busy,
  output logic        done,
  output logic [31:0] cycles,
  output logic        overflow
);

  localparam int unsigned CTRL_T_BIT   = 5;
  localparam int unsigned CTRL_W_LO    = 6;
  localparam int unsigned CTRL_W_HI    = 7;
  localparam int unsigned CTRL_PBH_BIT = 8;
  localparam int unsigned CTRL_PBV_BIT = 9;
  localparam int unsigned CTRL_ROP_LO  = 10;
  localparam int unsigned CTRL_ROP_HI  = 14;

  typedef enum logic [1:0] {
    GFXC_IDLE = 2'd0,
    GFXC_ROWS = 2'd1,
    GFXC_DONE = 2'd2
  } gfxc_state_t;

  gfxc_state_t state_q;

  logic [39:0] acc_q;
  logic [15:0] rows_left_q;
  logic [15:0] dx_q;
  logic [31:0] src_addr_q;
  logic [31:0] dst_addr_q;
  logic [31:0] sptch_q;
  logic [31:0] dptch_q;
  logic [4:0]  bpp_shift_q;
  logic [3:0]  op_timing_q;
  logic        fill_q;
  logic        binary_q;
  logic        reverse_q;
  logic        yreverse_q;
  logic        needs_dest_q;

  function automatic logic [4:0] mame_bpp_shift(
      input logic [4:0] psize_low);
    begin
      // pixelsize_lookup[] in 34010gfx.hxx: floor to a supported power of
      // two, cap at 16, and map zero to the 1-bpp specialization.
      if (psize_low[4])
        mame_bpp_shift = 5'd4;
      else if (psize_low[3])
        mame_bpp_shift = 5'd3;
      else if (psize_low[2])
        mame_bpp_shift = 5'd2;
      else if (psize_low[1])
        mame_bpp_shift = 5'd1;
      else
        mame_bpp_shift = 5'd0;
    end
  endfunction

  function automatic logic [4:0] mame_pixel_shift(
      input logic [4:0] psize_low);
    begin
      // tms34010.cpp REG_PSIZE write handling.  Invalid encodings select the
      // default shift of zero even though the graphics dispatch table floors
      // the BPP specialization independently.
      unique case (psize_low)
        5'd1:    mame_pixel_shift = 5'd0;
        5'd2:    mame_pixel_shift = 5'd1;
        5'd4:    mame_pixel_shift = 5'd2;
        5'd8:    mame_pixel_shift = 5'd3;
        5'd16:   mame_pixel_shift = 5'd4;
        default: mame_pixel_shift = 5'd0;
      endcase
    end
  endfunction

  function automatic logic [3:0] mame_rop_timing(
      input logic [4:0] rop,
      input logic       transparency);
    logic [3:0] base;
    begin
      unique case (rop)
        5'd0,
        5'd22, 5'd23, 5'd24, 5'd25, 5'd26,
        5'd27, 5'd28, 5'd29, 5'd30, 5'd31: base = 4'd2;
        5'd17, 5'd18, 5'd20, 5'd21:        base = 4'd5;
        5'd19:                              base = 4'd6;
        default:                           base = 4'd4;
      endcase
      mame_rop_timing = base + (transparency ? 4'd2 : 4'd0);
    end
  endfunction

  function automatic logic [39:0] mul_small(
      input logic [39:0] value,
      input logic [3:0]  factor);
    begin
      unique case (factor)
        4'd0:    mul_small = 40'd0;
        4'd1:    mul_small = value;
        4'd2:    mul_small = value << 1;
        4'd3:    mul_small = (value << 1) + value;
        4'd4:    mul_small = value << 2;
        4'd5:    mul_small = (value << 2) + value;
        4'd6:    mul_small = (value << 2) + (value << 1);
        4'd7:    mul_small = (value << 2) + (value << 1) + value;
        4'd8:    mul_small = value << 3;
        4'd9:    mul_small = (value << 3) + value;
        4'd10:   mul_small = (value << 3) + (value << 1);
        default: mul_small = 40'd0;
      endcase
    end
  endfunction

  function automatic logic [31:0] xy_to_linear(
      input logic [31:0] xy,
      input logic [31:0] base_offset,
      input logic [15:0] conv,
      input logic [4:0]  pixel_shift);
    logic signed [63:0] sx;
    logic signed [63:0] sy;
    logic signed [63:0] soff;
    logic signed [63:0] result;
    logic [4:0] conv_shift;
    begin
      sx         = {{48{xy[15]}}, xy[15:0]};
      sy         = {{48{xy[31]}}, xy[31:16]};
      soff       = {{32{base_offset[31]}}, base_offset};
      conv_shift = 5'd31 - conv[4:0];
      result     = soff + (sy <<< conv_shift) + (sx <<< pixel_shift);
      xy_to_linear = result[31:0];
    end
  endfunction

  logic [4:0] calc_bpp_shift;
  logic [4:0] calc_pixel_shift;
  logic [4:0] calc_convsp_shift;
  logic [4:0] calc_convdp_shift;
  logic [4:0] calc_rop;
  logic [3:0] calc_op_timing;
  logic [1:0] calc_wmode;
  logic       calc_transparency;
  logic       calc_needs_dest;
  logic       calc_any_xy;
  logic       calc_active;

  logic signed [32:0] calc_dx_orig;
  logic signed [32:0] calc_dy_orig;
  logic signed [32:0] calc_sx_orig;
  logic signed [32:0] calc_sy_orig;
  logic signed [32:0] calc_ex;
  logic signed [32:0] calc_ey;
  logic signed [32:0] calc_sx;
  logic signed [32:0] calc_sy;
  logic signed [32:0] calc_dx;
  logic signed [32:0] calc_dy;
  logic signed [32:0] calc_wsx;
  logic signed [32:0] calc_wsy;
  logic signed [32:0] calc_wex;
  logic signed [32:0] calc_wey;
  logic signed [32:0] calc_diff;

  logic [31:0] calc_src_addr;
  logic [31:0] calc_dst_addr;
  logic [31:0] calc_dst_xy;
  logic [31:0] calc_bpp_mask;
  logic [63:0] calc_addr_delta;
  logic [39:0] calc_base_cycles;
  logic [15:0] calc_rows;
  logic [15:0] calc_dx_u;

  always_comb begin
    calc_bpp_shift     = mame_bpp_shift(psize[4:0]);
    calc_pixel_shift   = mame_pixel_shift(psize[4:0]);
    calc_convsp_shift  = 5'd31 - convsp[4:0];
    calc_convdp_shift  = 5'd31 - convdp[4:0];
    calc_rop           = control[CTRL_ROP_HI:CTRL_ROP_LO];
    calc_wmode         = control[CTRL_W_HI:CTRL_W_LO];
    calc_transparency  = control[CTRL_T_BIT];
    calc_op_timing     = mame_rop_timing(calc_rop, calc_transparency);
    calc_needs_dest    = (calc_rop != 5'd0) || calc_transparency;
    calc_any_xy        = src_xy || dst_xy;

    calc_dx_orig = {{17{dydx[15]}}, dydx[15:0]};
    calc_dy_orig = {{17{dydx[31]}}, dydx[31:16]};
    calc_sx_orig = {{17{daddr[15]}}, daddr[15:0]};
    calc_sy_orig = {{17{daddr[31]}}, daddr[31:16]};
    calc_wsx     = {{17{wstart[15]}}, wstart[15:0]};
    calc_wsy     = {{17{wstart[31]}}, wstart[31:16]};
    calc_wex     = {{17{wend[15]}}, wend[15:0]};
    calc_wey     = {{17{wend[31]}}, wend[31:16]};
    calc_sx      = calc_sx_orig;
    calc_sy      = calc_sy_orig;
    calc_ex      = calc_sx_orig + calc_dx_orig - 33'sd1;
    calc_ey      = calc_sy_orig + calc_dy_orig - 33'sd1;
    calc_dx      = calc_dx_orig;
    calc_dy      = calc_dy_orig;
    calc_diff    = 33'sd0;

    calc_src_addr = src_xy
                  ? xy_to_linear(saddr, offset, convsp, calc_pixel_shift)
                  : saddr;
    calc_dst_addr = daddr;
    calc_dst_xy   = daddr;
    calc_addr_delta = 64'd0;

    if (!is_fill && !is_binary)
      calc_base_cycles = 40'd7 + (src_xy ? 40'd2 : 40'd0);
    else
      calc_base_cycles = 40'd4;

    // MAME calls apply_window only for an XY destination.  The two/three
    // setup-cycle addends surrounding it are charged even when W=0.
    if (dst_xy) begin
      if (!is_fill && !is_binary)
        calc_base_cycles = calc_base_cycles + 40'd2
                         + (src_xy ? 40'd1 : 40'd0);
      else
        calc_base_cycles = calc_base_cycles + 40'd2;

      if (calc_wmode != 2'd0) begin
        calc_base_cycles = calc_base_cycles + 40'd3;

        // Clip left.  PIXBLT advances its source by srcbpp for every removed
        // column; FILL passes a null source pointer to apply_window.
        calc_diff = calc_wsx - calc_sx;
        if (calc_diff > 33'sd0) begin
          if (!is_fill) begin
            calc_addr_delta = {{31{1'b0}}, calc_diff}
                            << (is_binary ? 5'd0 : calc_bpp_shift);
            calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
          end
          calc_sx = calc_sx + calc_diff;
        end

        // Clip right.
        calc_diff = calc_ex - calc_wex;
        if (calc_diff > 33'sd0)
          calc_ex = calc_ex - calc_diff;

        // Clip top.  MAME advances PIXBLT source rows using CONVSP here,
        // regardless of whether the source operand itself was linear.
        calc_diff = calc_wsy - calc_sy;
        if (calc_diff > 33'sd0) begin
          if (!is_fill) begin
            calc_addr_delta = {{31{1'b0}}, calc_diff}
                            << calc_convsp_shift;
            calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
          end
          calc_sy = calc_sy + calc_diff;
        end

        // Clip bottom.
        calc_diff = calc_ey - calc_wey;
        if (calc_diff > 33'sd0)
          calc_ey = calc_ey - calc_diff;

        calc_dx = calc_ex - calc_sx + 33'sd1;
        calc_dy = calc_ey - calc_sy + 33'sd1;

        if ((calc_dx_orig != calc_dx) || (calc_dy_orig != calc_dy)) begin
          if ((calc_sx_orig != calc_sx) || (calc_sy_orig != calc_sy))
            calc_base_cycles = calc_base_cycles + 40'd11;
          else
            calc_base_cycles = calc_base_cycles + 40'd3;
        end else if ((calc_sx_orig != calc_sx)
                  || (calc_sy_orig != calc_sy)) begin
          calc_base_cycles = calc_base_cycles + 40'd7;
        end
      end

      calc_dst_xy   = {calc_sy[15:0], calc_sx[15:0]};
      calc_dst_addr = xy_to_linear(calc_dst_xy, offset, convdp,
                                   calc_pixel_shift);
    end

    calc_bpp_mask = (32'd1 << calc_bpp_shift) - 32'd1;
    calc_dst_addr = calc_dst_addr & ~calc_bpp_mask;
    if (!is_fill && !is_binary && control[CTRL_PBH_BIT])
      calc_src_addr = calc_src_addr & ~calc_bpp_mask;

    calc_active = (calc_dx > 33'sd0) && (calc_dy > 33'sd0)
               && !(dst_xy && (calc_wmode == 2'd1));
    calc_rows = calc_dy[15:0];
    calc_dx_u = calc_dx[15:0];

    // Reverse non-binary PIXBLT adjusts to the far edge only for an XY form;
    // this is the exact gate in MAME's pixblt_r implementation.
    if (calc_active && !is_fill && !is_binary
        && control[CTRL_PBH_BIT] && calc_any_xy) begin
      calc_addr_delta = {{31{1'b0}}, calc_dx}
                      << calc_bpp_shift;
      calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
      calc_dst_addr = calc_dst_addr + calc_addr_delta[31:0];
    end

    // PBV's initial row adjustment is likewise gated by either XY operand.
    if (calc_active && !is_fill && !is_binary
        && control[CTRL_PBV_BIT] && calc_any_xy) begin
      calc_addr_delta = {{31{1'b0}}, (calc_dy - 33'sd1)}
                      << calc_convsp_shift;
      calc_src_addr = calc_src_addr + calc_addr_delta[31:0];
      calc_addr_delta = {{31{1'b0}}, (calc_dy - 33'sd1)}
                      << calc_convdp_shift;
      calc_dst_addr = calc_dst_addr + calc_addr_delta[31:0];
    end

    // FILL and PIXBLT B charge +2 only after the empty/W=1 early returns.
    // Their per-row word split is evaluated from the registered operation
    // snapshot below.  Keeping it out of this command-capture cone prevents
    // the instruction decoder, window clipper, word splitter, and multiplier
    // from becoming one three-CPU-step timing path.
    if (calc_active && is_fill) begin
      calc_base_cycles = calc_base_cycles + 40'd2;
    end else if (calc_active && is_binary) begin
      calc_base_cycles = calc_base_cycles + 40'd2;
    end
  end

  logic [31:0] row_total_bits;
  logic [31:0] row_dst_span;
  logic [31:0] row_src_span;
  logic [31:0] row_dst_words;
  logic [31:0] row_src_words;
  logic [31:0] row_dest_reads;
  logic [31:0] row_readwrites;
  logic [31:0] row_reverse_start;
  logic        row_left_partial;
  logic        row_right_partial;
  logic [3:0]  row_extra_timing;
  logic [39:0] row_cycles;
  logic [39:0] row_sum;

  always_comb begin
    row_total_bits    = {16'd0, dx_q} << bpp_shift_q;
    // FILL and PIXBLT B use a row-invariant word split in MAME.  The operands
    // here are the registered, post-window operation snapshot, so computing it
    // on each row is mathematically identical to capturing a precomputed value
    // at start while removing that very long start-to-register cone.
    row_dst_span      = {28'd0, dst_addr_q[3:0]} + row_total_bits;
    row_src_span      = 32'd0;
    row_dst_words     = (row_dst_span + 32'd15) >> 4;
    row_src_words     = (row_dst_words << bpp_shift_q) >> 4;
    row_dest_reads    = 32'd0;
    row_readwrites    = 32'd0;
    row_reverse_start = dst_addr_q - row_total_bits;
    row_left_partial  = 1'b0;
    row_right_partial = 1'b0;
    row_extra_timing  = op_timing_q - 4'd2;
    row_cycles        = 40'd0;

    if (fill_q) begin
      row_cycles = mul_small({8'd0, row_dst_words}, op_timing_q);
    end else if (binary_q) begin
      row_cycles = mul_small({8'd0, row_dst_words}, op_timing_q)
                 + ({8'd0, row_src_words} << 1);
    end else begin
      if (reverse_q) begin
        row_dst_span  = {28'd0, row_reverse_start[3:0]}
                      + row_total_bits;
        row_dst_words = (row_dst_span + 32'd15) >> 4;
        row_cycles    = mul_small({8'd0, row_dst_words},
                                  op_timing_q + 4'd2) + 40'd2;
      end else begin
        row_dst_span      = {28'd0, dst_addr_q[3:0]} + row_total_bits;
        row_src_span      = {28'd0, src_addr_q[3:0]} + row_total_bits;
        row_dst_words     = (row_dst_span + 32'd15) >> 4;
        row_src_words     = (row_src_span + 32'd15) >> 4;
        row_left_partial  = (dst_addr_q[3:0] != 4'd0);
        row_right_partial = (row_dst_span[3:0] != 4'd0);
        if (needs_dest_q)
          row_dest_reads = row_dst_words
                         + (row_right_partial ? 32'd1 : 32'd0);
        else
          row_dest_reads = (row_left_partial ? 32'd1 : 32'd0)
                         + (row_right_partial ? 32'd1 : 32'd0);
        row_readwrites = row_src_words + row_dst_words + row_dest_reads;
        row_cycles = ({8'd0, row_readwrites} << 1)
                   + mul_small({24'd0, dx_q}, row_extra_timing);
      end
    end

    row_sum = acc_q + row_cycles;
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      state_q             <= GFXC_IDLE;
      acc_q               <= 40'd0;
      rows_left_q         <= 16'd0;
      dx_q                <= 16'd0;
      src_addr_q          <= 32'd0;
      dst_addr_q          <= 32'd0;
      sptch_q             <= 32'd0;
      dptch_q             <= 32'd0;
      bpp_shift_q         <= 5'd0;
      op_timing_q         <= 4'd2;
      fill_q              <= 1'b0;
      binary_q            <= 1'b0;
      reverse_q           <= 1'b0;
      yreverse_q          <= 1'b0;
      needs_dest_q        <= 1'b0;
      busy                <= 1'b0;
      done                <= 1'b0;
      cycles              <= 32'd0;
      overflow            <= 1'b0;
    end else if (ce !== 1'b0) begin
      if (start) begin
        acc_q              <= calc_base_cycles;
        rows_left_q        <= calc_rows;
        dx_q               <= calc_dx_u;
        src_addr_q         <= calc_src_addr;
        dst_addr_q         <= calc_dst_addr;
        sptch_q            <= sptch;
        dptch_q            <= dptch;
        bpp_shift_q        <= calc_bpp_shift;
        op_timing_q        <= calc_op_timing;
        fill_q             <= is_fill;
        binary_q           <= is_binary;
        reverse_q          <= !is_fill && !is_binary
                           && control[CTRL_PBH_BIT];
        yreverse_q         <= !is_fill && !is_binary
                           && control[CTRL_PBV_BIT];
        needs_dest_q       <= calc_needs_dest;
        done               <= 1'b0;
        overflow           <= 1'b0;

        if (calc_active) begin
          state_q <= GFXC_ROWS;
          busy    <= 1'b1;
        end else begin
          state_q  <= GFXC_DONE;
          busy     <= 1'b0;
          done     <= 1'b1;
          overflow <= |calc_base_cycles[39:32];
          cycles   <= |calc_base_cycles[39:32]
                    ? 32'hffff_ffff : calc_base_cycles[31:0];
        end
      end else begin
        unique case (state_q)
          GFXC_ROWS: begin
            acc_q <= row_sum;
            if (rows_left_q == 16'd1) begin
              state_q  <= GFXC_DONE;
              busy     <= 1'b0;
              done     <= 1'b1;
              overflow <= |row_sum[39:32];
              cycles   <= |row_sum[39:32]
                        ? 32'hffff_ffff : row_sum[31:0];
            end else begin
              rows_left_q <= rows_left_q - 16'd1;
              if (!fill_q && !binary_q) begin
                if (yreverse_q) begin
                  src_addr_q <= src_addr_q - sptch_q;
                  dst_addr_q <= dst_addr_q - dptch_q;
                end else begin
                  src_addr_q <= src_addr_q + sptch_q;
                  dst_addr_q <= dst_addr_q + dptch_q;
                end
              end
            end
          end

          GFXC_IDLE,
          GFXC_DONE: begin
            busy <= 1'b0;
          end

          default: begin
            state_q <= GFXC_IDLE;
            busy    <= 1'b0;
            done    <= 1'b0;
          end
        endcase
      end
    end
  end

endmodule

`default_nettype wire
