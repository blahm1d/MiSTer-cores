// -----------------------------------------------------------------------------
// tms34010_regfile.sv
//
// General-purpose register file for the TMS34010 core.
//
// Architectural contract (per bibliography/hdl-reimplementation/03-registers.md):
//   - File A: A0..A14 (15 entries, 32 bits each).
//   - File B: B0..B14 (15 entries, 32 bits each).
//   - SP    : 1 entry, 32 bits, accessible from BOTH files at index 4'hF
//             (i.e., A15 and B15 are aliases for the same SP).
//
// Port shape:
//   - Two combinational read ports. Async read is FPGA-friendly for this
//     size (~1 Kb total) — fits in distributed/LUT RAM on Cyclone V or
//     plain flip-flops without inflating the LUT count.
//   - One CPU-CE synchronous write port plus one full-rate auxiliary commit
//     channel used by MMFM. Write-after-read on either channel within a cycle:
//     a read on `rs1`/`rs2` issued in the same cycle as a write to the matching
//     index returns the OLD value (the new value lands at the next clock edge).
//   - The storage is a flop array, so the two channels may update distinct
//     physical registers on the same sysclk edge. Same-target writes are a
//     protocol violation and are asserted below.
//
// Reset:
//   Synchronous active-high `rst`. All entries clear to '0. The loop in
//   the reset arm is bounded and fully unrollable (15 iterations × 2 files
//   + 1 SP = 31 sequential element updates), so synthesis treats it as
//   plain parallel resets.
//
// Notes:
//   - SP aliasing is implemented in one place (the read/write decode
//     functions). Code that touches the regfile never has to know about
//     the alias.
//   - No `/`, no `%`, no `initial` (rst handles all init), no unbounded
//     loops, no latches (all combinational outputs assigned on every
//     path through `always_comb`).
//
// Spec source:
//   third_party/TMS34010_Info/bibliography/hdl-reimplementation/03-registers.md
// -----------------------------------------------------------------------------

`default_nettype none
module tms34010_regfile
  import tms34010_pkg::*;
(
  input  wire logic                  clk,
  input  wire logic                  ce_cpu,   // P0019: CPU clock-enable (see tms34010_core)
  input  wire logic                  rst,

  // Read port 1.
  input  wire reg_file_t             rs1_file,
  input  wire reg_idx_t              rs1_idx,
  output logic [DATA_WIDTH-1:0] rs1_data,

  // Read port 2.
  input  wire reg_file_t             rs2_file,
  input  wire reg_idx_t              rs2_idx,
  output logic [DATA_WIDTH-1:0] rs2_data,

  // Read port 3. Added for instructions that need a third simultaneous
  // source — currently CPW (reads the point plus WSTART and WEND). Async
  // read like the others; a third read mux on this flop-based file is
  // cheap (no extra memory blocks).
  input  wire reg_file_t             rs3_file,
  input  wire reg_idx_t              rs3_idx,
  output logic [DATA_WIDTH-1:0] rs3_data,

  // Write port.
  input  wire logic                  wr_en,
  input  wire reg_file_t             wr_file,
  input  wire reg_idx_t              wr_idx,
  input  wire logic [DATA_WIDTH-1:0] wr_data,

  // Full-rate auxiliary write channel. MMFM supplies a zero-or-one-hot target
  // over A0..A14, B0..B14, and shared SP. Predecoding the physical target on
  // the issue side removes the former global valid plus variable file/index
  // decoder from every storage-flop D cone.
  input  wire logic [30:0]           aux_wr_target,
  input  wire logic [DATA_WIDTH-1:0] aux_wr_data,

  // Observability: SP value, used by testbenches and (eventually) host
  // interface debug paths.
  output logic [DATA_WIDTH-1:0] sp_o
);

  // ---------------------------------------------------------------------------
  // Storage
  // ---------------------------------------------------------------------------
  logic [DATA_WIDTH-1:0] a_regs [0:14];
  logic [DATA_WIDTH-1:0] b_regs [0:14];
  logic [DATA_WIDTH-1:0] sp_q;

  // ---------------------------------------------------------------------------
  // Read multiplex (combinational / async read)
  //
  // Index 4'hF on either file returns SP. Other indices return the matching
  // file entry. Implemented inline rather than via a function to keep the
  // synthesizable form trivial for Quartus.
  // ---------------------------------------------------------------------------
  always_comb begin
    if (rs1_idx == REG_SP_IDX) begin
      rs1_data = sp_q;
    end else if (rs1_file == REG_FILE_B) begin
      rs1_data = b_regs[rs1_idx];
    end else begin
      rs1_data = a_regs[rs1_idx];
    end
  end

  always_comb begin
    if (rs2_idx == REG_SP_IDX) begin
      rs2_data = sp_q;
    end else if (rs2_file == REG_FILE_B) begin
      rs2_data = b_regs[rs2_idx];
    end else begin
      rs2_data = a_regs[rs2_idx];
    end
  end

  always_comb begin
    if (rs3_idx == REG_SP_IDX) begin
      rs3_data = sp_q;
    end else if (rs3_file == REG_FILE_B) begin
      rs3_data = b_regs[rs3_idx];
    end else begin
      rs3_data = a_regs[rs3_idx];
    end
  end

  // ---------------------------------------------------------------------------
  // Writes
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (rst) begin
      // Bounded, fully unrollable resets.
      for (int unsigned i = 0; i < 15; i++) begin
        a_regs[i] <= '0;
      end
      for (int unsigned i = 0; i < 15; i++) begin
        b_regs[i] <= '0;
      end
      sp_q <= '0;
    end else begin
      // MMFM commit channel: always samples at the full-rate sysclk. In the
      // production Y-unit scheduler this lands on an idle edge, but keeping it
      // independent also preserves legacy/full-rate ce_cpu=1 benches. If both
      // channels fire, the architectural contract requires different physical
      // targets (MMFM excludes Rp from its list), so both flop updates land.
      for (int unsigned i = 0; i < 15; i++) begin
        if (aux_wr_target[i])
          a_regs[i] <= aux_wr_data;
        if (aux_wr_target[15 + i])
          b_regs[i] <= aux_wr_data;
      end
      if (aux_wr_target[30])
        sp_q <= aux_wr_data;

      if ((ce_cpu !== 1'b0) && wr_en) begin
        if (wr_idx == REG_SP_IDX) begin
          sp_q <= wr_data;
        end else if (wr_file == REG_FILE_B) begin
          b_regs[wr_idx] <= wr_data;
        end else begin
          a_regs[wr_idx] <= wr_data;
        end
      end
    end
  end

`ifndef SYNTHESIS
  logic aux_primary_collision;
  always_comb begin
    if (wr_idx == REG_SP_IDX)
      aux_primary_collision = aux_wr_target[30];
    else if (wr_file == REG_FILE_B)
      aux_primary_collision = aux_wr_target[15 + wr_idx];
    else
      aux_primary_collision = aux_wr_target[wr_idx];
  end

  // Distinct variable-index writes are legal for this flop array. A same-target
  // write would make ordering observable, so fail closed instead of relying on
  // the source-order priority above. A15/B15 are the same physical SP target.
  always_ff @(posedge clk) begin
    if (!rst
        && (aux_wr_target != 31'd0)
        && ((aux_wr_target & (aux_wr_target - 31'd1)) != 31'd0)) begin
      $fatal(1, "tms34010_regfile: auxiliary write target is not one-hot");
    end
    if (!rst
        && (aux_wr_target != 31'd0)
        && (ce_cpu !== 1'b0)
        && wr_en
        && aux_primary_collision) begin
      $fatal(1, "tms34010_regfile: primary/auxiliary write collision");
    end
  end
`endif

  assign sp_o = sp_q;

endmodule : tms34010_regfile
`default_nettype wire
