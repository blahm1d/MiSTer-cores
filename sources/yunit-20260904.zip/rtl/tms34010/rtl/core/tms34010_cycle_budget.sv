// TMS34010 architectural instruction-cycle budget.
//
// This is a combinational translation of the TMS34010 instruction classes
// implemented by this core to MAME's COUNT_CYCLES accounting.  Dynamic
// outcomes are explicit inputs so timing is based on the instruction that
// actually retired, not on an opcode-average or a user-selected speed.
//
// The three block-graphics instructions use MAME's address/control-dependent
// timing formula.  Their already-computed result enters through gfx_cycles;
// gfx_cycles_valid must be asserted before that result may be called exact.
//
// Source cross-check:
//   MAME src/devices/cpu/tms34010/34010ops.hxx
//   MAME src/devices/cpu/tms34010/34010gfx.hxx
`default_nettype none

module tms34010_cycle_budget
  import tms34010_pkg::*;
(
  input  wire instr_class_t    iclass,
  input  wire logic [15:0]     instr_word,
  input  wire logic            branch_taken,
  input  wire logic            dsj_precondition,
  input  wire logic            dsj_rd_nonzero,
  input  wire logic [4:0]      reg_list_count,
  input  wire move_addr_mode_t move_mode,
  input  wire logic            force_byte,
  input  wire logic            force_pixel,
  input  wire logic            xy_addr,
  input  wire logic            rd_odd,
  input  wire logic [31:0]     line_count,
  input  wire logic [15:0]     gfx_cycles,
  input  wire logic            gfx_cycles_valid,
  output logic [15:0]    cycles,
  output logic           valid
);

  logic [15:0] line_cycles;

  always_comb begin
    // MAME re-enters LINE once per pixel at two cycles per invocation.  The
    // RTL executes the whole line in one FSM visit, so aggregate the count.
    // Saturate only the observability value; real Y-unit line counts are far
    // below this limit.
    if (|line_count[31:15])
      line_cycles = 16'hffff;
    else
      line_cycles = {line_count[14:0], 1'b0};

    cycles = 16'd1;
    valid  = 1'b1;

    unique case (iclass)
      INSTR_ILLEGAL: cycles = 16'd16;

      INSTR_MOVI_IW,
      INSTR_ADDI_IW,
      INSTR_SUBI_IW,
      INSTR_CMPI_IW: cycles = 16'd2;

      INSTR_MOVI_IL,
      INSTR_ADDI_IL,
      INSTR_SUBI_IL,
      INSTR_CMPI_IL,
      INSTR_ANDI_IL,
      INSTR_ORI_IL,
      INSTR_XORI_IL: cycles = 16'd3;

      INSTR_JRCC_SHORT: cycles = branch_taken ? 16'd2 : 16'd1;
      INSTR_JRCC_LONG:  cycles = branch_taken ? 16'd3 : 16'd2;
      INSTR_JACC:       cycles = branch_taken ? 16'd3 : 16'd4;

      INSTR_JUMP_RS,
      INSTR_EXGPC,
      INSTR_BTST_RR,
      INSTR_PUSHST: cycles = 16'd2;

      INSTR_DSJ,
      INSTR_DSJEQ,
      INSTR_DSJNE:
        cycles = (dsj_precondition && dsj_rd_nonzero) ? 16'd3 : 16'd2;

      INSTR_DSJS: cycles = dsj_rd_nonzero ? 16'd2 : 16'd3;

      INSTR_SLA_K,
      INSTR_SLA_RR,
      INSTR_PUTST,
      INSTR_DINT,
      INSTR_EINT,
      INSTR_CALL_RS,
      INSTR_CALLR,
      INSTR_CVXYL: cycles = 16'd3;

      INSTR_SETF: cycles = instr_word[9] ? 16'd2 : 16'd1;
      INSTR_SEXT: cycles = 16'd3;
      INSTR_ZEXT: cycles = 16'd1;

      INSTR_POPST:  cycles = 16'd8;
      INSTR_RETS:   cycles = 16'd7;
      INSTR_CALLA:  cycles = 16'd4;
      INSTR_RETI:   cycles = 16'd11;
      INSTR_TRAP:   cycles = 16'd16;

      INSTR_MMTM:
        cycles = 16'd2 + ({11'd0, reg_list_count} << 2);
      INSTR_MMFM:
        cycles = 16'd3 + ({11'd0, reg_list_count} << 2);

      INSTR_MOVE_FIELD_STORE: begin
        if (force_pixel)
          cycles = xy_addr ? 16'd4 : 16'd2; // PIXT R,IXY / PIXT R,I
        else if (force_byte)
          cycles = 16'd1;                  // MOVB R,N
        else
          cycles = (move_mode == MV_ADDR_NONE) ? 16'd1 : 16'd2;
      end

      INSTR_MOVE_FIELD_LOAD: begin
        if (force_pixel)
          cycles = xy_addr ? 16'd6 : 16'd4; // PIXT IXY,R / PIXT I,R
        else if (force_byte)
          cycles = 16'd3;                  // MOVB N,R
        else
          cycles = (move_mode == MV_ADDR_NONE) ? 16'd3 : 16'd4;
      end

      INSTR_MOVE_FIELD_M2M: begin
        if (force_pixel)
          cycles = xy_addr ? 16'd7 : 16'd4; // PIXT IXY,IXY / PIXT I,I
        else if (force_byte)
          cycles = 16'd3;                  // MOVB N,N
        else
          cycles = 16'd4;
      end

      INSTR_MOVE_ABS_STORE: cycles = force_byte ? 16'd1 : 16'd3;
      INSTR_MOVE_ABS_LOAD:  cycles = 16'd5;
      INSTR_MOVE_OFF_STORE: cycles = 16'd3;
      INSTR_MOVE_OFF_LOAD:  cycles = 16'd5;
      INSTR_MOVE_ABS_M2M:   cycles = 16'd7;
      INSTR_MOVE_OFF_M2M:   cycles = 16'd5;
      INSTR_MOVE_OFF_NI:    cycles = 16'd5;

      INSTR_MPYS: cycles = 16'd20;
      INSTR_MPYU: cycles = 16'd21;
      INSTR_DIVU: cycles = 16'd37;
      INSTR_MODU: cycles = 16'd35;
      INSTR_DIVS: cycles = rd_odd ? 16'd39 : 16'd40;
      INSTR_MODS: cycles = 16'd40;

      INSTR_FILL_L,
      INSTR_FILL_XY,
      INSTR_PIXBLT_LL: begin
        cycles = gfx_cycles;
        valid  = gfx_cycles_valid;
      end

      INSTR_DRAV: cycles = 16'd4;
      INSTR_LINE: cycles = line_cycles;

      // All remaining implemented register/ALU/status classes are one cycle
      // in MAME's TMS34010 handler table.
      INSTR_MOVK,
      INSTR_ADD_RR,
      INSTR_SUB_RR,
      INSTR_AND_RR,
      INSTR_ANDN_RR,
      INSTR_OR_RR,
      INSTR_XOR_RR,
      INSTR_CMP_RR,
      INSTR_ADDK,
      INSTR_SUBK,
      INSTR_NEG,
      INSTR_NOT,
      INSTR_SLL_K,
      INSTR_SRA_K,
      INSTR_SRL_K,
      INSTR_RL_K,
      INSTR_MOVE_RR,
      INSTR_NOP,
      INSTR_ADDC_RR,
      INSTR_SUBB_RR,
      INSTR_ABS,
      INSTR_NEGB,
      INSTR_BTST_K,
      INSTR_CLRC,
      INSTR_SETC,
      INSTR_GETST,
      INSTR_SLL_RR,
      INSTR_SRA_RR,
      INSTR_SRL_RR,
      INSTR_RL_RR,
      INSTR_GETPC,
      INSTR_REV,
      INSTR_LMO_RR,
      INSTR_EXGF,
      INSTR_MOVX,
      INSTR_MOVY,
      INSTR_ADDXY,
      INSTR_SUBXY,
      INSTR_CMPXY,
      INSTR_CPW: cycles = 16'd1;

      default: begin
        cycles = 16'd1;
        valid  = 1'b0;
      end
    endcase
  end

endmodule

`default_nettype wire
