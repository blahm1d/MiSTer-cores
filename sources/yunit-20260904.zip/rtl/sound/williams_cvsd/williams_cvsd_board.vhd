---------------------------------------------------------------------------------
-- Williams cvsd board by Dar (darfpga@aol.fr)
--
-- Background sound and speech (D-11298) model
--
-- http://darfpga.blogspot.fr
-- https://sourceforge.net/projects/darfpga/files
-- github.com/darfpga
---------------------------------------------------------------------------------
-- gen_ram.vhd
-- Copyright 2005-2008 by Peter Wendrich (pwsoft@syntiac.com)
-- http://www.syntiac.com/fpga64.html
---------------------------------------------------------------------------------
-- MC6809
-- Copyright (c) 2016, Greg Miller
---------------------------------------------------------------------------------
-- HC55516/HC55564 Continuously Variable Slope Delta decoder
-- (c)2015 vlait
---------------------------------------------------------------------------------
-- JT51 (YM2151). <http://www.gnu.org/licenses/>.
-- Author: Jose Tejada Gomez. Twitter: @topapate
---------------------------------------------------------------------------------
-- Educational use only
-- Do not redistribute synthetized file with roms
-- Do not redistribute roms whatever the form
-- Use at your own risk
---------------------------------------------------------------------------------
-- Version 0.0 -- 25/03/2022 -- 
--		    initial version
---------------------------------------------------------------------------------
--  Features :
-- 
--  Use with MAME roms from joust2.zip
--
--  Connexions :
--
--     main board                        cvsd board 
--     pia_io2 pb_o   (IC5/2C - port B)  => sound_select
--     pia_io2 ca2_o  (IC5/2C - ca2)     => sound_trig
--
---------------------------------------------------------------------------------
--  Use make_joust2_proms.bat to build vhd file and bin from binaries
---------------------------------------------------------------------------------
---------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

entity williams_cvsd_board is
port(
 clock_12     : in std_logic;
 -- MAME-faithful reset split (williamssound.cpp reset_write / device_reset):
 -- the game-controlled sound-reset line halts ONLY the 6809 (+ returns the
 -- bank register to 0). The YM2151 / PIA / CVSD are NOT on that line — they
 -- reset only at power-on. Drive `reset` from the game latch (bit8) and
 -- `reset_pon` from the system power-on reset. (Tie them together to get the
 -- old whole-board behavior.)
 reset        : in std_logic;
 reset_pon    : in std_logic;
 
 sound_select : in std_logic_vector(7 downto 0);
 sound_trig   : in std_logic;
 game_id      : in std_logic_vector(3 downto 0);
 
 pia_audio    : out std_logic_vector( 7 downto 0);
 speech_out   : out std_logic_vector(15 downto 0);
 -- std_logic_vector for clean mixed-language binding (values are signed PCM)
 ym2151_left  : out std_logic_vector(15 downto 0);
 ym2151_right : out std_logic_vector(15 downto 0);
  
 dbg_out : out std_logic_vector(31 downto 0);

 -- MRA sound-ROM ioctl load (clk_sys / ioctl domain, async to clock_12). The
 -- 6809 is held in reset during the download, so the read side sees settled
 -- contents. addr(17:16) = chip select (00=U4 01=U19 10=U20); addr(15:0) = byte
 -- within the 64KB chip.
 snd_dl_clk  : in std_logic;
 snd_dl_addr : in std_logic_vector(17 downto 0);
 snd_dl_data : in std_logic_vector( 7 downto 0);
 snd_dl_we   : in std_logic;

 -- Large Y-unit CVSD sets use 128KB ROMs.  They are served from the shared
 -- SDRAM sound region; the original 64KB Smash/Trog path keeps its BRAMs.
 use_ext_rom  : in std_logic;
 ext_rom_addr : out std_logic_vector(20 downto 0);
 ext_rom_data : in std_logic_vector(7 downto 0);
 ext_rom_ok   : in std_logic

);
end williams_cvsd_board;

architecture struct of williams_cvsd_board is

-- jt51 component matching the vendored jt51 @4a47f66 (this revision has no
-- dacleft/dacright; full-resolution outs are xleft/xright). Vector ports are
-- std_logic_vector for clean Questa mixed-language default binding.
component jt51 is
port (
 rst   : in std_logic;    -- reset
 clk   : in std_logic;    -- main clock
 cen   : in std_logic;    -- clock enable (* direct_enable *)
 cen_p1: in std_logic;    -- clock enable at half the speed (* direct_enable *)
 cs_n  : in std_logic;    -- chip select
 wr_n  : in std_logic;    -- write
 a0    : in std_logic;
 din   : in  std_logic_vector(7 downto 0); -- data in
 dout  : out std_logic_vector(7 downto 0); -- data out
 -- peripheral control
 ct1   : out std_logic;
 ct2   : out std_logic;
 irq_n : out std_logic;    -- I do not synchronize this signal
 -- Low resolution output (same as real chip)
 sample: out std_logic;     -- marks new output sample
 left  : out std_logic_vector(15 downto 0);
 right : out std_logic_vector(15 downto 0);
 -- Full resolution output
 xleft  : out std_logic_vector(15 downto 0);
 xright : out std_logic_vector(15 downto 0)
); end component jt51;


component mc6809is is
port (
 CLK      : in  std_logic;
 fallE_en : in  std_logic;
 fallQ_en : in  std_logic;

 OP     : in  std_logic_vector(7 downto 0); -- Konami-1 opcode port (unused
                                            -- with default generics; tied =D)
 D      : in  std_logic_vector(7 downto 0);
 DOut   : out std_logic_vector(7 downto 0);
 ADDR   : out std_logic_vector(15 downto 0);
 RnW    : out std_logic;
 BS     : out std_logic;
 BA     : out std_logic;

 nIRQ   : in  std_logic := '1';
 nFIRQ  : in  std_logic := '1';
 nNMI   : in  std_logic := '1';
	
 AVMA   : out std_logic;
 BUSY   : out std_logic;
 LIC    : out std_logic;
	
 nHALT  : in  std_logic := '1';
 nRESET : in  std_logic := '1';
	
 nDMABREQ: in std_logic := '1';
 RegData : out std_logic_vector(111 downto 0)
);
end component mc6809is;

 signal en_cnt  : std_logic := '0'; 
 signal div_cnt : std_logic_vector(1 downto 0) := "00";

 -- JT51's area-saving shift registers clear by shifting their reset value
 -- through on enabled clocks; the longest chain needs 32 cen_p1 pulses.
 -- Hold the complete sound board for 511 clock_12 cycles after reset release,
 -- which supplies about 76 cen_p1 pulses even after an unusually short host
 -- reset and keeps the CPU from programming a still-reset synthesizer.
 signal pon_count     : unsigned(8 downto 0) := (others => '1');
 signal reset_pon_snd : std_logic := '1';

 signal rom_bank_cs  : std_logic;
 
 signal cpu_addr   : std_logic_vector(15 downto 0);
 signal cpu_di     : std_logic_vector( 7 downto 0);
 signal cpu_do     : std_logic_vector( 7 downto 0);
 signal cpu_rw_n   : std_logic;
 signal write_n    : std_logic;

 signal reset_n    : std_logic;
 signal cpu_firq_n : std_logic;
 signal cpu_nmi_n  : std_logic;
 signal cpu_e_en   : std_logic;
 signal cpu_q_en   : std_logic;
 signal ext_ok_meta : std_logic := '0';
 signal ext_ok_snd  : std_logic := '0';
 signal cpu_rom_wait: std_logic;
  
 signal page_cs         : std_logic;
 -- Smash TV adaptation (Arcade-SmashTV): the Y-unit CVSD bank register is 4
 -- bits (MAME williamssound.cpp bank_select_w: data & 0x0f) — D0/D1 select the
 -- chip (0=U4 1=U19 2=U20), D2 = chip A15, D3 = chip A16 (mirror on these
 -- 64KB chips, matching the driver's ROM_RELOADs). joust2 used 3 bits with
 -- 32KB chips; Smash TV needs page(2) as A15 into 64KB chips.
 signal page            : std_logic_vector( 3 downto 0);
 signal ext_rom_addr_r : std_logic_vector(20 downto 0) := (others => '0');
signal rom_cs          : std_logic;
 signal rom_chip_addr   : std_logic_vector(15 downto 0);
 signal rom_bank_a_do   : std_logic_vector( 7 downto 0);
 signal rom_bank_b_do   : std_logic_vector( 7 downto 0);
 signal rom_bank_c_do   : std_logic_vector( 7 downto 0);

 -- per-chip ioctl write-enable (decoded from the download chip-select bits)
 signal snd_we_a        : std_logic;
 signal snd_we_b        : std_logic;
 signal snd_we_c        : std_logic;

 -- Each Y-unit game installs a tiny writable window over the banked ROM.
 -- THE TWO MECHANISMS ARE NOT THE SAME AND MUST NOT BE COLLAPSED:
 --
 --  * CVSD_SMALL (Smash T.V., Trog, Strike Force) -- midyunit_m.cpp:296-306
 --    installs cvsd_protection_w (midyunit_m.cpp:230-237) as a WRITE handler
 --    only, and the byte lands in the BANK 0 ROM IMAGE
 --    (m_cvsd_protection_base = "cvsd:cpu" + 0x10000 + (prot_start - 0x8000);
 --    bank 0 is exactly rom[0x10000..0x17fff] -- williamssound.cpp:213-227
 --    device_start).  READS ARE NOT INTERCEPTED: they still go through the
 --    bank, so the written value is visible ONLY while bank 0 is selected
 --    (bank = data and 0x0f, williamssound.cpp:127-130 bank_select_w), and a
 --    read before any write returns the underlying bank-0 ROM byte.
 --
 --  * CVSD large (High Impact, Super High Impact) -- midyunit_m.cpp:308-310
 --    calls install_hidden_ram (midyunit_m.cpp:239-245), which install_ram()s
 --    over the window and REPLACES the ROM mapping in every bank; the block is
 --    value-initialised, so a read before any write returns 0x00, not ROM.
 --
 -- MEASURED WHY THIS MATTERS (Smash T.V.): the sound program clears the whole
 -- window at boot -- U4 bank 0, cpu $9cb1: 8e 9c f6 (LDX #$9CF6) / 6f 80
 -- (CLR ,X+) / 8c 9d 21 (CMPX #$9D21) / 26 f9 (BNE) -- so prot_valid goes all
 -- ones on every boot.  Bank 0 holds 0xFF filler at $9cf6-$9d20 (spare ROM,
 -- which is the point of the hack) but banks 1/2/4/5/6 hold dense CVSD sample
 -- data there.  A bank-unconditional read override therefore forced 44 bytes of
 -- EVERY speech page to 0x00 for the rest of the session.
 type prot_ram_t is array (0 to 63) of std_logic_vector(7 downto 0);
 -- Power-on value 0x00 == MAME's value-initialised install_hidden_ram block.
 -- Nothing in williamssound.cpp reset_write clears it, so no reset does here.
 signal prot_ram         : prot_ram_t := (others => (others => '0'));
 signal prot_valid       : std_logic_vector(63 downto 0) := (others => '0');
 signal prot_hit         : std_logic;
 signal prot_large       : std_logic;
 signal prot_read        : std_logic;
 signal prot_index       : integer range 0 to 63;

 component smashtv_snd_rom
  generic ( HEX : string );
  port (
   clk   : in  std_logic;
   addr  : in  std_logic_vector(15 downto 0);
   data  : out std_logic_vector(7 downto 0);
   wrclk : in  std_logic;
   we    : in  std_logic;
   waddr : in  std_logic_vector(15 downto 0);
   wdata : in  std_logic_vector(7 downto 0)
  );
 end component;

 signal sram_cs        : std_logic;
 signal sram_we        : std_logic;
 signal sram_do        : std_logic_vector( 7 downto 0);
 
 signal cvsd1_cs   : std_logic;
 signal cvsd2_cs   : std_logic;
 signal cvsd_data  : std_logic;
 signal cvsd_clk   : std_logic;
 signal cvsd_cnt   : std_logic_vector(15 downto 0);

 signal pia_clock  : std_logic;

 signal pia_cs     : std_logic;
 signal pia_we_n   : std_logic;
 signal pia_do     : std_logic_vector( 7 downto 0);
-- signal pia_pa_o   : std_logic_vector( 7 downto 0);
 signal pia_irqa   : std_logic;
 signal pia_irqb   : std_logic;
 
 signal ym2151_irq_n  : std_logic := '0';
 signal ym2151_cs_n   : std_logic;
 signal ym2151_do     : std_logic_vector( 7 downto 0);
 signal ym2151_we_n   : std_logic;
 signal ym2151_sample : std_logic;
 
 signal lim       : unsigned(9 downto 0);
 signal cnt_max   : unsigned(9 downto 0);
 signal next_cnt  : unsigned(9 downto 0);
 signal next_cnt2 : unsigned(9 downto 0);
 signal cen_cnt   : unsigned(9 downto 0) := "0000000000";
 signal alt       : std_logic := '0';
 signal cen_1p78  : std_logic := '0';
 signal cen_3p57  : std_logic := '0';
 
begin

process (clock_12, reset_pon)
begin
	if reset_pon = '1' then
		pon_count     <= (others => '1');
		reset_pon_snd <= '1';
	elsif rising_edge(clock_12) then
		if pon_count /= 0 then
			pon_count     <= pon_count - 1;
			reset_pon_snd <= '1';
		else
			reset_pon_snd <= '0';
		end if;
	end if;
end process;

-- for debug
process (clock_12) 
begin
	if rising_edge(clock_12) then 
		dbg_out(15 downto 0) <= cpu_addr;
		dbg_out(23 downto 16) <= cpu_di;
		dbg_out(24) <= ym2151_irq_n;   -- YM timer IRQ (the sound engine's heartbeat)
		dbg_out(25) <= cpu_firq_n;     -- FIRQ into the 6809 (PIA IRQA <- CA1 <- YM)
		dbg_out(26) <= cpu_nmi_n;      -- NMI  into the 6809 (PIA IRQB <- CB1 latch)
		dbg_out(27) <= ym2151_we_n;    -- low on a real YM register/data write
		dbg_out(31 downto 28) <= page; -- active 6809 ROM bank
	end if;
end process;

-- 
reset_n    <= not (reset or reset_pon_snd);  -- 6809 halts until all sound devices are initialized
cpu_rom_wait <= '1' when use_ext_rom = '1' and rom_cs = '1' and
                         cpu_rw_n = '1' and
                         (ext_rom_ok = '0' or ext_ok_snd = '0') else '0';

-- The SDRAM cache-valid indication is generated at 96 MHz. Synchronize it
-- before it controls the 12 MHz CPU enables; the associated ROM byte remains
-- stable for the complete valid interval.
process(clock_12)
begin
	if rising_edge(clock_12) then
		if reset_pon_snd = '1' or use_ext_rom = '0' then
			ext_ok_meta <= '0';
			ext_ok_snd <= '0';
		else
			ext_ok_meta <= ext_rom_ok;
			ext_ok_snd <= ext_ok_meta;
		end if;
	end if;
end process;
		
-- make cpu clocks 2MHz (12MHz/6)
-- in original hardware 2MHz from 8MHz/4
--             _   _   _   _   _
-- en_cnt   |_| |_| |_| |_| |_| | ...  (6MHz)
--
-- div_cnt  | 0 | 1 | 2 | 0 | 1 | ...
--               _           _
-- cpu_e_en  ___| |_________| |__ ...
--           _           _        
-- cpu_q_en | |_________| |______ ...
--          ______ ___________ __
-- cpu_do   ______|___________|__ ...
--          __________     ______
-- write_n            |___|       ...

process (reset, clock_12)
begin
	if rising_edge(clock_12) then
	
		write_n  <= '1';
		cpu_e_en <= '0';
		cpu_q_en <= '0';

		-- Hold the complete E/Q phase generator on an external-ROM cache miss.
		-- The address remains stable while the 96 MHz SDRAM side fetches it.
		if cpu_rom_wait = '0' then
			en_cnt <= not en_cnt;
			if en_cnt = '1' then
				if div_cnt = "10" then
					div_cnt <= "00";
				else
					div_cnt <= div_cnt + '1';
				end if;

				-- place E and Q falling edge for MC6809
				if div_cnt = "00" then cpu_e_en <= '1'; end if;
				if div_cnt = "10" then cpu_q_en <= '1'; end if;
			end if;
		end if;

		-- center cpu write pulse 
		if div_cnt = "10" then write_n <= cpu_rw_n; end if;

		-- synchronize interruptions
		if  div_cnt = "01" then
			cpu_nmi_n  <= not pia_irqb;
			cpu_firq_n <= not pia_irqa;
		end if;
		
	end if;
end process;

pia_clock <= not clock_12;

-- chip select/we
sram_cs      <= '1' when cpu_addr(15 downto 13) = "000"   else '0'; -- 0000-1FFF
ym2151_cs_n  <= '0' when cpu_addr(15 downto 13) = "001"   else '1'; -- 2000-3FFF
pia_cs       <= '1' when cpu_addr(15 downto 13) = "010"   else '0'; -- 4000-5FFF
cvsd1_cs     <= '1' when cpu_addr(15 downto 11) = "01100" else '0'; -- 6000-67FF
cvsd2_cs     <= '1' when cpu_addr(15 downto 11) = "01101" else '0'; -- 6800-6FFF
page_cs      <= '1' when cpu_addr(15 downto 11) = "01111" else '0'; -- 7800-7FFF
rom_cs       <= '1' when cpu_addr(15)           = '1';              -- 8000-FFFF
 
sram_we       <= '1' when write_n = '0' and sram_cs     = '1' else '0';
pia_we_n      <= '0' when write_n = '0' and pia_cs      = '1' else '1';
ym2151_we_n   <= '0' when write_n = '0' and ym2151_cs_n = '0' else '1';

-- mux data to cpu di
cpu_di <=
	cpu_do        when cpu_rw_n = '0' else 
	sram_do		  when sram_cs = '1' else
	ym2151_do	  when ym2151_cs_n = '0' else
	pia_do	     when pia_cs = '1' else
	prot_ram(prot_index) when prot_read = '1' else
	ext_rom_data  when rom_cs = '1' and use_ext_rom = '1' else
	rom_bank_a_do when rom_cs = '1' and page(1 downto 0) = "00" else
	rom_bank_b_do when rom_cs = '1' and page(1 downto 0) = "01" else
	rom_bank_c_do when rom_cs = '1' and page(1 downto 0) = "10" else
	X"00";

-- MAME midyunit_m.cpp init_* protection windows AND mechanism:
--   0000 Smash T.V.        9cf6-9d21  SOUND_CVSD_SMALL  midyunit_m.cpp:374
--   0001 Trog              9eaf-9ed9  SOUND_CVSD_SMALL  midyunit_m.cpp:365
--   0010 High Impact       9b79-9ba3  SOUND_CVSD (RAM)  midyunit_m.cpp:394
--   0011 Super High Impact 9c06-9c15  SOUND_CVSD (RAM)  midyunit_m.cpp:412
--   0100 Strike Force      9f7d-9fa7  SOUND_CVSD_SMALL  midyunit_m.cpp:428
--   1000 Y-unit test ROM   9c06-9c15  SOUND_CVSD (RAM)  init_shimpact,
--        midyunit.cpp:3916 / midyunit_m.cpp:400-412
process(game_id, cpu_addr)
	variable a, first_addr, last_addr : integer;
begin
	a := to_integer(unsigned(cpu_addr));
	first_addr := 0;
	last_addr := -1;
	case game_id is
		when "0000" => first_addr := 16#9cf6#; last_addr := 16#9d21#;
		when "0001" => first_addr := 16#9eaf#; last_addr := 16#9ed9#;
		when "0010" => first_addr := 16#9b79#; last_addr := 16#9ba3#;
		when "0011" => first_addr := 16#9c06#; last_addr := 16#9c15#;
		when "0100" => first_addr := 16#9f7d#; last_addr := 16#9fa7#;
		when "1000" => first_addr := 16#9c06#; last_addr := 16#9c15#;
		when others => null;
	end case;
	if a >= first_addr and a <= last_addr then
		prot_hit <= '1';
		prot_index <= a - first_addr;
	else
		prot_hit <= '0';
		prot_index <= 0;
	end if;
end process;

-- Mechanism select (see the block comment on prot_ram above).
prot_large <= '1' when game_id = "0010" or game_id = "0011" or
                           game_id = "1000" else '0';

-- READ OVERRIDE.
--  large: install_ram() replaces the mapping in every bank, and a read before
--         the first write sees the zero-initialised block -> unconditional.
--  small: cvsd_protection_w only writes bank 0's ROM image, so the value is
--         visible ONLY with bank 0 selected, and only after a write.
prot_read <= '1' when prot_hit = '1' and
                      (prot_large = '1' or
                       (page = "0000" and prot_valid(prot_index) = '1'))
             else '0';

-- WRITE. Unconditional in both models: MAME installs the small-board write
-- handler over the sound CPU's whole address space (midyunit_m.cpp:304), so a
-- write from any bank lands in bank 0's image.
process(clock_12)
begin
	if rising_edge(clock_12) then
		if reset_pon_snd = '1' then
			prot_valid <= (others => '0');
		elsif write_n = '0' and prot_hit = '1' then
			prot_ram(prot_index) <= cpu_do;
			prot_valid(prot_index) <= '1';
		end if;
	end if;
end process;
	
-- page register, cvsd clock and data
process (reset, reset_pon_snd, clock_12)
begin
	if (reset or reset_pon_snd)='1' then   -- MAME: reset_write also does bank_select_w(0)
		page <= "0000";
		cvsd_data <= '0';
		cvsd_clk  <= '0';
	else
		if rising_edge(clock_12) then
			if page_cs = '1' and write_n = '0' then page <= cpu_do(3 downto 0); end if;  -- Smash TV: 4-bit bank (MAME data & 0x0f)
			if cvsd1_cs = '1' then cvsd_data <= cpu_do(0); end if;
			if cvsd1_cs = '1' then cvsd_clk <= '0';        end if;
			if cvsd2_cs = '1' then cvsd_clk <= '1';        end if;			
		end if;
	end if;
end process;

-- microprocessor 6809 -IC28
--main_cpu : entity work.cpu09
--port map(	
--	clk      => en_cpu,   -- E clock input (falling edge)
--	rst      => reset,    -- reset input (active high)
--	vma      => open,     -- valid memory address (active high)
-- lic_out  => open,     -- last instruction cycle (active high)
-- ifetch   => open,     -- instruction fetch cycle (active high)
-- opfetch  => open,     -- opcode fetch (active high)
-- ba       => open,     -- bus available (high on sync wait or DMA grant)
-- bs       => open,     -- bus status (high on interrupt or reset vector fetch or DMA grant)
--	addr     => cpu_addr, -- address bus output
--	rw       => cpu_rw_n, -- read not write output
--	data_out => cpu_do,   -- data bus output
--	data_in  => cpu_di,   -- data bus input
--	irq      => '0',      -- interrupt request input (active high)
--	firq     => cpu_firq, -- fast interrupt request input (active high)
--	nmi      => cpu_nmi,  -- non maskable interrupt request input (active high)
--	halt     => '0',      -- halt input (active high) grants DMA
--	hold     => '0'       -- hold input (active high) extend bus cycle
--);

-- microprocessor 6809 - IC28
main_cpu : mc6809is
port map (
 CLK      => clock_12, -- : in  std_logic;
 fallE_en => cpu_e_en, -- : in  std_logic;
 fallQ_en => cpu_q_en, -- : in  std_logic;

 OP       => cpu_di,   -- Konami-1 port, unused with default generics
 D        => cpu_di,   -- : in  std_logic_vector(7 downto 0);
 DOut     => cpu_do,   -- : out std_logic_vector(7 downto 0);
 ADDR     => cpu_addr, -- : out std_logic_vector(15 downto 0); 
 RnW      => cpu_rw_n, -- : out std_logic;
 BS       => open,     -- : out std_logic;
 BA       => open,     -- : out std_logic;

 nIRQ     => '1',        -- : in  std_logic := '1';
 nFIRQ    => cpu_firq_n, -- : in  std_logic := '1';
 nNMI     => cpu_nmi_n,  -- : in  std_logic := '1';
	
 AVMA     => open,   -- : out std_logic;
 BUSY     => open,   -- : out std_logic;
 LIC      => open,   -- : out std_logic;
	
 nHALT    => '1',    -- : in  std_logic := '1'
 nRESET   => reset_n,-- : in  std_logic := '1';
	
 nDMABREQ => '1',    -- : in std_logic := '1';
 RegData  => open    -- : out std_logic_vector(111 downto 0);
);

-- Smash TV (Y-unit) sound ROMs: 64KB chips; the CPU's 32KB banked window
-- (0x8000-0xFFFF) selects the half via page(2) = A15 (page(3) = A16 mirrors
-- on 64KB parts). Chip select stays page(1:0) in the cpu_di mux below.
rom_chip_addr <= page(2) & cpu_addr(14 downto 0);
-- QUALIFY THE EXTERNAL ROM REQUEST WITH rom_cs.
-- This was driven straight off cpu_addr with no rom_cs qualifier, so it moved on EVERY
-- 6809 bus cycle -- including RAM and I/O accesses, which are not ROM reads at all. The
-- shared yunit_sound_rom_cache keys on this address, so each of those looked like a miss
-- and launched a useless SDRAM fetch.
--
-- CABINET-MEASURED consequence, on the three titles that stream sound from SDRAM
-- (High Impact / Super High Impact / Y-Unit Test ROM -- the CVSD_LARGE 3x128 KiB sets
-- that cannot be BRAM-resident): all silent, sprites flashing, and the Test ROM's HARSH
-- DMA test never advances past NORMAL. One cause, three symptoms -- the spurious traffic
-- saturates the single SDRAM port so the blitter cannot finish a blit, while the cache
-- thrash stalls the 6809 so no sound is produced.
--
-- Holding the last ROM address across non-ROM cycles keeps the cache's key stable, so a
-- sequential run of real ROM reads hits instead of missing.
--
-- SCOPE: ext_rom_addr is consumed ONLY when use_ext_rom = '1'. The BRAM-resident titles
-- (Smash T.V., Trog, Strike Force, Saurian Front) tie it low and cannot be affected.
process(clock_12)
begin
	if rising_edge(clock_12) then
		if rom_cs = '1' then
			ext_rom_addr_r <= "00" & page(1 downto 0) & page(3 downto 2) & cpu_addr(14 downto 0);
		end if;
	end if;
end process;
ext_rom_addr <= ext_rom_addr_r;

-- ioctl download chip-select decode (addr(17:16): 00=U4 01=U19 10=U20)
snd_we_a <= snd_dl_we when snd_dl_addr(17 downto 16) = "00" else '0';
snd_we_b <= snd_dl_we when snd_dl_addr(17 downto 16) = "01" else '0';
snd_we_c <= snd_dl_we when snd_dl_addr(17 downto 16) = "10" else '0';

-- rom0 IC_U4
bank_a_rom : smashtv_snd_rom
generic map ( HEX => "build/snd_u4.hex" )
port map(
 clk   => clock_12,
 addr  => rom_chip_addr,
 data  => rom_bank_a_do,
 wrclk => snd_dl_clk,
 we    => snd_we_a,
 waddr => snd_dl_addr(15 downto 0),
 wdata => snd_dl_data
);

-- rom1 IC_U19
bank_b_rom : smashtv_snd_rom
generic map ( HEX => "build/snd_u19.hex" )
port map(
 clk   => clock_12,
 addr  => rom_chip_addr,
 data  => rom_bank_b_do,
 wrclk => snd_dl_clk,
 we    => snd_we_b,
 waddr => snd_dl_addr(15 downto 0),
 wdata => snd_dl_data
);

-- rom2 IC_U20
bank_c_rom : smashtv_snd_rom
generic map ( HEX => "build/snd_u20.hex" )
port map(
 clk   => clock_12,
 addr  => rom_chip_addr,
 data  => rom_bank_c_do,
 wrclk => snd_dl_clk,
 we    => snd_we_c,
 waddr => snd_dl_addr(15 downto 0),
 wdata => snd_dl_data
);

-- sram IC U3
sram : entity work.gen_ram
generic map( dWidth => 8, aWidth => 11)
port map(
 clk  => clock_12,
 we   => sram_we,
 addr => cpu_addr(10 downto 0),
 d    => cpu_do,
 q    => sram_do
);

-- pia IC_U2
pia : entity work.pia6821
port map
(	
	clk       	=> pia_clock,           -- rising edge
	rst       	=> reset_pon_snd,       -- power-on only, locally stretched for deterministic startup
	cs        	=> pia_cs,
	rw        	=> pia_we_n,            -- write low
	addr      	=> cpu_addr(1 downto 0),
	data_in   	=> cpu_do,
	data_out  	=> pia_do,
	irqa      	=> pia_irqa,            -- active high
	irqb      	=> pia_irqb,            -- active high
	pa_i      	=> x"00",
	pa_o        => pia_audio,
	pa_oe       => open,
	ca1       	=> ym2151_irq_n,
	ca2_i      	=> '0',
	ca2_o       => open,
	ca2_oe      => open,
	pb_i      	=> sound_select,
	pb_o        => open,
	pb_oe       => open,
	cb1       	=> sound_trig,
	cb2_i      	=> '0',
	cb2_o       => open,
	cb2_oe      => open
);

-- CVSD speech decoder	
cvsd : entity work.HC55564	
port map(	
	clk => clock_12,
	cen => cvsd_clk,
	rst => reset_pon_snd,
	bit_in => cvsd_data,
	sample_out(15 downto 0) => speech_out
);

-- YM2151 : FM Clocks -- phase-accumulator cen from the 12 MHz clk_snd.
-- EXACT: the YM2151 runs at the NTSC colorburst 315/88 MHz = 3.579545... MHz. From 12 MHz that is
-- exactly 105/352 (315/1056 reduced), so inc=105 / mod=352 gives 12e6*105/352 = 3.579545454 MHz on
-- the nose. (The old inc=152 / mod=512 gave 3.5625 MHz, 0.48% low.) cen_cnt stays < 352 (< the 10-bit
-- width). cen_1p78 (jt51 cen_p1) is the half-rate toggle, unchanged.
lim       <= to_unsigned(352,10);
cnt_max   <= to_unsigned(352+105,10);

next_cnt  <= cen_cnt + to_unsigned(105,10);
next_cnt2 <= cen_cnt + to_unsigned(105,10) - to_unsigned(352,10);

process (clock_12)
begin
	if rising_edge(clock_12) then
		cen_3p57 <= '0';
		cen_1p78 <= '0';

		if cen_cnt >= cnt_max then 
			cen_cnt <= (others => '0');
			alt <= '0';
		else		
			if next_cnt >= lim then
				cen_cnt <= next_cnt2;
				cen_3p57 <= '1';
				alt <= not alt;
				cen_1p78 <= alt;
			else
				cen_cnt <= next_cnt;
			end if;
		end if;
			
	end if;
end process;


-- YM2151
jt51_if : jt51
port map (

 rst    => reset_pon_snd, -- power-on only; long enough to flush JT51 reset shift chains
 clk    => clock_12,      -- main clock
 cen    => cen_3p57,      -- clock enable (* direct_enable *)
 cen_p1 => cen_1p78,      -- clock enable at half the speed (* direct_enable *)
 cs_n   => ym2151_cs_n,   -- chip select
 wr_n   => ym2151_we_n,   -- write
 a0     => cpu_addr(0),  
 din    => cpu_do,        -- data in
 dout   => ym2151_do,     -- data out
 -- peripheral control
 ct1   => open,
 ct2   => open,
 irq_n => ym2151_irq_n,   -- I do not synchronize this signal
 
 -- Low resolution output (same as real chip)
 sample => ym2151_sample, -- marks new output sample
 left   => open,
 right  => open,
 -- Full resolution output (this jt51 revision has no dac* ports)
 xleft  => ym2151_left,
 xright => ym2151_right
);

end struct;
