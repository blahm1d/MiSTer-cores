//
// sdram_stock.sv — the stock MiSTer SDRAM controller (Sorgelig, GPLv3), vendored for
// Arcade-SmashTV to replace the hand-rolled sdram_phy. DE10-proven single 16-bit port
// (addr/din/dout/wtbt/we/rd/ready), CAS-latency shift-register read capture, and — the key
// fix — it forwards SDRAM_CLK via an altddio_out I/O cell (NOT a fabric assign), so reads
// land in the valid window on real silicon. Bridged to the yunit arbiter by
// yunit_sdram_adapter.
//
// Original: Copyright (c) 2015-2019 Sorgelig. GNU GPLv3.
// Local changes: module renamed to `sdram_stock`; all declarations hoisted to module level
// (Questa rejects the upstream in-always initialized vars + forward-referenced `command`);
// the SDRAM_CLK DDIO is guarded (SIM_NO_ALTERA) so the behavioral sim needs no altera_mf.
//
module sdram_stock
(
   input             init,
   input             clk,         // ~96-100 MHz (CAS_LATENCY=2 for <100 MHz)

   inout      [15:0] SDRAM_DQ,
   output reg [12:0] SDRAM_A,
   output reg        SDRAM_DQML,
   output reg        SDRAM_DQMH,
   output reg  [1:0] SDRAM_BA,
   output            SDRAM_nCS,
   output            SDRAM_nWE,
   output            SDRAM_nRAS,
   output            SDRAM_nCAS,
   output            SDRAM_CKE,
   // NOTE: SDRAM_CLK is NOT driven here. The emu forwards it from the phase-shifted PLL
   // output (clk_sdram, outclk_1, -3515ps) exactly like the proven tecmo/jtframe cores —
   // and rtl/sdram.sdc sources the SDRAM_CLK generated clock from that same general[1]
   // output. (An earlier build drove SDRAM_CLK from a DDIO on clk_sys here, which did NOT
   // match the SDC's general[1] source -> STA closed the read window against the wrong
   // clock edge -> garbage reads on silicon. Reverted to the proven clk_sdram forward.)

   input       [1:0] wtbt,        // write byte mask: [1]=high, [0]=low
   input      [24:0] addr,        // BYTE address; addr[0]=0 for 16-bit accesses
   output     [15:0] dout,
   input      [15:0] din,
   input             we,
   input             rd,
   output reg        ready,

   // P2b (cont.23): PAGE-MODE BURST READ for scanout. brd_req (held until brd_done) reads brd_len
   // consecutive words starting at brd_addr with ONE ACTIVATE (no per-word re-ACTIVATE / auto-
   // precharge) -> ~1 clk/word. brd_addr must stay within one SDRAM row: with the P2a col=word[8:0]
   // split, brd_len<=512 words that don't cross a 512-word (col) boundary = exactly one VRAM
   // scanline. Streamed out on brd_dout/brd_dvalid (one pulse per word, in order), then brd_done.
   // Mutually exclusive with the single-beat path (they share the pins; the system arbiter
   // serializes), so single-beat behavior is unchanged when brd_req is idle.
   input             brd_req,
   input      [24:0] brd_addr,    // BYTE start address (word-aligned; col-aligned run start)
   input      [9:0]  brd_len,     // words to read (1..512)
   output reg [15:0] brd_dout,
   output reg        brd_dvalid,  // 1-cycle strobe per streamed word
   output reg        brd_done,    // 1-cycle burst-complete strobe

   // Page-mode burst write. bwr_req is edge-latched and held by the caller
   // until bwr_done. Once the row is open, every bwr_valid && bwr_ready edge
   // writes one consecutive 16-bit word. Producer stalls leave the row open
   // and issue NOPs. The run must remain within one 512-word SDRAM row.
   input             bwr_req,
   input      [24:0] bwr_addr,    // BYTE start address, word aligned
   input      [9:0]  bwr_len,     // words to write (1..512)
   input      [15:0] bwr_din,
   input       [1:0] bwr_wtbt,    // asserted byte lanes: 11=full word
   input             bwr_valid,
   output            bwr_ready,
   output reg        bwr_done     // 1-cycle burst-complete strobe
);

localparam BURST_LENGTH        = 3'b000;
localparam ACCESS_TYPE         = 1'b0;
localparam CAS_LATENCY         = 3'd2;     // 2 for < 100MHz
localparam OP_MODE             = 2'b00;
localparam NO_WRITE_BURST      = 1'b1;
localparam MODE                = {3'b000, NO_WRITE_BURST, OP_MODE, CAS_LATENCY, ACCESS_TYPE, BURST_LENGTH};

localparam sdram_startup_cycles= 14'd12100;
localparam cycles_per_refresh  = 14'd780;
localparam startup_refresh_max = 14'b11111111111111;

localparam [2:0] CMD_NOP          = 3'b111;
localparam [2:0] CMD_ACTIVE       = 3'b011;
localparam [2:0] CMD_READ         = 3'b101;
localparam [2:0] CMD_WRITE        = 3'b100;
localparam [2:0] CMD_PRECHARGE    = 3'b010;
localparam [2:0] CMD_AUTO_REFRESH = 3'b001;
localparam [2:0] CMD_LOAD_MODE    = 3'b000;

typedef enum {
	STATE_STARTUP,
	STATE_OPEN_1, STATE_OPEN_2,
	STATE_IDLE, STATE_IDLE_1, STATE_IDLE_2, STATE_IDLE_3,
	STATE_IDLE_4, STATE_IDLE_5, STATE_IDLE_6, STATE_IDLE_7,
	STATE_BR_ACT, STATE_BR_RD, STATE_BR_DRAIN, STATE_BR_PRE,
	STATE_BW_ACT, STATE_BW_WR, STATE_BW_REC1, STATE_BW_REC2,
	STATE_BW_PRE
} state_t;

// all state hoisted to module level (declared before use)
reg  [2:0]  command;
reg  [13:0] refresh_count = startup_refresh_max - sdram_startup_cycles;
reg  [24:0] save_addr;
reg  [15:0] data;
reg         old_we, old_rd;
reg  [CAS_LATENCY+1:0] data_ready_delay;   // +1 stage vs stock: DQ is now sampled through the
reg  [15:0] dq_r;                           // dedicated pin-adjacent input register dq_r below, so
                                            // the capture window fires one clk later to match.
reg  [15:0] new_data;
reg  [1:0]  new_wtbt;
reg         new_we;
reg         new_rd;
reg         save_we = 1'b1;
state_t     state = STATE_STARTUP;
reg  [15:0] sdram_dq_out;                 // DQ drive value + tristate enable (Questa rejects
reg         sdram_dq_oe;                  // a procedurally-driven inout net, so gate it here)
// P2b page-mode burst-read state (separate from the single-beat regs so single-beat is untouched)
reg                    old_brd, new_brd;
reg  [12:0]            brd_row;
reg  [1:0]             brd_bank;
reg  [8:0]             brd_col;           // current column within the open row (0..511)
reg  [9:0]             brd_i;             // words issued so far
reg  [9:0]             brd_len_l;         // latched length
reg  [CAS_LATENCY+1:0] brd_vdelay;        // read-valid pipe, mirrors data_ready_delay for the stream
wire                   brd_issue = (state == STATE_BR_RD) && (brd_i < brd_len_l);
// Page-mode burst-write state. A request is captured independently of the
// single-beat slot, then serviced atomically after any earlier burst read.
reg                    old_bwr, new_bwr;
reg  [12:0]            bwr_row;
reg  [1:0]             bwr_bank;
reg  [8:0]             bwr_col;
reg  [9:0]             bwr_i;
reg  [9:0]             bwr_len_l;
wire                   bwr_beat =
	(state == STATE_BW_WR) && (bwr_i < bwr_len_l) && bwr_valid;
assign bwr_ready = (state == STATE_BW_WR) && (bwr_i < bwr_len_l);

assign SDRAM_DQ   = sdram_dq_oe ? sdram_dq_out : 16'bZ;
assign SDRAM_CKE  = 1;
assign SDRAM_nCS  = 0;
assign SDRAM_nRAS = command[2];
assign SDRAM_nCAS = command[1];
assign SDRAM_nWE  = command[0];
assign {SDRAM_DQMH,SDRAM_DQML} = SDRAM_A[12:11];
assign dout = save_addr[0] ? {data[7:0], data[15:8]} : {data[15:8], data[7:0]};

always @(posedge clk) begin
	sdram_dq_oe <= 1'b0;                   // release the DQ bus by default
	command <= CMD_NOP;
	refresh_count  <= refresh_count+1'b1;

	// Capture DQ into a dedicated register whose ONLY driver is the pin, unconditionally, every
	// clk. With FAST_INPUT_REGISTER ON -to SDRAM_DQ[*] (in the .qsf) Quartus packs this flop into
	// the pin's IOE input register (right next to the ball), so setup/hold is fixed by the device,
	// not by whatever fabric route Quartus happened to pick — the read-margin fix. The stock
	// controller sampled SDRAM_DQ straight into `data` CONDITIONALLY, and `data` also feeds the
	// byte-swap `dout`, so the fitter could never IOE-pack it and the capture floated in fabric.
	dq_r <= SDRAM_DQ;
	data_ready_delay <= {1'b0, data_ready_delay[CAS_LATENCY+1:1]};
	if(data_ready_delay[0]) {ready, data} <= {1'b1, dq_r};

	// P2b burst-read capture: same dq_r + delay timing as single-beat, but a per-word valid pipe
	// (brd_issue injected at the READ cycle, popped CAS_LATENCY+1 cycles later onto brd_dout).
	brd_dvalid <= 1'b0;
	brd_done   <= 1'b0;
	bwr_done   <= 1'b0;
	brd_vdelay <= {brd_issue, brd_vdelay[CAS_LATENCY+1:1]};
	if(brd_vdelay[0]) begin brd_dvalid <= 1'b1; brd_dout <= dq_r; end

	case(state)
		STATE_STARTUP: begin
			SDRAM_A    <= 0;
			SDRAM_BA   <= 0;
			if (refresh_count == startup_refresh_max-31) begin command <= CMD_PRECHARGE; SDRAM_A[10] <= 1; SDRAM_BA <= 2'b00; end
			if (refresh_count == startup_refresh_max-23) command <= CMD_AUTO_REFRESH;
			if (refresh_count == startup_refresh_max-15) command <= CMD_AUTO_REFRESH;
			if (refresh_count == startup_refresh_max-7)  begin command <= CMD_LOAD_MODE; SDRAM_A <= MODE; end
			if(!refresh_count) begin state <= STATE_IDLE; ready <= 1; refresh_count <= 0; end
		end
		STATE_IDLE_7: state <= STATE_IDLE_6;
		STATE_IDLE_6: state <= STATE_IDLE_5;
		STATE_IDLE_5: state <= STATE_IDLE_4;
		STATE_IDLE_4: state <= STATE_IDLE_3;
		STATE_IDLE_3: state <= STATE_IDLE_2;
		STATE_IDLE_2: state <= STATE_IDLE_1;
		STATE_IDLE_1: begin
			state <= STATE_IDLE;
			if(refresh_count > cycles_per_refresh) begin state <= STATE_IDLE_7; command <= CMD_AUTO_REFRESH; refresh_count <= 0; end
		end
		STATE_IDLE: begin
			if(refresh_count > (cycles_per_refresh<<1)) state <= STATE_IDLE_1;
			else if(new_brd) begin                          // P2b: page-mode burst read (ACTIVATE the row once)
				new_brd <= 0; brd_i <= 10'd0;
				state <= STATE_BR_ACT; command <= CMD_ACTIVE;
				SDRAM_A <= brd_row; SDRAM_BA <= brd_bank;
			end
			else if(new_bwr) begin                         // page-mode burst write owns the open row
				new_bwr <= 0; bwr_i <= 10'd0;
				state <= STATE_BW_ACT; command <= CMD_ACTIVE;
				SDRAM_A <= bwr_row; SDRAM_BA <= bwr_bank;
			end
			else if(new_rd | new_we) begin
				new_we <= 0; new_rd <= 0; save_we <= new_we;
				state <= STATE_OPEN_1; command <= CMD_ACTIVE;
				// P2a (cont.23): framebuffer-friendly row/col split — col = word[8:0] (512 cols =
				// one 512-entry VRAM scanline), row = word[21:9]. So a scanline's 512 consecutive
				// entries share ONE SDRAM row (VRAM_BASE 0xE0000 is 512-aligned) -> page-mode burst
				// reads a whole row in one ACTIVATE (P2b). Bijective vs the old row=word[12:0] split:
				// every client writes and reads the same word address, so gfx/ROM/VRAM data is
				// bit-identical (re-verified by the SDRAM round-trip TBs); only the physical DRAM
				// row/col placement changes, which no client sees.  [was: save_addr[13:1]]
				SDRAM_A <= save_addr[22:10]; SDRAM_BA <= save_addr[24:23];
			end
		end
		STATE_OPEN_1: state <= STATE_OPEN_2;
		STATE_OPEN_2: begin
			SDRAM_A <= {save_we & (new_wtbt ? ~new_wtbt[1] : ~save_addr[0]), save_we & (new_wtbt ? ~new_wtbt[0] : save_addr[0]), 2'b10, save_addr[9:1]};   // P2a: col = word[8:0]  [was: save_addr[22:14]]
			if(save_we) begin
				command <= CMD_WRITE;
				sdram_dq_out <= new_wtbt ? new_data : {new_data[7:0], new_data[7:0]}; sdram_dq_oe <= 1'b1;
				ready <= 1; state <= STATE_IDLE_2;
			end
			else begin command <= CMD_READ; data_ready_delay[CAS_LATENCY+1] <= 1; state <= STATE_IDLE_5; end
		end
		// ---- P2b page-mode burst read: ACTIVATE (in IDLE) -> tRCD gap -> stream READs (no auto-
		//      precharge, col++/cycle, A[10]=0) -> drain the read pipe -> PRECHARGE -> done. ----
		STATE_BR_ACT: state <= STATE_BR_RD;                 // tRCD NOP gap (mirrors OPEN_1)
		STATE_BR_RD: begin
			if(brd_i < brd_len_l) begin
				command <= CMD_READ;
				SDRAM_A  <= {4'b0000, brd_col};             // DQM=0 (read both), A[10]=0 (keep row open), col
				brd_col  <= brd_col + 9'd1;
				brd_i    <= brd_i + 10'd1;
			end else state <= STATE_BR_DRAIN;               // all reads issued
		end
		STATE_BR_DRAIN: if(brd_vdelay == 0) begin           // last streamed word captured
			command <= CMD_PRECHARGE; SDRAM_A[10] <= 1'b1;  // close the open row (all banks)
			state   <= STATE_BR_PRE;
		end
		STATE_BR_PRE: begin brd_done <= 1'b1; state <= STATE_IDLE; end
		// ---- Page-mode burst write: ACTIVATE -> tRCD -> valid/ready WRITE
		//      stream -> tWR recovery -> explicit PRECHARGE -> done. ----
		STATE_BW_ACT: state <= STATE_BW_WR;
		STATE_BW_WR: begin
			if(bwr_i < bwr_len_l) begin
				if(bwr_beat) begin
					command      <= CMD_WRITE;
					// A12/A11 feed DQMH/DQML, A10=0 keeps the row open,
					// A9=0 because the physical column is A8:0.
					SDRAM_A      <= {~bwr_wtbt[1], ~bwr_wtbt[0], 2'b00, bwr_col};
					sdram_dq_out <= bwr_din;
					sdram_dq_oe  <= 1'b1;
					bwr_col      <= bwr_col + 9'd1;
					bwr_i        <= bwr_i + 10'd1;
				end
			end else state <= STATE_BW_REC1;
		end
		// Two NOP cycles after the final WRITE satisfy write recovery before
		// closing the bank. STATE_BW_PRE reports completion only after the
		// PRECHARGE command has reached the SDRAM pins.
		STATE_BW_REC1: state <= STATE_BW_REC2;
		STATE_BW_REC2: begin
			command <= CMD_PRECHARGE; SDRAM_A[10] <= 1'b1;
			state <= STATE_BW_PRE;
		end
		STATE_BW_PRE: begin bwr_done <= 1'b1; state <= STATE_IDLE; end
		default: state <= STATE_IDLE;
	endcase

	if(init) begin
		state <= STATE_STARTUP;
		refresh_count <= startup_refresh_max - sdram_startup_cycles;
		new_brd <= 1'b0; brd_vdelay <= 0;
		new_bwr <= 1'b0; bwr_i <= 10'd0;
	end

	old_we <= we;
	if(we & ~old_we) begin save_addr <= addr; {ready, new_we, new_data, new_wtbt} <= {1'b0, 1'b1, din, wtbt}; end

	old_rd <= rd;
	if(rd & ~old_rd) begin
		save_addr <= addr;
		if(!(ready & ~save_we & (save_addr[24:1] == addr[24:1]))) {ready, new_rd} <= {1'b0, 1'b1};
	end

	// P2b: latch a burst-read request on its rising edge (held until brd_done by the caller)
	old_brd <= brd_req;
	if(brd_req & ~old_brd) begin
		brd_row   <= brd_addr[22:10];
		brd_bank  <= brd_addr[24:23];
		brd_col   <= brd_addr[9:1];
		brd_len_l <= brd_len;
		new_brd   <= 1'b1;
	end

	// Latch one burst-write descriptor. The caller holds request/descriptor
	// stable through bwr_done and supplies stream data through valid/ready.
	old_bwr <= bwr_req;
	if(bwr_req & ~old_bwr) begin
		bwr_row   <= bwr_addr[22:10];
		bwr_bank  <= bwr_addr[24:23];
		bwr_col   <= bwr_addr[9:1];
		bwr_len_l <= bwr_len;
		new_bwr   <= 1'b1;
	end
end

endmodule
