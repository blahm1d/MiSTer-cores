// yunit_sdram_burst_arb.sv
//
// Arbitrates sdram_stock's page-mode burst ports between:
//   * scanout: one read burst
//   * autoerase: one atomic read-then-write pair
//
// A fresh simultaneous request favors scanout. If autoerase was waiting behind
// that scanout, it is remembered and receives the next grant, bounding
// starvation. Ownership is held through brd_done for scanout and through
// bwr_done for autoerase. A request-low bubble follows every owner so the
// controller's edge-latched brd_req/bwr_req inputs can recognize a subsequent
// request even when a client presents back-to-back work.

`default_nettype none

module yunit_sdram_burst_arb (
  input  logic        clk,
  input  logic        rst,

  // Scanout burst-read client.
  input  logic        scan_brd_req,
  input  logic [24:0] scan_brd_addr,
  input  logic [9:0]  scan_brd_len,
  output logic [15:0] scan_brd_dout,
  output logic        scan_brd_dvalid,
  output logic        scan_brd_done,

  // Autoerase atomic read/write client. Both request levels must be asserted
  // together and held through their respective completion strobes.
  input  logic        erase_brd_req,
  input  logic [24:0] erase_brd_addr,
  input  logic [9:0]  erase_brd_len,
  output logic [15:0] erase_brd_dout,
  output logic        erase_brd_dvalid,
  output logic        erase_brd_done,

  input  logic        erase_bwr_req,
  input  logic [24:0] erase_bwr_addr,
  input  logic [9:0]  erase_bwr_len,
  input  logic [15:0] erase_bwr_din,
  input  logic [1:0]  erase_bwr_wtbt,
  input  logic        erase_bwr_valid,
  output logic        erase_bwr_ready,
  output logic        erase_bwr_done,

  // Shared sdram_stock burst ports.
  output logic        brd_req,
  output logic [24:0] brd_addr,
  output logic [9:0]  brd_len,
  input  logic [15:0] brd_dout,
  input  logic        brd_dvalid,
  input  logic        brd_done,

  output logic        bwr_req,
  output logic [24:0] bwr_addr,
  output logic [9:0]  bwr_len,
  output logic [15:0] bwr_din,
  output logic [1:0]  bwr_wtbt,
  output logic        bwr_valid,
  input  logic        bwr_ready,
  input  logic        bwr_done,

  // Diagnostics.
  output logic        scan_owned,
  output logic        erase_owned,
  output logic        request_bubble,
  output logic        erase_waiting,
  output logic        protocol_error
);

  typedef enum logic [1:0] {
    A_IDLE,
    A_SCAN,
    A_ERASE,
    A_BUBBLE
  } arb_state_t;
  arb_state_t state;

  logic [24:0] read_addr_q;
  logic [9:0]  read_len_q;
  logic [24:0] write_addr_q;
  logic [9:0]  write_len_q;
  logic        erase_read_complete;

  wire erase_pair = erase_brd_req && erase_bwr_req;
  wire erase_half_request = erase_brd_req ^ erase_bwr_req;

  assign scan_owned    = (state == A_SCAN);
  assign erase_owned   = (state == A_ERASE);
  assign request_bubble = (state == A_BUBBLE);

  assign brd_req  = scan_owned || erase_owned;
  assign brd_addr = read_addr_q;
  assign brd_len  = read_len_q;

  assign bwr_req   = erase_owned;
  assign bwr_addr  = write_addr_q;
  assign bwr_len   = write_len_q;
  assign bwr_din   = erase_bwr_din;
  assign bwr_wtbt  = erase_bwr_wtbt;
  assign bwr_valid = erase_owned && erase_bwr_valid;

  // Response isolation: a non-owner sees no completion/ready activity.
  assign scan_brd_dout   = scan_owned ? brd_dout : 16'd0;
  assign scan_brd_dvalid = scan_owned && brd_dvalid;
  assign scan_brd_done   = scan_owned && brd_done;

  assign erase_brd_dout   = erase_owned ? brd_dout : 16'd0;
  assign erase_brd_dvalid = erase_owned && brd_dvalid;
  assign erase_brd_done   = erase_owned && brd_done;
  assign erase_bwr_ready  = erase_owned && bwr_ready;
  assign erase_bwr_done   = erase_owned && bwr_done;

  always_ff @(posedge clk) begin
    if (rst) begin
      state          <= A_IDLE;
      erase_waiting  <= 1'b0;
      protocol_error <= 1'b0;
      read_addr_q    <= 25'd0;
      read_len_q     <= 10'd0;
      write_addr_q   <= 25'd0;
      write_len_q    <= 10'd0;
      erase_read_complete <= 1'b0;
    end else begin
      if (erase_half_request && (state != A_ERASE))
        protocol_error <= 1'b1;

      // Remember a complete autoerase pair specifically when scanout made it
      // wait. A request first observed during the neutral bubble is not allowed
      // to defeat scanout's priority at the following idle decision.
      if (erase_pair && (state == A_SCAN))
        erase_waiting <= 1'b1;
      else if (erase_waiting && !erase_pair) begin
        // Requests are required to remain stable until their eventual grant.
        erase_waiting  <= 1'b0;
        protocol_error <= 1'b1;
      end

      unique case (state)
        A_IDLE: begin
          // A previously deferred erase has fairness priority. Otherwise a
          // fresh collision goes to scanout as required.
          if (erase_waiting && erase_pair) begin
            read_addr_q   <= erase_brd_addr;
            read_len_q    <= erase_brd_len;
            write_addr_q  <= erase_bwr_addr;
            write_len_q   <= erase_bwr_len;
            erase_read_complete <= 1'b0;
            erase_waiting <= 1'b0;
            state         <= A_ERASE;
          end else if (scan_brd_req) begin
            read_addr_q <= scan_brd_addr;
            read_len_q  <= scan_brd_len;
            if (erase_pair)
              erase_waiting <= 1'b1;
            state       <= A_SCAN;
          end else if (erase_pair) begin
            read_addr_q   <= erase_brd_addr;
            read_len_q    <= erase_brd_len;
            write_addr_q  <= erase_bwr_addr;
            write_len_q   <= erase_bwr_len;
            erase_read_complete <= 1'b0;
            erase_waiting <= 1'b0;
            state         <= A_ERASE;
          end
        end

        A_SCAN: begin
          if (!scan_brd_req && !brd_done)
            protocol_error <= 1'b1;
          if (brd_done)
            state <= A_BUBBLE;
        end

        A_ERASE: begin
          if ((!erase_read_complete && !erase_brd_req && !brd_done) ||
              (!erase_bwr_req && !bwr_done))
            protocol_error <= 1'b1;
          // brd_done is routed to the backend but does not release ownership.
          // The reserved write half is part of this same atomic grant.
          if (brd_done)
            erase_read_complete <= 1'b1;
          if (bwr_done)
            state <= A_BUBBLE;
        end

        A_BUBBLE: state <= A_IDLE;

        default: state <= A_IDLE;
      endcase
    end
  end

endmodule

`default_nettype wire
