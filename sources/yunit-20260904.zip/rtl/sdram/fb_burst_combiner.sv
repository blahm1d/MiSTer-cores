// fb_burst_combiner.sv — v2: coalesce the blitter's per-row consecutive fb writes into ONE
// sdram_stock page-mode burst write (bwr_*). The blitter (yunit_dma, MAME dma_draw-faithful)
// emits fb_we/fb_addr/fb_wdata one pixel at a time, sx-sequential within a row: fb_addr = ty*512
// + tx, tx incrementing. Consecutive VRAM entries in a row = consecutive SDRAM columns in ONE row
// (col = word[8:0], a 512-entry scanline = one SDRAM row). So a blit row IS a natural page burst.
//
// PROTOCOL: the blitter holds fb_we until fb_ack, then drops + re-asserts for the next pixel. The
// combiner ACCEPTS+ACKs each pixel into a run buffer (fast, so the blitter keeps feeding) while the
// address extends the run; on a run BREAK (non-consecutive addr, or a different SDRAM row, or the
// buffer is full) it FIREs the accumulated run as one bwr_* burst (stalling the blitter until the
// burst lands), then starts a fresh run with the pending pixel. fb_flush (blit done) fires the
// residual run. The odd end-pixel is trivial — full-word be=11 writes (the blitter already composed
// {pal,pix}); DQM is available if a lane ever needs masking, but fb writes are whole words.
//
// COHERENCY: fb_busy = (a run is buffered OR a burst is in flight). The DMA gates its done-report
// on fb_busy so "done" == committed to SDRAM, never mid-run -> scanout/CPU never read an un-fired
// pixel (the proven fb_flush/fb_busy commit-gate from the DDR3 path, bridge-free here).
`default_nettype none
module fb_burst_combiner #(
  parameter [24:0] VRAM_WBASE = 25'h0E0000,   // VRAM word base in SDRAM (col-aligned)
  parameter int    CAP        = 512            // max run = one SDRAM row (512 words)
)(
  input  logic        clk,
  input  logic        rst,
  // blitter fb port
  input  logic        fb_we,
  input  logic [17:0] fb_addr,     // VRAM entry (word) index
  input  logic [15:0] fb_wdata,
  input  logic        fb_flush,    // blit done: drain the residual run now
  output logic        fb_ack,
  output logic        fb_busy,     // run buffered OR burst in flight (commit-gate)
  // sdram_stock bwr_* port
  output logic        bwr_req,
  output logic [24:0] bwr_addr,    // BYTE address (word<<1)
  output logic [9:0]  bwr_len,
  output logic [15:0] bwr_din,     // FWFT head
  output logic [1:0]  bwr_wtbt,
  input  logic        bwr_next,    // burst consumed a beat -> advance the head
  input  logic        bwr_done
);
  localparam int AWIDTH = $clog2(CAP);

  logic [15:0] rb [0:CAP-1];       // run data, in EMISSION order (rb[k] = the k-th pixel emitted)
  logic [17:0] rb_base;            // FIRST VRAM entry of the run (asc: lowest; desc: highest)
  logic [AWIDTH:0] rb_cnt;         // words buffered (0..CAP)
  logic        dir;                // 0 = ascending (dx=+1), 1 = descending (dx=-1, xflip)
  logic [AWIDTH:0] str;            // FWFT buffer index during FIRE
  logic [15:0] bwr_din_q;         // v2 Fmax: REGISTERED stream head. Was `assign bwr_din =
                                  // rb[str]` — a combinational CAP:1 mux driving sdram_stock's
                                  // sdram_dq_out register (STA worst path -1.574ns @96MHz). Now the
                                  // mux terminates at this flop (preloaded during the ACT/tRCD gap
                                  // before beat 0, re-loaded on each bwr_next). Same word sequence,
                                  // bit-identical (gated by tb_fb_burst_combiner + tb_vram_sdram_v2).
  logic        fb_we_d;
  wire         fb_edge = fb_we & ~fb_we_d;   // one accept per rising fb_we

  // Run extension (MAME dma_draw: dest steps tx += dx, dx = flip?-1:+1; midyunit_v.cpp:264). The
  // 2nd pixel latches dir; thereafter the k-th pixel sits at rb_base +/- k. same_row (word[17:9] =
  // the 512-word col page) forbids a page-crossing run (page-mode requires one SDRAM row).
  wire        same_row = (fb_addr[17:9] == rb_base[17:9]);
  wire        step_up  = (fb_addr == rb_base + rb_cnt);          // asc: next-higher entry
  wire        step_dn  = (rb_base >= rb_cnt) && (fb_addr == rb_base - rb_cnt);  // desc: next-lower
  wire        dir2_ok  = (rb_cnt == 1) && ((fb_addr == rb_base + 18'd1) || (fb_addr == rb_base - 18'd1));
  wire        dirN_ok  = (rb_cnt >= 2) && (dir ? step_dn : step_up);
  wire        run_ext  = (rb_cnt != 0) && same_row && (rb_cnt < CAP[9:0]) && (dir2_ok || dirN_ok);
  wire        new_dir  = (fb_addr == rb_base - 18'd1);           // 2nd pixel went DOWN -> descending

  // low word address of the run (bwr_* writes ascending columns from here): asc -> rb_base;
  // desc -> the lowest entry rb_base-(rb_cnt-1). The stream is emitted REVERSED for desc so the
  // word landing at the low address is the last-buffered pixel.
  wire [17:0] run_lo = dir ? (rb_base - (rb_cnt - 1'b1)) : rb_base;

  // stream index at FIRE start (asc: 0; desc: rb_cnt-1) and the next index after a consumed beat.
  wire [AWIDTH:0] str_init = dir ? (rb_cnt - 1'b1) : '0;
  wire [AWIDTH:0] str_nxt  = dir ? (str - 1'b1)    : (str + 1'b1);

  typedef enum logic [1:0] { ACC, FIRE_REQ } st_t;
  st_t st;

  assign bwr_din  = bwr_din_q;                             // registered head (see decl)
  assign bwr_wtbt = 2'b11;                                  // fb writes are full composed words
  assign bwr_addr = {VRAM_WBASE + {{7{1'b0}}, run_lo}, 1'b0};
  assign bwr_len  = rb_cnt[9:0];
  assign fb_busy  = (rb_cnt != 0) || (st != ACC);

  always_ff @(posedge clk) begin
    if (rst) begin
      st <= ACC; rb_cnt <= '0; str <= '0; dir <= 1'b0; bwr_req <= 1'b0; fb_ack <= 1'b0; fb_we_d <= 1'b0; bwr_din_q <= '0;
    end else begin
      fb_ack  <= 1'b0;
      fb_we_d <= fb_we;
      case (st)
        ACC: begin
          if (fb_edge) begin
            if (rb_cnt == 0) begin                          // start a fresh run
              rb_base <= fb_addr; rb[0] <= fb_wdata; rb_cnt <= 1; dir <= 1'b0; fb_ack <= 1'b1;
            end else if (run_ext) begin                     // append; latch dir on the 2nd pixel
              rb[rb_cnt[AWIDTH-1:0]] <= fb_wdata; rb_cnt <= rb_cnt + 1'b1; fb_ack <= 1'b1;
              if (rb_cnt == 1) dir <= new_dir;
            end else begin                                  // run break -> FIRE (hold this pixel, no ack)
              str <= str_init; bwr_din_q <= rb[str_init[AWIDTH-1:0]]; bwr_req <= 1'b1; st <= FIRE_REQ;
            end
          end else if (fb_flush && rb_cnt != 0) begin       // blit done -> drain residual
            str <= str_init; bwr_din_q <= rb[str_init[AWIDTH-1:0]]; bwr_req <= 1'b1; st <= FIRE_REQ;
          end
        end
        FIRE_REQ: begin                                     // stream the buffer; asc up, desc down
          if (bwr_next) begin str <= str_nxt; bwr_din_q <= rb[str_nxt[AWIDTH-1:0]]; end
          if (bwr_done) begin
            bwr_req <= 1'b0; rb_cnt <= '0;
            // seed the next run with the held run-break pixel (fb_we still high)
            if (fb_we) begin rb_base <= fb_addr; rb[0] <= fb_wdata; rb_cnt <= 1; dir <= 1'b0; fb_ack <= 1'b1; end
            st <= ACC;
          end
        end
        default: st <= ACC;
      endcase
    end
  end
endmodule
`default_nettype wire
