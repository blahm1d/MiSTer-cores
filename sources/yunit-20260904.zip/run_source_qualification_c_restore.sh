#!/usr/bin/env bash
set -Eeuo pipefail

export PATH="/usr/local/bin:/usr/bin:/mingw64/bin:/c/iverilog/bin:${PATH:-}"

WT="${WT:-$(cd "$(dirname "$0")" && pwd)}"
OUT="${OUT:-/d/deck/fpga/_codex_builds/yunit_strikeforce_c_restore_hailmary_qual_20260827/source-qualification}"
SV2V_FEATURES='-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_DISPLAY_SEQ -DYUNIT_SRT_FILL_BURST -DYUNIT_ERASE_MASKED_PAGE_GUARD -DYUNIT_ERASE_FRAME_SNAP'

mkdir -p "$OUT"
cd "$WT"
: >"$OUT/results.txt"

pass() {
  local label="$1"
  shift
  if "$@" >"$OUT/$label.log" 2>&1; then
    printf 'PASS %s\n' "$label" | tee -a "$OUT/results.txt"
  else
    tail -80 "$OUT/$label.log" >&2 || true
    printf 'FAIL %s\n' "$label" | tee -a "$OUT/results.txt" >&2
    return 1
  fi
}

kill_mutant() {
  local label="$1"
  local marker="$2"
  shift 2
  if "$@" >"$OUT/$label.log" 2>&1; then
    printf 'FAIL %s mutant survived\n' "$label" | tee -a "$OUT/results.txt" >&2
    return 1
  fi
  if ! grep -Eq "$marker" "$OUT/$label.log"; then
    tail -80 "$OUT/$label.log" >&2 || true
    printf 'FAIL %s wrong failure\n' "$label" | tee -a "$OUT/results.txt" >&2
    return 1
  fi
  printf 'KILLED %s\n' "$label" | tee -a "$OUT/results.txt"
}

# Record the exact source identity. This runner is intended to be rerun after
# the implementation commit, when the worktree is clean.
git rev-parse HEAD | tee "$OUT/head.txt"
git status --porcelain=v1 | tee "$OUT/status.txt"
sha256sum run_source_qualification_c_restore.sh | tee "$OUT/runner.sha256"

# Core discriminator: exact path, both negative scopes, and a deliberate
# reversion to the rejected generic-FILL behavior.
pass fill_xy_feature_off ./sim/run_tms34010_tb.sh tb_fill_xy
pass fill_srt_exact ./sim/run_tms34010_tb.sh tb_fill_srt \
  -DYUNIT_SRT_FILL_BURST
pass fill_srt_dedicated_ack ./sim/run_tms34010_tb.sh tb_fill_srt \
  -DYUNIT_SRT_FILL_BURST -DSRT_FILL_SHARED_ACK_POISON
pass fill_srt_scope_off ./sim/run_tms34010_tb.sh tb_fill_srt \
  -DYUNIT_SRT_FILL_BURST -DSRT_FILL_SCOPE_OFF
pass fill_srt_near_envelope ./sim/run_tms34010_tb.sh tb_fill_srt \
  -DYUNIT_SRT_FILL_BURST -DSRT_FILL_NEAR_ENVELOPE
kill_mutant fill_srt_ordinary 'expected 105 SRT FILL commands, got 0' \
  ./sim/run_tms34010_tb.sh tb_fill_srt \
  -DYUNIT_SRT_FILL_BURST -DMUT_SRT_FILL_AS_ORDINARY
pass pixt_srt_unchanged ./sim/run_tms34010_tb.sh tb_pixt_srt \
  -DYUNIT_SRT_FILL_BURST

# Timing-closure boundary: MMFM snapshots the issued register target in the
# CPU-CE domain, then commits through a preserved 32-bit-data + 31-bit-one-hot
# target bank on the following sysclk.  The bench runs ce_cpu=1 so it also
# proves the final popped register and final Rp can land together on distinct
# flop-array targets without changing architectural results.
pass mmfm_registered_commit ./sim/run_tms34010_tb.sh tb_mmfm
pass mmfm_registered_commit_div4 ./sim/run_tms34010_tb.sh tb_mmfm \
  -DMMFM_DIV4_CE
pass tms34010_cycle_budget ./sim/run.sh tb_tms34010_cycle_budget

# Registered CPU-CE command and response boundary.
pass memcdc_response ./sim/run.sh tb_yunit_mem_cdc
pass command_bridge ./sim/run.sh tb_yunit_shiftreg_command_bridge
kill_mutant command_bridge_raw \
  'engine request bypassed the cpu_ce command register' \
  env SV2V_EXTRA_DEFINE=MUT_SHIFTREG_RAW_COMMAND \
      MUTATE=MUT_SHIFTREG_RAW_COMMAND \
  ./sim/run.sh tb_yunit_shiftreg_command_bridge
kill_mutant command_bridge_direct_ack \
  'engine_done bypassed the CPU-CE response register' \
  env SV2V_EXTRA_DEFINE=MUT_SHIFTREG_DIRECT_ACK \
      MUTATE=MUT_SHIFTREG_DIRECT_ACK \
  ./sim/run.sh tb_yunit_shiftreg_command_bridge

# Exact row-pair backend and its load-bearing negative controls.
pass ddr_srt_full_command ./sim/run.sh tb_vram_ddr_shiftreg
kill_mutant ddr_srt_early_done 'RESULT: FAIL' \
  env MUTATE=MUT_SRT_EARLY_DONE ./sim/run.sh tb_vram_ddr_shiftreg
kill_mutant ddr_srt_snapshot_mutable 'SF SRT chain had [1-9][0-9]* corrupt entries' \
  env MUTATE=MUT_SRT_SNAPSHOT_MUTABLE ./sim/run.sh tb_vram_ddr_shiftreg
pass ddr_srt_scanrace ./sim/run.sh tb_vram_ddr_shiftreg_scanrace

# The inherited C-engine suite is load-bearing now that SRT shares its cache
# and L2 grant. It covers cold fill, parity, source write-through, autoerase,
# B coherency, framebuffer overlap, and their existing mutations.
pass ddr3_c_engine_regression bash sim/run_ddr3.sh
pass erase_event_order bash sim/probe/erase-base/run_gate.sh

# Shadow-valid retime and every already-proven neighboring seam.
pass shw_valid_retime_source \
  env SHWVALID_RETIME_OUT="$OUT/shwvalid_source_work" \
  bash sim/run_shw_valid_retime.sh
pass family2_dma_queue ./sim/run.sh tb_family2_dma_queue
pass sf_display_replay ./sim/run.sh tb_yunit_sf_display_replay
pass page_publish_smear ./sim/run.sh tb_yunit_page_publish_smear
pass vram_bsnoop ./sim/run.sh tb_vram_bsnoop
pass family2_pageflip ./sim/run.sh tb_family2_pageflip_coherent
pass dma_term2_flip ./sim/run.sh tb_yunit_dma_term2_flip

# Offline release logic and source/provenance contracts.
pass release_ram_unit_tests python -B -m unittest discover

# Translate the exact physical feature set and elaborate the complete emu
# hierarchy against that same generated blob.
pass sv2v_exact_feature env SV2V_EXTRA="$SV2V_FEATURES" \
  bash quartus/build_sv2v.sh

NETLIST=build_syn/smashtv_core.v
test -s "$NETLIST"
test "$(grep -Fc 'reg [6:0] srt_fill_pair_q;' "$NETLIST")" = 1
test "$(grep -Fc 'input wire srt_fill_ack_i;' "$NETLIST")" = 1
test "$(grep -Fc "(srt_fill_ack_i === 1'b1)" "$NETLIST")" = 2
test "$(grep -Fc '.srt_fill_ack_i(sr_core_ack)' "$NETLIST")" = 1
! grep -Fq 'srt_fill_req_q' "$NETLIST"
! grep -Fq 'srt_fill_addr_q' "$NETLIST"

# C/SRT consolidation structural gates: exactly one 256x64 source cache, no
# duplicate ebuf, no fifth grant value, and a 2-bit four-owner grant register.
test "$(grep -Fc 'reg [63:0] src_cache [0:255];' "$NETLIST")" = 1
! grep -Fq 'reg [63:0] ebuf [0:255];' "$NETLIST"
! grep -Eq "l_gnt[[:space:]]*==[[:space:]]*3'd4" "$NETLIST"
test "$(grep -Fc 'reg [1:0] l_gnt;' "$NETLIST")" = 1

test "$(grep -Fc 'reg [15:0] shw_v_bank_q;' "$NETLIST")" = 1
test "$(grep -Fc 'reg [3:0] shw_v_bank_sel_q;' "$NETLIST")" = 1
test "$(grep -Fc 'wire [15:0] shw_v_bank_d;' "$NETLIST")" = 1
test "$(grep -Fc 'assign shw_v_bank_d[' "$NETLIST")" = 16
test "$(grep -Fc 'assign shw_v_q = shw_v_bank_q[shw_v_bank_sel_q];' "$NETLIST")" = 1
test "$(grep -Fc 'shw_v_bank_q <= shw_v_bank_d;' "$NETLIST")" = 1
test "$(grep -Fc 'shw_v_bank_sel_q <= shw_cand_idx[3:0];' "$NETLIST")" = 1
! grep -Fq 'shw_v_q <= shw_valid[' "$NETLIST"
! grep -Fq 'MUT_SHW_VALID_LIVE_BANK_SELECT' "$NETLIST"
! grep -Fq 'MUT_SHW_VALID_CORE_RST_CLEAR' "$NETLIST"

# The two timing cuts must survive the exact production translation as real
# register boundaries.  MMFM's issue bank remains CPU-CE state; its full-rate
# commit bank has exactly 63 canonical leaves (32 data + 31 one-hot targets).
# Physical fitter duplicates remain legal only under the fitted audit's
# duplicate-aware census and per-lane timing checks. Pin the
# stable names, attributes, unconditional data capture, and one-hot regfile
# interface, while rejecting every token from the old valid/file/index channel.
# The former same-edge rc[bsn_fillbeat_q] write must also be absent.
test "$(grep -Fc 'reg mmfm_issue_active_q;' "$NETLIST")" = 1
test "$(grep -Fc 'reg mmfm_issue_file_q;' "$NETLIST")" = 1
test "$(grep -Fc 'reg [30:0] mmfm_issue_target_q;' "$NETLIST")" = 1
test "$(grep -Fc 'reg [31:0] mmfm_commit_data_q;' "$NETLIST")" = 1
test "$(grep -Fc 'reg [30:0] mmfm_commit_target_q;' "$NETLIST")" = 1
test "$(grep -Fc 'reg [15:0] mm_mask_q;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg mmfm_issue_active_q;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [15:0] mm_mask_q;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg mmfm_issue_file_q;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [30:0] mmfm_issue_target_q;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [31:0] mmfm_commit_data_q;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge, altera_attribute = "-name ADV_NETLIST_OPT_ALLOWED NEVER_ALLOW; -name DONT_MERGE_REGISTER ON; -name PRESERVE_REGISTER ON" *) reg [30:0] mmfm_commit_target_q;' "$NETLIST")" = 1
test "$(grep -Fc 'mmfm_commit_data_q <= mem_rdata;' "$NETLIST")" = 1
! grep -Fq 'mmfm_commit_data_q <= mem_rdata_eff;' "$NETLIST"
test "$(grep -Fc 'if (mmfm_pop_accept && io_is_io)' rtl/tms34010/rtl/core/tms34010_core.sv)" = 1
test "$(grep -Fc '$fatal(1, "tms34010_core: 32-bit MMFM pop from 16-bit I/O space is unsupported");' rtl/tms34010/rtl/core/tms34010_core.sv)" = 1
test "$(grep -Fc "mmfm_commit_target_q <= (mmfm_pop_accept ? mmfm_issue_target_q : 31'd0);" "$NETLIST")" = 1
test "$(grep -Fc '.aux_wr_target(mmfm_commit_target_q)' "$NETLIST")" = 1
test "$(grep -Fc '.aux_wr_data(mmfm_commit_data_q)' "$NETLIST")" = 1
test "$(grep -Fc 'assign core_mem_ack = cpu_ack | sr_core_ack;' "$NETLIST")" = 1
test "$(grep -Fc 'assign core_mem_rdata = (sr_core_ack ? {{16 {1'\''b0}}, sr_read_data} : cpu_rdata);' "$NETLIST")" = 1
test "$(grep -Fc 'assign core_mem_ack = cpu_ack | sr_core_ack;' rtl/yunit/family2/yunit_top_family2.sv)" = 1
test "$(grep -Fc 'assign core_mem_rdata = sr_core_ack' rtl/yunit/family2/yunit_top_family2.sv)" = 1
test "$(grep -Fc 'if (!core_rst_sys && cpu_ack && sr_core_ack)' rtl/yunit/family2/yunit_top_family2.sv)" = 1
test "$(grep -Fc '$fatal(1, \"yunit_top_family2: ordinary and SRT acknowledgements collided\");' rtl/yunit/family2/yunit_top_family2.sv)" = 1
! grep -Fq 'assign core_mem_ack = sf_shiftreg_req ?' rtl/yunit/family2/yunit_top_family2.sv
! grep -Fq 'assign core_mem_rdata = sf_shiftreg_req' rtl/yunit/family2/yunit_top_family2.sv
! grep -Fq 'assign core_mem_ack = (sf_shiftreg_req ?' "$NETLIST"
! grep -Fq 'assign core_mem_rdata = (sf_shiftreg_req ?' "$NETLIST"
test "$(grep -Fc '.cpu_req(sf_shiftreg_req)' "$NETLIST")" = 1
test "$(grep -Fc '.c_req(cpu_req && !sf_shiftreg_req)' "$NETLIST")" = 1
! grep -Fq 'mmfm_commit_valid_q' "$NETLIST"
! grep -Fq 'mmfm_commit_file_q' "$NETLIST"
! grep -Fq 'mmfm_commit_idx_q' "$NETLIST"
! grep -Fq 'aux_wr_en' "$NETLIST"
! grep -Fq 'aux_wr_file' "$NETLIST"
! grep -Fq 'aux_wr_idx' "$NETLIST"
test "$(grep -Fc 'rf_wr_data = mm_rp_q;' "$NETLIST")" = 2
! grep -Fq 'mmfm_pop_wr' "$NETLIST"
! grep -Fq 'rf_wr_data = mem_rdata_eff;' "$NETLIST"
test "$(grep -Fc 'reg bsn_commit_v;' "$NETLIST")" = 1
test "$(grep -Fc 'reg [6:0] bsn_commit_addr;' "$NETLIST")" = 1
test "$(grep -Fc 'reg [63:0] bsn_commit_data;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge *) reg bsn_commit_v;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge *) reg [6:0] bsn_commit_addr;' "$NETLIST")" = 1
test "$(grep -Fc '(* preserve, dont_merge *) reg [63:0] bsn_commit_data;' "$NETLIST")" = 1
test "$(grep -Fc 'reg bsn_commit_done_q;' "$NETLIST")" = 1
test "$(grep -Fc 'bsn_commit_v <= (bts == B_FILL) && b_rd_valid;' "$NETLIST")" = 1
test "$(grep -Fc 'bsn_commit_addr <= bsn_fillbeat_q;' "$NETLIST")" = 1
test "$(grep -Fc 'bsn_commit_data <= bfill_merged;' "$NETLIST")" = 1
test "$(grep -Fc 'rc[bsn_commit_addr] <= bsn_commit_data;' "$NETLIST")" = 1
! grep -Fq 'rc[bsn_fillbeat_q] <=' "$NETLIST"
printf 'TIMING_CUTS mmfm_issue=33 mmfm_commit=63 mmfm_commit_data=32 mmfm_commit_target=31 mmfm_mask_source_leaves=16 mmfm_mask_retime=0 mmfm_live_response_select=0 mmfm_io_response_to_commit=0 mmfm_memcdc_response_lanes=32 mmfm_srt_selector=registered_ack mmfm_legacy_aux=0 bsn_commit=1 direct_bsn_to_rc=0\n' | tee -a "$OUT/results.txt"

# Constraint least-privilege gates.  MMFM's issue bank remains in the CPU-CE
# collection; only the exact 63-leaf commit bank is full-rate and removed from
# it.  The fitted audit must demand ordinary 1/1 issue-to-target,
# memory-response-to-data, and commit-to-regfile paths, plus prove there are no
# I/O/decode/mask bypasses into the commit bank.  It must also explicitly
# reject the old bsn_fillbeat_q -> rc cone (the older audit checked only the
# unrelated live fillbeat register).
SDC=rtl/sdram.sdc
AUDIT=quartus/audit_release_constraints.tcl
test "$(grep -Fc 'set cpu_fullrate_mmfm_commit_data [get_registers -nowarn {*tms34010_core:u_core|mmfm_commit_data_q[*]*}]' "$SDC")" = 1
test "$(grep -Fc 'set cpu_fullrate_mmfm_commit_target [get_registers -nowarn {*tms34010_core:u_core|mmfm_commit_target_q[*]*}]' "$SDC")" = 1
test "$(grep -Fc 'set cpu_fullrate_mmfm_commit [add_to_collection $cpu_fullrate_mmfm_commit_data $cpu_fullrate_mmfm_commit_target]' "$SDC")" = 1
test "$(grep -Fc 'set cpu_regs [remove_from_collection $cpu_regs $cpu_fullrate_mmfm_commit]' "$SDC")" = 1
test "$(grep -Fc 'set mmfm_issue_active [get_registers -nowarn {*tms34010_core:u_core|mmfm_issue_active_q*}]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_issue_file [get_registers -nowarn {*tms34010_core:u_core|mmfm_issue_file_q*}]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_issue_target [get_registers -nowarn {*tms34010_core:u_core|mmfm_issue_target_q[*]*}]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_issue_stage [add_to_collection $mmfm_issue_active $mmfm_issue_file]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_issue_stage [add_to_collection $mmfm_issue_stage $mmfm_issue_target]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_commit_data [get_registers -nowarn {*tms34010_core:u_core|mmfm_commit_data_q[*]*}]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_commit_target [get_registers -nowarn {*tms34010_core:u_core|mmfm_commit_target_q[*]*}]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_commit_stage [add_to_collection $mmfm_commit_data $mmfm_commit_target]' "$AUDIT")" = 1
test "$(grep -Fc 'set gated_cpu [remove_from_collection $gated_cpu $mmfm_commit_stage]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_issue_stage_expected [list {mmfm_issue_active_q} {mmfm_issue_file_q}]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_mask_state_expected [list]' "$AUDIT")" = 1
test "$(grep -Fc 'for {set bit 0} {$bit < 16} {incr bit} {' "$AUDIT")" = 1
test "$(grep -Fc 'lappend mmfm_mask_state_expected [format {mm_mask_q[%d]} $bit]' "$AUDIT")" = 1
test "$(grep -Fc 'for {set bit 0} {$bit < 31} {incr bit} {' "$AUDIT")" = 1
test "$(grep -Fc 'lappend mmfm_issue_stage_expected [format {mmfm_issue_target_q[%d]} $bit]' "$AUDIT")" = 1
test "$(grep -Fc 'require_exact_register_leaves mmfm_issue_stage' "$AUDIT")" = 1
test "$(grep -Fc 'require_exact_register_leaves mmfm_commit_stage' "$AUDIT")" = 1
test "$(grep -Fc 'require_exact_register_leaves mmfm_mask_state' "$AUDIT")" = 1
test "$(grep -Fc '$mmfm_mask_state $mmfm_mask_state_expected' "$AUDIT")" = 1
test "$(grep -Fc 'foreach {bank width} [list mmfm_commit_data_q 32 mmfm_commit_target_q 31]' "$AUDIT")" = 1
! grep -Fq 'require_collection_exact_count mmfm_issue_' "$AUDIT"
! grep -Fq 'require_collection_exact_count mmfm_commit_stage_physical' "$AUDIT"
! grep -Fq 'require_collection_exact_count [format {mmfm_commit_data_lane_' "$AUDIT"
! grep -Fq 'require_collection_exact_count [format {mmfm_issue_target_lane_' "$AUDIT"
! grep -Fq 'require_collection_exact_count [format {mmfm_commit_target_lane_' "$AUDIT"
test "$(grep -Fc 'require_setup_multicycle mmfm_issue_active_to_commit_target' "$AUDIT")" = 1
test "$(grep -Fc '$mmfm_issue_active $mmfm_commit_target 1 1' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle mmfm_issue_target_to_commit_target' "$AUDIT")" = 1
test "$(grep -Fc '$mmfm_issue_target $mmfm_commit_target 1 1' "$AUDIT")" = 1
test "$(grep -Fc 'require_no_setup_path mmfm_io_to_commit_data' "$AUDIT")" = 1
test "$(grep -Fc '$io_physical_registers $mmfm_commit_data' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_memcdc_rdata [get_registers -nowarn {*u_memcdc|c_rdata*}]' "$AUDIT")" = 1
test "$(grep -Fc 'set mmfm_memcdc_ack [get_registers -nowarn {*u_memcdc|c_ack*}]' "$AUDIT")" = 1
test "$(grep -Fc 'require_collection mmfm_memcdc_rdata $mmfm_memcdc_rdata' "$AUDIT")" = 1
test "$(grep -Fc 'require_collection mmfm_memcdc_ack $mmfm_memcdc_ack' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle mmfm_memcdc_rdata_to_commit_data' "$AUDIT")" = 1
test "$(grep -Fc '$mmfm_memcdc_rdata $mmfm_commit_data 1 1' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle mmfm_memcdc_ack_to_commit_target' "$AUDIT")" = 1
test "$(grep -Fc '$mmfm_memcdc_ack $mmfm_commit_target 1 1' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle mmfm_commit_data_to_regfile' "$AUDIT")" = 1
test "$(grep -Fc '$mmfm_commit_data $cpu_regfile 1 1' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle mmfm_commit_target_to_regfile' "$AUDIT")" = 1
test "$(grep -Fc '$mmfm_commit_target $cpu_regfile 1 1' "$AUDIT")" = 1
! grep -Fq 'require_no_setup_path mmfm_decode_to_commit_stage' "$AUDIT"
! grep -Fq 'require_no_setup_path mmfm_state_to_commit_stage' "$AUDIT"
! grep -Fq 'set mmfm_state_registers' "$AUDIT"
test "$(grep -Fc 'require_no_setup_path mmfm_decode_to_commit_data' "$AUDIT")" = 1
test "$(grep -Fc '$decode_snapshot $mmfm_commit_data' "$AUDIT")" = 1
test "$(grep -Fc 'require_no_setup_path mmfm_mask_to_commit_stage' "$AUDIT")" = 1
test "$(grep -Fc '$mmfm_mask_state $mmfm_commit_stage' "$AUDIT")" = 1
test "$(grep -Fc 'for {set lane 0} {$lane < 32} {incr lane} {' "$AUDIT")" = 1
test "$(grep -Fc 'require_collection [format {mmfm_commit_data_lane_%d} $lane] $source' "$AUDIT")" = 1
test "$(grep -Fc 'require_collection [format {mmfm_memcdc_rdata_lane_%d} $lane] $response_source' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle [format {mmfm_memcdc_rdata_lane_%d_to_commit_data} $lane]' "$AUDIT")" = 1
test "$(grep -Fc '$response_source $source 1 1' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle [format {mmfm_commit_data_lane_%d_to_regfile} $lane]' "$AUDIT")" = 1
test "$(grep -Fc 'for {set lane 0} {$lane < 31} {incr lane} {' "$AUDIT")" = 1
test "$(grep -Fc 'require_collection [format {mmfm_issue_target_lane_%d} $lane] $issue_source' "$AUDIT")" = 1
test "$(grep -Fc 'require_collection [format {mmfm_commit_target_lane_%d} $lane] $commit_source' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle [format {mmfm_issue_target_lane_%d_to_commit_target} $lane]' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle [format {mmfm_commit_target_lane_%d_to_regfile} $lane]' "$AUDIT")" = 1
! grep -Fq 'require_setup_multicycle mmfm_cpu_to_commit_capture' "$AUDIT"
! grep -Fq 'require_setup_multicycle mmfm_commit_valid_to_regfile' "$AUDIT"
! grep -Fq 'require_setup_multicycle mmfm_commit_meta_to_regfile' "$AUDIT"
test "$(grep -Fc 'require_exact_register_leaves bsn_commit_stage' "$AUDIT")" = 1
test "$(grep -Fc 'set bsn_commit_dead_data_bits [list 6 7 22 23 38 39 54 55]' "$AUDIT")" = 1
test "$(grep -Fc 'set bsn_commit_data_live $bsn_commit_data' "$AUDIT")" = 1
test "$(grep -Fc 'if {$pixel_bit == 6 || $pixel_bit == 7}' "$AUDIT")" = 1
test "$(grep -Fc 'require_setup_multicycle vram_bsn_commit_data_to_row_cache_data' "$AUDIT")" = 1
test "$(grep -Fc 'require_no_setup_path vram_bsn_merge_sources_to_row_cache_data' "$AUDIT")" = 1
test "$(grep -Fc 'require_no_setup_path vram_bsn_fillbeat_to_row_cache_data' "$AUDIT")" = 1
test "$(grep -Fc 'require_no_setup_path vram_bsn_fillbeat_to_row_cache_address' "$AUDIT")" = 1
printf 'CONSTRAINT_CUTS mmfm_issue_cpu_ce=1 mmfm_mask_canonical_leaves=16 mmfm_issue_canonical_leaves=33 mmfm_commit_canonical_leaves=63 mmfm_duplicate_aware=1 mmfm_issue_to_commit_1_1=1 mmfm_memcdc_rdata_to_commit_1_1=1 mmfm_memcdc_ack_to_commit_1_1=1 mmfm_commit_to_regfile_1_1=1 mmfm_io_to_commit=0 mmfm_decode_to_commit=0 mmfm_mask_bypass=0 bsn_ordinary_1_1=1 bsn_live_data=56 bsn_dead_data=8 direct_bsn_to_rc=0\n' | tee -a "$OUT/results.txt"

netlist_lines="$(wc -l <"$NETLIST")"
netlist_casts="$(grep -Ec "[0-9A-Za-z_]+'\\(" "$NETLIST" || true)"
printf 'NETLIST lines=%s remaining_size_casts=%s src_cache=1 ebuf=0 l2_grants=4 shw_valid_bank_taps=16\n' \
  "$netlist_lines" "$netlist_casts" | tee -a "$OUT/results.txt"
test "$netlist_casts" = 0

# Generated blob must preserve the same cycle-level behavior as the source.
pass shw_valid_retime_netlist \
  env SHWVALID_RETIME_OUT="$OUT/shwvalid_netlist_work" \
      VRAM_SHWVALID_NETLIST="$WT/$NETLIST" \
  bash sim/run_shw_valid_retime.sh

pass crt_release_audit python tools/audit_yunit_crt_release.py \
  --generated "$NETLIST"

pass emu_cvsdseq_exact env SV2V_EXTRA="$SV2V_FEATURES" \
  ELAB_SKIP_SV2V=1 bash sim/elab_top.sh cvsdseq-icarus
grep -Eq 'elaborated-hierarchy gate PASS: root emu:emu, 16 required present, 31 forbidden absent' \
  "$OUT/emu_cvsdseq_exact.log"

printf 'SOURCE_QUALIFICATION: PASS\n' | tee -a "$OUT/results.txt"
