
# Build TimeStamp Verilog Module
# Jeff Wiencrot - 8/1/2011
# Sorgelig - 02/11/2019
proc generateBuildID_Verilog {} {

	# Get the timestamp (see: http://www.altera.com/support/examples/tcl/tcl-date-time-stamp.html)
	# Include hour/minute so two diagnostic candidates built on the same day are
	# distinguishable in MiSTer's Version line.  A date-only stamp made it
	# impossible to prove which of several same-day RBFs the cabinet had loaded.
	set buildDate "`define BUILD_DATE \"[clock format [ clock seconds ] -format %y%m%d-%H%M]\""

	# Create a Verilog file for output
	set outputFileName "build_id.v"
	
	set fileData ""
	if { [file exists $outputFileName]} {
		set outputFile [open $outputFileName "r"]
		set fileData [read $outputFile]
		close $outputFile	
	}

	if {$buildDate ne $fileData} {
		set outputFile [open $outputFileName "w"]
		puts -nonewline $outputFile $buildDate
		close $outputFile
		# Send confirmation message to the Messages window
		post_message "Generated: [pwd]/$outputFileName: $buildDate"
	}
}

# Build CDF file
# Sorgelig - 17/2/2018
proc generateCDF {revision device outpath} {

	set outputFileName "jtag.cdf"
	set outputFile [open $outputFileName "w"]

	puts $outputFile "JedecChain;"
	puts $outputFile "	FileRevision(JESD32A);"
	puts $outputFile "	DefaultMfr(6E);"
	puts $outputFile ""
	puts $outputFile "	P ActionCode(Ign)"
	puts $outputFile "		Device PartName(SOCVHPS) MfrSpec(OpMask(0));"
	puts $outputFile "	P ActionCode(Cfg)"
	puts $outputFile "		Device PartName($device) Path(\"$outpath/\") File(\"$revision.sof\") MfrSpec(OpMask(1));"
	puts $outputFile "ChainEnd;"
	puts $outputFile ""
	puts $outputFile "AlteraBegin;"
	puts $outputFile "	ChainType(JTAG);"
	puts $outputFile "AlteraEnd;"
}

# For both a QSF PRE_FLOW_SCRIPT_FILE invocation and
#   quartus_sh -t sys/build_id.tcl <project> <revision>
# quartus(args) contains the two caller arguments at indices 0 and 1.  The old
# 1/2 indexing happened to open the project (because both names are normally
# identical) but left revision empty, producing File(".sof") in jtag.cdf.
if {[llength $quartus(args)] != 2} {
    post_message -type error \
        "build_id.tcl expects <project> <revision>; got: $quartus(args)"
    qexit -error
}
set project_name [lindex $quartus(args) 0]
set revision [lindex $quartus(args) 1]

if {[project_exists $project_name]} {
    if {[string equal "" $revision]} {
        set revision [get_current_revision $project_name]
        project_open $project_name -revision $revision
    } else {
        project_open $project_name -revision $revision
    }
} else {
    post_message -type error "Project $project_name does not exist"
    exit
}

set device  [get_global_assignment -name DEVICE]
set outpath [get_global_assignment -name PROJECT_OUTPUT_DIRECTORY]

if [is_project_open] {
    project_close
}

generateBuildID_Verilog
generateCDF $revision $device $outpath
