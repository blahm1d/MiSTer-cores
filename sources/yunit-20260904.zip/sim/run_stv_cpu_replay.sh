#!/usr/bin/env bash
# run_stv_cpu_replay.sh — the STV START-transition CPU differential debugger under Questa.
#   SEED=B ./run_stv_cpu_replay.sh     (A=press window, B=GAMESTR/INIT_GAME [default],
#                                       C=SET_WAVE, D=first INGAME)
# Lock protocol per lessons_vsim_node_lock: ONE shared cross-campaign lock
# (%TEMP%/vsim_ase.lock, mkdir-atomic). If ANY live vsim exists (even lockless — another
# campaign), REFUSE (exit 75). NEVER reap a live vsim. Reap nothing; stale lock (dir held,
# no live vsim) is reclaimed.
set -u
SEED="${SEED:-B}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MT="/d/deck/fpga/smash tv/mame-trace"
CORE="$ROOT/rtl/tms34010"
TB=tb_stv_cpu_replay

# ---- Questa (reject stale ModelSim ASE) ----
VLOG=""; VSIM=""; VLIB=""
for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64 /c/intelFPGA*/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -z "$VLOG" ] && { echo "ERROR: Questa FSE not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
: "${SALT_LICENSE_SERVER:=C:\altera\LR-175212_License.dat;C:\altera\LR-175213_License.dat}"; export SALT_LICENSE_SERVER

# ---- shared node lock ----
LOCK="$(cygpath -u "${TEMP:-/tmp}")/vsim_ase.lock"
live_vsim() {
  tasklist //FI "IMAGENAME eq vsim.exe"  2>/dev/null | grep -qi "vsim.exe"  && return 0
  tasklist //FI "IMAGENAME eq vsimk.exe" 2>/dev/null | grep -qi "vsimk.exe" && return 0
  return 1
}
if live_vsim; then echo "BLOCKED: a live vsim exists (another campaign's run) — refusing (exit 75)"; exit 75; fi
if ! mkdir "$LOCK" 2>/dev/null; then
  if live_vsim; then echo "BLOCKED: lock held by a live vsim — refusing (exit 75)"; exit 75
  else echo "[lock] stale (held, no live vsim) — reclaiming"; rmdir "$LOCK" 2>/dev/null
       mkdir "$LOCK" 2>/dev/null || { echo "BLOCKED: lock race"; exit 75; }
  fi
fi
trap 'rmdir "$LOCK" 2>/dev/null' EXIT
echo "[lock] acquired $LOCK"

# ---- stale-golden guard: seeds ALWAYS copied fresh from the capture dir ----
SRC="$MT/scene_checkpoints/mame/start_seed$SEED"
[ -d "$SRC" ] || { echo "ERROR: no capture at $SRC"; exit 1; }
mkdir -p "$ROOT/sim/build"
cp "$SRC"/seed_regs.txt "$SRC"/seed_ram.hex "$SRC"/seed_cmos.hex "$SRC"/seed_palette.hex \
   "$SRC"/seed_vram.hex "$SRC"/seed_ioregs.hex "$SRC"/seed_dmaregs.hex "$SRC"/seed_control.hex \
   "$SRC"/full_state.txt "$SRC"/io_reads.txt "$SRC"/hcount_log.txt "$SRC"/ram_writes.txt \
   "$ROOT/sim/build/" || { echo "ERROR: seed copy failed"; exit 1; }
echo "[seeds] window $SEED copied from $SRC"

# ---- compile + run ----
cd "$ROOT/sim"; rm -rf work; "$VLIB" work >/dev/null
SRCS=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRCS+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRCS+=( "$ROOT/sim/$TB.sv" )
echo "[vlog] ${#SRCS[@]} sources"
"$VLOG" -sv -quiet -svinputport=var "${SRCS[@]}" 2>&1 | grep -iE "error|\*\*" | head -20
LOG="$ROOT/sim/build/${TB}_seed$SEED.vsim.log"
echo "[vsim] $TB (seed $SEED) -> $LOG"
set +e
"$VSIM" -c -quiet -suppress 7061 -do "run -all; quit" "$TB" 2>&1 | tee "$LOG" | \
  grep -iE "loaded|SEED |DIVERGE|CULPRIT|class =|RESULT|CENSUS|REAL|IO-GAP|VRAM-GAP|GFX-GAP|IOSEQ|hb\]|Fatal|Error|license" | head -80
rc=$?
set -e
grep -q "RESULT:" "$LOG" || { echo "FAIL: no RESULT token (crash/license?) — see $LOG"; exit 1; }
echo "[done] full log: $LOG"
