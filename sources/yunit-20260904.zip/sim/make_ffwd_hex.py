#!/usr/bin/env python3
# Regenerate the fast-forward sim ROM. Patches the long power-on self-test loops
# to return immediately (pass) so integrated sims reach attract/gameplay without
# grinding through the ~140M-cycle POST + the multi-ROM checksums. HW keeps the
# real self-test; this is a sim-only ROM.
#
# Each patched routine is entered via `EXGPC B5` (the caller loads B5 with the
# routine addr, CLRs B0, then EXGPC B5 — so B5 holds the return addr and B0=0 on
# entry). Overwriting the routine's FIRST word with 0x0135 (EXGPC B5) makes it
# return immediately with B0=0 = "no error", exactly like the routine's own
# natural EXGPC-B5 exit.
#
# Patches:
#   0xfff4ec20  0xb7cc MOVE   -> 0x0135 EXGPC B5   POST RAM/VRAM test + gfx checksum
#   The shortcut is deliberately after RAMCHECK's SETF16, SETF32, and CLR B2
#   prologue so its caller-visible field widths/register state match a pass.
#
# Usage:  python3 sim/make_ffwd_hex.py    (run from repo root; needs build/*.hex)
import sys
src = "sim/build/smashtv_maindata.hex"
dst = "sim/build/smashtv_maindata_ffwd.hex"
PATCHES = [
    (0xfff4ec20, "b7cc", "0135"),   # POST RAM/VRAM test -> EXGPC B5 after its
                                    # caller-visible SETF/CLR prologue
    # DSCRCLR's setup has already selected color map 0 and established its
    # documented scratch registers here.  The simulation SDRAM model is
    # deterministically zero-initialized, so 65,536 longword writes would only
    # rewrite the same zeros.  Return at the first loop store; hardware never
    # uses this patched image, and the unpatched MAME-prefix gate remains exact.
    (0xfff505f0, "9253", "0136"),   # MOVE B2,*B3+,L -> FRET B6
    # POST diagnostic drawing is erased by the real CLR_SCRN before GAMELOOP.
    # Keep the tests, pass/fail state, palette setup, and clear itself; branch
    # from CPUDRAW's FCALL directly to the existing A12 error-flow test.  The
    # skipped register setup is used only as painter arguments and all relevant
    # return registers are overwritten before their next use.
    (0xfff48120, "0135", "c010"),   # EXGPC B5 -> JRUC FFF48230
    (0xfff4f680, "0135", "0300"),   # ROMCHECK per-chip CHIPOUT -> NOP
    # The remaining clean-path POST painters have no test/status result and all
    # of their pixels are erased by the real pre-GAMELOOP CLR_SCRN.  Suppress
    # only their call-transfer words; error-path painters stay intact.
    (0xfff48360, "0136", "0300"),   # STRING "CHECKING CUSTOM"
    (0xfff48440, "0135", "0300"),   # CHIPOUT DMA result
    (0xfff48500, "0136", "0300"),   # RECTANGLE erase DMA line
    (0xfff48630, "0136", "0300"),   # STRING "CHECKING SCRATCH RAMS"
    (0xfff48880, "0136", "0300"),   # RECTANGLE erase SRAM line
    (0xfff48970, "0136", "0300"),   # STRING "CHECKING ROMS"
    (0xfff48b60, "0136", "0300"),   # RECTANGLE erase ROM line
    (0xfff48e80, "0136", "0300"),   # STRING "CPU BOARD OK"
    # ROM checksum ("CHECKING ROMS", fff4f170): a per-descriptor byte-sum that GATES
    # (CMP expected,computed -> sets a bad-ROM bit in B0) and walks A14 += 0xA0 per ROM.
    # A blind EXGPC-skip of the whole routine leaves A14 at the descriptor-table base and
    # B0's cascade wrong -> main code derails into font data. Instead, keep the descriptor
    # walk + display intact and only (a) short-circuit the slow inner byte-sum loop and
    # (b) force the compare to pass (our maindata is byte-exact + gfx unpack is MAME-
    # verified, so the real ROMs WOULD pass; HW keeps the real check). State-faithful:
    # A14 walks to FFF54AF0 and B0 stays clean, matching MAME at FFE0F8A0.
    (0xfff4f450, "3f6d", "0300"),   # byte-sum loop A (planar) DSJS A13,fff4f2b0 -> NOP
    (0xfff4f4f0, "3ccd", "0300"),   # byte-sum loop B (linear) DSJS A13,fff4f4a0 -> NOP
    (0xfff4f550, "ca06", "c006"),   # checksum cmp   JREQ fff4f5c0     -> JR (always "pass")
    # Post-self-test "show the screen" delay: MOVI 600000h,B6; NOP; DSJS B6,self
    # (~30M cyc). Shrink the count to 4 so sim reaches the SP check + main code.
    (0xfff48ea0, "0000", "0004"),   # delay count MOVI 600000h,B6 low word  -> 4
    (0xfff48eb0, "0060", "0000"),   # delay count high word                 -> 0
]
if "--debug-short-clear" in sys.argv:
    # Debug-only acceleration for iterating post-GAMELOOP observability.  This
    # changes only CLR_SCRN's DSJS count after its real stack save, DMA wait,
    # CMAPSEL setup, screen pointer setup and A2 initialization.  Release
    # qualification never passes this option and therefore executes all 0xff00
    # longword clears.
    PATCHES.append((0xffe07fb0, "ff00", "0004"))
lines = open(src).read().split("\n")
cr = "\r" if (lines and lines[0].endswith("\r")) else ""
for addr, want, new in PATCHES:
    # smashtv_maindata.hex models MAME's complete 1 MiB maindata region,
    # mapped at bit address 0xff800000.  The program occupies its upper
    # 0x20000 words; indexing as though the file began at 0xffe00000 would
    # silently target the zero-filled hole 0x60000 words too early.
    idx = (addr - 0xff800000) >> 4
    cur = lines[idx].strip().lower()
    assert cur == want, f"@0x{addr:08x} (idx 0x{idx:x}) expected {want!r}, found {cur!r}"
    lines[idx] = new + cr
    print(f"patched @0x{addr:08x} (idx 0x{idx:x}): {want} -> {new} (EXGPC B5)")
open(dst, "w", newline="").write("\n".join(lines))
print(f"wrote {dst}")
