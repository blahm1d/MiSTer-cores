#!/usr/bin/env bash
# GATE: the ADPCM board's 6809 runs at (near) its gospel 2 MHz, and no stale
# byte ever reaches the OKI decoder's schedule-slot latch.
#
# WHY THE BAR IS 1.9 MHz. MAME (mame-trace/adpcm_ym_cadence.lua, totcarn):
# the sound driver runs YM2151 timer A at a 72 us FIRQ tick -- ~143 CPU cycles
# of service budget per interrupt at the gospel 2.00 MHz. The pre-fix per-byte
# ext-ROM cache measured 1.70 MHz effective (tb_adpcm_cpu_pace, PHYS_LATENCY=6,
# the same charitable SDRAM as the starve gate) -- the whole budget gone, which
# is the cabinet's "music too slow / single notes stuck". 5% grace covers
# genuine cold-miss wait states.
#
# Runs the mutation control every invocation: -DMUT_PACE_EAGER_STALL reverts
# to the whole-divider freeze (the pre-fix stall) and MUST fail the bar.
#
# EAGER_STALL kill scope (2026-08-18): the single-clock fixbank drove polite
# rom_wait to 0.0% -- with zero waits the mutant is IDENTICAL to the fix and
# survived both the polite AND hostile legs (measured 2.000 / 1.990 MHz).
# The eager-stall fix is load-bearing on the ext-ROM cache path, so its kill
# control runs -DMUT_PACE_NO_FIXBANK both ways: NO_FIXBANK alone polite is
# the PASS control (2.000 MHz at 24.5% rom_wait), NO_FIXBANK+EAGER_STALL
# must FAIL (measured 1.616 MHz -- the historical whole-freeze pace).
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IV="${IV:-iverilog}"

command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }

if [ ! -s "$ROOT/sim/build/totcarn_sound.hex" ]; then
  python "$ROOT/sim/make_adpcm_hex.py" \
    "${YUNIT_TC_ZIP:-D:/deck/fpga/smash tv/roms/totcarn.zip}" \
    "$ROOT/sim/build/totcarn_sound.hex" \
    || { echo "GATE_INCONCLUSIVE: cannot stage totcarn sound image"; exit 77; }
fi

SRC=("$ROOT/rtl/pkg/yunit_pkg.sv")
for f in "$ROOT"/rtl/sound/jt51/hdl/*.v; do SRC+=("$f"); done
for f in "$ROOT"/rtl/sound/jt6295/*.v;   do SRC+=("$f"); done
SRC+=("$ROOT/rtl/sound/williams_cvsd/mc6809is.v"
      "$ROOT/rtl/yunit/yunit_sound_cdc.sv"
      "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv"
      "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
      "$ROOT/rtl/yunit/yunit_audio_mix.sv"
      "$ROOT/rtl/yunit/yunit_adpcm_board.sv"
      "$ROOT/sim/tb_adpcm_cpu_pace.sv")

D="$ROOT/sim/build"
"$IV" -g2012 -s tb_adpcm_cpu_pace -o "$D/pace.vvp"  "${SRC[@]}" 2>&1 | grep -v "sorry:" || true
"$IV" -g2012 -DMUT_PACE_NO_FIXBANK -s tb_adpcm_cpu_pace -o "$D/pacef.vvp" "${SRC[@]}" 2>&1 | grep -v "sorry:" || true
"$IV" -g2012 -DMUT_PACE_NO_FIXBANK -DMUT_PACE_EAGER_STALL -s tb_adpcm_cpu_pace -o "$D/pacemf.vvp" "${SRC[@]}" 2>&1 | grep -v "sorry:" || true

(cd "$ROOT/sim" && vvp "$D/pace.vvp"   +BAR_MHZ=1.9) | tee "$D/pace.log"
(cd "$ROOT/sim" && vvp "$D/pacef.vvp"  +BAR_MHZ=1.9) | tee "$D/pace_nofix.log" >/dev/null
(cd "$ROOT/sim" && vvp "$D/pacemf.vvp" +BAR_MHZ=1.9) | tee "$D/pace_mutant.log" >/dev/null

grep -q "TEST_RESULT: PASS" "$D/pace.log" \
  || { echo "GATE FAIL: adpcm_pace -- the 6809 is under the gospel pace bar (or stale OKI bytes)"; exit 1; }
grep -q "TEST_RESULT: PASS" "$D/pace_nofix.log" \
  || { echo "GATE FAIL: adpcm_pace -- the ext-ROM cache path alone no longer holds the pace bar (eager-stall differential control broken)"; exit 1; }
grep -q "TEST_RESULT: FAIL" "$D/pace_mutant.log" \
  || { echo "GATE_INCONCLUSIVE: the MUT_PACE_EAGER_STALL mutant SURVIVED the pace bar on the ext-cache path"; exit 77; }

# HOSTILE leg (2026-08-18): the polite port hid the cabinet defect entirely --
# 2.000 MHz here was 0.633 MHz with FIRQ starved to ZERO under MK-class
# scanout/blit bursts. The bar must hold under the burst profile, and the
# fixed-bank BRAM is the load-bearing mechanism: its kill control must
# collapse exactly the way the cabinet did.
HOSTILE="+BAR_MHZ=1.9 +PHYS_LAT=30 +HOG_BEATS=48 +HOG_GAP=12"
(cd "$ROOT/sim" && vvp "$D/pace.vvp" $HOSTILE) | tee "$D/pace_hostile.log"
grep -q "TEST_RESULT: PASS" "$D/pace_hostile.log" \
  || { echo "GATE FAIL: adpcm_pace HOSTILE -- the 6809 collapses under port bursts"; exit 1; }
(cd "$ROOT/sim" && vvp "$D/pacef.vvp" $HOSTILE) | tee "$D/pace_nofix_mutant.log" >/dev/null
grep -q "TEST_RESULT: FAIL" "$D/pace_nofix_mutant.log" \
  || { echo "GATE_INCONCLUSIVE: the MUT_PACE_NO_FIXBANK mutant SURVIVED the hostile leg"; exit 77; }

echo "ADPCM-PACE: PASS (>=1.9 MHz polite AND burst-hostile, zero stale OKI bytes, both mutants killed)"
