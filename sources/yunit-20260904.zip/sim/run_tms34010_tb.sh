#!/usr/bin/env bash
# Run a vendored tms34010 core testbench under Icarus (licence-free).
#
#   ./run_tms34010_tb.sh tb_move_off_ni [-DMUT_...]
#
# The vendored core uses SystemVerilog port styles Icarus rejects
# (`input wire <typedef> port`), so the whole set goes through the same sv2v
# the production netlist uses. Mutant defines are passed straight to sv2v.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
TB="${1:-tb_move_off_ni}"; shift || true
OUT="$ROOT/sim/build/tms34010"
mkdir -p "$OUT"

SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done \
  < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$CORE/sim/models/sim_memory_model.sv" "$CORE/sim/tb/$TB.sv" )

"$SV2V" "$@" "${SRC[@]}" > "$OUT/$TB.v"
iverilog -g2012 -o "$OUT/$TB.vvp" "$OUT/$TB.v"
# Keep the transcript: piping vvp into grep would return grep's status.
set +e
vvp "$OUT/$TB.vvp" > "$OUT/$TB.log" 2>&1
VVP_STATUS=$?
set -e
grep -E "TEST_RESULT" "$OUT/$TB.log" || true
[ "$VVP_STATUS" -eq 0 ] || { echo "RUNNER: $TB vvp exit $VVP_STATUS"; exit "$VVP_STATUS"; }
grep -q "TEST_RESULT: PASS" "$OUT/$TB.log" \
  || { echo "RUNNER: $TB FAILED (no PASS marker)"; exit 1; }
echo "RUNNER: $TB OK"
