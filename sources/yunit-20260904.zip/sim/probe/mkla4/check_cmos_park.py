#!/usr/bin/env python3
"""GATE: the cold-CMOS park contract for the Y-unit family, measured in MAME 0.280.

CLAIM UNDER TEST
  With an all-zero CMOS (MAME's no-.nv cold boot -- docs/mame-ref/midyunit.cpp:1257
  nvram_device::DEFAULT_ALL_0, the same image the FPGA core presents from its
  zero-initialised BRAM), mkla4 and trog STOP at the self-test screen
  "CMOS INVALID -- FACTORY SETTINGS RESTORED / ERRORS DETECTED -- ANY BUTTON TO
  CONTINUE" and issue ZERO blits, while smashtv and totcarn walk straight past it
  and render.  ONE button press releases mkla4 within a handful of frames and it
  then renders identically to a warm-CMOS boot.

WHY THIS MATTERS
  It is a real, MK-visible, mostly-black first-boot screen -- but it is NOT unique to
  MK (trog does it too, and trog boots on the cabinet), and it is escapable by any
  button, and it paints VISIBLE red/yellow text (~3% of sampled pixels lit) rather
  than a truly black frame.  Keeping it as a gate stops it being re-derived, and
  stops anyone claiming a truly-black MK cabinet screen is "just the CMOS screen".

Regenerate the inputs with:
  ./cmosaudit_run.sh mkla4   1800 cold      # -> ca_mkla4_cold.txt
  MK_PRESS_FRAME=300 ./cmosaudit_run.sh mkla4 1800 cold ; mv ca_mkla4_cold.txt ca_mkla4_coldpress.txt
  ./cmosaudit_run.sh trog    1800 cold
  ./cmosaudit_run.sh smashtv 1800 cold
  ./cmosaudit_run.sh totcarn 1800 cold
  ./cmosaudit_run.sh mkla4   1800 warm      # after the cold run saved a .nv
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PRESS_FRAME = 300


def load(tag):
    path = os.path.join(HERE, "ca_%s.txt" % tag)
    if not os.path.exists(path):
        return None, "missing capture %s" % path
    vals = {}
    seen_summary = False
    with open(path) as fh:
        for line in fh:
            if line.startswith("== SUMMARY =="):
                seen_summary = True
                continue
            if line.startswith("NOTIFIER_ERROR"):
                return None, "%s: the capture's frame notifier threw -- capture VOID" % tag
            if seen_summary:
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        vals[parts[0]] = int(parts[1])
                    except ValueError:
                        pass
    if not seen_summary:
        return None, "%s: no SUMMARY block -- the run did not reach its stop frame" % tag
    return vals, None


def main():
    fails = []
    cov = []

    # ---- COVERAGE / SELF-VOIDING INVARIANTS. Zero coverage is a FAIL, never a pass.
    data = {}
    for tag in ("mkla4_cold", "mkla4_coldpress", "mkla4_warm",
                "trog_cold", "smashtv_cold", "totcarn_cold"):
        vals, err = load(tag)
        if err:
            fails.append(err)
            continue
        data[tag] = vals
        if vals.get("frames_seen", 0) <= 0:
            fails.append("%s: frames_seen=0 -- capture VOID" % tag)
        if vals.get("dma_window_writes", 0) <= 0:
            fails.append("%s: dma_window_writes=0 -- the DMA tap never fired, capture VOID"
                         % tag)
        cov.append("%-16s frames=%d dma_window_writes=%d blits=%d first_blit=%d "
                   "first_lit=%d black_frames=%d cmosW=%d"
                   % (tag, vals.get("frames_seen", -1), vals.get("dma_window_writes", -1),
                      vals.get("blits", -1), vals.get("first_blit_frame", -1),
                      vals.get("first_lit_frame", -1), vals.get("black_frames", -1),
                      vals.get("cmos_writes", -1)))
    if fails:
        for c in cov:
            print("COVERAGE " + c)
        for f in fails:
            print("FAIL " + f)
        return 1

    # ---- CONTRACT 1: mkla4 and trog PARK on a cold CMOS -- zero blits for the whole run.
    for tag in ("mkla4_cold", "trog_cold"):
        if data[tag]["blits"] != 0:
            fails.append("%s: expected 0 blits on a cold CMOS, got %d"
                         % (tag, data[tag]["blits"]))
        if data[tag]["first_blit_frame"] != -1:
            fails.append("%s: expected no first blit, got frame %d"
                         % (tag, data[tag]["first_blit_frame"]))
        # the park screen is NOT black: it paints the red/yellow self-test text.
        if data[tag]["black_frames"] >= data[tag]["frames_seen"]:
            fails.append("%s: park screen measured fully black for the whole run "
                         "(%d/%d) -- that contradicts the captured PNG"
                         % (tag, data[tag]["black_frames"], data[tag]["frames_seen"]))

    # ---- CONTRACT 2: smashtv and totcarn do NOT park -- they render on a cold CMOS.
    for tag in ("smashtv_cold", "totcarn_cold"):
        if data[tag]["blits"] <= 0:
            fails.append("%s: expected a cold CMOS to render, got %d blits"
                         % (tag, data[tag]["blits"]))

    # ---- CONTRACT 3: one button press releases mkla4, and it then renders like warm.
    p = data["mkla4_coldpress"]
    if p["blits"] <= 0:
        fails.append("mkla4_coldpress: a button press did not release the park (%d blits)"
                     % p["blits"])
    elif not (PRESS_FRAME <= p["first_blit_frame"] <= PRESS_FRAME + 10):
        fails.append("mkla4_coldpress: first blit at frame %d, expected within 10 frames "
                     "of the press at %d" % (p["first_blit_frame"], PRESS_FRAME))
    if p["blits"] != data["mkla4_warm"]["blits"]:
        fails.append("mkla4_coldpress: released-cold blit total %d != warm-CMOS total %d "
                     "-- the released path is NOT the warm path"
                     % (p["blits"], data["mkla4_warm"]["blits"]))

    # ---- CONTRACT 4: the park is not a CMOS-write failure. Both parking titles DO
    # write the factory-restored image, so a working save path fixes the next boot.
    for tag in ("mkla4_cold", "trog_cold"):
        if data[tag]["cmos_writes"] <= 0:
            fails.append("%s: parked without writing CMOS -- factory restore did not run"
                         % tag)

    for c in cov:
        print("COVERAGE " + c)
    for f in fails:
        print("FAIL " + f)
    print("GATE %s (%d contracts checked over %d captures)"
          % ("FAIL" if fails else "PASS", 4, len(data)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
