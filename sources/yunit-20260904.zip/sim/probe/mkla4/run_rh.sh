#!/usr/bin/env bash
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; stride="$2"; secs="${3:-40}"
NV="$D/nvrh_${g}_${stride}"; rm -rf "$NV"; mkdir -p "$NV"; cp -r "$D/nvwarm/$g" "$NV/$g"
mkdir -p "$D/snaprh_${g}_${stride}"
RH_STRIDE=$stride RH_OUT="$D/rh_${g}_${stride}.txt" RH_SECS=$secs \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$NV" \
  -snapshot_directory "$D/snaprh_${g}_${stride}" \
  -autoboot_script "$D/romhole_mkla4.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
  > "$D/rhlog_${g}_${stride}.txt" 2>&1
grep -m1 '^RH\[' "$D/rhlog_${g}_${stride}.txt" || echo "NO RH LINE ($g/$stride)"
