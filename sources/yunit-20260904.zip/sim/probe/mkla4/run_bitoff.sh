#!/usr/bin/env bash
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; secs="${2:-60}"
rm -rf "$D/nvb_$g"; mkdir -p "$D/nvb_$g"; cp -r "$D/nvwarm/$g" "$D/nvb_$g/$g"
BO_OUT="$D/bo_$g.txt" BO_SECS=$secs \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvb_$g" \
  -autoboot_script "$D/bitoff_probe.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
  > "$D/bolog_$g.txt" 2>&1
grep -m1 '^BO:' "$D/bolog_$g.txt" || echo "NO BO LINE -- CHECK $D/bolog_$g.txt"
