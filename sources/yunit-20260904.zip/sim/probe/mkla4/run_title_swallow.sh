#!/usr/bin/env bash
# run_title_swallow.sh -- sweep the SRC-1 swallow across the family's real plane-word
# ratios.  iverilog only.  Rigs are reused verbatim from sim/probe/impl-tc-hi/.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
RIG="$ROOT/sim/probe/impl-tc-hi"
cd "$ROOT"

SRC=(
  "$RIG/rig_f2_fixed.sv" "$RIG/rig_f2_prefix.sv"
  "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" "$ROOT/rtl/sdram/sdram_stock.sv"
  "$ROOT/sim/sdram_chip.sv" "$HERE/tb_title_swallow.sv"
)

# title            plane_words   R = 7*pw/0x100000
#   MK / TERM2      0x100000     7.00  -> TPW 96
#   TOTCARN         0x080000     3.50  -> TPW 48
#   TROG            0x060000     2.63  -> TPW 36
#   SMASHTV         0x030000     1.31  -> TPW 18
run_one() {  # $1=name $2=TPW
  echo "=================== $1  (TPW=$2) ==================="
  iverilog -g2012 -I"$RIG" -DTPW=$2 -DTNAME="\"$1\"" -o "$HERE/ts_$1.vvp" "${SRC[@]}" || return 2
  vvp "$HERE/ts_$1.vvp" 2>&1 | tee "$HERE/ts_$1.log"
  return "${PIPESTATUS[0]}"
}

rc=0
run_one MK_TERM2 96 || rc=1
run_one TOTCARN   48 || rc=1
run_one TROG      36 || rc=1
run_one SMASHTV   18 || rc=1
echo
echo "---- summary ----"
grep -h "RESULT" "$HERE"/ts_*.log
exit $rc
