#!/usr/bin/env bash
# run_prot.sh GAME MODE SECS
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; mode="$2"; secs="${3:-40}"
NV="$D/nvpr_${g}_${mode}"
rm -rf "$NV"; mkdir -p "$NV"; cp -r "$D/nvwarm/$g" "$NV/$g"
mkdir -p "$D/snappr_${g}_${mode}"
PROT_MODE="$mode" PR_OUT="$D/pr_${g}_${mode}.txt" PR_SECS=$secs \
PR_SNAP="$D/snappr_${g}_${mode}" \
"$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$NV" \
  -snapshot_directory "$D/snappr_${g}_${mode}" \
  -autoboot_script "$D/inject_prot.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+15)) -nothrottle -skip_gameinfo \
  > "$D/prlog_${g}_${mode}.txt" 2>&1
grep -m1 '^PR\[' "$D/prlog_${g}_${mode}.txt" || echo "NO PR LINE ($g/$mode)"
