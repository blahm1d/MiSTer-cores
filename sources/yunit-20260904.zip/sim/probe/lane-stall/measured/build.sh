#!/usr/bin/env bash
# iverilog only (Questa is nodelocked to one vsim across five sessions -- do not use it).
# Shipping defines: USE_DDR3_VRAM, YUNIT_NO_COMMITGATE, YUNIT_CVSD_BRAM_SOUND.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$D/../../../.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
mkdir -p "$D/out"

iverilog -g2012 -s tb_lane_measure \
  -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND -DSIM_NO_ALTERA \
  -o "$D/out/lane_measure.vvp" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/sdram/sdram_stock.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_arb.sv" \
  "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/rtl/yunit/family2/yunit_video_family2.sv" \
  "$ROOT/rtl/yunit/family2/yunit_scanline_family2.sv" \
  "$ROOT/rtl/yunit/family2/yunit_video_top_family2.sv" \
  "$ROOT/sim/sdram_chip.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$D/tb_lane_measure.sv"
echo "built $D/out/lane_measure.vvp"
