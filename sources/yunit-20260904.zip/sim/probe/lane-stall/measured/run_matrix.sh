#!/usr/bin/env bash
# Full lane-stall matrix. iverilog only; every arm is an independent vvp so they parallelise.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
cd "$D"
V="$D/out/lane_measure.vvp"
CV="../../hi-sound-stream/out"
mkdir -p out/logs

run () {  # run <tag> <args...>
  local tag="$1"; shift
  vvp "$V" +TAG="$tag" "$@" > "out/logs/$tag.log" 2>&1 &
}

# ---------------- A: instrument cross-checks (hiimpact geometry, no contention) -----------
run xchk-ideal-ideal +DESC=out/desc_hiimpact.hex +SRC=0 +FB=0 +SND=0 +CGFX=0 +SCAN=0 +ERASE=0
run xchk-realsrc     +DESC=out/desc_hiimpact.hex +SRC=1 +FB=0 +SND=0 +CGFX=0 +SCAN=0 +ERASE=0
run xchk-realfb      +DESC=out/desc_hiimpact.hex +SRC=0 +FB=1 +SND=0 +CGFX=0 +SCAN=0 +ERASE=0
run xchk-realfb-quiet +DESC=out/desc_hiimpact.hex +SRC=0 +FB=1 +SND=0 +CGFX=0 +SCAN=0 +ERASE=0
wait

# ---------------- B: shipping operating point, per title, own client mix ------------------
# HI/SHI stream CVSD sound from SDRAM (YS_CVSD_LARGE); Smash/Trog are BRAM-resident.
run hiimpact-ship +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=0 +SCAN=1 +ERASE=1
run shimpact-ship +DESC=out/desc_shimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_shimpact.txt +CGFX=0 +SCAN=1 +ERASE=1
run smashtv-ship  +DESC=out/desc_smashtv.hex  +SRC=1 +FB=1 +SND=0 +CGFX=0 +SCAN=1 +ERASE=1
run trog-ship     +DESC=out/desc_trog.hex     +SRC=1 +FB=1 +SND=0 +CGFX=0 +SCAN=1 +ERASE=1
wait

# ---------------- C: THE A/B -- hiimpact's blit stream with and without the sound client ---
run hi-snd-on  +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=0 +SCAN=1 +ERASE=1
run hi-snd-off +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=0 +CGFX=0 +SCAN=1 +ERASE=1
run shi-snd-on  +DESC=out/desc_shimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_shimpact.txt +CGFX=0 +SCAN=1 +ERASE=1
run shi-snd-off +DESC=out/desc_shimpact.hex +SRC=1 +FB=1 +SND=0 +CGFX=0 +SCAN=1 +ERASE=1
wait

# ---------------- D: decomposition + sensitivity (hiimpact) -------------------------------
run hi-noscan-noerase +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=0 +SCAN=0 +ERASE=0
run hi-scan-noerase   +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=0 +SCAN=1 +ERASE=0
run hi-cgfx32         +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=32 +SCAN=1 +ERASE=1
run hi-cgfx8          +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=8 +SCAN=1 +ERASE=1
wait
run hi-transp35       +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=0 +SCAN=1 +ERASE=1 +TRANSP=35
run hi-ddrstress      +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=0 +SCAN=1 +ERASE=1 +BUSY=20 +RLAT=12
run hi-ddrideal       +DESC=out/desc_hiimpact.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_hiimpact.txt +CGFX=0 +SCAN=1 +ERASE=1 +BUSY=1 +RLAT=1
run stv-snd-on        +DESC=out/desc_smashtv.hex +SRC=1 +FB=1 +SND=1 +TRACE=$CV/cvsdtrace_smashtv.txt +CGFX=0 +SCAN=1 +ERASE=1
wait

grep -h "^RESULT\|^FAIL" out/logs/*.log | sort
