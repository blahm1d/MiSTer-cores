#!/usr/bin/env bash
# iverilog only. Shipping defines: USE_DDR3_VRAM, YUNIT_NO_COMMITGATE, YUNIT_CVSD_BRAM_SOUND.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$D/../../.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
mkdir -p "$D/out"

EXTRA=""
TAG=""
while true; do
  case "$1" in
    comback) EXTRA="$EXTRA -DSRCCACHE_COMBACK"; TAG="${TAG}_cb"; shift;;
    combwe)  EXTRA="$EXTRA -DDMA_COMBWE";       TAG="${TAG}_cw"; shift;;
    early)   EXTRA="$EXTRA -DDMA_EARLY";        TAG="${TAG}_ea"; shift;;
    *) break;;
  esac
done
OUTV="$D/out/lane_stall${TAG}.vvp"

iverilog -g2012 -gsupported-assertions -s tb_lane_stall \
  -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND -DSIM_NO_ALTERA \
  $EXTRA \
  -o "$OUTV" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/sdram/sdram_stock.sv" \
  "$ROOT/sim/sdram_chip.sv" \
  "$D/mut/yunit_src_cache_comback.sv" \
  "$D/mut/yunit_dma_family2_combwe.sv" \
  "$D/mut/yunit_dma_family2_early.sv" \
  "$D/tb_lane_stall.sv"
cd "$D"
vvp "$OUTV" "$@"
