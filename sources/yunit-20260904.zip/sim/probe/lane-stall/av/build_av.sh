#!/usr/bin/env bash
# Adversarial-verifier build: same file list as measured/build.sh + mut DUTs, DUT selected by define.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$D/../../../.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
mkdir -p "$D/out"
mk () { # mk <name> <extra defines...>
  local n="$1"; shift
  iverilog -g2012 -s tb_lane_measure \
    -DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND -DSIM_NO_ALTERA "$@" \
    -o "$D/out/$n.vvp" \
    "$ROOT/rtl/pkg/yunit_pkg.sv" \
    "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" \
    "$ROOT/rtl/sdram/yunit_src_cache.sv" \
    "$D/../mut/yunit_dma_family2_combwe.sv" \
    "$D/../mut/yunit_src_cache_comback.sv" \
    "$ROOT/rtl/sdram/sdram_stock.sv" \
    "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
    "$ROOT/rtl/sdram/yunit_sdram_arb.sv" \
    "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" \
    "$ROOT/rtl/yunit/vram_sdram.sv" \
    "$ROOT/rtl/yunit/vram_sdram_top.sv" \
    "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
    "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
    "$ROOT/rtl/yunit/family2/yunit_video_family2.sv" \
    "$ROOT/rtl/yunit/family2/yunit_scanline_family2.sv" \
    "$ROOT/rtl/yunit/family2/yunit_video_top_family2.sv" \
    "$ROOT/sim/sdram_chip.sv" \
    "$ROOT/sim/ddr3_avalon_model.sv" \
    "$D/tb_av_measure.sv"
  echo "built out/$n.vvp"
}
mk av_base
mk av_m1 -DAV_COMBACK
mk av_m2 -DAV_COMBWE
mk av_m1m2 -DAV_COMBACK -DAV_COMBWE
