#!/usr/bin/env bash
# RC5 sound-ROM-cache reset gate. iverilog only (no Questa).
set -e
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
D="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(cd "$D/../../.." && pwd)"; cd "$D"

iverilog -g2012 -DSIM_NO_ALTERA -s tb_rc5_cachereset -o rc5.vvp \
  "$ROOT/rtl/sdram/sdram_stock.sv" \
  "$ROOT/sim/sdram_chip.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_arb.sv" \
  "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" \
  "$ROOT/rtl/sound/williams_cvsd/mc6809is.v" \
  "$D/tb_rc5_cachereset.sv" 2>&1 | grep -v "sorry: constant selects" || true

vvp rc5.vvp

echo
echo "###### REGRESSION ARM: BRAM-resident titles (Smash T.V. / Trog) ######"
vvp rc5.vvp +BRAM=1
