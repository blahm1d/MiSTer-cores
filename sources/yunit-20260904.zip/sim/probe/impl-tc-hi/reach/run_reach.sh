#!/usr/bin/env bash
# RC5 REACHABILITY: prove by HIERARCHY (not by grepping the source) that the edited
# instance is compiled in under BOTH shipping define sets.
#
# Method: re-run the EXACT sv2v step the build runs (quartus/build_sv2v.sh, copied here
# with only the output path parameterised) with each shipping SV2V_EXTRA, into a scratch
# file.  build_syn/smashtv_core.v is NOT touched, and no Quartus stage is invoked.
# The generated blob is the literal netlist Quartus compiles (files.qip:12).
set -e
export PATH="/usr/bin:/mingw64/bin:$PATH"
D="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(cd "$D/../../../.." && pwd)"
SCRATCH="${SCRATCH:-$D/out}"
mkdir -p "$SCRATCH"

check() {
  local name="$1"; shift
  local extra="$1"; shift
  local out="$SCRATCH/core_${name}.v"
  echo "===== $name :  SV2V_EXTRA='$extra' ====="
  SV2V_EXTRA="$extra" OUT="$out" ROOT="$ROOT" bash "$D/sv2v_to.sh" >/dev/null
  local n
  n=$(grep -c "yunit_sound_rom_cache u_sound_rom_cache" "$out" || true)
  echo "  instances of yunit_sound_rom_cache u_sound_rom_cache : $n"
  if [ "$n" != "1" ]; then echo "  FAIL: expected exactly 1"; return 1; fi
  echo "  --- as compiled ---"
  grep -A4 "yunit_sound_rom_cache u_sound_rom_cache" "$out" | sed 's/^/    /'
  if grep -A4 "yunit_sound_rom_cache u_sound_rom_cache" "$out" | grep -q "sdram_por | ioctl_download"; then
    echo "  REACHABLE: the RC5 reset term IS in the compiled netlist."
  else
    echo "  FAIL: the RC5 reset term is NOT in the compiled netlist (dead branch)."
    return 1
  fi
  # the top that carries it must be the one emu selects
  grep -c "^module yunit_top_family2" "$out" | sed 's/^/  yunit_top_family2 module defs: /'
  echo
}

rc=0
check family2 "-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_CVSD_BRAM_SOUND" || rc=1
check adpcmfull "-DUSE_DDR3_VRAM -DYUNIT_NO_COMMITGATE -DYUNIT_ADPCM -DYUNIT_FULL" || rc=1

echo "===== CORE_TOP selection (Arcade-SmashTV.sv, Quartus-native, NOT sv2v'd) ====="
sed -n '194,202p;681,692p' "$ROOT/Arcade-SmashTV.sv" | sed 's/^/  /'
echo
if [ $rc -eq 0 ]; then echo "REACHABILITY: PASS (both shipping define sets)"; else echo "REACHABILITY: FAIL"; fi
exit $rc
