#!/usr/bin/env bash
# ONE oracle, ANY tree.  Runs the SUB/SUBB/CMP carry-flag gate
# (tb_tms34010_sub_cflag.sv) against whichever tree's ALU you point it at.
#
#   PKG=<path to tms34010_pkg.sv> ALU=<path to tms34010_alu.sv> \
#   TB=<path to tb_tms34010_sub_cflag.sv> ./run_sub_cflag.sh
#
# The TB is the GOSPEL transcription (34010ops.hxx:66); PKG/ALU are the tree
# under test.  Nothing here is tree-specific.
#
# The run is MUTATION-CONTRACTED IN THE SAME INVOCATION: after the live ALU is
# checked, a mutant copy is generated with the defective form
#     flags.c = !sub_ext[DATA_WIDTH]
# substituted for the fixed form, and the script ASSERTS that the mutant FAILS.
# A pass without a demonstrated kill exits non-zero.
set -uo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

: "${PKG:?set PKG=<tms34010_pkg.sv>}"
: "${ALU:?set ALU=<tms34010_alu.sv>}"
: "${TB:?set TB=<tb_tms34010_sub_cflag.sv>}"
OUT="${OUT:-$(cd "$(dirname "$0")" && pwd)/build}"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
mkdir -p "$OUT"

run_one () {  # $1 = tag, $2 = alu source
  "$SV2V" "$PKG" "$2" "$TB" > "$OUT/$1.v" 2> "$OUT/$1.sv2v.err" || {
    echo "[$1] sv2v FAILED"; cat "$OUT/$1.sv2v.err"; return 99; }
  iverilog -g2012 -o "$OUT/$1.vvp" "$OUT/$1.v" 2> "$OUT/$1.iv.err" || {
    echo "[$1] iverilog FAILED"; cat "$OUT/$1.iv.err"; return 99; }
  vvp "$OUT/$1.vvp" > "$OUT/$1.log" 2>&1
  grep -E "^(PASS|RESULT|FAIL)" "$OUT/$1.log" | head -5
  grep -q "^PASS: tb_tms34010_sub_cflag" "$OUT/$1.log"
}

echo "=== LIVE: $ALU"
run_one live "$ALU"; LIVE=$?

# ---- mutant: restore the defective adder-carry-out form --------------------
MUT="$OUT/tms34010_alu_MUTANT.sv"
sed 's/flags\.c  = (b > a);/flags.c  = !sub_ext[DATA_WIDTH];/' "$ALU" > "$MUT"
if cmp -s "$MUT" "$ALU"; then
  echo "MUTATION SETUP FAILED: the fixed form 'flags.c  = (b > a);' was not found in $ALU"
  echo "  -> cannot demonstrate a kill; treating the run as INCONCLUSIVE"
  exit 98
fi
echo "=== MUTANT (flags.c = !sub_ext[DATA_WIDTH])"
run_one mutant "$MUT"; MUTPASS=$?

echo "----"
if [ "$LIVE" -ne 0 ]; then echo "GATE: LIVE FAILED"; exit 1; fi
if [ "$MUTPASS" -eq 0 ]; then
  echo "GATE: MUTANT SURVIVED -> the gate does not exercise the change. INVALID."; exit 1;
fi
if [ "$MUTPASS" -eq 99 ]; then echo "GATE: mutant build error"; exit 1; fi
echo "GATE: PASS (live clean) + KILL CONFIRMED (mutant failed) in this same run"
