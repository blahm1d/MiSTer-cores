#!/usr/bin/env bash
# Baseline-vs-injected sufficiency run.  $1=game  $2=secs
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; secs="${2:-60}"
for mode in base inj; do
  inj=0; [ "$mode" = "inj" ] && inj=1
  mkdir -p "$D/snap_${g}_${mode}"
  # fresh copy of the WARM nvram for every run: neither mode may contaminate the other
  rm -rf "$D/nv_${g}_${mode}"; cp -r "$D/nvram" "$D/nv_${g}_${mode}"
  P0038_INJECT=$inj P0038_OUT="$D/res_${g}_${mode}.txt" P0038_SECS=$secs \
  P0038_SNAP="$D/snap_${g}_${mode}" \
  "$MAME" "$g" -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nv_${g}_${mode}" \
    -snapshot_directory "$D/snap_${g}_${mode}" \
    -autoboot_script "$D/inject_p0038.lua" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run $((secs+10)) -nothrottle -skip_gameinfo \
    > "$D/log_${g}_${mode}.txt" 2>&1
  echo "-- $g $mode: $(grep -m1 P0038_SUFF\\[ "$D/log_${g}_${mode}.txt")"
done
