#!/usr/bin/env bash
# usage: vf_run.sh <game> <gfx_bytes_hex> [secs]
set -uo pipefail
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; gb="$2"; secs="${3:-25}"
mkdir -p "$D/work/cfg_$g" "$D/work/nv_$g"
GFXBYTES="$gb" SECS="$secs" OUTF="$D/work/vf_${g}.txt" \
/c/tools/mame/mame.exe "$g" -rompath "/d/deck/fpga/smash tv/roms" \
  -cfg_directory "$D/work/cfg_$g" -nvram_directory "$D/work/nv_$g" \
  -autoboot_script "$D/vf_census.lua" -autoboot_delay 0 \
  -video none -sound none -seconds_to_run $((secs+8)) -nothrottle -skip_gameinfo \
  > "$D/work/log_${g}.txt" 2>&1
echo "--- $g exit=$? ---"
cat "$D/work/vf_${g}.txt" 2>/dev/null || echo "NO CENSUS WRITTEN (instrument failure, NOT a zero)"
