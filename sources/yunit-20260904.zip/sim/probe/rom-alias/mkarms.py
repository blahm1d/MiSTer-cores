#!/usr/bin/env python3
"""Derive the positive-control arms for the ROM-alias gate.

Nothing in the shipping tree is modified. Every substitution is anchored; a
missing anchor ABORTS so a kill/pass can never be vacuous.

  PCROM : exd_alias loses its !exd_isrom guard  -> program ROM words get
          nibble-aliased. This is the CATASTROPHIC defect the gate must detect.
  PCGFX : exd_alias forced to 0 -> the 4bpp alias disappears entirely. Proves the
          gfx side of the TB actually exercises the alias (a 4bpp PASS is then
          not vacuous).
"""
import sys

src_path, which, out_path = sys.argv[1], sys.argv[2], sys.argv[3]
src = open(src_path, encoding='utf-8', errors='surrogateescape').read()

ANCHOR = "  wire exd_alias = !exd_isrom && bpp4;\n"
if ANCHOR not in src:
    sys.exit("PATCH ERROR: anchor missing (exd_alias) -- a kill/pass here would be vacuous")

MUT = {
    'pcrom': "  wire exd_alias = bpp4; // POSITIVE CONTROL: !exd_isrom guard removed\n",
    'pcgfx': "  wire exd_alias = 1'b0; // POSITIVE CONTROL: 4bpp alias removed\n",
}
if which not in MUT:
    sys.exit("PATCH ERROR: unknown arm %s" % which)

t = src.replace(ANCHOR, MUT[which], 1)
if "POSITIVE CONTROL" not in t or ANCHOR in t:
    sys.exit("PATCH ERROR: %s did not apply" % which)
open(out_path, 'w', encoding='utf-8', errors='surrogateescape').write(t)
print("PATCH OK: %s" % which)
