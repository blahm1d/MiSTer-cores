#!/usr/bin/env bash
# Does the "alias at CAPTURE" retime ever nibble-alias a PROGRAM ROM word?
#
# Compiles with -DUSE_EXT_GFX -DUSE_EXT_ROM, i.e. the configuration SYNTHESIS
# produces (yunit_mem_family2.sv:34-41) and the one sim/probe/sf-gfxoor never
# builds -- that gate is -DUSE_EXT_GFX only, so exd_isrom is structurally 0
# there and the R_ROM path through the shared M_GFX loop is not elaborated.
#
# Arms:
#   wt     working tree (retime applied)   -> must PASS
#   hd     committed HEAD (pre-retime)     -> must PASS, and burn the IDENTICAL
#                                             request->ack clocks as wt
#   pcrom  wt with !exd_isrom removed      -> POSITIVE CONTROL, must FAIL on ROM
#   pcgfx  wt with the alias removed       -> POSITIVE CONTROL, must FAIL on GFX
#                                             at 4bpp (proves the alias is live)
# Configs: bpp4=1 (Trog / Strike Force / Saurian Front, where the hazard lives)
#          bpp4=0 (regression; both controls are asserted INERT there)
#
# No check is weakened anywhere. Zero coverage is an explicit FAIL inside the TB,
# and so is a run in which no multi-word ROM fetch occurred -- i.e. the gate
# refuses to pass unless gw0/gw1 provably carried program-ROM words into win_s_q.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
OUT="$HERE/work"; mkdir -p "$OUT"
SRC_MEM="$ROOT/rtl/yunit/family2/yunit_mem_family2.sv"

cp "$SRC_MEM" "$OUT/mem_wt.sv" || exit 3
( cd "$ROOT" && git show HEAD:rtl/yunit/family2/yunit_mem_family2.sv ) > "$OUT/mem_hd.sv" || exit 3
# HEAD must be the PRE-retime text, else the hd arm is not an independent reference
grep -q "gfx_rd_a" "$OUT/mem_hd.sv" && { echo "ABORT: HEAD already carries the retime -- hd arm would be vacuous"; exit 3; }
grep -q "gfx_rd_a" "$OUT/mem_wt.sv" || { echo "ABORT: working tree does NOT carry the retime -- nothing to verify"; exit 3; }

python "$HERE/mkarms.py" "$SRC_MEM" pcrom "$OUT/mem_pcrom.sv" || exit 3
python "$HERE/mkarms.py" "$SRC_MEM" pcgfx "$OUT/mem_pcgfx.sv" || exit 3

declare -A MEM=( [wt]="$OUT/mem_wt.sv" [hd]="$OUT/mem_hd.sv" \
                 [pcrom]="$OUT/mem_pcrom.sv" [pcgfx]="$OUT/mem_pcgfx.sv" )

run() {  # $1=arm $2=cfg $3..=defines
  local arm="$1" cfg="$2"; shift 2
  local tag="${arm}_${cfg}"
  iverilog -g2012 -DUSE_EXT_GFX -DUSE_EXT_ROM "$@" -s tb_rom_alias -o "$OUT/$tag.vvp" \
    "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_protection.sv" \
    "${MEM[$arm]}" "$HERE/tb_rom_alias.sv" > "$OUT/$tag.iv.log" 2>&1
  if [ ! -f "$OUT/$tag.vvp" ]; then echo "COMPILE-FAIL $tag"; tail -20 "$OUT/$tag.iv.log"; return 2; fi
  ( cd "$OUT" && vvp "$OUT/$tag.vvp" ) > "$OUT/$tag.log" 2>&1
  grep -E "^(CONFIG|COVERAGE|RACKS|FAILS|ROM_VALUES|CYCLES|TEST_RESULT|ROM MISMATCH|GFX MISMATCH)" "$OUT/$tag.log" | head -14
}

num() { sed -n "s/^$2: .*$3=\([0-9]*\).*/\1/p" "$OUT/$1.log" | head -1; }
res() { grep -c "TEST_RESULT: $2" "$OUT/$1.log"; }

rc=0
for cfg in b4 b6; do
  case $cfg in
    b4) D=(-DGFXPIX=32\'h400000 -DGFXBYTES=24\'h300000 -DBPP4=1\'b1);;
    b6) D=(-DGFXPIX=32\'h400000 -DGFXBYTES=24\'h300000 -DBPP4=1\'b0);;
  esac
  for arm in wt hd pcrom pcgfx; do
    echo "=== $arm / $cfg ==="
    run "$arm" "$cfg" "${D[@]}"
  done

  W=wt_$cfg; H=hd_$cfg; PR=pcrom_$cfg; PG=pcgfx_$cfg

  # coverage, reported and enforced
  cov_rom=$(num $W COVERAGE rom); cov_m=$(num $W COVERAGE rom_need_ge2); cov_3=$(num $W COVERAGE rom_need3)
  cov_gfx=$(num $W COVERAGE gfx)
  echo "--- $cfg: ROM reads=$cov_rom (need>=2: $cov_m, need=3: $cov_3)  GFX reads=$cov_gfx"
  [ "${cov_rom:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: zero ROM coverage"; rc=1; }
  [ "${cov_3:-0}"   -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: no 3-word ROM fetch requested"; rc=1; }

  # WHITE-BOX coverage: program-ROM words must actually have passed THROUGH gw0
  # and gw1. A stream-buffer hit is served from sb_q and bypasses them, so
  # without this a ROM pass could be vacuous.
  r_w0=$(num $W RACKS rom_gw0); r_w1=$(num $W RACKS rom_gw1)
  r_gx=$(num $W RACKS gfx_gw0); r_al=$(num $W RACKS alias_on_rom)
  echo "--- $cfg: racks through the retimed capture: ROM->gw0=$r_w0 ROM->gw1=$r_w1 GFX->gw0=$r_gx"
  [ "${r_w0:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: no program-ROM word reached gw0 -- ROM pass is vacuous"; rc=1; }
  [ "${r_w1:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: no program-ROM word reached gw1 -- ROM pass is vacuous"; rc=1; }
  [ "${r_gx:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: no gfx word reached gw0 -- aliasing capture unexercised"; rc=1; }
  [ "${r_al:-0}" = "0" ]             || { echo "ASSERT FAIL[$cfg]: exd_alias asserted during $r_al program-ROM racks"; rc=1; }

  [ "$(res $W PASS)" = "1" ] || { echo "ASSERT FAIL[$cfg]: WORKING TREE fails -- retime is WRONG"; rc=1; }
  [ "$(res $H PASS)" = "1" ] || { echo "ASSERT FAIL[$cfg]: HEAD fails the same oracle -- oracle suspect"; rc=1; }

  # latency neutrality against HEAD itself (sharper than sf-gfxoor's pre-SRC-4 arm)
  cw=$(num $W CYCLES total); ch=$(num $H CYCLES total)
  [ -n "$cw" ] && [ -n "$ch" ] || { echo "ASSERT FAIL[$cfg]: no CYCLES instrumentation"; rc=1; }
  [ "$cw" = "$ch" ] || { echo "ASSERT FAIL[$cfg]: latency CHANGED vs HEAD wt=$cw hd=$ch"; rc=1; }
  echo "--- $cfg: request->ack clocks  worktree=$cw  HEAD=$ch  (must be equal)"

  pr_rom=$(num $PR FAILS rom); pr_hit=$(sed -n 's/^ROM_VALUES_MATCHING_ALIASED_FORM=//p' "$OUT/$PR.log" | head -1)
  pg_gfx=$(num $PG FAILS gfx)
  if [ "$cfg" = "b4" ]; then
    [ "${pr_rom:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: PCROM not killed -- the gate is BLIND to a ROM alias"; rc=1; }
    [ "${pr_hit:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: PCROM failures are not the aliased form -- wrong defect injected"; rc=1; }
    [ "${pg_gfx:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: PCGFX not killed -- the 4bpp alias is not exercised"; rc=1; }
    # the white-box probe must ALSO see the injected defect, else it is blind
    pr_al=$(num $PR RACKS alias_on_rom)
    [ "${pr_al:-0}" -gt 0 ] 2>/dev/null || { echo "ASSERT FAIL[$cfg]: probe did not see exd_alias during PCROM's ROM racks -- probe is BLIND"; rc=1; }
    echo "--- $cfg: PCROM killed ($pr_rom ROM mismatches, $pr_hit of them exactly the ALIASED value; probe saw $pr_al aliased ROM racks)"
    echo "--- $cfg: PCGFX killed ($pg_gfx GFX mismatches) -- the alias is live, not dead code"
  else
    [ "${pr_rom:-0}" = "0" ] || { echo "ASSERT FAIL[$cfg]: PCROM claimed inert at 6bpp but failed"; rc=1; }
    [ "${pg_gfx:-0}" = "0" ] || { echo "ASSERT FAIL[$cfg]: PCGFX claimed inert at 6bpp but failed"; rc=1; }
    echo "--- $cfg: both controls INERT by construction at 6bpp (exd_alias is 0 either way) -- asserted, not skipped"
  fi
  echo
done

if [ $rc -eq 0 ]; then
  echo "GATE: PASS -- program ROM is never aliased with the retime applied, the"
  echo "              retime is bit- and cycle-identical to HEAD, and both positive"
  echo "              controls are killed at 4bpp."
else
  echo "GATE: FAIL"
fi
exit $rc
