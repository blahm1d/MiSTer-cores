#!/usr/bin/env bash
# GATE: the 34010 core's committed display tap forwards HEBLNK/HSBLNK.
#
# Root cause of the cabinet's persistent right-edge columns (mkla1 400 px vs
# the 410 raster): display_wr_idx_match in tms34010_core.sv omitted the two
# horizontal-blank registers, so the family2 top's runtime-width tracker never
# saw the game's writes and visible_px sat at the H_ACT default forever. Both
# pre-existing width gates drove visible_px straight into the leaf video
# modules, so neither could see this -- this gate runs REAL stores through the
# REAL core (sv2v + Icarus, licence-free, same runner as the P0038 audit).
#
# Kill control on every invocation: MUT_DISPLAY_TAP_NO_HBLNK reverts only the
# two new whitelist terms and MUST fail, while its DPYSTRT positive-control
# event still fires (asserted inside the TB).
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
RUNNER="$HERE/../p0038-reach-audit/run_core_oracle.sh"
[ -x "$RUNNER" ] || { echo "GATE_INCONCLUSIVE: missing $RUNNER"; exit 77; }
TB=tb_display_tap_hblnk
rc=0
run() {  # $1 = label, $2 = sv2v defines, $3 = expected PASS|FAIL
  local out; out="$(DEFS="$2" "$RUNNER" $TB 2>&1)"
  local got=FAIL; grep -q "^PASS $TB" <<<"$out" && got=PASS
  if [ "$got" = "$3" ]; then echo "GATE ok   $1: $got (expected $3)"
  else echo "GATE FAIL $1: $got (expected $3)"; sed 's/^/        /' <<<"$out"; rc=1; fi
}
run "unmutated"        ""                             PASS
run "kill/no-hblnk"    "-DMUT_DISPLAY_TAP_NO_HBLNK"   FAIL
if [ $rc -eq 0 ]; then echo "DISPLAY-TAP: PASS (HEBLNK/HSBLNK forwarded, mutant killed)"
else echo "DISPLAY-TAP: FAIL"; fi
exit $rc
