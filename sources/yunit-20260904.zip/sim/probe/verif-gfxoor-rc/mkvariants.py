#!/usr/bin/env python3
"""Derive the FIXED and the POSITIVE-CONTROL variants of yunit_mem_family2.sv.

Nothing in the shipping tree is modified. Every substitution is verified; if any
anchor is missing the script aborts so a kill/pass can never be vacuous.

  FIXED  : exd_gfx_oor's bound extended from word 0 to ALL 1..3 covered words.
  MUTW0  : FIXED with the word-0 bound removed -- positive control proving the TB
           detects an unbounded word 0 as well (so a FIXED pass is not vacuous).
"""
import sys, os

src_path, out_fixed, out_mutw0 = sys.argv[1], sys.argv[2], sys.argv[3]
src = open(src_path, encoding='utf-8', errors='surrogateescape').read()

ANCHOR_OOR = "  wire exd_gfx_oor = !exd_isrom && (exd_base >= gfx_bytes);\n"
ANCHOR_ALIAS = "  wire exd_alias = !exd_isrom && bpp4;\n"

ADD_AFTER_ALIAS = """\
  // ---- PER-COVERED-WORD out-of-range bound (round-2 finding) ---------------
  // exd_gfx_oor above names ONLY exd_base, i.e. window word 0, but M_GFX fetches
  // exd_need = 1..3 words at exd_base, +2, +4 (:644 extnw, :1318 latch). A field
  // straddling the top of the populated image therefore merged RAW SDRAM into
  // words 1/2 where MAME's zero-initialised m_gfx_rom reads 0.
  wire exd_oor1 = !exd_isrom && ((exd_base + 24'd2) >= gfx_bytes);
  wire exd_oor2 = !exd_isrom && ((exd_base + 24'd4) >= gfx_bytes);
  // window words in fetch order (the LAST covered word is live on gfx_rdata)
  wire [15:0] gxw0 = (gfx_need == 2'd1) ? gfx_rdata : gw0;
  wire [15:0] gxw1 = (gfx_need == 2'd2) ? gfx_rdata : gw1;
  wire [15:0] gxw2 = gfx_rdata;
  wire [15:0] gxa0 = exd_gfx_oor ? 16'h0 : (exd_alias ? gfx4_alias(gxw0) : gxw0);
  wire [15:0] gxa1 = exd_oor1    ? 16'h0 : (exd_alias ? gfx4_alias(gxw1) : gxw1);
  wire [15:0] gxa2 = exd_oor2    ? 16'h0 : (exd_alias ? gfx4_alias(gxw2) : gxw2);
"""

OLD_WIN = """\
              win_s_q <= exd_gfx_oor ? 48'd0 :
                         exd_alias ?
                           ((gfx_need == 2'd1) ? {32'h0, gfx4_alias(gfx_rdata)} :
                            (gfx_need == 2'd2) ? {16'h0, gfx4_alias(gfx_rdata), gfx4_alias(gw0)} :
                                                 {gfx4_alias(gfx_rdata), gfx4_alias(gw1), gfx4_alias(gw0)}) :
                         (gfx_need == 2'd1) ? {32'h0, gfx_rdata} :
                         (gfx_need == 2'd2) ? {16'h0, gfx_rdata, gw0} :
                                              {gfx_rdata, gw1, gw0};
"""

NEW_WIN = """\
              win_s_q <= (gfx_need == 2'd1) ? {32'h0, gxa0} :
                         (gfx_need == 2'd2) ? {16'h0, gxa1, gxa0} :
                                              {gxa2, gxa1, gxa0};
"""

def need(text, anchor, what):
    if anchor not in text:
        sys.exit("PATCH ERROR: anchor missing (%s) -- a kill/pass here would be vacuous" % what)

need(src, ANCHOR_OOR, "exd_gfx_oor")
need(src, ANCHOR_ALIAS, "exd_alias")
need(src, OLD_WIN, "M_GFX win_s_q load")

fixed = src.replace(ANCHOR_ALIAS, ANCHOR_ALIAS + ADD_AFTER_ALIAS, 1)
fixed = fixed.replace(OLD_WIN, NEW_WIN, 1)
if "exd_oor2" not in fixed or "gxa2, gxa1, gxa0" not in fixed:
    sys.exit("PATCH ERROR: FIXED did not apply")

# positive control: same FIXED text with the word-0 bound defeated
mutw0 = fixed.replace(ANCHOR_OOR,
    "  wire exd_gfx_oor = 1'b0; // POSITIVE CONTROL: word-0 bound removed\n", 1)
if "POSITIVE CONTROL" not in mutw0:
    sys.exit("PATCH ERROR: MUTW0 did not apply")

open(out_fixed, 'w', encoding='utf-8', errors='surrogateescape').write(fixed)
open(out_mutw0, 'w', encoding='utf-8', errors='surrogateescape').write(mutw0)
print("PATCH OK: FIXED and MUTW0 generated from", os.path.basename(src_path))
