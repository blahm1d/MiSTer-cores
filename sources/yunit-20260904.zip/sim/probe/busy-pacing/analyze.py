#!/usr/bin/env python3
"""Y-unit BUSY-gate / blit-workload census analyzer.

Inputs: <base>.blits, <base>.frames, <base>.reads from capture_busy_gate.lua.
MAME model: dma duration = 41 ns * width * height (midyunit_v.cpp:523).
Frame rate: Y-unit ~54.71 Hz.
"""
import sys, os, statistics, collections

FRAME_S = 1.0 / 54.71
NS_PER_PX = 41.0


def pct(sorted_vals, p):
    if not sorted_vals:
        return 0
    i = min(len(sorted_vals) - 1, int(round((p / 100.0) * (len(sorted_vals) - 1))))
    return sorted_vals[i]


def load(base):
    blits = []
    with open(base + ".blits") as fh:
        for line in fh:
            if not line.startswith("BLIT"):
                continue
            p = line.split()
            d = dict(kv.split("=") for kv in p[4:])
            blits.append((int(p[1]), int(p[3], 16), int(d["W"]), int(d["H"]),
                          float(d["T"]), int(d["CMD"], 16)))
    frames = {}
    with open(base + ".frames") as fh:
        for line in fh:
            p = line.split()
            if p and p[0] == "F":
                frames[int(p[1])] = (int(p[2].split("=")[1]), int(p[3].split("=")[1]))
    return blits, frames


def report(base, lo, hi):
    name = os.path.basename(base)
    blits, frames = load(base)
    sel = [b for b in blits if lo <= b[0] <= hi]
    fsel = {f: v for f, v in frames.items() if lo <= f <= hi}
    nframes = hi - lo + 1
    if not sel:
        print(f"{name}: ZERO BLITS in window {lo}..{hi} -- FAIL (no coverage)")
        return
    px = [w * h for _, _, w, h, _, _ in sel]
    spx = sorted(px)
    per_frame = collections.Counter(b[0] for b in sel)
    counts = [per_frame.get(f, 0) for f in range(lo, hi + 1)]
    reads = [fsel.get(f, (0, 0))[0] for f in range(lo, hi + 1)]
    # inter-command gaps, in issue order
    ts = [b[4] for b in sel]
    gaps_ns = sorted((ts[i + 1] - ts[i]) * 1e9 for i in range(len(ts) - 1))
    # MAME modeled blitter-busy per frame
    busy_frame = collections.Counter()
    for f, _, w, h, _, _ in sel:
        busy_frame[f] += w * h * NS_PER_PX * 1e-9
    bf = sorted(busy_frame.values())

    print(f"=== {name}  frames {lo}..{hi} ({nframes}) ===")
    print(f"  blits            total={len(sel)}  mean/frame={len(sel)/nframes:.1f}  "
          f"PEAK/frame={max(counts)}  p99/frame={pct(sorted(counts),99)}")
    print(f"  DMA_COMMAND reads total={sum(reads)}  mean/frame={sum(reads)/nframes:.1f}  "
          f"PEAK/frame={max(reads)}")
    print(f"  reads per blit   = {sum(reads)/len(sel):.2f}")
    print(f"  blit pixels(w*h) mean={statistics.mean(px):.1f} median={pct(spx,50)} "
          f"p10={pct(spx,10)} p25={pct(spx,25)} p75={pct(spx,75)} p90={pct(spx,90)} "
          f"p99={pct(spx,99)} max={spx[-1]}")
    small = sum(1 for v in px if v <= 256)
    tiny = sum(1 for v in px if v <= 64)
    big = sum(1 for v in px if v >= 4096)
    print(f"  size classes     <=64px:{100*tiny/len(px):.1f}%  <=256px:{100*small/len(px):.1f}%  "
          f">=4096px:{100*big/len(px):.1f}%")
    px_frame = collections.Counter()
    for f, _, w, h, _, _ in sel:
        px_frame[f] += w * h
    print(f"  pixels/frame     mean={sum(px)/nframes:.0f}  peak={max(px_frame.values())}")
    print(f"  MAME modeled blitter-busy/frame: mean={statistics.mean(bf)/FRAME_S*100:.1f}% "
          f"median={pct(bf,50)/FRAME_S*100:.1f}% p90={pct(bf,90)/FRAME_S*100:.1f}% "
          f"max={bf[-1]/FRAME_S*100:.1f}%")
    print(f"  inter-cmd gap ns p10={pct(gaps_ns,10):.0f} median={pct(gaps_ns,50):.0f} "
          f"mean={statistics.mean(gaps_ns):.0f} p75={pct(gaps_ns,75):.0f} "
          f"p90={pct(gaps_ns,90):.0f} p99={pct(gaps_ns,99):.0f}")
    # what fraction of the gap is explained by MAME's own 41ns/px model
    modeled = [b[2] * b[3] * NS_PER_PX for b in sel[:-1]]
    gaps_raw = [(ts[i + 1] - ts[i]) * 1e9 for i in range(len(ts) - 1)]
    tight = sum(1 for g, m in zip(gaps_raw, modeled) if g < m)
    print(f"  back-to-back (next cmd issued BEFORE MAME's 41ns/px model expired): "
          f"{tight}/{len(gaps_raw)} = {100*tight/len(gaps_raw):.1f}%")
    # top issuing PCs
    pcs = collections.Counter(b[1] for b in sel).most_common(4)
    print("  issuing PCs: " + ", ".join(f"{p:08X}:{n}" for p, n in pcs))
    print()


if __name__ == "__main__":
    lo = int(sys.argv[1]); hi = int(sys.argv[2])
    for base in sys.argv[3:]:
        report(base, lo, hi)
