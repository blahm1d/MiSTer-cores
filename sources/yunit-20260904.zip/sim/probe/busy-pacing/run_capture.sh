#!/bin/bash
# Two passes per title: pass 1 builds NVRAM (fresh boot parks at the CMOS/factory
# screen and never reaches display init), pass 2 is the MEASURED run.
# usage: ./run_capture.sh <coin_frame> <stop_frame> <game>...
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
COIN=${1:?coin_frame}; shift
STOP=${1:?stop_frame}; shift

for g in "$@"; do
  mkdir -p "$D/nvram/$g"
  # pass 1 -- NVRAM warm-up, no taps
  "$MAME" $g -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram/$g" \
    -video none -sound none -seconds_to_run 45 -nothrottle -skip_gameinfo \
    > "$D/out/${g}_p1.log" 2>&1
  # pass 2 -- measured
  BG_OUT="$D/out/${g}" BG_STOP_FRAME=$STOP BG_COIN_FRAME=$COIN \
  "$MAME" $g -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram/$g" \
    -autoboot_script "$D/capture_busy_gate.lua" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run 600 -nothrottle -skip_gameinfo \
    > "$D/out/${g}_p2.log" 2>&1
  echo "== $g : $(head -1 "$D/out/${g}.reads" 2>/dev/null)"
done
