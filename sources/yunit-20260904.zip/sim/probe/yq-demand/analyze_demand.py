#!/usr/bin/env python3
"""Peak blit demand per frame + one-deep-queue stall model for the Y-unit family2 DMA.

Input: tl_<game>.txt from capture_blit_timeline.lua  (T <frame> <t_ns> <w> <h>)

Queue model (rtl/yunit/family2/yunit_dma_family2.sv:133-138): 1 blit in flight +
K pending snapshot slots (K=1 on the shipping family2 datapath). A trigger
arriving with the pending slot full HOLDS the CPU bus
(rtl/yunit/family2/yunit_memsys_family2.sv:344 -- mem_ack withheld). Service time
per blit is the MAME-faithful pace: 41.7 ns/clipped pixel (4 clk_sys @96 MHz,
yunit_dma_family2.sv:91-95; MAME midyunit_v.cpp:523 = 41 ns/px).

The CPU is serial, so a stall shifts every later trigger by the accumulated
stall -- modelled here, which makes the estimate a LOWER BOUND on real slowdown.
"""
import sys
from collections import defaultdict

NS_PER_PX = 41.7  # RTL pace: 4 clk_sys / px at 96 MHz


def load(path):
    ev = []
    with open(path) as f:
        for line in f:
            if not line.startswith("T "):
                continue
            _, fr, t, w, h = line.split()
            ev.append((int(fr), float(t), int(w), int(h)))
    return ev


def stall_model(ev, K):
    shift = 0.0
    outstanding = []
    per_frame = defaultdict(float)
    total = 0.0
    for fr, t, w, h in ev:
        arr = t + shift
        outstanding = [c for c in outstanding if c > arr]
        if len(outstanding) >= K + 1:
            outstanding.sort()
            free_at = outstanding[0]
            stall = free_at - arr
            shift += stall
            total += stall
            per_frame[fr] += stall
            arr = free_at
            outstanding = [c for c in outstanding if c > arr]
        svc = NS_PER_PX * max(w, 0) * max(h, 0)
        start = max(arr, max(outstanding) if outstanding else arr)
        outstanding.append(start + svc)
    return total, per_frame


def depth_needed(ev):
    live = []
    peak = 0
    peak_frame = 0
    for fr, t, w, h in ev:
        live = [c for c in live if c > t]
        live.append(t + NS_PER_PX * max(w, 0) * max(h, 0))
        if len(live) > peak:
            peak = len(live)
            peak_frame = fr
    return peak, peak_frame


for path in sys.argv[1:]:
    ev = load(path)
    if not ev:
        print(f"{path}: NO EVENTS")
        continue
    c = defaultdict(int)
    px = defaultdict(int)
    firsts = {}
    for fr, t, w, h in ev:
        c[fr] += 1
        px[fr] += w * h
        firsts.setdefault(fr, t)
    frames = sorted(c)
    fs = sorted(firsts)
    wall = firsts[fs[-1]] - firsts[fs[0]]
    span = wall / (fs[-1] - fs[0])
    top = sorted(c.items(), key=lambda kv: -kv[1])[:5]
    peak_fr, peak_n = top[0]
    arr = [c[f] for f in frames]
    sus = 0.0
    if len(arr) >= 60:
        run = sum(arr[:60])
        sus = run / 60
        for i in range(60, len(arr)):
            run += arr[i] - arr[i - 60]
            sus = max(sus, run / 60)
    d, dfr = depth_needed(ev)
    print(f"== {path}")
    print(f"   frames-with-blits {len(frames)}   frame period ~{span/1e6:.2f} ms ({1e9/span:.2f} Hz)")
    print(f"   PEAK blits/frame {peak_n} (frame {peak_fr})   top5 {top}")
    print(f"   best 60-frame sustained mean {sus:.1f} blits/frame")
    print(f"   peak clipped-px/frame {max(px.values())}  "
          f"= {max(px.values())*NS_PER_PX/1e6:.2f} ms of 41.7ns/px pace "
          f"({100*max(px.values())*NS_PER_PX/span:.0f}% of one frame)")
    print(f"   MAX CONCURRENT outstanding blits under MAME arrivals: {d} (frame {dfr})")
    for K in (0, 1, 2, 3, 7, 15, 31):
        tot, pf = stall_model(ev, K)
        worst = max(pf.values()) if pf else 0.0
        wf = max(pf, key=pf.get) if pf else -1
        print(f"   K={K:2d} pending: CPU stall {tot/1e6:9.1f} ms / {wall/1e6:.0f} ms wall "
              f"({100*tot/wall:5.1f}%)   worst frame {worst/1e6:6.2f} ms "
              f"(frame {wf}, budget {span/1e6:.2f} ms)")
