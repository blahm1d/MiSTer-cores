#!/usr/bin/env python3
"""Busy-bit duration divergence: MAME (concurrent, rescheduled timer) vs the RTL
(serialized 1-active + 1-pending engine), from the same measured arrival stream.

MAME midyunit_v.cpp:523 sets ONE done timer at each trigger:
    m_dma_timer->adjust(41ns * width * height)
so a trigger issued while a previous blit is still timing simply RESCHEDULES the
single deadline -- the two blits' busy windows OVERLAP.

rtl/yunit/family2/yunit_dma_family2.sv holds a queued successor in pendf and does
not start its pace counter until the active blit reaches S_IDLE, so the two
windows are SERIALIZED. Busy therefore clears LATER than MAME by the overlap.

That only costs CPU time in a title that SPINS on the busy bit (measured:
shimpact/hiimpact poll DMA_COMMAND ~23-29x per blit; smashtv essentially never).
"""
import sys
from collections import defaultdict

NS_PER_PX = 41.7


def load(path):
    ev = []
    with open(path) as f:
        for line in f:
            if line.startswith("T "):
                _, fr, t, w, h = line.split()
                ev.append((int(fr), float(t), int(w), int(h)))
    return ev


for path in sys.argv[1:]:
    ev = load(path)
    if not ev:
        print(f"{path}: NO EVENTS")
        continue
    mame_busy = defaultdict(float)   # union of MAME busy windows, per frame
    rtl_busy = defaultdict(float)    # union of serialized RTL busy windows
    excess = defaultdict(float)      # extra ns the RTL keeps busy asserted
    overlaps = 0

    mame_end = -1.0
    rtl_end = -1.0
    prev_m_cov = None
    for fr, t, w, h in ev:
        d = NS_PER_PX * max(w, 0) * max(h, 0)
        # MAME: single timer, rescheduled
        m_start = t
        m_new_end = t + d
        add = m_new_end - max(mame_end, m_start)
        mame_busy[fr] += max(add, 0.0)
        mame_end = max(mame_end, m_new_end)
        # RTL: serialized service
        r_start = max(t, rtl_end)
        if rtl_end > t:
            overlaps += 1
        r_new_end = r_start + d
        rtl_busy[fr] += r_new_end - max(rtl_end, t)
        rtl_end = r_new_end
        excess[fr] += (r_new_end - m_new_end) if r_new_end > m_new_end else 0.0

    frames = sorted(set(list(mame_busy) + list(rtl_busy)))
    tm = sum(mame_busy.values())
    tr = sum(rtl_busy.values())
    worst_f = max(excess, key=excess.get)
    print(f"== {path}")
    print(f"   triggers {len(ev)}   triggers arriving while the previous blit still ran: "
          f"{overlaps} ({100*overlaps/len(ev):.1f}%)")
    print(f"   total MAME busy {tm/1e6:.1f} ms   total RTL(serialized) busy {tr/1e6:.1f} ms   "
          f"(+{100*(tr-tm)/tm:.2f}%)")
    top = sorted(excess.items(), key=lambda kv: -kv[1])[:3]
    print(f"   worst-frame extra busy: " +
          ", ".join(f"frame {f}: +{v/1e3:.0f} us" for f, v in top) +
          "   (frame budget 18280 us)")
    per = [mame_busy[f] for f in frames]
    print(f"   peak MAME busy in one frame {max(per)/1e6:.2f} ms "
          f"({100*max(per)/18.28e6:.0f}% of a frame)")
