#!/usr/bin/env bash
# ROUND 2 owner-D gate: WHERE the phantom drain's loss lands (prefix + MRA pad geometry).
# iverilog only -- no Questa, no licence.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
D="$ROOT/sim/probe/d2-padprefix"

# Re-extract the shipping download-FIFO + boot-mux text VERBATIM (yunit_top_family2.sv:656-709)
# into THIS directory, and derive the one-line fixed variant.  Same technique as round 1, so
# the gate can never drift from the RTL and never collides with a parallel owner's copy.
python - "$ROOT" <<'PY'
import sys
root=sys.argv[1]
seg=open(root+'/rtl/yunit/family2/yunit_top_family2.sv',encoding='utf8').read().splitlines()[655:709]
txt="\n".join(seg)
open(root+'/sim/probe/d2-padprefix/_iol_asis.vh','w',encoding='utf8').write(txt+"\n")
r="      if (iol_hold && iol_ack) iol_hold <= 1'b0;"
l="      if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin"
assert r in txt and l in txt, "extraction anchor moved -- refresh the line range"
txt=txt.replace(r,"      if (iol_hold && iol_ack_dl) iol_hold <= 1'b0;")
txt=txt.replace(l,"      if ((!iol_hold || (iol_hold && iol_ack_dl)) && !iol_empty) begin")
txt=txt.replace("  localparam int IOL_AW  = 9;",
                "  wire iol_ack_dl = iol_ack & ~boot_unp;   // FIX under test\n  localparam int IOL_AW  = 9;")
open(root+'/sim/probe/d2-padprefix/_iol_fixed.vh','w',encoding='utf8').write(txt+"\n")
PY

iverilog -g2012 -I "$D" -s tb_pad_prefix -o "$D/tb_pad_prefix.vvp" \
  "$ROOT/rtl/sdram/yunit_sdram_arb.sv" "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" \
  "$ROOT/rtl/yunit/family2/family2_download_mapper.sv" \
  "$ROOT/sim/sdram_chip.sv" "$D/tb_pad_prefix.sv" 2>&1 | grep -v "sorry:" || true

(cd "$ROOT/sim" && vvp "$D/tb_pad_prefix.vvp") | tee "$D/pad_prefix.log"
grep -q "^PASS: PAD_PREFIX" "$D/pad_prefix.log" || { echo "GATE FAIL: pad_prefix"; exit 1; }
echo "D2-PADPREFIX: PASS"
