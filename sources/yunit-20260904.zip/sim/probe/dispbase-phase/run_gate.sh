#!/usr/bin/env bash
# GATE: display-base PHASE -- does the Family2 DPYSTRT producer reproduce the
# gospel row (tms34010.cpp:1149-1152) for every title's MEASURED DPYSTRT values?
#
# iverilog only -- no Questa, no licence.
#
# The producer RTL is re-extracted VERBATIM from yunit_top_family2.sv on every
# run, so this gate can never drift from the shipped text, and the shipped DELTA
# form is derived from that same text as the mutation control. See the header of
# tb_dispbase_phase.sv for the method and the two mandatory controls.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
D="$ROOT/sim/probe/dispbase-phase"
IV="${IV:-iverilog}"

command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }

python - "$ROOT" <<'PY'
import sys
root = sys.argv[1]
src  = open(root+'/rtl/yunit/family2/yunit_top_family2.sv', encoding='utf8').read().splitlines()

# Producer block: `wire dpystrt_we` .. the close of its always_ff.
beg = next(i for i,l in enumerate(src) if 'wire       dpystrt_we' in l)
end = next(i for i,l in enumerate(src) if i > beg and 'disp_row_dyn <= disp_row_next' in l)
end = next(i for i,l in enumerate(src) if i > end and l.rstrip() == '  end')
txt = "\n".join(src[beg:end+1])

# Anchors -- if these moved, the extraction is stale and the gate must not
# silently test the wrong text.
A_ROW  = "wire [8:0] dpystrt_row_w = ~tms_display_wr_data[12:4];"
A_BASE = "wire [8:0] disp_row_next = dpystrt_ref_set ? dpystrt_row_pend : 9'(DISP_ROW0);"
assert A_ROW  in txt, "extraction anchor moved (row complement) -- refresh run_gate.sh"
assert A_BASE in txt, "extraction anchor moved (absolute base) -- refresh run_gate.sh"

open(root+'/sim/probe/dispbase-phase/_dispbase_asis.vh','w',encoding='utf8').write(txt+"\n")

# MUTANT: rewrite back to the shipped form -- raw row field + DELTA base.
mut = txt.replace(A_ROW,  "wire [8:0] dpystrt_row_w = tms_display_wr_data[12:4];")
mut = mut.replace(A_BASE, "wire [8:0] disp_row_next = dpystrt_ref_set"
                          " ? 9'(9'(DISP_ROW0) + (dpystrt_row_pend - dpystrt_row_ref))"
                          " : 9'(DISP_ROW0);")
assert mut != txt, "mutant identical to as-is -- the control is dead"
open(root+'/sim/probe/dispbase-phase/_dispbase_delta.vh','w',encoding='utf8').write(mut+"\n")
PY

# Two wrappers around the two extractions. IO_IDX_DPYSTRT = 5'h09 is
# tms34010_pkg.sv:296; the wrapper does not import the package so the gate stays
# free of the core's elaboration cost.
cat > "$D/_dispbase_wrap.vh" <<'SV'
`timescale 1ns/1ps
module dispbase_asis #(parameter int DISP_ROW0 = 0) (
  input  wire clk, input wire video_phase_rst, input wire vblank,
  input  wire tms_display_wr_valid, input wire [4:0] tms_display_wr_idx,
  input  wire [15:0] tms_display_wr_data,
  output wire [8:0] o_disp_row_next, output wire [8:0] o_disp_row_dyn,
  output wire [31:0] o_flip_cnt);
  localparam logic [4:0] IO_IDX_DPYSTRT = 5'h09;
  `include "_dispbase_asis.vh"
  assign o_disp_row_next = disp_row_next;
  assign o_disp_row_dyn  = disp_row_dyn;
  assign o_flip_cnt      = dpystrt_flip_cnt;
endmodule

module dispbase_delta #(parameter int DISP_ROW0 = 0) (
  input  wire clk, input wire video_phase_rst, input wire vblank,
  input  wire tms_display_wr_valid, input wire [4:0] tms_display_wr_idx,
  input  wire [15:0] tms_display_wr_data,
  output wire [8:0] o_disp_row_next, output wire [8:0] o_disp_row_dyn,
  output wire [31:0] o_flip_cnt);
  localparam logic [4:0] IO_IDX_DPYSTRT = 5'h09;
  `include "_dispbase_delta.vh"
  assign o_disp_row_next = disp_row_next;
  assign o_disp_row_dyn  = disp_row_dyn;
  assign o_flip_cnt      = dpystrt_flip_cnt;
endmodule
SV

"$IV" -g2012 -I "$D" -s tb_dispbase_phase -o "$D/tb_dispbase_phase.vvp" \
  "$D/_dispbase_wrap.vh" "$D/tb_dispbase_phase.sv"

vvp "$D/tb_dispbase_phase.vvp" | tee "$D/dispbase_phase.log"

grep -q "^PASS: DISPBASE_PHASE" "$D/dispbase_phase.log" || { echo "GATE FAIL: dispbase_phase"; exit 1; }
echo "DISPBASE-PHASE: PASS"
