#!/usr/bin/env bash
# run_rstwin.sh -- ADVERSARIAL verification of SRC-1b on the FULL yunit_top_family2
# hierarchy with a FAITHFUL emu reset (Arcade-SmashTV.sv:655 has no ioctl_download term)
# and a TITLE-SWITCH (second download into the running core).  Reuses the fullcore
# sv2v/iverilog plumbing; writes only into this directory.
set -uo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../../.." && pwd)"
FC="$ROOT/sim/probe/src1b/fullcore"
for tag in fixed reverted; do
  [ -f "$FC/core_$tag.v" ] || { echo "missing $FC/core_$tag.v -- run the fullcore gate first"; exit 2; }
  iverilog -g2012 -s tb_arm_rstwin -o "$HERE/rstwin_$tag.vvp" \
    "$FC/core_$tag.v" "$ROOT/sim/probe/src1b/williams_cvsd_board_stub.v" \
    "$ROOT/sim/sdram_chip.sv" "$ROOT/sim/ddr3_avalon_model.sv" \
    "$HERE/tb_arm_rstwin.sv" || exit 2
done
rc=0
for tag in fixed reverted; do
  for m in boot switch; do
    echo; echo "=========== $tag / MODE=$m ==========="
    ( cd "$HERE" && vvp "$HERE/rstwin_$tag.vvp" +MODE=$m "$@" ) 2>&1 | \
      grep -E "^\[rstwin\]|^FAIL|^RESULT"
  done
done
exit $rc
