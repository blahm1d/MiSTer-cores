#!/usr/bin/env python
"""SRC-1b MRA index-order contract gate.

SRC-1b arms the gfx unpack on the FALLING EDGE of sound_download
(yunit_top_family2.sv:806).  sound_download is Arcade-SmashTV.sv:497
    wire sound_download = ioctl_download & (ioctl_index == 8'd2);
and the core's ioctl_download port is fed with rom_download = index 0|1|2
(Arcade-SmashTV.sv:751, family2_download_mapper.sv:54-57).

So the arm is correct if and only if, for EVERY shipping MRA:
  (A) an index-2 rom element exists and carries at least one <part> (otherwise
      sound_download never rises, so it never falls, so the unpack never arms and
      core_rst is held forever -- measured at 400,250 cycles and still held by
      sim/probe/src1b/fullcore/tb_arm_fullcore.sv +MODE=single);
  (B) no index-0 or index-1 rom element follows the last index-2 element, i.e.
      index 2 really is the LAST core-visible stream.  (index 3/4 may follow: they
      do not raise rom_download.)

Exit 0 only if every MRA in every scanned set satisfies both.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
SETS = ["releases/family2", "releases/siblings", "releases/Y-unit"]

ELEM = re.compile(r'<(rom|nvram)\b[^>]*\bindex="(\d+)"[^>]*(/?)>', re.I)
PART = re.compile(r'<part\b', re.I)


def parts_after(text, pos, end):
    return len(PART.findall(text[pos:end]))


def check(path: Path):
    text = path.read_text(encoding="utf-8", errors="replace")
    hits = [(m.start(), m.end(), int(m.group(2)), m.group(3) == "/")
            for m in ELEM.finditer(text)]
    if not hits:
        return ["no <rom>/<nvram> index elements at all"]
    order = [h[2] for h in hits]
    errs = []

    idx2 = [i for i, h in enumerate(hits) if h[2] == 2]
    if not idx2:
        errs.append("NO index-2 element -> sound_download never rises (A)")
    else:
        last2 = idx2[-1]
        # (A) non-empty: count <part> between this element and the next index element
        start = hits[last2][1]
        end = hits[last2 + 1][0] if last2 + 1 < len(hits) else len(text)
        n = parts_after(text, start, end)
        if hits[last2][3] or n == 0:
            errs.append("index-2 element carries 0 <part> -> empty sound stream (A)")
        # (B) nothing core-visible after it
        after = [h[2] for h in hits[last2 + 1:]]
        bad = [i for i in after if i in (0, 1)]
        if bad:
            errs.append(f"core-visible index {bad} follows index 2 (B)")
    return errs, order


def main():
    total = 0
    bad = 0
    for s in SETS:
        d = ROOT / s
        if not d.is_dir():
            print(f"SKIP {s}: not present")
            continue
        files = sorted(d.glob("*.mra"))
        print(f"== {s}  ({len(files)} MRAs)")
        for f in files:
            res = check(f)
            errs, order = (res if isinstance(res, tuple) else (res, []))
            total += 1
            tag = "OK  " if not errs else "FAIL"
            if errs:
                bad += 1
            print(f"  {tag} order={','.join(map(str, order)):12s} {f.name}")
            for e in errs:
                print(f"       -> {e}")
    if total == 0:
        print("CONTRACT: FAIL (zero MRAs scanned -- coverage zero)")
        return 2
    print(f"CONTRACT: {'PASS' if bad == 0 else 'FAIL'} "
          f"({total - bad}/{total} MRAs satisfy index-2-last)")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
