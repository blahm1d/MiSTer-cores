#!/usr/bin/env bash
# run_src1b.sh -- the SRC-1b gate pair.  iverilog only (no Questa: nodelocked).
#
#   run_src1b.sh                 contract gate + arm gate; both must PASS
#   run_src1b.sh --revert-check  rebuild the "fixed" rig from git HEAD (edit reverted)
#                                and require the arm gate to FAIL
#   run_src1b.sh --full          run the gate, then the revert check
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../../.." && pwd)"
cd "$ROOT"

MODE="${1:-normal}"

arm_gate() {   # $1 = ARM_FIXED_FROM value ("" or HEAD)
  ARM_FIXED_FROM="$1" python "$HERE/gen_arm_rigs.py" || return 2
  echo "--- iverilog elaborate (-DSYNTHESIS: the arm block is inside \`ifdef SYNTHESIS) ---"
  iverilog -g2012 -DSYNTHESIS -o "$HERE/arm.vvp" \
    "$HERE/arm_fixed.sv" "$HERE/arm_reverted.sv" "$HERE/tb_arm_last_index.sv" || return 2
  vvp "$HERE/arm.vvp"
}

contract_gate() {
  echo "=============== gate 1/2: MRA index-order contract ==============="
  python "$HERE/check_mra_index_contract.py" | tail -5 || return 1
  echo
  echo "--- contract gate self-test (mutation coverage) ---"
  python "$HERE/check_mra_index_contract.py" --self-test | tail -3 || return 1
}

case "$MODE" in
  --revert-check)
    echo "### REVERT CHECK: the arm_fixed rig is rebuilt with the arm condition mechanically reverted."
    echo "### The gate MUST FAIL here, otherwise it does not exercise the edit."
    if arm_gate REVERT; then
      echo; echo "REVERT CHECK FAILED: the gate PASSED with the edit reverted."
      exit 1
    else
      echo; echo "REVERT CHECK OK: the gate FAILS with the edit reverted."
      exit 0
    fi
    ;;
  --full)
    contract_gate || { echo "CONTRACT GATE FAILED"; exit 1; }
    echo; echo "=============== gate 2/2: unpack arm ==============="
    arm_gate "" || { echo "ARM GATE FAILED"; exit 1; }
    echo; echo "BOTH GATES PASS"
    echo; bash "$0" --revert-check
    ;;
  *)
    contract_gate || { echo "CONTRACT GATE FAILED"; exit 1; }
    echo; echo "=============== gate 2/2: unpack arm ==============="
    arm_gate ""
    rc=$?
    echo
    if [ $rc -eq 0 ]; then echo "BOTH GATES PASS"; else echo "ARM GATE FAILED"; fi
    exit $rc
    ;;
esac
