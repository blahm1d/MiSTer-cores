#!/usr/bin/env bash
# SHARED-P0038 gate for the Y-unit tree.
#
#   1  un-mutated  -> the T-unit blind full-core oracle MUST pass
#   2  MUT_IO_NO_FIELD_MERGE -> write half reverted, oracle MUST fail (kill)
#   3  MUT_IO_NO_READ_RJ     -> read  half reverted, oracle MUST fail (kill)
#
# Both kills are ASSERTED, in the SAME run that reports the pass. A gate that
# passes without both kills firing is not verification: it would also pass on
# the un-fixed tree.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
TB=tb_io_subword_field
rc=0
run() {  # $1 = label, $2 = sv2v defines, $3 = expected PASS|FAIL
  local out; out="$(DEFS="$2" "$HERE/run_core_oracle.sh" $TB 2>&1)"
  local got=FAIL; grep -q "^PASS $TB" <<<"$out" && got=PASS
  if [ "$got" = "$3" ]; then echo "GATE ok   $1: $got (expected $3)"
  else echo "GATE FAIL $1: $got (expected $3)"; sed 's/^/        /' <<<"$out"; rc=1; fi
}
run "unmutated"               ""                          PASS
run "kill/write-half"         "-DMUT_IO_NO_FIELD_MERGE"   FAIL
run "kill/read-half"          "-DMUT_IO_NO_READ_RJ"       FAIL
if [ $rc -eq 0 ]; then echo "GATE RESULT: PASS (fix present AND both halves independently killable)"
else echo "GATE RESULT: FAIL"; fi
exit $rc
