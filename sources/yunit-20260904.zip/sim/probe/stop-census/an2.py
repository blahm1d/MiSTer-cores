import sys, glob, os, re, statistics
rows = []
for path in sorted(sys.argv[1:]):
    S = {}
    frames, areas, stopsites, dz = {}, {}, {}, {}
    reads = {}
    for line in open(path):
        p = line.split()
        if p[0] == "FRAME": frames[int(p[1])] = int(p[2])
        elif p[0] == "AREA": areas[int(p[1])] = int(p[2])
        elif p[0] == "READSITE": reads[p[1]] = int(p[2])
        elif p[0] == "STOPSITE":
            d = dict(kv.split("=") for kv in p[2:]); stopsites[p[1]] = d
        elif p[0] == "DZPAIR": dz[p[1]] = int(p[2])
        elif p[0] == "SUMMARY":
            for kv in p[1:]:
                k, v = kv.split("=", 1); S[k] = v
    if not S: print(f"{path}: NO SUMMARY -- VOID"); continue
    trig = int(S["trig"]); stop = int(S["stop"])
    if trig == 0 and stop == 0:
        print(f"{path}: ZERO COVERAGE -- FAIL"); continue
    cnt = list(frames.values())
    peak = max(cnt) if cnt else 0
    peakf = max(frames, key=frames.get) if frames else -1
    nfr = int(S["frames"])
    # size distribution over post-clip area
    tot_a = sum(areas.values())
    exp = []
    for a, c in sorted(areas.items()): exp += [a] * min(c, 4000)
    med = statistics.median(exp) if exp else 0
    small = sum(c for a, c in areas.items() if a <= 64 * 32) / tot_a * 100 if tot_a else 0
    rd = int(S["rtapcalls"])
    rows.append(dict(
        t=S["tag"], trig=trig, stop=stop, nfr=nfr,
        bpf=trig / nfr, bpf_act=(trig / len(frames)) if frames else 0, peak=peak, peakf=peakf,
        dzs=int(S["dz_strict"]), dzl=int(S["dz_loose"]), dzlgo=int(S["dz_loose_go"]),
        sb=int(S["stop_busy"]), rd=rd, rpb=rd / trig if trig else 0,
        za=int(S["zeroarea"]), med=med, small=small,
        am=int(S["audit_mismatch"]), ac=int(S["audit_cmp"]),
        sites=stopsites, dz_pairs=dz, reads=reads))

hdr = f"{'tag':26} {'trig':>8} {'b/frm':>7} {'PEAK':>6} {'STOPs':>7} {'DZstr':>6} {'DZstr%':>7} {'DZloose':>8} {'DZl%':>6} {'sBusy':>5} {'DMAreads':>10} {'rd/blit':>8} {'0area':>6} {'medPx':>6} {'audit%':>7}"
print(hdr); print("-" * len(hdr))
for r in rows:
    dzp = 100.0 * r['dzs'] / r['stop'] if r['stop'] else 0
    dlp = 100.0 * r['dzl'] / r['stop'] if r['stop'] else 0
    ap = 100.0 * r['am'] / r['ac'] if r['ac'] else float('nan')
    print(f"{r['t']:26} {r['trig']:8d} {r['bpf']:7.1f} {r['peak']:6d} {r['stop']:7d} {r['dzs']:6d} {dzp:7.2f} {r['dzl']:8d} {dlp:6.2f} {r['sb']:5d} {r['rd']:10d} {r['rpb']:8.2f} {r['za']:6d} {r['med']:6.0f} {ap:7.3f}")

print("\n--- STOP sites (pc: n, busy, guarded-by-DMACTRL-read-within-3-writes) ---")
for r in rows:
    tot = sum(int(d['n']) for d in r['sites'].values())
    g = sum(int(d['guarded']) for d in r['sites'].values())
    print(f"{r['t']:26} sites={len(r['sites'])} guarded={g}/{tot} ({100.0*g/tot if tot else 0:.1f}%)  " +
          " ".join(f"{pc}:n={d['n']},g={d['guarded']}" for pc, d in
                   sorted(r['sites'].items(), key=lambda kv: -int(kv[1]['n']))[:3]))
print("\n--- DZ strict PC pairs ---")
for r in rows:
    if r['dz_pairs']:
        print(f"{r['t']:26} " + " ".join(f"{k}:{v}" for k, v in
              sorted(r['dz_pairs'].items(), key=lambda kv: -kv[1])[:4]))
print("\n--- top DMACTRL read sites ---")
for r in rows:
    print(f"{r['t']:26} " + " ".join(f"{k}:{v}" for k, v in
          sorted(r['reads'].items(), key=lambda kv: -kv[1])[:3]))
