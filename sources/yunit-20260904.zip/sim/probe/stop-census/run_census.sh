#!/usr/bin/env bash
# Y-unit STOP census runner.  Two passes per title:
#   pass 1  cold, no NVRAM -> parks at the CMOS/factory-settings screen, never reaches
#           display init.  Its ONLY job is to leave an nvram file behind.  Discarded.
#   pass 2  warm, reads that NVRAM -> boots to attract, gets coined into gameplay.  MEASURED.
# 600 frames per pass.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
ROMS="/d/deck/fpga/smash tv/roms"
MAME="/c/ProgramData/chocolatey/bin/mame.exe"   # 0.280
OUT="$HERE/out"
mkdir -p "$OUT"

FR=${FR:-600}
COIN=${COIN:-200}

run_one () {
  local title="$1"
  local nv="$OUT/nv_$title"
  mkdir -p "$nv"
  echo "=== $title pass1 (cold, seeding NVRAM) ==="
  YSC_OUT="$OUT/${title}_pass1.txt" YSC_STOP_FRAME=$FR YSC_COIN_AT=$COIN \
    "$MAME" "$title" -rompath "$ROMS" -nvram_directory "$nv" -cfg_directory "$OUT/cfg" \
      -video none -sound none -skip_gameinfo -nothrottle \
      -autoboot_script "$HERE/yunit_stop_census.lua" \
      > "$OUT/${title}_pass1.log" 2>&1
  echo "  exit=$?  nvram:"; ls -la "$nv"/*/ 2>/dev/null | tail -3
  echo "=== $title pass2 (warm, MEASURED) ==="
  YSC_OUT="$OUT/${title}_pass2.txt" YSC_STOP_FRAME=$FR YSC_COIN_AT=$COIN \
    "$MAME" "$title" -rompath "$ROMS" -nvram_directory "$nv" -cfg_directory "$OUT/cfg" \
      -video none -sound none -skip_gameinfo -nothrottle \
      -autoboot_script "$HERE/yunit_stop_census.lua" \
      > "$OUT/${title}_pass2.log" 2>&1
  echo "  exit=$?"
  tail -1 "$OUT/${title}_pass2.txt" 2>/dev/null
}

for t in "$@"; do run_one "$t"; done
