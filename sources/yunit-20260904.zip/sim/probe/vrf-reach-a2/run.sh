#!/usr/bin/env bash
# VERIFIER arm: the case a2-cache-suff never ran -- frozen ext_rom_addr = the MEASURED
# value a reset-held 6809 produces (0x07FFF), with the reset vector actually fetched.
set -e
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
D="$(cd "$(dirname "$0")" && pwd)"; ROOT="$(cd "$D/../../.." && pwd)"; cd "$D"

iverilog -g2012 -DSIM_NO_ALTERA -s tb_reach -o reach.vvp \
  "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/sim/sdram_chip.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" "$ROOT/rtl/sdram/yunit_sdram_arb.sv" \
  "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" \
  "$D/tb_reach.sv" 2>&1 | grep -v "sorry: constant selects" || true

echo "###### ARM V1: REAL reset-held freeze 0x07FFF + reset vector (THE MISSING ARM) ######"
vvp reach.vvp +FROZEN=07FFF +VEC=1 2>&1 | tail -25
echo
echo "###### ARM V0 (control): reproduce the claim's ARM 2 -- frozen 0, VEC=1 ############"
vvp reach.vvp +FREEZE=0 +VEC=1 2>&1 | tail -20
