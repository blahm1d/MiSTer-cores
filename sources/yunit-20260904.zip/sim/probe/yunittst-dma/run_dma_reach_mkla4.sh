#!/bin/bash
# Path-#2 residual: the Phase-1 census ran MAME set "mk", which is the T-UNIT
# Mortal Kombat (midtunit.cpp). The Y-unit core's MRA is "Mortal Kombat (rev 4.0
# 09-28-92, Y-Unit)" = MAME set mkla4 (midyunit.cpp). Re-run the SAME probe on
# the correct machine. No check weakened; identical tap window and duration.
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
S="$D/../p0038-reach-audit"
P="$D/../fixinv-pathaudit"
mkdir -p "$D/dmareach"
for g in "$@"; do
  P0038_OUT="$D/dmareach/dma_${g}.txt" P0038_SECS=60 P0038_PLAY=1 "$MAME" $g \
    -rompath "$RP" -cfg_directory "$S/cfg" -nvram_directory "$S/nvram" \
    -autoboot_script "$P/dma_field_probe.lua" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run 70 -nothrottle -skip_gameinfo \
    > "$D/dmareach/log_${g}.txt" 2>&1
  echo "== $g : $(tail -2 "$D/dmareach/dma_${g}.txt" 2>/dev/null | tr '\n' ' ')"
done
