# Path-#2 residual closure WITHOUT trusting the tap's `lownib` column.
#
# The tap's address column comes from MAME's handler offset, and WFIELDMAC
# (34010ops.h:36) writes `address & ~15`, so lownib is 0 BY CONSTRUCTION -- a
# tautology of the instrument, not a measurement.  The bit offset is instead
# recovered from an INVARIANT that survives the alignment: a field write of W
# bits starting at bit offset b inside a 16-bit word is decomposed by MAME into
#   ceil((b + W) / 16)  aligned word writes at CONSECUTIVE addresses.
# So for one PC:
#   W=16 : 1 index  => b == 0        ; 2 indices => b != 0   (STRADDLE)
#   W=32 : 2 indices => b == 0       ; 3 indices => b != 0   (STRADDLE)
#   MMTM of n regs (W=32n): 2n indices => b == 0 ; 2n+1 => b != 0
# A straddling write is exactly the case the yunit_memsys DMA register file
# cannot express (d_addr_q[3:0] never referenced), so it is the DEFECT case.
import sys, glob, os, re

def eff_width(op, fs0, fs1):
    """(width_bits, how) for the instruction that produced the access."""
    # MMTM Rp,list  = 0000 1001 100R RRRR ; MMFM = 0000 1001 101R RRRR
    if (op >> 5) == 0x04C: return ('MMTM', None)
    if (op >> 5) == 0x04D: return ('MMFM', None)
    # MOVB variants: 0x8800-0x8FFF (*Rs,Rd / Rs,*Rd), 0x0Dxx / 0x0Fxx abs forms
    if 0x8800 <= op <= 0x8FFF: return ('MOVB8', 8)
    if op in (0x05C0, 0x05E0, 0x07C0, 0x07E0): return ('MOVBabs', 8)
    # MOVE Rs,@abs,F  = 0000 010F 10.. / 0000 011F ...  -> 0x0580/0x0581.. F in bit9
    if (op & 0xFE00) == 0x0400 or (op & 0xFC00) == 0x0400: pass
    if (op & 0xFF00) in (0x0500, 0x0700):     # MOVE abs forms
        F = 1 if (op & 0x0200) else 0
        return ('MOVEabs.F%d' % F, fs1 if F else fs0)
    # register indirect MOVE forms 0x8000-0x87FF (*Rs,Rd), 0x9000-0x9FFF,
    # 0xA000-0xBFFF (Rs,*Rd / Rs,*Rd+ / Rs,-*Rd / offset forms)
    if 0x8000 <= op <= 0x87FF or 0x9000 <= op <= 0xBFFF:
        F = 1 if (op & 0x0200) else 0
        return ('MOVEind.F%d' % F, fs1 if F else fs0)
    return ('UNKNOWN', None)

for path in sorted(sys.argv[1:]):
    name = os.path.basename(path)
    sites = {}
    for line in open(path):
        line = line.strip()
        if not line or line.startswith('#'): continue
        f = line.split()
        if f[0] != 'W': continue
        pc, idx, lownib, fs0, fs1, op, cnt = f[1], int(f[2],16), int(f[3]), int(f[4]), int(f[5]), int(f[6],16), int(f[7])
        sites.setdefault((pc,op,fs0,fs1), []).append((idx,cnt))
    bad = []
    for (pc,op,fs0,fs1), idxs in sorted(sites.items()):
        ids = sorted(set(i for i,_ in idxs))
        n = len(ids)
        kind, w = eff_width(op, fs0, fs1)
        contiguous = (ids == list(range(ids[0], ids[0]+n)))
        verdict = None
        if kind.startswith('MMTM') or kind.startswith('MMFM'):
            verdict = 'ALIGNED' if (n % 2 == 0 and contiguous) else 'STRADDLE?'
        elif w == 16:
            verdict = 'ALIGNED' if n == 1 else 'STRADDLE'
        elif w == 32:
            verdict = 'ALIGNED' if n == 2 and contiguous else 'STRADDLE'
        elif w == 8:
            verdict = 'SUBWORD-8BIT'
        else:
            verdict = 'UNCLASSIFIED w=%s' % w
        if verdict != 'ALIGNED':
            bad.append((pc,op,kind,w,ids,verdict,sum(c for _,c in idxs)))
    print('%-22s sites=%-4d  NON-ALIGNED/SUBWORD=%d' % (name, len(sites), len(bad)))
    for b in bad:
        print('    pc=%s op=%04X %s w=%s idx=%s -> %s (count=%d)' % (b[0],b[1],b[2],b[3],b[4],b[5],b[6]))
