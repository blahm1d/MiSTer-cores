#!/bin/bash
# RC1 reachability census re-run on the CORRECT machine. The Phase-1 table's
# "mk" row used MAME set `mk`, which is midtunit.cpp's T-Unit Mortal Kombat
# (rev 5.0 T-Unit) -- a different board, map and program. The Y-unit core's
# MRA is "Mortal Kombat (rev 4.0 09-28-92, Y-Unit)" = MAME set mkla4
# (midyunit.cpp). Same probe, same 60 s, same two-pass NVRAM warm-up.
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
S="$D/../p0038-reach-audit"
for g in "$@"; do
  for pass in 1 2; do
    P0038_OUT="$D/sites_${g}_p${pass}.txt" P0038_SECS=60 "$MAME" $g \
      -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram" \
      -autoboot_script "$S/p0038_io_field_probe.lua" -autoboot_delay 0 \
      -video none -sound none -seconds_to_run 70 -nothrottle -skip_gameinfo \
      > "$D/log_${g}_p${pass}.txt" 2>&1
  done
  echo "== $g pass2: $(tail -2 "$D/sites_${g}_p2.txt" 2>/dev/null | tr '\n' ' ')"
done
