import sys
lo=open('y_unit_test_u105.u105','rb').read()
hi=open('y_unit_test_u89.u89','rb').read()
assert len(lo)==len(hi)
out=bytearray(len(lo)*2)
for i in range(len(lo)):
    out[2*i]=lo[i]
    out[2*i+1]=hi[i]
open('yunittst.bin','wb').write(out)
print("size",len(out),hex(len(out)))
# base address in 34010 bit-address terms: image sits at top of map
base = 0x100000000 - len(out)*8
print("bit base", hex(base))
