import sys, re, collections

path = sys.argv[1]
per_frame = collections.Counter()
px_frame = collections.Counter()
tot = 0
for line in open(path):
    if not line.startswith("BLIT"):
        continue
    p = line.split()
    f = int(p[1]); tot += 1
    d = dict(kv.split("=") for kv in p[4:])
    w = int(d["W"]); h = int(d["H"])
    per_frame[f] += 1
    px_frame[f] += w * h

if not per_frame:
    print("EMPTY"); sys.exit(1)

frames = sorted(per_frame)
counts = [per_frame[f] for f in frames]
peak = max(counts)
peak_f = frames[counts.index(peak)]
top = sorted(per_frame.items(), key=lambda kv: -kv[1])[:8]
# 41 ns/pixel MAME blit duration (midyunit_v.cpp:523); Y-unit frame = 1/54.71 s
FRAME_S = 1.0 / 54.71
busy = {f: px_frame[f] * 41e-9 for f in frames}
top_busy = sorted(busy.items(), key=lambda kv: -kv[1])[:5]

print(f"file={path}")
print(f"frames_with_blits={len(frames)} total_blits={tot} span={frames[0]}..{frames[-1]}")
print(f"PEAK blits/frame = {peak} (frame {peak_f})")
print("top frames:", ", ".join(f"{f}:{c}" for f, c in top))
print(f"mean blits/frame over active frames = {tot/len(frames):.1f}")
print(f"PEAK pixels/frame = {max(px_frame.values())}")
print("peak MAME blitter-busy fraction of a frame: " +
      ", ".join(f"f{f}:{b/FRAME_S*100:.1f}%" for f, b in top_busy))
