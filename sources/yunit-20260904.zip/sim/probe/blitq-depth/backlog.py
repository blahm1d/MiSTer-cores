"""Replay the captured (unstalled) MAME blit issue stream through a FIFO served at
k * 41ns/pixel and report the PEAK BACKLOG -- i.e. the queue depth that would be
needed for the CPU never to be back-pressured.

MAME never stalls the CPU on a DMA trigger (docs/mame-ref/midyunit_v.cpp:422-435
accepts every write; the timer at :523 only reports done), so the captured issue
times are the true unstalled demand.
"""
import sys, collections

NS = 41e-9
path = sys.argv[1]
ks = [float(x) for x in (sys.argv[2:] or ["1.0", "2.0", "4.0"])]

ev = []
for line in open(path):
    if not line.startswith("BLIT"):
        continue
    p = line.split()
    d = dict(kv.split("=") for kv in p[4:])
    ev.append((float(d["T"]), int(d["W"]) * int(d["H"]), int(p[1])))
ev.sort()

print(f"file={path}  blits={len(ev)}")
for k in ks:
    svc_free = 0.0          # time the engine next becomes free
    inflight = collections.deque()   # completion times of queued+active blits
    peak = 0
    peak_t = 0.0
    for t, px, f in ev:
        while inflight and inflight[0] <= t:
            inflight.popleft()
        start = max(t, svc_free)
        svc_free = start + k * NS * max(px, 1)
        inflight.append(svc_free)
        if len(inflight) > peak:
            peak = len(inflight)
            peak_t = t
    print(f"  service={k:g}x41ns/px  PEAK BACKLOG (active+queued) = {peak}   at t={peak_t:.3f}s")
