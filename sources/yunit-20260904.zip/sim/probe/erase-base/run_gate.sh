#!/usr/bin/env bash
# GATE: the beam-locked autoerase engine erases the rows the game ACTUALLY
# DISPLAYS -- at any display base, not just base 0.
#
# THE DEFECT THIS GATE EXISTS FOR (fixed 2026-08-17). The C engine's goal
# filter was `!trig_nr[8]`, documented as "goals are always 0..255 ... the
# erase can never touch non-displayed VRAM (rows 256+)". Rows 256+ are
# non-displayed ONLY when the display base is 0. MEASURED on MAME 0.289
# (mame-trace/page_usage.lua, live gameplay):
#   High Impact  displays rows 256..511 on 1,275 of 2,931 drawing frames
#   Strike Force is a TRUE BACK-BUFFER title (draws into the page it is not
#                displaying on 2,945 frames vs 5) at bases 255 and 511
# so those pages were never erased: Strike Force smeared and lost sprites,
# High Impact's UI flashed (one page erased, one stale, alternating -- which
# is exactly why turning autoerase OFF "improved" it: both pages then stale).
# Smash T.V. and Trog are base-0 and were unaffected. Family blindness.
#
# Legs: base 0 (the cabinet-proven control -- must stay green), 256 (High
# Impact's second page), 255 and 511 (Strike Force's two bases).
#
# Mutation control runs on every invocation: -DMUT_ERASE_PAGE0_ONLY restores
# the pre-fix filter and MUST fail the non-zero-base legs (and MUST still pass
# base 0 -- proving the fix is inert for the titles that already worked).
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
D="$ROOT/sim/probe/erase-base"
T="$ROOT/sim/build/erase-base"
IV="${IV:-iverilog}"
mkdir -p "$T"

command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }

SRC=("$ROOT/rtl/pkg/yunit_pkg.sv"
     "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv"
     "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
     "$ROOT/rtl/yunit/family2/yunit_video_family2.sv"
     "$ROOT/rtl/yunit/family2/yunit_scanline_family2.sv"
     "$ROOT/rtl/yunit/family2/yunit_video_top_family2.sv"
     "$ROOT/sim/ddr3_avalon_model.sv" "$D/tb_erase_base.sv")

"$IV" -g2012 -s tb_erase_base -o "$T/tb.vvp"  "${SRC[@]}" 2>&1 | grep -v "sorry:" || true
"$IV" -g2012 -DMUT_ERASE_PAGE0_ONLY -s tb_erase_base -o "$T/tbm.vvp" "${SRC[@]}" 2>&1 | grep -v "sorry:" || true
[ -s "$T/tb.vvp" ] && [ -s "$T/tbm.vvp" ] || { echo "GATE_INCONCLUSIVE: compile produced no image"; exit 77; }

fail=0
for base in 0 256 255 511; do
  log="$T/base$base.log"
  (cd "$ROOT/sim" && vvp "$T/tb.vvp" "+BASE=$base") > "$log" 2>&1 || true
  if grep -q "^RESULT: PASS" "$log"; then
    echo "  base $base: PASS"
  else
    echo "  base $base: FAIL"; grep -E "FAIL" "$log" | head -4; fail=1
  fi
done
[ "$fail" = 0 ] || { echo "GATE FAIL: erase-base -- a displayed page is not being erased"; exit 1; }

# Mutant discrimination, derived from the defect's own arithmetic rather than
# assumed uniform across the legs:
#   base 256 -> erase targets 255..509  } include rows >= 256, exactly what the
#   base 255 -> erase targets 254..509  } old filter rejected  => KILL legs
#   base 511 -> targets are 510/511 (skipped) then 0..253 -- ALL below 256, so
#               the old filter accepted them too. This leg proves the fix WORKS
#               there but CANNOT discriminate it; demanding a kill here would be
#               a fake gate.
#   base 0   -> targets 0..254, likewise never affected.
# So the mutant must DIE at 256 and 255, and must SURVIVE at 0 and 511 -- the
# latter is the positive evidence that this change is inert for the
# cabinet-proven titles (Smash T.V. and Trog are base 0).
mfail=0
for base in 256 255; do
  mlog="$T/mut_base$base.log"
  (cd "$ROOT/sim" && vvp "$T/tbm.vvp" "+BASE=$base") > "$mlog" 2>&1 || true
  grep -q "^RESULT: FAIL" "$mlog" || { echo "GATE_INCONCLUSIVE: mutant SURVIVED at kill-leg base $base"; mfail=1; }
done
[ "$mfail" = 0 ] || exit 77
for base in 0 511; do
  mlog="$T/mut_base$base.log"
  (cd "$ROOT/sim" && vvp "$T/tbm.vvp" "+BASE=$base") > "$mlog" 2>&1 || true
  grep -q "^RESULT: PASS" "$mlog"     || { echo "GATE_INCONCLUSIVE: mutant FAILS unaffected base $base -- the legs do not isolate the defect"; exit 77; }
done

# ---- 2026-08-18 raw-space guard legs (the SF/Saurian phantom-erase fix) ----
# Base 511's expectation FLIPPED: gospel's guard runs on the UNMASKED rowaddr
# (midyunit_v.cpp:538), so a base-511 window (raw 511..765) is NEVER erased --
# the tb now demands full PRESERVATION + zero issues there. Two configs:
#   no-sequencer (the vvp above): erase_en carries the per-frame guard (tb
#     transcription of yunit_top_family2's erase_frame_raw_ok).
#   sequencer (-DYUNIT_DISPLAY_SEQ): the event path -- tb fires gospel-guarded
#     per-line events; base 511 fires none.
# Kill control: -DYUNIT_DISPLAY_SEQ -DMUT_ERASE_PHYS_TRIGGER restores the phys-space
# snoop trigger and MUST fail base 511 (the phantom recreated) while still
# passing base 0 (inert where phys == raw).
"$IV" -g2012 -DYUNIT_DISPLAY_SEQ -s tb_erase_base -o "$T/tbf.vvp" "${SRC[@]}" 2>&1 | grep -v "sorry:" || true
"$IV" -g2012 -DYUNIT_DISPLAY_SEQ -DMUT_ERASE_PHYS_TRIGGER -s tb_erase_base -o "$T/tbfm.vvp" "${SRC[@]}" 2>&1 | grep -v "sorry:" || true
[ -s "$T/tbf.vvp" ] && [ -s "$T/tbfm.vvp" ] || { echo "GATE_INCONCLUSIVE: DISPLAY_SEQ compile produced no image"; exit 77; }

for base in 0 256 511; do
  log="$T/full_base$base.log"
  (cd "$ROOT/sim" && vvp "$T/tbf.vvp" "+BASE=$base") > "$log" 2>&1 || true
  if grep -q "^RESULT: PASS" "$log"; then
    echo "  DISPLAY_SEQ base $base: PASS"
  else
    echo "  DISPLAY_SEQ base $base: FAIL"; grep -E "FAIL" "$log" | head -4; fail=1
  fi
done
[ "$fail" = 0 ] || { echo "GATE FAIL: erase-base DISPLAY_SEQ event path"; exit 1; }

mlog="$T/fullmut_base511.log"
(cd "$ROOT/sim" && vvp "$T/tbfm.vvp" "+BASE=511") > "$mlog" 2>&1 || true
grep -q "^RESULT: FAIL" "$mlog" \
  || { echo "GATE_INCONCLUSIVE: MUT_ERASE_PHYS_TRIGGER survived base 511 -- the phantom-erase fix is not exercised"; exit 77; }
mlog="$T/fullmut_base0.log"
(cd "$ROOT/sim" && vvp "$T/tbfm.vvp" "+BASE=0") > "$mlog" 2>&1 || true
grep -q "^RESULT: PASS" "$mlog" \
  || { echo "GATE_INCONCLUSIVE: MUT_ERASE_PHYS_TRIGGER fails base 0 -- legs do not isolate the trigger source"; exit 77; }

# Macro-order guard: build_hw passes YUNIT_FULL directly to stv_vram_ddr_top
# before yunit_top_family2 can declare its DISPLAY_SEQ alias. Exercise that
# FULL-only preprocessing route independently from the explicit SF flavor.
"$IV" -g2012 -DYUNIT_FULL -s tb_erase_base -o "$T/tbfull.vvp" "${SRC[@]}" 2>&1 | grep -v "sorry:" || true
[ -s "$T/tbfull.vvp" ] || { echo "GATE_INCONCLUSIVE: FULL-only compile produced no image"; exit 77; }
for base in 0 256 511; do
  log="$T/fullonly_base$base.log"
  (cd "$ROOT/sim" && vvp "$T/tbfull.vvp" "+BASE=$base") > "$log" 2>&1 || true
  if grep -q "^RESULT: PASS" "$log"; then
    echo "  FULL-only base $base: PASS"
  else
    echo "  FULL-only base $base: FAIL"; grep -E "FAIL" "$log" | head -4; fail=1
  fi
done
[ "$fail" = 0 ] || { echo "GATE FAIL: erase-base FULL-only event path"; exit 1; }

echo "ERASE-BASE: PASS (fallback, DISPLAY_SEQ, and FULL-only paths; rows 510/511 preserved; event mutations killed)"
