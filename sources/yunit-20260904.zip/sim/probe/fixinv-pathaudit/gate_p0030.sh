#!/bin/sh
# GATE + MUTATION KILL in ONE run. Exits 0 only if:
#   (a) the LIVE Y-unit ALU passes the gospel oracle, AND
#   (b) the pre-P0030 mutant (flags.c = !sub_ext[32]) is KILLED by that same oracle.
# (b) is the "would this fail if the change were reverted?" proof.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
R="$(cd "$D/../../.." && pwd)"
PKG="$R/rtl/tms34010/rtl/tms34010_pkg.sv"
LIVE="$R/rtl/tms34010/rtl/core/tms34010_alu.sv"
MUT="$D/mutant_alu_p0030.sv"

echo "--- LIVE ---"
LIVE_OUT="$(PKG="$PKG" ALU="$LIVE" sh "$D/run_sub_cflag.sh" 2>&1)"; echo "$LIVE_OUT"
echo "--- MUTANT (pre-P0030) ---"
MUT_OUT="$(PKG="$PKG" ALU="$MUT" sh "$D/run_sub_cflag.sh" 2>&1)"; echo "$MUT_OUT" | grep -E "FAIL|RESULT|PASS" | head -6

fail=0
echo "$LIVE_OUT" | grep -q "^PASS: tb_tms34010_sub_cflag" || { echo "ASSERT-FAIL: live ALU did not PASS"; fail=1; }
echo "$MUT_OUT"  | grep -q "^PASS: tb_tms34010_sub_cflag" && { echo "ASSERT-FAIL: MUTANT SURVIVED -- gate does not exercise the change"; fail=1; }
echo "$MUT_OUT"  | grep -q "SUBB a==b borrow-in (the P0025 case)" || { echo "ASSERT-FAIL: named divergence case did not fire on the mutant"; fail=1; }
[ "$fail" -eq 0 ] || { echo "GATE_RESULT: FAIL"; exit 1; }
echo "GATE_RESULT: PASS (live green + mutant killed on the named case)"
