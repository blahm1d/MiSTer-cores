#!/bin/sh
# PATH MERGE AUDIT -- measures, for every CPU-field-write terminator in the live
# Y-unit tree, whether it MERGES (bit-granular RMW vs the WFIELDMAC gospel) or
# CLOBBERS. Reproduces every PATH_VERDICT in the report from scratch.
set -e
D="$(cd "$(dirname "$0")" && pwd)"
R="$(cd "$D/../../.." && pwd)"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
T="/tmp/pathaudit.$$"; mkdir -p "$T"
# NOTE: the repo path contains a space -- every path stays individually quoted.
core_sv2v() {   # $1 = TB path; stdout = flattened verilog
  "$SV2V" "$R/rtl/pkg/yunit_pkg.sv" "$R/rtl/yunit/yunit_protection.sv" "$R/rtl/yunit/family2/yunit_mem_family2.sv" "$R/rtl/yunit/family2/yunit_dma_family2.sv" "$R/rtl/yunit/yunit_dma_logical_timer.sv" "$R/rtl/yunit/yunit_dma_descriptor_fifo.sv" "$R/rtl/yunit/family2/yunit_memsys_family2.sv" "$1"
}

echo "===== 1/3  TMS34010 internal I/O register file (0xC0000000) ====="
$SV2V "$R/rtl/tms34010/rtl/tms34010_pkg.sv" "$R/rtl/tms34010/rtl/video/tms34010_video.sv" \
      "$R/rtl/tms34010/rtl/io/tms34010_io_regs.sv" "$D/tb_io_field_merge_probe.sv" > "$T/io.v"
iverilog -g2012 -s tb_io_field_merge_probe -o "$T/io.vvp" "$T/io.v"; vvp "$T/io.vvp" | grep -vE '\$finish'

echo "===== 1b/3 CONTROL: the SAME probe against the T-unit tree (recorded fixed) ====="
TR=/d/deck/fpga/tunit/Arcade-TUnit_MiSTer
$SV2V "$TR/rtl/tms34010/rtl/tms34010_pkg.sv" "$TR/rtl/tms34010/rtl/video/tms34010_video.sv" \
      "$TR/rtl/tms34010/rtl/io/tms34010_io_regs.sv" "$D/tb_io_field_merge_probe_tunit.sv" > "$T/iot.v"
iverilog -g2012 -s tb_io_field_merge_probe_tunit -o "$T/iot.vvp" "$T/iot.v"; vvp "$T/iot.vvp" | grep -vE '\$finish'

echo "===== 2/3  board memory map: DMA regs / RAM / palette / CMOS / VRAM ====="
core_sv2v "$D/tb_dma_field_merge_probe.sv" > "$T/bd.v"
iverilog -g2012 -s tb_dma_field_merge_probe -o "$T/bd.vvp" "$T/bd.v"
vvp "$T/bd.vvp" 2>&1 | grep -vE 'readmemh|\$finish'

echo "===== 3/3  sound / control latch field sensitivity ====="
core_sv2v "$D/tb_snd_ctrl_field_probe.sv" > "$T/sc.v"
iverilog -g2012 -s tb_snd_ctrl_field_probe -o "$T/sc.vvp" "$T/sc.v"
vvp "$T/sc.vvp" 2>&1 | grep -vE 'readmemh|\$finish'
rm -rf "$T"
