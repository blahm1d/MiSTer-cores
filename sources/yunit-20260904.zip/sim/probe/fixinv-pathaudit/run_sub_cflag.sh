#!/bin/sh
# Shared SUB/SUBB/CMP carry oracle runner -- ONE oracle, any tree's ALU.
#   PKG=<tms34010_pkg.sv> ALU=<tms34010_alu.sv> [TB=<tb>] [DEF=-Dxxx] sh run_sub_cflag.sh
# The vendored core uses `input wire <typedef>` / `output var`, which Icarus
# rejects, so everything goes through the same sv2v the production netlist uses.
set -e
: "${TB:=/d/deck/fpga/tunit/Arcade-TUnit_MiSTer/sim/monitors/tb_tms34010_sub_cflag.sv}"
: "${SV2V:=/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
T="${OUTDIR:-/tmp/subc.$$}"; mkdir -p "$T"
"$SV2V" $DEF "$PKG" "$ALU" "$TB" > "$T/flat.v"
iverilog -g2012 -o "$T/flat.vvp" "$T/flat.v"
vvp "$T/flat.vvp"
rm -rf "$T"
