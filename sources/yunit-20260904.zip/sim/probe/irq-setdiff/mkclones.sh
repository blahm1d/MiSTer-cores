#!/usr/bin/env bash
# Mechanically derive PACE-BUDGET MUTANTS of the SHIPPING blitter.
#
# The real DUT (rtl/yunit/family2/yunit_dma_family2.sv) is NEVER modified.  Each
# clone is produced by exactly TWO sed substitutions:
#   1. module rename                       (so all four can coexist in one TB)
#   2. the pace_cnt reload shift  << 2  ->  << N        (:391)
#      i.e. the 4.00 clk/px MAME-matched budget (midyunit_v.cpp:523) becomes
#      2^N clk/px.  N=2 is the IDENTITY clone -- it must behave bit-identically
#      to the real DUT, which is the clone-fidelity check inside the gate.
#
# Every generated file is diffed against the original and the diff MUST be
# exactly two changed lines, or this script fails.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/../../../rtl/yunit/family2/yunit_dma_family2.sv"
test -f "$SRC" || { echo "FATAL: missing $SRC"; exit 2; }

for N in 1 2 3; do
  OUT="$HERE/yunit_dma_family2_p${N}.sv"
  sed -e "s/^module yunit_dma_family2\$/module yunit_dma_family2_p${N}/" \
      -e "s/<< 2;\$/<< ${N};/" "$SRC" > "$OUT"
  CH=$(diff "$SRC" "$OUT" | grep -c '^[<>]' || true)
  if [ "$N" = "2" ]; then WANT=2; else WANT=4; fi   # identity clone: only the rename differs
  if [ "$CH" != "$WANT" ]; then
    echo "FATAL: clone p${N} diff has $CH changed lines, expected $WANT"
    diff "$SRC" "$OUT" || true
    exit 3
  fi
  echo "clone p${N}: OK ($CH diff lines)"
done
