#!/usr/bin/env python3
"""Real-operating-point calibration for the Y-unit blitter done-IRQ set difference.

Input: sim/probe/blitq-depth/out/<title>_attract.txt captures (MAME 0.280,
       tap = sim/probe/blitq-depth/capture_yunit_blit_stream.lua, every
       DMA_COMMAND write with bit15 set, with emulated issue time T).

Reproduces MAME's clip math EXACTLY (docs/mame-ref/midyunit_v.cpp:456-518) so the
timer duration uses the CLIPPED dims that midyunit_v.cpp:523 actually multiplies:
    m_dma_timer->adjust(attotime::from_nsec(41 * width * height))
and reports, per title:
  * clipped-pixel distribution              (census axis 1)
  * inter-command gap distribution, ns      (census axis 2)
  * MAME's own done-IRQ loss rate: fraction of blits whose successor TRIGGER
    lands within 41ns*clipped_px of their own command (emu_timer::adjust
    replaces the pending expiry -> dma_callback never runs -> IRQ lost).
  * the RTL set difference as a function of the blitter's realised clk/px:
    RTL suppresses iff the successor is pending when the blit reaches S_DONE,
    and S_DONE is gated by pace_cnt==0 i.e. 4.00 clk/px @96MHz = 41.667 ns/px
    (rtl/yunit/family2/yunit_dma_family2.sv:243-246,+300-306), but the REAL walk
    can run longer under SDRAM contention -> window widens to walk_ns.

No tolerance is applied anywhere; a blit with zero clipped pixels is reported
separately rather than being dropped.
"""
import sys, os, collections, math

MAME_NS_PER_PX = 41.0
CLK_MHZ = 96.0
NS_PER_CLK = 1000.0 / CLK_MHZ   # 10.4166.. ns


def s16(v):
    return v - 0x10000 if v & 0x8000 else v


def clip(cmd, W, H, X, Y):
    """midyunit_v.cpp:456-518, yawdim_dma=0 (only mkyawdim sets it, :94).
    Returns (clipped_w, clipped_h) as SIGNED ints (may go negative)."""
    xpos = s16(X)
    ypos = s16(Y)
    w = W
    h = H
    if cmd & 0x10:
        # :466-476 -- xpos += width-1 (rowbytes adj does not affect w/h)
        xpos += w - 1
    # Y clip :479-487
    if ypos < 0:
        h -= -ypos
        ypos = 0
    if ypos + h > 512:
        h = 512 - ypos
    # X clip :490-512
    if not (cmd & 0x10):
        if xpos < 0:
            w -= -xpos
            xpos = 0
        if xpos + w > 512:
            w = 512 - xpos
    else:
        if xpos >= 512:
            w -= xpos - 511
            xpos = 511
        if xpos - w < 0:
            w = xpos
    return w, h


def load(path):
    rows = []
    for line in open(path):
        if not line.startswith("BLIT"):
            continue
        p = line.split()
        d = dict(kv.split("=", 1) for kv in p[4:])
        if "T" not in d:
            return None  # capture predates the timestamp field; unusable here
        cmd = int(d["CMD"], 16)
        W = int(d["W"]); H = int(d["H"])
        X = int(d["X"]); Y = int(d["Y"])
        cw, ch = clip(cmd, W, H, X, Y)
        px = cw * ch if (cw > 0 and ch > 0) else 0
        rows.append(dict(frame=int(p[1]), cmd=cmd, rawpx=W * H, px=px,
                         cw=cw, ch=ch, t=float(d["T"])))
    return rows


def pct(vals, q):
    if not vals:
        return float("nan")
    v = sorted(vals)
    i = min(len(v) - 1, max(0, int(round(q / 100.0 * (len(v) - 1)))))
    return v[i]


def report(title, rows, clk_per_px_list):
    n = len(rows)
    # gaps to the NEXT trigger command
    gaps = []
    for i in range(n - 1):
        gaps.append((rows[i + 1]["t"] - rows[i]["t"]) * 1e9)  # ns
    pxs = [r["px"] for r in rows]
    live = [r for r in rows if r["px"] > 0]
    degen = n - len(live)

    print(f"\n================ {title} ================")
    print(f"blits={n}  frames={rows[0]['frame']}..{rows[-1]['frame']}  "
          f"span={rows[-1]['t']-rows[0]['t']:.3f}s emulated")
    print(f"degenerate (clipped pixels == 0) = {degen} ({100.0*degen/n:.2f}%)"
          "  -- MAME timer duration 0 -> no loss window")
    print("CLIPPED PIXELS/BLIT   "
          f"mean={sum(pxs)/n:8.1f}  p10={pct(pxs,10)}  p50={pct(pxs,50)}  "
          f"p90={pct(pxs,90)}  p99={pct(pxs,99)}  max={max(pxs)}")
    print("MAME BLIT DURATION ns "
          f"mean={41.0*sum(pxs)/n:8.1f}  p50={41.0*pct(pxs,50):.0f}  "
          f"p90={41.0*pct(pxs,90):.0f}  p99={41.0*pct(pxs,99):.0f}")
    print("INTER-CMD GAP ns      "
          f"mean={sum(gaps)/len(gaps):8.1f}  p10={pct(gaps,10):.0f}  "
          f"p50={pct(gaps,50):.0f}  p90={pct(gaps,90):.0f}  "
          f"p99={pct(gaps,99):.0f}  max={pct(gaps,100):.0f}")

    # --- MAME's own loss set --------------------------------------------
    mame_lost = [i for i in range(n - 1)
                 if gaps[i] < MAME_NS_PER_PX * rows[i]["px"]]
    ml = set(mame_lost)
    print(f"MAME LOSS RATE        {len(ml)}/{n-1} = {100.0*len(ml)/(n-1):.2f}%"
          "   (successor trigger inside 41ns*clipped_px)")

    # --- RTL window as a function of realised clk/px ---------------------
    # RTL S_DONE gate: pace_cnt==0 (4.00 clk/px) but the walk can run longer.
    # window_ns = max(4.00 clk/px, realised clk/px) * px * NS_PER_CLK
    print("  realised   RTL-window   RTL lost   set-diff (RTL loses, MAME delivers)")
    print("  clk/px       ns/px       count      count      frac-of-all")
    for cpp in clk_per_px_list:
        eff = max(4.00, cpp)
        rtl_lost = set(i for i in range(n - 1)
                       if gaps[i] < eff * NS_PER_CLK * rows[i]["px"])
        diff = rtl_lost - ml
        rev = ml - rtl_lost
        flag = "" if not rev else f"  [REVERSE={len(rev)}]"
        print(f"  {cpp:5.2f}      {eff*NS_PER_CLK:7.2f}     "
              f"{len(rtl_lost):8d}   {len(diff):8d}   "
              f"{100.0*len(diff)/(n-1):7.3f}%{flag}")
    return dict(n=n, mame_loss=len(ml))


if __name__ == "__main__":
    base = os.path.join(os.path.dirname(__file__), "..", "blitq-depth", "out")
    files = sys.argv[1:] or [
        ("hiimpact", "hiimpact_attract.txt"),
        ("shimpact", "shimpact_attract.txt"),
        ("shimpact-COINED", "shimpact_coin.txt"),
        ("smashtv", "smashtv_attract2.txt"),
        ("totcarn", "totcarn_attract.txt"),
    ]
    sweep = [3.03, 3.50, 4.00, 4.25, 4.50, 5.00, 6.00, 8.00]
    for title, fn in files:
        p = os.path.join(base, fn)
        if not os.path.exists(p):
            print(f"\n{title}: MISSING {p}")
            continue
        rows = load(p)
        if rows is None:
            print(f"\n{title}: capture has no T field -- UNUSABLE for gap stats")
            continue
        if len(rows) < 2:
            print(f"\n{title}: ZERO COVERAGE ({len(rows)} blits) -- FAIL")
            sys.exit(2)
        report(title, rows, sweep)
