#!/usr/bin/env python3
"""Is the Y-unit display-list pump DONE-SERIALIZED (closed loop) or free-running?

If the CPU issues blit B only after receiving A's completion IRQ, then
    gap(A->B) = 41ns*px(A) + L      with L = the software's IRQ->reissue latency,
and the "successor pending at S_DONE" condition is UNREACHABLE in the RTL no
matter how slow the walk is: the successor cannot exist before the done that
causes it. That would make the set difference structurally ZERO and reclassify
the cabinet symptom as throughput, not lost interrupts.

If instead the pump is free-running (fixed cadence, blit issued from a display
list without waiting), the open-loop replay in opoint.py is valid.

This separates the two by measuring SLACK = gap - 41ns*px, bucketed by blit size.
A done-serialized pump shows slack roughly INDEPENDENT of px (it is the software
latency L). A free-running pump shows slack falling as px grows (eventually
negative -> MAME itself would lose IRQs, which we measured at exactly 0).
"""
import sys, os, collections
sys.path.insert(0, os.path.dirname(__file__))
from opoint import load, pct, MAME_NS_PER_PX

BUCKETS = [(1, 63), (64, 255), (256, 1023), (1024, 3999), (4000, 15999),
           (16000, 10 ** 9)]

base = os.path.join(os.path.dirname(__file__), "..", "blitq-depth", "out")
titles = [("hiimpact", "hiimpact_attract.txt"),
          ("shimpact", "shimpact_attract.txt"),
          ("smashtv", "smashtv_attract2.txt"),
          ("totcarn", "totcarn_attract.txt")]

for title, fn in titles:
    p = os.path.join(base, fn)
    rows = load(p)
    print(f"\n===== {title} =====   SLACK = gap - 41ns*clipped_px  (ns)")
    print("  px range        n      slack_p1   slack_p10   slack_p50   slack_p90"
          "    frac slack < 0.667*px (=RTL 41.667ns/px window)")
    by = collections.defaultdict(list)
    for i in range(len(rows) - 1):
        px = rows[i]["px"]
        gap = (rows[i + 1]["t"] - rows[i]["t"]) * 1e9
        for lo, hi in BUCKETS:
            if lo <= px <= hi:
                by[(lo, hi)].append((px, gap - MAME_NS_PER_PX * px))
                break
    for lo, hi in BUCKETS:
        v = by.get((lo, hi))
        if not v:
            print(f"  {lo}-{hi}: EMPTY")
            continue
        sl = [s for _, s in v]
        nin = sum(1 for px, s in v if s < 0.6667 * px)
        print(f"  {lo:>6}-{hi if hi<10**9 else 'inf':<7} {len(v):>7}  "
              f"{pct(sl,1):>10.0f} {pct(sl,10):>10.0f} {pct(sl,50):>10.0f} "
              f"{pct(sl,90):>10.0f}     {100.0*nin/len(v):6.2f}%")
    # global correlation check: median slack vs px
    allv = [x for lst in by.values() for x in lst]
    print(f"  ALL n={len(allv)} median slack={pct([s for _,s in allv],50):.0f} ns"
          f"  min slack={min(s for _,s in allv):.0f} ns")
