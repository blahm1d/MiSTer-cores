#!/usr/bin/env bash
# $1 = game, $2 = secs, rest = hole lengths (hex, no 0x)
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"
g="$1"; shift; secs="$1"; shift
for L in "$@"; do
  tag="${g}_L${L}"
  rm -rf "$D/nv_$tag"; cp -r "$D/../p0038-sufficiency/nvram" "$D/nv_$tag"
  mkdir -p "$D/snap_$tag"
  HOLE_LEN=$((16#$L)) HOLE_FILL=${HOLE_FILL:-0} HOLE_SECS=$secs \
  HOLE_OUT="$D/res_$tag.txt" HOLE_SNAP="$D/snap_$tag" \
  "$MAME" "$g" -rompath "$RP" -cfg_directory "$D/../p0038-sufficiency/cfg" \
    -nvram_directory "$D/nv_$tag" -snapshot_directory "$D/snap_$tag" \
    -autoboot_script "$D/romhole.lua" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run $((secs+8)) -nothrottle -skip_gameinfo \
    > "$D/log_$tag.txt" 2>&1
  echo "$(grep -m1 'ROMHOLE\[' "$D/log_$tag.txt")"
done
