#!/bin/bash
# CVSD 6809 banked-ROM fetch census + bounded trace, per title.
set -u
MAME=/c/tools/mame/mame.exe
RP="/d/deck/fpga/smash tv/roms"
D="$(cd "$(dirname "$0")" && pwd)"

for g in "$@"; do
  mkdir -p "$D/nvram/$g"
  "$MAME" $g -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram/$g" \
    -video none -sound none -seconds_to_run 45 -nothrottle -skip_gameinfo \
    > "$D/out/${g}_cv_p1.log" 2>&1
  YC_OUT="$D/out/cvsd_${g}.txt" YC_TRACE="$D/out/cvsdtrace_${g}.txt" \
  YC_STOP=1200 YC_COIN_AT=400 YC_SAMPLE_FROM=700 YC_SAMPLE_N=400000 \
  "$MAME" $g -rompath "$RP" -cfg_directory "$D/cfg" -nvram_directory "$D/nvram/$g" \
    -autoboot_script "$D/capture_cvsd_fetch.lua" -autoboot_delay 0 \
    -video none -sound none -seconds_to_run 600 -nothrottle -skip_gameinfo \
    > "$D/out/${g}_cv_p2.log" 2>&1
  echo "== $g"; head -2 "$D/out/cvsd_${g}.txt" 2>/dev/null || tail -5 "$D/out/${g}_cv_p2.log"
done
