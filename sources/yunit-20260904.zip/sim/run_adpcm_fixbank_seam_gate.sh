#!/usr/bin/env bash
# The ADPCM fixbank seam gate (the 2026-08-19 dead-sound class).
#
# Three legs, ALL required:
#   1. DECODE LOCKSTEP: the bench replicates the board's fixbank fill decode.
#      Grep the exact decode text out of rtl/yunit/yunit_adpcm_board.sv and out
#      of the bench; if the board's decode ever changes shape, this leg fails
#      and the bench must be re-locked BY HAND against the new board source.
#   2. BASE: real family2_download_mapper, MRA-ordered full-length 0x140000-byte
#      index-2 stream -> fixbank must hold the U3 window byte-exact. PASS.
#   3. MUTANT MUT_SNDADDR_TRUNC18 (the shipped 2026-08-19 behaviour: every
#      index-2 byte rides the tap, 18-bit alias clobbers the fixbank): the
#      SAME bench must FAIL. A base pass without this kill is vacuous.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
cd "$ROOT"

fail() { echo "SEAM-GATE: FAIL: $*" >&2; exit 1; }

# ---- leg 1: decode lockstep -------------------------------------------------
BOARD="rtl/yunit/yunit_adpcm_board.sv"
BENCH="sim/tb_adpcm_fixbank_seam.sv"
grep -Eq "snd_dl_addr\[17:14\] *== *4'hF" "$BOARD" \
  || fail "board fixbank decode text not found in $BOARD -- board changed; re-lock the bench"
grep -Eq "snd_addr\[17:14\] *== *4'hF" "$BENCH" \
  || fail "bench decode replica not found in $BENCH"
# The mapper must carry the qualifier AND the mutant hook, in BOTH mappers.
for M in rtl/yunit/family2/family2_download_mapper.sv rtl/yunit/yunit_download_mapper.sv; do
  grep -q "adpcm_snd_tap_ok" "$M" || fail "tap qualifier missing from $M"
  grep -q "MUT_SNDADDR_TRUNC18" "$M" || fail "mutant hook missing from $M"
done
echo "SEAM-GATE: decode lockstep OK"

# ---- leg 2: base run (expect PASS) -------------------------------------------
SRC=( rtl/pkg/yunit_pkg.sv rtl/yunit/family2/family2_download_mapper.sv "$BENCH" )
iverilog -g2012 -o sim/build/seam_base.vvp "${SRC[@]}" || fail "base compile"
vvp sim/build/seam_base.vvp > sim/build/seam_base.log 2>&1
grep -q "TEST_RESULT: PASS" sim/build/seam_base.log \
  || { tail -5 sim/build/seam_base.log >&2; fail "base run did not PASS"; }
echo "SEAM-GATE: base PASS"

# ---- leg 3: mutant run (expect FAIL = kill) ----------------------------------
iverilog -g2012 -DMUT_SNDADDR_TRUNC18 -o sim/build/seam_mut.vvp "${SRC[@]}" \
  || fail "mutant compile"
vvp sim/build/seam_mut.vvp > sim/build/seam_mut.log 2>&1
if grep -q "TEST_RESULT: PASS" sim/build/seam_mut.log; then
  fail "MUT_SNDADDR_TRUNC18 SURVIVED -- the gate does not exercise the alias"
fi
grep -q "TEST_RESULT: FAIL" sim/build/seam_mut.log \
  || { tail -5 sim/build/seam_mut.log >&2; fail "mutant produced no verdict"; }
echo "SEAM-GATE: mutant MUT_SNDADDR_TRUNC18 KILLED"

echo "SEAM-GATE: PASS (lockstep + base + mutant-kill)"
