#!/usr/bin/env python3
"""Streaming dual-digest comparator for the long Smash TV differential march.

The RTL digest harness uses the same ordered pixel fields as the verbose shared
trace, but reduces each completed blit to count + two independent 64-bit hashes.
This tool streams the large MAME trace (it never constructs the 550 MB trace in
memory), computes the identical reference digest, and stops at the first command
or pixel-stream mismatch.  A mismatch is then localized with the verbose probe.
"""

import argparse
import re

MASK = (1 << 64) - 1
H1_SEED = 0xCBF29CE484222325
H2_SEED = 0x6A09E667F3BCC909
H1_PRIME = 0x00000100000001B3
H2_PRIME = 0x9E3779B185EBCA87
H2_SALT = 0x517CC1B727220A95
BFIELDS = ("CMD", "X", "Y", "W", "H", "SAG", "RB", "COL", "PAL")


def mix1(h, v):
    return ((h ^ (v & MASK)) * H1_PRIME) & MASK


def mix2(h, v):
    return ((h ^ ((v + H2_SALT) & MASK)) * H2_PRIME) & MASK


def pixel_hash(h1, h2, fields):
    srca = 0xFFFFFFFF if fields["SRCA"] == "--------" else int(fields["SRCA"], 16)
    srcb = 0xFF if fields["SRCB"] == "--" else int(fields["SRCB"], 16)
    values = (
        srca, srcb, int(fields["X"]) & 0xFFFFFFFF,
        int(fields["Y"]) & 0xFFFFFFFF, int(fields["VA"], 16),
        int(fields["VAL"], 16), int(fields["BE"], 16), int(fields["CMT"]),
    )
    for value in values:
        h1 = mix1(h1, value)
        h2 = mix2(h2, value)
    return h1, h2


def stored_hash(h1, h2, fields):
    """Digest one MAME-committed framebuffer write (address + 16-bit data)."""
    values = (int(fields["VA"], 16), int(fields["VAL"], 16))
    for value in values:
        h1 = mix1(h1, value)
        h2 = mix2(h2, value)
    return h1, h2


def kvs(tokens):
    return dict(token.split("=", 1) for token in tokens if "=" in token)


def zero_gfx_pixel(fields, command):
    """Apply tb_yunit_ddr3game's intentional all-zero source-ROM substitution."""
    mode = int(command["CMD"], 16) & 0xF
    if not 1 <= mode <= 0xB:
        return fields
    fields = fields.copy()
    fields["SRCB"] = "00"
    pal16 = (int(command["PAL"], 16) & 0xFF) << 8
    color16 = pal16 | (int(command["COL"], 16) & 0xFF)
    if mode == 1:
        value, commit = pal16, 1
    elif mode == 2:
        value, commit = pal16, 0
    elif mode == 3:
        value, commit = pal16, 1
    elif mode in (4, 5):
        value, commit = color16, 1
    elif mode in (6, 7):
        value, commit = color16, 1
    elif mode in (8, 0xA):
        value, commit = color16, 0
    else:  # 9/B: px==0 selects the palette value, but still commits
        value, commit = pal16, 1
    fields["VAL"] = f"{value:04x}"
    fields["CMT"] = str(commit)
    return fields


def reference(path, start, stop, zero_gfx=False):
    result = {}
    current = None
    h1, h2, count = H1_SEED, H2_SEED, 0
    sh1, sh2, scount = H1_SEED, H2_SEED, 0
    command = None
    with open(path, "r", encoding="ascii", errors="replace", buffering=1024 * 1024) as trace:
        for raw in trace:
            if raw.startswith("B|"):
                if current is not None and start <= current < stop:
                    result[current]["digest"] = (count, h1, h2)
                    result[current]["stored"] = (scount, sh1, sh2)
                parts = raw.rstrip().split("|")
                current = int(parts[1])
                if current >= stop:
                    break
                h1, h2, count = H1_SEED, H2_SEED, 0
                sh1, sh2, scount = H1_SEED, H2_SEED, 0
                if current >= start:
                    fields = kvs(parts[3:])
                    command = fields
                    result[current] = {"fields": tuple(fields[name].lower() for name in BFIELDS)}
            elif raw.startswith("P|") and current is not None and start <= current < stop:
                parts = raw.rstrip().split("|")
                fields = kvs(parts[3:])
                if zero_gfx:
                    fields = zero_gfx_pixel(fields, command)
                h1, h2 = pixel_hash(h1, h2, fields)
                count += 1
                if int(fields["CMT"]):
                    sh1, sh2 = stored_hash(sh1, sh2, fields)
                    scount += 1
    if current is not None and start <= current < stop and "digest" not in result.get(current, {}):
        result[current]["digest"] = (count, h1, h2)
        result[current]["stored"] = (scount, sh1, sh2)
    return result


def dut(path, start, stop):
    result = {}
    with open(path, "r", encoding="ascii", errors="replace") as trace:
        for raw in trace:
            if raw.startswith("B|"):
                parts = raw.rstrip().split("|")
                bidx = int(parts[1])
                if start <= bidx < stop:
                    fields = kvs(parts[3:])
                    result.setdefault(bidx, {})["fields"] = tuple(fields[name].lower() for name in BFIELDS)
            elif raw.startswith("D|"):
                parts = raw.rstrip().split("|")
                bidx = int(parts[1])
                if start <= bidx < stop:
                    fields = kvs(parts[2:])
                    result.setdefault(bidx, {})["digest"] = (
                        int(fields["N"]), int(fields["H1"], 16), int(fields["H2"], 16))
            elif raw.startswith("S|"):
                parts = raw.rstrip().split("|")
                bidx = int(parts[1])
                if start <= bidx < stop:
                    fields = kvs(parts[2:])
                    result.setdefault(bidx, {})["stored"] = (
                        int(fields["N"]), int(fields["H1"], 16), int(fields["H2"], 16))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mame")
    parser.add_argument("rtl")
    parser.add_argument("--start", type=int, default=110)
    parser.add_argument("--stop", type=int, default=10000)
    parser.add_argument("--stored", action="store_true",
                        help="also compare accepted framebuffer writes against committed MAME P records")
    parser.add_argument("--zero-gfx", action="store_true",
                        help="transform MAME pixels to the top harness's intentional all-zero source ROM")
    args = parser.parse_args()
    ref = reference(args.mame, args.start, args.stop, args.zero_gfx)
    got = dut(args.rtl, args.start, args.stop)
    matched_pixels = 0
    matched_stores = 0
    for bidx in range(args.start, args.stop):
        if bidx not in ref:
            print(f"REFERENCE ENDS before B{bidx}")
            return 2
        if bidx not in got:
            print(f"RTL ENDS before completed B{bidx}; matched through B{bidx-1}")
            return 3
        if ref[bidx].get("fields") != got[bidx].get("fields"):
            print(f"FIRST COMMAND DIVERGENCE B{bidx}")
            for name, rv, dv in zip(BFIELDS, ref[bidx]["fields"], got[bidx]["fields"]):
                print(f"  {name}: MAME={rv} RTL={dv} {'MATCH' if rv == dv else 'DIFFER'}")
            return 1
        if ref[bidx].get("digest") != got[bidx].get("digest"):
            print(f"FIRST PIXEL-STREAM DIVERGENCE B{bidx}")
            print(f"  MAME N/H1/H2={ref[bidx].get('digest')}")
            print(f"  RTL  N/H1/H2={got[bidx].get('digest')}")
            return 1
        if args.stored and ref[bidx].get("stored") != got[bidx].get("stored"):
            print(f"FIRST ACCEPTED-FRAMEBUFFER DIVERGENCE B{bidx}")
            print(f"  MAME N/H1/H2={ref[bidx].get('stored')}")
            print(f"  RTL  N/H1/H2={got[bidx].get('stored')}")
            return 1
        matched_pixels += ref[bidx]["digest"][0]
        matched_stores += ref[bidx]["stored"][0]
    print(f"MATCH B{args.start}..B{args.stop-1}: {args.stop-args.start} commands, "
          f"{matched_pixels} ordered pixels, dual 64-bit digests" +
          (f", {matched_stores} MAME-vs-accepted framebuffer writes" if args.stored else "") +
          (", zero-gfx-transformed MAME oracle" if args.zero_gfx else ", raw MAME oracle"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
