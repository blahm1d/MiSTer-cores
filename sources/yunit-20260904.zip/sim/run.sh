#!/usr/bin/env bash
# Run a Y-unit testbench under Icarus Verilog.
#   ./run.sh tb_yunit_dma
# Toolchain note: birdybro's SV subset + this wrapper need Questa or Icarus.
# ModelSim ASE 17.0 (bundled with Quartus 17.0) is too old — it rejects
# `input logic` under `default_nettype none`. Icarus 12 works (constant selects
# are hoisted to continuous assigns; see rtl/yunit/yunit_dma.sv).
# NOTE: the repo path contains a space ("smash tv") — keep every path quoted.
set -e
TB="${1:-tb_yunit_dma}"
PLUSARGS=( "${@:2}" )   # +NAME=value forwarded to vvp
TB_FILE="$TB"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

SRC=( "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_protection.sv" )
DEFS=()
case "$TB" in
  tb_smashtv_cabinet_inputs)
    SRC=( "$ROOT/rtl/yunit/smashtv_cabinet_inputs.sv" ) ;;
  tb_smashtv_legacy_download_mapper)
    SRC=( "$ROOT/rtl/yunit/smashtv_legacy_download_mapper.sv" ) ;;
  tb_yunit_protection) ;;
  tb_yunit_profiles) SRC+=( "$ROOT/rtl/yunit/yunit_input_mapper.sv" ) ;;
  tb_yunit_twinstick) SRC+=( "$ROOT/rtl/yunit/yunit_twinstick.sv" ) ;;
  tb_yunit_input_bus)
    DEFS+=( -DUSE_HW_RAM -DUSE_EXT_GFX -DUSE_EXT_ROM )
    SRC+=( "$ROOT/rtl/yunit/yunit_input_mapper.sv"
           "$ROOT/rtl/yunit/yunit_mem.sv" ) ;;
  tb_yunit_cpu_cadence) SRC+=( "$ROOT/rtl/yunit/yunit_cpu_cadence.sv" ) ;;
  tb_yunit_dma_logical_timer) SRC+=( "$ROOT/rtl/yunit/yunit_dma_logical_timer.sv" ) ;;
  tb_yunit_dma_descriptor_fifo) SRC+=( "$ROOT/rtl/yunit/yunit_dma_descriptor_fifo.sv" ) ;;
  tb_tms34010_cycle_scheduler)
    SRC+=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
           "$ROOT/rtl/yunit/yunit_cpu_cadence.sv"
           "$ROOT/rtl/tms34010/rtl/io/tms34010_io_cpu_status.sv"
           "$ROOT/rtl/tms34010/rtl/core/tms34010_cycle_scheduler.sv" ) ;;
  # Protocol-aware equivalence gate for the scheduler retime.  It uses the real
  # cadence generator plus legal core-like start/retire handshakes and compares
  # every output with the PRE-RETIME module on every non-reset cycle.
  tb_sched_equiv)
    SRC=( "$ROOT/rtl/pkg/yunit_pkg.sv"
          "$ROOT/rtl/yunit/yunit_cpu_cadence.sv"
          "$ROOT/rtl/tms34010/rtl/core/tms34010_cycle_scheduler.sv"
          "$ROOT/sim/ref/sched_ref_raw.sv" ) ;;
  tb_tms34010_cycle_budget)
    SRC=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
          "$ROOT/rtl/tms34010/rtl/core/tms34010_cycle_budget.sv" ) ;;
  tb_tms34010_gfx_cycle_counter)
    SRC=( "$ROOT/rtl/tms34010/rtl/core/tms34010_gfx_cycle_counter.sv" ) ;;
  tb_yunit_gfx_unpack4) SRC+=( "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" ) ;;
  tb_yunit_gfx_unpack_oracle) SRC+=( "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" ) ;;
  tb_yunit_download_delivery)
    SRC=( "$ROOT/rtl/pkg/yunit_pkg.sv"
          "$ROOT/rtl/yunit/family2/family2_download_mapper.sv"
          "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" ) ;;
  tb_tms34010_cycle_budget_move_off_ni)
    SRC=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
          "$ROOT/rtl/tms34010/rtl/core/tms34010_cycle_budget.sv" ) ;;
  tb_gfx_unpack)
    SRC=( "$ROOT/rtl/yunit/yunit_gfx_unpack.sv"
          "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
          "$ROOT/rtl/sdram/sdram_phy.sv"
          "$ROOT/sim/sdram_chip.sv" ) ;;
  tb_yunit_palfold)
    DEFS+=( -DUSE_HW_RAM )
    SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_palram.sv" ) ;;
  tb_yunit_hwram)
    DEFS+=( -DUSE_HW_RAM )
    SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" ) ;;
  tb_yunit_adpcm_map)
    SRC+=( "$ROOT/rtl/yunit/yunit_adpcm_board.sv"
           "$ROOT/rtl/sound/williams_cvsd/mc6809is.v"
           "$ROOT/rtl/sound/jt51/hdl/"*.v
           "$ROOT/rtl/sound/jt6295/"*.v ) ;;
  # Package-only: the per-title hidden-RAM window table lives in yunit_pkg
  # precisely so it can be checked without driving the board's internal 6809.
  tb_yunit_adpcm_prot) ;;
  # Sound-latch CDC: the game's close write pair (SOUNDS.ASM:289-306) must
  # survive the 96->12 MHz crossing at every clock phase.
  tb_yunit_sound_cdc) SRC+=( "$ROOT/rtl/yunit/yunit_sound_cdc.sv" ) ;;
  tb_sound_rom_cache) SRC=( "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" ) ;;
  tb_yunit_sound_service)
    SRC=( "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv"
          "$ROOT/rtl/sdram/yunit_sdram_arb.sv" ) ;;
  # Harness-correctness bench: proves the CRTC ce_pix RATIO matters. It compares
  # a "bad harness" (ce tied high, the old differential rig) against production
  # (clk_sys/24). It was previously executed by NO runner, which is why its
  # MUT_BAD_CE contract sat orphaned.
  tb_dma_dpy_ratio)
    SRC+=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
           "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv"
           "$ROOT/rtl/yunit/yunit_dma.sv" ) ;;
  tb_yunit_dma) SRC+=( "$ROOT/rtl/yunit/yunit_dma.sv" ) ;;
  tb_yunit_dma_matrix) SRC+=( "$ROOT/rtl/yunit/yunit_dma.sv" ) ;;
  tb_yunit_dma_stop) SRC+=( "$ROOT/rtl/yunit/yunit_dma.sv" ) ;;
  tb_yunit_dma_queue) SRC+=( "$ROOT/rtl/yunit/yunit_dma.sv" ) ;;
  tb_audio_mix) SRC+=( "$ROOT/rtl/yunit/yunit_audio_mix.sv" ) ;;
  tb_yunit_cmos_nvram)
    DEFS+=( -DUSE_HW_RAM -DUSE_EXT_GFX -DUSE_EXT_ROM )
    SRC+=( "$ROOT/rtl/yunit/yunit_nvram_bridge.sv"
           "$ROOT/rtl/yunit/yunit_mem.sv" ) ;;
  tb_family2_cmos_nvram)
    TB_FILE=tb_yunit_cmos_nvram
    DEFS+=( -DFAMILY2_NVRAM_TEST -DUSE_HW_RAM -DUSE_EXT_GFX -DUSE_EXT_ROM )
    SRC+=( "$ROOT/rtl/yunit/yunit_nvram_bridge.sv"
           "$ROOT/rtl/yunit/family2/yunit_mem_family2.sv" ) ;;
  tb_yunit_mem_cdc)
    SRC+=( "$ROOT/rtl/yunit/yunit_cpu_cadence.sv"
           "$ROOT/rtl/yunit/yunit_mem_cdc.sv" ) ;;
  tb_yunit_hps_nvram)
    SRC=( "$ROOT/sys/hps_io.sv"
          "$ROOT/rtl/yunit/yunit_nvram_bridge.sv" ) ;;
  tb_yunit_mem) SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" ) ;;
  tb_yunit_romfetch)
    # R_ROM fetch THROUGHPUT + content gate. USE_EXT_ROM routes R_ROM reads out the
    # gfx_rd/gfx_rack word port that the TB models with a realistic round trip.
    DEFS+=( -DUSE_EXT_ROM )
    SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" ) ;;
  tb_yunit_vramcheck)
    # USE_EXT_GFX/USE_EXT_ROM are REQUIRED: the TB wires yunit_mem's gfx_rd/gfx_raddr/
    # gfx_rdata/gfx_rack port group, which only exists when a read-only region is
    # externalized. (The TB header's build line omits them and does not elaborate.)
    DEFS+=( -DUSE_HW_RAM -DUSE_SDRAM_VRAM -DUSE_DDR3_VRAM -DUSE_EXT_GFX -DUSE_EXT_ROM )
    SRC+=( "$ROOT/rtl/yunit/vram_sdram.sv"
           "$ROOT/rtl/yunit/vram_sdram_top.sv"
           "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
           "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
           "$ROOT/rtl/yunit/yunit_mem.sv"
           "$ROOT/rtl/yunit/yunit_palram.sv"
           "$ROOT/sim/ddr3_avalon_model.sv" ) ;;
  tb_yunit_autoerase) SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" ) ;;
  tb_yunit_autoerase_scheduler) SRC+=( "$ROOT/rtl/yunit/yunit_autoerase_scheduler.sv" ) ;;
  tb_sdram_burst_write)
    DEFS+=( -DSIM_NO_ALTERA )
    SRC=( "$ROOT/rtl/sdram/sdram_stock.sv"
          "$ROOT/sim/sdram_chip.sv" ) ;;
  tb_sdram_raster)
    DEFS+=( -DSIM_NO_ALTERA )
    SRC=( "$ROOT/rtl/sdram/sdram_stock.sv"
          "$ROOT/rtl/yunit/vram_sdram_scanout.sv"
          "$ROOT/sim/sdram_chip.sv" ) ;;
  tb_yunit_autoerase_sdram_backend)
    DEFS+=( -DSIM_NO_ALTERA )
    SRC=( "$ROOT/rtl/sdram/sdram_stock.sv"
          "$ROOT/rtl/yunit/yunit_autoerase_sdram_backend.sv"
          "$ROOT/sim/sdram_chip.sv" ) ;;
  tb_yunit_sdram_burst_arb)
    SRC=( "$ROOT/rtl/sdram/yunit_sdram_burst_arb.sv" ) ;;
  tb_yunit_shiftreg_engine) SRC+=( "$ROOT/rtl/yunit/yunit_shiftreg_engine.sv" ) ;;
  tb_yunit_scanline)
    SRC=( "$ROOT/rtl/yunit/yunit_scanline.sv"
          "$ROOT/sim/sdram_model.sv" ) ;;
  tb_yunit_scanline_livewrite_red)
    SRC=( "$ROOT/rtl/yunit/yunit_scanline.sv" ) ;;
  tb_yunit_shiftreg_command_bridge)
    SRC+=( "$ROOT/rtl/yunit/yunit_cpu_cadence.sv"
           "$ROOT/rtl/yunit/yunit_shiftreg_engine.sv" ) ;;
  tb_yunit_vram_word_arb) SRC+=( "$ROOT/rtl/yunit/yunit_vram_word_arb.sv" ) ;;
  tb_vram_ddr_shiftreg)
    DEFS+=( -DYUNIT_SRT_FILL_BURST )
    SRC=( "$ROOT/rtl/yunit/vram_sdram.sv"
          "$ROOT/rtl/yunit/vram_sdram_top.sv"
          "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
          "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
          "$ROOT/sim/ddr3_avalon_model.sv" ) ;;
  tb_vram_ddr_shiftreg_scanrace)
    DEFS+=( -DYUNIT_SRT_FILL_BURST )
    SRC=( "$ROOT/rtl/yunit/yunit_scanline.sv"
          "$ROOT/rtl/yunit/vram_sdram.sv"
          "$ROOT/rtl/yunit/vram_sdram_top.sv"
          "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
          "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
          "$ROOT/sim/ddr3_avalon_model.sv" ) ;;
  tb_yunit_display_address_sequencer) SRC+=( "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv" ) ;;
  tb_yunit_sf_display_replay) SRC+=( "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv" ) ;;
  tb_hq2x_blend_pipeline)
    # Cycle-for-cycle equivalence against the pre-cut Blend pipeline, including
    # generic HQ2x's legal back-to-back clk_en cadence.
    SRC=( "$ROOT/sys/hq2x.sv" ) ;;
  tb_yunit_crt_adjust)
    SRC=( "$ROOT/rtl/video/crt_adjust.sv"
          "$ROOT/rtl/video/yunit_crt_adjust.sv" ) ;;
  tb_yunit_download_mapper)
    SRC=( "$ROOT/rtl/yunit/yunit_download_mapper.sv" ) ;;
  tb_yunit_production_rom_contract)
    DEFS+=( -DUSE_EXT_ROM )
    SRC+=( "$ROOT/rtl/yunit/yunit_download_mapper.sv"
           "$ROOT/rtl/yunit/yunit_mem.sv"
           "$ROOT/rtl/sdram/yunit_sdram_arb.sv" ) ;;
  tb_yunit_smash_firefix_rom_layout)
    DEFS+=( -DUSE_EXT_ROM )
    SRC+=( "$ROOT/rtl/yunit/yunit_mem_smash_firefix.sv" ) ;;
  tb_family2_rom_layout)
    DEFS+=( -DUSE_EXT_ROM )
    SRC+=( "$ROOT/rtl/yunit/family2/yunit_mem_family2.sv" ) ;;
  tb_family2_palette_alias)
    DEFS+=( -DUSE_HW_RAM )
    SRC+=( "$ROOT/rtl/yunit/family2/yunit_mem_family2.sv"
           "$ROOT/rtl/yunit/yunit_palram.sv" ) ;;
  tb_family2_penmap)
    SRC+=( "$ROOT/rtl/yunit/family2/yunit_video_family2.sv"
           "$ROOT/rtl/yunit/yunit_video_smash_firefix.sv" ) ;;
  tb_family2_download_mapper)
    # yunit_pkg is REQUIRED here: 3f98b36 added yunit_pkg::yunit_sound_type to
    # both mappers, and without it this entry has been uncompilable -- the gate
    # could not run through this runner at all (found 2026-08-19).
    SRC=( "$ROOT/rtl/pkg/yunit_pkg.sv"
          "$ROOT/rtl/yunit/family2/family2_download_mapper.sv"
          "$ROOT/rtl/yunit/yunit_download_mapper.sv" ) ;;
  tb_adpcm_fixbank_seam)
    # Mapper->board fixbank seam gate (the 2026-08-19 dead-sound class).
    SRC=( "$ROOT/rtl/pkg/yunit_pkg.sv"
          "$ROOT/rtl/yunit/family2/family2_download_mapper.sv" ) ;;
  tb_family2_inputs)
    SRC+=( "$ROOT/rtl/yunit/family2/family2_cabinet_inputs.sv"
           "$ROOT/rtl/yunit/yunit_input_mapper.sv"
           "$ROOT/rtl/yunit/smashtv_cabinet_inputs.sv" ) ;;
  tb_family2_protection)
    SRC+=( "$ROOT/rtl/yunit/family2/yunit_mem_family2.sv" ) ;;
  tb_family2_term2_hack)
    SRC+=( "$ROOT/rtl/yunit/family2/yunit_mem_family2.sv" ) ;;
  tb_family2_dma_queue)
    SRC+=( "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv" ) ;;
  tb_yunit_dma_term2_flip)
    SRC+=( "$ROOT/rtl/yunit/family2/yunit_dma_family2.sv"
           "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
           "$ROOT/rtl/yunit/vram_sdram.sv"
           "$ROOT/rtl/yunit/vram_sdram_top.sv"
           "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
           "$ROOT/sim/ddr3_avalon_model.sv" ) ;;
  tb_t2_paced_replay|tb_sf_fill_bw)
    DEFS+=( -DYUNIT_NO_COMMITGATE )
    SRC+=( "$ROOT/rtl/yunit/yunit_dma.sv"
           "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
           "$ROOT/rtl/yunit/vram_sdram.sv"
           "$ROOT/rtl/yunit/vram_sdram_top.sv"
           "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
           "$ROOT/sim/ddr3_avalon_model.sv" ) ;;
  tb_family2_pageflip_coherent)
    SRC+=( "$ROOT/rtl/yunit/family2/yunit_video_family2.sv"
           "$ROOT/rtl/yunit/family2/yunit_scanline_family2.sv"
           "$ROOT/rtl/yunit/family2/yunit_video_top_family2.sv" ) ;;
  tb_tms34010_display_contract)
    SRC=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
          "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv"
          "$ROOT/rtl/tms34010/rtl/io/tms34010_io_write_boundary.sv"
          "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv"
          "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv" ) ;;
  tb_yunit_dynamic_video_cache)
    SRC+=( "$ROOT/rtl/yunit/yunit_video.sv"
           "$ROOT/rtl/yunit/yunit_scanline.sv" ) ;;
  tb_yunit_native_frame_contract)
    SRC+=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
           "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv"
           "$ROOT/rtl/yunit/yunit_display_address_sequencer.sv"
           "$ROOT/rtl/yunit/yunit_video.sv"
           "$ROOT/rtl/yunit/yunit_scanline.sv"
           "$ROOT/rtl/yunit/yunit_video_top.sv" ) ;;
  tb_yunit_memsys|tb_yunit_memsys_trigburst|tb_yunit_memsys_logical_dma)
    SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv"
           "$ROOT/rtl/yunit/yunit_dma.sv"
           "$ROOT/rtl/yunit/yunit_dma_logical_timer.sv"
           "$ROOT/rtl/yunit/yunit_dma_descriptor_fifo.sv"
           "$ROOT/rtl/yunit/yunit_memsys.sv" ) ;;
  tb_yunit_memsys_snapshot)
    DEFS+=( -DUSE_SDRAM_VRAM )
    SRC+=( "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
           "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" \
           "$ROOT/rtl/yunit/yunit_dma_logical_timer.sv" \
           "$ROOT/rtl/yunit/yunit_dma_descriptor_fifo.sv" \
           "$ROOT/rtl/yunit/yunit_memsys.sv" ) ;;
  tb_vram_bsnoop)
    # B-side scanout snoop/merge coherency gate. Carries the MUT_NO_BSNOOP
    # (old design) and MUT_NO_BMERGE (merge off) contracts -- both cited across
    # the Wolf/NARC/Y-unit sessions as the guards for the BSNOOP merge repair,
    # and both previously unarmed because this bench was in no runner.
    SRC=( "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
          "$ROOT/rtl/yunit/vram_sdram.sv"
          "$ROOT/rtl/yunit/vram_sdram_top.sv"
          "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
          "$ROOT/sim/ddr3_avalon_model.sv" ) ;;
  tb_yunit_page_publish_smear)
    # Page-flip publication seam gate. Production must qualify every retired
    # background/sprite epoch by exact readback before a cold scan fill;
    # MUT_B_SCAN_NO_PROOF restores the bounded-shadow stale-layer behavior.
    SRC=( "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
          "$ROOT/rtl/yunit/vram_sdram.sv"
          "$ROOT/rtl/yunit/vram_sdram_top.sv"
          "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
          "$ROOT/sim/ddr3_avalon_model.sv" ) ;;
  tb_tms34010_io_fs32)
    # FS>16 I/O field write must span two registers (tms34010.cpp:329-333).
    SV2V_FIRST=1
    SRC=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
          "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv"
          "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" ) ;;
  tb_tms34010_intpend_rmw)
    # INTPEND read-only/w0c semantics vs tms34010.cpp:1348-1356. Needs sv2v
    # (io_regs uses SV constructs Icarus rejects).
    SV2V_FIRST=1
    SRC=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
          "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv"
          "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" ) ;;
  tb_tms34010_sub_cflag)
    # SUB/SUBB/CMP carry-flag oracle vs 34010ops.hxx:66. Needs sv2v: the ALU
    # declares `output var alu_flags_t`, which Icarus rejects.
    SV2V_FIRST=1
    SRC=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
          "$ROOT/rtl/tms34010/rtl/core/tms34010_alu.sv" ) ;;
  tb_yunit_dpyint_schedule)
    SRC+=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
           "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv"
           "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" ) ;;
  tb_tms34010_sync_endpoints)
    SRC=( "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv"
          "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" ) ;;
esac
SRC+=( "$ROOT/sim/$TB_FILE.sv" )

mkdir -p "$ROOT/sim/build"
OUT="$ROOT/sim/build/$TB.vvp"

# Some core modules use SV that Icarus cannot parse (e.g. tms34010_alu declares
# `output var alu_flags_t flags`). sv2v down-converts them, and the sv2v output
# is exactly what Quartus synthesises, so this tests the shipping form rather
# than a simulation-only variant. Licence-free, unlike Questa.
# MUTATE=<DEFINE> compiles the named mutation contract in. Used by
# tools/run_mutation_gates.py, which REQUIRES the resulting run to FAIL --
# a mutant that still passes is not coverage, it is a false green line.
MUTDEF=()
if [ -n "${MUTATE:-}" ]; then
  MUTDEF=( "-D${MUTATE}" )
  echo "mutate:    $MUTATE"
fi

if [ "$SV2V_FIRST" = "1" ]; then
  SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
  [ -x "$SV2V" ] || { echo "sv2v not found at $SV2V"; exit 1; }
  echo "sv2v:      $TB"
  # The define must reach sv2v, not iverilog: sv2v resolves the ifdef while
  # down-converting, so a -D handed only to iverilog would be silently ignored
  # and the mutant would compile to production.
  "$SV2V" "${MUTDEF[@]}" "${SRC[@]}" > "$ROOT/sim/build/$TB.sv2v.v" || { echo "sv2v failed"; exit 1; }
  SRC=( "$ROOT/sim/build/$TB.sv2v.v" )
  DEFS=()
  MUTDEF=()
fi

echo "compiling: $TB"
iverilog -g2012 "${DEFS[@]}" "${MUTDEF[@]}" -s "$TB" -o "$OUT" "${SRC[@]}"
echo "running:   $TB"
# run from sim/ so $readmemh("build/...") resolves
cd "$ROOT/sim"
# Real pass/fail propagation. Piping vvp straight into grep would return grep's
# status, so a testbench printing "FAIL:" would still exit 0 -- a fake pass.
# Capture the transcript, show the same filtered view as before, then decide.
LOG="$ROOT/sim/build/$TB.log"
set +e
vvp "$OUT" "${PLUSARGS[@]}" >"$LOG" 2>&1
VVP_STATUS=$?
set -e
grep -iE "PASS|FAIL|RESULT" "$LOG" || true

if [ "$VVP_STATUS" -ne 0 ]; then
  echo "RUNNER: vvp exited $VVP_STATUS ($TB)"
  exit 1
fi
if ! grep -qiE "PASS|FAIL|RESULT" "$LOG"; then
  echo "RUNNER: no PASS/FAIL printed ($TB)"
  exit 1
fi
# Failure detection is anchored and case-sensitive on purpose: PASS lines
# legitimately contain words like "fails closed", which a loose match would
# misread as a failure.
if grep -qE "^FAIL" "$LOG"; then
  echo "RUNNER: testbench reported FAIL ($TB)"
  exit 1
fi
# Covers "RESULT: FAIL" and "TEST_RESULT: FAIL".
if grep -qE "RESULT:.*FAIL" "$LOG"; then
  echo "RUNNER: testbench reported a FAIL result ($TB)"
  exit 1
fi
# "RESULT: <n> error(s)" is emitted only when n > 0, but match digits anyway.
if grep -qE "RESULT:[[:space:]]*[1-9]" "$LOG"; then
  echo "RUNNER: testbench reported errors ($TB)"
  exit 1
fi
# Success signal. The suite uses several shapes -- "PASS: <name>",
# "RESULT: PASS -- ...", "TEST_RESULT: PASS (...)" -- so require the token
# somewhere rather than anchoring it.
if ! grep -qE "PASS" "$LOG"; then
  echo "RUNNER: no PASS line ($TB)"
  exit 1
fi
echo "RUNNER: $TB OK"
