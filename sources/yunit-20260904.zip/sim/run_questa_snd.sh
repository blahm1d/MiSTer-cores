#!/usr/bin/env bash
# Compile + run the Williams CVSD sound-board sim (mixed VHDL/Verilog, Questa).
#   ./run_questa_snd.sh [tb_snd_board] [+ARGS...]
set -e
TB="${1:-tb_snd_board}"; shift || true
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SND="$ROOT/rtl/sound"

for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -n "$VLOG" ] || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

. "$(cd "$(dirname "$0")" && pwd)/questa_lock.sh"
questa_lock_acquire "yunit:run_questa_snd:$TB" || exit 3

cd "$ROOT/sim"
rm -rf work_snd; "$VLIB" work_snd >/dev/null

# jt51 (Verilog): top + everything it pulls in (hdl/*.v, no filter/deprecated).
JT51=()
while IFS= read -r f; do JT51+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
JT6295=()
while IFS= read -r f; do JT6295+=("$f"); done < <(find "$SND/jt6295" -maxdepth 1 -name '*.v' | sort)

"$VLOG" -sv -quiet -svinputport=var -work work_snd \
  "$ROOT/rtl/pkg/yunit_pkg.sv" "${JT51[@]}" "${JT6295[@]}" \
  "$SND/williams_cvsd/mc6809is.v" \
  "$SND/smashtv_snd_rom.sv" \
  "$ROOT/rtl/yunit/yunit_sound_cdc.sv" \
  "$ROOT/rtl/yunit/yunit_sound_rom_cache.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_arb.sv" \
  "$ROOT/rtl/yunit/yunit_audio_mix.sv" \
  "$ROOT/rtl/yunit/yunit_adpcm_board.sv" \
  "$ROOT/sim/$TB.sv"

"$VCOM" -2008 -quiet -work work_snd \
  "$SND/williams_cvsd/gen_ram.vhd" \
  "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" \
  "$SND/williams_cvsd/williams_cvsd_board.vhd"

echo "running $TB ..."
LOG="$ROOT/sim/build/$TB.snd.log"
mkdir -p "$(dirname "$LOG")"
set +e
"$VSIM" -c -quiet -work work_snd -do "run -all; quit -f" "$TB" "$@" >"$LOG" 2>&1
VSIM_STATUS=$?
set -e
grep -vE "^# (Loading|//|\*\* Note)" "$LOG" || true

if grep -qE "lost connection|Exiting VSIM license process|Kernel lost connection|Fatal:" "$LOG"; then
  echo "run_questa_snd: simulator/license died -- INCONCLUSIVE"
  exit 2
fi
if [ "$VSIM_STATUS" -ne 0 ]; then
  echo "run_questa_snd: vsim exited $VSIM_STATUS"
  exit 1
fi
if grep -qE "SND E2E FAIL|RESULT:.*FAIL|^FAIL" "$LOG"; then
  echo "run_questa_snd: testbench reported failure"
  exit 1
fi
if [ "$TB" = "tb_snd_e2e" ] && ! grep -q "SND E2E PASS" "$LOG"; then
  echo "run_questa_snd: no SND E2E PASS verdict"
  exit 1
fi
if [ "$TB" = "tb_adpcm_snd_e2e" ] && ! grep -q "ADPCM E2E PASS" "$LOG"; then
  echo "run_questa_snd: no ADPCM E2E PASS verdict"
  exit 1
fi
echo "run_questa_snd: $TB PASS"
