#!/usr/bin/env bash
# GATE: twin-stick analog->digital (yunit_twinstick) -- rest-bias latch,
# +/-64 delta thresholds, title gating (SMASHTV/TOTCARN only; TERM2's gun
# rides the same axes and must see zero contribution).
# Kill control: -DMUT_TWINSTICK_NO_REBIAS (raw thresholds, the cab-refuted
# behaviour behind "only fires downwards" -- idle right-stick Y +119) must
# FAIL the BIAS case.
set -euo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
IV="${IV:-iverilog}"
command -v "$IV" >/dev/null 2>&1 || { echo "GATE_INCONCLUSIVE: no iverilog on PATH"; exit 77; }

D="$ROOT/sim/build"
mkdir -p "$D"
SRC=("$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_twinstick.sv" "$ROOT/sim/tb_yunit_twinstick.sv")

"$IV" -g2012 -s tb_yunit_twinstick -o "$D/twinstick.vvp"  "${SRC[@]}"
"$IV" -g2012 -DMUT_TWINSTICK_NO_REBIAS -s tb_yunit_twinstick -o "$D/twinstickm.vvp" "${SRC[@]}"

vvp "$D/twinstick.vvp"  | tee "$D/twinstick.log"
vvp "$D/twinstickm.vvp" | tee "$D/twinstick_mutant.log" >/dev/null

grep -q "TEST_RESULT: PASS" "$D/twinstick.log" \
  || { echo "GATE FAIL: twinstick baseline"; exit 1; }
grep -q "TEST_RESULT: FAIL" "$D/twinstick_mutant.log" \
  || { echo "GATE_INCONCLUSIVE: MUT_TWINSTICK_NO_REBIAS survived (BIAS case exercises nothing)"; exit 77; }
echo "TWINSTICK: PASS (baseline green, rebias mutant killed)"
