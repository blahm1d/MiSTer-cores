#!/usr/bin/env python3
"""Build the canonical Y-unit ADPCM external-ROM byte image for simulation.

The family MRA layout is the MAME layout after its unused prefix is removed:
0x000000-0x03ffff CPU U3 (a 128 KiB EPROM mirrored once), followed by the
1 MiB OKI image (U12 mirrored at 0x40000/0x80000 and U13 at 0xc0000/0x100000).
"""

from pathlib import Path
import sys
import zipfile


archive = Path(sys.argv[1] if len(sys.argv) > 1 else
               "D:/deck/fpga/smash tv/roms/totcarn.zip")
output = Path(sys.argv[2] if len(sys.argv) > 2 else
              "sim/build/totcarn_sound.hex")

NAME_SETS = {
    "totcarn": (
        "sl1_total_carnage_sound_rom_u3.u3",
        "sl1_total_carnage_sound_rom_u12.u12",
        "sl1_total_carnage_sound_rom_u13.u13",
    ),
    # midyunit.cpp:3533-3541 (term2 LA4 shares the SL1 sound set)
    "term2": (
        "sl1_terminator_2_u3_sound_rom.u3",
        "sl1_terminator_2_u12_sound_rom.u12",
        "sl1_terminator_2_u13_sound_rom.u13",
    ),
    # midyunit.cpp:2918-2926 (mkla4; the zip carries SL1 labels, same data as
    # the L1-labeled set MAME lists -- "labeled L1 vs SL1")
    "mk": (
        "sl1_mortal_kombat_u3_sound_rom.u3",
        "sl1_mortal_kombat_u12_sound_rom.u12",
        "sl1_mortal_kombat_u13_sound_rom.u13",
    ),
}
title = archive.stem.lower()
if title not in NAME_SETS:
    raise SystemExit(f"no ADPCM sound name set for {title}")
names = NAME_SETS[title]
with zipfile.ZipFile(archive) as rom_zip:
    u3, u12, u13 = (rom_zip.read(name) for name in names)

# U3 prefix is 0x40000 either way: a 128 KiB EPROM is mirrored once (TC/T2,
# ROM_RELOAD in midyunit.cpp), a 256 KiB EPROM (MK) loads straight.
if len(u3) == 0x20000:
    u3 = u3 + u3
elif len(u3) != 0x40000:
    raise SystemExit(f"{names[0]}: expected 0x20000 or 0x40000 bytes, got {len(u3):#x}")
if len(u12) != 0x40000 or len(u13) != 0x40000:
    raise SystemExit("U12/U13 must each be 0x40000 bytes")

image = u3 + u12 + u12 + u13 + u13
if len(image) != 0x140000:
    raise SystemExit(f"expanded image is {len(image):#x}, expected 0x140000")

output.parent.mkdir(parents=True, exist_ok=True)
output.write_text("\n".join(f"{byte:02x}" for byte in image), encoding="ascii")
print(f"{archive} -> {output} ({len(image):#x} bytes, exact ADPCM MRA layout)")
