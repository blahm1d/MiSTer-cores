#!/usr/bin/env bash
# Release-flavor Smash TV scene replay through yunit_dma + the cabinet-proven
# DDR3 framebuffer. These are MAME-captured multi-blit frames, not synthetic
# single-command tests.
set -euo pipefail

export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TRACE_ROOT="${MAME_TRACE_ROOT:-$ROOT/../mame-trace}"
SCENES="$TRACE_ROOT/scene_checkpoints/mame"
OUT="$ROOT/sim/build/scene_replay_release"
VVP="$OUT/tb_yunit_scene_replay.vvp"

[[ -f "$ROOT/sim/build/smashtv_gfx.hex" ]] \
  || { echo "scene replay: missing sim/build/smashtv_gfx.hex"; exit 1; }
[[ -f "$SCENES/manifest.tsv" ]] \
  || { echo "scene replay: missing MAME scene manifest at $SCENES"; exit 1; }
mkdir -p "$OUT"

iverilog -g2012 -DYUNIT_NO_COMMITGATE -o "$VVP" \
  "$ROOT/rtl/pkg/yunit_pkg.sv" \
  "$ROOT/rtl/yunit/yunit_dma.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_yunit_scene_replay.sv"

cd "$ROOT/sim"
while read -r name writes; do
  scene="$SCENES/$name"
  scene_out="$OUT/$name"
  log="$scene_out/replay.log"
  mkdir -p "$scene_out"
  vvp "$VVP" \
    "+SCENE=$name" \
    "+VEC=$scene/dma.vec" \
    "+NV=$writes" \
    "+PRE_VRAM=$scene/pre_vram.hex" \
    "+POST_VRAM=$scene/dma_expected_vram.hex" \
    "+OUT_DIR=$scene_out" | tee "$log"
  grep -Fq "RESULT: DMA-WRITES-MATCH" "$log"
  if grep -Fq "RESULT: FAIL" "$log"; then
    echo "scene replay: $name reported a failure"
    exit 1
  fi
done <<'SCENE_LIST'
high_score_table 942
splash_logo_descending 222
splash_logo_displaced_right 242
attract_player_no_background 892
attract_background_restored 1032
SCENE_LIST

echo "PASS: five firefix_mixboot DDR3 scene replays match MAME"
