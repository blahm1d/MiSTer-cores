#!/usr/bin/env bash
# Fail-closed source/netlist gate for the banked own-write-shadow valid lookup.
# HDL execution is shared-host work; run only in an explicitly released,
# simulator-exclusive source-qualification window (never inside Quartus FIFO).
set -Eeuo pipefail
export PATH="/usr/bin:/mingw64/bin:/c/iverilog/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TIMEOUT="${SHWVALID_RETIME_TIMEOUT:-45}"
NETLIST="${VRAM_SHWVALID_NETLIST:-}"

if [ -n "${SHWVALID_RETIME_OUT:-}" ]; then
  OUT="$SHWVALID_RETIME_OUT"
  mkdir -p "$OUT"
else
  mkdir -p "$ROOT/sim/build"
  OUT="$(mktemp -d "$ROOT/sim/build/shwvalid_retime.XXXXXX")"
fi
echo "SHWVALID_RETIME_RUN_DIR=$OUT"

fail() {
  echo "SHWVALID-RETIME-GATE: FAIL -- $*" >&2
  exit 1
}
inconclusive() {
  echo "SHWVALID-RETIME-GATE: INCONCLUSIVE -- $*" >&2
  exit 77
}

command -v iverilog >/dev/null 2>&1 || inconclusive "iverilog not found"
command -v vvp >/dev/null 2>&1 || inconclusive "vvp not found"
command -v timeout >/dev/null 2>&1 || inconclusive "timeout not found"

if [ -n "$NETLIST" ]; then
  [ -s "$NETLIST" ] || inconclusive "missing generated netlist $NETLIST"
  SRC=(
    "$NETLIST"
    "$ROOT/sim/ddr3_avalon_model.sv"
    "$ROOT/sim/tb_yunit_shw_valid_retime.sv"
  )
  echo "SHWVALID_RETIME_DESIGN=netlist:$NETLIST"
else
  SRC=(
    "$ROOT/rtl/yunit/vram_sdram.sv"
    "$ROOT/rtl/yunit/vram_sdram_top.sv"
    "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
    "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
    "$ROOT/sim/ddr3_avalon_model.sv"
    "$ROOT/sim/tb_yunit_shw_valid_retime.sv"
  )
  echo "SHWVALID_RETIME_DESIGN=source-full-top:YUNIT_SRT_FILL_BURST"
fi

compile_leg() {
  local name="$1" define="$2"
  local image="$OUT/$name.vvp"
  local log="$OUT/$name.compile.log"
  local args=(-g2012 -s tb_yunit_shw_valid_retime -o "$image")
  if [ -z "$NETLIST" ]; then
    args+=(-DYUNIT_SRT_FILL_BURST)
  fi
  [ -z "$define" ] || args+=("-D$define")
  if ! iverilog "${args[@]}" "${SRC[@]}" >"$log" 2>&1; then
    tail -80 "$log" >&2 || true
    inconclusive "$name compile failed"
  fi
  [ -s "$image" ] || inconclusive "$name compile emitted no image"
}

run_image() {
  local name="$1"
  local log="$OUT/$name.log"
  echo "== shwvalid leg $name =="
  if timeout "$TIMEOUT" vvp "$OUT/$name.vvp" >"$log" 2>&1; then
    :
  else
    local rc=$?
    tail -80 "$log" >&2 || true
    inconclusive "$name simulator exit $rc"
  fi
  grep -E '^SHWVALID_(COVERAGE|RESULT):|^SHWVALID_FAIL' "$log" || true
  ! grep -Fq 'SHWVALID_RESULT: FAIL timeout' "$log" \
    || inconclusive "$name timed out inside the bench"
}

require_clean_terminal() {
  local log="$1"
  if ! awk '
    BEGIN {
      pass = "SHWVALID_RESULT: PASS clean"
      trailer = "(^|.*[/\\\\])tb_yunit_shw_valid_retime\\.sv:[0-9]+: \\$finish called at [0-9]+ \\([0-9]+(fs|ps|ns|us|ms|s)\\)$"
    }
    NF {
      sub(/\r$/, "", $0)
      previous = last
      last = $0
      if ($0 ~ trailer) trailers++
    }
    END {
      if (last == pass && trailers == 0) exit 0
      if (previous == pass && last ~ trailer && trailers == 1) exit 0
      exit 1
    }
  ' "$log"; then
    fail "clean PASS is not terminal"
  fi
}

require_mutant_terminal() {
  local log="$1" label="$2"
  ! grep -Eq '^SHWVALID_RESULT: PASS( |$)|^SHWVALID_RESULT: FAIL timeout$' "$log" \
    || fail "$label contains a PASS/timeout verdict"
  if ! awk '
    BEGIN {
      verdict = "^SHWVALID_RESULT: FAIL errors=[1-9][0-9]*$"
      trailer = "(^|.*[/\\\\])tb_yunit_shw_valid_retime\\.sv:[0-9]+: \\$finish called at [0-9]+ \\([0-9]+(fs|ps|ns|us|ms|s)\\)$"
    }
    NF {
      sub(/\r$/, "", $0)
      previous = last
      last = $0
      if ($0 ~ trailer) trailers++
    }
    END {
      if (last ~ verdict && trailers == 0) exit 0
      if (previous ~ verdict && last ~ trailer && trailers == 1) exit 0
      exit 1
    }
  ' "$log"; then
    fail "$label FAIL verdict is not terminal"
  fi
}

compile_leg clean ""
run_image clean
[ "$(grep -Fxc 'SHWVALID_RESULT: PASS clean' "$OUT/clean.log" || true)" -eq 1 ] \
  || fail "clean leg lacks one exact PASS"
! grep -Fq 'SHWVALID_FAIL' "$OUT/clean.log" \
  || fail "clean leg contains a scoreboard failure"
! grep -Eq '^SHWVALID_RESULT: FAIL( |$)' "$OUT/clean.log" \
  || fail "clean leg contains a FAIL verdict"
require_clean_terminal "$OUT/clean.log"

if [ -z "$NETLIST" ]; then
  compile_leg live_select MUT_SHW_VALID_LIVE_BANK_SELECT
  run_image live_select
  [ "$(grep -Ec '^SHWVALID_FAIL phase_mismatch( |$)' "$OUT/live_select.log" || true)" -gt 0 ] \
    || fail "live-select mutant did not fail on lookup phase"
  [ "$(grep -Ec '^SHWVALID_RESULT: FAIL errors=[1-9][0-9]*$' "$OUT/live_select.log" || true)" -eq 1 ] \
    || fail "live-select mutant lacks one fail verdict"
  require_mutant_terminal "$OUT/live_select.log" "live-select mutant"

  compile_leg bank15_alias14 MUT_SHW_VALID_BANK15_ALIAS14
  run_image bank15_alias14
  [ "$(grep -Ec '^SHWVALID_FAIL phase_mismatch( |$)' "$OUT/bank15_alias14.log" || true)" -gt 0 ] \
    || fail "bank-15 alias mutant did not fail on independently indexed validity"
  [ "$(grep -Ec '^SHWVALID_RESULT: FAIL errors=[1-9][0-9]*$' "$OUT/bank15_alias14.log" || true)" -eq 1 ] \
    || fail "bank-15 alias mutant lacks one fail verdict"
  require_mutant_terminal "$OUT/bank15_alias14.log" "bank-15 alias mutant"

  compile_leg core_rst_clear MUT_SHW_VALID_CORE_RST_CLEAR
  run_image core_rst_clear
  [ "$(grep -Fxc 'SHWVALID_FAIL core reset cleared POR-persistent shadow validity' \
       "$OUT/core_rst_clear.log" || true)" -eq 1 ] \
    || fail "core-reset mutant did not fail persistence check"
  [ "$(grep -Ec '^SHWVALID_RESULT: FAIL errors=[1-9][0-9]*$' "$OUT/core_rst_clear.log" || true)" -eq 1 ] \
    || fail "core-reset mutant lacks one fail verdict"
  require_mutant_terminal "$OUT/core_rst_clear.log" "core-reset mutant"
fi

echo "SHWVALID-RETIME-GATE: PASS"
