#!/usr/bin/env bash
# POST-CONVERSION gate: verify the input mappers on the Verilog that Quartus
# actually reads, not the SystemVerilog the benches read.
#
# Why this exists: sv2v lowers a SystemVerilog `inout` task argument
# (copy-in/copy-out) to a plain Verilog `output` (copy-out only).  Every
# .sv-side bench passed while the shipped core had its direction nibbles and,
# for the 4-player profiles, its entire coin/start/service/tilt field stuck at
# whatever the fitter resolved X to.  A gate on the wrong side of a source
# transform is not a gate.
#
# This script is self-proving: it runs the same bench against a frozen copy of
# the broken converted module and REQUIRES that to fail.  If the mutant ever
# passes, the gate has gone blind and this exits non-zero.
set -euo pipefail

cd "$(dirname "$0")/../.."
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
EXPECTED_SV2V_VERSION="sv2v v0.0.13"
HERE=sim/postconv
WORK="${TMPDIR:-/tmp}/yunit_postconv.$$"
mkdir -p "$WORK"
trap 'rm -rf "$WORK"' EXIT

die() { echo "POSTCONV GATE FAIL: $*" >&2; exit 1; }

[[ -x "$SV2V" ]] || die "sv2v not found at $SV2V"
got_ver="$("$SV2V" --version 2>&1 | head -1)"
[[ "$got_ver" == "$EXPECTED_SV2V_VERSION" ]] \
  || die "sv2v version drift: got '$got_ver', pinned '$EXPECTED_SV2V_VERSION'"

PKG=rtl/pkg/yunit_pkg.sv
MAPPERS=(rtl/yunit/family2/family2_cabinet_inputs.sv rtl/yunit/yunit_input_mapper.sv)

# 1. Source-side structural check: no `inout` task/function arguments anywhere
#    in the synthesized RTL.  This is the defect class, banned at the root.
python "$HERE/check_no_inout_args.py" rtl \
  || die 'an `inout` subroutine argument reappeared in rtl/ -- sv2v drops its copy-in'

# 1b. CVSD sound-ROM residence. Production streams samples from SDRAM, freeing
#     the 192 M10Ks the three 64 KiB BRAMs measured; the named revert
#     +define+YUNIT_CVSD_BRAM_SOUND must stay reachable because Smash T.V.'s
#     sound is cabinet-proven on the BRAM path. Both states are pinned here;
#     the post-FIT proof is in quartus/ram_release_gate.py.
python "$HERE/check_cvsd_sound_residence.py" \
  || die "CVSD sound-ROM residence pin failed"

# 2. Convert and prove no task survived into the Verilog at all.
"$SV2V" "$PKG" "${MAPPERS[@]}" > "$WORK/conv.v" || die "sv2v conversion failed"
ntask="$(grep -c 'task automatic' "$WORK/conv.v" || true)"
[[ "$ntask" == "0" ]] || die "$ntask task(s) survived into the converted Verilog"

# 3. Behavioural check on the converted module.
awk '/^module family2_cabinet_inputs/,/^endmodule/' "$WORK/conv.v" > "$WORK/dut.v"
[[ -s "$WORK/dut.v" ]] || die "family2_cabinet_inputs missing from converted output"
iverilog -g2005 -o "$WORK/good.vvp" "$HERE/tb_postconv_inputs.v" "$WORK/dut.v" \
  || die "iverilog build (fixed) failed"
good_out="$(vvp "$WORK/good.vvp")"
echo "$good_out" | grep -q '== tb_postconv_inputs PASS' \
  || { echo "$good_out" >&2; die "converted mapper does not satisfy the input contract"; }

# 4. SELF-PROOF: the frozen broken conversion must still be caught.
MUT="$HERE/MUTANT_family2_cabinet_inputs.v"
[[ -f "$MUT" ]] || die "mutant fixture $MUT is missing -- the gate cannot prove itself"
grep -q 'output reg \[15:0\] dst' "$MUT" \
  || die "mutant fixture no longer contains the downgraded task argument"
iverilog -g2005 -o "$WORK/mut.vvp" "$HERE/tb_postconv_inputs.v" "$MUT" \
  || die "iverilog build (mutant) failed"
mut_out="$(vvp "$WORK/mut.vvp")"
echo "$mut_out" | grep -q '== tb_postconv_inputs FAIL' \
  || die "MUTANT PASSED -- the gate is blind and proves nothing"

echo "POSTCONV GATE PASS: converted mapper clean, 0 tasks, mutant killed"
