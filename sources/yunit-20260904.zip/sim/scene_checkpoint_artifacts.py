#!/usr/bin/env python3
"""Finalize MAME/RTL scene replay artifacts and produce visible diffs.

The RTL replay's storage oracle is ``dma_expected_vram.hex`` (MAME DMA only).
``post_vram.hex`` also contains MAME's concurrently scheduled scanline
autoerase and is retained as an independent full-system witness.
"""
from __future__ import annotations

import argparse
import binascii
import csv
import hashlib
import struct
import zlib
from pathlib import Path


def read_hex(path: Path) -> list[int]:
    values: list[int] = []
    with path.open("r", encoding="ascii") as f:
        for line in f:
            token = line.split("//", 1)[0].strip()
            if token and not token.startswith("@"):
                values.extend(int(x, 16) for x in token.split())
    return values


def pen6(word: int) -> int:
    return (((word >> 8) & 0xF) << 8) | (((word >> 14) & 0x3) << 6) | (word & 0x3F)


def rgb555(value: int) -> tuple[int, int, int]:
    def ex(v: int) -> int:
        return (v << 3) | (v >> 2)

    return ex((value >> 10) & 0x1F), ex((value >> 5) & 0x1F), ex(value & 0x1F)


def render_scanout(words: list[int], palette_words: list[int]) -> tuple[int, int, bytes]:
    if len(words) != 410 * 256:
        raise ValueError(f"expected 104960 scanout words, got {len(words)}")
    folded = [0] * 4096
    for off, value in enumerate(palette_words):
        if value:
            folded[off & 0xFFF] = value
    data = bytearray()
    for word in words:
        data.extend(rgb555(folded[pen6(word) & 0xFFF]))
    return 410, 256, bytes(data)


def read_png_rgb(path: Path) -> tuple[int, int, bytes]:
    """Read the non-interlaced 8-bit RGB/RGBA PNGs emitted by MAME."""
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"{path}: not a PNG")
    pos = 8
    width = height = color_type = bit_depth = interlace = 0
    packed = bytearray()
    while pos < len(data):
        n = struct.unpack(">I", data[pos : pos + 4])[0]
        kind = data[pos + 4 : pos + 8]
        payload = data[pos + 8 : pos + 8 + n]
        pos += 12 + n
        if kind == b"IHDR":
            width, height, bit_depth, color_type, _, _, interlace = struct.unpack(
                ">IIBBBBB", payload
            )
        elif kind == b"IDAT":
            packed.extend(payload)
        elif kind == b"IEND":
            break
    if bit_depth != 8 or color_type not in (2, 6) or interlace:
        raise ValueError(
            f"{path}: unsupported PNG depth/type/interlace {bit_depth}/{color_type}/{interlace}"
        )
    bpp = 3 if color_type == 2 else 4
    stride = width * bpp
    raw = zlib.decompress(bytes(packed))
    prev = bytearray(stride)
    out = bytearray()
    off = 0
    for _ in range(height):
        filt = raw[off]
        cur = bytearray(raw[off + 1 : off + 1 + stride])
        off += 1 + stride
        for x in range(stride):
            a = cur[x - bpp] if x >= bpp else 0
            b = prev[x]
            c = prev[x - bpp] if x >= bpp else 0
            if filt == 1:
                cur[x] = (cur[x] + a) & 0xFF
            elif filt == 2:
                cur[x] = (cur[x] + b) & 0xFF
            elif filt == 3:
                cur[x] = (cur[x] + ((a + b) >> 1)) & 0xFF
            elif filt == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
                cur[x] = (cur[x] + pr) & 0xFF
            elif filt != 0:
                raise ValueError(f"{path}: unsupported PNG filter {filt}")
        if bpp == 3:
            out.extend(cur)
        else:
            for x in range(0, stride, 4):
                out.extend(cur[x : x + 3])
        prev = cur
    return width, height, bytes(out)


def write_png_rgb(path: Path, width: int, height: int, pixels: bytes) -> None:
    def chunk(kind: bytes, payload: bytes) -> bytes:
        return (
            struct.pack(">I", len(payload))
            + kind
            + payload
            + struct.pack(">I", binascii.crc32(kind + payload) & 0xFFFFFFFF)
        )

    scan = b"".join(
        b"\x00" + pixels[y * width * 3 : (y + 1) * width * 3] for y in range(height)
    )
    path.write_bytes(
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(scan, 9))
        + chunk(b"IEND", b"")
    )


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest().upper()


def first_rgb_difference(a: bytes, b: bytes, width: int, height: int) -> tuple[int, int] | None:
    for y in range(height):
        for x in range(width):
            off = (y * width + x) * 3
            if a[off : off + 3] != b[off : off + 3]:
                return x, y
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint_root", type=Path)
    args = parser.parse_args()
    root = args.checkpoint_root.resolve()
    mame = root / "mame"
    rtl = root / "rtl"

    rows = list(csv.DictReader((mame / "manifest.tsv").open(newline=""), delimiter="\t"))
    artifact_rows: list[dict[str, str]] = []

    for row in rows:
        name = row["name"]
        mdir = mame / name
        rdir = rtl / f"{name}_dmaoracle"

        mw, mh, mame_pixels = read_png_rgb(mame / row["rgb"])
        mame_rgb_path = mdir / "mame_rgb.png"
        mame_rgb_path.write_bytes((mame / row["rgb"]).read_bytes())
        (mdir / "mame_scanout.rgb").write_bytes(mame_pixels)
        with (mdir / "mame_scanout.hex").open("w", encoding="ascii") as f:
            for i in range(0, len(mame_pixels), 3):
                f.write(f"{mame_pixels[i]:02X}{mame_pixels[i+1]:02X}{mame_pixels[i+2]:02X}\n")

        status = "RTL_PENDING"
        vram_diff = ""
        rgb_diff = ""
        first = ""
        if rdir.exists() and (rdir / "rtl_post_vram.hex").exists():
            expected = read_hex(mdir / "dma_expected_vram.hex")
            actual = read_hex(rdir / "rtl_post_vram.hex")
            if len(expected) != len(actual):
                raise ValueError(f"{name}: VRAM length mismatch {len(expected)} != {len(actual)}")
            vram_diff_n = sum(a != b for a, b in zip(expected, actual))
            vram_diff = str(vram_diff_n)

            scanout = read_hex(rdir / "rtl_scanout.hex")
            palette = read_hex(mdir / "post_palette.hex")
            rw, rh, rtl_pixels = render_scanout(scanout, palette)
            rtl_rgb_path = rdir / "rtl_rgb.png"
            write_png_rgb(rtl_rgb_path, rw, rh, rtl_pixels)

            if (rw, rh) != (mw, mh):
                raise ValueError(f"{name}: RGB size mismatch {(rw, rh)} != {(mw, mh)}")
            diff_pixels_raw = bytes(abs(a - b) for a, b in zip(mame_pixels, rtl_pixels))
            diff_path = rdir / "rgb_diff.png"
            write_png_rgb(diff_path, rw, rh, diff_pixels_raw)
            diff_pixels = sum(
                mame_pixels[i : i + 3] != rtl_pixels[i : i + 3]
                for i in range(0, len(mame_pixels), 3)
            )
            rgb_diff = str(diff_pixels)
            first_xy = first_rgb_difference(mame_pixels, rtl_pixels, rw, rh)
            first = "" if first_xy is None else f"{first_xy[0]},{first_xy[1]}"
            status = "DMA_EXACT" if vram_diff_n == 0 else "DMA_DIVERGED"
            with (rdir / "diff_summary.tsv").open("w", encoding="ascii", newline="") as f:
                w = csv.writer(f, delimiter="\t", lineterminator="\n")
                w.writerow(["scene", "dma_vram_diff", "display_rgb_diff", "first_rgb_diff", "status"])
                w.writerow([name, vram_diff, rgb_diff, first, status])
        else:
            (mdir / "diff_pending.txt").write_text(
                "No RTL scene replay artifact exists yet.\n", encoding="ascii"
            )

        artifact_rows.append(
            {
                "name": name,
                "snapshot_frame": row["snapshot_frame"],
                "dma_frame": row["dma_frame"],
                "bidx_first": row["bidx_first"],
                "bidx_last": row["bidx_last"],
                "mame_rgb_sha256": sha256(mame_rgb_path),
                "mame_pre_vram_sha256": sha256(mdir / "pre_vram.hex"),
                "mame_dma_expected_sha256": sha256(mdir / "dma_expected_vram.hex"),
                "rtl_dma_vram_diff": vram_diff,
                "rtl_display_rgb_diff": rgb_diff,
                "first_rgb_diff": first,
                "status": status,
            }
        )

    fields = list(artifact_rows[0])
    with (root / "artifact_manifest.tsv").open("w", encoding="ascii", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(artifact_rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
