// SPDX-License-Identifier: GPL-3.0-or-later
// T2 integration of the Alien3/MiSTer generic positional-gun contract.
// The cabinet mapper and its four-action Start/Coin ABI remain unchanged.
module yunit_term2_gun_controls (
    input wire clk, reset, enable, vs,
    input wire [1:0] p1_source, p2_source, sensitivity,
    input wire [15:0] left0, left1, right0,
    input wire [15:0] joy0, joy1,
    input wire [24:0] ps2_mouse,
    output wire [31:0] term2_analog,
    output wire [15:0] joy0_out, joy1_out,
    output wire [8:0] gun1_x, gun1_y, gun2_x, gun2_y
);
    // Both source-zero defaults select that player's own LEFT analog stick.
    // P2 source 3 explicitly selects P1's right stick for one-pad calibration.
    wire [15:0] p2_axes = p2_source == 2'd3 ? right0 : left1;
    reg mouse_toggle_d;
    wire mouse_event = ps2_mouse[24] ^ mouse_toggle_d;
    always @(posedge clk) mouse_toggle_d <= ps2_mouse[24];
    // HPS PS/2 sign bits, including deltas outside signed-byte range.
    // Match Alien3/JTFRAME's arithmetic half-scale mouse packet conversion.
    wire signed [8:0] mouse_dx9 = $signed({ps2_mouse[4], ps2_mouse[15:8]}) >>> 1;
    wire signed [8:0] mouse_dy9 = $signed({ps2_mouse[5], ps2_mouse[23:16]}) >>> 1;
    wire [7:0] adc1_x, adc1_y, adc2_x, adc2_y;
    // Only one relative mouse exists in hps_io. If selected for both players,
    // P1 owns it. Two USB/Sinden guns use independent left analog channels.
    wire mouse_p1 = enable && p1_source == 2'd1;
    wire mouse_p2 = enable && p2_source == 2'd1 && !mouse_p1;
    yunit_lightgun_position #(.DEFAULT_WIDTH(410), .DEFAULT_HEIGHT(256)) p1 (
        .clk(clk), .rst(reset || !enable), .vs(vs),
        .screen_width(9'd410), .screen_height(9'd256), .rotate(2'b00),
        .source(p1_source), .sensitivity(sensitivity), .joyana(left0),
        .joy_dir({joy0[2],joy0[3],joy0[1],joy0[0]}),
        .mouse_dx(mouse_dx9[7:0]), .mouse_dy(mouse_dy9[7:0]),
        .mouse_strobe(mouse_event && mouse_p1),
        .gun_x(gun1_x), .gun_y(gun1_y), .adc_x(adc1_x), .adc_y(adc1_y), .gun_strobe()
    );
    yunit_lightgun_position #(.DEFAULT_WIDTH(410), .DEFAULT_HEIGHT(256)) p2 (
        .clk(clk), .rst(reset || !enable), .vs(vs),
        .screen_width(9'd410), .screen_height(9'd256), .rotate(2'b00),
        .source(p2_source), .sensitivity(sensitivity), .joyana(p2_axes),
        .joy_dir({joy1[2],joy1[3],joy1[1],joy1[0]}),
        .mouse_dx(mouse_dx9[7:0]), .mouse_dy(mouse_dy9[7:0]),
        .mouse_strobe(mouse_event && mouse_p2),
        .gun_x(gun2_x), .gun_y(gun2_y), .adc_x(adc2_x), .adc_y(adc2_y), .gun_strobe()
    );
    // Original T2 uses 128 - signed X and 128 + signed Y. Widen X before
    // reversing: the exact -128 endpoint must saturate at FF, not wrap to 00.
    wire [8:0] reversed1_x = 9'd256 - {1'b0, adc1_x};
    wire [8:0] reversed2_x = 9'd256 - {1'b0, adc2_x};
    wire [7:0] t2x1 = reversed1_x[8] ? 8'hff : reversed1_x[7:0];
    wire [7:0] t2x2 = reversed2_x[8] ? 8'hff : reversed2_x[7:0];
    assign term2_analog = {adc2_y, t2x2, adc1_y, t2x1};
    // USB absolute guns send Trigger/Bomb through their ordinary MRA actions.
    // Optional relative mouse uses left=Trigger/right=Bomb, never Start/Coin.
    assign joy0_out = joy0 | {10'd0, (mouse_p1 && ps2_mouse[1]), (mouse_p1 && ps2_mouse[0]), 4'd0};
    assign joy1_out = joy1 | {10'd0, (mouse_p2 && ps2_mouse[1]), (mouse_p2 && ps2_mouse[0]), 4'd0};
endmodule
