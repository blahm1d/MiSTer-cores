// yunit_top_family2.sv — Phase 6 W2: the synthesizable Y-unit core (everything below the
// Template_MiSTer chassis). Composes the proven pieces into one top the emu wraps:
//
//   tms34010_core  <-> yunit_memsys_family2 (CPU + DMA blitter + memory map; SYNTHESIS
//                      selects the external gfx/ROM/VRAM SDRAM ports)
//   yunit_sdram_arb + sdram_phy  : all SDRAM traffic (gfx ROM, prog ROM, VRAM,
//                      + ioctl ROM download) onto one MT48LC16M16 word port
//   yunit_video_top_family2 : VRAM(SDRAM) -> line buffer -> pen_map6 -> palette -> RGB
//   yunit_palram    : palette mirror (video read port, fed by CPU palette writes)
//   williams_cvsd_board : Y-unit sound (6809 + YM2151 + CVSD), on its own ~12 MHz
//                      clock; the sound latch is crossed clk -> clk_snd (CDC).
//
// Clocking: `clk` runs the CPU / memory / SDRAM / video logic; `ce_pix` gates the
// raster; `clk_snd` (~12 MHz) runs the sound board. Game/CPU speed calibration
// (the real 34010 runs far slower than the SDRAM clock) is a later tuning knob.
`default_nettype none
// YUNIT_ADPCM implies YUNIT_FULL, declared HERE as well as in the emu.
// The ADPCM board and the audio mux live under `ifdef YUNIT_FULL while the CVSD board is
// removed under `ifndef YUNIT_ADPCM, so a build given YUNIT_ADPCM WITHOUT YUNIT_FULL compiles
// out BOTH sound boards and produces a silent core that still passes map, fit and every gate.
// That happened: the fitted netlist had no sound entity at all, general[2] matched no clock,
// and audio_l/audio_r were hard zero. Deriving it inside the core makes the sv2v token list
// unable to cause it.
`ifdef YUNIT_ADPCM
 `ifndef YUNIT_FULL
  `define YUNIT_FULL
 `endif
`endif
// YUNIT_DISPLAY_SEQ decouples the FULL DISPLAY PATH (the yunit_display_address_
// sequencer + yunit_video_top, which track DPYSTRT/DPYTAP to produce the exact
// per-line row+COLUMN scanout address) from the ADPCM sound board. The plain
// non-FULL family2 scanout reads every row at column 0 (yunit_scanline_family2),
// which is right for base-0/column-0 titles (Smash TV -- cab-good) but wrong for
// Strike Force / Saurian Front, whose DPYSTRT carries a non-zero display column
// (E00C) -- the running game is then shown horizontally mis-addressed (cab: draws,
// washes to blue, HUD frozen, no gameplay; the CPU is NOT hung). A CVSD core built
// with -DYUNIT_DISPLAY_SEQ (no YUNIT_FULL) gets the correct sequencer scanout WITHOUT
// the ADPCM board's ~30 M10K dead weight, so it fits the 512-M10K release budget
// while YUNIT_FULL (which also carries the board) does not (full-sf1: 537/553).
`ifdef YUNIT_FULL
 `ifndef YUNIT_DISPLAY_SEQ
  `define YUNIT_DISPLAY_SEQ
 `endif
`endif
module yunit_top_family2
  import yunit_pkg::*;
  import tms34010_pkg::*;
#(
  parameter ROM_HEX = "smashtv_maindata.hex",
  // MAME/TMS stdres geometry. Totals remain 506x289; sync widths are the
  // programmed duration-minus-one contract ((HESYNC+1)*2, VESYNC+1).
  parameter int H_ACT=410, H_FP=6,  H_SYNC=42, H_BP=48,
  parameter int V_ACT=256, V_FP=13, V_SYNC=3,  V_BP=17,
  parameter int DISP_ROW0=0,
  // SDRAM word-address map (see rtl/sdram/yunit_sdram_arb.sv, tb_sdram_full)
  parameter [24:0] GFXW_BASE = 25'h000000,
  parameter [24:0] ROMW_BASE = 25'h0C0000,
  parameter [24:0] VRAMW_BASE= 25'h0E0000,
  parameter [23:0] GFX_BYTES = 24'h180000,
  parameter [24:0] SCRATCH_WBASE = 25'h120000,   // raw gfx planes (boot scratch)
  // Present only to match the current multi-MRA wrapper.  The cabinet-good
  // Smash path downloads CVSD bytes directly into the sound-board BRAMs.
  parameter [24:0] SOUNDW_BASE   = 25'h120000,
  parameter [23:0] PLANE_WORDS   = 24'h30000,    // words/plane (E2E sim overrides small)
  parameter int    ROM_WORDS       = 32'h20000,  // program window words (family2: 0x80000)
  parameter int    ROM_WORD_OFFSET = 32'h60000   // image offset in window (family2: 0)
)(
  input  logic        clk,        // core clock (memory + SDRAM + video logic), ~96 MHz
  input  logic        clk_cpu,    // UNUSED since P0019: the CPU now runs on `clk` gated by the
                                   // selected cpu_ce divisor instead of this async /4 tap.
                                   // Port kept so the emu wiring is unchanged (easy revert).
  input  logic        ce_pix,     // pixel-clock enable (video raster)
  input  logic  [2:0] cpu_div_sel,// OSD CPU-speed: 0=/4(default headroom), 1=/6, 2=/8, 3=/10, 4=/12, 5=/14, 6=/16, 7=/20(stock)
  input  logic        clk_snd,    // ~12 MHz sound-board clock
  input  logic        rst,        // core reset (active high)
  input  logic        rst_pon,    // power-on reset (sound board full init)
  input  logic        sdram_por,  // P0022: TRUE power-on (synchronized ~locked) for the PERSISTENT
                                  // SDRAM/download subsystem. Unlike `rst`/`rst_pon` it is LOW during
                                  // any ROM download (which always follows PLL lock), so the capture
                                  // path (FIFO+arb+adapter+phy) keeps running even if the framework
                                  // holds RESET high across the download -> the black-screen root cause.

  input  logic [63:0] inputs,     // {DSW, IN2, IN1, IN0}, active-low
  // Current runtime-profile wrapper compatibility.  This dedicated module is
  // selected only for Smash, whose already-mapped `inputs` bus is authoritative.
  input  logic [3:0]  game_id,
  input  logic [31:0] term2_analog,

  // MiSTer index-4 CMOS persistence side port (flat 32 KiB byte image).
  input  logic        cmos_quiesce,
  input  logic        nvram_ext_en,
  input  logic        nvram_ext_wr,
  input  logic [14:0] nvram_ext_addr,
  input  logic [7:0]  nvram_ext_wdata,
  output logic [7:0]  nvram_ext_rdata,
  output logic        cmos_cpu_busy,
  output logic        cmos_cpu_write_pulse,

  // ioctl ROM download -> SDRAM word writes (gfx@GFXW_BASE, prog ROM@ROMW_BASE).
  // The MRA/loader presents a linear WORD address matching the SDRAM layout.
  input  logic        ioctl_download,  // held high during ROM load (holds the CPU in reset)
  input  logic        gfx_download,
  input  logic        sound_download,
  input  logic        ioctl_wr,
  input  logic [24:0] ioctl_addr,   // SDRAM word address (gfx planes -> scratch, prog ROM)
  input  logic [15:0] ioctl_dout,
  input  logic [1:0]  ioctl_be,     // byte lane(s): 11=packed plane word, 01/10=interleaved ROM
  output logic        ioctl_wait,

  // MRA sound-ROM download (BYTE stream, clk domain). addr[17:16]=chip (0=U4 1=U19
  // 2=U20), addr[15:0]=byte within the 64KB chip. Routed to the CVSD board's BRAMs.
  input  logic        snd_dl_wr,
  input  logic [17:0] snd_dl_addr,
  input  logic [7:0]  snd_dl_data,

  // SDRAM (MT48LC16M16) pins
  inout  wire  [15:0] SDRAM_DQ,
  output logic [12:0] SDRAM_A,
  output logic [1:0]  SDRAM_BA,
  output logic        SDRAM_DQML, SDRAM_DQMH,
  output logic        SDRAM_nCS, SDRAM_nRAS, SDRAM_nCAS, SDRAM_nWE,
  output logic        SDRAM_CKE,
  // NOTE: SDRAM_CLK is NOT a port here — the emu forwards it from clk_sdram (outclk_1,
  // -3515ps) directly to the pin, matching rtl/sdram.sdc (general[1]) and the proven
  // tecmo/jtframe cores. Keeping it out of the core avoids double-driving the pin.

  // HPS DDR3 (f2h_sdram1) Avalon master. Ports are UNCONDITIONAL (the emu is Quartus-native,
  // NOT sv2v'd, so it cannot see USE_DDR3_VRAM) — under USE_DDR3_VRAM they carry VRAM traffic;
  // otherwise they are tied off to 0 inside. DDRAM_CLK is driven by the emu (= clk_sys, no CDC).
  output logic [28:0] DDRAM_ADDR,
  output logic [7:0]  DDRAM_BURSTCNT,
  output logic        DDRAM_RD,
  output logic [63:0] DDRAM_DIN,
  output logic [7:0]  DDRAM_BE,
  output logic        DDRAM_WE,
  input  logic        DDRAM_BUSY,
  input  logic [63:0] DDRAM_DOUT,
  input  logic        DDRAM_DOUT_READY,

  // video out
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de,

  // audio out (signed PCM)
  output logic signed [15:0] audio_l, audio_r,
  output logic               adpcm_irq,

  // debug
  output logic [31:0] pc_dbg,
  output logic        illegal_dbg,
  // boot-instrument taps (observability only; read by the DIAG_BOOT overlay). Unconnected
  // in the normal build — pure outputs, no behavioral effect.
  output logic        dbg_core_rst,
  output logic        dbg_sdram_ready,
  output logic        dbg_unp_done,
  output logic        dbg_cpu_req,
  output logic        dbg_mem_ack,
  output logic        dbg_int1,
  output logic        dbg_vblank_irq,
  output logic        dbg_cpu_ce,          // P0019: CPU clock-enable pulse (liveness tap for the
                                           // DIAG_BOOT overlay — proves the /4 CE is actually pulsing)
  output logic [31:0] dbg_p1ctrl,          // fire-chain watch: {P1CTRL last value, write count}
  output logic [31:0] dbg_bdir,            // fire-chain watch: {B_DIR last value, write count}
  output logic [7:0]  dbg_snd_select,      // sound-latch command byte (live copy)
  output logic        dbg_snd_trig,        // sound-latch strobe (count edges at the consumer)
  // derail capture (frozen at the FIRST time the PC leaves R_ROM = the wild jump)
  output logic        dbg_derailed,
  output logic [31:0] dbg_culprit_pc,     // last valid code PC = the instruction that jumped
  output logic [15:0] dbg_culprit_instr,  // opcode at the culprit
  output logic [31:0] dbg_derail_pc,       // where it jumped TO (the bad target)
  // P0020 download audit: dropped vs accepted FIFO pushes (see the iol_* block below).
  // Display-base instrument (DIAG_DISPBASE). Read the two together: a frozen
  // flip count alone cannot distinguish a dead tap from a title that does not
  // flip -- dbg_disp_rows shows live|pending|reference so the tap proves alive.
  output logic [31:0] dbg_disp_flips,
  output logic [31:0] dbg_disp_rows,
  // thin-blit census (DIAG_THINBLIT): does the game ISSUE its row-by-row blits?
  output logic [31:0] dbg_blit_total,
  output logic [31:0] dbg_blit_thin,
  // RUNTIME autoerase kill (OSD bit). A cabinet experiment, not a build define:
  // DIAG_NO_AUTOERASE answers the same question but costs a full Quartus build
  // per toggle, and the question -- "is autoerase what makes the page-flipping
  // titles flash?" -- needs A/B on the SAME image, on the SAME cabinet, without
  // a reflash between halves. 0 = normal (ships this way; status defaults to 0).
  input  wire         autoerase_off,
  output logic [31:0] dbg_iol_drop,        // # download words DROPPED on FIFO overflow (>0 = hps_io outran backpressure)
  output logic [31:0] dbg_iol_wrs,         // # download words ACCEPTED into the FIFO (should reach ~0xD0000)
  // cont.24 splash-capture diag taps (DIAG_SPLASHCAP): the DMA reg-write stream + the blitter's
  // first source byte + the scanout stream, so the emu overlay can capture the title-splash blit
  // commands (LEFT/RIGHT column) and the boot-noise scanout on the cab.
  output logic        dbg_dma_we,
  output logic  [3:0] dbg_dma_addr,
  output logic [15:0] dbg_dma_wdata,
  output logic  [7:0] dbg_src_data,
  output logic        dbg_src_ack,
  output logic [15:0] dbg_scan_data,
  output logic        dbg_scan_ack,
  // ---- F4 cabinet service instrument (SHIP-SPEC-yunit-2026-08-02.md §4) --------------
  // Per-frame service counters read by yunit_diag_service_overlay on the cab. The PORTS are
  // unconditional (the emu instantiates the overlay behind its own Quartus macro), but the
  // counting logic below is compiled only under DIAG_SERVICE and these tie to 0 otherwise,
  // so a production build carries none of it.
  output logic [15:0] dbg_cgfx_grants,
  output logic [15:0] dbg_snd_grants,
  output logic [31:0] dbg_cgfx_maxwait,
  output logic [15:0] dbg_snd_miss,
  output logic [15:0] dbg_snd_busy16,
  output logic [15:0] dbg_cvsd_moves,
  output logic [15:0] dbg_adpcm_moves,
  output logic [15:0] dbg_blank_pix,
  output logic [31:0] dbg_cpu_pc_moves,
  output logic [31:0] dbg_snd_acks,
  output logic [31:0] dbg_snd_first_words,
  output logic        dbg_snd_region_seen,
  output logic        dbg_snd_board_rst,
  output logic [15:0] dbg_restart_cnt
);
  // adpcm_irq is now driven by the ADPCM board instance further down; it feeds
  // the CUSTOM sound-status bit IN1[14] that MK / T2 / Total Carnage poll.
  // family2 P1: game_id is live -- it selects the runtime board profile.
  // First consumer is the pen-map/unpack bpp (yunit_pkg.yunit_is_4bpp:
  // Trog / Strike Force / Saurian Front are 4bpp, all others 6bpp).
  wire game_bpp4 = yunit_is_4bpp(game_id);
  // Per-title raw plane span (Trog's plane hole, MK/T2's 2 MB planes, ...).
  // A non-default PLANE_WORDS parameter (small E2E sims) still wins.
  wire [23:0] game_plane_words =
      (PLANE_WORDS != 24'h30000) ? PLANE_WORDS : yunit_plane_words(game_id);
  // sound_download left the unused list at SRC-1b: it is the unpack arm (see :792).
  // It stays XOR'd in so the non-SYNTHESIS sim build, where the arm block is
  // compiled out, still has exactly one consumer of the port.
  wire unused_wrapper_inputs = ^{gfx_download, sound_download,
                                 24'h0};  // GFX_BYTES + SOUNDW_BASE are LIVE since family2 P1.4
  // Hold the CPU / memory / video in reset until the SDRAM controller has finished
  // its power-up init (the real MiSTer pattern: the core waits for SDRAM ready +
  // ROM load). Without this the CPU's first fetch rises DURING init and the phy's
  // rising-edge accept misses it -> the held request deadlocks. The SDRAM phy +
  // arbiter run on the raw `rst` so init can proceed while the core is held.
  // sdram_ready is driven by the stock-SDRAM adapter (sticky: it latches the controller's
  // first `ready` = power-up init complete). The adapter + sdram_stock run on raw `rst`.
  logic sdram_ready;
  // Boot-time SDRAM scratch for the raw gfx planes (see yunit_gfx_unpack): plane0 @
  // SCRATCH_WBASE, plane1 @ +PLANE_WORDS, plane2 @ +2*PLANE_WORDS (module parameters).
  // unp_done: gfx unpack complete. 1 in sim (the tb preloads flat gfx directly);
  // in synth it rises only after the boot-time planar->flat pass finishes.
  logic unp_done;
  // Hold the core during ROM download AND the subsequent gfx-unpack pass: SDRAM stays
  // initialized (ready) so the ioctl/unpack channels can write it, while the CPU/video
  // wait until the ROMs are loaded and the gfx is unpacked.
  wire  core_rst = rst | ~sdram_ready | ioctl_download | ~unp_done;

  // ---- CPU on clk + clock-enable (P0019: NO separate async clk_cpu) -----------
  // HISTORY: the CPU used to run on a separate clk_cpu (~24 MHz) PLL tap, with
  // yunit_mem_cdc as a real clock-domain crossing to memsys (clk 96 MHz). That
  // passed zero-delay sim but FAILED on silicon. clk_cpu is clk/4 from the SAME PLL
  // (phase-locked, NOT truly async), yet the SDC declared it asynchronous, so STA
  // never timed the CPU<->memsys crossing and the fitter routed those paths freely
  // -> the CPU read back garbage for its reset vector on the cab while the live PC
  // (clk-sampled) marched. FIX: run the CPU on `clk` gated by a 1-in-4 clock-enable
  // (cpu_ce) so it advances at the identical ~24 MHz rate but on a SINGLE clock.
  // The CDC's cpu-side FSM is gated by the SAME cpu_ce (its clk_cpu port is driven
  // by clk), so the 2-phase toggle handshake is behaviorally identical to the proven
  // /4-clock sim, but now single-clock: STA times everything and no metastability is
  // possible. The long CPU combinational path (~30 MHz max) gets 4 clk periods via a
  // 4:1 multicycle in rtl/sdram.sdc (cpu_ce -> memsys and back).
  // CPU-SPEED SELECTOR: this non-cycle-accurate core shares DDR3 with scanout and
  // pays much higher VRAM latency than the original board. Cab A/B is decisive:
  // /20 reaches the software deadline late and warps/restarts; /4 reaches attract.
  // Therefore status 0 defaults to /4 headroom and /20 remains the last, explicitly
  // labelled stock-rate experiment. This only addresses the independent deadline/
  // watchdog failure; it does not claim to fix missing or broken sprites. Every
  // selectable divisor is >=4, so the 4:1 cpu_ce multicycle remains conservative.
  logic [4:0] cpu_ce_div;
  always_comb case (cpu_div_sel)
    3'd0: cpu_ce_div = 5'd4;  3'd1: cpu_ce_div = 5'd6;  3'd2: cpu_ce_div = 5'd8;  3'd3: cpu_ce_div = 5'd10;
    3'd4: cpu_ce_div = 5'd12; 3'd5: cpu_ce_div = 5'd14; 3'd6: cpu_ce_div = 5'd16; default: cpu_ce_div = 5'd20;
  endcase
  logic [4:0] ce_div;
  always_ff @(posedge clk) if (rst) ce_div <= 5'd0;
                           else     ce_div <= (ce_div == cpu_ce_div - 5'd1) ? 5'd0 : ce_div + 5'd1;
  wire cpu_ce = (ce_div == 5'd0);          // 1 clk-wide pulse every cpu_ce_div'th clk

  // Reset synchronizer into clk, shared by the core AND the CDC (both single-clock now).
  // core_rst is a raw combinational term; reclocking its deassertion into clk gives clean
  // recovery/removal on all CPU-side flops. memsys/arb keep raw core_rst (never crossed).
  logic core_rst_sys_m, core_rst_sys;
  always_ff @(posedge clk) begin core_rst_sys_m <= core_rst; core_rst_sys <= core_rst_sys_m; end
  // int1 (DMA-done LINT1, the blit-queue pump) is generated by u_sys on clk — already in
  // the CPU's clock domain now, so it drives the core directly (sampled on cpu_ce edges).
  logic int1;

  // CPU memory interface (clk, advanced by cpu_ce)
  logic cpu_req, cpu_we; logic [ADDR_WIDTH-1:0] cpu_addr; logic [FIELD_SIZE_WIDTH-1:0] cpu_size;
  logic [DATA_WIDTH-1:0] cpu_wdata, cpu_rdata; logic cpu_ack;
  logic erase_busy, blit_busy, blit_engine_active;
`ifdef YUNIT_SRT_FILL_BURST
  logic [DATA_WIDTH-1:0] core_mem_rdata;
  logic core_mem_ack;
  logic cpu_shiftreg_req, cpu_shiftreg_write;
  logic [ADDR_WIDTH-1:0] cpu_shiftreg_bit_addr;
  logic sr_req_ready, sr_done;
  logic [15:0] sr_read_data;
  logic sr_engine_req_valid, sr_engine_req_write;
  logic [ADDR_WIDTH-1:0] sr_engine_req_bit_addr;
  logic sr_burst_req;
  logic [17:0] sr_burst_entry;
  logic sr_backend_ready;
  logic sr_invalidate_valid;
  logic [8:0] sr_invalidate_row;
  logic sr_core_ack;
  logic sr_error_sticky;
  // Restore bursts are limited to measured Strike Force and Terminator 2.
  // T2 has measured starts at pairs 0 and 11; its pattern LOAD is unchanged.
  wire srt_restore_profile = (game_id == YG_STRKFORC) || (game_id == YG_TERM2);
  wire sf_shiftreg_addr_ok = (!cpu_shiftreg_write
                              && (cpu_shiftreg_bit_addr == 32'h001F_E000))
                           || (cpu_shiftreg_write
                               && ((cpu_shiftreg_bit_addr & 32'hFFEF_FFFF) >=
                                   ((game_id == YG_TERM2) ? 32'h0000_0000 : 32'h0002_C000))
                               && ((cpu_shiftreg_bit_addr & 32'hFFEF_FFFF) <= 32'h000F_C000)
                               && (cpu_shiftreg_bit_addr[12:0] == 13'd0));
  wire sf_shiftreg_req = cpu_shiftreg_req && srt_restore_profile
                       && sf_shiftreg_addr_ok;
`endif
  // The display-register write stream is needed by BOTH flavours now: Family2
  // tracks DPYSTRT for the runtime display base (page flip), FULL feeds the
  // address sequencer. Declared unconditionally; the FULL-only extras below
  // stay guarded.
  logic tms_display_wr_valid;
  logic [IO_REG_IDX_W-1:0] tms_display_wr_idx;
  logic [15:0] tms_display_wr_data;
`ifdef YUNIT_DISPLAY_SEQ
  logic tms_display_line_wrap;
  logic [15:0] display_dpyadr_live;
`endif
  core_state_t state_w; instr_word_t instr_w;

  // .ce_pix = P0023 (ported from UMK3): the core's internal tms34010_video counters
  // advance at the DOT rate (8 MHz enable), not raw clk. Without it DPYINT fired ~12x
  // too fast at meaningless scanline positions -- lethal at the boot's first EINT
  // (cab: warm-restart cycle through CLSCRACH/INTENB-enable, PC samples FFE0DEC0/
  // FFE0E7D0/FFE01970 = init -> enable DPYINT -> die -> restart, decoded vs ROM dasm).
  //
  // cont.23 — the LAST 2x (pixels_per_clock=2): MAME midyunit.cpp:1291-1306 sets the 34010's
  // set_pixel_clock(4 MHz) + set_pixels_per_clock(2), screen dot clock = 8 MHz. So the video
  // COUNTERS tick at 4 MHz (each tick = 2 screen dots), NOT the 8 MHz dot rate. P0023 fixed 12x->2x
  // but left the counters at the full 8 MHz ce_pix -> DPYINT/DIRQ/@TIMER ran at 110 Hz vs the 55 Hz
  // display (yunit_video_family2 506x289 @ 8 MHz) = a 2:1 mismatch. That ONE bug = overspeed (110 Hz DIRQ,
  // NOT a cpu_ce issue) + flashing (draw/erase chase a 110 Hz phantom beam) + dropped sprites (DIRQ
  // at wrong displayed rows) + START->bonus warp (watchdog @TIMER>=200 climbs 2x fast). FIX: feed
  // the CORE's video counters ce_pix/2 (= the 4 MHz pixel clock); yunit_video_family2 KEEPS the full 8 MHz
  // ce_pix (it paints 506 real dots/line). Scoped to the 34010 counters only. VERIFIED in sim
  // (tb_video_2x): 2.000 DPYINT/display-frame at full ce_pix -> 1.000 at ce_pix/2.
  logic ce_pix_ph;
  logic timing_start;
  always_ff @(posedge clk) begin
`ifdef MUT_TIMING_NO_DIV_RESYNC
    if (core_rst_sys) ce_pix_ph <= 1'b0;
`else
    // HTOTAL activates the previously-zero internal raster. Reset the /2 dot
    // phase on that exact write edge, including when it coincides with ce_pix.
    if (core_rst_sys || timing_start) ce_pix_ph <= 1'b0;
`endif
    else if (ce_pix) ce_pix_ph <= ~ce_pix_ph;
  end
  wire ce_pix_cnt = ce_pix & ce_pix_ph;   // 4 MHz pixel clock = every 2nd 8 MHz ce_pix tick
  tms34010_core u_core (
    .clk(clk), .ce_cpu(cpu_ce), .ce_pix(ce_pix_cnt), .rst(core_rst_sys),
    .mem_req(cpu_req), .mem_we(cpu_we), .mem_addr(cpu_addr), .mem_size(cpu_size),
`ifdef YUNIT_SRT_FILL_BURST
    .mem_wdata(cpu_wdata), .mem_rdata(core_mem_rdata), .mem_ack(core_mem_ack),
`else
    .mem_wdata(cpu_wdata), .mem_rdata(cpu_rdata), .mem_ack(cpu_ack),
`endif
    .state_o(state_w), .pc_o(pc_dbg), .instr_word_o(instr_w),
    .illegal_opcode_o(illegal_dbg),
    // FULL consumes the live display and SRT sidebands used across the family.
    // Its dynamic line cache is bandwidth-bounded to the visible window below.
    .instruction_start_o(), .instruction_retire_o(),
    .instruction_cycles_o(), .instruction_cycles_valid_o(),
    .timing_start_o(timing_start),
    // Both flavours consume the display-write stream now -- Family2 needs it
    // for the runtime display base, so these three leave the FULL guard.
    .display_wr_valid_o(tms_display_wr_valid),
    .display_wr_idx_o(tms_display_wr_idx),
    .display_wr_data_o(tms_display_wr_data),
`ifdef YUNIT_SRT_FILL_BURST
    .srt_fill_ack_i(sr_core_ack),
`else
    .srt_fill_ack_i(1'b0),
`endif
`ifdef YUNIT_DISPLAY_SEQ
    .display_line_wrap_o(tms_display_line_wrap),
    .display_dpyadr_live_i(display_dpyadr_live),
    .display_dpyadr_live_valid_i(1'b1),
`ifdef YUNIT_SRT_FILL_BURST
    .srt_fill_exact_enable_i(srt_restore_profile),
    .srt_fill_term2_enable_i(game_id == YG_TERM2),
    .shiftreg_req_o(cpu_shiftreg_req),
    .shiftreg_write_o(cpu_shiftreg_write),
    .shiftreg_bit_addr_o(cpu_shiftreg_bit_addr),
`else
    .srt_fill_exact_enable_i(1'b0),
    .srt_fill_term2_enable_i(1'b0),
    .shiftreg_req_o(), .shiftreg_write_o(), .shiftreg_bit_addr_o(),
`endif
`else
    // display_wr_{valid,idx,data}_o are now bound ABOVE for both flavours --
    // Family2 needs the DPYSTRT stream for the runtime display base. Binding
    // them here too is a duplicate connection and sv2v rejects it.
    .display_line_wrap_o(),
    .display_dpyadr_live_i(16'd0), .display_dpyadr_live_valid_i(1'b0),
`ifdef YUNIT_SRT_FILL_BURST
    .srt_fill_exact_enable_i(srt_restore_profile),
    .srt_fill_term2_enable_i(game_id == YG_TERM2),
    .shiftreg_req_o(cpu_shiftreg_req),
    .shiftreg_write_o(cpu_shiftreg_write),
    .shiftreg_bit_addr_o(cpu_shiftreg_bit_addr),
`else
    .srt_fill_exact_enable_i(1'b0),
    .srt_fill_term2_enable_i(1'b0),
    .shiftreg_req_o(), .shiftreg_write_o(), .shiftreg_bit_addr_o(),
`endif
`endif
    .lint1_in(int1));

`ifdef YUNIT_SRT_FILL_BURST
  // Register the architectural command on the CPU-CE boundary. Completion is
  // withheld until the DDR agent/bridge has accepted the entire 1024-entry
  // row-pair operation; no queued/early acknowledgement is permitted.
  yunit_shiftreg_command_bridge #(.AW(ADDR_WIDTH)) u_shiftreg_cmd (
    .clk(clk), .rst(core_rst_sys), .cpu_ce(cpu_ce),
    .cpu_req(sf_shiftreg_req), .cpu_write(cpu_shiftreg_write),
    .cpu_bit_addr(cpu_shiftreg_bit_addr),
    .engine_req_valid(sr_engine_req_valid),
    .engine_req_ready(sr_req_ready),
    .engine_req_write(sr_engine_req_write),
    .engine_req_bit_addr(sr_engine_req_bit_addr),
    .engine_done(sr_done), .engine_error(1'b0),
    .core_ack(sr_core_ack), .error_sticky(sr_error_sticky));

  // Both response sources are already registered and mutually exclusive: an
  // SRT command is withheld from u_memcdc, while every ordinary request is
  // withheld from the SRT bridge.  Select with the registered response itself,
  // not the live sf_shiftreg_req/address comparator.  The old live select made
  // a combinational loop-shaped timing path from core decode/mask/address,
  // through this mux, and back into MMFM's full-rate commit bank.
  assign core_mem_ack = cpu_ack | sr_core_ack;
  assign core_mem_rdata = sr_core_ack
                        ? {{(DATA_WIDTH-16){1'b0}}, sr_read_data}
                        : cpu_rdata;
`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (!core_rst_sys && cpu_ack && sr_core_ack)
      $fatal(1, "yunit_top_family2: ordinary and SRT acknowledgements collided");
  end
`endif
  assign sr_burst_req   = sr_engine_req_valid && sr_req_ready;
  assign sr_burst_entry = sr_engine_req_bit_addr[20:3];
  // MAME orders the SRT FILL before the next 59 DMA compositions.  Do not let
  // the new command park a DMA pixel already in flight: wolf_dma's proven
  // barrier waits for busy to fall, then the E lane drains the accepted D/A/C
  // backend work before replacing the row pair.
  assign sr_req_ready   = sr_backend_ready && !blit_engine_active;
`endif

  // Gospel-guarded erase line events (YUNIT_DISPLAY_SEQ: exact, from the
  // display sequencer; builds without it keep C's snoop trigger, gated by the
  // per-frame raw guard erase_frame_raw_ok below).
  logic display_frame_start;
  logic display_line_consumed_valid;
  logic [8:0] display_line_consumed_row;
`ifndef YUNIT_DISPLAY_SEQ
  assign display_line_consumed_valid = 1'b0;
  assign display_line_consumed_row   = 9'd0;
`endif

`ifdef YUNIT_DISPLAY_SEQ
  // Live 34010 display address.  A timing_start bootstraps VCOUNT=0; later
  // events follow the core's 4 MHz HCOUNT wraps.  This replaces FULL's fixed
  // row-zero scanout, which only happened to match a subset of the family.
  wire display_line_tick = timing_start | tms_display_line_wrap;
  logic [15:0] display_vcount_live;
  logic display_line_event;
  logic display_scanout_valid;
  logic [8:0] display_scanout_row_phys;
  logic [8:0] display_scanout_col_word;
  logic display_prefetch_valid;
  logic [8:0] display_prefetch_row_phys;
  logic [8:0] display_prefetch_col_word;
  logic display_contract_valid;

  yunit_display_address_sequencer u_display_address (
    .clk(clk), .rst(core_rst_sys), .line_tick(display_line_tick),
    .dpyctl_we(tms_display_wr_valid &&
               (tms_display_wr_idx == IO_IDX_DPYCTL)),
    .dpyctl_wdata(tms_display_wr_data),
    .dpystart_we(tms_display_wr_valid &&
                 (tms_display_wr_idx == IO_IDX_DPYSTRT)),
    .dpystart_wdata(tms_display_wr_data),
    .dpytap_we(tms_display_wr_valid &&
               (tms_display_wr_idx == IO_IDX_DPYTAP)),
    .dpytap_wdata(tms_display_wr_data),
    .dpyadr_we(tms_display_wr_valid &&
               (tms_display_wr_idx == IO_IDX_DPYADR)),
    .dpyadr_wdata(tms_display_wr_data),
    .veblnk_we(tms_display_wr_valid &&
               (tms_display_wr_idx == IO_IDX_VEBLNK)),
    .veblnk_wdata(tms_display_wr_data),
    .vsblnk_we(tms_display_wr_valid &&
               (tms_display_wr_idx == IO_IDX_VSBLNK)),
    .vsblnk_wdata(tms_display_wr_data),
    .vtotal_we(tms_display_wr_valid &&
               (tms_display_wr_idx == IO_IDX_VTOTAL)),
    .vtotal_wdata(tms_display_wr_data),
    // DPYADR<-DPYSTRT at VSBLNK is an architectural display transition.  Do not
    // suppress it on the global framebuffer-combiner busy level: a per-frame
    // A->B->A title can otherwise lose B forever when the next request aliases
    // the still-committed A page.  Accepted writes are kept coherent by the
    // scanline snoop/write-through path below, independent of physical drain.
    .flip_hold(1'b0),
    .vcount_live(display_vcount_live),
    .dpyadr_live(display_dpyadr_live),
    .line_event(display_line_event),
    .scanout_valid(display_scanout_valid),
    .scanout_vcount(), .scanout_row_raw(),
    .scanout_row_phys(display_scanout_row_phys),
    .scanout_base_word(), .scanout_coladdr(),
    .scanout_col_word(display_scanout_col_word), .scanout_yoffset(),
    .prefetch_valid(display_prefetch_valid),
    .prefetch_vcount(), .prefetch_row_raw(),
    .prefetch_row_phys(display_prefetch_row_phys),
    .prefetch_base_word(), .prefetch_coladdr(),
    .prefetch_col_word(display_prefetch_col_word), .prefetch_yoffset(),
    .frame_start_o(display_frame_start),
    .line_consumed_valid(display_line_consumed_valid), .line_consumed_row_raw(),
    .line_consumed_row_phys(display_line_consumed_row), .line_consumed_base_word(),
    .contract_valid(display_contract_valid),
    .unsupported_mode(), .config_invalid(),
    .timing_conflict_pulse(), .timing_conflict_sticky(),
    .line_deferred_pulse(), .line_deferred_sticky(),
    .sequence_error_pulse(), .sequence_error_sticky());
`endif

  // memsys-domain memory interface (clk); fed by the CDC's memsys side
  logic mem_req, mem_we; logic [ADDR_WIDTH-1:0] mem_addr; logic [FIELD_SIZE_WIDTH-1:0] mem_size;
  logic [DATA_WIDTH-1:0] mem_wdata, mem_rdata; logic mem_ack;

  yunit_mem_cdc #(.AW(ADDR_WIDTH), .DW(DATA_WIDTH), .SW(FIELD_SIZE_WIDTH)) u_memcdc (
    .clk_cpu(clk), .ce_cpu(cpu_ce), .rst_cpu(core_rst_sys),
`ifdef YUNIT_SRT_FILL_BURST
    .c_req(cpu_req && !sf_shiftreg_req),
`else
    .c_req(cpu_req),
`endif
    .c_we(cpu_we), .c_addr(cpu_addr), .c_size(cpu_size), .c_wdata(cpu_wdata),
    .c_ack(cpu_ack), .c_rdata(cpu_rdata),
    .clk_sys(clk), .rst_sys(core_rst_sys),
    .m_req(mem_req), .m_we(mem_we), .m_addr(mem_addr), .m_size(mem_size), .m_wdata(mem_wdata),
    .m_rdata(mem_rdata), .m_ack(mem_ack));

  // ---- memsys external channels ----------------------------------------------
  logic        src_req;  logic [23:0] src_addr;  logic [7:0] src_data;  logic src_ack;
  logic        cgfx_rd;  logic [23:0] cgfx_addr; logic [15:0] cgfx_data; logic cgfx_ack;  // PERF: word-wide cgfx
  logic        scan_req; logic [17:0] scan_addr; logic [15:0] scan_data; logic scan_ack;
`ifndef USE_DDR3_VRAM
  logic [24:0] vsd_addr; logic [15:0] vsd_din, vsd_dout; logic [1:0] vsd_be;
  logic        vsd_rd, vsd_wr, vsd_ack;
  // VRAM stays on SDRAM -> DDR3 master is unused: tie it off (mirrors the emu's old tie-off).
  assign DDRAM_ADDR=29'd0; assign DDRAM_BURSTCNT=8'd0; assign DDRAM_RD=1'b0;
  assign DDRAM_DIN=64'd0;  assign DDRAM_BE=8'd0;       assign DDRAM_WE=1'b0;
`endif
  logic [7:0]  snd_select; logic snd_trig, snd_reset;
  logic [1:0] term2_adc_sel;
  logic [7:0] term2_adc;
  always_comb case (term2_adc_sel)
    2'd0: term2_adc = term2_analog[7:0];
    2'd1: term2_adc = term2_analog[15:8];
    2'd2: term2_adc = term2_analog[23:16];
    default: term2_adc = term2_analog[31:24];
  endcase
  assign dbg_snd_select = snd_select;   // fire-chain/sound diag copies (always-on, no cost)
  assign dbg_snd_trig   = snd_trig;
  // Framebuffer write-combine drain observability.  This must not gate DPYSTRT:
  // it is a global backend level, not a page-specific publication token.
  logic        mem_fb_busy;
  logic        fb_snoop_we;
  logic [17:0] fb_snoop_addr;
  logic [15:0] fb_snoop_data;
  // palette write-tap
  logic        palv_we_a, palv_we_b; logic [12:0] palv_aa, palv_ba; logic [15:0] palv_awd, palv_bwd;

  // autoerase: whole-frame sweep triggered at vblank (post-scanout model, frame-
  // gate verified). row0 = DISP_ROW0, lines = V_ACT.
  logic vblank_irq;

  yunit_memsys_family2 #(.ROM_HEX(ROM_HEX), .ROM_WORDS(ROM_WORDS),
                         .ROM_WORD_OFFSET(ROM_WORD_OFFSET),
                         .GFX_PIXELS({8'h00, GFX_BYTES})) u_sys (
    .clk(clk), .rst(core_rst),
    .mem_req(mem_req), .mem_we(mem_we), .mem_addr(mem_addr), .mem_size(mem_size),
    .mem_wdata(mem_wdata), .mem_rdata(mem_rdata), .mem_ack(mem_ack),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .inputs(inputs), .game_id(game_id), .cpu_pc(pc_dbg),
    .term2_adc(term2_adc), .term2_adc_sel(term2_adc_sel),
    .bpp4(game_bpp4), .gfx_bytes(yunit_gfx_bytes(game_id)), .int1(int1),
    .cmos_quiesce(cmos_quiesce),
    .nvram_ext_en(nvram_ext_en), .nvram_ext_wr(nvram_ext_wr),
    .nvram_ext_addr(nvram_ext_addr), .nvram_ext_wdata(nvram_ext_wdata),
    .nvram_ext_rdata(nvram_ext_rdata),
    .cmos_cpu_busy(cmos_cpu_busy),
    .cmos_cpu_write_pulse(cmos_cpu_write_pulse),
`ifdef YUNIT_SRT_FILL_BURST
    .shift_req(sr_burst_req), .shift_write(sr_engine_req_write),
    .shift_entry(sr_burst_entry), .shift_rdata(sr_read_data),
    .shift_ready(sr_backend_ready), .shift_done(sr_done),
    .shift_invalidate_valid(sr_invalidate_valid),
    .shift_invalidate_row(sr_invalidate_row),
`endif
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .dbg_p1ctrl(dbg_p1ctrl), .dbg_bdir(dbg_bdir),
`ifdef DIAG_NO_AUTOERASE
    .erase_start(1'b0),                 // DIAG probe: kill autoerase -> confirm it is the flicker source
`else
    // Same probe, runtime. Gating the START pulse (not the engine) leaves the
    // erase FSM's reset/idle behaviour untouched -- with no start it simply
    // never leaves AE_IDLE, which is exactly what the compile-time probe does.
    .erase_start(vblank_irq && !autoerase_off),
`endif
    .erase_row0(disp_row_dyn), .erase_lines(10'(V_ACT)),
    // Gospel-guarded per-line erase events: the sequencer's line_consumed_*
    // apply MAME's RAW-rowaddr guard (scanline<510, midyunit_v.cpp:538) at the
    // source. C consumes these whenever YUNIT_DISPLAY_SEQ is present, so the
    // copy begins only after the addressed row has finished displaying.
    .erase_frame_start(display_frame_start),
    .erase_line_valid(display_line_consumed_valid),
    .erase_line_row(display_line_consumed_row),
    .erase_frame_raw_ok(erase_frame_raw_ok),
    .autoerase_off(autoerase_off),   // reaches the LIVE beam-locked erase_en
    .erase_busy(erase_busy), .blit_busy(blit_busy),
    .blit_engine_active(blit_engine_active), .fb_busy(mem_fb_busy),
    .fb_snoop_we(fb_snoop_we), .fb_snoop_addr(fb_snoop_addr), .fb_snoop_data(fb_snoop_data),
    .dbg_blit_total(dbg_blit_total), .dbg_blit_thin(dbg_blit_thin),
    .dbg_dma_we(dbg_dma_we), .dbg_dma_addr(dbg_dma_addr), .dbg_dma_wdata(dbg_dma_wdata),   // cont.24 splash-capture
    // external gfx/ROM read (CPU gfx window)
    .cpu_gfx_rd(cgfx_rd), .cpu_gfx_raddr(cgfx_addr), .cpu_gfx_rdata(cgfx_data), .cpu_gfx_rack(cgfx_ack),
    // VRAM SDRAM channel + video scanout (memsys's fb_ack is internal — not a port)
`ifdef USE_DDR3_VRAM
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
    .sdram_por(sdram_por),
    .ddram_addr(DDRAM_ADDR), .ddram_burstcnt(DDRAM_BURSTCNT), .ddram_rd(DDRAM_RD), .ddram_we(DDRAM_WE),
    .ddram_din(DDRAM_DIN), .ddram_be(DDRAM_BE),
    .ddram_busy(DDRAM_BUSY), .ddram_dout(DDRAM_DOUT), .ddram_dout_ready(DDRAM_DOUT_READY),
`else
 `ifdef USE_SDRAM_VRAM
  `ifdef SDRAM_SINGLEBEAT_SCANOUT
    // ISOLATION (cont.23 HW bring-up): page-mode u_scanout DISABLED -> vram_sdram_top serves scanout
    // via its own single-beat path (VSD). Tests whether the page-mode burst scanout is the HW-corruption.
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
  `else
    // SDRAM: scanout is served by the P2 page-mode row-cache (u_scanout) below, NOT vram_sdram_top's
    // single-beat scanout (which oversubscribed the line budget, P0023). Tie memsys's scanout off.
    .scan_req(1'b0), .scan_addr(18'd0), .scan_data(), .scan_ack(),
  `endif
    .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr),
    .vsd_dout(vsd_dout), .vsd_ack(vsd_ack),
 `endif  // USE_SDRAM_VRAM -- under USE_HW_VRAM memsys has no scan_*/vsd_* ports (BRAM framebuffer)
`endif
    // palette write-tap
    .palv_we_a(palv_we_a), .palv_aa(palv_aa), .palv_awd(palv_awd),
    .palv_we_b(palv_we_b), .palv_ba(palv_ba), .palv_bwd(palv_bwd));

  // ---- video subsystem -------------------------------------------------------
  logic [11:0] pal_raddr; logic [15:0] pal_rdata;
`ifdef MUT_YVIDEO_RAW_RESET
  wire video_rst = core_rst;
`else
  // Keep the physical raster and the 34010 counters on the same reset-release
  // edge.  core_rst can fall within two sys clocks of ce_pix; using it directly
  // could let yunit_video_family2 consume an 8 MHz tick while the synchronized 34010
  // counter and its /2 phase divider are still held reset.
  wire video_rst = core_rst_sys;
`endif
`ifdef MUT_TIMING_NO_HTOTAL_RESYNC
  wire video_phase_rst = video_rst;
`else
  // Reset the complete video_top (raster + scanline ownership) on the same
  // first-HTOTAL write that starts the internal 34010 timing generator.
  wire video_phase_rst = video_rst | timing_start;
`endif

  // ---------------------------------------------------------------------
  // RUNTIME DISPLAY BASE (page flip).
  //
  // MEASURED 2026-08-16, MAME 0.280, live gameplay (mame-trace/
  // yunit_render_profile_gp.lua): SEVEN of eight Y-unit titles move DPYSTRT
  // every frame -- High Impact 4,784 flips over 5,200 drawing frames, Strike
  // Force 4,300/4,300, Super High Impact 4,641/5,045, MK 2,014, T2 1,127 with
  // THREE distinct bases. Only Smash T.V. (ZERO DPYSTRT writes in gameplay)
  // and Trog (15 writes, one value) hold a static base -- and those are the
  // only two titles that render correctly on the cabinet.
  //
  // yunit_video_family2 pinned the base to the compile-time DISP_ROW0, so a
  // flip was invisible to scanout: the core displayed one page while the game
  // drew into the other, alternating every frame = whole-screen flash.
  //
  // Row field matches gospel exactly -- midyunit_v.cpp:545 indexes
  // m_local_videoram[(rowaddr << 9) & 0x3fe00], i.e. rowaddr[8:0], and rowaddr
  // is dpyadr[15:4], so the row is write_data[12:4].
  //
  // ...but NOT raw. tms34010.cpp:1149-1152 normalises first:
  //     dpyadr = IOREG(REG_DPYADR);
  //     if (!(IOREG(REG_DPYCTL) & 0x0400)) dpyadr ^= 0xfffc;   // ORG bit clear
  //     params->rowaddr = dpyadr >> 4;
  // DPYCTL bit 10 is CLEAR on this family -- Smash writes DPYCTL=F010 in its
  // own CRTC init table (MAIN.ASM:502-532, F010 & 0400 == 0), so the XOR is
  // ALWAYS taken. Bits [12:4] all sit inside the 0xfffc mask, so the row is the
  // bitwise COMPLEMENT of the raw field:
  //     row_gospel[8:0] = ~write_data[12:4] = 511 - write_data[12:4]
  // (F010 & 03fc == 0x10 -> DUDATE 16 -> rowaddr advances exactly 1 per line,
  // which is why scanout counting UP is correct and must not be inverted.)
  //
  // ABSOLUTE form. The earlier DELTA form (DISP_ROW0 + (row_now - row_first))
  // was chosen because raw DPYSTRT=FFFC "maps to row 511 while the core scans
  // from 0" -- but that 511 is the UN-complemented value. Gospel puts Smash at
  // ~511 = row 0, exactly where the core already scans, so the mismatch the
  // delta form was built to absorb never existed. Measured DPYSTRT values
  // (MAME 0.280 live gameplay, mame-trace/yunit_render_profile_gp.lua):
  //     smashtv  FFFC                -> row 0            (static)
  //     trog     FFFC                -> row 0            (static)
  //     hi/shi/mk FFFC, EFFC         -> rows 0, 256
  //     strkforc E00C, F00C          -> rows 511, 255
  //     term2    FFFC, E00C, F00C    -> rows 0, 511, 255
  // A delta reproduces gospel only where g_ref == 2*g_now (mod 512): it happens
  // to hold for the {0,256} titles because -256 == +256, but T2 has THREE bases
  // and g -> g_ref - g is an involution with ONE fixed point, so at most one of
  // the three could ever be right. Strike Force lands a row off. The complement
  // is right for all of them, and Smash/Trog still resolve to 0 -- so the
  // no-regression property the delta form was chosen for is PRESERVED, and now
  // holds by gospel rather than by arithmetic coincidence.
  //
  // Applied at the vblank edge, never on the write: the TMS34010 reloads
  // DPYADR from DPYSTRT at the top of the frame, and the games write DPYSTRT
  // at arbitrary beam positions (only 6 of High Impact's 2,157 attract writes
  // landed in blanking). Applying on write would tear instead of flip.
  // ---------------------------------------------------------------------
  // RUNTIME VISIBLE WIDTH (CRTC HEBLNK/HSBLNK).
  //
  // MEASURED 2026-08-16, MAME 0.280, live gameplay:
  //   smashtv  HEBLNK=45 HSBLNK=250 -> (250-45)*2 = 410 px
  //   hiimpact HEBLNK=45 HSBLNK=243 -> (243-45)*2 = 396 px
  // H_ACT is a compile-time 410 -- Smash's width -- so High Impact gets 14
  // columns it never asked for. Autoerase masks them (it clears all 512 VRAM
  // columns); with autoerase OFF they show stale data that differs per display
  // page, which is the flashing vertical strip on the right edge seen on the
  // cabinet. Same class of defect as the display base: a per-title CRTC value
  // frozen to Smash's constant.
  //
  // Gospel: visible x range is [heblnk, hsblnk) with the registers scaled by
  // pixperclock (tms34010.cpp:1143-1144), and the scanline callback writes only
  // that range (midyunit_v.cpp:550). pixperclock is 2 on this family.
  //
  // The RASTER stays at H_ACT -- changing it would change the output video mode
  // -- so this only blanks pixels. Clamped to H_ACT: a CRTC asking for MORE than
  // the raster provides cannot be honoured by widening, and silently painting
  // past the raster would corrupt timing.
  wire heblnk_we = tms_display_wr_valid && (tms_display_wr_idx == IO_IDX_HEBLNK);
  wire hsblnk_we = tms_display_wr_valid && (tms_display_wr_idx == IO_IDX_HSBLNK);
  // RESET DOMAIN IS LOAD-BEARING -- do NOT use video_phase_rst here.
  //
  // video_phase_rst = video_rst | timing_start, and timing_start fires on the
  // FIRST HTOTAL WRITE. The CRTC init table writes HESYNC, HEBLNK, HSBLNK,
  // HTOTAL, ... (MAIN.ASM:502-532) -- so HEBLNK/HSBLNK arrive BEFORE HTOTAL, and
  // resetting on video_phase_rst wipes the values the game just wrote, one
  // register later. visible_px then sits at the default forever and the fix is
  // a silent no-op. That shipped once (YUnitWidth_20260816) and the cabinet
  // reported the strip unchanged.
  //
  // The display base does not have this problem only because DPYSTRT is written
  // AFTER HTOTAL and so survives the same pulse. Same register file, opposite
  // side of the reset.
  logic [11:0] crtc_heblnk, crtc_hsblnk;
  // DISPLAY ENABLE (DPYCTL bit 15, "ENV"). Gospel blanks the WHOLE scanline
  // when it is clear: tms340x0_ind16 (tms34010.cpp:1178-1194) calls the
  // scanline callback only when params.enabled, and otherwise collapses the
  // window to nothing so every pixel of the line is the black pen.
  //
  // MEASURED (MAME 0.289, mame-trace/crtc_geom.lua, live gameplay): Strike
  // Force clears ENV 584 times and Saurian Front 591 -- both CVSD titles, i.e.
  // this static Family2 path. An earlier pass concluded "only term2 uses ENV"
  // and skipped it here; that pass had measured smashtv/totcarn/mk/term2 and
  // HI/SHI and simply never sampled the two titles that use it most. With ENV
  // unimplemented the core keeps painting stale VRAM through a blank the game
  // asked for, which on a cabinet is indistinguishable from a FROZEN picture --
  // Strike Force's "renders the top HUD, then freezes" report.
  //
  // Same reset domain as the width tracker: video_rst, NOT video_phase_rst.
  // DPYCTL is written by the same CRTC init table (before HTOTAL's
  // timing_start) so resetting on the phase pulse would wipe it -- the exact
  // no-op that shipped once as YUnitWidth_20260816.
  logic        crtc_env;
  wire         dpyctl_we = tms_display_wr_valid && (tms_display_wr_idx == IO_IDX_DPYCTL);
  always_ff @(posedge clk) begin
    if (video_rst) begin                  // NOT video_phase_rst -- see above
      crtc_heblnk <= 12'd45;              // Smash's values as the pre-CRTC default,
      crtc_hsblnk <= 12'd250;             // so behaviour before programming is unchanged
      crtc_env    <= 1'b1;                // display ENABLED until the game says otherwise
    end else begin
      if (heblnk_we) crtc_heblnk <= tms_display_wr_data[11:0];
      if (hsblnk_we) crtc_hsblnk <= tms_display_wr_data[11:0];
      if (dpyctl_we) crtc_env    <= tms_display_wr_data[15];
    end
  end
  // Derived, not sequenced: both registers are written once during CRTC init,
  // so a one-cycle settle is irrelevant and this stays trivially reviewable.
  // hsblnk <= heblnk would underflow, so the sign bit falls back to H_ACT.
  wire [12:0] crtc_w  = {1'b0, crtc_hsblnk} - {1'b0, crtc_heblnk};
  wire [13:0] crtc_px = {crtc_w, 1'b0};                 // * pixperclock (2)
  wire [11:0] visible_px = (crtc_w[12] || crtc_px > 14'(H_ACT))
                           ? 12'(H_ACT) : crtc_px[11:0];

  wire       dpystrt_we    = tms_display_wr_valid
                             && (tms_display_wr_idx == IO_IDX_DPYSTRT);
  wire [8:0] dpystrt_row_w = ~tms_display_wr_data[12:4];   // tms34010.cpp:1150-1152

  logic [8:0] dpystrt_row_pend, dpystrt_row_ref, disp_row_dyn;
  logic       dpystrt_ref_set, disp_vblank_q;
  // Flip counter for the DIAG overlay. A FROZEN counter is ambiguous (dead tap
  // reads the same as a title that never flips), so the overlay pairs it with
  // the live/pending/reference rows -- read them together, never alone.
  logic [31:0] dpystrt_flip_cnt;

  // Effective base as of RIGHT NOW. Consumers latch it on their own frame edge.
  // dpystrt_row_pend is ALREADY the gospel row (complemented at capture), so the
  // base is that row directly. DISP_ROW0 is now strictly the pre-first-write
  // default -- it is NOT an offset, and adding it would double-count.
  wire [8:0] disp_row_next = dpystrt_ref_set ? dpystrt_row_pend : 9'(DISP_ROW0);

  always_ff @(posedge clk) begin
    if (video_phase_rst) begin
      dpystrt_row_pend <= 9'(DISP_ROW0);
      dpystrt_row_ref  <= 9'd0;
      dpystrt_ref_set  <= 1'b0;
      disp_row_dyn     <= 9'(DISP_ROW0);
      disp_vblank_q    <= 1'b0;
      dpystrt_flip_cnt <= 32'd0;
    end else begin
      disp_vblank_q <= vblank;
      if (dpystrt_we) begin
        dpystrt_row_pend <= dpystrt_row_w;
        if (dpystrt_ref_set && (dpystrt_row_w != dpystrt_row_pend))
          dpystrt_flip_cnt <= dpystrt_flip_cnt + 32'd1;
        if (!dpystrt_ref_set) begin
          dpystrt_row_ref <= dpystrt_row_w;   // first write sets the reference
          dpystrt_ref_set <= 1'b1;
        end
      end
      // Kept ONLY for autoerase and the diag overlay. The VIDEO path no longer
      // uses this register: it latches disp_row_next itself off the same vblank
      // edge its prefetcher uses. Latching here off `vblank` (s3) while the
      // prefetcher primes off `vblank_raw` (s0) is what left the line buffers
      // holding the old page while the address asked for the new one.
      if (vblank && !disp_vblank_q)
        disp_row_dyn <= disp_row_next;
    end
  end

  // PER-FRAME RAW-SPACE ERASE GUARD (2026-08-18, the SF/Saurian phantom-erase
  // fix; see stv_vram_ddr_top erase_line_valid note for the full mechanism).
  // MAME's autoerase guard `scanline < 510` (midyunit_v.cpp:538) runs on the
  // UNMASKED rowaddr, so a window that wraps physical row 511 (base 511: raw
  // rows 511..765) is NEVER autoerased by real hardware. The 9-bit base is
  // sufficient to detect the wrap: base + V_ACT > 512 <=> the window aliases,
  // and for every MEASURED base (0/255/256/511; mame-trace/page_usage.lua)
  // this frame-level verdict equals gospel's per-line one exactly (bases
  // 0/255/256 never produce a target >= 510 that trig_row_ok does not already
  // exclude; base 511 is disabled outright). Unmeasured mid-frame-crossing
  // bases (257..510) would under-erase their head rows here -- the FULL
  // config's sequencer events are exact for those; documented residual.
  //
  // GOSPEL-VERIFIED 2026-08-19 (MAME 0.289 c531ffa701, midyunit_v.cpp:534-554):
  // base 255 produces targets 254..509, all valid when armed. Sequencer builds
  // use the exact per-line events above; this coarser frame verdict exists only
  // for the legacy snoop-trigger fallback.
  logic erase_frame_raw_ok;
  always_ff @(posedge clk) begin
    if (video_phase_rst)
      erase_frame_raw_ok <= 1'b1;
    else if (vblank && !disp_vblank_q)
      erase_frame_raw_ok <= (({1'b0, disp_row_next} + 10'(V_ACT)) <= 10'd512);
  end

`ifdef YUNIT_DISPLAY_SEQ
  wire full_video_snoop_we = fb_snoop_we;
  wire [17:0] full_video_snoop_addr = fb_snoop_addr;
  wire [15:0] full_video_snoop_data = fb_snoop_data;
  yunit_video_top #(
    .H_ACT(H_ACT), .H_FP(H_FP), .H_SYNC(H_SYNC), .H_BP(H_BP),
    .V_ACT(V_ACT), .V_FP(V_FP), .V_SYNC(V_SYNC), .V_BP(V_BP),
    // Refill exactly the displayed wrapped window.  A 512-word single-beat
    // refill exceeds the physical line budget; H_ACT leaves measured headroom.
    .DISP_ROW0(DISP_ROW0), .NCOL(H_ACT)
  ) u_video (
    .clk(clk), .rst(video_phase_rst), .ce_pix(ce_pix), .bpp4(game_bpp4),
    .use_dynamic_display(1'b1),
    .display_contract_valid(display_contract_valid),
    .display_line_event(display_line_event),
    .display_line_valid(display_scanout_valid),
    .display_line_row_phys(display_scanout_row_phys),
    .display_line_col_word(display_scanout_col_word),
    .display_prefetch_valid(display_prefetch_valid),
    .display_prefetch_row_phys(display_prefetch_row_phys),
    .display_prefetch_col_word(display_prefetch_col_word),
    // Runtime CRTC width (crtc_heblnk/crtc_hsblnk tracker above): mkla1 400,
    // totcarn 400, term2 404 px measured on MAME 0.289 vs the raster's 410.
    .visible_px(visible_px),
    .flip_x(yunit_flip_x(game_id)),
    .snoop_we(full_video_snoop_we),
    .snoop_addr(full_video_snoop_addr), .snoop_data(full_video_snoop_data),
    // The DDR3 backend performs its beam-locked erase internally and keeps its
    // physical row cache coherent; there is no separate completed-row event.
`ifdef YUNIT_SRT_FILL_BURST
    .invalidate_valid(sr_invalidate_valid), .invalidate_row(sr_invalidate_row),
`else
    .invalidate_valid(1'b0), .invalidate_row(9'd0),
`endif
    .pal_raddr(pal_raddr), .pal_rdata(pal_rdata),
    .scan_req(scan_req), .scan_addr(scan_addr),
    .scan_data(scan_data), .scan_ack(scan_ack),
    .vid_r(vid_r), .vid_g(vid_g), .vid_b(vid_b),
    .hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank), .de(de),
    .vblank_irq(vblank_irq));
`else
  yunit_video_top_family2 #(
    .H_ACT(H_ACT), .H_FP(H_FP), .H_SYNC(H_SYNC), .H_BP(H_BP),
    .V_ACT(V_ACT), .V_FP(V_FP), .V_SYNC(V_SYNC), .V_BP(V_BP),
    // P0023 (VRAM-bandwidth stopgap): prefetch only the VISIBLE columns (H_ACT=410), not a full
    // 512-word VRAM row. The scanline loader refetched all 512 cols/line as burst-less single reads
    // (~6144 sys-clk) vs a ~6072-clk line budget -> 1.012x oversubscribed -> scanout owned the port
    // ~100% of every active line and starved the CPU's VRAM writes to the vblank sliver (~11% duty),
    // which is why the POST full-screen clears crawled. Smash T.V. shows cols 0..409 (yunit_video_family2.sv:27,
    // col = s0_x&0x1ff, s0_x<=409), so 410..511 were pure over-fetch. 410*12=4920 < 6072 -> fits in a
    // line with headroom. Real fix (burst) follows; this is the near-zero-risk direction-confirm.
    .DISP_ROW0(DISP_ROW0), .NCOL(H_ACT)
  ) u_video (
    .clk(clk), .rst(video_phase_rst), .ce_pix(ce_pix), .bpp4(game_bpp4),
    .disp_row_next(disp_row_next),
    .visible_px(visible_px),
    .disp_enable(crtc_env),
    .snoop_we(fb_snoop_we), .snoop_addr(fb_snoop_addr), .snoop_data(fb_snoop_data),
    .pal_raddr(pal_raddr), .pal_rdata(pal_rdata),
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
    .vid_r(vid_r), .vid_g(vid_g), .vid_b(vid_b),
    .hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank), .de(de),
    .vblank_irq(vblank_irq));
`endif

  // ---- palette mirror (video read port) --------------------------------------
  yunit_palram #(.AW(13)) u_pal (
    .clk(clk), .rst(core_rst),
    .we_a(palv_we_a), .aa(palv_aa), .awd(palv_awd),
    .we_b(palv_we_b), .ba(palv_ba), .bwd(palv_bwd),
    .raddr({1'b0, pal_raddr}), .rdata(pal_rdata));

  // ---- SDRAM arbiter + physical controller -----------------------------------
  logic [24:0] sd_addr; logic [15:0] sd_din, sd_dout; logic [1:0] sd_be; logic sd_rd, sd_wr, sd_ack;
  logic        iol_ack;

  // ioctl SDRAM-write path + HPS backpressure via a FIFO. hps_io does NOT gate its byte
  // stream on ioctl_wait — the ARM polls ioctl_wait (HPS_BUS[37]) and pauses with a ROUND-
  // TRIP LATENCY of many clks (bus + software). Meanwhile sdram_stock writes each ROM byte
  // slowly (ACTIVATE+WRITE+auto-precharge, ~12 clk). During that latency MANY bytes arrive:
  // a single latch (or a 1-deep skid) DROPS them — measured with +IOLSTRESS: 33% lost at
  // latency 2, 50% at 3, 72% at 6 -> Swiss-cheesed program ROM -> the CPU reads ~0 and
  // marches from 0 (the exact cab capture). So buffer the download in a FIFO deep enough to
  // absorb the HPS round-trip, and assert ioctl_wait at a high-water mark that leaves enough
  // headroom for the still-in-flight bytes. (+IOLSTRESS shows this FIFO loses 0 up to L~256.)
  localparam int IOL_AW  = 9;                       // 512-deep
  localparam int IOL_HWM = 256;                     // wait high-water mark (256 slots headroom)
  logic [42:0] iol_fifo [0:(1<<IOL_AW)-1];          // {addr[24:0], din[15:0], be[1:0]}
  logic [IOL_AW:0] iol_wp, iol_rp;
  wire  [IOL_AW:0] iol_occ   = iol_wp - iol_rp;
  wire             iol_full  = (iol_occ == (1<<IOL_AW));
  wire             iol_empty = (iol_wp == iol_rp);
  logic        iol_hold;
  logic        unp_owner;
  logic [24:0] iol_addr_r; logic [15:0] iol_din_r; logic [1:0] iol_be_r;
  // P0020 download audit: dbg_iol_drop counts pushes DROPPED on FIFO overflow (should be 0 if
  // ioctl_wait backpressure holds); dbg_iol_wrs counts pushes ACCEPTED (should reach the total
  // FIFO-bound download word count ~0xD0000). Displayed on the DIAG_BOOT overlay to prove/refute
  // "the program ROM reads 0 because the download drops words on real hps_io latency".
  logic [31:0] iol_drop_cnt, iol_wr_cnt;
  always_ff @(posedge clk) begin
    if (sdram_por) begin iol_wp <= '0; iol_rp <= '0; iol_hold <= 1'b0; iol_drop_cnt <= '0; iol_wr_cnt <= '0; end
    else begin
      // PUSH a download word (dropped only on true overflow — prevented by ioctl_wait)
      if (ioctl_wr && !iol_full) begin
        iol_fifo[iol_wp[IOL_AW-1:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
        iol_wp <= iol_wp + 1'b1;
        iol_wr_cnt <= iol_wr_cnt + 1'b1;                 // accepted push
      end
      else if (ioctl_wr && iol_full) iol_drop_cnt <= iol_drop_cnt + 1'b1;  // OVERFLOW DROP
      // DRAIN only while the FIFO owns the shared boot channel. The unpacker
      // holds ownership across its NXT bubbles; otherwise an iol_ack belonging
      // to an unpack request could retire a queued ROM word, or a queued ROM
      // request could replace the address beneath an in-flight unpack grant.
      // (Ported from the universal top, rtl/yunit/yunit_top.sv:669. The family
      // MRA drops rom_download between ioctl_index 0/1/2 -- see
      // family2/family2_download_mapper.sv:54-57 -- so the unpack arms on the
      // GRAPHICS falling edge and the program+sound streams arrive WHILE it
      // runs: on raw iol_ack every one of those words was silently swallowed.)
      if (!unp_owner) begin
        if (iol_hold && iol_ack) iol_hold <= 1'b0;
        if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin
          {iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[IOL_AW-1:0]];
          iol_hold <= 1'b1;
          iol_rp   <= iol_rp + 1'b1;
        end
      end
    end
  end
  assign ioctl_wait = (iol_occ >= IOL_HWM[IOL_AW:0]);

  // gfx-unpack master (boot only). unp_rd/wr/addr/din come FROM the unpack FSM; its
  // dout/ack are driven from the shared boot iol channel below.
  logic        unp_rd, unp_wr, unp_ack;
  logic [24:0] unp_addr; logic [15:0] unp_din, unp_dout;

  // Boot SDRAM channel = ioctl download (write, via the iol_hold latch) MUXED WITH the
  // gfx-unpack (rd+wr). Ownership is held for the complete unpack SESSION, including
  // its request-free NXT bubbles (yunit_gfx_unpack.sv:53,123 -- NXT drives neither
  // unp_rd nor unp_wr), so an arbiter grant can never see its address/control bus
  // change owners before acknowledgement. Selecting on the combinational
  // (unp_rd | unp_wr) instead drops the mux back to the download every bubble.
  // Folding both boot users into the single iol channel keeps the run-time address
  // mux short.
  wire        b_iol_rd   = unp_owner ? unp_rd   : 1'b0;
  wire        b_iol_wr   = unp_owner ? unp_wr   : iol_hold;
  wire [24:0] b_iol_addr = unp_owner ? unp_addr : iol_addr_r;
  wire [15:0] b_iol_din  = unp_owner ? unp_din  : iol_din_r;
  wire [1:0]  b_iol_be   = unp_owner ? 2'b11    : iol_be_r;
  wire [15:0] iol_dout;
  assign unp_dout = iol_dout;
  assign unp_ack  = iol_ack & unp_owner & (unp_rd | unp_wr);

  yunit_sdram_arb #(
    .SD_AW(25), .GFXW_BASE(GFXW_BASE), .ROMW_BASE(ROMW_BASE),
    // P1.4: the arb's gfx/ROM byte split MUST equal the mem's GFX_PIXELS --
    // they are two halves of one address map (mem emits cgfx byte addresses,
    // the arb translates them).  The recovery clone hardcoded Smash's proven
    // 0x180000 on BOTH sides while sinking the wrapper parameter; family2
    // passes the wrapper parameter to BOTH sides instead, so the family map
    // (8MB gfx, ROM at word 0x400000) holds end to end.  The download mapper
    // writes program ROM at ROMW_BASE directly, which the family constants
    // place exactly at GFXW_BASE + GFX_BYTES/2 -- the three agree.
    .VRAMW_BASE(VRAMW_BASE), .GFX_BYTES(GFX_BYTES), .SOUNDW_BASE(SOUNDW_BASE)
  ) u_arb (
    .clk(clk), .rst(sdram_por),                 // P0022: persistent SDRAM subsystem -> POR, not core rst
`ifdef USE_DDR3_VRAM
    // VRAM moved to DDR3 -> the SDRAM arbiter's VRAM channel is unused (this is the whole point:
    // SDRAM now serves only cgfx/prog-ROM/boot-IOL, so scanout no longer starves the CPU).
    .vsd_addr(25'd0), .vsd_din(16'd0), .vsd_be(2'd0), .vsd_rd(1'b0), .vsd_wr(1'b0),
    .vsd_dout(), .vsd_ack(),
`else
    .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr),
    .vsd_dout(vsd_dout), .vsd_ack(vsd_ack),
`endif
    .cgfx_rd(cgfx_rd), .cgfx_addr(cgfx_addr), .cgfx_data(cgfx_data), .cgfx_ack(cgfx_ack),
`ifdef USE_DDR3_VRAM
    // cont.24: blitter src is served by yunit_src_cache via the brd_* burst port -- the arb's
    // single-word src channel is bypassed (would double-drive src_data/src_ack if connected).
    .src_rd(1'b0), .src_addr(24'd0), .src_data(), .src_ack(),
`else
    .src_rd(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
`endif
    // Later universal-Y arbiter extension; disabled for the firefix CVSD path.
    .snd_rd(sndrom_rd), .snd_addr(sndrom_addr),
    .snd_data(sndrom_data), .snd_wdata(sndrom_wdata), .snd_ack(sndrom_ack),
    .iol_rd(b_iol_rd), .iol_wr(b_iol_wr), .iol_addr(b_iol_addr), .iol_din(b_iol_din),
    .iol_be(b_iol_be), .iol_dout(iol_dout), .iol_ack(iol_ack),
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
    .sd_dout(sd_dout), .sd_ack(sd_ack));

  // ---- gfx planar->flat unpack (boot only) -----------------------------------
  // Synth: run the pass once when the ROM download drops, holding the core (via
  // unp_done) until it completes. Sim: the tb preloads the flat gfx directly, so we
  // tie unp_done=1 and leave the unp channel idle (identical to the proven boot tb).
`ifdef SYNTHESIS
  // SRC-1b: ARM ON THE LAST INDEX, NOT ON EVERY INDEX.
  // The MRA presents one ioctl_download pulse PER PART, so arming on
  // ioctl_download's falling edge fires the unpack up to three times, and every
  // pass after the first runs CONCURRENTLY with the next part's stream.
  // unp_owner makes that concurrency safe (no ack theft), but it pays for the
  // safety with ioctl_wait backpressure against the ARM transmit path -- an
  // untested exposure -- plus ~+1.2 s of boot time.
  //
  // All ten shipping MRAs order their parts 3, 4, 0, 1, 2 -- sound (index 2) is
  // LAST for every title (tools/generate_yunit_mras.py:305-312 hardcodes that
  // order; measured over all 60 generated MRAs by
  // sim/probe/src1b/check_mra_index_contract.py). So the falling edge of
  // sound_download IS "the last part finished": arming on it makes the unpack
  // strictly serial with every stream, the ack theft UNREACHABLE rather than
  // merely mitigated, and the backpressure gone.
  //
  // SCOPED TO THIS TOP ONLY. Do NOT port to rtl/yunit/yunit_top_smash_firefix.sv:
  // under YUNIT_SMASH_RECOVERY, Arcade-SmashTV.sv:569 defines sound_download by
  // ADDRESS WINDOW inside a single index-0 stream, so its falling edge lands
  // MID-download and would fire the unpack early on the cabinet-good build.
  //
  // CONTRACT (machine-checked by sim/probe/src1b/check_mra_index_contract.py):
  // every MRA must carry an index-2 part and no higher index may follow it.
  // Violating it means sound_download never falls -> no unpack -> core_rst held
  // -> silent black screen.
  logic sdl_q, dl_seen, unp_pending, unp_start, unp_fsm_done, unp_done_q;
  always_ff @(posedge clk) begin
    sdl_q     <= sound_download;
    unp_start <= 1'b0;
    unp_done_q <= unp_fsm_done;
    if (sdram_por) begin dl_seen <= 1'b0; unp_pending <= 1'b0; unp_owner <= 1'b0;
                       unp_done_q <= 1'b0; end
                                                                    // P0022: dl_seen must be SET during
                                                                    // download (rst is high then) -> POR
    else begin
      if (ioctl_download) dl_seen <= 1'b1;                 // a ROM download occurred
      if (sdl_q & ~sound_download)     unp_pending <= 1'b1; // LAST part (index 2) just ended
      else if (unp_pending & ~iol_hold & ~unp_owner) begin // last iol write drained ->
        unp_pending <= 1'b0; unp_start <= 1'b1;             // fire the unpack (1-cyc pulse)
        unp_owner   <= 1'b1;                                // ACQUIRE the shared boot channel
      end


      // RELEASE on the COMPLETION EDGE, never on the level.  unp_fsm_done is a LEVEL
      // (yunit_gfx_unpack.sv:82, done = (st == FINI)) and it is ALREADY HIGH when a
      // re-arm acquires ownership out of FINI -- the title-switch path that
      // yunit_gfx_unpack.sv:125-142 exists to support (every Y-unit MRA names the same
      // rbf, so a title change is another ioctl download into the RUNNING core).  A
      // level release drops ownership one cycle after acquiring it: unp_ack is gated
      // off forever, the FSM stalls in RD0, unp_done never rises and core_rst is held
      // -- a black screen on every title change after the first.  Measured by
      // sim/probe/impl-tc-hi/tb_iol_ownership.sv (serial scenario, unpack pass 2).
      if (unp_owner && unp_fsm_done && !unp_done_q) unp_owner <= 1'b0;
    end
  end
  yunit_gfx_unpack #(
    .SD_AW(25), .SCRATCH_WBASE(SCRATCH_WBASE), .GFXW_BASE(GFXW_BASE),
    .PLANE_WORDS(PLANE_WORDS)
  ) u_unpack (
    // Explicitly select the legacy 3-plane/6bpp path added as the default/X
    // fallback by the later universal unpacker.
    .clk(clk), .rst(sdram_por), .start(unp_start),
    .plane_words(game_plane_words), .bpp4(game_bpp4),
    .busy(), .done(unp_fsm_done),  // P0022: runs during the
                                                                                  // RESET-high post-download window
    .unp_rd(unp_rd), .unp_wr(unp_wr), .unp_addr(unp_addr), .unp_din(unp_din),
    .unp_dout(unp_dout), .unp_ack(unp_ack));
  // Only REQUIRE the unpack once a download has actually happened. With no download
  // (a soft reset that keeps the already-unpacked gfx in SDRAM, or a preloaded sim),
  // dl_seen=0 -> unp_done=1 so the CPU boots on the existing flat gfx.
  assign unp_done = ~dl_seen | unp_fsm_done;
`else
  assign unp_owner = 1'b0;
  assign unp_done = 1'b1;
  assign unp_rd = 1'b0; assign unp_wr = 1'b0; assign unp_addr = 25'd0; assign unp_din = 16'd0;
`endif

  // ---- P2 (cont.23) page-mode scanout row-cache (SDRAM path) ---------------------
  // Serves the video's scan_req from a per-scanline BRAM cache, burst-filling each row from SDRAM
  // in ONE ACTIVATE via sdram_stock's brd_* port (8% of the line budget, vs the single-beat
  // scanout's 76% oversubscription — P0023). Replaces vram_sdram_top's single-beat scanout (tied
  // off above). DDR3 build keeps its own row-cache in stv_vram_ddr_top -> brd_* tied off there.
  wire        brd_req;  wire [24:0] brd_addr;  wire [9:0] brd_len;
  wire [15:0] brd_dout;  wire brd_dvalid, brd_done;
`ifndef USE_DDR3_VRAM
 `ifdef USE_SDRAM_VRAM
  `ifdef SDRAM_SINGLEBEAT_SCANOUT
  assign brd_req = 1'b0; assign brd_addr = 25'd0; assign brd_len = 10'd0;   // ISOLATION: page-mode off
  `else
  vram_sdram_scanout #(.VRAM_WBASE(VRAMW_BASE)) u_scanout (
    .clk(clk), .rst(sdram_por),
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
    .brd_req(brd_req), .brd_addr(brd_addr), .brd_len(brd_len),
    .brd_dout(brd_dout), .brd_dvalid(brd_dvalid), .brd_done(brd_done));
  `endif
 `else
  // USE_HW_VRAM PROBE STUB: the BRAM framebuffer (yunit_mem_family2.vram) has no scanout READ port yet.
  // Feed the video a constant black pixel (scan_data=0, scan_ack=1) so it builds, and tie the SDRAM
  // page-mode burst port off. NOT a real scanout -- M10K-count probe only. No second BRAM port added.
  assign brd_req = 1'b0; assign brd_addr = 25'd0; assign brd_len = 10'd0;
  assign scan_data = 16'd0; assign scan_ack = 1'b1;
 `endif
`else
  // cont.24: DDR3 build -- the scanout row-cache lives in stv_vram_ddr_top, so the SDRAM
  // page-mode burst port is FREE. It now feeds the blitter SOURCE-READ streaming cache
  // (16-word ring, 8-word page-mode sub-bursts): readmode source bytes stream at ~3 clk/px
  // instead of one full lowest-priority single-word round trip per PIXEL -- the title-splash
  // "sprites missing / flashing in and out" root cause (DMAQ overflow cans the OBJLST tail;
  // NDSP1.ASM:646-648). The arb's src channel is bypassed entirely (tied off below).
  yunit_src_cache #(.GFXW_BASE(GFXW_BASE[23:0])) u_srccache (
    .clk(clk), .rst(core_rst),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .brd_req(brd_req), .brd_addr(brd_addr), .brd_len(brd_len),
    .brd_dout(brd_dout), .brd_dvalid(brd_dvalid), .brd_done(brd_done));
`endif

  // ---- stock SDRAM controller (Sorgelig) + arbiter adapter ----------------------
  // Replaces the hand-rolled sdram_phy. The stock controller forwards SDRAM_CLK via a DDIO
  // I/O cell (not a fabric assign) and uses the DE10-proven CAS-latency read capture — the
  // fix for reads landing in the wrong window on real silicon. The adapter bridges the
  // arbiter's held sd_rd/sd_wr/ack handshake to the controller's edge we/rd + `ready` level.
  // `init`=rst (level high during reset); the controller runs its power-up sequence when it
  // drops. sdram_ready comes from the adapter (latches the controller's first ready).
  logic [24:0] ctl_addr; logic [15:0] ctl_din, ctl_dout; logic [1:0] ctl_wtbt;
  logic        ctl_rd, ctl_we, ctl_ready;

  yunit_sdram_adapter u_sdadapt (
    .clk(clk), .rst(sdram_por),                 // P0022: persistent SDRAM subsystem -> POR, not core rst
    .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
    .sd_dout(sd_dout), .sd_ack(sd_ack), .sdram_ready(sdram_ready),
    .ctl_addr(ctl_addr), .ctl_din(ctl_din), .ctl_wtbt(ctl_wtbt),
    .ctl_rd(ctl_rd), .ctl_we(ctl_we), .ctl_dout(ctl_dout), .ctl_ready(ctl_ready));

  sdram_stock u_sdram (
    .init(sdram_por), .clk(clk),                // P0022: SDRAM inits once at true power-on, not core rst
    .addr(ctl_addr), .din(ctl_din), .wtbt(ctl_wtbt), .we(ctl_we), .rd(ctl_rd),
    .dout(ctl_dout), .ready(ctl_ready),
    .brd_req(brd_req), .brd_addr(brd_addr), .brd_len(brd_len),   // P2b page-mode scanout burst
    .brd_dout(brd_dout), .brd_dvalid(brd_dvalid), .brd_done(brd_done),
    // Later universal-Y page-mode write extension; the exact firefix source
    // cache is read-only on this SDRAM port.
    .bwr_req(1'b0), .bwr_addr(25'd0), .bwr_len(10'd0),
    .bwr_din(16'd0), .bwr_wtbt(2'b00), .bwr_valid(1'b0),
    .bwr_ready(), .bwr_done(),
    .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA),
    .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH),
    .SDRAM_nCS(SDRAM_nCS), .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nCAS(SDRAM_nCAS),
    .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE));

  // ---- sound-latch CDC: clk -> clk_snd ---------------------------------------
  // MAME passes D[9] as the PIA CB1 level and ~D[8] as the sound-CPU reset
  // (midyunit_m.cpp:650-663). The game emits close write pairs (FDxx->FFxx and
  // FE00->FFFF); a raw 2-FF level crossing can miss the intervening low/high
  // level entirely at 12 MHz. Stretch those active levels in clk_sys, then
  // synchronize them while preserving the board-visible CB1 protocol.
  logic [7:0] sel_sync;
  logic       strig_snd, srst_snd;
  yunit_sound_cdc u_sound_cdc (
    .clk_sys(clk), .clk_snd(clk_snd), .rst_pon(rst_pon),
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .sel_snd(sel_sync), .trig_snd(strig_snd), .reset_snd(srst_snd));

  logic [7:0]  pia_audio; logic [15:0] speech_out;
  logic signed [15:0] ym_l, ym_r; logic [31:0] snd_dbg;

  // ---- large-CVSD external sound ROM (P1.4; port of the family top's FSM) --
  // High Impact / Super High Impact / the test ROM ship CVSD sets bigger than
  // the three 64 KiB BRAMs; their bytes live in SDRAM at SOUNDW_BASE (the
  // download mapper's index-2 packed stream).  The 6809 changes its ROM
  // address at only ~2 MHz, so fetch the current byte from 96 MHz SDRAM and
  // retain it -- same one-sound-clock visible latency as the BRAM path.
  // Smash-class small sets keep the cabinet-proven BRAM images (use_ext=0).
  // ---- CVSD sound-ROM RESIDENCE ------------------------------------------
  // MEASURED (family2 fit, output_files/Arcade-SmashTV.fit.rpt): the three
  // 64 KiB smashtv_snd_rom BRAMs cost 192 of the CVSD board's 203 M10Ks --
  // 35% of the whole device's block RAM to hold 192 KiB of samples. Moving
  // them to SDRAM is what makes room for a single core carrying every title.
  //
  // The external path is NOT new: High Impact, Super High Impact and the Test
  // ROM already run this way because their sets never fit the BRAMs. And the
  // bytes are already in SDRAM for EVERY title -- family2_download_mapper
  // writes each sound byte to SOUNDW_BASE unconditionally, in addition to the
  // BRAM stream. So the default below consumes data that was already there.
  //
  // REVERT: build with +define+YUNIT_CVSD_BRAM_SOUND to restore the exact
  // prior behaviour (per-title selection, BRAM images live). This is the
  // documented escape hatch if the cabinet shows a CVSD sound regression --
  // Smash T.V.'s sound is cabinet-proven on the BRAM path, and this moves it.
  // Both states are pinned: sim/postconv/check_cvsd_sound_residence.py fails
  // if the default silently changes, and the elaboration gate forbids
  // smashtv_snd_rom unless the revert define is present.
`ifdef YUNIT_CVSD_BRAM_SOUND
  wire use_ext_cvsd = (yunit_sound_type(game_id) == YS_CVSD_LARGE);
  wire cvsd_dl_we   = snd_dl_wr;
`else
  wire use_ext_cvsd = 1'b1;   // every CVSD title streams from SDRAM
  // The BRAMs must lose their WRITE driver too, or Quartus keeps all 192
  // M10Ks alive for a memory nothing reads.
  wire cvsd_dl_we   = 1'b0;
`endif
  // Mortal Kombat / Terminator 2 / Total Carnage carry the Williams D-11581
  // ADPCM board instead of the CVSD one. Both are external-ROM clients of the
  // same SOUNDW_BASE region and exactly one is ever active for a given
  // game_id, so they share this single cached-byte fetch FSM rather than
  // each opening its own SDRAM port.
  //
  // FULL carries both physical boards and selects the active one at runtime.
  // Each board has its own JT51/YM2151, and ADPCM also adds a 6809 + JT6295;
  // moving CVSD program/sample storage out of three 64 KiB BRAM images and
  // into the already-populated SDRAM sound region is what made that fit viable.
  // The smaller YUNIT_FAMILY2 engineering flavour remains CVSD-only.
`ifdef YUNIT_ADPCM
  // ADPCM sibling: every title in this core is an ADPCM title, so the board is not selected
  // at runtime -- it is the only board present. Constant-folding this also lets the fitter
  // delete the CVSD board's audio mux leg entirely.
  wire use_adpcm    = 1'b1;
`elsif YUNIT_FULL
  wire use_adpcm    = (yunit_sound_type(game_id) == YS_ADPCM);
`else
  wire use_adpcm    = 1'b0;
`endif
  logic [20:0] cvsd_ext_addr;
  wire  [20:0] adpcm_ext_addr;
  logic        sndrom_rd, sndrom_ack;
  logic [20:0] sndrom_addr;
  logic [7:0]  sndrom_data;
  logic [15:0] sndrom_wdata;
`ifdef PROFILE_BOOT_QUIET_SOUND
  // The all-profile CPU/video gate intentionally removes the 12 MHz sound
  // clocks; its sound service/cache/boards are covered by separate exact
  // gates.  With those clocks stopped, ADPCM's address register cannot leave
  // X in simulation.  Do not let an inactive X-valued client launch a bogus
  // SDRAM read just before the main CPU's reset-vector fetch.
  wire use_ext_snd = 1'b0;
  wire [20:0] sound_ext_addr = 21'd0;
`else
  wire use_ext_snd = use_ext_cvsd | use_adpcm;
  wire [20:0] sound_ext_addr = use_adpcm ? adpcm_ext_addr : cvsd_ext_addr;
`endif

  // ---- sound-ROM WORD CACHE + SEQUENTIAL PREFETCH -------------------------
  // MEASURED CABINET SYMPTOM: Smash T.V. sound played slow and pitched down
  // while game pacing was unaffected -- the signature of the 6809 stalling,
  // since CVSD playback rate is set by 6809 execution speed and the game runs
  // in a different clock domain.
  //
  // The previous FSM cached ONE BYTE. The board asserts
  //     cpu_rom_wait = use_ext_rom & rom_cs & read & (~ext_rom_ok | ~ext_ok_snd)
  // and the 6809 changes address on essentially every fetch, so every read
  // missed, and each miss cost a full 96 MHz SDRAM round-trip PLUS a 2-FF sync
  // back into the 12 MHz sound domain (~167 ns of sync alone, against a ~500 ns
  // 6809 cycle). The stall was per-byte and unavoidable.
  //
  // Two things fix it, both essentially free:
  //   1. The SDRAM read already returns 16 bits and the arbiter discarded half.
  //      Caching the WORD serves the companion byte with no fetch -- and 6809
  //      code is overwhelmingly sequential, so that is every other byte.
  //   2. Prefetch the NEXT word while the CPU is consuming the current one.
  //      A sequential run then never misses, and ext_rom_ok never drops, so the
  //      wait-state never asserts and the CDC sync is off the critical path.
  // A non-sequential jump still costs one miss, exactly as before.
  //
  // ok/data are combinational on a hit, so a cached byte costs zero cycles.
  //
  // RC5 -- CACHE RESET MUST ALSO COVER THE DOWNLOAD WINDOW.
  // sdram_por (Arcade-SmashTV.sv:663-664) is a 2-FF-synced ~locked: it drops at PLL
  // lock, LONG BEFORE ioctl_download (that is the whole point of P0022 -- the capture
  // path must keep running across the download).  So across the entire ROM download the
  // cache is OUT of reset, `active` is already high (game_id/MRA index 3 lands first),
  // and the CVSD 6809 is held in reset by snd_reset -- which pins its address bus.
  // mc6809is.v:1720-1722 drives ADDR = 16'hFFFF for every cycle nRESET is low, and
  // williams_cvsd_board.vhd:398/:570-577 latch ext_rom_addr_r only on rom_cs (= A15), so
  // the frozen client address is 0x07FFF -- the RESET-VECTOR word.  The cache therefore
  // fills its current/prefetch entries from PRE-IMAGE SDRAM and, because a hit never
  // re-fetches, still holds them when the 6809 is released: the 6809 reads its reset
  // vector out of the stale entry.
  // Holding the cache in reset for the download window costs nothing (its only clients
  // are held in reset there too) and guarantees the first post-release fetch is a miss.
  wire sound_ext_ok;
  wire [7:0] cvsd_ext_data;
  yunit_sound_rom_cache u_sound_rom_cache (
    .clk(clk), .rst(sdram_por | ioctl_download), .active(use_ext_snd),
    .client_addr(sound_ext_addr), .client_data(cvsd_ext_data),
    .client_ok(sound_ext_ok),
    .mem_rd(sndrom_rd), .mem_addr(sndrom_addr),
    .mem_rdata(sndrom_wdata), .mem_ack(sndrom_ack));

  // BOTH sound boards are present in the full core and selected per title at
  // runtime by game_id -- the Y-unit family genuinely shipped two different
  // sound boards, and one core serving every title has to carry both.
  //
  // That only became affordable once CVSD sound moved to SDRAM: the three
  // 64 KiB smashtv_snd_rom BRAMs measured 192 of 553 device M10Ks, and the
  // ADPCM board's second YM2151 costs only ~9 because its samples already
  // stream from SDRAM. Carrying both boards is now cheaper than carrying the
  // CVSD board's sample BRAMs alone used to be.
  // The ADPCM sibling carries NO CVSD board. Every title in that core is an ADPCM title, so
  // the board is dead weight (measured: 11 M10K, 3061 ALM, 1 DSP) and its 6809/YM2151 would
  // otherwise free-run on whatever byte the shared sound cache happened to hold.
  logic signed [15:0] cvsd_l, cvsd_r;
`ifndef YUNIT_ADPCM
  williams_cvsd_board u_board (
    .clock_12(clk_snd), .reset(srst_snd), .reset_pon(rst_pon),
    .sound_select(sel_sync), .sound_trig(strig_snd), .game_id(game_id),
    .pia_audio(pia_audio), .speech_out(speech_out),
    .ym2151_left(ym_l), .ym2151_right(ym_r), .dbg_out(snd_dbg),
    // MRA sound-ROM load (ioctl clk domain -> board's dual-clock ROM BRAMs)
    .snd_dl_clk(clk), .snd_dl_addr(snd_dl_addr),
    .snd_dl_data(snd_dl_data), .snd_dl_we(cvsd_dl_we),
    .use_ext_rom(use_ext_cvsd), .ext_rom_addr(cvsd_ext_addr),
    .ext_rom_data(cvsd_ext_data), .ext_rom_ok(sound_ext_ok));

  // ---- Williams CVSD-board mono mix -----------------------------------------
  // The real board and MAME device have one mono mixer. yunit_audio_mix sums
  // both YM outputs at x0.10 each, normalizes the unsigned MC1408 before x0.25,
  // applies CVSD x0.60 with DC removal, saturates, and duplicates mono to L/R.
  yunit_audio_mix u_audio_mix (
    .clk(clk_snd), .rst(rst_pon), .ym_l(ym_l), .ym_r(ym_r),
    .speech_u(speech_out), .pia_u(pia_audio), .audio_l(cvsd_l), .audio_r(cvsd_r));
`else
  // ADPCM sibling: no CVSD board, no CVSD mixer. Tie its outputs off so the audio mux below
  // and the shared sound-ROM address mux stay structurally valid and constant-fold away.
  assign cvsd_l = 16'sd0;
  assign cvsd_r = 16'sd0;
  assign cvsd_ext_addr = 21'd0;
`endif

  // ---- Williams D-11581 ADPCM board (Mortal Kombat / T2 / Total Carnage) ----
  // Transcribed from MAME's williams_adpcm_sound_device and gated by
  // tb_yunit_adpcm_map (register map, banking, delayed external-IRQ clear)
  // and tb_yunit_adpcm_prot (per-title hidden RAM, midyunit_m.cpp).
  // IN1[14] is the CUSTOM sound-status bit on all three titles, which is why
  // the mapper takes adpcm_irq: MAME midyunit.cpp wires it to this line.
`ifdef YUNIT_FULL
  logic signed [15:0] adpcm_l, adpcm_r;
  yunit_adpcm_board u_adpcm (
    .clk(clk_snd), .reset_pon(rst_pon), .reset(srst_snd),
    .sound_select(sel_sync), .sound_trig(strig_snd), .game(game_id),
    .ext_rom_addr(adpcm_ext_addr), .ext_rom_data(cvsd_ext_data),
    .ext_rom_ok(sound_ext_ok & use_adpcm),
    // fixed-bank BRAM fill (mapper emits RAW 18-bit addresses for ADPCM)
    .snd_dl_clk(clk), .snd_dl_addr(snd_dl_addr),
    .snd_dl_data(snd_dl_data), .snd_dl_we(snd_dl_wr),
    .audio_l(adpcm_l), .audio_r(adpcm_r), .irq_state(adpcm_irq));

  assign audio_l = use_adpcm ? adpcm_l : cvsd_l;
  assign audio_r = use_adpcm ? adpcm_r : cvsd_r;
`else
  assign adpcm_ext_addr = 21'd0;
  assign adpcm_irq      = 1'b0;
  assign audio_l        = cvsd_l;
  assign audio_r        = cvsd_r;
`endif

  // ---- boot-instrument taps (DIAG_BOOT overlay reads these; harmless in normal build) ----
  assign dbg_core_rst    = core_rst;
  assign dbg_sdram_ready = sdram_ready;
  assign dbg_unp_done    = unp_done;
  assign dbg_cpu_req     = cpu_req;
  assign dbg_mem_ack     = mem_ack;
  assign dbg_int1        = int1;         // DMA-done interrupt to the CPU (blit-queue pump)
  assign dbg_vblank_irq  = vblank_irq;   // display/vblank interrupt (per-frame)
  // cont.24 splash-capture: blitter first-source byte + scanout stream (both are yunit_top_family2 wires).
  assign dbg_src_data    = src_data;
  assign dbg_src_ack     = src_ack;
  assign dbg_scan_data   = scan_data;
  assign dbg_scan_ack    = scan_ack;
  assign dbg_cpu_ce      = cpu_ce;       // P0019: /4 CPU clock-enable pulse (liveness)
  assign dbg_disp_flips  = dpystrt_flip_cnt;
  // {ref[8:0], pending[8:0], live[8:0]} -- HI should show live alternating
  // between two values 256 apart; Smash/Trog must show live == 0 always.
  assign dbg_disp_rows   = {4'd0, dpystrt_ref_set, dpystrt_row_ref, dpystrt_row_pend, disp_row_dyn};
  assign dbg_iol_drop    = iol_drop_cnt; // P0020: download words dropped on FIFO overflow
  assign dbg_iol_wrs     = iol_wr_cnt;   // P0020: download words accepted into the FIFO

  // ---- COMBINED reset-vector + derail capture (clk + cpu_ce, i.e. the CPU's step) -------
  // After the FIFO download fix, answer BOTH questions in one flash. Overlay 4 hex rows:
  //   row1 dbg_culprit_pc    = RESET-VECTOR VALUE the CPU read (first ack'd read).
  //                            FFE0F5C0 => ROM finally LANDED + CPU reads it (download fixed);
  //                            0000/garbage => ROM still not reaching the CPU (download or read).
  //   row2 dbg_culprit_instr = derail CULPRIT PC[15:0] (last valid code PC before it jumped)
  //   row3 dbg_derail_pc     = derail TARGET (where PC jumped OUT of the R_ROM code region)
  //   row4 (overlay live PC) = where the CPU is NOW
  //   status: GREEN = running / not derailed (if PC advances in-region, CPU runs -> video bug);
  //           RED   = derailed (rows 2/3 show the death site).
  logic [1:0]  rd_cnt;
  logic        ack_q;
  logic        d_started;
  logic [31:0] d_prevpc;
  always_ff @(posedge clk) if (cpu_ce) begin
    if (core_rst_sys) begin
      dbg_derailed<=1'b0; rd_cnt<=2'd0; ack_q<=1'b0; d_started<=1'b0; d_prevpc<=32'hFFFFFFFF;
      dbg_culprit_pc<=32'hDEADBEEF; dbg_culprit_instr<=16'h0000; dbg_derail_pc<=32'hDEADBEEF;
    end else begin
      // (A) RESET-VECTOR value = the FIRST ack'd read (row1: did the ROM land?)
      ack_q <= cpu_ack;
      if (cpu_ack && !ack_q && !cpu_we && rd_cnt==2'd0) begin
        dbg_culprit_pc <= cpu_rdata; rd_cnt <= 2'd1;
      end
      // (B) DERAIL: freeze the first time PC leaves the R_ROM code region (pc[31:23]==9'h1FF)
      if (pc_dbg !== d_prevpc) begin
        // (C) WARM-RESTART SOURCE CAPTURE (names the loop mechanism). FFE0F5C0 is the
        // warm-restart vector. The watchdog jumps here from FFE0E9E0 (JANC, frame-count>=200,
        // MAME dasm). If the jump SOURCE (d_prevpc, still the pre-transition PC this cycle) is
        // FFE0E9E0 -> watchdog/starvation confirmed. ANY OTHER source names a different cause
        // (CALLERR process-error, or a wild jump) -> explains why every watchdog-assumption fix
        // failed. This restart is IN-region so (B)'s leave-region derail never catches it.
        if (pc_dbg == 32'hFFE0F5C0) begin
          dbg_derail_pc     <= d_prevpc;                   // row3: WHO jumped to the restart
          dbg_culprit_instr <= dbg_culprit_instr + 16'd1;  // row2: restart COUNT (climbs = looping)
        end
        d_prevpc <= pc_dbg;
        if (pc_dbg[31:23]==9'h1FF) d_started <= 1'b1;
      end
    end
  end

  // ==== F4 CABINET SERVICE INSTRUMENT =================================================
  // Answers the three questions the e519fcf cabinet rejection left open, in one trip.
  // See SHIP-SPEC-yunit-2026-08-02.md §4 and rtl/yunit/yunit_service_counters.sv.
  assign dbg_snd_board_rst = srst_snd;
`ifdef DIAG_SERVICE
  // ---- warm-restart detector, generalized across all ten titles -----------------------
  // The existing derail capture hardcodes Smash's restart vector FFE0F5C0, which would need
  // each other title's address from disassembly. It does not have to: for Smash that address
  // is ALSO the value the CPU fetches as its reset vector, because a warm restart re-enters
  // the cold entry point. So latch whatever the CPU fetched FIRST and count re-entries to it.
  // That needs no per-title knowledge and works for every profile.
  logic [31:0] svc_rst_vector, svc_pc_q;
  logic        svc_vector_got, svc_ack_q;
  logic [15:0] svc_restart_cnt;
  always_ff @(posedge clk) if (cpu_ce) begin
    if (core_rst_sys) begin
      svc_rst_vector <= 32'd0; svc_vector_got <= 1'b0; svc_ack_q <= 1'b0;
      svc_pc_q <= 32'hFFFFFFFF; svc_restart_cnt <= 16'd0;
    end else begin
      svc_ack_q <= cpu_ack;
      if (cpu_ack && !svc_ack_q && !cpu_we && !svc_vector_got) begin
        svc_rst_vector <= cpu_rdata; svc_vector_got <= 1'b1;
      end
      if (pc_dbg != svc_pc_q) begin
        svc_pc_q <= pc_dbg;
        if (svc_vector_got && (pc_dbg == svc_rst_vector) && (svc_restart_cnt != 16'hFFFF))
          svc_restart_cnt <= svc_restart_cnt + 16'd1;
      end
    end
  end
  assign dbg_restart_cnt = svc_restart_cnt;

  // Frame boundary from the raster's own vblank (not the display interrupt), so the counters
  // stay meaningful even when the game's ISR is starved -- which is exactly the case under test.
  logic svc_vb_q;
  always_ff @(posedge clk) svc_vb_q <= vblank;
  wire svc_frame_tick = vblank & ~svc_vb_q;

  // hblank/vblank are pure raster functions while `de` carries the scanline-cache gate, so
  // (~hblank & ~vblank & ~de) IS the set of pixels the core blanked inside the active window.
  yunit_service_counters u_service_counters (
    .clk(clk), .rst(core_rst_sys), .frame_tick(svc_frame_tick),
    .cgfx_rd(cgfx_rd), .cgfx_ack(cgfx_ack),
    .snd_rd(sndrom_rd), .snd_ack(sndrom_ack), .snd_rdata(sndrom_wdata),
    .cvsd_addr(cvsd_ext_addr), .adpcm_addr(adpcm_ext_addr),
    .cpu_ce(cpu_ce), .pc(pc_dbg),
    .in_active(~hblank & ~vblank), .de(de), .pix_ce(ce_pix),
    .cnt_cgfx_grants(dbg_cgfx_grants), .cnt_snd_grants(dbg_snd_grants),
    .cnt_cgfx_maxwait(dbg_cgfx_maxwait),
    .cnt_snd_miss(dbg_snd_miss), .cnt_snd_busy16(dbg_snd_busy16),
    .cnt_cvsd_moves(dbg_cvsd_moves), .cnt_adpcm_moves(dbg_adpcm_moves),
    .cnt_blank_pix(dbg_blank_pix), .cnt_cpu_pc_moves(dbg_cpu_pc_moves),
    .cnt_snd_acks(dbg_snd_acks), .snd_first_words(dbg_snd_first_words),
    .snd_region_seen(dbg_snd_region_seen));
`else
  assign dbg_cgfx_grants     = 16'd0;
  assign dbg_snd_grants      = 16'd0;
  assign dbg_cgfx_maxwait    = 32'd0;
  assign dbg_snd_miss        = 16'd0;
  assign dbg_snd_busy16      = 16'd0;
  assign dbg_cvsd_moves      = 16'd0;
  assign dbg_adpcm_moves     = 16'd0;
  assign dbg_blank_pix       = 16'd0;
  assign dbg_cpu_pc_moves    = 32'd0;
  assign dbg_snd_acks        = 32'd0;
  assign dbg_snd_first_words = 32'd0;
  assign dbg_snd_region_seen = 1'b0;
  assign dbg_restart_cnt     = 16'd0;
`endif
endmodule
`default_nettype wire
