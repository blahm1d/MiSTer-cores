// yunit_pkg.sv — Williams Y-unit (Smash T.V.) constants: memory map, DMA
// blitter register set, draw modes, palette/video geometry.
//
// Single home for magic numbers (per birdybro CLAUDE.md convention). Values
// are cited to docs/HARDWARE-REFERENCE.md and the MAME driver mirrored under
// docs/mame-ref/.
//
// NOTE on address units: the region bases below are the TMS34010 *logical*
// addresses as MAME's midyunit main_map presents them (docs/mame-ref/
// midyunit.cpp:184). birdybro's core drives a bit-address on `mem_addr`; the
// exact logical→bit shift is pinned in Phase 1 when yunit_mem is wired and
// sim-checked against the 34010 boot. Region *decode* keys on the high bits,
// which distinguish the regions regardless of the shift.

`default_nettype none

package yunit_pkg;

  // ---- Runtime board profiles -----------------------------------------
  // A single RBF covers the complete MAME Y-unit parent set.  The MRA loads
  // one of these IDs before the ROM streams; the values deliberately remain
  // small/stable because they are part of the MRA <-> core ABI.
  localparam logic [3:0] YG_SMASHTV  = 4'd0;
  localparam logic [3:0] YG_TROG     = 4'd1;
  localparam logic [3:0] YG_HIIMPACT = 4'd2;
  localparam logic [3:0] YG_SHIMPACT = 4'd3;
  localparam logic [3:0] YG_STRKFORC = 4'd4;
  localparam logic [3:0] YG_MK       = 4'd5;
  localparam logic [3:0] YG_TERM2    = 4'd6;
  localparam logic [3:0] YG_TOTCARN  = 4'd7;
  localparam logic [3:0] YG_YUNITTST = 4'd8;
  // Saurian Front shares Strike Force's silicon, graphics format, clock, and
  // protection algorithm, but its DIP/test-switch contract is different.
  // Give it a distinct runtime profile instead of hiding that difference.
  localparam logic [3:0] YG_SAURNFRNT = 4'd9;

  // MiSTer packs named MRA actions starting at joystick bit 4, followed by
  // Start and Coin.  The MRA override is per title, so these positions are
  // profile data -- they are not fixed by the six-button maximum advertised
  // by the generic CONF_STR.  Keeping the count here makes the MRA/core ABI
  // explicit and lets the RTL map exactly the controls the title exposes.
  function automatic logic [3:0] yunit_action_buttons(input logic [3:0] game);
    case (game)
      YG_SMASHTV:                 yunit_action_buttons = 4'd5;
      YG_STRKFORC,
      YG_SAURNFRNT:               yunit_action_buttons = 4'd3;
      YG_MK:                      yunit_action_buttons = 4'd6;
      // T2 exposes the second gun's trigger/bomb as dedicated actions on
      // pad 0.  Keeping them in the ABI (rather than borrowing Start/Coin)
      // lets one controller complete two-gun calibration without corrupting
      // the cabinet's P1/P2 Start controls used by the operator menus.
      YG_TERM2:                   yunit_action_buttons = 4'd4;
      YG_TOTCARN:                 yunit_action_buttons = 4'd4;
      default:                    yunit_action_buttons = 4'd1;
    endcase
  endfunction

  // Presentation mirror. GOSPEL midyunit.cpp:3886-3891: every term2 set is
  // ORIENTATION_FLIP_X (the cabinet's monitor is mirrored); no other Y-unit
  // title is. Cabinet 2026-08-17: T2's CMOS screen rendered horizontally
  // flipped -- this flag drives the scanout mirror in yunit_video.sv.
  function automatic logic yunit_flip_x(input logic [3:0] game);
    yunit_flip_x = (game == YG_TERM2);
  endfunction

  function automatic logic [3:0] yunit_start_bit(input logic [3:0] game);
    yunit_start_bit = 4'd4 + yunit_action_buttons(game);
  endfunction

  function automatic logic [3:0] yunit_coin_bit(input logic [3:0] game);
    yunit_coin_bit = 4'd5 + yunit_action_buttons(game);
  endfunction

  localparam logic [1:0] YS_CVSD_SMALL = 2'd0;
  localparam logic [1:0] YS_CVSD_LARGE = 2'd1;
  localparam logic [1:0] YS_ADPCM      = 2'd2;

  localparam logic [1:0] YC_SLOWER = 2'd0; // 40 MHz board master
  localparam logic [1:0] YC_FAST   = 2'd1; // 48 MHz board master
  localparam logic [1:0] YC_FASTER = 2'd2; // 50 MHz board master

  function automatic logic yunit_is_4bpp(input logic [3:0] game);
    yunit_is_4bpp = (game == YG_TROG) || (game == YG_STRKFORC)
                 || (game == YG_SAURNFRNT);
  endfunction

  // ---- ADPCM sound-CPU hidden ("protection") RAM window ---------------------
  // MAME install_hidden_ram(cpu, prot_start, prot_end) allocates EXACTLY
  // (1 + prot_end - prot_start) bytes and installs them over the 6809's ROM
  // mapping (midyunit_m.cpp:239-245). The bounds are per-title:
  //     MK      0xfb9c..0xfbc6  (43 bytes)   midyunit_m.cpp:457 init_mkyunit
  //     TERM2   0xfa8d..0xfa9c  (16 bytes)   midyunit_m.cpp:548 term2_init_common
  //     TOTCARN 0xfc04..0xfc2e  (43 bytes)   midyunit_m.cpp:577 init_totcarn
  // The END matters and is NOT a constant size: Term2's window is 16 bytes, so
  // sizing every title at the 43-byte maximum would capture 27 extra addresses
  // and steal ROM reads that MAME serves from ROM. CVSD titles have no ADPCM
  // board window at all -- their protection is a different mechanism entirely
  // (cvsd_protection_w, midyunit_m.cpp:230-237).
  function automatic logic [15:0] yunit_adpcm_prot_start(input logic [3:0] game);
    case (game)
      YG_MK:      yunit_adpcm_prot_start = 16'hfb9c;
      YG_TERM2:   yunit_adpcm_prot_start = 16'hfa8d;
      YG_TOTCARN: yunit_adpcm_prot_start = 16'hfc04;
      default:    yunit_adpcm_prot_start = 16'h0000;
    endcase
  endfunction

  function automatic logic [15:0] yunit_adpcm_prot_end(input logic [3:0] game);
`ifdef MUT_ADPCM_PROT_BLANKET64
    // MUTANT: size every window at the storage array instead of the gospel end.
    // This is the exact defect that was caught during authoring, kept armed so
    // the gate proves it would be caught again. Term2's window is 16 bytes, so
    // a blanket 64 swallows 48 addresses that MAME serves from ROM.
    yunit_adpcm_prot_end = yunit_adpcm_prot_start(game) + 16'd63;
`else
    case (game)
      YG_MK:      yunit_adpcm_prot_end = 16'hfbc6;
      YG_TERM2:   yunit_adpcm_prot_end = 16'hfa9c;
      YG_TOTCARN: yunit_adpcm_prot_end = 16'hfc2e;
      default:    yunit_adpcm_prot_end = 16'h0000;
    endcase
`endif
  endfunction

  // Window active only for the three ADPCM profiles. Kept as its own predicate
  // so a CVSD title can never accidentally alias into the table's default 0.
  function automatic logic yunit_has_adpcm_prot(input logic [3:0] game);
    yunit_has_adpcm_prot = (game == YG_MK) || (game == YG_TERM2)
                        || (game == YG_TOTCARN);
  endfunction

  // Machine classes from MAME's Y-unit configurations. yunit_cpu_cadence
  // converts these master clocks to the exact TMS34010 master/8 architectural
  // cycle target. The multi-state RTL still needs a retirement scheduler to
  // enforce that target; this is hardware configuration, never a user control.
  function automatic logic [1:0] yunit_clock_class(input logic [3:0] game);
    if (game == YG_TERM2)
      yunit_clock_class = YC_FASTER;
    else if (game == YG_STRKFORC || game == YG_SAURNFRNT
          || game == YG_MK || game == YG_TOTCARN)
      yunit_clock_class = YC_FAST;
    else
      yunit_clock_class = YC_SLOWER;
  endfunction

  function automatic logic [1:0] yunit_sound_type(input logic [3:0] game);
    if (game == YG_MK || game == YG_TERM2 || game == YG_TOTCARN)
      yunit_sound_type = YS_ADPCM;
    else if (game == YG_HIIMPACT || game == YG_SHIMPACT
          || game == YG_YUNITTST)
      yunit_sound_type = YS_CVSD_LARGE;
    else
      yunit_sound_type = YS_CVSD_SMALL;
  endfunction

  // Words in one raw 2-bit graphics plane.  The two 4bpp games load two
  // planes; 6bpp games load three.  MRA zero-fill preserves the intentional
  // holes in Trog's graphics region.
  function automatic logic [23:0] yunit_plane_words(input logic [3:0] game);
    case (game)
      // Trog has a 0x20000-byte hole between the first and second ROM
      // groups in each of its two planes, so each plane spans 0xc0000
      // bytes even though only 0xa0000 bytes are populated.
      YG_TROG:     yunit_plane_words = 24'h060000;
      YG_HIIMPACT: yunit_plane_words = 24'h040000;
      YG_SHIMPACT: yunit_plane_words = 24'h080000;
      YG_STRKFORC,
      YG_SAURNFRNT:yunit_plane_words = 24'h060000;
      YG_MK,
      YG_TERM2:    yunit_plane_words = 24'h100000;
      YG_TOTCARN:  yunit_plane_words = 24'h080000;
      default:     yunit_plane_words = 24'h030000; // Smash TV / Y-unit test
    endcase
  endfunction

  // Size of the unpacked one-byte-per-pixel graphics image. One 16-bit
  // raw word contains two bytes * four 2-bit pixels, so it expands to
  // eight pixel bytes.
  function automatic logic [23:0] yunit_gfx_bytes(input logic [3:0] game);
    logic [23:0] pw;
    begin
      pw = yunit_plane_words(game);
      yunit_gfx_bytes = {pw[20:0], 3'b000}; // 8 output bytes / plane word
    end
  endfunction

  function automatic logic yunit_has_protection(input logic [3:0] game);
    case (game)
      YG_TROG,
      YG_HIIMPACT,
      YG_SHIMPACT,
      YG_STRKFORC,
      YG_MK,
      YG_TERM2,
      YG_TOTCARN,
      YG_YUNITTST,
      YG_SAURNFRNT: yunit_has_protection = 1'b1;
      default:      yunit_has_protection = 1'b0;
    endcase
  endfunction

  // True while the cabinet test switch is asserted.  Most Y-unit boards use
  // an active-low switch; Saurian Front's prototype DIP is active-high.
  function automatic logic yunit_test_mode(
    input logic [3:0] game,
    input logic [15:0] dsw
  );
    case (game)
      YG_SMASHTV,
      YG_STRKFORC: yunit_test_mode = ~dsw[15];
      YG_SAURNFRNT:yunit_test_mode =  dsw[14];
      YG_TROG,
      YG_HIIMPACT,
      YG_SHIMPACT,
      YG_MK,
      YG_TERM2,
      YG_TOTCARN:  yunit_test_mode = ~dsw[8];
      // The dedicated Y-unit test ROM is already a diagnostic environment;
      // it has no cabinet Test DIP to assert around the menu.
      YG_YUNITTST: yunit_test_mode = 1'b1;
      default:     yunit_test_mode = 1'b0;
    endcase
  endfunction

  // ---- Main-board memory map (34010 logical, MAME convention) ----------
  localparam logic [31:0] YMAP_VRAM_BASE     = 32'h0000_0000; // 0x00000000-0x001FFFFF  vram_r/w
  localparam logic [31:0] YMAP_RAM_BASE      = 32'h0100_0000; // 0x01000000-0x010FFFFF  main DRAM
  localparam logic [31:0] YMAP_CMOS_BASE     = 32'h0140_0000; // 0x01400000-0x0140FFFF  NVRAM (paged)
  localparam logic [31:0] YMAP_PAL_BASE      = 32'h0180_0000; // 0x01800000-0x0181FFFF  palette
  localparam logic [31:0] YMAP_DMA_BASE      = 32'h01A0_0000; // 0x01A00000-0x01A0009F  blitter regs (mirror +0x80000)
  localparam logic [31:0] YMAP_INPUT_BASE    = 32'h01C0_0000; // 0x01C00000-0x01C0005F  inputs
  localparam logic [31:0] YMAP_PROT_BASE     = 32'h01C0_0060; // 0x01C00060-0x01C0007F  protection_r / cmos_enable_w
  localparam logic [31:0] YMAP_SOUND_BASE    = 32'h01E0_0000; // 0x01E00000-0x01E0001F  cvsd_sound_w
  localparam logic [31:0] YMAP_CTRL_BASE     = 32'h01F0_0000; // 0x01F00000-0x01F0001F  control_w
  localparam logic [31:0] YMAP_GFX_BASE      = 32'h0200_0000; // 0x02000000-0x05FFFFFF  gfx ROM window
  localparam logic [31:0] YMAP_MAINDATA_BASE = 32'hFF80_0000; // 0xFF800000-0xFFFFFFFF  program ROM

  // ---- Control register (control_w) bit fields -------------------------
  // docs/mame-ref/midyunit_v.cpp:190
  localparam int CTRL_CMOS_PAGE_HI = 7;   // bits [7:6] CMOS page (*0x1000)
  localparam int CTRL_CMOS_PAGE_LO = 6;
  localparam int CTRL_VIDEOBANK    = 5;   // VRAM byte-lane select
  localparam int CTRL_AUTOERASE_N  = 4;   // /autoerase enable (active low)
  localparam int CTRL_LED_N        = 2;
  localparam int CTRL_WD_DAT       = 1;   // watchdog data
  localparam int CTRL_WD_CLK       = 0;   // watchdog clock

  // ---- DMA blitter register indices (dma_r/dma_w) ----------------------
  // docs/mame-ref/midyunit_v.cpp:22. Typed [3:0] so they can be compared to
  // a 4-bit reg address without constant part-selects (Icarus portability).
  localparam logic [3:0] DMA_COMMAND  = 4'd0; // bit15 trigger/busy; b5 flipY; b4 flipX; [3:0] mode
  localparam logic [3:0] DMA_ROWBYTES = 4'd1;
  localparam logic [3:0] DMA_OFFSETLO = 4'd2;
  localparam logic [3:0] DMA_OFFSETHI = 4'd3;
  localparam logic [3:0] DMA_XSTART   = 4'd4;
  localparam logic [3:0] DMA_YSTART   = 4'd5;
  localparam logic [3:0] DMA_WIDTH    = 4'd6;
  localparam logic [3:0] DMA_HEIGHT   = 4'd7;
  localparam logic [3:0] DMA_PALETTE  = 4'd8;
  localparam logic [3:0] DMA_COLOR    = 4'd9;
  localparam int         DMA_NREGS    = 16; // register file size (only 0..9 used)

  localparam int DMA_CMD_TRIG_BIT   = 15; // COMMAND bit15
  localparam int DMA_CMD_FLIPY_BIT  = 5;
  localparam int DMA_CMD_FLIPX_BIT  = 4;

  // ---- Frame-buffer geometry -------------------------------------------
  localparam int FB_W       = 512; // columns
  localparam int FB_H       = 512; // rows
  localparam int FB_ADDR_W  = 18;  // 512*512 = 0x40000 words
  localparam int FB_ROWSHIFT= 9;   // row * 512 (dma_draw: ty*512 ; scanline: rowaddr<<9)

  // ---- Palette / pixel depth (Smash T.V. = 6bpp) -----------------------
  // pen_map 6bit (midyunit_v.cpp:86): idx = ((w & 0xC000)>>8) | (w & 0x0F3F)
  localparam logic [15:0] PALETTE_MASK_6BIT = 16'h0FFF; // 4096 entries
  // xRGB-1555: 0 RRRRR GGGGG BBBBB  (paletteram_w, midyunit_v.cpp:247)

  // 6-bit pen map for a 16-bit frame-buffer word → 12-bit palette index.
  // MAME: ((w & 0xC000)>>8) | (w & 0x0F3F)
  //   result[11:8] = w[11:8]; result[7:6] = w[15:14]; result[5:0] = w[5:0]
  function automatic logic [11:0] pen_map6(input logic [15:0] w);
    pen_map6 = {w[11:8], w[15:14], w[5:0]};
  endfunction

  // 4-bit pen map (midyunit_v.cpp): ((w & f000)>>8) | (w & 000f).
  function automatic logic [11:0] pen_map4(input logic [15:0] w);
    pen_map4 = {4'b0000, w[15:12], w[3:0]};
  endfunction

  // xRGB-1555 → 8:8:8 (pal5bit replicate: {c,c[4:2]})
  function automatic logic [23:0] rgb555_to_888(input logic [15:0] c);
    logic [4:0] r5, g5, b5;
    begin
      r5 = c[14:10]; g5 = c[9:5]; b5 = c[4:0];
      rgb555_to_888 = {r5, r5[4:2], g5, g5[4:2], b5, b5[4:2]};
    end
  endfunction

endpackage

`default_nettype wire
