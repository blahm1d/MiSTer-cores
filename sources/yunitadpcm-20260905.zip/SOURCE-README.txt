Y Unit - ADPCM / T2 guns r41
RBF SHA-256: 2061a3031fbf5d3878a79eccb912b84336ad976dfabc80d2cddb84f931745b41

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: yunit_term2_gun_osd_r41_20260905
For Wolf Unit use WOLF_MASTER=1,CRT_ADJUST=1,USE_DDR3_GFX=1,USE_DDR3_VRAM=1.
The compiled binary's validation status is recorded in the feed catalog.
