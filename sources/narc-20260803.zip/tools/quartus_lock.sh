#!/usr/bin/env bash
# Cross-session Quartus mutex for the shared build box.
#
# Four sibling sessions (NARC/Z-unit, Y-unit/Smash T.V., Wolf/Open Ice, T-unit/MK2) share one
# machine. Concurrent fits kill each other (observed exit 127) and fight for ~3 GB each. This
# wrapper makes the CLAIM and the PROCESS atomic: starting quartus_* bare is what produced the
# three-way attribution standoff of 2026-07-27.
#
# Every rule below was paid for on 2026-07-27. Do not simplify one away without reading why.
#
#  R1  ATTRIBUTION IS NOT BY NAME. Three of the four trees build a revision literally named
#      `Arcade-SmashTV` (NARC and Wolf both inherited it from the Y-unit donor). A Quartus command
#      line carries ZERO ownership information. Only PID LINEAGE and this owner file discriminate.
#  R2  EXISTENCE IS NOT LIVENESS. A wedged fit and a working fit look identical to tasklist. Wait
#      on CPU-TIME DELTA, not on the process existing. (WOLF's rule.)
#  R3  A RELEASE THAT CANNOT OBSERVE THE RESOURCE MUST NOT RELEASE. Killing a Quartus parent frees
#      the lock via its EXIT trap while forked workers keep running, so the lock reads FREE while
#      the box is BUSY. If children survive, HOLD the lock -- a held lock is a true statement about
#      an occupied box; a released one would be a lie.
#  R4  ACQUIRE WAITS ON PROCESSES, NOT ON THE LOCK FILE. An empty lock dir does not mean a free box
#      (orphans outlive their locks).
#  R5  THE CHECK MUST GATE THE ACT. Never `cat owner ; rm -rf lock` in one command -- the ownership
#      check then prints AFTER the delete it was supposed to prevent. Verify, branch, then act.
#  R6  CAPTURE THE BUILD EXIT CODE BEFORE ANY PIPELINE. `build 2>&1 | tail` reports the PIPELINE's
#      status; a build that exited 3 was reported as 0 and its post-fit gate failure was missed.
#
# KNOWN LIMITATION -- READ THIS BEFORE ARMING A WAITER (Y-unit, 2026-07-27):
#  R7  THIS IS A LOCK, NOT A QUEUE. A LOCK PROVIDES MUTUAL EXCLUSION, NEVER ORDERING.
#      The acquire loop above is a wait-for-free-then-take RACE: it has no concept of queue
#      position, so the instant the box frees, WHOEVER POLLS FASTEST WINS regardless of what was
#      announced in chat. Y-unit caught this in their own waiter -- it was armed to grab the box
#      ahead of NARC's agreed slot 2 while they were telling NARC they were slot 3. Announced
#      priority and automated behaviour disagreed, and only the automation would have run.
#      Until this reads an ordering file, arming a waiter is legitimate ONLY when every earlier
#      slot has stood down IN WRITING. Advertise your claim in /tmp/fpga_quartus.queue/<session>
#      and read the other files there before arming. Do not infer your turn from an idle box.
#      TODO: make acquire() refuse while a lower-numbered position= claim is still armed.
#
# Usage:  tools/quartus_lock.sh <session-tag> <command...>
#   e.g.  tools/quartus_lock.sh narc:v7m-sndcapture bash quartus/build_hw.sh 'DIAG_BOOT,USE_DDR3_VRAM' Arcade-NARC-DDR3-v7m-sndcapture

set -u
LOCK=/tmp/fpga_quartus.lock
OWNER="$LOCK/owner"
TAG="${1:?usage: quartus_lock.sh <session-tag> <command...>}"; shift
[ "$#" -gt 0 ] || { echo "quartus_lock: no command given" >&2; exit 2; }

# Report the WINDOWS pid (ps -W column 4 = WINPID), NOT column 1 (the MSYS pid). Siblings check
# with tasklist/Get-CimInstance, which only ever show WINPID; printing the MSYS pid would name a
# process they cannot find and recreate the very attribution confusion this wrapper exists to stop
# (measured: MSYS 126810 == WINPID 103120 for the same fit).
# The regex deliberately matches quartus_map|fit|sta|asm|sh|cdb and NOT jtagserver.exe, which is a
# long-lived Quartus helper that must never be treated as an occupied box.
quartus_pids() { ps -W 2>/dev/null | awk 'tolower($0) ~ /quartus_(map|fit|sta|asm|sh|cdb)/ {print $4}'; }
have_quartus() { [ -n "$(quartus_pids)" ]; }

# ---- acquire: BOTH the lock dir AND a process-free box (R4) --------------------------------
tries=0
while :; do
  if mkdir "$LOCK" 2>/dev/null; then
    if have_quartus; then
      # We took the dir but the box is occupied by someone who did not use the wrapper.
      # Give it straight back rather than starting into them.
      rm -rf "$LOCK"
    else
      { echo "$$"; echo "session=$TAG"; echo "started=$(date -Is)"; echo "cmd=$*"; } > "$OWNER"
      break
    fi
  fi
  tries=$((tries+1))
  if [ $((tries % 12)) -eq 1 ]; then
    echo "quartus_lock: waiting ($TAG). holder: $(sed -n 2p "$OWNER" 2>/dev/null || echo unknown); quartus pids: $(quartus_pids | tr '\n' ' ')"
  fi
  if [ "$tries" -gt 720 ]; then       # 720 * 10s = 2h
    echo "quartus_lock: TIMED OUT waiting for the box" >&2; exit 75
  fi
  sleep 10
done
echo "quartus_lock: ACQUIRED by $TAG (pid $$)"

# ---- release: reap, verify, and refuse to lie (R3, R5) --------------------------------------
release() {
  rc=$?
  # Verify FIRST, then branch, then act -- never delete before the check has spoken (R5).
  survivors="$(quartus_pids | tr '\n' ' ')"
  if [ -n "${survivors// /}" ]; then
    echo "quartus_lock: HOLDING the lock -- quartus still alive after exit: $survivors" >&2
    echo "quartus_lock: this is deliberate. Reap them, then: rm -rf $LOCK" >&2
    exit "$rc"
  fi
  if [ -f "$OWNER" ] && [ "$(head -n1 "$OWNER" 2>/dev/null)" != "$$" ]; then
    echo "quartus_lock: NOT releasing -- lock is owned by pid $(head -n1 "$OWNER"), not me ($$)" >&2
    exit "$rc"
  fi
  rm -rf "$LOCK"
  echo "quartus_lock: released by $TAG"
  exit "$rc"
}
trap release EXIT INT TERM

# ---- run, capturing the REAL exit code before any pipeline (R6) -----------------------------
"$@"
BUILD_RC=$?
echo "quartus_lock: BUILD_RC=$BUILD_RC"
exit "$BUILD_RC"
