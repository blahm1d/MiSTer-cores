#!/usr/bin/env bash
# Generate the ignored Verilog build-date include needed by Arcade-SmashTV.sv.
# BUILD_ID_DATE may pin YYMMDD for a deterministic test; normal builds use today.
set -eu
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/build_id.v}"
STAMP="${BUILD_ID_DATE:-$(date +%y%m%d)}"

[[ "$STAMP" =~ ^[0-9]{6}$ ]] || {
  echo "ERROR: BUILD_ID_DATE must be YYMMDD, got: $STAMP" >&2
  exit 2
}

printf '`define BUILD_DATE "%s"' "$STAMP" > "$OUT"
echo "Generated $OUT: BUILD_DATE=$STAMP"
