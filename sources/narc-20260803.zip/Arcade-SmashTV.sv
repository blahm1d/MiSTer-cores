//============================================================================
//  Arcade: NARC (Williams Z-unit) for MiSTer — emu wrapper
//
//  Open, anti-paywall TMS34010 Z-unit core. This emu wraps rtl/zunit/zunit_top.sv
//  (the whole synthesizable core: TMS34010 + NARC memory map + DMA blitter + video +
//  palette + CVSD sound + SDRAM controller) in the standard Template_MiSTer chassis.
//  zunit_top owns the SDRAM controller, so this wrapper just passes the SDRAM pins
//  through (assign SDRAM_CLK = clk_sdram) and feeds it clocks, inputs, ioctl ROM
//  data, and takes RGB + audio back out.
//
//  GPL (jt51 + darfpga CVSD + 6809 are GPL). No ROM data distributed. See VENDOR.md.
//============================================================================
module emu
(
	input         CLK_50M,
	input         RESET,
	inout  [48:0] HPS_BUS,

	output        CLK_VIDEO,
	output        CE_PIXEL,
	output [12:0] VIDEO_ARX,
	output [12:0] VIDEO_ARY,

	output  [7:0] VGA_R,
	output  [7:0] VGA_G,
	output  [7:0] VGA_B,
	output        VGA_HS,
	output        VGA_VS,
	output        VGA_DE,
	output        VGA_F1,
	output [1:0]  VGA_SL,
	output        VGA_SCALER,
	output        VGA_DISABLE,

	input  [11:0] HDMI_WIDTH,
	input  [11:0] HDMI_HEIGHT,
	output        HDMI_FREEZE,
	output        HDMI_BLACKOUT,
	output        HDMI_BOB_DEINT,

	output        FB_EN,
	output  [4:0] FB_FORMAT,
	output [11:0] FB_WIDTH,
	output [11:0] FB_HEIGHT,
	output [31:0] FB_BASE,
	output [13:0] FB_STRIDE,
	input         FB_VBL,
	input         FB_LL,
	output        FB_FORCE_BLANK,

	output        FB_PAL_CLK,
	output  [7:0] FB_PAL_ADDR,
	output [23:0] FB_PAL_DOUT,
	input  [23:0] FB_PAL_DIN,
	output        FB_PAL_WR,

	output        LED_USER,
	output  [1:0] LED_POWER,
	output  [1:0] LED_DISK,

	output  [1:0] BUTTONS,

	input         CLK_AUDIO,
	output [15:0] AUDIO_L,
	output [15:0] AUDIO_R,
	output        AUDIO_S,
	output  [1:0] AUDIO_MIX,

	inout   [3:0] ADC_BUS,

	output        SD_SCK,
	output        SD_MOSI,
	input         SD_MISO,
	output        SD_CS,
	input         SD_CD,

	output        DDRAM_CLK,
	input         DDRAM_BUSY,
	output  [7:0] DDRAM_BURSTCNT,
	output [28:0] DDRAM_ADDR,
	input  [63:0] DDRAM_DOUT,
	input         DDRAM_DOUT_READY,
	output        DDRAM_RD,
	output [63:0] DDRAM_DIN,
	output  [7:0] DDRAM_BE,
	output        DDRAM_WE,

	output        SDRAM_CLK,
	output        SDRAM_CKE,
	output [12:0] SDRAM_A,
	output  [1:0] SDRAM_BA,
	inout  [15:0] SDRAM_DQ,
	output        SDRAM_DQML,
	output        SDRAM_DQMH,
	output        SDRAM_nCS,
	output        SDRAM_nCAS,
	output        SDRAM_nRAS,
	output        SDRAM_nWE,

	input         UART_CTS,
	output        UART_RTS,
	input         UART_RXD,
	output        UART_TXD,
	output        UART_DTR,
	input         UART_DSR,

	input   [6:0] USER_IN,
	output  [6:0] USER_OUT,

	input         OSD_STATUS
);

// ---- unused chassis features -------------------------------------------------
assign VGA_F1 = 0;
assign VGA_SCALER = 0;   // VGA_SL is driven by arcade_video
assign VGA_DISABLE = 0;
assign HDMI_FREEZE = 0;
assign HDMI_BLACKOUT = 0;
assign HDMI_BOB_DEINT = 0;
assign FB_FORCE_BLANK = 0;
assign {FB_EN, FB_FORMAT, FB_WIDTH, FB_HEIGHT, FB_BASE, FB_STRIDE} = 0;
assign {FB_PAL_CLK, FB_PAL_ADDR, FB_PAL_DOUT, FB_PAL_WR} = 0;
// HPS DDR3 (f2h_sdram1). DDRAM_CLK is always driven from clk_sys (the ram1 f2sdram bridge +
// safe-terminator run off this core clock; no CDC).
assign DDRAM_CLK      = clk_sys;
`ifdef USE_DDR3_VRAM
// VRAM-in-DDR3 build: the core's ddram master (stv_vram_ddr_top via zunit_top) drives the
// f2h_sdram1 port. SDRAM still carries CPU/gfx/prog/sound. Macro must match the sv2v build
// of the core blob (SV2V_EXTRA=-DUSE_DDR3_VRAM) so zunit_top's port list agrees.
wire [28:0] core_ddram_addr;
wire [7:0]  core_ddram_burstcnt, core_ddram_be;
wire        core_ddram_rd, core_ddram_we;
wire [63:0] core_ddram_din;
assign DDRAM_ADDR     = core_ddram_addr;
assign DDRAM_BURSTCNT = core_ddram_burstcnt;
assign DDRAM_RD       = core_ddram_rd;
assign DDRAM_DIN      = core_ddram_din;
assign DDRAM_BE       = core_ddram_be;
assign DDRAM_WE       = core_ddram_we;
`else
assign DDRAM_ADDR     = 0;
assign DDRAM_BURSTCNT = 0;
assign DDRAM_RD       = 0;
assign DDRAM_DIN      = 0;
assign DDRAM_BE       = 0;
assign DDRAM_WE       = 0;
`endif
assign {SD_SCK, SD_MOSI, SD_CS} = 'Z;
assign {UART_RTS, UART_TXD, UART_DTR} = 0;
assign USER_OUT = '1;
assign LED_DISK  = 0;
assign LED_POWER = 0;
assign LED_USER  = ioctl_download;
assign BUTTONS   = 0;

// NARC is a horizontal 4:3 game.
assign VIDEO_ARX = status[1] ? 12'd16 : 12'd4;
assign VIDEO_ARY = status[1] ? 12'd9  : 12'd3;

assign AUDIO_S   = 1;              // zunit_top emits signed stereo PCM
assign AUDIO_MIX = 0;

// SDRAM_CLK is forwarded from the phase-shifted PLL output (clk_sdram = outclk_1, -4036ps)
// straight to the pin, exactly like the proven tecmo/jtframe MiSTer cores on this DE10 —
// and rtl/sdram.sdc sources the SDRAM_CLK generated clock from that same general[1] output,
// so the fitter closes the read window against the REAL pin clock. (An earlier build drove
// SDRAM_CLK from a DDIO on clk_sys, which did NOT match the SDC -> reads captured against a
// phantom edge -> black screen on silicon. The stock controller keeps its proven CAS-latency
// capture; only the clock forward reverts to this proven scheme.)
assign SDRAM_CLK = clk_sdram;

`include "build_id.v"
localparam CONF_STR = {
	// Correct direct-RBF fallback identity. The MRA also pins setname=narc.
	"A.NARC;;",
	"O1,Aspect Ratio,4:3,16:9;",
	"O46,Scandoubler Fx,None,CRT 25%,CRT 50%,CRT 75%;",   // HQ2x removed -- see arcade_video HQ2X(0)
	"P1O7,CRT Adjust,Off,On;",
	// Positive size changes are unsafe here: even +1 extends active video into
	// the native HSync interval. Shrink-only settings preserve a blanking guard.
	"H1P1O[12:8],CRT H-Size,0,-16,-15,-14,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1;",
	// Safe SYNCSHIFT range is derived from NARC's actual timing and the line
	// buffer's registered output guard. Native active ends at 633 and HSync
	// begins at 642; -7 is the proven output-safe negative boundary.
	// +48 wraps the 32-pixel pulse to 16..47, before the earliest shrunk row.
	"H1P1O[19:13],CRT H-Position,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,+16,+17,+18,+19,+20,+21,+22,+23,+24,+25,+26,+27,+28,+29,+30,+31,+32,+33,+34,+35,+36,+37,+38,+39,+40,+41,+42,+43,+44,+45,+46,+47,+48,-7,-6,-5,-4,-3,-2,-1;",
	"H1P1O[24:20],CRT V-Shift,0,+1,+2,+3,+4,+5,+6,+7,+8,+9,+10,+11,+12,+13,+14,+15,-16,-15,-14,-13,-12,-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1;",
	"-;",
	"DIP;",
	"-;",
	"R0,Reset;",
	"J1,Fire,Jump,Rocket Bomb,Crouch,Start,Coin,Vault,Service;",
	"jn,A,B,X,Y,Start,Select,R,L;",
	"V,v",`BUILD_DATE
};

////////////////////////////////////////////////////////////////////////////////
// CLOCKS — clk_sys/clk_sdram = 96 MHz (SDRAM+CPU+video), clk_snd = 12 MHz (CVSD)
////////////////////////////////////////////////////////////////////////////////
wire clk_sys, clk_sdram, clk_snd, clk_cpu_unused;
wire locked;

pll pll
(
	.rst(RESET),
	.refclk(CLK_50M),
	.outclk_0(clk_sys),      // 96 MHz
	.outclk_1(clk_sdram),    // 96 MHz, phase-shifted for the SDRAM chip
	.outclk_2(clk_snd),      // 12 MHz sound-board clock
	.outclk_3(clk_cpu_unused), // legacy PLL output; NARC CPU uses clk_sys with fixed /4 CE
	.locked(locked)
);

// NARC Z-unit raster: 96 MHz / 6 = 16 MHz dot clock
// (MAME screen.set_raw(MEDRES_PIXEL_CLOCK*2, 674, ..., 433, ...)).
// The donor Smash TV /12 divider produced an invalid ~27.4 Hz NARC frame on
// hardware, while simulation gates drove ce_pix independently and missed it.
reg [2:0] cediv = 0;
wire ce_pix = (cediv == 3'd0);
always @(posedge clk_sys) cediv <= (cediv == 3'd5) ? 3'd0 : cediv + 3'd1;

////////////////////////////////////////////////////////////////////////////////
// HPS IO
////////////////////////////////////////////////////////////////////////////////
wire  [1:0] buttons;
wire [31:0] status;
wire        forced_scandoubler;
wire [21:0] gamma_bus;
wire        direct_video;

wire [24:0] ioctl_addr;
wire  [7:0] ioctl_dout;
wire        ioctl_wr;
wire        ioctl_download;
wire  [7:0] ioctl_index;

wire [15:0] joystick_0, joystick_1;

hps_io #(.CONF_STR(CONF_STR)) hps_io
(
	.clk_sys(clk_sys),
	.HPS_BUS(HPS_BUS),

	.buttons(buttons),
	.status(status),
	// P1 is hidden while CRT Adjust is Off. Preserve the framework's direct-
	// video menu mask in bit 0 exactly as before.
	.status_menumask({14'd0, ~status[7], direct_video}),
	.forced_scandoubler(forced_scandoubler),
	.gamma_bus(gamma_bus),
	.direct_video(direct_video),

	.ioctl_addr(ioctl_addr),
	.ioctl_dout(ioctl_dout),
	.ioctl_wr(ioctl_wr),
	.ioctl_wait(yt_ioctl_wait),      // SDRAM download backpressure (from zunit_top)
	.ioctl_download(ioctl_download),
	.ioctl_index(ioctl_index),

	.joystick_0(joystick_0),
	.joystick_1(joystick_1)
);
wire yt_ioctl_wait;

////////////////////////////////////////////////////////////////////////////////
// VIDEO
////////////////////////////////////////////////////////////////////////////////
wire [7:0] r, g, b;
wire       hsync, vsync, hblank, vblank, de;
wire       rgb_valid;   // zunit_top scanout data-valid strobe (observability)

// boot-instrument taps + overlay video (driven later by the core + smashtv_diag2_overlay)
wire [31:0] dbg_pc; wire dbg_illegal, dbg_core_rst, dbg_sdram_ready, dbg_unp_done, dbg_cpu_req, dbg_mem_ack;
wire dbg_int1, dbg_vblank_irq, dbg_cpu_ce;
wire dbg_derailed; wire [31:0] dbg_culprit_pc, dbg_derail_pc; wire [15:0] dbg_culprit_instr;
// NARC does not yet implement the donor derail-history recorder. Keep those
// legacy overlay inputs deterministic; the live PC, illegal flag, first-fetch,
// FIFO audit, and boot-gate lanes below are the load-bearing NARC diagnostics.
assign dbg_derailed = 1'b0;
assign dbg_culprit_pc = 32'd0;
assign dbg_derail_pc = 32'd0;
assign dbg_culprit_instr = 16'd0;
// cont.24 splash-capture taps (used by the DIAG_SPLASHCAP capture below; harmless wires otherwise)
wire dbg_dma_we; wire [3:0] dbg_dma_addr; wire [15:0] dbg_dma_wdata;
wire [7:0] dbg_src_data; wire dbg_src_ack; wire [15:0] dbg_scan_data; wire dbg_scan_ack;
wire [31:0] iol_accepted, iol_dropped;   // exact FIFO pushes accepted / dropped (no wrap)
// Expected SDRAM word-writes for a COMPLETE ROM download: 0x400000 gfx+prog + 0x120000 sound
// byte-lane writes (D1 sound seam, 82b4b95) = 0x520000, matching sim/zunit_download's assert.
// The old hard-coded 0x400000 predated the sound seam -> forced the overlay status bar RED and
// the unp_done lane RED on a HEALTHY cab (2026-07-25). Keep in sync with zunit_top's copy.
localparam [31:0] DL_EXPECT_WRITES = 32'h0040_0000 + 32'h0012_0000;  // 0x520000
wire [31:0] snd_stall_clks;              // core clocks an overdue ROM word stretched falling E
wire        iol_rst_during;              // zunit_top P0022 tap (core reset overlapped ioctl_download)
// P0022 FIRST-FETCH taps: what the CPU RECEIVED on its first read-ack after reset
// (§6 first-flash disproof). ff_addr=reset-vector @FFFFFFE0, ff_data=ROM reset PC.
wire [31:0] ff_addr, ff_data; wire ff_valid;
wire [31:0] rb_data; wire rb_valid;          // direct physical SDRAM reset-vector readback
wire [31:0] cksum_w0, cksum_w1, cksum_w2; wire cksum_valid;  // DIAG_ROMCHKSUM U41/U23 sweep
`ifdef DIAG_BOOT
// SOUND-CAMPAIGN instrument taps (SPEC 29.4 item 2, 2026-07-30): sound-region
// checksum sweep + low-lane sum, master-6809 first-fetch latch, and the
// rst->snd_board_rst release-gap counter. Expected values are recorded at the
// overlay row map below (offline golden: rtl/zunit/tools/compute_snd_chksum.py).
wire [31:0] snd_cksum_w0; wire snd_cksum_valid; wire [15:0] snd_lo_sum;
wire [19:0] snd_ff_offset; wire [7:0] snd_ff_data; wire snd_ff_valid;
wire [15:0] snd_gap_clks;
wire [15:0] snd_req_count, snd_ack_count;
wire [31:0] snd_wd_rearms;
wire [15:0] snd_cmd_count, snd_audio_changes;
wire [15:0] snd_pa_data; wire snd_pa_valid, snd_pa_addr_match;
wire [15:0] snd_land_data; wire [1:0] snd_land_seen;
`endif
wire [7:0] ov_r, ov_g, ov_b; wire ov_hs, ov_vs, ov_hb, ov_vb, ov_de;

// arcade_video source: the boot overlay under +define+DIAG_BOOT or +define+DIAG_ROMCHKSUM,
// else the real core.
`ifdef DIAG_ROMCHKSUM
wire [7:0] av_r = ov_r, av_g = ov_g, av_b = ov_b;
wire       av_hs = ov_hs, av_vs = ov_vs, av_hb = ov_hb, av_vb = ov_vb;
`elsif DIAG_BOOT
wire [7:0] av_r = ov_r, av_g = ov_g, av_b = ov_b;
wire       av_hs = ov_hs, av_vs = ov_vs, av_hb = ov_hb, av_vb = ov_vb;
`else
wire [7:0] av_r = r, av_g = g, av_b = b;
wire       av_hs = hsync, av_vs = vsync, av_hb = hblank, av_vb = vblank;
`endif

// Core-side CRT Adjust (rmonic79/MiSTer-CRT-Adjust).
//
// NARC is 512 visible pixels on a 674-pixel line with strongly asymmetric
// blanking (122 pixels before active, 40 after), so HPOS_SYNCSHIFT is the safe
// per-game choice: content-shift would run out of the short-side buffer margin.
// This is a one-line geometry buffer only. It preserves the native 674x433
// sync periods and 54.82 Hz refresh; there is no full-frame retimer.
reg crt_on = 1'b0;
reg        [4:0] crt_hsize_code = 5'd0;
reg        [6:0] crt_hpos_code = 7'd0;
reg signed [5:0] crt_vshift = 6'sd0;
always @(posedge clk_sys) if (ce_pix) begin
	crt_on        <= status[7];
	crt_hsize_code<= status[12:8];
	crt_hpos_code <= status[19:13];
	crt_vshift    <= $signed(status[24:20]);
end

// The NARC-safe menu is 0 then -16..-1, hence code 1 begins -16.
wire signed [5:0] crt_hsize_neg = $signed({1'b0,crt_hsize_code}) - 6'sd17;
wire signed [4:0] crt_hsize =
	(crt_hsize_code == 5'd0) ? 5'sd0
	: (crt_hsize_code <= 5'd16) ? crt_hsize_neg[4:0] : 5'sd0;

// The NARC-safe menu enumerates 0..+48 then -7..-1. The negative run begins
// at code 49 and therefore decodes by -56. Invalid persisted codes fail safe.
wire signed [8:0] crt_hpos =
	(crt_hpos_code <= 7'd48) ? $signed({2'b00,crt_hpos_code})
	: (crt_hpos_code <= 7'd55)
		? $signed({2'b00,crt_hpos_code}) - 9'sd56 : 9'sd0;

// NARC's clk_sys/pixel ratio is 96/16 = 6 whole clocks = 24 quarter-clocks.
// Restart on the module's hs_ref_out exactly; resetting on raw HSync makes the
// shrink path drift when sync-shift positioning is selected. NARC's positive
// HSync occupies the tail of the line, so the module is fed the native inverse:
// hs_ref_out then rises on the native HSync falling edge (the real line start).
// The adjusted HSync is inverted back before arcade_video, preserving native
// polarity, width, period, and refresh at zero position.
wire crt_hs_ref;
reg  crt_hs_ref_d = 1'b0;
reg  [7:0] crt_rd_acc = 8'd0;
wire crt_hs_ref_rise = crt_hs_ref & ~crt_hs_ref_d;
wire [7:0] crt_rd_period = 8'd24 + {{3{crt_hsize[4]}},crt_hsize};
wire [8:0] crt_rd_sum = {1'b0,crt_rd_acc} + 9'd4;
wire crt_rd_tick = crt_rd_sum >= {1'b0,crt_rd_period};
always @(posedge clk_sys) begin
	crt_hs_ref_d <= crt_hs_ref;
	if (RESET || crt_hs_ref_rise) crt_rd_acc <= 8'd0;
	else if (crt_rd_tick)         crt_rd_acc <= crt_rd_sum - {1'b0,crt_rd_period};
	else                          crt_rd_acc <= crt_rd_sum[7:0];
end
wire crt_ce = crt_on ? crt_rd_tick : ce_pix;

wire [7:0] crt_r, crt_g, crt_b;
wire crt_hs, crt_vs, crt_hb, crt_vb;
crt_adjust #(
	.VTOTAL(433),
	.HTOTAL(674),
	.HPOS_MODE(0)                 // HPOS_SYNCSHIFT: NARC's asymmetric line
) u_crt_adjust (
	.clk(clk_sys),
	.pxl_cen(ce_pix),
	.pxl2_cen(crt_rd_tick),
	.active(crt_on),
	.hsize(crt_hsize),
	.hoffset(crt_hpos),
	.voffset(crt_vshift),
	.r_in(av_r), .g_in(av_g), .b_in(av_b),
	.hs_in(~av_hs), .vs_in(av_vs),
	.hb_in(av_hb | av_vb),        // combined blank only for the line buffer
	.vb_in(av_vb),                // true VBlank keeps the downstream OSD alive
	.r_out(crt_r), .g_out(crt_g), .b_out(crt_b),
	.hs_out(crt_hs), .vs_out(crt_vs), .hb_out(crt_hb), .vb_out(crt_vb),
	.hs_ref_out(crt_hs_ref)
);

wire [7:0] mix_r  = crt_on ? crt_r  : av_r;
wire [7:0] mix_g  = crt_on ? crt_g  : av_g;
wire [7:0] mix_b  = crt_on ? crt_b  : av_b;
wire       mix_hs = crt_on ? ~crt_hs : av_hs;
wire       mix_vs = crt_on ? crt_vs : av_vs;
wire       mix_hb = crt_on ? crt_hb : av_hb;
wire       mix_vb = crt_on ? crt_vb : av_vb;

// HQ2X(0): the Hq2x Blend cone was the ENTIRE timing frontier of this design. Measured on the
// seed-7 fitted netlist (quartus_sta, no refit): worst setup -0.434 ns / TNS -8.787 ns at Slow
// 1100mV -40C and -0.109 / -0.140 at Slow 1100mV 100C, and EVERY one of the 25 worst paths was
// Hq2x|Blend|df_rule[0] -> Hq2x|Blend|i30[*]. Every other clock passes with margin (FPGA_CLK1_50
// +7.863, SDRAM_CLK +2.017, audio +13.540, hdmi +0.244).
// NOT fixable with a multicycle: source and destination share clk_en (hq2x.sv:322/332), but the
// enable is ce_x4i, which for NARC's 6-clk input pixel period fires at pc_in in {0,1,3,4}
// (scandoubler.v:69,84 with pixsz4=1, pixsz2=3) -- MINIMUM GAP ONE CLOCK. A multicycle there
// would be a weakened constraint, not a correct one.
// The 100C corner matters: a hot cabinet reaches it, so this is not a dismissible -40C-only
// industrial corner. HQ2x is a cosmetic upscaling filter and costs the whole design's closure;
// scandoubling and the CRT scanline options are unaffected. To restore it, pipeline Blend's
// rule->i30 mux in sys/hq2x.sv rather than reverting this line.
arcade_video #(.WIDTH(512), .DW(24), .HQ2X(0)) arcade_video
(
	.clk_video(clk_sys),
	.ce_pix(crt_ce),
	.RGB_in({mix_r, mix_g, mix_b}),
	.HBlank(mix_hb),
	.VBlank(mix_vb),
	.HSync(mix_hs),
	.VSync(mix_vs),

	.CLK_VIDEO(CLK_VIDEO),
	.CE_PIXEL(CE_PIXEL),
	.VGA_R(VGA_R),
	.VGA_G(VGA_G),
	.VGA_B(VGA_B),
	.VGA_HS(VGA_HS),
	.VGA_VS(VGA_VS),
	.VGA_DE(VGA_DE),
	.VGA_SL(VGA_SL),

	// FX REMAP -- load-bearing, do not simplify to status[6:4].
	// arcade_video derives scanline strength numerically: sl = fx ? fx-1 : 0 (arcade_video.v:117),
	// so the CRT levels are tied to fx's VALUE, not to the OSD entry's position. Dropping the HQ2x
	// entry (fx==1) from the menu string shortens the list, so a naive status[6:4] would hand
	// CRT 25%/50%/75% the values 1/2/3 -> sl 0/1/2: CRT 25% would render with NO scanlines and the
	// other two would each be one step too weak. Remap so the menu's 0..3 select fx 0,2,3,4 and
	// every CRT level keeps the strength it had before HQ2x was removed.
	//   menu 0 None -> fx 0 -> sl 0     menu 2 CRT 50% -> fx 3 -> sl 2
	//   menu 1 CRT 25% -> fx 2 -> sl 1  menu 3 CRT 75% -> fx 4 -> sl 3
	.fx(status[6:4] == 3'd0 ? 3'd0 : (status[6:4] + 3'd1)),
	.forced_scandoubler(forced_scandoubler),
	.gamma_bus(gamma_bus)
);

////////////////////////////////////////////////////////////////////////////////
// ROM DOWNLOAD — one linear hps_io byte stream (rom index 0), demuxed by
// rtl/zunit/zunit_download.sv into the two SDRAM-resident NARC MRA regions.
//   "Narc (rev 7.00).mra" (validate_narc_mra.py; gospel midyunit.cpp:1449-1548):
//     [0x000000, 0x080000)  PROGRAM 512KB (pre-interleaved LE16) -> ROMW_BASE words
//     [0x080000, 0x880000)  GFX 8MB raw quadrants -> flat GFXW_BASE, init_gfxrom(8)
//     [0x880000, 0x9A0500)  SOUND MASTER/SLAVE + PLDs -> UNROUTED (D1 seam stubbed)
//   Bases come from zunit_pkg (SDRAM_ROMW_BASE / SDRAM_GFXW_BASE) via the module's
//   defaults — single source of truth. NOTE(audit): zunit_mem still carries the
//   donor GFX_PIXELS=SDRAM_ROMB=0x180000 (6bpp) -> it READS program at word 0xC0000,
//   but this demux WRITES at ROMW_BASE=0x1E0000 (8bpp NARC geometry). That read/write
//   base mismatch (and the gfx array size) must be reconciled in zunit_mem before boot.
////////////////////////////////////////////////////////////////////////////////
wire rom_download = ioctl_download & (ioctl_index == 0);

wire        yt_ioctl_wr;
wire [24:0] yt_ioctl_addr;
wire [15:0] yt_ioctl_dout;
wire  [1:0] yt_ioctl_be;

zunit_download u_download (
	.clk        (clk_sys),
	.dl_en      (rom_download),
	.ioctl_wr   (ioctl_wr),
	.ioctl_addr (ioctl_addr),
	.ioctl_dout (ioctl_dout),
	.sd_wr      (yt_ioctl_wr),
	.sd_addr    (yt_ioctl_addr),
	.sd_dout    (yt_ioctl_dout),
	.sd_be      (yt_ioctl_be)
);

// ---- P0021 download-path disambiguation (emu-side, reset only on ~locked).
// ytwr_cnt is the exact number of SDRAM writes emitted by the demux; dl_vec_stream
// independently captures the four raw HPS bytes before the demux/FIFO/SDRAM.
reg [31:0] dl_ytwr_cnt;
reg [31:0] dl_vec_stream;
reg  [3:0] dl_vec_seen;
always @(posedge clk_sys) begin
	if (~locked) begin
		dl_ytwr_cnt <= 32'd0;
		dl_vec_stream <= 32'd0; dl_vec_seen <= 4'd0;
	end
	else begin
		if (yt_ioctl_wr)          dl_ytwr_cnt   <= dl_ytwr_cnt + 1'b1;
		// Raw bytes from the MRA/HPS stream, before zunit_download, FIFO, or SDRAM.
		// Rev 7.00 offsets 0x7FFFC..0x7FFFF must assemble to FFF6E000.
		if (rom_download && ioctl_wr) case (ioctl_addr)
			25'h07FFFC: begin dl_vec_stream[7:0]   <= ioctl_dout; dl_vec_seen[0] <= 1'b1; end
			25'h07FFFD: begin dl_vec_stream[15:8]  <= ioctl_dout; dl_vec_seen[1] <= 1'b1; end
			25'h07FFFE: begin dl_vec_stream[23:16] <= ioctl_dout; dl_vec_seen[2] <= 1'b1; end
			25'h07FFFF: begin dl_vec_stream[31:24] <= ioctl_dout; dl_vec_seen[3] <= 1'b1; end
			default: ;
		endcase
	end
end

////////////////////////////////////////////////////////////////////////////////
// CONTROLS -> Z-unit (NARC) input word {DSW, IN2, IN1, IN0}, per MAME
// midyunit.cpp INPUT_PORTS_START(narc) :261-316 (midzunit_state). NARC is a
// single 8-way stick + 4 buttons per player (NOT the donor twin-stick).
// MiSTer joystick dirs: [0]=R [1]=L [2]=D [3]=U; CONF_STR J1 buttons map to bits
// [4]=Fire [5]=Jump [6]=RocketBomb [7]=Crouch [8]=Start [9]=Coin [10]=Vault
// [11]=Service. Emu ports are ACTIVE-LOW (0=pressed) except the two talkback
// CUSTOM fields which are ACTIVE-HIGH sound-board readback (tied 0, see below).
////////////////////////////////////////////////////////////////////////////////
wire p1_up=joystick_0[3], p1_dn=joystick_0[2], p1_lf=joystick_0[1], p1_rt=joystick_0[0];
wire p1_fire=joystick_0[4], p1_jump=joystick_0[5], p1_rb=joystick_0[6], p1_crouch=joystick_0[7];
wire p2_up=joystick_1[3], p2_dn=joystick_1[2], p2_lf=joystick_1[1], p2_rt=joystick_1[0];
wire p2_fire=joystick_1[4], p2_jump=joystick_1[5], p2_rb=joystick_1[6], p2_crouch=joystick_1[7];
wire start1=joystick_0[8], start2=joystick_1[8];
wire coin1 =joystick_0[9], coin2 =joystick_1[9];
wire vault   = joystick_0[10] | joystick_1[10];   // IPT_OTHER "Vault Switch" (global)
wire service = joystick_0[11] | joystick_1[11];   // PORT_SERVICE_NO_TOGGLE (global)
wire tilt  = 1'b0;   // IPT_TILT slam switch  - no MiSTer mapping (released)
wire coin3 = 1'b0;   // IPT_COIN3             - no MiSTer mapping (released)
wire coin4 = 1'b0;   // IPT_COIN4             - no MiSTer mapping (released)

// IN0 (midyunit.cpp:261-276): per player b0-3 stick U/D/L/R, b4 BUTTON4 Crouch,
// b5 BUTTON1 Fire, b6 BUTTON2 Jump, b7 BUTTON3 Rocket Bomb; P2 in b8-15. All
// IP_ACTIVE_LOW -> invert the (active-high) MiSTer press bits.
wire [15:0] in0 = ~{ p2_rb,p2_jump,p2_fire,p2_crouch, p2_rt,p2_lf,p2_dn,p2_up,
                     p1_rb,p1_jump,p1_fire,p1_crouch, p1_rt,p1_lf,p1_dn,p1_up };

// IN1 (midyunit.cpp:279-292): b0 Coin1, b1 Coin2, b2 Coin3, b3 Tilt,
// b4 Service(NO_TOGGLE), b5 Video Freeze(UNUSED), b6 Vault, b7 Coin4,
// b8 Start1, b9 Start2, b10 talkback_strobe(CUSTOM ACTIVE_HIGH sound seam),
// b11 mem-protect interlock(UNUSED), b12-15 UNUSED. Active-low bits inverted;
// the b10 talkback strobe is active-high and tied 0 (built bit-explicit so the
// two polarities are not mixed under one ~).
wire in1_talkback_strobe = 1'b0;   // TODO(sound): narc_talkback_strobe_r, wire from narc_sound_board
wire [15:0] in1 = { 4'b1111,               // b15-12 UNUSED (active-low, released)
                    1'b1,                  // b11 mem-protect interlock UNUSED (released)
                    in1_talkback_strobe,   // b10 talkback_strobe ACTIVE-HIGH sound seam (tied 0)
                    ~start2,               // b9  START2
                    ~start1,               // b8  START1
                    ~coin4,                // b7  COIN4
                    ~vault,                // b6  Vault Switch (IPT_OTHER)
                    1'b1,                  // b5  Video Freeze UNUSED (released)
                    ~service,              // b4  SERVICE (NO_TOGGLE)
                    ~tilt,                 // b3  TILT / slam
                    ~coin3,                // b2  COIN3
                    ~coin2,                // b1  COIN2
                    ~coin1 };              // b0  COIN1

// IN2 (midyunit.cpp:304-306): b0-7 talkback_data (CUSTOM ACTIVE_HIGH sound
// readback, tied 0), b8-15 UNKNOWN (active-low, released).
wire [7:0] in2_talkback_data = 8'h00;  // TODO(sound): narc_talkback_data_r, wire from narc_sound_board
wire [15:0] in2 = { 8'hFF, in2_talkback_data };

// DSW (midyunit.cpp:308-309): all 16 bits IPT_UNKNOWN, unused -> 0xFFFF (no DIPs).
wire [15:0] dsw = 16'hFFFF;

wire [63:0] inputs = {dsw, in2, in1, in0};

////////////////////////////////////////////////////////////////////////////////
// GAME
////////////////////////////////////////////////////////////////////////////////
wire reset = RESET | status[0] | buttons[1] | ~locked;
reg  rst_pon = 1'b1;
always @(posedge clk_sys) rst_pon <= RESET | ~locked;   // power-on only (sound board full reset)
// P0022: TRUE power-on for the PERSISTENT SDRAM/download subsystem. ~locked (PLL) synchronized
// into clk_sys (2-FF, clean removal). It is LOW during ANY ROM download (which always follows
// PLL lock), so the capture path keeps running even if the framework holds RESET high across
// the download — the black-screen root cause was that RESET froze the whole SDRAM path. This
// does NOT include RESET (rst_pon does), which is the whole point: rst_pon would freeze too.
reg  sdram_por_m = 1'b1, sdram_por = 1'b1;
always @(posedge clk_sys) begin sdram_por_m <= ~locked; sdram_por <= sdram_por_m; end

reg [7:0] sw[2];
always @(posedge clk_sys)
	if (ioctl_wr && (ioctl_index == 254) && !ioctl_addr[24:1]) sw[ioctl_addr[0]] <= ioctl_dout;

// Core-top selection: the real Z-unit core, or (with +define+DIAG_SDRAM) the self-contained
// SDRAM loopback diagnostic (rtl/diag/smashtv_diag_top.sv) — same ports, so no rewiring. The
// diagnostic discards the CPU and paints the SDRAM read/write self-test result to the screen.
`ifdef DIAG_ROM
 `define CORE_TOP smashtv_diag_rom
`elsif DIAG_SDRAM
 `define CORE_TOP smashtv_diag_top
`else
 `define CORE_TOP zunit_top
`endif
// P0019 single-clock: zunit_top runs CPU/memory/SDRAM/video on `clk` with an internal
// cpu_ce = clk/4 (CPU_CE_DIV=4, M1 CONFIRMED) — NO async clk_cpu/clk_snd/rst_pon. The
// CPU timing is intentionally fixed. VRAM is on the SDRAM word channel
// (ZT_SDRAM_CHASSIS); the DDR3 lane is the M2 slice.
`CORE_TOP #(.ROM_HEX("")) zunit_top
(
	.clk(clk_sys),
	.ce_pix(ce_pix),
	.rst(reset),
	.sdram_por(sdram_por),

	.inputs(inputs),

	// ---- ioctl ROM download (remap FSM -> SDRAM words; MRA demux refines next step) ----
	.ioctl_download(rom_download),
	.ioctl_wr(yt_ioctl_wr),
	.ioctl_addr(yt_ioctl_addr),
	.ioctl_dout(yt_ioctl_dout),
	.ioctl_be(yt_ioctl_be),
	.ioctl_wait(yt_ioctl_wait),

	// ---- SDRAM (MT48LC16M16) — all core traffic + ROM download ----
	.SDRAM_DQ(SDRAM_DQ),
	.SDRAM_A(SDRAM_A),
	.SDRAM_BA(SDRAM_BA),
	.SDRAM_DQML(SDRAM_DQML),
	.SDRAM_DQMH(SDRAM_DQMH),
	.SDRAM_nCS(SDRAM_nCS),
	.SDRAM_nRAS(SDRAM_nRAS),
	.SDRAM_nCAS(SDRAM_nCAS),
	.SDRAM_nWE(SDRAM_nWE),
	.SDRAM_CKE(SDRAM_CKE),

`ifdef USE_DDR3_VRAM
	// ---- HPS DDR3 VRAM lane (scanout row-cache + CPU field RMW + blitter fb) ----
	.ddram_addr(core_ddram_addr), .ddram_burstcnt(core_ddram_burstcnt),
	.ddram_rd(core_ddram_rd), .ddram_we(core_ddram_we),
	.ddram_din(core_ddram_din), .ddram_be(core_ddram_be),
	.ddram_busy(DDRAM_BUSY), .ddram_dout(DDRAM_DOUT), .ddram_dout_ready(DDRAM_DOUT_READY),
`endif

	// ---- sound latch decode (observability; narc_sound_board is internal, ZT_SOUND) ----
	.snd_select(),
	.snd_trig(),
	.snd_reset(),

	// ---- sound-ROM read seam: D1 RESOLVED and CLOSED INSIDE zunit_top (zunit_snd_rom
	//      reads the images the download demux now writes at SDRAM_SNDW_BASE). Only the
	//      offsets + the actual falling-E deadline-stall counter come out for observability. ----
	.mst_rom_offset(),
	.slv_rom_offset(),
	.snd_rom_stall_clks(snd_stall_clks),

	// ---- audio (signed PCM) ----
	.audio_l(AUDIO_L), .audio_r(AUDIO_R),

	// ---- video ----
	.vid_r(r), .vid_g(g), .vid_b(b),
	.hsync(hsync), .vsync(vsync), .hblank(hblank), .vblank(vblank), .de(de),
	.rgb_valid(rgb_valid),

	// ---- observability (subset; blit_busy/erase_busy left open) ----
	.pc_dbg(dbg_pc), .illegal_dbg(dbg_illegal),
	.int1_dbg(dbg_int1), .blit_busy(), .erase_busy(),
	.vblank_irq(dbg_vblank_irq),
	.dbg_dma_we(dbg_dma_we), .dbg_dma_addr(dbg_dma_addr), .dbg_dma_wdata(dbg_dma_wdata),
	// P0020/P0022 download-audit taps (cab bring-up): FIFO accepted/dropped + held-reset latch.
	.fifo_accepted(iol_accepted), .fifo_dropped(iol_dropped), .rst_during_dl(iol_rst_during),
	// P0022 first-fetch latch (§6): the addr+data the CPU received on its first read.
	.dbg_ff_addr(ff_addr), .dbg_ff_data(ff_data), .dbg_ff_valid(ff_valid)
	, .dbg_rb_data(rb_data), .dbg_rb_valid(rb_valid)
	, .dbg_cksum_w0(cksum_w0), .dbg_cksum_w1(cksum_w1), .dbg_cksum_w2(cksum_w2), .dbg_cksum_valid(cksum_valid)
`ifndef DIAG_ROM
`ifndef DIAG_SDRAM
	// DIAG_BOOT liveness lanes: expose the real NARC chassis/core signals.
	, .dbg_core_rst_o(dbg_core_rst), .dbg_sdram_ready_o(dbg_sdram_ready)
	, .dbg_unp_done_o(dbg_unp_done), .dbg_cpu_req_o(dbg_cpu_req)
	, .dbg_mem_ack_o(dbg_mem_ack), .dbg_cpu_ce_o(dbg_cpu_ce)
`ifdef DIAG_BOOT
	// Sound-campaign instruments (DIAG_BOOT-only ports on zunit_top).
	, .dbg_snd_cksum_w0(snd_cksum_w0), .dbg_snd_cksum_valid(snd_cksum_valid)
	, .dbg_snd_lo_sum(snd_lo_sum)
	, .dbg_snd_ff_offset(snd_ff_offset), .dbg_snd_ff_data(snd_ff_data)
	, .dbg_snd_ff_valid(snd_ff_valid)
	, .dbg_snd_gap_clks(snd_gap_clks)
	, .dbg_snd_req_count(snd_req_count), .dbg_snd_ack_count(snd_ack_count)
	, .dbg_snd_wd_rearms(snd_wd_rearms)
	, .dbg_snd_cmd_count(snd_cmd_count), .dbg_snd_audio_changes(snd_audio_changes)
	, .dbg_snd_pa_data(snd_pa_data), .dbg_snd_pa_valid(snd_pa_valid)
	, .dbg_snd_pa_addr_match(snd_pa_addr_match)
	, .dbg_snd_land_data(snd_land_data), .dbg_snd_land_seen(snd_land_seen)
`endif
`endif
`endif
);
// ---- boot-instrument overlay (+define+DIAG_BOOT): paints the real core's boot state ----
`ifdef DIAG_BOOT
// ---- DDR3 SCANOUT-HEALTH MONITOR (isolate MEMORY vs VIDEO on the cab) ------------------------
// Watches the REAL f2sdram Avalon traffic (DDRAM_* are emu-level, so no core re-threading). A
// read is accepted on (RD & ~BUSY) carrying BURSTCNT beats; each DOUT_READY is one beat. If beats
// stop arriving before the burst is met (>~1500 clk idle mid-burst) the bridge UNDER-DELIVERED
// the burst = the scanout wedge. Single-outstanding (the agent), so one FSM tracks it.
//   ddr_wedge (sticky) -> status bar RED  => the burst STILL under-delivers on silicon (drop BMAX).
//   ddr_wedge 0 + row3 counters climbing   => DDR3 reads COMPLETE (fix landed) -> the garbage is
//                                             DOWNSTREAM (video/palette/page), not memory.
//   row 3 (8 hex) = {DDR reads[15:0], DDR beats[15:0]} -- both should climb together when healthy.
reg [15:0] ddr_reads=16'd0, ddr_beats=16'd0; reg [7:0] ddr_expect=8'd0; reg [11:0] ddr_idle=12'd0;
reg ddr_outst=1'b0, ddr_wedge=1'b0;
always @(posedge clk_sys) begin
	if (~locked) begin ddr_reads<=0; ddr_beats<=0; ddr_expect<=0; ddr_idle<=0; ddr_outst<=0; ddr_wedge<=0; end
	else if (DDRAM_RD & ~DDRAM_BUSY & ~ddr_outst) begin           // burst accepted
		ddr_reads<=ddr_reads+16'd1; ddr_expect<=DDRAM_BURSTCNT; ddr_outst<=1'b1; ddr_idle<=12'd0;
	end else if (ddr_outst) begin
		if (DDRAM_DOUT_READY) begin                                // a beat arrived
			ddr_beats<=ddr_beats+16'd1; ddr_idle<=12'd0;
			ddr_outst<=(ddr_expect>8'd1); ddr_expect<=ddr_expect-8'd1;
		end else begin                                             // mid-burst stall -> wedge
			ddr_idle<=ddr_idle+12'd1; if (ddr_idle>12'd1500) ddr_wedge<=1'b1;
		end
	end
end
wire [31:0] ddr_stat = {ddr_reads, ddr_beats};

// WRITE-side health (P1.5 RMW fix). The cab white/purple was masked single-beat writes clobbering
// the 3 neighbor entries of a shared 64-bit beat (the real f2h_sdram1 drops per-byte BE on a 1-beat
// write). The fix makes EVERY VRAM write a FULL-beat write (be=FF) -- which is immune to BE-drop by
// construction (all 8 bytes written regardless of how the bridge treats BE). So on a healthy silicon
// fix, ddr_masked stays 0 (no be!=FF write ever slips through) and ddr_writes climbs as the blitter
// draws. A masked write here => the RMW path is NOT active => status bar RED.
reg [15:0] ddr_writes=16'd0; reg ddr_masked=1'b0;
always @(posedge clk_sys) begin
	if (~locked) begin ddr_writes<=16'd0; ddr_masked<=1'b0; end
	else if (DDRAM_WE & ~DDRAM_BUSY) begin
		ddr_writes <= ddr_writes + 16'd1;
		if (DDRAM_BE != 8'hFF) ddr_masked <= 1'b1;   // masked write = fix not active on silicon
	end
end

// ---- BLIT-COUNT MONITOR (cont.22): measure the blit-count DEFICIT vs MAME on the cab. dbg_int1 =
// the blitter done-IRQ (exactly one 0->1 edge per COMPLETED blit); dbg_vblank_irq = frame boundary.
// Sim proved our command DELIVERY is complete (all regs, correct values) in the correct-render
// config, so a low count here = the CPU is STARVED out of issuing blits (not dropping commands).
//   row 2 = blit_total[31:0]  (running count -- CLIMBS = blits happening; rate = throughput)
//   row 3 = {blit_max[15:0], blit_last[15:0]}  (PEAK-per-frame, last-frame)
// Let attract run through its screens; read row3 PEAK and compare to the MAME golden (mame-trace/
// dma_cmd.log: ~36 blits/frame avg, the high-score screen is the busiest). blit_max << MAME peak
// = the starvation deficit CONFIRMED (the missing text is blits the CPU never got to issue).
reg int1_d=1'b0, vbl_d=1'b0;
reg [31:0] blit_total=32'd0;
reg [15:0] blit_frame=16'd0, blit_last=16'd0, blit_max=16'd0;
always @(posedge clk_sys) begin
	int1_d <= dbg_int1; vbl_d <= dbg_vblank_irq;
	if (~locked) begin blit_total<=32'd0; blit_frame<=16'd0; blit_last<=16'd0; blit_max<=16'd0; end
	else begin
		if (dbg_int1 & ~int1_d) begin blit_total <= blit_total + 32'd1; blit_frame <= blit_frame + 16'd1; end
		if (dbg_vblank_irq & ~vbl_d) begin                              // frame boundary: latch + reset
			blit_last <= blit_frame;
			if (blit_frame > blit_max) blit_max <= blit_frame;
			blit_frame <= 16'd0;
		end
	end
end
wire [31:0] blit_stat = {blit_max, blit_last};

// RESET-EDGE COUNTER: the cheapest disproof of "our RTL is re-resetting the CPU" (the full
// pipeline+asm audit found NO watchdog model and NO periodic reset generator anywhere in this
// RTL -- `reset`/`core_rst` are a level-combinational OR of RESET/status[0]/buttons[1]/~locked,
// re-evaluated every clock, not edge-latched -- so nothing should re-fire it after the initial
// power-on drop UNLESS something external (PLL relock glitch, a stray OSD/button assert) does).
// Counts every RISING edge of `reset` in the ~locked-only domain (mirrors dl_ytwr_cnt below), so
// it SURVIVES core_rst and answers directly: repeat count stays at its post-boot value (usually 1,
// the initial power-up drop) = the cab's repeating white/purple loop is the GAME'S OWN software
// loop (BURN_IN, historicalsource/smashtv DIAG.ASM:269,500-502, which re-runs RAMCHECK+DSCRCLR+the
// chip screen every attract pass); count climbing = something IS re-asserting reset/core_rst on
// real silicon, a genuine RTL-side bug distinct from the DDR3-slowness/gating fixes already landed.
reg [15:0] rst_edge_cnt=16'd0; reg reset_d=1'b1;
always @(posedge clk_sys) begin
	if (~locked) begin rst_edge_cnt<=16'd0; reset_d<=1'b1; end
	else begin
		reset_d <= reset;
		if (reset & ~reset_d) rst_edge_cnt <= rst_edge_cnt + 16'd1;
	end
end

// ---- cont.24 SPLASH COMMAND-CAPTURE (+define+DIAG_SPLASHCAP): reconstruct the title-splash blit
// commands from the DMA reg-write stream and latch the LEFT (x=5) + RIGHT (x=315) blue-column
// blits, so the cab tells us whether our CPU issues the right command + whether the source reads
// nonzero. Golden (MAME f2050): LEFT cmd=8002 (unflip, bit4=0) SAG=026BD848/026D1688; RIGHT
// cmd=8002 SAG=027D5000/027E8E40; both source bytes NONZERO. Rows (read while the splash is up,
// ~30s no coin): row1=LEFT SAG, row2=LEFT cmd (bit4 set => spurious flip = (A) command corrupt),
// row3={LEFT srcbyte, RIGHT srcbyte, LEFT x, LEFT h} (LEFT srcbyte 00 while RIGHT !=00 => (B) HW
// source reads ZERO at ~0.86MB), row4=boot-scanout CRC (DIAG_BOOTSCAN) else RIGHT SAG.
`ifdef DIAG_SPLASHCAP
reg [15:0] shx=0, shh=0, shol=0, shoh=0;
reg [15:0] Lcmd=0, Rcmd=0; reg [31:0] Lsag=0, Rsag=0; reg [7:0] Lx=0, Lh=0, Lsrcb=0, Rsrcb=0;
reg [15:0] Lany=0, Lmatch=0;   // Lany = last cmd of ANY blit at the left-col position (any mode);
reg [1:0]  pend=2'd0;          // Lmatch = # of READMODE left-col blits captured (splash validity)
// FILLCAP: capture whether the CPU issues narrow-tall (vertical) vs wide-short (horizontal) mode-C fills
reg [15:0] shw=0;                                  // WIDTH (DMA_WIDTH = addr 6)
reg [15:0] NVcnt=0, NWcnt=0, NVcmd=0;              // vertical-fill count, horizontal-fill count, last vert cmd
reg [7:0]  NVw=0, NVh=0; reg [15:0] NVx=0;         // last vertical fill W, H, x
reg [15:0] HWlat=0, HXlat=0;                       // last horizontal fill W, x (control)
// A blit is READMODE (reads gfx source) iff cmd[3:0] in 1..0xB; modes 0xC..0xF are constant FILLS
// (the per-frame left-edge ERASE is mode 0xC, and would otherwise masquerade as the column blit).
wire [15:0] trig_c = dbg_dma_wdata;
wire        rmode  = (trig_c[3:0]>=4'd1) && (trig_c[3:0]<=4'd11);
wire        lpos   = ($signed(shx)>=16'sd3)   && ($signed(shx)<=16'sd10)  && (shh>16'd100);
wire        rpos   = ($signed(shx)>=16'sd310) && ($signed(shx)<=16'sd320) && (shh>16'd100);
always @(posedge clk_sys) begin
	if (~locked) begin shx<=0;shh<=0;shol<=0;shoh<=0;Lcmd<=0;Rcmd<=0;Lsag<=0;Rsag<=0;Lx<=0;Lh<=0;Lsrcb<=0;Rsrcb<=0;Lany<=0;Lmatch<=0;pend<=2'd0;shw<=0;NVcnt<=0;NWcnt<=0;NVcmd<=0;NVw<=0;NVh<=0;NVx<=0;HWlat<=0;HXlat<=0; end
	else begin
		if (dbg_dma_we) begin
			if      (dbg_dma_addr==4'd4) shx <= dbg_dma_wdata;   // XSTART
			else if (dbg_dma_addr==4'd6) shw <= dbg_dma_wdata;   // WIDTH
			else if (dbg_dma_addr==4'd7) shh <= dbg_dma_wdata;   // HEIGHT
			else if (dbg_dma_addr==4'd2) shol<= dbg_dma_wdata;   // OFFSETLO
			else if (dbg_dma_addr==4'd3) shoh<= dbg_dma_wdata;   // OFFSETHI
			else if (dbg_dma_addr==4'd0 && trig_c[15]) begin     // COMMAND trigger
				if (trig_c[3:0]==4'hC) begin                     // FILLCAP: mode-C constant FILL -> classify shape
					if (shw<=16'd6 && shh>=16'd16) begin         // NARROW-TALL = a vertical box side
						NVcnt<=NVcnt+16'd1; NVcmd<=trig_c; NVw<=shw[7:0]; NVh<=shh[7:0]; NVx<=shx;
					end else if (shw>=16'd40 && shh<=16'd8) begin // WIDE-SHORT = a horizontal box side
						NWcnt<=NWcnt+16'd1; HWlat<=shw; HXlat<=shx;
					end
				end
				if (lpos) begin
					Lany <= trig_c;                              // any-mode cmd at left col (catches a corrupted fill)
					if (rmode) begin                             // the REAL readmode column blit
						Lcmd<=trig_c; Lsag<={shoh,shol}; Lx<=shx[7:0]; Lh<=shh[7:0];
						Lmatch<=Lmatch+16'd1; pend<=2'd1;
					end
				end else if (rpos && rmode) begin
					Rcmd<=trig_c; Rsag<={shoh,shol}; pend<=2'd2;
				end
			end
		end
		if (dbg_src_ack && pend!=2'd0) begin        // first source byte of the matched readmode blit
			if (pend==2'd1) Lsrcb<=dbg_src_data; else Rsrcb<=dbg_src_data;
			pend<=2'd0;
		end
	end
end
`ifdef DIAG_BOOTSCAN
// boot-noise scanout CRC vs MAME: accumulate the scanout stream over a boot window (RAM-test
// patterns, deterministic). Compare row4 to the MAME VRAM golden CRC (scene_boot golden).
reg [31:0] bscan_crc=0; reg [15:0] bscan_fr=0; reg bvbl_d=0;
always @(posedge clk_sys) begin
	if (~locked) begin bscan_crc<=0; bscan_fr<=0; bvbl_d<=0; end
	else begin
		bvbl_d <= dbg_vblank_irq;
		if (dbg_vblank_irq & ~bvbl_d) bscan_fr <= bscan_fr + 16'd1;
		if (dbg_scan_ack && bscan_fr>=16'd20 && bscan_fr<16'd120)
			bscan_crc <= {bscan_crc[30:0], bscan_crc[31]} ^ {16'd0, dbg_scan_data};
	end
end
wire [31:0] r4v_unused = bscan_crc;   // boot CRC confirmed stable (122FE75A); row4 now = validity
`endif
// row4 = {Lmatch, Lany}: Lmatch climbs => a READMODE left-column blit fired (we are on the splash +
// the column IS issued as readmode). Lany = last ANY-mode cmd at the left-col position. So:
//   Lmatch climbs, row2=8002        -> column readmode blit fires correctly (read rows 1-3)
//   Lmatch stuck 0, Lany=800C       -> the left-col blit fires ONLY as a FILL = (A) command wrong
//   Lmatch=0, Lany=0 on the splash  -> no left-col blit at all (upstream drop)
// FILLCAP retarget: does the CPU ISSUE the revision-box narrow-tall (W<=6,H>=16) mode-C verticals?
//   row1 r1v = {NVcnt, NWcnt}  -> vert-fill count (left 4 hex) | horiz-fill count (right 4 hex)  <== THE ANSWER
//   row2 r2v = NVcmd           -> 800C if a vertical fill EVER fired, 0000 if never
//   row3 r3v = {NVw,NVh,NVx}   -> last vertical geom: WW HH XXXX (expect 03 23 000A or 03 23 017D)
//   row4 r4v = {HWlat,HXlat}   -> horizontal control geom: WWWW XXXX (expect 0176 000A)
// READOUT on the REVISION screen: NVcnt>0 + row3=0323000A/017D => CPU DOES issue verticals => bug is
// DOWNSTREAM (write/display). NVcnt==0 while NWcnt>0 => CPU draws horizontals but NEVER verticals =>
// UPSTREAM command-gen bug (the whole write-path hunt was a phantom).
wire [31:0] r1v = {NVcnt, NWcnt};
wire [31:0] r2v = {16'h0000, NVcmd};   // row2 port is 32-bit under DIAG_BOOT
wire [31:0] r3v = {NVw, NVh, NVx};
wire [31:0] r4v = {HWlat, HXlat};
`elsif DIAG_ROMCHKSUM
// U41/U23 full-range sweep-checksum (rtl/zunit/zunit_rom_chksum_audit.sv). Compare
// against the offline golden (rtl/zunit/tools/compute_u23_chksum.py, computed
// straight from narc.zip -- NOT embedded in hardware, screen-as-logic-analyzer):
//   row1 w0=DAB1AB82 (hi_xor|lo_xor|hi_sum16)  row2 = w1 upper 16 (block3|block2)
//   row3 w1=0B0A5238 (block3|block2|block1|block0)   row4 w2=D49548B8 (block7..4)
// A mismatch on row3/row4 ISOLATES the divergence to one of the 8 blocks (each
// 0x4000 words = 16KB of U23, maindata byte [0xC0001+block*0x8000, +0x8000), odd lane).
wire [31:0] r1v = cksum_w0;
wire [31:0] r2v = {16'h0000, cksum_w1[31:16]};   // row2 port is 32-bit under DIAG_BOOT
wire [31:0] r3v = cksum_w1;
wire [31:0] r4v = cksum_w2;
`else
// =============================================================================
// DIAG_BOOT OVERLAY ROW MAP -- SOUND CAMPAIGN (SPEC 29.4 item 2, 2026-07-30).
// Repurposed from the v4 DDR3-traffic rows: DDR3 read/write health, the blit
// counters and the reset-edge counter all already reported HEALTHY on the cab
// (v8a/v8b sessions), and every fault term of the retired v3 BITMASK row still
// drives the status-bar `derailed` OR below (a red bar keeps its exact prior
// meaning) -- those rows were the least-diagnostic content left. The open
// question is SOUND (totally silent since v7y; every offline surface is
// exonerated by sim/tb_narc_snd_realchain.sv), so the four rows now measure
// the silicon sound chain end to end. Offline goldens computed straight from
// narc.zip by rtl/zunit/tools/compute_snd_chksum.py.
//
// row1 = iol_accepted -- INSTRUMENT ZERO (v3 row restored; MUST stay). Exact
//        SDRAM word-writes accepted by the download FIFO.
//        EXPECTED 00520000 (0x400000 gfx+prog + 0x120000 sound byte-lane
//        writes). Anything less = the sound bytes were never even OFFERED to
//        SDRAM (upstream of every other sound instrument). FIFO drops still
//        surface through the status bar's |iol_dropped term.
// row2 = {snd_stall_clks[31:16], snd_gap_clks[15:0]} -- instruments 2+4.
//        Left 4 hex: UPPER half of zunit_top's falling-E deadline-stall
//        counter (already wired to the emu; previously dropped on the floor).
//        0000 = 6809s running free; climbing = SDRAM starvation of the sound
//        lane (SPEC 29.2 mechanism 1); frozen nonzero = E wedged.
//        Right 4 hex: clk_sys cycles from rst_sys fall to snd_board_rst fall,
//        16-bit saturating. EXPECTED ~002B (43, tb_narc_ym_clock_en_longrst);
//        a large/FFFF value contradicts that sim (29.2 mechanism 2).
//        Healthy boot photo: 0000002B (exact gap may vary by a few clks).
// row3 = {snd_ff_valid, snd_cksum_valid, 2'b00, snd_ff_offset[19:0],
//        snd_ff_data[7:0]} -- instrument 3 plus the sweep-done flag.
//        The master 6809's FIRST acknowledged sound-ROM fetch after
//        snd_board_rst release. EXPECTED C8FFFEC0: top digit C = fetch
//        captured + sound sweep done (8 = fetch only, 4 = sweep only,
//        0 = neither); offset 8FFFE = the 6809 reset-vector HIGH byte
//        (masterupper bank, williamssound.cpp:547); data C0 = u5[0xFFFE]
//        (reset vector C060 -- compute_snd_chksum.py / make_hex.py agree).
//        Top digit stuck at 4/0 = the master 6809 never issued a ROM fetch
//        (dead CPU / wedged E); data byte 00 = it fetched but SDRAM returned
//        nothing (sound ROM never landed, or the snd arbiter channel broke).
// row4 = {snd_lo_sum[15:0], snd_cksum_w0[15:0]} -- instrument 1. Sound-region
//        sweep over ALL 0x90000 words at SDRAM_SNDW_BASE (master+slave 6809
//        images) through the real arbiter/controller/pins:
//        low-lane 16-bit sum | high-lane 16-bit sum.
//        EXPECTED 43847998 (final once row3's snd_cksum_valid flag sets, well
//        under a second after release). 00000000 = the region is empty;
//        any other value = the bytes in SDRAM are WRONG (the landing path is
//        the bug). The audit's XOR fields are deliberately NOT displayed: the
//        RELOAD-duplicated images make them 00 by construction (no signal).
`ifdef DIAG_SOUND_PRODRESET
// Production-reset sound discriminator, third cabinet cut. The production
// core-reset boundary remains unchanged. During the existing sound-board
// stagger, the boot audit channel reads the same vector word twice; then the
// original passive probes capture the first G_SND completion and CPU byte.
// The two raw words are compared locally in zunit_top so only three result bits
// cross the placement-sensitive core boundary.
// row1: drop | pre-read valid | vector writes seen | count; healthy 70520000
// row2: valid | first==landing | second==landing | first==second; healthy F0000000
// row3: first physical G_SND ACK valid | exact-address match | returned word;
//        healthy C00060C0
// row4: CPU first-fetch offset/data; healthy 88FFFF60
// P0047 STRIP (2026-08-03). Every SOUND diagnostic is retired from this cut. Their question
// is ANSWERED: P0046 is cabinet-confirmed and NARC has working sound. They are not free --
// they sit in the sound cone, and v18 was rejected at Slow 100C with 484 of 538 failing paths
// ending in narc_sound_board|os_m, a 32-bit retriggerable down-counter. v13 fit this same
// macro set at a full-frontier minimum of +0.086 ns, i.e. essentially no margin, so the
// instruments added since (P0044 DQM register, P0046 settle, P0047 probe and its route) could
// not fit alongside instruments measuring a solved problem.
//
// Dropping the sound probes from the overlay makes their logic DEAD and synthesis prunes it,
// which both frees frontier margin and unloads the exact cone that failed -- without touching
// working, cabinet-confirmed sound RTL to make room for a diagnostic.
//
// row1: download health only (drop flag + accepted count) -- outside the sound cone.
// row2: THE MEASUREMENT (first erased row, base-relative). healthy 00000250.
// row3/row4: retired.
wire [31:0] r1v = {|iol_dropped, 7'b0, iol_accepted[23:0]};
wire [31:0] r2v = 32'h00000000;   // retired with the sound campaign
wire [31:0] r3v = 32'h00000000;   // retired with the sound campaign
wire [31:0] r4v = 32'h00000000;   // retired with the sound campaign
`else
wire [31:0] r1v = iol_accepted;
wire [31:0] r2v = {snd_lo_sum, snd_cksum_w0[15:0]};
wire [31:0] r3v = {snd_ff_valid, snd_cksum_valid, 2'b00, snd_ff_offset, snd_ff_data};
wire [31:0] r4v = {snd_lo_sum, snd_cksum_w0[15:0]};
`endif
`endif

smashtv_diag2_overlay u_diag2 (
	.clk(clk_sys), .ce_pix(ce_pix), .rst(reset),
	.core_rst(dbg_core_rst), .sdram_ready(dbg_sdram_ready), .unp_done(dbg_unp_done),
	.ioctl_download(rom_download), .cpu_req(dbg_cpu_req), .mem_ack(dbg_mem_ack),
	.int1(dbg_int1), .vblank_irq(dbg_vblank_irq), .cpu_ce(dbg_cpu_ce),
	.pc(r4v), .illegal(dbg_illegal),
	// DDR3 health: status bar RED on a scanout burst under-delivery (ddr_wedge), a masked write
	// (ddr_masked = RMW fix not active), or a real CPU derail. row3 = {DDR reads[15:0], beats[15:0]}
	// (read health, GREEN+climbing = memory read healthy on silicon -- already cab-confirmed this
	// session). row2 = RESET-EDGE COUNT (was ddr_writes -- write health also already cab-confirmed;
	// freed for the higher-priority question right now, see rst_edge_cnt above): stays at its
	// post-boot value = the repeating white/purple loop is the GAME'S OWN software loop (BURN_IN);
	// climbing = our RTL is genuinely re-resetting the CPU on silicon.
	// cont.22 BLIT-COUNT diag: row2 = blit_last (this frame's count), row3 = {PEAK/frame, last/frame}.
	// MAME golden reference: avg 170.7 blits/frame, PEAK 219. Cab peak (row3 high 4 hex) << 219 = deficit.
	// P0022: additively OR the core's held-reset-during-download latch into the RED status
	// (ddr_wedge/ddr_masked stay 0 here — DDRAM idle — so they add nothing but keep the
	// dead-health signals read). RED status + row3 dropped!=0 = a capture-path freeze on cab.
	// RED if any independent layer disagrees: incomplete/wrong stream or write
	// count, FIFO drop, physical readback mismatch, or CPU receive mismatch.
`ifdef DIAG_ROMCHKSUM
	// status bar: RED while the U41/U23 sweep is still running, GREEN once the
	// full 128K-word pass completes and rows 3/4 are final (no expected-value
	// compare in hardware -- see rtl/zunit/tools/compute_u23_chksum.py).
	.derailed(!cksum_valid),
`elsif DIAG_SOUND_PRODRESET
	// Passive sound mode deliberately has no rb_valid/readback comparison.
	// Keep the bar meaningful using only passive release-image observers.
	// P0047 STRIP: the ff_valid/dl_vec_stream sound term is gone with the rest of the sound
	// campaign, so the bar reports download health only. Keeping it would have held the
	// first-fetch latch alive purely to colour a status pip.
	.derailed(dbg_derailed | ddr_wedge | ddr_masked |
	          !(dl_vec_seen == 4'hF) | (dl_ytwr_cnt != DL_EXPECT_WRITES) |
	          (iol_accepted != DL_EXPECT_WRITES) | (|iol_dropped)),
`else
	.derailed(dbg_derailed | ddr_wedge | ddr_masked |
	          !(dl_vec_seen == 4'hF) | (dl_ytwr_cnt != DL_EXPECT_WRITES) |
	          (iol_accepted != DL_EXPECT_WRITES) |
	          (|iol_dropped) | (rb_valid && (rb_data != dl_vec_stream)) |
	          (ff_valid && rb_valid && (ff_data != rb_data))),
`endif
	.culprit_pc(r1v),
	.culprit_instr(r2v), .derail_pc(r3v),
	// COMPOSITOR (UMK3 overlay, cont.24): feed the core's live raster in; the diag draws into the
	// top-left quadrant and the game shows through everywhere else -> read the numbers AND see the
	// splash behind them (confirm scene + watch the columns draw/black directly).
	.g_r(r), .g_g(g), .g_b(b), .g_hs(hsync), .g_vs(vsync), .g_hb(hblank), .g_vb(vblank), .g_de(de),
	.vid_r(ov_r), .vid_g(ov_g), .vid_b(ov_b),
	.hsync(ov_hs), .vsync(ov_vs), .hblank(ov_hb), .vblank(ov_vb), .de(ov_de));
`else
assign {ov_r,ov_g,ov_b,ov_hs,ov_vs,ov_hb,ov_vb,ov_de} = '0;
`endif

endmodule
