#!/usr/bin/env python3
"""Byte-diff the zunit_memsys POST VRAM window against MAME 0.280's captured POST
window, for every real attract blit. NO tolerance.

Oracle  = mame-trace/goldens/narc_blit_capture.txt (frozen MAME real blits).
DUT out = dut.txt (POST VRAM window read back by tb_zunit_memsys_realblit.sv).

Unlike the zunit_dma real-blit gate (which reconstructs POST = PRE + observed FB
writes), this reads the ACTUAL VRAM inside zunit_mem after the blit ran through
the full memsys glue (CPU bus -> D_LO/D_HI decode -> zunit_dma -> fb write port
-> VRAM). So a byte mismatch here means the INTEGRATION is wrong (decode, routing,
or fb write-back), not just the blitter kernel. A DUT gfx fetch outside the
captured span (oob flag) is a HARD FAIL.

Prints "<pass>/<n> byte-exact"; exit 0 iff every blit is byte-exact (and n==NBLITS
matches the golden replay's count).
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
GOLDEN_DIR = os.path.abspath(os.path.join(
    HERE, "..", "..", "..", "mame-trace", "blitter_golden"))
sys.path.insert(0, GOLDEN_DIR)
from replay_diff import parse_capture, DEFAULT  # noqa: E402

CAP = os.environ.get("CAPTURE", DEFAULT)
DUT = os.path.join(HERE, "dut.txt")


def parse_dut(path):
    """Return list of blits, each = {"oob": bool, "post": {y: [words]}}."""
    blits = []
    cur = None
    with open(path) as f:
        for line in f:
            p = line.split()
            if not p:
                continue
            if p[0] == "BLIT":
                cur = {"oob": p[2] != "0", "post": {}}
                blits.append(cur)
            elif p[0] == "POST":
                y = int(p[1])
                cur["post"][y] = [int(v, 16) for v in p[2:]]
    return blits


def diff_one(cap, dut):
    """Return list of mismatch strings (empty = byte-exact)."""
    x0, y0, x1, y1 = cap["rect"]
    errs = []
    if dut["oob"]:
        return ["  HARD FAIL: DUT fetched gfx byte outside captured span"]

    for y in range(y0, y1 + 1):
        want = cap["post"][y]
        got = dut["post"].get(y)
        if got is None:
            errs.append(f"  y={y}: DUT dumped no POST row")
            return errs
        if len(got) != len(want):
            errs.append(f"  y={y}: DUT row len {len(got)} != {len(want)}")
            return errs
        for i, (g, w) in enumerate(zip(got, want)):
            if g != w:
                errs.append(f"  ({x0 + i},{y}): rtl {g:04X} != mame {w:04X}")
                if len(errs) >= 8:
                    errs.append("  ... (truncated)")
                    return errs
    return errs


def main():
    caps = parse_capture(CAP)
    duts = parse_dut(DUT)
    if len(caps) != len(duts):
        print(f"FAIL: blit count mismatch capture={len(caps)} dut={len(duts)}")
        return 1

    n = len(caps)
    npass = 0
    for cap, dut in zip(caps, duts):
        errs = diff_one(cap, dut)
        cmd = cap["regs"][0]
        tag = "OK " if not errs else "FAIL"
        print(f"[{tag}] blit n={cap['meta']['n']} CMD={cmd:04X} "
              f"key={cap['meta']['key']} rect={cap['rect']}")
        if errs:
            print("\n".join(errs))
        else:
            npass += 1

    print(f"\n{npass}/{n} byte-exact")
    ok = (npass == n and n >= 6)
    print("GATE: " + ("PASS -- memsys POST VRAM byte-exact vs MAME real blits"
                      if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
