#!/usr/bin/env bash
# zunit_dma blitter cross-diff matrix vs dma_golden.py (iverilog).
#   ./run.sh
# Base build must be 320/320 byte-exact; each named mutant must DIE (compare
# FAIL). Keep every path quoted (repo tree contains a space).
set -u
export PATH="/c/iverilog/bin:$PATH"
PY="${PYTHON:-python}"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DUT="$ROOT/rtl/zunit/zunit_dma.sv"
TB="$HERE/tb_zunit_dma_matrix.sv"

cd "$HERE"

echo "== generating matrix + golden =="
"$PY" gen_cases.py || { echo "GEN FAIL"; exit 1; }

build_run() {   # $1 = extra defines (may be empty)
  local defs="$1"
  rm -f build.vvp dut.txt
  iverilog -g2012 $defs -I "$HERE" -s tb_zunit_dma_matrix \
      -o build.vvp "$PKG" "$DUT" "$TB" 2> iverilog.log
  if [ $? -ne 0 ]; then echo "IVERILOG FAIL"; cat iverilog.log; return 2; fi
  vvp build.vvp > vvp.log 2>&1
  "$PY" compare.py
  return $?
}

echo "== BASE (expect PASS) =="
build_run ""
BASE=$?
if [ $BASE -ne 0 ]; then echo "RESULT: BASE FAILED"; exit 1; fi

echo "== MUTANTS (each expect FAIL / die) =="
MUTS="MUT_CMD_DECODE MUT_FLIPX_REWIND MUT_CLIP MUT_SRC_ADVANCE"
ALL_DIE=1
for M in $MUTS; do
  build_run "-D$M"
  rc=$?
  if [ $rc -eq 0 ]; then
    echo "  $M : SURVIVED  <-- BAD (mutant not caught)"
    ALL_DIE=0
  elif [ $rc -eq 2 ]; then
    echo "  $M : COMPILE-ERROR <-- BAD"
    ALL_DIE=0
  else
    echo "  $M : DIED (caught)"
  fi
done

echo "== SUMMARY =="
if [ $ALL_DIE -eq 1 ]; then
  echo "RESULT: PASS  (base byte-exact; all 4 mutants died)"
  exit 0
else
  echo "RESULT: FAIL  (a mutant survived)"
  exit 1
fi
