#!/usr/bin/env python3
"""Byte-exact cross-diff: dut.txt (zunit_dma RTL) vs golden.txt (dma_golden.py).

Both files are the SAME format:
    CASE <c> <nwrites>
    <addr5hex> <data4hex>   x nwrites
Exits non-zero on the FIRST divergence.  Prints 'N/N cases byte-exact'.
"""
import sys, os

HERE = os.path.dirname(os.path.abspath(__file__))

def parse(path):
    cases = {}
    cur = None
    with open(path) as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            if ln.startswith("CASE"):
                _, c, n = ln.split()
                cur = int(c)
                cases[cur] = {"n": int(n), "w": []}
            else:
                cases[cur]["w"].append(ln.upper())
    return cases

def main():
    gold = parse(os.path.join(HERE, "golden.txt"))
    dut  = parse(os.path.join(HERE, "dut.txt"))

    if set(gold.keys()) != set(dut.keys()):
        print("FAIL: case-set mismatch gold=%d dut=%d" % (len(gold), len(dut)))
        return 1

    ncase = len(gold)
    for c in sorted(gold.keys()):
        g, d = gold[c], dut[c]
        if g["n"] != d["n"]:
            print("FAIL case %d: write-count gold=%d dut=%d" % (c, g["n"], d["n"]))
            return 1
        if g["w"] != d["w"]:
            # find first differing line
            for i, (gw, dw) in enumerate(zip(g["w"], d["w"])):
                if gw != dw:
                    print("FAIL case %d write %d: gold=[%s] dut=[%s]" % (c, i, gw, dw))
                    return 1
            print("FAIL case %d: write list differs (len g=%d d=%d)"
                  % (c, len(g["w"]), len(d["w"])))
            return 1

    print("PASS: %d/%d cases byte-exact vs dma_golden.py" % (ncase, ncase))
    return 0

if __name__ == "__main__":
    sys.exit(main())
