#!/usr/bin/env python3
# Regenerate the fast-forward sim ROM. Patches the long power-on self-test loops
# to return immediately (pass) so integrated sims reach attract/gameplay without
# grinding through the ~140M-cycle POST + the multi-ROM checksums. HW keeps the
# real self-test; this is a sim-only ROM.
#
# Each patched routine is entered via `EXGPC B5` (the caller loads B5 with the
# routine addr, CLRs B0, then EXGPC B5 — so B5 holds the return addr and B0=0 on
# entry). Overwriting the routine's FIRST word with 0x0135 (EXGPC B5) makes it
# return immediately with B0=0 = "no error", exactly like the routine's own
# natural EXGPC-B5 exit.
#
# Patches:
#   0xfff4ebf0  0x0550 SETF  -> 0x0135 EXGPC B5   POST RAM/VRAM test + gfx checksum
#   0xfff4f170  0x5652 CLR B2-> 0x0135 EXGPC B5   "CHECKING ROMS" per-ROM byte-sum
#
# Usage:  python3 sim/make_ffwd_hex.py    (run from repo root; needs build/*.hex)
import sys
src = "sim/build/smashtv_maindata.hex"
dst = "sim/build/smashtv_maindata_ffwd.hex"
PATCHES = [
    (0xfff4ebf0, "0550", "0135"),   # POST RAM/VRAM test -> EXGPC B5 (its reg leftovers
                                    # don't reach main code; verified reg-diff at FFE0F8A0)
    # ROM checksum ("CHECKING ROMS", fff4f170): a per-descriptor byte-sum that GATES
    # (CMP expected,computed -> sets a bad-ROM bit in B0) and walks A14 += 0xA0 per ROM.
    # A blind EXGPC-skip of the whole routine leaves A14 at the descriptor-table base and
    # B0's cascade wrong -> main code derails into font data. Instead, keep the descriptor
    # walk + display intact and only (a) short-circuit the slow inner byte-sum loop and
    # (b) force the compare to pass (our maindata is byte-exact + gfx unpack is MAME-
    # verified, so the real ROMs WOULD pass; HW keeps the real check). State-faithful:
    # A14 walks to FFF54AF0 and B0 stays clean, matching MAME at FFE0F8A0.
    (0xfff4f450, "3f6d", "0300"),   # byte-sum loop A (planar) DSJS A13,fff4f2b0 -> NOP
    (0xfff4f4f0, "3ccd", "0300"),   # byte-sum loop B (linear) DSJS A13,fff4f4a0 -> NOP
    (0xfff4f550, "ca06", "c006"),   # checksum cmp   JREQ fff4f5c0     -> JR (always "pass")
    # Post-self-test "show the screen" delay: MOVI 600000h,B6; NOP; DSJS B6,self
    # (~30M cyc). Shrink the count to 4 so sim reaches the SP check + main code.
    (0xfff48ea0, "0000", "0004"),   # delay count MOVI 600000h,B6 low word  -> 4
    (0xfff48eb0, "0060", "0000"),   # delay count high word                 -> 0
]
lines = open(src).read().split("\n")
cr = "\r" if (lines and lines[0].endswith("\r")) else ""
for addr, want, new in PATCHES:
    idx = (addr >> 4) - 0x0ffe0000
    cur = lines[idx].strip().lower()
    assert cur == want, f"@0x{addr:08x} (idx 0x{idx:x}) expected {want!r}, found {cur!r}"
    lines[idx] = new + cr
    print(f"patched @0x{addr:08x} (idx 0x{idx:x}): {want} -> {new} (EXGPC B5)")
open(dst, "w", newline="").write("\n".join(lines))
print(f"wrote {dst}")
