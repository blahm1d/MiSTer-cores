#!/usr/bin/env bash
# run_beamerase_base.sh -- DISCRIMINATING probe (uncommitted, 2026-07-30).
# Same production RTL chain as run_beamerase.sh, but with a NON-ZERO display base
# (+base=N -> DPYSTRT = 0xFFFC ^ (N<<4)).  base=0 must reproduce the green gate;
# base=80 is the MEASURED NARC wave-start state (mame-trace/narc_erase_hud.txt).
set -e
export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="${TMPDIR:-/tmp}/narc-beamerase-base.$$"; mkdir -p "$T"; trap 'rm -rf "$T"' EXIT
SRC=(
  "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/zunit/zunit_pkg.sv"
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv"
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
  "$ROOT/rtl/zunit/zunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv"
  "$ROOT/rtl/zunit/zunit_video_top.sv" "$ROOT/sim/ddr3_avalon_model.sv"
  "$ROOT/sim/tb_zunit_beamerase_base.sv"
)
iverilog -g2012 ${IVFLAGS:-} -s tb_zunit_beamerase_base -o "$T/tb.vvp" "${SRC[@]}"
for B in ${BASES:-0 80 40}; do
  echo "== BASE=$B GAMERASE=1 =="
  vvp "$T/tb.vvp" "+gamerase=1" "+base=$B" ${EXTRA:-} | grep -E "^\[beam\]|^\[trc\]|^RESULT" || true
done

# ---------------------------------------------------------------------------
# COVERAGE: restoring the pre-P0040 absolute-anchored window MUST turn this red.
# It reproduces the cabinet mechanism exactly -- erase issued during blanking,
# marching through the HUD rows -- so a silent regression cannot pass here.
# ---------------------------------------------------------------------------
echo "== MUTANT MUT_ERASE_ABS_WINDOW (must FAIL) =="
iverilog -g2012 -DMUT_ERASE_ABS_WINDOW -s tb_zunit_beamerase_base -o "$T/mut.vvp" "${SRC[@]}"
MUT_RC=0
for B in 0 80; do
  if vvp "$T/mut.vvp" "+gamerase=1" "+base=$B" "+isrlat=4000" | grep -q "^RESULT: PASS"; then
    echo "MUTANT-CHECK: BAD -- mutant PASSED at base=$B"; MUT_RC=1
  else
    echo "MUTANT-CHECK: OK -- mutant dies at base=$B"
  fi
done
[ "$MUT_RC" -eq 0 ] || exit 1
