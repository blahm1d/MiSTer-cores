#!/usr/bin/env bash
# Run an integrated testbench (real TMS34010 core + Y-unit wrapper) under Questa.
# The core needs Questa — Icarus can't parse its SV struct-literals. Use this for
# tb_yunit_boot (and later integrated TBs); use run.sh (Icarus) for wrapper units.
#
#   ./run_questa.sh tb_yunit_boot
#
# Finds vlog/vsim via $VLOG/$VSIM or PATH, else common Altera/Intel install dirs.
# Questa FPGA Starter Edition (FSE) is what birdybro develops the core on.
set -e
TB="${1:-tb_yunit_boot}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"

find_bin() {
  local name="$1"; local env="$2"
  # 1) explicit env override wins.
  if [ -n "$env" ] && [ -x "$env" ]; then echo "$env"; return; fi
  # 2) a real questa_fse install — BEFORE PATH, which holds the stale ModelSim ASE 17.
  for d in \
    /c/altera_pro/*/questa_fse/win64 \
    /c/intelFPGA_pro/*/questa_fse/win64 \
    /c/altera/*/questa_fse/win64 \
    /c/intelFPGA/*/questa_fse/win64 ; do
    [ -x "$d/$name.exe" ] && { echo "$d/$name"; return; }
    [ -x "$d/$name" ]     && { echo "$d/$name"; return; }
  done
  # 3) last resort: PATH (but reject modelsim_ase — 17.0 is too old for this core).
  local p; p="$(command -v "$name" 2>/dev/null || true)"
  case "$p" in *modelsim_ase*) p="";; esac
  [ -n "$p" ] && echo "$p"
}
VLIB="$(find_bin vlib "$VLIB")"; VLOG="$(find_bin vlog "$VLOG")"; VSIM="$(find_bin vsim "$VSIM")"
if [ -z "$VLOG" ] || [ -z "$VSIM" ]; then
  echo "ERROR: Questa (vlog/vsim) not found. Install Questa FPGA Starter Edition, or"
  echo "set \$VLOG/\$VSIM/\$VLIB, or add its win64/ dir to PATH. Do NOT use ModelSim ASE 17."
  exit 1
fi
echo "using: $VLOG"

# The environment ships a bogus LM_LICENSE_FILE=C:\nolicense.dat (left over to
# neutralize the license-free ModelSim ASE 17). It breaks Questa FSE licensing —
# drop it here. Questa FSE 25.1std uses SALT licensing (SALT_LICENSE_SERVER); set
# that to your free license from Altera's Self-Service Licensing Center. If vsim
# says "Invalid license environment", the license isn't set up yet.
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

# -svinputport=var: FSE 25.1std won't take the core's typed ANSI ports under
# `default_nettype none` without it (vlog-2892). Needed on 25.1std, harmless else.
# The declaration-before-use strictness of 25.1std (vlog-2730) is handled by the
# P0002 hoist baked into the vendored core (rtl/tms34010/PATCHES.md) — re-apply it
# after a `git -C rtl/tms34010 pull`. Full design compiles clean (0 errors).
VLOG_FLAGS="-sv -quiet -svinputport=var ${EXTRA_VLOG:-}"

cd "$ROOT/sim"
rm -rf work; "$VLIB" work >/dev/null

# Source set: core pkg first, then all core rtl, then the Y-unit wrapper + TB.
SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" "$ROOT/rtl/yunit/yunit_memsys.sv" )
# Phase-6 SDRAM-VRAM modules (only instantiated under +define+USE_SDRAM_VRAM; harmless otherwise)
SRC+=( "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" "$ROOT/sim/sdram_model.sv" )
SRC+=( "$ROOT/sim/$TB.sv" )

echo "compiling ${#SRC[@]} files..."
"$VLOG" $VLOG_FLAGS "${SRC[@]}"
echo "running $TB ..."
"$VSIM" -c -quiet -do "run -all; quit -f" "$TB" > "$ROOT/sim/build/qsim_$TB.log" 2>&1; echo "vsim done -> sim/build/qsim_$TB.log"
