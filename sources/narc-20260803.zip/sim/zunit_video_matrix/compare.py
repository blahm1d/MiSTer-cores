#!/usr/bin/env python
"""Cross-diff the RTL (zunit_video.sv) RGB888 output for one scene against BOTH
the MAME reference PNG (independent oracle) and video_golden.py's render (blind
agreement). Zero tolerance. Exit 0 iff both diffs are pixel-exact.

Usage: compare.py <scene> <rgb.hex>
"""
import sys, os
import numpy as np

VIS_W, VIS_H = 512, 400
HERE = os.path.dirname(os.path.abspath(__file__))
GOLDEN_DIR = os.path.abspath(os.path.join(HERE, "..", "..", "..",
                                          "mame-trace", "video_golden"))
CKPT_DIR = os.path.abspath(os.path.join(HERE, "..", "..", "..",
                                        "mame-trace", "goldens", "scene_checkpoints"))
sys.path.insert(0, GOLDEN_DIR)
import video_golden as vg  # the blind Python oracle


def load_rtl_rgb(path):
    with open(path) as f:
        vals = [int(x, 16) for x in f.read().split()]
    a = np.array(vals, dtype=np.uint32)
    if a.size != VIS_W * VIS_H:
        raise SystemExit(f"RTL output has {a.size} px, expected {VIS_W*VIS_H}")
    rgb = np.empty((a.size, 3), dtype=np.uint8)
    rgb[:, 0] = (a >> 16) & 0xff
    rgb[:, 1] = (a >> 8) & 0xff
    rgb[:, 2] = a & 0xff
    return rgb.reshape(VIS_H, VIS_W, 3)


def main():
    scene, hexpath = sys.argv[1], sys.argv[2]
    got = load_rtl_rgb(hexpath)

    # Oracle 1: MAME reference PNG (independent).
    ref = vg.load_ref_png(os.path.join(CKPT_DIR, f"narc_{scene}_ref.png"))
    d_png = int(np.count_nonzero(np.any(got != ref, axis=-1))) \
        if got.shape == ref.shape else -1

    # Oracle 2: video_golden.py render (blind agreement).
    vram = vg.load_hex_u16(os.path.join(CKPT_DIR, f"narc_{scene}_vram.hex"))
    pram = vg.load_hex_u16(os.path.join(CKPT_DIR, f"narc_{scene}_palette.hex"))
    gold = vg.render_scene(vram, pram)               # (400,512,3)
    d_gold = int(np.count_nonzero(np.any(got != gold, axis=-1)))

    tot = VIS_W * VIS_H
    ok = (d_png == 0) and (d_gold == 0)
    print(f"[{scene:24s}] {'PASS' if ok else 'FAIL'} "
          f"vs_png={d_png}/{tot} vs_golden={d_gold}/{tot}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
