#!/usr/bin/env bash
# zunit_video 8bpp scanline-unpack cross-diff (iverilog) vs MAME ref PNG AND
# video_golden.py, over the 4 scene_checkpoints. Base = 4/4 pixel-exact; the
# donor-6bpp mutant (PEN_MASK=0x0FFF) must break >=1 scene. Quote every path
# (repo tree contains a space).
set -u
export PATH="/c/iverilog/bin:$PATH"
PY="${PYTHON:-python}"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DUT="$ROOT/rtl/zunit/zunit_video.sv"
TB="$HERE/tb_zunit_video.sv"
CKPT="$ROOT/../mame-trace/goldens/scene_checkpoints"

SCENES="high_score_table gameplay_demo_junkyard title_logo title_credits"

cd "$HERE"

build() {   # $1 = extra defines (may be empty), $2 = vvp name
    rm -f "$2"
    iverilog -g2012 $1 -s tb_zunit_video -o "$2" "$PKG" "$DUT" "$TB" 2> iverilog.log
    if [ $? -ne 0 ]; then echo "IVERILOG FAIL"; cat iverilog.log; return 2; fi
    return 0
}

echo "== BASE build (8bpp, PEN_MASK=0x1FFF) =="
build "" build_base.vvp || { echo "RESULT: BUILD FAILED"; exit 1; }

BASE_PASS=0
for S in $SCENES; do
    vvp build_base.vvp \
        +VRAM="$CKPT/narc_${S}_vram.hex" \
        +PAL="$CKPT/narc_${S}_palette.hex" \
        +OUT="rtl_${S}.hex" > "vvp_${S}.log" 2>&1
    "$PY" compare.py "$S" "rtl_${S}.hex"
    [ $? -eq 0 ] && BASE_PASS=$((BASE_PASS+1))
done
echo "BASE: ${BASE_PASS}/4 scenes pixel-exact (vs PNG AND golden)"

echo "== MUTANT build (donor 6bpp, PEN_MASK=0x0FFF) — must kill >=1 scene =="
build "-DMUT_6BPP" build_mut.vvp || { echo "RESULT: MUTANT BUILD FAILED"; exit 1; }
MUT_PASS=0
for S in $SCENES; do
    vvp build_mut.vvp \
        +VRAM="$CKPT/narc_${S}_vram.hex" \
        +PAL="$CKPT/narc_${S}_palette.hex" \
        +OUT="mut_${S}.hex" > "vvpmut_${S}.log" 2>&1
    "$PY" compare.py "$S" "mut_${S}.hex" > /dev/null 2>&1
    [ $? -eq 0 ] && MUT_PASS=$((MUT_PASS+1))
done
MUT_KILLED=$((4-MUT_PASS))
echo "MUTANT MUT-6bpp (mask 0x0FFF): ${MUT_KILLED} scene(s) killed"

if [ "$BASE_PASS" -eq 4 ] && [ "$MUT_KILLED" -ge 1 ]; then
    echo "RESULT: PASS (base 4/4 pixel-exact; 6bpp mutant killed ${MUT_KILLED})"
    exit 0
else
    echo "RESULT: FAIL (base ${BASE_PASS}/4, mutant killed ${MUT_KILLED})"
    exit 1
fi
