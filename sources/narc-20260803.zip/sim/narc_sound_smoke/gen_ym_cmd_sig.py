#!/usr/bin/env python3
# Deterministic segmenter -> per-command filler-stripped YM SIGNATURE.
# Splits narc_attract_sound_stream.txt on L| latch boundaries (see span rule),
# reduces each command span's YM writes to (addr,val) REGISTER PAIRS, strips the
# async YM-timer-ack pair (REG 0x14 / DAT 0x15), and emits the leading SIG_MAX
# command-semantic pairs as the gospel signature for that distinct host command.
#
# SPAN rule: an interrupt-asserting latch (D8==0 NMI or D9==0 IRQ) starts a span
# keyed by cmd; a RESET latch (D10==0) ends the active span; deassert (FFxx)
# latches keep the current span open (the response continues after deassert).
# Boot self-init ("bootinit") = writes before the first assert. FIRST span per
# distinct key is kept. Pairing: REG(a0=0) sets pending addr, next DAT(a0=1)
# completes (addr,val); lone leading DAT (L|-straddle) is skipped. Timer-ack pair
# (0x14,0x15) is a real-time artifact (YM timer async to the 6809) -> stripped.
import sys, hashlib

G       = "D:/deck/fpga/NARC/mame-trace/goldens/narc_attract_sound_stream.txt"
OUT     = sys.argv[1] if len(sys.argv) > 1 else "."
SIG_MAX  = int(sys.argv[2]) if len(sys.argv) > 2 else 32    # signature pairs kept
RAW_CAP  = 60000   # max raw YM writes scanned per span before giving up
IDLE_RUN = 16      # >=IDLE_RUN back-to-back timer-ack pairs after the response
                   # started => the command's response burst is over (master went
                   # idle). Delimits the command RESPONSE from later autonomous
                   # attract activity within the same (long) L| span (e.g. the
                   # bootinit self-init = 3 pairs, then a long idle filler run).

def is_assert(w): return ((w>>8)&1)==0 or ((w>>9)&1)==0
def is_reset(w):  return ((w>>10)&1)==0
def keyname(w):
    cmd=w&0xff
    return (f"nmi_{cmd:02x}" if ((w>>8)&1)==0 else f"irq_{cmd:02x}")

spans={}      # key -> dict(pairs=[], pend=None, raw=0, idle=0, closed=False)
order=[]
def newspan(): return dict(pairs=[], pend=None, raw=0, idle=0, closed=False)
cur="bootinit"; spans[cur]=newspan(); order.append(cur)
seen_assert=False

def feed(span, a0, d):
    if span is None or span["closed"]: return
    if len(span["pairs"])>=SIG_MAX or span["raw"]>=RAW_CAP:
        span["closed"]=True; return
    span["raw"]+=1
    if a0==0:
        span["pend"]=d
    else:
        if span["pend"] is not None:
            addr=span["pend"]; val=d; span["pend"]=None
            if addr==0x14 and val==0x15:            # timer-ack filler
                if span["pairs"]:                   # only after response started
                    span["idle"]+=1
                    if span["idle"]>=IDLE_RUN:
                        span["closed"]=True          # burst over -> stop
            else:
                span["idle"]=0
                span["pairs"].append((addr,val))

with open(G) as fh:
    for line in fh:
        c0=line[0]
        if c0=='Y':
            s=spans.get(cur)
            if s is not None:
                p=line.rstrip("\n").split("|")
                a0=0 if p[6]=="REG" else 1
                d=int(p[7].split("=")[1],16)
                feed(s,a0,d)
        elif c0=='L':
            p=line.rstrip("\n").split("|")
            w=None
            for tok in p:
                if tok.startswith("D="): w=int(tok.split("=")[1],16); break
            if not seen_assert and not is_assert(w):
                cur="bootinit"; continue
            if is_reset(w):
                cur=None
            elif is_assert(w):
                seen_assert=True
                k=keyname(w)
                if k not in spans:
                    spans[k]=newspan(); order.append(k); cur=k
                else:
                    cur=k if len(spans[k]["pairs"])<SIG_MAX else None
            else:
                pass  # deassert: keep current span

manifest=[]
for k in order:
    pairs=spans[k]["pairs"]
    body="\n".join(f"{a:02x} {v:02x}" for a,v in pairs)+("\n" if pairs else "")
    path=f"{OUT}/ymsig_{k}.txt"
    open(path,"w").write(body)
    h=hashlib.sha256(body.encode()).hexdigest()[:16]
    manifest.append((k,len(pairs),h))
    shown=" ".join(f"{a:02x}:{v:02x}" for a,v in pairs[:20])
    print(f"ymsig_{k}.txt  npairs={len(pairs):2d}  sha16={h}  {shown}")
open(f"{OUT}/ymsig_manifest.txt","w").write(
    "".join(f"{k} {n} {h}\n" for k,n,h in manifest))
print("done")
