#!/usr/bin/env bash
# zunit_mem <-> zunit_download SDRAM-base reconciliation gate (iverilog, two-sided).
#   base    : frozen rtl/zunit/zunit_mem.sv (SDRAM_ROMB=SDRAM_GFX_BYTES,
#             EXT_PROG_WORDS=SDRAM_PROG_WORDS) -> RESULT: PASS
#   mutant  : constants reverted to the donor (GFX_PIXELS / ROM_WORDS) -> the
#             base-match AND the 0x40000-word range checks must DIE (coverage:
#             the gate fails iff the change is reverted).
# Built with +define+USE_EXT_ROM so zunit_mem's external R_ROM fetch path is live.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
DIR="$ROOT/sim/zunit_rom_base"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
MEM="$ROOT/rtl/zunit/zunit_mem.sv"
DL="$ROOT/rtl/zunit/zunit_download.sv"
TB="$DIR/tb_zunit_rom_base.sv"
BUILD="$DIR/build"
mkdir -p "$BUILD"
MUT="$BUILD/zunit_mem_donormut.sv"

python - "$MEM" "$MUT" <<'PY'
import sys
src, out = sys.argv[1], sys.argv[2]
txt = open(src, encoding="utf-8").read()
a = "= 24'(SDRAM_GFX_BYTES);"
b = "= 28'(SDRAM_PROG_WORDS);"
assert txt.count(a) == 1, f"SDRAM_ROMB anchor count {txt.count(a)}"
assert txt.count(b) == 1, f"EXT_PROG_WORDS anchor count {txt.count(b)}"
txt = txt.replace(a, "= 24'(GFX_PIXELS);       // MUTANT: donor drift")
txt = txt.replace(b, "= 28'(ROM_WORDS);        // MUTANT: donor drift")
open(out, "w", encoding="utf-8").write(txt)
print("mutant generated")
PY

build_run () {  # $1=label $2=memfile
  local out="$BUILD/tb_$1.vvp"
  echo "=== $1 ==="
  # PERF_NO_STREAMBUF: demand-fetch only (no background prefetch polluting gfx_rd);
  # the ext_base decode + program-range check under test are identical either way.
  iverilog -g2012 -D USE_EXT_ROM -D PERF_NO_STREAMBUF -s tb_zunit_rom_base -o "$out" "$PKG" "$2" "$DL" "$TB"
  ( cd "$DIR" && vvp "$out" )
}

BASE_LOG="$(build_run base   "$MEM")"; echo "$BASE_LOG"
MUT_LOG="$(build_run  mutant "$MUT")"; echo "$MUT_LOG"

echo
echo "================= ACCEPTANCE ================="
fail=0
if echo "$BASE_LOG" | grep -q "RESULT: PASS"; then echo "base   : PASS"; else echo "base   : FAIL"; fail=1; fi
if echo "$MUT_LOG"  | grep -q "RESULT: FAIL"; then echo "mutant : KILLED (donor drift dies)"; else echo "mutant : NOT KILLED"; fail=1; fi
if [ "$fail" -eq 0 ]; then echo "ACCEPTANCE: PASS"; else echo "ACCEPTANCE: FAIL"; exit 1; fi
