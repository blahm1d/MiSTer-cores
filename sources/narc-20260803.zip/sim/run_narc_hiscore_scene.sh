#!/usr/bin/env bash
# Complete MAME-captured frame-1214 NARC high-score scene gate.
set -eu
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY="${PYTHON:-python}"
T="$(mktemp -d "${TMPDIR:-/tmp}/narc_hiscore_scene.XXXXXX")"
trap 'rm -rf "$T"' EXIT

"$PY" "$ROOT/sim/prep_narc_hiscore_gfx.py"
"$PY" "$ROOT/sim/prep_narc_hiscore_scene.py"

SRC=("$ROOT/rtl/zunit/zunit_pkg.sv" \
  "$ROOT/rtl/zunit/zunit_dma.sv" \
  "$ROOT/rtl/zunit/narc_fb_beat_fifo.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/sdram/sdram_stock_shipped.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_narc_hiscore_pipeline.sv")

echo "== Compact-journal CPU/scan/write-combine coherency =="
iverilog -g2012 -s tb_vram_ddr_fbcombine \
  -Ptb_vram_ddr_fbcombine.DSB=1 \
  -Ptb_vram_ddr_fbcombine.DWF=1 \
  -Ptb_vram_ddr_fbcombine.DBF=1 \
  -o "$T/fbcombine.vvp" \
  "$ROOT/rtl/zunit/narc_fb_beat_fifo.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" \
  "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/sim/ddr3_avalon_model.sv" \
  "$ROOT/sim/tb_vram_ddr_fbcombine.sv"
FBC="$(cd "$ROOT" && vvp "$T/fbcombine.vvp")"
printf '%s\n' "$FBC" | grep -E \
  "compact beat-journal|A-beat-cache|B-cache|done-tail|^RESULT"
printf '%s\n' "$FBC" | grep -Fq \
  "RESULT: PASS -- fb write-combine: content + cost + coherency + redraw-fits-in-frame."

compile_scene() {
  local beat="$1"
  local out="$2"
  iverilog -g2012 -DUSE_DDR3_VRAM -s tb_narc_hiscore_pipeline \
    -Ptb_narc_hiscore_pipeline.FULL_SCENE=1 \
    -Ptb_narc_hiscore_pipeline.BEAT_FIFO="$beat" \
    -Ptb_narc_hiscore_pipeline.BEAT_FIFO_DEPTH=16384 \
    -Ptb_narc_hiscore_pipeline.DDR_CMD_BUSY=24 \
    -o "$out" "${SRC[@]}"
}

echo "== Candidate: compact 16K beat journal, conservative busy=24 =="
compile_scene 1 "$T/candidate.vvp"
CAND="$(cd "$ROOT" && vvp "$T/candidate.vvp")"
printf '%s\n' "$CAND" | grep -E \
  "NARC-HISCORE-SCENE|NARC-HISCORE-FBQ|NARC-HISCORE-BEATQ|NARC-SCENE-BUDGET|^FAIL|^RESULT"
printf '%s\n' "$CAND" | grep -Fq \
  "RESULT: SCENE-BUDGET PASS -- all 240 captured high-score-table blits meet MAME pace and retire byte-exact."
printf '%s\n' "$CAND" | grep -Eq \
  "^NARC-HISCORE-BEATQ max=[0-9]+/16384 headroom=[1-9][0-9]*$"
if printf '%s\n' "$CAND" | grep -Eq "^FAIL"; then
  echo "GATE ERROR: candidate emitted a failure." >&2
  exit 1
fi

echo "== Killing mutation: exact v7x path without compact journal =="
compile_scene 0 "$T/mutation.vvp"
MUT="$(cd "$ROOT" && vvp "$T/mutation.vvp")"
printf '%s\n' "$MUT" | grep -E \
  "NARC-HISCORE-SCENE|NARC-HISCORE-FBQ|NARC-SCENE-BUDGET SUMMARY|^RESULT"
printf '%s\n' "$MUT" | grep -Fq "RESULT: SCENE-BUDGET FAIL"
printf '%s\n' "$MUT" | grep -Eq \
  "^NARC-SCENE-BUDGET SUMMARY over=[1-9][0-9]*/240"

echo "RESULT: PASS -- candidate clears the complete scene; exact v7x mutation fails."
