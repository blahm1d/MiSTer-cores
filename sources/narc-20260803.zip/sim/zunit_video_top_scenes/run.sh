#!/usr/bin/env bash
# zunit_video_top_scenes — acceptance for rtl/zunit/zunit_video_top.sv.
#
# Runs the net-new 8bpp scanout READ lane end-to-end with the raster LIVE:
#   raster/timing gen (674x433 raw, 512x400 visible, 16 MHz dot) -> VRAM
#   addr gen ((DISP_ROW0+row)<<9|col) -> yunit_scanline double-buffered
#   line-fetch over an sdram_model scan_* responder (backed by one green scene
#   checkpoint) -> FROZEN zunit_video back-end -> RGB888. CPU palette writes go
#   through the top's pal_we. The active-region RGB is captured on the top's
#   video bus (de + vid_*) and diffed BIT-EXACT vs the MAME ref PNG (compare.py,
#   reused from ../zunit_video_scenes). Zero tolerance.
#
# Gate-exercises-the-change: the MUT_6BPP mutant (donor 6bpp pen mask 0x0FFF)
# MUST FAIL the scene compare.  zunit_video is NEVER modified (verification only).
set -u
export PATH="/c/iverilog/bin:$PATH"
PY="${PYTHON:-python}"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
SCAN="$ROOT/rtl/yunit/yunit_scanline.sv"
VID="$ROOT/rtl/zunit/zunit_video.sv"
TOP="$ROOT/rtl/zunit/zunit_video_top.sv"
SDRAM="$ROOT/sim/sdram_model.sv"
TB="$HERE/tb_zunit_video_top.sv"
CKPT="$ROOT/../mame-trace/goldens/scene_checkpoints"
CMP="$ROOT/sim/zunit_video_scenes/compare.py"

# Default scene MUST exercise pen bit 12 or the 6bpp mutant is invisible
# (coverage trap, CLAUDE.md §5): title_logo/title_credits set bit 12 on 30k+ px;
# high_score_table/gameplay_demo_junkyard do NOT (0 px) -> cannot kill the mutant.
SCENE="${SCENE:-title_logo}"

cd "$HERE"

build() {   # $1 = extra defines (may be empty), $2 = vvp name
  rm -f "$2"
  iverilog -g2012 $1 -s tb_zunit_video_top -o "$2" \
    "$PKG" "$SCAN" "$VID" "$TOP" "$SDRAM" "$TB" 2> iverilog.log
  if [ $? -ne 0 ]; then echo "IVERILOG FAIL"; cat iverilog.log; return 2; fi
  return 0
}

echo "== BASE build (8bpp, PEN_MASK=0x1FFF) =="
build "" build_base.vvp || { echo "RESULT: BUILD FAILED"; exit 1; }

echo "== BASE render (scene=$SCENE) + bit-exact diff vs MAME ref PNG (512x400) =="
vvp build_base.vvp \
  +VRAM="$CKPT/narc_${SCENE}_vram.hex" \
  +PAL="$CKPT/narc_${SCENE}_palette.hex" \
  +OUT="rtl_${SCENE}.hex" > "vvp_${SCENE}.log" 2>&1
tail -1 "vvp_${SCENE}.log"
"$PY" "$CMP" "$SCENE" "rtl_${SCENE}.hex"
BASE_OK=$?

echo "== MUTANT MUT_6BPP (donor 6bpp mask 0x0FFF) — MUST FAIL =="
build "-DMUT_6BPP" build_m6bpp.vvp || { echo "RESULT: MUTANT BUILD FAILED"; exit 1; }
vvp build_m6bpp.vvp \
  +VRAM="$CKPT/narc_${SCENE}_vram.hex" \
  +PAL="$CKPT/narc_${SCENE}_palette.hex" \
  +OUT="m6bpp_${SCENE}.hex" > "vvp_m6bpp_${SCENE}.log" 2>&1
"$PY" "$CMP" "$SCENE" "m6bpp_${SCENE}.hex"
MUT_OK=$?   # 0 = mutant matched (BAD); nonzero = mutant killed (GOOD)

# ---------------------------------------------------------------------------
# P0031 (SPEC section 28.1): DPYSTRT-tracking scanout base.
# Scene golden: halt-coherent coined-intro capture displayed from VRAM row 80
# (DPYSTRT=FAFC), goldens/dpystrt_row80/ (provenance in its README).
# ---------------------------------------------------------------------------
R80="$ROOT/../mame-trace/goldens/dpystrt_row80"
R80V="$R80/narc_gameplay_row80_vram.hex"
R80P="$R80/narc_gameplay_row80_palette.hex"
R80REF="$R80/narc_gameplay_row80_ref.png"

echo "== P0031 row-80 scene (DPYSTRT=FAFC) — bit-exact vs MAME snapshot =="
vvp build_base.vvp +VRAM="$R80V" +PAL="$R80P" +DPYSTRT=FAFC \
  +OUT="rtl_row80.hex" > vvp_row80.log 2>&1
tail -1 vvp_row80.log
"$PY" "$CMP" "gameplay_row80" "rtl_row80.hex" "$R80REF"
R80_OK=$?

echo "== P0031 fixed-base mutation (DPYSTRT=FFFC on the row-80 scene = the"
echo "   rejected v8a behavior) — MUST FAIL =="
vvp build_base.vvp +VRAM="$R80V" +PAL="$R80P" +DPYSTRT=FFFC \
  +OUT="m_fixed_row80.hex" > vvp_m_fixed_row80.log 2>&1
"$PY" "$CMP" "gameplay_row80" "m_fixed_row80.hex" "$R80REF"
MFIX_OK=$?   # nonzero = killed (GOOD)

echo "== P0031 tearing gate: mid-frame DPYSTRT flip, frame-latched base must"
echo "   hold the captured frame bit-exact =="
vvp build_base.vvp +VRAM="$R80V" +PAL="$R80P" +DPYSTRT=FAFC +DPYSTRT_MID=FFFC \
  +OUT="rtl_row80_mid.hex" > vvp_row80_mid.log 2>&1
"$PY" "$CMP" "gameplay_row80" "rtl_row80_mid.hex" "$R80REF"
TEAR_OK=$?

echo "== P0031 MUTANT MUT_UNLATCHED (combinational base) — tearing MUST FAIL =="
build "-DMUT_UNLATCHED" build_munlat.vvp || { echo "RESULT: MUTANT BUILD FAILED"; exit 1; }
vvp build_munlat.vvp +VRAM="$R80V" +PAL="$R80P" +DPYSTRT=FAFC +DPYSTRT_MID=FFFC \
  +OUT="m_unlat_row80.hex" > vvp_m_unlat_row80.log 2>&1
"$PY" "$CMP" "gameplay_row80" "m_unlat_row80.hex" "$R80REF"
MUNLAT_OK=$?   # nonzero = killed (GOOD)

echo "----------------------------------------------------------------------"
if [ "$BASE_OK" -eq 0 ] && [ "$MUT_OK" -ne 0 ] && \
   [ "$R80_OK" -eq 0 ] && [ "$MFIX_OK" -ne 0 ] && \
   [ "$TEAR_OK" -eq 0 ] && [ "$MUNLAT_OK" -ne 0 ]; then
  echo "RESULT: PASS (scene + row-80 bit-exact; MUT_6BPP, fixed-base and"
  echo "         MUT_UNLATCHED mutations all killed; latch holds mid-frame flip)"
  exit 0
else
  echo "RESULT: FAIL (base_ok=$BASE_OK mut6bpp_killed=$([ $MUT_OK -ne 0 ] && echo yes || echo no)" \
       "row80_ok=$R80_OK fixed_killed=$([ $MFIX_OK -ne 0 ] && echo yes || echo no)" \
       "tear_ok=$TEAR_OK unlat_killed=$([ $MUNLAT_OK -ne 0 ] && echo yes || echo no))"
  exit 1
fi
