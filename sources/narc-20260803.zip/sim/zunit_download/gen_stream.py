#!/usr/bin/env python3
# gen_stream.py — build the FAITHFUL hps_io download byte stream that the MiSTer
# `mra` tool would emit for "Narc (rev 7.00).mra", and write it as raw bytes for
# the iverilog TB to replay through zunit_download.
#
# This is the DEMUX INPUT. It is produced by interpreting the .mra XML exactly as
# validate_narc_mra.py's (B) path does (<part name>, <part repeat>,
# <interleave output=16>). It is INDEPENDENT of the RTL and of the output oracle
# (cross_check.py rebuilds the expected SDRAM image from the zip via init_gfxrom).
import os, sys, zipfile, xml.etree.ElementTree as ET

REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ZIP  = "D:/deck/fpga/NARC/roms/narc.zip"
MRA  = os.path.join(REPO, "releases", "Narc (rev 7.00).mra")
OUT  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stream.bin")

def build_stream(z):
    root = ET.parse(MRA).getroot()
    rom = root.find("rom")
    out = bytearray()
    def emit_part(p):
        name = p.get("name"); rep = p.get("repeat")
        if name is not None:
            return z.read(name)
        txt = (p.text or "").strip().replace(" ", "")
        byte = bytes([int(txt or "00", 16)])
        n = int(rep, 0) if rep else 1
        return byte * n
    for el in rom:
        if el.tag == "part":
            out += emit_part(el)
        elif el.tag == "interleave":
            assert el.get("output") == "16"
            parts = [emit_part(p) for p in el.findall("part")]
            assert len(parts) == 2 and len(parts[0]) == len(parts[1])
            inter = bytearray(len(parts[0]) * 2)
            inter[0::2] = parts[0]      # even byte = low ROM
            inter[1::2] = parts[1]      # odd  byte = high ROM
            out += inter
    return bytes(out)

def main():
    z = zipfile.ZipFile(ZIP)
    s = build_stream(z)
    with open(OUT, "wb") as f:
        f.write(s)
    # sanity: region boundaries per MRA header
    assert len(s) == 0x9A0500, "stream len 0x%X != 0x9A0500" % len(s)
    print("stream.bin: 0x%X bytes (%d)" % (len(s), len(s)))
    print("  PROGRAM   [0x000000,0x080000)")
    print("  GFX       [0x080000,0x880000)")
    print("  SOUND/PLA [0x880000,0x9A0500)")

if __name__ == "__main__":
    main()
