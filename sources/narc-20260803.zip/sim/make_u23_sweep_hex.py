#!/usr/bin/env python3
# make_u23_sweep_hex.py — $readmemh image of the real {u41,u23} program-ROM
# pair (128K words) for tb_zunit_rom_chksum_audit.sv, word i = u41[i] | u23[i]<<8.
import zipfile, os

ZIP = "D:/deck/fpga/NARC/roms/narc.zip"
OUT = "sim/build/u23_sweep.hex"

def main():
    z = zipfile.ZipFile(ZIP)
    u41 = z.read("rev7_narc_game_rom_u41.u41")
    u23 = z.read("rev7_narc_game_rom_u23.u23")
    assert len(u41) == 0x20000 and len(u23) == 0x20000
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        for i in range(0x20000):
            f.write("%04x\n" % (u41[i] | (u23[i] << 8)))
    print("wrote", OUT, "0x20000 words")

if __name__ == "__main__":
    main()
