#!/usr/bin/env bash
# run_io_subword_field_gate.sh -- SHARED-P0038: I/O register writes/reads must
# honour TMS34010 BIT-FIELD semantics (offset from addr[3:0], width from ST.FS).
#
# The TB is IMPORTED VERBATIM from wolf-crt/sim/tb_tms_io_subword_field.sv --
# written BLIND to this decoder from the 1988 User's Guide §6 field semantics,
# which is the independent-transcription property the doctrine asks for. Only
# the port binding may be adapted; every case and expected value is byte-for-byte
# the wolf-crt original.
#
# Runs BOTH arms in ONE invocation so a green can never inherit a kill from an
# earlier run (the standard agreed across the Wolf/Y/T/Z sessions).
set -e
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
SRC=("$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" \
     "$ROOT/rtl/tms34010/rtl/io/tms34010_io_regs.sv" \
     "$ROOT/rtl/tms34010/rtl/video/tms34010_video.sv" \
     "$ROOT/sim/tb_tms_io_subword_field.sv")

echo "== field semantics: production must PASS =="
iverilog -g2012 -s tb_tms_io_subword_field -o "$T/p.vvp" "${SRC[@]}"
OUT="$(vvp "$T/p.vvp")"
printf '%s\n' "$OUT"
printf '%s\n' "$OUT" | grep -Fq "RESULT PASS"

echo
echo "== self-test of the INCONCLUSIVE arm (+SELFTEST_X): must NOT read as PASS =="
STOUT="$(vvp "$T/p.vvp" +SELFTEST_X)"
printf '%s\n' "$STOUT" | grep -iE "RESULT"
printf '%s\n' "$STOUT" | grep -Fq "RESULT INCONCLUSIVE"

echo
echo "== MUTATION (-DMUT_IO_NO_FIELD): the pre-P0038 unmasked store MUST fail =="
iverilog -g2012 -DMUT_IO_NO_FIELD -s tb_tms_io_subword_field -o "$T/m.vvp" "${SRC[@]}"
MOUT="$(vvp "$T/m.vvp")"
printf '%s\n' "$MOUT"
printf '%s\n' "$MOUT" | grep -Fq "RESULT FAIL"
# require the load-bearing kills BY NAME, not just "some failure". The first is
# the T-unit NBA Jam / Jam TE signature: got 0001 want 0400.
printf '%s\n' "$MOUT" | grep -Fq "FAIL 1 one-bit SET of DIE: got 0001 want 0400"
printf '%s\n' "$MOUT" | grep -Fq "FAIL 2 one-bit CLEAR leaves others"
printf '%s\n' "$MOUT" | grep -Fq "FAIL 4 one-bit READ of DIE"

echo
echo "RESULT: PASS -- SHARED-P0038 field semantics proven (production green, mutant killed, same run)."
