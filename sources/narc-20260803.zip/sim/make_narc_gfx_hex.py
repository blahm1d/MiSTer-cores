#!/usr/bin/env python3
# make_narc_gfx_hex.py — build the NARC (Z-unit) UNPACKED 8bpp gfx-ROM image for
# the boot-smoke sim's DMA source responder (sim/tb_narc_boot.sv).
#
# GEOMETRY (cited): MAME midyunit.cpp:1473-1539 ROM_REGION(0x800000,"gfx") is
# loaded as four 0xF0000-populated quadrants of 15x64KB byte ROMs:
#     quadrant 0  0x000000: rev2_narc_image_rom_u94 .. u80
#     quadrant 1  0x200000: rev2_narc_image_rom_u76 .. u62
#     quadrant 2  0x400000: rev2_narc_image_rom_u58 .. u44
#     quadrant 3  0x600000: rev2_narc_image_rom_u40 .. u26
# init_gfxrom(8) (midyunit_m.cpp:284-292): chunk = region.bytes()/4 = 0x200000;
# the unpacked pixel array is a 4-way byte interleave of the four quadrants:
#     m_gfx_rom[p] = base[(p & 3) * chunk + (p >> 2)]
# For 8bpp each unpacked byte IS the pixel (no plane-packing). Only pixels with
# (p>>2) < 0xF0000, i.e. p < 0x3C0000, carry ROM data; above that MAME reads the
# 0-filled region tail (so the boot responder returns 0 there).
#
# Output: sim/build/narc_gfx.hex, one hex pixel byte per line, indexed by the
# zunit_dma src_addr (byte/pixel offset into the flat gfx window @0x02000000).
#
# Usage:  python3 sim/make_narc_gfx_hex.py    (run from repo root)
import zipfile, os, sys

ZIP = "D:/deck/fpga/NARC/roms/narc.zip"
OUT = "sim/build"
OUT_HEX = os.path.join(OUT, "narc_gfx.hex")

REGION = 0x800000
CHUNK  = REGION // 4              # 0x200000
NPIX   = 0xF0000 * 4             # 0x3C0000 populated unpacked pixels (15*64KB*4)
QUAD_TOP = [94, 76, 58, 40]      # top chip # of each descending 15-chip quadrant


def main():
    z = zipfile.ZipFile(ZIP)
    names = set(z.namelist())
    region = bytearray(REGION)   # 0x00 default fill (matches ROM_REGION)
    for qi, top in enumerate(QUAD_TOP):
        qbase = qi * CHUNK
        for k in range(15):
            chip = top - k
            name = "rev2_narc_image_rom_u%d.u%d" % (chip, chip)
            if name not in names:
                sys.exit("FATAL: %s not in %s" % (name, ZIP))
            d = z.read(name)
            if len(d) != 0x10000:
                sys.exit("FATAL: %s expected 64KB, got %d" % (name, len(d)))
            off = qbase + k * 0x10000
            region[off:off + 0x10000] = d

    out = bytearray(NPIX)
    for p in range(NPIX):
        out[p] = region[(p & 3) * CHUNK + (p >> 2)]

    os.makedirs(OUT, exist_ok=True)
    with open(OUT_HEX, "w", newline="\n") as f:
        f.write("\n".join("%02x" % b for b in out))
        f.write("\n")

    # non-zero sanity: real art must be present (not an all-zero image).
    nz = sum(1 for b in out if b)
    print("%s: %d unpacked pixels (0x%X), %d non-zero" % (OUT_HEX, NPIX, NPIX, nz))
    if nz == 0:
        sys.exit("FATAL: unpacked gfx is all-zero (interleave/load wrong)")


if __name__ == "__main__":
    main()
