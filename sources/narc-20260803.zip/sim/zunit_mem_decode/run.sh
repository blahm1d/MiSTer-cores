#!/usr/bin/env bash
# zunit_mem decode-delta unit gate (iverilog). Builds/runs three variants:
#   base        : frozen rtl/zunit/zunit_mem.sv          -> RESULT: PASS
#   cmos-mutant : cmos_page forced 0 (ignore D6-7)       -> kills cmos_p*_readback
#   dma-mutant  : DMA decode requires bit19==0           -> kills dma_mirror_*
# The frozen zunit_mem is NEVER modified; mutants are throwaway copies in build/.
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
export PATH="/c/iverilog/bin:$PATH"
DIR="$ROOT/sim/zunit_mem_decode"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
MEM="$ROOT/rtl/zunit/zunit_mem.sv"
TB="$DIR/tb_zunit_mem_decode.sv"
BUILD="$DIR/build"
mkdir -p "$BUILD"

CMOS_MUT="$BUILD/zunit_mem_cmosmut.sv"
DMA_MUT="$BUILD/zunit_mem_dmamut.sv"

# --- generate mutants via python (exact single-site replace, count asserted so a
#     mis-applied mutation can never masquerade as a passing base) ---------------
python - "$MEM" "$CMOS_MUT" "$DMA_MUT" <<'PY'
import sys
src, cmos_out, dma_out = sys.argv[1], sys.argv[2], sys.argv[3]
txt = open(src, encoding="utf-8").read()

a, b = "cmos_page <= wd_q[7:6];", "cmos_page <= 2'd0;  // MUTANT: ignore D6-7"
assert txt.count(a) == 1, f"cmos anchor count {txt.count(a)}"
open(cmos_out, "w", encoding="utf-8").write(txt.replace(a, b))

c, dd = "region = R_DMA;", "region = a_q[19] ? R_NONE : R_DMA;  // MUTANT: require bit19==0"
assert txt.count(c) == 1, f"dma anchor count {txt.count(c)}"
open(dma_out, "w", encoding="utf-8").write(txt.replace(c, dd))
print("mutants generated")
PY

build_run () {  # $1=label  $2=memfile
  local out="$BUILD/tb_$1.vvp"
  echo "=== $1 ==="
  iverilog -g2012 -s tb_zunit_mem_decode -o "$out" "$PKG" "$2" "$TB"
  ( cd "$DIR" && vvp "$out" )
}

BASE_LOG="$(build_run base       "$MEM")";      echo "$BASE_LOG"
CMOS_LOG="$(build_run cmos-mutant "$CMOS_MUT")"; echo "$CMOS_LOG"
DMA_LOG="$(build_run  dma-mutant  "$DMA_MUT")";  echo "$DMA_LOG"

echo
echo "================= ACCEPTANCE ================="
fail=0
# base: all cases pass
if echo "$BASE_LOG" | grep -q "RESULT: PASS"; then echo "base            : PASS (all cases)"; else echo "base            : FAIL"; fail=1; fi
# cmos mutant: the multi-page independence case must die
if echo "$CMOS_LOG" | grep -q "FAIL: cmos_p0_readback"; then echo "cmos-mutant     : KILLED (cmos_p0_readback died)"; else echo "cmos-mutant     : NOT KILLED"; fail=1; fi
# dma mutant: the 0x01A80000 route case must die (base 0x01A00000 case stays green)
if echo "$DMA_LOG" | grep -q "FAIL: dma_mirror_0x01A80000" && echo "$DMA_LOG" | grep -q "ok:   dma_base_0x01A00000"; then
  echo "dma-mutant      : KILLED (dma_mirror_0x01A80000 died, base stayed green)"; else echo "dma-mutant      : NOT KILLED"; fail=1; fi

if [ "$fail" -eq 0 ]; then echo "ACCEPTANCE: PASS"; else echo "ACCEPTANCE: FAIL"; exit 1; fi
