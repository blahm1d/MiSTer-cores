#!/usr/bin/env bash
# zunit_dma real-blit byte-exact gate: drive the RTL with MAME 0.280's real
# attract blits (mame-trace/goldens/narc_blit_capture.txt) and byte-diff the RTL
# POST frame-buffer window against MAME's captured POST window, NO tolerance.
#   ./run.sh
# Base build must be N/N byte-exact (N == the golden replay's blit count, 45).
# Gate-exercises-the-change: reverting zunit_dma.sv's clip clamp (flip-branch
# width clamp, dma_w:510-511) via the harness-generated clamp-revert probe makes
# >=1 real blit's POST window diff.  The frozen zunit_dma.sv is NEVER modified.
# Keep every path quoted (repo tree contains a space).
set -u
export PATH="/c/iverilog/bin:$PATH"
PY="${PYTHON:-python}"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DUT="$ROOT/rtl/zunit/zunit_dma.sv"
TB="$HERE/tb_zunit_dma_realblit.sv"

cd "$HERE"

echo "== prep (regs/gfx/meta from captured real blits) =="
"$PY" prep.py || { echo "PREP FAIL"; exit 1; }

build_run() {   # $1 = DUT source, $2 = extra defines (may be empty)
  local dutsrc="$1" defs="$2"
  rm -f build.vvp dut.txt
  iverilog -g2012 $defs -I "$HERE" -s tb_zunit_dma_realblit \
      -o build.vvp "$PKG" "$dutsrc" "$TB" 2> iverilog.log
  if [ $? -ne 0 ]; then echo "IVERILOG FAIL"; cat iverilog.log; return 2; fi
  vvp build.vvp > vvp.log 2>&1
  "$PY" compare.py
  return $?
}

echo "== BASE (frozen zunit_dma.sv; expect 45/45 byte-exact) =="
build_run "$DUT" ""
BASE=$?
if [ $BASE -ne 0 ]; then echo "RESULT: BASE FAILED"; exit 1; fi

# ---- gate-exercises-the-change: two independent probes ---------------------
# (1) POST-WINDOW BYTE-DIFF IS LIVE: the built-in MUT_CMD_DECODE mis-decodes
#     draw mode 0x02 as write-all.  The real set is dense in mode-2 blits, so
#     this produces pure in-rect POST-window byte mismatches (no span guard) --
#     proving the byte-diff itself discriminates.
echo "== PROBE A: MUT_CMD_DECODE (pure POST-window byte-diff must FAIL) =="
build_run "$DUT" "-DMUT_CMD_DECODE"
PA=$?
if   [ $PA -eq 0 ]; then echo "  A SURVIVED <-- BAD (POST byte-diff not live)"; exit 1
elif [ $PA -eq 2 ]; then echo "  A COMPILE-ERROR <-- BAD"; exit 1
else echo "  A DIED (POST-window byte-diff is discriminating)"; fi

# (2) CLIP CLAMP IS EXERCISED: the real attract set never issues ypos<0 /
#     non-flip xpos<0 / flip xpos>=512, so MUT_SRC_ADVANCE and the non-flip
#     left clamp MUT_CLIP are UNREACHABLE here (they are killed two-sidedly by
#     the 320-case matrix instead).  The clip clamp the real set DOES exercise
#     is the flip-branch width clamp `if (xpos-width<0) width=xpos;`
#     (dma_w:510-511; clipped blits n=22/23/24/31/32/33/37/38/39).  Reverting it
#     over-draws past MAME's captured source span, tripping replay_diff's own
#     out-of-span HARD-FAIL contract.  Revert exactly that line into a throwaway
#     copy (frozen source untouched) and require the gate to FAIL.
echo "== PROBE B: revert flip-branch clip clamp (dma_w:510-511) =="
PROBE="$HERE/.zunit_dma_clipprobe.sv"
sed 's/if ((xpos_f - width_f) < 0) width_f = xpos_f;.*$/\/\/ CLIP-CLAMP REVERTED (probe)/' \
    "$DUT" > "$PROBE"
if cmp -s "$PROBE" "$DUT"; then
  echo "  B: sed did not alter the clamp line <-- BAD (line drift?)"; rm -f "$PROBE"; exit 1
fi
build_run "$PROBE" ""
PB=$?
rm -f "$PROBE"
if   [ $PB -eq 0 ]; then echo "  B SURVIVED <-- BAD (clip clamp not exercised)"; exit 1
elif [ $PB -eq 2 ]; then echo "  B COMPILE-ERROR <-- BAD"; exit 1
else echo "  B DIED (>=1 real blit over-draws MAME's span -- clip clamp exercised)"; fi

# rebuild BASE artifacts so the working tree reflects the passing gate.
build_run "$DUT" "" >/dev/null

echo "== SUMMARY =="
echo "RESULT: PASS  (45/45 byte-exact vs MAME real blits; clip-clamp + POST-diff probes died)"
exit 0
