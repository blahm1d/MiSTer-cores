#!/usr/bin/env python3
# Convert the sound-board sim capture (build/snd_samples.csv: ym_l,ym_r,speech,
# pia_dac per line @50kHz) into WAVs: full mix + per-channel stems.
import sys, wave, struct
d = sys.argv[1] if len(sys.argv) > 1 else "sim/build"
FS = 50000
src = sys.argv[2] if len(sys.argv) > 2 else "snd_samples.csv"
def num(x):
    try: return int(x)
    except ValueError: return 0     # 'x'/'X' (undriven, e.g. CVSD before first clock) -> silence
rows = []
for line in open(f"{d}/{src}"):
    p = line.strip().split(",")
    if len(p) == 4:
        rows.append(tuple(num(x) for x in p))
print(f"{len(rows)} samples = {len(rows)/FS:.2f}s")
def clamp(v): return max(-32768, min(32767, int(v)))
def write_wav(name, samples):
    w = wave.open(f"{d}/{name}", "w")
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(FS)
    w.writeframes(b"".join(struct.pack("<h", clamp(s)) for s in samples))
    w.close()
    peak = max((abs(s) for s in samples), default=0)
    print(f"  {name}: peak {peak}")
ym    = [(r[0] + r[1]) / 2 for r in rows]
sp    = [r[2] for r in rows]
dac   = [r[3] * 200 for r in rows]           # 8-bit DAC scaled to ~16-bit range
mix   = [ym[i] * 0.6 + sp[i] * 0.4 + dac[i] * 0.5 for i in range(len(rows))]
write_wav("snd_mix.wav", mix)
write_wav("snd_ym2151.wav", ym)
write_wav("snd_speech.wav", sp)
write_wav("snd_dac.wav", dac)
