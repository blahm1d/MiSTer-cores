#!/usr/bin/env bash
# run_narc_snd_realchain.sh — coverage gap #1 (2026-07-30 sound audit): the REAL
# sound landing->readback chain no other sim exercises. Base must PASS; all four
# mutants must die with a bounded "RESULT: FAIL" (never a hang). Offline
# iverilog only (no Quartus, no Questa).
#
#   IOL landing (zunit_download be pattern) -> yunit_sdram_arb -> yunit_sdram_adapter
#     -> sdram_stock_shipped -> sdram_chip pins -> zunit_snd_rom -> dual mc6809is,
#   across a >=200k-clk held rst_sys (P0022 axis) + CGFX/page-burst contention.
set -euo pipefail
export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="${TMPDIR:-/tmp}"
PY="${PYTHON:-python}"

# real narc.zip-derived hex assets (same generator the proven sound-boot gate uses)
if [[ ! -f "$ROOT/sim/narc_sound_smoke/build/narc_snd_u5.hex" || \
      ! -f "$ROOT/sim/narc_sound_smoke/build/narc_snd_u38.hex" ]]; then
  "$PY" "$ROOT/sim/narc_sound_smoke/make_hex.py"
fi

JT51=()
while IFS= read -r f; do JT51+=("$f"); done \
  < <(find "$ROOT/rtl/sound/jt51/hdl" -maxdepth 1 -name '*.v' | sort)

SRC=(
  "$ROOT/rtl/zunit/zunit_pkg.sv"
  "$ROOT/rtl/sound/narc_sound_pkg.sv"
  "${JT51[@]}"
  "$ROOT/rtl/sound/williams_cvsd/mc6809is.v"
  "$ROOT/rtl/sound/sim/hc55564_stub.v"
  "$ROOT/rtl/sound/narc_sound_bank.sv"
  "$ROOT/rtl/sound/narc_sound_latch.sv"
  "$ROOT/rtl/sound/narc_6809_clock_en.sv"
  "$ROOT/rtl/sound/narc_ym_clock_en.sv"
  "$ROOT/rtl/sound/narc_sound_board.sv"
  "$ROOT/rtl/zunit/zunit_snd_rom.sv"
  "$ROOT/rtl/zunit/zunit_boot_readback_audit.sv"
  "$ROOT/rtl/sdram/yunit_sdram_arb.sv"
  "$ROOT/rtl/sdram/yunit_sdram_adapter.sv"
  "$ROOT/rtl/sdram/sdram_stock_shipped.sv"
  "$ROOT/sim/sdram_chip.sv"
  "$ROOT/sim/tb_narc_snd_realchain.sv"
)

run_one() {
  local name="$1"
  local define="${2:-}"
  local vvp="$T/tb_narc_snd_realchain_${name}.vvp"
  if [[ -n "$define" ]]; then
    iverilog -g2012 -DJT51_ONLYTIMERS -DUSE_DDR3_VRAM "-D${define}" \
      -s tb_narc_snd_realchain -o "$vvp" "${SRC[@]}"
  else
    iverilog -g2012 -DJT51_ONLYTIMERS -DUSE_DDR3_VRAM \
      -s tb_narc_snd_realchain -o "$vvp" "${SRC[@]}"
  fi
  (cd "$ROOT" && vvp "$vvp")
}

echo "== real-chain sound boot: base (must PASS) =="
BASE_OUT="$(run_one base)"
printf '%s\n' "$BASE_OUT"
grep -Fq "RESULT: PASS" <<<"$BASE_OUT"

# MUT_SND_ARB_NO_AGING: restores strict-lowest G_SND priority -> the continuous
#   CGFX+SRC case must starve before WD_MAX and fail.
# MUT_SNDROM_NO_WATCHDOG: one consumed transaction loses its logical ack -> the
#   request never re-arms and both 6809 clocks remain frozen.
# MUT_SND_ACK_DROP: every G_SND ack is hidden -> bounded wedge verdict, no hang.
# MUT_SND_LANE_SWAP: landing byte lanes swapped -> vector compare must fail.
for mut in MUT_SND_ARB_NO_AGING MUT_SNDROM_NO_WATCHDOG MUT_SND_ACK_DROP MUT_SND_LANE_SWAP; do
  echo "== $mut (must die, bounded) =="
  MUT_OUT="$(run_one "$mut" "$mut")"
  printf '%s\n' "$MUT_OUT"
  if grep -Fq "RESULT: PASS" <<<"$MUT_OUT"; then
    echo "MUTANT-CHECK: FAIL -- $mut survived"
    exit 1
  fi
  if ! grep -Fq "RESULT: FAIL" <<<"$MUT_OUT"; then
    echo "MUTANT-CHECK: FAIL -- $mut died without a bounded verdict line"
    exit 1
  fi
done

echo "MUTANT-CHECK: PASS -- aging and watchdog recovery proved; permanent-ack and lane-swap faults also dead"
echo "RESULT: PASS -- real-chain sound gate green with all four mutants dead"
