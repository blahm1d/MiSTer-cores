#!/usr/bin/env python3
# pack_golden.py -- pack the MAME 0.280 :narcsnd:cpu1 (slave) per-instruction
# golden into two $readmemh mem files for the iverilog diff TB:
#   build/cpu1_regdata.mem : one 112-bit hex value per instruction, laid out
#       EXACTLY like mc6809is RegData (so the TB compares RegData === golden[n]
#       with zero re-packing on the RTL side -- no chance of a layout fudge):
#         [7:0]=A [15:8]=B [31:16]=X [47:32]=Y [63:48]=S [79:64]=U
#         [87:80]=CC [95:88]=DP [111:96]=PC
#   build/cpu1_op.mem      : one 8-bit OP per instruction (fetch-path cross-check)
#   build/cpu1_count.vh    : `define NGOLD <n>
# Source: mame-trace/goldens/narc_snd_cpu1_pc_golden.txt (entering register state,
# one record per instruction, no loop collapse). NO transformation of values --
# a pure re-encoding; the diff is still bit-exact vs the golden text.
import os, re, sys

HERE = os.path.dirname(__file__)
G = "D:/deck/fpga/NARC/mame-trace/goldens/narc_snd_cpu1_pc_golden.txt"
OUT = os.path.join(HERE, "build")
os.makedirs(OUT, exist_ok=True)
MAXN = int(sys.argv[1]) if len(sys.argv) > 1 else 150000

pat = re.compile(
    r"^(\d+) PC=([0-9A-Fa-f]{4}) OP=([0-9A-Fa-f]{2}) A=([0-9A-Fa-f]{2}) "
    r"B=([0-9A-Fa-f]{2}) X=([0-9A-Fa-f]{4}) Y=([0-9A-Fa-f]{4}) "
    r"U=([0-9A-Fa-f]{4}) S=([0-9A-Fa-f]{4}) DP=([0-9A-Fa-f]{2}) CC=([0-9A-Fa-f]{2})$")

reg_lines = []
op_lines = []
n = 0
with open(G) as f:
    for line in f:
        line = line.rstrip("\n")
        if not line or line[0] == '#':
            continue
        m = pat.match(line)
        if not m:
            raise SystemExit(f"unparseable golden line: {line!r}")
        seq, pc, op, a, b, x, y, u, s, dp, cc = m.groups()
        if int(seq) != n:
            raise SystemExit(f"seq gap: expected {n} got {seq}")
        PC = int(pc, 16); OP = int(op, 16); A = int(a, 16); B = int(b, 16)
        X = int(x, 16); Y = int(y, 16); U = int(u, 16); S = int(s, 16)
        DP = int(dp, 16); CC = int(cc, 16)
        val = (A) | (B << 8) | (X << 16) | (Y << 32) | (S << 48) | (U << 64) \
            | (CC << 80) | (DP << 88) | (PC << 96)
        reg_lines.append(f"{val:028x}")
        op_lines.append(f"{OP:02x}")
        n += 1
        if n >= MAXN:
            break

with open(os.path.join(OUT, "cpu1_regdata.mem"), "w") as f:
    f.write("\n".join(reg_lines) + "\n")
with open(os.path.join(OUT, "cpu1_op.mem"), "w") as f:
    f.write("\n".join(op_lines) + "\n")
with open(os.path.join(OUT, "cpu1_count.vh"), "w") as f:
    f.write(f"`define NGOLD {n}\n")
print(f"packed {n} golden instructions -> build/cpu1_regdata.mem (+op,+count)")
print(f"  seq0 regdata = {reg_lines[0]}  op={op_lines[0]}")
