#!/usr/bin/env python3
# pack_cvsd.py -- pack the MAME 0.280 slave CVSD digit-stream golden into $readmemh mem files
# for the iverilog CVSD_STREAM diff (tb_snd_cpu1_diff.sv). One record per slave write to the
# HC55516 bit-bang addresses, IN PROGRAM ORDER:
#   build/cvsd_kind.mem  : 0=SET(0x2000 clock_set) 1=CLR(0x2400 digit+clock_clear)
#   build/cvsd_data.mem  : the 8-bit data byte written
#   build/cvsd_digit.mem : the codec digit bit (data&1; latched by CLR, williamssound.cpp:453)
#   build/cvsd_count.vh  : `define NCVSD <k>
# Source: mame-trace/goldens/narc_snd_cvsd_stream.txt. NO transformation of values -- a pure
# re-encoding; the diff is still bit-exact vs the golden text.
import os, re, sys
HERE = os.path.dirname(__file__)
G = "D:/deck/fpga/NARC/mame-trace/goldens/narc_snd_cvsd_stream.txt"
OUT = os.path.join(HERE, "build")
os.makedirs(OUT, exist_ok=True)
MAXN = int(sys.argv[1]) if len(sys.argv) > 1 else 10**9

pat = re.compile(r"^(\d+) KIND=(SET|CLR) DATA=([0-9A-Fa-f]{2}) DIGIT=([01]) PC=([0-9A-Fa-f]{4})$")
kind, data, digit = [], [], []
n = 0
with open(G) as f:
    for line in f:
        line = line.rstrip("\n")
        if not line or line[0] == '#':
            continue
        m = pat.match(line)
        if not m:
            raise SystemExit(f"unparseable golden line: {line!r}")
        seq, k, d, dig, pc = m.groups()
        if int(seq) != n:
            raise SystemExit(f"seq gap: expected {n} got {seq}")
        dv = int(d, 16)
        if (dv & 1) != int(dig):
            raise SystemExit(f"golden self-inconsistent at {n}: DIGIT!=DATA&1")
        kind.append("1" if k == "CLR" else "0")
        data.append(f"{dv:02x}")
        digit.append(dig)
        n += 1
        if n >= MAXN:
            break

with open(os.path.join(OUT, "cvsd_kind.mem"), "w")  as f: f.write("\n".join(kind)  + "\n")
with open(os.path.join(OUT, "cvsd_data.mem"), "w")  as f: f.write("\n".join(data)  + "\n")
with open(os.path.join(OUT, "cvsd_digit.mem"), "w") as f: f.write("\n".join(digit) + "\n")
with open(os.path.join(OUT, "cvsd_count.vh"), "w")  as f: f.write(f"`define NCVSD {n}\n")
nset = kind.count("0"); nclr = kind.count("1")
print(f"packed {n} CVSD writes -> build/cvsd_{{kind,data,digit}}.mem (set={nset} clr={nclr})")
print(f"  seq0 kind={kind[0]} data={data[0]} digit={digit[0]}")
