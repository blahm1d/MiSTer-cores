#!/usr/bin/env bash
set -e
TB="tb_yunit_ddr3game"
WORK="${WORK:-work_ddr3game}"
LOG="${LOG:-qsim_$TB.log}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"; SND="$ROOT/rtl/sound"
for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -n "$VLOG" ] || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE
cd "$ROOT/sim"; rm -rf "$WORK"; "$VLIB" "$WORK" >/dev/null
SRC=( "$ROOT/rtl/pkg/yunit_pkg.sv" "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=("$f"); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" \
  "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
  "$ROOT/rtl/sdram/yunit_src_cache.sv" \
  "$ROOT/rtl/yunit/yunit_memsys.sv" "$ROOT/rtl/yunit/yunit_video.sv" \
  "$ROOT/rtl/yunit/yunit_scanline.sv" "$ROOT/rtl/yunit/yunit_video_top.sv" "$ROOT/rtl/yunit/yunit_palram.sv" \
  "$ROOT/rtl/sdram/yunit_sdram_arb.sv" "$ROOT/rtl/sdram/sdram_stock.sv" "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
  "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" "$ROOT/rtl/yunit/yunit_mem_cdc.sv" "$ROOT/rtl/yunit/yunit_top.sv" \
  "$ROOT/rtl/sound/smashtv_snd_rom.sv" )
while IFS= read -r f; do SRC+=("$f"); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
SRC+=( "$SND/williams_cvsd/mc6809is.v" "$ROOT/sim/sdram_chip.sv" "$ROOT/sim/ddr3_avalon_model.sv" "$ROOT/sim/$TB.sv" )
# Optional, non-production checkpoint observer.  It binds to this TB only when
# explicitly requested; normal regressions compile and run exactly as before.
[ "${SCENE_MONITOR:-0}" = "1" ] && SRC+=( "$ROOT/sim/tb_yunit_scene_event_monitor.sv" )
echo "vlog ${#SRC[@]} SV/V files (+USE_DDR3_VRAM)..."
MON_FLAGS=()
[ "${SCENE_MONITOR:-0}" = "1" ] && MON_FLAGS+=( +define+SCENE_MONITOR )
[ "${REAL_GFX:-0}" = "1" ] && MON_FLAGS+=( +define+REAL_GFX_PRELOAD )
for d in ${EXTRA_DEFINES:-}; do MON_FLAGS+=( "+define+$d" ); done
"$VLOG" -sv -quiet -svinputport=var -suppress 2892 +define+SYNTHESIS +define+USE_DDR3_VRAM "${MON_FLAGS[@]}" -work "$WORK" "${SRC[@]}" 2>&1 | grep -iE "error|\*\* Error" | head -20 || true
echo "vcom VHDL sound..."
"$VCOM" -2008 -quiet -work "$WORK" "$SND/williams_cvsd/gen_ram.vhd" "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" "$SND/williams_cvsd/williams_cvsd_board.vhd" 2>&1 | grep -iE "error" | head || true
[ "${COMPILE_ONLY:-0}" = "1" ] && { echo "compile-only complete -> $WORK"; exit 0; }
echo "vsim..."
# -suppress 7061: the SEED-mode TB deposits into always_ff-owned state
# (regfile/ST/SP/io_reg) once at seed time; the RTL FF keeps ownership after.
"$VSIM" -c -quiet -suppress 7061 -work "$WORK" -do "run -all; quit -f" "$TB" ${SIM_ARGS:-} > "$ROOT/sim/build/$LOG" 2>&1
echo "done -> sim/build/$LOG"
