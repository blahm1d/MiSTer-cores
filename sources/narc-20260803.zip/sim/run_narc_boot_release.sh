#!/usr/bin/env bash
# run_narc_boot_release.sh — P0046/P0033 boot-release boundary gate.
#
# The release boundary is the measured discriminator between a NARC image that plays sound
# (v8b: extra completed-read hold, sound worked, first fetch 0x60, sound-region checksum exact)
# and one that is silent (v13: bare production boundary, same word reads FFFF). Until now
# NOTHING offline covered it -- MUT_NO_DRAIN_HOLD existed in the RTL and no runner had ever
# executed it.
#
# Arms:
#   base                             must PASS
#   BR_NO_DOWNLOAD                   must PASS (bounded fail-open: no download -> still releases)
#   MUT_NO_BOOT_SETTLE               must FAIL (releases before any read completed)
#   MUT_NO_BOOT_SETTLE+NO_DRAIN_HOLD must FAIL (also releases with a write in flight)
#
# MUT_NO_DRAIN_HOLD alone is deliberately NOT an arm: with P0046 present the settle audit
# already waits for fifo_empty && !fifo_hold, so the drain term cannot independently break
# release. That is a real subsumption, not a coverage gap -- hence the paired arm above.
# Offline iverilog only (no Quartus, no Questa).
set -euo pipefail
export PATH="/c/iverilog/bin:/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="${TMPDIR:-/tmp}"

SRC=(
  "$ROOT/rtl/zunit/zunit_boot_readback_audit.sv"
  "$ROOT/sim/tb_narc_boot_release.sv"
)

run_one() {
  local name="$1"; shift
  local vvp="$T/tb_narc_boot_release_${name}.vvp"
  iverilog -g2012 "$@" -s tb_narc_boot_release -o "$vvp" "${SRC[@]}"
  (cd "$ROOT" && vvp "$vvp")
}

echo "== boot release: base (must PASS) =="
OUT="$(run_one base)"
printf '%s\n' "$OUT"
grep -Fq "RESULT: PASS" <<<"$OUT"

echo "== boot release: no download, bounded fail-open (must PASS) =="
OUT="$(run_one nodl -DBR_NO_DOWNLOAD)"
printf '%s\n' "$OUT"
grep -Fq "RESULT: PASS" <<<"$OUT"

for arm in "MUT_NO_BOOT_SETTLE" "MUT_NO_BOOT_SETTLE -DMUT_NO_DRAIN_HOLD"; do
  echo "== $arm (must die) =="
  # shellcheck disable=SC2086
  OUT="$(run_one "$(tr ' ' '_' <<<"$arm" | tr -d '-')" -D${arm})"
  printf '%s\n' "$OUT"
  if grep -Fq "RESULT: PASS" <<<"$OUT"; then
    echo "MUTANT-CHECK: FAIL -- $arm survived"
    exit 1
  fi
  grep -Fq "RESULT: FAIL" <<<"$OUT" || { echo "MUTANT-CHECK: FAIL -- $arm died without a verdict"; exit 1; }
done

echo "MUTANT-CHECK: PASS -- settle and drain terms both proved load-bearing"
echo "RESULT: PASS -- boot-release boundary gate green"
