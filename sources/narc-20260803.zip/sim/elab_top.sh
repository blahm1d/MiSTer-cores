#!/usr/bin/env bash
# Elaborate the synthesizable core top (yunit_top) under SYNTHESIS in Questa:
# real TMS34010 core + yunit_* + SDRAM controller + video + palette mirror +
# the mixed-language Williams CVSD sound board. Compile-and-elaborate only
# (run 0) — proves every port/width binds. Not a functional run.
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CORE="$ROOT/rtl/tms34010"; SND="$ROOT/rtl/sound"

for d in /c/altera/*/questa_fse/win64 /c/altera_pro/*/questa_fse/win64; do
  [ -x "$d/vlog.exe" ] && { VLOG="$d/vlog"; VCOM="$d/vcom"; VSIM="$d/vsim"; VLIB="$d/vlib"; break; }
done
[ -n "$VLOG" ] || { echo "Questa not found"; exit 1; }
unset LM_LICENSE_FILE MGLS_LICENSE_FILE

cd "$ROOT/sim"
rm -rf work_top; "$VLIB" work_top >/dev/null

# SystemVerilog: CPU core (pkg first) + yunit + sdram + video + jt51 + 6809/snd_rom
SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SRC+=( "$ROOT/rtl/pkg/yunit_pkg.sv"
       "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv"
       "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv"
       "$ROOT/rtl/yunit/yunit_memsys.sv"
       "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv"
       "$ROOT/rtl/yunit/yunit_video_top.sv" "$ROOT/rtl/yunit/yunit_palram.sv"
       "$ROOT/rtl/sdram/yunit_sdram_arb.sv" "$ROOT/rtl/sdram/sdram_phy.sv" )
while IFS= read -r f; do SRC+=( "$f" ); done < <(find "$SND/jt51/hdl" -maxdepth 1 -name '*.v' | sort)
SRC+=( "$SND/williams_cvsd/mc6809is.v" "$SND/smashtv_snd_rom.sv"
       "$ROOT/rtl/yunit/yunit_mem_cdc.sv" "$ROOT/rtl/yunit/yunit_top.sv" )

"$VLOG" -sv -quiet -svinputport=var +define+SYNTHESIS -work work_top "${SRC[@]}"

"$VCOM" -2008 -quiet -work work_top \
  "$SND/williams_cvsd/gen_ram.vhd" \
  "$SND/williams_cvsd/hc55564.vhd" \
  "$SND/williams_cvsd/pia6821.vhd" \
  "$SND/williams_cvsd/williams_cvsd_board.vhd"

echo "elaborating yunit_top ..."
"$VSIM" -c -quiet -work work_top -do "run 0; quit -f" yunit_top 2>&1 \
  | grep -viE "^# (Loading|//|\*\* Note)" | grep -iE "error|warning|fatal|yunit_top" | head -40
echo "elab_top done"
