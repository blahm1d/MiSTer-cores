#!/usr/bin/env python3
"""Rebuild the exact MAME-visible GFX prefix used by the NARC high-score gates.

MAME's init_gfxrom(8) exposes a four-way byte interleave of the four populated
graphics quadrants. The frame-1214 complete-table workload addresses bytes
0x0000..0x8d1b, so a 0x9000-byte checked prefix covers both that scene and the
smaller frame-1802 batch.

The ROM names and CRCs below are copied from docs/mame-ref/midyunit.cpp's
NARC V7_00 set.  The final byte digest was independently captured through
MAME's post-init_gfxrom CPU aperture.
"""

from __future__ import annotations

import argparse
import binascii
import hashlib
from pathlib import Path
import sys
import zipfile


PREFIX_BYTES = 0x9000
MAME_PREFIX_SHA256 = "272f8a58b5d1cea887b169006e8ee97128356391bc24c38d7674f087d5a311bc"
CHIPS = (
    ("rev2_narc_image_rom_u94.u94", 0xCA3194E4),
    ("rev2_narc_image_rom_u76.u76", 0x1CD897F4),
    ("rev2_narc_image_rom_u58.u58", 0x8A7501E3),
    ("rev2_narc_image_rom_u40.u40", 0x7FCA_EBC7),
)


def default_zip(repo: Path) -> Path:
    candidates = (repo / "releases" / "narc.zip", repo.parent / "roms" / "narc.zip")
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return candidates[0]


def main() -> int:
    repo = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", type=Path, default=default_zip(repo))
    parser.add_argument(
        "--out", type=Path, default=repo / "build_sim" / "narc_hiscore_gfx.hex"
    )
    args = parser.parse_args()

    if not args.zip.is_file():
        sys.exit(f"FATAL: NARC ROM archive not found: {args.zip}")

    chip_data: list[bytes] = []
    with zipfile.ZipFile(args.zip) as archive:
        for name, expected_crc in CHIPS:
            try:
                data = archive.read(name)
            except KeyError:
                sys.exit(f"FATAL: {name} is absent from {args.zip}")
            actual_crc = binascii.crc32(data) & 0xFFFF_FFFF
            if len(data) != 0x10000 or actual_crc != expected_crc:
                sys.exit(
                    f"FATAL: {name}: len={len(data):#x} crc={actual_crc:08x}; "
                    f"expected len=0x10000 crc={expected_crc:08x}"
                )
            chip_data.append(data)

    prefix = bytes(chip_data[p & 3][p >> 2] for p in range(PREFIX_BYTES))
    digest = hashlib.sha256(prefix).hexdigest()
    if digest != MAME_PREFIX_SHA256:
        sys.exit(
            f"FATAL: interleaved prefix sha256={digest}; "
            f"MAME aperture={MAME_PREFIX_SHA256}"
        )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text("".join(f"{value:02X}\n" for value in prefix), encoding="ascii")
    print(
        f"{args.out}: {len(prefix)} bytes, MAME-aperture sha256={digest}, "
        "ROM CRCs verified"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
