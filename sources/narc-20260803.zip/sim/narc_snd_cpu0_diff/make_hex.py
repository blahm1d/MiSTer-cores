#!/usr/bin/env python3
# make_hex.py -- extract the NARC master sound ROMs (rev2 u4/u5, 64KB each) from
# narc.zip into $readmemh hex files for the cpu0 per-instruction diff TB.
# Gospel: midyunit.cpp:1449-1454 region "narcsnd:cpu0":
#   u4 @0x50000 (+reload 0x60000), u5 @0x70000 (+reload 0x80000);
#   masterupper base rom[0x8C000]=u5[0xC000], reset vec rom[0x8FFFE:F]=u5[FFFE:F].
import zipfile, os
Z   = "D:/deck/fpga/NARC/roms/narc.zip"
OUT = os.path.join(os.path.dirname(__file__), "build")
ROMS = {"rev2_narc_sound_rom_u4.u4": "narc_snd_u4.hex",
        "rev2_narc_sound_rom_u5.u5": "narc_snd_u5.hex"}
os.makedirs(OUT, exist_ok=True)
z = zipfile.ZipFile(Z); names = set(z.namelist())
for src, dst in ROMS.items():
    key = src if src in names else next(n for n in names if n.endswith("/" + src))
    data = z.read(key)
    assert len(data) == 0x10000, f"{src}: expected 64KB, got {len(data)}"
    with open(f"{OUT}/{dst}", "w") as f:
        f.write("\n".join(f"{b:02x}" for b in data))
    print(f"{key} -> {OUT}/{dst}  reset_vec={data[0xFFFE]:02x}{data[0xFFFF]:02x}")
print("done")
