#!/usr/bin/env bash
# NARC production DDR raw-SRT gate. Base must pass; every data-shape/address
# mutant must die. This is offline simulation only (no Quartus).
set -euo pipefail
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
T="${TMPDIR:-/tmp}"
SRC=(
  "$ROOT/rtl/yunit/vram_sdram.sv"
  "$ROOT/rtl/yunit/vram_sdram_top.sv"
  "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv"
  "$ROOT/rtl/sdram/stv_vram_ddr_top.sv"
  "$ROOT/sim/ddr3_avalon_model.sv"
  "$ROOT/sim/tb_narc_srt_ddr.sv"
)

run_one() {
  local name="$1"
  local define="${2:-}"
  local vvp="$T/tb_narc_srt_ddr_${name}.vvp"
  if [[ -n "$define" ]]; then
    iverilog -g2012 "-D${define}" -s tb_narc_srt_ddr -o "$vvp" "${SRC[@]}"
  else
    iverilog -g2012 -s tb_narc_srt_ddr -o "$vvp" "${SRC[@]}"
  fi
  vvp "$vvp"
}

echo "== raw SRT base =="
BASE_OUT="$(run_one base)"
printf '%s\n' "$BASE_OUT"
grep -Fq "TEST_RESULT: PASS (1024 raw entries" <<<"$BASE_OUT"

for mut in MUT_SRT_RAW_HALF MUT_SRT_RAW_DROP_PALETTE MUT_SRT_RAW_BASE_WORD MUT_SRT_RAW_OFFBY1 MUT_SRT_SCAN_INTERLEAVE; do
  echo "== $mut (must die) =="
  MUT_OUT="$(run_one "$mut" "$mut")"
  printf '%s\n' "$MUT_OUT"
  if grep -Fq "TEST_RESULT: PASS" <<<"$MUT_OUT"; then
    echo "MUTANT-CHECK: FAIL -- $mut survived"
    exit 1
  fi
done

echo "MUTANT-CHECK: PASS -- all raw-SRT data/address/live-visibility mutants died"
