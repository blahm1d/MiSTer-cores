#!/usr/bin/env bash
# zunit_memsys ACCUMULATION gate: seed VRAM once with MAME's T0 canvas, drive the
# full ordered attract blit stream IN ORDER through the real memsys glue (CPU bus
# 0x01A00000 -> 32b D_LO/D_HI decode -> zunit_dma -> fb write -> VRAM) WITHOUT
# re-seeding, then byte-diff the RTL end-of-frame VRAM against MAME's T1 over the
# SAME DMA-written set D that replay_accum.py masks (identical golden code path),
# NO tolerance. Proves the synthesizable blit path accumulates a real MAME frame
# bit-exact under overdraw+ordering (a stronger blits>0 proof than isolated blits).
#   ./run.sh
# Gate-exercises-the-change: two named mutants must DIE (RTL-drive perturbed; the
# oracle set D is ALWAYS the full golden stream, never mutated):
#   A  --drop N    omit the golden's heaviest last-writer blit -> its final pixels
#                  revert -> D-region mismatch vs T1 (dropping ONE blit FAILS).
#   B  --reverse   drive blits in reverse order -> overdraw stack inverted ->
#                  overlapping D pixels take the wrong top value (reordering FAILS).
# The frozen zunit_dma.sv / zunit_mem.sv are NEVER modified.
# Keep every path quoted (repo tree contains a space).
set -u
export PATH="/c/iverilog/bin:$PATH"
PY="${PYTHON:-python}"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DMA="$ROOT/rtl/zunit/zunit_dma.sv"
MEM="$ROOT/rtl/zunit/zunit_mem.sv"
SYS="$ROOT/rtl/zunit/zunit_memsys.sv"
TB="$HERE/tb_zunit_memsys_accum.sv"

cd "$HERE"

build() {
  rm -f build.vvp dut_vram.hex
  iverilog -g2012 -I "$HERE" -s tb_zunit_memsys_accum \
      -o build.vvp "$PKG" "$DMA" "$MEM" "$SYS" "$TB" 2> iverilog.log
  if [ $? -ne 0 ]; then echo "IVERILOG FAIL"; cat iverilog.log; return 2; fi
  vvp build.vvp > vvp.log 2>&1
  return 0
}

echo "== BASE prep (T0 canvas + full ordered blit stream) =="
"$PY" prep_accum.py || { echo "PREP FAIL"; exit 1; }
build || { echo "BUILD FAIL"; exit 1; }
echo "== BASE compare (RTL end VRAM vs T1 over set D; expect PASS) =="
"$PY" compare_accum.py
BASE=$?
if [ $BASE -ne 0 ]; then echo "RESULT: BASE FAILED"; exit 1; fi

DROP="$("$PY" pick_drop.py)"
echo "== MUTANT A: --drop $DROP (dropping ONE blit must FAIL over set D) =="
"$PY" prep_accum.py --drop "$DROP" || { echo "PREP FAIL"; exit 1; }
build || { echo "BUILD FAIL"; exit 1; }
"$PY" compare_accum.py > mutA.log 2>&1
MA=$?
tail -3 mutA.log
if [ $MA -eq 0 ]; then echo "  A SURVIVED <-- BAD (drop not exercised)"; exit 1
else echo "  A DIED (dropping blit $DROP corrupts the accumulated frame)"; fi

echo "== MUTANT B: --reverse (reordering the stream must FAIL over set D) =="
"$PY" prep_accum.py --reverse || { echo "PREP FAIL"; exit 1; }
build || { echo "BUILD FAIL"; exit 1; }
"$PY" compare_accum.py > mutB.log 2>&1
MB=$?
tail -3 mutB.log
if [ $MB -eq 0 ]; then echo "  B SURVIVED <-- BAD (order not exercised)"; exit 1
else echo "  B DIED (reversing the overdraw stack changes the frame)"; fi

# rebuild BASE artifacts so the working tree reflects the passing gate.
echo "== rebuild BASE artifacts =="
"$PY" prep_accum.py >/dev/null
build >/dev/null
"$PY" compare_accum.py >/dev/null 2>&1 || { echo "REBUILD BASE FAILED"; exit 1; }

echo "== SUMMARY =="
echo "RESULT: PASS  (RTL end VRAM byte-exact vs MAME T1 over the DMA-written set D;"
echo "              drop + reorder mutants died; non-DMA residual measured+reported)"
exit 0
