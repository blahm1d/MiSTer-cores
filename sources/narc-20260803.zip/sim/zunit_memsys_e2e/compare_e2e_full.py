#!/usr/bin/env python3
"""FULL-FRAME zunit_memsys -> zunit_video G3 gate (NARC first-full-frame milestone).

Extends compare_e2e.py from a set-D-only compare to the WHOLE visible 512x400 frame
-- the mandatory G3 scanout closer (CLAUDE.md sec.6: PC-diff / DMA-replay is blind to
scanout, so the full frame must be compared vs a MAME captured frame, never a subset).

The RTL end-of-frame VRAM (dut_vram.hex) is rendered through zunit_video (e2e_rtl.hex)
and diffed over the ENTIRE 512x400 vs MAME's coherent T1 ref PNG.  Two assertions,
NEITHER loosened:

  (1) set-D bit-exact   -- d_D == 0 over the imported unmutated golden mask
      (ca.build_golden, IDENTICAL to compare_accum / compare_e2e; guardrail: never
      re-derived, never toleranced).  This is the compare_e2e.py D check, unchanged.

  (2) full-frame explained -- EVERY visible pixel where RTL != ref must be POSITIVELY
      inside the SRT strip, i.e. at that (x,y) MAME's T0_vram != T1_vram
      (goldens/narc_accum_t0_vram.hex vs narc_accum_t1_vram.hex).  The RTL drive
      replays only the DMA stream onto T0, so a legitimate residual can ONLY be a
      pixel MAME changed by the SRT scroll-copy (T0!=T1) but the DMA replay did not.
      A residual where T0_vram == T1_vram is unexplained -> HARD FAIL.  This bound is
      MEASURED two-sided per pixel -- NOT a tolerance count, NOT an x-range whitelist.

Any full-frame diff not so explained FAILS the gate.  Residual (SRT) pixel count is
reported (~57).

Usage: compare_e2e_full.py [rtl_rgb.hex]
Exit 0 = PASS (full 512x400 RGB bit-exact vs ref PNG except the T0!=T1 SRT strip).
"""
import os
import sys
import numpy as np

VIS_W, VIS_H = 512, 400
W = 512                                    # full VRAM row stride (512x512)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
ACCUM_SIM = os.path.join(ROOT, "sim", "zunit_memsys_accum")
MAME = os.path.abspath(os.path.join(ROOT, "..", "mame-trace"))
VG_DIR = os.path.join(MAME, "video_golden")
GOLD = os.path.join(MAME, "goldens")

sys.path.insert(0, ACCUM_SIM)
import compare_accum as ca                 # noqa: E402 (SAME golden D mask as accum gate)
sys.path.insert(0, VG_DIR)
import video_golden as vg                  # noqa: E402 (blind RGB oracle + hex loaders)


def load_rtl_rgb(path):
    with open(path) as f:
        vals = [int(x, 16) for x in f.read().split()]
    a = np.array(vals, dtype=np.uint32)
    if a.size != VIS_W * VIS_H:
        raise SystemExit(f"FATAL: RTL RGB has {a.size} px, expected {VIS_W*VIS_H}")
    rgb = np.empty((a.size, 3), dtype=np.uint8)
    rgb[:, 0] = (a >> 16) & 0xff
    rgb[:, 1] = (a >> 8) & 0xff
    rgb[:, 2] = a & 0xff
    return rgb.reshape(VIS_H, VIS_W, 3)


def load_vram_vis(path):
    """local_videoram flat -> visible (400,512) words (row=idx>>9, col=idx&0x1ff)."""
    v = vg.load_hex_u16(path)
    if v.size != W * W:
        raise SystemExit(f"FATAL: {os.path.basename(path)} has {v.size} words, "
                         f"expected {W*W}")
    return v.reshape(W, W)[:VIS_H, :VIS_W]


def main():
    rtlpath = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "e2e_rtl.hex")
    rtl = load_rtl_rgb(rtlpath)

    # --- set D (imported, unmutated golden stream), restricted to visible 512x400 ---
    blits, meta, gfb, written = ca.build_golden()
    wv = np.array(written, dtype=np.uint8).reshape(W, W)[:VIS_H, :VIS_W].astype(bool)
    d_count = int(wv.sum())

    # --- oracle 1: MAME coherent T1 ref PNG --------------------------------------
    ref = vg.load_ref_png(os.path.join(GOLD, "narc_accum_ref.png"))
    # --- oracle 2: blind video_golden render of MAME's T1 VRAM + frozen palette ---
    t1 = vg.load_hex_u16(os.path.join(GOLD, "narc_accum_t1_vram.hex"))
    pal = vg.load_hex_u16(os.path.join(GOLD, "narc_accum_palette.hex"))
    gold = vg.render_scene(t1, pal)
    if ref.shape != (VIS_H, VIS_W, 3) or gold.shape != (VIS_H, VIS_W, 3):
        raise SystemExit(f"FATAL: oracle shape ref={ref.shape} gold={gold.shape}")

    # --- SRT strip (two-sided, MEASURED): pixels MAME changed T0->T1 in VRAM ------
    t0v = load_vram_vis(os.path.join(GOLD, "narc_accum_t0_vram.hex"))
    t1v = load_vram_vis(os.path.join(GOLD, "narc_accum_t1_vram.hex"))
    srt_mask = (t0v != t1v)                 # (400,512) bool, per-pixel T0!=T1

    # --- oracle-consistency guard (never weaken): the two oracles must AGREE over
    # the FULL visible frame (both are renders of MAME's coherent T1). ------------
    oc = int(np.any(ref != gold, axis=-1).sum())
    if oc != 0:
        print(f"ORACLE-INCONSISTENT: ref PNG != video_golden(T1) over {oc} full-frame "
              f"pixels (broken oracle triple; NOT tolerated)")
        return 1

    # --- assertion (1): set-D bit-exact (compare_e2e.py check, UNCHANGED) ---------
    ne_ref = np.any(rtl != ref, axis=-1)    # full-frame RTL != ref
    ne_gold = np.any(rtl != gold, axis=-1)
    d_D = int(((ne_ref | ne_gold) & wv).sum())

    # --- assertion (2): full-frame -- every RTL!=ref pixel is inside the SRT strip
    resid_total = int(ne_ref.sum())         # all full-frame RTL != ref pixels
    unexplained_mask = ne_ref & ~srt_mask   # RTL!=ref but T0_vram==T1_vram -> a bug
    unexplained = int(unexplained_mask.sum())
    resid_srt = int((ne_ref & srt_mask).sum())
    cpuw, srt = meta.get("cpuw"), meta.get("srt_seen")

    print(f"visible D pixels (mapped to 512x400) = {d_count}")
    print(f"set-D bit-exact d_D (RTL != ref OR != golden, over D) = {d_D}  "
          f"(0 => set D RGB bit-exact vs both oracles)")
    print(f"full-frame residual (visible, RTL != ref) = {resid_total}  "
          f"[capture CPUW={cpuw} SRT_seen={srt}]")
    print(f"  of which inside SRT strip (T0_vram != T1_vram) = {resid_srt}")
    print(f"  UNEXPLAINED (RTL != ref AND T0_vram == T1_vram) = {unexplained}  "
          f"(must be 0)")
    for yx in np.argwhere(unexplained_mask)[:8]:
        y, x = int(yx[0]), int(yx[1])
        print(f"  UNEXPLAINED ({x},{y}): rtl={tuple(int(v) for v in rtl[y,x])} "
              f"ref={tuple(int(v) for v in ref[y,x])} "
              f"t0={int(t0v[y,x]):04x} t1={int(t1v[y,x]):04x}")

    ok = (d_count > 0 and d_D == 0 and unexplained == 0)
    print("GATE: " + (
        f"PASS -- full 512x400 RTL frame RGB bit-exact vs MAME ref PNG except the "
        f"{resid_srt}-pixel SRT strip (every residual pixel positively T0_vram!=T1_vram); "
        f"set-D d_D=0" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
