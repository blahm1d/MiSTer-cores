#!/usr/bin/env python3
"""zunit_memsys -> zunit_video END-TO-END gate (NARC Phase-3 blits->frame milestone).

Renders the RTL end-of-frame VRAM (dut_vram.hex, produced by the accumulation gate
tb_zunit_memsys_accum through the real memsys glue) THROUGH zunit_video with the
coherent frozen-T1 palette, and diffs the RGB888 frame against BOTH oracles over the
DMA-written set D (mapped to the visible 512x400):

  * MAME's coherent T1 reference PNG   (mame-trace/goldens/narc_accum_ref.png), and
  * the blind video_golden.py render of MAME's T1 VRAM + palette (independent agreement).

This is the first NARC gate that spans the whole memsys-BRAM-layout <-> video-read seam:
memsys' clocked single-port BRAM VRAM word (hi=palette-select, lo=pixel) must equal
zunit_video's scanline-unpack read layout.  PC-diff is blind to scanout; this proves it.

Set D is the IDENTICAL golden mask compare_accum.py / replay_accum.py use -- it is
IMPORTED (compare_accum.build_golden), never re-derived, and ALWAYS the full unmutated
golden stream (guardrail).  NO tolerance over D.  The non-DMA residual (the SRT scroll
copy, ~57 px) is out of scope: MEASURED + REPORTED, NEVER absorbed into the D check
and NEVER allowed to touch it (CLAUDE.md sec.5).

Usage: compare_e2e.py <rtl_rgb.hex>
Exit 0 = PASS (over visible D, RTL RGB == ref PNG AND == video_golden(T1)).
"""
import os
import sys
import numpy as np

VIS_W, VIS_H = 512, 400
W = 512                                    # full VRAM row stride (512x512)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
ACCUM_SIM = os.path.join(ROOT, "sim", "zunit_memsys_accum")
MAME = os.path.abspath(os.path.join(ROOT, "..", "mame-trace"))
VG_DIR = os.path.join(MAME, "video_golden")
GOLD = os.path.join(MAME, "goldens")

sys.path.insert(0, ACCUM_SIM)
import compare_accum as ca                 # noqa: E402 (SAME golden D mask as the accum gate)
sys.path.insert(0, VG_DIR)
import video_golden as vg                  # noqa: E402 (blind RGB oracle)


def load_rtl_rgb(path):
    with open(path) as f:
        vals = [int(x, 16) for x in f.read().split()]
    a = np.array(vals, dtype=np.uint32)
    if a.size != VIS_W * VIS_H:
        raise SystemExit(f"FATAL: RTL RGB has {a.size} px, expected {VIS_W*VIS_H}")
    rgb = np.empty((a.size, 3), dtype=np.uint8)
    rgb[:, 0] = (a >> 16) & 0xff
    rgb[:, 1] = (a >> 8) & 0xff
    rgb[:, 2] = a & 0xff
    return rgb.reshape(VIS_H, VIS_W, 3)


def main():
    rtlpath = sys.argv[1] if len(sys.argv) > 1 else "e2e_rtl.hex"
    rtl = load_rtl_rgb(rtlpath)

    # --- set D (imported, unmutated golden stream), restricted to visible 512x400 ---
    blits, meta, gfb, written = ca.build_golden()
    wv = np.array(written, dtype=np.uint8).reshape(W, W)[:VIS_H, :VIS_W].astype(bool)
    d_count = int(wv.sum())

    # --- oracle 1: MAME coherent T1 ref PNG --------------------------------------
    ref = vg.load_ref_png(os.path.join(GOLD, "narc_accum_ref.png"))
    # --- oracle 2: blind video_golden render of MAME's T1 VRAM + frozen palette ---
    t1 = vg.load_hex_u16(os.path.join(GOLD, "narc_accum_t1_vram.hex"))
    pal = vg.load_hex_u16(os.path.join(GOLD, "narc_accum_palette.hex"))
    gold = vg.render_scene(t1, pal)
    if ref.shape != (VIS_H, VIS_W, 3) or gold.shape != (VIS_H, VIS_W, 3):
        raise SystemExit(f"FATAL: oracle shape ref={ref.shape} gold={gold.shape}")

    # --- oracle-consistency guard (never weaken): the two oracles must AGREE over D
    # (both are renders of MAME's T1); if not, the triple is broken -> HARD FAIL.
    oc = int((np.any(ref != gold, axis=-1) & wv).sum())
    if oc != 0:
        print(f"ORACLE-INCONSISTENT: ref PNG != video_golden(T1) over {oc}/{d_count} "
              f"D pixels (broken oracle triple; NOT tolerated)")
        return 1

    # --- the gate: RTL RGB == ref AND == golden over D, no tolerance --------------
    ne_ref = np.any(rtl != ref, axis=-1)
    ne_gold = np.any(rtl != gold, axis=-1)
    d_png = int((ne_ref & wv).sum())
    d_gold = int((ne_gold & wv).sum())
    d_D = int(((ne_ref | ne_gold) & wv).sum())

    # --- non-DMA residual: visible pixels NOT in D where RTL != ref (dut_vram holds
    # T0 there; ref holds T1 -> the SRT scroll-copy delta). Measured + reported ONLY.
    resid = int((ne_ref & ~wv).sum())
    cpuw, srt = meta.get("cpuw"), meta.get("srt_seen")

    print(f"visible D pixels (mapped to 512x400) = {d_count}")
    print(f"RTL vs MAME ref PNG   over D = {d_png}")
    print(f"RTL vs video_golden(T1) over D = {d_gold}")
    print(f"combined d_D (RTL != ref OR != golden, over D) = {d_D}  "
          f"(0 => RGB bit-exact vs both oracles)")
    print(f"non-D residual (visible, RTL!=ref, p NOT in D) = {resid}  "
          f"[out of scope: SRT scroll-copy; capture CPUW={cpuw} SRT_seen={srt}; "
          f"MEASURED, NOT tolerated into D]")
    for yx in np.argwhere((ne_ref | ne_gold) & wv)[:8]:
        y, x = int(yx[0]), int(yx[1])
        print(f"  D-MISMATCH ({x},{y}): rtl={tuple(int(v) for v in rtl[y,x])} "
              f"ref={tuple(int(v) for v in ref[y,x])} gold={tuple(int(v) for v in gold[y,x])}")

    ok = (d_count > 0 and d_D == 0)
    print("GATE: " + ("PASS -- RTL memsys VRAM rendered through zunit_video is RGB "
                      "bit-exact vs MAME ref PNG AND video_golden(T1) over the DMA set D; "
                      "non-DMA residual measured+reported" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
