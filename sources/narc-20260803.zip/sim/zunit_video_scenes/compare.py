#!/usr/bin/env python
"""Diff the RTL (zunit_video.sv) RGB888 render of one scene BIT-EXACT against the
MAME reference PNG over the full visible 512x400 frame. Zero tolerance.

The scene VRAM was captured post-DMA/SRT/autoerase (scene_checkpoints.lua), so a
correct zunit_video render is expected bit-exact; any residual is a real
zunit_video pen/palette/unpack bug to REPORT, never tolerance-absorb.

Usage: compare.py <scene> <rgb.hex> [ref.png]
The optional third argument overrides the reference PNG path (used by the
P0031 DPYSTRT row-80 scene, whose golden lives outside scene_checkpoints/).
Exit 0 iff the RTL frame is pixel-exact vs the ref PNG.
"""
import sys
import os
import numpy as np
from PIL import Image

VIS_W, VIS_H = 512, 400
HERE = os.path.dirname(os.path.abspath(__file__))
CKPT = os.path.abspath(os.path.join(HERE, "..", "..", "..",
                                    "mame-trace", "goldens", "scene_checkpoints"))


def load_rtl_rgb(path):
    with open(path) as f:
        vals = [int(x, 16) for x in f.read().split()]
    a = np.array(vals, dtype=np.uint32)
    if a.size != VIS_W * VIS_H:
        raise SystemExit(f"RTL output has {a.size} px, expected {VIS_W*VIS_H}")
    rgb = np.empty((a.size, 3), dtype=np.uint8)
    rgb[:, 0] = (a >> 16) & 0xff
    rgb[:, 1] = (a >> 8) & 0xff
    rgb[:, 2] = a & 0xff
    return rgb.reshape(VIS_H, VIS_W, 3)


def load_ref_png(path):
    return np.asarray(Image.open(path).convert("RGB"), dtype=np.uint8)


def main():
    scene, hexpath = sys.argv[1], sys.argv[2]
    got = load_rtl_rgb(hexpath)
    ref_path = sys.argv[3] if len(sys.argv) > 3 else \
        os.path.join(CKPT, f"narc_{scene}_ref.png")
    ref = load_ref_png(ref_path)
    tot = VIS_W * VIS_H
    if got.shape != ref.shape:
        print(f"[{scene:24s}] FAIL shape {got.shape} != ref {ref.shape}")
        return 1
    diff = int(np.count_nonzero(np.any(got != ref, axis=-1)))
    ok = (diff == 0)
    print(f"[{scene:24s}] {'PASS' if ok else 'FAIL'} diff_px={diff}/{tot} "
          f"(RTL zunit_video RGB vs MAME ref PNG, full 512x400, bit-exact)")
    if not ok:
        for yx in np.argwhere(np.any(got != ref, axis=-1))[:6]:
            y, x = int(yx[0]), int(yx[1])
            print(f"    ({x},{y}) rtl={tuple(int(v) for v in got[y,x])} "
                  f"ref={tuple(int(v) for v in ref[y,x])}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
