#!/usr/bin/env bash
# zunit_video_scenes — G3 scanout proof extended 1->4 independent MAME frames.
#
# Renders each of the 4 SHA-pinned scene checkpoints
# (mame-trace/goldens/scene_checkpoints/narc_<scene>_vram.hex) through the real
# rtl/zunit/zunit_video.sv scanline-unpack + palette back-end, using that scene's
# own _palette.hex, and diffs the RGB888 frame BIT-EXACT vs the MAME reference PNG
# over the full visible 512x400. Zero tolerance (captured VRAM already holds any
# SRT/autoerase content -> a correct render is bit-exact; a residual is a real
# zunit_video bug to report).
#
# Guardrail: FNV integrity of every vram/palette hex is verified against
# narc_scenes.tsv BEFORE rendering (verify_integrity.py); the control word
# (videobank D5, narc_scenes.tsv) is decoded and reported per scene.
#
# Gate-exercises-the-change (acceptance: >=1 scene MUST FAIL under a mutant):
#   MUT_6BPP       donor Y-unit 6bpp pen mask 0x0FFF (drops the pen high nibble).
#   MUT_PLANESWAP  videobank-plane swap = byte-swap of each VRAM word.
# Frozen RTL (rtl/zunit/zunit_video.sv) is NEVER modified; verification only.
# Quote every path (repo tree contains a space).
set -u
export PATH="/c/iverilog/bin:$PATH"
PY="${PYTHON:-python}"

HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
PKG="$ROOT/rtl/zunit/zunit_pkg.sv"
DUT="$ROOT/rtl/zunit/zunit_video.sv"
TB="$HERE/tb_zunit_video.sv"
CKPT="$ROOT/../mame-trace/goldens/scene_checkpoints"

SCENES="high_score_table gameplay_demo_junkyard title_logo title_credits"

cd "$HERE"

build() {   # $1 = extra defines (may be empty), $2 = vvp name
    rm -f "$2"
    iverilog -g2012 $1 -s tb_zunit_video -o "$2" "$PKG" "$DUT" "$TB" 2> iverilog.log
    if [ $? -ne 0 ]; then echo "IVERILOG FAIL"; cat iverilog.log; return 2; fi
    return 0
}

# ---- guardrail: verify input hex integrity (FNV vs narc_scenes.tsv) ----------
echo "== FNV integrity + control-word decode (narc_scenes.tsv) =="
"$PY" verify_integrity.py || { echo "RESULT: INTEGRITY FAILED"; exit 1; }

# ---- BASE: render all 4 scenes, bit-exact vs ref PNG -------------------------
echo "== BASE build (8bpp, PEN_MASK=0x1FFF) =="
build "" build_base.vvp || { echo "RESULT: BUILD FAILED"; exit 1; }

echo "== BASE render + bit-exact diff vs MAME ref PNG (full 512x400) =="
BASE_PASS=0
for S in $SCENES; do
    vvp build_base.vvp \
        +VRAM="$CKPT/narc_${S}_vram.hex" \
        +PAL="$CKPT/narc_${S}_palette.hex" \
        +OUT="rtl_${S}.hex" > "vvp_${S}.log" 2>&1
    "$PY" compare.py "$S" "rtl_${S}.hex"
    [ $? -eq 0 ] && BASE_PASS=$((BASE_PASS+1))
done
echo "BASE: ${BASE_PASS}/4 scenes RGB bit-exact vs ref PNG"

# ---- MUTANTS: each must kill >=1 scene ---------------------------------------
run_mutant() {   # $1 = define, $2 = tag
    build "-D$1" "build_${2}.vvp" || { echo "RESULT: MUTANT BUILD FAILED ($2)"; exit 1; }
    local pass=0
    for S in $SCENES; do
        vvp "build_${2}.vvp" \
            +VRAM="$CKPT/narc_${S}_vram.hex" \
            +PAL="$CKPT/narc_${S}_palette.hex" \
            +OUT="${2}_${S}.hex" > "vvp_${2}_${S}.log" 2>&1
        "$PY" compare.py "$S" "${2}_${S}.hex" > /dev/null 2>&1
        [ $? -eq 0 ] && pass=$((pass+1))
    done
    echo $((4-pass))
}

echo "== MUTANT MUT_6BPP (donor 6bpp mask 0x0FFF) — must kill >=1 scene =="
K6=$(run_mutant MUT_6BPP m6bpp)
echo "MUTANT MUT_6BPP:      ${K6} scene(s) killed"

echo "== MUTANT MUT_PLANESWAP (videobank-plane byte-swap) — must kill >=1 scene =="
KPS=$(run_mutant MUT_PLANESWAP mps)
echo "MUTANT MUT_PLANESWAP: ${KPS} scene(s) killed"

KILL_MAX=$K6
[ "$KPS" -gt "$KILL_MAX" ] && KILL_MAX=$KPS

echo "----------------------------------------------------------------------"
if [ "$BASE_PASS" -eq 4 ] && [ "$KILL_MAX" -ge 1 ]; then
    echo "RESULT: PASS (4/4 scenes RGB bit-exact vs ref PNG over 512x400; "\
"mutants killed 6bpp=${K6} planeswap=${KPS})"
    exit 0
else
    echo "RESULT: FAIL (base ${BASE_PASS}/4; mutants killed 6bpp=${K6} planeswap=${KPS})"
    exit 1
fi
