#!/usr/bin/env python
"""Verify the SHA-pinned scene checkpoint hex files against the FNV fingerprints
recorded in narc_scenes.tsv BEFORE rendering (guardrail: a corrupt/regenerated
input hex must be caught, not silently rendered).

FNV-1a exactly as scene_checkpoints.lua:96-119 computes it:
    h = 0x811C9DC5
    for each 16-bit word w (in file/dump order):
        h = ((h ^ w) * 0x01000193) & 0xFFFFFFFF
vram_fnv covers the full 512x512 dump (262144 words); pal_fnv covers 8192 words.

Also decodes the control word (videobank = CONTROL bit 5, midyunit_v.cpp:154-161).

Exit 0 iff every scene's vram_fnv AND pal_fnv match the TSV. No tolerance.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
CKPT = os.path.abspath(os.path.join(HERE, "..", "..", "..",
                                    "mame-trace", "goldens", "scene_checkpoints"))
TSV = os.path.join(CKPT, "narc_scenes.tsv")

FNV_OFFSET = 0x811C9DC5
FNV_PRIME = 0x01000193
MASK32 = 0xFFFFFFFF


def fnv1a_hex(path):
    h = FNV_OFFSET
    with open(path) as f:
        for tok in f.read().split():
            w = int(tok, 16) & 0xFFFF
            h = ((h ^ w) * FNV_PRIME) & MASK32
    return h


def load_scenes():
    scenes = []
    with open(TSV) as f:
        header = f.readline().rstrip("\n").split("\t")
        idx = {k: i for i, k in enumerate(header)}
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            c = line.rstrip("\n").split("\t")
            scenes.append({
                "name": c[idx["name"]],
                "vram_fnv": int(c[idx["vram_fnv"]], 16),
                "pal_fnv": int(c[idx["pal_fnv"]], 16),
                "control": int(c[idx["control"]], 16),
            })
    return scenes


def main():
    scenes = load_scenes()
    if not scenes:
        print("FATAL: no scenes parsed from narc_scenes.tsv")
        return 1
    allok = True
    for s in scenes:
        vpath = os.path.join(CKPT, f"narc_{s['name']}_vram.hex")
        ppath = os.path.join(CKPT, f"narc_{s['name']}_palette.hex")
        vg = fnv1a_hex(vpath)
        pg = fnv1a_hex(ppath)
        vok = (vg == s["vram_fnv"])
        pok = (pg == s["pal_fnv"])
        d5 = (s["control"] >> 5) & 1
        ok = vok and pok
        allok = allok and ok
        print(f"[{s['name']:24s}] {'OK  ' if ok else 'FAIL'} "
              f"vram_fnv={vg:08X}{'==' if vok else '!='}{s['vram_fnv']:08X} "
              f"pal_fnv={pg:08X}{'==' if pok else '!='}{s['pal_fnv']:08X} "
              f"control={s['control']:04X} videobank(D5)={d5}")
    print(f"INTEGRITY: {'PASS' if allok else 'FAIL'} "
          f"({sum(1 for _ in scenes)} scenes)")
    return 0 if allok else 1


if __name__ == "__main__":
    sys.exit(main())
