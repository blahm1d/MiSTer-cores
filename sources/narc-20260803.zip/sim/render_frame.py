#!/usr/bin/env python3
# Render a dumped VRAM+palette (from tb_yunit_frame) into a PNG, faithfully to
# MAME's scanout: pen_map6(word) -> palette (xRGB1555, folded to pens) -> RGB888.
# Usage:  python3 sim/render_frame.py   (run from repo root; needs sim/build/*_dump.hex)
#
# PALETTE FOLD (important): MAME addresses palette pens as (write_offset & 0x0FFF)
# — 4096 pens. Our yunit_mem stores the palette UNFOLDED (0x2000 words at literal
# offsets), so a write to 0x01810000 (offset 0x1000) lands at pal[0x1000] but MAME
# aliases it to pen 0x000. We fold here. (yunit_video should mask pal addr & 0x0FFF,
# or yunit_mem should mask palette writes — see HANDOFF.)
import sys
def read_memh(fn, size):
    arr=[0]*size; addr=0
    for line in open(fn):
        line=line.split('//')[0].strip()
        if not line: continue
        if line.startswith('@'): addr=int(line[1:],16); continue
        for tok in line.split():
            if addr<size: arr[addr]=int(tok,16); addr+=1
    return arr
def pen6(w): return (((w>>8)&0xF)<<8) | (((w>>14)&0x3)<<6) | (w&0x3F)  # {w[11:8],w[15:14],w[5:0]}
def rgb(c):
    r5=(c>>10)&0x1F; g5=(c>>5)&0x1F; b5=c&0x1F; ex=lambda v:(v<<3)|(v>>2)
    return (ex(r5),ex(g5),ex(b5))
d=sys.argv[1] if len(sys.argv)>1 else "sim/build"
suf=sys.argv[2] if len(sys.argv)>2 else "dump"   # e.g. precoin/postcoin/poststart
vram=read_memh(f"{d}/vram_{suf}.hex", 0x40000)
pal =read_memh(f"{d}/pal_{suf}.hex",  0x2000)
palf=[0]*4096
for off in range(0x2000):
    if pal[off]: palf[off & 0xfff]=pal[off]   # fold to pens
W,H=512,512
buf=bytearray(W*H*3)
for i,w in enumerate(vram):
    r,g,b=rgb(palf[pen6(w)&0xFFF]); o=i*3; buf[o]=r; buf[o+1]=g; buf[o+2]=b
from PIL import Image
img=Image.frombytes("RGB",(W,H),bytes(buf))
img.crop((0,10,512,258)).save(f"{d}/frame_{suf}.png")   # stdres visible-ish crop
print(f"wrote {d}/frame_{suf}.png")
