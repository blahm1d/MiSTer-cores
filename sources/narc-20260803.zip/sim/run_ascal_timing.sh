#!/usr/bin/env bash
# Offline gate for the scaler-only timing candidate. No Quartus is invoked.
set -euo pipefail
PYTHON_BIN="${PYTHON_BIN:-$(command -v python3 || command -v python)}"
GHDL_BIN="${GHDL_BIN:-$(command -v ghdl)}"
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PY="$ROOT/sim/test_ascal_timing.py"
ASCAL="$ROOT/sys/ascal.vhd"
T="${TMPDIR:-/tmp}/narc-ascal-timing.$$"
mkdir -p "$T"
trap 'rm -rf "$T"' EXIT

"$PYTHON_BIN" "$PY" --source "$ASCAL"

"$GHDL_BIN" -a --std=08 --workdir="$T" "$ASCAL"
echo "RESULT: PASS -- production ascal.vhd analyzes with GHDL"

set +e
"$PYTHON_BIN" "$PY" --source "$ASCAL" --mutation counter-live >"$T/counter-live.log" 2>&1
counter_rc=$?
"$PYTHON_BIN" "$PY" --source "$ASCAL" --mutation line-bypass >"$T/line-bypass.log" 2>&1
line_rc=$?
"$PYTHON_BIN" "$PY" --source "$ASCAL" --mutation eol-live >"$T/eol-live.log" 2>&1
eol_rc=$?
set -e

if [[ "$counter_rc" -eq 0 ]] ||
   ! grep -Fq "counter-live mutation restores the increment/compare/mux feedback cone" \
      "$T/counter-live.log"; then
  sed 's/^/  /' "$T/counter-live.log" >&2
  echo "RESULT: FAIL -- live vertical-counter mutation escaped the mechanism gate" >&2
  exit 1
fi

if [[ "$line_rc" -eq 0 ]] ||
   ! grep -Fq "line-bypass mutation reconnects the split BRAM output directly to pixel selection" \
      "$T/line-bypass.log"; then
  sed 's/^/  /' "$T/line-bypass.log" >&2
  echo "RESULT: FAIL -- line-buffer bypass mutation escaped the mechanism gate" >&2
  exit 1
fi

if [[ "$eol_rc" -eq 0 ]] ||
   ! grep -Fq "eol-live mutation reconnects the horizontal counter directly to every vertical load" \
      "$T/eol-live.log"; then
  sed 's/^/  /' "$T/eol-live.log" >&2
  echo "RESULT: FAIL -- live end-of-line mutation escaped the mechanism gate" >&2
  exit 1
fi

echo "RESULT: PASS -- counter-live, line-buffer-bypass, and eol-live mutations are all rejected"
