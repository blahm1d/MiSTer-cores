//============================================================================
//  crt_adjust.sv -- core-side CRT geometry adjustment for MiSTer arcade cores.
//
//  Based on rmonic79/MiSTer-CRT-Adjust, crt_adjust.sv, master blob
//  31f7cccff76053c15e40f30fa1663665596bf18a (2026-07-28).
//  Author: Umberto Parisi (rmonic79), with Andrea Bogazzi / @asturur.
//  Distributed under GNU GPL v3 or later.
//
//  NARC adaptation:
//    The upstream fixed 1024-word memory is two 512-sample ping-pong banks.
//    NARC has a 674-pixel native line, so BANK_AW is derived from HTOTAL and
//    each bank is 1024 samples.  No frame buffering or refresh conversion is
//    performed: native H/V periods remain 674 x 433 at 16 MHz (54.82 Hz).
//
//  The read-rate generator outside this module MUST restart on hs_ref_out.
//============================================================================
`timescale 1ns/1ps
`default_nettype none

`ifndef HPOS_SYNCSHIFT
`define HPOS_SYNCSHIFT     0
`define HPOS_CONTENTSHIFT  1
`endif

module crt_adjust #(
  parameter integer VTOTAL = 263,
  parameter integer HTOTAL = 384,
  parameter integer HPOS_MODE = `HPOS_CONTENTSHIFT
) (
  input  wire              clk,
  input  wire              pxl_cen,
  input  wire              pxl2_cen,
  input  wire              active,
  input  wire signed [4:0] hsize,
  input  wire signed [8:0] hoffset,
  input  wire signed [5:0] voffset,
  input  wire [7:0]        r_in,
  input  wire [7:0]        g_in,
  input  wire [7:0]        b_in,
  input  wire              hs_in,
  input  wire              vs_in,
  input  wire              hb_in,
  input  wire              vb_in,
  output reg  [7:0]        r_out,
  output reg  [7:0]        g_out,
  output reg  [7:0]        b_out,
  output reg               hs_out,
  output reg               vs_out,
  output reg               hb_out,
  output reg               vb_out,
  output wire              hs_ref_out
);

  // One power-of-two bank must hold a complete native line.  The extra bit
  // selects the read/write ping-pong bank.
  localparam integer BANK_AW = $clog2(HTOTAL);
  localparam integer AW      = BANK_AW + 1;
  localparam [10:0] HTOTAL_U = HTOTAL;
  localparam [9:0]  VTOTAL_U = VTOTAL;

  reg [7:0] r_in_q, g_in_q, b_in_q;
  reg hs_in_q, hb_in_q, vs_in_q, vb_in_q, hs_in_d;
  initial begin
    r_in_q=0; g_in_q=0; b_in_q=0;
    hs_in_q=0; hb_in_q=1; vs_in_q=0; vb_in_q=0; hs_in_d=0;
  end
  always @(posedge clk) if (pxl_cen) begin
    r_in_q<=r_in; g_in_q<=g_in; b_in_q<=b_in;
    hs_in_q<=hs_in; hb_in_q<=hb_in; vs_in_q<=vs_in; vb_in_q<=vb_in;
    hs_in_d<=hs_in;
  end

  // HPOS_SYNCSHIFT advances a negative offset by selecting the matching tap
  // from the preceding native line; a positive offset delays directly.
  wire signed [10:0] hoff_ext = {{2{hoffset[8]}},hoffset};
  wire signed [10:0] hshift_calc =
      hoffset[8] ? $signed(HTOTAL_U) + hoff_ext
                 : $signed({2'b00,hoffset});
  wire [9:0] hshift_tap_next = hshift_calc[9:0];
  // Geometry controls arrive from the OSD and are static for normal display,
  // but allowing their decode to feed the 674-way sync tap directly both
  // permits a mid-line sync discontinuity and leaves the selector on the
  // clk_sys critical path.  Commit a new tap only at the raw native line
  // boundary.  Nonblocking assignment keeps the current line on the old,
  // complete setting and applies the new setting to the following line.
`ifdef MUT_CRT_HPOS_UNLATCHED
  wire [9:0] hshift_tap = hshift_tap_next;
`else
  reg [9:0] hshift_tap;
`endif
  reg [HTOTAL-1:0] hsync_pix_shreg;
  reg hs_shifted;
  initial begin
`ifndef MUT_CRT_HPOS_UNLATCHED
    hshift_tap=0;
`endif
    hsync_pix_shreg=0; hs_shifted=0;
  end
  always @(posedge clk) if (pxl_cen) begin
`ifndef MUT_CRT_HPOS_UNLATCHED
    if (hs_in && !hs_in_q) hshift_tap <= hshift_tap_next;
`endif
    hsync_pix_shreg <= {hsync_pix_shreg[HTOTAL-2:0],hs_in};
    hs_shifted <= (hshift_tap==0) ? hs_in
                                  : hsync_pix_shreg[hshift_tap-1'b1];
  end

  wire hs_read_ref = (HPOS_MODE == `HPOS_SYNCSHIFT) ? hs_shifted : hs_in;
  assign hs_ref_out = hs_read_ref;
  reg hs_ref_d1;
  initial hs_ref_d1=0;
  always @(posedge clk) if (pxl_cen) hs_ref_d1<=hs_read_ref;
  wire hs_rise_in = pxl_cen && hs_read_ref && !hs_ref_d1;

  (* ramstyle = "no_rw_check, M10K" *)
  reg [23:0] mem [0:(1<<AW)-1];
  integer ii;
  initial for (ii=0; ii<(1<<AW); ii=ii+1) mem[ii]=24'd0;

  reg [AW-1:0] wrp;
  reg [AW-1:0] hb0, hb1;
  reg lhb_l, bank;
  wire lhb = ~hb_in;
  initial begin wrp=0; hb0=0; hb1=0; lhb_l=0; bank=0; end
  always @(posedge clk) if (pxl_cen) begin
    lhb_l <= lhb;
    mem[{bank,wrp[BANK_AW-1:0]}] <= {r_in,g_in,b_in};
    if (hs_rise_in) begin
      wrp<=0;
      bank<=~bank;
    end else begin
      wrp<=wrp+1'b1;
    end
    if (lhb && !lhb_l) hb1<=wrp;
    if (!lhb && lhb_l) hb0<=wrp;
  end

  // Detect the shared reference at full clk rate, then consume the pending
  // line reset on the next read enable.
  reg [AW-1:0] rdcnt;
  reg hs_in_d2, hs_rise_pending;
  initial begin rdcnt=0; hs_in_d2=0; hs_rise_pending=0; end
  always @(posedge clk) begin
    hs_in_d2<=hs_read_ref;
    if (hs_read_ref && !hs_in_d2) hs_rise_pending<=1'b1;
    else if (pxl2_cen)            hs_rise_pending<=1'b0;
  end
  always @(posedge clk) if (pxl2_cen) begin
    if (hs_rise_pending) rdcnt<=0;
    else                 rdcnt<=rdcnt+1'b1;
  end

  // The read side emits the preceding complete line.  Delay true VBlank by
  // one line to match it; do not use combined blank here or the widened active
  // window would be clipped back to native width.
  reg vb_line, vb_active;
  initial begin vb_line=0; vb_active=0; end
  always @(posedge clk) if (hs_rise_in) begin
    vb_line<=vb_in;
    vb_active<=vb_line;
  end

  wire signed [AW+1:0] hoff_s =
      (HPOS_MODE == `HPOS_CONTENTSHIFT)
        ? {{(AW-7){hoffset[8]}},hoffset}
        : {(AW+2){1'b0}};
  wire signed [AW+1:0] rdcnt_s = $signed({2'b00,rdcnt});
  wire signed [AW+1:0] hb1_s   = $signed({2'b00,hb1});
  wire signed [AW+1:0] hb0_s   = $signed({2'b00,hb0});
  wire [AW-1:0] rd_addr = rdcnt_s - hoff_s;
  reg [23:0] rd_data;
  reg pass_q;
  initial begin rd_data=0; pass_q=0; end
  always @(posedge clk) if (pxl2_cen) begin
    rd_data <= mem[{~bank,rd_addr[BANK_AW-1:0]}];
    pass_q <= (rdcnt_s >= hb1_s+hoff_s) &&
              (rdcnt_s <  hb0_s+hoff_s) && !vb_active;
  end

  wire signed [9:0] voff_ext = {{4{voffset[5]}},voffset};
  wire signed [9:0] vshift_calc =
      voffset[5] ? $signed(VTOTAL_U) + voff_ext
                 : $signed({4'b0000,voffset});
  wire [8:0] vshift_tap = vshift_calc[8:0];
  reg [VTOTAL-1:0] vsync_line_shreg;
  reg vs_shifted;
  initial begin vsync_line_shreg=0; vs_shifted=0; end
  always @(posedge clk) if (hs_rise_in) begin
    vsync_line_shreg <= {vsync_line_shreg[VTOTAL-2:0],vs_in};
    vs_shifted <= (vshift_tap==0) ? vs_in
                                  : vsync_line_shreg[vshift_tap-1'b1];
  end

  wire hs_pos_out =
      (HPOS_MODE == `HPOS_SYNCSHIFT) ? hs_shifted : hs_in_q;
  wire bypass = ~active;
  initial begin
    r_out=0; g_out=0; b_out=0; hs_out=0; vs_out=0; hb_out=1; vb_out=0;
  end
  always @(posedge clk) begin
    if (bypass) begin
      if (pxl_cen) begin
        r_out<=r_in_q; g_out<=g_in_q; b_out<=b_in_q;
        hb_out<=hb_in_q; hs_out<=hs_in_q; vs_out<=vs_in_q; vb_out<=vb_in_q;
      end
    end else if (pxl2_cen) begin
      if (pass_q) begin
        r_out<=rd_data[23:16]; g_out<=rd_data[15:8]; b_out<=rd_data[7:0];
      end else begin
        r_out<=0; g_out<=0; b_out<=0;
      end
      hb_out<=~pass_q;
      hs_out<=hs_pos_out;
      vs_out<=vs_shifted;
      vb_out<=vb_in_q;
    end
  end

  // hsize is consumed by the documented external read-rate generator.  Keep
  // it in the interface so the module remains source-compatible upstream.
  wire _unused_hsize = &{1'b0,hsize};

endmodule
`default_nettype wire
