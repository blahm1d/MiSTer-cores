`default_nettype none
// =============================================================================
// zunit_iol_audit.sv — P0020/P0022 ioctl-download OBSERVABILITY tap.
//
// Pure OBSERVER of the ioctl-download FIFO in zunit_top (ZT_SDRAM_CHASSIS): it
// never drives the FIFO push/drain datapath, only counts what happens on it and
// latches the P0022 held-reset condition. Additive-only by construction — remove
// this module and the boot path is byte-identical.
//
//   accepted[31:0]  : # FIFO pushes that landed  (ioctl_wr while NOT full)
//   dropped[31:0]   : # FIFO pushes DROPPED       (ioctl_wr while FULL) — P0020
//                     signal; MUST stay 0 on healthy hps_io backpressure. Nonzero
//                     = the download outran the 512-deep FIFO -> ROM byte lost.
//   rst_during_dl   : sticky P0022 latch — set iff the core reset was HIGH while a
//                     ROM download was in flight. Lives in the `por` (sdram_por)
//                     domain, so it SURVIVES the core reset and answers "did a
//                     held-high RESET across ioctl_download freeze the capture
//                     path?" (§6 P0022). Cleared ONLY by true power-on (por).
//
// The accepted/dropped split is computed HERE from (ioctl_wr, iol_full) so the
// full-check itself is inside the unit under test (a drop-the-full-check mutant
// is caught by the unit TB, not hidden upstream). These counters must be 32-bit:
// NARC emits exactly 0x520000 writes, an exact multiple of 0x10000. The old
// 16-bit observer therefore wrapped to zero on every complete load and made the
// otherwise healthy DIAG_BOOT status bar and download pip permanently red.
// =============================================================================
module zunit_iol_audit (
  input  wire        clk,
  input  wire        por,            // sdram_por (P0022 persistent domain reset)
  input  wire        ioctl_wr,       // one strobe per offered download word
  input  wire        iol_full,       // FIFO full flag (push would drop)
  input  wire        ioctl_download,  // high across the whole ROM load
  input  wire        core_rst,       // core reset (active high) — the P0022 subject
  output reg  [31:0] accepted,
  output reg  [31:0] dropped,
  output reg         rst_during_dl
);
  wire push = ioctl_wr & ~iol_full;   // accepted push
  wire drop = ioctl_wr &  iol_full;   // dropped push (overflow)

  always_ff @(posedge clk) begin
    if (por) begin
      accepted      <= 32'd0;
      dropped       <= 32'd0;
      rst_during_dl <= 1'b0;
    end else begin
      if (push) accepted <= accepted + 32'd1;
      if (drop) dropped  <= dropped  + 32'd1;
      if (ioctl_download & core_rst) rst_during_dl <= 1'b1;  // P0022: sticky
    end
  end
endmodule
`default_nettype wire
