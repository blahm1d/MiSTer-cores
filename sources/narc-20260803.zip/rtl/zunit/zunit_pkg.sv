// zunit_pkg.sv — Williams Z-unit (NARC, 1988) delta constants vs the Y-unit
// donor (yunit_pkg.sv). This is ATTACK-PLAN §3 (donor-constant delta audit)
// made executable: every value below is cited to a primary source line.
//
// Citation keys:
//   midyunit.cpp / midyunit_v.cpp / midyunit_m.cpp / tms34010.h /
//   williamssound.cpp  = MAME 0.280 gospel vendored at
//                        D:\deck\fpga\NARC\mame-gospel\  (behavioral WHAT)
//   Z-UNIT.DOC         = Williams 1988 hardware spec,
//                        D:\deck\fpga\umk3\nba-hangtime\DOC\Z-UNIT.DOC
//   ATTACK-PLAN §n     = D:\deck\fpga\NARC\ATTACK-PLAN.md (secondary; rows
//                        there carry their own primary citations)
//
// DOCTRINE: MAME is the behavioral ground truth; where Z-UNIT.DOC documents
// bits MAME does not implement (watchdog, must-be-1), the bit positions are
// named here but flagged — implement MAME 0.280 semantics (risk R2).
//
// Address-unit convention: identical to yunit_pkg.sv — region bases are the
// TMS34010 *logical* (bit) addresses exactly as MAME's address_map presents
// them (midyunit.cpp:184-202).

`default_nettype none

package zunit_pkg;

  // =====================================================================
  // Clocks — delta: CLKIN 48 MHz (donor 40), dot clock 16 MHz (donor 8)
  // =====================================================================
  // FAST_MASTER_CLOCK = 48 MHz ("fast" == narc): midyunit.cpp:1239, fed to
  // TMS34010 at midyunit.cpp:1250.
  localparam int CLK_CLKIN_HZ    = 48_000_000;
  // Internal machine rate = CLKIN/8: tms34010.h:970 (execute_clocks_to_cycles).
  localparam int CLK_MACHINE_HZ  = CLK_CLKIN_HZ / 8;          // 6 MHz
  // MEDRES_PIXEL_CLOCK = 48 MHz / 6 = 8 MHz: midyunit.cpp:1245,1251.
  localparam int CLK_PIXEL_HZ    = 8_000_000;
  // 2 pixels per VCLK: set_pixels_per_clock(2), midyunit.cpp:1252.
  localparam int PIX_PER_CLOCK   = 2;
  // Effective dot clock = MEDRES_PIXEL_CLOCK*2 = 16 MHz: midyunit.cpp:1265.
  localparam int CLK_DOT_HZ      = 16_000_000;
  // MiSTer realization (M1 CLOSED, docs/M1-CE-MEASUREMENT.md): keep donor
  // clk_sys = 96 MHz; 96/6 = 16 MHz dot exact; cpu_ce = /4 = 24 MHz with the
  // donor 4:1 multicycle (P0019 clocking retained).
  localparam int CLK_SYS_HZ      = 96_000_000;

  // =====================================================================
  // Screen timing — delta: 512x400 visible, 674x433 raw (donor 410x256)
  // =====================================================================
  // screen.set_raw(MEDRES_PIXEL_CLOCK*2, 674, 122, 634, 433, 27, 427):
  // midyunit.cpp:1265 (args: dotclk, htotal, hbend, hbstart, vtotal, vbend,
  // vbstart). Refresh = 16 MHz / (674*433) = 54.82 Hz (derived).
  localparam int SCR_H_TOTAL   = 674;
  localparam int SCR_H_VIS_ST  = 122;  // hblank end   (first visible dot)
  localparam int SCR_H_VIS_EN  = 634;  // hblank start (one past last visible)
  localparam int SCR_V_TOTAL   = 433;
  localparam int SCR_V_VIS_ST  = 27;   // vblank end
  localparam int SCR_V_VIS_EN  = 427;  // vblank start
  localparam int SCR_VIS_W     = SCR_H_VIS_EN - SCR_H_VIS_ST; // 512
  localparam int SCR_VIS_H     = SCR_V_VIS_EN - SCR_V_VIS_ST; // 400

  // =====================================================================
  // Pixel depth / pen map — delta: 8bpp, 8192 pens (donor 6bpp/4096)
  // =====================================================================
  // midzunit_state::video_start "init for 8-bit": pen_map[i] = i & 0x1fff,
  // palette_mask = 0x1fff — midyunit_v.cpp:102-105.
  localparam logic [15:0] PALETTE_MASK_8BIT = 16'h1FFF;
  // PALETTE(...).set_entries(8192): midyunit.cpp:1260.
  localparam int          PEN_COUNT         = 8192;
  // Scanline fetch: dest[x] = pen_map[src[coladdr++ & 0x1ff]] with
  // src = vram[(rowaddr<<9) & 0x3fe00] — midyunit_v.cpp:545-551 (shared
  // with donor; 16-bit VRAM word = {palette-high byte, 8-bit pixel}).
  function automatic logic [12:0] pen_map8(input logic [15:0] w);
    pen_map8 = w[12:0]; // i & 0x1fff, midyunit_v.cpp:104
  endfunction

  // Palette word format (shared with donor): xRGB-1555 —
  // set_pen_color(pal5bit(w>>10) R, pal5bit(w>>5) G, pal5bit(w>>0) B),
  // midyunit_v.cpp:251. Palette RAM window 0x01800000-0x0181FFFF holds
  // 8192 x 16-bit entries (midyunit.cpp:189).

  // =====================================================================
  // Frame-buffer geometry (shared with donor — midyunit_v.cpp scanline/DMA)
  // =====================================================================
  localparam int FB_W        = 512;
  localparam int FB_H        = 512;
  localparam int FB_ADDR_W   = 18;   // 512*512 words
  localparam int FB_ROWSHIFT = 9;    // rowaddr<<9, midyunit_v.cpp:545

  // =====================================================================
  // Main-board memory map (34010 logical, midyunit.cpp:184-202 main_map +
  // zunit_main_map at :198-202; Z-UNIT.DOC:33-72 agrees on every base)
  // =====================================================================
  localparam logic [31:0] ZMAP_VRAM_BASE     = 32'h0000_0000; // :186  0x00000000-0x001FFFFF vram_r/w
  localparam logic [31:0] ZMAP_RAM_BASE      = 32'h0100_0000; // :187  0x01000000-0x010FFFFF mainram (128 KB)
  localparam logic [31:0] ZMAP_CMOS_BASE     = 32'h0140_0000; // :188  0x01400000-0x0140FFFF cmos_r/w (paged, below)
  localparam logic [31:0] ZMAP_PAL_BASE      = 32'h0180_0000; // :189  0x01800000-0x0181FFFF paletteram
  localparam logic [31:0] ZMAP_DMA_BASE      = 32'h01A0_0000; // :190  0x01A00000-0x01A0009F dma_r/dma_w
  // DMA regs are MIRRORED at +0x00080000 (.mirror(0x00080000),
  // midyunit.cpp:190) — i.e. alias 0x01A80000-0x01A8009F. The game code
  // uses the 01A8xxxx alias, DIAG uses 01A0xxxx (ATTACK-PLAN §1, SYS.INC).
  // Decode MUST ignore logical-address bit 19.
  localparam logic [31:0] ZMAP_DMA_MIRROR    = 32'h01A8_0000;
  localparam logic [31:0] ZMAP_DMA_MIRROR_BIT= 32'h0008_0000; // the don't-care bit
  localparam logic [31:0] ZMAP_INPUT_BASE    = 32'h01C0_0000; // :191  0x01C00000-0x01C0005F input_r
  localparam logic [31:0] ZMAP_PROT_BASE     = 32'h01C0_0060; // :192  0x01C00060-0x01C0007F protection_r/cmos_enable_w
                                                              //       (narc has NO protection — reads unused;
                                                              //        cmos_enable_w: w-enable = BIT(~data,9),
                                                              //        midyunit_m.cpp:60)
  localparam logic [31:0] ZMAP_SOUND_BASE    = 32'h01E0_0000; // :201  0x01E00000-0x01E0001F narc_sound_w (Z-unit
                                                              //       delta — donor Y latch lived elsewhere)
  localparam logic [31:0] ZMAP_CTRL_BASE     = 32'h01F0_0000; // :193  0x01F00000-0x01F0001F control_w
  localparam logic [31:0] ZMAP_GFX_BASE      = 32'h0200_0000; // :194  0x02000000-0x05FFFFFF gfxrom_r (flat, no banking)
  localparam logic [31:0] ZMAP_MAINDATA_BASE = 32'hFF80_0000; // :195  0xFF800000-0xFFFFFFFF program ROM

  // =====================================================================
  // System control register (01F00000, control_w) — delta: D8-15 LED,
  // D6-7 CMOS page, D5 videobank, D4 /autoerase (donor Y layout differs)
  // =====================================================================
  // MAME implements ONLY bits 4-7 (midyunit_v.cpp:226-236, ACCESSING_BITS_0_7
  // guard at :226). Z-unit bit chart: midyunit_v.cpp:192-209 comment +
  // Z-UNIT.DOC:97-115.
  localparam int CTRL_LED_HI       = 15; // [15:8] 7-seg LED, active low
  localparam int CTRL_LED_LO       = 8;  //   (midyunit_v.cpp:198 "xxxxxxxx--------",
                                         //    Z-UNIT.DOC:100-104; MAME ignores)
  localparam int CTRL_CMOS_PAGE_HI = 7;  // [7:6] CMOS page: m_cmos_page =
  localparam int CTRL_CMOS_PAGE_LO = 6;  //   BIT(data,6,2)*0x1000 (words) —
                                         //   midyunit_v.cpp:229. NOTE (R2):
                                         //   Z-UNIT.DOC:107-108 calls D7/D6
                                         //   "Must Always =1"; MAME (via the
                                         //   /SPK.0-1 EP800 note, v.cpp:202)
                                         //   pages CMOS with them. Implement
                                         //   MAME 0.280.
  localparam int CTRL_VIDEOBANK_N  = 5;  // /OBJ PAL RAM select: videobank_select
                                         //   = BIT(data,5) — midyunit_v.cpp:232;
                                         //   Z-UNIT.DOC:109 "Obj Pal EN=0"
  localparam int CTRL_AUTOERASE_N  = 4;  // /autoerase: enable = BIT(~data,4)
                                         //   (active LOW) — midyunit_v.cpp:235;
                                         //   Z-UNIT.DOC:110 "AutoErase EN=0"
  // Bits 3-2 "Must Always =1", bits 1-0 watchdog data/clk: Z-UNIT.DOC:111-114.
  // MAME 0.280 does NOT implement them (risk R2: trace the game's SYSCTRL
  // writes to confirm dead). Named only — do not wire without measurement.
  localparam int CTRL_MUSTBE1_HI   = 3;
  localparam int CTRL_MUSTBE1_LO   = 2;
  localparam int CTRL_WD_DAT       = 1;
  localparam int CTRL_WD_CLK       = 0;

  // =====================================================================
  // CMOS — delta: 32 KB total, 4 x 8 KB pages via ctrl D6-7 (donor unpaged)
  // =====================================================================
  // Window 0x01400000-0x0140FFFF = 8 KB visible page (midyunit.cpp:188);
  // access = cmos_ram[offset + cmos_page] (midyunit_m.cpp:41,47) with
  // cmos_page in 16-bit WORDS stepping 0x1000 (= 8 KB) per page
  // (midyunit_v.cpp:229). 4 pages x 8 KB = 32 KB backing store.
  localparam int CMOS_PAGE_BYTES    = 8192;
  localparam int CMOS_NPAGES        = 4;
  localparam int CMOS_TOTAL_BYTES   = CMOS_PAGE_BYTES * CMOS_NPAGES; // 32768
  localparam int CMOS_PAGE_STRIDE_W = 'h1000; // 16-bit words per page, midyunit_v.cpp:229

  // =====================================================================
  // Sound latch (01E00000, narc_sound_w) — Z-unit delta, NET-NEW board
  // =====================================================================
  // Host write path: 16-bit word writes only (both byte lanes must be
  // active, midyunit_m.cpp:636-651); offset!=0 writes are logged+dropped.
  // Latch semantics (williams_narc_sound_device::write williamssound.cpp:
  // 307-310 -> sync_master_command williamssound.cpp:598-607):
  localparam int SND_DATA_HI    = 7;  // [7:0] command byte -> master latch
  localparam int SND_DATA_LO    = 0;  //   (param & 0xff, williamssound.cpp:600)
  localparam int SND_NMI_N_BIT  = 8;  // D8 LOW asserts master 6809 NMI, HIGH
                                      //   clears (param & 0x100 ? CLEAR :
                                      //   ASSERT, williamssound.cpp:601)
  localparam int SND_IRQ_N_BIT  = 9;  // D9 LOW asserts master 6809 IRQ
                                      //   ((param & 0x200)==0, williamssound.cpp:602-606)
  localparam int SND_RESET_N_BIT= 10; // D10 LOW = board reset per game-source
                                      //   protocol (0xFB00 then 0xFFFF —
                                      //   ATTACK-PLAN §1, SYS/GSPSND.ASM).
                                      //   NOTE: MAME 0.280 does NOT wire this
                                      //   bit (reset_write williamssound.cpp:317
                                      //   has no zunit caller; sync_master_command
                                      //   examines only 0x100/0x200). TODO(G4):
                                      //   two-sided check before implementing.
  // Talkback readback: host read = talkback | (audio_sync << 8)
  // (williamssound.cpp:295-299); wired to IN1 bit 10 (sync strobe,
  // midyunit.cpp:161) and IN2 [7:0] (talkback byte, midyunit.cpp:167).
  // audio_sync bits self-clear after a 74LS123 one-shot of
  // TIME_OF_74LS123(180000 ohm, 1 uF) ~ 81 ms (williamssound.cpp:415,439).

  // =====================================================================
  // Sound board clocks (NET-NEW dual-6809 board; chips AS-IS per §2)
  // =====================================================================
  localparam int SND_MASTER_CLOCK_HZ = 8_000_000; // NARC_MASTER_CLOCK, williamssound.cpp:46
  localparam int SND_6809_E_HZ       = SND_MASTER_CLOCK_HZ / 4; // 2 MHz E — MC6809E x2,
                                                  // williamssound.cpp:512-516
  localparam int SND_YM2151_HZ       = 3_579_545; // NARC_FM_CLOCK, williamssound.cpp:47,518
                                                  // (YM2151 IRQ -> master FIRQ, :519)
  // Hidden RAM overlay on the MASTER 6809 fixed-ROM region: 0xCDFF-0xCE29
  // (install_hidden_ram, midyunit_m.cpp:335 in init_narc).
  localparam logic [15:0] SND_HIDDEN_RAM_LO = 16'hCDFF;
  localparam logic [15:0] SND_HIDDEN_RAM_HI = 16'hCE29;
  // Bank select (both CPUs): D0->A15, D1-2 chip select, D3->A16 —
  // offset = 0x8000*(b&1) + 0x10000*((b>>3)&1) + 0x20000*((b>>1)&3),
  // williamssound.cpp:533-547 (master), :549-561 (slave).

  // =====================================================================
  // DMA blitter (Rev-1, 10 regs — SHARED engine with donor, same indices:
  // midyunit_v.cpp:22-34; ATTACK-PLAN §3 "identical indices" row verified
  // index-by-index against the donor yunit_pkg.sv values)
  // =====================================================================
  localparam logic [3:0] DMA_COMMAND  = 4'd0; // midyunit_v.cpp:24; Z-UNIT.DOC:60
  localparam logic [3:0] DMA_ROWBYTES = 4'd1; // :25; DOC:59 "OFFSET REGISTER"
  localparam logic [3:0] DMA_OFFSETLO = 4'd2; // :26; DOC:58 source LSW
  localparam logic [3:0] DMA_OFFSETHI = 4'd3; // :27; DOC:57 source MSW
  localparam logic [3:0] DMA_XSTART   = 4'd4; // :28; DOC:56 dest X
  localparam logic [3:0] DMA_YSTART   = 4'd5; // :29; DOC:55 dest Y
  localparam logic [3:0] DMA_WIDTH    = 4'd6; // :30; DOC:54 horizontal size
  localparam logic [3:0] DMA_HEIGHT   = 4'd7; // :31; DOC:53 vertical size
  localparam logic [3:0] DMA_PALETTE  = 4'd8; // :32; DOC:52 object palette
  localparam logic [3:0] DMA_COLOR    = 4'd9; // :33; DOC:51 constant
  localparam int         DMA_NREGS    = 16;   // reg file size; only 0-9 used

  // COMMAND register bits (dma_w, midyunit_v.cpp:427-523 + Z-UNIT.DOC:77-94):
  localparam int DMA_CMD_TRIG_BIT  = 15; // GO / busy; cleared on completion
                                         // (&= ~0x8000, midyunit_v.cpp:372);
                                         // Z-UNIT.DOC:85 "DMA GO (READ/WRITE)"
  localparam int DMA_CMD_FLIPY_BIT = 5;  // vertical flip (MAME bit5;
                                         // = Z-UNIT.DOC:89 "Flip About X Axis")
  localparam int DMA_CMD_FLIPX_BIT = 4;  // horizontal flip (command & 0x10,
                                         // midyunit_v.cpp:466; = Z-UNIT.DOC:90
                                         // "Flip About Y Axis")
  // [3:0] = draw mode (16 cases: zero/nonzero source x constant/copy —
  // Z-UNIT.DOC:91-94 bit names; per-mode behavior = dma_draw,
  // midyunit_v.cpp:262-360). Z-UNIT.DOC:87-88 additionally documents bit7
  // "Enable X Cycle" and bit6 "Enable Internal ROM" — MAME 0.280 ignores
  // both (ATTACK-PLAN §3: verify the game never sets them; do not wire).
  localparam int DMA_CMD_MODE_HI   = 3;
  localparam int DMA_CMD_MODE_LO   = 0;

  // dma_w start-of-blit fixups (midyunit_v.cpp:456-517) — shared with donor:
  //   palette = reg[DMA_PALETTE] << 8            (:461)
  //   color   = reg[DMA_COLOR] & 0xff            (:462)
  //   non-flip:  rowbytes = (rb + w + 3) & ~3    (:478)
  //   flip-X:    gfxoffset -= (w-1)*8; rowbytes = (rb - w + 3) & ~3 (:470-471)
  //   clip to 0..511 both axes                   (:481-512)
  //   gfxoffset < 0x02000000 -> += 0x02000000, then offset = gfx - 0x02000000 (:515-519)
  localparam int DMA_CLIP_MAX = 511; // midyunit_v.cpp:487,499,506-508

  // Completion: timer 41 ns * width * height (midyunit_v.cpp:523), then
  // DMA_COMMAND bit15 clears and CPU external interrupt line 0 asserts
  // (dma_callback, midyunit_v.cpp:370-374; donor wired this as LINT1).
  localparam int DMA_NS_PER_PIXEL = 41;

  // =====================================================================
  // Videobank (ctrl D5) VRAM access planes — midyunit_v.cpp:134-161
  // =====================================================================
  // videobank_select = 1: CPU writes pixel byte + DMA_PALETTE reg into the
  //   high byte lane — vram[o] = (data & 0x00ff) | (DMA_PALETTE << 8);
  //   vram[o+1] = (data >> 8) | (DMA_PALETTE & 0xff00)   (:137-143)
  //   reads return the pixel-byte plane packed (vram_r :154, :157-158)
  // videobank_select = 0: access hits the palette-high ("OBJ PAL RAM")
  //   plane — vram[o] = (vram[o] & 0x00ff) | (data << 8) (:144-150);
  //   reads return the palette-plane bytes packed (:159-160)

  // =====================================================================
  // Autoerase (ctrl D4) — midyunit_v.cpp:534-559 (shared engine, Z rows)
  // =====================================================================
  // After each displayed line, row 510+(scanline&1) is copied over rows
  // 0..509: memcpy(&vram[512*scanline], &vram[512*(510+(scanline&1))]),
  // guarded scanline < 510 (midyunit_v.cpp:538-540). Trigger: scanline_update
  // erases the PREVIOUS line (:554), final line via timer (:557-559).
  localparam int AUTOERASE_TEMPLATE_ROW = 510; // + (scanline & 1)
  localparam int AUTOERASE_LAST_ROW     = 509; // rows 510/511 are templates

  // =====================================================================
  // GFX ROM — delta: flat 8 MB window, 60 byte-ROMs, 4-way quadrant
  // interleave (donor: 9 planar ROMs, banked window)
  // =====================================================================
  // Window 0x02000000-0x05FFFFFF, plain gfxrom_r, NO banking (midyunit.cpp:194).
  // ROM region 0x800000 bytes (midyunit.cpp:1473); narc populates 60 x 64 KB
  // = 3.75 MB (loads midyunit.cpp:1474-1539: U94->U80, U76->U62, U58->U44,
  // U40->U26 quadrant blocks of 15).
  localparam int GFX_REGION_BYTES    = 'h80_0000;  // 8 MB model
  localparam int GFX_POPULATED_BYTES = 'h3C_0000;  // 3.75 MB (60 x 0x10000)
  localparam int GFX_NROMS           = 60;
  localparam int GFX_ROM_BYTES       = 'h1_0000;   // 27C512-class 64 KB each
  // init_narc -> init_gfxrom(8) (midyunit_m.cpp:334): 4-way byte interleave,
  // quadrant chunk = region/4; out[i+q] = base[q*chunk + i/4] for q=0..3
  // (midyunit_m.cpp:284-292) — each quadrant supplies every 4th output byte.
  localparam int GFX_QUADRANTS       = 4;
  localparam int GFX_QUAD_CHUNK      = GFX_REGION_BYTES / 4; // 0x200000

  // =====================================================================
  // Program ROM — delta: 512 KB populated (donor 2 x 512 Kbit)
  // =====================================================================
  // maindata region 0x100000 bytes, 16-bit LE (midyunit.cpp:1466); rev 7.00
  // populates 4 x 27C010 (0x20000 each) as LOAD16_BYTE pairs U42/U24 at
  // region +0x80000 and U41/U23 at +0xC0000 (midyunit.cpp:1467-1470) —
  // i.e. upper 512 KB of the 0xFF800000 window => code lives at
  // 0xFFC00000+ with reset vectors at top (ATTACK-PLAN §1).
  localparam int          PROG_REGION_BYTES    = 'h10_0000;
  localparam int          PROG_POPULATED_BYTES = 'h8_0000;    // 512 KB
  localparam logic [31:0] PROG_POPULATED_BASE  = 32'hFFC0_0000;

  // =====================================================================
  // SDRAM word-address map — Phase-6 emu integration (yunit_sdram_arb on
  // the single MT48LC16M16 16-bit word port). NOT a donor value: the donor
  // bases (yunit_top GFXW/ROMW/VRAMW) were sized for Smash T.V.'s 6bpp
  // planar gfx (0x180000 B) + 256 KB program. Here every base is DERIVED
  // from the NARC populated geometry above (ATTACK-PLAN §4 SDRAM partition:
  // gfx ROM + program ROM live in SDRAM; VRAM in SDRAM for this slice, DDR3
  // is the deferred M2 lane). Compact ascending layout, no overlap:
  //   gfx words @ 0 .. GFX_WORDS
  //   program ROM @ ROMW_BASE .. +PROG_WORDS
  //   VRAM @ VRAMW_BASE .. +VRAM_WORDS  (512x512 word framebuffer)
  // GFX_BYTES is the gfx/ROM split used by both the arbiter and zunit_mem's
  // SDRAM_ROMB. Both are sourced here from GFX_POPULATED_BYTES.
  // =====================================================================
  localparam int          SDRAM_AW         = 25;                    // MT48LC16M16 word addr (donor SD_AW)
  localparam int          SDRAM_GFX_WORDS  = GFX_POPULATED_BYTES  >> 1; // 0x1E0000 (3.75 MB / 2)
  localparam int          SDRAM_PROG_WORDS = PROG_POPULATED_BYTES >> 1; // 0x040000 (512 KB / 2)
  localparam int          SDRAM_VRAM_WORDS = FB_W * FB_H;               // 0x040000 (512x512 words)
  localparam logic [SDRAM_AW-1:0] SDRAM_GFXW_BASE  = '0;                            // gfx @ 0
  localparam logic [SDRAM_AW-1:0] SDRAM_ROMW_BASE  = SDRAM_AW'(SDRAM_GFX_WORDS);    // 0x1E0000
  localparam logic [SDRAM_AW-1:0] SDRAM_VRAMW_BASE = SDRAM_AW'(SDRAM_GFX_WORDS + SDRAM_PROG_WORDS); // 0x220000
  localparam logic [23:0]         SDRAM_GFX_BYTES  = 24'(GFX_POPULATED_BYTES);      // 0x3C0000 (= zunit_mem SDRAM_ROMB)

  // ---- D1 RESOLVED: the dual-6809 sound ROMs live in SDRAM, above VRAM --------
  // Each 6809 has its own 0x90000-byte image (narc_sound_bank tops out at exactly
  // 0x8C000 + 0x4000 = 0x90000; the MRA lays out master @stream 0x880000 and slave
  // @stream 0x910000, each 0x90000 "incl reloads"). Master first, then slave, so a
  // CPU's word address is SNDW_BASE + cpu*SND_IMAGE_WORDS + (rom_offset>>1).
  // BRAM was never an option here: 2 x 576 KB = 1.125 MB against a ~5.5 Mbit M10K
  // budget already at ~93%.
  localparam int          SND_IMAGE_BYTES  = 32'h09_0000;               // per-6809 image (MRA region size)
  localparam int          SND_IMAGE_WORDS  = SND_IMAGE_BYTES >> 1;      // 0x048000
  localparam logic [SDRAM_AW-1:0] SDRAM_SNDW_BASE  =
      SDRAM_AW'(SDRAM_GFX_WORDS + SDRAM_PROG_WORDS + SDRAM_VRAM_WORDS); // 0x260000 (after VRAM)
  // Stream (ioctl byte) bounds of the two sound regions, per the MRA layout.
  localparam logic [24:0] SND_STREAM_BASE  = 25'h88_0000;               // master image start
  localparam logic [24:0] SND_STREAM_END   = 25'h9A_0000;               // slave image end (PLA follows)

endpackage

`default_nettype wire
