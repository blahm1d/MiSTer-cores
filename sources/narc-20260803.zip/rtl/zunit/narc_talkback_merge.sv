// narc_talkback_merge.sv — P0032 (SPEC section 28.2): merge the NARC sound
// board's talkback readback into the main-CPU input ports.
//
// Gospel (MAME 0.280 midyunit.cpp): the host reads the sound board through
// input-port CUSTOM fields —
//   IN1 bit 10 (ACTIVE_HIGH)  = narc_talkback_strobe_r = BIT(read(), 8)
//                               = audio_sync bit 0            (:289, :159-162)
//   IN2 bits 7:0 (ACTIVE_HIGH)= narc_talkback_data_r  = read() & 0xff
//                               = the talkback latch          (:305, :165-168)
// where read() = m_talkback | (m_audio_sync << 8) (williamssound.cpp:296-299),
// exactly the narc_sound_board `talkback_rd` port.
//
// v8a shipped with talkback_rd UNCONNECTED (cabinet-rejected build): the game
// read harness constants in those bits. Every other bit stays the external
// harness's (active-low switch matrix, DSW).
//
// `inputs` packing (zunit_top/zunit_memsys contract): {DSW, IN2, IN1, IN0}.

`default_nettype none

module narc_talkback_merge (
  input  wire [63:0] inputs_ext,    // {DSW, IN2, IN1, IN0} from the emu harness
  input  wire [15:0] talkback_rd,   // narc_sound_board read(): talkback | (audio_sync<<8)
  output wire [63:0] inputs_merged
);

`ifdef MUT_TB_PASSTHRU
  // MUTATION (sim-only, must die in tb_narc_talkback_merge): the rejected v8a
  // behavior — talkback ignored, harness constants pass through.
  assign inputs_merged = inputs_ext;
`else
  assign inputs_merged = {
      inputs_ext[63:48],                                    // DSW: untouched
      inputs_ext[47:40], talkback_rd[7:0],                  // IN2[7:0] = talkback data
      inputs_ext[31:27], talkback_rd[8], inputs_ext[25:16], // IN1[10]  = talkback strobe
      inputs_ext[15:0]                                      // IN0: untouched
  };
`endif

endmodule

`default_nettype wire
