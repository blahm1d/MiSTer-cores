`default_nettype none
// =============================================================================
// zunit_download.sv — NARC "Narc (rev 7.00).mra" ioctl-download demux.
//
// Replaces the donor Smash-T.V. plane/romlo/romhi FSM. Takes the single linear
// hps_io byte stream (rom index 0) whose region layout is fixed by the MRA
// (releases/Narc (rev 7.00).mra, mirrored in validate_narc_mra.py; gospel
// midyunit.cpp:1449-1548) and emits 16-bit SDRAM word writes for the two
// SDRAM-resident regions only:
//
//   PROGRAM  [0x000000, 0x080000)  512 KB, 34010 code (rev 7.00).
//     The MRA already <interleave output="16">s the LOAD16_BYTE pairs, so the
//     stream is final little-endian: even byte = low lane, odd byte = high lane.
//     Pack 2 consecutive bytes -> one word @ ROMW_BASE + (addr>>1), be=11.
//
//   GFX      [0x080000, 0x880000)  8 MB raw ROM_REGION (midyunit.cpp:1473).
//     Four 0x200000 quadrants, each 15x64KB descending + 0-gap to 0x200000
//     (MRA <part repeat="0x110000">00). On-chip init_gfxrom(8) de-interleave
//     (midyunit_m.cpp:284-292): flat[4k+q] = raw[q*0x200000 + k], i.e. each
//     quadrant q supplies every 4th flat byte. flat byte f lives at SDRAM
//     byte f -> word GFXW_BASE + (f>>1), lane f&1.  For a raw byte at
//     raw_off = addr-0x080000, q=raw_off[22:21], k=raw_off[20:0]:
//        f = 4k+q  ->  word = GFXW_BASE + 2k + q[1],  lane = q[0].
//     Only the POPULATED bytes (k < 0x0F0000 in each quadrant) are stored: they
//     de-interleave to the contiguous flat block [0, 0x3C0000) = words
//     [0, 0x1E0000) = exactly SDRAM_GFX_WORDS. The 0-gap bytes (k >= 0x0F0000)
//     de-interleave to flat >= 0x3C0000, which would spill PAST the gfx SDRAM
//     allocation and overwrite the program-ROM region at ROMW_BASE=0x1E0000 —
//     so they are DROPPED (correct: MAME's flat gfx is 0 there, and our gfx
//     window is only the 3.75 MB populated span).
//
//   SOUND    [0x880000, 0x9A0000)  D1 RESOLVED -> SDRAM @SNDW_BASE (above VRAM).
//     Two 0x90000-byte 6809 images back to back (master then slave), byte-linear
//     with no de-interleave: stream byte b -> word SNDW_BASE + (b-0x880000)>>1,
//     lane b&1. The 6809s read BYTES, so this region is written byte-lane-wise
//     exactly like gfx rather than packed LE16 like the 34010 program ROM.
//
//   PLA      [0x9A0000, 0x9A0500)  unrouted (not modelled).
//
// HW-FIT (architect ratified): the de-interleave is a trivial combinational
// index remap in the download FSM on clk_sys (NOT the core path) driving
// byte-lane SDRAM writes — zero BRAM, no read/rewrite pass. Keeps the MRA a
// faithful transcription of the MAME raw ROM_REGION quadrants.
// =============================================================================
import zunit_pkg::*;
module zunit_download #(
  parameter logic [24:0] ROMW_BASE = 25'(SDRAM_ROMW_BASE),  // 0x1E0000 (program ROM word base)
  parameter logic [24:0] GFXW_BASE = 25'(SDRAM_GFXW_BASE),  // 0x000000 (flat gfx word base)
  parameter logic [24:0] SNDW_BASE = 25'(SDRAM_SNDW_BASE)   // 0x260000 (dual-6809 sound images)
)(
  input  wire        clk,
  input  wire        dl_en,        // ioctl_download & (ioctl_index == 0)
  input  wire        ioctl_wr,     // one strobe per downloaded byte
  input  wire [24:0] ioctl_addr,   // running byte offset in the download stream
  input  wire [7:0]  ioctl_dout,   // the downloaded byte

  output reg         sd_wr,        // SDRAM word-write strobe (1-cycle)
  output reg  [24:0] sd_addr,      // SDRAM word address
  output reg  [15:0] sd_dout,      // SDRAM word data
  output reg  [1:0]  sd_be         // byte enables {high, low}
);
  // ---- MRA region boundaries (byte offsets in the concatenated stream) --------
  localparam logic [24:0] PROG_END     = 25'h08_0000;         // 0x080000 (512 KB)
  localparam logic [24:0] GFX_END      = 25'h88_0000;          // 0x080000 + 0x800000
  localparam logic [24:0] GFX_QUAD_POP = 25'h0F_0000;          // 15 x 64 KB populated / quadrant

  wire is_prog = (ioctl_addr <  PROG_END);
  wire is_gfx  = (ioctl_addr >= PROG_END) && (ioctl_addr < GFX_END);
  wire is_snd  = (ioctl_addr >= SND_STREAM_BASE) && (ioctl_addr < SND_STREAM_END);

  // ---- PROGRAM: stream already LE16 -> pack 2 bytes/word ----------------------
  wire [24:0] prog_word = ROMW_BASE + {1'b0, ioctl_addr[24:1]};

  // ---- GFX: init_gfxrom(8) de-interleave -------------------------------------
  wire [24:0] raw_off  = ioctl_addr - PROG_END;
  wire [1:0]  gq       = raw_off[22:21];        // quadrant 0..3
  wire [20:0] gk       = raw_off[20:0];         // offset within quadrant
  wire        gfx_pop  = (gk < GFX_QUAD_POP);   // real byte (drop the 0-gap tail)
  wire [24:0] gfx_word = GFXW_BASE + {3'b0, gk, 1'b0} + {24'b0, gq[1]}; // 2k + q>>1

  // ---- SOUND: byte-linear, master image then slave image ---------------------
  wire [24:0] snd_off  = ioctl_addr - SND_STREAM_BASE;
  wire [24:0] snd_word = SNDW_BASE + {1'b0, snd_off[24:1]};

  reg [7:0] prog_lo;
  always @(posedge clk) begin
    sd_wr <= 1'b0;
    if (dl_en & ioctl_wr) begin
      if (is_prog) begin
        if (~ioctl_addr[0]) begin
          prog_lo <= ioctl_dout;                        // even byte -> low-lane latch
        end else begin                                  // odd byte -> emit LE16 word
          sd_addr <= prog_word;
          sd_dout <= {ioctl_dout, prog_lo};
          sd_be   <= 2'b11;
          sd_wr   <= 1'b1;
        end
      end else if (is_gfx & gfx_pop) begin
        sd_addr <= gfx_word;
        sd_be   <= gq[0] ? 2'b10 : 2'b01;               // odd flat index -> high lane
        sd_dout <= gq[0] ? {ioctl_dout, 8'h00} : {8'h00, ioctl_dout};
        sd_wr   <= 1'b1;
      end else if (is_snd) begin
        sd_addr <= snd_word;
        sd_be   <= snd_off[0] ? 2'b10 : 2'b01;          // odd byte -> high lane
        sd_dout <= snd_off[0] ? {ioctl_dout, 8'h00} : {8'h00, ioctl_dout};
        sd_wr   <= 1'b1;
      end
      // else: PLA region -> unrouted, or a gfx 0-gap byte -> dropped.
    end
  end
endmodule
`default_nettype wire
