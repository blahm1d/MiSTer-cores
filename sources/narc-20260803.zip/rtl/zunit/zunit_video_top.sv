// zunit_video_top.sv — Williams Z-unit (NARC, 1988) 8bpp scanout READ lane.
//
// Net-new top that wraps the FROZEN zunit_video back-end (pen_map8 + palette +
// RGB888 expand, proven bit-exact by sim/zunit_video_scenes) with:
//   * a 512x400-visible / 674x433-raw raster + timing generator (16 MHz dot),
//   * a VRAM address generator ((DISP_ROW0+row)<<9 | col), and
//   * the generic yunit_scanline double-buffered line-fetch (reused AS-IS,
//     retuned only via NCOL=512 for the wider Z-unit rows) over the SDRAM
//     scan_* read channel.
// CPU palette writes are routed straight through to zunit_video.pal_we.
//
// Citations (MAME 0.280 gospel, D:\deck\fpga\NARC\mame-gospel):
//   * Raster: screen.set_raw(MEDRES_PIXEL_CLOCK*2, 674,122,634, 433,27,427)
//     midyunit.cpp:1265 -> htotal 674, hblank end/first-visible 122, hblank
//     start 634 (=> 512 visible cols); vtotal 433, vblank end 27, vblank
//     start 427 (=> 400 visible lines). Refresh 16e6/(674*433)=54.82 Hz.
//     Encoded in zunit_pkg (SCR_* constants) — used as defaults here.
//   * Scanline unpack src = vram[(rowaddr<<9)&0x3fe00], coladdr++ & 0x1ff
//     midyunit_v.cpp:545-551 -> vram_raddr = (row<<9)|col, 512 cols/row.
//   * vblank_irq: 34010 ext-int line 0 fires entering vblank (dma_callback /
//     display-int shared engine) — a 1-clk pulse at the active->blank edge.
//
// HW-FIT (architect ratification, ATTACK-PLAN §4 / M2 2x-scanout read lane):
//   RATIFIED — reuse yunit_scanline's proven double-buffered line-fetch
//   (clocked BRAM line buffers, NO async multi-read window); it is generic on
//   FB_ADDR_W/NCOL and needs only NCOL=512 for the 512-entry Z-unit rows. The
//   2x scanout (16 MHz dot vs the donor 8 MHz) is absorbed by the pixel-clock
//   enable (ce_pix), not a structural change. The fb burst-WRITE lane (bwr_*
//   forward-port) is a SEPARATE later slice — not this read path.
//
// Latency: vram_raddr (comb) -> vram_rdata (+1 ce_pix, scanline) ->
//   zunit_video (+3 clk) -> rgb. pix_valid is aligned to vram_rdata; the TB
//   captures the active-pixel stream on rgb_valid (order-preserving).

`default_nettype none

module zunit_video_top
  import zunit_pkg::*;
#(
  // Raster geometry — defaults from zunit_pkg (midyunit.cpp:1265 set_raw).
  parameter int H_TOTAL   = SCR_H_TOTAL,   // 674
  parameter int H_VIS_ST  = SCR_H_VIS_ST,  // 122 (first visible dot)
  parameter int H_VIS_EN  = SCR_H_VIS_EN,  // 634 (one past last visible)
  parameter int V_TOTAL   = SCR_V_TOTAL,   // 433
  parameter int V_VIS_ST  = SCR_V_VIS_ST,  // 27
  parameter int V_VIS_EN  = SCR_V_VIS_EN,  // 427
  // Sync widths (front porch then sync); absolute placement only affects HW
  // scanout, not the visible-region pixel compare. Donor-style porch split.
  parameter int H_FP      = 8,
  parameter int H_SYNC    = 40,
  parameter int V_FP      = 2,
  parameter int V_SYNC    = 4,
  parameter int DISP_ROW0 = 0,             // first displayed VRAM row (DPYSTRT)
  parameter int NCOL      = 512,           // entries/row prefetched (= visible cols)
  // 8bpp Z-unit pen mask (midyunit_v.cpp:104). Donor 6bpp mutant = 13'h0FFF.
  parameter logic [12:0] PEN_MASK = 13'h1FFF
)(
  input  wire        clk,
  input  wire        rst,
  input  wire        ce_pix,               // 1-clk-wide pixel-clock enable (16 MHz dot)

  // P0031 (SPEC section 28.1): live DPYSTRT from the 34010 io regs. Latched
  // once per frame at the entering-vblank boundary; the whole next frame
  // (priming + scanout) uses the latched base, so a mid-frame game write can
  // never tear the raster. NARC-exercised rule (DPYCTL=F010 measured constant:
  // ORG=0, DUDATE=16): first displayed row = (DPYSTRT ^ 0xFFFC) >> 4.
  // DISP_ROW0 remains the reset/default base (0 = the boot/attract value).
  input  wire [15:0] dpystrt,

  // CPU palette write port (paletteram_w, midyunit_v.cpp:247-252).
  input  wire        pal_we,
  input  wire [12:0] pal_waddr,
  input  wire [15:0] pal_wdata,

  // SDRAM scanout read channel (to the VRAM row-cache / sdram_model).
  output wire        scan_req,
  output wire [17:0] scan_addr,
  input  wire [15:0] scan_data,
  input  wire        scan_ack,

  // Video output.
  output reg  [7:0]  vid_r, vid_g, vid_b,
  output reg         hsync, vsync,
  output reg         hblank, vblank,
  output reg         de,
  output wire        rgb_valid,            // 1 pulse per active pixel (capture strobe)
  output reg         vblank_irq,           // 1-clk pulse entering vertical blank

  // P0033: the beam-locked autoerase engine in stv_vram_ddr_top snoops scan_addr for its
  // row-change trigger, so it needs the SAME two pieces of raster state MAME's
  // autoerase_line() implicitly has: the frame's display base (rowaddr is DPYSTRT-derived,
  // tms34010.cpp:1035/1152) and whether the raster is inside the visible region at all
  // (autoerase_line is only reachable from scanline_update, midyunit_v.cpp:554). Both are
  // already computed here -- exported, not re-derived.
  output wire [8:0]  disp_base,            // frame-latched first displayed VRAM row
  output wire        disp_vblank           // high while the raster is vertically blanked
);

  localparam int FBW = FB_ADDR_W;          // 18

  // ---- raster counters (stage 0) ---------------------------------------
  reg [11:0] hc, vc;
  reg [8:0]  disp_row0_q;                  // P0031: frame-latched first displayed row
  always @(posedge clk) begin
    if (rst) begin
      hc <= 12'd0; vc <= 12'd0; vblank_irq <= 1'b0;
      disp_row0_q <= 9'(DISP_ROW0);
    end else if (ce_pix) begin
      vblank_irq <= 1'b0;
      if (hc == H_TOTAL-1) begin
        hc <= 12'd0;
        if (vc == V_TOTAL-1) vc <= 12'd0;
        else begin
          vc <= vc + 12'd1;
          if (vc == V_VIS_EN-1) begin
            vblank_irq <= 1'b1;            // entering vblank
            // P0031: sample DPYSTRT exactly once per frame, at the same epoch
            // MAME's display machine reloads DPYADR from DPYSTRT (vblank
            // entry). The scanline reprime (vblank rising in yunit_scanline)
            // observes the updated value one clk later — never mid-frame.
            disp_row0_q <= 9'((dpystrt ^ 16'hFFFC) >> 4);
          end
        end
      end else hc <= hc + 12'd1;
    end
  end

  // active-region flags (stage 0, aligned with vram_raddr)
  wire h_active = (hc >= H_VIS_ST) && (hc < H_VIS_EN);
  wire v_active = (vc >= V_VIS_ST) && (vc < V_VIS_EN);
  wire de0      = h_active && v_active;
  // sync sits after the front porch within the blank interval.
  wire hs0 = (hc >= H_VIS_EN + H_FP) && (hc < H_VIS_EN + H_FP + H_SYNC);
  wire vs0 = (vc >= V_VIS_EN + V_FP) && (vc < V_VIS_EN + V_FP + V_SYNC);
  wire hb0 = !h_active;
  wire vb0 = !v_active;

  // VRAM address: (disp_row0 + row)<<9 | col. row tracks v_active so it holds
  // the current display row across horizontal blank (no spurious line swap);
  // col is 0 outside the visible span (readout unused there). The 9-bit row
  // sum wraps within the 512-row buffer, matching MAME's
  // (rowaddr << 9) & 0x3fe00 (midyunit_v.cpp:545).
`ifdef MUT_UNLATCHED
  // MUTATION (sim-only, must die in the tearing gate): apply DPYSTRT
  // combinationally instead of at the frame boundary — a mid-frame game write
  // tears the raster.
  wire [8:0] disp_row0_eff = 9'((dpystrt ^ 16'hFFFC) >> 4);
`else
  wire [8:0] disp_row0_eff = disp_row0_q;
`endif
  wire [8:0] row = v_active ? 9'(vc - V_VIS_ST) : 9'd0;
  wire [8:0] col = h_active ? 9'(hc - H_VIS_ST) : 9'd0;
  wire [8:0] disp_row = disp_row0_eff + row;
  wire [FBW-1:0] vram_raddr = FBW'(({9'd0, disp_row} << FB_ROWSHIFT) | {9'd0, col});
  wire [15:0] vram_rdata;

  // scanline reprime signal: high across the vertical blank (rising edge at the
  // active->blank boundary, vc=V_VIS_EN) — yunit_scanline primes rows
  // disp_row0_q / disp_row0_q+1 during the blank so row 0 is ready at active
  // start. disp_row0_q latches one clk before the reprime edge is observed
  // (both are ce_pix-epoch events at vc==V_VIS_EN), so priming always uses the
  // new frame's base.
  wire vblank_i = !v_active;

  // P0033 exports (see the port comment). disp_row0_eff is the same base the address
  // generator and the scanline prefetcher use, so the erase engine cannot disagree with the
  // beam; vblank_i is the same level that drives the prefetcher's re-prime.
  assign disp_base   = disp_row0_eff;
  assign disp_vblank = vblank_i;

  yunit_scanline #(.FB_ADDR_W(FBW), .NCOL(NCOL)) u_scan (
    .clk(clk), .rst(rst), .ce_pix(ce_pix), .vblank(vblank_i),
    .first_row(disp_row0_eff),
    .vram_raddr(vram_raddr), .vram_rdata(vram_rdata),
    .scan_req(scan_req), .scan_addr(scan_addr),
    .scan_data(scan_data), .scan_ack(scan_ack)
  );

  // ---- align pix_valid to vram_rdata (1 ce_pix latency) ----------------
  reg de_s1;                       // de0 delayed 1 ce_pix (== vram_rdata epoch)
  always @(posedge clk) begin
    if (rst) de_s1 <= 1'b0;
    else if (ce_pix) de_s1 <= de0;
  end
  wire pix_valid = ce_pix & de_s1; // one-clk pulse per active pixel

  // ---- frozen back-end: pen_map8 + palette + RGB888 --------------------
  wire       vrgb_valid;
  wire [7:0] vr, vg, vb;
  zunit_video #(.PEN_MASK(PEN_MASK)) u_vid (
    .clk(clk),
    .pal_we(pal_we), .pal_waddr(pal_waddr), .pal_wdata(pal_wdata),
    .pix_valid(pix_valid), .vram_word(vram_rdata),
    .rgb_valid(vrgb_valid), .r(vr), .g(vg), .b(vb)
  );
  assign rgb_valid = vrgb_valid;

  // ---- HW output register ----------------------------------------------
  // The back-end colour (vr/vg/vb) for column c settles one ce_pix ahead of the
  // de/sync path, so it is re-registered through one ce_pix stage (vr_q) to
  // land co-aligned with de_s2/sync (MEASURED: shifts the visible frame from a
  // 1-px lead to bit-exact vs the MAME scene PNG). de/sync are delayed 2 ce_pix
  // from stage 0 so they co-sample with the settled colour.
  reg [7:0] vr_q, vg_q, vb_q;
  reg de_s2, hs_s1, hs_s2, vs_s1, vs_s2, hb_s1, hb_s2, vb_s1, vb_s2;
  always @(posedge clk) begin
    if (rst) begin
      vr_q<=0; vg_q<=0; vb_q<=0;
      de_s2<=0; hs_s1<=0; hs_s2<=0; vs_s1<=0; vs_s2<=0;
      hb_s1<=0; hb_s2<=0; vb_s1<=0; vb_s2<=0;
      de<=0; hsync<=0; vsync<=0; hblank<=0; vblank<=0;
      vid_r<=0; vid_g<=0; vid_b<=0;
    end else if (ce_pix) begin
      vr_q<=vr; vg_q<=vg; vb_q<=vb;
      de_s2<=de_s1; hs_s1<=hs0; hs_s2<=hs_s1; vs_s1<=vs0; vs_s2<=vs_s1;
      hb_s1<=hb0; hb_s2<=hb_s1; vb_s1<=vb0; vb_s2<=vb_s1;
      de<=de_s2; hsync<=hs_s2; vsync<=vs_s2; hblank<=hb_s2; vblank<=vb_s2;
      vid_r<=de_s2?vr_q:8'h00; vid_g<=de_s2?vg_q:8'h00; vid_b<=de_s2?vb_q:8'h00;
    end
  end

endmodule

`default_nettype wire
