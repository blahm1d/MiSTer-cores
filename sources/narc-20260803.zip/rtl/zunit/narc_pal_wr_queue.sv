// narc_pal_wr_queue.sv — P0039b: palette-write serializer for the NARC video
// palette mirror.
//
// The mirror accepts up to TWO palette writes per clock (zunit_mem's A and B
// ports) but retires only ONE, so the surplus must be QUEUED. The original
// inline merge in zunit_top used a SINGLE pending slot and silently DROPPED any
// write arriving while that slot was occupied, with no backpressure to tell the
// producer. zunit_mem's `M_HFIN2` asserts A+B (words 0,1) and the very next
// state `M_HW2` asserts A again (word 2) whenever a palette field write spans
// past bit 32 — so word 2 was lost.
//
// MEASURED: NARC's real firmware only ever issues aligned 16-bit palette writes
// (all 115,288 writes in the MAME 0.280 trace), so the drop never fired on the
// cabinet. It is a real structural hole regardless, and a wider write from any
// path would corrupt color silently.
//
// A 4-deep queue covers the worst producer burst (2 in one clock, then 1 in the
// next, drained 1/clock) with margin. `ovf_o` is a sticky loud-failure hook: if
// it ever asserts, the queue is too shallow and a write WOULD have been lost —
// the TB $fatals on it rather than letting color corrupt silently.
//
// EXTRACTED FROM zunit_top so the acceptance gate can instantiate the REAL
// logic. The previous gate carried a hand-copied transcription of the merge,
// which is exactly the self-consistency trap CLAUDE.md §5 bans: a copy cannot
// catch a bug in the original, and the two drift.

`default_nettype none

module narc_pal_wr_queue #(
  parameter int PQ_AW = 2                       // 1<<PQ_AW entries (4)
)(
  input  wire        clk,
  input  wire        rst,
  // producer: up to two writes per clock, A retires before B (program order)
  input  wire        we_a,
  input  wire [12:0] addr_a,
  input  wire [15:0] data_a,
  input  wire        we_b,
  input  wire [12:0] addr_b,
  input  wire [15:0] data_b,
  // consumer: one write per clock into the palette mirror
  output reg         pal_we,
  output reg  [12:0] pal_waddr,
  output reg  [15:0] pal_wdata,
  output reg         ovf_o                      // sticky: a write could not be queued
);

  localparam int DEPTH = (1 << PQ_AW);

  reg [28:0]     mem [0:DEPTH-1];               // {addr[12:0], data[15:0]}
  reg [PQ_AW:0]  wp, rp;
  wire [PQ_AW:0] occ      = wp - rp;
  wire           retiring = (occ != 0);
  wire [PQ_AW:0] wp1      = wp + 1'b1;   // 2nd-port slot, width-correct

  // room available for THIS clock's enqueues, judged after the retire
  wire [7:0] occ8  = {{(8-PQ_AW-1){1'b0}}, occ};
  wire [7:0] room8 = DEPTH[7:0] - occ8 + (retiring ? 8'd1 : 8'd0);
  wire [7:0] need8 = (we_a ? 8'd1 : 8'd0) + (we_b ? 8'd1 : 8'd0);

  always @(posedge clk) begin
    if (rst) begin
      wp <= 0; rp <= 0; ovf_o <= 1'b0;
      pal_we <= 1'b0; pal_waddr <= 13'd0; pal_wdata <= 16'd0;
    end else begin
      // ---- retire one entry per clock (registered, 1-clk latency) ----
      if (retiring) begin
        pal_we    <= 1'b1;
        pal_waddr <= mem[rp[PQ_AW-1:0]][28:16];
        pal_wdata <= mem[rp[PQ_AW-1:0]][15:0];
        rp        <= rp + 1'b1;
      end else begin
        pal_we <= 1'b0;
      end

      // ---- enqueue both ports this clock, A before B (program order) ----
      if (need8 > room8) begin
        ovf_o <= 1'b1;                          // would have dropped -- fail loudly
      end else if (we_a && we_b) begin
        mem[wp[PQ_AW-1:0]]                 <= {addr_a, data_a};
        mem[wp1[PQ_AW-1:0]]                <= {addr_b, data_b};
        wp <= wp + 2;
      end else if (we_a) begin
        mem[wp[PQ_AW-1:0]] <= {addr_a, data_a};
        wp <= wp + 1'b1;
      end else if (we_b) begin
        mem[wp[PQ_AW-1:0]] <= {addr_b, data_b};
        wp <= wp + 1'b1;
      end
    end
  end

endmodule

`default_nettype wire
