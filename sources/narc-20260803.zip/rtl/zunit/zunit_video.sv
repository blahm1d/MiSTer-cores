// zunit_video.sv — Williams Z-unit (NARC, 1988) 8bpp scanline-unpack + palette
// video back-end. Phase-2 fork of the Y-unit scanline/palette path.
//
// BLIND transcription from the MAME 0.280 gospel
// (D:\deck\fpga\NARC\mame-gospel\midyunit_v.cpp) — NOT from any golden/RTL.
// Cited semantic decisions:
//
//   * 8bpp pen map  (midzunit_state::video_start, midyunit_v.cpp:103-105)
//         m_pen_map[i] = i & 0x1fff;   m_palette_mask = 0x1fff;
//     -> pen = local_videoram_word & 0x1FFF  (a bare 13-bit mask; the donor
//        Y-unit 6bpp map at midyunit_v.cpp:86 uses mask 0x0FFF — the mutant).
//
//   * scanline unpack (midyunit_base_state::scanline_update, midyunit_v.cpp:545-551)
//         dest[x] = m_pen_map[ src[coladdr++ & 0x1ff] ];
//     The upstream VRAM row-cache presents the src word stream to this module;
//     this block performs the per-pixel pen_map + palette lookup + RGB expand.
//
//   * palette (midyunit_base_state::paletteram_w, midyunit_v.cpp:250-251)
//         set_pen_color(offset & mask,
//                       pal5bit(w>>10), pal5bit(w>>5), pal5bit(w>>0));
//     -> palette word = xRGB-1555 (bits [14:10]=R [9:5]=G [4:0]=B);
//        RGB888 R=pal5bit(w[14:10]) G=pal5bit(w[9:5]) B=pal5bit(w[4:0]).
//     pal5bit(v) = (v<<3)|(v>>2)  (MAME emupal.h 5->8 expand) = {v, v[4:2]}.
//
// HW-FIT (architect ratification): 8bpp pen is a bare 13-bit mask (cheaper than
// the donor's 6bpp bit-scramble — no LUT). Palette = one dual-port M10K
// (8192 x 16 = 128 Kbit). pal5bit is a trivial combinational 5->8 expand.
// Clocked BRAM read only — NO async multi-read window. VRAM stays in the DDR3
// row-cache upstream (ATTACK-PLAN §4); this module consumes a word stream.
//
// Latency: 3 clocks from pix_valid/vram_word in to rgb_valid/{r,g,b} out.

`default_nettype none

module zunit_video #(
    // 8bpp Z-unit pen mask (midyunit_v.cpp:104). Donor 6bpp mutant = 13'h0FFF.
    parameter logic [12:0] PEN_MASK = 13'h1FFF
) (
    input  wire        clk,

    // Palette RAM host-write port (paletteram_w, midyunit_v.cpp:247-252).
    // 8192 x 16-bit xRGB-1555 entries.
    input  wire        pal_we,
    input  wire [12:0] pal_waddr,
    input  wire [15:0] pal_wdata,

    // Per-pixel VRAM word stream in (from the row-cache scanline source).
    input  wire        pix_valid,
    input  wire [15:0] vram_word,

    // RGB888 pixel out (3-clock latency vs the matching pix_valid).
    output reg         rgb_valid,
    output reg  [7:0]  r,
    output reg  [7:0]  g,
    output reg  [7:0]  b
);

    // pal5bit: 5-bit -> 8-bit expand, (v<<3)|(v>>2). midyunit_v.cpp:251 / emupal.h
    function automatic logic [7:0] pal5bit(input logic [4:0] v);
        pal5bit = {v, v[4:2]};
    endfunction

    // ---- Palette RAM: one dual-port M10K (8192 x 16), synchronous read ----
    (* ramstyle = "M10K" *)
    reg [15:0] palram [0:8191];

    // Stage 1: pen_map = vram_word & pen mask (midyunit_v.cpp:104)
    reg [12:0] pen_r;
    reg        valid_1;

    // Stage 2: synchronous palette read
    reg [15:0] pal_q;
    reg        valid_2;

    always @(posedge clk) begin
        // Stage 1 — pen map (bare 13-bit mask)
        pen_r   <= vram_word[12:0] & PEN_MASK;
        valid_1 <= pix_valid;

        // Stage 2 — palette BRAM: write-port + synchronous read of stage-1 pen
        if (pal_we)
            palram[pal_waddr] <= pal_wdata;
        pal_q   <= palram[pen_r];
        valid_2 <= valid_1;

        // Stage 3 — pal5bit RGB888 expand (xRGB-1555)
        r         <= pal5bit(pal_q[14:10]);
        g         <= pal5bit(pal_q[9:5]);
        b         <= pal5bit(pal_q[4:0]);
        rgb_valid <= valid_2;
    end

endmodule

`default_nettype wire
