// zunit_memsys.sv — Z-unit (NARC, 1988) memory subsystem: zunit_mem + zunit_dma
// glued into one slave on the TMS34010 core's request-valid memory interface.
//
// FORK of yunit_memsys.sv (Smash T.V. Y-unit donor). The Z-unit and Y-unit share
// the midyunit_v.cpp video/DMA engine and the same 34010 logical memory map
// (midyunit.cpp:184-202), so the glue STRUCTURE transfers as-is. Audited donor
// deltas applied (ATTACK-PLAN §3 / zunit_pkg.sv):
//   - imports zunit_pkg (region bases + DMA constants cited to Z-unit gospel).
//   - instantiates zunit_mem / zunit_dma (the 8bpp-store + byte-lane fork), NOT
//     the donor yunit_* blocks.
//   - the 8bpp {palette_hi, pixel_lo} store and the dma_palette byte-lane fold
//     are internal to zunit_mem / zunit_dma; the memsys wiring is depth-agnostic
//     (fb write = one 16-bit word at a PIXEL index either way).
//   - PORT-SET DELTA: zunit_dma self-paces on fb_ack and emits an S_DONE-level
//     fb_flush after all pixels have been accepted. The DDR3 combiner consumes
//     that level while the MAME completion-time floor is still running. fb_busy
//     remains observed-only because accepted pixels are already owned by the
//     combiner and zunit_dma must not delay the emulated completion callback.
//
// Routing (unchanged from donor):
//   - DMA blitter register region 0x01A00000 (+0x80000 mirror) -> zunit_dma
//   - everything else                                          -> zunit_mem
//   - blitter fb_* -> zunit_mem VRAM write port; dma_palette -> zunit_mem byte-lane
//   - blit_irq (dma_callback ASSERT on completion; any COMMAND write CLEARs,
//     midyunit_v.cpp:370-374/433) -> int1 -> tms34010 LINT1 (P0016).
//
// TRIGGER-COLLISION STALL carried from donor commit 323472c (cont.25): a GO write
// arriving while blit_busy is high stalls the CPU bus write until the blit drains,
// transparently reproducing "real silicon is fast enough that software polling
// never observes busy" (the multi-cycle FPGA blitter can't match per-pixel HW
// throughput). See the D_IDLE case below.
//
// HW-FIT (architect's ratification): zunit_dma = clocked multi-cycle FSM, single-
// port source fetch self-paced by fb_ack, single-port fb write to zunit_mem's
// clocked VRAM port. No async multi-read, no combinational blitter explosion —
// holds the 45-blit byte-exact behavior on Cyclone V.

`default_nettype none

// Mirror zunit_mem's synthesis auto-defines so the guarded ports/wiring here match.
`ifdef SYNTHESIS
  `ifndef USE_EXT_GFX
    `define USE_EXT_GFX
  `endif
  `ifndef USE_EXT_ROM
    `define USE_EXT_ROM
  `endif
  `ifndef USE_HW_VRAM
  `ifndef USE_SDRAM_VRAM
    `define USE_SDRAM_VRAM
  `endif
  `endif
  `ifndef USE_HW_RAM
    `define USE_HW_RAM
  `endif
`endif
`ifdef USE_EXT_GFX
  `define ZM_EXT_RD
`endif
`ifdef USE_EXT_ROM
  `ifndef ZM_EXT_RD
    `define ZM_EXT_RD
  `endif
`endif

module zunit_memsys
  import zunit_pkg::*;
#(
  parameter ROM_HEX = "smashtv_maindata.hex",
  parameter int ROM_PROG_OFF = 32'h40000   // NARC program @0xFFC00000 (region-word 0x40000)
)(
  input  logic        clk,
  input  logic        rst,

  // CPU (TMS34010 core) request-valid memory interface.
  input  logic        mem_req,
  input  logic        mem_we,
  input  logic        mem_srt,
  input  logic [31:0] mem_addr,          // bit address
  input  logic  [5:0] mem_size,          // field width 1..32
  input  logic [31:0] mem_wdata,
  output logic [31:0] mem_rdata,
  output logic        mem_ack,

  // Unpacked-gfx source (to external gfx ROM / SDRAM): 1 byte/pixel.
  output logic        src_req,
  output logic [23:0] src_addr,
  input  logic  [7:0] src_data,
  input  logic        src_ack,

  // Player inputs: packed {DSW, IN2, IN1, IN0}, active-low.
  input  logic [63:0] inputs,

  // P0016: DMA-done interrupt line -> TMS34010 LINT1.
  output logic        int1,

  // Sound latch -> williams_narc_sound_device (see zunit_mem).
  output logic [7:0]  snd_select,
  output logic        snd_trig,
  output logic        snd_reset,
  // RAW latch seam for the NET-NEW dual-6809 board (narc_sound_board ext_wr/ext_wdata).
  output logic        snd_wr,
  output logic [15:0] snd_wdata,

  // Autoerase sweep: frame-paced trigger into zunit_mem's erase engine.
  input  logic        erase_start,
  input  logic [8:0]  erase_row0,
  input  logic [9:0]  erase_lines,
  output logic        erase_busy,

  // Observability
  output logic        blit_busy
  // splash-capture diag: raw DMA register-write stream for the emu overlay.
  , output logic        dbg_dma_we
  , output logic  [3:0] dbg_dma_addr
  , output logic [15:0] dbg_dma_wdata
`ifdef ZM_EXT_RD
  // CPU read-only external port (gfx/ROM in SDRAM) — exposed to the top controller.
  , output logic        cpu_gfx_rd
  , output logic [23:0] cpu_gfx_raddr
  , input  logic [15:0] cpu_gfx_rdata   // aligned word at raddr&~1
  , input  logic        cpu_gfx_rack
`endif
`ifdef USE_SDRAM_VRAM
  // VRAM SDRAM channel + video scanout read port — exposed to the top controller/video.
  , input  logic        scan_req
  , input  logic [17:0] scan_addr
  , output logic [15:0] scan_data
  , output logic        scan_ack
`ifdef USE_DDR3_VRAM
  , input  logic        sdram_por
  // P0033: raster state for the beam-locked autoerase engine (see zunit_mem/stv_vram_ddr_top).
  , input  logic [8:0]  scan_disp_base
  , input  logic        scan_vblank
  , output logic [28:0] ddram_addr
  , output logic [7:0]  ddram_burstcnt
  , output logic        ddram_rd
  , output logic        ddram_we
  , output logic [63:0] ddram_din
  , output logic [7:0]  ddram_be
  , input  logic        ddram_busy
  , input  logic [63:0] ddram_dout
  , input  logic        ddram_dout_ready
`else
  , output logic [24:0] vsd_addr
  , output logic [15:0] vsd_din
  , output logic [1:0]  vsd_be
  , output logic        vsd_rd
  , output logic        vsd_wr
  , input  logic [15:0] vsd_dout
  , input  logic        vsd_ack
`endif
`endif
`ifdef USE_HW_RAM
  // palette write-tap -> video scanout mirror (zunit_palram, in zunit_top).
  , output logic        palv_we_a
  , output logic [12:0] palv_aa
  , output logic [15:0] palv_awd
  , output logic        palv_we_b
  , output logic [12:0] palv_ba
  , output logic [15:0] palv_bwd
`endif
);

  // ---- DMA-region detect (0x01A00000 and its 0x080000 mirror) -----------
  // The 0x01A top-12-bit case subsumes both aliases (bit 19 is don't-care).
  wire is_dma_now = (mem_addr[31:20] == 12'h01A);

  // ---- zunit_mem (all non-DMA regions, incl. VRAM/PAL/RAM/ROM/CMOS/CTRL) --
  logic        mem_req_m;
  logic [31:0] mem_rdata_m;
  logic        mem_ack_m;

  // ---- zunit_dma blitter ------------------------------------------------
  logic        dma_reg_we;
  logic  [3:0] dma_reg_addr;
  logic [15:0] dma_reg_wdata;
  logic [15:0] dma_reg_rdata;
  logic        dma_fb_we;
  logic [FB_ADDR_W-1:0] dma_fb_addr;
  logic [15:0] dma_fb_wdata;
  logic [15:0] dma_palette;
  logic        dma_fb_flush;

  // Blitter framebuffer write completion.  The compact NARC ingress journal
  // lives inside stv_vram_ddr_top, where CPU and autoerase ownership fences can
  // see it; this boundary remains the exact pre-journal handshake.
`ifdef USE_SDRAM_VRAM
  logic mem_fb_ack;
  wire  dma_fb_ack = mem_fb_ack;
  logic mem_fb_busy;
`else
  wire  dma_fb_ack = 1'b1;
`endif

  zunit_mem #(.ROM_HEX(ROM_HEX), .ROM_PROG_OFF(ROM_PROG_OFF)) u_mem (
    .clk(clk), .rst(rst),
    .mem_req(mem_req_m), .mem_we(mem_we), .mem_srt(mem_srt), .mem_addr(mem_addr),
    .mem_size(mem_size), .mem_wdata(mem_wdata),
    .mem_rdata(mem_rdata_m), .mem_ack(mem_ack_m),
    .fb_we(dma_fb_we), .fb_addr(dma_fb_addr), .fb_wdata(dma_fb_wdata),
    .dma_palette(dma_palette),
    .inputs(inputs),
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .snd_wr(snd_wr), .snd_wdata(snd_wdata),
    .erase_start(erase_start), .erase_row0(erase_row0),
    .erase_lines(erase_lines), .erase_busy(erase_busy)
`ifdef ZM_EXT_RD
    , .gfx_rd(cpu_gfx_rd), .gfx_raddr(cpu_gfx_raddr),
      .gfx_rdata(cpu_gfx_rdata), .gfx_rack(cpu_gfx_rack)
`endif
`ifdef USE_SDRAM_VRAM
    , .fb_ack(mem_fb_ack)
    , .fb_busy(mem_fb_busy)
    , .fb_flush(dma_fb_flush)
    , .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack)
`ifdef USE_DDR3_VRAM
    , .sdram_por(sdram_por)
    , .scan_disp_base(scan_disp_base), .scan_vblank(scan_vblank)
    , .ddram_addr(ddram_addr), .ddram_burstcnt(ddram_burstcnt), .ddram_rd(ddram_rd), .ddram_we(ddram_we)
    , .ddram_din(ddram_din), .ddram_be(ddram_be)
    , .ddram_busy(ddram_busy), .ddram_dout(ddram_dout), .ddram_dout_ready(ddram_dout_ready)
`else
    , .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr)
    , .vsd_dout(vsd_dout), .vsd_ack(vsd_ack)
`endif
`endif
`ifdef USE_HW_RAM
    , .palv_we_a(palv_we_a), .palv_aa(palv_aa), .palv_awd(palv_awd)
    , .palv_we_b(palv_we_b), .palv_ba(palv_ba), .palv_bwd(palv_bwd)
`endif
  );

  // zunit_dma self-paces on fb_ack. Its S_DONE level flushes the DDR3
  // write-combiner while the MAME 41ns/pixel completion floor is still running.
  zunit_dma u_dma (
    .clk(clk), .rst(rst),
    .reg_we(dma_reg_we), .reg_addr(dma_reg_addr),
    .reg_wdata(dma_reg_wdata), .reg_rdata(dma_reg_rdata),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .fb_we(dma_fb_we), .fb_addr(dma_fb_addr), .fb_wdata(dma_fb_wdata),
    .fb_ack(dma_fb_ack), .fb_flush(dma_fb_flush),
    .busy(blit_busy), .blit_irq(int1), .dma_palette(dma_palette)   // P0016: -> LINT1
  );

  // ---- DMA register access FSM (DMA 32->16b D_LO/D_HI decode) ------------
  // The DMA registers are 16-bit at word-aligned bit addresses (reg index =
  // addr[7:4]). The 34010 memory system splits a >16-bit field write into
  // consecutive word writes, so a 32-bit field write to reg N updates reg N
  // (low word) AND reg N+1 (high word) — MAME calls dma_w twice. The custom-
  // chip test relies on this: `MOVE A14,@1A80060h,1` (32-bit) sets WIDTH(6)
  // AND HEIGHT(7). A 16-bit-only FSM dropped HEIGHT -> blit height 0 -> no-op.
  // So: writes visit D_LO (reg idx, wdata[15:0]) then, if size>16, D_HI
  // (reg idx+1, wdata[31:16]); reads go straight to D_ACKR. One dma_ack pulse
  // per access, after all register writes land.
  typedef enum logic [1:0] { D_IDLE, D_LO, D_HI, D_ACKR } dstate_t;
  dstate_t dstate;
  logic [31:0] d_addr_q;
  logic        d_we_q;
  logic [31:0] d_wd_q;
  logic  [5:0] d_sz_q;
  logic        dma_ack;

  wire d_second = (dstate == D_HI);
  assign dma_reg_addr  = d_second ? (d_addr_q[7:4] + 4'd1) : d_addr_q[7:4];
  assign dma_reg_wdata = d_second ? d_wd_q[31:16]          : d_wd_q[15:0];

  // splash-capture: forward the DMA register-write stream to the emu overlay taps.
  assign dbg_dma_we    = dma_reg_we;
  assign dbg_dma_addr  = dma_reg_addr;
  assign dbg_dma_wdata = dma_reg_wdata;
  assign dma_reg_we    = (dstate == D_LO) || (dstate == D_HI); // only entered on writes

`ifdef MUT_MEMSYS_DROP_HI
  // MUTANT (memsys D_HI decode): treat every write as <=16 bits, so the high
  // word (reg idx+1) of every 32-bit register pair is DROPPED. OFFSETHI/YSTART/
  // HEIGHT/COLOR never land -> blit degenerates (HEIGHT=0 no-op etc). Must die.
  wire d_want_hi = 1'b0;
`else
  wire d_want_hi = (d_sz_q > 6'd16);
`endif

  always_ff @(posedge clk) begin
    if (rst) begin
      dstate  <= D_IDLE;
      dma_ack <= 1'b0;
    end else begin
      unique case (dstate)
        D_IDLE: begin
          dma_ack <= 1'b0;
          if (mem_req && is_dma_now && !mem_ack) begin
            // TRIGGER-COLLISION STALL (cont.25 / donor 323472c): a DMA_COMMAND
            // write with the trigger bit set, arriving while blit_busy is high,
            // stalls the CPU bus write (do not latch, do not ack) until the blit
            // drains — transparently reproducing "real hardware is fast enough
            // that software polling never observes busy". A KILL (b15=0) or any
            // non-COMMAND write always passes through immediately.
`ifdef MUT_NO_TRIGSTALL
            // MUTANT (revert the cont.25/323472c trigger-collision stall): pass a
            // busy-colliding DMA_COMMAND trigger straight through. zunit_dma's
            // S_IDLE-gated GO (zunit_dma.sv:257) then silently absorbs it into
            // regf[] with no start -> the colliding blit is DROPPED. Must die.
            if (1'b0) begin
`else
            if (mem_we && (mem_addr[7:4] == DMA_COMMAND) && mem_wdata[DMA_CMD_TRIG_BIT] && blit_busy) begin
              // hold: re-evaluate next cycle; mem_req/mem_addr/mem_wdata stay
              // stable (the CPU's own req/ack handshake keeps them driven).
`endif
            end else begin
              d_addr_q <= mem_addr;
              d_we_q   <= mem_we;
              d_wd_q   <= mem_wdata;
              d_sz_q   <= mem_size;
              dstate   <= mem_we ? D_LO : D_ACKR;
            end
          end
        end
        D_LO:   dstate <= d_want_hi ? D_HI : D_ACKR; // reg idx written this edge
        D_HI:   dstate <= D_ACKR;                    // reg idx+1 written this edge
        D_ACKR: begin dma_ack <= 1'b1; dstate <= D_IDLE; end
        default: dstate <= D_IDLE;
      endcase
    end
  end

  // ---- output mux -------------------------------------------------------
  // DMA region -> the DMA FSM (mem_req_m held low so zunit_mem ignores it);
  // everything else -> zunit_mem.
  assign mem_req_m = mem_req && !is_dma_now;
  assign mem_ack   = is_dma_now ? dma_ack : mem_ack_m;
  assign mem_rdata = is_dma_now ? {16'h0000, dma_reg_rdata} : mem_rdata_m;

endmodule

`default_nettype wire
