`timescale 1ns/1ps
`default_nettype none
// ============================================================================
// tb_narc_sound_latch.sv
// Dual-transcription matrix TB for narc_sound_latch (DUT).
// The GOLDEN below is an INDEPENDENT, blind re-transcription of the same gospel
// (williams_narc_sound_device, MAME 0.280) using different expression forms
// (explicit ASSERT/CLEAR constants, ternaries) so it cannot inherit a DUT bug.
// Every driven cycle: DUT next-state vs golden next-state, bit-exact or FAIL.
// Covers D8 NMI polarity (both), D9 IRQ polarity (both) + latching, command_r &
// command2_r clear-on-read, command2_w FIRQ, reset assert/deassert, talkback +
// audio-sync set/clear, plus a randomized soak.
// ============================================================================
module tb_narc_sound_latch;

    localparam ASSERT = 1'b1, CLEAR = 1'b0;

    // ---- DUT ports --------------------------------------------------------
    reg        clk, rst, reset_in;
    reg        ext_wr;         reg [15:0] ext_wdata;
    reg        master_rd_cmd;
    reg        master_wr_cmd2; reg [7:0]  cmd2_wdata;
    reg        slave_rd_cmd2;
    reg        master_wr_tb;   reg [7:0]  tb_wdata;
    reg        master_sync_w, slave_sync_w;
    reg [7:0]  sync_clr_mask;  reg        sync_clr;

    wire [7:0]  latch_o, latch2_o;
    wire [15:0] talkback_rd;
    wire        master_nmi, master_irq, slave_firq, sound_int_state, cpu_reset;

    narc_sound_latch dut(
        .clk(clk), .rst(rst), .reset_in(reset_in),
        .ext_wr(ext_wr), .ext_wdata(ext_wdata),
        .master_rd_cmd(master_rd_cmd), .latch_o(latch_o),
        .master_wr_cmd2(master_wr_cmd2), .cmd2_wdata(cmd2_wdata),
        .slave_rd_cmd2(slave_rd_cmd2), .latch2_o(latch2_o),
        .master_wr_tb(master_wr_tb), .tb_wdata(tb_wdata),
        .master_sync_w(master_sync_w), .slave_sync_w(slave_sync_w),
        .sync_clr_mask(sync_clr_mask), .sync_clr(sync_clr),
        .talkback_rd(talkback_rd),
        .master_nmi(master_nmi), .master_irq(master_irq),
        .slave_firq(slave_firq), .sound_int_state(sound_int_state),
        .cpu_reset(cpu_reset));

    // ---- INDEPENDENT golden state ----------------------------------------
    reg [7:0] gL, gL2, gTB, gSY;
    reg       gINT, gNMI, gIRQ, gFIRQ;

    integer errors, checks;

    // Blind golden next-state, transcribed independently from gospel lines.
    task automatic golden_step;
        begin
            if (rst) begin
                gL=0; gL2=0; gTB=0; gSY=0; gINT=0; gNMI=CLEAR; gIRQ=CLEAR; gFIRQ=CLEAR;
            end else if (reset_in) begin
                // device_reset(): all interrupt state cleared, data latches held
                gINT=0; gNMI=CLEAR; gIRQ=CLEAR; gFIRQ=CLEAR;
            end else begin
                if (ext_wr) begin
                    gL   = ext_wdata[7:0];
                    // D8=1 -> CLEAR, D8=0 -> ASSERT
                    gNMI = (ext_wdata & 16'h0100) ? CLEAR : ASSERT;
                    // D9=0 -> assert IRQ + int_state
                    if ((ext_wdata & 16'h0200) == 16'h0000) begin
                        gIRQ = ASSERT; gINT = 1'b1;
                    end
                end
                if (master_rd_cmd) begin gIRQ = CLEAR; gINT = 1'b0; end
                if (master_wr_cmd2) begin gL2 = cmd2_wdata; gFIRQ = ASSERT; end
                if (slave_rd_cmd2)  gFIRQ = CLEAR;
                if (master_wr_tb)   gTB = tb_wdata;
                if (sync_clr)       gSY = gSY & ~sync_clr_mask;
                if (master_sync_w)  gSY = gSY | 8'h01;
                if (slave_sync_w)   gSY = gSY | 8'h02;
            end
        end
    endtask

    task automatic check(input [255:0] tag);
        begin
            checks = checks + 1;
            if (latch_o!==gL || latch2_o!==gL2 || talkback_rd!=={gSY,gTB} ||
                master_nmi!==gNMI || master_irq!==gIRQ || slave_firq!==gFIRQ ||
                sound_int_state!==gINT || cpu_reset!==reset_in) begin
                errors = errors + 1;
                if (errors <= 16)
                  $display("MISMATCH @%0t [%0s]: L d%02x/g%02x L2 d%02x/g%02x TB d%04x/g%04x NMI %b/%b IRQ %b/%b FIRQ %b/%b INT %b/%b RST %b/%b",
                    $time, tag, latch_o,gL, latch2_o,gL2, talkback_rd,{gSY,gTB},
                    master_nmi,gNMI, master_irq,gIRQ, slave_firq,gFIRQ,
                    sound_int_state,gINT, cpu_reset,reset_in);
            end
        end
    endtask

    // One driven cycle: apply strobes, clock, advance golden, compare.
    task automatic step(input [255:0] tag);
        begin
            @(posedge clk);
            golden_step;
            #1 check(tag);
            // clear one-shot strobes
            ext_wr=0; master_rd_cmd=0; master_wr_cmd2=0; slave_rd_cmd2=0;
            master_wr_tb=0; master_sync_w=0; slave_sync_w=0; sync_clr=0;
        end
    endtask

    always #5 clk = ~clk;

    integer i;
    reg [15:0] rw;
    initial begin
        clk=0; rst=1; reset_in=0;
        ext_wr=0; ext_wdata=0; master_rd_cmd=0;
        master_wr_cmd2=0; cmd2_wdata=0; slave_rd_cmd2=0;
        master_wr_tb=0; tb_wdata=0; master_sync_w=0; slave_sync_w=0;
        sync_clr_mask=0; sync_clr=0;
        errors=0; checks=0;

        step("por_reset");            // rst high -> everything cleared
        rst=0;

        // ---- D8 NMI polarity ------------------------------------------------
        ext_wdata=16'h02AA; ext_wr=1; step("nmi_deassert_D8hi"); // D8=1,D9=1 -> NMI clear
        ext_wdata=16'h0255; ext_wr=1; step("nmi_assert_D8lo");   // D8=0,D9=1 -> NMI assert, no IRQ
        // NMI stays asserted until a write with D8=1
        ext_wdata=16'h0300; ext_wr=1; step("nmi_deassert_again");// D8=1 -> clear

        // ---- D9 IRQ polarity + latch ---------------------------------------
        ext_wdata=16'h0142; ext_wr=1; step("irq_assert_D9lo");   // D9=0 -> IRQ assert, latch=42, D8=1 NMI clear
        // D9=1 write must NOT clear a set IRQ (only command_r clears)
        ext_wdata=16'h0399; ext_wr=1; step("irq_hold_D9hi");     // D9=1 -> no IRQ change, latch=99
        master_rd_cmd=1;              step("cmdr_clear_irq");     // command_r clears IRQ + int_state, returns latch=99

        // re-assert then clear via command_r again
        ext_wdata=16'h017F; ext_wr=1; step("irq_reassert");
        master_rd_cmd=1;              step("cmdr_clear_irq2");

        // ---- command2_w / command2_r (slave FIRQ) --------------------------
        master_wr_cmd2=1; cmd2_wdata=8'hC3; step("cmd2_w_firq");  // latch2=C3, FIRQ assert
        slave_rd_cmd2=1;                     step("cmd2_r_clear"); // FIRQ clear, returns latch2=C3

        // ---- talkback + audio-sync -----------------------------------------
        master_wr_tb=1; tb_wdata=8'h5A; step("tb_write");
        master_sync_w=1;                step("sync_master_set");   // SY|=1
        slave_sync_w=1;                 step("sync_slave_set");    // SY|=2 -> talkback_rd hi=03
        sync_clr=1; sync_clr_mask=8'h01;step("sync_clear_master"); // SY&=~1 -> 02
        sync_clr=1; sync_clr_mask=8'h02;step("sync_clear_slave");  // -> 00

        // ---- reset assert / deassert ---------------------------------------
        ext_wdata=16'h0100; ext_wr=1;   step("preload_irq_nmi");   // set IRQ (D9=0), NMI clear(D8=1)
        reset_in=1;                     step("reset_assert");      // device_reset clears int lines, cpu_reset=1
        reset_in=1;                     step("reset_hold");
        reset_in=0;                     step("reset_deassert");    // cpu_reset=0, lines stay cleared

        // ---- randomized soak (non-conflicting strobes) ---------------------
        for (i=0;i<400;i=i+1) begin
            rw = $random;
            ext_wr        = rw[0];  ext_wdata = $random;
            master_rd_cmd = rw[1] & ~rw[0];      // avoid same-cycle set+clear IRQ
            master_wr_cmd2= rw[2];  cmd2_wdata = $random;
            slave_rd_cmd2 = rw[3] & ~rw[2];      // avoid same-cycle set+clear FIRQ
            master_wr_tb  = rw[4];  tb_wdata   = $random;
            master_sync_w = rw[5];  slave_sync_w = rw[6];
            sync_clr      = rw[7] & ~rw[5] & ~rw[6]; sync_clr_mask = $random;
            reset_in      = (rw[8] & rw[9]);     // occasional reset
            step("soak");
        end

        $display("checks=%0d errors=%0d", checks, errors);
        if (errors==0) $display("RESULT: PASS");
        else           $display("RESULT: FAIL");
        $finish;
    end
endmodule
`default_nettype wire
