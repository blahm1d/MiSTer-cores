`timescale 1ns/1ps
`default_nettype none

// NARC dual-MC6809E clock enables.
//
// MAME: NARC_MASTER_CLOCK (8 MHz) / 4 = 2 MHz for both CPUs.
// The borrowed Williams divider places falling Q 32 clk_sys clocks after
// falling E and the next falling E 16 clocks later at clk_sys=96 MHz.
//
// SDRAM is not the CPU bus clock. A ROM address appears immediately after a
// falling-E commit and has the remainder of the 48-clock CPU period to settle.
// Therefore a pending ROM word must block only the NEXT falling-E deadline.
// Freezing the whole phase counter as soon as the address changes incorrectly
// adds every normal fetch latency to the CPU period and slows music/CVSD code.
module narc_6809_clock_en #(
  parameter integer CLK_HZ = 96_000_000,
  parameter integer CPU_HZ = 2_000_000
)(
  input  wire        clk,
  input  wire        rst,
  input  wire        rom_ready,
  output reg         cen_e,
  output reg         cen_q,
  output reg  [31:0] stall_clks
);
  localparam integer PERIOD  = CLK_HZ / CPU_HZ;
  localparam integer Q_PHASE = (PERIOD * 2) / 3;
  localparam integer PH_W    = (PERIOD <= 2) ? 1 : $clog2(PERIOD);
  localparam [PH_W-1:0] E_AT = PERIOD - 1;
  localparam [PH_W-1:0] Q_AT = Q_PHASE - 1;

  reg [PH_W-1:0] phase;
  wire e_due = (phase == E_AT);
  wire q_due = (phase == Q_AT);

  always @(posedge clk) begin
    if (rst) begin
      phase       <= {PH_W{1'b0}};
      cen_e       <= 1'b0;
      cen_q       <= 1'b0;
      stall_clks  <= 32'd0;
    end else begin
      cen_e <= 1'b0;
      cen_q <= 1'b0;

`ifdef MUT_SND_EARLY_STALL
      // Recreate the inherited fault: any fetch latency freezes all E/Q phase.
      if (!rom_ready) begin
        stall_clks <= stall_clks + 32'd1;
      end else begin
`else
      // Correct wait-state behavior: consume the full memory-access window and
      // stretch only a falling-E edge whose live ROM word is still unavailable.
      if (e_due && !rom_ready) begin
        stall_clks <= stall_clks + 32'd1;
      end else begin
`endif
        if (q_due)
          cen_q <= 1'b1;
        if (e_due) begin
          phase <= {PH_W{1'b0}};
          cen_e <= 1'b1;
        end else begin
          phase <= phase + {{(PH_W-1){1'b0}}, 1'b1};
        end
      end
    end
  end
endmodule

`default_nettype wire
