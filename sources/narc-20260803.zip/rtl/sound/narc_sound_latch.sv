// ============================================================================
// narc_sound_latch.sv
// ----------------------------------------------------------------------------
// NARC (Williams 1988, Z-unit) sound-board command-latch + interrupt/reset
// controller. Pure register block: m_latch / m_latch2 / m_talkback /
// m_audio_sync + comparator-driven interrupt lines and the board-reset line.
// A handful of FFs; zero M10K, zero DSP (architect HW-FIT: ratify MAME-faithful
// structure as-is, no async multi-read).
//
// BLIND-TRANSCRIBED, gospel-cited from MAME 0.280 williams_narc_sound_device,
// vendored at D:\deck\fpga\NARC\mame-gospel\williamssound.cpp :
//   write()             :307-310  -> sync_master_command :598-607
//     m_latch = param & 0xff                                      (:600)
//     NMI = (param & 0x100) ? CLEAR : ASSERT   (D8 low -> assert) (:601)
//     if ((param & 0x200)==0){ IRQ=ASSERT; m_sound_int_state=1 }  (:602-606, D9 low)
//   command_r()         :365-369
//     IRQ=CLEAR; m_sound_int_state=0; return m_latch
//   command2_w()        :378-381  -> sync_slave_command :609-613
//     m_latch2 = param & 0xff; slave FIRQ = ASSERT
//   command2_r()        :389-392
//     slave FIRQ = CLEAR; return m_latch2
//   reset_write(state)  :317-335
//     high -> bank sel 0,0 + device_reset + both cpus RESET ASSERT
//     low  -> both cpus RESET CLEAR
//   device_reset()      :581-591
//     m_sound_int_state=0; FIRQ/IRQ/NMI CLEAR on both cpus
//   read()              :296-299
//     return m_talkback | (m_audio_sync << 8)   (SYNC bits in D8/D9)
//   master_talkback_w() :401-405   m_talkback = data
//   master_sync_w()     :413-418   m_audio_sync |= 0x01
//   slave_sync_w()      :437-442   m_audio_sync |= 0x02
//   sync_clear()        :615-618   m_audio_sync &= ~param   (74LS123 one-shot)
//
// GUARDRAIL (per task / zunit_pkg TODO(G4)): D10 (board reset) is NOT a write()
// latch bit in MAME -- it is the separate reset_write() line. This module keeps
// them separate: ext_wr / ext_wdata models write() (only D8/D9 acted on; D10 is
// ignored here), and reset_in is the reset_write() line. The zunit wrapper
// decodes the 34010 latch @0x01E00000 D10 onto reset_in.
//
// Interrupt-line polarity: outputs are ACTIVE-HIGH "asserted" (1 = ASSERT_LINE,
// 0 = CLEAR_LINE); the 6809 wrappers invert as their pins require.
// ============================================================================
`default_nettype none

module narc_sound_latch
(
    input  wire        clk,          // sound-board clock (SND_MASTER_CLOCK domain)
    input  wire        rst,          // synchronous power-on reset (device_reset)

    // ---- board reset line (reset_write(), williamssound.cpp:317-335) --------
    input  wire        reset_in,     // 1 = halt both cpus (assert RESET); 0 = run

    // ---- external latch write (34010 write(), :307-310 / :598-607) ----------
    input  wire        ext_wr,       // 1-clk strobe: latch a command word
    input  wire [15:0] ext_wdata,    // D0-7 data, D8=~NMI, D9=~IRQ (D10 ignored here)

    // ---- master CPU command read (command_r(), :365-369) --------------------
    input  wire        master_rd_cmd,// 1-clk strobe: master reads latch, clears IRQ
    output wire [7:0]  latch_o,      // m_latch (command_r return value)

    // ---- master->slave command (command2_w/r, :378-392 / :609-613) ----------
    input  wire        master_wr_cmd2,   // 1-clk strobe: master writes slave latch
    input  wire [7:0]  cmd2_wdata,       // slave command byte
    input  wire        slave_rd_cmd2,    // 1-clk strobe: slave reads latch, clears FIRQ
    output wire [7:0]  latch2_o,         // m_latch2 (command2_r return value)

    // ---- talkback + audio-sync (read(), :296-299; talkback_w :401-405) ------
    input  wire        master_wr_tb,     // 1-clk strobe: master_talkback_w
    input  wire [7:0]  tb_wdata,         // talkback byte
    input  wire        master_sync_w,    // 1-clk strobe: audio_sync |= 0x01
    input  wire        slave_sync_w,     // 1-clk strobe: audio_sync |= 0x02
    input  wire [7:0]  sync_clr_mask,    // 74LS123 one-shot: audio_sync &= ~mask
    input  wire        sync_clr,         // 1-clk strobe applying sync_clr_mask
    output wire [15:0] talkback_rd,      // m_talkback | (m_audio_sync << 8)

    // ---- interrupt / reset line outputs (ACTIVE-HIGH asserted) --------------
    output wire        master_nmi,       // cpu0 INPUT_LINE_NMI
    output wire        master_irq,       // cpu0 M6809_IRQ_LINE
    output wire        slave_firq,       // cpu1 M6809_FIRQ_LINE
    output wire        sound_int_state,  // m_sound_int_state
    output wire        cpu_reset         // both cpus INPUT_LINE_RESET (= reset_in)
);

    // ---- state ------------------------------------------------------------
    reg [7:0] r_latch;        // m_latch
    reg [7:0] r_latch2;       // m_latch2
    reg [7:0] r_talkback;     // m_talkback
    reg [7:0] r_audio_sync;   // m_audio_sync
    reg       r_int_state;    // m_sound_int_state
    reg       r_nmi;          // cpu0 NMI  (1 = ASSERT)
    reg       r_irq;          // cpu0 IRQ  (1 = ASSERT)
    reg       r_firq;         // cpu1 FIRQ (1 = ASSERT)

    // reset_write() high halts both cpus; the RESET line simply follows reset_in.
    assign cpu_reset = reset_in;

    always @(posedge clk) begin
        if (rst) begin
            // device_reset() equivalent at power-on (:581-591)
            r_latch      <= 8'h00;
            r_latch2     <= 8'h00;
            r_talkback   <= 8'h00;
            r_audio_sync <= 8'h00;
            r_int_state  <= 1'b0;
            r_nmi        <= 1'b0;
            r_irq        <= 1'b0;
            r_firq       <= 1'b0;
        end
        else if (reset_in) begin
            // reset_write(1): device_reset() clears all interrupt state while
            // the board is held in reset (:324 device_reset -> :581-591).
            r_int_state  <= 1'b0;
            r_nmi        <= 1'b0;
            r_irq        <= 1'b0;
            r_firq       <= 1'b0;
        end
        else begin
            // ---- external latch write -> sync_master_command (:598-607) ----
            if (ext_wr) begin
                r_latch <= ext_wdata[7:0];                      // :600
                r_nmi   <= ~ext_wdata[8];                       // :601 (D8 low = assert)
                if (ext_wdata[9] == 1'b0) begin                 // :602 (D9 low = assert)
                    r_irq       <= 1'b1;                        // :604
                    r_int_state <= 1'b1;                        // :605
                end
            end

            // ---- master reads command -> command_r (:365-369) --------------
            if (master_rd_cmd) begin
                r_irq       <= 1'b0;                            // :367 IRQ CLEAR
                r_int_state <= 1'b0;                            // :368
            end

            // ---- master writes slave -> sync_slave_command (:609-613) -------
            if (master_wr_cmd2) begin
                r_latch2 <= cmd2_wdata;                         // :611
                r_firq   <= 1'b1;                               // :612 slave FIRQ ASSERT
            end

            // ---- slave reads command2 -> command2_r (:389-392) -------------
            if (slave_rd_cmd2)
                r_firq <= 1'b0;                                 // :391 slave FIRQ CLEAR

            // ---- talkback + audio-sync -------------------------------------
            if (master_wr_tb)
                r_talkback <= tb_wdata;                         // :403
            // audio_sync set (|=) has priority over the same-cycle timed clear,
            // matching the |= then later scheduled &= ordering in MAME.
            r_audio_sync <= (r_audio_sync
                             & ~(sync_clr ? sync_clr_mask : 8'h00)) // :617
                             | (master_sync_w ? 8'h01 : 8'h00)      // :416
                             | (slave_sync_w  ? 8'h02 : 8'h00);     // :440
        end
    end

    assign latch_o         = r_latch;
    assign latch2_o        = r_latch2;
    assign talkback_rd     = {r_audio_sync, r_talkback};  // m_talkback | (audio_sync<<8) :298
    assign master_nmi      = r_nmi;
    assign master_irq      = r_irq;
    assign slave_firq      = r_firq;
    assign sound_int_state = r_int_state;

endmodule

`default_nettype wire
