// narc_sound_pkg.sv — Williams NARC (1988) dual-6809 sound board wiring
// constants. NET-NEW board (the reason NARC didn't exist as a MiSTer core);
// the chips (mc6809is, jt51, hc55564) already exist in rtl/sound but the
// BOARD WIRING is new. Every value below is transcribed + cited to the
// primary source. NO board logic here — constants only (Phase-4 kickoff,
// mirrors the zunit_pkg pattern).
//
// Citation key:
//   williamssound.cpp = MAME 0.280 williams_narc_sound_device, vendored at
//                       D:\deck\fpga\NARC\mame-gospel\williamssound.cpp
//                       (behavioral WHAT — bit-exact).
//
// DOCTRINE: MAME 0.280 is the behavioral ground truth. Address decodes below
// are the master/slave CPU maps EXACTLY as MAME presents them, with the .mirror
// spans recorded so the board module can fold them without re-deriving.
//
// Address convention: 6809 byte addresses (16-bit space per CPU).

`default_nettype none

package narc_sound_pkg;

  // =====================================================================
  // Clocks
  // =====================================================================
  // NARC_MASTER_CLOCK = XTAL(8'000'000): williamssound.cpp:46.
  localparam int SND_MASTER_CLOCK_HZ = 8_000_000;
  // MC6809E fed NARC_MASTER_CLOCK/4 for BOTH cpus (master + slave):
  // williamssound.cpp:512 (cpu0), :515 (cpu1) -> 2 MHz E-clock.
  localparam int SND_CPU_DIV         = 4;
  localparam int SND_CPU_E_CLOCK_HZ  = SND_MASTER_CLOCK_HZ / SND_CPU_DIV; // 2 MHz
  // NARC_FM_CLOCK = XTAL(3'579'545) feeding the YM2151: williamssound.cpp:47,
  // instantiated williamssound.cpp:518.
  localparam int SND_FM_CLOCK_HZ     = 3_579_545;

  // =====================================================================
  // ROM banking — bank mask 0x0f (16 entries) for BOTH cpus
  // =====================================================================
  // master_bank_select_w: set_entry(data & 0x0f): williamssound.cpp:345.
  // slave_bank_select_w:  set_entry(data & 0x0f): williamssound.cpp:356.
  // 16 configured entries per bank: device_start loops bank<16 for master
  // (williamssound.cpp:537) and slave (williamssound.cpp:551).
  localparam [7:0] SND_BANK_MASK     = 8'h0f;
  localparam int   SND_BANK_ENTRIES  = 16;

  // =====================================================================
  // MASTER 6809 CPU address map (williams_narc_master_map,
  // williamssound.cpp:471-483). Decoded addresses + their .mirror spans.
  // =====================================================================
  // 0x0000-0x1fff RAM (8 KB): williamssound.cpp:473.
  localparam [15:0] MST_RAM_BASE       = 16'h0000;
  localparam [15:0] MST_RAM_END        = 16'h1fff;
  // 0x2000-0x2001 mirror 0x03fe : YM2151 r/w: williamssound.cpp:474.
  localparam [15:0] MST_YM2151_BASE    = 16'h2000;
  localparam [15:0] MST_YM2151_END     = 16'h2001;
  localparam [15:0] MST_YM2151_MIRROR  = 16'h03fe;
  // 0x2800 mirror 0x03ff : master_talkback_w: williamssound.cpp:475.
  localparam [15:0] MST_TALKBACK       = 16'h2800;
  localparam [15:0] MST_TALKBACK_MIRROR= 16'h03ff;
  // 0x2c00 mirror 0x03ff : command2_w (master->slave command): williamssound.cpp:476.
  localparam [15:0] MST_CMD2_W         = 16'h2c00;
  localparam [15:0] MST_CMD2_W_MIRROR  = 16'h03ff;
  // 0x3000 mirror 0x03ff : DAC1 (AD7224) data_w: williamssound.cpp:477,522.
  localparam [15:0] MST_DAC1           = 16'h3000;
  localparam [15:0] MST_DAC1_MIRROR    = 16'h03ff;
  // 0x3400 mirror 0x03ff : command_r (read external latch, clears IRQ): williamssound.cpp:478.
  localparam [15:0] MST_CMD_R          = 16'h3400;
  localparam [15:0] MST_CMD_R_MIRROR   = 16'h03ff;
  // 0x3800 mirror 0x03ff : master_bank_select_w: williamssound.cpp:479.
  localparam [15:0] MST_BANK_SEL       = 16'h3800;
  localparam [15:0] MST_BANK_SEL_MIRROR= 16'h03ff;
  // 0x3c00 mirror 0x03ff : master_sync_w (74LS123 one-shot): williamssound.cpp:480.
  localparam [15:0] MST_SYNC           = 16'h3c00;
  localparam [15:0] MST_SYNC_MIRROR    = 16'h03ff;
  // 0x4000-0xbfff banked ROM ("masterbank"): williamssound.cpp:481.
  localparam [15:0] MST_BANK_BASE      = 16'h4000;
  localparam [15:0] MST_BANK_END       = 16'hbfff;
  // 0xc000-0xffff fixed upper ROM ("masterupper"): williamssound.cpp:482.
  localparam [15:0] MST_UPPER_BASE     = 16'hc000;
  localparam [15:0] MST_UPPER_END      = 16'hffff;

  // =====================================================================
  // SLAVE 6809 CPU address map (williams_narc_slave_map,
  // williamssound.cpp:490-502).
  // =====================================================================
  // 0x0000-0x1fff RAM (8 KB): williamssound.cpp:492.
  localparam [15:0] SLV_RAM_BASE       = 16'h0000;
  localparam [15:0] SLV_RAM_END        = 16'h1fff;
  // 0x2000 mirror 0x03ff : cvsd_clock_set_w (HC55516 clock high): williamssound.cpp:493.
  localparam [15:0] SLV_CVSD_CLK_SET   = 16'h2000;
  localparam [15:0] SLV_CVSD_CLK_SET_MIRROR = 16'h03ff;
  // 0x2400 mirror 0x03ff : cvsd_digit_clock_clear_w (clock low + digit latch): williamssound.cpp:494.
  localparam [15:0] SLV_CVSD_CLK_CLR   = 16'h2400;
  localparam [15:0] SLV_CVSD_CLK_CLR_MIRROR = 16'h03ff;
  // 0x2800 mirror 0x03ff : slave_talkback_w: williamssound.cpp:495.
  localparam [15:0] SLV_TALKBACK       = 16'h2800;
  localparam [15:0] SLV_TALKBACK_MIRROR= 16'h03ff;
  // 0x3000 mirror 0x03ff : DAC2 (AD7224) data_w: williamssound.cpp:496,523.
  localparam [15:0] SLV_DAC2           = 16'h3000;
  localparam [15:0] SLV_DAC2_MIRROR    = 16'h03ff;
  // 0x3400 mirror 0x03ff : command2_r (read master->slave latch, clears FIRQ): williamssound.cpp:497.
  localparam [15:0] SLV_CMD2_R         = 16'h3400;
  localparam [15:0] SLV_CMD2_R_MIRROR  = 16'h03ff;
  // 0x3800 mirror 0x03ff : slave_bank_select_w: williamssound.cpp:498.
  localparam [15:0] SLV_BANK_SEL       = 16'h3800;
  localparam [15:0] SLV_BANK_SEL_MIRROR= 16'h03ff;
  // 0x3c00 mirror 0x03ff : slave_sync_w (74LS123 one-shot): williamssound.cpp:499.
  localparam [15:0] SLV_SYNC           = 16'h3c00;
  localparam [15:0] SLV_SYNC_MIRROR    = 16'h03ff;
  // 0x4000-0xbfff banked ROM ("slavebank"): williamssound.cpp:500.
  localparam [15:0] SLV_BANK_BASE      = 16'h4000;
  localparam [15:0] SLV_BANK_END       = 16'hbfff;
  // 0xc000-0xffff fixed upper ROM ("slaveupper"): williamssound.cpp:501.
  localparam [15:0] SLV_UPPER_BASE     = 16'hc000;
  localparam [15:0] SLV_UPPER_END      = 16'hffff;

  // =====================================================================
  // External command latch (main TMS34010 -> sound board) bit semantics.
  // write(u16) -> sync_master_command: williamssound.cpp:307-310, 598-607.
  //   D0-D7  = command data byte              (m_latch = param & 0xff, :600)
  //   D8  low = assert master NMI             ((param&0x100)?CLEAR:ASSERT, :601)
  //   D9  low = assert master IRQ             ((param&0x200)==0 -> ASSERT, :602-605)
  //   D10 low = board reset (reset_write)     : williamssound.cpp:317-335
  //             (decoded from the 34010-side latch 0x01E00000; reset_write
  //              halts both cpus high, releases both low).
  // =====================================================================
  localparam int SND_LATCH_NMI_BIT   = 8;  // active-low
  localparam int SND_LATCH_IRQ_BIT   = 9;  // active-low
  localparam int SND_LATCH_RESET_BIT = 10; // active-low, board reset

  // =====================================================================
  // Interrupt wiring (for the board FSM — recorded, not driven here).
  //   YM2151 IRQ -> master (cpu0) FIRQ line: williamssound.cpp:519.
  //   master command_r read clears cpu0 IRQ:  williamssound.cpp:367.
  //   command2_w (master->slave) asserts slave FIRQ: williamssound.cpp:612.
  //   command2_r read clears slave FIRQ:       williamssound.cpp:391.
  // =====================================================================

  // =====================================================================
  // Talkback / audio-sync readback (34010 read() ) : williamssound.cpp:296-299.
  //   returns m_talkback | (m_audio_sync << 8)  -> SYNC bits at D8/D9.
  //   master_sync bit = 0x01 (:416), slave_sync bit = 0x02 (:440).
  // =====================================================================
  localparam [7:0] SND_SYNC_MASTER_BIT = 8'h01; // williamssound.cpp:416
  localparam [7:0] SND_SYNC_SLAVE_BIT  = 8'h02; // williamssound.cpp:440

  // =====================================================================
  // 74LS123 sync one-shot period. master_sync_w / slave_sync_w schedule the
  // clear at TIME_OF_74LS123(180000, 0.000001): williamssound.cpp:415,439.
  // rescap.h TIME_OF_74LS123(R,C) = 0.45*R*C -> 0.45*180000*1e-6 = ~81 ms.
  // =====================================================================
  localparam int SND_LS123_R_OHMS   = 180000;    // williamssound.cpp:415,439
  // C = 1 uF encoded in picofarads to keep it integral (0.000001 F).
  localparam int SND_LS123_C_PF     = 1_000_000; // 1 uF, williamssound.cpp:415,439
  localparam int SND_LS123_US_APPROX= 81000;     // 0.45*R*C -> ~81 ms

endpackage : narc_sound_pkg

`default_nettype wire
