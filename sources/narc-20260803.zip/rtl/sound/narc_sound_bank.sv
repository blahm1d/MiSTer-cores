// ============================================================================
// narc_sound_bank.sv
// ----------------------------------------------------------------------------
// NARC (Williams 1988, Z-unit) sound-board ROM bank decoder.
// Pure-combinational. Used for BOTH the master and the slave MC6809E CPUs:
// per gospel the offset equation is bit-identical for the two CPUs, differing
// ONLY in which physical ROM region is addressed (cpu0 vs cpu1) -- that region
// home is the deferred D1 decision, so this decoder is ROM-home-agnostic and
// emits a FLAT byte offset within the (either) CPU's sound-ROM image.
//
// BLIND-TRANSCRIBED, gospel-cited from:
//   williamssound.cpp:539-547 (master), :554-561 (slave)
//     offs_t offset = 0x8000 * (bank & 1)
//                   + 0x10000 * ((bank >> 3) & 1)
//                   + 0x20000 * ((bank >> 1) & 3);
//     configure_entry(bank, &rom[0x10000 + offset]);       // banked window
//     membank("...upper")->set_base(
//         &rom[0x10000 + 0x4000 + 0x8000 + 0x10000 + 0x20000 * 3]); // :547/:561
//   bank select bit meaning (williamssound.cpp:540-542 / :554-556):
//     D0 -> A15 ; D1/D2 -> chip select 0..3 ; D3 -> A16
//
// CPU 6809 address map (banked region only, per Z-UNIT sound board):
//   0x4000-0xbfff : banked window  (0x8000 bytes) -> rom[0x10000 + offset + a]
//   0xc000-0xffff : fixed upper    (0x4000 bytes) -> rom[upper_base + a]
// Addresses below 0x4000 are NOT decoded here (RAM/IO/ym) -> not_rom asserted.
//
// HW-FIT: trivial combinational adders/muxes; zero M10K / zero DSP. The flat
// byte offset keeps the physical ROM home (SDRAM 5th client vs HPS DDR3) open.
// ============================================================================
`default_nettype none

module narc_sound_bank
(
    input  wire [3:0]  bank,      // sound bank latch value 0..15 (D3..D0)
    input  wire [15:0] cpu_addr,  // 6809 address bus
    output wire [19:0] rom_offset,// flat byte offset into the CPU's sound-ROM image
    output wire        rom_sel,   // 1 = cpu_addr hits ROM (banked window or fixed upper)
    output wire        upper_sel  // 1 = fixed-upper region, 0 = banked window (valid when rom_sel)
);

    // ---- region decode ----------------------------------------------------
    // banked window : 0x4000 .. 0xbfff
    // fixed upper   : 0xc000 .. 0xffff
    wire in_banked = (cpu_addr >= 16'h4000) && (cpu_addr <= 16'hbfff);
    wire in_upper  = (cpu_addr >= 16'hc000);

    assign rom_sel   = in_banked | in_upper;
    assign upper_sel = in_upper;

    // ---- bank offset (williamssound.cpp:544 / :558) -----------------------
    //   0x8000 * (bank & 1)          -> D0 -> A15
    //   0x10000 * ((bank >> 3) & 1)  -> D3 -> A16
    //   0x20000 * ((bank >> 1) & 3)  -> D1/D2 chip select (0..3)
    wire [19:0] bank_off =
          ({19'd0, bank[0]}      << 15)   // 0x8000  * (bank & 1)
        + ({19'd0, bank[3]}      << 16)   // 0x10000 * ((bank>>3)&1)
        + ({18'd0, bank[2:1]}    << 17);  // 0x20000 * ((bank>>1)&3)

    // banked flat offset = 0x10000 + bank_off + (cpu_addr - 0x4000)
    wire [19:0] banked_offset = 20'h10000 + bank_off
                              + ({4'd0, cpu_addr} - 20'h04000);

    // fixed-upper base (williamssound.cpp:547 / :561):
    //   0x10000 + 0x4000 + 0x8000 + 0x10000 + 0x20000*3 = 0x8C000
    // fixed flat offset = 0x8C000 + (cpu_addr - 0xc000)
    wire [19:0] upper_offset = 20'h8C000 + ({4'd0, cpu_addr} - 20'h0C000);

    assign rom_offset = in_upper ? upper_offset : banked_offset;

endmodule

`default_nettype wire
