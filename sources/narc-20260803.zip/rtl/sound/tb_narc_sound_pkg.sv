// tb_narc_sound_pkg.sv — smoke TB asserting the cited NARC sound-board map
// constants from narc_sound_pkg.sv (williamssound.cpp gospel). Self-checking:
// any wrong localparam prints FAIL and $fatal.
`default_nettype none

module tb_narc_sound_pkg;
  import narc_sound_pkg::*;

  int errors = 0;

  task automatic chk8(input string nm, input [15:0] got, input [15:0] exp);
    if (got !== exp) begin
      $display("FAIL: %s = 0x%04x expected 0x%04x", nm, got, exp);
      errors++;
    end
  endtask

  task automatic chki(input string nm, input int got, input int exp);
    if (got !== exp) begin
      $display("FAIL: %s = %0d expected %0d", nm, got, exp);
      errors++;
    end
  endtask

  initial begin
    // Master map (williamssound.cpp:474-480)
    chk8("MST_YM2151_BASE", MST_YM2151_BASE, 16'h2000);
    chk8("MST_DAC1",        MST_DAC1,        16'h3000);
    chk8("MST_BANK_SEL",    MST_BANK_SEL,    16'h3800);
    chk8("MST_SYNC",        MST_SYNC,        16'h3c00);
    chk8("MST_CMD2_W",      MST_CMD2_W,      16'h2c00);
    chk8("MST_CMD_R",       MST_CMD_R,       16'h3400);

    // Slave map (williamssound.cpp:493-499)
    chk8("SLV_CVSD_CLK_CLR",SLV_CVSD_CLK_CLR,16'h2400); // CVSD digit-clock-clear
    chk8("SLV_DAC2",        SLV_DAC2,        16'h3000);
    chk8("SLV_CMD2_R",      SLV_CMD2_R,      16'h3400); // command2 (cmd2)

    // Bank mask (williamssound.cpp:345,356)
    chki("SND_BANK_MASK",   SND_BANK_MASK,   8'h0f);
    chki("SND_BANK_ENTRIES",SND_BANK_ENTRIES,16);

    // Clocks (williamssound.cpp:46,47,512/515)
    chki("SND_MASTER_CLOCK_HZ", SND_MASTER_CLOCK_HZ, 8_000_000);
    chki("SND_CPU_E_CLOCK_HZ",  SND_CPU_E_CLOCK_HZ,  2_000_000); // master/4
    chki("SND_FM_CLOCK_HZ",     SND_FM_CLOCK_HZ,     3_579_545);

    // Latch NMI/IRQ/reset bit positions (williamssound.cpp:601,602,317)
    chki("SND_LATCH_NMI_BIT",   SND_LATCH_NMI_BIT,   8);
    chki("SND_LATCH_IRQ_BIT",   SND_LATCH_IRQ_BIT,   9);
    chki("SND_LATCH_RESET_BIT", SND_LATCH_RESET_BIT, 10);

    if (errors == 0)
      $display("PASS: narc_sound_pkg smoke — all cited map constants OK");
    else begin
      $display("FAIL: %0d constant mismatch(es)", errors);
      $fatal(1);
    end
    $finish;
  end
endmodule

`default_nettype wire
