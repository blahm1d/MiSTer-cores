// narc_audio_mix.sv -- NARC sound-device normalization and saturating mono mix.
//
// MAME's williams_narc_sound_device is a mono device_mixer_interface:
//   YM2151 ALL_OUTPUTS x0.10 + AD7224 #1 x0.25 + AD7224 #2 x0.25 + HC55516 x0.60.
// The HC55564 RTL emits an UNSIGNED integrator value, not signed PCM.  Treating bit 15 as a
// sign bit creates a full-scale discontinuity at 0x7fff/0x8000.  Track and remove its slow
// DC component, normalize both offset-binary DAC bytes, sum in 32 bits, then saturate once.
`timescale 1ns/1ps
`default_nettype none
module narc_audio_mix (
    input  logic               clk,
    input  logic               rst,
    input  logic signed [15:0] ym_l,
    input  logic signed [15:0] ym_r,
    input  logic         [7:0] dac1_u,
    input  logic         [7:0] dac2_u,
    input  logic        [15:0] cvsd_u,
    output logic signed [15:0] audio_l,
    output logic signed [15:0] audio_r
);
    // HC55564's unipolar resting level follows the encoded stream.  This one-pole tracker
    // removes only sub-audio DC at the 96 MHz system clock.
    logic signed [24:0] cvsd_dc;
    wire signed [16:0] cvsd_x = $signed({1'b0, cvsd_u});
    always_ff @(posedge clk) begin
        if (rst)
            cvsd_dc <= 25'sd0;
        else
            cvsd_dc <= cvsd_dc + (($signed({cvsd_x, 8'd0}) - cvsd_dc) >>> 18);
    end

    wire signed [17:0] cvsd_ac = $signed({cvsd_x[16], cvsd_x}) -
                                  $signed(cvsd_dc[24:8]);
    wire signed [15:0] cvsd_s = (cvsd_ac >  18'sd32767) ?  16'sd32767 :
                                (cvsd_ac < -18'sd32768) ? -16'sd32768 :
                                                                  cvsd_ac[15:0];

    // MAME's AD7224 dac_byte_interface maps unsigned 0..255 across -1..+1.
    wire signed [16:0] dac1_s = ($signed({1'b0, dac1_u}) - 17'sd128) <<< 8;
    wire signed [16:0] dac2_s = ($signed({1'b0, dac2_u}) - 17'sd128) <<< 8;

`ifdef MUT_NARC_AUDIO_OLD_MIX
    // Discriminating mutation: former stereo split, signed-CVSD interpretation, 16-bit
    // intermediate, and wrapping output.  tb_narc_audio_mix must reject this path.
    wire signed [15:0] old_dac1 = $signed({~dac1_u[7], dac1_u[6:0], 8'h00});
    wire signed [15:0] old_dac2 = $signed({~dac2_u[7], dac2_u[6:0], 8'h00});
    wire signed [15:0] old_cvsd = $signed(cvsd_u);
    wire signed [15:0] old_aux =
          (old_dac1 >>> 2) + (old_dac2 >>> 2)
        + (old_cvsd >>> 1) + (old_cvsd >>> 3);
    wire signed [15:0] old_l = (ym_l >>> 3) + (ym_l >>> 5) + old_aux;
    wire signed [15:0] old_r = (ym_r >>> 3) + (ym_r >>> 5) + old_aux;
    always_ff @(posedge clk) begin
        if (rst) begin
            audio_l <= 16'sd0;
            audio_r <= 16'sd0;
        end else begin
            audio_l <= old_l;
            audio_r <= old_r;
        end
    end
`else
    // The NARC board is mono: both YM outputs feed the device mixer before it reaches the
    // machine speaker.  Coefficients are the closest /256 forms of MAME's route gains.
    wire signed [16:0] ym_mono = $signed({ym_l[15], ym_l}) +
                                 $signed({ym_r[15], ym_r});
    logic signed [16:0] ym_mono_q, dac1_s_q, dac2_s_q;
    logic signed [15:0] cvsd_s_q;
    wire signed [31:0] ym_term_d   = ($signed(ym_mono_q) * 32'sd26) >>> 8; // x0.10
    wire signed [31:0] dac1_term_d = ($signed(dac1_s_q)  * 32'sd64) >>> 8; // x0.25
    wire signed [31:0] dac2_term_d = ($signed(dac2_s_q)  * 32'sd64) >>> 8; // x0.25
    wire signed [31:0] cvsd_term_d = ($signed(cvsd_s_q)  * 32'sd154) >>> 8; // x0.60

    // Keep each 96 MHz path deliberately short.  The sound sources update far more slowly
    // than clk, so five clocks (52.1 ns) of fixed mixer latency is inaudible.  The explicit
    // normalization stage is load-bearing: the v7a fit found a real -0.540 ns path from
    // cvsd_dc through subtract/clamp and the x154 coefficient into cvsd_term_q.  Registering
    // all four normalized sources keeps them aligned and splits that path without an SDC
    // exception; the remaining stages avoid a multiply -> four-way add -> saturation cone.
    logic signed [31:0] ym_term_q, dac1_term_q, dac2_term_q, cvsd_term_q;
    logic signed [31:0] music_sum_q, dac_sum_q, mix_q;

    always_ff @(posedge clk) begin
        if (rst) begin
            ym_mono_q   <= 17'sd0;
            dac1_s_q    <= 17'sd0;
            dac2_s_q    <= 17'sd0;
            cvsd_s_q    <= 16'sd0;
            ym_term_q   <= 32'sd0;
            dac1_term_q <= 32'sd0;
            dac2_term_q <= 32'sd0;
            cvsd_term_q <= 32'sd0;
            music_sum_q <= 32'sd0;
            dac_sum_q   <= 32'sd0;
            mix_q       <= 32'sd0;
            audio_l <= 16'sd0;
            audio_r <= 16'sd0;
        end else begin
            ym_mono_q   <= ym_mono;
            dac1_s_q    <= dac1_s;
            dac2_s_q    <= dac2_s;
            cvsd_s_q    <= cvsd_s;
            ym_term_q   <= ym_term_d;
            dac1_term_q <= dac1_term_d;
            dac2_term_q <= dac2_term_d;
            cvsd_term_q <= cvsd_term_d;
            music_sum_q <= ym_term_q + cvsd_term_q;
            dac_sum_q   <= dac1_term_q + dac2_term_q;
            mix_q       <= music_sum_q + dac_sum_q;
            audio_l <= (mix_q >  32'sd32767) ?  16'sd32767 :
                       (mix_q < -32'sd32768) ? -16'sd32768 : mix_q[15:0];
            audio_r <= (mix_q >  32'sd32767) ?  16'sd32767 :
                       (mix_q < -32'sd32768) ? -16'sd32768 : mix_q[15:0];
        end
    end
`endif
endmodule
`default_nettype wire
