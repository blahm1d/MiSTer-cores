// NARC YM2151 clock-enable generator.
//
// MAME's board definition uses a dedicated 3.579545 MHz crystal.  The previous
// inherited Williams donor divider generated 12 MHz * 152/512 = 3.562500 MHz,
// making every FM note and YM timer 0.476% flat.  This rational accumulator
// emits exactly YM_HZ enables in every CLK_HZ source clocks, while keeping all
// sound logic in the 96 MHz system-clock domain.
//
// JT51's `jt51_sh` reset is an output mux, not a flop clear: its own source
// requires clock enables to continue for at least the longest (32-stage) shift
// chain while reset is asserted.  The shipped Williams CVSD donor therefore
// leaves its YM accumulator free-running during power-on reset.  Do the same
// here, and extend the NARC sound-board reset until 32 cen_fm_p1 pulses have
// crossed it.  Release immediately after a p1 pulse so the next JT51 capture is
// more than fifty clk_sys cycles away.
`timescale 1ns/1ps
`default_nettype none
module narc_ym_clock_en #(
    parameter integer CLK_HZ = 96_000_000,
    parameter integer YM_HZ  = 3_579_545,
    parameter integer ACC_W  = $clog2(CLK_HZ)
) (
    input  logic clk,
    input  logic rst,
    output logic cen_fm,
    output logic cen_fm_p1,
    output logic sound_rst
);
    localparam integer RESET_P1_PULSES = 32;
    localparam integer RESET_CNT_W = $clog2(RESET_P1_PULSES + 1);

    logic [ACC_W-1:0] phase;
    logic             half_phase;
    logic             rst_d;
    logic [RESET_CNT_W-1:0] reset_p1_count;
`ifdef MUT_NARC_YM_DONOR
    // Discriminating mutation: the inherited 12 MHz * 152/512 donor rate.
    localparam integer EFFECTIVE_YM_HZ = 3_562_500;
`else
    localparam integer EFFECTIVE_YM_HZ = YM_HZ;
`endif
    wire  [ACC_W:0] phase_sum = {1'b0, phase} + EFFECTIVE_YM_HZ;

    initial begin
        phase          = '0;
        half_phase     = 1'b0;
        rst_d          = 1'b1;
        cen_fm         = 1'b0;
        cen_fm_p1      = 1'b0;
        sound_rst      = 1'b1;
        reset_p1_count = '0;
    end

    always_ff @(posedge clk) begin
        rst_d      <= rst;
        cen_fm     <= 1'b0;
        cen_fm_p1  <= 1'b0;

        // Rephase once on a new reset assertion, then keep emitting the exact
        // cadence throughout the rest of reset so JT51's shift chains flush.
        if (rst && !rst_d) begin
            phase      <= '0;
            half_phase <= 1'b0;
        end else begin
            if (phase_sum >= CLK_HZ) begin
                phase      <= phase_sum - CLK_HZ;
                cen_fm     <= 1'b1;
                cen_fm_p1  <= half_phase;
                half_phase <= ~half_phase;
            end else begin
                phase <= phase_sum[ACC_W-1:0];
            end
        end

        // A fresh reset starts a new 32-p1 flush.  While reset remains high the
        // counter saturates but sound_rst cannot release.  Once the request is
        // low, release only on a p1 pulse; JT51 sees the old asserted reset on
        // that edge and cannot capture again until the following p1 cadence.
        // P0034 (MEASURED ON THE CABINET 2026-07-30, DIAG row 2 = 9 clocks):
        // the release counter used to advance WHILE rst was still asserted, so a
        // real download reset (SECONDS long) left it saturated and sound_rst
        // dropped on the FIRST cen_fm_p1 after rst fell -- 9 clocks measured on
        // silicon, ~43 in sim, versus the ~18 us / 32-pulse extension this block
        // is documented (and was gated) to provide. Every prior TB released rst
        // after 3 clocks, so the counter was never saturated and the intended
        // path was the only one ever exercised: tb_narc_ym_clock_en_longrst
        // reproduces the divergence.
        //
        // Holding the count at zero for the whole of rst makes the 32-pulse
        // flush start when rst FALLS, so the extension is delivered on hardware
        // as designed. JT51's own flush requirement is unaffected -- the enables
        // free-run during reset (see the accumulator above), so a long reset
        // already supplies far more than 32 enabled pulses while reset is held.
        // What this restores is the BOOT STAGGER: the sound board now leaves
        // reset ~18 us after the core instead of alongside it, keeping the 6809s'
        // first ROM fetches out of the post-release fetch storm.
        if (rst) begin
            sound_rst      <= 1'b1;
            reset_p1_count <= '0;
        end else begin
            if (sound_rst && cen_fm_p1 &&
                reset_p1_count < RESET_P1_PULSES)
                reset_p1_count <= reset_p1_count + 1'b1;

            if (rst)
                sound_rst <= 1'b1;
            else if (sound_rst && cen_fm_p1 &&
                     reset_p1_count >= RESET_P1_PULSES-1)
                sound_rst <= 1'b0;
        end
    end
endmodule
`default_nettype wire
