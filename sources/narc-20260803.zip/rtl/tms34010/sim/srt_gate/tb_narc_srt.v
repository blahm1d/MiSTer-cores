// -----------------------------------------------------------------------------
// tb_narc_srt.v  --  CORE-2 SRT (shift-register transfer) acceptance gate.
//
// Drives the REAL tms34010 core (sv2v-converted to Verilog for Icarus) through
// the discriminating vector goldens/narc_srt_vector.json:
//
//   DPYCTL.SRT = 0x0800 ; A2 = 512<<3 ; A1 = 1536<<3 ; A4 = 0x1234
//   PIXT *A2,A4   (load : VRAM row @A2>>3  -> shift register)
//   PIXT A4,*A1   (store: shift register   -> VRAM row @A1>>3)
//
// Expected (MAME 0.280, midyunit_v.cpp:171-180, tms34010.cpp:941):
//   dest row (word 1536..2559) == source row (word 512..1535), all 1024 words;
//   source row unchanged. The register operand A4 is a don't-care on the store.
//
// The core executes a real instruction stream (MOVI/SETF/MOVE-to-IO/PIXT) built
// in the memory image below; nothing is forced. Word index on the bit-addressed
// bus is bit_addr>>4; MAME's shift-register word index is pointer>>3, so the SRT
// FSM presents (pointer>>3 + i)<<4. I/O-space accesses (DPYCTL/PSIZE writes) are
// acked but NOT stored in the array (the core's io_regs owns them) so they never
// alias the program/VRAM image.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
`default_nettype none

module srt_mem #(
  parameter integer DEPTH = 4096            // 12-bit word index (addr[15:4])
)(
  input  wire        clk,
  input  wire        rst,
  input  wire        mem_req,
  input  wire        mem_we,
  input  wire        mem_srt,
  input  wire [31:0] mem_addr,
  input  wire [5:0]  mem_size,
  input  wire [31:0] mem_wdata,
  output reg  [31:0] mem_rdata,
  output reg         mem_ack
);
  reg [15:0] mem [0:DEPTH-1];
  reg [15:0] shiftreg [0:1023];

  localparam ST_IDLE = 1'b0, ST_ACK = 1'b1;
  reg        state;
  reg [31:0] a_addr, a_wdata;
  reg        a_we, a_srt;
  reg [5:0]  a_size;

  wire        is_io = (a_addr[31:30] == 2'b11) && (a_addr[29:9] == 21'd0);
  wire [11:0] widx  = a_addr[15:4];
  wire [11:0] rawidx = a_addr[14:3];
  wire [3:0]  boff  = a_addr[3:0];

  reg [15:0] r0, r1, r2;
  reg [47:0] win, rmask, smask, merged;
  reg [6:0]  lastb;

  always @(posedge clk) begin
    if (rst) begin
      state     <= ST_IDLE;
      mem_ack   <= 1'b0;
      mem_rdata <= 32'h0;
    end else begin
      case (state)
        ST_IDLE: begin
          mem_ack <= 1'b0;
          if (mem_req && !mem_ack) begin
            a_addr  <= mem_addr;
            a_we    <= mem_we;
            a_srt   <= mem_srt;
            a_wdata <= mem_wdata;
            a_size  <= mem_size;
            state   <= ST_ACK;
          end
        end
        ST_ACK: begin
          mem_ack <= 1'b1;
          if (a_srt) begin
            // External SRT command: MAME copies 1024 RAW uint16 framebuffer
            // entries at bit_address>>3. Both bytes are preserved; store data
            // is ignored and the buffer persists between the two commands.
            if (a_we) begin
              for (integer si=0; si<1024; si=si+1)
                if ((rawidx+si) < DEPTH) mem[rawidx+si] <= shiftreg[si];
              mem_rdata <= 32'h0;
            end else begin
              for (integer si=0; si<1024; si=si+1)
                shiftreg[si] <= ((rawidx+si) < DEPTH) ? mem[rawidx+si] : 16'h0;
              mem_rdata <= {16'h0, mem[rawidx]};
            end
          end else if (is_io) begin
            // I/O space: the core's io_regs owns the value; just ack.
            mem_rdata <= 32'h0;
          end else begin
            r0    = (widx     < DEPTH) ? mem[widx]     : 16'h0;
            r1    = (widx + 1 < DEPTH) ? mem[widx + 1] : 16'h0;
            r2    = (widx + 2 < DEPTH) ? mem[widx + 2] : 16'h0;
            win   = {r2, r1, r0};
            rmask = (48'd1 << a_size) - 48'd1;
            smask = rmask << boff;
            lastb = boff + a_size - 7'd1;
            if (a_we) begin
              merged = (win & ~smask) | (({16'h0, a_wdata} << boff) & smask);
              if (widx     < DEPTH)                       mem[widx]     <= merged[15:0];
              if (lastb >= 16 && widx + 1 < DEPTH)        mem[widx + 1] <= merged[31:16];
              if (lastb >= 32 && widx + 2 < DEPTH)        mem[widx + 2] <= merged[47:32];
              mem_rdata <= 32'h0;
            end else begin
              mem_rdata <= (win >> boff) & rmask;
            end
          end
          state <= ST_IDLE;
        end
        default: begin state <= ST_IDLE; mem_ack <= 1'b0; end
      endcase
    end
  end
endmodule

module tb_narc_srt;
  `include "srt_params.vh"

  reg clk = 1'b0;
  reg rst = 1'b1;
  always #5 clk = ~clk;

  wire        mem_req, mem_we;
  wire [31:0] mem_addr;
  wire [5:0]  mem_size;
  wire [31:0] mem_wdata, mem_rdata;
  wire        mem_ack;
  wire [5:0]  state_o;
  wire [31:0] pc_o;
  wire [15:0] instr_word_o;
  wire        illegal_o;
  wire [15:0] dpystrt_o;

  wire mem_srt;
  tms34010_core #(.EXTERNAL_SRT(1'b1)) u_core (
    .clk(clk), .ce_cpu(1'b1), .ce_pix(1'b0), .rst(rst),
    .mem_req(mem_req), .mem_we(mem_we), .mem_addr(mem_addr), .mem_size(mem_size),
    .mem_wdata(mem_wdata), .mem_srt(mem_srt),
    .mem_rdata(mem_rdata), .mem_ack(mem_ack),
    .state_o(state_o), .pc_o(pc_o), .instr_word_o(instr_word_o),
    .illegal_opcode_o(illegal_o), .dpystrt_o(dpystrt_o), .lint1_in(1'b0)
  );

  srt_mem #(.DEPTH(4096)) u_mem (
    .clk(clk), .rst(rst),
    .mem_req(mem_req), .mem_we(mem_we), .mem_srt(mem_srt),
    .mem_addr(mem_addr), .mem_size(mem_size),
    .mem_wdata(mem_wdata), .mem_rdata(mem_rdata), .mem_ack(mem_ack)
  );

  // Golden source row (1024 words), loaded from the vector-derived hex.
  reg [15:0] src [0:1023];

  integer i, p, failures, diffs;

  // --- opcode encoders ---
  function [15:0] movi_il;  input [3:0] idx; movi_il = 16'h09E0 | idx; endfunction
  function [15:0] store_abs;input [3:0] rs;  store_abs = 16'h0580 | rs; endfunction

  task put_movi;                       // MOVI Aidx, imm32  (immediate long)
    input [3:0] idx; input [31:0] imm;
    begin
      u_mem.mem[p] = movi_il(idx);        p = p + 1;
      u_mem.mem[p] = imm[15:0];           p = p + 1;
      u_mem.mem[p] = imm[31:16];          p = p + 1;
    end
  endtask
  task put_store_abs;                  // MOVE A_rs, @addr32   (FS from ST = 16)
    input [3:0] rs; input [31:0] addr;
    begin
      u_mem.mem[p] = store_abs(rs);       p = p + 1;
      u_mem.mem[p] = addr[15:0];          p = p + 1;
      u_mem.mem[p] = addr[31:16];         p = p + 1;
    end
  endtask
  task put_word; input [15:0] w; begin u_mem.mem[p] = w; p = p + 1; end endtask

  initial begin : main
    failures = 0; diffs = 0;

    for (i = 0; i < 4096; i = i + 1) u_mem.mem[i] = 16'h0000;
    // Golden source row.
    $readmemh("srt_src.hex", src);
    for (i = 0; i < SRT_ROW; i = i + 1) begin
      u_mem.mem[SRC_WIDX + i] = src[i];   // source row seeded
      u_mem.mem[DST_WIDX + i] = 16'h0000; // dest row cleared
    end
    // Reset vector 0xFFFFFFE0 -> word 4094/4095 (=0) -> PC = 0.
    u_mem.mem[4094] = 16'h0000;
    u_mem.mem[4095] = 16'h0000;

    // --- program @ word 0 ---
    p = 0;
    put_word(16'h0550);                          // SETF FS0=16, FE=0 (for MOVE-to-IO)
    put_movi(4'd0, 32'h0000_0008);               // A0 = 8  (PSIZE)
    put_store_abs(4'd0, 32'hC000_0150);          // PSIZE  = 8
    put_movi(4'd0, DPYCTL_V);                     // A0 = 0x0800 (SRT)
    put_store_abs(4'd0, 32'hC000_0080);          // DPYCTL = SRT on
    put_movi(4'd2, A2_SRC);                       // A2 = source pointer (512<<3)
    put_movi(4'd1, A1_DST);                       // A1 = dest   pointer (1536<<3)
    put_movi(4'd4, A4_REG);                       // A4 = 0x1234 (don't-care on store)
    put_word(16'hFA44);                           // PIXT *A2,A4  (SRT load)
    put_word(16'hF881);                           // PIXT A4,*A1  (SRT store)
    put_word(16'hC0FF);                           // JR $ (self-loop terminator)

    repeat (3) @(posedge clk);
    rst = 1'b0;

    // Two 1024-word SRT streams (~a few cycles/word) + program: run generously.
    repeat (40000) @(posedge clk);
    #1;

    // --- checks ---
    if (illegal_o !== 1'b0) begin
      $display("TEST_RESULT: FAIL: illegal_opcode asserted during SRT program");
      failures = failures + 1;
    end
    // dest row == source row, all 1024 words
    for (i = 0; i < SRT_ROW; i = i + 1) begin
      if (u_mem.mem[DST_WIDX + i] !== src[i]) begin
        if (diffs < 8)
          $display("  dst[%0d] (word %0d) = %04h, expected %04h",
                   i, DST_WIDX + i, u_mem.mem[DST_WIDX + i], src[i]);
        diffs = diffs + 1;
      end
    end
    if (diffs != 0) begin
      $display("TEST_RESULT: FAIL: SRT dest row mismatch: %0d/%0d words differ", diffs, SRT_ROW);
      failures = failures + 1;
    end
    // source row unchanged
    for (i = 0; i < SRT_ROW; i = i + 1) begin
      if (u_mem.mem[SRC_WIDX + i] !== src[i]) begin
        $display("TEST_RESULT: FAIL: source word %0d corrupted: %04h != %04h",
                 SRC_WIDX + i, u_mem.mem[SRC_WIDX + i], src[i]);
        failures = failures + 1;
        i = SRT_ROW;   // report once
      end
    end

    if (failures == 0)
      $display("TEST_RESULT: PASS (SRT: 1024/1024 dest words == source, source preserved)");
    else
      $display("TEST_RESULT: FAIL: %0d check group(s) failed", failures);
    $finish;
  end

  initial begin : watchdog
    #6_000_000;
    $display("TEST_RESULT: FAIL: tb_narc_srt hard timeout (SRT stream never completed)");
    $finish;
  end
endmodule
`default_nettype wire
