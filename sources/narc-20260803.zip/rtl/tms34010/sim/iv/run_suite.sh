#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# Licence-free TMS34010 instruction-suite runner (sv2v + Icarus Verilog).
#
# scripts/sim.sh runs ONE testbench through Questa, which on this box is
# nodelocked to a single concurrent vsim and contended across the sibling core
# sessions. This runner reproduces the same suite with iverilog: every
# sim/tb/*.sv is sv2v-converted together with the real core + the behavioural
# memory model, compiled, run, and graded on "TEST_RESULT: PASS" — the exact
# same pass criterion scripts/sim.sh greps for.
#
# Usage:
#   sim/iv/run_suite.sh                 # whole suite
#   sim/iv/run_suite.sh tb_move_off_ni  # one or more named TBs
#
# Exit 0 iff every testbench printed TEST_RESULT: PASS.
# -----------------------------------------------------------------------------
set -uo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
CORE="$(cd "$HERE/../.." && pwd)"          # rtl/tms34010
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
export PATH="/c/iverilog/bin:$PATH"

command -v iverilog >/dev/null || { echo "run_suite.sh: iverilog not on PATH" >&2; exit 69; }
[ -x "$SV2V" ] || { echo "run_suite.sh: sv2v not found at $SV2V" >&2; exit 69; }

OUT="$HERE/work"
SAN="$OUT/src"
mkdir -p "$OUT" "$SAN"

# --- toolchain shims (cosmetic only; no check is weakened) -------------------
# 1) sv2v v0.0.13 on Windows cannot ENCODE non-ASCII characters on its output
#    handle ("cannot encode character '\8594'" = the U+2192 arrow used in some
#    $display strings), so every source is copied through an ASCII filter.
# 2) Icarus does not implement the enum `.name()` method. It appears only as a
#    $display argument in 4 testbenches; the copy substitutes a literal "?" so
#    the diagnostic still prints and the actual assertions are untouched.
# Both rewrites act on a COPY under sim/iv/work/src — the repo sources and the
# Questa flow (scripts/sim.sh) are unaffected.
sanitize() {   # $1 = source file -> echoes the sanitized copy's path
  local src="$1" dst="$SAN/$(basename "$1")"
  perl -pe 's/[^\x00-\x7F]/?/g; s/\b[A-Za-z_][A-Za-z_0-9]*\.name\(\)/"?"/g' \
       "$src" > "$dst"
  echo "$dst"
}

# Core sources: package first, then the rest of rtl/, then the sim memory model.
RAW_SRC=( "$CORE/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do RAW_SRC+=("$f"); done \
  < <(find "$CORE/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
RAW_SRC+=( "$CORE/sim/models/sim_memory_model.sv" )
CORE_SRC=()
for f in "${RAW_SRC[@]}"; do CORE_SRC+=( "$(sanitize "$f")" ); done

if [ $# -gt 0 ]; then
  TBS=("$@")
else
  TBS=()
  while IFS= read -r f; do TBS+=("$(basename "$f" .sv)"); done \
    < <(find "$CORE/sim/tb" -name 'tb_*.sv' | sort)
fi

pass=0; fail=0; failed=()
for tb in "${TBS[@]}"; do
  src="$CORE/sim/tb/${tb}.sv"
  if [ ! -f "$src" ]; then
    echo "MISSING $tb"; fail=$((fail+1)); failed+=("$tb(missing)"); continue
  fi
  src="$(sanitize "$src")"
  if ! "$SV2V" -w "$OUT/$tb.v" "${CORE_SRC[@]}" "$src" 2>"$OUT/$tb.sv2v.err"; then
    echo "SV2V-FAIL $tb"; fail=$((fail+1)); failed+=("$tb(sv2v)"); continue
  fi
  # sv2v can report success on stdout-encoding failures; require real output.
  if [ ! -s "$OUT/$tb.v" ] || [ -s "$OUT/$tb.sv2v.err" ]; then
    echo "SV2V-FAIL $tb"; sed 's/^/      /' "$OUT/$tb.sv2v.err" | head -3
    fail=$((fail+1)); failed+=("$tb(sv2v)"); continue
  fi
  if ! iverilog -g2012 -s "$tb" -o "$OUT/$tb.vvp" "$OUT/$tb.v" \
        > "$OUT/$tb.iv.log" 2>&1; then
    echo "COMPILE-FAIL $tb"; fail=$((fail+1)); failed+=("$tb(compile)"); continue
  fi
  ( cd "$OUT" && vvp "$OUT/$tb.vvp" ) > "$OUT/$tb.log" 2>&1
  if grep -q "TEST_RESULT: PASS" "$OUT/$tb.log"; then
    echo "PASS $tb"; pass=$((pass+1))
  else
    echo "FAIL $tb"; fail=$((fail+1)); failed+=("$tb")
    grep -m3 -iE "TEST_RESULT|FAIL:" "$OUT/$tb.log" | sed 's/^/      /'
  fi
done

echo "-----------------------------------------------------------"
echo "SUITE: $pass/$((pass+fail)) PASS"
if [ $fail -ne 0 ]; then
  printf 'FAILED: %s\n' "${failed[*]}"
  exit 1
fi
exit 0
