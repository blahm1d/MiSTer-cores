// stv_vram_ddr_top.sv — VRAM-in-DDR3 subsystem (P1). Drop-in for vram_sdram_top: same
// accessor ports, but VRAM lives in the HPS DDR3 (f2h_sdram1) — freeing the SDRAM port so
// the scanout no longer starves the CPU.
//
// INCREMENT 2 (this file): the scanout is now served by a ROW-BURST CACHE (the bandwidth win).
// yunit_scanline (the proven W3 double-buffer) is UNCHANGED and still issues one scan_req per
// column; on the first miss of a row the cache bursts the WHOLE row (128 beats = 512 entries)
// from DDR3 in ONE transaction, then serves every column of that row from a 128x64b BRAM at a
// ~2-clk hit. So a line costs ~1 burst instead of 512 single reads.
//
// Two requesters share the single DDR3 agent (single-outstanding), muxed by a grant-held L2
// arbiter (scanout burst = priority; it is real-time but rare — once per row):
//   A = the proven vram_sdram_top (CPU field RMW + blitter fb + autoerase) with its scanout
//       port tied off; its single 16-bit sd_* word port is translated to single-beat DDR3
//       accesses via the 4:1 packing (entry>>2 = beat, entry[1:0] = lane, 2-byte lane BE).
//   B = the scanout row cache: burst-fills a row, serves scan_req from cache.
//
// 4:1 packing: entry = (row<<9)|col ; beat = entry>>2 ; lane = entry[1:0]. A 512-entry row =
// 128 contiguous beats at beat_base = row<<7. Reset: accessor engines + A/B/L2 on core rst;
// the persistent DDR agent on sdram_por (P0022).
`default_nettype none
module stv_vram_ddr_top #(
    parameter int VRAMW = 32'h40000,
    parameter [28:0] VRAM_DDR_BASE = 29'h6400000,
    // NARC-only performance option. On a tagged own-write-shadow hit, a D-side
    // partial beat already has an exact newest merge base and need not issue a
    // redundant DDR read first. Default OFF preserves every donor/Y-unit build.
    // P0048: base-relative row where MAME's erase band STARTS. Negative = disabled, which is
    // the donor/Y-unit behaviour and every legacy instantiation. NARC passes 80: the gospel
    // table (NARC.ASM:2768 DIRQ2 at SCOREINT = 80+1BH = 107, SYS.INC:94-96, VBL_OFF 27) puts
    // the first erased display row at 80, and MAME's autoerase_line(rowaddr-1) confirms it.
    parameter int ERASE_FIRST_REL = -1,
    // Bound on how far back the arm-edge replay may reach. The engine already tolerates
    // lagging the beam (the beam-lock gate bounds it at 24 rows), so a replay inside that
    // window cannot run ahead of the beam and cannot become an unbounded catch-up burst.
    parameter int ERASE_ARM_CATCHUP_MAX = 24,
    parameter bit D_SHADOW_RMW_BYPASS = 1'b0,
    // NARC-only masked-beat ingress FIFO.  It decouples pixel acceptance from
    // DDR flush latency while preserving the existing D-lane merge/coherency
    // machinery.  Default OFF keeps donor/Y-unit behavior unchanged.
    parameter bit D_WRITE_FIFO = 1'b0,
    // NARC-only compact front end for D_WRITE_FIFO. Four 16-bit pixels sharing
    // a DDR beat are journaled as one masked 84-bit record. The journal is
    // inside this owner so CPU and autoerase cannot overtake accepted pixels.
    // Scanout remains real-time and observes the replay through the existing
    // BSNOOP/write-through path; the NARC gate requires a complete drain in
    // less than one frame. Default OFF preserves every donor instance.
    parameter bit D_BEAT_FIFO = 1'b0,
    parameter int D_BEAT_FIFO_DEPTH = 16384,
    // Number of DISPLAYED VRAM rows -- the range the beam-locked C erase engine may target.
    // This is a PER-BOARD raster constant, not a shared one:
    //   Y-unit / Smash T.V.  512x256  -> 256   (the default; every donor build unchanged)
    //   Z-unit / NARC        512x400  -> 400   (zunit_pkg SCR_VIS_H, midyunit.cpp:1265
    //                                           set_raw(..., 433,27,427) => 427-27 = 400)
    // It was previously HARD-CODED as the bit-8 test `!trig_nr[8]` plus the 9'd255 wrap
    // constants below -- i.e. the donor's 256 rows baked into a shared module. On NARC that
    // silently dropped every erase goal for displayed rows 256..399: the bottom 144 of 400
    // rows were never autoerased on the cabinet. Gated by sim/tb_zunit_beamerase.sv
    // (mutation -DMUT_BEAMERASE_DONOR_ROWS restores the cap and MUST turn that gate red).
    parameter int ERASE_ROWS = 256,
    // ---- C-lane bounded-progress floor (anti-starvation) -------------------------------
    // The L2 ladder below is STRICT FIXED PRIORITY: B > A > D > C, with C dead last and NO
    // aging. Its design note argues C keeps up "between D's 1-beat flushes" -- that argument
    // covers D's demand and says NOTHING about sustained A (CPU) demand. MEASURED on NARC
    // (sim/tb_zunit_beamerase.sv +cpu=1): with the CPU field lane driven continuously the erase
    // engine issues 132 of the required 320 rows/frame and the continuity gate goes RED, while
    // the same build UNLOADED issues 320/320 and passes. Throughput is also wildly
    // NON-MONOTONIC in CPU request period -- the signature of an unfair arbiter, not of a
    // bandwidth budget.
    // The codebase has already been bitten by this exact class once, in the other direction:
    // A needed an explicit park against D or "the sustained fb stream would never empty the
    // combiner and A would starve (the contention-gate deadlock UMK3 caught 2026-07-10)".
    // That fix gave A a floor and left C with none.
    // C_FAIR raises C above A and D (never above B, which is hard real-time scanout) once it
    // has waited C_FAIR_AGE arbitration cycles. DEFAULT OFF so the donor / Y-unit ladder is
    // bit-identical. NARC currently keeps it OFF too: C_FAIR=1 repairs C progress but produced
    // one un-root-caused ~18 ms CPU stall in the contention gate. Mutation -DMUT_CFAIR_OFF
    // forces the unfair ladder for the opt-in probe and proves that gate discriminates.
    parameter bit C_FAIR     = 1'b0,
    parameter int C_FAIR_AGE = 192
)(
    input  logic         clk,
    input  logic         rst,
    input  logic         sdram_por,
    // CPU field access
    input  logic         req,
    input  logic         we,
    input  logic         srt,       // raw 1024-entry shift-register command
    input  logic [27:0]  widx,
    input  logic [3:0]   boff,
    input  logic [5:0]   sz,
    input  logic [31:0]  wd,
    input  logic         videobank,
    input  logic [15:0]  dma_palette,
    output logic [31:0]  rdata,
    output logic         done,
    // blitter framebuffer write
    input  logic         fb_we,
    input  logic [17:0]  fb_addr,
    input  logic [15:0]  fb_wdata,
    output logic         fb_ack,
    input  logic         fb_flush,    // cont.24 done-flush: the blit finished (all pixels accepted) --
                                      // drain the combiner + run-buffer NOW, overlapping the DMA's pace
                                      // wait, instead of the 2x 64-clk idle timeouts (~130clk dead tail
                                      // on every done-serialized blit IRQ).
    output logic         fb_busy,     // D-lane drain status (combiner holds pixels OR flush FSM active).
                                      // Y-unit DMA may use this as a commit gate; NARC observes it
                                      // while self-pacing from fb_ack and its fixed completion delay.
    // BEAM-LOCKED AUTOERASE (C engine). Replaces the old bulk erase_start/erase_row0/erase_lines
    // ports (that pulse-driven bulk sweep is now dead on the DDR3 path; u_acc's internal bulk engine
    // is tied OFF below). erase_en is the ENABLED-sense autoerase flop (yunit_mem `autoerase`,
    // control_w bit4 active-low). The engine snoops the existing scan_addr for the row-change
    // trigger and erases (displayed_row - 1) one row behind the beam, MAME midyunit_v.cpp:554
    // autoerase_line(rowaddr-1). erase_busy now = the C engine's busy.
    input  logic         erase_en,
    output logic         erase_busy,
    // P0033 BEAM-LOCKED AUTOERASE, BASE-RELATIVE + VISIBLE-ONLY. Both are OPTIONAL: every
    // donor / Y-unit / legacy-TB instantiation leaves them unconnected and gets exactly the
    // previous absolute-row-0, always-armed behavior (z -> 0 here and GND after synthesis).
    //   disp_base  = the frame-latched first displayed VRAM row, (DPYSTRT ^ 0xFFFC) >> 4
    //                (zunit_video_top.sv disp_row0_q, P0031). MAME: tms34010.cpp:1035/1152.
    //   scan_blank = raster vertical-blank level (zunit_video_top vblank_i). MAME calls
    //                autoerase_line ONLY from scanline_update (midyunit_v.cpp:554), so no
    //                erase may be triggered while blanked.
    input  logic [8:0]   disp_base,
    input  logic         scan_blank,
    // video scanout read
    input  logic         scan_req,
    input  logic [17:0]  scan_addr,
    output logic [15:0]  scan_data,
    output logic         scan_ack,
    // DDR3 Avalon master
    output logic [28:0]  ddram_addr,
    output logic [ 7:0]  ddram_burstcnt,
    output logic         ddram_rd,
    output logic         ddram_we,
    output logic [63:0]  ddram_din,
    output logic [ 7:0]  ddram_be,
    input  logic         ddram_busy,
    input  logic [63:0]  ddram_dout,
    input  logic         ddram_dout_ready
);
    // Open on legacy direct-instantiation TBs means ordinary CPU access.
    wire srt_i = (srt === 1'b1);
    function automatic logic [7:0] lane_be(input [1:0] l);
        case (l) 2'd0: lane_be=8'h03; 2'd1: lane_be=8'h0C; 2'd2: lane_be=8'h30; default: lane_be=8'hC0; endcase
    endfunction

    // --- FORWARD DECLARATIONS (hoisted for Questa 25.1std declare-before-use, vlog-2730). These
    // are DRIVEN in the B/C/D blocks below but REFERENCED earlier by the A-side coherency snoops/
    // write-throughs. Declaring them here is harmless to iverilog/sv2v (which allow the forward
    // ref) and required by Questa; the driving logic stays in each block. (Same pattern as the
    // core's P0002 hoist.)
    logic [8:0] rc_row;  logic rc_valid;              // B scanout row-cache tag/valid
    // BSNOOP: NARC, like Smash TV, races the beam while the framebuffer write stream can
    // remain continuously active.  A scanout miss therefore cannot wait for the whole write
    // path to drain, nor can it proof-poll a publication-dirty page indefinitely.  Fill the
    // requested row immediately and overlay the returned DDR beat with every newer value
    // still resident in this module's write structures.  MUT_NO_BSNOOP restores the former
    // drain + proof-poll behavior for the discriminating regression.
`ifdef MUT_NO_BSNOOP
    localparam bit BSNOOP = 1'b0;
`else
    localparam bit BSNOOP = 1'b1;
`endif
    logic [63:0] bfill_merged;
    logic       c_start, c_wr;  logic [25:0] c_addr;  // C erase-engine L2 request
    logic [15:0] c_wait;                            // cycles C has asked without a grant
    logic        c_urgent;                          // C_FAIR: C has waited long enough to outrank A/D
    logic       d_start, d_wr;  logic [25:0] d_addr;  // D fb-combine L2 request
    logic       d_is_burst;                           // current D flush is a multi-beat run burst
    logic       d_busy;                               // D owns/holds work (used by A admission)
    logic       b_fill_lock;                          // B drain + atomic row-fill admission lock
    logic       b_bus_lock;                           // B_REQ/B_FILL: L2 grants B only
    logic [2:0] ls;                                    // L2 state (B_DRAIN ownership check)
    logic       tst_busy;                              // persistent agent busy (same check)
    logic       d_add;  logic [15:0] d_add_beat;       // pulse: a full beat was ADDED to the run-buffer
                                                       // (on-add coherency -> A snoop uses these below)
    // NARC-only framebuffer ingress FIFO signals are declared here because
    // the A/B/C ownership machines precede the D implementation below.
    logic       fbq_busy, fbq_empty, fbq_push, fbq_pop;
    logic       fbq_row_conflict;
    logic       b_drain_is_hit, b_fifo_fenced;
    logic       beat_pending, beat_busy;
    logic       beat_fb_we, beat_fb_ack, beat_fb_flush;
    logic [17:0] beat_fb_addr;
    logic [15:0] beat_fb_wdata;
    // E: NARC raw SRT burst engine. One command moves 1024 raw 16-bit
    // framebuffer entries (256 packed DDR beats), preserving pixel+palette.
    logic       e_start, e_wr;
    logic [25:0] e_addr;
    logic [7:0] e_burstlen;
    logic       e_done, e_rd_valid;
    logic [63:0] e_rdata;
    logic       srt_busy, srt_done, srt_store_q;
    logic [31:0] srt_rdata;
    logic       srt_claim;
    wire        srt_store_atomic, srt_invalidate_evt;

    // ================= A: proven accessors (scanout tied off) -> single 16b sd_* port =========
    logic [20:0] sd_addr;  logic [15:0] sd_din;  logic [1:0] sd_be;  logic sd_rd, sd_wr;
    logic [15:0] sd_dout;  logic sd_ack;
    // v7g: this instance already hard-ties fb_we / erase_start / scan_req to constants
    // below, so all three engines are UNREACHABLE here -- but Quartus 17 kept their
    // unreset counters alive and let the dead {er_row,er_x} -> sd_addr fanin contend for
    // placement in the a_addr mux (105 of v7f's 140 rejected setup endpoints). Eliding
    // them is behavior-preserving BY CONSTRUCTION: the ports they serve are constants on
    // this path. u_acc is CPU-field-only here; the C engine does erase, the D combiner
    // does fb writes, and B does scanout. Defaults stay ON, so every other
    // vram_sdram_top instantiation (yunit_mem, zunit_mem, SDR fallback) is unchanged.
    logic [31:0] acc_rdata;
    logic        acc_done;
    vram_sdram_top #(.VRAMW(VRAMW), .SD_AW(21), .VRAM_BASE(21'd0),
                     .HAS_ERASE(1'b0), .HAS_FBW(1'b0), .HAS_SCAN(1'b0)) u_acc (
        .clk(clk), .rst(rst),
        .req(req && !srt_i), .we(we), .srt(1'b0),
        .widx(widx), .boff(boff), .sz(sz), .wd(wd),
        .videobank(videobank), .dma_palette(dma_palette), .rdata(acc_rdata), .done(acc_done),
        // W-THRU2(D): fb bypasses u_acc's sd path entirely -> the D beat write-combiner below.
        // Frees the sd channel for CPU-only field ops (the second bandwidth win). fb_ack is now
        // driven by the D combiner. Tie u_acc's fb port OFF.
        .fb_we(1'b0), .fb_addr(18'd0), .fb_wdata(16'd0), .fb_ack(),
        // Bulk erase engine inside u_acc is DEAD on the DDR3 path (the beam-locked C engine below
        // replaces it). Tie erase_start OFF; its erase_busy is left unconnected (erase_busy is now
        // driven by the C engine). erase_row0/erase_lines are don't-care with erase_start=0.
        .erase_start(1'b0), .erase_row0(9'd0), .erase_lines(10'd0), .erase_busy(),
        .scan_req(1'b0), .scan_addr(18'd0), .scan_data(), .scan_ack(),
        .sd_addr(sd_addr), .sd_din(sd_din), .sd_be(sd_be), .sd_rd(sd_rd), .sd_wr(sd_wr),
        .sd_dout(sd_dout), .sd_ack(sd_ack) );
    assign done  = srt_done | acc_done;
    assign rdata = srt_done ? srt_rdata : acc_rdata;

    // A-side request to the L2 arbiter (levels held until *_done)
    logic        a_start, a_wr;
    logic [25:0] a_addr;
    logic [63:0] a_wdata;
    logic [ 7:0] a_be;
    logic        a_done, a_rd_valid;   // driven by L2
    logic [63:0] a_rdata;              // driven by L2
    logic [1:0]  a_lane;
    logic [15:0] rmw_din;              // write data held across the read-modify-write
    // ---- own-write SHADOW (deep-posting RMW forward, 2026-07-18) ----------------
    // The beat-cache/d_fwd safety invariants below assume only the MOST RECENT
    // write can be unpublished (1-deep bridge posting). Deep posting falsifies
    // that (sim: 66 stale-RMW-merged entries at cfg_pub_delay=3000; 14 at 1500 --
    // unchanged by any bounded range guard). The shadow records the last-written
    // value of every recently-written beat (512-entry direct-mapped, index beat
    // addr [8:0], tag {v,addr[15:9]}); RMW merges use the shadow as base on HIT --
    // the RTL's own newest data, correct by single-outstanding ordering at ANY
    // publication depth. MISS = not recently written (safe DDR read) or a
    // collision eviction (the measured residual class). Write capture is fed from
    // the agent's accept stream (tst_wnext beats + tst_wr_done final), below.
    // index {row[4:0],col[5:0]} = addr{[11:7],[5:0]} so a 30-row blit strip maps
    // DISTINCT entries (a plain addr[8:0] index aliased the same column every 4
    // rows -> constant eviction -> the measured 52-entry residual at depth 3000).
    // BRAM form (fit fix: the FF-array + async multi-read version synthesized to
    // 166k registers / 351% ALM). 2048 x {generation[7:0], v, tag[4:0],
    // data[63:0]} simple-dual-port M10K; ONE synchronous read port fed by a
    // pipelined candidate lookup
    // (the next A/D read the L2 would grant).  A second response register keeps
    // the BRAM/tag compare out of the same physical path as the L2 grant/agent
    // command.  Hit+base are then latched at the read grant and consumed at
    // merge.  The NARC FIFO configuration carries an 8-bit re-POR generation
    // in each BRAM word, removing the timing-rejected 2048-bit FF valid lookup
    // without a startup sweep or an M10K-breaking bulk reset. FIFO-off donor
    // users retain their original vector/latency contract.
    (* ramstyle = "M10K" *) logic [77:0] shw_mem [0:2047];
`ifndef SYNTHESIS
    // sim: match the M10K power-up-zero contract (an uninitialized array reads X
    // and X-poisons the hit logic; hardware BRAM initializes to 0).
    initial for (int shwi = 0; shwi < 2048; shwi++) shw_mem[shwi] = 78'd0;
`endif
    logic [77:0] shw_q;  logic [15:0] shw_cand_q;
    logic [63:0] shw_rsp_data_q;
    logic [15:0] shw_rsp_cand_q;
    logic        shw_rsp_hit_q;
    logic [1:0]  shw_epoch, shw_read_epoch_q, shw_rsp_epoch_q;
    logic [63:0] shw_base;  logic shw_base_hit;
    logic [7:0]  shw_generation = 8'd0;
    logic        shw_por_seen = 1'b0;
    logic [2047:0] shw_valid; // legacy/default only; constant-elided in NARC
    logic          shw_v_q;
    wire d_shadow_bypass_en;
    wire d_shadow_lookup;
    wire d_shadow_bypass;
    // This state deliberately survives sdram_por: each assertion advances the
    // generation exactly once, instantly invalidating every older BRAM word.
    // Cyclone-V registers power up low; declaration initializers make the same
    // contract explicit to simulation/sv2v.  The first POR selects generation 1,
    // while the all-zero M10K image therefore cannot be a hit.
    always_ff @(posedge clk) begin
        if (sdram_por) begin
            if (!shw_por_seen) shw_generation <= shw_generation + 8'd1;
            shw_por_seen <= 1'b1;
        end else begin
            shw_por_seen <= 1'b0;
        end
    end
`ifdef YUNIT_NO_PUBGUARD
    wire shw_en = 1'b0;    // mutation: shadow off with the fence/guard
`else
    wire shw_en = 1'b1;
`endif
    wire [63:0] a_read_beat =
        (D_WRITE_FIFO && shw_en && shw_base_hit) ? shw_base : a_rdata;

    logic [63:0] rmw_beat;             // the beat being merged (DDR read OR the write-forward copy)
    // WRITE = READ-MODIFY-WRITE of the shared 64-bit beat (4 VRAM entries/beat), be=FF, PLUS a 1-deep
    // WRITE/READ FORWARD of the last beat this side wrote. Two silicon hazards motivate it:
    //   (a) BE: a masked single-beat write relies on the bridge honoring per-byte write-enables on a
    //       1-beat burst, which the real f2h_sdram1 does NOT -> full-beat be=FF write instead.
    //   (b) POSTED WRITES: the bridge accepts a write before the data lands, so a per-entry RMW that
    //       RE-READS the beat for the next entry can read STALE DDR data and clobber the neighbor.
    //       This failed the cab's VRAM self-test ("RAM CHIPS BAD"): the game writes all 4 entries of
    //       every beat back-to-back. FORWARDING makes same-beat accesses use the local copy (fwd_beat)
    //       instead of re-reading DDR -> correct independent of commit latency. The full-beat write
    //       still goes to DDR every time (persist + scanout). Sim's DDR model commits instantly so it
    //       exposed NEITHER hazard -- the same charitable-oracle gap for both.
    wire  [63:0] rmw_merged = (a_lane==2'd0) ? {rmw_beat[63:16], rmw_din}
                            : (a_lane==2'd1) ? {rmw_beat[63:32], rmw_din, rmw_beat[15:0]}
                            : (a_lane==2'd2) ? {rmw_beat[63:48], rmw_din, rmw_beat[31:0]}
                            :                  {rmw_din, rmw_beat[47:0]};
`ifdef PERF_NO_BEATCACHE2
    // MUTATION baseline: the original 1-deep write-allocate-only forward.
    logic [63:0] fwd_beat;             // local copy of the last beat this side wrote
    logic [25:0] fwd_addr;  logic fwd_valid;
`else
    // PERF (boot ~50x-slow fix, part 2): the 1-deep write-forward EXTENDED to a
    // 2-ENTRY BEAT CACHE, read-allocate AND write-allocate. The RAMCHECK's 3-word
    // straddling fields gather 6 entries = 2-3 shared beats per cell, and its
    // ascending sweep overlaps the previous cell's tail beat — with only the
    // last-written beat forwarded, 4-5 of those 6 gather reads re-read DDR3 every
    // cell. Two entries cover the whole working set of the field engine (a field
    // never spans more than 3 beats, and the gather walks them monotonically), so
    // this is 130ish flops, deliberately NOT a general cache and NOT BRAM.
    //
    // PRESERVED semantics: the cache IS the posted-write forward (a write always
    // updates/allocates its entry, and the full-beat be=FF write still goes to
    // DDR3 every time — persist + scanout); wt/srcwt write-throughs fire exactly
    // as before (from A_RMW_MRG, off rmw_merged); reset is the only bulk
    // invalidation, PLUS a C-erase snoop (below) that the 1-deep version lacked.
    //
    // POSTED-WRITE SAFETY invariant: the bridge holds at most the MOST RECENT
    // write uncommitted (the next accepted write flushes it). So a DDR3 re-read
    // is only hazardous for the beat of the most recent write — that beat is
    // always cache-resident: a write updates its entry, and READ-allocation is
    // forbidden from evicting the last-written entry (rd_alloc below). Write-
    // allocation MAY evict it: the RMW's full-beat write ACCEPT flushes the older
    // posted write before any later read can reach DDR3.
    logic [63:0] bc_beat0, bc_beat1;   // cached beats
    logic [25:0] bc_addr0, bc_addr1;   // their beat addresses
    logic        bc_v0, bc_v1;         // entry valid
    logic        bc_lru;               // eviction candidate (least recently used)
    logic        bc_lastwr;            // entry holding the MOST RECENT write
    logic        bc_lastwr_v;
    logic        bc_alloc;             // allocation target latched for the in-flight miss
    wire         bc_hit0 = bc_v0 && (bc_addr0 == a_addr);
    wire         bc_hit1 = bc_v1 && (bc_addr1 == a_addr);
    wire         hit_idx = bc_hit1;    // (hits are exclusive: duplicate tags impossible —
                                       //  a write hit updates in place, never re-allocates)
    wire  [63:0] fwd_beat = bc_hit1 ? bc_beat1 : bc_beat0;
    // allocation targets: an invalid entry first, else LRU; read-allocation must
    // additionally never evict the last-written entry (see invariant above).
    wire         wr_alloc = !bc_v0 ? 1'b0 : !bc_v1 ? 1'b1 : bc_lru;
    wire         rd_alloc = !bc_v0 ? 1'b0 : !bc_v1 ? 1'b1 :
                            (bc_lastwr_v && (bc_lru == bc_lastwr)) ? ~bc_lru : bc_lru;
`endif
    logic        a_is_wr;
    // ------- A-LANE WRITE-BEHIND (A_WBACK, cont.19 CPU-VRAM latency fix) -----------------------
    // MEASURED (tb_vram_ddr_acost): a CPU field RMW = 1 beat-read + 2 same-beat entry-writes = 3 DDR
    // ops = 72 clk, because the field engine writes a 16b field as 2 entries (vram_sdram.sv:11) and
    // the A cache is write-THROUGH (each entry-write -> its own full-beat DDR write). The 2 writes
    // (and an object cluster's read pos/write x/write y) all hit the SAME beat -> coalesce them.
    // wb = 1-deep dirty-beat buffer: A_RMW_MRG defers the DDR write into wb (coalescing same-beat),
    // and wb is FLUSHED before any DIFFERENT-beat access (no eviction/read staleness: wb is written
    // out before the cache is touched for another beat) and on idle. awt/asrcwt still fire every
    // write (B/C caches stay fresh for the displayed row); C/D writing wb's beat invalidates wb.
    logic        wb_v;                 // a deferred (dirty) beat is pending flush
    logic [25:0] wb_addr;              // its beat address
    logic [63:0] wb_data;              // its data
    logic [25:0] a_addr_save;          // registered request beat held across a flush-before-access
    logic        flush_pend;           // A_FLUSH returns to A_DEC (1) vs A_IDLE (0, idle-flush)
    logic [4:0]  wb_idle;              // idle cycles since wb last touched (hold before idle-flush so
    localparam [4:0] WB_FLUSH_IDLE = 5'd16;  // the field engine's back-to-back entry-writes coalesce)
    // A->B / A->C COHERENCY write-throughs. BOTH the A CPU-RMW lane AND the new D fb-combine lane
    // land real VRAM beats, so each write-through has TWO producers (awt_/asrcwt_ from A, dwt_/
    // dsrcwt_ from D) merged into the wt_/srcwt_ wires the B and C blocks consume. A and D writes
    // are TEMPORALLY EXCLUSIVE (A is granted only when !d_busy, and D accepts no fb pixels while
    // a_start is held -> D is fully idle throughout any A access), so the A-priority mux below can
    // never drop a live D pulse.
    //
    // A->B scanout-cache write-through: a write into the row B currently caches pushes the merged
    // beat into rc[] so a concurrently-scanned row shows FRESH data (else CPU/blitter drawing the
    // displayed buffer while B serves that row from cache = stale-vs-fresh frames = "purple flash").
    logic        awt_req;  logic [6:0] awt_col;  logic [63:0] awt_data;   // from A (A_RMW_MRG)
    logic        dwt_req;  logic [6:0] dwt_col;  logic [63:0] dwt_data;   // from D (fb flush)
    // A->C source-row (510/511) write-through: keeps the C engine's src_cache[] fresh so the beam-
    // locked erase copies live pattern data (parity-select per MAME midyunit_v.cpp:539 510+(line&1)).
    // MYOINIT's pattern fill is a DMA blit = fb writes, which now ride D -> D must produce this too.
    logic        asrcwt_req;  logic [7:0] asrcwt_idx;  logic [63:0] asrcwt_data;   // from A
    logic        dsrcwt_req;  logic [7:0] dsrcwt_idx;  logic [63:0] dsrcwt_data;   // from D
    logic [63:0] dsrcwt_data_next;
    // Keep a distinct source-cache data register: aliasing it to dwt_data made
    // that scanout write-through register drive both caches and exposed a real
    // erase/DMA-control -> dwt_data cone in the v7d fit (slow/100C -0.652 ns).
    // Unlike v7c's conditionally-enabled duplicate, this copy loads every cycle
    // from a preselected commit value, so its D input does not inherit the deep
    // flush-launch enable while the live dsrcwt_req/data alignment is unchanged.
    // merged views (A wins the impossible tie): the B block reads wt_*, the C block reads srcwt_*.
    wire         wt_req  = awt_req | dwt_req;
    wire  [6:0]  wt_col  = awt_req ? awt_col  : dwt_col;
    wire  [63:0] wt_data = awt_req ? awt_data : dwt_data;
    wire         srcwt_req  = asrcwt_req | dsrcwt_req;
    wire  [7:0]  srcwt_idx  = asrcwt_req ? asrcwt_idx  : dsrcwt_idx;
    wire  [63:0] srcwt_data = asrcwt_req ? asrcwt_data : dsrcwt_data;
    // fwd_hit compares the REGISTERED a_addr (latched in A_IDLE) against the cached tags -> reg-to-reg,
    // so the deep u_acc/autoerase address generation never feeds rmw_beat combinationally (that path
    // violated setup by -0.327ns when the compare used the live sd_addr). Decision is taken one cycle
    // later in A_DEC; the extra cycle per VRAM access is negligible vs the once-per-row scanout burst.
    // (The 2-entry cache adds one more 26-bit reg-to-reg compare in parallel — same depth.)
`ifdef PERF_NO_BEATCACHE2
    wire         fwd_hit = fwd_valid && (fwd_addr == a_addr);
`else
    wire         fwd_hit = bc_hit0 | bc_hit1;
`endif
    localparam [2:0] A_IDLE=3'd0, A_DEC=3'd1, A_WAIT=3'd2, A_ACK=3'd3, A_RMW_RD=3'd4, A_RMW_MRG=3'd5, A_FLUSH=3'd6;
    logic [2:0] ats;
    wire a_req_pending = sd_rd || sd_wr;
    wire a_flush_due   = wb_v && (wb_idle >= WB_FLUSH_IDLE);
    // Ownership claim seen by D admission. A live accessor request or a due
    // write-behind flush wins over accepting another framebuffer pixel.
    wire a_claim = (ats != A_IDLE) || a_start || a_req_pending || a_flush_due;
    always_ff @(posedge clk) begin
        if (rst) begin
            ats<=A_IDLE; a_start<=1'b0; a_wr<=1'b0; a_addr<=26'd0; a_wdata<=64'd0; a_be<=8'd0;
            a_lane<=2'd0; rmw_din<=16'd0; rmw_beat<=64'd0; sd_ack<=1'b0; sd_dout<=16'd0;
            wb_v<=1'b0; wb_addr<=26'd0; wb_data<=64'd0; a_addr_save<=26'd0; flush_pend<=1'b0; wb_idle<=5'd0;
`ifdef PERF_NO_BEATCACHE2
            fwd_beat<=64'd0; fwd_addr<=26'd0; fwd_valid<=1'b0;
`else
            bc_beat0<=64'd0; bc_beat1<=64'd0; bc_addr0<=26'd0; bc_addr1<=26'd0;
            bc_v0<=1'b0; bc_v1<=1'b0; bc_lru<=1'b0; bc_lastwr<=1'b0; bc_lastwr_v<=1'b0; bc_alloc<=1'b0;
`endif
            a_is_wr<=1'b0; awt_req<=1'b0;
            asrcwt_req<=1'b0; asrcwt_idx<=8'd0; asrcwt_data<=64'd0;
        end else begin
            sd_ack <= 1'b0; awt_req <= 1'b0; asrcwt_req <= 1'b0;
`ifdef PERF_NO_BEATCACHE2
            // fb-combine (D) or erase (C) writes can supersede A's 1-deep forward copy; never let a
            // CPU RMW merge into a stale forward. (The beat-cache path does an ADDRESSED invalidate.)
            // d_add = a run-buffer beat commit (on-add); (d_start&&d_wr) = partial RMW / burst launch.
            if ((c_start && c_wr) || (d_start && d_wr) || d_add ||
                srt_invalidate_evt) fwd_valid <= 1'b0;
            if (srt_invalidate_evt) begin
                bc_v0 <= 1'b0;
                bc_v1 <= 1'b0;
                bc_lastwr_v <= 1'b0;
            end
`endif
            case (ats)
                A_IDLE: begin                   // D ownership drains before A may latch/forward/flush
                  if (!d_busy) begin
                    if (b_fill_lock && wb_v) begin
                        // B_DRAIN must commit preexisting A write-behind data before the atomic
                        // row fill starts. Ignore the normal coalescing age; do not admit the held
                        // sd_rd/sd_wr until B publishes the completed row.
                        flush_pend<=1'b0; a_addr<=wb_addr; a_wdata<=wb_data;
                        a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                    end else if (!b_fill_lock && sd_rd) begin
                        a_lane<=sd_addr[1:0]; a_addr<={10'd0,sd_addr[17:2]}; a_addr_save<={10'd0,sd_addr[17:2]}; a_is_wr<=1'b0;
`ifdef MUT_A_FLUSH_LIVE_DECIDE
                        if (wb_v && (wb_addr != {10'd0,sd_addr[17:2]})) begin  // flush-before-access
                            flush_pend<=1'b1; a_addr<=wb_addr; a_wdata<=wb_data; a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                        end else ats<=A_DEC;
`else
                        // Register the request before deciding whether its beat conflicts
                        // with the dirty write-behind beat. This keeps the live accessor
                        // request off the flush_pend/a_wdata control cone.
                        ats<=A_DEC;
`endif
                    end else if (!b_fill_lock && sd_wr) begin
                        a_lane<=sd_addr[1:0]; a_addr<={10'd0,sd_addr[17:2]}; a_addr_save<={10'd0,sd_addr[17:2]}; rmw_din<=sd_din; a_is_wr<=1'b1;
`ifdef MUT_A_FLUSH_LIVE_DECIDE
                        if (wb_v && (wb_addr != {10'd0,sd_addr[17:2]})) begin  // flush-before-access
                            flush_pend<=1'b1; a_addr<=wb_addr; a_wdata<=wb_data; a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                        end else ats<=A_DEC;
`else
                        ats<=A_DEC;
`endif
                    end else if (!b_fill_lock && wb_v) begin // normal idle coalescing outside B fill
                        if (wb_idle >= WB_FLUSH_IDLE) begin   // same-beat entry-writes coalesce, THEN flush
                            flush_pend<=1'b0; a_addr<=wb_addr; a_wdata<=wb_data; a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                        end else wb_idle <= wb_idle + 5'd1;
                    end
                  end
                end
                A_DEC: begin                    // all access/flush decisions are registered-to-registered
`ifndef MUT_A_FLUSH_LIVE_DECIDE
                    if (wb_v && (wb_addr != a_addr)) begin
                        // A dirty different beat must reach DDR before the held access
                        // may consult or alter its target. A_FLUSH restores the registered
                        // request and re-enters A_DEC after the commit.
                        flush_pend<=1'b1; a_addr<=wb_addr; a_wdata<=wb_data;
                        a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_FLUSH;
                    end else
`endif
                    if (fwd_hit) begin
                        if (a_is_wr) begin rmw_beat<=fwd_beat; ats<=A_RMW_MRG; end   // WRITE-FORWARD
                        else begin                                                   // READ-FORWARD
                            case (a_lane)
                                2'd0: sd_dout<=fwd_beat[15:0]; 2'd1: sd_dout<=fwd_beat[31:16];
                                2'd2: sd_dout<=fwd_beat[47:32]; default: sd_dout<=fwd_beat[63:48];
                            endcase
                            sd_ack<=1'b1; ats<=A_ACK;
                        end
`ifndef PERF_NO_BEATCACHE2
                        bc_lru   <= ~hit_idx;                          // hit entry = most recently used
                        bc_alloc <= hit_idx;                           // a write-hit updates IN PLACE
`endif
                    end else begin                                                   // MISS: go to DDR
                        a_wr<=1'b0; a_start<=1'b1; ats<= a_is_wr ? A_RMW_RD : A_WAIT;
`ifndef PERF_NO_BEATCACHE2
                        bc_alloc <= a_is_wr ? wr_alloc : rd_alloc;     // latch the eviction target
`endif
                    end
                end
                A_WAIT: begin                   // completion of a plain READ (sd_rd) OR the RMW full-beat WRITE
                    if (a_rd_valid) begin
                        // A FIFO-enabled NARC read may reach DDR while the
                        // bridge still exposes the previous posted value.  The
                        // publication shadow captured at grant is the exact
                        // newest accepted full beat (the RMW path already uses
                        // it below); use the same base for plain reads and their
                        // cache allocation.  Parameter isolation leaves every
                        // donor/default instance on its established path.
                        case (a_lane)
                            2'd0: sd_dout<=a_read_beat[15:0]; 2'd1: sd_dout<=a_read_beat[31:16];
                            2'd2: sd_dout<=a_read_beat[47:32]; default: sd_dout<=a_read_beat[63:48];
                        endcase
`ifndef PERF_NO_BEATCACHE2
                        // READ-ALLOCATE the whole beat (miss reads only reach A_WAIT with
                        // a_rd_valid; the RMW write completion has no read beats). rd_alloc
                        // (latched into bc_alloc) never evicts the last-written entry.
                        if (!a_is_wr) begin
                            if (bc_alloc) begin bc_beat1<=a_read_beat; bc_addr1<=a_addr; bc_v1<=1'b1; end
                            else          begin bc_beat0<=a_read_beat; bc_addr0<=a_addr; bc_v0<=1'b1; end
                            bc_lru <= ~bc_alloc;
                        end
`endif
                    end
                    if (a_done) begin a_start<=1'b0; sd_ack<=1'b1; ats<=A_ACK; end
                end
                A_RMW_RD: begin                 // RMW step 1: read the shared beat from DDR (miss, a_wr=0)
                    // shadow override: a recently-written beat's merge base comes from
                    // the RTL's own newest data, immune to publication depth.
                    if (a_rd_valid) rmw_beat <= (shw_en && shw_base_hit) ? shw_base : a_rdata;
                    if (a_done) begin a_start<=1'b0; ats<=A_RMW_MRG; end   // drop start -> L2 bubbles to IDLE
                end
                A_RMW_MRG: begin                // RMW step 2: merge the lane, write the FULL beat + remember it
`ifndef PERF_NO_WBACK
                    // WRITE-BEHIND (DEFAULT — cab-proven cont.20, fixed the starvation reboot): defer
                    // the DDR write into wb (coalesces the field engine's 2 same-beat entry-writes +
                    // an object cluster into ONE flush; CPU-VRAM RMW 72->59 clk, cluster 51->25). The
                    // cache update + awt/asrcwt below still fire (reads forward from cache, B/C stay
                    // fresh); wb flushes before any different-beat access (A_IDLE) or on idle.
                    // (-DPERF_NO_WBACK reverts to the old write-through for A/B testing.)
                    wb_v<=1'b1; wb_addr<=a_addr; wb_data<=rmw_merged; wb_idle<=5'd0; sd_ack<=1'b1; ats<=A_ACK;
`else
                    a_wdata<=rmw_merged; a_be<=8'hFF; a_wr<=1'b1; a_start<=1'b1; ats<=A_WAIT;
`endif
`ifdef PERF_NO_BEATCACHE2
                    fwd_beat<=rmw_merged; fwd_addr<=a_addr; fwd_valid<=1'b1;
`else
                    // WRITE-ALLOCATE/UPDATE: a hit updates its own entry (bc_alloc was set
                    // to hit_idx in A_DEC — duplicate tags are structurally impossible), a
                    // miss lands in the latched wr_alloc target. This entry is now both the
                    // posted-write forward AND the most recent write.
                    if (bc_alloc) begin bc_beat1<=rmw_merged; bc_addr1<=a_addr; bc_v1<=1'b1; end
                    else          begin bc_beat0<=rmw_merged; bc_addr0<=a_addr; bc_v0<=1'b1; end
                    bc_lru      <= ~bc_alloc;
                    bc_lastwr   <= bc_alloc;
                    bc_lastwr_v <= 1'b1;
`endif
                    awt_req <= (rc_valid && (a_addr[15:7]==rc_row));   // write-through into B's cache if it holds this row
                    awt_col <= a_addr[6:0]; awt_data <= rmw_merged;
                    // A->C source-row cache write-through (rows 510/511). a_addr is the beat index
                    // (entry>>2); its top 9 bits [15:7] are the VRAM row, [6:0] the beat-in-row.
                    // src_cache is 256 deep: [0..127]=row510, [128..255]=row511 (bit7 selects half).
                    asrcwt_req  <= (a_addr[15:7]==9'd510) || (a_addr[15:7]==9'd511);
                    asrcwt_idx  <= {(a_addr[15:7]==9'd511), a_addr[6:0]};
                    asrcwt_data <= rmw_merged;
                end
                A_ACK: ats<=A_IDLE;            // 1-cyc bubble so sd_rd/sd_wr clear
                A_FLUSH: if (a_done) begin     // the deferred write-behind beat committed to DDR
                    a_start<=1'b0; a_wr<=1'b0; wb_v<=1'b0;
                    if (flush_pend) begin a_addr<=a_addr_save; ats<=A_DEC; end  // resume the held request
                    else                  ats<=A_IDLE;                          // idle-flush done
                end
                default: ats<=A_IDLE;
            endcase
`ifndef PERF_NO_BEATCACHE2
            // C-ERASE SNOOP (placed AFTER the case so it wins a same-cycle allocate of
            // the same entry): the autoerase engine writes whole beats behind the beam;
            // a cached copy of an erased beat would serve pre-erase data to a later CPU
            // read. The 1-deep forward had this same staleness window (never invalidated
            // until the next write) — read-allocation would WIDEN it, so close it here.
            // No posted-write hazard opens up: C's write ACCEPT flushes any older posted
            // A write in the bridge before a re-read of the invalidated beat can issue
            // (single-outstanding L2 + the bridge's flush-on-next-write-accept).
            if (c_start && c_wr) begin
                if (bc_v0 && (bc_addr0 == c_addr)) bc_v0 <= 1'b0;
                if (bc_v1 && (bc_addr1 == c_addr)) bc_v1 <= 1'b0;
            end
            // D (fb-combine) SNOOP: a combined fb beat write must invalidate any A beat-cache copy of
            // that beat, else a later CPU read/RMW merges into stale pre-fb data. Two producers now:
            //  (1) ON-ADD (d_add): each FULL beat as it ENTERS the run-buffer -- the burst commits many
            //      beats under ONE d_start, so the per-beat snoop MUST ride the add, not the drain.
            //  (2) the single-beat PARTIAL RMW write (d_start && d_wr && !d_is_burst) -- immediate.
            if (d_add) begin
                if (bc_v0 && (bc_addr0 == {10'd0, d_add_beat})) bc_v0 <= 1'b0;
                if (bc_v1 && (bc_addr1 == {10'd0, d_add_beat})) bc_v1 <= 1'b0;
            end
            if (d_start && d_wr && !d_is_burst) begin
                if (bc_v0 && (bc_addr0 == d_addr)) bc_v0 <= 1'b0;
                if (bc_v1 && (bc_addr1 == d_addr)) bc_v1 <= 1'b0;
            end
`endif
            // The deferred A beat exists in BOTH cache configurations. Clear it only when a
            // later C/D write has actually launched ownership of the same beat. For the D-partial
            // wb-bypass path, d_wdata already contains wb_data merged with the new D lanes before
            // this edge, so no A data is discarded. Keep these clears outside BEATCACHE2's ifdef.
            if (c_start && c_wr && wb_v && (wb_addr == c_addr)) wb_v <= 1'b0;
            if (d_add && wb_v && (wb_addr == {10'd0, d_add_beat})) wb_v <= 1'b0;
            if (d_start && d_wr && !d_is_burst && wb_v && (wb_addr == d_addr)) wb_v <= 1'b0;
        end
    end

    // ================= B: scanout row-burst cache ============================================
    (* ramstyle="no_rw_check" *) logic [63:0] rc [0:127];   // one row = 128 beats x 4 entries
    // rc_row, rc_valid hoisted to top (Questa declare-before-use)
    // wt PEND (1-deep, ROW-TAGGED): the rc[] BRAM has a SINGLE write port. A refill beat (B_FILL) always
    // wins it; an A->B write-through (wt_req) arriving on that same cycle would otherwise be silently
    // DROPPED (the stv_vram_ddr_top.sv:236-239 drop race). Instead, LATCH the colliding write-through
    // (col + data + its ROW) into a 1-deep pending slot and drain it on the next port-free cycle -- but
    // ONLY if rc still caches that row (coherent). The row tag matters because a write-through can only
    // collide with a fill of a DIFFERENT row (B hits, never re-fills, the currently cached row), so the
    // pended write's target row is usually being evicted by that very fill; draining it blindly would
    // stamp stale data into the newly-filled row's cache. The row-tag gate makes the drain a no-op in
    // that (normal) case and correct in any case where the row is still cached. Depth 1 suffices: A
    // issues at most one write-through per multi-cycle RMW, so a second cannot land before the first
    // drains. (DDR always gets the A write regardless -- this only concerns the same-frame cache copy.)
    logic        wtp_v;  logic [6:0] wtp_col;  logic [63:0] wtp_data;  logic [8:0] wtp_row;
    wire  [8:0]  req_row = scan_addr[17:9];   // continuous (NOT `logic = ...`, which is init-only)
    wire  [8:0]  req_col = scan_addr[8:0];
    logic [63:0] rc_q;  wire [6:0] rc_raddr = req_col[8:2];  logic [1:0] rc_rlane;
    always_ff @(posedge clk) rc_q <= rc[rc_raddr];          // reads the CURRENT scan col's beat (1 clk)

    logic        b_start;
    logic [25:0] b_addr;
    logic [7:0]  b_burstlen;           // per-sub-burst length (to L2)
    logic        b_done, b_rd_valid;   // driven by L2
    logic [63:0] b_rdata;              // driven by L2
    logic [7:0]  fillbeat;
    logic [8:0]  fill_row;             // miss row latched for the entire atomic fill
    // v7h TIMING: the BSNOOP merge comparators used to consume {fill_row,fillbeat[6:0]}
    // COMBINATIONALLY, putting both counters (and their case/ifdef mux cones) directly in front
    // of the rc[] BRAM write-data mux -- the async multi-read window CLAUDE.md S3 bans.
    // bfill_bt_q is a dedicated register MIRRORING that concatenation with zero skew: loaded on
    // the B_IDLE miss (>=2 cycles before the first b_rd_valid, since B_REQ only sets b_start and
    // b_rd_valid cannot precede the cycle after b_start), then incremented under the SAME
    // condition as fillbeat. The increment is 7-BIT (wraps inside the row) because the live tag
    // truncates fillbeat to [6:0]; a 16-bit +1 would carry into the row field at beat 127->128.
    // B_REQ re-entry (sub-bursts bounded by BMAX) touches neither counter, so the mirror needs
    // NO reload there -- correct by induction. The equality is CHECKED by the $fatal below.
    logic [15:0] bfill_bt_q;
    // v21 TIMING (P0049): a DEDICATED DUPLICATE of bfill_bt_q for the rb/burst offset path.
    // v21's frontier rejected 3 paths at Slow 100C only -- bfill_bt_q[9]->bfill_pipe_data[28]
    // -0.114, [9]->[24] -0.024, [8]->[28] -0.003 -- i.e. the ROW half of the tag (bfill_bt bit
    // 8/9 = fill_row[1]/[2]) into the rb_data-selected lanes. T-unit's corner analysis says a
    // hot-corner-only failure on a 64-bit merge is a cell/logic-depth cone, and this tag drives
    // FIVE independent consumers (two 16-bit subtracts and three 16-bit equalities) that all
    // reconverge on one 5:1 64-bit mux.
    //
    // This duplicate is loaded from the SAME sources under the SAME conditions with zero skew,
    // so it is bit-identical to bfill_bt_q by construction and CANNOT change coherency -- the
    // property MUT_NO_BMERGE exists to police. It exists purely to split fanout and let the
    // fitter place a copy next to the rb_data muxes. Chosen over restructuring the merge
    // because that merge already carries the v7j T2 re-association whose own comment warns a
    // change there "silently reverts the timing repair with every gate still green".
    logic [15:0] bfill_bt_rb_q;
    // v7u TIMING: the all-corner frontier found the remaining BSNOOP cone
    // rb_base -> subtract/range/select -> rc[] porta data-in negative at Slow
    // 85C/100C (worst -0.331 ns).  Register each fully-resolved refill beat
    // before the row-cache BRAM.  The pipe accepts and commits one beat per
    // clock, so burst throughput is unchanged; B_COMMIT keeps the cache invalid
    // and same-row D ingress parked until the final registered beat lands.
    logic        bfill_pipe_v;
    logic [6:0]  bfill_pipe_col;
    logic [63:0] bfill_pipe_data;
    // A row = 128 beats, but the REAL HPS f2sdram UNDER-DELIVERS a burst longer than its max
    // (NS ran 32-beat bursts on HW; the 128-beat request stalled the fill on silicon -> the
    // pulsing-line-on-white hang, reproduced in tb_vram_ddr_xdiff with the 32-cap oracle). Fill
    // the row in <=BMAX sub-bursts, re-requesting from wherever fillbeat reached.
    localparam [7:0] BMAX = 8'd32;
    localparam [2:0] B_IDLE=3'd0, B_REQ=3'd1, B_FILL=3'd2, B_HIT=3'd3, B_WAIT=3'd4,
                     B_DRAIN=3'd5, B_COMMIT=3'd6;
    logic [2:0] bts;
    wire b_fill_active = (bts==B_REQ) || (bts==B_FILL) || (bts==B_COMMIT);
`ifdef MUT_BFILL_NOLOCK
    assign b_fill_lock = 1'b0;
    assign b_bus_lock  = 1'b0;
`else
    assign b_fill_lock = (bts==B_DRAIN) || (bts==B_REQ) || (bts==B_FILL) || (bts==B_COMMIT);
    assign b_bus_lock  = (bts==B_REQ) || (bts==B_FILL);
`endif
    always_ff @(posedge clk) begin
        if (rst) begin
            bts<=B_IDLE; b_start<=1'b0; b_addr<=26'd0; b_burstlen<=8'd0; rc_valid<=1'b0; rc_row<=9'd0;
            fillbeat<=8'd0; fill_row<=9'd0; bfill_bt_q<=16'd0; bfill_bt_rb_q<=16'd0; rc_rlane<=2'd0; scan_ack<=1'b0; scan_data<=16'd0;
            bfill_pipe_v<=1'b0; bfill_pipe_col<=7'd0; bfill_pipe_data<=64'd0;
            wtp_v<=1'b0; wtp_col<=7'd0; wtp_data<=64'd0; wtp_row<=9'd0;
            b_drain_is_hit<=1'b0; b_fifo_fenced<=1'b0;
        end else begin
            scan_ack <= 1'b0;
            if (srt_invalidate_evt) rc_valid <= 1'b0;
`ifndef MUT_BFILL_UNPIPE
            // Drain the previous response while accepting the next.  Nonblocking
            // ordering makes bfill_pipe_v below refer to the previous cycle.
            bfill_pipe_v <= 1'b0;
            if ((bts==B_FILL) && b_rd_valid) begin
                bfill_pipe_v    <= 1'b1;
                bfill_pipe_col  <= fillbeat[6:0];
                bfill_pipe_data <= bfill_merged;
            end
`endif
            case (bts)
                B_IDLE: if (scan_req) begin
                    if (rc_valid && (rc_row==req_row)) begin        // HIT (rc_raddr combinational -> rc_q aligned by B_HIT)
                        rc_rlane<=req_col[1:0];
                        // A FIFO push is accepted before its downstream beat
                        // reaches dwt/rc.  If any such write targets the live
                        // scan row, freeze new ingress and drain the bounded
                        // queue before serving this hit.  The sticky bit also
                        // closes the same-edge hit+push race without searching
                        // the FIFO or adding a second rc[] write port.
                        // v7j: the same-edge race term follows the sticky's new arming
                        // point -- the SKID push, i.e. the cycle the pixel is ACKed.
                        if (D_WRITE_FIFO &&
                            (fbq_row_conflict ||
                             (!D_BEAT_FIFO && skd_push &&
                              (beat_fb_addr[17:9] == rc_row)))) begin
                            b_drain_is_hit<=1'b1;
                            b_fifo_fenced<=1'b0;
                            bts<=B_DRAIN;
                        end else begin
                            b_drain_is_hit<=1'b0;
                            bts<=B_HIT;
                        end
                    end else begin                                   // MISS -> fill the row in <=BMAX sub-bursts
                        fillbeat<=8'd0;
`ifdef MUT_BFILL_NOLOCK
                        if (D_WRITE_FIFO) begin
                            fill_row<=req_row; bfill_bt_q<={req_row, 7'd0}; bfill_bt_rb_q<={req_row, 7'd0};
                            rc_valid<=1'b0; wtp_v<=1'b0;
                            b_drain_is_hit<=1'b0; b_fifo_fenced<=1'b1;
                            bts<=B_DRAIN;
                        end else begin
                            bfill_bt_q<={fill_row[8:0], 7'd0}; bfill_bt_rb_q<={fill_row[8:0], 7'd0}; // mirror: fill_row is NOT reloaded here
                            bts<=B_REQ;                              // mutation: old live-tag/non-atomic behavior
                        end
`else
                        fill_row<=req_row; bfill_bt_q<={req_row, 7'd0}; bfill_bt_rb_q<={req_row, 7'd0}; rc_valid<=1'b0; wtp_v<=1'b0;
                        b_drain_is_hit<=1'b0;
                        if (D_WRITE_FIFO) begin
                            // Always drain on a FIFO-enabled miss, even if the
                            // queue looks empty now: ingress is frozen in
                            // B_DRAIN, closing a coincident miss+push edge.
                            b_fifo_fenced<=1'b1;
                            bts<=B_DRAIN;
                        end else begin
                            b_fifo_fenced<=1'b0;
`ifdef MUT_NO_BSNOOP
                            bts<=B_DRAIN;                            // mutation: old unbounded drain barrier
`else
                            bts<=B_REQ;                              // bounded fill; coherency via bfill_merged
`endif
                        end
`endif
                    end
                end
                B_DRAIN: begin
                    // Drain only PREEXISTING A/D ownership. Held new sd_rd/sd_wr and fb_pend
                    // are deliberately excluded or the barrier would deadlock on work it blocks.
                    if ((ats==A_IDLE) && !a_start && !wb_v && !d_busy && !d_start &&
                        !c_start && (ls==3'd0) && !tst_busy) begin
                        if (b_drain_is_hit) begin
                            b_drain_is_hit<=1'b0;
                            bts<=B_HIT;
                        end else bts<=B_REQ;
                    end
                end
                B_REQ: begin                                        // set up the next sub-burst from fillbeat
`ifdef MUT_BFILL_NOLOCK
                    b_addr     <= {10'd0, req_row, 7'd0} + {18'd0, fillbeat};
`else
                    b_addr     <= {10'd0, fill_row, 7'd0} + {18'd0, fillbeat};
`endif
                    b_burstlen <= ((8'd128 - fillbeat) > BMAX) ? BMAX : (8'd128 - fillbeat);
                    b_start    <= 1'b1; bts <= B_FILL;
                end
                B_FILL: begin
                    if (b_rd_valid) begin
                        fillbeat <= fillbeat + 8'd1;               // response captured; registered rc[] commit follows
                        bfill_bt_q[6:0] <= bfill_bt_q[6:0] + 7'd1; // 7-bit: mirrors fillbeat[6:0], never carries into the row
                        bfill_bt_rb_q[6:0] <= bfill_bt_rb_q[6:0] + 7'd1;  // P0049 duplicate, same increment
                    end
                    if (b_done) begin                               // sub-burst complete
                        b_start <= 1'b0;
                        if (fillbeat >= 8'd128) begin
`ifdef MUT_BFILL_UNPIPE
                            rc_valid<=1'b1;
                            b_fifo_fenced<=1'b0;
`ifdef MUT_BFILL_NOLOCK
                            rc_row<=req_row;
`else
                            rc_row<=fill_row;
`endif
                            bts<=B_IDLE;
`else
                            // Do not publish until the final registered merge has
                            // crossed the sole rc[] write port.
                            bts<=B_COMMIT;
`endif
                        end
                        else bts <= B_REQ;                          // more of the row to fetch
                    end
                end
                B_COMMIT: if (!bfill_pipe_v) begin
                    rc_valid<=1'b1;
                    b_fifo_fenced<=1'b0;
`ifdef MUT_BFILL_NOLOCK
                    rc_row<=req_row;
`else
                    rc_row<=fill_row;
`endif
                    bts<=B_IDLE;
                end
                B_HIT: begin                                          // rc_q valid now
                    case (rc_rlane)
                        2'd0: scan_data<=rc_q[15:0]; 2'd1: scan_data<=rc_q[31:16];
                        2'd2: scan_data<=rc_q[47:32]; default: scan_data<=rc_q[63:48];
                    endcase
                    scan_ack<=1'b1; bts<=B_WAIT;
                end
                B_WAIT: if (!scan_req) bts<=B_IDLE;   // ONE ack per request: wait for the consumer to drop
                                                      // scan_req before re-arming, else B_IDLE re-detects the
                                                      // still-high scan_req as a 2nd hit -> double-serve ->
                                                      // the next column reads this column's beat (col shift).
                default: bts<=B_IDLE;
            endcase
            // rc[] SINGLE write port with 1-deep ROW-TAGGED PEND for write-through collisions:
            //   priority: (1) registered refill beat always wins the port;
            //             (2) else DRAIN a pending write-through, but only if rc still caches its row
            //                 (coherent); if the row was evicted by the fill, discard (clear wtp_v);
            //             (3) else apply a fresh non-colliding wt_req directly.
            // A fresh wt_req colliding with a refill beat (case 1) is CAPTURED into the pend (with its
            // row = rc_row at capture) rather than lost. This closes the :236-239 drop race.
`ifdef MUT_BFILL_UNPIPE
            if (bts==B_FILL && b_rd_valid) begin
                rc[fillbeat[6:0]] <= bfill_merged;
                if (wt_req) begin wtp_v<=1'b1; wtp_col<=wt_col; wtp_data<=wt_data; wtp_row<=rc_row; end  // PEND (was dropped)
`else
            if (bfill_pipe_v) begin
                rc[bfill_pipe_col] <= bfill_pipe_data;
                if (wt_req) begin wtp_v<=1'b1; wtp_col<=wt_col; wtp_data<=wt_data; wtp_row<=rc_row; end
`endif
            end else if (wtp_v) begin
                if (rc_valid && (rc_row == wtp_row)) rc[wtp_col] <= wtp_data;            // coherent drain
                wtp_v <= 1'b0;                                                            // (else discard: row evicted)
                if (wt_req) begin wtp_v<=1'b1; wtp_col<=wt_col; wtp_data<=wt_data; wtp_row<=rc_row; end  // re-pend a fresh collision
            end else if (wt_req) begin
                rc[wt_col] <= wt_data;                                                   // no collision: apply directly
            end
        end
    end

`ifndef SYNTHESIS
    // v7h D4 CHECKED INVARIANT (pattern: rtl/yunit/vram_sdram_top.sv:206-214).
    // Moving the merge tag into bfill_bt_q is behavior-identical ONLY IF the register equals
    // the live concatenation at every CONSUMING beat. That is a premise, not a fact, so check
    // it instead of asserting it: any skew (a missed reload on the B_REQ sub-burst re-entry
    // path, a carry out of the 7-bit field at beat 127, an ifdef arm that forgets the load)
    // kills the run here rather than silently corrupting the snoop merge into rc[]. It holds
    // in BOTH ifdef configurations, so it is NOT a revert-discriminator -- it is the premise
    // check that licenses calling the repair equivalent. Costs nothing in synthesis.
    always @(posedge clk) if (!rst) begin
        if ((bts==B_FILL) && b_rd_valid && (bfill_bt_rb_q !== bfill_bt_q))
            $fatal(1, "stv_vram_ddr_top: P0049 duplicate skew rb=%h q=%h", bfill_bt_rb_q, bfill_bt_q);
        if ((bts==B_FILL) && b_rd_valid && (bfill_bt_q !== {fill_row[8:0], fillbeat[6:0]}))
            $fatal(1, "stv_vram_ddr_top: bfill_bt_q skew q=%h live=%h",
                   bfill_bt_q, {fill_row[8:0], fillbeat[6:0]});
    end

`ifndef MUT_BFILL_UNPIPE
    // Premise check for the v7u timing register: the following-cycle pipe must
    // contain exactly the resolved data and column sampled on the response.
    // Functional BSNOOP tests then check that those committed values match the
    // MAME-derived newest-writer ordering.
    logic        bfill_check_v;
    logic [6:0]  bfill_check_col;
    logic [63:0] bfill_check_data;
    always @(posedge clk) begin
        if (rst) begin
            bfill_check_v    <= 1'b0;
            bfill_check_col  <= 7'd0;
            bfill_check_data <= 64'd0;
        end else begin
            if (bfill_pipe_v !== bfill_check_v)
                $fatal(1, "stv_vram_ddr_top: bfill pipe-valid skew pipe=%b expected=%b",
                       bfill_pipe_v, bfill_check_v);
            if (bfill_pipe_v &&
                ((bfill_pipe_col !== bfill_check_col) ||
                 (bfill_pipe_data !== bfill_check_data)))
                $fatal(1, "stv_vram_ddr_top: bfill pipe payload skew col=%h/%h data=%h/%h",
                       bfill_pipe_col, bfill_check_col,
                       bfill_pipe_data, bfill_check_data);
            bfill_check_v <= (bts==B_FILL) && b_rd_valid;
            if ((bts==B_FILL) && b_rd_valid) begin
                bfill_check_col  <= fillbeat[6:0];
                bfill_check_data <= bfill_merged;
            end
        end
    end
`endif
`endif

    // ================= C: beam-locked per-scanline AUTOERASE engine =========================
    // MAME midyunit_v.cpp:534-559 autoerase_line(scanline): memcpy(&vram[512*line],
    //   &vram[512*(510+(line&1))], 1024) for 0<=line<510, called every scanline as
    //   autoerase_line(rowaddr-1) — ONE ROW BEHIND THE BEAM. We snoop the existing scan_addr's
    //   req_row: on a row change we latch erase_row = displayed_row-1 and copy one row's worth
    //   of 128 pre-merged 64-bit beats from the parity-selected source-row cache to erase_row,
    //   as WHOLE-BEAT be=FF writes (NO per-entry RMW — the old bulk sweep's 5-7M clk/frame cost).
    //
    // Source-row cache: 256x64b BRAM = row510 in [0..127], row511 in [128..255], parity-selected
    // by erase_row[0] (MAME :539 510+(scanline&1)). Kept fresh by the A-side srcwt_* write-through;
    // lazily burst-filled from DDR3 (through L2, like B) at cold start before any write-through.
    (* ramstyle="no_rw_check" *) logic [63:0] src_cache [0:255];
    logic        src510_valid, src511_valid;
    logic [63:0] src_q;                      // 1-clk BRAM read of the current erase beat's source
    logic [7:0]  src_raddr;                  // {parity, c_beat}
    always_ff @(posedge clk) src_q <= src_cache[src_raddr];

    // Trigger: req_row transition detector (req_row is the B-side wire = scan_addr[17:9]).
    //
    // GOAL/CATCH-UP ARCHITECTURE (the cab-stripes fix, reproduced by tb_vram_ddr_raster):
    // scan_addr comes from yunit_scanline's PREFETCH loader, whose tgt_row (a) runs one row
    // AHEAD of the display, (b) loads row ERASE_ROWS (one past the last displayed row) during
    // the last visible line, and (c)
    // re-primes rows 0/1 back-to-back DURING vblank -- so row transitions arrive in BURSTS
    // faster than one ~1.2k-clk erase. The old edge-triggered C_IDLE handshake silently
    // DROPPED any transition that fired while C was busy: rows 0-4 were never erased (the
    // white stripes on the cab), and the P1.9b wrap rule erased the one-past-last prefetch
    // row -- VRAM the real hardware never touches (midyunit scanline_update only walks
    // displayed rows).
    // FIX: triggers are DECOUPLED from execution. Every transition latches a GOAL row
    // (er_goal, always 0..ER_LAST -- targets outside the visible range are structurally
    // rejected, which also subsumes the old 510/511 skip guard); the erase FSM marches
    // er_next -> er_goal, erasing EVERY row in order, immune to trigger bursts. Erase is
    // ~5x faster than a line, so it stays caught up in steady state and clears the vblank
    // burst backlog within the first few active lines -- every visible row is erased every
    // frame, exactly like the real per-scanline hardware.
    logic [8:0] req_row_d;
    always_ff @(posedge clk) req_row_d <= req_row;
    wire row_changed = (req_row != req_row_d);
    // target row = new_row-1 (MAME :554 one-behind-the-beam, which with the prefetch lead =
    // the currently-displayed row). Frame-WRAP transitions (row decreases -- only possible
    // across vblank) latch NO goal: with the real prefetcher every visible row is already
    // covered by +1 transitions (the row-V_ACT prefetch covers the last visible row; the
    // vblank re-prime's 0->1 covers row 0), and a wrap goal is not merely redundant -- it is
    // the deadlock found by tb_vram_ddr_raster: a stale goal of 255 after er_next wrapped to
    // 0 reads as a 255-row backlog, the catch-up FREE-RUNS ahead during vblank, the fresh
    // goal 0 then lands BEHIND er_next, er_pending goes false, and the engine locks out
    // permanently (each row erased exactly once, then dead = the cab's frozen stripes).
    // (Supersedes P1.9b's wrap-erase, which was designed against a beam-following scan_addr
    // model that the real prefetch loader does not match.)
    wire       trig_wrap = (req_row < req_row_d);
    wire [8:0] trig_nr   = req_row - 9'd1;

    // Displayed-row range for this board (see the ERASE_ROWS parameter). ER_LAST is the
    // highest row the beam ever scans; goals outside 0..ER_LAST are structurally rejected,
    // which also subsumes the old 510/511 skip guard.
`ifdef MUT_BEAMERASE_DONOR_ROWS
    // MUTANT (coverage proof, sim only -- must NEVER reach a build): re-impose the inherited
    // Y-unit 256-row cap regardless of ERASE_ROWS. sim/tb_zunit_beamerase.sv GAMERASE=1 must
    // go RED on NARC display rows 256..399.
    localparam int ER_ROWS = 256;
`else
    localparam int ER_ROWS = ERASE_ROWS;
`endif
    localparam [8:0] ER_LAST = ER_ROWS - 1;

    // ---- P0033: the erase window is BASE-RELATIVE, not anchored to absolute VRAM row 0 -----
    // MAME's erased row is autoerase_line(params->rowaddr - 1) (midyunit_v.cpp:554) with
    // rowaddr loaded from DPYSTRT at vsblnk and decremented per VISIBLE scanline
    // (tms34010.cpp:1152, :1035). So the erasable set is ABSOLUTE rows base-1 .. base+VIS-1,
    // where base = (DPYSTRT ^ 0xFFFC) >> 4 -- NOT 0 .. VIS-1. The filter and the catch-up wrap
    // below used to be anchored to absolute 0, which is only equal to the gospel when base==0.
    // NARC holds DPYSTRT=0FAFC (base 80) for ~380 frames at every wave start and then scrolls
    // it 79->0 (SCORDPYS, NARCBGND.ASM:64-65), so on the cabinet (a) goals for absolute rows
    // 400..base+398 were rejected -> the bottom `base` displayed rows were never erased, and
    // (b) er_next wrapped to absolute 0 and parked there, so the vblank prefetch re-prime's
    // goal restarted the engine at absolute row 0 = NARC's resident status panel (HUD, VRAM
    // rows 0..79, SCOREINT .EQU 80+1BH / SYS.INC:94), which is painted ONCE by SCORAREA on
    // area entry and never repainted per frame -> "the top of the HUD is gone until you enter
    // a new area".
    // disp_base is the frame-latched first displayed row (zunit_video_top disp_row0_q, P0031).
    // UNDRIVEN (every donor / Y-unit / legacy-TB instantiation) it reads x/z here and z=GND
    // after synthesis -- both fold to 0, i.e. the previous absolute-0 anchoring. Same
    // legacy-instantiation idiom as `srt_i` at the top of this file.
`ifdef MUT_BEAMERASE_ABS_ROW0
    // MUTANT (coverage proof, sim only -- must NEVER reach a build): restore the pre-P0033
    // ABSOLUTE-row-0 anchoring and the always-armed (blanking-included) trigger. This is the
    // exact cabinet defect: with DPYSTRT base 80 the bottom 80 displayed rows are never erased
    // and the vblank re-prime restarts the engine on absolute row 0 = NARC's resident HUD.
    // sim/run_beamerase.sh's base sweep MUST go RED on base=40 and base=80.
    wire [8:0] er_base    = 9'd0;
`elsif SYNTHESIS
    // In a real build disp_base is always driven (zunit_mem), and Quartus has no x/z value to
    // test -- take the port directly rather than leave a `===` against 1'bx for the synthesizer
    // to fold. The x-guard below exists only for legacy TBs that leave the port unconnected.
    wire [8:0] er_base    = disp_base;
`else
    wire [8:0] er_base    = (^disp_base === 1'bx) ? 9'd0 : disp_base;
`endif
    // TIMING (P0040b): disp_base arrives from zunit_video_top across FOUR module
    // boundaries (video_top -> top -> memsys -> mem -> here) into the most
    // congested block in the design, and it fed combinational compares directly.
    // That routing + logic load pushed unrelated cones (fbq->wc_data,
    // wstream_idx->f2sdram) negative at slow/100C on two different seeds.
    // disp_base is FRAME-LATCHED upstream and only changes at vblank entry, so
    // registering it here -- and the two constants derived from it -- is free
    // functionally (the erase engine re-primes at vblank, thousands of clocks
    // later) and terminates the long cross-hierarchy route at a flop.
    reg [8:0] er_base_q, er_top_q, er_wrap_to_q;
    always_ff @(posedge clk) begin
        er_base_q    <= er_base;
        er_top_q     <= er_base + ER_LAST;   // last displayed row of this frame
        er_wrap_to_q <= er_base - 9'd1;      // MAME's rowaddr-1 at the first visible line
    end
    wire [8:0] er_top     = er_top_q;
    wire [8:0] er_wrap_to = er_wrap_to_q;
    wire [8:0] trig_rel   = trig_nr - er_base_q; // goal offset from the frame base (mod 512)

    // ---- P0033: erase ONLY while the raster is inside the active display window ------------
    // GOSPEL: autoerase_line() is called ONLY from scanline_update (midyunit_v.cpp:554), i.e.
    // only on visible scanlines -- it is structurally UNREACHABLE during vblank. Our trigger is
    // the scanout prefetcher's row change, and yunit_scanline ALSO re-primes first_row /
    // first_row+1 during the blank; that base->base+1 transition is a goal MAME can never
    // produce. With the game's AUTOERAS disarm being a CPU ISR that lands *inside* line 427
    // while the re-prime fires at the *start* of 427, the engine was still enabled when that
    // blanking goal arrived -- which is exactly how absolute row 0 (the HUD) got erased.
    // scan_blank is the raster's vertical-blank level (zunit_video_top vblank_i = !v_active).
    // UNDRIVEN it reads z (GND after synthesis) -> never blanking -> donor behavior unchanged.
`ifdef MUT_BEAMERASE_ABS_ROW0
    wire       er_blank = 1'b0;      // see MUT_BEAMERASE_ABS_ROW0 above
`else
    // TIMING (P0040b): like disp_base, scan_blank arrives from zunit_video_top
    // across four module boundaries and fed goal_accept combinationally. Register
    // it here too. The blank LEVEL is stable for thousands of clocks, and the
    // erase trigger fires at most once per scanline (~674 dot periods apart), so
    // a one-clock delay cannot let a row_changed slip past the boundary -- which
    // the base gate verifies directly at isrlat=4000, the case that reproduced
    // the cabinet's vblank HUD erase.
    reg        er_blank_q;
    always_ff @(posedge clk) er_blank_q <= (scan_blank === 1'b1);
    wire       er_blank = er_blank_q;
`endif

    logic [8:0] er_goal;  logic er_goal_v;     // newest visible-range target (0..ER_LAST)
    logic       erase_en_q;                    // arm-edge replay of the most recent line goal
    logic       arm_seen;                      // P0048: an arm edge is awaiting its first issue
    // P0048 gospel band start, base-relative, and how far behind the live goal it sits.
    wire [8:0] er_gospel_row = er_base_q + 9'(ERASE_FIRST_REL);
    wire [8:0] er_gospel_lag = er_goal - er_gospel_row;   // 9-bit wrap, same idiom as er_lag

    logic [8:0] er_next;                       // next row the catch-up loop will erase
    // pending = er_next has not yet passed er_goal (unsigned 9-bit distance < ERASE_ROWS;
    // rows are strictly increasing 0..ER_LAST within a frame, er_next wraps explicitly below).
    // er_next is never more than ONE row ahead of er_goal (it only advances by completing a
    // row, or by the disabled-pin to er_goal+1), so "ahead" always reads as a 9-bit distance
    // of 512-1 = 511 >= ERASE_ROWS and is correctly rejected for any ERASE_ROWS <= 400.
    wire [8:0] er_lag     = er_goal - er_next;
    wire       er_pending = er_goal_v && erase_en && (er_lag <= ER_LAST);

    // GOAL ACCEPTANCE (P0033). Was `row_changed && !trig_wrap && (trig_nr <= ER_LAST)`.
    //   * base-relative window: MAME's erasable set is rowaddr-1 for rowaddr in
    //     base..base+VIS-1, i.e. relative offsets -1 .. ERASE_ROWS-1 (511 == -1 mod 512).
    //   * trig_nr < 510: midyunit_v.cpp:538 "scanline >= 0 && scanline < 510" -- rows 510/511
    //     are the erase SOURCE rows and are never a destination. At base==0 this is also what
    //     rejects the relative -1 case (MAME's `scanline >= 0` on rowaddr-1 == -1).
    //   * !er_blank: midyunit_v.cpp:554 is reachable only from scanline_update (visible lines).
`ifdef MUT_ERASE_ABS_WINDOW
    // MUTATION (sim-only): restore the pre-P0040 ABSOLUTE-anchored window with no
    // visible-line gate -- i.e. the exact defect that clobbered the NARC HUD.
    // Anchoring acceptance to absolute row 0 rejects goals above ER_LAST once the
    // display base is non-zero (the bottom `base` rows are never erased), and
    // dropping !er_blank lets the vblank re-prime erase rows 0.. -- the HUD band.
    // This gate MUST go red with it.
    wire goal_accept = row_changed && !trig_wrap && (trig_nr <= ER_LAST);
`else
    wire goal_accept = row_changed && !trig_wrap && !er_blank
                    && ((trig_rel <= ER_LAST) || (trig_rel == 9'h1FF))
                    && (trig_nr < 9'd510);
`endif

    // C requester to L2 (cont.24: erase is now a BE=FF BURST write; burst read during a cold fill)
    // c_start, c_wr, c_addr hoisted to top (Questa declare-before-use)
    logic [63:0] c_wdata;
    logic [ 7:0] c_burstlen;
    logic        c_done, c_rd_valid;         // driven by L2
    logic [63:0] c_rdata;                    // driven by L2
    // ERASE-BURST staging (cont.24): CB_MAX contiguous source beats staged from src_cache into
    // cb_data[], then streamed to the agent as ONE Avalon burst (mux in the L2 block). 128 = 8 x
    // CB_MAX. Was 128 SINGLE-beat writes/row = 128 f2h round-trips = the background repaint fell
    // behind the beam on real HW (cab FLICKER, proven via -DNO_AUTOERASE; sim commits free so the
    // ":512 ~5x-per-line" margin was a SIM ARTIFACT). [[lessons_ddr3_write_burst]].
    localparam [7:0] CB_MAX = 8'd16;         // <= f2h BMAX(32) / sim cfg_maxburst(32); 128 % CB_MAX == 0
    logic [63:0] cb_data [0:15];             // staged sub-burst beats (cb_data[0] = lowest); ~1k flops
    logic [4:0]  c_stg;                      // staging counter 0..CB_MAX
    localparam [4:0] C_STG_READY = 5'd17;    // beat15 captured once; wait here for B lock release
    wire         c_is_burst = c_wr && (c_burstlen > 8'd1);   // C is streaming a be=FF burst write

    logic [8:0]  erase_row;                  // the row currently being erased (from the catch-up loop)
    logic [6:0]  c_beat;                      // 0..127 beat index within the row
    logic [7:0]  c_fill;                      // cold-fill beat counter (0..127)
    logic        c_fill_which;                // 0 = filling row510 half, 1 = row511 half
    wire         erase_par = erase_row[0];    // 0 -> source row 510, 1 -> source row 511 (MAME :539)
    // per-erase source-cache validity, evaluated for er_next at issue time (C_IDLE)
    wire         next_par  = er_next[0];
    wire         next_srcv = next_par ? src511_valid : src510_valid;

    localparam [2:0] C_IDLE=3'd0, C_FILL_REQ=3'd1, C_FILL_RCV=3'd2, C_STAGE=3'd3, C_BWR=3'd4;
    logic [2:0]  cts;
    assign erase_busy = (cts != C_IDLE);

    // srcwt 1-deep PEND: src_cache[] must have exactly ONE write statement chain (below) or Quartus
    // cannot map it to a simple-dual-port M10K and falls back to 16384 LOOSE REGISTERS -- which is
    // exactly what happened on the first beamerase build (routing congestion at seed 1, then a
    // -1.028 ns a_wdata->src_cache[*][*] setup violation at seed 3, +16k registers in the fit
    // summary). Same discipline as rc[]'s single prioritized port + wtp pend: a fill beat wins the
    // port; a colliding A-side write-through PENDS here and drains on the next non-fill cycle.
    logic        swp_v;  logic [7:0] swp_idx;  logic [63:0] swp_data;

    always_ff @(posedge clk) begin
        if (rst) begin
            cts<=C_IDLE; c_start<=1'b0; c_wr<=1'b0; c_addr<=26'd0; c_wdata<=64'd0; c_burstlen<=8'd1;
            c_beat<=7'd0; c_stg<=5'd0; c_fill<=8'd0; c_fill_which<=1'b0; erase_row<=9'd0; src_raddr<=8'd0;
            src510_valid<=1'b0; src511_valid<=1'b0; swp_v<=1'b0; swp_idx<=8'd0; swp_data<=64'd0;
            er_goal<=9'd0; er_goal_v<=1'b0; er_next<=9'd0; erase_en_q<=1'b0;
            arm_seen <= 1'b0;
        end else begin
            erase_en_q <= erase_en;
            if (erase_en && !erase_en_q) arm_seen <= 1'b1;   // P0047: arm edge, await first issue
            if (srt_invalidate_evt) begin
                src510_valid <= 1'b0;
                src511_valid <= 1'b0;
            end
            // P0041: A-side write-through UPDATES the cached copy but must NEVER
            // declare the row valid. ONE 64-bit beat validated the whole 512-entry
            // source cache, so the other 127 beats / 508 entries were stale BRAM --
            // and the C engine then copied that garbage into every erased row.
            // Reachable in normal play: srt_invalidate_evt (the scroll path) clears
            // both flags, and the next single write-through beat re-validated the
            // cache with 127 stale beats. The correct producer of `valid` is the
            // COLD FILL completion below (c_fill >= 128), which fetches the whole
            // row first. A write-through into an INVALID row now simply leaves it
            // invalid, so the next erase cold-fills it.
`ifdef MUT_SRCWT_VALIDATES
            // MUTATION (sim-only): restore the single-beat validation -- must fail.
            if (srcwt_req) begin
                if (srcwt_idx[7]) src511_valid <= 1'b1; else src510_valid <= 1'b1;
            end
`endif
            // GOAL LATCH -- runs EVERY cycle, independent of the FSM state (the whole point:
            // trigger bursts must never be dropped because C is busy). Targets outside the
            // DISPLAYED range (the -1 pre-frame case, the prefetcher's one-past-last row, and
            // any 510/511 alias) are structurally rejected -- goals are always 0..ER_LAST,
            // which also guarantees the erase can never touch the pattern rows or the
            // non-displayed VRAM above the raster.
            // (goal_latch is also checked by the CONSUME in C_ADV below: a goal completed and a
            // new goal latched in the same cycle must not lose the new one.)
            if (goal_accept) begin
                er_goal <= trig_nr;  er_goal_v <= 1'b1;
            end
            // While the enable is LOW, pin er_next just past the goal so NO backlog accrues:
            // MAME semantics are per-line (a line whose display passed with erase disabled is
            // simply never erased); a catch-up burst on re-enable would wrongly erase rows the
            // game painted while erase was off.  (P0033: base-relative -- past the frame's LAST
            // displayed row is the frame's base-1, not absolute 0.)
            //
            // P0045: the real NARC DIRQ2 write that ARMS AUTOERAS lands inside raster line
            // 107/108, after yunit_scanline may already have emitted that line's prefetch
            // transition. v11 waited for the NEXT transition, permanently omitting the first
            // enabled row; cabinet pixels crossing that row (for example a missile explosion)
            // accumulated there as a one-row garbage band. `er_goal` already records exactly
            // the newest visible-line target while disabled. Replay that ONE row on the rising
            // edge, then resume normal beam goals. This is not backlog catch-up: no older
            // disabled row is revisited, and the replay remains behind the live beam.
            // P0048: START WHERE MAME STARTS, not where our ISR happens to land.
            //
            // The v11 replay above set er_next to er_goal -- wherever the beam was when the
            // AUTOERAS write arrived. That is correct only if our DIRQ2 latency matches MAME's.
            // It does not have to: our 34010 shares one SDRAM port and is measurably starved, so
            // a late arm loses every row between MAME's band start and ours, permanently, which
            // is the cabinet's one-row garbage band under the HUD. Measured in
            // tb_zunit_beamerase_base: first erased row 80/80/81/83 at armlat 1000/4000/8000/16000
            // -- rows lost scale with OUR latency, and the arm-edge replay recovers exactly one.
            //
            // We do not need to know our latency. MAME's band START is a constant (base+80), so
            // begin there and the bands agree by construction at any arm latency. This is not a
            // catch-up burst: the replay is clamped to ERASE_ARM_CATCHUP_MAX rows, it only ever
            // reaches BACKWARD toward a row the beam has already passed, and rows it erases are
            // rows MAME also erases (MAME's own arm is on time).
`ifndef MUT_ERASE_NO_ARM_REPLAY
            if (erase_en && !erase_en_q && er_goal_v) begin
                if ((ERASE_FIRST_REL >= 0) &&
                    (er_gospel_lag <= ERASE_ARM_CATCHUP_MAX[8:0]))
                    er_next <= er_gospel_row;   // start at MAME's first row
                else
                    er_next <= er_goal;         // donor behaviour / out-of-range guard
            end
            else
`endif
            if (!erase_en) er_next <= (er_goal == er_top) ? er_wrap_to : (er_goal + 9'd1);
            case (cts)
                C_IDLE: begin
                    // Do not wait here for a continuously-fed framebuffer
                    // FIFO to become empty: that can starve autoerase
                    // forever.  Each physical C transaction raises c_start;
                    // the ingress fence below then stops NEW D acceptance,
                    // drains the bounded preexisting queue, and lets C run.
                    if (er_pending) begin
                        // P0033 gospel skip (midyunit_v.cpp:538 "scanline >= 0 && scanline < 510"):
                        // rows 510/511 are the erase SOURCE rows -- MAME's guard SKIPS such a
                        // line, it does not stop the machine. This is reachable only at base==0,
                        // where the frame's wrap target er_base-1 is 511; skipping it lands
                        // er_next on 0 exactly as the old absolute wrap did.
                        if (er_next >= 9'd510) begin
                            er_next <= (er_next == er_top) ? er_wrap_to : (er_next + 9'd1);
                        end else begin
                        erase_row <= er_next;
                        src_raddr <= {next_par, 7'd0};                // pre-read source beat 0 for C_WR
                        c_beat    <= 7'd0;
                        if (!next_srcv) begin
                            c_fill       <= 8'd0;                     // cold start: burst-fill the source row first
                            c_fill_which <= next_par;
                            cts          <= C_FILL_REQ;
                        end else begin
                            c_stg <= 5'd0; cts <= C_STAGE;            // source cached -> stage beats, then burst
                        end
                        end
                    end
                end
                // ---- cold-start source-row fill: burst-read the whole source row into src_cache ----
                C_FILL_REQ: begin                              // request a <=BMAX sub-burst from c_fill
                    if (!b_fill_lock) begin
                        c_addr     <= {10'd0, (c_fill_which ? 9'd511 : 9'd510), 7'd0} + {18'd0, c_fill};
                        c_burstlen <= ((8'd128 - c_fill) > BMAX) ? BMAX : (8'd128 - c_fill);
                        c_wr       <= 1'b0; c_start <= 1'b1; cts <= C_FILL_RCV;
                    end
                end
                C_FILL_RCV: begin
                    if (c_rd_valid) begin
                        c_fill <= c_fill + 8'd1;     // src_cache write happens in the single port below
                    end
                    if (c_done) begin
                        c_start <= 1'b0;
                        if (c_fill >= 8'd128) begin
                            if (c_fill_which) src511_valid <= 1'b1; else src510_valid <= 1'b1;
                            src_raddr <= {c_fill_which, 7'd0};   // re-point read for the erase pass
                            c_stg <= 5'd0; cts <= C_STAGE;       // stage beats, then burst
                        end else cts <= C_FILL_REQ;              // more of the source row to fetch
                    end
                end
                // ---- erase pass (cont.24 BURST): stage CB_MAX contiguous beats from src_cache into
                // cb_data[], then ONE be=FF Avalon burst -- the D-lane/B-scanout streaming path.
                // src_q is a REGISTERED src_cache read: src_raddr was pointed at {par,c_beat} the
                // previous cycle (C_IDLE / C_FILL end / a C_BWR sub-burst advance), so at the FIRST
                // C_STAGE cycle src_q already holds beat c_beat. Each cycle captures cb_data[c_stg]=
                // src_q and points src_raddr one beat ahead; after CB_MAX captures, fire the burst.
                C_STAGE: begin
                    if (c_stg == 5'd0) begin
                        // SETTLE (the old C_RD, once per sub-burst): src_raddr was pointed at this
                        // sub-burst's beat0 the PREVIOUS cycle, so src_q -- a REGISTERED src_cache
                        // read -- becomes valid NEXT cycle. Capturing without this settle samples
                        // the previous beat's src_q (the xdiff-caught off-by-one: beat0 = stale
                        // wrong-parity data, every later beat shifted one down, last beat dropped).
                        src_raddr <= {erase_par, (c_beat + 7'd1)};    // pre-point at beat0+1
                        c_stg     <= 5'd1;
                    end else if (c_stg == C_STG_READY) begin
                        // cb_data[15] is already captured. Holding here MUST perform no further
                        // BRAM write: src_q has advanced to beat16 and would corrupt the tail.
                        if (!b_fill_lock) begin
                            c_addr     <= {10'd0, erase_row, c_beat};
                            c_burstlen <= CB_MAX;
                            c_wr       <= 1'b1; c_start <= 1'b1;
                            cts        <= C_BWR;
                        end
                    end else begin
                        cb_data[c_stg[3:0] - 4'd1] <= src_q;          // src_q = beat c_beat+(c_stg-1)
                        if (c_stg == CB_MAX[4:0]) begin               // last beat captured -> fire
                            if (!b_fill_lock) begin
                                c_addr     <= {10'd0, erase_row, c_beat}; // dst beat0 = row*128 + c_beat
                                c_burstlen <= CB_MAX;
                                c_wr       <= 1'b1; c_start <= 1'b1;
                                cts        <= C_BWR;
                            end else c_stg <= C_STG_READY;            // locked: tail captured once, then hold
                        end else begin
                            src_raddr <= {erase_par, (c_beat + {2'b00, c_stg} + 7'd1)};  // next beat
                            c_stg     <= c_stg + 5'd1;
                        end
                    end
                end
                // C_BWR: the L2 arbiter streams cb_data[wstream_idx] as a be=FF burst (mux at the L2
                // block). On c_done, advance to the next CB_MAX sub-burst, or finish the row.
                C_BWR: if (c_done) begin
                    c_start <= 1'b0;
                    if ((c_beat + CB_MAX[6:0]) == 7'd0) begin    // 128 wrapped to 0 (7-bit) = row done
                        // advance the catch-up pointer (P0033: the frame's LAST displayed row
                        // er_top = base+ERASE_ROWS-1 wraps to base-1, MAME's rowaddr-1 at the
                        // first visible line -- so a stale end-of-frame goal reads as a lag of
                        // ERASE_ROWS and correctly stops the engine instead of restarting it at
                        // absolute row 0) and bounce through C_IDLE, which immediately issues the
                        // next backlogged row if er_pending still holds.
                        er_next <= (er_next == er_top) ? er_wrap_to : (er_next + 9'd1);
                        // CONSUME the goal when this row completed it. NOT load-bearing (mutation-
                        // verified self-heals); kept as FAITHFULNESS hardening so no VRAM row is
                        // erased ahead of its MAME per-scanline time. Guard a same-cycle NEW goal.
                        if (erase_row == er_goal && !goal_accept)
                            er_goal_v <= 1'b0;
                        cts <= C_IDLE;
                    end
                    else begin
                        c_beat    <= c_beat + CB_MAX[6:0];                    // next sub-burst
                        src_raddr <= {erase_par, (c_beat + CB_MAX[6:0])};     // prime its beat0
                        c_stg     <= 5'd0;
                        cts       <= C_STAGE;
                    end
                end
                default: cts <= C_IDLE;
            endcase
            // src_cache[] SINGLE write port (M10K inference requirement -- see the swp_v comment
            // above): a cold-fill beat wins; else a live A-side write-through; else drain the pend.
            // A write-through colliding with a fill beat PENDS (1-deep) and lands the next non-fill
            // cycle -- never silently dropped (the erase copies from this cache every line, so a
            // dropped source update would repaint stale pattern data indefinitely).
            if (cts==C_FILL_RCV && c_rd_valid) begin
                src_cache[{c_fill_which, c_fill[6:0]}] <= c_rdata;
                if (srcwt_req) begin swp_v <= 1'b1; swp_idx <= srcwt_idx; swp_data <= srcwt_data; end
            end else if (srcwt_req) begin
                src_cache[srcwt_idx] <= srcwt_data;
                // a NEWER direct write to the same beat supersedes a still-pended older one --
                // draining the pend afterwards would clobber fresh data with stale.
                if (swp_v && swp_idx == srcwt_idx) swp_v <= 1'b0;
            end else if (swp_v) begin
                src_cache[swp_idx] <= swp_data;  swp_v <= 1'b0;
            end
        end
    end

    // ================= D: W-THRU2 fb beat WRITE-COMBINE (ported from UMK3 083d55e) =============
    // The blitter fb stream used to ride u_acc's 16-bit sd channel: EVERY pixel cost a full-beat
    // RMW pair (~25 clk/px). That term makes an attract-mode WHOLE-SCREEN redraw take ~2.5 frames
    // on the single-buffered Y-unit -> the process dispatcher falls behind -> the software watchdog
    // (200-frame TIMER) reboots (cab-measured 2026-07-10; SCOPE-wthru2-port.md). Blit rows are
    // sx-sequential, so 4 entries/beat combine naturally: a FULL beat writes be=FF with NO read
    // (bridge-safe); partial beats (row edges) RMW, a 1-deep own-write forward covering consecutive
    // partials of the same beat. Drops fb to ~4 clk/px so a redraw fits in a frame -> watchdog stops.
    //
    // ORDERING / DEADLOCK GUARD: the CPU sd lane (A) is granted only on a DRAINED combiner
    // (a_start && !d_busy in L2), and a_start FORCES a flush + parks new fb accepts for its duration
    // -- without the park the sustained fb stream would never empty the combiner and A would starve
    // (the contention-gate deadlock UMK3 caught 2026-07-10).
    //
    // COHERENCY (the STV-specific part -- UMK3 had only A + B): every combined beat write is a real
    // VRAM write, so it stays coherent with all three caches: it invalidates A's 2-entry beat cache
    // (the D snoop in the A block above), writes through B's scanout row cache when it holds that
    // row (dwt_*), and srcwt's into C's autoerase source cache for rows 510/511 (dsrcwt_*).
    // fb_addr is an 18-bit ENTRY index; beat = fb_addr[17:2], lane = fb_addr[1:0]; beat[15:7]=row,
    // beat[6:0]=beat-in-row -- identical to the A-side encoding, so all coherency tags line up.
`ifdef PERF_NO_FBCOMBINE
    localparam FBCOMB = 1'b0;   // MUTATION: disable same-beat combine -> every pixel a partial RMW
`else                          //           (the cost gate must then FAIL; coherency stays green)
    localparam FBCOMB = 1'b1;
`endif
    // ---- Optional NARC ingress elasticity --------------------------------
    // A 64-entry raw-pixel FIFO is one M10K (64 x {18b addr,16b data}).  Its
    // synchronous registered head deliberately inserts the same one-cycle
    // post-pop gap as the simulation probe that closed every 4*w*h deadline.
    // Nothing below searches this RAM: scan coherency uses a sticky row
    // conflict + bounded drain, keeping the FIFO off the BSNOOP/rc[] cones.
    localparam integer FBQ_DEPTH = 64;
    localparam integer FBQ_AW    = 6;
    (* ramstyle="M10K" *) logic [33:0] fbq_mem [0:FBQ_DEPTH-1];
    logic [FBQ_AW:0] fbq_wptr, fbq_rptr, fbq_rptr_q;
    logic [33:0]     fbq_head;
    logic            fbq_ne_q, fbq_flush_pend;
    wire [FBQ_AW-1:0] fbq_wp = fbq_wptr[FBQ_AW-1:0];
    wire [FBQ_AW-1:0] fbq_rp = fbq_rptr[FBQ_AW-1:0];
    wire fbq_full = (fbq_wptr[FBQ_AW-1:0] == fbq_rptr[FBQ_AW-1:0]) &&
                    (fbq_wptr[FBQ_AW] != fbq_rptr[FBQ_AW]);
    assign fbq_empty = (fbq_wptr == fbq_rptr);
    wire fbq_head_valid = !fbq_empty && fbq_ne_q && (fbq_rptr == fbq_rptr_q);

    // ---- v7j T1 REPAIR: registered-ready INGRESS SKID -------------------------
    // fb_ack fans into zunit_dma's 32-bit col_i/tx/o_ptr incrementers and its
    // S_WRITE next-state.  Driving it from fbq_ingress_ready dragged fbq_wptr /
    // fbq_rptr / fbq_rptr_q (via fbq_pop -> fbq_head_valid) AND fbq_head (via
    // d_fb_addr -> fb_same -> the whole `accept` combiner cone at :1224) across the
    // module boundary into that datapath -- the ~370 reported failing paths.
    //
    // The fix inserts a small elastic buffer in FRONT of the FIFO and hands the
    // blitter a REGISTERED ready.  Deliberately NOT done by registering
    // fbq_ingress_ready itself: the FIFO's `!fbq_full || fbq_pop` term is what lets
    // it accept a push in the very cycle it is full and popping, and the pipeline
    // gate asserts that coverage (run_ddr3.sh: "max=64/64 full-pop-push>=1").  A
    // registered room predicate caps occupancy one short of that and would silently
    // retire the coverage.  The skid leaves the FIFO's accept semantics BYTE-FOR-BYTE
    // as they were and only moves the producer handshake one stage upstream.
    //
    // skd_room_q is exact, not stale: it is loaded from the true next-cycle
    // occupancy (occ + push - pop, all three known combinationally in the cycle
    // before use), so the level presented at cycle N describes occupancy at N with
    // zero skew.  Occupancy parks at SKD_DEPTH-1 under sustained flow (push and pop
    // cancel), so steady-state throughput is 1 pixel/clk exactly as before; the only
    // cost is one bubble on each transition out of a full stall.
    localparam integer SKD_DEPTH = 4;
    localparam integer SKD_AW    = 2;
    localparam [SKD_AW:0] SKD_FULL = 3'd4;      // sized: no part-select of an integer param
    logic [33:0]     skd_mem [0:SKD_DEPTH-1];
    logic [SKD_AW:0] skd_wptr, skd_rptr;
    logic            skd_room_q;
    wire [SKD_AW:0]  skd_occ   = skd_wptr - skd_rptr;
    wire             skd_empty = (skd_wptr == skd_rptr);
    wire [33:0]      skd_head  = skd_mem[skd_rptr[SKD_AW-1:0]];
    wire [17:0]      skd_addr  = skd_head[33:16];
    wire             skd_push, skd_pop;

    // D is busy while EITHER stage holds a pixel: the skid has already ACKed those
    // writes to the blitter, so A admission (!d_busy) and the exported fb_busy must
    // cover it exactly as they cover the FIFO.
    assign fbq_busy  = D_WRITE_FIFO && (!fbq_empty || !skd_empty);
    wire fbq_drained = fbq_empty && skd_empty;

    // Freeze NEW ownership for A, the bounded B drain, and each physical C
    // transaction.  Existing FIFO work still reaches the internal combiner:
    // pre-fence D writes drain first, then the L2 arbiter may grant C.  Holding
    // the fence through c_done gives autoerase bounded progress without
    // reordering a newly accepted pixel ahead of the active erase burst.
    wire fbq_b_park = (bts == B_DRAIN) ||
                      (b_fill_active && (fb_addr[17:9] == fill_row));
    wire fbq_c_park = D_WRITE_FIFO && c_start;
    // A and C are ordering owners and fence new logical acceptance. B is a
    // real-time observer: compact entries may continue accumulating while it
    // scans, then replay through the existing row-qualified BSNOOP and dwt
    // machinery. The complete-scene gate requires that replay to finish
    // inside one frame, bounding display visibility without stalling DMA.
    wire beat_in_allow = !a_claim && !srt_claim && !fbq_c_park;
    logic skd_ingress_ready;

    // The compact journal lives before the existing skid/raw FIFO. Its output
    // is already-owned D work, so it drains through A/C while those owners wait
    // on beat_pending. B keeps its short real-time raw-FIFO drain: replay parks
    // there while new pixels may continue accumulating compactly. This prevents
    // CPU or erase from overtaking an acknowledged pixel without turning each
    // scanline fill into a full-journal drain.
    logic beat_in_ack;
    generate
      if (D_BEAT_FIFO) begin : g_beat_fifo
        narc_fb_beat_fifo #(.DEPTH(D_BEAT_FIFO_DEPTH)) u_beat_fifo (
          .clk(clk), .rst(rst),
          .in_we(fb_we), .in_addr(fb_addr), .in_data(fb_wdata),
          .in_allow(beat_in_allow), .in_ack(beat_in_ack),
          .in_flush(fb_flush),
          .out_we(beat_fb_we), .out_addr(beat_fb_addr),
          .out_data(beat_fb_wdata), .out_ack(skd_ingress_ready),
          .out_flush(beat_fb_flush), .out_busy(d_busy),
          .pending(beat_pending), .busy(beat_busy));
      end else begin : g_no_beat_fifo
        always_comb begin
          beat_in_ack   = 1'b0;
          beat_fb_we    = fb_we;
          beat_fb_addr  = fb_addr;
          beat_fb_wdata = fb_wdata;
          beat_fb_flush = fb_flush;
          beat_pending  = 1'b0;
          beat_busy     = d_busy;
        end
      end
    endgenerate

    wire        pipe_fb_we    = beat_fb_we;
    wire [17:0] pipe_fb_addr  = beat_fb_addr;
    wire [15:0] pipe_fb_wdata = beat_fb_wdata;
    wire        pipe_fb_flush = beat_fb_flush;

    wire fbq_room = !fbq_full || fbq_pop;          // UNCHANGED: full-turnover accept
    // PRODUCER boundary.  Every ownership fence stays exactly where it was in
    // logical terms -- it now qualifies the ACK instead of the FIFO push, which is
    // the same instant a pixel becomes the subsystem's responsibility.  What has
    // LEFT this cone is the whole of `fbq_room`: fbq_wptr/fbq_rptr (fbq_full),
    // fbq_rptr_q (fbq_head_valid) and fbq_head (d_fb_addr -> fb_same -> `accept`).
    // That is the T1 repair; the fence terms (a_claim/bts/c_start/fill_row) were
    // never in the reported failing cone.
    always_comb skd_ingress_ready =
        skd_room_q &&
        (D_BEAT_FIFO
          ? !fbq_b_park
          : (!a_claim && !fbq_b_park && !fbq_c_park));
    logic       d_fb_ack, d_fb_ack_q;
    always_comb fb_ack = D_BEAT_FIFO ? beat_in_ack :
                         (D_WRITE_FIFO ? skd_ingress_ready : d_fb_ack);
    always_comb fb_busy = D_BEAT_FIFO ? beat_busy : d_busy;
    assign skd_push = D_WRITE_FIFO && pipe_fb_we && skd_ingress_ready;
    // skid -> FIFO is an INTERNAL transfer of pixels the subsystem has ALREADY
    // accepted, so it carries no fence.  It must not: d_busy covers the skid (those
    // writes are owed to any A read), and A and C are granted only on !d_busy while
    // holding the very fences that would stop the skid -- fencing this transfer
    // livelocks the arbiter.  Draining is also the correct ordering: a pre-fence
    // pixel is supposed to reach DDR before the fence owner's transaction, and
    // because C/A are granted only on !d_busy nothing can overtake them.
    assign skd_pop  = D_WRITE_FIFO && !skd_empty && fbq_room;
    assign fbq_push = skd_pop;
    wire        d_fb_we    = D_WRITE_FIFO ? fbq_head_valid : pipe_fb_we;
    wire [17:0] d_fb_addr  = D_WRITE_FIFO ? fbq_head[33:16] : pipe_fb_addr;
    wire [15:0] d_fb_wdata = D_WRITE_FIFO ? fbq_head[15:0]  : pipe_fb_wdata;
    wire        d_fb_flush = D_WRITE_FIFO
                           ? (fbq_drained && (pipe_fb_flush || fbq_flush_pend))
                           : pipe_fb_flush;
    assign fbq_pop  = D_WRITE_FIFO && d_fb_we && d_fb_ack;
    wire [SKD_AW:0] skd_occ_n = skd_occ + {{SKD_AW{1'b0}}, skd_push}
                                        - {{SKD_AW{1'b0}}, skd_pop};

    always_ff @(posedge clk) begin
        if (rst || !D_WRITE_FIFO) begin
            fbq_wptr<=0; fbq_rptr<=0; fbq_rptr_q<=0;
            fbq_head<=34'd0; fbq_ne_q<=1'b0;
            fbq_flush_pend<=1'b0; fbq_row_conflict<=1'b0;
            skd_wptr<=0; skd_rptr<=0; skd_room_q<=1'b1;
        end else begin
            // Exact next-cycle skid occupancy: push is qualified by skd_room_q itself
            // (a registered term), so this is a plain feed-forward, not a loop.
            skd_room_q <= (skd_occ_n < SKD_FULL);
            if (skd_push) begin
                skd_mem[skd_wptr[SKD_AW-1:0]] <=
                    {pipe_fb_addr, pipe_fb_wdata};
                skd_wptr <= skd_wptr + 1'b1;
            end
            if (skd_pop) skd_rptr <= skd_rptr + 1'b1;

            // Registered synchronous head.  Pointer currency suppresses the
            // stale head for one cycle after pop (and after push-into-empty).
            fbq_head   <= fbq_mem[fbq_rp];
            fbq_rptr_q <= fbq_rptr;
            fbq_ne_q   <= !fbq_empty;

            if (fbq_push) begin
                fbq_mem[fbq_wp] <= skd_head;
                fbq_wptr <= fbq_wptr + 1'b1;
            end
            if (fbq_pop) fbq_rptr <= fbq_rptr + 1'b1;

            // S_DONE is normally a level, but retain even a one-cycle boundary
            // until all older queued pixels have crossed into the D combiner.
            if (pipe_fb_flush && !fbq_drained) fbq_flush_pend <= 1'b1;
            else if (fbq_drained)         fbq_flush_pend <= 1'b0;

            // Any queued write to the cached scan row means rc[] trails the
            // logical DMA stream until downstream dwt consumes the queue.
            // Freeze ingress and drain once on the next B hit; no FIFO CAM or
            // new rc[] write port is required.
            // Armed at the SKID push (the ACK boundary), not the FIFO push: a pixel
            // sitting in the skid has already been acknowledged to the blitter, so
            // rc[] would otherwise be allowed to serve stale data for it.  d_busy
            // covers the skid too, so the sticky cannot clear early.
            if (!rc_valid)
                fbq_row_conflict <= 1'b0;
            else if (!D_BEAT_FIFO && skd_push &&
                     (pipe_fb_addr[17:9] == rc_row))
                fbq_row_conflict <= 1'b1;
            else if (!d_busy)
                fbq_row_conflict <= 1'b0;
        end
    end
`ifndef SYNTHESIS
    always @(posedge clk) if (!rst && D_WRITE_FIFO) begin
        if (fbq_push && fbq_full && !fbq_pop)
            $fatal(1, "stv_vram_ddr_top: framebuffer FIFO overflow");
        if (fbq_pop && !fbq_head_valid)
            $fatal(1, "stv_vram_ddr_top: framebuffer FIFO pop without a current head");
        // v7j: the fences now qualify the ACK, so "ingress" is skd_push.  fbq_push is
        // an internal drain of pixels accepted BEFORE the fence and is expected to
        // continue through it (see the skd_pop comment).
        if (!D_BEAT_FIFO && (bts == B_DRAIN) && fb_we && fb_ack)
            $fatal(1, "stv_vram_ddr_top: framebuffer ingress escaped B_DRAIN fence");
        if (c_start && fb_we && fb_ack)
            $fatal(1, "stv_vram_ddr_top: framebuffer ingress escaped C transaction fence");
        // v7j: this guards the PRODUCER edge (a pixel accepted from the blitter on the
        // same cycle it raises the flush).  With the ingress skid that boundary is
        // skd_push; fbq_push is now an internal skid->FIFO transfer that legitimately
        // continues while fb_flush is held, so testing it there would be wrong.
        if (fb_we && fb_ack && fb_flush)
            $fatal(1, "stv_vram_ddr_top: framebuffer push and blit flush share an undefined edge");
        if (skd_push && (skd_occ == SKD_FULL) && !skd_pop)
            $fatal(1, "stv_vram_ddr_top: framebuffer ingress skid overflow");
        if (skd_pop && skd_empty)
            $fatal(1, "stv_vram_ddr_top: framebuffer ingress skid pop while empty");
    end
    initial if (D_BEAT_FIFO && !D_WRITE_FIFO)
        $fatal(1, "stv_vram_ddr_top: D_BEAT_FIFO requires D_WRITE_FIFO");
`endif

    logic [15:0] wc_beat;       // fb_addr[17:2]  (STV: 16-bit beat vs UMK3's 17)
    logic [3:0]  wc_mask;       // which of the 4 lanes are dirty
    logic [63:0] wc_data;       // combined beat
    logic [7:0]  wc_idle;
    localparam [7:0] FB_WFLUSH_IDLE = 8'd64;
    logic        cmb_fb_we_d;
    logic        fb_pend;       // held request the combiner could not accept at its edge
    logic        fb_flush_pend; // remember a one-cycle DMA flush until wc + rb are both drained
    wire  [15:0] fb_beat = d_fb_addr[17:2];
    wire         fb_same = FBCOMB && (wc_mask != 4'd0) && (fb_beat == wc_beat);
    wire         fb_new  = d_fb_we & ~cmb_fb_we_d;    // producer holds d_fb_we until d_fb_ack
    wire         fb_req  = fb_new | fb_pend;          // live request (edge or parked)
    // BSNOOP already makes a row fill coherent with older D work.  Writes for
    // unrelated rows may therefore keep entering the combiner while B owns
    // DDR; only a write to the row actively being filled must park because its
    // target beat may already have passed the fill snoop.
`ifdef MUT_FB_FILL_PARK
    wire         fb_fill_park_fifo = b_fill_active;
`else
    wire         fb_fill_park_fifo = b_fill_active && fb_req
                                   && (fb_beat[15:7] == fill_row);
`endif
    // Preserve the shipped/default contract exactly: without the NARC FIFO,
    // every B_DRAIN/B_REQ/B_FILL cycle parks D ingress.  Only the FIFO-enabled
    // path may exploit row-qualified overlap.
    wire         fb_fill_park = D_WRITE_FIFO ? fb_fill_park_fifo : b_fill_lock;
    // v7j: these three "the D lane has nothing left owed" predicates must span the
    // ingress skid as well as the FIFO (fbq_drained = fbq_empty && skd_empty).  With
    // the bare fbq_empty they park the combiner the instant the FIFO momentarily
    // empties while the skid is still feeding it, which deadlocks A against d_busy.
    wire         all_fb_drained = fbq_drained && !beat_pending;
    wire         d_ingress_park = D_WRITE_FIFO
                                ? (a_claim && all_fb_drained) : a_claim;
    wire         d_owner_final = D_WRITE_FIFO
                               ? (a_claim && all_fb_drained)
                               : (a_start || a_req_pending);
    wire         b_drain_final = (bts == B_DRAIN) && (!D_WRITE_FIFO || fbq_drained);
    wire         d_flush_req = (wc_mask != 4'd0) &&
                               ((fb_req && !fb_same) || (wc_idle >= FB_WFLUSH_IDLE)
                                 || d_owner_final || b_drain_final || fb_fill_park
                                 || d_fb_flush || fb_flush_pend);
                                // owner pending -> drain now
    // d_start, d_wr, d_addr hoisted to top (Questa declare-before-use)
    logic [63:0] d_wdata;
    logic [7:0]  d_be;
    logic        d_done, d_rd_valid;                   // driven by L2
    logic [63:0] d_rdata;                              // driven by L2
    logic [63:0] d_fwd;  logic [15:0] d_fwd_beat;  logic d_fwd_v;   // 1-deep own-write forward
    logic [3:0]  df_mask;  logic [63:0] df_data;  logic [15:0] df_beat;  // latched RMW flush job
    localparam [2:0] D_IDLE=3'd0, D_RD=3'd1, D_MRG=3'd2, D_WR=3'd3, D_WRB=3'd4;
    logic [2:0] dst;
    // ---- Piece 2/3: immediate run-buffer -- batch consecutive ASCENDING full be=F beats into ONE
    // Avalon write burst so the (high-latency real f2h) bridge round-trip is paid once per run, not
    // per beat. COHERENCY STAYS ON-ADD (per beat, immediate): the snoop/dwt/dsrcwt fire the cycle a
    // beat ENTERS the buffer (below), exactly like the single-beat path -- accept==commit for A/B/C.
    // Only the physical DDR3 write is deferred to the burst; A-forward would cover the in-flight
    // window, but A is granted only on !d_busy (rb empty) so the run is committed before A can read.
    // Partial (edge) beats never enter rb -> they keep the single-beat RMW path (FIRE the run first).
    localparam [3:0] RB_MAX = 4'd8;
`ifdef PERF_NO_DPARTIAL_BURST
    localparam DPARTBURST = 1'b0;
`else
    // NARC enables D_SHADOW_RMW_BYPASS.  Once a partial beat has a known
    // full-beat base (shadow hit or one DDR read), queue that merged full beat
    // beside ordinary full beats so a sprite row drains as one Avalon burst.
    // The donor/default path remains byte-for-byte behaviorally unchanged.
    localparam DPARTBURST = D_SHADOW_RMW_BYPASS;
`endif
    logic [63:0] rb_data [0:7];        // consecutive full beats awaiting a burst (rb_data[0]=lowest)
    logic [15:0] rb_base;              // beat addr of rb_data[0]
    // Timing-only mirror for the B refill snoop.  rb_base lives in the D
    // burst-combiner region; consuming it directly in bfill_merged produced a
    // -0.018 ns fitted path across the block.  Preserve an explicitly local
    // copy, updated on every rb_base write, so Quartus cannot merge it back
    // into the distant D register.  The synthesis-free invariant below proves
    // this remains an exact mirror rather than a stale coherency shortcut.
    (* preserve *) logic [15:0] bsn_rb_base_q;
    logic [3:0]  rb_cnt;               // 0..8 (0 = empty)
    logic [7:0]  rb_idle;              // cycles since the last add (drain timeout)
    logic [7:0]  d_blen;               // latched burst length (beats) at FIRE
    logic [3:0]  wstream_idx;          // L2 burst-write streaming pointer (driven in the L2 block)
    // Preserve the donor expression exactly when the NARC FIFO is disabled.
    // Besides keeping synthesis isolated, this avoids a simulator-only delta
    // pulse introduced by OR-ing a constant-elided fbq_busy term into the
    // legacy handoff between wc_mask and dst.
    generate
        if (D_WRITE_FIFO) begin : g_fbq_busy
            assign d_busy = fbq_busy || (dst != D_IDLE) ||
                            (wc_mask != 4'd0) || (rb_cnt != 4'd0);
        end else begin : g_legacy_busy
            assign d_busy = (dst != D_IDLE) ||
                            (wc_mask != 4'd0) || (rb_cnt != 4'd0);
        end
    endgenerate
    function automatic [63:0] d_lane_merge(input [63:0] base, input [63:0] neu, input [3:0] m);
        d_lane_merge = {m[3] ? neu[63:48] : base[63:48], m[2] ? neu[47:32] : base[47:32],
                        m[1] ? neu[31:16] : base[31:16], m[0] ? neu[15:0]  : base[15:0]};
    endfunction
    wire  [63:0] d_ownmerge = d_lane_merge(d_fwd, wc_data, wc_mask);
    wire  [63:0] d_wbmerge  = d_lane_merge(wb_data, wc_data, wc_mask);
    // Disposition of a completed wc beat: FULL + (empty run | ascending-contiguous) -> extend rb;
    // FULL + run-break, or PARTIAL, or a_start/idle/full -> FIRE the run as a burst (see the FSM).
    wire         fbeat_full = (wc_mask == 4'hF);
    wire         rb_ext     = (rb_cnt != 4'd0) && (rb_cnt < RB_MAX) && (wc_beat == rb_base + {12'd0, rb_cnt});
    wire         rb_accepts_df = (rb_cnt == 4'd0)
                               || ((rb_cnt < RB_MAX)
                                   && (df_beat == rb_base + {12'd0, rb_cnt}));
    // FIRE-on-completed-beat: only when a COMPLETED beat (d_flush_req) won't extend the run -- a full
    // run-break or any partial. Must NOT trigger on an empty combiner (else every lone beat fires as a
    // 1-beat "burst" the cycle after it's added and no run ever accumulates).
    wire         d_want_fire = (rb_cnt != 4'd0) && d_flush_req
                             && (fbeat_full ? !rb_ext
                                            : (!DPARTBURST || !rb_ext));
    // flush_now = a flush LAUNCHES this cycle (wc_mask -> 0 below). accept must exclude it: a same-
    // beat pixel arriving exactly as the idle-timeout fires would otherwise be both combined into wc
    // AND wiped by wc_mask<=0 in the same cycle = a DROPPED pixel. Excluded here -> it parks instead
    // and lands in the next (freshly empty) combiner.
    wire         flush_now = (dst == D_IDLE) && d_flush_req;
    wire         accept    = fb_req && !d_ingress_park && !fb_fill_park &&
                             (wc_mask == 4'd0 || fb_same) && !flush_now;
`ifdef MUT_FB_ACK_REGISTERED
    always_comb d_fb_ack = d_fb_ack_q;
`else
    // Same-cycle ready/accept: data and combiner state still capture on the
    // accepting edge, while the DMA advances on that edge instead of waiting
    // one extra clock.  This optimization is NARC-only; FIFO-off donor users
    // retain the original registered acknowledgement through d_fb_ack_q.
    always_comb d_fb_ack = D_WRITE_FIFO ? accept : d_fb_ack_q;
`endif
    // Preselect the coherent data independently of d_flush_req.  Values loaded
    // while dsrcwt_req is low are don't-care; on each live pulse this exactly
    // matches the corresponding dwt_data assignment below.
    always_comb begin
        dsrcwt_data_next = d_wdata;                 // D_MRG source
        if (dst == D_IDLE) begin
            if (fbeat_full)
                dsrcwt_data_next = wc_data;
            else if (wb_v && (wb_addr == {10'd0, wc_beat}))
                dsrcwt_data_next = d_wbmerge;
            else if (d_fwd_v && (d_fwd_beat == wc_beat))
                dsrcwt_data_next = d_ownmerge;
        end
    end
    always_ff @(posedge clk) begin
        if (rst) begin
            wc_beat<=16'd0; wc_mask<=4'd0; wc_data<=64'd0; wc_idle<=8'd0;
            cmb_fb_we_d<=1'b0; fb_pend<=1'b0; fb_flush_pend<=1'b0;
            d_fb_ack_q<=1'b0;
            d_start<=1'b0; d_wr<=1'b0; d_addr<=26'd0; d_wdata<=64'd0; d_be<=8'd0;
            d_fwd<=64'd0; d_fwd_beat<=16'd0; d_fwd_v<=1'b0;
            df_mask<=4'd0; df_data<=64'd0; df_beat<=16'd0; dst<=D_IDLE;
            dwt_req<=1'b0; dwt_col<=7'd0; dwt_data<=64'd0;
            dsrcwt_req<=1'b0; dsrcwt_idx<=8'd0; dsrcwt_data<=64'd0;
            rb_base<=16'd0; bsn_rb_base_q<=16'd0;
            rb_cnt<=4'd0; rb_idle<=8'd0; d_blen<=8'd0;
            d_is_burst<=1'b0; d_add<=1'b0; d_add_beat<=16'd0;
        end else begin
            d_fb_ack_q  <= 1'b0;
            cmb_fb_we_d <= d_fb_we;
            dwt_req     <= 1'b0;
            dsrcwt_req  <= 1'b0;
            dsrcwt_data <= dsrcwt_data_next;
            d_add       <= 1'b0;
            if (srt_invalidate_evt) d_fwd_v <= 1'b0;
            if (D_WRITE_FIFO && d_fb_flush) fb_flush_pend <= 1'b1;
            // Once all pre-flush work has been dispatched, the physical
            // D_WR/D_WRB may finish in the background; carrying the flush into
            // the next blit would force every new pixel to flush alone.
            // D_RD/D_MRG are excluded because they can still append one beat.
            else if (fb_flush_pend && (wc_mask == 4'd0) && (rb_cnt == 4'd0)
                     && (dst != D_RD) && (dst != D_MRG))
                fb_flush_pend <= 1'b0;
            // A persistent d_fwd copy is older than a later autoerase of the same row.  Drop
            // it before the fill snoop can resurrect a four-pixel ghost over erased data.
            // A legitimate same-cycle forward assignment below wins by nonblocking ordering.
            if (c_start && c_wr && d_fwd_v && (d_fwd_beat[15:7] == c_addr[15:7]))
                d_fwd_v <= 1'b0;
            if (wc_mask != 4'd0 && wc_idle != 8'hFF) wc_idle <= wc_idle + 8'd1;
            if (rb_cnt  != 4'd0 && rb_idle != 8'hFF) rb_idle <= rb_idle + 8'd1;
            // accept a pixel: empty or (combine-enabled) same-beat combiner, and NOT the flush-launch
            // cycle (one ack per request). Anything not accepted PARKS in fb_pend until a flush frees
            // it -- the dma holds addr/data until ack, so the parked pixel's fb_addr/fb_wdata are
            // still valid when it lands.
            if (accept) begin
                fb_pend <= 1'b0;
                wc_beat <= fb_beat;
                wc_mask[d_fb_addr[1:0]] <= 1'b1;
                wc_data[d_fb_addr[1:0]*16 +: 16] <= d_fb_wdata;
                d_fb_ack_q<= 1'b1;
                wc_idle <= 8'd0;
            end else if (fb_new) fb_pend <= 1'b1;   // fresh edge not taken this cycle -> hold it
            // ---- dispatch a completed wc beat / drain the run-buffer (immediate burst-combiner) ----
            if (dst == D_IDLE) begin
                if (rb_cnt != 4'd0 &&
                     (d_owner_final || b_drain_final || fb_fill_park || (rb_cnt == RB_MAX) ||
                      (rb_idle >= FB_WFLUSH_IDLE) || d_want_fire
                      || d_fb_flush || fb_flush_pend)) begin
                    // cont.24: blit done -> fire the accumulated run now
                    // FIRE the accumulated ASCENDING run as ONE Avalon burst (be=FF, addr auto-incs).
                    // CPU wants the port (a_start) / run full / run idle / the next beat won't extend
                    // it (run-break or a partial). The completed wc beat (if any) is NOT consumed here
                    // -> it re-dispatches into the freshly-empty run-buffer once the burst finishes.
                    d_addr <= {10'd0, rb_base};  d_blen <= {4'd0, rb_cnt};
                    d_wr <= 1'b1;  d_start <= 1'b1;  d_is_burst <= 1'b1;  dst <= D_WRB;
                    rb_cnt <= 4'd0;  rb_idle <= 8'd0;  d_fwd_v <= 1'b0;   // run supersedes the 1-deep fwd
                end else if (d_flush_req) begin
                    // reachable here: rb empty, OR the completed beat extends the run (rb_ext)
                    if (fbeat_full) begin                         // FULL beat -> ADD to the run-buffer
                        if (rb_cnt == 4'd0) begin
                            rb_base <= wc_beat;                   // start a run (else extend at rb_cnt)
                            bsn_rb_base_q <= wc_beat;
                        end
                        rb_data[rb_cnt] <= wc_data;  rb_cnt <= rb_cnt + 4'd1;  rb_idle <= 8'd0;
                        wc_mask <= 4'd0;
                        // ON-ADD COHERENCY (immediate, per beat -- identical to the single-beat launch).
                        // MUTATION -DMUT_NO_ONADD drops it: a burst then commits beats whose stale A/B/C
                        // cache copies are never invalidated -> fbcombine (c)/(d) + xdiff MUST fail. That
                        // failure is the proof the burst path is exercised AND on-add is load-bearing.
`ifndef MUT_NO_ONADD
                        d_add <= 1'b1;  d_add_beat <= wc_beat;     // A beat-cache snoop-invalidate (A block)
                        dwt_req  <= (rc_valid && (wc_beat[15:7]==rc_row));  dwt_col <= wc_beat[6:0];  dwt_data <= wc_data;
                        dsrcwt_req <= (wc_beat[15:7]==9'd510) || (wc_beat[15:7]==9'd511);
                        dsrcwt_idx <= {(wc_beat[15:7]==9'd511), wc_beat[6:0]};
`endif
                        d_fwd_v <= 1'b0;                           // a full beat supersedes the partial fwd
`ifndef MUT_AWB_DPARTIAL_STALE
                    end else if (wb_v && (wb_addr == {10'd0, wc_beat})) begin
                        // PARTIAL over A's dirty write-behind beat: wb_data is the newest whole-beat
                        // image and MUST outrank both D's own forward and DDR. Launch one full merged
                        // write directly; the A-side launched-write snoop clears wb_v on the next
                        // ownership edge, after d_wdata has captured every A and D lane.
                        df_mask <= wc_mask;  df_data <= wc_data;  df_beat <= wc_beat;  wc_mask <= 4'd0;
                        d_wdata <= d_wbmerge;  d_addr <= {10'd0, wc_beat};  d_be <= 8'hFF;
                        d_wr <= 1'b1;  d_start <= 1'b1;  d_is_burst <= 1'b0;  dst <= D_WR;
                        d_fwd <= d_wbmerge;  d_fwd_beat <= wc_beat;  d_fwd_v <= 1'b1;
                        dwt_req  <= (rc_valid && (wc_beat[15:7]==rc_row));
                        dwt_col  <= wc_beat[6:0];  dwt_data <= d_wbmerge;
                        dsrcwt_req <= (wc_beat[15:7]==9'd510) || (wc_beat[15:7]==9'd511);
                        dsrcwt_idx <= {(wc_beat[15:7]==9'd511), wc_beat[6:0]};
`endif
                    end else if (d_fwd_v && (d_fwd_beat == wc_beat)) begin  // PARTIAL: own-write forward
                        df_mask <= wc_mask;  df_data <= wc_data;  df_beat <= wc_beat;  wc_mask <= 4'd0;
                        d_wdata <= d_ownmerge;  d_addr <= {10'd0, wc_beat};  d_be <= 8'hFF;
                        d_wr <= 1'b1;  d_start <= 1'b1;  d_is_burst <= 1'b0;  dst <= D_WR;
                        d_fwd <= d_ownmerge;  d_fwd_beat <= wc_beat;
                        dwt_req  <= (rc_valid && (wc_beat[15:7]==rc_row));  dwt_col <= wc_beat[6:0];  dwt_data <= d_ownmerge;
                        dsrcwt_req <= (wc_beat[15:7]==9'd510) || (wc_beat[15:7]==9'd511);
                        dsrcwt_idx <= {(wc_beat[15:7]==9'd511), wc_beat[6:0]};
                    end else begin                                // PARTIAL: RMW read first
                        df_mask <= wc_mask;  df_data <= wc_data;  df_beat <= wc_beat;  wc_mask <= 4'd0;
                        d_addr <= {10'd0, wc_beat};  d_wr <= 1'b0;  d_start <= 1'b1;  d_is_burst <= 1'b0;  dst <= D_RD;
                    end
                end
            end
            case (dst)
                D_RD: begin
                    // shadow override (see shw_* decl): stale-RMW-merge immunity at depth
                    if (d_shadow_bypass) begin
                        // The tagged shadow is the RTL's exact newest full beat.
                        // Merge locally; no DDR read, proof poll or posted-range
                        // wait is needed. The normal full-beat write still lands.
                        d_wdata <= d_lane_merge(shw_rsp_data_q, df_data, df_mask);
                        d_start <= 1'b0;
                        dst <= D_MRG;
                    end else begin
                        if (d_rd_valid) d_wdata <= d_lane_merge(
                            (shw_en && shw_base_hit) ? shw_base : d_rdata,
                            df_data, df_mask);
                        if (d_done) begin d_start <= 1'b0; dst <= D_MRG; end
                    end
                end
                D_MRG: begin
                    if (DPARTBURST) begin
                        // The partial is now a complete 64-bit image.  Queue it
                        // exactly like an originally-full beat so adjacent
                        // sparse sprite beats share one physical DDR burst.
                        // D_IDLE drained any non-contiguous/full rb before the
                        // RMW launch, therefore this append is bounded and
                        // ascending by construction.
                        if (rb_cnt == 4'd0) begin
                            rb_base <= df_beat;
                            bsn_rb_base_q <= df_beat;
                        end
                        rb_data[rb_cnt] <= d_wdata;
                        rb_cnt <= rb_cnt + 4'd1;
                        rb_idle <= 8'd0;
                        d_start <= 1'b0; d_wr <= 1'b0; d_is_burst <= 1'b0;
                        dst <= D_IDLE;
                        // Coherency remains ON-ADD, before the physical burst:
                        // invalidate A and update live B/C cache copies.
                        d_add <= 1'b1; d_add_beat <= df_beat;
                        dwt_req  <= (rc_valid && (df_beat[15:7]==rc_row));
                        dwt_col  <= df_beat[6:0]; dwt_data <= d_wdata;
                        dsrcwt_req <= (df_beat[15:7]==9'd510) || (df_beat[15:7]==9'd511);
                        dsrcwt_idx <= {(df_beat[15:7]==9'd511), df_beat[6:0]};
                        d_fwd <= d_wdata; d_fwd_beat <= df_beat; d_fwd_v <= 1'b1;
`ifndef SYNTHESIS
                        if (!rb_accepts_df)
                            $fatal(1, "stv_vram_ddr_top: non-contiguous/full partial-rb append beat=%h base=%h cnt=%0d",
                                   df_beat, rb_base, rb_cnt);
`endif
                    end else begin                         // legacy single-beat write
                        d_addr <= {10'd0, df_beat};  d_be <= 8'hFF;  d_wr <= 1'b1;  d_start <= 1'b1;
                        d_fwd <= d_wdata;  d_fwd_beat <= df_beat;  d_fwd_v <= 1'b1;
                        dwt_req  <= (rc_valid && (df_beat[15:7]==rc_row));  dwt_col <= df_beat[6:0];  dwt_data <= d_wdata;
                        dsrcwt_req <= (df_beat[15:7]==9'd510) || (df_beat[15:7]==9'd511);
                        dsrcwt_idx <= {(df_beat[15:7]==9'd511), df_beat[6:0]};
                        dst <= D_WR;
                    end
                end
                D_WR:  if (d_done) begin d_start <= 1'b0; d_wr <= 1'b0; d_is_burst <= 1'b0; dst <= D_IDLE; end
                D_WRB: if (d_done) begin d_start <= 1'b0; d_wr <= 1'b0; d_is_burst <= 1'b0; dst <= D_IDLE; end   // whole run drained
                default: ;
            endcase
        end
    end

`ifndef SYNTHESIS
    always @(posedge clk) if (!rst && (bsn_rb_base_q !== rb_base))
        $fatal(1, "stv_vram_ddr_top: bsn rb-base mirror skew q=%h live=%h",
               bsn_rb_base_q, rb_base);
`endif

    // ---- BSNOOP: bounded-time coherent scanout fill ----------------------------------------
    // Overlay the DDR fill beat with newer registered write state, oldest to newest.  Later
    // assignments win: DDR < last posted D write < A write-behind < D burst/run buffers <
    // current D single/RMW job < current partial combiner.
`ifdef MUT_NO_BSNOOP
    always_comb bfill_merged = b_rdata;
`else
    // v7h: registered tag (see bfill_bt_q decl). Do NOT "simplify" this back to the
    // concatenation -- that silently reverts the timing repair with every gate still green.
    wire [15:0] bfill_bt   = bfill_bt_q;
    // P0049: the rb/burst OFFSET arithmetic reads the duplicate. Everything else keeps the
    // original register, so fanout splits instead of one flop feeding all five consumers.
    wire [15:0] bfill_bt_rb = bfill_bt_rb_q;
    wire [15:0] bsn_bstoff = bfill_bt_rb - d_addr[15:0];
    wire        bsn_burst  = d_start && d_wr && d_is_burst &&
                             ({8'd0, bsn_bstoff} < {16'd0, d_blen});
    wire        bsn_single = d_start && d_wr && !d_is_burst &&
                             (d_addr[15:0] == bfill_bt);
    wire        bsn_rmwjob = ((dst==D_RD) || (dst==D_MRG)) && (df_beat == bfill_bt);
    wire [15:0] bsn_rboff  = bfill_bt_rb - bsn_rb_base_q;
    wire        bsn_rbacc  = (rb_cnt != 4'd0) &&
                             ({12'd0, bsn_rboff[3:0]} < {12'd0, rb_cnt}) &&
                             (bsn_rboff[15:4] == 12'd0);
`ifdef MUT_NO_BMERGE
    always_comb bfill_merged = b_rdata;
`else
    // v7j T2 REPAIR (structural, timing).  BEHAVIOUR IS UNCHANGED -- this is the same
    // oldest-to-newest overlay, re-associated so the rc[] BRAM write-data input sees a
    // shallower cone.  The old form was a 7-deep chain of 64-bit 2:1 muxes fed by TWO
    // independent 8:1 rb_data muxes, then two chained lane merges (~10 levels).  Three
    // exact rewrites, each priority-preserving:
    //   (1) bsn_rbacc and bsn_burst both select out of rb_data and rbacc wins (it is the
    //       later assignment), so pre-select the OFFSET and keep ONE 8:1 rb_data mux.
    //       Removes a whole 64-bit 8:1 mux level and halves rb_data's fanout.
    //   (2) The five "later assignment wins" overrides become a 3-bit priority ENCODE
    //       (4 selects -> 3 bits: one 6-LUT per bit) driving ONE 5:1 64-bit mux (2 levels),
    //       replacing the 5-deep 64-bit cascade.  Encode order is the exact reverse of the
    //       old assignment order, so the resolved source is identical for every input
    //       combination, including simultaneous hits.
    //   (3) The two chained d_lane_merge()s collapse into ONE 3:1 per lane (3 data + 2
    //       selects = 5 inputs -> a single 6-LUT), with wc still winning over the RMW job.
    // Coherency is NOT relaxed: every source and every qualifying compare is still present
    // and still consulted in the same precedence, which is why MUT_NO_BMERGE must keep
    // failing with its 6 stale sprite pixels.
    wire        bsn_dfwd  = d_fwd_v && (d_fwd_beat == bfill_bt);
    wire        bsn_wb    = wb_v && (wb_addr[15:0] == bfill_bt);
    wire        bsn_rb    = bsn_rbacc || bsn_burst;                 // (1)
    wire [2:0]  bsn_rboff3 = bsn_rbacc ? bsn_rboff[2:0] : bsn_bstoff[2:0];
    wire [63:0] bsn_rbpick = rb_data[bsn_rboff3];
    wire        bsn_wc    = (wc_mask != 4'd0) && (wc_beat == bfill_bt);
    // (2) newest-wins priority encode: single > {rbacc,burst} > wb > d_fwd > DDR
    wire [2:0]  bsn_sel = bsn_single ? 3'd4
                        : bsn_rb     ? 3'd3
                        : bsn_wb     ? 3'd2
                        : bsn_dfwd   ? 3'd1
                                     : 3'd0;
    logic [63:0] bfill_base;
    always_comb begin
        case (bsn_sel)
            3'd4:    bfill_base = d_wdata;
            3'd3:    bfill_base = bsn_rbpick;
            3'd2:    bfill_base = wb_data;
            3'd1:    bfill_base = d_fwd;
            default: bfill_base = b_rdata;
        endcase
    end
    // (3) single 3:1 lane select: wc (newest) > in-flight RMW job > resolved base
    wire [3:0] bsn_dfm = bsn_rmwjob ? df_mask : 4'd0;
    wire [3:0] bsn_wcm = bsn_wc     ? wc_mask : 4'd0;
    function automatic [15:0] bsn_lane(input [15:0] wcd, input [15:0] dfd,
                                      input [15:0] bas, input w, input d);
        bsn_lane = w ? wcd : (d ? dfd : bas);
    endfunction
    always_comb bfill_merged = {
        bsn_lane(wc_data[63:48], df_data[63:48], bfill_base[63:48], bsn_wcm[3], bsn_dfm[3]),
        bsn_lane(wc_data[47:32], df_data[47:32], bfill_base[47:32], bsn_wcm[2], bsn_dfm[2]),
        bsn_lane(wc_data[31:16], df_data[31:16], bfill_base[31:16], bsn_wcm[1], bsn_dfm[1]),
        bsn_lane(wc_data[15: 0], df_data[15: 0], bfill_base[15: 0], bsn_wcm[0], bsn_dfm[0])};
`endif
`endif

    // ================= E: raw TMS34010 shift-register burst engine =================
    // MAME's Midway callback copies 2*512 raw uint16_t framebuffer entries at
    // address>>3. A raw entry is {palette-bank,pixel}; it is NOT the normal
    // videobank-selected CPU field view. NARC's scroll loop performs one load
    // and one store for every two display lines, so serial single-entry DDR
    // commands are functionally closer but far too slow. Keep the persistent
    // shift register as 256 packed 64-bit beats and transfer it in 16-beat
    // Avalon bursts. B scanout remains higher priority between sub-bursts.
    localparam [7:0] SRT_CHUNK = 8'd16;
    (* ramstyle="M10K" *) logic [63:0] srt_mem [0:255];
    logic [63:0] srt_stage [0:15];
    logic [63:0] srt_mem_q;
    logic [7:0]  srt_mem_ra;
    logic [7:0]  srt_beat, srt_rcv;
    logic [4:0]  srt_stage_cnt;
    logic [15:0] srt_base_beat;
    logic [15:0] srt_first;
    logic        srt_buf_valid;
    logic        srt_armed;
    logic [3:0]  e_stream_idx;

    localparam [2:0] E_IDLE=3'd0, E_RD_REQ=3'd1, E_RD_RCV=3'd2,
                     E_STAGE=3'd3, E_WR_WAIT=3'd4;
    logic [2:0] ets;
`ifdef MUT_SRT_RAW_BASE_WORD
    wire [17:0] srt_req_entry = {1'b0, widx[16:0]};    // mutant: address>>4
`else
    wire [17:0] srt_req_entry = {widx[16:0], boff[3]}; // bit address >> 3
`endif
`ifdef MUT_SRT_RAW_OFFBY1
    wire [7:0]  srt_chunk_len = (srt_beat == 8'd240) ? 8'd15 : SRT_CHUNK;
`else
    wire [7:0]  srt_chunk_len = SRT_CHUNK;
`endif
    assign srt_claim = srt_busy || (req && srt_i);
`ifdef MUT_SRT_SCAN_INTERLEAVE
    // Mutation: let B refill between store chunks and invalidate immediately,
    // exposing a partially-copied row to scanout.
    assign srt_store_atomic  = 1'b0;
    assign srt_invalidate_evt = e_start && e_wr;
`else
    // MAME completes the raw callback synchronously. Preserve that visibility:
    // a cached old row may finish, but no new B fill may observe a partial SRT
    // store. Invalidate the old cache only after all 256 DDR beats commit.
    assign srt_store_atomic  = srt_busy && srt_store_q;
    assign srt_invalidate_evt = srt_done && srt_store_q;
`endif
    wire [7:0]  srt_next_beat = srt_beat + SRT_CHUNK;
    wire        e_is_burst = e_start && e_wr;
    wire [63:0] e_wdata = srt_stage[e_stream_idx];

    always_ff @(posedge clk) begin
        srt_mem_q <= srt_mem[srt_mem_ra];
        if (rst) begin
            ets<=E_IDLE; srt_busy<=1'b0; srt_done<=1'b0; srt_rdata<=32'd0;
            srt_buf_valid<=1'b0; srt_store_q<=1'b0; srt_beat<=8'd0; srt_rcv<=8'd0;
            srt_armed<=1'b1;
            srt_stage_cnt<=5'd0; srt_base_beat<=16'd0; srt_first<=16'd0;
            srt_mem_ra<=8'd0; e_start<=1'b0; e_wr<=1'b0;
            e_addr<=26'd0; e_burstlen<=SRT_CHUNK;
        end else begin
            srt_done <= 1'b0;
            if (!req || !srt_i) srt_armed <= 1'b1;
            case (ets)
                E_IDLE: begin
                    e_start <= 1'b0;
                    if (req && srt_i && srt_armed) begin
                        srt_armed      <= 1'b0;
                        srt_busy      <= 1'b1;
                        srt_store_q   <= we;
                        srt_beat      <= 8'd0;
                        srt_base_beat <= srt_req_entry[17:2];
                        if (we) begin
                            // from_shiftreg: source operand is ignored; stream
                            // the persistent raw buffer to the destination.
                            srt_mem_ra    <= 8'd0;
                            srt_stage_cnt <= 5'd0;
                            ets           <= E_STAGE;
                        end else begin
                            // to_shiftreg: fill the raw buffer from the source.
                            ets <= E_RD_REQ;
                        end
                    end
                end
                E_RD_REQ: begin
                    e_addr     <= {10'd0, srt_base_beat + {8'd0, srt_beat}};
                    e_burstlen <= srt_chunk_len;
                    e_wr       <= 1'b0;
                    e_start    <= 1'b1;
                    srt_rcv    <= 8'd0;
                    ets        <= E_RD_RCV;
                end
                E_RD_RCV: begin
                    if (e_rd_valid) begin
`ifdef MUT_SRT_RAW_DROP_PALETTE
                        srt_mem[srt_beat + srt_rcv] <= {8'h00, e_rdata[55:48],
                                                       8'h00, e_rdata[39:32],
                                                       8'h00, e_rdata[23:16],
                                                       8'h00, e_rdata[7:0]};
`else
                        srt_mem[srt_beat + srt_rcv] <= e_rdata;
`endif
                        if ((srt_beat == 8'd0) && (srt_rcv == 8'd0))
                            srt_first <= e_rdata[15:0];
                        srt_rcv <= srt_rcv + 8'd1;
                    end
                    if (e_done) begin
                        e_start <= 1'b0;
`ifdef MUT_SRT_RAW_HALF
                        if (srt_next_beat == 8'd128) begin
`else
                        if (srt_next_beat == 8'd0) begin
`endif
                            srt_buf_valid <= 1'b1;
                            srt_busy      <= 1'b0;
                            srt_rdata     <= {16'h0, srt_first};
                            srt_done      <= 1'b1;
                            ets           <= E_IDLE;
                        end else begin
                            srt_beat <= srt_next_beat;
                            ets      <= E_RD_REQ;
                        end
                    end
                end
                E_STAGE: begin
                    // Registered M10K read. cnt=0 is the settle cycle; cnt=1..16
                    // capture one 16-beat write chunk into the streaming flops.
                    if (srt_stage_cnt == 5'd0) begin
                        srt_mem_ra    <= srt_beat + 8'd1;
                        srt_stage_cnt <= 5'd1;
                    end else begin
                        srt_stage[srt_stage_cnt[3:0] - 4'd1] <= srt_mem_q;
                        if (srt_stage_cnt == 5'd16) begin
                            e_addr     <= {10'd0, srt_base_beat + {8'd0, srt_beat}};
                            e_burstlen <= srt_chunk_len;
                            e_wr       <= 1'b1;
                            e_start    <= 1'b1;
                            ets        <= E_WR_WAIT;
                        end else begin
                            srt_mem_ra    <= srt_beat + {3'd0, srt_stage_cnt} + 8'd1;
                            srt_stage_cnt <= srt_stage_cnt + 5'd1;
                        end
                    end
                end
                E_WR_WAIT: if (e_done) begin
                    e_start <= 1'b0;
`ifdef MUT_SRT_RAW_HALF
                    if (srt_next_beat == 8'd128) begin
`else
                    if (srt_next_beat == 8'd0) begin
`endif
                        srt_busy  <= 1'b0;
                        srt_rdata <= 32'd0;
                        srt_done  <= 1'b1;
                        ets       <= E_IDLE;
                    end else begin
                        srt_beat      <= srt_next_beat;
                        srt_mem_ra    <= srt_next_beat;
                        srt_stage_cnt <= 5'd0;
                        ets           <= E_STAGE;
                    end
                end
                default: ets <= E_IDLE;
            endcase
        end
    end

`ifndef SYNTHESIS
    always_ff @(posedge clk) if (!rst && req && srt_i) begin
        if (srt_req_entry[1:0] != 2'b00)
            $fatal(1, "NARC SRT base is not raw-entry/DDR-beat aligned: %h", srt_req_entry);
        if (we && !srt_buf_valid)
            $fatal(1, "NARC from_shiftreg issued before to_shiftreg");
    end
`endif

    // ================= L2 arbiter: B (scanout) > A (CPU) > D (fb-combine) > C (erase) -> agent =====
    logic        tst_wr_req, tst_rd_req;
    logic [25:0] tst_addr;
    logic [63:0] tst_wdata_lat, tst_rdata;             // latched single-beat write value
    wire  [63:0] tst_wdata;                            // agent write data: live rb head during a D burst
    wire         tst_wnext;                            // agent: a burst write beat was accepted
    wire         d_burst_next;
    logic [ 7:0] tst_be, tst_burstcnt;
    logic        tst_rd_valid;

    logic [2:0] l_gnt;   // 0=A, 1=B, 2=C, 3=D, 4=E(raw SRT)
    localparam [2:0] L_IDLE=3'd0, L_ISSUE=3'd1, L_ACCEPT=3'd2,
                     L_RUN=3'd3, L_DONE=3'd4;

    // ---- PUBLICATION FENCE (2026-07-18, UMK3/Hangtime coherence transplant) ------------
    // The bridge ACCEPTS a write before the data is physically readable; a read issued in
    // that window returns STALE data, and a stale RMW merge writes the corruption back
    // PERMANENTLY (sim-reproduced: 66-entry vertical strip at RMW-preserved beat lanes
    // under cfg_pub_delay=3000; the cab "missing verticals" class). Fix: 4 independent
    // 128-row regions (beat addr [15:14]) go DIRTY at write acceptance (both endpoints of
    // a burst) and are cleared only when a 1-beat readback of the region's proof address
    // returns the exact final accepted value. Every READ issuer (B scan fill, A CPU read,
    // D partial-RMW read, C source-fill) to a dirty region issues the proof poll instead
    // of its access; WRITES are never gated (single-outstanding ordering). An already-
    // dirty region's proof ADVANCES to each later retired write (a later transaction
    // orders all older ones; without advancement a cross-region burst can strand an old
    // proof address whose value never reappears). Persistent across core rst (sdram_por
    // domain) like the agent. Caveat carried from the source work: readback-equality has
    // an ABA ambiguity if old==new; this is the leading reproduced mechanism, not a
    // documented bridge guarantee.
    logic [3:0]  pub_dirty;
    logic [15:0] pub_addr   [0:3];
    logic [63:0] pub_expect [0:3];
    logic [1:0]  pub_page;
    logic        l_proof;
    logic        tst_wr_done;  logic [25:0] tst_wr_base;
    logic [7:0]  tst_wr_count; logic [63:0] tst_wr_last_data;
    wire  [15:0] pub_ret_base = tst_wr_base[15:0];
    wire  [15:0] pub_ret_last = tst_wr_base[15:0] + {8'd0, tst_wr_count} - 16'd1;
    wire  [3:0]  pub_ret_mask = (4'b0001 << pub_ret_base[15:14]) | (4'b0001 << pub_ret_last[15:14]);
    // retirement-collision hold: metadata lands this edge; no gated read may issue using
    // the previous clean bit on the same cycle.
    wire         pub_hold = tst_wr_done;
    wire         pub_match_evt;

    // ---- bounded posted-range guard (A CPU / D partial-RMW / C source reads) ----------
    // These reads must NOT go through the readback fence: a blit's own write stream
    // re-arms its region's proof forever (measured self-livelock at launch 33). Instead
    // a read OVERLAPPING a recently-accepted write range WAITS until the range ages out
    // (PG_WINDOW clk, sized >= the bridge's realistic publication latency). 4-deep
    // rotating history: deep posting keeps several transactions unpublished at once --
    // a 1-deep range is the reference's own killed mutation. Publication beyond
    // PG_WINDOW remains the documented ABA-class caveat (readback cannot bound it
    // without livelocking the write path).
    localparam int PG_WINDOW = 2047;
    logic [15:0] pg_base [0:3];
    logic [15:0] pg_last [0:3];
    logic [10:0] pg_age  [0:3];
    logic [1:0]  pg_wr;
    integer pge;
    always_ff @(posedge clk) begin
        if (sdram_por) begin
            for (pge = 0; pge < 4; pge = pge + 1) begin
                pg_base[pge] <= 16'd0; pg_last[pge] <= 16'd0; pg_age[pge] <= 11'd0;
            end
            pg_wr <= 2'd0;
        end else begin
            for (pge = 0; pge < 4; pge = pge + 1)
                if (pg_age[pge] != 11'd0) pg_age[pge] <= pg_age[pge] - 11'd1;
            if (tst_wr_done) begin
                pg_base[pg_wr] <= pub_ret_base; pg_last[pg_wr] <= pub_ret_last;
                pg_age[pg_wr]  <= 11'(PG_WINDOW);
                pg_wr <= pg_wr + 2'd1;
            end
        end
    end
    // shadow write capture: every accepted beat, straight off the agent's accept
    // stream -- tst_wnext covers burst beats 0..n-2 (FWFT pops), tst_wr_done's
    // registered {addr,data} covers the final (and any single) beat.
    logic [7:0] shw_cnt;
    wire [15:0] shw_wa = tst_addr[15:0] + {8'd0, shw_cnt};
    wire shw_write_evt = tst_wr_done || tst_wnext;
    // one write port: burst beats stream through tst_wnext; the final (or single)
    // beat lands via tst_wr_done a cycle later.
    always_ff @(posedge clk) begin
        if (sdram_por) begin
            shw_cnt <= 8'd0;
            shw_epoch <= 2'd0;
        end else begin
            if (tst_wr_req) shw_cnt <= 8'd0;
            if (tst_wnext) shw_cnt <= shw_cnt + 8'd1;
            if (shw_write_evt) shw_epoch <= shw_epoch + 2'd1;
            if (tst_wr_done) begin
                shw_mem[{pub_ret_last[11:7], pub_ret_last[5:0]}]
                    <= {shw_generation, 1'b1,
                        pub_ret_last[15:12], pub_ret_last[6],
                        tst_wr_last_data};
            end else if (tst_wnext) begin
                shw_mem[{shw_wa[11:7], shw_wa[5:0]}]
                    <= {shw_generation, 1'b1,
                        shw_wa[15:12], shw_wa[6], tst_wdata};
            end
        end
    end

    // Keep the original bulk-clear valid vector only in FIFO-off donor builds.
    // The NARC FIFO build validates the synchronous BRAM word by generation and
    // therefore has no indexed 2048:1 FF-vector read in its fitted datapath.
    generate
        if (!D_WRITE_FIFO) begin : g_shw_legacy_valid
            always_ff @(posedge clk) begin
                if (sdram_por) begin
                    shw_valid <= '0;
                end else if (tst_wr_done) begin
                    shw_valid[{pub_ret_last[11:7], pub_ret_last[5:0]}] <= 1'b1;
                end else if (tst_wnext) begin
                    shw_valid[{shw_wa[11:7], shw_wa[5:0]}] <= 1'b1;
                end
            end
        end
    endgenerate
    // Pipelined candidate lookup. The NARC D-side bypass gets lookup priority
    // while its partial job owns d_busy; A cannot be admitted until D drains.
`ifdef MUT_NO_DSHWBYPASS
    assign d_shadow_bypass_en = 1'b0;
`else
    assign d_shadow_bypass_en = D_SHADOW_RMW_BYPASS;
`endif
    assign d_shadow_lookup = d_shadow_bypass_en && d_start && !d_wr && !d_is_burst;
    // A and D ownership is exclusive. While A is active its address is the only
    // useful lookup, regardless of read versus write; otherwise D is the only
    // candidate.  The D-bypass predicate must not sit in this 2048-bit valid-
    // vector address cone: v7d's nested selector exposed d_wr/d_is_burst ->
    // shw_v_q at -0.357 ns.  The simpler owner mux is behaviorally identical
    // under the enforced ownership invariant and removes all write-mode inputs.
    wire [15:0] shw_cand = a_start ? a_addr[15:0] : d_addr[15:0];
    always_ff @(posedge clk) begin
        shw_q      <= shw_mem[{shw_cand[11:7], shw_cand[5:0]}];
        shw_cand_q <= shw_cand;
        if (sdram_por) shw_read_epoch_q <= 2'd0;
        else           shw_read_epoch_q <= shw_epoch;
    end
    generate
        if (D_WRITE_FIFO) begin : g_shw_generation_valid
            always_ff @(posedge clk) shw_v_q <= 1'b1;
        end else begin : g_shw_vector_valid
            always_ff @(posedge clk)
                shw_v_q <= shw_valid[{shw_cand[11:7], shw_cand[5:0]}];
        end
    endgenerate
    // v7b fitted at -0.428 ns because the raw M10K output/tag compare directly
    // controlled tst_addr/tst_burstcnt enables through the L2 arbitration cone.
    // Register the complete lookup response.  The epoch travels with the read
    // and invalidates both read-during-write ambiguity and any response made
    // stale by an intervening accepted shadow write.
    always_ff @(posedge clk) begin
        if (sdram_por) begin
            shw_rsp_data_q  <= 64'd0;
            shw_rsp_cand_q  <= 16'd0;
            shw_rsp_hit_q   <= 1'b0;
            shw_rsp_epoch_q <= 2'd0;
        end else begin
            shw_rsp_data_q  <= shw_q[63:0];
            shw_rsp_cand_q  <= shw_cand_q;
            shw_rsp_hit_q   <= shw_v_q
                             && (!D_WRITE_FIFO ||
                                 (shw_q[77:70] == shw_generation))
                             && shw_q[69]
                             && (shw_q[68:64] == {shw_cand_q[15:12], shw_cand_q[6]});
            shw_rsp_epoch_q <= shw_read_epoch_q;
        end
    end

    function automatic logic pg_overlap(input logic [15:0] lo, input logic [15:0] hi);
        pg_overlap = ((pg_age[0] != 11'd0) && !(hi < pg_base[0] || lo > pg_last[0]))
                  || ((pg_age[1] != 11'd0) && !(hi < pg_base[1] || lo > pg_last[1]))
                  || ((pg_age[2] != 11'd0) && !(hi < pg_base[2] || lo > pg_last[2]))
                  || ((pg_age[3] != 11'd0) && !(hi < pg_base[3] || lo > pg_last[3]));
    endfunction
    // lane-qualified pipelined hits + lookup CURRENCY (defined regardless of the
    // mutation switch: the grant latch consumes them). CURRENCY: an A/D read may
    // only be granted when the pipelined lookup corresponds to ITS address, or
    // the latch captures a stale miss and merges from possibly-stale DDR data.
    // Guard = eviction backstop on shadow MISSES only (a blanket hold stalled
    // every write-then-readback ~2047 clk; xdiff TIMEOUT).
    wire shw_rsp_fresh = (shw_rsp_epoch_q == shw_epoch);
    wire a_shw_hit  = shw_rsp_fresh && shw_rsp_hit_q && (shw_rsp_cand_q == a_addr[15:0]);
    wire d_shw_hit  = shw_rsp_fresh && shw_rsp_hit_q && (shw_rsp_cand_q == d_addr[15:0]);
    wire a_lkp_cur  = shw_rsp_fresh && (shw_rsp_cand_q == a_addr[15:0]);
    wire d_lkp_cur  = shw_rsp_fresh && (shw_rsp_cand_q == d_addr[15:0]);
    assign d_shadow_bypass = d_shadow_lookup && d_lkp_cur && d_shw_hit;
`ifdef YUNIT_NO_PUBGUARD
    // mutation build: whole publication protection off (fence + guard) -> the
    // delayed-publication A/B must re-show the stale-RMW corruption strip.
    wire pub_fence_en = 1'b0;
    wire a_pub_hazard = 1'b0;
    wire d_pub_hazard = 1'b0;
    wire c_pub_hazard = 1'b0;
`else
    wire pub_fence_en = 1'b1;
    wire a_pub_hazard = (pg_overlap(a_addr[15:0], a_addr[15:0]) && !a_shw_hit) || tst_wr_done || !a_lkp_cur;
    wire d_pub_hazard = (pg_overlap(d_addr[15:0], d_addr[15:0]) && !d_shw_hit) || tst_wr_done || !d_lkp_cur;
    wire c_pub_hazard = pg_overlap(c_addr[15:0], c_addr[15:0] + {8'd0, c_burstlen} - 16'd1) || tst_wr_done;
`endif
    integer pgi;
    always_ff @(posedge clk) begin
        if (sdram_por) begin
            pub_dirty <= 4'b0000;
            for (pgi = 0; pgi < 4; pgi = pgi + 1) begin
                pub_addr[pgi] <= 16'd0; pub_expect[pgi] <= 64'd0;
            end
        end else begin
            if (pub_match_evt) pub_dirty[pub_page] <= 1'b0;
            if (tst_wr_done)
                for (pgi = 0; pgi < 4; pgi = pgi + 1)
                    if (pub_dirty[pgi] || pub_ret_mask[pgi]) begin
                        pub_dirty[pgi]  <= 1'b1;               // re-dirty wins over a same-edge match
                        pub_addr[pgi]   <= pub_ret_last;
                        pub_expect[pgi] <= tst_wr_last_data;
                    end
        end
    end
    // Burst-write streaming (D fb-combine AND C erase, cont.24): present the granted lane's run-
    // buffer head on tst_wdata (FWFT); each tst_wnext (agent accepted a beat) advances wstream_idx.
    // wstream_idx reset at the burst grant below. Only one lane is granted at a time -> shared idx.
    wire e_burst_next = (l_gnt==3'd4 && ls==L_RUN) && tst_wnext;
    assign tst_wdata    = (l_gnt==3'd4 && e_is_burst) ? e_wdata
                        : (l_gnt==3'd3 && d_is_burst) ? rb_data[wstream_idx]
                        : (l_gnt==3'd2 && c_is_burst) ? cb_data[wstream_idx]
                        : tst_wdata_lat;
    assign d_burst_next = (((l_gnt==3'd3 && d_is_burst) || (l_gnt==3'd2 && c_is_burst)) && ls==L_RUN) && tst_wnext;

    // C-lane aging (see the C_FAIR parameter). Counts ARBITRATION cycles in which C is asking
    // and the ladder chose someone else; cleared the moment C is granted or stops asking, so a
    // C that is keeping up never elevates and the donor-equivalent path is the common case.
`ifdef MUT_CFAIR_OFF
    localparam bit C_FAIR_EN = 1'b0;   // MUTATION: force the unfair ladder back (gate must go RED)
`else
    localparam bit C_FAIR_EN = C_FAIR;
`endif
    always_ff @(posedge clk) begin
        if (rst) begin
            c_wait <= 16'd0;
        end else if (!c_start) begin
            c_wait <= 16'd0;                                   // not asking
        end else if ((ls == L_ISSUE) && (l_gnt == 3'd2)) begin
            c_wait <= 16'd0;                                   // granted -- progress made
        end else if ((ls == L_IDLE) && (c_wait != 16'hFFFF)) begin
            c_wait <= c_wait + 16'd1;                          // asked, passed over
        end
    end
    assign c_urgent = C_FAIR_EN && (c_wait >= C_FAIR_AGE[15:0]);
    always_ff @(posedge clk) begin
        if (rst) begin
            ls<=L_IDLE; l_gnt<=3'd0; tst_rd_req<=1'b0; tst_wr_req<=1'b0;
            tst_addr<=26'd0; tst_wdata_lat<=64'd0; tst_be<=8'd0; tst_burstcnt<=8'd1;
            a_done<=1'b0; b_done<=1'b0; c_done<=1'b0; d_done<=1'b0; e_done<=1'b0;
            wstream_idx<=4'd0; e_stream_idx<=4'd0;
            l_proof<=1'b0; pub_page<=2'd0;   // fence STATE (pub_dirty/addr/expect) is sdram_por-persistent
        end else begin
            tst_rd_req<=1'b0; tst_wr_req<=1'b0; a_done<=1'b0; b_done<=1'b0; c_done<=1'b0; d_done<=1'b0; e_done<=1'b0;
            if (d_burst_next) wstream_idx <= wstream_idx + 4'd1;   // advance the D-burst FWFT source
            if (e_burst_next) e_stream_idx <= e_stream_idx + 4'd1;
            case (ls)
                // Gate acceptance on the agent actually being IDLE. The agent runs on sdram_por while
                // A/B/L2 run on core rst (P0022 split): a core_rst pulse mid-burst snaps L2 to L_IDLE
                // while the agent keeps draining its pre-reset transaction. Without this guard L2 would
                // pulse a req the busy agent ignores, then mistake the OLD transaction's tst_busy for
                // its own acceptance and fabricate a completion for an access that never issued
                // ([[lessons_gate_fsm_not_output]] — never sequence on a busy you do not own). Waiting
                // for !tst_busy makes the orphaned burst drain (its beats are dropped: a_rd_valid/
                // b_rd_valid are gated on ls==L_RUN) before any fresh command is issued.
                // PRIORITY (4-way, W-THRU2): B (scanout, hard real-time) > A (CPU, latency-critical,
                // P1.9e) > D (fb-combine, redraw bulk) > C (erase, beam-paced background). A is gated
                // on !d_busy so the CPU only issues once the combiner has DRAINED to DDR -- combined
                // with a_start forcing a D flush + parking new fb accepts (see the D block), this
                // orders CPU-vs-fb on the shared VRAM and stops the sustained fb stream from starving
                // the CPU lane (the contention-gate deadlock). D above C: the combined fb write is
                // now ~1 beat / 4px (was ~2 RMW ops/px) so its total demand is small, and the beam-
                // paced C engine (goal/catch-up, ~5x per-line slack) keeps up between D's 1-beat
                // flushes (d_start is low while the combiner accumulates, so C is granted then).
                // v7b also fitted a_addr/shadow-response -> tst_addr at about
                // -0.5 ns.  L_IDLE now registers only the qualified owner; the
                // following L_ISSUE cycle emits the stable command.  Requesters
                // already hold every payload until *_done, and no agent write can
                // retire between selection and issue, so this is a real pipeline
                // boundary rather than a timing exception.
                L_IDLE: if (!tst_busy) begin
                    // PUBLICATION FENCE: any READ to a dirty region issues the region's
                    // 1-beat proof readback instead (same lane grant, l_proof marked);
                    // the lane's start stays held and re-arbitrates until the region
                    // proves published. pub_hold = retirement-collision 1-cycle hold.
                    if (srt_store_atomic) begin
                        // Atomic raw-store visibility. During staging gaps this
                        // intentionally grants nobody; a pending B miss resumes
                        // after the final store beat and cache invalidation.
                        if (e_start && !d_busy && !beat_pending &&
                            (ats==A_IDLE) && !a_start && !wb_v) begin
                            l_gnt<=3'd4; l_proof<=1'b0; ls<=L_ISSUE;
                        end
                    end else if (b_start) begin              // B: scanout sub-burst = highest priority
                        // Display reads cannot corrupt memory.  BSNOOP makes their coherency
                        // bounded at fill time, so only the write-back paths retain proof fences.
                        // A FIFO miss drains all live BSNOOP structures before
                        // filling.  Those writes may still be posted behind the
                        // bridge, so that one fill must reuse the publication
                        // proof even though ordinary BSNOOP fills stay bounded.
                        if ((!BSNOOP || b_fifo_fenced) && pub_fence_en && pub_hold) begin end
                        else if ((!BSNOOP || b_fifo_fenced) && pub_fence_en &&
                                 pub_dirty[b_addr[15:14]]) begin
                            l_gnt<=3'd1; l_proof<=1'b1; pub_page<=b_addr[15:14];
                            ls<=L_ISSUE;
                        end else begin
                            l_gnt<=3'd1; l_proof<=1'b0; ls<=L_ISSUE;
                        end
                    end else if (b_bus_lock) begin            // atomic row fill: reserve sub-burst gaps for B
                    end else if (e_start && !d_busy && !beat_pending &&
                                 (ats==A_IDLE) && !a_start && !wb_v) begin
                                                              // E: raw SRT sub-burst, CPU waits
                        if (!e_wr && pub_fence_en && pub_hold) begin end
                        else if (!e_wr && pub_fence_en && pub_dirty[e_addr[15:14]]) begin
                            l_gnt<=3'd4; l_proof<=1'b1; pub_page<=e_addr[15:14];
                            ls<=L_ISSUE;
                        end else begin
                            l_gnt<=3'd4; l_proof<=1'b0; ls<=L_ISSUE;
                        end
                    end else if (c_urgent && c_start &&
                                 !srt_claim &&
                                 (!D_WRITE_FIFO || (!d_busy && !beat_pending))
                                 && !(!c_wr && c_pub_hazard)) begin
                        // C ELEVATED (C_FAIR): C has been passed over for C_FAIR_AGE arbitration
                        // cycles. Take it above A and D -- but never above B, which is hard
                        // real-time.
                        // THE HAZARD TEST IS IN THE BRANCH CONDITION, NOT THE BODY, AND THAT IS
                        // LOAD-BEARING. The first version guarded inside the arm ("if hazard,
                        // do nothing") copying the normal C arm below -- but that arm is LAST,
                        // so consuming a cycle there starves nobody. Up here it consumes the
                        // whole else-if chain, so a hazard-blocked C blocked A and D too.
                        // MEASURED regression: CPU max latency 343 clk -> 1,751,694 clk (over a
                        // full frame) at +cpugap=3 while the erase gate went green. Falling
                        // through to A on a hazard is what makes elevation safe.
                        l_gnt<=3'd2; l_proof<=1'b0; ls<=L_ISSUE;
                    end else if (a_start && !d_busy && !beat_pending) begin
                                                              // A: CPU single beat, only after all accepted D work
                        // RMW/CPU reads are NOT fence-gated (a blit's own write stream
                        // re-arms its region forever = self-livelock, measured: wedge at
                        // launch 33). They use the bounded posted-range guard instead.
                        if (!a_wr && a_pub_hazard) begin end  // overlaps a recently-posted window -> wait it out
                        else begin
                            l_gnt<=3'd0; l_proof<=1'b0; ls<=L_ISSUE;
                        end
                    end else if (d_start) begin              // D: fb-combine flush -- BURST run OR single beat
                        // The shadow RAM is synchronous.  Wait until its registered
                        // candidate is current before deciding hit versus miss; this
                        // also prevents a speculative DDR read from escaping when the
                        // publication-guard mutation is compiled for regression.
                        if (d_shadow_lookup && !d_lkp_cur) begin end
                        else if (d_shadow_bypass) begin end   // D consumes the local shadow in parallel
                        else if (!d_wr && !d_is_burst && d_pub_hazard) begin end  // partial-RMW read vs posted window
                        else begin
                            l_gnt<=3'd3; l_proof<=1'b0; ls<=L_ISSUE;
                        end
                    end else if (c_start &&
                                 !srt_claim &&
                                 (!D_WRITE_FIFO || (!d_busy && !beat_pending))) begin
                                                              // C: erase BURST write OR cold source-fill read
                        if (!c_wr && c_pub_hazard) begin end
                        else begin
                            l_gnt<=3'd2; l_proof<=1'b0; ls<=L_ISSUE;
                        end
                    end
                end
                L_ISSUE: if (!tst_busy) begin
                    case (l_gnt)
                        3'd1: begin                         // B: proof or scanout sub-burst
                            if (l_proof) begin
                                tst_addr<={10'd0, pub_addr[pub_page]};
                                tst_burstcnt<=8'd1;
                            end else begin
                                tst_addr<=b_addr;
                                tst_burstcnt<=b_burstlen;
                            end
                            tst_rd_req<=1'b1;
                        end
                        3'd0: begin                         // A: CPU single beat
                            tst_addr<=a_addr;
                            tst_burstcnt<=8'd1;
                            if (a_wr) begin
                                tst_wdata_lat<=a_wdata;
                                tst_be<=a_be;
                                tst_wr_req<=1'b1;
                            end else begin
                                tst_rd_req<=1'b1;
                                shw_base<=shw_rsp_data_q;
                                shw_base_hit<=(a_shw_hit === 1'b1);
                            end
                        end
                        3'd3: begin                         // D: fb-combine run or single beat
                            tst_addr<=d_addr;
                            if (d_is_burst) begin
                                tst_burstcnt<=d_blen;
                                tst_be<=8'hFF;
                                tst_wr_req<=1'b1;
                                wstream_idx<=4'd0;
                            end else begin
                                tst_burstcnt<=8'd1;
                                if (d_wr) begin
                                    tst_wdata_lat<=d_wdata;
                                    tst_be<=d_be;
                                    tst_wr_req<=1'b1;
                                end else begin
                                    tst_rd_req<=1'b1;
                                    shw_base<=shw_rsp_data_q;
                                    shw_base_hit<=(d_shw_hit === 1'b1);
                                end
                            end
                        end
                        3'd4: begin                         // E: raw SRT burst/proof
                            if (l_proof) begin
                                tst_addr<={10'd0, pub_addr[pub_page]};
                                tst_burstcnt<=8'd1;
                                tst_rd_req<=1'b1;
                            end else begin
                                tst_addr<=e_addr;
                                tst_burstcnt<=e_burstlen;
                                if (e_wr) begin
                                    tst_be<=8'hFF;
                                    tst_wr_req<=1'b1;
                                    e_stream_idx<=4'd0;
                                end else begin
                                    tst_rd_req<=1'b1;
                                end
                            end
                        end
                        default: begin                      // C: erase burst or cold source fill
                            tst_addr<=c_addr;
                            tst_burstcnt<=c_burstlen;
                            if (c_wr) begin
                                tst_be<=8'hFF;
                                tst_wr_req<=1'b1;
                                wstream_idx<=4'd0;
                            end else begin
                                tst_rd_req<=1'b1;
                            end
                        end
                    endcase
                    ls<=L_ACCEPT;
                end
                L_ACCEPT: if (tst_busy) ls<=L_RUN;            // agent accepted the transaction
                L_RUN: if (!tst_busy) begin                  // transaction complete
                        // a publication proof poll completes WITHOUT signalling the lane's
                        // done: the lane's held start re-arbitrates (poll again or, once
                        // pub_match_evt cleared the region this same cycle, run for real).
                        if (!l_proof)
                            case (l_gnt)
                                3'd1:    b_done<=1'b1;
                                3'd2:    c_done<=1'b1;
                                3'd3:    d_done<=1'b1;
                                3'd4:    e_done<=1'b1;
                                default: a_done<=1'b1;
                            endcase
                        l_proof<=1'b0;
                        ls<=L_DONE;
                    end
                L_DONE: ls<=L_IDLE;                           // bubble: requester clears its start level before re-arbitrate
                default: ls<=L_IDLE;
            endcase
        end
    end
    // route read beats to the granted consumer (a proof poll's beat goes to NO lane)
    assign a_rd_valid = (l_gnt==3'd0) && (ls==L_RUN) && tst_rd_valid && !l_proof;
    assign b_rd_valid = (l_gnt==3'd1) && (ls==L_RUN) && tst_rd_valid && !l_proof;
    assign c_rd_valid = (l_gnt==3'd2) && (ls==L_RUN) && tst_rd_valid && !l_proof;
    assign d_rd_valid = (l_gnt==3'd3) && (ls==L_RUN) && tst_rd_valid && !l_proof;
    assign e_rd_valid = (l_gnt==3'd4) && (ls==L_RUN) && tst_rd_valid && !l_proof;
    // publication proof: the 1-beat poll returned the exact final accepted value
    assign pub_match_evt = l_proof && (ls==L_RUN) && tst_rd_valid &&
                           (tst_rdata == pub_expect[pub_page]);
    assign a_rdata = tst_rdata;
    assign b_rdata = tst_rdata;
    assign c_rdata = tst_rdata;
    assign d_rdata = tst_rdata;
    assign e_rdata = tst_rdata;

    stv_vram_ddr_agent #(.VRAM_DDR_BASE(VRAM_DDR_BASE)) u_agent (
        .clk(clk), .sdram_por(sdram_por),
        .tst_wr_req(tst_wr_req), .tst_rd_req(tst_rd_req), .tst_addr(tst_addr),
        .tst_wdata(tst_wdata), .tst_be(tst_be), .tst_burstcnt(tst_burstcnt),
        .tst_rdata(tst_rdata), .tst_rd_valid(tst_rd_valid), .tst_busy(tst_busy), .tst_wnext(tst_wnext),
        .tst_wr_done(tst_wr_done), .tst_wr_base(tst_wr_base),
        .tst_wr_count(tst_wr_count), .tst_wr_last_data(tst_wr_last_data),
        .ddram_addr(ddram_addr), .ddram_burstcnt(ddram_burstcnt), .ddram_rd(ddram_rd), .ddram_we(ddram_we),
        .ddram_din(ddram_din), .ddram_be(ddram_be),
        .ddram_busy(ddram_busy), .ddram_dout(ddram_dout), .ddram_dout_ready(ddram_dout_ready) );
endmodule
`default_nettype wire
