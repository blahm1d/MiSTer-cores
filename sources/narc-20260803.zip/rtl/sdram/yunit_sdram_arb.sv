// yunit_sdram_arb.sv — Phase 6 W1f: system-level SDRAM arbiter + address map. Multiplexes
// the four Y-unit SDRAM requesters onto ONE physical 16-bit word port (a real MT48LC16M16
// controller in synth; the behavioral sdram_model in sim — both honor the same
// req-held-until-ack + edge-accept + inter-command-gap contract as vram_sdram_top).
//
//   vsd    : VRAM r/w + scanout (16-bit word; already merged by vram_sdram_top)   [run-time]
//   cpu_gfx: CPU gfx/ROM read   (BYTE; read a word, return the selected byte)      [run-time]
//   src    : blitter gfx read   (BYTE; same)                                       [run-time]
//   ioctl  : ROM load           (16-bit word write)                                [boot only]
//
// SDRAM WORD address map: gfx @0, program ROM @ROMB, VRAM @VRAMB. gfx/src byte address B ->
// word (GFXW_BASE + B>>1), byte = B[0]. cpu_gfx region: byte<GFX_BYTES -> gfx; else ROM.
`timescale 1ns/1ps
`default_nettype none
module yunit_sdram_arb #(
  parameter int SD_AW      = 25,
  parameter [SD_AW-1:0] GFXW_BASE  = 25'h000000,   // gfx words   @ 0
  parameter [SD_AW-1:0] ROMW_BASE  = 25'h0C0000,   // program ROM @ 0xC0000 words (=0x180000 B)
  parameter [SD_AW-1:0] VRAMW_BASE = 25'h0E0000,   // VRAM        @ 0xE0000 words
  parameter [23:0]      GFX_BYTES  = 24'h180000    // gfx region size in bytes (ROM follows)
)(
  input  logic         clk,
  input  logic         rst,
  // VRAM channel (16-bit word, from yunit_mem/vram_sdram_top)
  input  logic [SD_AW-1:0] vsd_addr,   // VRAM entry (word)
  input  logic [15:0]  vsd_din,
  input  logic [1:0]   vsd_be,
  input  logic         vsd_rd,
  input  logic         vsd_wr,
  output logic [15:0]  vsd_dout,
  output logic         vsd_ack,
  // CPU gfx/ROM read (req held until ack) — the yunit_mem external read port.
  // PERF: returns the full 16-bit SDRAM WORD at cgfx_addr&~1 (the SDRAM is natively
  // 16-bit; the old byte-serial return threw half of every read away and doubled the
  // CPU window's round trips). Byte-lane selection, when needed, happens in yunit_mem.
  input  logic         cgfx_rd,
  input  logic [23:0]  cgfx_addr,      // BYTE address in the CPU gfx/ROM space (gfx@0, ROM@GFX_BYTES)
  output logic [15:0]  cgfx_data,      // aligned word at cgfx_addr&~1
  output logic         cgfx_ack,
  // blitter src read (byte)
  input  logic         src_rd,
  input  logic [23:0]  src_addr,       // BYTE address into gfx
  output logic [7:0]   src_data,
  output logic         src_ack,
  // boot SDRAM channel (word rd/wr): serves BOTH the ioctl ROM download (writes) AND the
  // gfx-unpack pass (planar-scratch reads + flat-gfx writes) — they are disjoint in time
  // (download THEN unpack), so yunit_top muxes them into this one channel. Folding them
  // keeps the run-time sd_addr mux 4-way (VSD/CGFX/SRC/IOL) instead of 5, shortening the
  // scan_req->SDRAM_A path. iol_be: 2'b11 full-word, 2'b01/2'b10 byte-interleaved ROM.
  input  logic         iol_rd,
  input  logic         iol_wr,
  input  logic [SD_AW-1:0] iol_addr,   // word address (already mapped)
  input  logic [15:0]  iol_din,
  input  logic [1:0]   iol_be,
  output logic [15:0]  iol_dout,
  output logic         iol_ack,
  // dual-6809 sound-ROM read (req held until ack). WORD address, passed through with no
  // region math -- the caller (zunit_snd_rom) already knows SNDW_BASE and its per-CPU image
  // offset, and keeping the math out of here leaves the sd_addr mux the shallowest of the
  // five. LOWEST priority: a sound fetch has ~48 core clocks of slack per 6809 E cycle,
  // where the scanout burst and the 34010 do not.
  // NOTE: NO SystemVerilog default port value here. sv2v lowers a defaulted input to
  // `input reg`, which Verilog forbids -- Quartus rejects it (Error 10279) and every
  // downstream design unit cascades. Every instantiation ties these off EXPLICITLY.
  input  logic         snd_rd,
  input  logic [SD_AW-1:0] snd_addr_w,  // WORD address (absolute)
  output logic [15:0]  snd_data,        // full word; the caller selects the byte lane
  output logic         snd_ack,
  // physical single-word SDRAM port
  output logic [SD_AW-1:0] sd_addr,
  output logic [15:0]  sd_din,
  output logic [1:0]   sd_be,
  output logic         sd_rd,
  output logic         sd_wr,
  input  logic [15:0]  sd_dout,
  input  logic         sd_ack
);
  // per-channel physical word address + the byte-select for the byte channel (src).
  // cgfx is word-wide now: no byte select, the whole sd_dout goes back.
  wire [SD_AW-1:0] cgfx_word = (cgfx_addr < GFX_BYTES)
                             ? (GFXW_BASE + {1'b0, cgfx_addr[23:1]})
                             : (ROMW_BASE + {1'b0, (cgfx_addr - GFX_BYTES) >> 1});
  wire [SD_AW-1:0] src_word  = GFXW_BASE + {1'b0, src_addr[23:1]};
  wire             src_bsel  = src_addr[0];
  wire [SD_AW-1:0] vsd_word  = VRAMW_BASE + vsd_addr;

  // grant-held arbiter with inter-command bubble (same contract vram_sdram_top proved).
  // priority: boot IOL (download/unpack) > VRAM (real-time scanout) > CPU gfx/ROM > blitter
  // src. IOL is top priority but is only active at boot, when the CPU/video are held in
  // reset (no VSD/CGFX/SRC traffic), so it never starves the scanout at run time.
  localparam logic [2:0] G_NONE=3'd0, G_IOL=3'd1, G_VSD=3'd2, G_CGFX=3'd3, G_SRC=3'd4, G_SND=3'd5;
  wire vsd_req = vsd_rd | vsd_wr;
  wire iol_req = iol_rd | iol_wr;
  logic [2:0] gnt; logic gnt_held; logic [2:0] gnt_r; logic bubble;

  // ---- P0042: BOUNDED SERVICE FOR THE SOUND LANE -------------------------------
  // G_SND is strict-lowest with no aging, and the consumer has NO timeout: once
  // zunit_snd_rom asserts snd_rd it is single-outstanding and `ready` stays low
  // until snd_ack, while narc_6809_clock_en stalls its phase counter whenever an E
  // edge is due and rom_ready is low. So ONE sufficiently long denial freezes BOTH
  // 6809s FOREVER -- the board never recovers and the cabinet is totally silent for
  // the session. That is a one-shot boot race, and it is placement-sensitive: v9
  // had working audio and v10, with NO change anywhere in the sound path, was
  // silent. Winning it by luck is not a fix.
  //
  // Give the lane an age counter: after SND_AGE_MAX consecutive clocks with a
  // pending sound request that is not being granted, promote it above the
  // best-effort requesters (CGFX/SRC) -- but still BELOW IOL (boot download, which
  // runs while the core is in reset) and BELOW VSD (real-time scanout, which cannot
  // be late). The promotion is released as soon as the lane is granted.
  //
  // The bound is generous: a 6809 E period is 48 clocks and the fetch has ~48
  // clocks of slack per period, so 512 clocks of denial already means the lane is
  // being starved rather than merely queued. This changes NOTHING in the common
  // case -- it only bounds the tail.
  localparam int SND_AGE_MAX = 512;
  logic [9:0] snd_age;
`ifdef MUT_SND_ARB_NO_AGING
  // Mutation (sim-only): restore strict-lowest sound priority.  The real-chain
  // starvation case must then time out before the watchdog can mask the fault.
  wire        snd_urgent = 1'b0;
`else
  wire        snd_urgent = (snd_age == SND_AGE_MAX[9:0]);
`endif
  always_ff @(posedge clk) begin
    if (rst)                       snd_age <= 10'd0;
    else if (!snd_rd)              snd_age <= 10'd0;   // no pending request
    else if (gnt == G_SND)         snd_age <= 10'd0;   // being served
    else if (snd_age != SND_AGE_MAX[9:0]) snd_age <= snd_age + 10'd1;
  end

  always_comb begin
    if (gnt_held)     gnt = gnt_r;
    else if (bubble)  gnt = G_NONE;
    else if (iol_req) gnt = G_IOL;
    // aged sound request: above best-effort, still below IOL and real-time scanout
    else if (snd_urgent && snd_rd && !vsd_req) gnt = G_SND;
`ifdef SIM_CPU_PRIORITY
    // measure-first probe: CPU ROM/gfx fetch above the scanout to prove the scanout is
    // starving CPU instruction fetch (the ~1-instr-per-scanline throttle). Sim-only.
    else if (cgfx_rd) gnt = G_CGFX;
    else if (vsd_req) gnt = G_VSD;
`else
    else if (vsd_req) gnt = G_VSD;
    else if (cgfx_rd) gnt = G_CGFX;
`endif
    else if (src_rd)  gnt = G_SRC;
    else if (snd_rd)  gnt = G_SND;
    else              gnt = G_NONE;
  end
  always_ff @(posedge clk) begin
    if (rst) begin gnt_held<=1'b0; gnt_r<=G_NONE; bubble<=1'b0; end
    else begin
      bubble <= 1'b0;
      if (!gnt_held) begin
        if (!bubble && gnt!=G_NONE) begin gnt_held<=1'b1; gnt_r<=gnt; end
      end else if (sd_ack) begin
        gnt_held<=1'b0; bubble<=1'b1;
      end
    end
  end

  // route the granted requester to the physical port; return ack/data to it only.
  logic src_bsel_q;                // (decl before use: Questa/Quartus need decl-before-use)
  always_ff @(posedge clk) begin   // latch the byte-select at grant time (src channel only)
    if (gnt==G_SRC)  src_bsel_q  <= src_bsel;
  end
  always_comb begin
    sd_addr='0; sd_din=16'h0; sd_be=2'b00; sd_rd=1'b0; sd_wr=1'b0;
    vsd_ack=1'b0; cgfx_ack=1'b0; src_ack=1'b0; iol_ack=1'b0; snd_ack=1'b0;
    vsd_dout=sd_dout; iol_dout=sd_dout;
    cgfx_data = sd_dout;                                   // word-wide return
    src_data  = src_bsel_q  ? sd_dout[15:8] : sd_dout[7:0];
    snd_data  = sd_dout;
    case (gnt)
      G_IOL:  begin sd_addr=iol_addr;  sd_din=iol_din; sd_be=iol_be; sd_rd=iol_rd; sd_wr=iol_wr; iol_ack=sd_ack; end
      G_VSD:  begin sd_addr=vsd_word;  sd_din=vsd_din; sd_be=vsd_be; sd_rd=vsd_rd; sd_wr=vsd_wr; vsd_ack=sd_ack; end
      G_CGFX: begin sd_addr=cgfx_word; sd_be=2'b00; sd_rd=1'b1;                      cgfx_ack=sd_ack; end
      G_SRC:  begin sd_addr=src_word;  sd_be=2'b00; sd_rd=1'b1;                       src_ack=sd_ack; end
      G_SND:  begin sd_addr=snd_addr_w; sd_be=2'b00; sd_rd=1'b1;                      snd_ack=sd_ack; end
      default: ;
    endcase
  end
endmodule
`default_nettype wire
