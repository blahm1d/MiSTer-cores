// smashtv_diag_rom.sv  (+define+DIAG_ROM)  — DIRECT ROM-DOWNLOAD READBACK.
//
// Every prior conclusion about "the ROM isn't landing" was a DEDUCTION (CPU reads 0/garbage ->
// therefore ROM absent). This module MEASURES it. It replaces the CPU and:
//   1. accepts the REAL emu ioctl program-ROM download through the SAME 512-deep FIFO the core
//      uses (so it exercises the core's actual download+backpressure path, not a toy one),
//   2. writes it to SDRAM via sdram_stock,
//   3. AFTER the download completes + the FIFO drains, reads the program-ROM region back OUT of
//      SDRAM directly (no CPU, no CDC, no arbiter/CGFX) and scores it.
// Screen tells the truth:
//   BLUE   = SDRAM init not complete
//   YELLOW = downloading / reading back (in progress)
//   GREEN  = ROM region is POPULATED (>=1/4 of sampled words non-zero) -> the download LANDS the
//            ROM in SDRAM -> the black screen is the CPU-READ path, NOT the download.
//   RED    = ROM region is ~EMPTY (mostly zero) -> the download does NOT land -> download still broken.
//   moving white column = raster alive.  bottom red bar ~ log2(zero-word count).
// Ports mirror yunit_top so the emu `ifdef`-swaps it in with no rewiring.
`default_nettype none
module smashtv_diag_rom
#(
  parameter ROM_HEX = "",
  parameter int H_ACT=410, H_FP=6,  H_SYNC=40, H_BP=50,
  parameter int V_ACT=256, V_FP=13, V_SYNC=8,  V_BP=12,
  parameter [24:0] ROMW_BASE = 25'h0C0000,   // program-ROM SDRAM word base (matches emu DL)
  parameter [24:0] ROM_WORDS = 25'h020000    // 128K words = 256 KB program ROM
)(
  input  logic        clk, clk_cpu, ce_pix, clk_snd, rst, rst_pon,
  input  logic [63:0] inputs,
  input  logic        ioctl_download, ioctl_wr,
  input  logic [24:0] ioctl_addr,
  input  logic [15:0] ioctl_dout,
  input  logic [1:0]  ioctl_be,
  output logic        ioctl_wait,
  input  logic        snd_dl_wr,
  input  logic [17:0] snd_dl_addr,
  input  logic [7:0]  snd_dl_data,
  inout  wire  [15:0] SDRAM_DQ,
  output logic [12:0] SDRAM_A,
  output logic [1:0]  SDRAM_BA,
  output logic        SDRAM_DQML, SDRAM_DQMH,
  output logic        SDRAM_nCS, SDRAM_nRAS, SDRAM_nCAS, SDRAM_nWE, SDRAM_CKE,
  output logic [7:0]  vid_r, vid_g, vid_b,
  output logic        hsync, vsync, hblank, vblank, de,
  output logic signed [15:0] audio_l, audio_r,
  output logic [31:0] pc_dbg,
  output logic        illegal_dbg,
  output logic        dbg_core_rst, dbg_sdram_ready, dbg_unp_done, dbg_cpu_req, dbg_mem_ack,
  output logic        dbg_int1, dbg_vblank_irq, dbg_derailed,
  output logic [31:0] dbg_culprit_pc, dbg_derail_pc,
  output logic [15:0] dbg_culprit_instr
);
  assign audio_l=16'sd0; assign audio_r=16'sd0; assign illegal_dbg=1'b0;
  assign dbg_core_rst=0; assign dbg_sdram_ready=0; assign dbg_unp_done=0; assign dbg_cpu_req=0;
  assign dbg_mem_ack=0; assign dbg_int1=0; assign dbg_vblank_irq=0; assign dbg_derailed=0;
  assign dbg_culprit_pc=0; assign dbg_derail_pc=0; assign dbg_culprit_instr=0;

  // ---- stock SDRAM controller (identical to the real core) --------------------
  logic [24:0] ctl_addr; logic [15:0] ctl_din, ctl_dout; logic [1:0] ctl_wtbt;
  logic        ctl_rd, ctl_we, ctl_ready;
  sdram_stock u_sdram (
    .init(rst), .clk(clk),
    .addr(ctl_addr), .din(ctl_din), .wtbt(ctl_wtbt), .we(ctl_we), .rd(ctl_rd),
    .dout(ctl_dout), .ready(ctl_ready),
    .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA),
    .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH),
    .SDRAM_nCS(SDRAM_nCS), .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nCAS(SDRAM_nCAS),
    .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE));

  // ---- ioctl download FIFO (mirror of yunit_top: 512-deep, HWM backpressure) ---
  localparam int IOL_AW=9, IOL_HWM=256;
  logic [42:0] iol_fifo [0:511];
  logic [IOL_AW:0] iol_wp, iol_rp;
  wire  [IOL_AW:0] iol_occ  = iol_wp - iol_rp;
  wire             iol_full = (iol_occ == (1<<IOL_AW));
  wire             iol_empty= (iol_wp == iol_rp);
  logic        iol_hold;
  logic [24:0] iol_addr_r; logic [15:0] iol_din_r; logic [1:0] iol_be_r;
  logic        wr_done;                     // pulse: the current iol SDRAM write finished (from FSM)
  always_ff @(posedge clk) begin
    if (rst) begin iol_wp<='0; iol_rp<='0; iol_hold<=1'b0; end
    else begin
      if (ioctl_wr && !iol_full) begin
        iol_fifo[iol_wp[IOL_AW-1:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
        iol_wp <= iol_wp + 1'b1;
      end
      // free the live slot when its write completes; (re)load from FIFO when free
      if (iol_hold && wr_done) iol_hold <= 1'b0;
      if ((!iol_hold || (iol_hold && wr_done)) && !iol_empty) begin
        {iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[IOL_AW-1:0]];
        iol_hold <= 1'b1; iol_rp <= iol_rp + 1'b1;
      end
    end
  end
  assign ioctl_wait = (iol_occ >= IOL_HWM[IOL_AW:0]);

  // ---- top-level FSM: WRITE (drain FIFO to SDRAM) then READBACK (score the ROM) --
  typedef enum logic [2:0] { S_INIT, S_WISS, S_WWAIT, S_RISS, S_RWAIT, S_PASS, S_FAIL } st_t;
  st_t st;
  logic [24:0] ridx;                         // readback word index
  logic [31:0] nonzero, zero;                // readback tallies
  logic settle;
  logic dl_seen, dl_q;

  always_ff @(posedge clk) begin
    if (rst) begin
      st<=S_INIT; ctl_rd<=1'b0; ctl_we<=1'b0; ctl_addr<=25'd0; ctl_din<=16'd0; ctl_wtbt<=2'b11;
      wr_done<=1'b0; ridx<=25'd0; nonzero<=32'd0; zero<=32'd0; settle<=1'b0;
      dl_seen<=1'b0; dl_q<=1'b0;
    end else begin
      ctl_rd<=1'b0; ctl_we<=1'b0; wr_done<=1'b0;
      dl_q <= ioctl_download;
      if (ioctl_download) dl_seen<=1'b1;
      case (st)
        S_INIT: if (ctl_ready) st<=S_WISS;

        // ---- WRITE: issue each FIFO-held write to sdram_stock ----
        S_WISS: begin
                  if (iol_hold && ctl_ready) begin       // a write is queued + controller idle
                    ctl_addr<={iol_addr_r[23:0],1'b0}; ctl_din<=iol_din_r; ctl_wtbt<=iol_be_r;
                    ctl_we<=1'b1; settle<=1'b1; st<=S_WWAIT;
                  end
                  // download finished AND FIFO empty AND last write done -> go read back
                  else if (dl_seen && dl_q==1'b0 && iol_empty && !iol_hold) begin
                    ridx<=25'd0; nonzero<=32'd0; zero<=32'd0; st<=S_RISS;
                  end
                end
        S_WWAIT: if (settle) settle<=1'b0;
                 else if (ctl_ready) begin wr_done<=1'b1; st<=S_WISS; end  // frees the live slot

        // ---- READBACK: read the whole ROM region, tally zero vs non-zero ----
        S_RISS: if (ctl_ready) begin
                  ctl_addr<={ (ROMW_BASE[23:0]+ridx[23:0]), 1'b0 }; ctl_rd<=1'b1;
                  settle<=1'b1; st<=S_RWAIT;
                end
        S_RWAIT: if (settle) settle<=1'b0;
                 else if (ctl_ready) begin
                   if (ctl_dout != 16'h0000) nonzero<=nonzero+32'd1; else zero<=zero+32'd1;
                   if (ridx == ROM_WORDS-1)
                     st <= (nonzero >= (ROM_WORDS>>2)) ? S_PASS : S_FAIL;  // >=25% non-zero = populated
                   else begin ridx<=ridx+25'd1; st<=S_RISS; end
                 end
        S_PASS: st<=S_PASS;
        S_FAIL: st<=S_FAIL;
        default: st<=S_INIT;
      endcase
    end
  end

  assign pc_dbg = {2'd0, st, nonzero[24:0]};   // harmless; not routed on HW

  // ---- video raster (same geometry as yunit_video / the other diags) ----------
  localparam int H_TOTAL=H_ACT+H_FP+H_SYNC+H_BP, V_TOTAL=V_ACT+V_FP+V_SYNC+V_BP;
  logic [11:0] hc, vc; logic [23:0] frame;
  always_ff @(posedge clk) begin
    if (rst) begin hc<=0; vc<=0; frame<=0; end
    else if (ce_pix) begin
      if (hc==H_TOTAL-1) begin hc<=0; if (vc==V_TOTAL-1) begin vc<=0; frame<=frame+24'd1; end else vc<=vc+12'd1; end
      else hc<=hc+12'd1;
    end
  end
  wire s0_de=(hc<H_ACT)&&(vc<V_ACT); wire s0_hb=(hc>=H_ACT); wire s0_vb=(vc>=V_ACT);
  wire s0_hs=(hc>=H_ACT+H_FP)&&(hc<H_ACT+H_FP+H_SYNC);
  wire s0_vs=(vc>=V_ACT+V_FP)&&(vc<V_ACT+V_FP+V_SYNC);

  logic [7:0] br,bg,bb;
  always_comb begin
    case (st)
      S_INIT:  begin br=8'h00; bg=8'h00; bb=8'hC0; end   // blue = SDRAM not ready
      S_PASS:  begin br=8'h00; bg=8'hC0; bb=8'h00; end   // green = ROM landed
      S_FAIL:  begin br=8'hC0; bg=8'h00; bb=8'h00; end   // red = ROM absent
      default: begin br=8'h80; bg=8'h80; bb=8'h00; end   // yellow = busy
    endcase
  end
  localparam int E=H_ACT/8; logic [7:0] cbr,cbg,cbb;
  wire [2:0] bar=(hc<E)?3'd0:(hc<2*E)?3'd1:(hc<3*E)?3'd2:(hc<4*E)?3'd3:(hc<5*E)?3'd4:(hc<6*E)?3'd5:(hc<7*E)?3'd6:3'd7;
  always_comb case (bar)
    3'd0:{cbr,cbg,cbb}={8'hFF,8'hFF,8'hFF}; 3'd1:{cbr,cbg,cbb}={8'hFF,8'hFF,8'h00};
    3'd2:{cbr,cbg,cbb}={8'h00,8'hFF,8'hFF}; 3'd3:{cbr,cbg,cbb}={8'h00,8'hFF,8'h00};
    3'd4:{cbr,cbg,cbb}={8'hFF,8'h00,8'hFF}; 3'd5:{cbr,cbg,cbb}={8'hFF,8'h00,8'h00};
    3'd6:{cbr,cbg,cbb}={8'h00,8'h00,8'hFF}; default:{cbr,cbg,cbb}={8'h00,8'h00,8'h00};
  endcase
  wire [5:0] zlog = zero[31]?6'd32 : zero[24]?6'd25 : zero[20]?6'd21 : zero[16]?6'd17 :
                    zero[14]?6'd15 : zero[12]?6'd13 : zero[10]?6'd11 : zero[8]?6'd9 :
                    zero[4]?6'd5 : (zero[0]?6'd1:6'd0);
  wire [15:0] zbar = (H_ACT*zlog)>>5;
  wire in_bars=(vc<V_ACT/8); wire in_zbar=(vc>=(V_ACT-V_ACT/8)); wire live_col=(hc==frame[8:0]);
  always_ff @(posedge clk) if (ce_pix) begin
    de<=s0_de; hsync<=s0_hs; vsync<=s0_vs; hblank<=s0_hb; vblank<=s0_vb;
    if (!s0_de)          begin vid_r<=0; vid_g<=0; vid_b<=0; end
    else if (in_bars)    begin vid_r<=cbr; vid_g<=cbg; vid_b<=cbb; end
    else if (live_col)   begin vid_r<=8'hFF; vid_g<=8'hFF; vid_b<=8'hFF; end
    else if (in_zbar)    begin if ({4'd0,hc}<zbar) begin vid_r<=8'hFF; vid_g<=8'h00; vid_b<=8'h00; end
                               else begin vid_r<=8'h20; vid_g<=8'h20; vid_b<=8'h20; end end
    else                 begin vid_r<=br; vid_g<=bg; vid_b<=bb; end
  end
endmodule
`default_nettype wire
