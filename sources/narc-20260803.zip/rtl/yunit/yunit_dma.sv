// yunit_dma.sv — Williams Y-unit sprite DMA blitter.
//
// Faithful RTL port of MAME's midyunit blitter:
//   register set + trigger : docs/mame-ref/midyunit_v.cpp:422 (dma_w)
//   clip / flip setup       : docs/mame-ref/midyunit_v.cpp:456-518
//   per-pixel draw modes     : docs/mame-ref/midyunit_v.cpp:262 (dma_draw)
//   completion IRQ (LINT1)   : docs/mame-ref/midyunit_v.cpp:370 (dma_callback)
//
// Boundary: reads ONE unpacked pixel byte per source step from an external
// gfx-read path (2-bit-plane→6-bit unpack lives in yunit_mem/gfx, Phase 3).
// Writes 16-bit words into the 512x512 frame buffer. The palette high-byte is
// folded into the written word here (matching dma_draw): the frame buffer
// stores {palette[7:0], pixel[7:0]}; pen_map6 runs at scanout.
//
// Faithfulness note: MAME overwrites m_dma_state.offset with
// (gfxoffset-0x02000000) at draw time (midyunit_v.cpp:518), discarding the
// clip-time source-offset adjustments at :483/:496/:508. We reproduce MAME's
// observable behaviour: clipping adjusts width/height/xpos/ypos only.
//
// Verified by sim/tb_yunit_dma.sv (Icarus). Constant bit/part-selects are
// hoisted to continuous-assign wires so the module is portable across Icarus,
// Questa, and Quartus (Icarus miscompiles constant selects inside always).

`default_nettype none

module yunit_dma
  import yunit_pkg::*;
(
  input  logic        clk,
  input  logic        rst,          // sync, active-high

  // CPU register interface (from yunit_mem; addr = blitter reg index 0..15).
  input  logic        reg_we,
  input  logic  [3:0] reg_addr,
  input  logic [15:0] reg_wdata,
  output logic [15:0] reg_rdata,     // dma_r: returns register file

  // Unpacked-gfx source read: 1 byte/pixel at linear byte index src_addr.
  output logic        src_req,
  output logic [23:0] src_addr,
  input  logic  [7:0] src_data,
  input  logic        src_ack,

  // Frame-buffer write: 16-bit word at word index (ty*512 + tx).
  output logic        fb_we,
  output logic [FB_ADDR_W-1:0] fb_addr,
  output logic [15:0] fb_wdata,
  input  logic        fb_ack,        // write accepted/complete. Tie 1'b1 for a 1-cycle
                                      // (BRAM) write; the SDRAM path drives it multi-cycle
                                      // so the blitter self-paces (no fire-and-forget drops).
  input  logic        fb_busy,       // COMMIT-GATE (cont.20): the fb-combine is write-BEHIND, so
                                      // fb_ack=ACCEPT != committed-to-VRAM. Hold the done-report
                                      // (busy-clear + blit_irq) until fb_busy=0 (combiner drained)
                                      // so the game never displays a blit before it lands (mid-draw
                                      // = missing sprites/text). Tie 1'b0 (BRAM) = no gating.
  output logic        fb_flush,      // DONE-FLUSH (cont.24): all pixels of this blit are ACCEPTED
                                      // (state==S_DONE) -> drain the write-combiner + run-buffer NOW,
                                      // overlapping the 41ns/px pace wait, instead of waiting the 2x
                                      // 64-clk idle timeouts. Kills the ~130clk dead tail every
                                      // done-IRQ paid in the game's done-serialized queue drain.
                                      // Commit semantics unchanged (done still waits !fb_busy).

  // Status
  output logic        busy,          // COMMAND bit15 as seen by the CPU
  output logic        blit_irq,      // -> 34010 LINT1; set on completion, cleared on COMMAND write
  output logic [15:0] dma_palette    // DMA_PALETTE reg -> yunit_mem CPU vram_w byte-lane
);

  // ---- Register file ----------------------------------------------------
  logic [15:0] regf [DMA_NREGS];
  logic        busy_r;
  // P0025: DMA STOP/abort (Y-unit contract, MAME-cited): midyunit_v.cpp:425
  // COMBINE_DATA folds EVERY COMMAND write into the stored register -> a single
  // bit15=0 write clears the busy bit the CPU READS immediately (dma_r :384-386);
  // the done TIMER (:370-373) still fires the IRQ afterwards. MAME draws blits
  // instantaneously so it never holds an in-flight blit to kill; our multi-cycle
  // blit + the 41ns/px S_DONE pace hold do -- an ignored kill leaves a zombie
  // whose busy eats the next trigger (S_IDLE-only) = queue-head object silently
  // dropped every frame (the UMK3 cab-proven class, see wolf_dma STOP W*2).
  logic        abort_r;    // draining to S_IDLE after a bit15=0 COMMAND write
  logic        pend_trig;  // trigger during the drain: fire at IDLE landing
  // MAME-faithful DMA duration (midyunit_v.cpp:523): the done-report (busy bit 15 +
  // blit_irq) fires no earlier than 41 ns/pixel of CLIPPED width*height after the
  // command -- 4 clk_sys/pixel at 96 MHz (41.7 ns, within 1.6% of MAME). The engine
  // may finish writing sooner (masked pixels) or later (fb backpressure); the REPORT
  // honors max(engine_done, pace). The game's object/queue choreography is authored
  // against this timing.
  logic [25:0] pace_cnt;
  logic        pace_arm;   // 1-cycle delay: multiply from registered clipped dims

  // Constant-select helpers (continuous assigns; safe on Icarus).
  wire [15:0] cmd_reg    = regf[DMA_COMMAND];
  wire        flipx_w    = cmd_reg[DMA_CMD_FLIPX_BIT];
  wire [3:0]  mode_w     = cmd_reg[3:0];
  wire [7:0]  pal_lo     = regf[DMA_PALETTE][7:0];
  wire [7:0]  col_lo     = regf[DMA_COLOR][7:0];
  wire        wdata_trig = reg_wdata[DMA_CMD_TRIG_BIT];

  assign busy        = busy_r;
  assign dma_palette = regf[DMA_PALETTE];
  // CPU poll of COMMAND sees live busy in bit15; other regs read back directly.
  assign reg_rdata = (reg_addr == DMA_COMMAND) ? {busy_r, cmd_reg[14:0]} : regf[reg_addr];

  // ---- FSM --------------------------------------------------------------
  // S_TRIG (cont.24, UMK3 DEFECT-A port): a 1-cycle wait between the COMMAND
  // trigger write and S_SETUP's clip-cone capture. The trigger write lands
  // regf[DMA_COMMAND] on edge T; without the wait, S_SETUP latches
  // width_c/height_c/xpos_c (through the flipx_w 32-bit signed clip cone) at
  // T+1 -- ONE real cycle on a path the SDC licenses as multicycle-2
  // (sdram.sdc regf[*] -> width_c/state: true for the 9 data registers written
  // cycles earlier by the MMTM, FALSE for COMMAND). The fitter may legally
  // route the cone up to ~2 periods -> silicon mis-capture: truncated/misplaced
  // blits, wrong S_SETUP routing (UMK3 cab signature: portraits absent while
  // fills drew; fixed there by the same wait state, wolf_dma S_TRIG).
  typedef enum logic [2:0] {
    S_IDLE, S_TRIG, S_SETUP, S_ROW, S_FETCH, S_WRITE, S_DONE
  } state_t;
  state_t state, state_n;

  // Latched, clipped blit parameters (set at S_SETUP).
  logic  [3:0]        mode_c;
  logic               flipx_c;
  logic               readmode_c;
  logic signed [11:0] width_c, height_c;
  logic signed [11:0] xpos_c, ypos_c;
  logic signed [31:0] rowbytes_c;
  logic [15:0]        pal16_c, color16_c;

  // Running blit state.
  logic signed [11:0] row_i, col_i, tx;
  logic        [8:0]  ty;
  logic signed [31:0] cur_off, o_ptr;
  logic        [7:0]  px;

  // ---- Combinational clip/flip setup (MAME dma_w:456-518) --------------
  logic signed [31:0] rb_in, xs_in, ys_in;
  logic        [15:0] w_in, h_in;
  logic        [31:0] gfxoff0, gfxoff1, gfxoff2;
  logic signed [31:0] rb_adj, xpos0;
  logic signed [31:0] ypos1, height1a, height1;
  logic signed [31:0] xpos_f, width_f;
  logic signed [31:0] offbytes_c;

  always_comb begin
    rb_in   = $signed(regf[DMA_ROWBYTES]);
    xs_in   = $signed(regf[DMA_XSTART]);
    ys_in   = $signed(regf[DMA_YSTART]);
    w_in    = regf[DMA_WIDTH];
    h_in    = regf[DMA_HEIGHT];
    gfxoff0 = {regf[DMA_OFFSETHI], regf[DMA_OFFSETLO]};

    rb_adj  = flipx_w ? ((rb_in - $signed({16'd0, w_in}) + 32'sd3) & ~32'sd3)
                      : ((rb_in + $signed({16'd0, w_in}) + 32'sd3) & ~32'sd3);
    xpos0   = flipx_w ? (xs_in + $signed({16'd0, w_in}) - 32'sd1) : xs_in;
    gfxoff1 = flipx_w ? (gfxoff0 - (({16'd0, w_in} - 32'd1) << 3)) : gfxoff0;

    ypos1    = (ys_in < 0) ? 32'sd0 : ys_in;
    height1a = (ys_in < 0) ? ($signed({16'd0, h_in}) + ys_in) : $signed({16'd0, h_in});
    height1  = ((ypos1 + height1a) > 32'sd512) ? (32'sd512 - ypos1) : height1a;

    if (!flipx_w) begin
      if (xpos0 < 0) begin width_f = $signed({16'd0, w_in}) + xpos0; xpos_f = 32'sd0; end
      else           begin width_f = $signed({16'd0, w_in});         xpos_f = xpos0;  end
      if ((xpos_f + width_f) > 32'sd512) width_f = 32'sd512 - xpos_f;
    end else begin
      if (xpos0 >= 32'sd512) begin width_f = $signed({16'd0, w_in}) - (xpos0 - 32'sd511); xpos_f = 32'sd511; end
      else                   begin width_f = $signed({16'd0, w_in});                      xpos_f = xpos0;    end
      if ((xpos_f - width_f) < 0) width_f = xpos_f;
    end

    gfxoff2    = (gfxoff1 < 32'h0200_0000) ? (gfxoff1 + 32'h0200_0000) : gfxoff1;
    offbytes_c = ($signed(gfxoff2) - 32'sh0200_0000) >>> 3;   // bit -> byte
  end

  // Narrowed clip results as wires (avoid constant selects inside always).
  wire [11:0] width12  = width_f[11:0];
  wire [11:0] height12 = height1[11:0];
  wire [11:0] xpos12   = xpos_f[11:0];
  wire [11:0] ypos12   = ypos1[11:0];
  wire        readmode_w = (mode_w >= 4'h1) && (mode_w <= 4'hB);

  // ---- Per-pixel draw decision (MAME dma_draw:294-357) -----------------
  logic        pix_we;
  logic [15:0] pix_data;
  always_comb begin
    pix_we   = 1'b0;
    pix_data = 16'h0000;
    unique case (mode_c)
      4'h0: ;
      4'h1: begin pix_we = (px == 8'd0); pix_data = pal16_c;               end
      4'h2: begin pix_we = (px != 8'd0); pix_data = pal16_c | {8'd0, px};  end
      4'h3: begin pix_we = 1'b1;         pix_data = pal16_c | {8'd0, px};  end
      4'h4, 4'h5: begin pix_we = (px == 8'd0); pix_data = color16_c;       end
      4'h6, 4'h7: begin pix_we = 1'b1; pix_data = (px == 8'd0) ? color16_c : (pal16_c | {8'd0, px}); end
      4'h8, 4'ha: begin pix_we = (px != 8'd0); pix_data = color16_c;       end
      4'h9, 4'hb: begin pix_we = 1'b1; pix_data = (px != 8'd0) ? color16_c : (pal16_c | {8'd0, px}); end
      default:    begin pix_we = 1'b1; pix_data = color16_c;               end // 0xC..0xF
    endcase
  end

  // overrun guard (MAME dma_draw:290). MAME checks each row's OWN base once
  // (`o` is latched before `offset += rowbytes`); cur_off equals that base only
  // during the S_ROW decision cycle — by S_FETCH/S_WRITE it has already
  // advanced to the NEXT row's base, so this wire must gate S_ROW ONLY. (Bug
  // P0018: it was also ANDed into the S_WRITE fb write; a row whose SUCCESSOR
  // row-base crossed 0x06000000 had all its writes falsely suppressed —
  // caught by tb_yunit_dma_matrix case E9.)
  wire row_overrun = ($unsigned(cur_off) >= 32'h0600_0000) && (mode_c < 4'hC);

  // dest word index for the current pixel
  wire [8:0]  tx9     = tx[8:0];
  wire [8:0]  ty_next = ypos_c[8:0] + row_i[8:0];

  // COMMIT-GATE (cont.20) vs HANDSHAKE-OFF (cont.22): the fb-combine is write-behind, so the DMA's
  // done-report (busy-clear + LINT1) normally waits for fb_busy=0 (the write COMMITTED) to avoid a
  // mid-draw display. But the burst-combiner makes the commit fast, and on a text-heavy (thin,
  // 18x-cost) screen that per-blit commit wait STARVES the CPU's display-list pump -> canned blits.
  // With -DYUNIT_NO_COMMITGATE the done fires at the 41ns/px MAME pace (no commit wait): the CPU
  // gets its per-blit budget back. Mild mid-draw risk, but the burst-combiner shrinks the
  // accept->commit window that made the gate necessary in the first place.
`ifdef YUNIT_NO_COMMITGATE
  wire dma_done_ok = (pace_cnt == 26'd0);
`else
  wire dma_done_ok = (pace_cnt == 26'd0) && !fb_busy;
`endif

  // ---- next-state ------------------------------------------------------
  always_comb begin
    state_n = state;
    unique case (state)
      S_IDLE:  if (reg_we && reg_addr == DMA_COMMAND && wdata_trig) state_n = S_TRIG;
`ifndef YUNIT_NO_DMASTOP
               else if (pend_trig) state_n = S_TRIG;   // P0025: kill-then-refire landing
`endif
      S_TRIG:  state_n = S_SETUP;   // DEFECT-A wait: regf[COMMAND] settles a full extra cycle
      S_SETUP: if (height1 <= 0 || width_f <= 0) state_n = S_DONE; else state_n = S_ROW;
      S_ROW:   if (row_i >= height_c) state_n = S_DONE;
               else if (row_overrun)  state_n = S_ROW;
               else                   state_n = S_FETCH;
      S_FETCH: if (!readmode_c)  state_n = S_WRITE;
               else if (src_ack) state_n = S_WRITE;
      // Wait for the framebuffer write to be accepted (fb_ack) before advancing — the
      // SDRAM write is multi-cycle. With fb_ack tied high (BRAM), this never stalls.
      // A masked pixel (!pix_we) writes nothing, so it advances immediately.
      S_WRITE: if (pix_we && !fb_ack) state_n = S_WRITE;
               else if (col_i >= (width_c - 12'sd1)) state_n = S_ROW; else state_n = S_FETCH;
      S_DONE:  if (dma_done_ok) state_n = S_IDLE;   // 41ns/px pace [+ fb-combine COMMITTED unless -DYUNIT_NO_COMMITGATE]
      default: state_n = S_IDLE;
    endcase
`ifndef YUNIT_NO_DMASTOP
`ifdef YUNIT_KILL_TRUNCATE
    // OLD P0025 (truncate): the killed blit aborts to IDLE mid-draw, so ONLY the rows drawn
    // before the kill land. This is the cab bug -- the revision-screen orange box draws only
    // its top strip (never solid), and splash foreground objects go missing: the game issues a
    // display-pump kill (DMACTRL bit15=0) every frame to clear busy for the next blit, which on
    // MAME lands on an already-finished (instantaneous) blit but on our MULTI-CYCLE blitter
    // catches it mid-draw and this truncates it. Exit at safe boundaries only.
    if (abort_r) begin
      case (state)
        S_IDLE:                              state_n = S_IDLE;
        S_FETCH: if (!readmode_c || src_ack) state_n = S_IDLE;
        S_WRITE: if (!pix_we || fb_ack)      state_n = S_IDLE;
        default:                             state_n = S_IDLE;
      endcase
    end
`endif
    // DEFAULT (cont.24 LET-FINISH fix): on a kill, do NOT truncate -- let the blit run to
    // completion so ALL its pixels land, matching MAME's outcome (the blit already finished
    // instantly before the kill arrived). busy_r is cleared at the kill (the CPU's poll sees
    // done); abort_r now only (a) pends a trigger that arrives during the finish and (b) retires
    // when the blit lands (below) -- the S_DONE case fires the single done-IRQ. The blit uses its
    // LATCHED clip params (width_c/cur_off/...), so the next blit's register writes during the
    // finish cannot corrupt it. Fix for the orange rectangle + missing splash foreground.
`endif
  end

  assign src_req  = (state == S_FETCH) && readmode_c;
  assign src_addr = o_ptr[23:0];

  // DONE-FLUSH (cont.24): level-held through S_DONE. All of this blit's pixels are
  // accepted by then, so the combiner's residual partial beat + the run-buffer can
  // drain concurrently with the pace wait -- by pace_cnt==0, fb_busy is (usually)
  // already low and the done-report fires ON the pace, not pace + ~130clk of idle
  // timeouts. Degenerate blits (S_SETUP->S_DONE) assert it with nothing pending;
  // the consumers gate on wc_mask/rb_cnt so that is a no-op.
  assign fb_flush = (state == S_DONE);

  // ---- registers -------------------------------------------------------
  integer i;
  always_ff @(posedge clk) begin
    if (rst) begin
      state    <= S_IDLE;
      fb_we    <= 1'b0;
      blit_irq <= 1'b0;
      busy_r   <= 1'b0;
      pace_cnt <= 26'd0; pace_arm <= 1'b0;
      abort_r  <= 1'b0; pend_trig <= 1'b0;
      for (i = 0; i < DMA_NREGS; i = i + 1) regf[i] <= 16'h0000;
    end else begin
      state <= state_n;
      fb_we <= 1'b0;

      if (reg_we) begin
        regf[reg_addr] <= reg_wdata;
        if (reg_addr == DMA_COMMAND) begin
          blit_irq <= 1'b0;             // MAME: CLEAR_LINE on COMMAND write (:433)
          if (state == S_IDLE) busy_r <= wdata_trig;
`ifndef YUNIT_NO_DMASTOP
          else if (!wdata_trig) begin
            // P0025 STOP: busy reads 0 AT THE WRITE (COMBINE_DATA :425 +
            // dma_r :384-386); the FSM drains in the background.
            busy_r  <= 1'b0;
`ifdef YUNIT_NO_DONERACE
            abort_r <= 1'b1;                     // pre-fix: unconditional arm (buggy)
`else
            // P0026 done-race fix: only ARM a background drain when the blit is
            // genuinely still in flight. If state_n==S_IDLE the FSM is completing
            // on its OWN this very cycle (state==S_DONE & pace_cnt==0): the S_DONE
            // case below already fires the done-IRQ and clears busy, so there is
            // NOTHING to drain. Arming abort_r here leaves it dangling for one
            // cycle INTO S_IDLE -> a display-pump refire landing in that window
            // hits the S_IDLE reg_we branch (busy_r<=1, no pend_trig) while the
            // `if(abort_r)` next-state override eats the trigger => busy stuck high
            // with the FSM idle = the DMAQWAIT-spin / software-watchdog reboot the
            // cab shows on the high-score screen. Deterministically reproduced by
            // sim/tb_yunit_dma_queue.sv Phase C (kill @ S_DONE/pace0 + next-cycle
            // refire). Only the S_DONE/pace0 kill reaches here with state_n==IDLE;
            // a genuine mid-flight kill has state_n!=IDLE and still arms + drains.
            if (state_n != S_IDLE) abort_r <= 1'b1;
`endif
          end else if (abort_r || pend_trig) begin
            // trigger during the drain (kill-then-refire, the display-pump
            // pattern): PEND it -- dropping it is the queue-head bug.
            pend_trig <= 1'b1;
            busy_r    <= 1'b1;
          end
`endif
        end
      end

      // 41 ns/pixel pace (MAME uses the clipped dims for its timer). Computed one
      // cycle AFTER S_SETUP from the REGISTERED width_c/height_c -- feeding the
      // combinational clip network straight into a 12x12 multiply was a -5.3 ns
      // setup path; reg-to-reg through a DSP closes. The 1-cycle-late load is
      // irrelevant against a >=4-clk/pixel count.
`ifndef YUNIT_NO_DMASTOP
      // Landing: retire abort_r when the killed blit reaches IDLE. The done-IRQ fires from the
      // S_DONE case (the blit ran to completion under LET-FINISH); under YUNIT_KILL_TRUNCATE the
      // blit aborted before S_DONE, so the IRQ fires HERE instead (MAME's timer fires regardless).
      if (abort_r && (state_n == S_IDLE)) begin
        abort_r <= 1'b0;
`ifdef YUNIT_KILL_TRUNCATE
        if (!pend_trig) blit_irq <= 1'b1;
`endif
      end
      if ((state == S_IDLE) && pend_trig) pend_trig <= 1'b0;  // pended trigger launches
`endif
      pace_arm <= (state == S_SETUP);
      if (pace_arm)
        pace_cnt <= ({14'd0, width_c[11:0]} * {14'd0, height_c[11:0]}) << 2;
      else if (pace_cnt != 26'd0)
        pace_cnt <= pace_cnt - 26'd1;

      unique case (state)
        S_SETUP: begin
          mode_c     <= mode_w;
          flipx_c    <= flipx_w;
          readmode_c <= readmode_w;
          // cont.24 clamp: a fully-clipped blit leaves width_f/height1 NEGATIVE; the
          // 12-bit truncation of e.g. -5 zero-extends into the pace multiply below as
          // ~4091 -> pace_cnt up to ~67M clk = DMA busy ~0.7s on ONE degenerate blit
          // (episodic whole-screen sprite blackouts). MAME's negative product fires
          // its done timer immediately (attotime of a negative pixel count clamps) --
          // match it: clamp the latched dims at 0 so pace_cnt loads 0 and S_DONE
          // completes at once. (The S_SETUP->S_DONE route above already bypasses the
          // draw loop; this fixes only the REPORT time.)
          width_c    <= (width_f  <= 32'sd0) ? 12'sd0 : $signed(width12);
          height_c   <= (height1  <= 32'sd0) ? 12'sd0 : $signed(height12);
          xpos_c     <= $signed(xpos12);
          ypos_c     <= $signed(ypos12);
          rowbytes_c <= rb_adj;
          pal16_c    <= {pal_lo, 8'h00};
          color16_c  <= {pal_lo, col_lo};
          row_i      <= 12'sd0;
          cur_off    <= offbytes_c;
        end

        S_ROW: begin
          ty    <= ty_next;              // low 9 bits = MAME &0x1ff
          tx    <= xpos_c;
          col_i <= 12'sd0;
          o_ptr <= cur_off;
          if (row_i < height_c) begin
            cur_off <= cur_off + rowbytes_c;
            row_i   <= row_i + 12'sd1;
          end
        end

        S_FETCH: begin
          if (readmode_c && src_ack) px <= src_data;
        end

        S_WRITE: begin
          // No row_overrun term here: overrun rows never leave S_ROW, and by
          // this state cur_off is the NEXT row's base (see guard note above).
          // fb_we is held (re-asserted each cycle) while waiting for fb_ack so the
          // SDRAM fb writer captures it; the pixel advance is deferred until the
          // write is accepted (fb_ack), or immediately for a masked pixel.
          if (pix_we) begin
            fb_we    <= 1'b1;            // held while in S_WRITE; auto-clears on leaving
            fb_addr  <= {ty, tx9};       // ty*512 + tx
            fb_wdata <= pix_data;
          end
          if (!pix_we || fb_ack) begin   // write accepted (or nothing to write) -> advance
            tx    <= tx + (flipx_c ? -12'sd1 : 12'sd1);
            col_i <= col_i + 12'sd1;
            if (readmode_c) o_ptr <= o_ptr + 32'sd1;
          end
        end

        S_DONE: if (dma_done_ok) begin
          busy_r   <= 1'b0;              // bit15 -> 0 + blit_irq [gated on COMMIT unless -DYUNIT_NO_COMMITGATE]
          blit_irq <= 1'b1;             // assert LINT1
        end

        default: ;
      endcase
    end
  end

endmodule

`default_nettype wire
