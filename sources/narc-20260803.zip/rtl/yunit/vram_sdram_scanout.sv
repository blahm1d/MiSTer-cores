// vram_sdram_scanout.sv — P2c (cont.23): SCANOUT ROW-CACHE for the SDRAM VRAM path. Models the
// DDR3 B-lane (stv_vram_ddr_top) but for 16-bit SDRAM words (1 entry/word, no 4:1 packing):
// yunit_scanline issues one scan_req per displayed entry; this cache serves them from a 512-entry
// row buffer. On the FIRST scan_req of a new scanline (row miss) it PAGE-MODE BURST-FILLS the whole
// row from SDRAM in ONE ACTIVATE (sdram_stock brd_*), then serves every entry of that line as a
// ~2-clk cache hit. So a line costs ~1 burst (512 clk) + 512 cheap hits instead of 512 single-beat
// reads (measured 9 clk each = 76% of the line budget -> the pre-P2 infeasibility).
//
// The burst master port (brd_*) goes to sdram_stock (directly in the raster TB; through the system
// arbiter in the full core, P3). scan_addr layout: [17:9]=scanline row, [8:0]=x within the line.
`timescale 1ns/1ps
`default_nettype none
module vram_sdram_scanout #(
  parameter [24:0] VRAM_WBASE = 25'h0E0000     // VRAM word base in SDRAM (512-aligned)
)(
  input  logic         clk,
  input  logic         rst,
  // scanout consumer (yunit_scanline): scan_req held until scan_ack; scan_data valid at scan_ack
  input  logic         scan_req,
  input  logic [17:0]  scan_addr,
  output logic [15:0]  scan_data,
  output logic         scan_ack,
  // page-mode burst-read master to sdram_stock (brd_req held until brd_done)
  output logic         brd_req,
  output logic [24:0]  brd_addr,     // BYTE start address of the scanline
  output logic [9:0]   brd_len,      // = 512
  input  logic [15:0]  brd_dout,
  input  logic         brd_dvalid,
  input  logic         brd_done
);
  localparam integer ROWLEN = 512;

  (* ramstyle="no_rw_check" *) logic [15:0] rc [0:ROWLEN-1];   // one scanline
  logic [8:0] rc_row;  logic rc_valid;
  wire  [8:0] req_row = scan_addr[17:9];
  wire  [8:0] req_col = scan_addr[8:0];

  // 1-clk BRAM read for cache hits. rc_raddr is COMBINATIONAL (= the current scan column), so rc_q
  // continuously tracks rc[req_col] with 1-clk latency: when a HIT is detected in S_IDLE, rc_q is
  // already rc[req_col] by S_HIT (scan_addr is held until scan_ack). A registered rc_raddr would add
  // a cycle and return the PREVIOUS column (the DDR3 B-lane uses the same combinational tap).
  wire  [8:0]  rc_raddr = req_col;  logic [15:0] rc_q;
  always_ff @(posedge clk) rc_q <= rc[rc_raddr];

  logic [9:0] fill_i;      // words captured during a fill

  typedef enum logic [1:0] { S_IDLE, S_FILL, S_HIT, S_WAIT } st_t;
  st_t ss;

  always_ff @(posedge clk) begin
    if (rst) begin
      ss<=S_IDLE; rc_valid<=1'b0; rc_row<=9'd0; brd_req<=1'b0; brd_len<=10'd0;
      scan_ack<=1'b0; scan_data<=16'd0; fill_i<=10'd0;
    end else begin
      scan_ack <= 1'b0;
      case (ss)
        S_IDLE: if (scan_req) begin
          if (rc_valid && (rc_row==req_row)) begin        // HIT: rc_q already tracks rc[req_col]
            ss <= S_HIT;
          end else begin                                   // MISS: burst-fill the whole scanline
            brd_addr <= (VRAM_WBASE + {req_row, 9'd0}) << 1;   // scanline byte base
            brd_len  <= ROWLEN[9:0];
            brd_req  <= 1'b1; fill_i <= 10'd0; ss <= S_FILL;
          end
        end
        S_FILL: begin
          if (brd_dvalid && fill_i < ROWLEN) begin rc[fill_i[8:0]] <= brd_dout; fill_i <= fill_i + 10'd1; end
          if (brd_done) begin
            brd_req <= 1'b0; rc_valid <= 1'b1; rc_row <= req_row; ss <= S_IDLE;   // re-serve as a HIT next
          end
        end
        S_HIT: begin                                         // rc_q valid now
          scan_data <= rc_q; scan_ack <= 1'b1; ss <= S_WAIT;
        end
        S_WAIT: if (!scan_req) ss <= S_IDLE;                  // one ack per request (wait for drop)
        default: ss <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
