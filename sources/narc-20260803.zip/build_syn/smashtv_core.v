`default_nettype none
`default_nettype wire
`default_nettype none
`default_nettype wire
`default_nettype none
`default_nettype wire
`default_nettype none
module tms34010_alu (
	op,
	a,
	b,
	cin,
	result,
	flags
);
	reg _sv2v_0;
	input wire [3:0] op;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] a;
	input wire [31:0] b;
	input wire cin;
	output reg [31:0] result;
	output reg [3:0] flags;
	wire [tms34010_pkg_DATA_WIDTH:0] add_ext;
	wire [tms34010_pkg_DATA_WIDTH:0] sub_ext;
	wire [tms34010_pkg_DATA_WIDTH:0] sub_bo_ext;
	wire [31:0] not_b;
	wire add_cin;
	wire sub_cin;
	assign not_b = ~b;
	assign add_cin = (op == 4'd1 ? cin : 1'b0);
	assign sub_cin = (op == 4'd3 ? !cin : 1'b1);
	assign add_ext = ({1'b0, a} + {1'b0, b}) + {{tms34010_pkg_DATA_WIDTH {1'b0}}, add_cin};
	assign sub_ext = ({1'b0, a} + {1'b0, not_b}) + {{tms34010_pkg_DATA_WIDTH {1'b0}}, sub_cin};
	assign sub_bo_ext = ({1'b0, a} + {1'b0, not_b}) + {{tms34010_pkg_DATA_WIDTH {1'b0}}, 1'b1};
	wire [31:0] add_result;
	wire [31:0] sub_result;
	wire [31:0] neg_result;
	wire [tms34010_pkg_DATA_WIDTH:0] neg_ext;
	wire [31:0] not_a;
	assign add_result = add_ext[31:0];
	assign sub_result = sub_ext[31:0];
	assign not_a = ~a;
	assign neg_ext = ({1'b0, {tms34010_pkg_DATA_WIDTH {1'b0}}} + {1'b0, not_a}) + 33'd1;
	assign neg_result = neg_ext[31:0];
	always @(*) begin
		if (_sv2v_0)
			;
		result = 1'sb0;
		flags[3] = 1'b0;
		flags[2] = 1'b0;
		flags[1] = 1'b0;
		flags[0] = 1'b0;
		(* full_case, parallel_case *)
		case (op)
			4'd0, 4'd1: begin
				result = add_result;
				flags[3] = add_result[31];
				flags[1] = add_result == {32 {1'sb0}};
				flags[2] = add_ext[tms34010_pkg_DATA_WIDTH];
				flags[0] = (a[31] == b[31]) && (add_result[31] != a[31]);
			end
			4'd2, 4'd3, 4'd4: begin
				result = sub_result;
				flags[3] = sub_result[31];
				flags[1] = sub_result == {32 {1'sb0}};
				flags[2] = !sub_bo_ext[tms34010_pkg_DATA_WIDTH];
				flags[0] = (a[31] != b[31]) && (sub_result[31] != a[31]);
			end
			4'd10: begin
				result = neg_result;
				flags[3] = neg_result[31];
				flags[1] = neg_result == {32 {1'sb0}};
				flags[2] = !neg_ext[tms34010_pkg_DATA_WIDTH];
				flags[0] = a[31] && neg_result[31];
			end
			4'd5: begin
				result = a & b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd6: begin
				result = a & ~b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd7: begin
				result = a | b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd8: begin
				result = a ^ b;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd9: begin
				result = ~a;
				flags[3] = result[31];
				flags[1] = result == {32 {1'sb0}};
			end
			4'd11: begin
				result = a;
				flags[3] = a[31];
				flags[1] = a == {32 {1'sb0}};
			end
			4'd12: begin
				result = b;
				flags[3] = b[31];
				flags[1] = b == {32 {1'sb0}};
			end
			4'd13: begin
				result = (neg_result[31] ? a : neg_result);
				flags[3] = neg_result[31];
				flags[1] = a == {32 {1'sb0}};
				flags[2] = 1'b0;
				flags[0] = a == 32'h80000000;
			end
			default:
				;
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_core (
	clk,
	ce_cpu,
	ce_pix,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_srt,
	mem_rdata,
	mem_ack,
	state_o,
	pc_o,
	instr_word_o,
	illegal_opcode_o,
	dpystrt_o,
	lint1_in
);
	reg _sv2v_0;
	parameter [0:0] EXTERNAL_SRT = 1'b0;
	input wire clk;
	input wire ce_cpu;
	input wire ce_pix;
	input wire rst;
	output reg mem_req;
	output wire mem_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	output reg [31:0] mem_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	output reg [5:0] mem_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	output reg [31:0] mem_wdata;
	output reg mem_srt;
	input wire [31:0] mem_rdata;
	input wire mem_ack;
	output wire [5:0] state_o;
	output wire [31:0] pc_o;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	output wire [15:0] instr_word_o;
	output wire illegal_opcode_o;
	output wire [15:0] dpystrt_o;
	input wire lint1_in;
	reg pblt_w2_q;
	reg pblt_w1_q;
	wire pblt_array_hit;
	reg [1:0] drav_w_q;
	reg drav_inside_q;
	reg line_last_inside_q;
	reg line_aborted_q;
	wire line_win_en;
	wire [31:0] rf_rs1_data;
	wire [31:0] rf_rs2_data;
	wire [31:0] rf_rs3_data;
	wire is_fill;
	wire fill_is_xy;
	wire is_pblt;
	wire is_drav;
	wire is_line;
	wire pixt_rmw;
	reg [31:0] pix_dest_q;
	wire pixt_xy_win;
	reg pixt_inside_q;
	reg [4:0] pix_xy_xsh;
	wire [31:0] pix_xy_dst_linear;
	wire is_mpy;
	wire mpy_signed;
	wire mpy_rd_even;
	wire is_div;
	wire is_divu;
	wire is_modu;
	wire is_divs;
	wire is_mods;
	wire div_signed_ovf;
	wire div_v;
	wire is_pair_wb;
	wire pair_second_pass;
	reg pair_wb_step;
	wire [15:0] io_psize;
	wire [15:0] io_convdp;
	wire [15:0] io_convsp;
	wire [15:0] io_control;
	wire [15:0] io_pmask;
	wire [15:0] io_dpyctl;
	wire wvp_set;
	wire [31:0] mem_rdata_eff;
	reg int_push_q;
	function automatic [31:0] ppop_apply;
		input reg [31:0] src;
		input reg [31:0] dest;
		input reg [4:0] ppop;
		input reg [31:0] fmask;
		reg [31:0] sp;
		reg [31:0] dp;
		reg [31:0] addsum;
		begin
			sp = src & fmask;
			dp = dest & fmask;
			addsum = dp + sp;
			(* full_case, parallel_case *)
			case (ppop)
				5'h00: ppop_apply = src;
				5'h01: ppop_apply = src & dest;
				5'h02: ppop_apply = src & ~dest;
				5'h03: ppop_apply = 1'sb0;
				5'h04: ppop_apply = src | ~dest;
				5'h05: ppop_apply = ~(src ^ dest);
				5'h06: ppop_apply = ~dest;
				5'h07: ppop_apply = ~(src | dest);
				5'h08: ppop_apply = src | dest;
				5'h09: ppop_apply = dest;
				5'h0a: ppop_apply = src ^ dest;
				5'h0b: ppop_apply = ~src & dest;
				5'h0c: ppop_apply = 1'sb1;
				5'h0d: ppop_apply = ~src | dest;
				5'h0e: ppop_apply = ~(src & dest);
				5'h0f: ppop_apply = ~src;
				5'h10: ppop_apply = addsum;
				5'h11: ppop_apply = (addsum > fmask ? fmask : addsum);
				5'h12: ppop_apply = dp - sp;
				5'h13: ppop_apply = (dp >= sp ? dp - sp : {32 {1'sb0}});
				5'h14: ppop_apply = (dp >= sp ? dp : sp);
				5'h15: ppop_apply = (dp <= sp ? dp : sp);
				default: ppop_apply = src;
			endcase
		end
	endfunction
	reg pc_advance_en;
	reg pc_load_en;
	reg [31:0] pc_load_value;
	wire [31:0] pc_value;
	localparam [5:0] tms34010_pkg_INSTR_WORD_BITS = 6'd16;
	localparam [31:0] tms34010_pkg_PC_ADVANCE_WIDTH = 8;
	function automatic [7:0] sv2v_cast_4E301;
		input reg [7:0] inp;
		sv2v_cast_4E301 = inp;
	endfunction
	tms34010_pc u_pc(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.load_en(pc_load_en),
		.load_value(pc_load_value),
		.advance_en(pc_advance_en),
		.advance_amount(sv2v_cast_4E301(tms34010_pkg_INSTR_WORD_BITS)),
		.pc_o(pc_value)
	);
	reg [5:0] state_q;
	reg [5:0] state_d;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst)
				state_q <= 6'd0;
			else
				state_q <= state_d;
		end
	reg [15:0] instr_word_q;
	wire [52:0] decoded;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst)
				instr_word_q <= 1'sb0;
			else if ((state_q == 6'd1) && mem_ack)
				instr_word_q <= mem_rdata_eff[15:0];
		end
	tms34010_decode u_decode(
		.instr(instr_word_q),
		.decoded(decoded)
	);
	reg illegal_q;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst)
				illegal_q <= 1'b0;
			else if ((state_q == 6'd2) && decoded[52])
				illegal_q <= 1'b1;
		end
	wire [31:0] branch_target_short;
	wire signed [15:0] disp_signed_12;
	assign disp_signed_12 = $signed({instr_word_q[7:0], 4'h0});
	function automatic signed [31:0] sv2v_cast_DEBC9_signed;
		input reg signed [31:0] inp;
		sv2v_cast_DEBC9_signed = inp;
	endfunction
	assign branch_target_short = pc_value + sv2v_cast_DEBC9_signed(disp_signed_12);
	reg [15:0] imm_lo_q;
	reg [15:0] imm_hi_q;
	reg [15:0] imm2_lo_q;
	reg [15:0] imm2_hi_q;
	wire [31:0] imm2_32 = {imm2_hi_q, imm2_lo_q};
	wire is_mv_abs_m2m = decoded[51-:7] == 7'd99;
	wire is_mv_off_m2m = decoded[51-:7] == 7'd100;
	wire is_mv_off_ni = decoded[51-:7] == 7'd101;
	wire is_mv_abs_ni = decoded[51-:7] == 7'd102;
	wire [31:0] imm2_off_sext = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {imm2_lo_q[15]}}, imm2_lo_q};
	wire [31:0] branch_target_long;
	wire signed [19:0] disp_signed_20;
	assign disp_signed_20 = $signed({imm_lo_q, 4'h0});
	assign branch_target_long = pc_value + sv2v_cast_DEBC9_signed(disp_signed_20);
	wire [31:0] branch_target_jacc;
	assign branch_target_jacc = {imm_hi_q, imm_lo_q[15:4], 4'h0};
	wire [31:0] branch_target_dsjs;
	wire signed [9:0] dsjs_disp_bits;
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	assign dsjs_disp_bits = (instr_word_q[10] ? -sv2v_cast_10_signed($signed({1'b0, instr_word_q[9:5], 4'h0})) : sv2v_cast_10_signed($signed({1'b0, instr_word_q[9:5], 4'h0})));
	assign branch_target_dsjs = pc_value + sv2v_cast_DEBC9_signed(dsjs_disp_bits);
	reg [1:0] mem_op_step;
	reg [31:0] popped_st_q;
	reg [31:0] popped_pc_q;
	reg [31:0] move_data_q;
	reg [31:0] mv_load_data_q;
	wire trap_skip_push;
	assign trap_skip_push = (decoded[51-:7] == 7'd71) && (decoded[23-:5] == 5'd0);
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				mem_op_step <= 2'd0;
				popped_st_q <= 1'sb0;
				popped_pc_q <= 1'sb0;
				move_data_q <= 1'sb0;
				pix_dest_q <= 1'sb0;
			end
			else if ((state_q == 6'd6) && mem_ack) begin
				if ((decoded[51-:7] == 7'd76) && (mem_op_step == 2'd0))
					move_data_q <= mem_rdata_eff;
				if (((((decoded[51-:7] == 7'd99) || (decoded[51-:7] == 7'd100)) || (decoded[51-:7] == 7'd101)) || (decoded[51-:7] == 7'd102)) && (mem_op_step == 2'd0))
					move_data_q <= mem_rdata_eff;
				if (((decoded[51-:7] == 7'd74) && pixt_rmw) && (mem_op_step == 2'd0))
					pix_dest_q <= mem_rdata_eff;
				if (decoded[51-:7] == 7'd70) begin
					if (mem_op_step == 2'd0)
						popped_st_q <= mem_rdata_eff;
					if (mem_op_step == 2'd1)
						popped_pc_q <= mem_rdata_eff;
				end
				if (decoded[51-:7] == 7'd71) begin
					if (trap_skip_push) begin
						if (mem_op_step == 2'd0)
							popped_pc_q <= mem_rdata_eff;
					end
					else if (mem_op_step == 2'd2)
						popped_pc_q <= mem_rdata_eff;
				end
				(* full_case, parallel_case *)
				case (decoded[51-:7])
					7'd70: mem_op_step <= (mem_op_step == 2'd1 ? 2'd0 : mem_op_step + 2'd1);
					7'd71: mem_op_step <= (trap_skip_push || (mem_op_step == 2'd2) ? 2'd0 : mem_op_step + 2'd1);
					7'd76, 7'd99, 7'd100, 7'd101, 7'd102: mem_op_step <= (mem_op_step == 2'd1 ? 2'd0 : mem_op_step + 2'd1);
					7'd74: mem_op_step <= (pixt_rmw && (mem_op_step == 2'd0) ? 2'd1 : 2'd0);
					default: mem_op_step <= 2'd0;
				endcase
			end
			else if ((state_q == 6'd19) && mem_ack) begin
				popped_pc_q <= mem_rdata_eff;
				mem_op_step <= 2'd0;
			end
			else if (state_q != 6'd6)
				mem_op_step <= 2'd0;
		end
	reg [31:0] fill_dptch_q;
	reg [31:0] fill_color_q;
	reg [31:0] fill_daddr_raw_q;
	reg [15:0] fill_dx_q;
	reg [15:0] fill_dy_q;
	reg [31:0] fill_addr_q;
	reg [31:0] fill_row_base_q;
	reg [15:0] fill_x_q;
	reg [15:0] fill_y_q;
	wire [31:0] fill_psize_ext;
	wire fill_row_end;
	wire fill_done;
	function automatic [31:0] sv2v_cast_DEBC9;
		input reg [31:0] inp;
		sv2v_cast_DEBC9 = inp;
	endfunction
	assign fill_psize_ext = sv2v_cast_DEBC9(io_psize[5:0]);
	assign fill_row_end = fill_x_q == (fill_dx_q - 16'd1);
	assign fill_done = fill_row_end && (fill_y_q == (fill_dy_q - 16'd1));
	wire [4:0] fill_xy_yshift;
	wire [31:0] fill_xy_linear;
	wire [31:0] fill_start;
	assign fill_xy_yshift = 5'd31 - io_convdp[4:0];
	assign fill_xy_linear = (({{16 {fill_daddr_raw_q[31]}}, fill_daddr_raw_q[31:16]} << fill_xy_yshift) | ({16'b0000000000000000, fill_daddr_raw_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign fill_start = (fill_is_xy ? fill_xy_linear : fill_daddr_raw_q);
	reg fill_substep_q;
	reg [31:0] fill_dest_q;
	wire [31:0] fill_pixel_mask;
	wire [31:0] fill_pmask_field;
	wire [31:0] fill_processed;
	wire [31:0] fill_merged;
	wire fill_transp;
	reg [31:0] fill_wstart_q;
	reg [31:0] fill_wend_q;
	reg fill_win_en_q;
	reg fill_w2_q;
	wire [15:0] fill_px;
	wire [15:0] fill_py;
	wire fill_in_window;
	wire fill_clip_out;
	assign fill_px = fill_daddr_raw_q[15:0] + fill_x_q;
	assign fill_py = fill_daddr_raw_q[31:16] + fill_y_q;
	assign fill_in_window = (((fill_px >= fill_wstart_q[15:0]) && (fill_px <= fill_wend_q[15:0])) && (fill_py >= fill_wstart_q[31:16])) && (fill_py <= fill_wend_q[31:16]);
	assign fill_clip_out = fill_win_en_q && !fill_in_window;
	wire fill_array_inside;
	wire [15:0] fill_arr_x0;
	wire [15:0] fill_arr_y0;
	wire [15:0] fill_arr_x1;
	wire [15:0] fill_arr_y1;
	assign fill_arr_x0 = fill_daddr_raw_q[15:0];
	assign fill_arr_y0 = fill_daddr_raw_q[31:16];
	assign fill_arr_x1 = (fill_arr_x0 + fill_dx_q) - 16'd1;
	assign fill_arr_y1 = (fill_arr_y0 + fill_dy_q) - 16'd1;
	assign fill_array_inside = (((fill_arr_x0 >= rf_rs1_data[15:0]) && (fill_arr_x1 <= rf_rs2_data[15:0])) && (fill_arr_y0 >= rf_rs1_data[31:16])) && (fill_arr_y1 <= rf_rs2_data[31:16]);
	reg fill_w1_q;
	wire fill_array_hit;
	assign fill_array_hit = !((((fill_arr_x1 < fill_wstart_q[15:0]) || (fill_arr_x0 > fill_wend_q[15:0])) || (fill_arr_y1 < fill_wstart_q[31:16])) || (fill_arr_y0 > fill_wend_q[31:16]));
	wire fill_win_flag_wb;
	wire fill_win_violation;
	wire drav_win_wb;
	assign drav_win_wb = ((state_q == 6'd7) && is_drav) && (drav_w_q != 2'd0);
	wire line_win_wb;
	assign line_win_wb = (state_q == 6'd33) && line_win_en;
	wire pixt_win_wb;
	assign pixt_win_wb = (state_q == 6'd7) && pixt_xy_win;
	assign fill_win_violation = ((((((state_q == 6'd23) || (state_q == 6'd24)) || ((state_q == 6'd25) && !fill_array_hit)) || ((state_q == 6'd26) && !pblt_array_hit)) || (drav_win_wb && !drav_inside_q)) || (line_win_wb && !line_last_inside_q)) || (pixt_win_wb && !pixt_inside_q);
	assign fill_win_flag_wb = ((((((((state_q == 6'd23) || ((state_q == 6'd11) && fill_w2_q)) || (state_q == 6'd24)) || ((state_q == 6'd15) && pblt_w2_q)) || (state_q == 6'd25)) || (state_q == 6'd26)) || drav_win_wb) || line_win_wb) || pixt_win_wb;
	localparam [31:0] tms34010_pkg_CTRL_W_HI = 7;
	localparam [31:0] tms34010_pkg_CTRL_W_LO = 6;
	assign wvp_set = ((((((state_q == 6'd23) || (state_q == 6'd24)) || ((state_q == 6'd25) && fill_array_hit)) || ((state_q == 6'd26) && pblt_array_hit)) || (drav_win_wb && (((drav_w_q == 2'd1) && drav_inside_q) || ((drav_w_q == 2'd2) && !drav_inside_q)))) || (line_win_wb && line_aborted_q)) || (pixt_win_wb && (((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1) && pixt_inside_q) || ((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2) && !pixt_inside_q)));
	assign fill_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign fill_pmask_field = {{16 {1'b0}}, io_pmask} & fill_pixel_mask;
	localparam [31:0] tms34010_pkg_CTRL_PPOP_HI = 14;
	localparam [31:0] tms34010_pkg_CTRL_PPOP_LO = 10;
	assign fill_processed = ppop_apply(fill_color_q, fill_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], fill_pixel_mask);
	localparam [31:0] tms34010_pkg_CTRL_T_BIT = 5;
	assign fill_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((fill_processed & fill_pixel_mask) == {32 {1'sb0}});
	assign fill_merged = (fill_transp || fill_clip_out ? fill_dest_q : (fill_processed & ~fill_pmask_field) | (fill_dest_q & fill_pmask_field));
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				fill_dptch_q <= 1'sb0;
				fill_color_q <= 1'sb0;
				fill_daddr_raw_q <= 1'sb0;
				fill_dx_q <= 1'sb0;
				fill_dy_q <= 1'sb0;
				fill_addr_q <= 1'sb0;
				fill_row_base_q <= 1'sb0;
				fill_x_q <= 1'sb0;
				fill_y_q <= 1'sb0;
				fill_substep_q <= 1'b0;
				fill_dest_q <= 1'sb0;
				fill_wstart_q <= 1'sb0;
				fill_wend_q <= 1'sb0;
				fill_win_en_q <= 1'b0;
				fill_w2_q <= 1'b0;
				fill_w1_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_fill) begin
					fill_daddr_raw_q <= rf_rs1_data;
					fill_dptch_q <= rf_rs2_data;
					fill_dx_q <= rf_rs3_data[15:0];
					fill_dy_q <= rf_rs3_data[31:16];
					fill_x_q <= 16'd0;
					fill_y_q <= 16'd0;
					fill_win_en_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd3);
					fill_w2_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2);
					fill_w1_q <= fill_is_xy && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1);
				end
				if (state_q == 6'd21) begin
					fill_wstart_q <= rf_rs1_data;
					fill_wend_q <= rf_rs2_data;
				end
				if (state_q == 6'd9) begin
					fill_color_q <= rf_rs1_data;
					fill_addr_q <= fill_start;
					fill_row_base_q <= fill_start;
					fill_substep_q <= 1'b0;
				end
				if ((state_q == 6'd10) && mem_ack) begin
					fill_substep_q <= ~fill_substep_q;
					if (!fill_substep_q)
						fill_dest_q <= mem_rdata_eff;
					else begin
						fill_addr_q <= fill_addr_q + fill_psize_ext;
						if (fill_row_end && !fill_done) begin
							fill_y_q <= fill_y_q + 16'd1;
							fill_row_base_q <= fill_row_base_q + fill_dptch_q;
							fill_addr_q <= fill_row_base_q + fill_dptch_q;
							fill_x_q <= 16'd0;
						end
						else if (!fill_done)
							fill_x_q <= fill_x_q + 16'd1;
					end
				end
			end
		end
	reg [31:0] pblt_sptch_q;
	reg [31:0] pblt_dptch_q;
	reg [15:0] pblt_dx_q;
	reg [15:0] pblt_dy_q;
	reg [31:0] pblt_src_addr_q;
	reg [31:0] pblt_dst_addr_q;
	reg [31:0] pblt_src_row_q;
	reg [31:0] pblt_dst_row_q;
	reg [15:0] pblt_x_q;
	reg [15:0] pblt_y_q;
	reg [1:0] pblt_substep_q;
	reg [31:0] pblt_src_pix_q;
	reg [31:0] pblt_dst_pix_q;
	wire [31:0] pblt_psize_ext;
	wire [31:0] pblt_pixel_mask;
	wire [31:0] pblt_pmask_field;
	wire [31:0] pblt_processed;
	wire [31:0] pblt_merged;
	wire pblt_row_end;
	wire pblt_done;
	wire pblt_transp;
	reg [31:0] pblt_color0_q;
	reg [31:0] pblt_color1_q;
	wire [31:0] pblt_src_eff;
	wire [31:0] pblt_src_step;
	assign pblt_psize_ext = sv2v_cast_DEBC9(io_psize[5:0]);
	assign pblt_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign pblt_pmask_field = {{16 {1'b0}}, io_pmask} & pblt_pixel_mask;
	assign pblt_row_end = pblt_x_q == (pblt_dx_q - 16'd1);
	assign pblt_done = pblt_row_end && (pblt_y_q == (pblt_dy_q - 16'd1));
	assign pblt_src_eff = (decoded[0] ? (pblt_src_pix_q[0] ? pblt_color1_q : pblt_color0_q) : pblt_src_pix_q);
	assign pblt_src_step = (decoded[0] ? 32'd1 : pblt_psize_ext);
	assign pblt_processed = ppop_apply(pblt_src_eff, pblt_dst_pix_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], pblt_pixel_mask);
	assign pblt_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((pblt_processed & pblt_pixel_mask) == {32 {1'sb0}});
	reg [31:0] pblt_dst_xy_raw_q;
	reg [31:0] pblt_wstart_q;
	reg [31:0] pblt_wend_q;
	reg pblt_win_en_q;
	wire [15:0] pblt_px;
	wire [15:0] pblt_py;
	wire pblt_in_window;
	wire pblt_clip_out;
	assign pblt_px = pblt_dst_xy_raw_q[15:0] + pblt_x_q;
	assign pblt_py = pblt_dst_xy_raw_q[31:16] + pblt_y_q;
	assign pblt_in_window = (((pblt_px >= pblt_wstart_q[15:0]) && (pblt_px <= pblt_wend_q[15:0])) && (pblt_py >= pblt_wstart_q[31:16])) && (pblt_py <= pblt_wend_q[31:16]);
	assign pblt_clip_out = pblt_win_en_q && !pblt_in_window;
	wire pblt_array_inside;
	wire [15:0] pblt_arr_x0;
	wire [15:0] pblt_arr_y0;
	wire [15:0] pblt_arr_x1;
	wire [15:0] pblt_arr_y1;
	assign pblt_arr_x0 = pblt_dst_xy_raw_q[15:0];
	assign pblt_arr_y0 = pblt_dst_xy_raw_q[31:16];
	assign pblt_arr_x1 = (pblt_arr_x0 + pblt_dx_q) - 16'd1;
	assign pblt_arr_y1 = (pblt_arr_y0 + pblt_dy_q) - 16'd1;
	assign pblt_array_inside = (((pblt_arr_x0 >= rf_rs1_data[15:0]) && (pblt_arr_x1 <= rf_rs2_data[15:0])) && (pblt_arr_y0 >= rf_rs1_data[31:16])) && (pblt_arr_y1 <= rf_rs2_data[31:16]);
	assign pblt_array_hit = !((((pblt_arr_x1 < pblt_wstart_q[15:0]) || (pblt_arr_x0 > pblt_wend_q[15:0])) || (pblt_arr_y1 < pblt_wstart_q[31:16])) || (pblt_arr_y0 > pblt_wend_q[31:16]));
	assign pblt_merged = (pblt_transp || pblt_clip_out ? pblt_dst_pix_q : (pblt_processed & ~pblt_pmask_field) | (pblt_dst_pix_q & pblt_pmask_field));
	wire [31:0] pblt_src_conv;
	wire [31:0] pblt_dst_conv;
	assign pblt_src_conv = (({{16 {pblt_src_addr_q[31]}}, pblt_src_addr_q[31:16]} << (5'd31 - io_convsp[4:0])) | ({16'b0000000000000000, pblt_src_addr_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign pblt_dst_conv = (({{16 {pblt_dst_addr_q[31]}}, pblt_dst_addr_q[31:16]} << (5'd31 - io_convdp[4:0])) | ({16'b0000000000000000, pblt_dst_addr_q[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				pblt_sptch_q <= 1'sb0;
				pblt_dptch_q <= 1'sb0;
				pblt_dx_q <= 1'sb0;
				pblt_dy_q <= 1'sb0;
				pblt_src_addr_q <= 1'sb0;
				pblt_dst_addr_q <= 1'sb0;
				pblt_src_row_q <= 1'sb0;
				pblt_dst_row_q <= 1'sb0;
				pblt_x_q <= 1'sb0;
				pblt_y_q <= 1'sb0;
				pblt_substep_q <= 2'd0;
				pblt_src_pix_q <= 1'sb0;
				pblt_dst_pix_q <= 1'sb0;
				pblt_color0_q <= 1'sb0;
				pblt_color1_q <= 1'sb0;
				pblt_dst_xy_raw_q <= 1'sb0;
				pblt_wstart_q <= 1'sb0;
				pblt_wend_q <= 1'sb0;
				pblt_win_en_q <= 1'b0;
				pblt_w2_q <= 1'b0;
				pblt_w1_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_pblt) begin
					pblt_src_addr_q <= rf_rs1_data;
					pblt_src_row_q <= rf_rs1_data;
					pblt_dst_addr_q <= rf_rs2_data;
					pblt_dst_row_q <= rf_rs2_data;
					pblt_dst_xy_raw_q <= rf_rs2_data;
					pblt_dx_q <= rf_rs3_data[15:0];
					pblt_dy_q <= rf_rs3_data[31:16];
					pblt_x_q <= 16'd0;
					pblt_y_q <= 16'd0;
					pblt_substep_q <= 2'd0;
					pblt_win_en_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd3);
					pblt_w2_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd2);
					pblt_w1_q <= decoded[1] && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1);
				end
				if (state_q == 6'd22) begin
					pblt_wstart_q <= rf_rs1_data;
					pblt_wend_q <= rf_rs2_data;
				end
				if (state_q == 6'd12) begin
					pblt_sptch_q <= rf_rs1_data;
					pblt_dptch_q <= rf_rs2_data;
					if (decoded[2]) begin
						pblt_src_addr_q <= pblt_src_conv;
						pblt_src_row_q <= pblt_src_conv;
					end
					if (decoded[1]) begin
						pblt_dst_addr_q <= pblt_dst_conv;
						pblt_dst_row_q <= pblt_dst_conv;
					end
				end
				if (state_q == 6'd16) begin
					pblt_color0_q <= rf_rs1_data;
					pblt_color1_q <= rf_rs2_data;
				end
				if ((state_q == 6'd13) && mem_ack) begin
					if (pblt_substep_q == 2'd0) begin
						pblt_src_pix_q <= mem_rdata_eff;
						pblt_substep_q <= 2'd1;
					end
					else if (pblt_substep_q == 2'd1) begin
						pblt_dst_pix_q <= mem_rdata_eff;
						pblt_substep_q <= 2'd2;
					end
					else begin
						pblt_substep_q <= 2'd0;
						pblt_src_addr_q <= pblt_src_addr_q + pblt_src_step;
						pblt_dst_addr_q <= pblt_dst_addr_q + pblt_psize_ext;
						if (pblt_done) begin
							pblt_src_addr_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_addr_q <= pblt_dst_row_q + pblt_dptch_q;
						end
						else if (pblt_row_end) begin
							pblt_y_q <= pblt_y_q + 16'd1;
							pblt_src_row_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_row_q <= pblt_dst_row_q + pblt_dptch_q;
							pblt_src_addr_q <= pblt_src_row_q + pblt_sptch_q;
							pblt_dst_addr_q <= pblt_dst_row_q + pblt_dptch_q;
							pblt_x_q <= 16'd0;
						end
						else
							pblt_x_q <= pblt_x_q + 16'd1;
					end
				end
			end
		end
	reg [31:0] drav_rd_q;
	reg [31:0] drav_rs_q;
	reg [31:0] drav_linear_q;
	reg [31:0] drav_dest_q;
	reg drav_substep_q;
	wire drav_in_window;
	wire drav_draw;
	assign drav_in_window = (((drav_rd_q[15:0] >= rf_rs1_data[15:0]) && (drav_rd_q[15:0] <= rf_rs2_data[15:0])) && (drav_rd_q[31:16] >= rf_rs1_data[31:16])) && (drav_rd_q[31:16] <= rf_rs2_data[31:16]);
	assign drav_draw = (drav_w_q == 2'd0) || (((drav_w_q == 2'd2) || (drav_w_q == 2'd3)) && drav_inside_q);
	wire [31:0] drav_pixel_mask;
	wire [31:0] drav_pmask_field;
	wire [31:0] drav_processed;
	wire [31:0] drav_merged;
	wire drav_transp;
	wire [31:0] drav_advance;
	assign drav_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign drav_pmask_field = {{16 {1'b0}}, io_pmask} & drav_pixel_mask;
	assign drav_processed = ppop_apply(rf_rs1_data, drav_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], drav_pixel_mask);
	assign drav_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((drav_processed & drav_pixel_mask) == {32 {1'sb0}});
	assign drav_merged = (drav_transp ? drav_dest_q : (drav_processed & ~drav_pmask_field) | (drav_dest_q & drav_pmask_field));
	assign drav_advance = {drav_rd_q[31:16] + drav_rs_q[31:16], drav_rd_q[15:0] + drav_rs_q[15:0]};
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				drav_rd_q <= 1'sb0;
				drav_rs_q <= 1'sb0;
				drav_linear_q <= 1'sb0;
				drav_dest_q <= 1'sb0;
				drav_substep_q <= 1'b0;
				drav_w_q <= 2'd0;
				drav_inside_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_drav) begin
					drav_rd_q <= rf_rs2_data;
					drav_rs_q <= rf_rs1_data;
					drav_linear_q <= pix_xy_dst_linear;
					drav_substep_q <= 1'b0;
					drav_w_q <= io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO];
				end
				if (state_q == 6'd28)
					drav_inside_q <= drav_in_window;
				if ((state_q == 6'd27) && mem_ack) begin
					drav_substep_q <= ~drav_substep_q;
					if (!drav_substep_q)
						drav_dest_q <= mem_rdata_eff;
				end
			end
		end
	reg [31:0] line_d_q;
	reg [31:0] line_count_q;
	reg [31:0] line_inc1_q;
	reg [31:0] line_inc2_q;
	reg [31:0] line_offset_q;
	reg [31:0] line_daddr_q;
	reg [31:0] line_color_q;
	reg [31:0] line_dest_q;
	reg [15:0] line_b_q;
	reg [15:0] line_a_q;
	reg line_substep_q;
	wire [31:0] line_linear;
	assign line_linear = (({{16 {line_daddr_q[31]}}, line_daddr_q[31:16]} << (5'd31 - io_convdp[4:0])) | ({16'b0000000000000000, line_daddr_q[15:0]} << pix_xy_xsh)) + line_offset_q;
	wire [31:0] line_pixel_mask;
	wire [31:0] line_pmask_field;
	wire [31:0] line_processed;
	wire [31:0] line_merged;
	wire line_transp;
	assign line_pixel_mask = (32'd1 << io_psize[5:0]) - 32'd1;
	assign line_pmask_field = {{16 {1'b0}}, io_pmask} & line_pixel_mask;
	assign line_processed = ppop_apply(line_color_q, line_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], line_pixel_mask);
	assign line_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((line_processed & line_pixel_mask) == {32 {1'sb0}});
	reg [31:0] line_wstart_q;
	reg [31:0] line_wend_q;
	wire [1:0] line_w_mode;
	wire line_in_window;
	wire line_draw_pixel;
	wire line_clip_out;
	wire line_abort;
	assign line_w_mode = io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO];
	assign line_win_en = line_w_mode != 2'd0;
	assign line_in_window = (((line_daddr_q[15:0] >= line_wstart_q[15:0]) && (line_daddr_q[15:0] <= line_wend_q[15:0])) && (line_daddr_q[31:16] >= line_wstart_q[31:16])) && (line_daddr_q[31:16] <= line_wend_q[31:16]);
	assign line_draw_pixel = (line_w_mode == 2'd1 ? !line_in_window : line_in_window);
	assign line_clip_out = line_win_en && !line_draw_pixel;
	assign line_abort = ((line_w_mode == 2'd1) && line_in_window) || ((line_w_mode == 2'd2) && !line_in_window);
	assign line_merged = (line_transp || line_clip_out ? line_dest_q : (line_processed & ~line_pmask_field) | (line_dest_q & line_pmask_field));
	wire line_branch;
	wire [31:0] line_2b;
	wire [31:0] line_2a;
	wire [31:0] line_d_next;
	wire [31:0] line_daddr_next;
	wire [31:0] line_count_next;
	assign line_branch = (instr_word_q[7] ? !line_d_q[31] : !line_d_q[31] && (line_d_q != {32 {1'sb0}}));
	assign line_2b = {16'b0000000000000000, line_b_q} << 1;
	assign line_2a = {16'b0000000000000000, line_a_q} << 1;
	assign line_d_next = (line_branch ? (line_d_q + line_2b) - line_2a : line_d_q + line_2b);
	assign line_daddr_next = (line_branch ? {line_daddr_q[31:16] + line_inc1_q[31:16], line_daddr_q[15:0] + line_inc1_q[15:0]} : {line_daddr_q[31:16] + line_inc2_q[31:16], line_daddr_q[15:0] + line_inc2_q[15:0]});
	assign line_count_next = line_count_q - 32'd1;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				line_d_q <= 1'sb0;
				line_count_q <= 1'sb0;
				line_inc1_q <= 1'sb0;
				line_inc2_q <= 1'sb0;
				line_offset_q <= 1'sb0;
				line_daddr_q <= 1'sb0;
				line_color_q <= 1'sb0;
				line_dest_q <= 1'sb0;
				line_b_q <= 1'sb0;
				line_a_q <= 1'sb0;
				line_substep_q <= 1'b0;
				line_wstart_q <= 1'sb0;
				line_wend_q <= 1'sb0;
				line_last_inside_q <= 1'b0;
				line_aborted_q <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_line)
					line_aborted_q <= 1'b0;
				if (state_q == 6'd36) begin
					line_wstart_q <= rf_rs1_data;
					line_wend_q <= rf_rs2_data;
				end
				if (state_q == 6'd29) begin
					line_d_q <= rf_rs1_data;
					line_b_q <= rf_rs2_data[31:16];
					line_a_q <= rf_rs2_data[15:0];
					line_count_q <= rf_rs3_data;
				end
				if (state_q == 6'd30) begin
					line_inc1_q <= rf_rs1_data;
					line_inc2_q <= rf_rs2_data;
					line_offset_q <= rf_rs3_data;
				end
				if (state_q == 6'd31) begin
					line_daddr_q <= rf_rs1_data;
					line_color_q <= rf_rs2_data;
					line_substep_q <= 1'b0;
				end
				if ((state_q == 6'd32) && mem_ack) begin
					line_substep_q <= ~line_substep_q;
					if (!line_substep_q)
						line_dest_q <= mem_rdata_eff;
					else begin
						line_last_inside_q <= line_in_window;
						if (line_abort)
							line_aborted_q <= 1'b1;
						line_d_q <= line_d_next;
						line_daddr_q <= line_daddr_next;
						line_count_q <= line_count_next;
					end
				end
			end
		end
	reg [31:0] mm_rp_q;
	reg [15:0] mm_mask_q;
	reg [3:0] mm_iter_idx;
	wire [3:0] mm_reg_idx;
	wire mm_mask_will_be_empty;
	wire is_mmtm;
	wire is_mmfm;
	wire is_mm;
	assign is_mmtm = decoded[51-:7] == 7'd72;
	assign is_mmfm = decoded[51-:7] == 7'd73;
	assign is_mm = is_mmtm || is_mmfm;
	function automatic signed [3:0] sv2v_cast_4_signed;
		input reg signed [3:0] inp;
		sv2v_cast_4_signed = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		mm_iter_idx = 4'd0;
		begin : sv2v_autoblock_1
			reg signed [31:0] i;
			for (i = 0; i < 16; i = i + 1)
				if (mm_mask_q[i])
					mm_iter_idx = sv2v_cast_4_signed(i);
		end
	end
	assign mm_reg_idx = (is_mmtm ? 4'd15 - mm_iter_idx : mm_iter_idx);
	assign mm_mask_will_be_empty = (mm_mask_q & ~(16'd1 << mm_iter_idx)) == 16'd0;
	localparam [31:0] tms34010_pkg_WORD_BIT_SIZE = sv2v_cast_DEBC9(tms34010_pkg_DATA_WIDTH);
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				mm_rp_q <= 1'sb0;
				mm_mask_q <= 1'sb0;
			end
			else if (((state_q == 6'd5) && (state_d == 6'd6)) && is_mm) begin
				mm_rp_q <= (is_mmtm ? rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE : rf_rs2_data);
				mm_mask_q <= imm_lo_q;
			end
			else if (((state_q == 6'd6) && is_mm) && mem_ack) begin
				mm_mask_q[mm_iter_idx] <= 1'b0;
				if (is_mmfm)
					mm_rp_q <= mm_rp_q + tms34010_pkg_WORD_BIT_SIZE;
				else if (!mm_mask_will_be_empty)
					mm_rp_q <= mm_rp_q - tms34010_pkg_WORD_BIT_SIZE;
			end
		end
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				imm_lo_q <= 1'sb0;
				imm_hi_q <= 1'sb0;
			end
			else begin
				if ((state_q == 6'd3) && mem_ack)
					imm_lo_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd4) && mem_ack)
					imm_hi_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd39) && mem_ack)
					imm2_lo_q <= mem_rdata_eff[15:0];
				if ((state_q == 6'd40) && mem_ack)
					imm2_hi_q <= mem_rdata_eff[15:0];
			end
		end
	wire rf_rs1_file;
	wire [3:0] rf_rs1_idx;
	wire rf_rs2_file;
	wire [3:0] rf_rs2_idx;
	wire rf_rs3_file;
	wire [3:0] rf_rs3_idx;
	wire rf_wr_en;
	wire rf_wr_file;
	wire [3:0] rf_wr_idx;
	reg [31:0] rf_wr_data;
	wire [31:0] rf_sp;
	wire [3:0] alu_op;
	reg [31:0] alu_a;
	reg [31:0] alu_b;
	wire alu_cin;
	wire [31:0] alu_result;
	wire [3:0] alu_flags;
	wire st_flag_update_en;
	wire st_write_en;
	reg [31:0] st_write_data;
	wire [31:0] st_value;
	wire st_n;
	wire st_c;
	wire st_z;
	wire st_v;
	wire [31:0] shifter_result;
	wire [3:0] shifter_flags;
	reg [31:0] imm32;
	always @(*) begin
		if (_sv2v_0)
			;
		if (decoded[33])
			imm32 = {imm_hi_q, imm_lo_q};
		else if (decoded[32])
			imm32 = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {imm_lo_q[15]}}, imm_lo_q};
		else
			imm32 = {{tms34010_pkg_DATA_WIDTH - tms34010_pkg_INSTR_WORD_WIDTH {1'b0}}, imm_lo_q};
	end
	assign is_fill = (decoded[51-:7] == 7'd94) || (decoded[51-:7] == 7'd95);
	assign fill_is_xy = decoded[51-:7] == 7'd95;
	assign is_pblt = decoded[51-:7] == 7'd96;
	assign is_drav = decoded[51-:7] == 7'd97;
	assign is_line = decoded[51-:7] == 7'd98;
	wire line_rd_b;
	assign line_rd_b = is_line && ((((state_q == 6'd29) || (state_q == 6'd30)) || (state_q == 6'd31)) || (state_q == 6'd36));
	assign rf_rs1_file = (line_rd_b ? 1'b1 : (state_q == 6'd37 ? 1'b1 : (is_drav && ((state_q == 6'd27) || (state_q == 6'd28)) ? 1'b1 : (is_fill || is_pblt ? 1'b1 : (decoded[51-:7] == 7'd30 ? decoded[35] : decoded[44])))));
	localparam [3:0] tms34010_pkg_B_COLOR0_IDX = 4'd8;
	localparam [3:0] tms34010_pkg_B_COLOR1_IDX = 4'd9;
	localparam [3:0] tms34010_pkg_B_DADDR_IDX = 4'd2;
	localparam [3:0] tms34010_pkg_B_INC1_IDX = 4'd11;
	localparam [3:0] tms34010_pkg_B_SADDR_IDX = 4'd0;
	localparam [3:0] tms34010_pkg_B_SPTCH_IDX = 4'd1;
	localparam [3:0] tms34010_pkg_CPW_WSTART_IDX = 4'd5;
	assign rf_rs1_idx = (is_fill ? (state_q == 6'd21 ? tms34010_pkg_CPW_WSTART_IDX : (state_q == 6'd9 ? tms34010_pkg_B_COLOR1_IDX : tms34010_pkg_B_DADDR_IDX)) : (is_pblt ? (state_q == 6'd22 ? tms34010_pkg_CPW_WSTART_IDX : (state_q == 6'd16 ? tms34010_pkg_B_COLOR0_IDX : (state_q == 6'd12 ? tms34010_pkg_B_SPTCH_IDX : tms34010_pkg_B_SADDR_IDX))) : ((state_q == 6'd6) && is_mmtm ? mm_reg_idx : (is_drav && (state_q == 6'd28) ? tms34010_pkg_CPW_WSTART_IDX : (is_drav && (state_q == 6'd27) ? tms34010_pkg_B_COLOR1_IDX : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_SADDR_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_INC1_IDX : (is_line && (state_q == 6'd31) ? tms34010_pkg_B_DADDR_IDX : (is_line && (state_q == 6'd36) ? tms34010_pkg_CPW_WSTART_IDX : (state_q == 6'd37 ? tms34010_pkg_CPW_WSTART_IDX : decoded[39-:4]))))))))));
	assign rf_rs2_file = (((((line_rd_b || is_fill) || is_pblt) || (decoded[51-:7] == 7'd86)) || (state_q == 6'd37)) || (is_drav && (state_q == 6'd28)) ? 1'b1 : decoded[44]);
	localparam [3:0] tms34010_pkg_B_DPTCH_IDX = 4'd3;
	localparam [3:0] tms34010_pkg_B_DYDX_IDX = 4'd7;
	localparam [3:0] tms34010_pkg_B_INC2_IDX = 4'd12;
	localparam [3:0] tms34010_pkg_CPW_WEND_IDX = 4'd6;
	assign rf_rs2_idx = (is_fill ? (state_q == 6'd21 ? tms34010_pkg_CPW_WEND_IDX : tms34010_pkg_B_DPTCH_IDX) : (is_pblt ? (state_q == 6'd22 ? tms34010_pkg_CPW_WEND_IDX : (state_q == 6'd16 ? tms34010_pkg_B_COLOR1_IDX : (state_q == 6'd12 ? tms34010_pkg_B_DPTCH_IDX : tms34010_pkg_B_DADDR_IDX))) : (is_drav && (state_q == 6'd28) ? tms34010_pkg_CPW_WEND_IDX : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_DYDX_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_INC2_IDX : (is_line && (state_q == 6'd31) ? tms34010_pkg_B_COLOR1_IDX : (is_line && (state_q == 6'd36) ? tms34010_pkg_CPW_WEND_IDX : (state_q == 6'd37 ? tms34010_pkg_CPW_WEND_IDX : (decoded[51-:7] == 7'd86 ? tms34010_pkg_CPW_WSTART_IDX : decoded[43-:4])))))))));
	assign rf_rs3_file = ((decoded[51-:7] == 7'd89) || (decoded[51-:7] == 7'd91) ? decoded[44] : 1'b1);
	localparam [3:0] tms34010_pkg_B_COUNT_IDX = 4'd10;
	localparam [3:0] tms34010_pkg_B_OFFSET_IDX = 4'd4;
	assign rf_rs3_idx = ((decoded[51-:7] == 7'd89) || (decoded[51-:7] == 7'd91) ? decoded[43-:4] + 4'd1 : (is_fill ? (state_q == 6'd9 ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_B_DYDX_IDX) : (is_pblt ? (state_q == 6'd12 ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_B_DYDX_IDX) : (is_line && (state_q == 6'd29) ? tms34010_pkg_B_COUNT_IDX : (is_line && (state_q == 6'd30) ? tms34010_pkg_B_OFFSET_IDX : (((decoded[51-:7] == 7'd93) || decoded[3]) || is_drav ? tms34010_pkg_B_OFFSET_IDX : tms34010_pkg_CPW_WEND_IDX))))));
	reg dsj_precondition;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd36, 7'd40: dsj_precondition = 1'b1;
			7'd37: dsj_precondition = st_z;
			7'd38: dsj_precondition = !st_z;
			default: dsj_precondition = 1'b1;
		endcase
	end
	wire dsj_rd_nonzero;
	assign dsj_rd_nonzero = alu_result != {32 {1'sb0}};
	wire mmfm_pop_wr;
	assign mmfm_pop_wr = ((state_q == 6'd6) && is_mmfm) && mem_ack;
	wire is_mv_store;
	wire is_mv_load;
	wire mv_postinc;
	wire mv_predec;
	wire mv_incdec;
	wire [31:0] mv_ptr;
	wire [31:0] mv_addr;
	wire [31:0] mv_ptr_new;
	wire mv_load_ptr_wr;
	assign is_mv_store = decoded[51-:7] == 7'd74;
	assign is_mv_load = decoded[51-:7] == 7'd75;
	assign mv_postinc = decoded[7-:2] == 2'b01;
	assign mv_predec = decoded[7-:2] == 2'b10;
	assign mv_incdec = mv_postinc || mv_predec;
	assign mv_ptr = ((is_mv_store || is_mv_off_ni) || is_mv_abs_ni ? rf_rs2_data : rf_rs1_data);
	assign mv_load_ptr_wr = (((state_q == 6'd6) && is_mv_load) && mv_incdec) && mem_ack;
	wire [4:0] mv_fs_raw;
	wire [5:0] mv_fs;
	wire mv_fe;
	wire [31:0] mv_fs_ext;
	wire [31:0] mv_fmask;
	reg [31:0] mv_load_data;
	localparam [31:0] tms34010_pkg_ST_FS0_HI = 4;
	localparam [31:0] tms34010_pkg_ST_FS0_LO = 0;
	localparam [31:0] tms34010_pkg_ST_FS1_HI = 10;
	localparam [31:0] tms34010_pkg_ST_FS1_LO = 6;
	assign mv_fs_raw = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	function automatic [5:0] sv2v_cast_13C0F;
		input reg [5:0] inp;
		sv2v_cast_13C0F = inp;
	endfunction
	assign mv_fs = (decoded[5] ? sv2v_cast_13C0F_signed(8) : (decoded[4] ? io_psize[5:0] : (mv_fs_raw == 5'd0 ? sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH) : {1'b0, mv_fs_raw})));
	localparam [31:0] tms34010_pkg_ST_FE0_BIT = 5;
	localparam [31:0] tms34010_pkg_ST_FE1_BIT = 11;
	assign mv_fe = (decoded[5] ? 1'b1 : (decoded[4] ? 1'b0 : (instr_word_q[9] ? st_value[tms34010_pkg_ST_FE1_BIT] : st_value[tms34010_pkg_ST_FE0_BIT])));
	assign mv_fs_ext = sv2v_cast_DEBC9(mv_fs);
	assign mv_fmask = (mv_fs >= sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH) ? {32 {1'sb1}} : (32'd1 << mv_fs) - 32'd1);
	always @(*) begin
		if (_sv2v_0)
			;
		if (mv_fs >= sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH))
			mv_load_data = mem_rdata_eff;
		else if (mv_fe && mem_rdata_eff[mv_fs - 6'd1])
			mv_load_data = mem_rdata_eff | ~mv_fmask;
		else
			mv_load_data = mem_rdata_eff & mv_fmask;
	end
	localparam [31:0] SRT_ROW_WORDS = 512;
	localparam [31:0] SRT_IDX_W = 10;
	wire srt_active;
	assign srt_active = ((io_dpyctl[11] && decoded[4]) && !decoded[3]) && (is_mv_load || is_mv_store);
	wire srt_enter;
	assign srt_enter = (state_q == 6'd5) && srt_active;
	localparam [0:0] EXT_SRT_CMD = EXTERNAL_SRT;
	reg [9:0] srt_idx;
	reg srt_wr_phase;
	reg [31:0] srt_word_base;
	wire srt_last;
	function automatic [9:0] sv2v_cast_CAAA9;
		input reg [9:0] inp;
		sv2v_cast_CAAA9 = inp;
	endfunction
	assign srt_last = srt_idx == sv2v_cast_CAAA9(511);
	wire [31:0] srt_bit_addr;
	assign srt_bit_addr = (srt_word_base + {{tms34010_pkg_DATA_WIDTH - SRT_IDX_W {1'b0}}, srt_idx}) << 4;
	reg [15:0] srt_buf [0:511];
	reg [15:0] srt_rdata_q;
	wire srt_buf_we;
	assign srt_buf_we = (!EXTERNAL_SRT && (state_q == 6'd41)) && mem_ack;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (srt_buf_we)
				srt_buf[srt_idx[9:0]] <= mem_rdata_eff[15:0];
			srt_rdata_q <= srt_buf[srt_idx[9:0]];
		end
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				srt_idx <= 1'sb0;
				srt_wr_phase <= 1'b0;
				srt_word_base <= 1'sb0;
			end
			else if (srt_enter && !EXTERNAL_SRT) begin
				srt_idx <= 1'sb0;
				srt_wr_phase <= 1'b0;
				srt_word_base <= mv_ptr >> 4;
			end
			else if (!EXTERNAL_SRT && (state_q == 6'd41)) begin
				if (mem_ack)
					srt_idx <= srt_idx + 1'b1;
			end
			else if (!EXTERNAL_SRT && (state_q == 6'd42)) begin
				if (!srt_wr_phase)
					srt_wr_phase <= 1'b1;
				else if (mem_ack) begin
					srt_idx <= srt_idx + 1'b1;
					srt_wr_phase <= 1'b0;
				end
			end
		end
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst)
				mv_load_data_q <= 1'sb0;
			else if (((state_q == 6'd41) && mem_ack) && (EXTERNAL_SRT || (srt_idx == {10 {1'sb0}})))
				mv_load_data_q <= {{16 {1'b0}}, mem_rdata_eff[15:0]};
			else if (((state_q == 6'd6) && mem_ack) && (((decoded[51-:7] == 7'd75) || (decoded[51-:7] == 7'd78)) || (decoded[51-:7] == 7'd80)))
				mv_load_data_q <= mv_load_data;
		end
	wire [31:0] pixt_pmask_field;
	wire [31:0] pixt_processed;
	wire pixt_transp;
	wire [31:0] pixt_merged;
	assign pixt_rmw = decoded[4] && is_mv_store;
	assign pixt_pmask_field = {{16 {1'b0}}, io_pmask} & mv_fmask;
	assign pixt_processed = ppop_apply(rf_rs1_data, pix_dest_q, io_control[tms34010_pkg_CTRL_PPOP_HI:tms34010_pkg_CTRL_PPOP_LO], mv_fmask);
	assign pixt_transp = io_control[tms34010_pkg_CTRL_T_BIT] && ((pixt_processed & mv_fmask) == {32 {1'sb0}});
	reg [31:0] pixt_wstart_q;
	reg [31:0] pixt_wend_q;
	wire pixt_in_window;
	wire pixt_clip_out;
	assign pixt_xy_win = (pixt_rmw && decoded[3]) && (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] != 2'd0);
	assign pixt_in_window = (((mv_ptr[15:0] >= pixt_wstart_q[15:0]) && (mv_ptr[15:0] <= pixt_wend_q[15:0])) && (mv_ptr[31:16] >= pixt_wstart_q[31:16])) && (mv_ptr[31:16] <= pixt_wend_q[31:16]);
	assign pixt_clip_out = pixt_xy_win && ((io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] == 2'd1) || !pixt_in_window);
	assign pixt_merged = (pixt_transp || pixt_clip_out ? pix_dest_q : (pixt_processed & ~pixt_pmask_field) | (pix_dest_q & pixt_pmask_field));
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				pixt_wstart_q <= 1'sb0;
				pixt_wend_q <= 1'sb0;
				pixt_inside_q <= 1'b0;
			end
			else begin
				if (state_q == 6'd37) begin
					pixt_wstart_q <= rf_rs1_data;
					pixt_wend_q <= rf_rs2_data;
				end
				if ((((state_q == 6'd6) && pixt_rmw) && (mem_op_step == 2'd1)) && mem_ack)
					pixt_inside_q <= pixt_in_window;
			end
		end
	wire [15:0] pix_xy_conv;
	wire [4:0] pix_xy_yshift;
	wire [31:0] pix_xy_linear;
	assign pix_xy_conv = (is_mv_store ? io_convdp : io_convsp);
	assign pix_xy_yshift = 5'd31 - pix_xy_conv[4:0];
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (io_psize[4:0])
			5'd1: pix_xy_xsh = 5'd0;
			5'd2: pix_xy_xsh = 5'd1;
			5'd4: pix_xy_xsh = 5'd2;
			5'd8: pix_xy_xsh = 5'd3;
			5'd16: pix_xy_xsh = 5'd4;
			default: pix_xy_xsh = 5'd0;
		endcase
	end
	assign pix_xy_linear = (({{16 {mv_ptr[31]}}, mv_ptr[31:16]} << pix_xy_yshift) | ({16'b0000000000000000, mv_ptr[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	assign mv_addr = (decoded[3] ? pix_xy_linear : (mv_predec ? mv_ptr - mv_fs_ext : mv_ptr));
	assign mv_ptr_new = (mv_predec ? mv_ptr - mv_fs_ext : mv_ptr + mv_fs_ext);
	wire [4:0] pix_xy_dst_yshift;
	assign pix_xy_dst_yshift = 5'd31 - io_convdp[4:0];
	assign pix_xy_dst_linear = (({{16 {rf_rs2_data[31]}}, rf_rs2_data[31:16]} << pix_xy_dst_yshift) | ({16'b0000000000000000, rf_rs2_data[15:0]} << pix_xy_xsh)) + rf_rs3_data;
	wire is_mv_m2m;
	wire m2m_same_reg;
	wire m2m_src_wr;
	wire [31:0] m2m_src_addr;
	wire [31:0] m2m_dst_addr;
	wire [31:0] m2m_src_new;
	wire [31:0] m2m_dst_new;
	assign is_mv_m2m = decoded[51-:7] == 7'd76;
	assign m2m_same_reg = decoded[39-:4] == decoded[43-:4];
	assign m2m_src_addr = (decoded[3] ? pix_xy_linear : (mv_predec ? rf_rs1_data - mv_fs_ext : rf_rs1_data));
	assign m2m_dst_addr = (decoded[3] ? pix_xy_dst_linear : (mv_predec ? rf_rs2_data - mv_fs_ext : rf_rs2_data));
	assign m2m_src_new = (mv_predec ? rf_rs1_data - mv_fs_ext : rf_rs1_data + mv_fs_ext);
	assign m2m_dst_new = (mv_predec ? rf_rs2_data - mv_fs_ext : rf_rs2_data + mv_fs_ext);
	assign m2m_src_wr = ((((state_q == 6'd6) && is_mv_m2m) && mv_incdec) && (mem_op_step == 2'd0)) && mem_ack;
	wire fill_wb;
	wire pblt_wb_saddr;
	wire pblt_wb_daddr;
	wire graphics_wb;
	assign fill_wb = state_q == 6'd11;
	assign pblt_wb_saddr = state_q == 6'd14;
	assign pblt_wb_daddr = state_q == 6'd15;
	wire line_wb_d;
	wire line_wb_daddr;
	wire line_wb_count;
	wire line_wb;
	assign line_wb_d = state_q == 6'd33;
	assign line_wb_daddr = state_q == 6'd34;
	assign line_wb_count = state_q == 6'd35;
	assign line_wb = (line_wb_d || line_wb_daddr) || line_wb_count;
	assign graphics_wb = ((fill_wb || pblt_wb_saddr) || pblt_wb_daddr) || line_wb;
	wire int_sp_wb;
	assign int_sp_wb = (state_q == 6'd20) && int_push_q;
	assign rf_wr_en = (((((((((state_q == 6'd7) && decoded[14]) && dsj_precondition) && !(is_mv_m2m && m2m_same_reg)) && !(is_div && div_v)) || mmfm_pop_wr) || mv_load_ptr_wr) || m2m_src_wr) || graphics_wb) || int_sp_wb;
	assign rf_wr_file = (int_sp_wb ? 1'b0 : (graphics_wb ? 1'b1 : decoded[44]));
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	assign rf_wr_idx = (int_sp_wb ? tms34010_pkg_REG_SP_IDX : (line_wb_count ? tms34010_pkg_B_COUNT_IDX : ((fill_wb || pblt_wb_daddr) || line_wb_daddr ? tms34010_pkg_B_DADDR_IDX : (pblt_wb_saddr || line_wb_d ? tms34010_pkg_B_SADDR_IDX : (mmfm_pop_wr ? mm_iter_idx : (mv_load_ptr_wr || m2m_src_wr ? decoded[39-:4] : ((is_mpy || is_div) && pair_wb_step ? decoded[43-:4] + 4'd1 : decoded[43-:4])))))));
	wire [4:0] exgf_cur_fs;
	wire exgf_cur_fe;
	wire [31:0] exgf_new_rd;
	reg [31:0] exgf_new_st;
	assign exgf_cur_fs = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	assign exgf_cur_fe = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FE1_BIT] : st_value[tms34010_pkg_ST_FE0_BIT]);
	assign exgf_new_rd = {{26 {1'b0}}, exgf_cur_fe, exgf_cur_fs};
	always @(*) begin
		if (_sv2v_0)
			;
		exgf_new_st = st_value;
		if (instr_word_q[9]) begin
			exgf_new_st[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] = rf_rs2_data[4:0];
			exgf_new_st[tms34010_pkg_ST_FE1_BIT] = rf_rs2_data[5];
		end
		else begin
			exgf_new_st[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO] = rf_rs2_data[4:0];
			exgf_new_st[tms34010_pkg_ST_FE0_BIT] = rf_rs2_data[5];
		end
	end
	wire [15:0] xy_rs_x;
	wire [15:0] xy_rs_y;
	wire [15:0] xy_rd_x;
	wire [15:0] xy_rd_y;
	wire [15:0] xy_x_add;
	wire [15:0] xy_y_add;
	wire [15:0] xy_x_sub;
	wire [15:0] xy_y_sub;
	wire [31:0] addxy_result;
	wire [31:0] subxy_result;
	wire [3:0] addxy_flags;
	wire [3:0] subxy_flags;
	assign xy_rs_x = rf_rs1_data[15:0];
	assign xy_rs_y = rf_rs1_data[31:16];
	assign xy_rd_x = rf_rs2_data[15:0];
	assign xy_rd_y = rf_rs2_data[31:16];
	assign xy_x_add = xy_rd_x + xy_rs_x;
	assign xy_y_add = xy_rd_y + xy_rs_y;
	assign xy_x_sub = xy_rd_x - xy_rs_x;
	assign xy_y_sub = xy_rd_y - xy_rs_y;
	assign addxy_result = {xy_y_add, xy_x_add};
	assign subxy_result = {xy_y_sub, xy_x_sub};
	assign addxy_flags = {xy_x_add == 16'd0, xy_y_add[15], xy_y_add == 16'd0, xy_x_add[15]};
	assign subxy_flags = {xy_x_sub == 16'd0, $signed(xy_rs_y) > $signed(xy_rd_y), xy_y_sub == 16'd0, $signed(xy_rs_x) > $signed(xy_rd_x)};
	wire [3:0] cmpxy_flags;
	assign cmpxy_flags = {xy_x_sub == 16'd0, xy_y_sub[15], xy_y_sub == 16'd0, xy_x_sub[15]};
	wire [15:0] cpw_pt_x;
	wire [15:0] cpw_pt_y;
	wire [15:0] cpw_ws_x;
	wire [15:0] cpw_ws_y;
	wire [15:0] cpw_we_x;
	wire [15:0] cpw_we_y;
	wire cpw_b5;
	wire cpw_b6;
	wire cpw_b7;
	wire cpw_b8;
	wire [31:0] cpw_result;
	wire [3:0] cpw_flags;
	assign cpw_pt_x = rf_rs1_data[15:0];
	assign cpw_pt_y = rf_rs1_data[31:16];
	assign cpw_ws_x = rf_rs2_data[15:0];
	assign cpw_ws_y = rf_rs2_data[31:16];
	assign cpw_we_x = rf_rs3_data[15:0];
	assign cpw_we_y = rf_rs3_data[31:16];
	assign cpw_b5 = $signed(cpw_ws_x) > $signed(cpw_pt_x);
	assign cpw_b6 = $signed(cpw_pt_x) > $signed(cpw_we_x);
	assign cpw_b7 = $signed(cpw_ws_y) > $signed(cpw_pt_y);
	assign cpw_b8 = $signed(cpw_pt_y) > $signed(cpw_we_y);
	assign cpw_result = {{23 {1'b0}}, cpw_b8, cpw_b7, cpw_b6, cpw_b5, 5'b00000};
	assign cpw_flags = {3'b000, ((cpw_b5 | cpw_b6) | cpw_b7) | cpw_b8};
	wire [4:0] cvxyl_ydp_shift;
	reg [4:0] cvxyl_xsh;
	wire [31:0] cvxyl_ypart;
	wire [31:0] cvxyl_xpart;
	wire [31:0] cvxyl_result;
	assign cvxyl_ydp_shift = 5'd31 - io_convdp[4:0];
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (io_psize[4:0])
			5'd1: cvxyl_xsh = 5'd0;
			5'd2: cvxyl_xsh = 5'd1;
			5'd4: cvxyl_xsh = 5'd2;
			5'd8: cvxyl_xsh = 5'd3;
			5'd16: cvxyl_xsh = 5'd4;
			default: cvxyl_xsh = 5'd0;
		endcase
	end
	assign cvxyl_ypart = {{16 {rf_rs1_data[31]}}, rf_rs1_data[31:16]} << cvxyl_ydp_shift;
	assign cvxyl_xpart = {16'b0000000000000000, rf_rs1_data[15:0]} << cvxyl_xsh;
	assign cvxyl_result = (cvxyl_ypart | cvxyl_xpart) + rf_rs3_data;
	wire signed [63:0] mpy_sprod;
	wire [63:0] mpy_uprod;
	wire [63:0] mpy_product;
	reg [63:0] mpy_product_q;
	assign is_mpy = (decoded[51-:7] == 7'd87) || (decoded[51-:7] == 7'd88);
	assign mpy_signed = decoded[51-:7] == 7'd87;
	assign mpy_rd_even = decoded[40] == 1'b0;
	wire [4:0] mpy_fs1;
	wire [31:0] mpy_fmask;
	reg [31:0] mpy_rs_field;
	assign mpy_fs1 = st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO];
	assign mpy_fmask = (32'd1 << mpy_fs1) - 32'd1;
	always @(*) begin
		if (_sv2v_0)
			;
		if (mpy_fs1 == 5'd0)
			mpy_rs_field = rf_rs1_data;
		else if (mpy_signed && rf_rs1_data[mpy_fs1 - 5'd1])
			mpy_rs_field = (rf_rs1_data & mpy_fmask) | ~mpy_fmask;
		else
			mpy_rs_field = rf_rs1_data & mpy_fmask;
	end
	assign mpy_sprod = $signed(rf_rs2_data) * $signed(mpy_rs_field);
	assign mpy_uprod = rf_rs2_data * mpy_rs_field;
	assign mpy_product = (mpy_signed ? $unsigned(mpy_sprod) : mpy_uprod);
	wire is_signed_div;
	wire is_div_mod;
	wire div_rd_even;
	wire div_use_pair;
	reg [63:0] div_dividend;
	wire [31:0] div_divisor;
	wire [31:0] div_quotient;
	wire [31:0] div_remainder;
	wire div_start;
	wire div_busy;
	wire div_done;
	wire div_overflow;
	assign is_divu = decoded[51-:7] == 7'd89;
	assign is_modu = decoded[51-:7] == 7'd90;
	assign is_divs = decoded[51-:7] == 7'd91;
	assign is_mods = decoded[51-:7] == 7'd92;
	assign is_div = ((is_divu || is_modu) || is_divs) || is_mods;
	assign is_signed_div = is_divs || is_mods;
	assign is_div_mod = is_modu || is_mods;
	assign div_rd_even = decoded[40] == 1'b0;
	assign div_use_pair = (is_divu || is_divs) && div_rd_even;
	wire div_dvd_sign;
	wire div_dvs_sign;
	wire div_result_neg;
	reg div_dvd_sign_q;
	reg div_dvs_sign_q;
	assign div_dvd_sign = is_signed_div && rf_rs2_data[31];
	assign div_dvs_sign = is_signed_div && rf_rs1_data[31];
	assign div_result_neg = div_dvd_sign_q ^ div_dvs_sign_q;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				div_dvd_sign_q <= 1'b0;
				div_dvs_sign_q <= 1'b0;
			end
			else if ((state_q == 6'd5) && is_div) begin
				div_dvd_sign_q <= div_dvd_sign;
				div_dvs_sign_q <= div_dvs_sign;
			end
		end
	wire [31:0] rd_abs;
	wire [63:0] raw64;
	wire [63:0] abs64;
	assign rd_abs = (rf_rs2_data[31] ? ~rf_rs2_data + 1'b1 : rf_rs2_data);
	assign raw64 = {rf_rs2_data, rf_rs3_data};
	assign abs64 = (rf_rs2_data[31] ? ~raw64 + 1'b1 : raw64);
	always @(*) begin
		if (_sv2v_0)
			;
		if (!is_signed_div)
			div_dividend = (div_use_pair ? raw64 : {{tms34010_pkg_DATA_WIDTH {1'b0}}, rf_rs2_data});
		else if (div_use_pair)
			div_dividend = abs64;
		else
			div_dividend = {{tms34010_pkg_DATA_WIDTH {1'b0}}, rd_abs};
	end
	assign div_divisor = (div_dvs_sign ? ~rf_rs1_data + 1'b1 : rf_rs1_data);
	assign div_start = (state_q == 6'd5) && is_div;
	tms34010_divider u_divider(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.start(div_start),
		.dividend(div_dividend),
		.divisor(div_divisor),
		.busy(div_busy),
		.done(div_done),
		.quotient(div_quotient),
		.remainder(div_remainder),
		.overflow(div_overflow)
	);
	wire [31:0] div_quot_out;
	wire [31:0] div_rem_out;
	wire [31:0] div_result_main;
	assign div_quot_out = (div_result_neg ? ~div_quotient + 1'b1 : div_quotient);
	assign div_rem_out = (div_dvd_sign_q ? ~div_remainder + 1'b1 : div_remainder);
	assign div_result_main = (is_div_mod ? div_rem_out : div_quot_out);
	assign div_signed_ovf = div_overflow || (is_signed_div && (div_result_neg ? div_quotient[31] && (div_quotient[30:0] != {31 {1'sb0}}) : div_quotient[31]));
	assign div_v = (is_signed_div ? div_signed_ovf : div_overflow);
	assign is_pair_wb = (is_mpy && mpy_rd_even) || (div_use_pair && !div_v);
	assign pair_second_pass = is_pair_wb && (pair_wb_step == 1'b0);
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				mpy_product_q <= 1'sb0;
				pair_wb_step <= 1'b0;
			end
			else begin
				if ((state_q == 6'd5) && is_mpy)
					mpy_product_q <= mpy_product;
				if (state_q == 6'd7)
					pair_wb_step <= (pair_second_pass ? 1'b1 : 1'b0);
				else
					pair_wb_step <= 1'b0;
			end
		end
	wire [4:0] fs_selected;
	reg [31:0] field_mask;
	reg field_msb;
	reg [31:0] sext_result;
	reg [31:0] zext_result;
	assign fs_selected = (instr_word_q[9] ? st_value[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] : st_value[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO]);
	always @(*) begin
		if (_sv2v_0)
			;
		if (fs_selected == 5'd0) begin
			field_mask = 1'sb1;
			field_msb = rf_rs2_data[31];
			sext_result = rf_rs2_data;
			zext_result = rf_rs2_data;
		end
		else begin
			field_mask = (32'd1 << fs_selected) - 32'd1;
			field_msb = rf_rs2_data[fs_selected - 5'd1];
			sext_result = (field_msb ? (rf_rs2_data & field_mask) | ~field_mask : rf_rs2_data & field_mask);
			zext_result = rf_rs2_data & field_mask;
		end
	end
	reg [4:0] lmo_bit_pos;
	reg [31:0] lmo_result;
	function automatic signed [4:0] sv2v_cast_5_signed;
		input reg signed [4:0] inp;
		sv2v_cast_5_signed = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		lmo_bit_pos = 5'd0;
		begin : sv2v_autoblock_2
			reg signed [31:0] i;
			for (i = 0; i < tms34010_pkg_DATA_WIDTH; i = i + 1)
				if (rf_rs1_data[i])
					lmo_bit_pos = sv2v_cast_5_signed(i);
		end
		if (rf_rs1_data == {32 {1'sb0}})
			lmo_result = 1'sb0;
		else
			lmo_result = {{27 {1'b0}}, ~lmo_bit_pos};
	end
	localparam [31:0] tms34010_pkg_REV_VALUE = 32'h00000008;
	localparam [31:0] tms34010_pkg_WORD_BIT_SIZE_2 = sv2v_cast_DEBC9(64);
	always @(*) begin
		if (_sv2v_0)
			;
		if (int_sp_wb)
			rf_wr_data = rf_sp - tms34010_pkg_WORD_BIT_SIZE_2;
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd81: rf_wr_data = {rf_rs2_data[31:16], rf_rs1_data[15:0]};
				7'd82: rf_wr_data = {rf_rs1_data[31:16], rf_rs2_data[15:0]};
				7'd83: rf_wr_data = addxy_result;
				7'd84: rf_wr_data = subxy_result;
				7'd97: rf_wr_data = drav_advance;
				7'd86: rf_wr_data = cpw_result;
				7'd87, 7'd88: rf_wr_data = (mpy_rd_even ? (pair_wb_step ? mpy_product_q[31:0] : mpy_product_q[63:32]) : mpy_product_q[31:0]);
				7'd89, 7'd91: rf_wr_data = (div_rd_even && pair_wb_step ? div_rem_out : div_quot_out);
				7'd90, 7'd92: rf_wr_data = div_rem_out;
				7'd47: rf_wr_data = st_value;
				7'd72: rf_wr_data = mm_rp_q;
				7'd73: rf_wr_data = (mmfm_pop_wr ? mem_rdata_eff : mm_rp_q);
				7'd74: rf_wr_data = mv_ptr_new;
				7'd101: rf_wr_data = mv_ptr_new;
				7'd102: rf_wr_data = mv_ptr_new;
				7'd75: rf_wr_data = (mv_load_ptr_wr ? mv_ptr_new : mv_load_data_q);
				7'd76: rf_wr_data = (m2m_src_wr ? m2m_src_new : m2m_dst_new);
				7'd78, 7'd80: rf_wr_data = mv_load_data_q;
				7'd93: rf_wr_data = cvxyl_result;
				7'd94, 7'd95: rf_wr_data = fill_addr_q;
				7'd96: rf_wr_data = (pblt_wb_saddr ? pblt_src_addr_q : (decoded[1] ? {pblt_dst_xy_raw_q[31:16] + pblt_dy_q, pblt_dst_xy_raw_q[15:0]} : pblt_dst_addr_q));
				7'd98: rf_wr_data = (line_wb_d ? line_d_q : (line_wb_daddr ? line_daddr_q : line_count_q));
				7'd54, 7'd55: rf_wr_data = pc_value;
				7'd56: rf_wr_data = tms34010_pkg_REV_VALUE;
				7'd57: rf_wr_data = lmo_result;
				7'd59: rf_wr_data = sext_result;
				7'd60: rf_wr_data = zext_result;
				7'd61: rf_wr_data = exgf_new_rd;
				default: rf_wr_data = (decoded[24] ? shifter_result : alu_result);
			endcase
	end
	assign alu_op = decoded[31-:4];
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd5, 7'd33, 7'd7, 7'd10, 7'd12, 7'd13, 7'd14, 7'd15, 7'd41, 7'd16, 7'd17, 7'd18, 7'd24, 7'd25, 7'd26, 7'd27, 7'd28, 7'd29, 7'd36, 7'd37, 7'd38, 7'd40, 7'd43, 7'd44: alu_a = rf_rs2_data;
			7'd42: alu_a = 1'sb0;
			7'd64, 7'd65, 7'd66, 7'd68, 7'd69, 7'd67, 7'd70, 7'd71: alu_a = rf_rs2_data;
			default: alu_a = rf_rs1_data;
		endcase
	end
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd17, 7'd18, 7'd25, 7'd26: alu_b = ~imm32;
			7'd1, 7'd2, 7'd16, 7'd24, 7'd27, 7'd28, 7'd29: alu_b = imm32;
			7'd3, 7'd12, 7'd13: alu_b = (decoded[23-:5] == 5'd0 ? 32'd32 : {{27 {1'b0}}, decoded[23-:5]});
			7'd36, 7'd37, 7'd38, 7'd40: alu_b = {{27 {1'b0}}, decoded[23-:5]};
			7'd43: alu_b = 32'd1 << decoded[23-:5];
			7'd44: alu_b = 32'd1 << rf_rs1_data[4:0];
			7'd64, 7'd65, 7'd66, 7'd68, 7'd69: alu_b = tms34010_pkg_WORD_BIT_SIZE;
			7'd67: alu_b = tms34010_pkg_WORD_BIT_SIZE + ({{27 {1'b0}}, decoded[23-:5]} << 4);
			7'd70: alu_b = tms34010_pkg_WORD_BIT_SIZE_2;
			7'd71: alu_b = (trap_skip_push ? 32'd0 : tms34010_pkg_WORD_BIT_SIZE_2);
			7'd5, 7'd33, 7'd7, 7'd10: alu_b = rf_rs1_data;
			default: alu_b = rf_rs2_data;
		endcase
	end
	assign alu_cin = st_c;
	assign st_flag_update_en = ((state_q == 6'd7) && decoded[13]) || fill_win_flag_wb;
	reg [31:0] setf_new_st;
	always @(*) begin
		if (_sv2v_0)
			;
		setf_new_st = st_value;
		if (instr_word_q[9]) begin
			setf_new_st[tms34010_pkg_ST_FS1_HI:tms34010_pkg_ST_FS1_LO] = instr_word_q[4:0];
			setf_new_st[tms34010_pkg_ST_FE1_BIT] = instr_word_q[5];
		end
		else begin
			setf_new_st[tms34010_pkg_ST_FS0_HI:tms34010_pkg_ST_FS0_LO] = instr_word_q[4:0];
			setf_new_st[tms34010_pkg_ST_FE0_BIT] = instr_word_q[5];
		end
	end
	assign st_write_en = ((state_q == 6'd7) && ((((((((decoded[51-:7] == 7'd48) || (decoded[51-:7] == 7'd58)) || (decoded[51-:7] == 7'd61)) || (decoded[51-:7] == 7'd62)) || (decoded[51-:7] == 7'd63)) || (decoded[51-:7] == 7'd65)) || (decoded[51-:7] == 7'd70)) || (decoded[51-:7] == 7'd71))) || ((state_q == 6'd20) && int_push_q);
	localparam [31:0] tms34010_pkg_ST_IE_BIT = 21;
	localparam [31:0] tms34010_pkg_ST_RESET_VALUE = 32'h00000010;
	always @(*) begin
		if (_sv2v_0)
			;
		if (state_q == 6'd20)
			st_write_data = tms34010_pkg_ST_RESET_VALUE;
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd48: st_write_data = rf_rs1_data;
				7'd58: st_write_data = setf_new_st;
				7'd61: st_write_data = exgf_new_st;
				7'd62: st_write_data = st_value & ~(32'd1 << tms34010_pkg_ST_IE_BIT);
				7'd63: st_write_data = st_value | (32'd1 << tms34010_pkg_ST_IE_BIT);
				7'd65: st_write_data = mem_rdata_eff;
				7'd70: st_write_data = popped_st_q;
				7'd71: st_write_data = tms34010_pkg_ST_RESET_VALUE;
				default: st_write_data = 1'sb0;
			endcase
	end
	reg branch_taken;
	localparam [3:0] tms34010_pkg_CC_C = 4'b1000;
	localparam [3:0] tms34010_pkg_CC_EQ = 4'b1010;
	localparam [3:0] tms34010_pkg_CC_GE = 4'b0101;
	localparam [3:0] tms34010_pkg_CC_GT = 4'b0111;
	localparam [3:0] tms34010_pkg_CC_HI = 4'b0011;
	localparam [3:0] tms34010_pkg_CC_HS = 4'b1001;
	localparam [3:0] tms34010_pkg_CC_LE = 4'b0110;
	localparam [3:0] tms34010_pkg_CC_LS = 4'b0010;
	localparam [3:0] tms34010_pkg_CC_LT = 4'b0100;
	localparam [3:0] tms34010_pkg_CC_N = 4'b1110;
	localparam [3:0] tms34010_pkg_CC_NE = 4'b1011;
	localparam [3:0] tms34010_pkg_CC_NN = 4'b1111;
	localparam [3:0] tms34010_pkg_CC_NV = 4'b1101;
	localparam [3:0] tms34010_pkg_CC_P = 4'b0001;
	localparam [3:0] tms34010_pkg_CC_UC = 4'b0000;
	localparam [3:0] tms34010_pkg_CC_V = 4'b1100;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[18-:4])
			tms34010_pkg_CC_UC: branch_taken = 1'b1;
			tms34010_pkg_CC_P: branch_taken = !st_n & !st_z;
			tms34010_pkg_CC_LS: branch_taken = st_c | st_z;
			tms34010_pkg_CC_HI: branch_taken = !st_c & !st_z;
			tms34010_pkg_CC_LT: branch_taken = st_n ^ st_v;
			tms34010_pkg_CC_LE: branch_taken = (st_n ^ st_v) | st_z;
			tms34010_pkg_CC_GT: branch_taken = !(st_n ^ st_v) & !st_z;
			tms34010_pkg_CC_GE: branch_taken = !(st_n ^ st_v);
			tms34010_pkg_CC_EQ: branch_taken = st_z;
			tms34010_pkg_CC_NE: branch_taken = !st_z;
			tms34010_pkg_CC_HS: branch_taken = !st_c;
			tms34010_pkg_CC_C: branch_taken = st_c;
			tms34010_pkg_CC_V: branch_taken = st_v;
			tms34010_pkg_CC_NV: branch_taken = !st_v;
			tms34010_pkg_CC_N: branch_taken = st_n;
			tms34010_pkg_CC_NN: branch_taken = !st_n;
			default: branch_taken = 1'b0;
		endcase
	end
	always @(*) begin
		if (_sv2v_0)
			;
		pc_load_en = 1'b0;
		pc_load_value = 1'sb0;
		if (state_q == 6'd7)
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd11:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_short;
					end
				7'd34:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_long;
					end
				7'd35: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs1_data[31:4], 4'h0};
				end
				7'd55: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs2_data[31:4], 4'h0};
				end
				7'd36, 7'd37, 7'd38:
					if (dsj_precondition && dsj_rd_nonzero) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_long;
					end
				7'd39:
					if (branch_taken) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_jacc;
					end
				7'd40:
					if (dsj_rd_nonzero) begin
						pc_load_en = 1'b1;
						pc_load_value = branch_target_dsjs;
					end
				7'd66: begin
					pc_load_en = 1'b1;
					pc_load_value = {rf_rs1_data[31:4], 4'h0};
				end
				7'd68: begin
					pc_load_en = 1'b1;
					pc_load_value = branch_target_jacc;
				end
				7'd69: begin
					pc_load_en = 1'b1;
					pc_load_value = branch_target_long;
				end
				7'd67: begin
					pc_load_en = 1'b1;
					pc_load_value = mem_rdata_eff;
				end
				7'd70: begin
					pc_load_en = 1'b1;
					pc_load_value = popped_pc_q;
				end
				7'd71: begin
					pc_load_en = 1'b1;
					pc_load_value = popped_pc_q;
				end
				default:
					;
			endcase
		else if (state_q == 6'd20) begin
			pc_load_en = 1'b1;
			pc_load_value = popped_pc_q;
		end
		else if ((state_q == 6'd38) && mem_ack) begin
			pc_load_en = 1'b1;
			pc_load_value = mem_rdata_eff;
		end
	end
	tms34010_regfile u_regfile(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.rs1_file(rf_rs1_file),
		.rs1_idx(rf_rs1_idx),
		.rs1_data(rf_rs1_data),
		.rs2_file(rf_rs2_file),
		.rs2_idx(rf_rs2_idx),
		.rs2_data(rf_rs2_data),
		.rs3_file(rf_rs3_file),
		.rs3_idx(rf_rs3_idx),
		.rs3_data(rf_rs3_data),
		.wr_en(rf_wr_en),
		.wr_file(rf_wr_file),
		.wr_idx(rf_wr_idx),
		.wr_data(rf_wr_data),
		.sp_o(rf_sp)
	);
	wire io_is_io;
	wire [15:0] io_rdata16;
	wire [15:0] io_intenb;
	wire [15:0] io_intpend;
	wire [15:0] io_hstctlh;
	wire nmi_clear;
	reg mem_we_int;
	tms34010_io_regs u_io_regs(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.req(mem_req),
		.we(mem_we_int),
		.addr(mem_addr),
		.size(mem_size),
		.wdata(mem_wdata),
		.rdata(io_rdata16),
		.is_io(io_is_io),
		.psize_o(io_psize),
		.convdp_o(io_convdp),
		.convsp_o(io_convsp),
		.control_o(io_control),
		.pmask_o(io_pmask),
		.intenb_o(io_intenb),
		.intpend_o(io_intpend),
		.dpystrt_o(dpystrt_o),
		.dpyctl_o(io_dpyctl),
		.hstctlh_o(io_hstctlh),
		.nmi_clear(nmi_clear),
		.wvp_set(wvp_set),
		.lint1_in(lint1_in)
	);
	wire int_req;
	wire [31:0] int_vector;
	tms34010_int_ctrl u_int_ctrl(
		.intpend(io_intpend),
		.intenb(io_intenb),
		.ie(st_value[tms34010_pkg_ST_IE_BIT]),
		.int_req(int_req),
		.int_vector(int_vector)
	);
	wire nmi_req;
	wire nmi_nmim;
	localparam [31:0] tms34010_pkg_HSTCTL_NMI_BIT = 8;
	assign nmi_req = io_hstctlh[tms34010_pkg_HSTCTL_NMI_BIT];
	localparam [31:0] tms34010_pkg_HSTCTL_NMIM_BIT = 9;
	assign nmi_nmim = io_hstctlh[tms34010_pkg_HSTCTL_NMIM_BIT];
	wire int_take;
	assign int_take = nmi_req || int_req;
	reg fetch_inflight_q;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst)
				fetch_inflight_q <= 1'b0;
			else if (((state_q == 6'd1) && mem_req) && !mem_ack)
				fetch_inflight_q <= 1'b1;
			else if (mem_ack || (state_q != 6'd1))
				fetch_inflight_q <= 1'b0;
		end
	reg [31:0] int_vec_q;
	reg int_is_nmi_q;
	localparam [31:0] tms34010_pkg_INT_VEC_NMI = 32'hfffffee0;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				int_vec_q <= 1'sb0;
				int_is_nmi_q <= 1'b0;
				int_push_q <= 1'b0;
			end
			else if ((state_q == 6'd1) && int_take) begin
				int_vec_q <= (nmi_req ? tms34010_pkg_INT_VEC_NMI : int_vector);
				int_is_nmi_q <= nmi_req;
				int_push_q <= (nmi_req ? !nmi_nmim : 1'b1);
			end
		end
	assign nmi_clear = (state_q == 6'd20) && int_is_nmi_q;
	assign mem_we = mem_we_int && !io_is_io;
	reg [15:0] io_rdata_q;
	reg io_is_io_q;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				io_rdata_q <= 1'sb0;
				io_is_io_q <= 1'b0;
			end
			else if (mem_req && mem_ack) begin
				io_rdata_q <= io_rdata16;
				io_is_io_q <= io_is_io;
			end
		end
	assign mem_rdata_eff = (mem_req ? (io_is_io ? {{16 {1'b0}}, io_rdata16} : mem_rdata) : (io_is_io_q ? {{16 {1'b0}}, io_rdata_q} : mem_rdata));
	tms34010_alu u_alu(
		.op(alu_op),
		.a(alu_a),
		.b(alu_b),
		.cin(alu_cin),
		.result(alu_result),
		.flags(alu_flags)
	);
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	reg [4:0] shifter_amount;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		case (decoded[51-:7])
			7'd49, 7'd50, 7'd53: shifter_amount = rf_rs1_data[4:0];
			7'd51, 7'd52: shifter_amount = ~rf_rs1_data[4:0] + {{4 {1'b0}}, 1'b1};
			7'd21, 7'd22: shifter_amount = ~decoded[23-:5] + {{4 {1'b0}}, 1'b1};
			default: shifter_amount = decoded[23-:5];
		endcase
	end
	tms34010_shifter u_shifter(
		.op(decoded[27-:3]),
		.a(rf_rs2_data),
		.amount(shifter_amount),
		.result(shifter_result),
		.flags(shifter_flags)
	);
	reg [3:0] flag_input;
	always @(*) begin
		if (_sv2v_0)
			;
		if (fill_win_flag_wb)
			flag_input = {3'b000, fill_win_violation};
		else
			(* full_case, parallel_case *)
			case (decoded[51-:7])
				7'd46: flag_input = 4'b0100;
				7'd45: flag_input = 4'b0000;
				7'd57: flag_input = {2'b00, rf_rs1_data == 1'b0, 1'b0};
				7'd59: flag_input = {sext_result[31], 1'b0, sext_result == 1'b0, 1'b0};
				7'd60: flag_input = {2'b00, zext_result == 1'b0, 1'b0};
				7'd72: flag_input = {~rf_rs2_data[31], 3'b000};
				7'd75, 7'd78, 7'd80: flag_input = {mv_load_data_q[31], 1'b0, mv_load_data_q == 1'b0, decoded[4] && (mv_load_data_q != 1'b0)};
				7'd83: flag_input = addxy_flags;
				7'd84: flag_input = subxy_flags;
				7'd85: flag_input = cmpxy_flags;
				7'd86: flag_input = cpw_flags;
				7'd87, 7'd88: flag_input = {mpy_product_q[63], 1'b0, mpy_product_q == 64'd0, 1'b0};
				7'd89, 7'd91, 7'd90, 7'd92: flag_input = {(is_signed_div && !div_v) && div_result_main[31], 1'b0, !div_v && (div_result_main == 1'b0), div_v};
				default: flag_input = (decoded[24] ? shifter_flags : alu_flags);
			endcase
	end
	reg [3:0] effective_flag_mask;
	always @(*) begin
		if (_sv2v_0)
			;
		effective_flag_mask = decoded[12-:4];
		if (is_div_mod && div_v)
			effective_flag_mask[1] = 1'b0;
		if (fill_win_flag_wb)
			effective_flag_mask = 4'b0001;
	end
	tms34010_status_reg u_status_reg(
		.clk(clk),
		.ce_cpu(ce_cpu),
		.rst(rst),
		.flag_update_en(st_flag_update_en),
		.flags_in(flag_input),
		.flag_update_mask(effective_flag_mask),
		.st_write_en(st_write_en),
		.st_write_data(st_write_data),
		.st_o(st_value),
		.n_o(st_n),
		.c_o(st_c),
		.z_o(st_z),
		.v_o(st_v)
	);
	wire [31:0] unused_rf_sp;
	wire [31:0] unused_st_value;
	wire unused_st_nv;
	assign unused_rf_sp = rf_sp;
	assign unused_st_value = st_value;
	assign unused_st_nv = (st_n ^ st_v) ^ st_z;
	localparam [5:0] tms34010_pkg_MEM_SIZE_32 = sv2v_cast_13C0F(tms34010_pkg_DATA_WIDTH);
	localparam [31:0] tms34010_pkg_TRAP_VECTOR_BASE = 32'hffffffe0;
	always @(*) begin
		if (_sv2v_0)
			;
		state_d = state_q;
		mem_req = 1'b0;
		mem_we_int = 1'b0;
		mem_addr = 1'sb0;
		mem_size = 1'sb0;
		mem_wdata = 1'sb0;
		mem_srt = 1'b0;
		pc_advance_en = 1'b0;
		(* full_case, parallel_case *)
		case (state_q)
			6'd0: state_d = 6'd38;
			6'd38: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = tms34010_pkg_TRAP_VECTOR_BASE;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				if (mem_ack)
					state_d = 6'd1;
			end
			6'd1:
				if (int_take && !fetch_inflight_q)
					state_d = (nmi_req && nmi_nmim ? 6'd19 : 6'd18);
				else begin
					mem_req = 1'b1;
					mem_we_int = 1'b0;
					mem_addr = pc_value;
					mem_size = tms34010_pkg_INSTR_WORD_BITS;
					if (mem_ack) begin
						state_d = 6'd2;
						pc_advance_en = 1'b1;
					end
				end
			6'd18: begin
				mem_req = 1'b1;
				mem_we_int = 1'b1;
				mem_addr = rf_sp - tms34010_pkg_WORD_BIT_SIZE;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				mem_wdata = pc_value;
				if (mem_ack)
					state_d = 6'd17;
			end
			6'd17: begin
				mem_req = 1'b1;
				mem_we_int = 1'b1;
				mem_addr = rf_sp - tms34010_pkg_WORD_BIT_SIZE_2;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				mem_wdata = st_value;
				if (mem_ack)
					state_d = 6'd19;
			end
			6'd19: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = int_vec_q;
				mem_size = tms34010_pkg_MEM_SIZE_32;
				if (mem_ack)
					state_d = 6'd20;
			end
			6'd20: state_d = 6'd1;
			6'd2:
				if (decoded[33])
					state_d = 6'd3;
				else if (decoded[34])
					state_d = 6'd3;
				else
					state_d = 6'd5;
			6'd3: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (decoded[33] ? 6'd4 : (is_mv_off_m2m ? 6'd39 : 6'd5));
				end
			end
			6'd4: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (is_mv_abs_m2m ? 6'd39 : 6'd5);
				end
			end
			6'd39: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = (is_mv_off_m2m ? 6'd5 : 6'd40);
				end
			end
			6'd40: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = pc_value;
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				if (mem_ack) begin
					pc_advance_en = 1'b1;
					state_d = 6'd5;
				end
			end
			6'd5:
				if (is_div)
					state_d = 6'd8;
				else if (is_fill)
					state_d = 6'd9;
				else if (is_pblt)
					state_d = 6'd12;
				else if (is_drav)
					state_d = (io_control[tms34010_pkg_CTRL_W_HI:tms34010_pkg_CTRL_W_LO] != 2'd0 ? 6'd28 : 6'd27);
				else if (is_line)
					state_d = 6'd29;
				else if (pixt_xy_win)
					state_d = 6'd37;
				else if (srt_active)
					state_d = (is_mv_load ? 6'd41 : 6'd42);
				else
					state_d = (decoded[8] ? 6'd6 : 6'd7);
			6'd8: state_d = (div_done ? 6'd7 : 6'd8);
			6'd9: state_d = ((fill_win_en_q || fill_w2_q) || fill_w1_q ? 6'd21 : 6'd10);
			6'd21: state_d = (fill_w1_q ? 6'd25 : (fill_w2_q && !fill_array_inside ? 6'd23 : 6'd10));
			6'd23: state_d = 6'd1;
			6'd25: state_d = 6'd1;
			6'd28: state_d = (((drav_w_q == 2'd2) || (drav_w_q == 2'd3)) && drav_in_window ? 6'd27 : 6'd7);
			6'd37: state_d = 6'd6;
			6'd41: begin
				mem_req = 1'b1;
				mem_we_int = 1'b0;
				mem_addr = (EXTERNAL_SRT ? mv_ptr : srt_bit_addr);
				mem_size = tms34010_pkg_INSTR_WORD_BITS;
				mem_srt = EXT_SRT_CMD;
				if (mem_ack && (EXTERNAL_SRT || srt_last))
					state_d = 6'd7;
			end
			6'd42:
				if (EXTERNAL_SRT || srt_wr_phase) begin
					mem_req = 1'b1;
					mem_we_int = 1'b1;
					mem_addr = (EXTERNAL_SRT ? mv_ptr : srt_bit_addr);
					mem_size = tms34010_pkg_INSTR_WORD_BITS;
					mem_wdata = (EXTERNAL_SRT ? {32 {1'sb0}} : {{16 {1'b0}}, srt_rdata_q});
					mem_srt = EXT_SRT_CMD;
					if (mem_ack && (EXTERNAL_SRT || srt_last))
						state_d = 6'd7;
				end
			6'd27: begin
				mem_req = 1'b1;
				mem_addr = drav_linear_q;
				mem_size = io_psize[5:0];
				if (!drav_substep_q)
					mem_we_int = 1'b0;
				else begin
					mem_we_int = 1'b1;
					mem_wdata = drav_merged;
				end
				if (mem_ack && drav_substep_q)
					state_d = 6'd7;
				else
					state_d = 6'd27;
			end
			6'd29: state_d = 6'd30;
			6'd30: state_d = 6'd31;
			6'd31: state_d = (line_count_q == {32 {1'sb0}} ? 6'd33 : (line_win_en ? 6'd36 : 6'd32));
			6'd36: state_d = 6'd32;
			6'd32: begin
				mem_req = 1'b1;
				mem_addr = line_linear;
				mem_size = io_psize[5:0];
				if (!line_substep_q)
					mem_we_int = 1'b0;
				else begin
					mem_we_int = 1'b1;
					mem_wdata = line_merged;
				end
				if ((mem_ack && line_substep_q) && ((line_count_q == 32'd1) || line_abort))
					state_d = 6'd33;
				else
					state_d = 6'd32;
			end
			6'd33: state_d = 6'd34;
			6'd34: state_d = 6'd35;
			6'd35: state_d = 6'd1;
			6'd10: begin
				mem_req = 1'b1;
				mem_addr = fill_addr_q;
				mem_size = io_psize[5:0];
				if (!fill_substep_q)
					mem_we_int = 1'b0;
				else begin
					mem_we_int = 1'b1;
					mem_wdata = fill_merged;
				end
				if ((mem_ack && fill_substep_q) && fill_done)
					state_d = 6'd11;
				else
					state_d = 6'd10;
			end
			6'd11: state_d = 6'd1;
			6'd12: state_d = ((pblt_dx_q == 16'd0) || (pblt_dy_q == 16'd0) ? 6'd1 : (decoded[0] ? 6'd16 : ((pblt_win_en_q || pblt_w2_q) || pblt_w1_q ? 6'd22 : 6'd13)));
			6'd16: state_d = ((pblt_win_en_q || pblt_w2_q) || pblt_w1_q ? 6'd22 : 6'd13);
			6'd22: state_d = (pblt_w1_q ? 6'd26 : (pblt_w2_q && !pblt_array_inside ? 6'd24 : 6'd13));
			6'd24: state_d = 6'd1;
			6'd26: state_d = 6'd1;
			6'd13: begin
				mem_req = 1'b1;
				mem_size = io_psize[5:0];
				(* full_case, parallel_case *)
				case (pblt_substep_q)
					2'd0: begin
						mem_we_int = 1'b0;
						mem_addr = pblt_src_addr_q;
						if (decoded[0])
							mem_size = sv2v_cast_13C0F_signed(1);
					end
					2'd1: begin
						mem_we_int = 1'b0;
						mem_addr = pblt_dst_addr_q;
					end
					default: begin
						mem_we_int = 1'b1;
						mem_addr = pblt_dst_addr_q;
						mem_wdata = pblt_merged;
					end
				endcase
				if ((mem_ack && (pblt_substep_q == 2'd2)) && pblt_done)
					state_d = 6'd14;
				else
					state_d = 6'd13;
			end
			6'd14: state_d = 6'd15;
			6'd15: state_d = 6'd1;
			6'd6: begin
				(* full_case, parallel_case *)
				case (decoded[51-:7])
					7'd64: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = alu_result;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = st_value;
					end
					7'd65: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = rf_rs2_data;
						mem_size = tms34010_pkg_MEM_SIZE_32;
					end
					7'd66, 7'd68, 7'd69: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = alu_result;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = pc_value;
					end
					7'd67: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = rf_rs2_data;
						mem_size = tms34010_pkg_MEM_SIZE_32;
					end
					7'd70: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_addr = (mem_op_step == 2'd0 ? rf_rs2_data : rf_rs2_data + tms34010_pkg_WORD_BIT_SIZE);
					end
					7'd71: begin
						mem_req = 1'b1;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						if (trap_skip_push) begin
							mem_we_int = 1'b0;
							mem_addr = tms34010_pkg_TRAP_VECTOR_BASE;
						end
						else
							(* full_case, parallel_case *)
							case (mem_op_step)
								2'd0: begin
									mem_we_int = 1'b1;
									mem_addr = rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE;
									mem_wdata = pc_value;
								end
								2'd1: begin
									mem_we_int = 1'b1;
									mem_addr = rf_rs2_data - tms34010_pkg_WORD_BIT_SIZE_2;
									mem_wdata = st_value;
								end
								default: begin
									mem_we_int = 1'b0;
									mem_addr = tms34010_pkg_TRAP_VECTOR_BASE - ({{27 {1'b0}}, decoded[23-:5]} << 5);
								end
							endcase
					end
					7'd72: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = mm_rp_q;
						mem_size = tms34010_pkg_MEM_SIZE_32;
						mem_wdata = rf_rs1_data;
					end
					7'd73: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = mm_rp_q;
						mem_size = tms34010_pkg_MEM_SIZE_32;
					end
					7'd74: begin
						mem_req = 1'b1;
						mem_addr = mv_addr;
						mem_size = mv_fs;
						if (pixt_rmw && (mem_op_step == 2'd0))
							mem_we_int = 1'b0;
						else begin
							mem_we_int = 1'b1;
							mem_wdata = (pixt_rmw ? pixt_merged : rf_rs1_data);
						end
					end
					7'd75: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = mv_addr;
						mem_size = mv_fs;
					end
					7'd79: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = rf_rs2_data + imm32;
						mem_size = mv_fs;
						mem_wdata = rf_rs1_data;
					end
					7'd80: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = rf_rs1_data + imm32;
						mem_size = mv_fs;
					end
					7'd77: begin
						mem_req = 1'b1;
						mem_we_int = 1'b1;
						mem_addr = imm32;
						mem_size = mv_fs;
						mem_wdata = rf_rs1_data;
					end
					7'd78: begin
						mem_req = 1'b1;
						mem_we_int = 1'b0;
						mem_addr = imm32;
						mem_size = mv_fs;
					end
					7'd76: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = m2m_src_addr;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = m2m_dst_addr;
							mem_wdata = move_data_q;
						end
					end
					7'd99: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = imm2_32;
							mem_wdata = move_data_q;
						end
					end
					7'd100: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = rf_rs1_data + imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = rf_rs2_data + imm2_off_sext;
							mem_wdata = move_data_q;
						end
					end
					7'd101: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = rf_rs1_data + imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = rf_rs2_data;
							mem_wdata = move_data_q;
						end
					end
					7'd102: begin
						mem_req = 1'b1;
						mem_size = mv_fs;
						if (mem_op_step == 2'd0) begin
							mem_we_int = 1'b0;
							mem_addr = imm32;
						end
						else begin
							mem_we_int = 1'b1;
							mem_addr = rf_rs2_data;
							mem_wdata = move_data_q;
						end
					end
					default:
						;
				endcase
				if (mem_ack)
					(* full_case, parallel_case *)
					case (decoded[51-:7])
						7'd70:
							if (mem_op_step == 2'd1)
								state_d = 6'd7;
						7'd71:
							if (trap_skip_push || (mem_op_step == 2'd2))
								state_d = 6'd7;
						7'd72, 7'd73:
							if (mm_mask_will_be_empty)
								state_d = 6'd7;
						7'd76, 7'd99, 7'd100, 7'd101, 7'd102:
							if (mem_op_step == 2'd1)
								state_d = 6'd7;
						7'd74:
							if (!pixt_rmw || (mem_op_step == 2'd1))
								state_d = 6'd7;
						default: state_d = 6'd7;
					endcase
			end
			6'd7: state_d = (pair_second_pass ? 6'd7 : 6'd1);
			default: state_d = 6'd0;
		endcase
	end
	assign state_o = state_q;
	assign pc_o = pc_value;
	assign instr_word_o = instr_word_q;
	assign illegal_opcode_o = illegal_q;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_decode (
	instr,
	decoded
);
	reg _sv2v_0;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	input wire [15:0] instr;
	output reg [52:0] decoded;
	wire [9:0] top10;
	wire [6:0] top7;
	wire [5:0] top6;
	assign top10 = instr[15:6];
	assign top7 = instr[15:9];
	assign top6 = instr[15:10];
	localparam [9:0] MOVI_TOP10 = 10'b0000100111;
	localparam [5:0] MOVK_TOP6 = 6'b000110;
	localparam [5:0] ADDK_TOP6 = 6'b000100;
	localparam [5:0] SUBK_TOP6 = 6'b000101;
	localparam [8:0] UNARY_TOP9 = 9'b000000111;
	localparam [10:0] ADDI_IW_TOP11 = 11'b00001011000;
	localparam [10:0] SUBI_IW_TOP11 = 11'b00001011111;
	localparam [10:0] CMPI_IW_TOP11 = 11'b00001011010;
	localparam [5:0] SLA_K_TOP6 = 6'b001000;
	localparam [5:0] SLL_K_TOP6 = 6'b001001;
	localparam [5:0] SRA_K_TOP6 = 6'b001010;
	localparam [5:0] SRL_K_TOP6 = 6'b001011;
	localparam [5:0] RL_K_TOP6 = 6'b001100;
	localparam [10:0] ADDI_IL_TOP11 = 11'b00001011001;
	localparam [10:0] CMPI_IL_TOP11 = 11'b00001011011;
	localparam [10:0] ANDI_IL_TOP11 = 11'b00001011100;
	localparam [10:0] ORI_IL_TOP11 = 11'b00001011101;
	localparam [10:0] XORI_IL_TOP11 = 11'b00001011110;
	localparam [10:0] SUBI_IL_TOP11 = 11'b00001101000;
	localparam [5:0] MOVE_RR_TOP6 = 6'b010011;
	localparam [5:0] MOVE_STORE_TOP6 = 6'b100000;
	localparam [5:0] MOVE_LOAD_TOP6 = 6'b100001;
	localparam [5:0] MOVE_M2M_TOP6 = 6'b100010;
	localparam [5:0] MOVE_M2M_POSTINC_TOP6 = 6'b100110;
	localparam [5:0] MOVE_M2M_PREDEC_TOP6 = 6'b101010;
	localparam [5:0] MOVE_OFF_STORE_TOP6 = 6'b101100;
	localparam [5:0] MOVE_OFF_LOAD_TOP6 = 6'b101101;
	localparam [5:0] MOVE_OFF_M2M_TOP6 = 6'b101110;
	localparam [5:0] MOVE_OFF_NI_TOP6 = 6'b110100;
	localparam [5:0] MOVE_ABS_NI_TOP6 = 6'b110101;
	localparam [5:0] MOVE_STORE_POSTINC_TOP6 = 6'b100100;
	localparam [5:0] MOVE_LOAD_POSTINC_TOP6 = 6'b100101;
	localparam [5:0] MOVE_STORE_PREDEC_TOP6 = 6'b101000;
	localparam [5:0] MOVE_LOAD_PREDEC_TOP6 = 6'b101001;
	localparam [6:0] MOVB_STORE_TOP7 = 7'b1000110;
	localparam [6:0] MOVB_LOAD_TOP7 = 7'b1000111;
	localparam [6:0] MOVB_M2M_TOP7 = 7'b1001110;
	localparam [6:0] MOVB_OFF_STORE_TOP7 = 7'b1010110;
	localparam [6:0] MOVB_OFF_LOAD_TOP7 = 7'b1010111;
	localparam [6:0] MOVB_OFF_M2M_TOP7 = 7'b1011110;
	localparam [6:0] PIXT_STORE_TOP7 = 7'b1111100;
	localparam [6:0] PIXT_LOAD_TOP7 = 7'b1111101;
	localparam [6:0] PIXT_M2M_TOP7 = 7'b1111110;
	localparam [6:0] PIXT_XY_STORE_TOP7 = 7'b1111000;
	localparam [6:0] PIXT_XY_LOAD_TOP7 = 7'b1111001;
	localparam [6:0] PIXT_XY_M2M_TOP7 = 7'b1111010;
	localparam [6:0] MOVX_TOP7 = 7'b1110110;
	localparam [6:0] MOVY_TOP7 = 7'b1110111;
	localparam [6:0] CVXYL_TOP7 = 7'b1110100;
	localparam [6:0] ADDXY_TOP7 = 7'b1110000;
	localparam [6:0] SUBXY_TOP7 = 7'b1110001;
	localparam [6:0] DRAV_TOP7 = 7'b1111011;
	localparam [6:0] CMPXY_TOP7 = 7'b1110010;
	localparam [6:0] CPW_TOP7 = 7'b1110011;
	localparam [6:0] MPYS_TOP7 = 7'b0101110;
	localparam [6:0] MPYU_TOP7 = 7'b0101111;
	localparam [6:0] DIVU_TOP7 = 7'b0101101;
	localparam [6:0] MODU_TOP7 = 7'b0110111;
	localparam [6:0] DIVS_TOP7 = 7'b0101100;
	localparam [6:0] MODS_TOP7 = 7'b0110110;
	localparam [6:0] ADD_RR_TOP7 = 7'b0100000;
	localparam [6:0] ADDC_RR_TOP7 = 7'b0100001;
	localparam [6:0] SUB_RR_TOP7 = 7'b0100010;
	localparam [6:0] SUBB_RR_TOP7 = 7'b0100011;
	localparam [6:0] AND_RR_TOP7 = 7'b0101000;
	localparam [6:0] ANDN_RR_TOP7 = 7'b0101001;
	localparam [6:0] OR_RR_TOP7 = 7'b0101010;
	localparam [6:0] XOR_RR_TOP7 = 7'b0101011;
	localparam [6:0] CMP_RR_TOP7 = 7'b0100100;
	localparam [15:0] PUSHST_OPCODE = 16'h01e0;
	localparam [15:0] POPST_OPCODE = 16'h01c0;
	localparam [10:0] CALL_RS_TOP11 = 11'b00001001001;
	localparam [15:0] RETI_OPCODE = 16'h0940;
	localparam [10:0] TRAP_TOP11 = 11'b00001001000;
	localparam [10:0] MMTM_TOP11 = 11'b00001001100;
	localparam [10:0] MMFM_TOP11 = 11'b00001001101;
	localparam [15:0] CALLA_OPCODE = 16'h0d5f;
	localparam [15:0] CALLR_OPCODE = 16'h0d3f;
	localparam [10:0] RETS_TOP11 = 11'b00001001011;
	localparam [15:0] DINT_OPCODE = 16'h0360;
	localparam [15:0] EINT_OPCODE = 16'h0d60;
	localparam [5:0] EXGF_TOP6 = 6'b110101;
	localparam [5:0] SETF_TOP6 = 6'b000001;
	localparam [6:0] LMO_RR_TOP7 = 7'b0110101;
	localparam [6:0] SLA_RR_TOP7 = 7'b0110000;
	localparam [6:0] SLL_RR_TOP7 = 7'b0110001;
	localparam [6:0] SRA_RR_TOP7 = 7'b0110010;
	localparam [6:0] SRL_RR_TOP7 = 7'b0110011;
	localparam [6:0] RL_RR_TOP7 = 7'b0110100;
	localparam [3:0] JRCC_TOP4 = 4'b1100;
	localparam [15:0] NOP_OPCODE = 16'h0300;
	localparam [10:0] JUMP_RS_TOP11 = 11'b00000001011;
	localparam [10:0] DSJ_TOP11 = 11'b00001101100;
	localparam [10:0] DSJEQ_TOP11 = 11'b00001101101;
	localparam [10:0] DSJNE_TOP11 = 11'b00001101110;
	localparam [15:0] CLRC_OPCODE = 16'h0320;
	localparam [15:0] SETC_OPCODE = 16'h0de0;
	localparam [10:0] GETST_TOP11 = 11'b00000001100;
	localparam [10:0] PUTST_TOP11 = 11'b00000001101;
	localparam [10:0] GETPC_TOP11 = 11'b00000001010;
	localparam [10:0] EXGPC_TOP11 = 11'b00000001001;
	localparam [10:0] REV_TOP11 = 11'b00000000001;
	localparam [5:0] BTST_K_TOP6 = 6'b000111;
	localparam [6:0] BTST_RR_TOP7 = 7'b0100101;
	localparam [4:0] DSJS_TOP5 = 5'b00111;
	wire [3:0] rs_idx_from_instr;
	assign rs_idx_from_instr = instr[8:5];
	wire [10:0] top11;
	assign top11 = instr[15:5];
	wire reg_file_from_instr;
	wire [3:0] reg_idx_from_instr;
	assign reg_file_from_instr = instr[4];
	assign reg_idx_from_instr = instr[3:0];
	localparam [3:0] tms34010_pkg_CC_C = 4'b1000;
	localparam [3:0] tms34010_pkg_CC_EQ = 4'b1010;
	localparam [3:0] tms34010_pkg_CC_GE = 4'b0101;
	localparam [3:0] tms34010_pkg_CC_GT = 4'b0111;
	localparam [3:0] tms34010_pkg_CC_HI = 4'b0011;
	localparam [3:0] tms34010_pkg_CC_HS = 4'b1001;
	localparam [3:0] tms34010_pkg_CC_LE = 4'b0110;
	localparam [3:0] tms34010_pkg_CC_LS = 4'b0010;
	localparam [3:0] tms34010_pkg_CC_LT = 4'b0100;
	localparam [3:0] tms34010_pkg_CC_N = 4'b1110;
	localparam [3:0] tms34010_pkg_CC_NE = 4'b1011;
	localparam [3:0] tms34010_pkg_CC_NN = 4'b1111;
	localparam [3:0] tms34010_pkg_CC_NV = 4'b1101;
	localparam [3:0] tms34010_pkg_CC_P = 4'b0001;
	localparam [3:0] tms34010_pkg_CC_UC = 4'b0000;
	localparam [3:0] tms34010_pkg_CC_V = 4'b1100;
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	always @(*) begin
		if (_sv2v_0)
			;
		decoded[52] = 1'b1;
		decoded[51-:7] = 7'd0;
		decoded[44] = 1'b0;
		decoded[43-:4] = 1'sb0;
		decoded[39-:4] = 1'sb0;
		decoded[34] = 1'b0;
		decoded[33] = 1'b0;
		decoded[32] = 1'b0;
		decoded[31-:4] = 4'd11;
		decoded[35] = reg_file_from_instr;
		decoded[7-:2] = 2'b00;
		decoded[5] = 1'b0;
		decoded[4] = 1'b0;
		decoded[3] = 1'b0;
		decoded[2] = 1'b0;
		decoded[1] = 1'b0;
		decoded[0] = 1'b0;
		decoded[27-:3] = 3'd0;
		decoded[24] = 1'b0;
		decoded[23-:5] = 1'sb0;
		decoded[18-:4] = 1'sb0;
		decoded[14] = 1'b0;
		decoded[13] = 1'b0;
		decoded[12-:4] = 4'b1111;
		decoded[8] = 1'b0;
		if ((top10 == MOVI_TOP10) && (instr[5] == 1'b0)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[33] = 1'b0;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if ((top10 == MOVI_TOP10) && (instr[5] == 1'b1)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd2;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b0;
			decoded[33] = 1'b1;
			decoded[32] = 1'b0;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top6 == MOVK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd3;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[34] = 1'b0;
			decoded[33] = 1'b0;
			decoded[32] = 1'b0;
			decoded[31-:4] = 4'd12;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == ADDK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd12;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top6 == SUBK_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd13;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == ADDI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd16;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == SUBI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd17;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == CMPI_IW_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd18;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top11 == ADDI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd24;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == SUBI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd25;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top11 == CMPI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd26;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top11 == ANDI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd27;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd6;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top11 == ORI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd28;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd7;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top11 == XORI_IL_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd29;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[31-:4] = 4'd8;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top6 == MOVE_RR_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd30;
			decoded[35] = reg_file_from_instr;
			decoded[44] = (instr[9] ? ~instr[4] : reg_file_from_instr);
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd11;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == MOVX_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd81;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd82;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == CVXYL_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd93;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == ADDXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd83;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUBXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd84;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == DRAV_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd97;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[8] = 1'b1;
		end
		if ((instr[15:8] == 8'hdf) && (instr[6:0] == 7'h1a)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd98;
			decoded[14] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == CMPXY_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd85;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if (top7 == MPYS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd87;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1010;
		end
		if (top7 == MPYU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd88;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == DIVU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd89;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0011;
		end
		if (top7 == MODU_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd90;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0011;
		end
		if (top7 == DIVS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd91;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == MODS_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd92;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == CPW_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd86;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
		end
		if (top6 == MOVE_STORE_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top6 == MOVE_LOAD_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top6 == MOVE_OFF_STORE_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd79;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_OFF_LOAD_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd80;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top6 == MOVE_OFF_M2M_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd100;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_OFF_NI_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd101;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[7-:2] = 2'b01;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if ((top6 == MOVE_ABS_NI_TOP6) && (instr[8:5] == 4'b0000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd102;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[7-:2] = 2'b01;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == MOVE_M2M_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_M2M_POSTINC_TOP6) || (top6 == MOVE_M2M_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_M2M_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_STORE_POSTINC_TOP6) || (top6 == MOVE_STORE_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_STORE_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if ((top6 == MOVE_LOAD_POSTINC_TOP6) || (top6 == MOVE_LOAD_PREDEC_TOP6)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[7-:2] = (top6 == MOVE_LOAD_PREDEC_TOP6 ? 2'b10 : 2'b01);
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top6 == SLA_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd19;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd1;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top6 == SLL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd20;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd0;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top6 == SRA_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd21;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd3;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1110;
		end
		if (top6 == SRL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd22;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd2;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top6 == RL_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd23;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = instr[9:5];
			decoded[27-:3] = 3'd4;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (instr[15:7] == UNARY_TOP9)
			case (instr[6:5])
				2'b00: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd41;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd13;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
					decoded[12-:4] = 4'b1011;
				end
				2'b01: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd14;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd10;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
				end
				2'b10: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd42;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd3;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
				end
				2'b11: begin
					decoded[52] = 1'b0;
					decoded[51-:7] = 7'd15;
					decoded[44] = reg_file_from_instr;
					decoded[43-:4] = reg_idx_from_instr;
					decoded[31-:4] = 4'd9;
					decoded[14] = 1'b1;
					decoded[13] = 1'b1;
					decoded[12-:4] = 4'b0010;
				end
				default:
					;
			endcase
		if (top7 == SLA_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd49;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd1;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SLL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd50;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd0;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == SRA_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd51;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd3;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1110;
		end
		if (top7 == SRL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd52;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd2;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == RL_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd53;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[27-:3] = 3'd4;
			decoded[24] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0110;
		end
		if (top7 == LMO_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd57;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:6] == 2'b01)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd58;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd59;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b001)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd60;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b100)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd77;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b101)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd78;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (((instr[15:10] == SETF_TOP6) && instr[8]) && (instr[7:5] == 3'b110)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd99;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVB_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == MOVB_OFF_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd79;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top7 == MOVB_OFF_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd80;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == MOVB_OFF_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd100;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[34] = 1'b1;
			decoded[32] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if ((((instr[15:10] == SETF_TOP6) && !instr[9]) && instr[8]) && (instr[7:5] == 3'b111)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd77;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if ((((instr[15:10] == SETF_TOP6) && instr[9]) && instr[8]) && (instr[7:5] == 3'b111)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd78;
			decoded[5] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[33] = 1'b1;
			decoded[8] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b1011;
		end
		if (top7 == PIXT_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[4] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_STORE_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd74;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_LOAD_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd75;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0001;
			decoded[8] = 1'b1;
		end
		if (top7 == PIXT_XY_M2M_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd76;
			decoded[4] = 1'b1;
			decoded[3] = 1'b1;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (((instr[15:10] == EXGF_TOP6) && instr[8]) && (instr[7:5] == 3'b000)) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd61;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (instr == DINT_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd62;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == EINT_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd63;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == PUSHST_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd64;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == POPST_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd65;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == CALL_RS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd66;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == RETS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd67;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[23-:5] = instr[4:0];
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == CALLA_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd68;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[33] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == CALLR_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd69;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd2;
			decoded[34] = 1'b1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (instr == RETI_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd70;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == TRAP_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd71;
			decoded[44] = 1'b0;
			decoded[43-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[39-:4] = tms34010_pkg_REG_SP_IDX;
			decoded[23-:5] = instr[4:0];
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[8] = 1'b1;
		end
		if (top11 == MMTM_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd72;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[34] = 1'b1;
			decoded[8] = 1'b1;
		end
		if (top11 == MMFM_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd73;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			decoded[34] = 1'b1;
			decoded[8] = 1'b1;
		end
		if (top7 == ADD_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd4;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == ADDC_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd32;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd1;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUB_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd5;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == SUBB_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd33;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd3;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
		end
		if (top7 == AND_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd6;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == ANDN_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd7;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd6;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == OR_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd8;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd7;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == XOR_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd9;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd8;
			decoded[14] = 1'b1;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (top7 == CMP_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd10;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd4;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
		end
		if ((((instr[15:12] == JRCC_TOP4) && (instr[7:0] != 8'h00)) && (instr[7:0] != 8'h80)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd11;
			decoded[18-:4] = instr[11:8];
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((instr[15:12] == JRCC_TOP4) && (instr[7:0] == 8'h00)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd34;
			decoded[18-:4] = instr[11:8];
			decoded[34] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == NOP_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd31;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr == 16'h0fc0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd94;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0fe0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd95;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f00) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f20) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f40) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[2] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f60) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[2] = 1'b1;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0f80) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[0] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (instr == 16'h0fa0) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd96;
			decoded[0] = 1'b1;
			decoded[1] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
			decoded[8] = 1'b0;
		end
		if (top11 == JUMP_RS_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd35;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (((top11 == DSJ_TOP11) || (top11 == DSJEQ_TOP11)) || (top11 == DSJNE_TOP11)) begin
			decoded[52] = 1'b0;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = 5'd1;
			decoded[31-:4] = 4'd2;
			decoded[34] = 1'b1;
			decoded[32] = 1'b0;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
			(* full_case, parallel_case *)
			case (top11)
				DSJ_TOP11: decoded[51-:7] = 7'd36;
				DSJEQ_TOP11: decoded[51-:7] = 7'd37;
				DSJNE_TOP11: decoded[51-:7] = 7'd38;
				default: decoded[51-:7] = 7'd0;
			endcase
		end
		if (((instr[15:12] == JRCC_TOP4) && (instr[7:0] == 8'h80)) && ((((((((((((((((instr[11:8] == tms34010_pkg_CC_UC) || (instr[11:8] == tms34010_pkg_CC_P)) || (instr[11:8] == tms34010_pkg_CC_LS)) || (instr[11:8] == tms34010_pkg_CC_HI)) || (instr[11:8] == tms34010_pkg_CC_LT)) || (instr[11:8] == tms34010_pkg_CC_LE)) || (instr[11:8] == tms34010_pkg_CC_GT)) || (instr[11:8] == tms34010_pkg_CC_GE)) || (instr[11:8] == tms34010_pkg_CC_EQ)) || (instr[11:8] == tms34010_pkg_CC_NE)) || (instr[11:8] == tms34010_pkg_CC_HS)) || (instr[11:8] == tms34010_pkg_CC_C)) || (instr[11:8] == tms34010_pkg_CC_V)) || (instr[11:8] == tms34010_pkg_CC_NV)) || (instr[11:8] == tms34010_pkg_CC_N)) || (instr[11:8] == tms34010_pkg_CC_NN))) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd39;
			decoded[18-:4] = instr[11:8];
			decoded[33] = 1'b1;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (instr[15:11] == DSJS_TOP5) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd40;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = 5'd1;
			decoded[31-:4] = 4'd2;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top6 == BTST_K_TOP6) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd43;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[23-:5] = ~instr[9:5];
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
		if (instr == CLRC_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd45;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0100;
		end
		if (instr == SETC_OPCODE) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd46;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0100;
		end
		if (top11 == GETST_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd47;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == PUTST_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd48;
			decoded[44] = reg_file_from_instr;
			decoded[39-:4] = reg_idx_from_instr;
			decoded[14] = 1'b0;
			decoded[13] = 1'b0;
		end
		if (top11 == GETPC_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd54;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == EXGPC_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd55;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top11 == REV_TOP11) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd56;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[14] = 1'b1;
			decoded[13] = 1'b0;
		end
		if (top7 == BTST_RR_TOP7) begin
			decoded[52] = 1'b0;
			decoded[51-:7] = 7'd44;
			decoded[44] = reg_file_from_instr;
			decoded[43-:4] = reg_idx_from_instr;
			decoded[39-:4] = rs_idx_from_instr;
			decoded[31-:4] = 4'd5;
			decoded[14] = 1'b0;
			decoded[13] = 1'b1;
			decoded[12-:4] = 4'b0010;
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_divider (
	clk,
	ce_cpu,
	rst,
	start,
	dividend,
	divisor,
	busy,
	done,
	quotient,
	remainder,
	overflow
);
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire start;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [63:0] dividend;
	input wire [31:0] divisor;
	output wire busy;
	output wire done;
	output wire [31:0] quotient;
	output wire [31:0] remainder;
	output wire overflow;
	reg [1:0] st_q;
	reg [tms34010_pkg_DATA_WIDTH:0] rem_q;
	reg [31:0] quot_q;
	reg [31:0] dvd_lo_q;
	reg [31:0] divisor_q;
	reg ovf_q;
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	reg [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] iter_q;
	wire [tms34010_pkg_DATA_WIDTH:0] shifted;
	wire [tms34010_pkg_DATA_WIDTH:0] divisor_ext;
	assign divisor_ext = {1'b0, divisor_q};
	assign shifted = {rem_q[31:0], dvd_lo_q[31]};
	wire start_overflow;
	assign start_overflow = (divisor == {32 {1'sb0}}) || (dividend[63:tms34010_pkg_DATA_WIDTH] >= divisor);
	function automatic [5:0] sv2v_cast_287E4;
		input reg [5:0] inp;
		sv2v_cast_287E4 = inp;
	endfunction
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				st_q <= 2'd0;
				rem_q <= 1'sb0;
				quot_q <= 1'sb0;
				dvd_lo_q <= 1'sb0;
				divisor_q <= 1'sb0;
				ovf_q <= 1'b0;
				iter_q <= 1'sb0;
			end
			else
				(* full_case, parallel_case *)
				case (st_q)
					2'd0:
						if (start) begin
							divisor_q <= divisor;
							ovf_q <= start_overflow;
							rem_q <= {1'b0, dividend[63:tms34010_pkg_DATA_WIDTH]};
							dvd_lo_q <= dividend[31:0];
							quot_q <= 1'sb0;
							iter_q <= 1'sb0;
							st_q <= (start_overflow ? 2'd2 : 2'd1);
						end
					2'd1: begin
						if (shifted >= divisor_ext) begin
							rem_q <= shifted - divisor_ext;
							quot_q <= {quot_q[30:0], 1'b1};
						end
						else begin
							rem_q <= shifted;
							quot_q <= {quot_q[30:0], 1'b0};
						end
						dvd_lo_q <= {dvd_lo_q[30:0], 1'b0};
						iter_q <= iter_q + 1'b1;
						if (iter_q == sv2v_cast_287E4(31))
							st_q <= 2'd2;
					end
					2'd2: st_q <= 2'd0;
					default: st_q <= 2'd0;
				endcase
		end
	assign busy = st_q != 2'd0;
	assign done = st_q == 2'd2;
	assign quotient = quot_q;
	assign remainder = rem_q[31:0];
	assign overflow = ovf_q;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_int_ctrl (
	intpend,
	intenb,
	ie,
	int_req,
	int_vector
);
	reg _sv2v_0;
	input wire [15:0] intpend;
	input wire [15:0] intenb;
	input wire ie;
	output wire int_req;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	output reg [31:0] int_vector;
	wire [15:0] active;
	assign active = intpend & intenb;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	localparam [31:0] tms34010_pkg_INT_HI_BIT = 9;
	localparam [31:0] tms34010_pkg_INT_WV_BIT = 11;
	localparam [31:0] tms34010_pkg_INT_X1_BIT = 1;
	localparam [31:0] tms34010_pkg_INT_X2_BIT = 2;
	assign int_req = ie && ((((active[tms34010_pkg_INT_HI_BIT] || active[tms34010_pkg_INT_DI_BIT]) || active[tms34010_pkg_INT_WV_BIT]) || active[tms34010_pkg_INT_X1_BIT]) || active[tms34010_pkg_INT_X2_BIT]);
	localparam [31:0] tms34010_pkg_INT_VEC_DI = 32'hfffffea0;
	localparam [31:0] tms34010_pkg_INT_VEC_HI = 32'hfffffec0;
	localparam [31:0] tms34010_pkg_INT_VEC_WV = 32'hfffffe80;
	localparam [31:0] tms34010_pkg_INT_VEC_X1 = 32'hffffffc0;
	localparam [31:0] tms34010_pkg_INT_VEC_X2 = 32'hffffffa0;
	always @(*) begin
		if (_sv2v_0)
			;
		if (active[tms34010_pkg_INT_HI_BIT])
			int_vector = tms34010_pkg_INT_VEC_HI;
		else if (active[tms34010_pkg_INT_DI_BIT])
			int_vector = tms34010_pkg_INT_VEC_DI;
		else if (active[tms34010_pkg_INT_WV_BIT])
			int_vector = tms34010_pkg_INT_VEC_WV;
		else if (active[tms34010_pkg_INT_X1_BIT])
			int_vector = tms34010_pkg_INT_VEC_X1;
		else if (active[tms34010_pkg_INT_X2_BIT])
			int_vector = tms34010_pkg_INT_VEC_X2;
		else
			int_vector = tms34010_pkg_INT_VEC_HI;
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_pc (
	clk,
	ce_cpu,
	rst,
	load_en,
	load_value,
	advance_en,
	advance_amount,
	pc_o
);
	reg _sv2v_0;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	localparam [31:0] tms34010_pkg_RESET_PC = 1'sb0;
	parameter [31:0] RESET_VALUE = tms34010_pkg_RESET_PC;
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire load_en;
	input wire [31:0] load_value;
	input wire advance_en;
	localparam [31:0] tms34010_pkg_PC_ADVANCE_WIDTH = 8;
	input wire [7:0] advance_amount;
	output wire [31:0] pc_o;
	reg [31:0] pc_q;
	reg [31:0] pc_d;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst)
				pc_q <= RESET_VALUE;
			else
				pc_q <= pc_d;
		end
	wire [31:0] advance_ext;
	assign advance_ext = {{tms34010_pkg_ADDR_WIDTH - tms34010_pkg_PC_ADVANCE_WIDTH {1'b0}}, advance_amount};
	always @(*) begin
		if (_sv2v_0)
			;
		pc_d = pc_q;
		if (load_en)
			pc_d = load_value;
		else if (advance_en)
			pc_d = pc_q + advance_ext;
	end
	assign pc_o = pc_q;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_regfile (
	clk,
	ce_cpu,
	rst,
	rs1_file,
	rs1_idx,
	rs1_data,
	rs2_file,
	rs2_idx,
	rs2_data,
	rs3_file,
	rs3_idx,
	rs3_data,
	wr_en,
	wr_file,
	wr_idx,
	wr_data,
	sp_o
);
	reg _sv2v_0;
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire rs1_file;
	input wire [3:0] rs1_idx;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	output reg [31:0] rs1_data;
	input wire rs2_file;
	input wire [3:0] rs2_idx;
	output reg [31:0] rs2_data;
	input wire rs3_file;
	input wire [3:0] rs3_idx;
	output reg [31:0] rs3_data;
	input wire wr_en;
	input wire wr_file;
	input wire [3:0] wr_idx;
	input wire [31:0] wr_data;
	output wire [31:0] sp_o;
	reg [31:0] a_regs [0:14];
	reg [31:0] b_regs [0:14];
	reg [31:0] sp_q;
	localparam [3:0] tms34010_pkg_REG_SP_IDX = 4'hf;
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs1_idx == tms34010_pkg_REG_SP_IDX)
			rs1_data = sp_q;
		else if (rs1_file == 1'b1)
			rs1_data = b_regs[rs1_idx];
		else
			rs1_data = a_regs[rs1_idx];
	end
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs2_idx == tms34010_pkg_REG_SP_IDX)
			rs2_data = sp_q;
		else if (rs2_file == 1'b1)
			rs2_data = b_regs[rs2_idx];
		else
			rs2_data = a_regs[rs2_idx];
	end
	always @(*) begin
		if (_sv2v_0)
			;
		if (rs3_idx == tms34010_pkg_REG_SP_IDX)
			rs3_data = sp_q;
		else if (rs3_file == 1'b1)
			rs3_data = b_regs[rs3_idx];
		else
			rs3_data = a_regs[rs3_idx];
	end
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst) begin
				begin : sv2v_autoblock_1
					reg [31:0] i;
					for (i = 0; i < 15; i = i + 1)
						a_regs[i] <= 1'sb0;
				end
				begin : sv2v_autoblock_2
					reg [31:0] i;
					for (i = 0; i < 15; i = i + 1)
						b_regs[i] <= 1'sb0;
				end
				sp_q <= 1'sb0;
			end
			else if (wr_en) begin
				if (wr_idx == tms34010_pkg_REG_SP_IDX)
					sp_q <= wr_data;
				else if (wr_file == 1'b1)
					b_regs[wr_idx] <= wr_data;
				else
					a_regs[wr_idx] <= wr_data;
			end
		end
	assign sp_o = sp_q;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_shifter (
	op,
	a,
	amount,
	result,
	flags
);
	reg _sv2v_0;
	input wire [2:0] op;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] a;
	localparam [31:0] tms34010_pkg_SHIFT_AMOUNT_WIDTH = 5;
	input wire [4:0] amount;
	output reg [31:0] result;
	output reg [3:0] flags;
	wire [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] amount_w6;
	wire [tms34010_pkg_SHIFT_AMOUNT_WIDTH:0] complement_w6;
	assign amount_w6 = {1'b0, amount};
	assign complement_w6 = 6'd32 - amount_w6;
	wire [4:0] left_carry_idx;
	wire [4:0] right_carry_idx;
	assign left_carry_idx = complement_w6[4:0];
	assign right_carry_idx = amount - 5'd1;
	wire [31:0] left;
	wire [31:0] right_l;
	wire signed [31:0] right_a;
	wire [31:0] right_comp;
	wire [31:0] left_comp;
	assign left = a << amount;
	assign right_l = a >> amount;
	assign right_a = $signed(a) >>> amount;
	assign right_comp = a >> complement_w6;
	assign left_comp = a << complement_w6;
	wire [31:0] sla_v_mask;
	wire [31:0] sla_v_res2;
	assign sla_v_mask = (32'hffffffff << (6'd31 - amount_w6)) & 32'h7fffffff;
	assign sla_v_res2 = (a[31] ? a ^ sla_v_mask : a);
	always @(*) begin
		if (_sv2v_0)
			;
		result = a;
		flags[3] = a[31];
		flags[2] = 1'b0;
		flags[1] = a == {32 {1'sb0}};
		flags[0] = 1'b0;
		if (amount != {5 {1'sb0}}) begin
			(* full_case, parallel_case *)
			case (op)
				3'd0: begin
					result = left;
					flags[2] = a[left_carry_idx];
				end
				3'd1: begin
					result = left;
					flags[2] = a[left_carry_idx];
					flags[0] = |(sla_v_res2 & sla_v_mask);
				end
				3'd2: begin
					result = right_l;
					flags[2] = a[right_carry_idx];
				end
				3'd3: begin
					result = right_a;
					flags[2] = a[right_carry_idx];
				end
				3'd4: begin
					result = left | right_comp;
					flags[2] = a[left_carry_idx];
				end
				3'd5: begin
					result = right_l | left_comp;
					flags[2] = a[right_carry_idx];
				end
				default:
					;
			endcase
			flags[3] = result[31];
			flags[1] = result == {32 {1'sb0}};
		end
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_status_reg (
	clk,
	ce_cpu,
	rst,
	flag_update_en,
	flags_in,
	flag_update_mask,
	st_write_en,
	st_write_data,
	st_o,
	n_o,
	c_o,
	z_o,
	v_o
);
	input wire clk;
	input wire ce_cpu;
	input wire rst;
	input wire flag_update_en;
	input wire [3:0] flags_in;
	input wire [3:0] flag_update_mask;
	input wire st_write_en;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] st_write_data;
	output wire [31:0] st_o;
	output wire n_o;
	output wire c_o;
	output wire z_o;
	output wire v_o;
	reg [31:0] st_q;
	localparam [31:0] tms34010_pkg_ST_C_BIT = 30;
	localparam [31:0] tms34010_pkg_ST_N_BIT = 31;
	localparam [31:0] tms34010_pkg_ST_RESET_VALUE = 32'h00000010;
	localparam [31:0] tms34010_pkg_ST_V_BIT = 28;
	localparam [31:0] tms34010_pkg_ST_Z_BIT = 29;
	always @(posedge clk)
		if (ce_cpu !== 1'b0) begin
			if (rst)
				st_q <= tms34010_pkg_ST_RESET_VALUE;
			else if (st_write_en)
				st_q <= st_write_data;
			else if (flag_update_en) begin
				if (flag_update_mask[3])
					st_q[tms34010_pkg_ST_N_BIT] <= flags_in[3];
				if (flag_update_mask[2])
					st_q[tms34010_pkg_ST_C_BIT] <= flags_in[2];
				if (flag_update_mask[1])
					st_q[tms34010_pkg_ST_Z_BIT] <= flags_in[1];
				if (flag_update_mask[0])
					st_q[tms34010_pkg_ST_V_BIT] <= flags_in[0];
			end
		end
	assign st_o = st_q;
	assign n_o = st_q[tms34010_pkg_ST_N_BIT];
	assign c_o = st_q[tms34010_pkg_ST_C_BIT];
	assign z_o = st_q[tms34010_pkg_ST_Z_BIT];
	assign v_o = st_q[tms34010_pkg_ST_V_BIT];
endmodule
`default_nettype wire
`default_nettype none
module tms34010_io_regs (
	clk,
	rst,
	req,
	we,
	addr,
	size,
	wdata,
	ce_pix,
	rdata,
	is_io,
	psize_o,
	convdp_o,
	convsp_o,
	control_o,
	pmask_o,
	intenb_o,
	intpend_o,
	dpystrt_o,
	dpyctl_o,
	hstctlh_o,
	nmi_clear,
	wvp_set,
	lint1_in
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	input wire [31:0] addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	input wire [5:0] size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	input wire [31:0] wdata;
	input wire ce_pix;
	output wire [15:0] rdata;
	output wire is_io;
	output wire [15:0] psize_o;
	output wire [15:0] convdp_o;
	output wire [15:0] convsp_o;
	output wire [15:0] control_o;
	output wire [15:0] pmask_o;
	output wire [15:0] intenb_o;
	output wire [15:0] intpend_o;
	output wire [15:0] dpystrt_o;
	output wire [15:0] dpyctl_o;
	output wire [15:0] hstctlh_o;
	input wire nmi_clear;
	input wire wvp_set;
	input wire lint1_in;
	localparam [31:0] tms34010_pkg_IO_REG_IDX_W = 5;
	wire [4:0] idx;
	assign is_io = (addr[31:30] == 2'b11) && (addr[29:9] == {21 {1'sb0}});
	assign idx = addr[8:4];
	localparam [31:0] tms34010_pkg_IO_REG_COUNT = 32;
	reg [15:0] io_reg [0:31];
	wire dpyint_pulse;
	wire [15:0] vid_hcount;
	wire [15:0] vid_vcount;
	wire vid_hs_unused;
	wire vid_vs_unused;
	wire vid_hb_unused;
	wire vid_vb_unused;
	wire vid_bl_unused;
	localparam [4:0] tms34010_pkg_IO_IDX_DPYINT = 5'h0a;
	localparam [4:0] tms34010_pkg_IO_IDX_HEBLNK = 5'h01;
	localparam [4:0] tms34010_pkg_IO_IDX_HESYNC = 5'h00;
	localparam [4:0] tms34010_pkg_IO_IDX_HSBLNK = 5'h02;
	localparam [4:0] tms34010_pkg_IO_IDX_HTOTAL = 5'h03;
	localparam [4:0] tms34010_pkg_IO_IDX_VEBLNK = 5'h05;
	localparam [4:0] tms34010_pkg_IO_IDX_VESYNC = 5'h04;
	localparam [4:0] tms34010_pkg_IO_IDX_VSBLNK = 5'h06;
	localparam [4:0] tms34010_pkg_IO_IDX_VTOTAL = 5'h07;
	tms34010_video u_video(
		.clk(clk),
		.rst(rst),
		.ce(ce_pix),
		.hesync(io_reg[tms34010_pkg_IO_IDX_HESYNC]),
		.heblnk(io_reg[tms34010_pkg_IO_IDX_HEBLNK]),
		.hsblnk(io_reg[tms34010_pkg_IO_IDX_HSBLNK]),
		.htotal(io_reg[tms34010_pkg_IO_IDX_HTOTAL]),
		.vesync(io_reg[tms34010_pkg_IO_IDX_VESYNC]),
		.veblnk(io_reg[tms34010_pkg_IO_IDX_VEBLNK]),
		.vsblnk(io_reg[tms34010_pkg_IO_IDX_VSBLNK]),
		.vtotal(io_reg[tms34010_pkg_IO_IDX_VTOTAL]),
		.dpyint(io_reg[tms34010_pkg_IO_IDX_DPYINT]),
		.hcount(vid_hcount),
		.vcount(vid_vcount),
		.hsync(vid_hs_unused),
		.vsync(vid_vs_unused),
		.hblank(vid_hb_unused),
		.vblank(vid_vb_unused),
		.blank(vid_bl_unused),
		.dpyint_pulse(dpyint_pulse)
	);
	wire lint1_lvl;
	assign lint1_lvl = lint1_in === 1'b1;
	wire field_contained;
	reg [15:0] selected_rdata;
	function automatic signed [5:0] sv2v_cast_13C0F_signed;
		input reg signed [5:0] inp;
		sv2v_cast_13C0F_signed = inp;
	endfunction
	assign field_contained = ((size >= sv2v_cast_13C0F_signed(1)) && (size <= sv2v_cast_13C0F_signed(16))) && (({2'b00, addr[3:0]} + size) <= sv2v_cast_13C0F_signed(16));
	localparam [31:0] tms34010_pkg_INT_X1_BIT = 1;
	localparam [4:0] tms34010_pkg_IO_IDX_HCOUNT = 5'h1c;
	localparam [4:0] tms34010_pkg_IO_IDX_INTPEND = 5'h12;
	localparam [4:0] tms34010_pkg_IO_IDX_VCOUNT = 5'h1d;
	function automatic [15:0] sv2v_cast_16;
		input reg [15:0] inp;
		sv2v_cast_16 = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		selected_rdata = io_reg[idx];
		if (idx == tms34010_pkg_IO_IDX_VCOUNT)
			selected_rdata = vid_vcount;
		else if (idx == tms34010_pkg_IO_IDX_HCOUNT)
			selected_rdata = vid_hcount;
		else if (idx == tms34010_pkg_IO_IDX_INTPEND)
			selected_rdata = io_reg[idx] | (sv2v_cast_16(lint1_lvl) << tms34010_pkg_INT_X1_BIT);
	end
	assign rdata = (!is_io ? 16'h0000 : (field_contained ? selected_rdata >> addr[3:0] : selected_rdata));
	reg io_span;
	reg [5:0] io_lo_bits;
	reg [15:0] io_write_mask;
	reg [15:0] io_write_data;
	reg [15:0] io_hi_mask;
	reg [15:0] io_hi_data;
	always @(*) begin
		if (_sv2v_0)
			;
		io_lo_bits = 6'd16 - {2'b00, addr[3:0]};
		io_span = (is_io && (size > sv2v_cast_13C0F_signed(16))) && (({2'b00, addr[3:0]} + size) <= sv2v_cast_13C0F_signed(32));
		io_write_mask = (field_contained ? (17'h1ffff >> (17 - size)) << addr[3:0] : (io_span ? 16'hffff << addr[3:0] : 16'hffff));
		io_write_data = (field_contained || io_span ? wdata[15:0] << addr[3:0] : wdata[15:0]);
		io_hi_mask = (io_span ? 16'hffff >> (6'd16 - (size - io_lo_bits)) : 16'h0000);
		io_hi_data = (io_span ? sv2v_cast_16(wdata >> io_lo_bits) : 16'h0000);
	end
	localparam [4:0] tms34010_pkg_IO_IDX_PSIZE = 5'h15;
	assign psize_o = io_reg[tms34010_pkg_IO_IDX_PSIZE];
	localparam [4:0] tms34010_pkg_IO_IDX_CONVDP = 5'h14;
	assign convdp_o = io_reg[tms34010_pkg_IO_IDX_CONVDP];
	localparam [4:0] tms34010_pkg_IO_IDX_CONVSP = 5'h13;
	assign convsp_o = io_reg[tms34010_pkg_IO_IDX_CONVSP];
	localparam [4:0] tms34010_pkg_IO_IDX_CONTROL = 5'h0b;
	assign control_o = io_reg[tms34010_pkg_IO_IDX_CONTROL];
	localparam [4:0] tms34010_pkg_IO_IDX_DPYSTRT = 5'h09;
	assign dpystrt_o = io_reg[tms34010_pkg_IO_IDX_DPYSTRT];
	localparam [4:0] tms34010_pkg_IO_IDX_DPYCTL = 5'h08;
	assign dpyctl_o = io_reg[tms34010_pkg_IO_IDX_DPYCTL];
	localparam [4:0] tms34010_pkg_IO_IDX_PMASK = 5'h16;
	assign pmask_o = io_reg[tms34010_pkg_IO_IDX_PMASK];
	localparam [4:0] tms34010_pkg_IO_IDX_INTENB = 5'h11;
	assign intenb_o = io_reg[tms34010_pkg_IO_IDX_INTENB];
	assign intpend_o = io_reg[tms34010_pkg_IO_IDX_INTPEND] | (sv2v_cast_16(lint1_lvl) << tms34010_pkg_INT_X1_BIT);
	localparam [4:0] tms34010_pkg_IO_IDX_HSTCTLH = 5'h10;
	assign hstctlh_o = io_reg[tms34010_pkg_IO_IDX_HSTCTLH];
	localparam [31:0] tms34010_pkg_HSTCTL_NMI_BIT = 8;
	localparam [31:0] tms34010_pkg_INT_DI_BIT = 10;
	localparam [31:0] tms34010_pkg_INT_WV_BIT = 11;
	localparam [15:0] tms34010_pkg_INTPEND_W0C_MASK = (16'h0001 << tms34010_pkg_INT_DI_BIT) | (16'h0001 << tms34010_pkg_INT_WV_BIT);
	function automatic [4:0] sv2v_cast_7548C;
		input reg [4:0] inp;
		sv2v_cast_7548C = inp;
	endfunction
	function automatic signed [4:0] sv2v_cast_7548C_signed;
		input reg signed [4:0] inp;
		sv2v_cast_7548C_signed = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin : sv2v_autoblock_1
			reg signed [31:0] i;
			for (i = 0; i < tms34010_pkg_IO_REG_COUNT; i = i + 1)
				io_reg[i] <= 16'h0000;
		end
		else begin
			if ((req && we) && is_io) begin
				if (idx == tms34010_pkg_IO_IDX_INTPEND)
					io_reg[tms34010_pkg_IO_IDX_INTPEND] <= io_reg[tms34010_pkg_IO_IDX_INTPEND] & (io_write_data | ~(tms34010_pkg_INTPEND_W0C_MASK & io_write_mask));
				else
					io_reg[idx] <= (io_reg[idx] & ~io_write_mask) | (io_write_data & io_write_mask);
				if (io_span && (idx != sv2v_cast_7548C(31))) begin
					if ((idx + sv2v_cast_7548C_signed(1)) == tms34010_pkg_IO_IDX_INTPEND)
						io_reg[tms34010_pkg_IO_IDX_INTPEND] <= io_reg[tms34010_pkg_IO_IDX_INTPEND] & (io_hi_data | ~(tms34010_pkg_INTPEND_W0C_MASK & io_hi_mask));
					else
						io_reg[idx + sv2v_cast_7548C_signed(1)] <= (io_reg[idx + sv2v_cast_7548C_signed(1)] & ~io_hi_mask) | (io_hi_data & io_hi_mask);
				end
			end
			else if (nmi_clear)
				io_reg[tms34010_pkg_IO_IDX_HSTCTLH][tms34010_pkg_HSTCTL_NMI_BIT] <= 1'b0;
			else if (wvp_set)
				io_reg[tms34010_pkg_IO_IDX_INTPEND][tms34010_pkg_INT_WV_BIT] <= 1'b1;
			if (dpyint_pulse && (io_reg[tms34010_pkg_IO_IDX_VTOTAL] != 16'h0000))
				io_reg[tms34010_pkg_IO_IDX_INTPEND][tms34010_pkg_INT_DI_BIT] <= 1'b1;
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module tms34010_refresh (
	clk,
	rst,
	rr,
	refresh_row,
	refresh_req
);
	input wire clk;
	input wire rst;
	input wire [1:0] rr;
	output wire [7:0] refresh_row;
	output wire refresh_req;
	wire enabled;
	wire [6:0] interval;
	assign enabled = (rr == 2'b00) || (rr == 2'b01);
	assign interval = (rr == 2'b01 ? 7'd63 : 7'd31);
	reg [6:0] presc_q;
	reg [7:0] refresh_row_q;
	assign refresh_req = enabled && (presc_q == interval);
	assign refresh_row = refresh_row_q;
	always @(posedge clk)
		if (rst) begin
			presc_q <= 7'd0;
			refresh_row_q <= 8'd0;
		end
		else if (enabled) begin
			if (presc_q == interval) begin
				presc_q <= 7'd0;
				refresh_row_q <= refresh_row_q + 8'd1;
			end
			else
				presc_q <= presc_q + 7'd1;
		end
endmodule
`default_nettype wire
`default_nettype none
module tms34010_video (
	clk,
	rst,
	ce,
	hesync,
	heblnk,
	hsblnk,
	htotal,
	vesync,
	veblnk,
	vsblnk,
	vtotal,
	dpyint,
	hcount,
	vcount,
	hsync,
	vsync,
	hblank,
	vblank,
	blank,
	dpyint_pulse
);
	input wire clk;
	input wire rst;
	input wire ce;
	input wire [15:0] hesync;
	input wire [15:0] heblnk;
	input wire [15:0] hsblnk;
	input wire [15:0] htotal;
	input wire [15:0] vesync;
	input wire [15:0] veblnk;
	input wire [15:0] vsblnk;
	input wire [15:0] vtotal;
	input wire [15:0] dpyint;
	output reg [15:0] hcount;
	output reg [15:0] vcount;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire blank;
	output wire dpyint_pulse;
	wire hwrap;
	assign hwrap = hcount == htotal;
	wire ce_eff;
	assign ce_eff = (ce === 1'b0 ? 1'b0 : 1'b1);
	always @(posedge clk)
		if (rst) begin
			hcount <= 16'd0;
			vcount <= 16'd0;
		end
		else if (ce_eff) begin
			if (hwrap) begin
				hcount <= 16'd0;
				if (vcount == vtotal)
					vcount <= 16'd0;
				else
					vcount <= vcount + 16'd1;
			end
			else
				hcount <= hcount + 16'd1;
		end
	assign hsync = hcount < hesync;
	assign vsync = vcount < vesync;
	assign hblank = (hcount < heblnk) || (hcount >= hsblnk);
	assign vblank = (vcount < veblnk) || (vcount >= vsblnk);
	assign blank = hblank || vblank;
	assign dpyint_pulse = (ce_eff && (hcount == 16'd0)) && (vcount == dpyint);
endmodule
`default_nettype wire
`default_nettype none
module narc_fb_beat_fifo (
	clk,
	rst,
	in_we,
	in_addr,
	in_data,
	in_allow,
	in_ack,
	in_flush,
	out_we,
	out_addr,
	out_data,
	out_ack,
	out_flush,
	out_busy,
	pending,
	busy
);
	parameter integer DEPTH = 16384;
	input wire clk;
	input wire rst;
	input wire in_we;
	input wire [17:0] in_addr;
	input wire [15:0] in_data;
	input wire in_allow;
	output wire in_ack;
	input wire in_flush;
	output wire out_we;
	output wire [17:0] out_addr;
	output wire [15:0] out_data;
	input wire out_ack;
	output wire out_flush;
	input wire out_busy;
	output wire pending;
	output wire busy;
	localparam integer AW = $clog2(DEPTH);
	localparam [1:0] O_IDLE = 2'd0;
	localparam [1:0] O_LOAD = 2'd1;
	localparam [1:0] O_SEND = 2'd2;
	(* ramstyle = "M10K" *) reg [83:0] qmem [0:DEPTH - 1];
	reg [AW:0] wptr;
	reg [AW:0] rptr;
	wire q_empty = wptr == rptr;
	wire q_full = (wptr[AW] != rptr[AW]) && (wptr[AW - 1:0] == rptr[AW - 1:0]);
	reg acc_valid;
	reg [15:0] acc_beat;
	reg [3:0] acc_mask;
	reg [63:0] acc_data;
	reg flush_pending;
	reg acc_flush_pending;
	wire [15:0] in_beat = in_addr[17:2];
	wire [1:0] in_lane = in_addr[1:0];
	wire in_same = acc_valid && (acc_beat == in_beat);
	wire in_take = (in_we && in_allow) && ((!acc_valid || in_same) || !q_full);
	wire push_old = (in_take && acc_valid) && !in_same;
	wire push_flush = (acc_valid && !q_full) && ((!in_we && (in_flush || acc_flush_pending)) || !in_allow);
	assign in_ack = in_take;
	reg [1:0] ost;
	reg [15:0] send_beat;
	reg [3:0] send_mask;
	reg [63:0] send_data;
	wire [1:0] send_lane = (send_mask[0] ? 2'd0 : (send_mask[1] ? 2'd1 : (send_mask[2] ? 2'd2 : 2'd3)));
	wire send_last = send_mask == (4'b0001 << send_lane);
	assign out_we = (ost == O_SEND) && (send_mask != 4'd0);
	assign out_addr = {send_beat, send_lane};
	assign out_data = send_data[{send_lane, 4'b0000}+:16];
	wire local_empty = (q_empty && !acc_valid) && (ost == O_IDLE);
	assign out_flush = flush_pending && local_empty;
	assign pending = !local_empty || flush_pending;
	assign busy = pending || out_busy;
	always @(posedge clk)
		if (rst) begin
			wptr <= 1'sb0;
			rptr <= 1'sb0;
			acc_valid <= 1'b0;
			acc_beat <= 16'd0;
			acc_mask <= 4'd0;
			acc_data <= 64'd0;
			acc_flush_pending <= 1'b0;
			ost <= O_IDLE;
			send_beat <= 16'd0;
			send_mask <= 4'd0;
			send_data <= 64'd0;
			flush_pending <= 1'b0;
		end
		else begin
			if (in_flush)
				flush_pending <= 1'b1;
			if (out_flush && !out_busy)
				flush_pending <= 1'b0;
			if ((in_flush && acc_valid) && q_full)
				acc_flush_pending <= 1'b1;
			if (push_flush)
				acc_flush_pending <= 1'b0;
			if (push_old || push_flush) begin
				qmem[wptr[AW - 1:0]] <= {acc_beat, acc_mask, acc_data};
				wptr <= wptr + 1'b1;
			end
			if (in_take) begin
				if (!acc_valid || !in_same) begin
					acc_valid <= 1'b1;
					acc_beat <= in_beat;
					acc_mask <= 4'b0001 << in_lane;
					acc_data <= {48'd0, in_data} << {in_lane, 4'b0000};
				end
				else begin
					acc_mask[in_lane] <= 1'b1;
					acc_data[{in_lane, 4'b0000}+:16] <= in_data;
				end
			end
			else if (push_flush) begin
				acc_valid <= 1'b0;
				acc_mask <= 4'd0;
			end
			case (ost)
				O_IDLE:
					if (!q_empty)
						ost <= O_LOAD;
				O_LOAD: begin
					{send_beat, send_mask, send_data} <= qmem[rptr[AW - 1:0]];
					ost <= O_SEND;
				end
				O_SEND:
					if (out_we && out_ack) begin
						if (send_last) begin
							send_mask <= 4'd0;
							rptr <= rptr + 1'b1;
							ost <= O_IDLE;
						end
						else
							send_mask[send_lane] <= 1'b0;
					end
				default: ost <= O_IDLE;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_mem (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	dma_palette,
	inputs,
	snd_select,
	snd_trig,
	snd_reset,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	gfx_rd,
	gfx_raddr,
	gfx_rdata,
	gfx_rack,
	fb_ack,
	fb_busy,
	fb_flush,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	reg _sv2v_0;
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] RAM_WORDS = 32'h00010000;
	parameter signed [31:0] VRAM_WORDS = 32'h00040000;
	parameter signed [31:0] PAL_WORDS = 32'h00002000;
	parameter signed [31:0] CMOS_WORDS = 32'h00008000;
	parameter signed [31:0] GFX_PIXELS = 32'h00180000;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter GFX_HEX = "build/smashtv_gfx.hex";
	parameter signed [31:0] ROM_PROG_OFF = 32'h00060000;
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output reg [31:0] mem_rdata;
	output reg mem_ack;
	input wire fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	input wire [15:0] dma_palette;
	input wire [63:0] inputs;
	output reg [7:0] snd_select;
	output reg snd_trig;
	output reg snd_reset;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	output reg gfx_rd;
	output wire [23:0] gfx_raddr;
	input wire [15:0] gfx_rdata;
	input wire gfx_rack;
	output wire fb_ack;
	output wire fb_busy;
	input wire fb_flush;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output reg palv_we_a;
	output reg [12:0] palv_aa;
	output reg [15:0] palv_awd;
	output reg palv_we_b;
	output reg [12:0] palv_ba;
	output reg [15:0] palv_bwd;
	localparam [3:0] R_NONE = 4'd0;
	localparam [3:0] R_VRAM = 4'd1;
	localparam [3:0] R_RAM = 4'd2;
	localparam [3:0] R_CMOS = 4'd3;
	localparam [3:0] R_PAL = 4'd4;
	localparam [3:0] R_DMA = 4'd5;
	localparam [3:0] R_INPUT = 4'd6;
	localparam [3:0] R_PROT = 4'd7;
	localparam [3:0] R_SOUND = 4'd8;
	localparam [3:0] R_CTRL = 4'd9;
	localparam [3:0] R_GFX = 4'd10;
	localparam [3:0] R_ROM = 4'd11;
	localparam [31:0] yunit_pkg_YMAP_RAM_BASE = 32'h01000000;
	function automatic [27:0] sv2v_cast_28;
		input reg [27:0] inp;
		sv2v_cast_28 = inp;
	endfunction
	localparam [27:0] WB_RAM = sv2v_cast_28(yunit_pkg_YMAP_RAM_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_MAINDATA_BASE = 32'hff800000;
	localparam [27:0] WB_ROM = sv2v_cast_28(yunit_pkg_YMAP_MAINDATA_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_VRAM_BASE = 32'h00000000;
	localparam [27:0] WB_VRAM = sv2v_cast_28(yunit_pkg_YMAP_VRAM_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_PAL_BASE = 32'h01800000;
	localparam [27:0] WB_PAL = sv2v_cast_28(yunit_pkg_YMAP_PAL_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_CMOS_BASE = 32'h01400000;
	localparam [27:0] WB_CMOS = sv2v_cast_28(yunit_pkg_YMAP_CMOS_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_INPUT_BASE = 32'h01c00000;
	localparam [27:0] WB_INPUT = sv2v_cast_28(yunit_pkg_YMAP_INPUT_BASE >> 4);
	localparam [31:0] yunit_pkg_YMAP_GFX_BASE = 32'h02000000;
	localparam [27:0] WB_GFX = sv2v_cast_28(yunit_pkg_YMAP_GFX_BASE >> 4);
	function automatic signed [27:0] sv2v_cast_28_signed;
		input reg signed [27:0] inp;
		sv2v_cast_28_signed = inp;
	endfunction
	localparam [27:0] ROM_PROG_OFF_W = sv2v_cast_28_signed(ROM_PROG_OFF);
	(* ramstyle = "no_rw_check" *) reg [15:0] ram [0:RAM_WORDS - 1];
	(* ramstyle = "no_rw_check" *) reg [15:0] pal [0:PAL_WORDS - 1];
	reg videobank = 1'b0;
	reg [1:0] cmos_page = 2'd0;
	reg autoerase = 1'b0;
	reg er_run = 1'b0;
	wire [8:0] er_row;
	wire [8:0] er_x;
	wire [9:0] er_left;
	(* ramstyle = "no_rw_check" *) reg [15:0] nvram [0:CMOS_WORDS - 1];
	localparam [3:0] M_IDLE = 4'd0;
	localparam [3:0] M_ACK = 4'd1;
	localparam [3:0] M_GFX = 4'd2;
	localparam [3:0] M_HR1 = 4'd3;
	localparam [3:0] M_HR2 = 4'd4;
	localparam [3:0] M_HFIN = 4'd5;
	localparam [3:0] M_HW2 = 4'd6;
	localparam [3:0] M_VRD = 4'd7;
	localparam [3:0] M_VWR0 = 4'd8;
	localparam [3:0] M_VWR1 = 4'd9;
	localparam [3:0] M_VWW0 = 4'd10;
	localparam [3:0] M_VWW1 = 4'd11;
	localparam [3:0] M_VSD = 4'd12;
	localparam [3:0] M_HFIN2 = 4'd13;
	localparam [3:0] M_RDLY = 4'd14;
	localparam [3:0] M_SBH = 4'd15;
	localparam [4:0] M_EXD = 5'd16;
	reg [4:0] state;
	function automatic signed [23:0] sv2v_cast_24_signed;
		input reg signed [23:0] inp;
		sv2v_cast_24_signed = inp;
	endfunction
	localparam [23:0] SDRAM_ROMB = sv2v_cast_24_signed(GFX_PIXELS);
	reg [23:0] gfx_base;
	reg [1:0] gfx_cnt;
	reg [1:0] gfx_need;
	reg gfx_isrom;
	reg [15:0] gw0;
	reg [15:0] gw1;
	reg [23:0] gfx_raddr_q;
	reg [3:0] boff_r;
	reg [47:0] rmask_r;
	localparam signed [31:0] SB_N = 8;
	reg [15:0] sb_q [0:7];
	reg [22:0] sb_base;
	reg [3:0] sb_fill;
	reg sb_vld;
	reg pf_run;
	reg pf_busy;
	reg [31:0] a_q;
	reg we_q;
	reg [31:0] wd_q;
	reg [5:0] sz_q;
	wire [27:0] widx = a_q[31:4];
	wire [3:0] boff = a_q[3:0];
	wire [5:0] sz = sz_q;
	reg [3:0] region;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		casez (a_q[31:20])
			12'h000, 12'h001: region = R_VRAM;
			12'h010: region = R_RAM;
			12'h014: region = R_CMOS;
			12'h018: region = R_PAL;
			12'h01a: region = R_DMA;
			12'h01c: region = (a_q[7:4] >= 4'd6 ? R_PROT : R_INPUT);
			12'h01e: region = R_SOUND;
			12'h01f: region = R_CTRL;
			12'h020, 12'h021, 12'h022, 12'h023, 12'h024, 12'h025, 12'h026, 12'h027, 12'h028, 12'h029, 12'h02a, 12'h02b, 12'h02c, 12'h02d, 12'h02e, 12'h02f, 12'h030, 12'h031, 12'h032, 12'h033, 12'h034, 12'h035, 12'h036, 12'h037, 12'h038, 12'h039, 12'h03a, 12'h03b, 12'h03c, 12'h03d, 12'h03e, 12'h03f, 12'h040, 12'h041, 12'h042, 12'h043, 12'h044, 12'h045, 12'h046, 12'h047, 12'h048, 12'h049, 12'h04a, 12'h04b, 12'h04c, 12'h04d, 12'h04e, 12'h04f, 12'h050, 12'h051, 12'h052, 12'h053, 12'h054, 12'h055, 12'h056, 12'h057, 12'h058, 12'h059, 12'h05a, 12'h05b, 12'h05c, 12'h05d, 12'h05e, 12'h05f: region = R_GFX;
			12'hff8, 12'hff9, 12'hffa, 12'hffb, 12'hffc, 12'hffd, 12'hffe, 12'hfff: region = R_ROM;
			default: region = R_NONE;
		endcase
	end
	wire is_hwvram = region == R_VRAM;
	localparam [27:0] ROMW = ROM_WORDS[27:0];
	localparam [27:0] RAMW = RAM_WORDS[27:0];
	localparam [27:0] VRAMW = VRAM_WORDS[27:0];
	localparam [27:0] PALW = PAL_WORDS[27:0];
	localparam [27:0] CMOSW = CMOS_WORDS[27:0];
	localparam [27:0] GFXPIXW = GFX_PIXELS[27:0];
	function automatic [15:0] read_word;
		input reg [3:0] rgn;
		input reg [27:0] gw;
		reg [27:0] rel;
		begin
			read_word = 16'h0000;
			if (rgn == R_ROM)
				;
			else if (rgn == R_RAM)
				;
			else if (rgn == R_VRAM)
				;
			else if (rgn == R_PAL)
				;
			else if (rgn == R_CMOS)
				;
			else if (rgn == R_INPUT) begin
				rel = gw - WB_INPUT;
				case (rel[1:0])
					2'd0: read_word = inputs[15:0];
					2'd1: read_word = inputs[31:16];
					2'd2: read_word = inputs[47:32];
					2'd3: read_word = inputs[63:48];
					default: read_word = 16'hffff;
				endcase
				if (rel > 28'd3)
					read_word = 16'hffff;
			end
			else if (rgn == R_GFX)
				rel = gw - WB_GFX;
		end
	endfunction
	wire [47:0] rmask = (48'd1 << sz) - 48'd1;
	wire [47:0] smask = rmask << boff;
	wire [5:0] lastb = (boff + sz) - 6'd1;
	assign gfx_raddr = gfx_raddr_q;
	always @(posedge clk) begin
		boff_r <= boff;
		rmask_r <= rmask;
	end
	reg ext_fetch;
	reg ext_isrom;
	reg [23:0] ext_base;
	reg [27:0] rom_rel;
	function automatic [23:0] sv2v_cast_24;
		input reg [23:0] inp;
		sv2v_cast_24 = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		ext_fetch = 1'b0;
		ext_isrom = 1'b0;
		ext_base = 24'd0;
		rom_rel = widx - WB_ROM;
		if ((region == R_GFX) && !we_q) begin
			ext_fetch = 1'b1;
			ext_base = sv2v_cast_24((widx - WB_GFX) << 1);
		end
		if ((((region == R_ROM) && !we_q) && (rom_rel >= ROM_PROG_OFF_W)) && ((rom_rel - ROM_PROG_OFF_W) < ROMW)) begin
			ext_fetch = 1'b1;
			ext_isrom = 1'b1;
			ext_base = SDRAM_ROMB + sv2v_cast_24((rom_rel - ROM_PROG_OFF_W) << 1);
		end
	end
	wire [1:0] extnw = 2'd1 + lastb[5:4];
	wire [22:0] ext_waddr = ext_base[23:1];
	reg [23:0] exd_base;
	reg [22:0] exd_waddr;
	reg exd_isrom;
	reg [1:0] exd_need;
	wire [22:0] exd_off = exd_waddr - sb_base;
	wire exd_hit = ((sb_vld && exd_isrom) && (exd_off < 23'd8)) && (({1'b0, exd_off[2:0]} + {2'b00, exd_need}) <= sb_fill);
	wire [15:0] exd_w0 = sb_q[exd_off[2:0]];
	wire [15:0] exd_w1 = sb_q[exd_off[2:0] + 3'd1];
	wire [15:0] exd_w2 = sb_q[exd_off[2:0] + 3'd2];
	function automatic [22:0] sv2v_cast_23;
		input reg [22:0] inp;
		sv2v_cast_23 = inp;
	endfunction
	localparam [22:0] SB_ROM_WEND = sv2v_cast_23((SDRAM_ROMB >> 1) + ROM_WORDS);
	wire pf_inrange = (sb_base + {19'd0, sb_fill}) < SB_ROM_WEND;
	reg is_hwram;
	reg [1:0] hsel;
	reg [17:0] hidx [0:2];
	reg hval [0:2];
	reg [27:0] hr;
	always @(*) begin
		if (_sv2v_0)
			;
		is_hwram = 1'b0;
		hsel = 2'd0;
		hr = 28'd0;
		begin : sv2v_autoblock_1
			reg signed [31:0] j;
			for (j = 0; j < 3; j = j + 1)
				begin
					hidx[j] = 18'd0;
					hval[j] = 1'b0;
				end
		end
		if (region == R_RAM) begin
			is_hwram = 1'b1;
			hsel = 2'd0;
			begin : sv2v_autoblock_2
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_RAM;
						hidx[j] = hr[17:0];
						hval[j] = hr < RAMW;
					end
			end
		end
		else if (region == R_PAL) begin
			is_hwram = 1'b1;
			hsel = 2'd1;
			begin : sv2v_autoblock_3
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_PAL;
						hidx[j] = hr[17:0];
						hval[j] = hr < PALW;
					end
			end
		end
		else if (region == R_CMOS) begin
			is_hwram = 1'b1;
			hsel = 2'd2;
			begin : sv2v_autoblock_4
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_CMOS;
						hidx[j] = {4'd0, cmos_page, hr[11:0]};
						hval[j] = hr < CMOSW;
					end
			end
		end
	end
	reg [15:0] rd0;
	reg [15:0] rd1;
	reg [15:0] rd2;
	wire [47:0] hwin = {(hval[2] ? rd2 : 16'h0000), (hval[1] ? rd1 : 16'h0000), (hval[0] ? rd0 : 16'h0000)};
	wire [47:0] hmerged = (hwin & ~smask) | (({16'h0000, wd_q} << boff) & smask);
	reg [47:0] smask_q;
	reg [47:0] rmask_q;
	reg [47:0] wsh_q;
	reg [47:0] hwin_q;
	reg [3:0] boff_q;
	always @(posedge clk) begin
		smask_q <= smask;
		rmask_q <= rmask;
		boff_q <= boff;
		wsh_q <= {16'h0000, wd_q} << boff;
		hwin_q <= hwin;
	end
	wire [47:0] hmerged2 = (hwin_q & ~smask_q) | (wsh_q & smask_q);
	reg [17:0] eng_aa;
	reg [17:0] eng_ba;
	reg eng_awe;
	reg eng_bwe;
	reg [15:0] eng_awd;
	reg [15:0] eng_bwd;
	reg [15:0] eng_aq;
	reg [15:0] eng_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		eng_aa = hidx[0];
		eng_ba = hidx[1];
		eng_awe = 1'b0;
		eng_bwe = 1'b0;
		eng_awd = hmerged2[15:0];
		eng_bwd = hmerged2[31:16];
		case (state)
			M_HR1: eng_aa = hidx[2];
			M_HFIN2:
				if (we_q) begin
					eng_aa = hidx[0];
					eng_awe = hval[0];
					eng_ba = hidx[1];
					eng_bwe = (lastb >= 6'd16) & hval[1];
				end
			M_HW2: begin
				eng_aa = hidx[2];
				eng_awe = (lastb >= 6'd32) & hval[2];
				eng_awd = hmerged2[47:32];
			end
			default:
				;
		endcase
	end
	reg [16:0] ram_aa;
	reg [16:0] ram_ba;
	reg ram_awe;
	reg ram_bwe;
	reg [15:0] ram_awd;
	reg [15:0] ram_bwd;
	reg [15:0] ram_aq;
	reg [15:0] ram_bq;
	reg [12:0] pal_aa;
	reg [12:0] pal_ba;
	reg pal_awe;
	reg pal_bwe;
	reg [15:0] pal_awd;
	reg [15:0] pal_bwd;
	reg [15:0] pal_aq;
	reg [15:0] pal_bq;
	reg [14:0] nv_aa;
	reg [14:0] nv_ba;
	reg nv_awe;
	reg nv_bwe;
	reg [15:0] nv_awd;
	reg [15:0] nv_bwd;
	reg [15:0] nv_aq;
	reg [15:0] nv_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		ram_aa = eng_aa[16:0];
		ram_ba = eng_ba[16:0];
		ram_awd = eng_awd;
		ram_bwd = eng_bwd;
		pal_aa = eng_aa[12:0];
		pal_ba = eng_ba[12:0];
		pal_awd = eng_awd;
		pal_bwd = eng_bwd;
		nv_aa = eng_aa[14:0];
		nv_ba = eng_ba[14:0];
		nv_awd = eng_awd;
		nv_bwd = eng_bwd;
		ram_awe = (hsel == 2'd0) & eng_awe;
		ram_bwe = (hsel == 2'd0) & eng_bwe;
		pal_awe = (hsel == 2'd1) & eng_awe;
		pal_bwe = (hsel == 2'd1) & eng_bwe;
		nv_awe = (hsel == 2'd2) & eng_awe;
		nv_bwe = (hsel == 2'd2) & eng_bwe;
		eng_aq = (hsel == 2'd0 ? ram_aq : (hsel == 2'd1 ? pal_aq : nv_aq));
		eng_bq = (hsel == 2'd0 ? ram_bq : (hsel == 2'd1 ? pal_bq : nv_bq));
	end
	always @(posedge clk) begin
		if (ram_awe)
			ram[ram_aa] <= ram_awd;
		ram_aq <= ram[ram_aa];
	end
	always @(posedge clk) begin
		if (ram_bwe)
			ram[ram_ba] <= ram_bwd;
		ram_bq <= ram[ram_ba];
	end
	always @(posedge clk) begin
		if (pal_awe)
			pal[pal_aa] <= pal_awd;
		pal_aq <= pal[pal_aa];
	end
	always @(posedge clk) begin
		if (pal_bwe)
			pal[pal_ba] <= pal_bwd;
		pal_bq <= pal[pal_ba];
	end
	always @(posedge clk) begin
		if (nv_awe)
			nvram[nv_aa] <= nv_awd;
		nv_aq <= nvram[nv_aa];
	end
	always @(posedge clk) begin
		if (nv_bwe)
			nvram[nv_ba] <= nv_bwd;
		nv_bq <= nvram[nv_ba];
	end
	always @(posedge clk) begin
		palv_we_a <= pal_awe;
		palv_aa <= {1'b0, pal_aa[11:0]};
		palv_awd <= pal_awd;
		palv_we_b <= pal_bwe;
		palv_ba <= {1'b0, pal_ba[11:0]};
		palv_bwd <= pal_bwd;
	end
	reg vsd_req;
	wire vsd_done;
	wire [31:0] vsd_rdata;
	stv_vram_ddr_top #(
		.VRAMW(VRAM_WORDS),
		.VRAM_DDR_BASE(29'h06400000)
	) u_vram_sdram(
		.clk(clk),
		.rst(rst),
		.sdram_por(sdram_por),
		.req(vsd_req),
		.we(we_q),
		.srt(1'b0),
		.widx(widx),
		.boff(boff),
		.sz(sz_q),
		.wd(wd_q),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(vsd_rdata),
		.done(vsd_done),
		.fb_we(fb_we),
		.fb_addr(fb_addr),
		.fb_wdata(fb_wdata),
		.fb_ack(fb_ack),
		.fb_busy(fb_busy),
		.fb_flush(fb_flush),
		.erase_en(autoerase),
		.erase_busy(erase_busy),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	reg [47:0] win_s;
	reg [47:0] merged_s;
	reg [47:0] win_s_q;
	wire [27:0] wrel;
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			state <= M_IDLE;
			mem_ack <= 1'b0;
			mem_rdata <= 32'h00000000;
			snd_select <= 8'h00;
			snd_trig <= 1'b0;
			snd_reset <= 1'b1;
			er_run <= 1'b0;
			gfx_rd <= 1'b0;
			sb_vld <= 1'b0;
			sb_fill <= 4'd0;
			sb_base <= 23'd0;
			pf_run <= 1'b0;
			pf_busy <= 1'b0;
			vsd_req <= 1'b0;
		end
		else begin
			if (pf_busy && gfx_rack) begin
				pf_busy <= 1'b0;
				gfx_rd <= 1'b0;
				if ((pf_run && sb_vld) && (sb_fill < SB_N)) begin
					sb_q[sb_fill[2:0]] <= gfx_rdata;
					sb_fill <= sb_fill + 4'd1;
				end
			end
			else if (((((((((pf_run && sb_vld) && !pf_busy) && !gfx_rd) && (sb_fill < SB_N)) && pf_inrange) && (state != M_GFX)) && (state != M_SBH)) && (state != M_EXD)) && !((state == M_ACK) && ext_fetch)) begin
				gfx_raddr_q <= {sb_base + {19'd0, sb_fill}, 1'b0};
				gfx_rd <= 1'b1;
				pf_busy <= 1'b1;
			end
			(* full_case, parallel_case *)
			case (state)
				M_IDLE: begin
					mem_ack <= 1'b0;
					if (mem_req && !mem_ack) begin
						a_q <= mem_addr;
						we_q <= mem_we;
						wd_q <= mem_wdata;
						sz_q <= mem_size;
						if (mem_we) begin
							sb_vld <= 1'b0;
							pf_run <= 1'b0;
						end
						state <= M_ACK;
					end
				end
				M_ACK:
					if (ext_fetch) begin
						mem_ack <= 1'b0;
						exd_base <= ext_base;
						exd_waddr <= ext_waddr;
						exd_isrom <= ext_isrom;
						exd_need <= extnw;
						state <= M_EXD;
					end
					else if (is_hwram) begin
						mem_ack <= 1'b0;
						state <= M_HR1;
					end
					else if (is_hwvram) begin
						mem_ack <= 1'b0;
						vsd_req <= 1'b1;
						state <= M_VSD;
					end
					else begin
						win_s = {read_word(region, widx + 28'd2), read_word(region, widx + 28'd1), read_word(region, widx)};
						merged_s = (win_s & ~smask) | (({16'h0000, wd_q} << boff) & smask);
						if (we_q) begin
							(* full_case, parallel_case *)
							case (region)
								default:
									;
							endcase
							if (region == R_CTRL) begin
								videobank <= wd_q[5];
								cmos_page <= wd_q[7:6];
								autoerase <= ~wd_q[4];
							end
							if (region == R_SOUND) begin
								snd_select <= wd_q[7:0];
								snd_trig <= wd_q[9];
								snd_reset <= ~wd_q[8];
							end
							mem_rdata <= 32'h00000000;
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
						else begin
							win_s_q <= win_s;
							mem_ack <= 1'b0;
							state <= M_RDLY;
						end
					end
				M_EXD:
					if (exd_hit) begin
						win_s_q <= {exd_w2, exd_w1, exd_w0};
						state <= M_SBH;
					end
					else if (pf_busy)
						;
					else begin
						gfx_base <= exd_base;
						gfx_cnt <= 2'd0;
						gfx_need <= exd_need;
						gfx_isrom <= exd_isrom;
						if (exd_isrom) begin
							sb_vld <= 1'b0;
							sb_base <= exd_waddr;
							sb_fill <= 4'd0;
							pf_run <= 1'b0;
						end
						gfx_raddr_q <= exd_base;
						gfx_rd <= 1'b1;
						state <= M_GFX;
					end
				M_GFX:
					if (gfx_rack) begin
						gfx_rd <= 1'b0;
						if (gfx_isrom)
							sb_q[{1'b0, gfx_cnt}] <= gfx_rdata;
						if (gfx_cnt == 2'd0)
							gw0 <= gfx_rdata;
						if (gfx_cnt == 2'd1)
							gw1 <= gfx_rdata;
						if (({1'b0, gfx_cnt} + 3'd1) >= {1'b0, gfx_need}) begin
							win_s_q <= (gfx_need == 2'd1 ? {32'h00000000, gfx_rdata} : (gfx_need == 2'd2 ? {16'h0000, gfx_rdata, gw0} : {gfx_rdata, gw1, gw0}));
							if (gfx_isrom) begin
								sb_fill <= {2'b00, gfx_cnt} + 4'd1;
								sb_vld <= 1'b1;
								pf_run <= 1'b1;
							end
							state <= M_SBH;
						end
						else
							gfx_cnt <= gfx_cnt + 2'd1;
					end
					else if (!gfx_rd) begin
						gfx_raddr_q <= gfx_base + {21'd0, gfx_cnt, 1'b0};
						gfx_rd <= 1'b1;
					end
				M_SBH: begin
					mem_rdata <= sv2v_cast_32((win_s_q >> boff_r) & rmask_r);
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_HR1: begin
					rd0 <= eng_aq;
					rd1 <= eng_bq;
					state <= M_HR2;
				end
				M_HR2: begin
					rd2 <= eng_aq;
					state <= M_HFIN;
				end
				M_HFIN: state <= M_HFIN2;
				M_HFIN2:
					if (we_q) begin
						if ((lastb >= 6'd32) && hval[2])
							state <= M_HW2;
						else begin
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
					end
					else begin
						mem_rdata <= sv2v_cast_32((hwin_q >> boff_q) & rmask_q);
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				M_HW2: begin
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_RDLY: begin
					mem_rdata <= sv2v_cast_32((win_s_q >> boff_q) & rmask_q);
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_VSD: begin
					vsd_req <= 1'b0;
					if (vsd_done) begin
						mem_rdata <= vsd_rdata;
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				end
				default: begin
					state <= M_IDLE;
					mem_ack <= 1'b0;
				end
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_dma (
	clk,
	rst,
	reg_we,
	reg_addr,
	reg_wdata,
	reg_rdata,
	src_req,
	src_addr,
	src_data,
	src_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	fb_busy,
	fb_flush,
	busy,
	blit_irq,
	dma_palette
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire reg_we;
	input wire [3:0] reg_addr;
	input wire [15:0] reg_wdata;
	output wire [15:0] reg_rdata;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	output reg fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output reg [17:0] fb_addr;
	output reg [15:0] fb_wdata;
	input wire fb_ack;
	input wire fb_busy;
	output wire fb_flush;
	output wire busy;
	output reg blit_irq;
	output wire [15:0] dma_palette;
	localparam signed [31:0] yunit_pkg_DMA_NREGS = 16;
	reg [15:0] regf [0:15];
	reg busy_r;
	reg abort_r;
	reg pend_trig;
	reg [25:0] pace_cnt;
	reg pace_arm;
	localparam [3:0] yunit_pkg_DMA_COMMAND = 4'd0;
	wire [15:0] cmd_reg = regf[yunit_pkg_DMA_COMMAND];
	localparam signed [31:0] yunit_pkg_DMA_CMD_FLIPX_BIT = 4;
	wire flipx_w = cmd_reg[yunit_pkg_DMA_CMD_FLIPX_BIT];
	wire [3:0] mode_w = cmd_reg[3:0];
	localparam [3:0] yunit_pkg_DMA_PALETTE = 4'd8;
	wire [7:0] pal_lo = regf[yunit_pkg_DMA_PALETTE][7:0];
	localparam [3:0] yunit_pkg_DMA_COLOR = 4'd9;
	wire [7:0] col_lo = regf[yunit_pkg_DMA_COLOR][7:0];
	localparam signed [31:0] yunit_pkg_DMA_CMD_TRIG_BIT = 15;
	wire wdata_trig = reg_wdata[yunit_pkg_DMA_CMD_TRIG_BIT];
	assign busy = busy_r;
	assign dma_palette = regf[yunit_pkg_DMA_PALETTE];
	assign reg_rdata = (reg_addr == yunit_pkg_DMA_COMMAND ? {busy_r, cmd_reg[14:0]} : regf[reg_addr]);
	reg [2:0] state;
	reg [2:0] state_n;
	reg [3:0] mode_c;
	reg flipx_c;
	reg readmode_c;
	reg signed [11:0] width_c;
	reg signed [11:0] height_c;
	reg signed [11:0] xpos_c;
	reg signed [11:0] ypos_c;
	reg signed [31:0] rowbytes_c;
	reg [15:0] pal16_c;
	reg [15:0] color16_c;
	reg signed [11:0] row_i;
	reg signed [11:0] col_i;
	reg signed [11:0] tx;
	reg [8:0] ty;
	reg signed [31:0] cur_off;
	reg signed [31:0] o_ptr;
	reg [7:0] px;
	reg signed [31:0] rb_in;
	reg signed [31:0] xs_in;
	reg signed [31:0] ys_in;
	reg [15:0] w_in;
	reg [15:0] h_in;
	reg [31:0] gfxoff0;
	reg [31:0] gfxoff1;
	reg [31:0] gfxoff2;
	reg signed [31:0] rb_adj;
	reg signed [31:0] xpos0;
	reg signed [31:0] ypos1;
	reg signed [31:0] height1a;
	reg signed [31:0] height1;
	reg signed [31:0] xpos_f;
	reg signed [31:0] width_f;
	reg signed [31:0] offbytes_c;
	localparam [3:0] yunit_pkg_DMA_HEIGHT = 4'd7;
	localparam [3:0] yunit_pkg_DMA_OFFSETHI = 4'd3;
	localparam [3:0] yunit_pkg_DMA_OFFSETLO = 4'd2;
	localparam [3:0] yunit_pkg_DMA_ROWBYTES = 4'd1;
	localparam [3:0] yunit_pkg_DMA_WIDTH = 4'd6;
	localparam [3:0] yunit_pkg_DMA_XSTART = 4'd4;
	localparam [3:0] yunit_pkg_DMA_YSTART = 4'd5;
	always @(*) begin
		if (_sv2v_0)
			;
		rb_in = $signed(regf[yunit_pkg_DMA_ROWBYTES]);
		xs_in = $signed(regf[yunit_pkg_DMA_XSTART]);
		ys_in = $signed(regf[yunit_pkg_DMA_YSTART]);
		w_in = regf[yunit_pkg_DMA_WIDTH];
		h_in = regf[yunit_pkg_DMA_HEIGHT];
		gfxoff0 = {regf[yunit_pkg_DMA_OFFSETHI], regf[yunit_pkg_DMA_OFFSETLO]};
		rb_adj = (flipx_w ? ((rb_in - $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3 : ((rb_in + $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3);
		xpos0 = (flipx_w ? (xs_in + $signed({16'd0, w_in})) - 32'sd1 : xs_in);
		gfxoff1 = (flipx_w ? gfxoff0 - (({16'd0, w_in} - 32'd1) << 3) : gfxoff0);
		ypos1 = (ys_in < 0 ? 32'sd0 : ys_in);
		height1a = (ys_in < 0 ? $signed({16'd0, h_in}) + ys_in : $signed({16'd0, h_in}));
		height1 = ((ypos1 + height1a) > 32'sd512 ? 32'sd512 - ypos1 : height1a);
		if (!flipx_w) begin
			if (xpos0 < 0) begin
				width_f = $signed({16'd0, w_in}) + xpos0;
				xpos_f = 32'sd0;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f + width_f) > 32'sd512)
				width_f = 32'sd512 - xpos_f;
		end
		else begin
			if (xpos0 >= 32'sd512) begin
				width_f = $signed({16'd0, w_in}) - (xpos0 - 32'sd511);
				xpos_f = 32'sd511;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f - width_f) < 0)
				width_f = xpos_f;
		end
		gfxoff2 = (gfxoff1 < 32'h02000000 ? gfxoff1 + 32'h02000000 : gfxoff1);
		offbytes_c = ($signed(gfxoff2) - 32'sh02000000) >>> 3;
	end
	wire [11:0] width12 = width_f[11:0];
	wire [11:0] height12 = height1[11:0];
	wire [11:0] xpos12 = xpos_f[11:0];
	wire [11:0] ypos12 = ypos1[11:0];
	wire readmode_w = (mode_w >= 4'h1) && (mode_w <= 4'hb);
	reg pix_we;
	reg [15:0] pix_data;
	always @(*) begin
		if (_sv2v_0)
			;
		pix_we = 1'b0;
		pix_data = 16'h0000;
		(* full_case, parallel_case *)
		case (mode_c)
			4'h0:
				;
			4'h1: begin
				pix_we = px == 8'd0;
				pix_data = pal16_c;
			end
			4'h2: begin
				pix_we = px != 8'd0;
				pix_data = pal16_c | {8'd0, px};
			end
			4'h3: begin
				pix_we = 1'b1;
				pix_data = pal16_c | {8'd0, px};
			end
			4'h4, 4'h5: begin
				pix_we = px == 8'd0;
				pix_data = color16_c;
			end
			4'h6, 4'h7: begin
				pix_we = 1'b1;
				pix_data = (px == 8'd0 ? color16_c : pal16_c | {8'd0, px});
			end
			4'h8, 4'ha: begin
				pix_we = px != 8'd0;
				pix_data = color16_c;
			end
			4'h9, 4'hb: begin
				pix_we = 1'b1;
				pix_data = (px != 8'd0 ? color16_c : pal16_c | {8'd0, px});
			end
			default: begin
				pix_we = 1'b1;
				pix_data = color16_c;
			end
		endcase
	end
	wire row_overrun = ($unsigned(cur_off) >= 32'h06000000) && (mode_c < 4'hc);
	wire [8:0] tx9 = tx[8:0];
	wire [8:0] ty_next = ypos_c[8:0] + row_i[8:0];
	wire dma_done_ok = (pace_cnt == 26'd0) && !fb_busy;
	always @(*) begin
		if (_sv2v_0)
			;
		state_n = state;
		(* full_case, parallel_case *)
		case (state)
			3'd0:
				if ((reg_we && (reg_addr == yunit_pkg_DMA_COMMAND)) && wdata_trig)
					state_n = 3'd1;
				else if (pend_trig)
					state_n = 3'd1;
			3'd1: state_n = 3'd2;
			3'd2:
				if ((height1 <= 0) || (width_f <= 0))
					state_n = 3'd6;
				else
					state_n = 3'd3;
			3'd3:
				if (row_i >= height_c)
					state_n = 3'd6;
				else if (row_overrun)
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd4:
				if (!readmode_c)
					state_n = 3'd5;
				else if (src_ack)
					state_n = 3'd5;
			3'd5:
				if (pix_we && !fb_ack)
					state_n = 3'd5;
				else if (col_i >= (width_c - 12'sd1))
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd6:
				if (dma_done_ok)
					state_n = 3'd0;
			default: state_n = 3'd0;
		endcase
	end
	assign src_req = (state == 3'd4) && readmode_c;
	assign src_addr = o_ptr[23:0];
	assign fb_flush = state == 3'd6;
	integer i;
	always @(posedge clk)
		if (rst) begin
			state <= 3'd0;
			fb_we <= 1'b0;
			blit_irq <= 1'b0;
			busy_r <= 1'b0;
			pace_cnt <= 26'd0;
			pace_arm <= 1'b0;
			abort_r <= 1'b0;
			pend_trig <= 1'b0;
			for (i = 0; i < yunit_pkg_DMA_NREGS; i = i + 1)
				regf[i] <= 16'h0000;
		end
		else begin
			state <= state_n;
			fb_we <= 1'b0;
			if (reg_we) begin
				regf[reg_addr] <= reg_wdata;
				if (reg_addr == yunit_pkg_DMA_COMMAND) begin
					blit_irq <= 1'b0;
					if (state == 3'd0)
						busy_r <= wdata_trig;
					else if (!wdata_trig) begin
						busy_r <= 1'b0;
						if (state_n != 3'd0)
							abort_r <= 1'b1;
					end
					else if (abort_r || pend_trig) begin
						pend_trig <= 1'b1;
						busy_r <= 1'b1;
					end
				end
			end
			if (abort_r && (state_n == 3'd0))
				abort_r <= 1'b0;
			if ((state == 3'd0) && pend_trig)
				pend_trig <= 1'b0;
			pace_arm <= state == 3'd2;
			if (pace_arm)
				pace_cnt <= ({14'd0, width_c[11:0]} * {14'd0, height_c[11:0]}) << 2;
			else if (pace_cnt != 26'd0)
				pace_cnt <= pace_cnt - 26'd1;
			(* full_case, parallel_case *)
			case (state)
				3'd2: begin
					mode_c <= mode_w;
					flipx_c <= flipx_w;
					readmode_c <= readmode_w;
					width_c <= (width_f <= 32'sd0 ? 12'sd0 : $signed(width12));
					height_c <= (height1 <= 32'sd0 ? 12'sd0 : $signed(height12));
					xpos_c <= $signed(xpos12);
					ypos_c <= $signed(ypos12);
					rowbytes_c <= rb_adj;
					pal16_c <= {pal_lo, 8'h00};
					color16_c <= {pal_lo, col_lo};
					row_i <= 12'sd0;
					cur_off <= offbytes_c;
				end
				3'd3: begin
					ty <= ty_next;
					tx <= xpos_c;
					col_i <= 12'sd0;
					o_ptr <= cur_off;
					if (row_i < height_c) begin
						cur_off <= cur_off + rowbytes_c;
						row_i <= row_i + 12'sd1;
					end
				end
				3'd4:
					if (readmode_c && src_ack)
						px <= src_data;
				3'd5: begin
					if (pix_we) begin
						fb_we <= 1'b1;
						fb_addr <= {ty, tx9};
						fb_wdata <= pix_data;
					end
					if (!pix_we || fb_ack) begin
						tx <= tx + (flipx_c ? -12'sd1 : 12'sd1);
						col_i <= col_i + 12'sd1;
						if (readmode_c)
							o_ptr <= o_ptr + 32'sd1;
					end
				end
				3'd6:
					if (dma_done_ok) begin
						busy_r <= 1'b0;
						blit_irq <= 1'b1;
					end
				default:
					;
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module vram_sdram (
	clk,
	rst,
	req,
	we,
	widx,
	boff,
	sz,
	wd,
	videobank,
	dma_palette,
	rdata,
	done,
	active,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack
);
	reg _sv2v_0;
	parameter signed [31:0] VRAMW = 32'h00040000;
	parameter signed [31:0] SD_AW = 21;
	parameter [SD_AW - 1:0] VRAM_BASE = 1'sb0;
	parameter [0:0] BE_WRITE = 1'b0;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	input wire [27:0] widx;
	input wire [3:0] boff;
	input wire [5:0] sz;
	input wire [31:0] wd;
	input wire videobank;
	input wire [15:0] dma_palette;
	output reg [31:0] rdata;
	output reg done;
	output wire active;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	reg we_l;
	reg vb_l;
	reg [27:0] wi;
	reg [3:0] bo;
	reg [5:0] szl;
	reg [31:0] wd_l;
	reg [15:0] pal_l;
	wire [17:0] ea = (wi << 1) + {17'd0, bo[3]};
	wire vea_v = ((wi << 1) + {27'd0, bo[3]}) < VRAMW;
	function automatic [17:0] went;
		input [2:0] i;
		went = ((wi + {26'd0, i[2:1]}) << 1) + {17'd0, i[0]};
	endfunction
	function automatic wentv;
		input [2:0] i;
		wentv = (((wi + {26'd0, i[2:1]}) << 1) + {17'd0, i[0]}) < VRAMW;
	endfunction
	reg [15:0] o0;
	reg [15:0] o1;
	reg [15:0] o2;
	reg [15:0] o3;
	reg [15:0] o4;
	reg [15:0] o5;
	wire [7:0] oea = (bo[3] ? o1[7:0] : o0[7:0]);
	wire [15:0] pw0 = (vb_l ? {o1[7:0], o0[7:0]} : {o1[15:8], o0[15:8]});
	wire [15:0] pw1 = (vb_l ? {o3[7:0], o2[7:0]} : {o3[15:8], o2[15:8]});
	wire [15:0] pw2 = (vb_l ? {o5[7:0], o4[7:0]} : {o5[15:8], o4[15:8]});
	wire [47:0] win48 = {pw2, pw1, pw0};
	wire [47:0] rmask = (48'd1 << szl) - 48'd1;
	wire [47:0] merged48 = (win48 & ~(rmask << bo)) | (({16'h0000, wd_l} & rmask) << bo);
	function automatic [15:0] nent;
		input [2:0] i;
		reg [7:0] nb;
		reg [7:0] ob;
		begin
			nb = merged48[{2'd0, i} * 8+:8];
			case (i)
				3'd0: ob = o0[7:0];
				3'd1: ob = o1[7:0];
				3'd2: ob = o2[7:0];
				3'd3: ob = o3[7:0];
				3'd4: ob = o4[7:0];
				default: ob = o5[7:0];
			endcase
			if (vb_l)
				nent = {(i[0] ? pal_l[15:8] : pal_l[7:0]), nb};
			else
				nent = {nb, ob};
		end
	endfunction
	wire [15:0] vnewea = (vb_l ? {(bo[3] ? pal_l[15:8] : pal_l[7:0]), wd_l[7:0]} : {wd_l[7:0], oea});
	wire [5:0] lastbit = ({2'd0, bo} + szl) - 6'd1;
	wire [2:0] nwords = 3'd1 + {1'b0, lastbit[5:4]};
	wire [2:0] nents = {nwords[1:0], 1'b0};
	wire is8 = we_l & (szl <= 6'd8);
	wire [2:0] nread = (is8 ? 3'd1 : nents);
	wire [2:0] nwrite = (we_l ? (is8 ? 3'd1 : nents) : 3'd0);
	function automatic [17:0] raddr;
		input [2:0] i;
		if (is8)
			raddr = ea;
		else
			raddr = went(i);
	endfunction
	function automatic rvalid;
		input [2:0] i;
		if (is8)
			rvalid = vea_v;
		else
			rvalid = wentv(i);
	endfunction
	function automatic [17:0] waddr;
		input [2:0] i;
		if (is8)
			waddr = ea;
		else
			waddr = went(i);
	endfunction
	function automatic [15:0] wdata;
		input [2:0] i;
		if (is8)
			wdata = vnewea;
		else
			wdata = nent(i);
	endfunction
	function automatic wvalid;
		input [2:0] i;
		if (is8)
			wvalid = vea_v;
		else
			wvalid = wentv(i);
	endfunction
	function automatic wr_read;
		input [2:0] i;
		reg [7:0] blo;
		reg [7:0] bhi;
		reg [7:0] flo;
		reg [7:0] fhi;
		begin
			blo = {5'd0, i} << 3;
			bhi = blo + 8'd8;
			flo = {4'd0, bo};
			fhi = flo + {2'd0, szl};
			wr_read = !((flo <= blo) && (fhi >= bhi));
		end
	endfunction
	wire [1:0] be_wr = (BE_WRITE && !is8 ? (vb_l ? 2'b11 : 2'b10) : 2'b11);
	reg [1:0] st;
	reg [2:0] idx;
	assign active = st != 2'd0;
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			st <= 2'd0;
			done <= 1'b0;
			sd_rd <= 1'b0;
			sd_wr <= 1'b0;
			idx <= 3'd0;
		end
		else begin
			done <= 1'b0;
			case (st)
				2'd0: begin
					sd_rd <= 1'b0;
					sd_wr <= 1'b0;
					if (req) begin
						we_l <= we;
						wi <= widx;
						bo <= boff;
						szl <= sz;
						wd_l <= wd;
						vb_l <= videobank;
						pal_l <= dma_palette;
						idx <= 3'd0;
						st <= 2'd1;
					end
				end
				2'd1:
					if (idx >= nread) begin
						sd_rd <= 1'b0;
						if (we_l) begin
							idx <= 3'd0;
							st <= 2'd2;
						end
						else
							st <= 2'd3;
					end
					else if (!rvalid(idx) || (((BE_WRITE && we_l) && !is8) && !wr_read(idx))) begin
						case (idx)
							3'd0: o0 <= 16'h0000;
							3'd1: o1 <= 16'h0000;
							3'd2: o2 <= 16'h0000;
							3'd3: o3 <= 16'h0000;
							3'd4: o4 <= 16'h0000;
							default: o5 <= 16'h0000;
						endcase
						idx <= idx + 3'd1;
					end
					else if (sd_ack) begin
						case (idx)
							3'd0: o0 <= sd_dout;
							3'd1: o1 <= sd_dout;
							3'd2: o2 <= sd_dout;
							3'd3: o3 <= sd_dout;
							3'd4: o4 <= sd_dout;
							default: o5 <= sd_dout;
						endcase
						sd_rd <= 1'b0;
						idx <= idx + 3'd1;
					end
					else begin
						sd_addr <= VRAM_BASE + raddr(idx);
						sd_be <= 2'b00;
						sd_rd <= 1'b1;
					end
				2'd2:
					if (idx >= nwrite) begin
						sd_wr <= 1'b0;
						st <= 2'd3;
					end
					else if (!wvalid(idx))
						idx <= idx + 3'd1;
					else if (sd_ack) begin
						sd_wr <= 1'b0;
						idx <= idx + 3'd1;
					end
					else begin
						sd_addr <= VRAM_BASE + waddr(idx);
						sd_din <= wdata(idx);
						sd_be <= be_wr;
						sd_wr <= 1'b1;
					end
				2'd3: begin
					rdata <= sv2v_cast_32((win48 >> bo) & rmask);
					done <= 1'b1;
					st <= 2'd0;
				end
				default: st <= 2'd0;
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module vram_sdram_top (
	clk,
	rst,
	req,
	we,
	srt,
	widx,
	boff,
	sz,
	wd,
	videobank,
	dma_palette,
	rdata,
	done,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack
);
	reg _sv2v_0;
	parameter signed [31:0] VRAMW = 32'h00040000;
	parameter signed [31:0] SD_AW = 21;
	parameter [SD_AW - 1:0] VRAM_BASE = 1'sb0;
	parameter [0:0] BE_WRITE = 1'b0;
	parameter [0:0] HAS_ERASE = 1'b1;
	parameter [0:0] HAS_FBW = 1'b1;
	parameter [0:0] HAS_SCAN = 1'b1;
	input wire clk;
	input wire rst;
	input wire req;
	input wire we;
	input wire srt;
	input wire [27:0] widx;
	input wire [3:0] boff;
	input wire [5:0] sz;
	input wire [31:0] wd;
	input wire videobank;
	input wire [15:0] dma_palette;
	output wire [31:0] rdata;
	output wire done;
	input wire fb_we;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	output reg fb_ack;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output reg scan_ack;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	wire srt_i = srt === 1'b1;
	reg c_ack_i;
	reg f_ack_i;
	reg ae_ack_i;
	reg srt_ack_i;
	wire [SD_AW - 1:0] c_addr;
	wire [15:0] c_din;
	wire [1:0] c_be;
	wire c_rd;
	wire c_wr;
	wire c_active;
	wire [31:0] cpu_rdata;
	wire cpu_done;
	vram_sdram #(
		.VRAMW(VRAMW),
		.SD_AW(SD_AW),
		.VRAM_BASE(VRAM_BASE),
		.BE_WRITE(BE_WRITE)
	) u_cpu(
		.clk(clk),
		.rst(rst),
		.req(req && !srt_i),
		.we(we),
		.widx(widx),
		.boff(boff),
		.sz(sz),
		.wd(wd),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(cpu_rdata),
		.done(cpu_done),
		.active(c_active),
		.sd_addr(c_addr),
		.sd_din(c_din),
		.sd_be(c_be),
		.sd_rd(c_rd),
		.sd_wr(c_wr),
		.sd_dout(sd_dout),
		.sd_ack(c_ack_i)
	);
	reg [15:0] srt_buf [0:1023];
	reg [15:0] srt_q;
	reg [15:0] srt_first;
	reg [17:0] srt_base;
	reg [10:0] srt_idx;
	reg srt_done;
	reg srt_we_q;
	reg srt_armed;
	localparam [2:0] SR_IDLE = 3'd0;
	localparam [2:0] SR_RD = 3'd1;
	localparam [2:0] SR_ST_SETTLE = 3'd2;
	localparam [2:0] SR_WR = 3'd3;
	reg [2:0] srst;
	wire srt_rd_req = srst == SR_RD;
	wire srt_wr_req = srst == SR_WR;
	always @(posedge clk) begin
		srt_q <= srt_buf[srt_idx[9:0]];
		if (rst) begin
			srst <= SR_IDLE;
			srt_idx <= 11'd0;
			srt_base <= 18'd0;
			srt_done <= 1'b0;
			srt_we_q <= 1'b0;
			srt_armed <= 1'b1;
			srt_first <= 16'd0;
		end
		else begin
			srt_done <= 1'b0;
			if (!req || !srt_i)
				srt_armed <= 1'b1;
			case (srst)
				SR_IDLE:
					if ((req && srt_i) && srt_armed) begin
						srt_armed <= 1'b0;
						srt_base <= {widx[16:0], boff[3]};
						srt_idx <= 11'd0;
						srt_we_q <= we;
						srst <= (we ? SR_ST_SETTLE : SR_RD);
					end
				SR_RD:
					if (srt_ack_i) begin
						srt_buf[srt_idx[9:0]] <= sd_dout;
						if (srt_idx == 11'd0)
							srt_first <= sd_dout;
						if (srt_idx == 11'd1023) begin
							srt_done <= 1'b1;
							srst <= SR_IDLE;
						end
						else
							srt_idx <= srt_idx + 11'd1;
					end
				SR_ST_SETTLE: srst <= SR_WR;
				SR_WR:
					if (srt_ack_i) begin
						if (srt_idx == 11'd1023) begin
							srt_done <= 1'b1;
							srst <= SR_IDLE;
						end
						else begin
							srt_idx <= srt_idx + 11'd1;
							srst <= SR_ST_SETTLE;
						end
					end
				default: srst <= SR_IDLE;
			endcase
		end
	end
	assign done = cpu_done | srt_done;
	assign rdata = (srt_done ? (srt_we_q ? 32'd0 : {16'd0, srt_first}) : cpu_rdata);
	reg [17:0] f_a;
	reg [15:0] f_d;
	reg f_pending;
	reg fb_we_d;
	generate
		if (HAS_FBW) begin : g_fbw
			always @(posedge clk)
				if (rst) begin
					f_pending <= 1'b0;
					fb_ack <= 1'b0;
					fb_we_d <= 1'b0;
				end
				else begin
					fb_ack <= 1'b0;
					fb_we_d <= fb_we;
					if (!f_pending) begin
						if (fb_we & ~fb_we_d) begin
							f_a <= fb_addr;
							f_d <= fb_wdata;
							f_pending <= 1'b1;
						end
					end
					else if (f_ack_i) begin
						f_pending <= 1'b0;
						fb_ack <= 1'b1;
					end
				end
		end
		else begin : g_no_fbw
			wire [18:1] sv2v_tmp_D4601;
			assign sv2v_tmp_D4601 = 18'd0;
			always @(*) f_a = sv2v_tmp_D4601;
			wire [16:1] sv2v_tmp_96CEA;
			assign sv2v_tmp_96CEA = 16'd0;
			always @(*) f_d = sv2v_tmp_96CEA;
			wire [1:1] sv2v_tmp_142EA;
			assign sv2v_tmp_142EA = 1'b0;
			always @(*) f_pending = sv2v_tmp_142EA;
			wire [1:1] sv2v_tmp_38360;
			assign sv2v_tmp_38360 = 1'b0;
			always @(*) fb_we_d = sv2v_tmp_38360;
			wire [1:1] sv2v_tmp_76D73;
			assign sv2v_tmp_76D73 = 1'b0;
			always @(*) fb_ack = sv2v_tmp_76D73;
		end
	endgenerate
	localparam [1:0] AE_IDLE = 2'd0;
	localparam [1:0] AE_RD = 2'd1;
	localparam [1:0] AE_WR = 2'd2;
	localparam [1:0] AE_ADV = 2'd3;
	reg [1:0] ae;
	reg er_run;
	reg [8:0] er_row;
	reg [8:0] er_x;
	reg [9:0] er_left;
	reg [15:0] er_data;
	wire [17:0] ae_src = {8'hff, er_row[0], er_x};
	wire [17:0] ae_dst = {er_row, er_x};
	wire ae_skip = (er_row == 9'd510) || (er_row == 9'd511);
	wire ae_rd_req = (ae == AE_RD) & ~ae_skip;
	wire ae_wr_req = ae == AE_WR;
	assign erase_busy = er_run;
	generate
		if (HAS_ERASE) begin : g_ae
			always @(posedge clk)
				if (rst) begin
					ae <= AE_IDLE;
					er_run <= 1'b0;
				end
				else
					case (ae)
						AE_IDLE:
							if (erase_start && (erase_lines != 10'd0)) begin
								er_run <= 1'b1;
								er_row <= erase_row0 - 9'd1;
								er_x <= 9'd0;
								er_left <= erase_lines + 10'd1;
								ae <= AE_RD;
							end
						AE_RD:
							if (ae_skip)
								ae <= AE_ADV;
							else if (ae_ack_i) begin
								er_data <= sd_dout;
								ae <= AE_WR;
							end
						AE_WR:
							if (ae_ack_i)
								ae <= AE_ADV;
						AE_ADV:
							if (er_x == 9'd511) begin
								er_x <= 9'd0;
								er_row <= er_row + 9'd1;
								er_left <= er_left - 10'd1;
								if (er_left <= 10'd1) begin
									er_run <= 1'b0;
									ae <= AE_IDLE;
								end
								else
									ae <= AE_RD;
							end
							else begin
								er_x <= er_x + 9'd1;
								ae <= AE_RD;
							end
						default: ae <= AE_IDLE;
					endcase
		end
		else begin : g_no_ae
			wire [2:1] sv2v_tmp_5DFCF;
			assign sv2v_tmp_5DFCF = AE_IDLE;
			always @(*) ae = sv2v_tmp_5DFCF;
			wire [1:1] sv2v_tmp_35500;
			assign sv2v_tmp_35500 = 1'b0;
			always @(*) er_run = sv2v_tmp_35500;
			wire [9:1] sv2v_tmp_F123D;
			assign sv2v_tmp_F123D = 9'd0;
			always @(*) er_row = sv2v_tmp_F123D;
			wire [9:1] sv2v_tmp_8BD39;
			assign sv2v_tmp_8BD39 = 9'd0;
			always @(*) er_x = sv2v_tmp_8BD39;
			wire [10:1] sv2v_tmp_F30B6;
			assign sv2v_tmp_F30B6 = 10'd0;
			always @(*) er_left = sv2v_tmp_F30B6;
			wire [16:1] sv2v_tmp_7BFBB;
			assign sv2v_tmp_7BFBB = 16'd0;
			always @(*) er_data = sv2v_tmp_7BFBB;
		end
	endgenerate
	wire cpu_req = c_rd | c_wr;
	wire fb_req = HAS_FBW & f_pending;
	wire ae_req = HAS_ERASE & (ae_rd_req | ae_wr_req);
	wire srt_req_i = srt_rd_req | srt_wr_req;
	wire scan_req_i = HAS_SCAN & scan_req;
	reg [2:0] gnt;
	reg gnt_held;
	reg [2:0] gnt_r;
	reg bubble;
	always @(*) begin
		if (_sv2v_0)
			;
		if (gnt_held)
			gnt = gnt_r;
		else if (bubble)
			gnt = 3'd0;
		else if (scan_req_i)
			gnt = 3'd1;
		else if (srt_req_i)
			gnt = 3'd5;
		else if (cpu_req)
			gnt = 3'd2;
		else if (fb_req)
			gnt = 3'd3;
		else if (ae_req)
			gnt = 3'd4;
		else
			gnt = 3'd0;
	end
	always @(posedge clk)
		if (rst) begin
			gnt_held <= 1'b0;
			gnt_r <= 3'd0;
			bubble <= 1'b0;
		end
		else begin
			bubble <= 1'b0;
			if (!gnt_held) begin
				if (!bubble && (gnt != 3'd0)) begin
					gnt_held <= 1'b1;
					gnt_r <= gnt;
				end
			end
			else if (sd_ack) begin
				gnt_held <= 1'b0;
				bubble <= 1'b1;
			end
		end
	always @(*) begin
		if (_sv2v_0)
			;
		sd_addr = 1'sb0;
		sd_din = 16'h0000;
		sd_be = 2'b00;
		sd_rd = 1'b0;
		sd_wr = 1'b0;
		c_ack_i = 1'b0;
		f_ack_i = 1'b0;
		ae_ack_i = 1'b0;
		srt_ack_i = 1'b0;
		scan_ack = 1'b0;
		case (gnt)
			3'd1: begin
				sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, scan_addr};
				sd_be = 2'b00;
				sd_rd = scan_req_i;
				scan_ack = sd_ack;
			end
			3'd2: begin
				sd_addr = c_addr;
				sd_din = c_din;
				sd_be = c_be;
				sd_rd = c_rd;
				sd_wr = c_wr;
				c_ack_i = sd_ack;
			end
			3'd3: begin
				sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, f_a};
				sd_din = f_d;
				sd_be = 2'b11;
				sd_wr = f_pending;
				f_ack_i = sd_ack;
			end
			3'd4: begin
				if (ae_rd_req) begin
					sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, ae_src};
					sd_be = 2'b00;
					sd_rd = 1'b1;
				end
				else begin
					sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, ae_dst};
					sd_din = er_data;
					sd_be = 2'b11;
					sd_wr = 1'b1;
				end
				ae_ack_i = sd_ack;
			end
			3'd5: begin
				sd_addr = VRAM_BASE + {{SD_AW - 18 {1'b0}}, srt_base + srt_idx[9:0]};
				sd_be = 2'b11;
				if (srt_rd_req)
					sd_rd = 1'b1;
				else begin
					sd_din = srt_q;
					sd_wr = 1'b1;
				end
				srt_ack_i = sd_ack;
			end
			default:
				;
		endcase
	end
	assign scan_data = sd_dout;
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module vram_sdram_scanout (
	clk,
	rst,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done
);
	parameter [24:0] VRAM_WBASE = 25'h00e0000;
	input wire clk;
	input wire rst;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output reg [15:0] scan_data;
	output reg scan_ack;
	output reg brd_req;
	output reg [24:0] brd_addr;
	output reg [9:0] brd_len;
	input wire [15:0] brd_dout;
	input wire brd_dvalid;
	input wire brd_done;
	localparam integer ROWLEN = 512;
	(* ramstyle = "no_rw_check" *) reg [15:0] rc [0:ROWLEN - 1];
	reg [8:0] rc_row;
	reg rc_valid;
	wire [8:0] req_row = scan_addr[17:9];
	wire [8:0] req_col = scan_addr[8:0];
	wire [8:0] rc_raddr = req_col;
	reg [15:0] rc_q;
	always @(posedge clk) rc_q <= rc[rc_raddr];
	reg [9:0] fill_i;
	reg [1:0] ss;
	always @(posedge clk)
		if (rst) begin
			ss <= 2'd0;
			rc_valid <= 1'b0;
			rc_row <= 9'd0;
			brd_req <= 1'b0;
			brd_len <= 10'd0;
			scan_ack <= 1'b0;
			scan_data <= 16'd0;
			fill_i <= 10'd0;
		end
		else begin
			scan_ack <= 1'b0;
			case (ss)
				2'd0:
					if (scan_req) begin
						if (rc_valid && (rc_row == req_row))
							ss <= 2'd2;
						else begin
							brd_addr <= (VRAM_WBASE + {req_row, 9'd0}) << 1;
							brd_len <= ROWLEN[9:0];
							brd_req <= 1'b1;
							fill_i <= 10'd0;
							ss <= 2'd1;
						end
					end
				2'd1: begin
					if (brd_dvalid && (fill_i < ROWLEN)) begin
						rc[fill_i[8:0]] <= brd_dout;
						fill_i <= fill_i + 10'd1;
					end
					if (brd_done) begin
						brd_req <= 1'b0;
						rc_valid <= 1'b1;
						rc_row <= req_row;
						ss <= 2'd0;
					end
				end
				2'd2: begin
					scan_data <= rc_q;
					scan_ack <= 1'b1;
					ss <= 2'd3;
				end
				2'd3:
					if (!scan_req)
						ss <= 2'd0;
				default: ss <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module stv_vram_ddr_agent (
	clk,
	sdram_por,
	tst_wr_req,
	tst_rd_req,
	tst_addr,
	tst_wdata,
	tst_be,
	tst_burstcnt,
	tst_rdata,
	tst_rd_valid,
	tst_busy,
	tst_wnext,
	tst_wr_done,
	tst_wr_base,
	tst_wr_count,
	tst_wr_last_data,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready
);
	parameter [28:0] VRAM_DDR_BASE = 29'h06400000;
	input clk;
	input sdram_por;
	input tst_wr_req;
	input tst_rd_req;
	input [25:0] tst_addr;
	input [63:0] tst_wdata;
	input [7:0] tst_be;
	input [7:0] tst_burstcnt;
	output reg [63:0] tst_rdata;
	output reg tst_rd_valid;
	output reg tst_busy;
	output wire tst_wnext;
	output reg tst_wr_done;
	output reg [25:0] tst_wr_base;
	output reg [7:0] tst_wr_count;
	output reg [63:0] tst_wr_last_data;
	output reg [28:0] ddram_addr;
	output reg [7:0] ddram_burstcnt;
	output reg ddram_rd;
	output reg ddram_we;
	output wire [63:0] ddram_din;
	output reg [7:0] ddram_be;
	input ddram_busy;
	input [63:0] ddram_dout;
	input ddram_dout_ready;
	localparam ST_IDLE = 3'd0;
	localparam ST_WR = 3'd1;
	localparam ST_RD_REQ = 3'd2;
	localparam ST_RD_RCV = 3'd3;
	localparam ST_WRB = 3'd4;
	reg [2:0] state;
	reg [63:0] ddram_din_r;
	reg [7:0] beat;
	reg [7:0] bcnt;
	assign ddram_din = (state == ST_WRB ? tst_wdata : ddram_din_r);
	assign tst_wnext = (((state == ST_WRB) && ddram_we) && !ddram_busy) && (beat != (bcnt - 8'd1));
	always @(posedge clk)
		if (sdram_por) begin
			state <= ST_IDLE;
			beat <= 8'd0;
			bcnt <= 8'd1;
			ddram_addr <= 29'd0;
			ddram_burstcnt <= 8'd1;
			ddram_rd <= 1'b0;
			ddram_we <= 1'b0;
			ddram_din_r <= 64'd0;
			ddram_be <= 8'hff;
			tst_rdata <= 64'd0;
			tst_rd_valid <= 1'b0;
			tst_busy <= 1'b0;
			tst_wr_done <= 1'b0;
			tst_wr_base <= 26'd0;
			tst_wr_count <= 8'd0;
			tst_wr_last_data <= 64'd0;
		end
		else begin
			ddram_rd <= 1'b0;
			ddram_we <= 1'b0;
			tst_rd_valid <= 1'b0;
			tst_wr_done <= 1'b0;
			case (state)
				ST_IDLE:
					if (tst_wr_req) begin
						ddram_addr <= VRAM_DDR_BASE + {3'd0, tst_addr};
						ddram_be <= tst_be;
						tst_busy <= 1'b1;
						tst_wr_base <= tst_addr;
						tst_wr_count <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						if (tst_burstcnt <= 8'd1) begin
							ddram_din_r <= tst_wdata;
							ddram_burstcnt <= 8'd1;
							state <= ST_WR;
						end
						else begin
							ddram_burstcnt <= tst_burstcnt;
							bcnt <= tst_burstcnt;
							beat <= 8'd0;
							state <= ST_WRB;
						end
					end
					else if (tst_rd_req) begin
						ddram_addr <= VRAM_DDR_BASE + {3'd0, tst_addr};
						ddram_burstcnt <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						bcnt <= (tst_burstcnt == 8'd0 ? 8'd1 : tst_burstcnt);
						beat <= 8'd0;
						ddram_rd <= 1'b1;
						tst_busy <= 1'b1;
						state <= ST_RD_REQ;
					end
				ST_WR: begin
					ddram_we <= 1'b1;
					if (ddram_we && !ddram_busy) begin
						ddram_we <= 1'b0;
						tst_busy <= 1'b0;
						state <= ST_IDLE;
						tst_wr_done <= 1'b1;
						tst_wr_last_data <= ddram_din_r;
					end
				end
				ST_WRB: begin
					ddram_we <= 1'b1;
					if (ddram_we && !ddram_busy) begin
						if (beat == (bcnt - 8'd1)) begin
							ddram_we <= 1'b0;
							tst_busy <= 1'b0;
							state <= ST_IDLE;
							tst_wr_done <= 1'b1;
							tst_wr_last_data <= tst_wdata;
						end
						beat <= beat + 8'd1;
					end
				end
				ST_RD_REQ:
					if (ddram_busy)
						ddram_rd <= 1'b1;
					else
						state <= ST_RD_RCV;
				ST_RD_RCV:
					if (ddram_dout_ready) begin
						tst_rdata <= ddram_dout;
						tst_rd_valid <= 1'b1;
						if (beat == (bcnt - 8'd1)) begin
							tst_busy <= 1'b0;
							state <= ST_IDLE;
						end
						beat <= beat + 8'd1;
					end
				default: state <= ST_IDLE;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module stv_vram_ddr_top (
	clk,
	rst,
	sdram_por,
	req,
	we,
	srt,
	widx,
	boff,
	sz,
	wd,
	videobank,
	dma_palette,
	rdata,
	done,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	fb_flush,
	fb_busy,
	erase_en,
	erase_busy,
	disp_base,
	scan_blank,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready
);
	reg _sv2v_0;
	parameter signed [31:0] VRAMW = 32'h00040000;
	parameter [28:0] VRAM_DDR_BASE = 29'h06400000;
	parameter signed [31:0] ERASE_FIRST_REL = -1;
	parameter signed [31:0] ERASE_ARM_CATCHUP_MAX = 24;
	parameter [0:0] D_SHADOW_RMW_BYPASS = 1'b0;
	parameter [0:0] D_WRITE_FIFO = 1'b0;
	parameter [0:0] D_BEAT_FIFO = 1'b0;
	parameter signed [31:0] D_BEAT_FIFO_DEPTH = 16384;
	parameter signed [31:0] ERASE_ROWS = 256;
	parameter [0:0] C_FAIR = 1'b0;
	parameter signed [31:0] C_FAIR_AGE = 192;
	input wire clk;
	input wire rst;
	input wire sdram_por;
	input wire req;
	input wire we;
	input wire srt;
	input wire [27:0] widx;
	input wire [3:0] boff;
	input wire [5:0] sz;
	input wire [31:0] wd;
	input wire videobank;
	input wire [15:0] dma_palette;
	output wire [31:0] rdata;
	output wire done;
	input wire fb_we;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	output reg fb_ack;
	input wire fb_flush;
	output reg fb_busy;
	input wire erase_en;
	output wire erase_busy;
	input wire [8:0] disp_base;
	input wire scan_blank;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output reg [15:0] scan_data;
	output reg scan_ack;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	wire srt_i = srt === 1'b1;
	function automatic [7:0] lane_be;
		input [1:0] l;
		case (l)
			2'd0: lane_be = 8'h03;
			2'd1: lane_be = 8'h0c;
			2'd2: lane_be = 8'h30;
			default: lane_be = 8'hc0;
		endcase
	endfunction
	reg [8:0] rc_row;
	reg rc_valid;
	localparam [0:0] BSNOOP = 1'b1;
	reg [63:0] bfill_merged;
	reg c_start;
	reg c_wr;
	reg [25:0] c_addr;
	reg [15:0] c_wait;
	wire c_urgent;
	reg d_start;
	reg d_wr;
	reg [25:0] d_addr;
	reg d_is_burst;
	wire d_busy;
	wire b_fill_lock;
	wire b_bus_lock;
	reg [2:0] ls;
	wire tst_busy;
	reg d_add;
	reg [15:0] d_add_beat;
	wire fbq_busy;
	wire fbq_empty;
	wire fbq_push;
	wire fbq_pop;
	reg fbq_row_conflict;
	reg b_drain_is_hit;
	reg b_fifo_fenced;
	reg beat_pending;
	reg beat_busy;
	reg beat_fb_we;
	wire beat_fb_ack;
	reg beat_fb_flush;
	reg [17:0] beat_fb_addr;
	reg [15:0] beat_fb_wdata;
	reg e_start;
	reg e_wr;
	reg [25:0] e_addr;
	reg [7:0] e_burstlen;
	reg e_done;
	wire e_rd_valid;
	wire [63:0] e_rdata;
	reg srt_busy;
	reg srt_done;
	reg srt_store_q;
	reg [31:0] srt_rdata;
	wire srt_claim;
	wire srt_store_atomic;
	wire srt_invalidate_evt;
	wire [20:0] sd_addr;
	wire [15:0] sd_din;
	wire [1:0] sd_be;
	wire sd_rd;
	wire sd_wr;
	reg [15:0] sd_dout;
	reg sd_ack;
	wire [31:0] acc_rdata;
	wire acc_done;
	vram_sdram_top #(
		.VRAMW(VRAMW),
		.SD_AW(21),
		.VRAM_BASE(21'd0),
		.HAS_ERASE(1'b0),
		.HAS_FBW(1'b0),
		.HAS_SCAN(1'b0)
	) u_acc(
		.clk(clk),
		.rst(rst),
		.req(req && !srt_i),
		.we(we),
		.srt(1'b0),
		.widx(widx),
		.boff(boff),
		.sz(sz),
		.wd(wd),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(acc_rdata),
		.done(acc_done),
		.fb_we(1'b0),
		.fb_addr(18'd0),
		.fb_wdata(16'd0),
		.fb_ack(),
		.erase_start(1'b0),
		.erase_row0(9'd0),
		.erase_lines(10'd0),
		.erase_busy(),
		.scan_req(1'b0),
		.scan_addr(18'd0),
		.scan_data(),
		.scan_ack(),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack)
	);
	assign done = srt_done | acc_done;
	assign rdata = (srt_done ? srt_rdata : acc_rdata);
	reg a_start;
	reg a_wr;
	reg [25:0] a_addr;
	reg [63:0] a_wdata;
	reg [7:0] a_be;
	reg a_done;
	wire a_rd_valid;
	wire [63:0] a_rdata;
	reg [1:0] a_lane;
	reg [15:0] rmw_din;
	(* ramstyle = "M10K" *) reg [77:0] shw_mem [0:2047];
	reg [77:0] shw_q;
	reg [15:0] shw_cand_q;
	reg [63:0] shw_rsp_data_q;
	reg [15:0] shw_rsp_cand_q;
	reg shw_rsp_hit_q;
	reg [1:0] shw_epoch;
	reg [1:0] shw_read_epoch_q;
	reg [1:0] shw_rsp_epoch_q;
	reg [63:0] shw_base;
	reg shw_base_hit;
	reg [7:0] shw_generation = 8'd0;
	reg shw_por_seen = 1'b0;
	reg [2047:0] shw_valid;
	reg shw_v_q;
	wire d_shadow_bypass_en;
	wire d_shadow_lookup;
	wire d_shadow_bypass;
	always @(posedge clk)
		if (sdram_por) begin
			if (!shw_por_seen)
				shw_generation <= shw_generation + 8'd1;
			shw_por_seen <= 1'b1;
		end
		else
			shw_por_seen <= 1'b0;
	wire shw_en = 1'b1;
	wire [63:0] a_read_beat = ((D_WRITE_FIFO && shw_en) && shw_base_hit ? shw_base : a_rdata);
	reg [63:0] rmw_beat;
	wire [63:0] rmw_merged = (a_lane == 2'd0 ? {rmw_beat[63:16], rmw_din} : (a_lane == 2'd1 ? {rmw_beat[63:32], rmw_din, rmw_beat[15:0]} : (a_lane == 2'd2 ? {rmw_beat[63:48], rmw_din, rmw_beat[31:0]} : {rmw_din, rmw_beat[47:0]})));
	reg [63:0] bc_beat0;
	reg [63:0] bc_beat1;
	reg [25:0] bc_addr0;
	reg [25:0] bc_addr1;
	reg bc_v0;
	reg bc_v1;
	reg bc_lru;
	reg bc_lastwr;
	reg bc_lastwr_v;
	reg bc_alloc;
	wire bc_hit0 = bc_v0 && (bc_addr0 == a_addr);
	wire bc_hit1 = bc_v1 && (bc_addr1 == a_addr);
	wire hit_idx = bc_hit1;
	wire [63:0] fwd_beat = (bc_hit1 ? bc_beat1 : bc_beat0);
	wire wr_alloc = (!bc_v0 ? 1'b0 : (!bc_v1 ? 1'b1 : bc_lru));
	wire rd_alloc = (!bc_v0 ? 1'b0 : (!bc_v1 ? 1'b1 : (bc_lastwr_v && (bc_lru == bc_lastwr) ? ~bc_lru : bc_lru)));
	reg a_is_wr;
	reg wb_v;
	reg [25:0] wb_addr;
	reg [63:0] wb_data;
	reg [25:0] a_addr_save;
	reg flush_pend;
	reg [4:0] wb_idle;
	localparam [4:0] WB_FLUSH_IDLE = 5'd16;
	reg awt_req;
	reg [6:0] awt_col;
	reg [63:0] awt_data;
	reg dwt_req;
	reg [6:0] dwt_col;
	reg [63:0] dwt_data;
	reg asrcwt_req;
	reg [7:0] asrcwt_idx;
	reg [63:0] asrcwt_data;
	reg dsrcwt_req;
	reg [7:0] dsrcwt_idx;
	reg [63:0] dsrcwt_data;
	reg [63:0] dsrcwt_data_next;
	wire wt_req = awt_req | dwt_req;
	wire [6:0] wt_col = (awt_req ? awt_col : dwt_col);
	wire [63:0] wt_data = (awt_req ? awt_data : dwt_data);
	wire srcwt_req = asrcwt_req | dsrcwt_req;
	wire [7:0] srcwt_idx = (asrcwt_req ? asrcwt_idx : dsrcwt_idx);
	wire [63:0] srcwt_data = (asrcwt_req ? asrcwt_data : dsrcwt_data);
	wire fwd_hit = bc_hit0 | bc_hit1;
	localparam [2:0] A_IDLE = 3'd0;
	localparam [2:0] A_DEC = 3'd1;
	localparam [2:0] A_WAIT = 3'd2;
	localparam [2:0] A_ACK = 3'd3;
	localparam [2:0] A_RMW_RD = 3'd4;
	localparam [2:0] A_RMW_MRG = 3'd5;
	localparam [2:0] A_FLUSH = 3'd6;
	reg [2:0] ats;
	wire a_req_pending = sd_rd || sd_wr;
	wire a_flush_due = wb_v && (wb_idle >= WB_FLUSH_IDLE);
	wire a_claim = (((ats != A_IDLE) || a_start) || a_req_pending) || a_flush_due;
	always @(posedge clk)
		if (rst) begin
			ats <= A_IDLE;
			a_start <= 1'b0;
			a_wr <= 1'b0;
			a_addr <= 26'd0;
			a_wdata <= 64'd0;
			a_be <= 8'd0;
			a_lane <= 2'd0;
			rmw_din <= 16'd0;
			rmw_beat <= 64'd0;
			sd_ack <= 1'b0;
			sd_dout <= 16'd0;
			wb_v <= 1'b0;
			wb_addr <= 26'd0;
			wb_data <= 64'd0;
			a_addr_save <= 26'd0;
			flush_pend <= 1'b0;
			wb_idle <= 5'd0;
			bc_beat0 <= 64'd0;
			bc_beat1 <= 64'd0;
			bc_addr0 <= 26'd0;
			bc_addr1 <= 26'd0;
			bc_v0 <= 1'b0;
			bc_v1 <= 1'b0;
			bc_lru <= 1'b0;
			bc_lastwr <= 1'b0;
			bc_lastwr_v <= 1'b0;
			bc_alloc <= 1'b0;
			a_is_wr <= 1'b0;
			awt_req <= 1'b0;
			asrcwt_req <= 1'b0;
			asrcwt_idx <= 8'd0;
			asrcwt_data <= 64'd0;
		end
		else begin
			sd_ack <= 1'b0;
			awt_req <= 1'b0;
			asrcwt_req <= 1'b0;
			case (ats)
				A_IDLE:
					if (!d_busy) begin
						if (b_fill_lock && wb_v) begin
							flush_pend <= 1'b0;
							a_addr <= wb_addr;
							a_wdata <= wb_data;
							a_be <= 8'hff;
							a_wr <= 1'b1;
							a_start <= 1'b1;
							ats <= A_FLUSH;
						end
						else if (!b_fill_lock && sd_rd) begin
							a_lane <= sd_addr[1:0];
							a_addr <= {10'd0, sd_addr[17:2]};
							a_addr_save <= {10'd0, sd_addr[17:2]};
							a_is_wr <= 1'b0;
							ats <= A_DEC;
						end
						else if (!b_fill_lock && sd_wr) begin
							a_lane <= sd_addr[1:0];
							a_addr <= {10'd0, sd_addr[17:2]};
							a_addr_save <= {10'd0, sd_addr[17:2]};
							rmw_din <= sd_din;
							a_is_wr <= 1'b1;
							ats <= A_DEC;
						end
						else if (!b_fill_lock && wb_v) begin
							if (wb_idle >= WB_FLUSH_IDLE) begin
								flush_pend <= 1'b0;
								a_addr <= wb_addr;
								a_wdata <= wb_data;
								a_be <= 8'hff;
								a_wr <= 1'b1;
								a_start <= 1'b1;
								ats <= A_FLUSH;
							end
							else
								wb_idle <= wb_idle + 5'd1;
						end
					end
				A_DEC:
					if (wb_v && (wb_addr != a_addr)) begin
						flush_pend <= 1'b1;
						a_addr <= wb_addr;
						a_wdata <= wb_data;
						a_be <= 8'hff;
						a_wr <= 1'b1;
						a_start <= 1'b1;
						ats <= A_FLUSH;
					end
					else if (fwd_hit) begin
						if (a_is_wr) begin
							rmw_beat <= fwd_beat;
							ats <= A_RMW_MRG;
						end
						else begin
							case (a_lane)
								2'd0: sd_dout <= fwd_beat[15:0];
								2'd1: sd_dout <= fwd_beat[31:16];
								2'd2: sd_dout <= fwd_beat[47:32];
								default: sd_dout <= fwd_beat[63:48];
							endcase
							sd_ack <= 1'b1;
							ats <= A_ACK;
						end
						bc_lru <= ~hit_idx;
						bc_alloc <= hit_idx;
					end
					else begin
						a_wr <= 1'b0;
						a_start <= 1'b1;
						ats <= (a_is_wr ? A_RMW_RD : A_WAIT);
						bc_alloc <= (a_is_wr ? wr_alloc : rd_alloc);
					end
				A_WAIT: begin
					if (a_rd_valid) begin
						case (a_lane)
							2'd0: sd_dout <= a_read_beat[15:0];
							2'd1: sd_dout <= a_read_beat[31:16];
							2'd2: sd_dout <= a_read_beat[47:32];
							default: sd_dout <= a_read_beat[63:48];
						endcase
						if (!a_is_wr) begin
							if (bc_alloc) begin
								bc_beat1 <= a_read_beat;
								bc_addr1 <= a_addr;
								bc_v1 <= 1'b1;
							end
							else begin
								bc_beat0 <= a_read_beat;
								bc_addr0 <= a_addr;
								bc_v0 <= 1'b1;
							end
							bc_lru <= ~bc_alloc;
						end
					end
					if (a_done) begin
						a_start <= 1'b0;
						sd_ack <= 1'b1;
						ats <= A_ACK;
					end
				end
				A_RMW_RD: begin
					if (a_rd_valid)
						rmw_beat <= (shw_en && shw_base_hit ? shw_base : a_rdata);
					if (a_done) begin
						a_start <= 1'b0;
						ats <= A_RMW_MRG;
					end
				end
				A_RMW_MRG: begin
					wb_v <= 1'b1;
					wb_addr <= a_addr;
					wb_data <= rmw_merged;
					wb_idle <= 5'd0;
					sd_ack <= 1'b1;
					ats <= A_ACK;
					if (bc_alloc) begin
						bc_beat1 <= rmw_merged;
						bc_addr1 <= a_addr;
						bc_v1 <= 1'b1;
					end
					else begin
						bc_beat0 <= rmw_merged;
						bc_addr0 <= a_addr;
						bc_v0 <= 1'b1;
					end
					bc_lru <= ~bc_alloc;
					bc_lastwr <= bc_alloc;
					bc_lastwr_v <= 1'b1;
					awt_req <= rc_valid && (a_addr[15:7] == rc_row);
					awt_col <= a_addr[6:0];
					awt_data <= rmw_merged;
					asrcwt_req <= (a_addr[15:7] == 9'd510) || (a_addr[15:7] == 9'd511);
					asrcwt_idx <= {a_addr[15:7] == 9'd511, a_addr[6:0]};
					asrcwt_data <= rmw_merged;
				end
				A_ACK: ats <= A_IDLE;
				A_FLUSH:
					if (a_done) begin
						a_start <= 1'b0;
						a_wr <= 1'b0;
						wb_v <= 1'b0;
						if (flush_pend) begin
							a_addr <= a_addr_save;
							ats <= A_DEC;
						end
						else
							ats <= A_IDLE;
					end
				default: ats <= A_IDLE;
			endcase
			if (c_start && c_wr) begin
				if (bc_v0 && (bc_addr0 == c_addr))
					bc_v0 <= 1'b0;
				if (bc_v1 && (bc_addr1 == c_addr))
					bc_v1 <= 1'b0;
			end
			if (d_add) begin
				if (bc_v0 && (bc_addr0 == {10'd0, d_add_beat}))
					bc_v0 <= 1'b0;
				if (bc_v1 && (bc_addr1 == {10'd0, d_add_beat}))
					bc_v1 <= 1'b0;
			end
			if ((d_start && d_wr) && !d_is_burst) begin
				if (bc_v0 && (bc_addr0 == d_addr))
					bc_v0 <= 1'b0;
				if (bc_v1 && (bc_addr1 == d_addr))
					bc_v1 <= 1'b0;
			end
			if (((c_start && c_wr) && wb_v) && (wb_addr == c_addr))
				wb_v <= 1'b0;
			if ((d_add && wb_v) && (wb_addr == {10'd0, d_add_beat}))
				wb_v <= 1'b0;
			if ((((d_start && d_wr) && !d_is_burst) && wb_v) && (wb_addr == d_addr))
				wb_v <= 1'b0;
		end
	(* ramstyle = "no_rw_check" *) reg [63:0] rc [0:127];
	reg wtp_v;
	reg [6:0] wtp_col;
	reg [63:0] wtp_data;
	reg [8:0] wtp_row;
	wire [8:0] req_row = scan_addr[17:9];
	wire [8:0] req_col = scan_addr[8:0];
	reg [63:0] rc_q;
	wire [6:0] rc_raddr = req_col[8:2];
	reg [1:0] rc_rlane;
	always @(posedge clk) rc_q <= rc[rc_raddr];
	reg b_start;
	reg [25:0] b_addr;
	reg [7:0] b_burstlen;
	reg b_done;
	wire b_rd_valid;
	wire [63:0] b_rdata;
	reg [7:0] fillbeat;
	reg [8:0] fill_row;
	reg [15:0] bfill_bt_q;
	reg [15:0] bfill_bt_rb_q;
	reg bfill_pipe_v;
	reg [6:0] bfill_pipe_col;
	reg [63:0] bfill_pipe_data;
	localparam [7:0] BMAX = 8'd32;
	localparam [2:0] B_IDLE = 3'd0;
	localparam [2:0] B_REQ = 3'd1;
	localparam [2:0] B_FILL = 3'd2;
	localparam [2:0] B_HIT = 3'd3;
	localparam [2:0] B_WAIT = 3'd4;
	localparam [2:0] B_DRAIN = 3'd5;
	localparam [2:0] B_COMMIT = 3'd6;
	reg [2:0] bts;
	wire b_fill_active = ((bts == B_REQ) || (bts == B_FILL)) || (bts == B_COMMIT);
	assign b_fill_lock = (((bts == B_DRAIN) || (bts == B_REQ)) || (bts == B_FILL)) || (bts == B_COMMIT);
	assign b_bus_lock = (bts == B_REQ) || (bts == B_FILL);
	wire skd_push;
	always @(posedge clk)
		if (rst) begin
			bts <= B_IDLE;
			b_start <= 1'b0;
			b_addr <= 26'd0;
			b_burstlen <= 8'd0;
			rc_valid <= 1'b0;
			rc_row <= 9'd0;
			fillbeat <= 8'd0;
			fill_row <= 9'd0;
			bfill_bt_q <= 16'd0;
			bfill_bt_rb_q <= 16'd0;
			rc_rlane <= 2'd0;
			scan_ack <= 1'b0;
			scan_data <= 16'd0;
			bfill_pipe_v <= 1'b0;
			bfill_pipe_col <= 7'd0;
			bfill_pipe_data <= 64'd0;
			wtp_v <= 1'b0;
			wtp_col <= 7'd0;
			wtp_data <= 64'd0;
			wtp_row <= 9'd0;
			b_drain_is_hit <= 1'b0;
			b_fifo_fenced <= 1'b0;
		end
		else begin
			scan_ack <= 1'b0;
			if (srt_invalidate_evt)
				rc_valid <= 1'b0;
			bfill_pipe_v <= 1'b0;
			if ((bts == B_FILL) && b_rd_valid) begin
				bfill_pipe_v <= 1'b1;
				bfill_pipe_col <= fillbeat[6:0];
				bfill_pipe_data <= bfill_merged;
			end
			case (bts)
				B_IDLE:
					if (scan_req) begin
						if (rc_valid && (rc_row == req_row)) begin
							rc_rlane <= req_col[1:0];
							if (D_WRITE_FIFO && (fbq_row_conflict || ((!D_BEAT_FIFO && skd_push) && (beat_fb_addr[17:9] == rc_row)))) begin
								b_drain_is_hit <= 1'b1;
								b_fifo_fenced <= 1'b0;
								bts <= B_DRAIN;
							end
							else begin
								b_drain_is_hit <= 1'b0;
								bts <= B_HIT;
							end
						end
						else begin
							fillbeat <= 8'd0;
							fill_row <= req_row;
							bfill_bt_q <= {req_row, 7'd0};
							bfill_bt_rb_q <= {req_row, 7'd0};
							rc_valid <= 1'b0;
							wtp_v <= 1'b0;
							b_drain_is_hit <= 1'b0;
							if (D_WRITE_FIFO) begin
								b_fifo_fenced <= 1'b1;
								bts <= B_DRAIN;
							end
							else begin
								b_fifo_fenced <= 1'b0;
								bts <= B_REQ;
							end
						end
					end
				B_DRAIN:
					if ((((((((ats == A_IDLE) && !a_start) && !wb_v) && !d_busy) && !d_start) && !c_start) && (ls == 3'd0)) && !tst_busy) begin
						if (b_drain_is_hit) begin
							b_drain_is_hit <= 1'b0;
							bts <= B_HIT;
						end
						else
							bts <= B_REQ;
					end
				B_REQ: begin
					b_addr <= {10'd0, fill_row, 7'd0} + {18'd0, fillbeat};
					b_burstlen <= ((8'd128 - fillbeat) > BMAX ? BMAX : 8'd128 - fillbeat);
					b_start <= 1'b1;
					bts <= B_FILL;
				end
				B_FILL: begin
					if (b_rd_valid) begin
						fillbeat <= fillbeat + 8'd1;
						bfill_bt_q[6:0] <= bfill_bt_q[6:0] + 7'd1;
						bfill_bt_rb_q[6:0] <= bfill_bt_rb_q[6:0] + 7'd1;
					end
					if (b_done) begin
						b_start <= 1'b0;
						if (fillbeat >= 8'd128)
							bts <= B_COMMIT;
						else
							bts <= B_REQ;
					end
				end
				B_COMMIT:
					if (!bfill_pipe_v) begin
						rc_valid <= 1'b1;
						b_fifo_fenced <= 1'b0;
						rc_row <= fill_row;
						bts <= B_IDLE;
					end
				B_HIT: begin
					case (rc_rlane)
						2'd0: scan_data <= rc_q[15:0];
						2'd1: scan_data <= rc_q[31:16];
						2'd2: scan_data <= rc_q[47:32];
						default: scan_data <= rc_q[63:48];
					endcase
					scan_ack <= 1'b1;
					bts <= B_WAIT;
				end
				B_WAIT:
					if (!scan_req)
						bts <= B_IDLE;
				default: bts <= B_IDLE;
			endcase
			if (bfill_pipe_v) begin
				rc[bfill_pipe_col] <= bfill_pipe_data;
				if (wt_req) begin
					wtp_v <= 1'b1;
					wtp_col <= wt_col;
					wtp_data <= wt_data;
					wtp_row <= rc_row;
				end
			end
			else if (wtp_v) begin
				if (rc_valid && (rc_row == wtp_row))
					rc[wtp_col] <= wtp_data;
				wtp_v <= 1'b0;
				if (wt_req) begin
					wtp_v <= 1'b1;
					wtp_col <= wt_col;
					wtp_data <= wt_data;
					wtp_row <= rc_row;
				end
			end
			else if (wt_req)
				rc[wt_col] <= wt_data;
		end
	(* ramstyle = "no_rw_check" *) reg [63:0] src_cache [0:255];
	reg src510_valid;
	reg src511_valid;
	reg [63:0] src_q;
	reg [7:0] src_raddr;
	always @(posedge clk) src_q <= src_cache[src_raddr];
	reg [8:0] req_row_d;
	always @(posedge clk) req_row_d <= req_row;
	wire row_changed = req_row != req_row_d;
	wire trig_wrap = req_row < req_row_d;
	wire [8:0] trig_nr = req_row - 9'd1;
	localparam signed [31:0] ER_ROWS = ERASE_ROWS;
	localparam [8:0] ER_LAST = ER_ROWS - 1;
	wire [8:0] er_base = disp_base;
	reg [8:0] er_base_q;
	reg [8:0] er_top_q;
	reg [8:0] er_wrap_to_q;
	always @(posedge clk) begin
		er_base_q <= er_base;
		er_top_q <= er_base + ER_LAST;
		er_wrap_to_q <= er_base - 9'd1;
	end
	wire [8:0] er_top = er_top_q;
	wire [8:0] er_wrap_to = er_wrap_to_q;
	wire [8:0] trig_rel = trig_nr - er_base_q;
	reg er_blank_q;
	always @(posedge clk) er_blank_q <= scan_blank === 1'b1;
	wire er_blank = er_blank_q;
	reg [8:0] er_goal;
	reg er_goal_v;
	reg erase_en_q;
	reg arm_seen;
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	wire [8:0] er_gospel_row = er_base_q + sv2v_cast_9_signed(ERASE_FIRST_REL);
	wire [8:0] er_gospel_lag = er_goal - er_gospel_row;
	reg [8:0] er_next;
	wire [8:0] er_lag = er_goal - er_next;
	wire er_pending = (er_goal_v && erase_en) && (er_lag <= ER_LAST);
	wire goal_accept = (((row_changed && !trig_wrap) && !er_blank) && ((trig_rel <= ER_LAST) || (trig_rel == 9'h1ff))) && (trig_nr < 9'd510);
	reg [63:0] c_wdata;
	reg [7:0] c_burstlen;
	reg c_done;
	wire c_rd_valid;
	wire [63:0] c_rdata;
	localparam [7:0] CB_MAX = 8'd16;
	reg [63:0] cb_data [0:15];
	reg [4:0] c_stg;
	localparam [4:0] C_STG_READY = 5'd17;
	wire c_is_burst = c_wr && (c_burstlen > 8'd1);
	reg [8:0] erase_row;
	reg [6:0] c_beat;
	reg [7:0] c_fill;
	reg c_fill_which;
	wire erase_par = erase_row[0];
	wire next_par = er_next[0];
	wire next_srcv = (next_par ? src511_valid : src510_valid);
	localparam [2:0] C_IDLE = 3'd0;
	localparam [2:0] C_FILL_REQ = 3'd1;
	localparam [2:0] C_FILL_RCV = 3'd2;
	localparam [2:0] C_STAGE = 3'd3;
	localparam [2:0] C_BWR = 3'd4;
	reg [2:0] cts;
	assign erase_busy = cts != C_IDLE;
	reg swp_v;
	reg [7:0] swp_idx;
	reg [63:0] swp_data;
	always @(posedge clk)
		if (rst) begin
			cts <= C_IDLE;
			c_start <= 1'b0;
			c_wr <= 1'b0;
			c_addr <= 26'd0;
			c_wdata <= 64'd0;
			c_burstlen <= 8'd1;
			c_beat <= 7'd0;
			c_stg <= 5'd0;
			c_fill <= 8'd0;
			c_fill_which <= 1'b0;
			erase_row <= 9'd0;
			src_raddr <= 8'd0;
			src510_valid <= 1'b0;
			src511_valid <= 1'b0;
			swp_v <= 1'b0;
			swp_idx <= 8'd0;
			swp_data <= 64'd0;
			er_goal <= 9'd0;
			er_goal_v <= 1'b0;
			er_next <= 9'd0;
			erase_en_q <= 1'b0;
			arm_seen <= 1'b0;
		end
		else begin
			erase_en_q <= erase_en;
			if (erase_en && !erase_en_q)
				arm_seen <= 1'b1;
			if (srt_invalidate_evt) begin
				src510_valid <= 1'b0;
				src511_valid <= 1'b0;
			end
			if (goal_accept) begin
				er_goal <= trig_nr;
				er_goal_v <= 1'b1;
			end
			if ((erase_en && !erase_en_q) && er_goal_v) begin
				if ((ERASE_FIRST_REL >= 0) && (er_gospel_lag <= ERASE_ARM_CATCHUP_MAX[8:0]))
					er_next <= er_gospel_row;
				else
					er_next <= er_goal;
			end
			else if (!erase_en)
				er_next <= (er_goal == er_top ? er_wrap_to : er_goal + 9'd1);
			case (cts)
				C_IDLE:
					if (er_pending) begin
						if (er_next >= 9'd510)
							er_next <= (er_next == er_top ? er_wrap_to : er_next + 9'd1);
						else begin
							erase_row <= er_next;
							src_raddr <= {next_par, 7'd0};
							c_beat <= 7'd0;
							if (!next_srcv) begin
								c_fill <= 8'd0;
								c_fill_which <= next_par;
								cts <= C_FILL_REQ;
							end
							else begin
								c_stg <= 5'd0;
								cts <= C_STAGE;
							end
						end
					end
				C_FILL_REQ:
					if (!b_fill_lock) begin
						c_addr <= {10'd0, (c_fill_which ? 9'd511 : 9'd510), 7'd0} + {18'd0, c_fill};
						c_burstlen <= ((8'd128 - c_fill) > BMAX ? BMAX : 8'd128 - c_fill);
						c_wr <= 1'b0;
						c_start <= 1'b1;
						cts <= C_FILL_RCV;
					end
				C_FILL_RCV: begin
					if (c_rd_valid)
						c_fill <= c_fill + 8'd1;
					if (c_done) begin
						c_start <= 1'b0;
						if (c_fill >= 8'd128) begin
							if (c_fill_which)
								src511_valid <= 1'b1;
							else
								src510_valid <= 1'b1;
							src_raddr <= {c_fill_which, 7'd0};
							c_stg <= 5'd0;
							cts <= C_STAGE;
						end
						else
							cts <= C_FILL_REQ;
					end
				end
				C_STAGE:
					if (c_stg == 5'd0) begin
						src_raddr <= {erase_par, c_beat + 7'd1};
						c_stg <= 5'd1;
					end
					else if (c_stg == C_STG_READY) begin
						if (!b_fill_lock) begin
							c_addr <= {10'd0, erase_row, c_beat};
							c_burstlen <= CB_MAX;
							c_wr <= 1'b1;
							c_start <= 1'b1;
							cts <= C_BWR;
						end
					end
					else begin
						cb_data[c_stg[3:0] - 4'd1] <= src_q;
						if (c_stg == CB_MAX[4:0]) begin
							if (!b_fill_lock) begin
								c_addr <= {10'd0, erase_row, c_beat};
								c_burstlen <= CB_MAX;
								c_wr <= 1'b1;
								c_start <= 1'b1;
								cts <= C_BWR;
							end
							else
								c_stg <= C_STG_READY;
						end
						else begin
							src_raddr <= {erase_par, (c_beat + {2'b00, c_stg}) + 7'd1};
							c_stg <= c_stg + 5'd1;
						end
					end
				C_BWR:
					if (c_done) begin
						c_start <= 1'b0;
						if ((c_beat + CB_MAX[6:0]) == 7'd0) begin
							er_next <= (er_next == er_top ? er_wrap_to : er_next + 9'd1);
							if ((erase_row == er_goal) && !goal_accept)
								er_goal_v <= 1'b0;
							cts <= C_IDLE;
						end
						else begin
							c_beat <= c_beat + CB_MAX[6:0];
							src_raddr <= {erase_par, c_beat + CB_MAX[6:0]};
							c_stg <= 5'd0;
							cts <= C_STAGE;
						end
					end
				default: cts <= C_IDLE;
			endcase
			if ((cts == C_FILL_RCV) && c_rd_valid) begin
				src_cache[{c_fill_which, c_fill[6:0]}] <= c_rdata;
				if (srcwt_req) begin
					swp_v <= 1'b1;
					swp_idx <= srcwt_idx;
					swp_data <= srcwt_data;
				end
			end
			else if (srcwt_req) begin
				src_cache[srcwt_idx] <= srcwt_data;
				if (swp_v && (swp_idx == srcwt_idx))
					swp_v <= 1'b0;
			end
			else if (swp_v) begin
				src_cache[swp_idx] <= swp_data;
				swp_v <= 1'b0;
			end
		end
	localparam FBCOMB = 1'b1;
	localparam integer FBQ_DEPTH = 64;
	localparam integer FBQ_AW = 6;
	(* ramstyle = "M10K" *) reg [33:0] fbq_mem [0:FBQ_DEPTH - 1];
	reg [FBQ_AW:0] fbq_wptr;
	reg [FBQ_AW:0] fbq_rptr;
	reg [FBQ_AW:0] fbq_rptr_q;
	reg [33:0] fbq_head;
	reg fbq_ne_q;
	reg fbq_flush_pend;
	wire [FBQ_AW - 1:0] fbq_wp = fbq_wptr[FBQ_AW - 1:0];
	wire [FBQ_AW - 1:0] fbq_rp = fbq_rptr[FBQ_AW - 1:0];
	wire fbq_full = (fbq_wptr[FBQ_AW - 1:0] == fbq_rptr[FBQ_AW - 1:0]) && (fbq_wptr[FBQ_AW] != fbq_rptr[FBQ_AW]);
	assign fbq_empty = fbq_wptr == fbq_rptr;
	wire fbq_head_valid = (!fbq_empty && fbq_ne_q) && (fbq_rptr == fbq_rptr_q);
	localparam integer SKD_DEPTH = 4;
	localparam integer SKD_AW = 2;
	localparam [SKD_AW:0] SKD_FULL = 3'd4;
	reg [33:0] skd_mem [0:SKD_DEPTH - 1];
	reg [SKD_AW:0] skd_wptr;
	reg [SKD_AW:0] skd_rptr;
	reg skd_room_q;
	wire [SKD_AW:0] skd_occ = skd_wptr - skd_rptr;
	wire skd_empty = skd_wptr == skd_rptr;
	wire [33:0] skd_head = skd_mem[skd_rptr[SKD_AW - 1:0]];
	wire [17:0] skd_addr = skd_head[33:16];
	wire skd_pop;
	assign fbq_busy = D_WRITE_FIFO && (!fbq_empty || !skd_empty);
	wire fbq_drained = fbq_empty && skd_empty;
	wire fbq_b_park = (bts == B_DRAIN) || (b_fill_active && (fb_addr[17:9] == fill_row));
	wire fbq_c_park = D_WRITE_FIFO && c_start;
	wire beat_in_allow = (!a_claim && !srt_claim) && !fbq_c_park;
	reg skd_ingress_ready;
	reg beat_in_ack;
	generate
		if (D_BEAT_FIFO) begin : g_beat_fifo
			wire [1:1] sv2v_tmp_u_beat_fifo_in_ack;
			always @(*) beat_in_ack = sv2v_tmp_u_beat_fifo_in_ack;
			wire [1:1] sv2v_tmp_u_beat_fifo_out_we;
			always @(*) beat_fb_we = sv2v_tmp_u_beat_fifo_out_we;
			wire [18:1] sv2v_tmp_u_beat_fifo_out_addr;
			always @(*) beat_fb_addr = sv2v_tmp_u_beat_fifo_out_addr;
			wire [16:1] sv2v_tmp_u_beat_fifo_out_data;
			always @(*) beat_fb_wdata = sv2v_tmp_u_beat_fifo_out_data;
			wire [1:1] sv2v_tmp_u_beat_fifo_out_flush;
			always @(*) beat_fb_flush = sv2v_tmp_u_beat_fifo_out_flush;
			wire [1:1] sv2v_tmp_u_beat_fifo_pending;
			always @(*) beat_pending = sv2v_tmp_u_beat_fifo_pending;
			wire [1:1] sv2v_tmp_u_beat_fifo_busy;
			always @(*) beat_busy = sv2v_tmp_u_beat_fifo_busy;
			narc_fb_beat_fifo #(.DEPTH(D_BEAT_FIFO_DEPTH)) u_beat_fifo(
				.clk(clk),
				.rst(rst),
				.in_we(fb_we),
				.in_addr(fb_addr),
				.in_data(fb_wdata),
				.in_allow(beat_in_allow),
				.in_ack(sv2v_tmp_u_beat_fifo_in_ack),
				.in_flush(fb_flush),
				.out_we(sv2v_tmp_u_beat_fifo_out_we),
				.out_addr(sv2v_tmp_u_beat_fifo_out_addr),
				.out_data(sv2v_tmp_u_beat_fifo_out_data),
				.out_ack(skd_ingress_ready),
				.out_flush(sv2v_tmp_u_beat_fifo_out_flush),
				.out_busy(d_busy),
				.pending(sv2v_tmp_u_beat_fifo_pending),
				.busy(sv2v_tmp_u_beat_fifo_busy)
			);
		end
		else begin : g_no_beat_fifo
			always @(*) begin
				if (_sv2v_0)
					;
				beat_in_ack = 1'b0;
				beat_fb_we = fb_we;
				beat_fb_addr = fb_addr;
				beat_fb_wdata = fb_wdata;
				beat_fb_flush = fb_flush;
				beat_pending = 1'b0;
				beat_busy = d_busy;
			end
		end
	endgenerate
	wire pipe_fb_we = beat_fb_we;
	wire [17:0] pipe_fb_addr = beat_fb_addr;
	wire [15:0] pipe_fb_wdata = beat_fb_wdata;
	wire pipe_fb_flush = beat_fb_flush;
	wire fbq_room = !fbq_full || fbq_pop;
	always @(*) begin
		if (_sv2v_0)
			;
		skd_ingress_ready = skd_room_q && (D_BEAT_FIFO ? !fbq_b_park : (!a_claim && !fbq_b_park) && !fbq_c_park);
	end
	reg d_fb_ack;
	reg d_fb_ack_q;
	always @(*) begin
		if (_sv2v_0)
			;
		fb_ack = (D_BEAT_FIFO ? beat_in_ack : (D_WRITE_FIFO ? skd_ingress_ready : d_fb_ack));
	end
	always @(*) begin
		if (_sv2v_0)
			;
		fb_busy = (D_BEAT_FIFO ? beat_busy : d_busy);
	end
	assign skd_push = (D_WRITE_FIFO && pipe_fb_we) && skd_ingress_ready;
	assign skd_pop = (D_WRITE_FIFO && !skd_empty) && fbq_room;
	assign fbq_push = skd_pop;
	wire d_fb_we = (D_WRITE_FIFO ? fbq_head_valid : pipe_fb_we);
	wire [17:0] d_fb_addr = (D_WRITE_FIFO ? fbq_head[33:16] : pipe_fb_addr);
	wire [15:0] d_fb_wdata = (D_WRITE_FIFO ? fbq_head[15:0] : pipe_fb_wdata);
	wire d_fb_flush = (D_WRITE_FIFO ? fbq_drained && (pipe_fb_flush || fbq_flush_pend) : pipe_fb_flush);
	assign fbq_pop = (D_WRITE_FIFO && d_fb_we) && d_fb_ack;
	wire [SKD_AW:0] skd_occ_n = (skd_occ + {{SKD_AW {1'b0}}, skd_push}) - {{SKD_AW {1'b0}}, skd_pop};
	always @(posedge clk)
		if (rst || !D_WRITE_FIFO) begin
			fbq_wptr <= 0;
			fbq_rptr <= 0;
			fbq_rptr_q <= 0;
			fbq_head <= 34'd0;
			fbq_ne_q <= 1'b0;
			fbq_flush_pend <= 1'b0;
			fbq_row_conflict <= 1'b0;
			skd_wptr <= 0;
			skd_rptr <= 0;
			skd_room_q <= 1'b1;
		end
		else begin
			skd_room_q <= skd_occ_n < SKD_FULL;
			if (skd_push) begin
				skd_mem[skd_wptr[SKD_AW - 1:0]] <= {pipe_fb_addr, pipe_fb_wdata};
				skd_wptr <= skd_wptr + 1'b1;
			end
			if (skd_pop)
				skd_rptr <= skd_rptr + 1'b1;
			fbq_head <= fbq_mem[fbq_rp];
			fbq_rptr_q <= fbq_rptr;
			fbq_ne_q <= !fbq_empty;
			if (fbq_push) begin
				fbq_mem[fbq_wp] <= skd_head;
				fbq_wptr <= fbq_wptr + 1'b1;
			end
			if (fbq_pop)
				fbq_rptr <= fbq_rptr + 1'b1;
			if (pipe_fb_flush && !fbq_drained)
				fbq_flush_pend <= 1'b1;
			else if (fbq_drained)
				fbq_flush_pend <= 1'b0;
			if (!rc_valid)
				fbq_row_conflict <= 1'b0;
			else if ((!D_BEAT_FIFO && skd_push) && (pipe_fb_addr[17:9] == rc_row))
				fbq_row_conflict <= 1'b1;
			else if (!d_busy)
				fbq_row_conflict <= 1'b0;
		end
	reg [15:0] wc_beat;
	reg [3:0] wc_mask;
	reg [63:0] wc_data;
	reg [7:0] wc_idle;
	localparam [7:0] FB_WFLUSH_IDLE = 8'd64;
	reg cmb_fb_we_d;
	reg fb_pend;
	reg fb_flush_pend;
	wire [15:0] fb_beat = d_fb_addr[17:2];
	wire fb_same = (FBCOMB && (wc_mask != 4'd0)) && (fb_beat == wc_beat);
	wire fb_new = d_fb_we & ~cmb_fb_we_d;
	wire fb_req = fb_new | fb_pend;
	wire fb_fill_park_fifo = (b_fill_active && fb_req) && (fb_beat[15:7] == fill_row);
	wire fb_fill_park = (D_WRITE_FIFO ? fb_fill_park_fifo : b_fill_lock);
	wire all_fb_drained = fbq_drained && !beat_pending;
	wire d_ingress_park = (D_WRITE_FIFO ? a_claim && all_fb_drained : a_claim);
	wire d_owner_final = (D_WRITE_FIFO ? a_claim && all_fb_drained : a_start || a_req_pending);
	wire b_drain_final = (bts == B_DRAIN) && (!D_WRITE_FIFO || fbq_drained);
	wire d_flush_req = (wc_mask != 4'd0) && (((((((fb_req && !fb_same) || (wc_idle >= FB_WFLUSH_IDLE)) || d_owner_final) || b_drain_final) || fb_fill_park) || d_fb_flush) || fb_flush_pend);
	reg [63:0] d_wdata;
	reg [7:0] d_be;
	reg d_done;
	wire d_rd_valid;
	wire [63:0] d_rdata;
	reg [63:0] d_fwd;
	reg [15:0] d_fwd_beat;
	reg d_fwd_v;
	reg [3:0] df_mask;
	reg [63:0] df_data;
	reg [15:0] df_beat;
	localparam [2:0] D_IDLE = 3'd0;
	localparam [2:0] D_RD = 3'd1;
	localparam [2:0] D_MRG = 3'd2;
	localparam [2:0] D_WR = 3'd3;
	localparam [2:0] D_WRB = 3'd4;
	reg [2:0] dst;
	localparam [3:0] RB_MAX = 4'd8;
	localparam DPARTBURST = D_SHADOW_RMW_BYPASS;
	reg [63:0] rb_data [0:7];
	reg [15:0] rb_base;
	(* preserve *) reg [15:0] bsn_rb_base_q;
	reg [3:0] rb_cnt;
	reg [7:0] rb_idle;
	reg [7:0] d_blen;
	reg [3:0] wstream_idx;
	generate
		if (D_WRITE_FIFO) begin : g_fbq_busy
			assign d_busy = ((fbq_busy || (dst != D_IDLE)) || (wc_mask != 4'd0)) || (rb_cnt != 4'd0);
		end
		else begin : g_legacy_busy
			assign d_busy = ((dst != D_IDLE) || (wc_mask != 4'd0)) || (rb_cnt != 4'd0);
		end
	endgenerate
	function automatic [63:0] d_lane_merge;
		input [63:0] base;
		input [63:0] neu;
		input [3:0] m;
		d_lane_merge = {(m[3] ? neu[63:48] : base[63:48]), (m[2] ? neu[47:32] : base[47:32]), (m[1] ? neu[31:16] : base[31:16]), (m[0] ? neu[15:0] : base[15:0])};
	endfunction
	wire [63:0] d_ownmerge = d_lane_merge(d_fwd, wc_data, wc_mask);
	wire [63:0] d_wbmerge = d_lane_merge(wb_data, wc_data, wc_mask);
	wire fbeat_full = wc_mask == 4'hf;
	wire rb_ext = ((rb_cnt != 4'd0) && (rb_cnt < RB_MAX)) && (wc_beat == (rb_base + {12'd0, rb_cnt}));
	wire rb_accepts_df = (rb_cnt == 4'd0) || ((rb_cnt < RB_MAX) && (df_beat == (rb_base + {12'd0, rb_cnt})));
	wire d_want_fire = ((rb_cnt != 4'd0) && d_flush_req) && (fbeat_full ? !rb_ext : !DPARTBURST || !rb_ext);
	wire flush_now = (dst == D_IDLE) && d_flush_req;
	wire accept = (((fb_req && !d_ingress_park) && !fb_fill_park) && ((wc_mask == 4'd0) || fb_same)) && !flush_now;
	always @(*) begin
		if (_sv2v_0)
			;
		d_fb_ack = (D_WRITE_FIFO ? accept : d_fb_ack_q);
	end
	always @(*) begin
		if (_sv2v_0)
			;
		dsrcwt_data_next = d_wdata;
		if (dst == D_IDLE) begin
			if (fbeat_full)
				dsrcwt_data_next = wc_data;
			else if (wb_v && (wb_addr == {10'd0, wc_beat}))
				dsrcwt_data_next = d_wbmerge;
			else if (d_fwd_v && (d_fwd_beat == wc_beat))
				dsrcwt_data_next = d_ownmerge;
		end
	end
	always @(posedge clk)
		if (rst) begin
			wc_beat <= 16'd0;
			wc_mask <= 4'd0;
			wc_data <= 64'd0;
			wc_idle <= 8'd0;
			cmb_fb_we_d <= 1'b0;
			fb_pend <= 1'b0;
			fb_flush_pend <= 1'b0;
			d_fb_ack_q <= 1'b0;
			d_start <= 1'b0;
			d_wr <= 1'b0;
			d_addr <= 26'd0;
			d_wdata <= 64'd0;
			d_be <= 8'd0;
			d_fwd <= 64'd0;
			d_fwd_beat <= 16'd0;
			d_fwd_v <= 1'b0;
			df_mask <= 4'd0;
			df_data <= 64'd0;
			df_beat <= 16'd0;
			dst <= D_IDLE;
			dwt_req <= 1'b0;
			dwt_col <= 7'd0;
			dwt_data <= 64'd0;
			dsrcwt_req <= 1'b0;
			dsrcwt_idx <= 8'd0;
			dsrcwt_data <= 64'd0;
			rb_base <= 16'd0;
			bsn_rb_base_q <= 16'd0;
			rb_cnt <= 4'd0;
			rb_idle <= 8'd0;
			d_blen <= 8'd0;
			d_is_burst <= 1'b0;
			d_add <= 1'b0;
			d_add_beat <= 16'd0;
		end
		else begin
			d_fb_ack_q <= 1'b0;
			cmb_fb_we_d <= d_fb_we;
			dwt_req <= 1'b0;
			dsrcwt_req <= 1'b0;
			dsrcwt_data <= dsrcwt_data_next;
			d_add <= 1'b0;
			if (srt_invalidate_evt)
				d_fwd_v <= 1'b0;
			if (D_WRITE_FIFO && d_fb_flush)
				fb_flush_pend <= 1'b1;
			else if ((((fb_flush_pend && (wc_mask == 4'd0)) && (rb_cnt == 4'd0)) && (dst != D_RD)) && (dst != D_MRG))
				fb_flush_pend <= 1'b0;
			if (((c_start && c_wr) && d_fwd_v) && (d_fwd_beat[15:7] == c_addr[15:7]))
				d_fwd_v <= 1'b0;
			if ((wc_mask != 4'd0) && (wc_idle != 8'hff))
				wc_idle <= wc_idle + 8'd1;
			if ((rb_cnt != 4'd0) && (rb_idle != 8'hff))
				rb_idle <= rb_idle + 8'd1;
			if (accept) begin
				fb_pend <= 1'b0;
				wc_beat <= fb_beat;
				wc_mask[d_fb_addr[1:0]] <= 1'b1;
				wc_data[d_fb_addr[1:0] * 16+:16] <= d_fb_wdata;
				d_fb_ack_q <= 1'b1;
				wc_idle <= 8'd0;
			end
			else if (fb_new)
				fb_pend <= 1'b1;
			if (dst == D_IDLE) begin
				if ((rb_cnt != 4'd0) && (((((((d_owner_final || b_drain_final) || fb_fill_park) || (rb_cnt == RB_MAX)) || (rb_idle >= FB_WFLUSH_IDLE)) || d_want_fire) || d_fb_flush) || fb_flush_pend)) begin
					d_addr <= {10'd0, rb_base};
					d_blen <= {4'd0, rb_cnt};
					d_wr <= 1'b1;
					d_start <= 1'b1;
					d_is_burst <= 1'b1;
					dst <= D_WRB;
					rb_cnt <= 4'd0;
					rb_idle <= 8'd0;
					d_fwd_v <= 1'b0;
				end
				else if (d_flush_req) begin
					if (fbeat_full) begin
						if (rb_cnt == 4'd0) begin
							rb_base <= wc_beat;
							bsn_rb_base_q <= wc_beat;
						end
						rb_data[rb_cnt] <= wc_data;
						rb_cnt <= rb_cnt + 4'd1;
						rb_idle <= 8'd0;
						wc_mask <= 4'd0;
						d_add <= 1'b1;
						d_add_beat <= wc_beat;
						dwt_req <= rc_valid && (wc_beat[15:7] == rc_row);
						dwt_col <= wc_beat[6:0];
						dwt_data <= wc_data;
						dsrcwt_req <= (wc_beat[15:7] == 9'd510) || (wc_beat[15:7] == 9'd511);
						dsrcwt_idx <= {wc_beat[15:7] == 9'd511, wc_beat[6:0]};
						d_fwd_v <= 1'b0;
					end
					else if (wb_v && (wb_addr == {10'd0, wc_beat})) begin
						df_mask <= wc_mask;
						df_data <= wc_data;
						df_beat <= wc_beat;
						wc_mask <= 4'd0;
						d_wdata <= d_wbmerge;
						d_addr <= {10'd0, wc_beat};
						d_be <= 8'hff;
						d_wr <= 1'b1;
						d_start <= 1'b1;
						d_is_burst <= 1'b0;
						dst <= D_WR;
						d_fwd <= d_wbmerge;
						d_fwd_beat <= wc_beat;
						d_fwd_v <= 1'b1;
						dwt_req <= rc_valid && (wc_beat[15:7] == rc_row);
						dwt_col <= wc_beat[6:0];
						dwt_data <= d_wbmerge;
						dsrcwt_req <= (wc_beat[15:7] == 9'd510) || (wc_beat[15:7] == 9'd511);
						dsrcwt_idx <= {wc_beat[15:7] == 9'd511, wc_beat[6:0]};
					end
					else if (d_fwd_v && (d_fwd_beat == wc_beat)) begin
						df_mask <= wc_mask;
						df_data <= wc_data;
						df_beat <= wc_beat;
						wc_mask <= 4'd0;
						d_wdata <= d_ownmerge;
						d_addr <= {10'd0, wc_beat};
						d_be <= 8'hff;
						d_wr <= 1'b1;
						d_start <= 1'b1;
						d_is_burst <= 1'b0;
						dst <= D_WR;
						d_fwd <= d_ownmerge;
						d_fwd_beat <= wc_beat;
						dwt_req <= rc_valid && (wc_beat[15:7] == rc_row);
						dwt_col <= wc_beat[6:0];
						dwt_data <= d_ownmerge;
						dsrcwt_req <= (wc_beat[15:7] == 9'd510) || (wc_beat[15:7] == 9'd511);
						dsrcwt_idx <= {wc_beat[15:7] == 9'd511, wc_beat[6:0]};
					end
					else begin
						df_mask <= wc_mask;
						df_data <= wc_data;
						df_beat <= wc_beat;
						wc_mask <= 4'd0;
						d_addr <= {10'd0, wc_beat};
						d_wr <= 1'b0;
						d_start <= 1'b1;
						d_is_burst <= 1'b0;
						dst <= D_RD;
					end
				end
			end
			case (dst)
				D_RD:
					if (d_shadow_bypass) begin
						d_wdata <= d_lane_merge(shw_rsp_data_q, df_data, df_mask);
						d_start <= 1'b0;
						dst <= D_MRG;
					end
					else begin
						if (d_rd_valid)
							d_wdata <= d_lane_merge((shw_en && shw_base_hit ? shw_base : d_rdata), df_data, df_mask);
						if (d_done) begin
							d_start <= 1'b0;
							dst <= D_MRG;
						end
					end
				D_MRG:
					if (DPARTBURST) begin
						if (rb_cnt == 4'd0) begin
							rb_base <= df_beat;
							bsn_rb_base_q <= df_beat;
						end
						rb_data[rb_cnt] <= d_wdata;
						rb_cnt <= rb_cnt + 4'd1;
						rb_idle <= 8'd0;
						d_start <= 1'b0;
						d_wr <= 1'b0;
						d_is_burst <= 1'b0;
						dst <= D_IDLE;
						d_add <= 1'b1;
						d_add_beat <= df_beat;
						dwt_req <= rc_valid && (df_beat[15:7] == rc_row);
						dwt_col <= df_beat[6:0];
						dwt_data <= d_wdata;
						dsrcwt_req <= (df_beat[15:7] == 9'd510) || (df_beat[15:7] == 9'd511);
						dsrcwt_idx <= {df_beat[15:7] == 9'd511, df_beat[6:0]};
						d_fwd <= d_wdata;
						d_fwd_beat <= df_beat;
						d_fwd_v <= 1'b1;
					end
					else begin
						d_addr <= {10'd0, df_beat};
						d_be <= 8'hff;
						d_wr <= 1'b1;
						d_start <= 1'b1;
						d_fwd <= d_wdata;
						d_fwd_beat <= df_beat;
						d_fwd_v <= 1'b1;
						dwt_req <= rc_valid && (df_beat[15:7] == rc_row);
						dwt_col <= df_beat[6:0];
						dwt_data <= d_wdata;
						dsrcwt_req <= (df_beat[15:7] == 9'd510) || (df_beat[15:7] == 9'd511);
						dsrcwt_idx <= {df_beat[15:7] == 9'd511, df_beat[6:0]};
						dst <= D_WR;
					end
				D_WR:
					if (d_done) begin
						d_start <= 1'b0;
						d_wr <= 1'b0;
						d_is_burst <= 1'b0;
						dst <= D_IDLE;
					end
				D_WRB:
					if (d_done) begin
						d_start <= 1'b0;
						d_wr <= 1'b0;
						d_is_burst <= 1'b0;
						dst <= D_IDLE;
					end
				default:
					;
			endcase
		end
	wire [15:0] bfill_bt = bfill_bt_q;
	wire [15:0] bfill_bt_rb = bfill_bt_rb_q;
	wire [15:0] bsn_bstoff = bfill_bt_rb - d_addr[15:0];
	wire bsn_burst = ((d_start && d_wr) && d_is_burst) && ({8'd0, bsn_bstoff} < {16'd0, d_blen});
	wire bsn_single = ((d_start && d_wr) && !d_is_burst) && (d_addr[15:0] == bfill_bt);
	wire bsn_rmwjob = ((dst == D_RD) || (dst == D_MRG)) && (df_beat == bfill_bt);
	wire [15:0] bsn_rboff = bfill_bt_rb - bsn_rb_base_q;
	wire bsn_rbacc = ((rb_cnt != 4'd0) && ({12'd0, bsn_rboff[3:0]} < {12'd0, rb_cnt})) && (bsn_rboff[15:4] == 12'd0);
	wire bsn_dfwd = d_fwd_v && (d_fwd_beat == bfill_bt);
	wire bsn_wb = wb_v && (wb_addr[15:0] == bfill_bt);
	wire bsn_rb = bsn_rbacc || bsn_burst;
	wire [2:0] bsn_rboff3 = (bsn_rbacc ? bsn_rboff[2:0] : bsn_bstoff[2:0]);
	wire [63:0] bsn_rbpick = rb_data[bsn_rboff3];
	wire bsn_wc = (wc_mask != 4'd0) && (wc_beat == bfill_bt);
	wire [2:0] bsn_sel = (bsn_single ? 3'd4 : (bsn_rb ? 3'd3 : (bsn_wb ? 3'd2 : (bsn_dfwd ? 3'd1 : 3'd0))));
	reg [63:0] bfill_base;
	always @(*) begin
		if (_sv2v_0)
			;
		case (bsn_sel)
			3'd4: bfill_base = d_wdata;
			3'd3: bfill_base = bsn_rbpick;
			3'd2: bfill_base = wb_data;
			3'd1: bfill_base = d_fwd;
			default: bfill_base = b_rdata;
		endcase
	end
	wire [3:0] bsn_dfm = (bsn_rmwjob ? df_mask : 4'd0);
	wire [3:0] bsn_wcm = (bsn_wc ? wc_mask : 4'd0);
	function automatic [15:0] bsn_lane;
		input [15:0] wcd;
		input [15:0] dfd;
		input [15:0] bas;
		input w;
		input d;
		bsn_lane = (w ? wcd : (d ? dfd : bas));
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		bfill_merged = {bsn_lane(wc_data[63:48], df_data[63:48], bfill_base[63:48], bsn_wcm[3], bsn_dfm[3]), bsn_lane(wc_data[47:32], df_data[47:32], bfill_base[47:32], bsn_wcm[2], bsn_dfm[2]), bsn_lane(wc_data[31:16], df_data[31:16], bfill_base[31:16], bsn_wcm[1], bsn_dfm[1]), bsn_lane(wc_data[15:0], df_data[15:0], bfill_base[15:0], bsn_wcm[0], bsn_dfm[0])};
	end
	localparam [7:0] SRT_CHUNK = 8'd16;
	(* ramstyle = "M10K" *) reg [63:0] srt_mem [0:255];
	reg [63:0] srt_stage [0:15];
	reg [63:0] srt_mem_q;
	reg [7:0] srt_mem_ra;
	reg [7:0] srt_beat;
	reg [7:0] srt_rcv;
	reg [4:0] srt_stage_cnt;
	reg [15:0] srt_base_beat;
	reg [15:0] srt_first;
	reg srt_buf_valid;
	reg srt_armed;
	reg [3:0] e_stream_idx;
	localparam [2:0] E_IDLE = 3'd0;
	localparam [2:0] E_RD_REQ = 3'd1;
	localparam [2:0] E_RD_RCV = 3'd2;
	localparam [2:0] E_STAGE = 3'd3;
	localparam [2:0] E_WR_WAIT = 3'd4;
	reg [2:0] ets;
	wire [17:0] srt_req_entry = {widx[16:0], boff[3]};
	wire [7:0] srt_chunk_len = SRT_CHUNK;
	assign srt_claim = srt_busy || (req && srt_i);
	assign srt_store_atomic = srt_busy && srt_store_q;
	assign srt_invalidate_evt = srt_done && srt_store_q;
	wire [7:0] srt_next_beat = srt_beat + SRT_CHUNK;
	wire e_is_burst = e_start && e_wr;
	wire [63:0] e_wdata = srt_stage[e_stream_idx];
	always @(posedge clk) begin
		srt_mem_q <= srt_mem[srt_mem_ra];
		if (rst) begin
			ets <= E_IDLE;
			srt_busy <= 1'b0;
			srt_done <= 1'b0;
			srt_rdata <= 32'd0;
			srt_buf_valid <= 1'b0;
			srt_store_q <= 1'b0;
			srt_beat <= 8'd0;
			srt_rcv <= 8'd0;
			srt_armed <= 1'b1;
			srt_stage_cnt <= 5'd0;
			srt_base_beat <= 16'd0;
			srt_first <= 16'd0;
			srt_mem_ra <= 8'd0;
			e_start <= 1'b0;
			e_wr <= 1'b0;
			e_addr <= 26'd0;
			e_burstlen <= SRT_CHUNK;
		end
		else begin
			srt_done <= 1'b0;
			if (!req || !srt_i)
				srt_armed <= 1'b1;
			case (ets)
				E_IDLE: begin
					e_start <= 1'b0;
					if ((req && srt_i) && srt_armed) begin
						srt_armed <= 1'b0;
						srt_busy <= 1'b1;
						srt_store_q <= we;
						srt_beat <= 8'd0;
						srt_base_beat <= srt_req_entry[17:2];
						if (we) begin
							srt_mem_ra <= 8'd0;
							srt_stage_cnt <= 5'd0;
							ets <= E_STAGE;
						end
						else
							ets <= E_RD_REQ;
					end
				end
				E_RD_REQ: begin
					e_addr <= {10'd0, srt_base_beat + {8'd0, srt_beat}};
					e_burstlen <= srt_chunk_len;
					e_wr <= 1'b0;
					e_start <= 1'b1;
					srt_rcv <= 8'd0;
					ets <= E_RD_RCV;
				end
				E_RD_RCV: begin
					if (e_rd_valid) begin
						srt_mem[srt_beat + srt_rcv] <= e_rdata;
						if ((srt_beat == 8'd0) && (srt_rcv == 8'd0))
							srt_first <= e_rdata[15:0];
						srt_rcv <= srt_rcv + 8'd1;
					end
					if (e_done) begin
						e_start <= 1'b0;
						if (srt_next_beat == 8'd0) begin
							srt_buf_valid <= 1'b1;
							srt_busy <= 1'b0;
							srt_rdata <= {16'h0000, srt_first};
							srt_done <= 1'b1;
							ets <= E_IDLE;
						end
						else begin
							srt_beat <= srt_next_beat;
							ets <= E_RD_REQ;
						end
					end
				end
				E_STAGE:
					if (srt_stage_cnt == 5'd0) begin
						srt_mem_ra <= srt_beat + 8'd1;
						srt_stage_cnt <= 5'd1;
					end
					else begin
						srt_stage[srt_stage_cnt[3:0] - 4'd1] <= srt_mem_q;
						if (srt_stage_cnt == 5'd16) begin
							e_addr <= {10'd0, srt_base_beat + {8'd0, srt_beat}};
							e_burstlen <= srt_chunk_len;
							e_wr <= 1'b1;
							e_start <= 1'b1;
							ets <= E_WR_WAIT;
						end
						else begin
							srt_mem_ra <= (srt_beat + {3'd0, srt_stage_cnt}) + 8'd1;
							srt_stage_cnt <= srt_stage_cnt + 5'd1;
						end
					end
				E_WR_WAIT:
					if (e_done) begin
						e_start <= 1'b0;
						if (srt_next_beat == 8'd0) begin
							srt_busy <= 1'b0;
							srt_rdata <= 32'd0;
							srt_done <= 1'b1;
							ets <= E_IDLE;
						end
						else begin
							srt_beat <= srt_next_beat;
							srt_mem_ra <= srt_next_beat;
							srt_stage_cnt <= 5'd0;
							ets <= E_STAGE;
						end
					end
				default: ets <= E_IDLE;
			endcase
		end
	end
	reg tst_wr_req;
	reg tst_rd_req;
	reg [25:0] tst_addr;
	reg [63:0] tst_wdata_lat;
	wire [63:0] tst_rdata;
	wire [63:0] tst_wdata;
	wire tst_wnext;
	wire d_burst_next;
	reg [7:0] tst_be;
	reg [7:0] tst_burstcnt;
	wire tst_rd_valid;
	reg [2:0] l_gnt;
	localparam [2:0] L_IDLE = 3'd0;
	localparam [2:0] L_ISSUE = 3'd1;
	localparam [2:0] L_ACCEPT = 3'd2;
	localparam [2:0] L_RUN = 3'd3;
	localparam [2:0] L_DONE = 3'd4;
	reg [3:0] pub_dirty;
	reg [15:0] pub_addr [0:3];
	reg [63:0] pub_expect [0:3];
	reg [1:0] pub_page;
	reg l_proof;
	wire tst_wr_done;
	wire [25:0] tst_wr_base;
	wire [7:0] tst_wr_count;
	wire [63:0] tst_wr_last_data;
	wire [15:0] pub_ret_base = tst_wr_base[15:0];
	wire [15:0] pub_ret_last = (tst_wr_base[15:0] + {8'd0, tst_wr_count}) - 16'd1;
	wire [3:0] pub_ret_mask = (4'b0001 << pub_ret_base[15:14]) | (4'b0001 << pub_ret_last[15:14]);
	wire pub_hold = tst_wr_done;
	wire pub_match_evt;
	localparam signed [31:0] PG_WINDOW = 2047;
	reg [15:0] pg_base [0:3];
	reg [15:0] pg_last [0:3];
	reg [10:0] pg_age [0:3];
	reg [1:0] pg_wr;
	integer pge;
	function automatic signed [10:0] sv2v_cast_11_signed;
		input reg signed [10:0] inp;
		sv2v_cast_11_signed = inp;
	endfunction
	always @(posedge clk)
		if (sdram_por) begin
			for (pge = 0; pge < 4; pge = pge + 1)
				begin
					pg_base[pge] <= 16'd0;
					pg_last[pge] <= 16'd0;
					pg_age[pge] <= 11'd0;
				end
			pg_wr <= 2'd0;
		end
		else begin
			for (pge = 0; pge < 4; pge = pge + 1)
				if (pg_age[pge] != 11'd0)
					pg_age[pge] <= pg_age[pge] - 11'd1;
			if (tst_wr_done) begin
				pg_base[pg_wr] <= pub_ret_base;
				pg_last[pg_wr] <= pub_ret_last;
				pg_age[pg_wr] <= sv2v_cast_11_signed(PG_WINDOW);
				pg_wr <= pg_wr + 2'd1;
			end
		end
	reg [7:0] shw_cnt;
	wire [15:0] shw_wa = tst_addr[15:0] + {8'd0, shw_cnt};
	wire shw_write_evt = tst_wr_done || tst_wnext;
	always @(posedge clk)
		if (sdram_por) begin
			shw_cnt <= 8'd0;
			shw_epoch <= 2'd0;
		end
		else begin
			if (tst_wr_req)
				shw_cnt <= 8'd0;
			if (tst_wnext)
				shw_cnt <= shw_cnt + 8'd1;
			if (shw_write_evt)
				shw_epoch <= shw_epoch + 2'd1;
			if (tst_wr_done)
				shw_mem[{pub_ret_last[11:7], pub_ret_last[5:0]}] <= {shw_generation, 1'b1, pub_ret_last[15:12], pub_ret_last[6], tst_wr_last_data};
			else if (tst_wnext)
				shw_mem[{shw_wa[11:7], shw_wa[5:0]}] <= {shw_generation, 1'b1, shw_wa[15:12], shw_wa[6], tst_wdata};
		end
	generate
		if (!D_WRITE_FIFO) begin : g_shw_legacy_valid
			always @(posedge clk)
				if (sdram_por)
					shw_valid <= 1'sb0;
				else if (tst_wr_done)
					shw_valid[{pub_ret_last[11:7], pub_ret_last[5:0]}] <= 1'b1;
				else if (tst_wnext)
					shw_valid[{shw_wa[11:7], shw_wa[5:0]}] <= 1'b1;
		end
	endgenerate
	assign d_shadow_bypass_en = D_SHADOW_RMW_BYPASS;
	assign d_shadow_lookup = ((d_shadow_bypass_en && d_start) && !d_wr) && !d_is_burst;
	wire [15:0] shw_cand = (a_start ? a_addr[15:0] : d_addr[15:0]);
	always @(posedge clk) begin
		shw_q <= shw_mem[{shw_cand[11:7], shw_cand[5:0]}];
		shw_cand_q <= shw_cand;
		if (sdram_por)
			shw_read_epoch_q <= 2'd0;
		else
			shw_read_epoch_q <= shw_epoch;
	end
	generate
		if (D_WRITE_FIFO) begin : g_shw_generation_valid
			always @(posedge clk) shw_v_q <= 1'b1;
		end
		else begin : g_shw_vector_valid
			always @(posedge clk) shw_v_q <= shw_valid[{shw_cand[11:7], shw_cand[5:0]}];
		end
	endgenerate
	always @(posedge clk)
		if (sdram_por) begin
			shw_rsp_data_q <= 64'd0;
			shw_rsp_cand_q <= 16'd0;
			shw_rsp_hit_q <= 1'b0;
			shw_rsp_epoch_q <= 2'd0;
		end
		else begin
			shw_rsp_data_q <= shw_q[63:0];
			shw_rsp_cand_q <= shw_cand_q;
			shw_rsp_hit_q <= ((shw_v_q && (!D_WRITE_FIFO || (shw_q[77:70] == shw_generation))) && shw_q[69]) && (shw_q[68:64] == {shw_cand_q[15:12], shw_cand_q[6]});
			shw_rsp_epoch_q <= shw_read_epoch_q;
		end
	function automatic pg_overlap;
		input reg [15:0] lo;
		input reg [15:0] hi;
		pg_overlap = ((((pg_age[0] != 11'd0) && !((hi < pg_base[0]) || (lo > pg_last[0]))) || ((pg_age[1] != 11'd0) && !((hi < pg_base[1]) || (lo > pg_last[1])))) || ((pg_age[2] != 11'd0) && !((hi < pg_base[2]) || (lo > pg_last[2])))) || ((pg_age[3] != 11'd0) && !((hi < pg_base[3]) || (lo > pg_last[3])));
	endfunction
	wire shw_rsp_fresh = shw_rsp_epoch_q == shw_epoch;
	wire a_shw_hit = (shw_rsp_fresh && shw_rsp_hit_q) && (shw_rsp_cand_q == a_addr[15:0]);
	wire d_shw_hit = (shw_rsp_fresh && shw_rsp_hit_q) && (shw_rsp_cand_q == d_addr[15:0]);
	wire a_lkp_cur = shw_rsp_fresh && (shw_rsp_cand_q == a_addr[15:0]);
	wire d_lkp_cur = shw_rsp_fresh && (shw_rsp_cand_q == d_addr[15:0]);
	assign d_shadow_bypass = (d_shadow_lookup && d_lkp_cur) && d_shw_hit;
	wire pub_fence_en = 1'b1;
	wire a_pub_hazard = ((pg_overlap(a_addr[15:0], a_addr[15:0]) && !a_shw_hit) || tst_wr_done) || !a_lkp_cur;
	wire d_pub_hazard = ((pg_overlap(d_addr[15:0], d_addr[15:0]) && !d_shw_hit) || tst_wr_done) || !d_lkp_cur;
	wire c_pub_hazard = pg_overlap(c_addr[15:0], (c_addr[15:0] + {8'd0, c_burstlen}) - 16'd1) || tst_wr_done;
	integer pgi;
	always @(posedge clk)
		if (sdram_por) begin
			pub_dirty <= 4'b0000;
			for (pgi = 0; pgi < 4; pgi = pgi + 1)
				begin
					pub_addr[pgi] <= 16'd0;
					pub_expect[pgi] <= 64'd0;
				end
		end
		else begin
			if (pub_match_evt)
				pub_dirty[pub_page] <= 1'b0;
			if (tst_wr_done) begin
				for (pgi = 0; pgi < 4; pgi = pgi + 1)
					if (pub_dirty[pgi] || pub_ret_mask[pgi]) begin
						pub_dirty[pgi] <= 1'b1;
						pub_addr[pgi] <= pub_ret_last;
						pub_expect[pgi] <= tst_wr_last_data;
					end
			end
		end
	wire e_burst_next = ((l_gnt == 3'd4) && (ls == L_RUN)) && tst_wnext;
	assign tst_wdata = ((l_gnt == 3'd4) && e_is_burst ? e_wdata : ((l_gnt == 3'd3) && d_is_burst ? rb_data[wstream_idx] : ((l_gnt == 3'd2) && c_is_burst ? cb_data[wstream_idx] : tst_wdata_lat)));
	assign d_burst_next = ((((l_gnt == 3'd3) && d_is_burst) || ((l_gnt == 3'd2) && c_is_burst)) && (ls == L_RUN)) && tst_wnext;
	localparam [0:0] C_FAIR_EN = C_FAIR;
	always @(posedge clk)
		if (rst)
			c_wait <= 16'd0;
		else if (!c_start)
			c_wait <= 16'd0;
		else if ((ls == L_ISSUE) && (l_gnt == 3'd2))
			c_wait <= 16'd0;
		else if ((ls == L_IDLE) && (c_wait != 16'hffff))
			c_wait <= c_wait + 16'd1;
	assign c_urgent = C_FAIR_EN && (c_wait >= C_FAIR_AGE[15:0]);
	always @(posedge clk)
		if (rst) begin
			ls <= L_IDLE;
			l_gnt <= 3'd0;
			tst_rd_req <= 1'b0;
			tst_wr_req <= 1'b0;
			tst_addr <= 26'd0;
			tst_wdata_lat <= 64'd0;
			tst_be <= 8'd0;
			tst_burstcnt <= 8'd1;
			a_done <= 1'b0;
			b_done <= 1'b0;
			c_done <= 1'b0;
			d_done <= 1'b0;
			e_done <= 1'b0;
			wstream_idx <= 4'd0;
			e_stream_idx <= 4'd0;
			l_proof <= 1'b0;
			pub_page <= 2'd0;
		end
		else begin
			tst_rd_req <= 1'b0;
			tst_wr_req <= 1'b0;
			a_done <= 1'b0;
			b_done <= 1'b0;
			c_done <= 1'b0;
			d_done <= 1'b0;
			e_done <= 1'b0;
			if (d_burst_next)
				wstream_idx <= wstream_idx + 4'd1;
			if (e_burst_next)
				e_stream_idx <= e_stream_idx + 4'd1;
			case (ls)
				L_IDLE:
					if (!tst_busy) begin
						if (srt_store_atomic) begin
							if (((((e_start && !d_busy) && !beat_pending) && (ats == A_IDLE)) && !a_start) && !wb_v) begin
								l_gnt <= 3'd4;
								l_proof <= 1'b0;
								ls <= L_ISSUE;
							end
						end
						else if (b_start) begin
							if (((!BSNOOP || b_fifo_fenced) && pub_fence_en) && pub_hold)
								;
							else if (((!BSNOOP || b_fifo_fenced) && pub_fence_en) && pub_dirty[b_addr[15:14]]) begin
								l_gnt <= 3'd1;
								l_proof <= 1'b1;
								pub_page <= b_addr[15:14];
								ls <= L_ISSUE;
							end
							else begin
								l_gnt <= 3'd1;
								l_proof <= 1'b0;
								ls <= L_ISSUE;
							end
						end
						else if (b_bus_lock)
							;
						else if (((((e_start && !d_busy) && !beat_pending) && (ats == A_IDLE)) && !a_start) && !wb_v) begin
							if ((!e_wr && pub_fence_en) && pub_hold)
								;
							else if ((!e_wr && pub_fence_en) && pub_dirty[e_addr[15:14]]) begin
								l_gnt <= 3'd4;
								l_proof <= 1'b1;
								pub_page <= e_addr[15:14];
								ls <= L_ISSUE;
							end
							else begin
								l_gnt <= 3'd4;
								l_proof <= 1'b0;
								ls <= L_ISSUE;
							end
						end
						else if ((((c_urgent && c_start) && !srt_claim) && (!D_WRITE_FIFO || (!d_busy && !beat_pending))) && !(!c_wr && c_pub_hazard)) begin
							l_gnt <= 3'd2;
							l_proof <= 1'b0;
							ls <= L_ISSUE;
						end
						else if ((a_start && !d_busy) && !beat_pending) begin
							if (!a_wr && a_pub_hazard)
								;
							else begin
								l_gnt <= 3'd0;
								l_proof <= 1'b0;
								ls <= L_ISSUE;
							end
						end
						else if (d_start) begin
							if (d_shadow_lookup && !d_lkp_cur)
								;
							else if (d_shadow_bypass)
								;
							else if ((!d_wr && !d_is_burst) && d_pub_hazard)
								;
							else begin
								l_gnt <= 3'd3;
								l_proof <= 1'b0;
								ls <= L_ISSUE;
							end
						end
						else if ((c_start && !srt_claim) && (!D_WRITE_FIFO || (!d_busy && !beat_pending))) begin
							if (!c_wr && c_pub_hazard)
								;
							else begin
								l_gnt <= 3'd2;
								l_proof <= 1'b0;
								ls <= L_ISSUE;
							end
						end
					end
				L_ISSUE:
					if (!tst_busy) begin
						case (l_gnt)
							3'd1: begin
								if (l_proof) begin
									tst_addr <= {10'd0, pub_addr[pub_page]};
									tst_burstcnt <= 8'd1;
								end
								else begin
									tst_addr <= b_addr;
									tst_burstcnt <= b_burstlen;
								end
								tst_rd_req <= 1'b1;
							end
							3'd0: begin
								tst_addr <= a_addr;
								tst_burstcnt <= 8'd1;
								if (a_wr) begin
									tst_wdata_lat <= a_wdata;
									tst_be <= a_be;
									tst_wr_req <= 1'b1;
								end
								else begin
									tst_rd_req <= 1'b1;
									shw_base <= shw_rsp_data_q;
									shw_base_hit <= a_shw_hit === 1'b1;
								end
							end
							3'd3: begin
								tst_addr <= d_addr;
								if (d_is_burst) begin
									tst_burstcnt <= d_blen;
									tst_be <= 8'hff;
									tst_wr_req <= 1'b1;
									wstream_idx <= 4'd0;
								end
								else begin
									tst_burstcnt <= 8'd1;
									if (d_wr) begin
										tst_wdata_lat <= d_wdata;
										tst_be <= d_be;
										tst_wr_req <= 1'b1;
									end
									else begin
										tst_rd_req <= 1'b1;
										shw_base <= shw_rsp_data_q;
										shw_base_hit <= d_shw_hit === 1'b1;
									end
								end
							end
							3'd4:
								if (l_proof) begin
									tst_addr <= {10'd0, pub_addr[pub_page]};
									tst_burstcnt <= 8'd1;
									tst_rd_req <= 1'b1;
								end
								else begin
									tst_addr <= e_addr;
									tst_burstcnt <= e_burstlen;
									if (e_wr) begin
										tst_be <= 8'hff;
										tst_wr_req <= 1'b1;
										e_stream_idx <= 4'd0;
									end
									else
										tst_rd_req <= 1'b1;
								end
							default: begin
								tst_addr <= c_addr;
								tst_burstcnt <= c_burstlen;
								if (c_wr) begin
									tst_be <= 8'hff;
									tst_wr_req <= 1'b1;
									wstream_idx <= 4'd0;
								end
								else
									tst_rd_req <= 1'b1;
							end
						endcase
						ls <= L_ACCEPT;
					end
				L_ACCEPT:
					if (tst_busy)
						ls <= L_RUN;
				L_RUN:
					if (!tst_busy) begin
						if (!l_proof)
							case (l_gnt)
								3'd1: b_done <= 1'b1;
								3'd2: c_done <= 1'b1;
								3'd3: d_done <= 1'b1;
								3'd4: e_done <= 1'b1;
								default: a_done <= 1'b1;
							endcase
						l_proof <= 1'b0;
						ls <= L_DONE;
					end
				L_DONE: ls <= L_IDLE;
				default: ls <= L_IDLE;
			endcase
		end
	assign a_rd_valid = (((l_gnt == 3'd0) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign b_rd_valid = (((l_gnt == 3'd1) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign c_rd_valid = (((l_gnt == 3'd2) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign d_rd_valid = (((l_gnt == 3'd3) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign e_rd_valid = (((l_gnt == 3'd4) && (ls == L_RUN)) && tst_rd_valid) && !l_proof;
	assign pub_match_evt = ((l_proof && (ls == L_RUN)) && tst_rd_valid) && (tst_rdata == pub_expect[pub_page]);
	assign a_rdata = tst_rdata;
	assign b_rdata = tst_rdata;
	assign c_rdata = tst_rdata;
	assign d_rdata = tst_rdata;
	assign e_rdata = tst_rdata;
	stv_vram_ddr_agent #(.VRAM_DDR_BASE(VRAM_DDR_BASE)) u_agent(
		.clk(clk),
		.sdram_por(sdram_por),
		.tst_wr_req(tst_wr_req),
		.tst_rd_req(tst_rd_req),
		.tst_addr(tst_addr),
		.tst_wdata(tst_wdata),
		.tst_be(tst_be),
		.tst_burstcnt(tst_burstcnt),
		.tst_rdata(tst_rdata),
		.tst_rd_valid(tst_rd_valid),
		.tst_busy(tst_busy),
		.tst_wnext(tst_wnext),
		.tst_wr_done(tst_wr_done),
		.tst_wr_base(tst_wr_base),
		.tst_wr_count(tst_wr_count),
		.tst_wr_last_data(tst_wr_last_data),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_memsys (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	src_req,
	src_addr,
	src_data,
	src_ack,
	inputs,
	int1,
	snd_select,
	snd_trig,
	snd_reset,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	blit_busy,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	cpu_gfx_rd,
	cpu_gfx_raddr,
	cpu_gfx_rdata,
	cpu_gfx_rack,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	parameter ROM_HEX = "smashtv_maindata.hex";
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output wire [31:0] mem_rdata;
	output wire mem_ack;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	input wire [63:0] inputs;
	output wire int1;
	output wire [7:0] snd_select;
	output wire snd_trig;
	output wire snd_reset;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	output wire blit_busy;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire cpu_gfx_rd;
	output wire [23:0] cpu_gfx_raddr;
	input wire [15:0] cpu_gfx_rdata;
	input wire cpu_gfx_rack;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output wire palv_we_a;
	output wire [12:0] palv_aa;
	output wire [15:0] palv_awd;
	output wire palv_we_b;
	output wire [12:0] palv_ba;
	output wire [15:0] palv_bwd;
	wire is_dma_now = mem_addr[31:20] == 12'h01a;
	wire mem_req_m;
	wire [31:0] mem_rdata_m;
	wire mem_ack_m;
	wire dma_reg_we;
	wire [3:0] dma_reg_addr;
	wire [15:0] dma_reg_wdata;
	wire [15:0] dma_reg_rdata;
	wire dma_fb_we;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	wire [17:0] dma_fb_addr;
	wire [15:0] dma_fb_wdata;
	wire [15:0] dma_palette;
	wire mem_fb_ack;
	wire dma_fb_ack = mem_fb_ack;
	wire mem_fb_busy;
	wire dma_fb_busy = mem_fb_busy;
	wire dma_fb_flush;
	yunit_mem #(.ROM_HEX(ROM_HEX)) u_mem(
		.clk(clk),
		.rst(rst),
		.mem_req(mem_req_m),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata_m),
		.mem_ack(mem_ack_m),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.dma_palette(dma_palette),
		.inputs(inputs),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.erase_start(erase_start),
		.erase_row0(erase_row0),
		.erase_lines(erase_lines),
		.erase_busy(erase_busy),
		.gfx_rd(cpu_gfx_rd),
		.gfx_raddr(cpu_gfx_raddr),
		.gfx_rdata(cpu_gfx_rdata),
		.gfx_rack(cpu_gfx_rack),
		.fb_ack(mem_fb_ack),
		.fb_busy(mem_fb_busy),
		.fb_flush(dma_fb_flush),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	yunit_dma u_dma(
		.clk(clk),
		.rst(rst),
		.reg_we(dma_reg_we),
		.reg_addr(dma_reg_addr),
		.reg_wdata(dma_reg_wdata),
		.reg_rdata(dma_reg_rdata),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.fb_ack(dma_fb_ack),
		.fb_busy(dma_fb_busy),
		.fb_flush(dma_fb_flush),
		.busy(blit_busy),
		.blit_irq(int1),
		.dma_palette(dma_palette)
	);
	reg [1:0] dstate;
	reg [31:0] d_addr_q;
	reg d_we_q;
	reg [31:0] d_wd_q;
	reg [5:0] d_sz_q;
	reg dma_ack;
	wire d_second = dstate == 2'd2;
	assign dma_reg_addr = (d_second ? d_addr_q[7:4] + 4'd1 : d_addr_q[7:4]);
	assign dma_reg_wdata = (d_second ? d_wd_q[31:16] : d_wd_q[15:0]);
	assign dbg_dma_we = dma_reg_we;
	assign dbg_dma_addr = dma_reg_addr;
	assign dbg_dma_wdata = dma_reg_wdata;
	assign dma_reg_we = (dstate == 2'd1) || (dstate == 2'd2);
	localparam signed [31:0] yunit_pkg_DMA_CMD_TRIG_BIT = 15;
	localparam [3:0] yunit_pkg_DMA_COMMAND = 4'd0;
	always @(posedge clk)
		if (rst) begin
			dstate <= 2'd0;
			dma_ack <= 1'b0;
		end
		else
			(* full_case, parallel_case *)
			case (dstate)
				2'd0: begin
					dma_ack <= 1'b0;
					if ((mem_req && is_dma_now) && !mem_ack) begin
						if (((mem_we && (mem_addr[7:4] == yunit_pkg_DMA_COMMAND)) && mem_wdata[yunit_pkg_DMA_CMD_TRIG_BIT]) && blit_busy)
							;
						else begin
							d_addr_q <= mem_addr;
							d_we_q <= mem_we;
							d_wd_q <= mem_wdata;
							d_sz_q <= mem_size;
							dstate <= (mem_we ? 2'd1 : 2'd3);
						end
					end
				end
				2'd1: dstate <= (d_sz_q > 6'd16 ? 2'd2 : 2'd3);
				2'd2: dstate <= 2'd3;
				2'd3: begin
					dma_ack <= 1'b1;
					dstate <= 2'd0;
				end
				default: dstate <= 2'd0;
			endcase
	assign mem_req_m = mem_req && !is_dma_now;
	assign mem_ack = (is_dma_now ? dma_ack : mem_ack_m);
	assign mem_rdata = (is_dma_now ? {16'h0000, dma_reg_rdata} : mem_rdata_m);
endmodule
`default_nettype wire
`default_nettype none
module yunit_video (
	clk,
	rst,
	ce_pix,
	vram_raddr,
	vram_rdata,
	pal_raddr,
	pal_rdata,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	vblank_irq
);
	reg _sv2v_0;
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter signed [31:0] DISP_ROW0 = 0;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	output wire [17:0] vram_raddr;
	input wire [15:0] vram_rdata;
	output wire [11:0] pal_raddr;
	input wire [15:0] pal_rdata;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output reg vblank_irq;
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	reg [11:0] hc;
	reg [11:0] vc;
	reg s0_de;
	reg s0_hs;
	reg s0_vs;
	reg s0_hb;
	reg s0_vb;
	reg [11:0] s0_x;
	reg [11:0] s0_y;
	always @(posedge clk)
		if (rst) begin
			hc <= 1'sb0;
			vc <= 1'sb0;
			vblank_irq <= 1'b0;
		end
		else if (ce_pix) begin
			vblank_irq <= 1'b0;
			if (hc == (H_TOTAL - 1)) begin
				hc <= 1'sb0;
				if (vc == (V_TOTAL - 1))
					vc <= 1'sb0;
				else begin
					vc <= vc + 12'd1;
					if (vc == (V_ACT - 1))
						vblank_irq <= 1'b1;
				end
			end
			else
				hc <= hc + 12'd1;
		end
	always @(*) begin
		if (_sv2v_0)
			;
		s0_x = hc;
		s0_y = vc;
		s0_de = (hc < H_ACT) && (vc < V_ACT);
		s0_hb = hc >= H_ACT;
		s0_vb = vc >= V_ACT;
		s0_hs = (hc >= (H_ACT + H_FP)) && (hc < ((H_ACT + H_FP) + H_SYNC));
		s0_vs = (vc >= (V_ACT + V_FP)) && (vc < ((V_ACT + V_FP) + V_SYNC));
	end
	localparam signed [31:0] yunit_pkg_FB_ROWSHIFT = 9;
	function automatic [17:0] sv2v_cast_18;
		input reg [17:0] inp;
		sv2v_cast_18 = inp;
	endfunction
	assign vram_raddr = sv2v_cast_18(((DISP_ROW0 + s0_y) << yunit_pkg_FB_ROWSHIFT) + (s0_x & 12'h1ff));
	reg s1_de;
	reg s1_hs;
	reg s1_vs;
	reg s1_hb;
	reg s1_vb;
	reg s2_de;
	reg s2_hs;
	reg s2_vs;
	reg s2_hb;
	reg s2_vb;
	always @(posedge clk)
		if (rst) begin
			s1_de <= 0;
			s1_hs <= 0;
			s1_vs <= 0;
			s1_hb <= 0;
			s1_vb <= 0;
			s2_de <= 0;
			s2_hs <= 0;
			s2_vs <= 0;
			s2_hb <= 0;
			s2_vb <= 0;
		end
		else if (ce_pix) begin
			s1_de <= s0_de;
			s1_hs <= s0_hs;
			s1_vs <= s0_vs;
			s1_hb <= s0_hb;
			s1_vb <= s0_vb;
			s2_de <= s1_de;
			s2_hs <= s1_hs;
			s2_vs <= s1_vs;
			s2_hb <= s1_hb;
			s2_vb <= s1_vb;
		end
	function automatic [11:0] yunit_pkg_pen_map6;
		input reg [15:0] w;
		yunit_pkg_pen_map6 = {w[11:8], w[15:14], w[5:0]};
	endfunction
	assign pal_raddr = yunit_pkg_pen_map6(vram_rdata);
	wire [23:0] rgb;
	function automatic [23:0] yunit_pkg_rgb555_to_888;
		input reg [15:0] c;
		reg [4:0] r5;
		reg [4:0] g5;
		reg [4:0] b5;
		begin
			r5 = c[14:10];
			g5 = c[9:5];
			b5 = c[4:0];
			yunit_pkg_rgb555_to_888 = {r5, r5[4:2], g5, g5[4:2], b5, b5[4:2]};
		end
	endfunction
	assign rgb = yunit_pkg_rgb555_to_888(pal_rdata);
	always @(posedge clk)
		if (rst) begin
			de <= 0;
			hsync <= 0;
			vsync <= 0;
			hblank <= 0;
			vblank <= 0;
			vid_r <= 0;
			vid_g <= 0;
			vid_b <= 0;
		end
		else if (ce_pix) begin
			de <= s2_de;
			hsync <= s2_hs;
			vsync <= s2_vs;
			hblank <= s2_hb;
			vblank <= s2_vb;
			vid_r <= (s2_de ? rgb[23:16] : 8'h00);
			vid_g <= (s2_de ? rgb[15:8] : 8'h00);
			vid_b <= (s2_de ? rgb[7:0] : 8'h00);
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_scanline (
	clk,
	rst,
	ce_pix,
	vblank,
	first_row,
	vram_raddr,
	vram_rdata,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack
);
	parameter signed [31:0] FB_ADDR_W = 18;
	parameter signed [31:0] NCOL = 512;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire vblank;
	input wire [FB_ADDR_W - 10:0] first_row;
	input wire [FB_ADDR_W - 1:0] vram_raddr;
	output reg [15:0] vram_rdata;
	output reg scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	localparam signed [31:0] ROWW = FB_ADDR_W - 9;
	wire [ROWW - 1:0] req_row = vram_raddr[FB_ADDR_W - 1:9];
	wire [8:0] req_col = vram_raddr[8:0];
	(* ramstyle = "no_rw_check" *) reg [15:0] lb0 [0:511];
	(* ramstyle = "no_rw_check" *) reg [15:0] lb1 [0:511];
	reg disp_sel;
	reg [ROWW - 1:0] disp_row;
	wire sel_now = (req_row == disp_row ? disp_sel : ~disp_sel);
	always @(posedge clk)
		if (ce_pix)
			vram_rdata <= (sel_now ? lb1[req_col] : lb0[req_col]);
	reg [ROWW - 1:0] buf_row [0:1];
	reg buf_valid [0:1];
	wire [ROWW - 1:0] next_row = disp_row + 1'b1;
	reg loading;
	reg tgt_sel;
	reg [ROWW - 1:0] tgt_row;
	reg [8:0] li;
	reg vbl_q;
	wire disp_stale = !buf_valid[disp_sel] || (buf_row[disp_sel] != disp_row);
	wire load_stale = !buf_valid[~disp_sel] || (buf_row[~disp_sel] != next_row);
	always @(posedge clk)
		if (rst) begin
			loading <= 1'b0;
			scan_req <= 1'b0;
			disp_sel <= 1'b0;
			disp_row <= 1'sb0;
			buf_valid[0] <= 1'b0;
			buf_valid[1] <= 1'b0;
		end
		else begin
			vbl_q <= vblank;
			if (!vbl_q && vblank) begin
				disp_sel <= 1'b0;
				disp_row <= first_row;
				buf_valid[0] <= 1'b0;
				buf_valid[1] <= 1'b0;
				loading <= 1'b0;
				scan_req <= 1'b0;
			end
			else if (!vblank && (req_row != disp_row)) begin
				disp_sel <= ~disp_sel;
				disp_row <= req_row;
			end
			if (!loading) begin
				if (disp_stale) begin
					tgt_sel <= disp_sel;
					tgt_row <= disp_row;
					li <= 9'd0;
					loading <= 1'b1;
				end
				else if (load_stale) begin
					tgt_sel <= ~disp_sel;
					tgt_row <= next_row;
					li <= 9'd0;
					loading <= 1'b1;
				end
			end
			else if (scan_req && scan_ack) begin
				if (tgt_sel)
					lb1[li] <= scan_data;
				else
					lb0[li] <= scan_data;
				scan_req <= 1'b0;
				if (li == (NCOL - 1)) begin
					loading <= 1'b0;
					buf_row[tgt_sel] <= tgt_row;
					buf_valid[tgt_sel] <= 1'b1;
				end
				else
					li <= li + 9'd1;
			end
			else if (!scan_req)
				scan_req <= 1'b1;
		end
	assign scan_addr = {tgt_row[8:0], li};
endmodule
`default_nettype wire
`default_nettype none
module yunit_video_top (
	clk,
	rst,
	ce_pix,
	pal_raddr,
	pal_rdata,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	vblank_irq
);
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter signed [31:0] NCOL = 512;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	output wire [11:0] pal_raddr;
	input wire [15:0] pal_rdata;
	output wire scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output wire vblank_irq;
	localparam signed [31:0] yunit_pkg_FB_ADDR_W = 18;
	wire [17:0] vram_raddr;
	wire [15:0] vram_rdata;
	wire vblank_i;
	yunit_video #(
		.H_ACT(H_ACT),
		.H_FP(H_FP),
		.H_SYNC(H_SYNC),
		.H_BP(H_BP),
		.V_ACT(V_ACT),
		.V_FP(V_FP),
		.V_SYNC(V_SYNC),
		.V_BP(V_BP),
		.DISP_ROW0(DISP_ROW0)
	) u_video(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.pal_raddr(pal_raddr),
		.pal_rdata(pal_rdata),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank_i),
		.de(de),
		.vblank_irq(vblank_irq)
	);
	assign vblank = vblank_i;
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	yunit_scanline #(
		.FB_ADDR_W(yunit_pkg_FB_ADDR_W),
		.NCOL(NCOL)
	) u_scan(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.vblank(vblank_i),
		.first_row(sv2v_cast_9_signed(DISP_ROW0)),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack)
	);
endmodule
`default_nettype wire
`default_nettype none
module yunit_palram (
	clk,
	rst,
	we_a,
	aa,
	awd,
	we_b,
	ba,
	bwd,
	raddr,
	rdata
);
	reg _sv2v_0;
	parameter signed [31:0] AW = 13;
	parameter signed [31:0] DEPTH = 1 << AW;
	input wire clk;
	input wire rst;
	input wire we_a;
	input wire [AW - 1:0] aa;
	input wire [15:0] awd;
	input wire we_b;
	input wire [AW - 1:0] ba;
	input wire [15:0] bwd;
	input wire [AW - 1:0] raddr;
	output reg [15:0] rdata;
	(* ramstyle = "no_rw_check" *) reg [15:0] mem [0:DEPTH - 1];
	localparam signed [31:0] QAW = 2;
	reg [AW + 15:0] q [0:3];
	reg [QAW:0] wptr;
	reg [QAW:0] rptr;
	wire qempty = wptr == rptr;
	reg w_we;
	reg [AW - 1:0] w_aa;
	reg [15:0] w_awd;
	always @(*) begin
		if (_sv2v_0)
			;
		w_we = !qempty;
		w_aa = q[rptr[1:0]][AW + 15:16];
		w_awd = q[rptr[1:0]][15:0];
	end
	always @(posedge clk)
		if (rst) begin
			wptr <= 1'sb0;
			rptr <= 1'sb0;
		end
		else begin
			if (!qempty)
				rptr <= rptr + 1'b1;
			if (we_a && we_b) begin
				q[wptr[1:0]] <= {aa, awd};
				q[wptr[1:0] + 1'b1] <= {ba, bwd};
				wptr <= wptr + 2'd2;
			end
			else if (we_a) begin
				q[wptr[1:0]] <= {aa, awd};
				wptr <= wptr + 1'b1;
			end
			else if (we_b) begin
				q[wptr[1:0]] <= {ba, bwd};
				wptr <= wptr + 1'b1;
			end
		end
	always @(posedge clk)
		if (w_we)
			mem[w_aa] <= w_awd;
	always @(posedge clk) rdata <= mem[raddr];
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_sdram_arb (
	clk,
	rst,
	vsd_addr,
	vsd_din,
	vsd_be,
	vsd_rd,
	vsd_wr,
	vsd_dout,
	vsd_ack,
	cgfx_rd,
	cgfx_addr,
	cgfx_data,
	cgfx_ack,
	src_rd,
	src_addr,
	src_data,
	src_ack,
	iol_rd,
	iol_wr,
	iol_addr,
	iol_din,
	iol_be,
	iol_dout,
	iol_ack,
	snd_rd,
	snd_addr_w,
	snd_data,
	snd_ack,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack
);
	reg _sv2v_0;
	parameter signed [31:0] SD_AW = 25;
	parameter [SD_AW - 1:0] GFXW_BASE = 25'h0000000;
	parameter [SD_AW - 1:0] ROMW_BASE = 25'h00c0000;
	parameter [SD_AW - 1:0] VRAMW_BASE = 25'h00e0000;
	parameter [23:0] GFX_BYTES = 24'h180000;
	input wire clk;
	input wire rst;
	input wire [SD_AW - 1:0] vsd_addr;
	input wire [15:0] vsd_din;
	input wire [1:0] vsd_be;
	input wire vsd_rd;
	input wire vsd_wr;
	output reg [15:0] vsd_dout;
	output reg vsd_ack;
	input wire cgfx_rd;
	input wire [23:0] cgfx_addr;
	output reg [15:0] cgfx_data;
	output reg cgfx_ack;
	input wire src_rd;
	input wire [23:0] src_addr;
	output reg [7:0] src_data;
	output reg src_ack;
	input wire iol_rd;
	input wire iol_wr;
	input wire [SD_AW - 1:0] iol_addr;
	input wire [15:0] iol_din;
	input wire [1:0] iol_be;
	output reg [15:0] iol_dout;
	output reg iol_ack;
	input wire snd_rd;
	input wire [SD_AW - 1:0] snd_addr_w;
	output reg [15:0] snd_data;
	output reg snd_ack;
	output reg [SD_AW - 1:0] sd_addr;
	output reg [15:0] sd_din;
	output reg [1:0] sd_be;
	output reg sd_rd;
	output reg sd_wr;
	input wire [15:0] sd_dout;
	input wire sd_ack;
	wire [SD_AW - 1:0] cgfx_word = (cgfx_addr < GFX_BYTES ? GFXW_BASE + {1'b0, cgfx_addr[23:1]} : ROMW_BASE + {1'b0, (cgfx_addr - GFX_BYTES) >> 1});
	wire [SD_AW - 1:0] src_word = GFXW_BASE + {1'b0, src_addr[23:1]};
	wire src_bsel = src_addr[0];
	wire [SD_AW - 1:0] vsd_word = VRAMW_BASE + vsd_addr;
	localparam [2:0] G_NONE = 3'd0;
	localparam [2:0] G_IOL = 3'd1;
	localparam [2:0] G_VSD = 3'd2;
	localparam [2:0] G_CGFX = 3'd3;
	localparam [2:0] G_SRC = 3'd4;
	localparam [2:0] G_SND = 3'd5;
	wire vsd_req = vsd_rd | vsd_wr;
	wire iol_req = iol_rd | iol_wr;
	reg [2:0] gnt;
	reg gnt_held;
	reg [2:0] gnt_r;
	reg bubble;
	localparam signed [31:0] SND_AGE_MAX = 512;
	reg [9:0] snd_age;
	wire snd_urgent = snd_age == SND_AGE_MAX[9:0];
	always @(posedge clk)
		if (rst)
			snd_age <= 10'd0;
		else if (!snd_rd)
			snd_age <= 10'd0;
		else if (gnt == G_SND)
			snd_age <= 10'd0;
		else if (snd_age != SND_AGE_MAX[9:0])
			snd_age <= snd_age + 10'd1;
	always @(*) begin
		if (_sv2v_0)
			;
		if (gnt_held)
			gnt = gnt_r;
		else if (bubble)
			gnt = G_NONE;
		else if (iol_req)
			gnt = G_IOL;
		else if ((snd_urgent && snd_rd) && !vsd_req)
			gnt = G_SND;
		else if (vsd_req)
			gnt = G_VSD;
		else if (cgfx_rd)
			gnt = G_CGFX;
		else if (src_rd)
			gnt = G_SRC;
		else if (snd_rd)
			gnt = G_SND;
		else
			gnt = G_NONE;
	end
	always @(posedge clk)
		if (rst) begin
			gnt_held <= 1'b0;
			gnt_r <= G_NONE;
			bubble <= 1'b0;
		end
		else begin
			bubble <= 1'b0;
			if (!gnt_held) begin
				if (!bubble && (gnt != G_NONE)) begin
					gnt_held <= 1'b1;
					gnt_r <= gnt;
				end
			end
			else if (sd_ack) begin
				gnt_held <= 1'b0;
				bubble <= 1'b1;
			end
		end
	reg src_bsel_q;
	always @(posedge clk)
		if (gnt == G_SRC)
			src_bsel_q <= src_bsel;
	always @(*) begin
		if (_sv2v_0)
			;
		sd_addr = 1'sb0;
		sd_din = 16'h0000;
		sd_be = 2'b00;
		sd_rd = 1'b0;
		sd_wr = 1'b0;
		vsd_ack = 1'b0;
		cgfx_ack = 1'b0;
		src_ack = 1'b0;
		iol_ack = 1'b0;
		snd_ack = 1'b0;
		vsd_dout = sd_dout;
		iol_dout = sd_dout;
		cgfx_data = sd_dout;
		src_data = (src_bsel_q ? sd_dout[15:8] : sd_dout[7:0]);
		snd_data = sd_dout;
		case (gnt)
			G_IOL: begin
				sd_addr = iol_addr;
				sd_din = iol_din;
				sd_be = iol_be;
				sd_rd = iol_rd;
				sd_wr = iol_wr;
				iol_ack = sd_ack;
			end
			G_VSD: begin
				sd_addr = vsd_word;
				sd_din = vsd_din;
				sd_be = vsd_be;
				sd_rd = vsd_rd;
				sd_wr = vsd_wr;
				vsd_ack = sd_ack;
			end
			G_CGFX: begin
				sd_addr = cgfx_word;
				sd_be = 2'b00;
				sd_rd = 1'b1;
				cgfx_ack = sd_ack;
			end
			G_SRC: begin
				sd_addr = src_word;
				sd_be = 2'b00;
				sd_rd = 1'b1;
				src_ack = sd_ack;
			end
			G_SND: begin
				sd_addr = snd_addr_w;
				sd_be = 2'b00;
				sd_rd = 1'b1;
				snd_ack = sd_ack;
			end
			default:
				;
		endcase
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
module sdram_stock (
	init,
	clk,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_BA,
	SDRAM_nCS,
	SDRAM_nWE,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_CKE,
	wtbt,
	addr,
	dout,
	din,
	we,
	rd,
	ready,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done
);
	input init;
	input clk;
	inout [15:0] SDRAM_DQ;
	output reg [12:0] SDRAM_A;
	output reg SDRAM_DQML;
	output reg SDRAM_DQMH;
	output reg [1:0] SDRAM_BA;
	output wire SDRAM_nCS;
	output wire SDRAM_nWE;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_CKE;
	input [1:0] wtbt;
	input [24:0] addr;
	output wire [15:0] dout;
	input [15:0] din;
	input we;
	input rd;
	output reg ready;
	input brd_req;
	input [24:0] brd_addr;
	input [9:0] brd_len;
	output reg [15:0] brd_dout;
	output reg brd_dvalid;
	output reg brd_done;
	localparam BURST_LENGTH = 3'b000;
	localparam ACCESS_TYPE = 1'b0;
	localparam CAS_LATENCY = 3'd2;
	localparam OP_MODE = 2'b00;
	localparam NO_WRITE_BURST = 1'b1;
	localparam MODE = {3'b000, NO_WRITE_BURST, OP_MODE, CAS_LATENCY, ACCESS_TYPE, BURST_LENGTH};
	localparam sdram_startup_cycles = 14'd12100;
	localparam cycles_per_refresh = 14'd780;
	localparam startup_refresh_max = 14'b11111111111111;
	localparam [2:0] CMD_NOP = 3'b111;
	localparam [2:0] CMD_ACTIVE = 3'b011;
	localparam [2:0] CMD_READ = 3'b101;
	localparam [2:0] CMD_WRITE = 3'b100;
	localparam [2:0] CMD_PRECHARGE = 3'b010;
	localparam [2:0] CMD_AUTO_REFRESH = 3'b001;
	localparam [2:0] CMD_LOAD_MODE = 3'b000;
	reg [2:0] command;
	reg [13:0] refresh_count = startup_refresh_max - sdram_startup_cycles;
	reg [24:0] save_addr;
	reg [15:0] data;
	reg old_we;
	reg old_rd;
	reg [CAS_LATENCY + 1:0] data_ready_delay;
	reg [15:0] dq_r;
	reg [15:0] new_data;
	reg [1:0] new_wtbt;
	reg new_we;
	reg new_rd;
	reg save_we = 1'b1;
	reg [31:0] state = 32'd0;
	reg [15:0] sdram_dq_out;
	reg sdram_dq_oe;
	reg old_brd;
	reg new_brd;
	reg [12:0] brd_row;
	reg [1:0] brd_bank;
	reg [8:0] brd_col;
	reg [9:0] brd_i;
	reg [9:0] brd_len_l;
	reg [CAS_LATENCY + 1:0] brd_vdelay;
	wire brd_issue = (state == 32'd12) && (brd_i < brd_len_l);
	assign SDRAM_DQ = (sdram_dq_oe ? sdram_dq_out : 16'bzzzzzzzzzzzzzzzz);
	assign SDRAM_CKE = 1;
	assign SDRAM_nCS = 0;
	assign SDRAM_nRAS = command[2];
	assign SDRAM_nCAS = command[1];
	assign SDRAM_nWE = command[0];
	wire [2:1] sv2v_tmp_B68B7;
	assign sv2v_tmp_B68B7 = SDRAM_A[12:11];
	always @(*) {SDRAM_DQMH, SDRAM_DQML} = sv2v_tmp_B68B7;
	assign dout = (save_addr[0] ? {data[7:0], data[15:8]} : {data[15:8], data[7:0]});
	always @(posedge clk) begin
		sdram_dq_oe <= 1'b0;
		command <= CMD_NOP;
		refresh_count <= refresh_count + 1'b1;
		dq_r <= SDRAM_DQ;
		data_ready_delay <= {1'b0, data_ready_delay[CAS_LATENCY + 1:1]};
		if (data_ready_delay[0])
			{ready, data} <= {1'b1, dq_r};
		brd_dvalid <= 1'b0;
		brd_done <= 1'b0;
		brd_vdelay <= {brd_issue, brd_vdelay[CAS_LATENCY + 1:1]};
		if (brd_vdelay[0]) begin
			brd_dvalid <= 1'b1;
			brd_dout <= dq_r;
		end
		case (state)
			32'd0: begin
				SDRAM_A <= 0;
				SDRAM_BA <= 0;
				if (refresh_count == 16352) begin
					command <= CMD_PRECHARGE;
					SDRAM_A[10] <= 1;
					SDRAM_BA <= 2'b00;
				end
				if (refresh_count == 16360)
					command <= CMD_AUTO_REFRESH;
				if (refresh_count == 16368)
					command <= CMD_AUTO_REFRESH;
				if (refresh_count == 16376) begin
					command <= CMD_LOAD_MODE;
					SDRAM_A <= MODE;
				end
				if (!refresh_count) begin
					state <= 32'd3;
					ready <= 1;
					refresh_count <= 0;
				end
			end
			32'd10: state <= 32'd9;
			32'd9: state <= 32'd8;
			32'd8: state <= 32'd7;
			32'd7: state <= 32'd6;
			32'd6: state <= 32'd5;
			32'd5: state <= 32'd4;
			32'd4: begin
				state <= 32'd3;
				if (refresh_count > cycles_per_refresh) begin
					state <= 32'd10;
					command <= CMD_AUTO_REFRESH;
					refresh_count <= 0;
				end
			end
			32'd3:
				if (refresh_count > (cycles_per_refresh << 1))
					state <= 32'd4;
				else if (new_brd) begin
					new_brd <= 0;
					brd_i <= 10'd0;
					state <= 32'd11;
					command <= CMD_ACTIVE;
					SDRAM_A <= brd_row;
					SDRAM_BA <= brd_bank;
				end
				else if (new_rd | new_we) begin
					new_we <= 0;
					new_rd <= 0;
					save_we <= new_we;
					state <= 32'd1;
					command <= CMD_ACTIVE;
					SDRAM_A <= save_addr[22:10];
					SDRAM_BA <= save_addr[24:23];
				end
			32'd1: state <= 32'd2;
			32'd2: begin
				SDRAM_A <= {save_we & (new_wtbt ? ~new_wtbt[1] : ~save_addr[0]), save_we & (new_wtbt ? ~new_wtbt[0] : save_addr[0]), 2'b10, save_addr[9:1]};
				if (save_we) begin
					command <= CMD_WRITE;
					sdram_dq_out <= (new_wtbt ? new_data : {new_data[7:0], new_data[7:0]});
					sdram_dq_oe <= 1'b1;
					ready <= 1;
					state <= 32'd5;
				end
				else begin
					command <= CMD_READ;
					data_ready_delay[CAS_LATENCY + 1] <= 1;
					state <= 32'd8;
				end
			end
			32'd11: state <= 32'd12;
			32'd12:
				if (brd_i < brd_len_l) begin
					command <= CMD_READ;
					SDRAM_A <= {4'b0000, brd_col};
					brd_col <= brd_col + 9'd1;
					brd_i <= brd_i + 10'd1;
				end
				else
					state <= 32'd13;
			32'd13:
				if (brd_vdelay == 0) begin
					command <= CMD_PRECHARGE;
					SDRAM_A[10] <= 1'b1;
					state <= 32'd14;
				end
			32'd14: begin
				brd_done <= 1'b1;
				state <= 32'd3;
			end
			default: state <= 32'd3;
		endcase
		if (init) begin
			state <= 32'd0;
			refresh_count <= startup_refresh_max - sdram_startup_cycles;
			new_brd <= 1'b0;
			brd_vdelay <= 0;
		end
		old_we <= we;
		if (we & ~old_we) begin
			save_addr <= addr;
			{ready, new_we, new_data, new_wtbt} <= {2'b01, din, wtbt};
		end
		old_rd <= rd;
		if (rd & ~old_rd) begin
			save_addr <= addr;
			if (!((ready & ~save_we) & (save_addr[24:1] == addr[24:1])))
				{ready, new_rd} <= 2'b01;
		end
		old_brd <= brd_req;
		if (brd_req & ~old_brd) begin
			brd_row <= brd_addr[22:10];
			brd_bank <= brd_addr[24:23];
			brd_col <= brd_addr[9:1];
			brd_len_l <= brd_len;
			new_brd <= 1'b1;
		end
	end
endmodule
`default_nettype none
module sdram_stock_shipped (
	init,
	clk,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_BA,
	SDRAM_nCS,
	SDRAM_nWE,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_CKE,
	wtbt,
	addr,
	dout,
	din,
	we,
	rd,
	ready,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done
);
	parameter [24:0] VRAM_BBASE = 25'h0440000;
	parameter [24:0] VRAM_BYTES = 25'h0080000;
	parameter [24:0] GFX_BBASE = 25'h0000000;
	parameter [24:0] GFX_BYTES = 25'h0000000;
	input init;
	input clk;
	inout [15:0] SDRAM_DQ;
	output reg [12:0] SDRAM_A;
	output reg SDRAM_DQML;
	output reg SDRAM_DQMH;
	output reg [1:0] SDRAM_BA;
	output wire SDRAM_nCS;
	output wire SDRAM_nWE;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_CKE;
	input [1:0] wtbt;
	input [24:0] addr;
	output wire [15:0] dout;
	input [15:0] din;
	input we;
	input rd;
	output reg ready;
	input brd_req;
	input [24:0] brd_addr;
	input [9:0] brd_len;
	output wire [15:0] brd_dout;
	output reg brd_dvalid;
	output reg brd_done;
	localparam BURST_LENGTH = 3'b000;
	localparam ACCESS_TYPE = 1'b0;
	localparam CAS_LATENCY = 3'd2;
	localparam OP_MODE = 2'b00;
	localparam NO_WRITE_BURST = 1'b1;
	localparam MODE = {3'b000, NO_WRITE_BURST, OP_MODE, CAS_LATENCY, ACCESS_TYPE, BURST_LENGTH};
	localparam sdram_startup_cycles = 14'd12100;
	localparam cycles_per_refresh = 14'd780;
	localparam startup_refresh_max = 14'b11111111111111;
	localparam [2:0] CMD_NOP = 3'b111;
	localparam [2:0] CMD_ACTIVE = 3'b011;
	localparam [2:0] CMD_READ = 3'b101;
	localparam [2:0] CMD_WRITE = 3'b100;
	localparam [2:0] CMD_PRECHARGE = 3'b010;
	localparam [2:0] CMD_AUTO_REFRESH = 3'b001;
	localparam [2:0] CMD_LOAD_MODE = 3'b000;
	reg [2:0] command;
	reg [13:0] refresh_count = startup_refresh_max - sdram_startup_cycles;
	reg [24:0] save_addr;
	reg [15:0] data;
	reg old_we;
	reg old_rd;
	reg [CAS_LATENCY:0] data_ready_delay;
	reg [15:0] new_data;
	reg [1:0] new_wtbt;
	reg new_we;
	reg new_rd;
	reg save_we = 1'b1;
	reg [31:0] state = 32'd0;
	reg [15:0] sb_data;
	reg sb_cap;
	reg [15:0] sdram_dq_out;
	reg sdram_dq_oe;
	reg old_brd;
	reg new_brd;
	reg [12:0] brd_row;
	reg [1:0] brd_bank;
	reg [8:0] brd_col;
	reg [9:0] brd_i;
	reg [9:0] brd_len_l;
	reg [CAS_LATENCY:0] brd_vdelay;
	wire brd_issue = (state == 32'd12) && (brd_i < brd_len_l);
	wire [24:0] save_vram_rel = save_addr - VRAM_BBASE;
	wire save_is_vram = (save_addr >= VRAM_BBASE) && (save_addr < (VRAM_BBASE + VRAM_BYTES));
	wire [24:0] brd_vram_rel = brd_addr - VRAM_BBASE;
	wire save_is_gfx = ((GFX_BYTES != 0) && (save_addr >= GFX_BBASE)) && (save_addr < (GFX_BBASE + GFX_BYTES));
	wire [24:0] save_gfx_rel = save_addr - GFX_BBASE;
	wire [24:0] brd_gfx_rel = brd_addr - GFX_BBASE;
	assign SDRAM_DQ = (sdram_dq_oe ? sdram_dq_out : 16'bzzzzzzzzzzzzzzzz);
	assign SDRAM_CKE = 1'b1;
	assign SDRAM_nCS = 1'b0;
	assign SDRAM_nRAS = command[2];
	assign SDRAM_nCAS = command[1];
	assign SDRAM_nWE = command[0];
	reg [1:0] dqm_r = 2'b00;
	wire [2:1] sv2v_tmp_F2FA3;
	assign sv2v_tmp_F2FA3 = dqm_r;
	always @(*) {SDRAM_DQMH, SDRAM_DQML} = sv2v_tmp_F2FA3;
	assign dout = (save_addr[0] ? {sb_data[7:0], sb_data[15:8]} : sb_data);
	assign brd_dout = data;
	always @(posedge clk) begin
		sdram_dq_oe <= 1'b0;
		dqm_r <= 2'b00;
		command <= CMD_NOP;
		refresh_count <= refresh_count + 1'b1;
		data_ready_delay <= {1'b0, data_ready_delay[CAS_LATENCY:1]};
		sb_cap <= 1'b0;
		if (data_ready_delay[0]) begin
			data <= SDRAM_DQ;
			sb_cap <= 1'b1;
		end
		if (sb_cap) begin
			sb_data <= data;
			ready <= 1'b1;
		end
		brd_dvalid <= 1'b0;
		brd_done <= 1'b0;
		brd_vdelay <= {brd_issue, brd_vdelay[CAS_LATENCY:1]};
		if (brd_vdelay[0]) begin
			brd_dvalid <= 1'b1;
			data <= SDRAM_DQ;
		end
		case (state)
			32'd0: begin
				SDRAM_A <= 0;
				SDRAM_BA <= 0;
				if (refresh_count == 16352) begin
					command <= CMD_PRECHARGE;
					SDRAM_A[10] <= 1'b1;
					SDRAM_BA <= 2'b00;
				end
				if (refresh_count == 16360)
					command <= CMD_AUTO_REFRESH;
				if (refresh_count == 16368)
					command <= CMD_AUTO_REFRESH;
				if (refresh_count == 16376) begin
					command <= CMD_LOAD_MODE;
					SDRAM_A <= MODE;
				end
				if (!refresh_count) begin
					state <= 32'd3;
					ready <= 1'b1;
					refresh_count <= 0;
				end
			end
			32'd10: state <= 32'd9;
			32'd9: state <= 32'd8;
			32'd8: state <= 32'd7;
			32'd7: state <= 32'd6;
			32'd6: state <= 32'd5;
			32'd5: state <= 32'd4;
			32'd4: begin
				state <= 32'd3;
				if (refresh_count > cycles_per_refresh) begin
					state <= 32'd10;
					command <= CMD_AUTO_REFRESH;
					refresh_count <= 0;
				end
			end
			32'd3:
				if (refresh_count > (cycles_per_refresh << 1))
					state <= 32'd4;
				else if (new_brd && (refresh_count > cycles_per_refresh)) begin
					state <= 32'd10;
					command <= CMD_AUTO_REFRESH;
					refresh_count <= 0;
				end
				else if (new_brd) begin
					ready <= 1'b0;
					new_brd <= 1'b0;
					brd_i <= 10'd0;
					state <= 32'd11;
					command <= CMD_ACTIVE;
					SDRAM_A <= brd_row;
					SDRAM_BA <= brd_bank;
				end
				else if (new_rd | new_we) begin
					new_we <= 1'b0;
					new_rd <= 1'b0;
					save_we <= new_we;
					state <= 32'd1;
					command <= CMD_ACTIVE;
					if (save_is_gfx) begin
						SDRAM_A <= {4'd0, save_gfx_rel[22:10]};
						SDRAM_BA <= 2'b01;
					end
					else begin
						SDRAM_A <= save_addr[13:1];
						SDRAM_BA <= save_addr[24:23];
					end
				end
			32'd1: state <= 32'd2;
			32'd2: begin
				if (save_is_gfx)
					SDRAM_A <= {save_we & (new_wtbt ? ~new_wtbt[1] : ~save_addr[0]), save_we & (new_wtbt ? ~new_wtbt[0] : save_addr[0]), 2'b10, save_gfx_rel[9:1]};
				else
					SDRAM_A <= {save_we & (new_wtbt ? ~new_wtbt[1] : ~save_addr[0]), save_we & (new_wtbt ? ~new_wtbt[0] : save_addr[0]), 2'b10, (save_is_vram ? save_vram_rel[9:1] : save_addr[22:14])};
				if (save_we) begin
					command <= CMD_WRITE;
					dqm_r <= {(new_wtbt ? ~new_wtbt[1] : ~save_addr[0]), (new_wtbt ? ~new_wtbt[0] : save_addr[0])};
					sdram_dq_out <= (new_wtbt ? new_data : {new_data[7:0], new_data[7:0]});
					sdram_dq_oe <= 1'b1;
					ready <= 1'b1;
					state <= 32'd5;
				end
				else begin
					command <= CMD_READ;
					data_ready_delay[CAS_LATENCY] <= 1'b1;
					state <= 32'd8;
				end
			end
			32'd11: state <= 32'd12;
			32'd12:
				if (brd_i < brd_len_l) begin
					command <= CMD_READ;
					SDRAM_A <= {4'b0000, brd_col};
					brd_col <= brd_col + 9'd1;
					brd_i <= brd_i + 10'd1;
				end
				else
					state <= 32'd13;
			32'd13:
				if (brd_vdelay == 0) begin
					command <= CMD_PRECHARGE;
					SDRAM_A[10] <= 1'b1;
					SDRAM_BA <= brd_bank;
					state <= 32'd14;
				end
			32'd14: begin
				brd_done <= 1'b1;
				state <= 32'd3;
				if (!(new_rd | new_we))
					ready <= 1'b1;
			end
			default: state <= 32'd3;
		endcase
		if (init) begin
			state <= 32'd0;
			refresh_count <= startup_refresh_max - sdram_startup_cycles;
			new_brd <= 1'b0;
			brd_vdelay <= 0;
		end
		old_we <= we;
		if (we & ~old_we) begin
			save_addr <= addr;
			{ready, new_we, new_data, new_wtbt} <= {2'b01, din, wtbt};
		end
		old_rd <= rd;
		if (rd & ~old_rd) begin
			save_addr <= addr;
			if (!((ready & ~save_we) & (save_addr[24:1] == addr[24:1])))
				{ready, new_rd} <= 2'b01;
		end
		old_brd <= brd_req;
		if (brd_req & ~old_brd) begin
			brd_row <= {4'd0, brd_gfx_rel[22:10]};
			brd_bank <= 2'b01;
			brd_col <= brd_gfx_rel[9:1];
			brd_len_l <= brd_len;
			new_brd <= 1'b1;
		end
	end
endmodule
`default_nettype wire
`default_nettype none
module yunit_sdram_adapter (
	clk,
	rst,
	sd_addr,
	sd_din,
	sd_be,
	sd_rd,
	sd_wr,
	sd_dout,
	sd_ack,
	sdram_ready,
	ctl_addr,
	ctl_din,
	ctl_wtbt,
	ctl_rd,
	ctl_we,
	ctl_dout,
	ctl_ready
);
	input wire clk;
	input wire rst;
	input wire [24:0] sd_addr;
	input wire [15:0] sd_din;
	input wire [1:0] sd_be;
	input wire sd_rd;
	input wire sd_wr;
	output reg [15:0] sd_dout;
	output reg sd_ack;
	output wire sdram_ready;
	output reg [24:0] ctl_addr;
	output reg [15:0] ctl_din;
	output reg [1:0] ctl_wtbt;
	output reg ctl_rd;
	output reg ctl_we;
	input wire [15:0] ctl_dout;
	input wire ctl_ready;
	reg startup_done;
	reg [1:0] astate;
	always @(posedge clk)
		if (rst) begin
			astate <= 2'd0;
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			sd_ack <= 1'b0;
			startup_done <= 1'b0;
		end
		else begin
			sd_ack <= 1'b0;
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			if (ctl_ready)
				startup_done <= 1'b1;
			case (astate)
				2'd0:
					if (((sd_rd | sd_wr) & ctl_ready) & startup_done) begin
						ctl_addr <= {sd_addr[23:0], 1'b0};
						ctl_din <= sd_din;
						ctl_wtbt <= sd_be;
						ctl_rd <= sd_rd;
						ctl_we <= sd_wr;
						astate <= 2'd1;
					end
				2'd1: astate <= 2'd2;
				2'd2:
					if (ctl_ready) begin
						sd_dout <= ctl_dout;
						sd_ack <= 1'b1;
						astate <= 2'd3;
					end
				2'd3: astate <= 2'd0;
			endcase
		end
	assign sdram_ready = startup_done;
endmodule
`default_nettype wire
`default_nettype none
module yunit_src_cache (
	clk,
	rst,
	src_req,
	src_addr,
	src_data,
	src_ack,
	brd_req,
	brd_addr,
	brd_len,
	brd_dout,
	brd_dvalid,
	brd_done
);
	parameter [23:0] GFXW_BASE = 24'h000000;
	input wire clk;
	input wire rst;
	input wire src_req;
	input wire [23:0] src_addr;
	output reg [7:0] src_data;
	output reg src_ack;
	output reg brd_req;
	output reg [24:0] brd_addr;
	output reg [9:0] brd_len;
	input wire [15:0] brd_dout;
	input wire brd_dvalid;
	input wire brd_done;
	localparam signed [31:0] DEPTH = 16;
	localparam [9:0] FILL = 10'd8;
	reg [15:0] ring [0:15];
	reg [22:0] rw0;
	reg [4:0] cnt;
	reg [3:0] head;
	reg [3:0] st_idx;
	reg retarget;
	reg [5:0] cool;
	reg [1:0] fst;
	wire [22:0] q_word = src_addr[23:1];
	wire [22:0] q_off = q_word - rw0;
	wire in_win = q_off < {18'd0, cnt};
	wire serve = (src_req && !src_ack) && in_win;
	wire miss = (src_req && !src_ack) && !in_win;
	wire flush = miss && (q_word != rw0);
	wire [3:0] q_off4 = q_off[3:0];
	wire st = ((brd_dvalid && (fst == 2'd1)) && !retarget) && !flush;
	wire [22:0] f_word = rw0 + {18'd0, cnt};
	wire [9:0] col_left = 10'd512 - {1'b0, f_word[8:0]};
	wire [9:0] f_len = (col_left < FILL ? col_left : FILL);
	always @(posedge clk)
		if (rst) begin
			cnt <= 5'd0;
			head <= 4'd0;
			rw0 <= 23'd0;
			st_idx <= 4'd0;
			fst <= 2'd0;
			retarget <= 1'b0;
			brd_req <= 1'b0;
			brd_addr <= 25'd0;
			brd_len <= 10'd1;
			src_ack <= 1'b0;
			src_data <= 8'h00;
			cool <= 6'd40;
		end
		else begin
			src_ack <= 1'b0;
			if (cool != 6'd0)
				cool <= cool - 6'd1;
			if (serve) begin
				src_data <= (src_addr[0] ? ring[head + q_off4][15:8] : ring[head + q_off4][7:0]);
				src_ack <= 1'b1;
			end
			rw0 <= (flush ? q_word : (serve ? rw0 + q_off : rw0));
			cnt <= (flush ? 5'd0 : (cnt - (serve ? {1'b0, q_off4} : 5'd0)) + (st ? 5'd1 : 5'd0));
			head <= (flush ? 4'd0 : head + (serve ? q_off4 : 4'd0));
			if (st) begin
				ring[st_idx] <= brd_dout;
				st_idx <= st_idx + 4'd1;
			end
			case (fst)
				2'd0: begin
					st_idx <= head + cnt[3:0];
					if (((cool == 6'd0) && (cnt <= 5'd8)) && !flush) begin
						brd_addr <= {1'b0, GFXW_BASE[22:0] + f_word, 1'b0};
						brd_len <= f_len;
						brd_req <= 1'b1;
						fst <= 2'd1;
					end
				end
				2'd1: begin
					if (flush)
						retarget <= 1'b1;
					if (brd_done) begin
						brd_req <= 1'b0;
						retarget <= 1'b0;
						fst <= 2'd2;
					end
				end
				2'd2: fst <= 2'd0;
				default: fst <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_gfx_unpack (
	clk,
	rst,
	start,
	busy,
	done,
	unp_rd,
	unp_wr,
	unp_addr,
	unp_din,
	unp_dout,
	unp_ack
);
	reg _sv2v_0;
	parameter signed [31:0] SD_AW = 25;
	parameter [SD_AW - 1:0] SCRATCH_WBASE = 25'h0120000;
	parameter [SD_AW - 1:0] GFXW_BASE = 25'h0000000;
	parameter [23:0] PLANE_WORDS = 24'h030000;
	input wire clk;
	input wire rst;
	input wire start;
	output wire busy;
	output wire done;
	output reg unp_rd;
	output reg unp_wr;
	output reg [SD_AW - 1:0] unp_addr;
	output reg [15:0] unp_din;
	input wire [15:0] unp_dout;
	input wire unp_ack;
	function automatic [7:0] mkpix;
		input [7:0] b0;
		input [7:0] b1;
		input [7:0] b2;
		input [1:0] m;
		reg [1:0] d0;
		reg [1:0] d1;
		reg [1:0] d2;
		begin
			d0 = (b0 >> {m, 1'b0}) & 2'b11;
			d1 = (b1 >> {m, 1'b0}) & 2'b11;
			d2 = (b2 >> {m, 1'b0}) & 2'b11;
			mkpix = {2'b00, d2, d1, d0};
		end
	endfunction
	reg [3:0] st;
	reg [23:0] w;
	reg [15:0] p0;
	reg [15:0] p1;
	reg [15:0] fw0;
	reg [15:0] fw1;
	reg [15:0] fw2;
	reg [15:0] fw3;
	wire [25:0] fourw = {w, 2'b00};
	wire [SD_AW - 1:0] a0 = SCRATCH_WBASE + {{SD_AW - 24 {1'b0}}, w};
	wire [SD_AW - 1:0] a1 = (SCRATCH_WBASE + PLANE_WORDS) + {{SD_AW - 24 {1'b0}}, w};
	wire [SD_AW - 1:0] a2 = (SCRATCH_WBASE + (2 * PLANE_WORDS)) + {{SD_AW - 24 {1'b0}}, w};
	wire [SD_AW - 1:0] wbase = GFXW_BASE + fourw[SD_AW - 1:0];
	always @(*) begin
		if (_sv2v_0)
			;
		unp_rd = 1'b0;
		unp_wr = 1'b0;
		unp_addr = 1'sb0;
		unp_din = 16'h0000;
		case (st)
			4'd1: begin
				unp_rd = 1'b1;
				unp_addr = a0;
			end
			4'd2: begin
				unp_rd = 1'b1;
				unp_addr = a1;
			end
			4'd3: begin
				unp_rd = 1'b1;
				unp_addr = a2;
			end
			4'd4: begin
				unp_wr = 1'b1;
				unp_addr = wbase;
				unp_din = fw0;
			end
			4'd5: begin
				unp_wr = 1'b1;
				unp_addr = wbase + 25'd1;
				unp_din = fw1;
			end
			4'd6: begin
				unp_wr = 1'b1;
				unp_addr = wbase + 25'd2;
				unp_din = fw2;
			end
			4'd7: begin
				unp_wr = 1'b1;
				unp_addr = wbase + 25'd3;
				unp_din = fw3;
			end
			default:
				;
		endcase
	end
	assign busy = (st != 4'd0) && (st != 4'd9);
	assign done = st == 4'd9;
	always @(posedge clk)
		if (rst) begin
			st <= 4'd0;
			w <= 24'd0;
		end
		else
			case (st)
				4'd0:
					if (start) begin
						w <= 24'd0;
						st <= 4'd1;
					end
				4'd1:
					if (unp_ack) begin
						p0 <= unp_dout;
						st <= 4'd2;
					end
				4'd2:
					if (unp_ack) begin
						p1 <= unp_dout;
						st <= 4'd3;
					end
				4'd3:
					if (unp_ack) begin
						fw0 <= {mkpix(p0[7:0], p1[7:0], unp_dout[7:0], 2'd1), mkpix(p0[7:0], p1[7:0], unp_dout[7:0], 2'd0)};
						fw1 <= {mkpix(p0[7:0], p1[7:0], unp_dout[7:0], 2'd3), mkpix(p0[7:0], p1[7:0], unp_dout[7:0], 2'd2)};
						fw2 <= {mkpix(p0[15:8], p1[15:8], unp_dout[15:8], 2'd1), mkpix(p0[15:8], p1[15:8], unp_dout[15:8], 2'd0)};
						fw3 <= {mkpix(p0[15:8], p1[15:8], unp_dout[15:8], 2'd3), mkpix(p0[15:8], p1[15:8], unp_dout[15:8], 2'd2)};
						st <= 4'd4;
					end
				4'd4:
					if (unp_ack)
						st <= 4'd5;
				4'd5:
					if (unp_ack)
						st <= 4'd6;
				4'd6:
					if (unp_ack)
						st <= 4'd7;
				4'd7:
					if (unp_ack)
						st <= 4'd8;
				4'd8:
					if (w == (PLANE_WORDS - 24'd1))
						st <= 4'd9;
					else begin
						w <= w + 24'd1;
						st <= 4'd1;
					end
				4'd9: st <= 4'd9;
				default: st <= 4'd0;
			endcase
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module yunit_mem_cdc (
	clk_cpu,
	ce_cpu,
	rst_cpu,
	c_req,
	c_we,
	c_srt,
	c_addr,
	c_size,
	c_wdata,
	c_ack,
	c_rdata,
	clk_sys,
	rst_sys,
	m_req,
	m_we,
	m_srt,
	m_addr,
	m_size,
	m_wdata,
	m_rdata,
	m_ack
);
	parameter AW = 32;
	parameter DW = 32;
	parameter SW = 6;
	input wire clk_cpu;
	input wire ce_cpu;
	input wire rst_cpu;
	input wire c_req;
	input wire c_we;
	input wire c_srt;
	input wire [AW - 1:0] c_addr;
	input wire [SW - 1:0] c_size;
	input wire [DW - 1:0] c_wdata;
	output reg c_ack;
	output reg [DW - 1:0] c_rdata;
	input wire clk_sys;
	input wire rst_sys;
	output reg m_req;
	output reg m_we;
	output reg m_srt;
	output reg [AW - 1:0] m_addr;
	output reg [SW - 1:0] m_size;
	output reg [DW - 1:0] m_wdata;
	input wire [DW - 1:0] m_rdata;
	input wire m_ack;
	reg req_tgl;
	reg ack_tgl;
	reg p_we;
	reg p_srt;
	reg [AW - 1:0] p_addr;
	reg [SW - 1:0] p_size;
	reg [DW - 1:0] p_wdata;
	reg [DW - 1:0] resp;
	reg [1:0] cst;
	reg [2:0] ackt_sync;
	always @(posedge clk_cpu)
		if (ce_cpu !== 1'b0) begin
			if (rst_cpu) begin
				cst <= 2'd0;
				req_tgl <= 1'b0;
				c_ack <= 1'b0;
				ackt_sync <= 3'b000;
			end
			else begin
				ackt_sync <= {ackt_sync[1:0], ack_tgl};
				c_ack <= 1'b0;
				case (cst)
					2'd0:
						if (c_req) begin
							p_we <= c_we;
							p_srt <= c_srt;
							p_addr <= c_addr;
							p_size <= c_size;
							p_wdata <= c_wdata;
							req_tgl <= ~req_tgl;
							cst <= 2'd1;
						end
					2'd1:
						if (ackt_sync[2] ^ ackt_sync[1]) begin
							c_rdata <= resp;
							c_ack <= 1'b1;
							cst <= 2'd2;
						end
					2'd2: cst <= 2'd0;
					default: cst <= 2'd0;
				endcase
			end
		end
	reg [1:0] sst;
	reg [2:0] reqt_sync;
	always @(posedge clk_sys)
		if (rst_sys) begin
			sst <= 2'd0;
			m_req <= 1'b0;
			m_srt <= 1'b0;
			ack_tgl <= 1'b0;
			reqt_sync <= 3'b000;
		end
		else begin
			reqt_sync <= {reqt_sync[1:0], req_tgl};
			case (sst)
				2'd0:
					if (reqt_sync[2] ^ reqt_sync[1]) begin
						m_we <= p_we;
						m_srt <= p_srt;
						m_addr <= p_addr;
						m_size <= p_size;
						m_wdata <= p_wdata;
						m_req <= 1'b1;
						sst <= 2'd1;
					end
				2'd1:
					if (m_ack) begin
						resp <= m_rdata;
						m_req <= 1'b0;
						ack_tgl <= ~ack_tgl;
						sst <= 2'd0;
					end
				default: sst <= 2'd0;
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module yunit_top (
	clk,
	clk_cpu,
	ce_pix,
	cpu_div_sel,
	clk_snd,
	rst,
	rst_pon,
	sdram_por,
	inputs,
	ioctl_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	snd_dl_wr,
	snd_dl_addr,
	snd_dl_data,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	DDRAM_ADDR,
	DDRAM_BURSTCNT,
	DDRAM_RD,
	DDRAM_DIN,
	DDRAM_BE,
	DDRAM_WE,
	DDRAM_BUSY,
	DDRAM_DOUT,
	DDRAM_DOUT_READY,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	audio_l,
	audio_r,
	pc_dbg,
	illegal_dbg,
	dbg_core_rst,
	dbg_sdram_ready,
	dbg_unp_done,
	dbg_cpu_req,
	dbg_mem_ack,
	dbg_int1,
	dbg_vblank_irq,
	dbg_cpu_ce,
	dbg_derailed,
	dbg_culprit_pc,
	dbg_culprit_instr,
	dbg_derail_pc,
	dbg_iol_drop,
	dbg_iol_wrs,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	dbg_src_data,
	dbg_src_ack,
	dbg_scan_data,
	dbg_scan_ack
);
	reg _sv2v_0;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter [24:0] GFXW_BASE = 25'h0000000;
	parameter [24:0] ROMW_BASE = 25'h00c0000;
	parameter [24:0] VRAMW_BASE = 25'h00e0000;
	parameter [23:0] GFX_BYTES = 24'h180000;
	parameter [24:0] SCRATCH_WBASE = 25'h0120000;
	parameter [23:0] PLANE_WORDS = 24'h030000;
	input wire clk;
	input wire clk_cpu;
	input wire ce_pix;
	input wire [2:0] cpu_div_sel;
	input wire clk_snd;
	input wire rst;
	input wire rst_pon;
	input wire sdram_por;
	input wire [63:0] inputs;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	input wire snd_dl_wr;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output wire [28:0] DDRAM_ADDR;
	output wire [7:0] DDRAM_BURSTCNT;
	output wire DDRAM_RD;
	output wire [63:0] DDRAM_DIN;
	output wire [7:0] DDRAM_BE;
	output wire DDRAM_WE;
	input wire DDRAM_BUSY;
	input wire [63:0] DDRAM_DOUT;
	input wire DDRAM_DOUT_READY;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output reg signed [15:0] audio_l;
	output reg signed [15:0] audio_r;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire dbg_core_rst;
	output wire dbg_sdram_ready;
	output wire dbg_unp_done;
	output wire dbg_cpu_req;
	output wire dbg_mem_ack;
	output wire dbg_int1;
	output wire dbg_vblank_irq;
	output wire dbg_cpu_ce;
	output reg dbg_derailed;
	output reg [31:0] dbg_culprit_pc;
	output reg [15:0] dbg_culprit_instr;
	output reg [31:0] dbg_derail_pc;
	output wire [31:0] dbg_iol_drop;
	output wire [31:0] dbg_iol_wrs;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire [7:0] dbg_src_data;
	output wire dbg_src_ack;
	output wire [15:0] dbg_scan_data;
	output wire dbg_scan_ack;
	wire sdram_ready;
	wire unp_done;
	wire core_rst = ((rst | ~sdram_ready) | ioctl_download) | ~unp_done;
	reg [4:0] cpu_ce_div;
	always @(*) begin
		if (_sv2v_0)
			;
		case (cpu_div_sel)
			3'd0: cpu_ce_div = 5'd20;
			3'd1: cpu_ce_div = 5'd4;
			3'd2: cpu_ce_div = 5'd6;
			3'd3: cpu_ce_div = 5'd8;
			3'd4: cpu_ce_div = 5'd10;
			3'd5: cpu_ce_div = 5'd12;
			3'd6: cpu_ce_div = 5'd14;
			default: cpu_ce_div = 5'd16;
		endcase
	end
	reg [4:0] ce_div;
	always @(posedge clk)
		if (rst)
			ce_div <= 5'd0;
		else
			ce_div <= (ce_div == (cpu_ce_div - 5'd1) ? 5'd0 : ce_div + 5'd1);
	wire cpu_ce = ce_div == 5'd0;
	reg core_rst_sys_m;
	reg core_rst_sys;
	always @(posedge clk) begin
		core_rst_sys_m <= core_rst;
		core_rst_sys <= core_rst_sys_m;
	end
	wire int1;
	wire cpu_req;
	wire cpu_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	wire [31:0] cpu_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	wire [5:0] cpu_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	wire [31:0] cpu_wdata;
	wire [31:0] cpu_rdata;
	wire cpu_ack;
	wire [5:0] state_w;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	wire [15:0] instr_w;
	reg ce_pix_ph;
	always @(posedge clk)
		if (core_rst_sys)
			ce_pix_ph <= 1'b0;
		else if (ce_pix)
			ce_pix_ph <= ~ce_pix_ph;
	wire ce_pix_cnt = ce_pix & ce_pix_ph;
	tms34010_core u_core(
		.clk(clk),
		.ce_cpu(cpu_ce),
		.ce_pix(ce_pix_cnt),
		.rst(core_rst_sys),
		.mem_req(cpu_req),
		.mem_we(cpu_we),
		.mem_addr(cpu_addr),
		.mem_size(cpu_size),
		.mem_wdata(cpu_wdata),
		.mem_rdata(cpu_rdata),
		.mem_ack(cpu_ack),
		.state_o(state_w),
		.pc_o(pc_dbg),
		.instr_word_o(instr_w),
		.illegal_opcode_o(illegal_dbg),
		.lint1_in(int1)
	);
	wire mem_req;
	wire mem_we;
	wire [31:0] mem_addr;
	wire [5:0] mem_size;
	wire [31:0] mem_wdata;
	wire [31:0] mem_rdata;
	wire mem_ack;
	yunit_mem_cdc #(
		.AW(tms34010_pkg_ADDR_WIDTH),
		.DW(tms34010_pkg_DATA_WIDTH),
		.SW(tms34010_pkg_FIELD_SIZE_WIDTH)
	) u_memcdc(
		.clk_cpu(clk),
		.ce_cpu(cpu_ce),
		.rst_cpu(core_rst_sys),
		.c_req(cpu_req),
		.c_we(cpu_we),
		.c_srt(1'b0),
		.c_addr(cpu_addr),
		.c_size(cpu_size),
		.c_wdata(cpu_wdata),
		.c_ack(cpu_ack),
		.c_rdata(cpu_rdata),
		.clk_sys(clk),
		.rst_sys(core_rst_sys),
		.m_req(mem_req),
		.m_we(mem_we),
		.m_srt(),
		.m_addr(mem_addr),
		.m_size(mem_size),
		.m_wdata(mem_wdata),
		.m_rdata(mem_rdata),
		.m_ack(mem_ack)
	);
	wire src_req;
	wire [23:0] src_addr;
	wire [7:0] src_data;
	wire src_ack;
	wire cgfx_rd;
	wire [23:0] cgfx_addr;
	wire [15:0] cgfx_data;
	wire cgfx_ack;
	wire scan_req;
	wire [17:0] scan_addr;
	wire [15:0] scan_data;
	wire scan_ack;
	wire [7:0] snd_select;
	wire snd_trig;
	wire snd_reset;
	wire erase_busy;
	wire blit_busy;
	wire palv_we_a;
	wire palv_we_b;
	wire [12:0] palv_aa;
	wire [12:0] palv_ba;
	wire [15:0] palv_awd;
	wire [15:0] palv_bwd;
	wire vblank_irq;
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	yunit_memsys #(.ROM_HEX(ROM_HEX)) u_sys(
		.clk(clk),
		.rst(core_rst),
		.mem_req(mem_req),
		.mem_we(mem_we),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata),
		.mem_ack(mem_ack),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.inputs(inputs),
		.int1(int1),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.erase_start(vblank_irq),
		.erase_row0(sv2v_cast_9_signed(DISP_ROW0)),
		.erase_lines(sv2v_cast_10_signed(V_ACT)),
		.erase_busy(erase_busy),
		.blit_busy(blit_busy),
		.dbg_dma_we(dbg_dma_we),
		.dbg_dma_addr(dbg_dma_addr),
		.dbg_dma_wdata(dbg_dma_wdata),
		.cpu_gfx_rd(cgfx_rd),
		.cpu_gfx_raddr(cgfx_addr),
		.cpu_gfx_rdata(cgfx_data),
		.cpu_gfx_rack(cgfx_ack),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.ddram_addr(DDRAM_ADDR),
		.ddram_burstcnt(DDRAM_BURSTCNT),
		.ddram_rd(DDRAM_RD),
		.ddram_we(DDRAM_WE),
		.ddram_din(DDRAM_DIN),
		.ddram_be(DDRAM_BE),
		.ddram_busy(DDRAM_BUSY),
		.ddram_dout(DDRAM_DOUT),
		.ddram_dout_ready(DDRAM_DOUT_READY),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	wire [11:0] pal_raddr;
	wire [15:0] pal_rdata;
	yunit_video_top #(
		.H_ACT(H_ACT),
		.H_FP(H_FP),
		.H_SYNC(H_SYNC),
		.H_BP(H_BP),
		.V_ACT(V_ACT),
		.V_FP(V_FP),
		.V_SYNC(V_SYNC),
		.V_BP(V_BP),
		.DISP_ROW0(DISP_ROW0),
		.NCOL(H_ACT)
	) u_video(
		.clk(clk),
		.rst(core_rst),
		.ce_pix(ce_pix),
		.pal_raddr(pal_raddr),
		.pal_rdata(pal_rdata),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank),
		.de(de),
		.vblank_irq(vblank_irq)
	);
	yunit_palram #(.AW(13)) u_pal(
		.clk(clk),
		.rst(core_rst),
		.we_a(palv_we_a),
		.aa(palv_aa),
		.awd(palv_awd),
		.we_b(palv_we_b),
		.ba(palv_ba),
		.bwd(palv_bwd),
		.raddr({1'b0, pal_raddr}),
		.rdata(pal_rdata)
	);
	wire [24:0] sd_addr;
	wire [15:0] sd_din;
	wire [15:0] sd_dout;
	wire [1:0] sd_be;
	wire sd_rd;
	wire sd_wr;
	wire sd_ack;
	wire iol_ack;
	localparam signed [31:0] IOL_AW = 9;
	localparam signed [31:0] IOL_HWM = 256;
	reg [42:0] iol_fifo [0:511];
	reg [IOL_AW:0] iol_wp;
	reg [IOL_AW:0] iol_rp;
	wire [IOL_AW:0] iol_occ = iol_wp - iol_rp;
	wire iol_full = iol_occ == 512;
	wire iol_empty = iol_wp == iol_rp;
	reg iol_hold;
	reg [24:0] iol_addr_r;
	reg [15:0] iol_din_r;
	reg [1:0] iol_be_r;
	reg [31:0] iol_drop_cnt;
	reg [31:0] iol_wr_cnt;
	always @(posedge clk)
		if (sdram_por) begin
			iol_wp <= 1'sb0;
			iol_rp <= 1'sb0;
			iol_hold <= 1'b0;
			iol_drop_cnt <= 1'sb0;
			iol_wr_cnt <= 1'sb0;
		end
		else begin
			if (ioctl_wr && !iol_full) begin
				iol_fifo[iol_wp[8:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
				iol_wp <= iol_wp + 1'b1;
				iol_wr_cnt <= iol_wr_cnt + 1'b1;
			end
			else if (ioctl_wr && iol_full)
				iol_drop_cnt <= iol_drop_cnt + 1'b1;
			if (iol_hold && iol_ack)
				iol_hold <= 1'b0;
			if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin
				{iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[8:0]];
				iol_hold <= 1'b1;
				iol_rp <= iol_rp + 1'b1;
			end
		end
	assign ioctl_wait = iol_occ >= IOL_HWM[IOL_AW:0];
	wire unp_rd;
	wire unp_wr;
	wire unp_ack;
	wire [24:0] unp_addr;
	wire [15:0] unp_din;
	wire [15:0] unp_dout;
	wire boot_unp = unp_rd | unp_wr;
	wire b_iol_rd = unp_rd;
	wire b_iol_wr = (boot_unp ? unp_wr : iol_hold);
	wire [24:0] b_iol_addr = (boot_unp ? unp_addr : iol_addr_r);
	wire [15:0] b_iol_din = (boot_unp ? unp_din : iol_din_r);
	wire [1:0] b_iol_be = (boot_unp ? 2'b11 : iol_be_r);
	wire [15:0] iol_dout;
	assign unp_dout = iol_dout;
	assign unp_ack = iol_ack & boot_unp;
	yunit_sdram_arb #(
		.SD_AW(25),
		.GFXW_BASE(GFXW_BASE),
		.ROMW_BASE(ROMW_BASE),
		.VRAMW_BASE(VRAMW_BASE),
		.GFX_BYTES(GFX_BYTES)
	) u_arb(
		.clk(clk),
		.rst(sdram_por),
		.vsd_addr(25'd0),
		.vsd_din(16'd0),
		.vsd_be(2'd0),
		.vsd_rd(1'b0),
		.vsd_wr(1'b0),
		.vsd_dout(),
		.vsd_ack(),
		.snd_rd(1'b0),
		.snd_addr_w(25'd0),
		.snd_data(),
		.snd_ack(),
		.cgfx_rd(cgfx_rd),
		.cgfx_addr(cgfx_addr),
		.cgfx_data(cgfx_data),
		.cgfx_ack(cgfx_ack),
		.src_rd(1'b0),
		.src_addr(24'd0),
		.src_data(),
		.src_ack(),
		.iol_rd(b_iol_rd),
		.iol_wr(b_iol_wr),
		.iol_addr(b_iol_addr),
		.iol_din(b_iol_din),
		.iol_be(b_iol_be),
		.iol_dout(iol_dout),
		.iol_ack(iol_ack),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack)
	);
	reg dl_q;
	reg dl_seen;
	reg unp_pending;
	reg unp_start;
	wire unp_fsm_done;
	always @(posedge clk) begin
		dl_q <= ioctl_download;
		unp_start <= 1'b0;
		if (sdram_por) begin
			dl_seen <= 1'b0;
			unp_pending <= 1'b0;
		end
		else begin
			if (ioctl_download)
				dl_seen <= 1'b1;
			if (dl_q & ~ioctl_download)
				unp_pending <= 1'b1;
			else if (unp_pending & ~iol_hold) begin
				unp_pending <= 1'b0;
				unp_start <= 1'b1;
			end
		end
	end
	yunit_gfx_unpack #(
		.SD_AW(25),
		.SCRATCH_WBASE(SCRATCH_WBASE),
		.GFXW_BASE(GFXW_BASE),
		.PLANE_WORDS(PLANE_WORDS)
	) u_unpack(
		.clk(clk),
		.rst(sdram_por),
		.start(unp_start),
		.busy(),
		.done(unp_fsm_done),
		.unp_rd(unp_rd),
		.unp_wr(unp_wr),
		.unp_addr(unp_addr),
		.unp_din(unp_din),
		.unp_dout(unp_dout),
		.unp_ack(unp_ack)
	);
	assign unp_done = ~dl_seen | unp_fsm_done;
	wire brd_req;
	wire [24:0] brd_addr;
	wire [9:0] brd_len;
	wire [15:0] brd_dout;
	wire brd_dvalid;
	wire brd_done;
	yunit_src_cache #(.GFXW_BASE(GFXW_BASE[23:0])) u_srccache(
		.clk(clk),
		.rst(core_rst),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.brd_req(brd_req),
		.brd_addr(brd_addr),
		.brd_len(brd_len),
		.brd_dout(brd_dout),
		.brd_dvalid(brd_dvalid),
		.brd_done(brd_done)
	);
	wire [24:0] ctl_addr;
	wire [15:0] ctl_din;
	wire [15:0] ctl_dout;
	wire [1:0] ctl_wtbt;
	wire ctl_rd;
	wire ctl_we;
	wire ctl_ready;
	yunit_sdram_adapter u_sdadapt(
		.clk(clk),
		.rst(sdram_por),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack),
		.sdram_ready(sdram_ready),
		.ctl_addr(ctl_addr),
		.ctl_din(ctl_din),
		.ctl_wtbt(ctl_wtbt),
		.ctl_rd(ctl_rd),
		.ctl_we(ctl_we),
		.ctl_dout(ctl_dout),
		.ctl_ready(ctl_ready)
	);
	sdram_stock u_sdram(
		.init(sdram_por),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready),
		.brd_req(brd_req),
		.brd_addr(brd_addr),
		.brd_len(brd_len),
		.brd_dout(brd_dout),
		.brd_dvalid(brd_dvalid),
		.brd_done(brd_done),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	(* preserve *) reg [1:0] trig_sync;
	(* preserve *) reg [1:0] rst_sync;
	reg [7:0] sel_sync;
	reg strig_snd;
	always @(posedge clk_snd) begin
		trig_sync <= {trig_sync[0], snd_trig};
		rst_sync <= {rst_sync[0], snd_reset};
		sel_sync <= snd_select;
		strig_snd <= trig_sync[1];
	end
	wire [7:0] pia_audio;
	wire [15:0] speech_out;
	wire signed [15:0] ym_l;
	wire signed [15:0] ym_r;
	wire [31:0] snd_dbg;
	williams_cvsd_board u_board(
		.clock_12(clk_snd),
		.reset(rst_sync[1]),
		.reset_pon(rst_pon),
		.sound_select(sel_sync),
		.sound_trig(strig_snd),
		.pia_audio(pia_audio),
		.speech_out(speech_out),
		.ym2151_left(ym_l),
		.ym2151_right(ym_r),
		.dbg_out(snd_dbg),
		.snd_dl_clk(clk),
		.snd_dl_addr(snd_dl_addr),
		.snd_dl_data(snd_dl_data),
		.snd_dl_we(snd_dl_wr)
	);
	wire signed [15:0] speech_s = $signed({1'b0, speech_out}) - 16'sd16384;
	wire signed [15:0] pia_s = {{8 {pia_audio[7]}}, pia_audio} <<< 6;
	always @(posedge clk_snd) begin
		audio_l <= (ym_l + (speech_s >>> 1)) + (pia_s >>> 2);
		audio_r <= (ym_r + (speech_s >>> 1)) + (pia_s >>> 2);
	end
	assign dbg_core_rst = core_rst;
	assign dbg_sdram_ready = sdram_ready;
	assign dbg_unp_done = unp_done;
	assign dbg_cpu_req = cpu_req;
	assign dbg_mem_ack = mem_ack;
	assign dbg_int1 = int1;
	assign dbg_vblank_irq = vblank_irq;
	assign dbg_src_data = src_data;
	assign dbg_src_ack = src_ack;
	assign dbg_scan_data = scan_data;
	assign dbg_scan_ack = scan_ack;
	assign dbg_cpu_ce = cpu_ce;
	assign dbg_iol_drop = iol_drop_cnt;
	assign dbg_iol_wrs = iol_wr_cnt;
	reg [1:0] rd_cnt;
	reg ack_q;
	reg d_started;
	reg [31:0] d_prevpc;
	always @(posedge clk)
		if (cpu_ce) begin
			if (core_rst_sys) begin
				dbg_derailed <= 1'b0;
				rd_cnt <= 2'd0;
				ack_q <= 1'b0;
				d_started <= 1'b0;
				d_prevpc <= 32'hffffffff;
				dbg_culprit_pc <= 32'hdeadbeef;
				dbg_culprit_instr <= 16'h0000;
				dbg_derail_pc <= 32'hdeadbeef;
			end
			else begin
				ack_q <= cpu_ack;
				if (((cpu_ack && !ack_q) && !cpu_we) && (rd_cnt == 2'd0)) begin
					dbg_culprit_pc <= cpu_rdata;
					rd_cnt <= 2'd1;
				end
				if (pc_dbg !== d_prevpc) begin
					if (pc_dbg == 32'hffe0f5c0) begin
						dbg_derail_pc <= d_prevpc;
						dbg_culprit_instr <= dbg_culprit_instr + 16'd1;
					end
					d_prevpc <= pc_dbg;
					if (pc_dbg[31:23] == 9'h1ff)
						d_started <= 1'b1;
				end
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module zunit_download (
	clk,
	dl_en,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	sd_wr,
	sd_addr,
	sd_dout,
	sd_be
);
	localparam signed [31:0] zunit_pkg_SDRAM_AW = 25;
	localparam signed [31:0] zunit_pkg_GFX_POPULATED_BYTES = 'h3c0000;
	localparam signed [31:0] zunit_pkg_SDRAM_GFX_WORDS = zunit_pkg_GFX_POPULATED_BYTES >> 1;
	function automatic signed [24:0] sv2v_cast_25_signed;
		input reg signed [24:0] inp;
		sv2v_cast_25_signed = inp;
	endfunction
	localparam [24:0] zunit_pkg_SDRAM_ROMW_BASE = sv2v_cast_25_signed(zunit_pkg_SDRAM_GFX_WORDS);
	function automatic [24:0] sv2v_cast_25;
		input reg [24:0] inp;
		sv2v_cast_25 = inp;
	endfunction
	parameter [24:0] ROMW_BASE = sv2v_cast_25(zunit_pkg_SDRAM_ROMW_BASE);
	localparam [24:0] zunit_pkg_SDRAM_GFXW_BASE = 1'sb0;
	parameter [24:0] GFXW_BASE = sv2v_cast_25(zunit_pkg_SDRAM_GFXW_BASE);
	localparam signed [31:0] zunit_pkg_PROG_POPULATED_BYTES = 'h80000;
	localparam signed [31:0] zunit_pkg_SDRAM_PROG_WORDS = zunit_pkg_PROG_POPULATED_BYTES >> 1;
	localparam signed [31:0] zunit_pkg_FB_H = 512;
	localparam signed [31:0] zunit_pkg_FB_W = 512;
	localparam signed [31:0] zunit_pkg_SDRAM_VRAM_WORDS = zunit_pkg_FB_W * zunit_pkg_FB_H;
	localparam [24:0] zunit_pkg_SDRAM_SNDW_BASE = sv2v_cast_25_signed((zunit_pkg_SDRAM_GFX_WORDS + zunit_pkg_SDRAM_PROG_WORDS) + zunit_pkg_SDRAM_VRAM_WORDS);
	parameter [24:0] SNDW_BASE = sv2v_cast_25(zunit_pkg_SDRAM_SNDW_BASE);
	input wire clk;
	input wire dl_en;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [7:0] ioctl_dout;
	output reg sd_wr;
	output reg [24:0] sd_addr;
	output reg [15:0] sd_dout;
	output reg [1:0] sd_be;
	localparam [24:0] PROG_END = 25'h0080000;
	localparam [24:0] GFX_END = 25'h0880000;
	localparam [24:0] GFX_QUAD_POP = 25'h00f0000;
	wire is_prog = ioctl_addr < PROG_END;
	wire is_gfx = (ioctl_addr >= PROG_END) && (ioctl_addr < GFX_END);
	localparam [24:0] zunit_pkg_SND_STREAM_BASE = 25'h0880000;
	localparam [24:0] zunit_pkg_SND_STREAM_END = 25'h09a0000;
	wire is_snd = (ioctl_addr >= zunit_pkg_SND_STREAM_BASE) && (ioctl_addr < zunit_pkg_SND_STREAM_END);
	wire [24:0] prog_word = ROMW_BASE + {1'b0, ioctl_addr[24:1]};
	wire [24:0] raw_off = ioctl_addr - PROG_END;
	wire [1:0] gq = raw_off[22:21];
	wire [20:0] gk = raw_off[20:0];
	wire gfx_pop = gk < GFX_QUAD_POP;
	wire [24:0] gfx_word = (GFXW_BASE + {3'b000, gk, 1'b0}) + {24'b000000000000000000000000, gq[1]};
	wire [24:0] snd_off = ioctl_addr - zunit_pkg_SND_STREAM_BASE;
	wire [24:0] snd_word = SNDW_BASE + {1'b0, snd_off[24:1]};
	reg [7:0] prog_lo;
	always @(posedge clk) begin
		sd_wr <= 1'b0;
		if (dl_en & ioctl_wr) begin
			if (is_prog) begin
				if (~ioctl_addr[0])
					prog_lo <= ioctl_dout;
				else begin
					sd_addr <= prog_word;
					sd_dout <= {ioctl_dout, prog_lo};
					sd_be <= 2'b11;
					sd_wr <= 1'b1;
				end
			end
			else if (is_gfx & gfx_pop) begin
				sd_addr <= gfx_word;
				sd_be <= (gq[0] ? 2'b10 : 2'b01);
				sd_dout <= (gq[0] ? {ioctl_dout, 8'h00} : {8'h00, ioctl_dout});
				sd_wr <= 1'b1;
			end
			else if (is_snd) begin
				sd_addr <= snd_word;
				sd_be <= (snd_off[0] ? 2'b10 : 2'b01);
				sd_dout <= (snd_off[0] ? {ioctl_dout, 8'h00} : {8'h00, ioctl_dout});
				sd_wr <= 1'b1;
			end
		end
	end
endmodule
`default_nettype wire
`default_nettype none
module zunit_iol_audit (
	clk,
	por,
	ioctl_wr,
	iol_full,
	ioctl_download,
	core_rst,
	accepted,
	dropped,
	rst_during_dl
);
	input wire clk;
	input wire por;
	input wire ioctl_wr;
	input wire iol_full;
	input wire ioctl_download;
	input wire core_rst;
	output reg [31:0] accepted;
	output reg [31:0] dropped;
	output reg rst_during_dl;
	wire push = ioctl_wr & ~iol_full;
	wire drop = ioctl_wr & iol_full;
	always @(posedge clk)
		if (por) begin
			accepted <= 32'd0;
			dropped <= 32'd0;
			rst_during_dl <= 1'b0;
		end
		else begin
			if (push)
				accepted <= accepted + 32'd1;
			if (drop)
				dropped <= dropped + 32'd1;
			if (ioctl_download & core_rst)
				rst_during_dl <= 1'b1;
		end
endmodule
`default_nettype wire
`default_nettype none
module zunit_boot_readback_audit (
	clk,
	por,
	sdram_ready,
	ioctl_download,
	fifo_empty,
	fifo_hold,
	iol_ack,
	iol_dout,
	iol_rd,
	iol_addr,
	data,
	valid
);
	parameter [24:0] VEC_LO_ADDR = 25'h021fffe;
	parameter [24:0] VEC_HI_ADDR = 25'h021ffff;
	input wire clk;
	input wire por;
	input wire sdram_ready;
	input wire ioctl_download;
	input wire fifo_empty;
	input wire fifo_hold;
	input wire iol_ack;
	input wire [15:0] iol_dout;
	output reg iol_rd;
	output reg [24:0] iol_addr;
	output reg [31:0] data;
	output reg valid;
	reg [2:0] state;
	reg dl_seen;
	always @(posedge clk)
		if (por) begin
			state <= 3'd0;
			dl_seen <= 1'b0;
			iol_rd <= 1'b0;
			iol_addr <= 25'd0;
			data <= 32'd0;
			valid <= 1'b0;
		end
		else begin
			if (ioctl_download)
				dl_seen <= 1'b1;
			case (state)
				3'd0:
					if ((((dl_seen && !ioctl_download) && fifo_empty) && !fifo_hold) && sdram_ready) begin
						iol_addr <= VEC_LO_ADDR;
						iol_rd <= 1'b1;
						state <= 3'd1;
					end
				3'd1:
					if (iol_ack) begin
						data[15:0] <= iol_dout;
						iol_rd <= 1'b0;
						state <= 3'd2;
					end
				3'd2: begin
					iol_addr <= VEC_HI_ADDR;
					iol_rd <= 1'b1;
					state <= 3'd3;
				end
				3'd3:
					if (iol_ack) begin
						data[31:16] <= iol_dout;
						iol_rd <= 1'b0;
						valid <= 1'b1;
						state <= 3'd4;
					end
				default: begin
					iol_rd <= 1'b0;
					state <= 3'd4;
				end
			endcase
		end
endmodule
`default_nettype wire
`default_nettype none
module zunit_rom_chksum_audit (
	clk,
	por,
	sdram_ready,
	ioctl_download,
	fifo_empty,
	fifo_hold,
	iol_ack,
	iol_dout,
	iol_rd,
	iol_addr,
	w0,
	w1,
	w2,
	w3,
	valid
);
	reg _sv2v_0;
	parameter [24:0] SWEEP_BASE = 25'h0200000;
	parameter signed [31:0] SWEEP_WORDS = 25'h0020000;
	parameter signed [31:0] NBLK = 8;
	input wire clk;
	input wire por;
	input wire sdram_ready;
	input wire ioctl_download;
	input wire fifo_empty;
	input wire fifo_hold;
	input wire iol_ack;
	input wire [15:0] iol_dout;
	output reg iol_rd;
	output reg [24:0] iol_addr;
	output reg [31:0] w0;
	output reg [31:0] w1;
	output reg [31:0] w2;
	output reg [31:0] w3;
	output reg valid;
	localparam signed [31:0] BLKWORDS = SWEEP_WORDS / NBLK;
	localparam signed [31:0] CNTW = $clog2(SWEEP_WORDS + 1);
	reg [1:0] state;
	reg dl_seen;
	reg [CNTW - 1:0] word_idx;
	reg [7:0] hi_xor;
	reg [7:0] lo_xor;
	reg [15:0] hi_sum;
	reg [7:0] block_xor [0:NBLK - 1];
	reg signed [31:0] blk;
	function automatic signed [31:0] sv2v_cast_32_signed;
		input reg signed [31:0] inp;
		sv2v_cast_32_signed = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		blk = sv2v_cast_32_signed(word_idx) / BLKWORDS;
	end
	function automatic signed [CNTW - 1:0] sv2v_cast_1954F_signed;
		input reg signed [CNTW - 1:0] inp;
		sv2v_cast_1954F_signed = inp;
	endfunction
	function automatic [24:0] sv2v_cast_25;
		input reg [24:0] inp;
		sv2v_cast_25 = inp;
	endfunction
	always @(posedge clk)
		if (por) begin
			state <= 2'd0;
			dl_seen <= 1'b0;
			iol_rd <= 1'b0;
			iol_addr <= 25'd0;
			word_idx <= 1'sb0;
			hi_xor <= 8'd0;
			lo_xor <= 8'd0;
			hi_sum <= 16'd0;
			valid <= 1'b0;
			begin : sv2v_autoblock_1
				reg signed [31:0] i;
				for (i = 0; i < NBLK; i = i + 1)
					block_xor[i] <= 8'd0;
			end
		end
		else begin
			if (ioctl_download)
				dl_seen <= 1'b1;
			case (state)
				2'd0:
					if ((((dl_seen && !ioctl_download) && fifo_empty) && !fifo_hold) && sdram_ready) begin
						iol_addr <= SWEEP_BASE;
						iol_rd <= 1'b1;
						state <= 2'd1;
					end
				2'd1:
					if (iol_ack) begin
						hi_xor <= hi_xor ^ iol_dout[15:8];
						lo_xor <= lo_xor ^ iol_dout[7:0];
						hi_sum <= hi_sum + {8'd0, iol_dout[15:8]};
						block_xor[blk] <= block_xor[blk] ^ iol_dout[15:8];
						iol_rd <= 1'b0;
						if (word_idx == sv2v_cast_1954F_signed(SWEEP_WORDS - 1))
							state <= 2'd3;
						else begin
							word_idx <= word_idx + 1'b1;
							state <= 2'd2;
						end
					end
				2'd2: begin
					iol_addr <= SWEEP_BASE + sv2v_cast_25(word_idx);
					iol_rd <= 1'b1;
					state <= 2'd1;
				end
				default: begin
					iol_rd <= 1'b0;
					valid <= 1'b1;
					state <= 2'd3;
				end
			endcase
		end
	always @(*) begin
		if (_sv2v_0)
			;
		w0 = {hi_xor, lo_xor, hi_sum};
		w1 = {block_xor[3], block_xor[2], block_xor[1], block_xor[0]};
		w2 = {block_xor[7], block_xor[6], block_xor[5], block_xor[4]};
		w3 = {valid, 16'h0000, word_idx[CNTW - 1:0]};
	end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module zunit_snd_rom (
	clk,
	rst,
	mst_offset,
	mst_read,
	mst_data,
	slv_offset,
	slv_read,
	slv_data,
	ready,
	snd_rd,
	snd_addr_w,
	snd_data,
	snd_ack,
	stall_clks,
	wd_rearms
);
	parameter signed [31:0] SD_AW = 25;
	parameter [SD_AW - 1:0] SNDW_BASE = 1'sb0;
	parameter signed [31:0] IMAGE_WORDS = 32'h00048000;
	input wire clk;
	input wire rst;
	input wire [19:0] mst_offset;
	input wire mst_read;
	output wire [7:0] mst_data;
	input wire [19:0] slv_offset;
	input wire slv_read;
	output wire [7:0] slv_data;
	output wire ready;
	output wire snd_rd;
	output wire [SD_AW - 1:0] snd_addr_w;
	input wire [15:0] snd_data;
	input wire snd_ack;
	output reg [31:0] stall_clks;
	output reg [31:0] wd_rearms;
	reg [19:0] off_r1 [0:1];
	reg [19:0] off_r2 [0:1];
	reg read_r1 [0:1];
	reg read_r2 [0:1];
	always @(posedge clk)
		if (rst) begin
			off_r1[0] <= 20'd0;
			off_r2[0] <= 20'd1;
			off_r1[1] <= 20'd0;
			off_r2[1] <= 20'd1;
			read_r1[0] <= 1'b0;
			read_r2[0] <= 1'b0;
			read_r1[1] <= 1'b0;
			read_r2[1] <= 1'b0;
		end
		else begin
			off_r1[0] <= mst_offset;
			off_r2[0] <= off_r1[0];
			off_r1[1] <= slv_offset;
			off_r2[1] <= off_r1[1];
			read_r1[0] <= mst_read;
			read_r2[0] <= read_r1[0];
			read_r1[1] <= slv_read;
			read_r2[1] <= read_r1[1];
		end
	wire stable0 = off_r1[0] == off_r2[0];
	wire stable1 = off_r1[1] == off_r2[1];
	reg [18:0] cur_word [0:1];
	reg [15:0] cur_dat [0:1];
	reg cur_byte [0:1];
	reg cur_val [0:1];
	wire demand0 = mst_read;
	wire demand1 = slv_read;
	wire sampled_read0 = read_r1[0] & read_r2[0];
	wire sampled_read1 = read_r1[1] & read_r2[1];
	reg [19:0] cand_off [0:1];
	reg cand_valid [0:1];
	always @(posedge clk)
		if (rst) begin
			cand_off[0] <= 20'd0;
			cand_valid[0] <= 1'b0;
			cand_off[1] <= 20'd0;
			cand_valid[1] <= 1'b0;
		end
		else begin
			cand_off[0] <= off_r2[0];
			cand_off[1] <= off_r2[1];
			cand_valid[0] <= sampled_read0 & stable0;
			cand_valid[1] <= sampled_read1 & stable1;
		end
	wire [19:0] req_off [0:1];
	assign req_off[0] = cand_off[0];
	assign req_off[1] = cand_off[1];
	wire [18:0] req_word [0:1];
	assign req_word[0] = req_off[0][19:1];
	assign req_word[1] = req_off[1][19:1];
	wire word_match0 = cur_val[0] & (cur_word[0] == req_word[0]);
	wire word_match1 = cur_val[1] & (cur_word[1] == req_word[1]);
	wire live_word0 = cur_val[0] & (cur_word[0] == mst_offset[19:1]);
	wire live_word1 = cur_val[1] & (cur_word[1] == slv_offset[19:1]);
	wire cache_match0 = word_match0;
	wire cache_match1 = word_match1;
	wire live0 = live_word0;
	wire live1 = live_word1;
	wire need0 = cand_valid[0] & ~cache_match0;
	wire need1 = cand_valid[1] & ~cache_match1;
	assign ready = (~demand0 | live0) & (~demand1 | live1);
	assign mst_data = (mst_offset[0] ? cur_dat[0][15:8] : cur_dat[0][7:0]);
	assign slv_data = (slv_offset[0] ? cur_dat[1][15:8] : cur_dat[1][7:0]);
	reg busy;
	reg lane_q;
	reg [19:0] off_q;
	wire pick = (need0 ? 1'b0 : 1'b1);
	wire [19:0] pick_off = (need0 ? req_off[0] : req_off[1]);
	localparam signed [31:0] WD_MAX = 4096;
	reg [12:0] wd_cnt;
	reg wd_gap;
	assign snd_rd = busy && !wd_gap;
	function automatic signed [SD_AW - 1:0] sv2v_cast_9C70E_signed;
		input reg signed [SD_AW - 1:0] inp;
		sv2v_cast_9C70E_signed = inp;
	endfunction
	function automatic [SD_AW - 1:0] sv2v_cast_9C70E;
		input reg [SD_AW - 1:0] inp;
		sv2v_cast_9C70E = inp;
	endfunction
	assign snd_addr_w = (SNDW_BASE + sv2v_cast_9C70E_signed((lane_q ? IMAGE_WORDS : 0))) + sv2v_cast_9C70E(off_q[19:1]);
	always @(posedge clk)
		if (rst) begin
			busy <= 1'b0;
			lane_q <= 1'b0;
			off_q <= 20'd0;
			cur_val[0] <= 1'b0;
			cur_val[1] <= 1'b0;
			cur_word[0] <= 19'd0;
			cur_word[1] <= 19'd0;
			cur_byte[0] <= 1'b0;
			cur_byte[1] <= 1'b0;
			cur_dat[0] <= 16'h0000;
			cur_dat[1] <= 16'h0000;
			stall_clks <= 32'd0;
			wd_cnt <= 13'd0;
			wd_gap <= 1'b0;
			wd_rearms <= 32'd0;
		end
		else begin
			if (!ready)
				stall_clks <= stall_clks + 32'd1;
			wd_gap <= 1'b0;
			if (!busy || snd_ack)
				wd_cnt <= 13'd0;
			else if (wd_cnt == WD_MAX[12:0]) begin
				wd_cnt <= 13'd0;
				wd_gap <= 1'b1;
				wd_rearms <= wd_rearms + 32'd1;
			end
			else
				wd_cnt <= wd_cnt + 13'd1;
			if (!busy) begin
				if (need0 | need1) begin
					busy <= 1'b1;
					lane_q <= pick;
					off_q <= pick_off;
				end
			end
			else if (snd_ack) begin
				busy <= 1'b0;
				cur_word[lane_q] <= off_q[19:1];
				cur_byte[lane_q] <= off_q[0];
				cur_dat[lane_q] <= snd_data;
				cur_val[lane_q] <= 1'b1;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module zunit_mem (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_srt,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	dma_palette,
	inputs,
	snd_select,
	snd_trig,
	snd_reset,
	snd_wr,
	snd_wdata,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	gfx_rd,
	gfx_raddr,
	gfx_rdata,
	gfx_rack,
	fb_ack,
	fb_busy,
	fb_flush,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	scan_disp_base,
	scan_vblank,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	reg _sv2v_0;
	parameter signed [31:0] ROM_WORDS = 32'h00020000;
	parameter signed [31:0] RAM_WORDS = 32'h00010000;
	parameter signed [31:0] VRAM_WORDS = 32'h00040000;
	parameter signed [31:0] PAL_WORDS = 32'h00002000;
	parameter signed [31:0] CMOS_WORDS = 32'h00004000;
	parameter signed [31:0] GFX_PIXELS = 32'h00180000;
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter GFX_HEX = "build/smashtv_gfx.hex";
	parameter signed [31:0] ROM_PROG_OFF = 32'h00060000;
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire mem_srt;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output reg [31:0] mem_rdata;
	output reg mem_ack;
	input wire fb_we;
	localparam signed [31:0] zunit_pkg_FB_ADDR_W = 18;
	input wire [17:0] fb_addr;
	input wire [15:0] fb_wdata;
	input wire [15:0] dma_palette;
	input wire [63:0] inputs;
	output reg [7:0] snd_select;
	output reg snd_trig;
	output reg snd_reset;
	output reg snd_wr;
	output reg [15:0] snd_wdata;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	output reg gfx_rd;
	output wire [23:0] gfx_raddr;
	input wire [15:0] gfx_rdata;
	input wire gfx_rack;
	output wire fb_ack;
	output wire fb_busy;
	input wire fb_flush;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	input wire [8:0] scan_disp_base;
	input wire scan_vblank;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output reg palv_we_a;
	output reg [12:0] palv_aa;
	output reg [15:0] palv_awd;
	output reg palv_we_b;
	output reg [12:0] palv_ba;
	output reg [15:0] palv_bwd;
	wire mem_srt_i = mem_srt;
	localparam [3:0] R_NONE = 4'd0;
	localparam [3:0] R_VRAM = 4'd1;
	localparam [3:0] R_RAM = 4'd2;
	localparam [3:0] R_CMOS = 4'd3;
	localparam [3:0] R_PAL = 4'd4;
	localparam [3:0] R_DMA = 4'd5;
	localparam [3:0] R_INPUT = 4'd6;
	localparam [3:0] R_PROT = 4'd7;
	localparam [3:0] R_SOUND = 4'd8;
	localparam [3:0] R_CTRL = 4'd9;
	localparam [3:0] R_GFX = 4'd10;
	localparam [3:0] R_ROM = 4'd11;
	localparam [31:0] zunit_pkg_ZMAP_RAM_BASE = 32'h01000000;
	function automatic [27:0] sv2v_cast_28;
		input reg [27:0] inp;
		sv2v_cast_28 = inp;
	endfunction
	localparam [27:0] WB_RAM = sv2v_cast_28(zunit_pkg_ZMAP_RAM_BASE >> 4);
	localparam [31:0] zunit_pkg_ZMAP_MAINDATA_BASE = 32'hff800000;
	localparam [27:0] WB_ROM = sv2v_cast_28(zunit_pkg_ZMAP_MAINDATA_BASE >> 4);
	localparam [31:0] zunit_pkg_ZMAP_VRAM_BASE = 32'h00000000;
	localparam [27:0] WB_VRAM = sv2v_cast_28(zunit_pkg_ZMAP_VRAM_BASE >> 4);
	localparam [31:0] zunit_pkg_ZMAP_PAL_BASE = 32'h01800000;
	localparam [27:0] WB_PAL = sv2v_cast_28(zunit_pkg_ZMAP_PAL_BASE >> 4);
	localparam [31:0] zunit_pkg_ZMAP_CMOS_BASE = 32'h01400000;
	localparam [27:0] WB_CMOS = sv2v_cast_28(zunit_pkg_ZMAP_CMOS_BASE >> 4);
	localparam [31:0] zunit_pkg_ZMAP_INPUT_BASE = 32'h01c00000;
	localparam [27:0] WB_INPUT = sv2v_cast_28(zunit_pkg_ZMAP_INPUT_BASE >> 4);
	localparam [31:0] zunit_pkg_ZMAP_GFX_BASE = 32'h02000000;
	localparam [27:0] WB_GFX = sv2v_cast_28(zunit_pkg_ZMAP_GFX_BASE >> 4);
	function automatic signed [27:0] sv2v_cast_28_signed;
		input reg signed [27:0] inp;
		sv2v_cast_28_signed = inp;
	endfunction
	localparam [27:0] ROM_PROG_OFF_W = sv2v_cast_28_signed(ROM_PROG_OFF);
	(* ramstyle = "no_rw_check" *) reg [15:0] ram [0:RAM_WORDS - 1];
	(* ramstyle = "no_rw_check" *) reg [15:0] pal [0:PAL_WORDS - 1];
	reg videobank = 1'b0;
	reg [1:0] cmos_page = 2'd0;
	reg autoerase = 1'b0;
	reg er_run = 1'b0;
	wire [8:0] er_row;
	wire [8:0] er_x;
	wire [9:0] er_left;
	(* ramstyle = "no_rw_check" *) reg [15:0] nvram [0:CMOS_WORDS - 1];
	localparam [3:0] M_IDLE = 4'd0;
	localparam [3:0] M_ACK = 4'd1;
	localparam [3:0] M_GFX = 4'd2;
	localparam [3:0] M_HR1 = 4'd3;
	localparam [3:0] M_HR2 = 4'd4;
	localparam [3:0] M_HFIN = 4'd5;
	localparam [3:0] M_HW2 = 4'd6;
	localparam [3:0] M_VRD = 4'd7;
	localparam [3:0] M_VWR0 = 4'd8;
	localparam [3:0] M_VWR1 = 4'd9;
	localparam [3:0] M_VWW0 = 4'd10;
	localparam [3:0] M_VWW1 = 4'd11;
	localparam [3:0] M_VSD = 4'd12;
	localparam [3:0] M_HFIN2 = 4'd13;
	localparam [3:0] M_RDLY = 4'd14;
	localparam [3:0] M_SBH = 4'd15;
	localparam [4:0] M_EXD = 5'd16;
	reg [4:0] state;
	localparam signed [31:0] zunit_pkg_GFX_POPULATED_BYTES = 'h3c0000;
	function automatic signed [23:0] sv2v_cast_24_signed;
		input reg signed [23:0] inp;
		sv2v_cast_24_signed = inp;
	endfunction
	localparam [23:0] zunit_pkg_SDRAM_GFX_BYTES = sv2v_cast_24_signed(zunit_pkg_GFX_POPULATED_BYTES);
	localparam [23:0] SDRAM_ROMB = zunit_pkg_SDRAM_GFX_BYTES;
	localparam signed [31:0] zunit_pkg_PROG_POPULATED_BYTES = 'h80000;
	localparam signed [31:0] zunit_pkg_SDRAM_PROG_WORDS = zunit_pkg_PROG_POPULATED_BYTES >> 1;
	localparam [27:0] EXT_PROG_WORDS = sv2v_cast_28_signed(zunit_pkg_SDRAM_PROG_WORDS);
	reg [23:0] gfx_base;
	reg [1:0] gfx_cnt;
	reg [1:0] gfx_need;
	reg gfx_isrom;
	reg [15:0] gw0;
	reg [15:0] gw1;
	reg [23:0] gfx_raddr_q;
	reg [3:0] boff_r;
	reg [47:0] rmask_r;
	localparam signed [31:0] SB_N = 8;
	reg [15:0] sb_q [0:7];
	reg [22:0] sb_base;
	reg [3:0] sb_fill;
	reg sb_vld;
	reg pf_run;
	reg pf_busy;
	reg [31:0] a_q;
	reg we_q;
	reg srt_q;
	reg [31:0] wd_q;
	reg [5:0] sz_q;
	wire [27:0] widx = a_q[31:4];
	wire [3:0] boff = a_q[3:0];
	wire [5:0] sz = sz_q;
	reg [3:0] region;
	always @(*) begin
		if (_sv2v_0)
			;
		(* full_case, parallel_case *)
		casez (a_q[31:20])
			12'h000, 12'h001: region = R_VRAM;
			12'h010: region = R_RAM;
			12'h014: region = R_CMOS;
			12'h018: region = R_PAL;
			12'h01a: region = R_DMA;
			12'h01c: region = (a_q[7:4] >= 4'd6 ? R_PROT : R_INPUT);
			12'h01e: region = R_SOUND;
			12'h01f: region = R_CTRL;
			12'h020, 12'h021, 12'h022, 12'h023, 12'h024, 12'h025, 12'h026, 12'h027, 12'h028, 12'h029, 12'h02a, 12'h02b, 12'h02c, 12'h02d, 12'h02e, 12'h02f, 12'h030, 12'h031, 12'h032, 12'h033, 12'h034, 12'h035, 12'h036, 12'h037, 12'h038, 12'h039, 12'h03a, 12'h03b, 12'h03c, 12'h03d, 12'h03e, 12'h03f, 12'h040, 12'h041, 12'h042, 12'h043, 12'h044, 12'h045, 12'h046, 12'h047, 12'h048, 12'h049, 12'h04a, 12'h04b, 12'h04c, 12'h04d, 12'h04e, 12'h04f, 12'h050, 12'h051, 12'h052, 12'h053, 12'h054, 12'h055, 12'h056, 12'h057, 12'h058, 12'h059, 12'h05a, 12'h05b, 12'h05c, 12'h05d, 12'h05e, 12'h05f: region = R_GFX;
			12'hff8, 12'hff9, 12'hffa, 12'hffb, 12'hffc, 12'hffd, 12'hffe, 12'hfff: region = R_ROM;
			default: region = R_NONE;
		endcase
	end
	wire is_hwvram = region == R_VRAM;
	localparam [27:0] ROMW = ROM_WORDS[27:0];
	localparam [27:0] RAMW = RAM_WORDS[27:0];
	localparam [27:0] VRAMW = VRAM_WORDS[27:0];
	localparam [27:0] PALW = PAL_WORDS[27:0];
	localparam [27:0] CMOSW = CMOS_WORDS[27:0];
	localparam [27:0] GFXPIXW = GFX_PIXELS[27:0];
	function automatic [15:0] read_word;
		input reg [3:0] rgn;
		input reg [27:0] gw;
		reg [27:0] rel;
		begin
			read_word = 16'h0000;
			if (rgn == R_ROM)
				;
			else if (rgn == R_RAM)
				;
			else if (rgn == R_VRAM)
				;
			else if (rgn == R_PAL)
				;
			else if (rgn == R_CMOS)
				;
			else if (rgn == R_INPUT) begin
				rel = gw - WB_INPUT;
				case (rel[1:0])
					2'd0: read_word = inputs[15:0];
					2'd1: read_word = inputs[31:16];
					2'd2: read_word = inputs[47:32];
					2'd3: read_word = inputs[63:48];
					default: read_word = 16'hffff;
				endcase
				if (rel > 28'd3)
					read_word = 16'hffff;
			end
			else if (rgn == R_GFX)
				rel = gw - WB_GFX;
		end
	endfunction
	wire [47:0] rmask = (48'd1 << sz) - 48'd1;
	wire [47:0] smask = rmask << boff;
	wire [5:0] lastb = (boff + sz) - 6'd1;
	assign gfx_raddr = gfx_raddr_q;
	always @(posedge clk) begin
		boff_r <= boff;
		rmask_r <= rmask;
	end
	reg ext_fetch;
	reg ext_isrom;
	reg [23:0] ext_base;
	reg [27:0] rom_rel;
	function automatic [23:0] sv2v_cast_24;
		input reg [23:0] inp;
		sv2v_cast_24 = inp;
	endfunction
	always @(*) begin
		if (_sv2v_0)
			;
		ext_fetch = 1'b0;
		ext_isrom = 1'b0;
		ext_base = 24'd0;
		rom_rel = widx - WB_ROM;
		if ((region == R_GFX) && !we_q) begin
			ext_fetch = 1'b1;
			ext_base = sv2v_cast_24((widx - WB_GFX) << 1);
		end
		if ((((region == R_ROM) && !we_q) && (rom_rel >= ROM_PROG_OFF_W)) && ((rom_rel - ROM_PROG_OFF_W) < EXT_PROG_WORDS)) begin
			ext_fetch = 1'b1;
			ext_isrom = 1'b1;
			ext_base = SDRAM_ROMB + sv2v_cast_24((rom_rel - ROM_PROG_OFF_W) << 1);
		end
	end
	wire [1:0] extnw = 2'd1 + lastb[5:4];
	wire [22:0] ext_waddr = ext_base[23:1];
	reg [23:0] exd_base;
	reg [22:0] exd_waddr;
	reg exd_isrom;
	reg [1:0] exd_need;
	wire [22:0] exd_off = exd_waddr - sb_base;
	wire exd_hit = ((sb_vld && exd_isrom) && (exd_off < 23'd8)) && (({1'b0, exd_off[2:0]} + {2'b00, exd_need}) <= sb_fill);
	wire [15:0] exd_w0 = sb_q[exd_off[2:0]];
	wire [15:0] exd_w1 = sb_q[exd_off[2:0] + 3'd1];
	wire [15:0] exd_w2 = sb_q[exd_off[2:0] + 3'd2];
	function automatic [22:0] sv2v_cast_23;
		input reg [22:0] inp;
		sv2v_cast_23 = inp;
	endfunction
	localparam [22:0] SB_ROM_WEND = sv2v_cast_23((SDRAM_ROMB >> 1) + EXT_PROG_WORDS);
	wire pf_inrange = (sb_base + {19'd0, sb_fill}) < SB_ROM_WEND;
	reg is_hwram;
	reg [1:0] hsel;
	reg [17:0] hidx [0:2];
	reg [1:0] hsel_q;
	reg [17:0] hidx_q [0:2];
	reg [15:0] hoff_q;
	reg hval_q [0:2];
	reg [27:0] hr;
	always @(*) begin
		if (_sv2v_0)
			;
		is_hwram = 1'b0;
		hsel = 2'd0;
		hr = 28'd0;
		begin : sv2v_autoblock_1
			reg signed [31:0] j;
			for (j = 0; j < 3; j = j + 1)
				hidx[j] = 18'd0;
		end
		if (region == R_RAM) begin
			is_hwram = 1'b1;
			hsel = 2'd0;
			begin : sv2v_autoblock_2
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_RAM;
						hidx[j] = hr[17:0];
					end
			end
		end
		else if (region == R_PAL) begin
			is_hwram = 1'b1;
			hsel = 2'd1;
			begin : sv2v_autoblock_3
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_PAL;
						hidx[j] = hr[17:0];
					end
			end
		end
		else if (region == R_CMOS) begin
			is_hwram = 1'b1;
			hsel = 2'd2;
			begin : sv2v_autoblock_4
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hr = (widx + j[27:0]) - WB_CMOS;
						hidx[j] = {4'd0, cmos_page, hr[11:0]};
					end
			end
		end
	end
	always @(posedge clk)
		if (rst) begin
			hsel_q <= 2'd0;
			hoff_q <= 16'd0;
			begin : sv2v_autoblock_5
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					begin
						hidx_q[j] <= 18'd0;
						hval_q[j] <= 1'b0;
					end
			end
		end
		else if ((state == M_ACK) && is_hwram) begin
			hsel_q <= hsel;
			hoff_q <= widx[15:0];
			begin : sv2v_autoblock_6
				reg signed [31:0] j;
				for (j = 0; j < 3; j = j + 1)
					hidx_q[j] <= hidx[j];
			end
		end
		else if (state == M_HR1) begin : sv2v_autoblock_7
			reg signed [31:0] j;
			for (j = 0; j < 3; j = j + 1)
				case (hsel_q)
					2'd0: hval_q[j] <= ({12'd0, hoff_q} + j[27:0]) < RAMW;
					2'd1: hval_q[j] <= ({12'd0, hoff_q} + j[27:0]) < PALW;
					2'd2: hval_q[j] <= ({12'd0, hoff_q} + j[27:0]) < CMOSW;
					default: hval_q[j] <= 1'b0;
				endcase
		end
	wire [1:0] hsel_run = (state == M_ACK ? hsel : hsel_q);
	reg [15:0] rd0;
	reg [15:0] rd1;
	reg [15:0] rd2;
	wire [47:0] hwin = {(hval_q[2] ? rd2 : 16'h0000), (hval_q[1] ? rd1 : 16'h0000), (hval_q[0] ? rd0 : 16'h0000)};
	wire [47:0] hmerged = (hwin & ~smask) | (({16'h0000, wd_q} << boff) & smask);
	reg [47:0] smask_q;
	reg [47:0] rmask_q;
	reg [47:0] wsh_q;
	reg [47:0] hwin_q;
	reg [3:0] boff_q;
	always @(posedge clk) begin
		smask_q <= smask;
		rmask_q <= rmask;
		boff_q <= boff;
		wsh_q <= {16'h0000, wd_q} << boff;
		hwin_q <= hwin;
	end
	wire [47:0] hmerged2 = (hwin_q & ~smask_q) | (wsh_q & smask_q);
	reg [17:0] eng_aa;
	reg [17:0] eng_ba;
	reg eng_awe;
	reg eng_bwe;
	reg [15:0] eng_awd;
	reg [15:0] eng_bwd;
	reg [15:0] eng_aq;
	reg [15:0] eng_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		eng_aa = (state == M_ACK ? hidx[0] : hidx_q[0]);
		eng_ba = (state == M_ACK ? hidx[1] : hidx_q[1]);
		eng_awe = 1'b0;
		eng_bwe = 1'b0;
		eng_awd = hmerged2[15:0];
		eng_bwd = hmerged2[31:16];
		case (state)
			M_HR1: eng_aa = hidx_q[2];
			M_HFIN2:
				if (we_q) begin
					eng_aa = hidx_q[0];
					eng_awe = hval_q[0];
					eng_ba = hidx_q[1];
					eng_bwe = (lastb >= 6'd16) & hval_q[1];
				end
			M_HW2: begin
				eng_aa = hidx_q[2];
				eng_awe = (lastb >= 6'd32) & hval_q[2];
				eng_awd = hmerged2[47:32];
			end
			default:
				;
		endcase
	end
	reg [16:0] ram_aa;
	reg [16:0] ram_ba;
	reg ram_awe;
	reg ram_bwe;
	reg [15:0] ram_awd;
	reg [15:0] ram_bwd;
	reg [15:0] ram_aq;
	reg [15:0] ram_bq;
	reg [12:0] pal_aa;
	reg [12:0] pal_ba;
	reg pal_awe;
	reg pal_bwe;
	reg [15:0] pal_awd;
	reg [15:0] pal_bwd;
	reg [15:0] pal_aq;
	reg [15:0] pal_bq;
	reg [14:0] nv_aa;
	reg [14:0] nv_ba;
	reg nv_awe;
	reg nv_bwe;
	reg [15:0] nv_awd;
	reg [15:0] nv_bwd;
	reg [15:0] nv_aq;
	reg [15:0] nv_bq;
	always @(*) begin
		if (_sv2v_0)
			;
		ram_aa = eng_aa[16:0];
		ram_ba = eng_ba[16:0];
		ram_awd = eng_awd;
		ram_bwd = eng_bwd;
		pal_aa = eng_aa[12:0];
		pal_ba = eng_ba[12:0];
		pal_awd = eng_awd;
		pal_bwd = eng_bwd;
		nv_aa = eng_aa[14:0];
		nv_ba = eng_ba[14:0];
		nv_awd = eng_awd;
		nv_bwd = eng_bwd;
		ram_awe = (hsel_run == 2'd0) & eng_awe;
		ram_bwe = (hsel_run == 2'd0) & eng_bwe;
		pal_awe = (hsel_run == 2'd1) & eng_awe;
		pal_bwe = (hsel_run == 2'd1) & eng_bwe;
		nv_awe = (hsel_run == 2'd2) & eng_awe;
		nv_bwe = (hsel_run == 2'd2) & eng_bwe;
		eng_aq = (hsel_run == 2'd0 ? ram_aq : (hsel_run == 2'd1 ? pal_aq : nv_aq));
		eng_bq = (hsel_run == 2'd0 ? ram_bq : (hsel_run == 2'd1 ? pal_bq : nv_bq));
	end
	always @(posedge clk) begin
		if (ram_awe)
			ram[ram_aa] <= ram_awd;
		ram_aq <= ram[ram_aa];
	end
	always @(posedge clk) begin
		if (ram_bwe)
			ram[ram_ba] <= ram_bwd;
		ram_bq <= ram[ram_ba];
	end
	always @(posedge clk) begin
		if (pal_awe)
			pal[pal_aa] <= pal_awd;
		pal_aq <= pal[pal_aa];
	end
	always @(posedge clk) begin
		if (pal_bwe)
			pal[pal_ba] <= pal_bwd;
		pal_bq <= pal[pal_ba];
	end
	always @(posedge clk) begin
		if (nv_awe)
			nvram[nv_aa] <= nv_awd;
		nv_aq <= nvram[nv_aa];
	end
	always @(posedge clk) begin
		if (nv_bwe)
			nvram[nv_ba] <= nv_bwd;
		nv_bq <= nvram[nv_ba];
	end
	always @(posedge clk) begin
		palv_we_a <= pal_awe;
		palv_aa <= pal_aa;
		palv_awd <= pal_awd;
		palv_we_b <= pal_bwe;
		palv_ba <= pal_ba;
		palv_bwd <= pal_bwd;
	end
	reg vsd_req;
	wire vsd_done;
	wire [31:0] vsd_rdata;
	localparam signed [31:0] zunit_pkg_SCR_V_VIS_EN = 427;
	localparam signed [31:0] zunit_pkg_SCR_V_VIS_ST = 27;
	localparam signed [31:0] zunit_pkg_SCR_VIS_H = zunit_pkg_SCR_V_VIS_EN - zunit_pkg_SCR_V_VIS_ST;
	stv_vram_ddr_top #(
		.VRAMW(VRAM_WORDS),
		.VRAM_DDR_BASE(29'h06400000),
		.D_SHADOW_RMW_BYPASS(1'b1),
		.D_WRITE_FIFO(1'b1),
		.D_BEAT_FIFO(1'b0),
		.ERASE_ROWS(zunit_pkg_SCR_VIS_H),
		.ERASE_FIRST_REL(80),
		.C_FAIR(1'b0)
	) u_vram_sdram(
		.clk(clk),
		.rst(rst),
		.sdram_por(sdram_por),
		.req(vsd_req),
		.we(we_q),
		.srt(srt_q),
		.widx(widx),
		.boff(boff),
		.sz(sz_q),
		.wd(wd_q),
		.videobank(videobank),
		.dma_palette(dma_palette),
		.rdata(vsd_rdata),
		.done(vsd_done),
		.fb_we(fb_we),
		.fb_addr(fb_addr),
		.fb_wdata(fb_wdata),
		.fb_ack(fb_ack),
		.fb_busy(fb_busy),
		.fb_flush(fb_flush),
		.erase_en(autoerase),
		.erase_busy(erase_busy),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.disp_base(scan_disp_base),
		.scan_blank(scan_vblank),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready)
	);
	reg [47:0] win_s;
	reg [47:0] merged_s;
	reg [47:0] win_s_q;
	wire [27:0] wrel;
	function automatic [31:0] sv2v_cast_32;
		input reg [31:0] inp;
		sv2v_cast_32 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			state <= M_IDLE;
			mem_ack <= 1'b0;
			mem_rdata <= 32'h00000000;
			snd_select <= 8'h00;
			snd_trig <= 1'b0;
			snd_reset <= 1'b1;
			snd_wr <= 1'b0;
			snd_wdata <= 16'h0000;
			er_run <= 1'b0;
			gfx_rd <= 1'b0;
			sb_vld <= 1'b0;
			sb_fill <= 4'd0;
			sb_base <= 23'd0;
			pf_run <= 1'b0;
			pf_busy <= 1'b0;
			vsd_req <= 1'b0;
		end
		else begin
			snd_wr <= 1'b0;
			if (pf_busy && gfx_rack) begin
				pf_busy <= 1'b0;
				gfx_rd <= 1'b0;
				if ((pf_run && sb_vld) && (sb_fill < SB_N)) begin
					sb_q[sb_fill[2:0]] <= gfx_rdata;
					sb_fill <= sb_fill + 4'd1;
				end
			end
			else if (((((((((pf_run && sb_vld) && !pf_busy) && !gfx_rd) && (sb_fill < SB_N)) && pf_inrange) && (state != M_GFX)) && (state != M_SBH)) && (state != M_EXD)) && !((state == M_ACK) && ext_fetch)) begin
				gfx_raddr_q <= {sb_base + {19'd0, sb_fill}, 1'b0};
				gfx_rd <= 1'b1;
				pf_busy <= 1'b1;
			end
			(* full_case, parallel_case *)
			case (state)
				M_IDLE: begin
					mem_ack <= 1'b0;
					if (mem_req && !mem_ack) begin
						a_q <= mem_addr;
						we_q <= mem_we;
						srt_q <= mem_srt_i;
						wd_q <= mem_wdata;
						sz_q <= mem_size;
						if (mem_we) begin
							sb_vld <= 1'b0;
							pf_run <= 1'b0;
						end
						state <= M_ACK;
					end
				end
				M_ACK:
					if (ext_fetch) begin
						mem_ack <= 1'b0;
						exd_base <= ext_base;
						exd_waddr <= ext_waddr;
						exd_isrom <= ext_isrom;
						exd_need <= extnw;
						state <= M_EXD;
					end
					else if (srt_q) begin
						mem_ack <= 1'b0;
						vsd_req <= 1'b1;
						state <= M_VSD;
					end
					else if (is_hwram) begin
						mem_ack <= 1'b0;
						state <= M_HR1;
					end
					else if (is_hwvram) begin
						mem_ack <= 1'b0;
						vsd_req <= 1'b1;
						state <= M_VSD;
					end
					else begin
						win_s = {read_word(region, widx + 28'd2), read_word(region, widx + 28'd1), read_word(region, widx)};
						merged_s = (win_s & ~smask) | (({16'h0000, wd_q} << boff) & smask);
						if (we_q) begin
							(* full_case, parallel_case *)
							case (region)
								default:
									;
							endcase
							if (region == R_CTRL) begin
								videobank <= wd_q[5];
								cmos_page <= wd_q[7:6];
								autoerase <= ~wd_q[4];
							end
							if (region == R_SOUND) begin
								snd_select <= wd_q[7:0];
								snd_trig <= wd_q[9];
								snd_reset <= ~wd_q[8];
								snd_wr <= 1'b1;
								snd_wdata <= wd_q[15:0];
							end
							mem_rdata <= 32'h00000000;
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
						else begin
							win_s_q <= win_s;
							mem_ack <= 1'b0;
							state <= M_RDLY;
						end
					end
				M_EXD:
					if (exd_hit) begin
						win_s_q <= {exd_w2, exd_w1, exd_w0};
						state <= M_SBH;
					end
					else if (pf_busy)
						;
					else begin
						gfx_base <= exd_base;
						gfx_cnt <= 2'd0;
						gfx_need <= exd_need;
						gfx_isrom <= exd_isrom;
						if (exd_isrom) begin
							sb_vld <= 1'b0;
							sb_base <= exd_waddr;
							sb_fill <= 4'd0;
							pf_run <= 1'b0;
						end
						gfx_raddr_q <= exd_base;
						gfx_rd <= 1'b1;
						state <= M_GFX;
					end
				M_GFX:
					if (gfx_rack) begin
						gfx_rd <= 1'b0;
						if (gfx_isrom)
							sb_q[{1'b0, gfx_cnt}] <= gfx_rdata;
						if (gfx_cnt == 2'd0)
							gw0 <= gfx_rdata;
						if (gfx_cnt == 2'd1)
							gw1 <= gfx_rdata;
						if (({1'b0, gfx_cnt} + 3'd1) >= {1'b0, gfx_need}) begin
							win_s_q <= (gfx_need == 2'd1 ? {32'h00000000, gfx_rdata} : (gfx_need == 2'd2 ? {16'h0000, gfx_rdata, gw0} : {gfx_rdata, gw1, gw0}));
							if (gfx_isrom) begin
								sb_fill <= {2'b00, gfx_cnt} + 4'd1;
								sb_vld <= 1'b1;
								pf_run <= 1'b1;
							end
							state <= M_SBH;
						end
						else
							gfx_cnt <= gfx_cnt + 2'd1;
					end
					else if (!gfx_rd) begin
						gfx_raddr_q <= gfx_base + {21'd0, gfx_cnt, 1'b0};
						gfx_rd <= 1'b1;
					end
				M_SBH: begin
					mem_rdata <= sv2v_cast_32((win_s_q >> boff_r) & rmask_r);
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_HR1: begin
					rd0 <= eng_aq;
					rd1 <= eng_bq;
					state <= M_HR2;
				end
				M_HR2: begin
					rd2 <= eng_aq;
					state <= M_HFIN;
				end
				M_HFIN: state <= M_HFIN2;
				M_HFIN2:
					if (we_q) begin
						if ((lastb >= 6'd32) && hval_q[2])
							state <= M_HW2;
						else begin
							mem_ack <= 1'b1;
							state <= M_IDLE;
						end
					end
					else begin
						mem_rdata <= sv2v_cast_32((hwin_q >> boff_q) & rmask_q);
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				M_HW2: begin
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_RDLY: begin
					mem_rdata <= sv2v_cast_32((win_s_q >> boff_q) & rmask_q);
					mem_ack <= 1'b1;
					state <= M_IDLE;
				end
				M_VSD: begin
					vsd_req <= 1'b0;
					if (vsd_done) begin
						mem_rdata <= vsd_rdata;
						mem_ack <= 1'b1;
						state <= M_IDLE;
					end
				end
				default: begin
					state <= M_IDLE;
					mem_ack <= 1'b0;
				end
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module zunit_dma (
	clk,
	rst,
	reg_we,
	reg_addr,
	reg_wdata,
	reg_rdata,
	src_req,
	src_addr,
	src_data,
	src_ack,
	fb_we,
	fb_addr,
	fb_wdata,
	fb_ack,
	fb_flush,
	busy,
	blit_irq,
	dma_palette
);
	reg _sv2v_0;
	input wire clk;
	input wire rst;
	input wire reg_we;
	input wire [3:0] reg_addr;
	input wire [15:0] reg_wdata;
	output wire [15:0] reg_rdata;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	output wire fb_we;
	localparam signed [31:0] zunit_pkg_FB_ADDR_W = 18;
	output wire [17:0] fb_addr;
	output wire [15:0] fb_wdata;
	input wire fb_ack;
	output wire fb_flush;
	output wire busy;
	output reg blit_irq;
	output wire [15:0] dma_palette;
	localparam signed [31:0] zunit_pkg_DMA_NREGS = 16;
	reg [15:0] regf [0:15];
	reg busy_r;
	localparam [3:0] zunit_pkg_DMA_COMMAND = 4'd0;
	wire [15:0] cmd_reg = regf[zunit_pkg_DMA_COMMAND];
	localparam signed [31:0] zunit_pkg_DMA_CMD_FLIPX_BIT = 4;
	wire flipx_w = cmd_reg[zunit_pkg_DMA_CMD_FLIPX_BIT];
	localparam signed [31:0] zunit_pkg_DMA_CMD_MODE_HI = 3;
	localparam signed [31:0] zunit_pkg_DMA_CMD_MODE_LO = 0;
	wire [3:0] mode_w = cmd_reg[zunit_pkg_DMA_CMD_MODE_HI:zunit_pkg_DMA_CMD_MODE_LO];
	localparam [3:0] zunit_pkg_DMA_PALETTE = 4'd8;
	wire [7:0] pal_lo = regf[zunit_pkg_DMA_PALETTE][7:0];
	localparam [3:0] zunit_pkg_DMA_COLOR = 4'd9;
	wire [7:0] col_lo = regf[zunit_pkg_DMA_COLOR][7:0];
	localparam signed [31:0] zunit_pkg_DMA_CMD_TRIG_BIT = 15;
	wire wdata_trig = reg_wdata[zunit_pkg_DMA_CMD_TRIG_BIT];
	assign busy = busy_r;
	assign dma_palette = regf[zunit_pkg_DMA_PALETTE];
	assign reg_rdata = (reg_addr == zunit_pkg_DMA_COMMAND ? {busy_r, cmd_reg[14:0]} : regf[reg_addr]);
	reg [2:0] state;
	reg [2:0] state_n;
	reg [25:0] pace_cnt;
	reg pace_arm;
	reg abort_r;
	reg pend_trig;
	reg [3:0] mode_c;
	reg flipx_c;
	reg readmode_c;
	reg signed [31:0] width_c;
	reg signed [31:0] height_c;
	reg signed [31:0] xpos_c;
	reg signed [31:0] ypos_c;
	reg signed [31:0] rowbytes_c;
	reg [15:0] pal16_c;
	reg [15:0] color16_c;
	reg signed [31:0] row_i;
	reg signed [31:0] col_i;
	reg signed [31:0] tx;
	reg [8:0] ty;
	reg signed [31:0] cur_off;
	reg signed [31:0] o_ptr;
	reg [7:0] px;
	reg signed [31:0] rb_in;
	reg signed [31:0] xs_in;
	reg signed [31:0] ys_in;
	reg [15:0] w_in;
	reg [15:0] h_in;
	reg [31:0] gfxoff0;
	reg [31:0] gfxoff1;
	reg [31:0] gfxoff2;
	reg signed [31:0] rb_adj;
	reg signed [31:0] xpos0;
	reg signed [31:0] ypos1;
	reg signed [31:0] height1a;
	reg signed [31:0] height1;
	reg signed [31:0] xpos_f;
	reg signed [31:0] width_f;
	reg signed [31:0] offbytes_c;
	localparam [3:0] zunit_pkg_DMA_HEIGHT = 4'd7;
	localparam [3:0] zunit_pkg_DMA_OFFSETHI = 4'd3;
	localparam [3:0] zunit_pkg_DMA_OFFSETLO = 4'd2;
	localparam [3:0] zunit_pkg_DMA_ROWBYTES = 4'd1;
	localparam [3:0] zunit_pkg_DMA_WIDTH = 4'd6;
	localparam [3:0] zunit_pkg_DMA_XSTART = 4'd4;
	localparam [3:0] zunit_pkg_DMA_YSTART = 4'd5;
	always @(*) begin
		if (_sv2v_0)
			;
		rb_in = $signed(regf[zunit_pkg_DMA_ROWBYTES]);
		xs_in = $signed(regf[zunit_pkg_DMA_XSTART]);
		ys_in = $signed(regf[zunit_pkg_DMA_YSTART]);
		w_in = regf[zunit_pkg_DMA_WIDTH];
		h_in = regf[zunit_pkg_DMA_HEIGHT];
		gfxoff0 = {regf[zunit_pkg_DMA_OFFSETHI], regf[zunit_pkg_DMA_OFFSETLO]};
		gfxoff1 = (flipx_w ? gfxoff0 - (({16'd0, w_in} - 32'd1) << 3) : gfxoff0);
		rb_adj = (flipx_w ? ((rb_in - $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3 : ((rb_in + $signed({16'd0, w_in})) + 32'sd3) & ~32'sd3);
		xpos0 = (flipx_w ? (xs_in + $signed({16'd0, w_in})) - 32'sd1 : xs_in);
		if (ys_in < 0) begin
			height1a = $signed({16'd0, h_in}) + ys_in;
			ypos1 = 32'sd0;
		end
		else begin
			height1a = $signed({16'd0, h_in});
			ypos1 = ys_in;
		end
		if ((ypos1 + height1a) > 32'sd512)
			height1 = 32'sd512 - ypos1;
		else
			height1 = height1a;
		if (!flipx_w) begin
			if (xpos0 < 0) begin
				width_f = $signed({16'd0, w_in}) + xpos0;
				xpos_f = 32'sd0;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f + width_f) > 32'sd512)
				width_f = 32'sd512 - xpos_f;
		end
		else begin
			if (xpos0 >= 32'sd512) begin
				width_f = $signed({16'd0, w_in}) - (xpos0 - 32'sd511);
				xpos_f = 32'sd511;
			end
			else begin
				width_f = $signed({16'd0, w_in});
				xpos_f = xpos0;
			end
			if ((xpos_f - width_f) < 0)
				width_f = xpos_f;
		end
		gfxoff2 = (gfxoff1 < 32'h02000000 ? gfxoff1 + 32'h02000000 : gfxoff1);
		offbytes_c = ($signed(gfxoff2) - 32'sh02000000) >>> 3;
	end
	wire readmode_w = (mode_w >= 4'h1) && (mode_w <= 4'hb);
	wire [15:0] pal16_u = pal16_c;
	wire [15:0] color16_u = color16_c;
	reg pix_we;
	reg [15:0] pix_data;
	always @(*) begin
		if (_sv2v_0)
			;
		pix_we = 1'b0;
		pix_data = 16'h0000;
		(* full_case, parallel_case *)
		case (mode_c)
			4'h0:
				;
			4'h1: begin
				pix_we = px == 8'd0;
				pix_data = pal16_u;
			end
			4'h2: begin
				pix_we = px != 8'd0;
				pix_data = pal16_u | {8'd0, px};
			end
			4'h3: begin
				pix_we = 1'b1;
				pix_data = pal16_u | {8'd0, px};
			end
			4'h4, 4'h5: begin
				pix_we = px == 8'd0;
				pix_data = color16_u;
			end
			4'h6, 4'h7: begin
				pix_we = 1'b1;
				pix_data = (px == 8'd0 ? color16_u : pal16_u | {8'd0, px});
			end
			4'h8, 4'ha: begin
				pix_we = px != 8'd0;
				pix_data = color16_u;
			end
			4'h9, 4'hb: begin
				pix_we = 1'b1;
				pix_data = (px != 8'd0 ? color16_u : pal16_u | {8'd0, px});
			end
			default: begin
				pix_we = 1'b1;
				pix_data = color16_u;
			end
		endcase
	end
	wire row_overrun_g = ($unsigned(cur_off) >= 32'h06000000) && (mode_c < 4'hc);
	wire [8:0] tx9 = tx[8:0];
	wire [8:0] ty_next = ypos_c[8:0] + row_i[8:0];
	wire dma_done_ok = pace_cnt <= 26'd4;
	always @(*) begin
		if (_sv2v_0)
			;
		state_n = state;
		(* full_case, parallel_case *)
		case (state)
			3'd0:
				if ((reg_we && (reg_addr == zunit_pkg_DMA_COMMAND)) && wdata_trig)
					state_n = 3'd1;
				else if (pend_trig)
					state_n = 3'd1;
			3'd1: state_n = 3'd2;
			3'd2:
				if ((height1 <= 0) || (width_f <= 0))
					state_n = 3'd6;
				else
					state_n = 3'd3;
			3'd3:
				if (abort_r)
					state_n = 3'd6;
				else if (row_i >= height_c)
					state_n = 3'd6;
				else if (row_overrun_g)
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd4:
				if (!readmode_c)
					state_n = 3'd5;
				else if (src_ack)
					state_n = 3'd5;
			3'd5:
				if (pix_we && !fb_ack)
					state_n = 3'd5;
				else if (abort_r)
					state_n = 3'd6;
				else if (col_i >= (width_c - 32'sd1))
					state_n = 3'd3;
				else
					state_n = 3'd4;
			3'd6:
				if (dma_done_ok)
					state_n = 3'd0;
			default: state_n = 3'd0;
		endcase
	end
	assign src_req = (state == 3'd4) && readmode_c;
	assign src_addr = o_ptr[23:0];
	assign fb_we = (state == 3'd5) && pix_we;
	assign fb_addr = {ty, tx9};
	assign fb_wdata = pix_data;
	assign fb_flush = state == 3'd6;
	integer i;
	always @(posedge clk)
		if (rst) begin
			state <= 3'd0;
			blit_irq <= 1'b0;
			busy_r <= 1'b0;
			pace_cnt <= 26'd0;
			pace_arm <= 1'b0;
			abort_r <= 1'b0;
			pend_trig <= 1'b0;
			for (i = 0; i < zunit_pkg_DMA_NREGS; i = i + 1)
				regf[i] <= 16'h0000;
		end
		else begin
			state <= state_n;
			if (reg_we) begin
				regf[reg_addr] <= reg_wdata;
				if (reg_addr == zunit_pkg_DMA_COMMAND) begin
					blit_irq <= 1'b0;
					if (state == 3'd0)
						busy_r <= wdata_trig;
					else if (wdata_trig && (abort_r || pend_trig)) begin
						pend_trig <= 1'b1;
						busy_r <= 1'b1;
					end
					else if (!wdata_trig) begin
						busy_r <= 1'b0;
						if (state_n != 3'd0)
							abort_r <= 1'b1;
					end
				end
			end
			pace_arm <= state == 3'd2;
			if (pace_arm)
				pace_cnt <= ({14'd0, width_c[11:0]} * {14'd0, height_c[11:0]}) << 2;
			else if (pace_cnt != 26'd0)
				pace_cnt <= pace_cnt - 26'd1;
			if (abort_r && (state_n == 3'd0))
				abort_r <= 1'b0;
			if ((state == 3'd0) && pend_trig) begin
				pend_trig <= 1'b0;
				busy_r <= 1'b1;
			end
			(* full_case, parallel_case *)
			case (state)
				3'd2: begin
					mode_c <= mode_w;
					flipx_c <= flipx_w;
					readmode_c <= readmode_w;
					width_c <= (width_f <= 32'sd0 ? 32'sd0 : width_f);
					height_c <= (height1 <= 32'sd0 ? 32'sd0 : height1);
					xpos_c <= xpos_f;
					ypos_c <= ypos1;
					rowbytes_c <= rb_adj;
					pal16_c <= {pal_lo, 8'h00};
					color16_c <= {pal_lo, col_lo};
					row_i <= 32'sd0;
					cur_off <= offbytes_c;
				end
				3'd3: begin
					ty <= ty_next;
					tx <= xpos_c;
					col_i <= 32'sd0;
					o_ptr <= cur_off;
					if (row_i < height_c) begin
						cur_off <= cur_off + rowbytes_c;
						row_i <= row_i + 32'sd1;
					end
				end
				3'd4:
					if (readmode_c && src_ack)
						px <= src_data;
				3'd5:
					if (!pix_we || fb_ack) begin
						tx <= tx + (flipx_c ? -32'sd1 : 32'sd1);
						col_i <= col_i + 32'sd1;
						if (readmode_c)
							o_ptr <= o_ptr + 32'sd1;
					end
				3'd6:
					if (dma_done_ok) begin
						if (pend_trig || (((reg_we && (reg_addr == zunit_pkg_DMA_COMMAND)) && wdata_trig) && abort_r)) begin
							busy_r <= 1'b1;
							blit_irq <= 1'b0;
						end
						else begin
							busy_r <= 1'b0;
							blit_irq <= 1'b1;
						end
					end
				default:
					;
			endcase
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module zunit_memsys (
	clk,
	rst,
	mem_req,
	mem_we,
	mem_srt,
	mem_addr,
	mem_size,
	mem_wdata,
	mem_rdata,
	mem_ack,
	src_req,
	src_addr,
	src_data,
	src_ack,
	inputs,
	int1,
	snd_select,
	snd_trig,
	snd_reset,
	snd_wr,
	snd_wdata,
	erase_start,
	erase_row0,
	erase_lines,
	erase_busy,
	blit_busy,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	cpu_gfx_rd,
	cpu_gfx_raddr,
	cpu_gfx_rdata,
	cpu_gfx_rack,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	sdram_por,
	scan_disp_base,
	scan_vblank,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	palv_we_a,
	palv_aa,
	palv_awd,
	palv_we_b,
	palv_ba,
	palv_bwd
);
	parameter ROM_HEX = "smashtv_maindata.hex";
	parameter signed [31:0] ROM_PROG_OFF = 32'h00040000;
	input wire clk;
	input wire rst;
	input wire mem_req;
	input wire mem_we;
	input wire mem_srt;
	input wire [31:0] mem_addr;
	input wire [5:0] mem_size;
	input wire [31:0] mem_wdata;
	output wire [31:0] mem_rdata;
	output wire mem_ack;
	output wire src_req;
	output wire [23:0] src_addr;
	input wire [7:0] src_data;
	input wire src_ack;
	input wire [63:0] inputs;
	output wire int1;
	output wire [7:0] snd_select;
	output wire snd_trig;
	output wire snd_reset;
	output wire snd_wr;
	output wire [15:0] snd_wdata;
	input wire erase_start;
	input wire [8:0] erase_row0;
	input wire [9:0] erase_lines;
	output wire erase_busy;
	output wire blit_busy;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire cpu_gfx_rd;
	output wire [23:0] cpu_gfx_raddr;
	input wire [15:0] cpu_gfx_rdata;
	input wire cpu_gfx_rack;
	input wire scan_req;
	input wire [17:0] scan_addr;
	output wire [15:0] scan_data;
	output wire scan_ack;
	input wire sdram_por;
	input wire [8:0] scan_disp_base;
	input wire scan_vblank;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output wire palv_we_a;
	output wire [12:0] palv_aa;
	output wire [15:0] palv_awd;
	output wire palv_we_b;
	output wire [12:0] palv_ba;
	output wire [15:0] palv_bwd;
	wire is_dma_now = mem_addr[31:20] == 12'h01a;
	wire mem_req_m;
	wire [31:0] mem_rdata_m;
	wire mem_ack_m;
	wire dma_reg_we;
	wire [3:0] dma_reg_addr;
	wire [15:0] dma_reg_wdata;
	wire [15:0] dma_reg_rdata;
	wire dma_fb_we;
	localparam signed [31:0] zunit_pkg_FB_ADDR_W = 18;
	wire [17:0] dma_fb_addr;
	wire [15:0] dma_fb_wdata;
	wire [15:0] dma_palette;
	wire dma_fb_flush;
	wire mem_fb_ack;
	wire dma_fb_ack = mem_fb_ack;
	wire mem_fb_busy;
	zunit_mem #(
		.ROM_HEX(ROM_HEX),
		.ROM_PROG_OFF(ROM_PROG_OFF)
	) u_mem(
		.clk(clk),
		.rst(rst),
		.mem_req(mem_req_m),
		.mem_we(mem_we),
		.mem_srt(mem_srt),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata_m),
		.mem_ack(mem_ack_m),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.dma_palette(dma_palette),
		.inputs(inputs),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.snd_wr(snd_wr),
		.snd_wdata(snd_wdata),
		.erase_start(erase_start),
		.erase_row0(erase_row0),
		.erase_lines(erase_lines),
		.erase_busy(erase_busy),
		.gfx_rd(cpu_gfx_rd),
		.gfx_raddr(cpu_gfx_raddr),
		.gfx_rdata(cpu_gfx_rdata),
		.gfx_rack(cpu_gfx_rack),
		.fb_ack(mem_fb_ack),
		.fb_busy(mem_fb_busy),
		.fb_flush(dma_fb_flush),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack),
		.sdram_por(sdram_por),
		.scan_disp_base(scan_disp_base),
		.scan_vblank(scan_vblank),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	zunit_dma u_dma(
		.clk(clk),
		.rst(rst),
		.reg_we(dma_reg_we),
		.reg_addr(dma_reg_addr),
		.reg_wdata(dma_reg_wdata),
		.reg_rdata(dma_reg_rdata),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.fb_we(dma_fb_we),
		.fb_addr(dma_fb_addr),
		.fb_wdata(dma_fb_wdata),
		.fb_ack(dma_fb_ack),
		.fb_flush(dma_fb_flush),
		.busy(blit_busy),
		.blit_irq(int1),
		.dma_palette(dma_palette)
	);
	reg [1:0] dstate;
	reg [31:0] d_addr_q;
	reg d_we_q;
	reg [31:0] d_wd_q;
	reg [5:0] d_sz_q;
	reg dma_ack;
	wire d_second = dstate == 2'd2;
	assign dma_reg_addr = (d_second ? d_addr_q[7:4] + 4'd1 : d_addr_q[7:4]);
	assign dma_reg_wdata = (d_second ? d_wd_q[31:16] : d_wd_q[15:0]);
	assign dbg_dma_we = dma_reg_we;
	assign dbg_dma_addr = dma_reg_addr;
	assign dbg_dma_wdata = dma_reg_wdata;
	assign dma_reg_we = (dstate == 2'd1) || (dstate == 2'd2);
	wire d_want_hi = d_sz_q > 6'd16;
	localparam signed [31:0] zunit_pkg_DMA_CMD_TRIG_BIT = 15;
	localparam [3:0] zunit_pkg_DMA_COMMAND = 4'd0;
	always @(posedge clk)
		if (rst) begin
			dstate <= 2'd0;
			dma_ack <= 1'b0;
		end
		else
			(* full_case, parallel_case *)
			case (dstate)
				2'd0: begin
					dma_ack <= 1'b0;
					if ((mem_req && is_dma_now) && !mem_ack) begin
						if (((mem_we && (mem_addr[7:4] == zunit_pkg_DMA_COMMAND)) && mem_wdata[zunit_pkg_DMA_CMD_TRIG_BIT]) && blit_busy)
							;
						else begin
							d_addr_q <= mem_addr;
							d_we_q <= mem_we;
							d_wd_q <= mem_wdata;
							d_sz_q <= mem_size;
							dstate <= (mem_we ? 2'd1 : 2'd3);
						end
					end
				end
				2'd1: dstate <= (d_want_hi ? 2'd2 : 2'd3);
				2'd2: dstate <= 2'd3;
				2'd3: begin
					dma_ack <= 1'b1;
					dstate <= 2'd0;
				end
				default: dstate <= 2'd0;
			endcase
	assign mem_req_m = mem_req && !is_dma_now;
	assign mem_ack = (is_dma_now ? dma_ack : mem_ack_m);
	assign mem_rdata = (is_dma_now ? {16'h0000, dma_reg_rdata} : mem_rdata_m);
endmodule
`default_nettype wire
`default_nettype none
module narc_talkback_merge (
	inputs_ext,
	talkback_rd,
	inputs_merged
);
	input wire [63:0] inputs_ext;
	input wire [15:0] talkback_rd;
	output wire [63:0] inputs_merged;
	assign inputs_merged = {inputs_ext[63:48], inputs_ext[47:40], talkback_rd[7:0], inputs_ext[31:27], talkback_rd[8], inputs_ext[25:16], inputs_ext[15:0]};
endmodule
`default_nettype wire
`default_nettype none
module narc_pal_wr_queue (
	clk,
	rst,
	we_a,
	addr_a,
	data_a,
	we_b,
	addr_b,
	data_b,
	pal_we,
	pal_waddr,
	pal_wdata,
	ovf_o
);
	parameter signed [31:0] PQ_AW = 2;
	input wire clk;
	input wire rst;
	input wire we_a;
	input wire [12:0] addr_a;
	input wire [15:0] data_a;
	input wire we_b;
	input wire [12:0] addr_b;
	input wire [15:0] data_b;
	output reg pal_we;
	output reg [12:0] pal_waddr;
	output reg [15:0] pal_wdata;
	output reg ovf_o;
	localparam signed [31:0] DEPTH = 1 << PQ_AW;
	reg [28:0] mem [0:DEPTH - 1];
	reg [PQ_AW:0] wp;
	reg [PQ_AW:0] rp;
	wire [PQ_AW:0] occ = wp - rp;
	wire retiring = occ != 0;
	wire [PQ_AW:0] wp1 = wp + 1'b1;
	wire [7:0] occ8 = {{(8 - PQ_AW) - 1 {1'b0}}, occ};
	wire [7:0] room8 = (DEPTH[7:0] - occ8) + (retiring ? 8'd1 : 8'd0);
	wire [7:0] need8 = (we_a ? 8'd1 : 8'd0) + (we_b ? 8'd1 : 8'd0);
	always @(posedge clk)
		if (rst) begin
			wp <= 0;
			rp <= 0;
			ovf_o <= 1'b0;
			pal_we <= 1'b0;
			pal_waddr <= 13'd0;
			pal_wdata <= 16'd0;
		end
		else begin
			if (retiring) begin
				pal_we <= 1'b1;
				pal_waddr <= mem[rp[PQ_AW - 1:0]][28:16];
				pal_wdata <= mem[rp[PQ_AW - 1:0]][15:0];
				rp <= rp + 1'b1;
			end
			else
				pal_we <= 1'b0;
			if (need8 > room8)
				ovf_o <= 1'b1;
			else if (we_a && we_b) begin
				mem[wp[PQ_AW - 1:0]] <= {addr_a, data_a};
				mem[wp1[PQ_AW - 1:0]] <= {addr_b, data_b};
				wp <= wp + 2;
			end
			else if (we_a) begin
				mem[wp[PQ_AW - 1:0]] <= {addr_a, data_a};
				wp <= wp + 1'b1;
			end
			else if (we_b) begin
				mem[wp[PQ_AW - 1:0]] <= {addr_b, data_b};
				wp <= wp + 1'b1;
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module zunit_video (
	clk,
	pal_we,
	pal_waddr,
	pal_wdata,
	pix_valid,
	vram_word,
	rgb_valid,
	r,
	g,
	b
);
	parameter [12:0] PEN_MASK = 13'h1fff;
	input wire clk;
	input wire pal_we;
	input wire [12:0] pal_waddr;
	input wire [15:0] pal_wdata;
	input wire pix_valid;
	input wire [15:0] vram_word;
	output reg rgb_valid;
	output reg [7:0] r;
	output reg [7:0] g;
	output reg [7:0] b;
	function automatic [7:0] pal5bit;
		input reg [4:0] v;
		pal5bit = {v, v[4:2]};
	endfunction
	(* ramstyle = "M10K" *) reg [15:0] palram [0:8191];
	reg [12:0] pen_r;
	reg valid_1;
	reg [15:0] pal_q;
	reg valid_2;
	always @(posedge clk) begin
		pen_r <= vram_word[12:0] & PEN_MASK;
		valid_1 <= pix_valid;
		if (pal_we)
			palram[pal_waddr] <= pal_wdata;
		pal_q <= palram[pen_r];
		valid_2 <= valid_1;
		r <= pal5bit(pal_q[14:10]);
		g <= pal5bit(pal_q[9:5]);
		b <= pal5bit(pal_q[4:0]);
		rgb_valid <= valid_2;
	end
endmodule
`default_nettype wire
`default_nettype none
module zunit_video_top (
	clk,
	rst,
	ce_pix,
	dpystrt,
	pal_we,
	pal_waddr,
	pal_wdata,
	scan_req,
	scan_addr,
	scan_data,
	scan_ack,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	rgb_valid,
	vblank_irq,
	disp_base,
	disp_vblank
);
	localparam signed [31:0] zunit_pkg_SCR_H_TOTAL = 674;
	parameter signed [31:0] H_TOTAL = zunit_pkg_SCR_H_TOTAL;
	localparam signed [31:0] zunit_pkg_SCR_H_VIS_ST = 122;
	parameter signed [31:0] H_VIS_ST = zunit_pkg_SCR_H_VIS_ST;
	localparam signed [31:0] zunit_pkg_SCR_H_VIS_EN = 634;
	parameter signed [31:0] H_VIS_EN = zunit_pkg_SCR_H_VIS_EN;
	localparam signed [31:0] zunit_pkg_SCR_V_TOTAL = 433;
	parameter signed [31:0] V_TOTAL = zunit_pkg_SCR_V_TOTAL;
	localparam signed [31:0] zunit_pkg_SCR_V_VIS_ST = 27;
	parameter signed [31:0] V_VIS_ST = zunit_pkg_SCR_V_VIS_ST;
	localparam signed [31:0] zunit_pkg_SCR_V_VIS_EN = 427;
	parameter signed [31:0] V_VIS_EN = zunit_pkg_SCR_V_VIS_EN;
	parameter signed [31:0] H_FP = 8;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] V_FP = 2;
	parameter signed [31:0] V_SYNC = 4;
	parameter signed [31:0] DISP_ROW0 = 0;
	parameter signed [31:0] NCOL = 512;
	parameter [12:0] PEN_MASK = 13'h1fff;
	input wire clk;
	input wire rst;
	input wire ce_pix;
	input wire [15:0] dpystrt;
	input wire pal_we;
	input wire [12:0] pal_waddr;
	input wire [15:0] pal_wdata;
	output wire scan_req;
	output wire [17:0] scan_addr;
	input wire [15:0] scan_data;
	input wire scan_ack;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output wire rgb_valid;
	output reg vblank_irq;
	output wire [8:0] disp_base;
	output wire disp_vblank;
	localparam signed [31:0] zunit_pkg_FB_ADDR_W = 18;
	localparam signed [31:0] FBW = zunit_pkg_FB_ADDR_W;
	reg [11:0] hc;
	reg [11:0] vc;
	reg [8:0] disp_row0_q;
	function automatic signed [8:0] sv2v_cast_9_signed;
		input reg signed [8:0] inp;
		sv2v_cast_9_signed = inp;
	endfunction
	function automatic [8:0] sv2v_cast_9;
		input reg [8:0] inp;
		sv2v_cast_9 = inp;
	endfunction
	always @(posedge clk)
		if (rst) begin
			hc <= 12'd0;
			vc <= 12'd0;
			vblank_irq <= 1'b0;
			disp_row0_q <= sv2v_cast_9_signed(DISP_ROW0);
		end
		else if (ce_pix) begin
			vblank_irq <= 1'b0;
			if (hc == (H_TOTAL - 1)) begin
				hc <= 12'd0;
				if (vc == (V_TOTAL - 1))
					vc <= 12'd0;
				else begin
					vc <= vc + 12'd1;
					if (vc == (V_VIS_EN - 1)) begin
						vblank_irq <= 1'b1;
						disp_row0_q <= sv2v_cast_9((dpystrt ^ 16'hfffc) >> 4);
					end
				end
			end
			else
				hc <= hc + 12'd1;
		end
	wire h_active = (hc >= H_VIS_ST) && (hc < H_VIS_EN);
	wire v_active = (vc >= V_VIS_ST) && (vc < V_VIS_EN);
	wire de0 = h_active && v_active;
	wire hs0 = (hc >= (H_VIS_EN + H_FP)) && (hc < ((H_VIS_EN + H_FP) + H_SYNC));
	wire vs0 = (vc >= (V_VIS_EN + V_FP)) && (vc < ((V_VIS_EN + V_FP) + V_SYNC));
	wire hb0 = !h_active;
	wire vb0 = !v_active;
	wire [8:0] disp_row0_eff = disp_row0_q;
	wire [8:0] row = (v_active ? sv2v_cast_9(vc - V_VIS_ST) : 9'd0);
	wire [8:0] col = (h_active ? sv2v_cast_9(hc - H_VIS_ST) : 9'd0);
	wire [8:0] disp_row = disp_row0_eff + row;
	localparam signed [31:0] zunit_pkg_FB_ROWSHIFT = 9;
	function automatic [17:0] sv2v_cast_18;
		input reg [17:0] inp;
		sv2v_cast_18 = inp;
	endfunction
	wire [17:0] vram_raddr = sv2v_cast_18(({9'd0, disp_row} << zunit_pkg_FB_ROWSHIFT) | {9'd0, col});
	wire [15:0] vram_rdata;
	wire vblank_i = !v_active;
	assign disp_base = disp_row0_eff;
	assign disp_vblank = vblank_i;
	yunit_scanline #(
		.FB_ADDR_W(FBW),
		.NCOL(NCOL)
	) u_scan(
		.clk(clk),
		.rst(rst),
		.ce_pix(ce_pix),
		.vblank(vblank_i),
		.first_row(disp_row0_eff),
		.vram_raddr(vram_raddr),
		.vram_rdata(vram_rdata),
		.scan_req(scan_req),
		.scan_addr(scan_addr),
		.scan_data(scan_data),
		.scan_ack(scan_ack)
	);
	reg de_s1;
	always @(posedge clk)
		if (rst)
			de_s1 <= 1'b0;
		else if (ce_pix)
			de_s1 <= de0;
	wire pix_valid = ce_pix & de_s1;
	wire vrgb_valid;
	wire [7:0] vr;
	wire [7:0] vg;
	wire [7:0] vb;
	zunit_video #(.PEN_MASK(PEN_MASK)) u_vid(
		.clk(clk),
		.pal_we(pal_we),
		.pal_waddr(pal_waddr),
		.pal_wdata(pal_wdata),
		.pix_valid(pix_valid),
		.vram_word(vram_rdata),
		.rgb_valid(vrgb_valid),
		.r(vr),
		.g(vg),
		.b(vb)
	);
	assign rgb_valid = vrgb_valid;
	reg [7:0] vr_q;
	reg [7:0] vg_q;
	reg [7:0] vb_q;
	reg de_s2;
	reg hs_s1;
	reg hs_s2;
	reg vs_s1;
	reg vs_s2;
	reg hb_s1;
	reg hb_s2;
	reg vb_s1;
	reg vb_s2;
	always @(posedge clk)
		if (rst) begin
			vr_q <= 0;
			vg_q <= 0;
			vb_q <= 0;
			de_s2 <= 0;
			hs_s1 <= 0;
			hs_s2 <= 0;
			vs_s1 <= 0;
			vs_s2 <= 0;
			hb_s1 <= 0;
			hb_s2 <= 0;
			vb_s1 <= 0;
			vb_s2 <= 0;
			de <= 0;
			hsync <= 0;
			vsync <= 0;
			hblank <= 0;
			vblank <= 0;
			vid_r <= 0;
			vid_g <= 0;
			vid_b <= 0;
		end
		else if (ce_pix) begin
			vr_q <= vr;
			vg_q <= vg;
			vb_q <= vb;
			de_s2 <= de_s1;
			hs_s1 <= hs0;
			hs_s2 <= hs_s1;
			vs_s1 <= vs0;
			vs_s2 <= vs_s1;
			hb_s1 <= hb0;
			hb_s2 <= hb_s1;
			vb_s1 <= vb0;
			vb_s2 <= vb_s1;
			de <= de_s2;
			hsync <= hs_s2;
			vsync <= vs_s2;
			hblank <= hb_s2;
			vblank <= vb_s2;
			vid_r <= (de_s2 ? vr_q : 8'h00);
			vid_g <= (de_s2 ? vg_q : 8'h00);
			vid_b <= (de_s2 ? vb_q : 8'h00);
		end
endmodule
`default_nettype wire
`default_nettype none
module zunit_top (
	clk,
	ce_pix,
	rst,
	inputs,
	sdram_por,
	ioctl_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	ddram_addr,
	ddram_burstcnt,
	ddram_rd,
	ddram_we,
	ddram_din,
	ddram_be,
	ddram_busy,
	ddram_dout,
	ddram_dout_ready,
	snd_select,
	snd_trig,
	snd_reset,
	mst_rom_offset,
	slv_rom_offset,
	snd_rom_stall_clks,
	audio_l,
	audio_r,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	rgb_valid,
	pc_dbg,
	illegal_dbg,
	int1_dbg,
	blit_busy,
	erase_busy,
	vblank_irq,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	fifo_accepted,
	fifo_dropped,
	rst_during_dl,
	dbg_ff_addr,
	dbg_ff_data,
	dbg_ff_valid,
	dbg_rb_data,
	dbg_rb_valid,
	dbg_cksum_w0,
	dbg_cksum_w1,
	dbg_cksum_w2,
	dbg_cksum_valid,
	dbg_core_rst_o,
	dbg_sdram_ready_o,
	dbg_unp_done_o,
	dbg_cpu_req_o,
	dbg_mem_ack_o,
	dbg_cpu_ce_o
);
	parameter ROM_HEX = "narc_maindata.hex";
	parameter signed [31:0] ROM_PROG_OFF = 32'h00040000;
	parameter signed [31:0] CPU_CE_DIV = 4;
	input wire clk;
	input wire ce_pix;
	input wire rst;
	input wire [63:0] inputs;
	input wire sdram_por;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output wire [28:0] ddram_addr;
	output wire [7:0] ddram_burstcnt;
	output wire ddram_rd;
	output wire ddram_we;
	output wire [63:0] ddram_din;
	output wire [7:0] ddram_be;
	input wire ddram_busy;
	input wire [63:0] ddram_dout;
	input wire ddram_dout_ready;
	output wire [7:0] snd_select;
	output wire snd_trig;
	output wire snd_reset;
	output wire [19:0] mst_rom_offset;
	output wire [19:0] slv_rom_offset;
	output wire [31:0] snd_rom_stall_clks;
	output wire signed [15:0] audio_l;
	output wire signed [15:0] audio_r;
	output wire [7:0] vid_r;
	output wire [7:0] vid_g;
	output wire [7:0] vid_b;
	output wire hsync;
	output wire vsync;
	output wire hblank;
	output wire vblank;
	output wire de;
	output wire rgb_valid;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire int1_dbg;
	output wire blit_busy;
	output wire erase_busy;
	output wire vblank_irq;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire [31:0] fifo_accepted;
	output wire [31:0] fifo_dropped;
	output wire rst_during_dl;
	output reg [31:0] dbg_ff_addr;
	output reg [31:0] dbg_ff_data;
	output reg dbg_ff_valid;
	output wire [31:0] dbg_rb_data;
	output wire dbg_rb_valid;
	output wire [31:0] dbg_cksum_w0;
	output wire [31:0] dbg_cksum_w1;
	output wire [31:0] dbg_cksum_w2;
	output wire dbg_cksum_valid;
	output wire dbg_core_rst_o;
	output wire dbg_sdram_ready_o;
	output wire dbg_unp_done_o;
	output wire dbg_cpu_req_o;
	output wire dbg_mem_ack_o;
	output wire dbg_cpu_ce_o;
	wire sdram_ready;
	wire dl_drain_busy;
	wire boot_settle_busy;
	wire boot_settle_to;
	wire core_rst = (((rst | ~sdram_ready) | ioctl_download) | dl_drain_busy) | boot_settle_busy;
	reg rst_sys_m;
	reg rst_sys;
	always @(posedge clk) begin
		rst_sys_m <= core_rst;
		rst_sys <= rst_sys_m;
	end
	reg [7:0] ce_div;
	always @(posedge clk)
		if (rst)
			ce_div <= 8'd0;
		else
			ce_div <= (ce_div >= (CPU_CE_DIV - 1) ? 8'd0 : ce_div + 8'd1);
	wire cpu_ce = ce_div == 8'd0;
	reg ce_pix_ph;
	always @(posedge clk)
		if (rst_sys)
			ce_pix_ph <= 1'b0;
		else if (ce_pix)
			ce_pix_ph <= ~ce_pix_ph;
	wire ce_pix_cnt = ce_pix & ce_pix_ph;
	wire cpu_req;
	wire cpu_we;
	localparam [31:0] tms34010_pkg_ADDR_WIDTH = 32;
	wire [31:0] cpu_addr;
	localparam [31:0] tms34010_pkg_FIELD_SIZE_WIDTH = 6;
	wire [5:0] cpu_size;
	localparam [31:0] tms34010_pkg_DATA_WIDTH = 32;
	wire [31:0] cpu_wdata;
	wire [31:0] cpu_rdata;
	wire cpu_ack;
	wire [5:0] state_w;
	localparam [31:0] tms34010_pkg_INSTR_WORD_WIDTH = 16;
	wire [15:0] instr_w;
	assign dbg_core_rst_o = core_rst;
	assign dbg_sdram_ready_o = sdram_ready;
	assign dbg_unp_done_o = 1'b1;
	assign dbg_cpu_req_o = cpu_req;
	assign dbg_mem_ack_o = cpu_ack;
	assign dbg_cpu_ce_o = cpu_ce;
	wire int1;
	wire snd_latch_wr;
	wire [15:0] snd_latch_wdata;
	wire cpu_srt;
	wire [15:0] dpystrt;
	tms34010_core #(.EXTERNAL_SRT(1'b1)) u_core(
		.clk(clk),
		.ce_cpu(cpu_ce),
		.ce_pix(ce_pix_cnt),
		.rst(rst_sys),
		.mem_req(cpu_req),
		.mem_we(cpu_we),
		.mem_addr(cpu_addr),
		.mem_size(cpu_size),
		.mem_wdata(cpu_wdata),
		.mem_srt(cpu_srt),
		.mem_rdata(cpu_rdata),
		.mem_ack(cpu_ack),
		.state_o(state_w),
		.pc_o(pc_dbg),
		.instr_word_o(instr_w),
		.illegal_opcode_o(illegal_dbg),
		.dpystrt_o(dpystrt),
		.lint1_in(int1)
	);
	wire mem_req;
	wire mem_we;
	wire mem_srt;
	wire [31:0] mem_addr;
	wire [5:0] mem_size;
	wire [31:0] mem_wdata;
	wire [31:0] mem_rdata;
	wire mem_ack;
	yunit_mem_cdc #(
		.AW(tms34010_pkg_ADDR_WIDTH),
		.DW(tms34010_pkg_DATA_WIDTH),
		.SW(tms34010_pkg_FIELD_SIZE_WIDTH)
	) u_memcdc(
		.clk_cpu(clk),
		.ce_cpu(cpu_ce),
		.rst_cpu(rst_sys),
		.c_req(cpu_req),
		.c_we(cpu_we),
		.c_srt(cpu_srt),
		.c_addr(cpu_addr),
		.c_size(cpu_size),
		.c_wdata(cpu_wdata),
		.c_ack(cpu_ack),
		.c_rdata(cpu_rdata),
		.clk_sys(clk),
		.rst_sys(rst_sys),
		.m_req(mem_req),
		.m_we(mem_we),
		.m_srt(mem_srt),
		.m_addr(mem_addr),
		.m_size(mem_size),
		.m_wdata(mem_wdata),
		.m_rdata(mem_rdata),
		.m_ack(mem_ack)
	);
	wire src_req;
	wire [23:0] src_addr;
	wire [7:0] src_data;
	wire src_ack;
	wire cpu_gfx_rd;
	wire [23:0] cpu_gfx_raddr;
	wire [15:0] cpu_gfx_rdata;
	wire cpu_gfx_rack;
	wire [24:0] vsd_addr;
	wire [15:0] vsd_din;
	wire [15:0] vsd_dout;
	wire [1:0] vsd_be;
	wire vsd_rd;
	wire vsd_wr;
	wire vsd_ack;
	wire video_scan_req;
	wire [17:0] video_scan_addr;
	wire [15:0] video_scan_data;
	wire video_scan_ack;
	wire mem_scan_req;
	wire [17:0] mem_scan_addr;
	wire [15:0] mem_scan_data;
	wire mem_scan_ack;
	wire vpal_we;
	wire [12:0] vpal_waddr;
	wire [15:0] vpal_wdata;
	wire [8:0] video_disp_base;
	wire video_disp_vblank;
	zunit_video_top u_video(
		.clk(clk),
		.rst(rst_sys),
		.ce_pix(ce_pix),
		.dpystrt(dpystrt),
		.pal_we(vpal_we),
		.pal_waddr(vpal_waddr),
		.pal_wdata(vpal_wdata),
		.scan_req(video_scan_req),
		.scan_addr(video_scan_addr),
		.scan_data(video_scan_data),
		.scan_ack(video_scan_ack),
		.vid_r(vid_r),
		.vid_g(vid_g),
		.vid_b(vid_b),
		.hsync(hsync),
		.vsync(vsync),
		.hblank(hblank),
		.vblank(vblank),
		.de(de),
		.rgb_valid(rgb_valid),
		.vblank_irq(vblank_irq),
		.disp_base(video_disp_base),
		.disp_vblank(video_disp_vblank)
	);
	wire scan_brd_req;
	wire [24:0] scan_brd_addr;
	wire [9:0] scan_brd_len;
	wire [15:0] scan_brd_dout;
	wire scan_brd_dvalid;
	wire scan_brd_done;
	assign mem_scan_req = video_scan_req;
	assign mem_scan_addr = video_scan_addr;
	assign video_scan_data = mem_scan_data;
	assign video_scan_ack = mem_scan_ack;
	localparam signed [31:0] zunit_pkg_SDRAM_AW = 25;
	localparam [24:0] zunit_pkg_SDRAM_GFXW_BASE = 1'sb0;
	yunit_src_cache #(.GFXW_BASE(zunit_pkg_SDRAM_GFXW_BASE[23:0])) u_narc_src_cache(
		.clk(clk),
		.rst(rst_sys),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.brd_req(scan_brd_req),
		.brd_addr(scan_brd_addr),
		.brd_len(scan_brd_len),
		.brd_dout(scan_brd_dout),
		.brd_dvalid(scan_brd_dvalid),
		.brd_done(scan_brd_done)
	);
	wire palv_we_a;
	wire palv_we_b;
	wire [12:0] palv_aa;
	wire [12:0] palv_ba;
	wire [15:0] palv_awd;
	wire [15:0] palv_bwd;
	wire pal_q_ovf;
	narc_pal_wr_queue u_pal_wr_q(
		.clk(clk),
		.rst(rst_sys),
		.we_a(palv_we_a),
		.addr_a(palv_aa),
		.data_a(palv_awd),
		.we_b(palv_we_b),
		.addr_b(palv_ba),
		.data_b(palv_bwd),
		.pal_we(vpal_we),
		.pal_waddr(vpal_waddr),
		.pal_wdata(vpal_wdata),
		.ovf_o(pal_q_ovf)
	);
	wire [63:0] inputs_merged;
	wire [15:0] snd_talkback;
	narc_talkback_merge u_tbmerge(
		.inputs_ext(inputs),
		.talkback_rd(snd_talkback),
		.inputs_merged(inputs_merged)
	);
	localparam signed [31:0] zunit_pkg_SCR_V_VIS_EN = 427;
	localparam signed [31:0] zunit_pkg_SCR_V_VIS_ST = 27;
	function automatic signed [9:0] sv2v_cast_10_signed;
		input reg signed [9:0] inp;
		sv2v_cast_10_signed = inp;
	endfunction
	zunit_memsys #(
		.ROM_HEX(ROM_HEX),
		.ROM_PROG_OFF(ROM_PROG_OFF)
	) u_sys(
		.clk(clk),
		.rst(rst_sys),
		.mem_req(mem_req),
		.mem_we(mem_we),
		.mem_srt(mem_srt),
		.mem_addr(mem_addr),
		.mem_size(mem_size),
		.mem_wdata(mem_wdata),
		.mem_rdata(mem_rdata),
		.mem_ack(mem_ack),
		.src_req(src_req),
		.src_addr(src_addr),
		.src_data(src_data),
		.src_ack(src_ack),
		.inputs(inputs_merged),
		.int1(int1),
		.snd_select(snd_select),
		.snd_trig(snd_trig),
		.snd_reset(snd_reset),
		.snd_wr(snd_latch_wr),
		.snd_wdata(snd_latch_wdata),
		.erase_start(vblank_irq),
		.erase_row0(9'd0),
		.erase_lines(sv2v_cast_10_signed(zunit_pkg_SCR_V_VIS_EN - zunit_pkg_SCR_V_VIS_ST)),
		.erase_busy(erase_busy),
		.blit_busy(blit_busy),
		.dbg_dma_we(dbg_dma_we),
		.dbg_dma_addr(dbg_dma_addr),
		.dbg_dma_wdata(dbg_dma_wdata),
		.cpu_gfx_rd(cpu_gfx_rd),
		.cpu_gfx_raddr(cpu_gfx_raddr),
		.cpu_gfx_rdata(cpu_gfx_rdata),
		.cpu_gfx_rack(cpu_gfx_rack),
		.scan_req(mem_scan_req),
		.scan_addr(mem_scan_addr),
		.scan_data(mem_scan_data),
		.scan_ack(mem_scan_ack),
		.sdram_por(sdram_por),
		.scan_disp_base(video_disp_base),
		.scan_vblank(video_disp_vblank),
		.ddram_addr(ddram_addr),
		.ddram_burstcnt(ddram_burstcnt),
		.ddram_rd(ddram_rd),
		.ddram_we(ddram_we),
		.ddram_din(ddram_din),
		.ddram_be(ddram_be),
		.ddram_busy(ddram_busy),
		.ddram_dout(ddram_dout),
		.ddram_dout_ready(ddram_dout_ready),
		.palv_we_a(palv_we_a),
		.palv_aa(palv_aa),
		.palv_awd(palv_awd),
		.palv_we_b(palv_we_b),
		.palv_ba(palv_ba),
		.palv_bwd(palv_bwd)
	);
	assign int1_dbg = int1;
	wire ff_por = sdram_por;
	wire ff_read_ack = cpu_ack & ~cpu_we;
	always @(posedge clk)
		if (cpu_ce !== 1'b0) begin
			if (ff_por) begin
				dbg_ff_valid <= 1'b0;
				dbg_ff_addr <= 32'd0;
				dbg_ff_data <= 32'd0;
			end
			else if (!dbg_ff_valid && ff_read_ack) begin
				dbg_ff_valid <= 1'b1;
				dbg_ff_addr <= cpu_addr;
				dbg_ff_data <= cpu_rdata;
			end
		end
	assign dbg_rb_data = 32'd0;
	assign dbg_rb_valid = 1'b1;
	assign dbg_cksum_w0 = 32'd0;
	assign dbg_cksum_w1 = 32'd0;
	assign dbg_cksum_w2 = 32'd0;
	assign dbg_cksum_valid = 1'b0;
	wire [24:0] sd_addr;
	wire [15:0] sd_din;
	wire [15:0] sd_dout;
	wire [1:0] sd_be;
	wire sd_rd;
	wire sd_wr;
	wire sd_ack;
	wire iol_ack;
	localparam signed [31:0] IOL_AW = 9;
	localparam signed [31:0] IOL_HWM = 256;
	reg [42:0] iol_fifo [0:511];
	reg [IOL_AW:0] iol_wp;
	reg [IOL_AW:0] iol_rp;
	wire [IOL_AW:0] iol_occ = iol_wp - iol_rp;
	wire iol_full = iol_occ == 512;
	wire iol_empty = iol_wp == iol_rp;
	reg iol_hold;
	reg [24:0] iol_addr_r;
	reg [15:0] iol_din_r;
	reg [1:0] iol_be_r;
	always @(posedge clk)
		if (sdram_por) begin
			iol_wp <= 1'sb0;
			iol_rp <= 1'sb0;
			iol_hold <= 1'b0;
		end
		else begin
			if (ioctl_wr && !iol_full) begin
				iol_fifo[iol_wp[8:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
				iol_wp <= iol_wp + 1'b1;
			end
			if (iol_hold && iol_ack)
				iol_hold <= 1'b0;
			if ((!iol_hold || (iol_hold && iol_ack)) && !iol_empty) begin
				{iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[8:0]];
				iol_hold <= 1'b1;
				iol_rp <= iol_rp + 1'b1;
			end
		end
	assign ioctl_wait = iol_occ >= IOL_HWM[IOL_AW:0];
	assign dl_drain_busy = !iol_empty || iol_hold;
	zunit_iol_audit u_iol_audit(
		.clk(clk),
		.por(sdram_por),
		.ioctl_wr(ioctl_wr),
		.iol_full(iol_full),
		.ioctl_download(ioctl_download),
		.core_rst(rst),
		.accepted(fifo_accepted),
		.dropped(fifo_dropped),
		.rst_during_dl(rst_during_dl)
	);
	wire [15:0] iol_dout;
	reg [17:0] boot_settle_cnt;
	wire bs_drained = (~ioctl_download & iol_empty) & ~iol_hold;
	always @(posedge clk)
		if (sdram_por)
			boot_settle_cnt <= 18'd0;
		else if (!bs_drained)
			boot_settle_cnt <= 18'd0;
		else if (!boot_settle_cnt[17])
			boot_settle_cnt <= boot_settle_cnt + 18'd1;
	assign boot_settle_to = boot_settle_cnt[17];
	localparam signed [31:0] zunit_pkg_PROG_POPULATED_BYTES = 'h80000;
	localparam signed [31:0] zunit_pkg_SDRAM_PROG_WORDS = zunit_pkg_PROG_POPULATED_BYTES >> 1;
	localparam signed [31:0] zunit_pkg_GFX_POPULATED_BYTES = 'h3c0000;
	localparam signed [31:0] zunit_pkg_SDRAM_GFX_WORDS = zunit_pkg_GFX_POPULATED_BYTES >> 1;
	function automatic signed [24:0] sv2v_cast_25_signed;
		input reg signed [24:0] inp;
		sv2v_cast_25_signed = inp;
	endfunction
	localparam [24:0] zunit_pkg_SDRAM_ROMW_BASE = sv2v_cast_25_signed(zunit_pkg_SDRAM_GFX_WORDS);
	localparam [24:0] BS_VEC_LO = (zunit_pkg_SDRAM_ROMW_BASE + zunit_pkg_SDRAM_PROG_WORDS) - 2;
	localparam [24:0] BS_VEC_HI = (zunit_pkg_SDRAM_ROMW_BASE + zunit_pkg_SDRAM_PROG_WORDS) - 1;
	wire bs_iol_rd;
	wire [24:0] bs_iol_addr;
	wire [31:0] bs_data;
	wire bs_valid;
	zunit_boot_readback_audit #(
		.VEC_LO_ADDR(BS_VEC_LO),
		.VEC_HI_ADDR(BS_VEC_HI)
	) u_boot_settle(
		.clk(clk),
		.por(sdram_por),
		.sdram_ready(sdram_ready),
		.ioctl_download(ioctl_download),
		.fifo_empty(iol_empty),
		.fifo_hold(iol_hold),
		.iol_ack(iol_ack),
		.iol_dout(iol_dout),
		.iol_rd(bs_iol_rd),
		.iol_addr(bs_iol_addr),
		.data(bs_data),
		.valid(bs_valid)
	);
	assign boot_settle_busy = ~(bs_valid | boot_settle_to);
	wire audit_iol_rd = bs_iol_rd;
	wire [24:0] audit_iol_addr = bs_iol_addr;
	wire snd_rom_rd;
	wire [24:0] snd_rom_addr_w;
	wire [15:0] snd_rom_data_w;
	wire snd_rom_ack;
	function automatic signed [23:0] sv2v_cast_24_signed;
		input reg signed [23:0] inp;
		sv2v_cast_24_signed = inp;
	endfunction
	localparam [23:0] zunit_pkg_SDRAM_GFX_BYTES = sv2v_cast_24_signed(zunit_pkg_GFX_POPULATED_BYTES);
	localparam [24:0] zunit_pkg_SDRAM_VRAMW_BASE = sv2v_cast_25_signed(zunit_pkg_SDRAM_GFX_WORDS + zunit_pkg_SDRAM_PROG_WORDS);
	yunit_sdram_arb #(
		.SD_AW(zunit_pkg_SDRAM_AW),
		.GFXW_BASE(zunit_pkg_SDRAM_GFXW_BASE),
		.ROMW_BASE(zunit_pkg_SDRAM_ROMW_BASE),
		.VRAMW_BASE(zunit_pkg_SDRAM_VRAMW_BASE),
		.GFX_BYTES(zunit_pkg_SDRAM_GFX_BYTES)
	) u_arb(
		.clk(clk),
		.rst(sdram_por),
		.vsd_addr(25'd0),
		.vsd_din(16'd0),
		.vsd_be(2'd0),
		.vsd_rd(1'b0),
		.vsd_wr(1'b0),
		.vsd_dout(),
		.vsd_ack(),
		.cgfx_rd(cpu_gfx_rd),
		.cgfx_addr(cpu_gfx_raddr),
		.cgfx_data(cpu_gfx_rdata),
		.cgfx_ack(cpu_gfx_rack),
		.src_rd(1'b0),
		.src_addr(24'd0),
		.src_data(),
		.src_ack(),
		.iol_rd(audit_iol_rd),
		.iol_wr(iol_hold),
		.iol_addr((audit_iol_rd ? audit_iol_addr : iol_addr_r)),
		.iol_din(iol_din_r),
		.iol_be(iol_be_r),
		.iol_dout(iol_dout),
		.iol_ack(iol_ack),
		.snd_rd(snd_rom_rd),
		.snd_addr_w(snd_rom_addr_w),
		.snd_data(snd_rom_data_w),
		.snd_ack(snd_rom_ack),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack)
	);
	wire [24:0] ctl_addr;
	wire [15:0] ctl_din;
	wire [15:0] ctl_dout;
	wire [1:0] ctl_wtbt;
	wire ctl_rd;
	wire ctl_we;
	wire ctl_ready_raw;
	yunit_sdram_adapter u_sdadapt(
		.clk(clk),
		.rst(sdram_por),
		.sd_addr(sd_addr),
		.sd_din(sd_din),
		.sd_be(sd_be),
		.sd_rd(sd_rd),
		.sd_wr(sd_wr),
		.sd_dout(sd_dout),
		.sd_ack(sd_ack),
		.sdram_ready(sdram_ready),
		.ctl_addr(ctl_addr),
		.ctl_din(ctl_din),
		.ctl_wtbt(ctl_wtbt),
		.ctl_rd(ctl_rd),
		.ctl_we(ctl_we),
		.ctl_dout(ctl_dout),
		.ctl_ready(ctl_ready_raw)
	);
	localparam signed [31:0] zunit_pkg_FB_H = 512;
	localparam signed [31:0] zunit_pkg_FB_W = 512;
	localparam signed [31:0] zunit_pkg_SDRAM_VRAM_WORDS = zunit_pkg_FB_W * zunit_pkg_FB_H;
	sdram_stock_shipped #(
		.VRAM_BBASE(zunit_pkg_SDRAM_VRAMW_BASE << 1),
		.VRAM_BYTES(zunit_pkg_SDRAM_VRAM_WORDS << 1),
		.GFX_BBASE(zunit_pkg_SDRAM_GFXW_BASE << 1),
		.GFX_BYTES(zunit_pkg_SDRAM_GFX_WORDS << 1)
	) u_sdram(
		.init(sdram_por),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready_raw),
		.brd_req(scan_brd_req),
		.brd_addr(scan_brd_addr),
		.brd_len(scan_brd_len),
		.brd_dout(scan_brd_dout),
		.brd_dvalid(scan_brd_dvalid),
		.brd_done(scan_brd_done),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	wire snd_board_rst;
	wire snd_rom_ready;
	wire [31:0] snd_fetch_wait_clks;
	wire [31:0] snd_wd_rearms;
	wire cen_e;
	wire cen_q;
	localparam signed [31:0] zunit_pkg_CLK_SYS_HZ = 96000000;
	localparam signed [31:0] zunit_pkg_SND_MASTER_CLOCK_HZ = 8000000;
	localparam signed [31:0] zunit_pkg_SND_6809_E_HZ = 2000000;
	narc_6809_clock_en #(
		.CLK_HZ(zunit_pkg_CLK_SYS_HZ),
		.CPU_HZ(zunit_pkg_SND_6809_E_HZ)
	) u_6809_clock_en(
		.clk(clk),
		.rst(snd_board_rst),
		.rom_ready(snd_rom_ready),
		.cen_e(cen_e),
		.cen_q(cen_q),
		.stall_clks(snd_rom_stall_clks)
	);
	wire cen_fm;
	wire cen_fm_p1;
	localparam signed [31:0] zunit_pkg_SND_YM2151_HZ = 3579545;
	narc_ym_clock_en #(
		.CLK_HZ(zunit_pkg_CLK_SYS_HZ),
		.YM_HZ(zunit_pkg_SND_YM2151_HZ)
	) u_ym_clock_en(
		.clk(clk),
		.rst(rst_sys),
		.cen_fm(cen_fm),
		.cen_fm_p1(cen_fm_p1),
		.sound_rst(snd_board_rst)
	);
	wire mst_rom_read;
	wire slv_rom_read;
	wire [7:0] mst_rom_data;
	wire [7:0] slv_rom_data;
	localparam [24:0] zunit_pkg_SDRAM_SNDW_BASE = sv2v_cast_25_signed((zunit_pkg_SDRAM_GFX_WORDS + zunit_pkg_SDRAM_PROG_WORDS) + zunit_pkg_SDRAM_VRAM_WORDS);
	localparam signed [31:0] zunit_pkg_SND_IMAGE_BYTES = 32'h00090000;
	localparam signed [31:0] zunit_pkg_SND_IMAGE_WORDS = zunit_pkg_SND_IMAGE_BYTES >> 1;
	zunit_snd_rom #(
		.SD_AW(zunit_pkg_SDRAM_AW),
		.SNDW_BASE(zunit_pkg_SDRAM_SNDW_BASE),
		.IMAGE_WORDS(zunit_pkg_SND_IMAGE_WORDS)
	) u_snd_rom(
		.clk(clk),
		.rst(snd_board_rst),
		.mst_offset(mst_rom_offset),
		.mst_read(mst_rom_read),
		.mst_data(mst_rom_data),
		.slv_offset(slv_rom_offset),
		.slv_read(slv_rom_read),
		.slv_data(slv_rom_data),
		.ready(snd_rom_ready),
		.snd_rd(snd_rom_rd),
		.snd_addr_w(snd_rom_addr_w),
		.snd_data(snd_rom_data_w),
		.snd_ack(snd_rom_ack),
		.stall_clks(snd_fetch_wait_clks),
		.wd_rearms(snd_wd_rearms)
	);
	wire signed [15:0] snd_ym_l;
	wire signed [15:0] snd_ym_r;
	wire [7:0] snd_dac1_level;
	wire [7:0] snd_dac2_level;
	wire [15:0] snd_cvsd;
	narc_sound_board u_snd(
		.clk(clk),
		.rst_pon(snd_board_rst),
		.cen_e(cen_e),
		.cen_q(cen_q),
		.cen_fm(cen_fm),
		.cen_fm_p1(cen_fm_p1),
		.ext_wr(snd_latch_wr),
		.ext_wdata(snd_latch_wdata),
		.reset_in(snd_board_rst),
		.talkback_rd(snd_talkback),
		.sound_int_state(),
		.mst_rom_offset(mst_rom_offset),
		.mst_rom_read(mst_rom_read),
		.mst_rom_data(mst_rom_data),
		.slv_rom_offset(slv_rom_offset),
		.slv_rom_read(slv_rom_read),
		.slv_rom_data(slv_rom_data),
		.ym_left(snd_ym_l),
		.ym_right(snd_ym_r),
		.dac1_level(snd_dac1_level),
		.dac2_level(snd_dac2_level),
		.dac1_sample(),
		.dac2_sample(),
		.cvsd_sample(snd_cvsd)
	);
	narc_audio_mix u_audio_mix(
		.clk(clk),
		.rst(snd_board_rst),
		.ym_l(snd_ym_l),
		.ym_r(snd_ym_r),
		.dac1_u(snd_dac1_level),
		.dac2_u(snd_dac2_level),
		.cvsd_u(snd_cvsd),
		.audio_l(audio_l),
		.audio_r(audio_r)
	);
endmodule
`default_nettype wire
`default_nettype none
module smashtv_diag_top (
	clk,
	clk_cpu,
	ce_pix,
	cpu_div_sel,
	clk_snd,
	rst,
	rst_pon,
	sdram_por,
	inputs,
	ioctl_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	snd_dl_wr,
	snd_dl_addr,
	snd_dl_data,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	audio_l,
	audio_r,
	pc_dbg,
	illegal_dbg,
	dbg_core_rst,
	dbg_sdram_ready,
	dbg_unp_done,
	dbg_cpu_req,
	dbg_mem_ack,
	dbg_int1,
	dbg_vblank_irq,
	dbg_derailed,
	dbg_culprit_pc,
	dbg_culprit_instr,
	dbg_derail_pc,
	dbg_cpu_ce,
	dbg_iol_drop,
	dbg_iol_wrs,
	dbg_dma_we,
	dbg_dma_addr,
	dbg_dma_wdata,
	dbg_src_data,
	dbg_src_ack,
	dbg_scan_data,
	dbg_scan_ack,
	DDRAM_ADDR,
	DDRAM_BURSTCNT,
	DDRAM_RD,
	DDRAM_DIN,
	DDRAM_BE,
	DDRAM_WE,
	DDRAM_BUSY,
	DDRAM_DOUT,
	DDRAM_DOUT_READY
);
	reg _sv2v_0;
	parameter ROM_HEX = "";
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter [24:0] DIAG_NWORDS = 25'h0160000;
	input wire clk;
	input wire clk_cpu;
	input wire ce_pix;
	input wire [2:0] cpu_div_sel;
	input wire clk_snd;
	input wire rst;
	input wire rst_pon;
	input wire sdram_por;
	input wire [63:0] inputs;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	input wire snd_dl_wr;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output wire signed [15:0] audio_l;
	output wire signed [15:0] audio_r;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire dbg_core_rst;
	output wire dbg_sdram_ready;
	output wire dbg_unp_done;
	output wire dbg_cpu_req;
	output wire dbg_mem_ack;
	output wire dbg_int1;
	output wire dbg_vblank_irq;
	output wire dbg_derailed;
	output wire [31:0] dbg_culprit_pc;
	output wire [15:0] dbg_culprit_instr;
	output wire [31:0] dbg_derail_pc;
	output wire dbg_cpu_ce;
	output wire [31:0] dbg_iol_drop;
	output wire [31:0] dbg_iol_wrs;
	output wire dbg_dma_we;
	output wire [3:0] dbg_dma_addr;
	output wire [15:0] dbg_dma_wdata;
	output wire [7:0] dbg_src_data;
	output wire dbg_src_ack;
	output wire [15:0] dbg_scan_data;
	output wire dbg_scan_ack;
	output wire [28:0] DDRAM_ADDR;
	output wire [7:0] DDRAM_BURSTCNT;
	output wire DDRAM_RD;
	output wire [63:0] DDRAM_DIN;
	output wire [7:0] DDRAM_BE;
	output wire DDRAM_WE;
	input wire DDRAM_BUSY;
	input wire [63:0] DDRAM_DOUT;
	input wire DDRAM_DOUT_READY;
	assign ioctl_wait = 1'b0;
	assign dbg_core_rst = 1'b0;
	assign dbg_sdram_ready = 1'b0;
	assign dbg_unp_done = 1'b0;
	assign dbg_cpu_req = 1'b0;
	assign dbg_mem_ack = 1'b0;
	assign dbg_int1 = 1'b0;
	assign dbg_vblank_irq = 1'b0;
	assign dbg_derailed = 1'b0;
	assign dbg_culprit_pc = 32'd0;
	assign dbg_culprit_instr = 16'd0;
	assign dbg_derail_pc = 32'd0;
	assign audio_l = 16'sd0;
	assign audio_r = 16'sd0;
	assign illegal_dbg = 1'b0;
	assign dbg_cpu_ce = 1'b0;
	assign dbg_iol_drop = 32'd0;
	assign dbg_iol_wrs = 32'd0;
	assign dbg_dma_we = 1'b0;
	assign dbg_dma_addr = 4'd0;
	assign dbg_dma_wdata = 16'd0;
	assign dbg_src_data = 8'd0;
	assign dbg_src_ack = 1'b0;
	assign dbg_scan_data = 16'd0;
	assign dbg_scan_ack = 1'b0;
	assign DDRAM_ADDR = 29'd0;
	assign DDRAM_BURSTCNT = 8'd0;
	assign DDRAM_RD = 1'b0;
	assign DDRAM_DIN = 64'd0;
	assign DDRAM_BE = 8'd0;
	assign DDRAM_WE = 1'b0;
	reg [24:0] ctl_addr;
	reg [15:0] ctl_din;
	wire [15:0] ctl_dout;
	reg [1:0] ctl_wtbt;
	reg ctl_rd;
	reg ctl_we;
	wire ctl_ready;
	sdram_stock u_sdram(
		.init(rst),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	function automatic [15:0] patt;
		input [24:0] i;
		patt = (i[15:0] ^ {i[23:16], i[23:16]}) ^ 16'h5aa5;
	endfunction
	reg [3:0] ds;
	reg [24:0] idx;
	reg [31:0] miscount;
	reg [24:0] first_fail;
	reg failed;
	reg settle;
	wire [15:0] exp = patt(idx);
	always @(posedge clk)
		if (rst) begin
			ds <= 4'd0;
			idx <= 25'd0;
			miscount <= 32'd0;
			first_fail <= 25'h1ffffff;
			failed <= 1'b0;
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			ctl_addr <= 25'd0;
			ctl_din <= 16'd0;
			ctl_wtbt <= 2'b11;
			settle <= 1'b0;
		end
		else begin
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			case (ds)
				4'd0:
					if (ctl_ready) begin
						idx <= 25'd0;
						ds <= 4'd1;
					end
				4'd1:
					if (ctl_ready) begin
						ctl_addr <= {idx[23:0], 1'b0};
						ctl_din <= {8'h00, exp[7:0]};
						ctl_wtbt <= 2'b01;
						ctl_we <= 1'b1;
						settle <= 1'b1;
						ds <= 4'd2;
					end
				4'd2:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready)
						ds <= 4'd3;
				4'd3:
					if (ctl_ready) begin
						ctl_addr <= {idx[23:0], 1'b0};
						ctl_din <= {exp[15:8], 8'h00};
						ctl_wtbt <= 2'b10;
						ctl_we <= 1'b1;
						settle <= 1'b1;
						ds <= 4'd4;
					end
				4'd4:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready) begin
						if (idx == (DIAG_NWORDS - 1)) begin
							idx <= 25'd0;
							ds <= 4'd5;
						end
						else begin
							idx <= idx + 25'd1;
							ds <= 4'd1;
						end
					end
				4'd5:
					if (ctl_ready) begin
						ctl_addr <= {idx[23:0], 1'b0};
						ctl_rd <= 1'b1;
						settle <= 1'b1;
						ds <= 4'd6;
					end
				4'd6:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready) begin
						if (ctl_dout != exp) begin
							miscount <= miscount + 32'd1;
							failed <= 1'b1;
							if (first_fail == 25'h1ffffff)
								first_fail <= idx;
						end
						if (idx == (DIAG_NWORDS - 1))
							ds <= (failed || (ctl_dout != exp) ? 4'd8 : 4'd7);
						else begin
							idx <= idx + 25'd1;
							ds <= 4'd5;
						end
					end
				4'd7: ds <= 4'd7;
				4'd8: ds <= 4'd8;
				default: ds <= 4'd0;
			endcase
		end
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	reg [11:0] hc;
	reg [11:0] vc;
	reg [23:0] frame;
	always @(posedge clk)
		if (rst) begin
			hc <= 0;
			vc <= 0;
			frame <= 0;
		end
		else if (ce_pix) begin
			if (hc == (H_TOTAL - 1)) begin
				hc <= 0;
				if (vc == (V_TOTAL - 1)) begin
					vc <= 0;
					frame <= frame + 24'd1;
				end
				else
					vc <= vc + 12'd1;
			end
			else
				hc <= hc + 12'd1;
		end
	wire s0_de = (hc < H_ACT) && (vc < V_ACT);
	wire s0_hb = hc >= H_ACT;
	wire s0_vb = vc >= V_ACT;
	wire s0_hs = (hc >= (H_ACT + H_FP)) && (hc < ((H_ACT + H_FP) + H_SYNC));
	wire s0_vs = (vc >= (V_ACT + V_FP)) && (vc < ((V_ACT + V_FP) + V_SYNC));
	reg [7:0] br;
	reg [7:0] bg;
	reg [7:0] bb;
	always @(*) begin
		if (_sv2v_0)
			;
		case (ds)
			4'd0: begin
				br = 8'h00;
				bg = 8'h00;
				bb = 8'hc0;
			end
			4'd7: begin
				br = 8'h00;
				bg = 8'hc0;
				bb = 8'h00;
			end
			4'd8: begin
				br = 8'hc0;
				bg = 8'h00;
				bb = 8'h00;
			end
			default: begin
				br = 8'h80;
				bg = 8'h80;
				bb = 8'h00;
			end
		endcase
	end
	localparam signed [31:0] E = H_ACT / 8;
	reg [7:0] cbr;
	reg [7:0] cbg;
	reg [7:0] cbb;
	wire [2:0] bar = (hc < E ? 3'd0 : (hc < (2 * E) ? 3'd1 : (hc < (3 * E) ? 3'd2 : (hc < (4 * E) ? 3'd3 : (hc < (5 * E) ? 3'd4 : (hc < (6 * E) ? 3'd5 : (hc < (7 * E) ? 3'd6 : 3'd7)))))));
	always @(*) begin
		if (_sv2v_0)
			;
		case (bar)
			3'd0: {cbr, cbg, cbb} = 24'hffffff;
			3'd1: {cbr, cbg, cbb} = 24'hffff00;
			3'd2: {cbr, cbg, cbb} = 24'h00ffff;
			3'd3: {cbr, cbg, cbb} = 24'h00ff00;
			3'd4: {cbr, cbg, cbb} = 24'hff00ff;
			3'd5: {cbr, cbg, cbb} = 24'hff0000;
			3'd6: {cbr, cbg, cbb} = 24'h0000ff;
			default: {cbr, cbg, cbb} = 24'h000000;
		endcase
	end
	wire [5:0] milog = (miscount[31] ? 6'd32 : (miscount[24] ? 6'd25 : (miscount[20] ? 6'd21 : (miscount[16] ? 6'd17 : (miscount[12] ? 6'd13 : (miscount[8] ? 6'd9 : (miscount[4] ? 6'd5 : (miscount[1] ? 6'd2 : (miscount[0] ? 6'd1 : 6'd0)))))))));
	wire [15:0] mibar_w = (H_ACT * milog) >> 5;
	wire in_bars = vc < (V_ACT / 8);
	wire in_mibar = vc >= (V_ACT - (V_ACT / 8));
	wire live_col = hc == frame[8:0];
	always @(posedge clk)
		if (ce_pix) begin
			de <= s0_de;
			hsync <= s0_hs;
			vsync <= s0_vs;
			hblank <= s0_hb;
			vblank <= s0_vb;
			if (!s0_de) begin
				vid_r <= 0;
				vid_g <= 0;
				vid_b <= 0;
			end
			else if (in_bars) begin
				vid_r <= cbr;
				vid_g <= cbg;
				vid_b <= cbb;
			end
			else if (live_col) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else if (in_mibar) begin
				if ({4'd0, hc} < mibar_w) begin
					vid_r <= 8'hff;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h20;
					vid_g <= 8'h20;
					vid_b <= 8'h20;
				end
			end
			else begin
				vid_r <= br;
				vid_g <= bg;
				vid_b <= bb;
			end
		end
	assign pc_dbg = {3'd0, ds, first_fail};
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_diag2_overlay (
	clk,
	ce_pix,
	rst,
	core_rst,
	sdram_ready,
	unp_done,
	ioctl_download,
	cpu_req,
	mem_ack,
	int1,
	vblank_irq,
	cpu_ce,
	pc,
	illegal,
	derailed,
	culprit_pc,
	culprit_instr,
	derail_pc,
	g_r,
	g_g,
	g_b,
	g_hs,
	g_vs,
	g_hb,
	g_vb,
	g_de,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de
);
	reg _sv2v_0;
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	input wire clk;
	input wire ce_pix;
	input wire rst;
	input wire core_rst;
	input wire sdram_ready;
	input wire unp_done;
	input wire ioctl_download;
	input wire cpu_req;
	input wire mem_ack;
	input wire int1;
	input wire vblank_irq;
	input wire cpu_ce;
	input wire [31:0] pc;
	input wire illegal;
	input wire derailed;
	input wire [31:0] culprit_pc;
	input wire [15:0] culprit_instr;
	input wire [31:0] derail_pc;
	input wire [7:0] g_r;
	input wire [7:0] g_g;
	input wire [7:0] g_b;
	input wire g_hs;
	input wire g_vs;
	input wire g_hb;
	input wire g_vb;
	input wire g_de;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	function automatic [14:0] glyph;
		input [3:0] v;
		case (v)
			4'h0: glyph = 15'b111101101101111;
			4'h1: glyph = 15'b010110010010111;
			4'h2: glyph = 15'b111001111100111;
			4'h3: glyph = 15'b111001111001111;
			4'h4: glyph = 15'b101101111001001;
			4'h5: glyph = 15'b111100111001111;
			4'h6: glyph = 15'b111100111101111;
			4'h7: glyph = 15'b111001001010010;
			4'h8: glyph = 15'b111101111101111;
			4'h9: glyph = 15'b111101111001111;
			4'ha: glyph = 15'b111101111101101;
			4'hb: glyph = 15'b110101110101110;
			4'hc: glyph = 15'b111100100100111;
			4'hd: glyph = 15'b110101101101110;
			4'he: glyph = 15'b111100111100111;
			default: glyph = 15'b111100111100100;
		endcase
	endfunction
	function automatic fpix;
		input [3:0] d;
		input [2:0] col;
		input [2:0] row;
		reg [14:0] g;
		reg [2:0] rb;
		begin
			g = glyph(d);
			case (row)
				3'd0: rb = g[14:12];
				3'd1: rb = g[11:9];
				3'd2: rb = g[8:6];
				3'd3: rb = g[5:3];
				default: rb = g[2:0];
			endcase
			fpix = (col == 3'd0 ? rb[2] : (col == 3'd1 ? rb[1] : (col == 3'd2 ? rb[0] : 1'b0)));
		end
	endfunction
	reg [11:0] gx;
	reg [11:0] gy;
	reg de_q;
	reg vb_q;
	reg [23:0] frame;
	reg [31:0] pc_q;
	reg [31:0] pc_qq;
	reg [31:0] pc_show;
	always @(posedge clk)
		if (rst) begin
			gx <= 0;
			gy <= 0;
			de_q <= 0;
			vb_q <= 0;
			frame <= 0;
			pc_q <= 0;
			pc_qq <= 0;
			pc_show <= 0;
		end
		else if (ce_pix) begin
			de_q <= g_de;
			vb_q <= g_vb;
			pc_q <= pc;
			pc_qq <= pc_q;
			if (g_vb && !vb_q) begin
				gy <= 12'd0;
				gx <= 12'd0;
				frame <= frame + 24'd1;
				if (frame[4:0] == 5'd0)
					pc_show <= pc_qq;
			end
			else if (g_de)
				gx <= gx + 12'd1;
			else if (de_q && !g_de) begin
				gx <= 12'd0;
				gy <= gy + 12'd1;
			end
		end
	wire [11:0] hc = gx << 1;
	wire [11:0] vc = gy << 1;
	wire s0_de = (hc < H_ACT) && (vc < V_ACT);
	wire frame_tick = (ce_pix && g_vb) && !vb_q;
	reg a1_req;
	reg a0_req;
	reg a1_ack;
	reg a0_ack;
	reg a1_i1;
	reg a0_i1;
	reg a1_vb;
	reg a0_vb;
	reg a1_ce;
	reg a0_ce;
	reg alive_req;
	reg alive_ack;
	reg alive_i1;
	reg alive_vb;
	reg alive_ce;
	reg illegal_sticky;
	always @(posedge clk)
		if (rst) begin
			a1_req <= 0;
			a0_req <= 0;
			a1_ack <= 0;
			a0_ack <= 0;
			a1_i1 <= 0;
			a0_i1 <= 0;
			a1_vb <= 0;
			a0_vb <= 0;
			a1_ce <= 0;
			a0_ce <= 0;
			alive_req <= 0;
			alive_ack <= 0;
			alive_i1 <= 0;
			alive_vb <= 0;
			alive_ce <= 0;
			illegal_sticky <= 0;
		end
		else begin
			if (illegal)
				illegal_sticky <= 1'b1;
			if (cpu_req)
				a1_req <= 1'b1;
			else
				a0_req <= 1'b1;
			if (mem_ack)
				a1_ack <= 1'b1;
			else
				a0_ack <= 1'b1;
			if (int1)
				a1_i1 <= 1'b1;
			else
				a0_i1 <= 1'b1;
			if (vblank_irq)
				a1_vb <= 1'b1;
			else
				a0_vb <= 1'b1;
			if (cpu_ce)
				a1_ce <= 1'b1;
			else
				a0_ce <= 1'b1;
			if (frame_tick) begin
				alive_req <= a1_req & a0_req;
				a1_req <= 1'b0;
				a0_req <= 1'b0;
				alive_ack <= a1_ack & a0_ack;
				a1_ack <= 1'b0;
				a0_ack <= 1'b0;
				alive_i1 <= a1_i1 & a0_i1;
				a1_i1 <= 1'b0;
				a0_i1 <= 1'b0;
				alive_vb <= a1_vb & a0_vb;
				a1_vb <= 1'b0;
				a0_vb <= 1'b0;
				alive_ce <= a1_ce & a0_ce;
				a1_ce <= 1'b0;
				a0_ce <= 1'b0;
			end
		end
	localparam signed [31:0] LEDW = H_ACT / 10;
	wire in_leds = (vc >= 12'd44) && (vc < 12'd52);
	wire [3:0] led_lane = (hc < LEDW ? 4'd0 : (hc < (2 * LEDW) ? 4'd1 : (hc < (3 * LEDW) ? 4'd2 : (hc < (4 * LEDW) ? 4'd3 : (hc < (5 * LEDW) ? 4'd4 : (hc < (6 * LEDW) ? 4'd5 : (hc < (7 * LEDW) ? 4'd6 : (hc < (8 * LEDW) ? 4'd7 : (hc < (9 * LEDW) ? 4'd8 : 4'd9)))))))));
	wire [11:0] led_x = hc - (led_lane * LEDW);
	wire led_body = (led_x >= 12'd2) && (led_x < (LEDW - 2));
	reg led_good;
	always @(*) begin
		if (_sv2v_0)
			;
		case (led_lane)
			4'd0: led_good = ~core_rst;
			4'd1: led_good = sdram_ready;
			4'd2: led_good = unp_done;
			4'd3: led_good = ~ioctl_download;
			4'd4: led_good = ~illegal_sticky;
			4'd5: led_good = alive_req;
			4'd6: led_good = alive_ack;
			4'd7: led_good = alive_i1;
			4'd8: led_good = alive_vb;
			default: led_good = alive_ce;
		endcase
	end
	localparam signed [31:0] HE = H_ACT / 8;
	reg [7:0] cbr;
	reg [7:0] cbg;
	reg [7:0] cbb;
	wire [2:0] barx = (hc < HE ? 3'd0 : (hc < (2 * HE) ? 3'd1 : (hc < (3 * HE) ? 3'd2 : (hc < (4 * HE) ? 3'd3 : (hc < (5 * HE) ? 3'd4 : (hc < (6 * HE) ? 3'd5 : (hc < (7 * HE) ? 3'd6 : 3'd7)))))));
	always @(*) begin
		if (_sv2v_0)
			;
		case (barx)
			3'd0: {cbr, cbg, cbb} = 24'hffffff;
			3'd1: {cbr, cbg, cbb} = 24'hffff00;
			3'd2: {cbr, cbg, cbb} = 24'h00ffff;
			3'd3: {cbr, cbg, cbb} = 24'h00ff00;
			3'd4: {cbr, cbg, cbb} = 24'hff00ff;
			3'd5: {cbr, cbg, cbb} = 24'hff0000;
			3'd6: {cbr, cbg, cbb} = 24'h0000ff;
			default: {cbr, cbg, cbb} = 24'h202020;
		endcase
	end
	reg [31:0] rowval;
	reg in_hex;
	reg [11:0] ry0;
	always @(*) begin
		if (_sv2v_0)
			;
		in_hex = 1'b0;
		rowval = 32'd0;
		ry0 = 12'd0;
		if ((vc >= 12'd52) && (vc < 12'd96)) begin
			in_hex = 1'b1;
			ry0 = 12'd52;
			rowval = culprit_pc;
		end
		else if ((vc >= 12'd100) && (vc < 12'd144)) begin
			in_hex = 1'b1;
			ry0 = 12'd100;
			rowval = {16'h0000, culprit_instr};
		end
		else if ((vc >= 12'd148) && (vc < 12'd192)) begin
			in_hex = 1'b1;
			ry0 = 12'd148;
			rowval = derail_pc;
		end
		else if ((vc >= 12'd200) && (vc < 12'd244)) begin
			in_hex = 1'b1;
			ry0 = 12'd200;
			rowval = pc_show;
		end
	end
	localparam signed [31:0] PX0 = 77;
	wire hxin = (hc >= PX0) && (hc < 333);
	wire [7:0] hrx = hc - PX0[11:0];
	wire [2:0] hdig = hrx[7:5];
	wire [1:0] hfcol = hrx[4:3];
	wire [11:0] hry12 = vc - ry0;
	wire [2:0] hfrow = hry12[5:3];
	wire [4:0] hsh = {2'b00, 3'd7 - hdig} << 2;
	wire [3:0] hnyb = rowval >> hsh;
	wire hex_on = (((in_hex && hxin) && (hfcol < 2'd3)) && (hfrow < 3'd5)) && fpix(hnyb, {1'b0, hfcol}, hfrow);
	wire in_status = (vc >= 12'd24) && (vc < 12'd44);
	wire live_col = hc == frame[8:0];
	always @(posedge clk)
		if (ce_pix) begin
			de <= g_de;
			hsync <= g_hs;
			vsync <= g_vs;
			hblank <= g_hb;
			vblank <= g_vb;
			if (!g_de) begin
				vid_r <= 8'd0;
				vid_g <= 8'd0;
				vid_b <= 8'd0;
			end
			else if (!s0_de) begin
				vid_r <= g_r;
				vid_g <= g_g;
				vid_b <= g_b;
			end
			else if (vc < 12'd20) begin
				vid_r <= cbr;
				vid_g <= cbg;
				vid_b <= cbb;
			end
			else if (live_col) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else if (in_status) begin
				if (derailed) begin
					vid_r <= 8'hc0;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h00;
					vid_g <= 8'hc0;
					vid_b <= 8'h00;
				end
			end
			else if (in_leds) begin
				if (led_body) begin
					if (led_good) begin
						vid_r <= 8'h00;
						vid_g <= 8'he0;
						vid_b <= 8'h00;
					end
					else begin
						vid_r <= 8'he0;
						vid_g <= 8'h00;
						vid_b <= 8'h00;
					end
				end
				else begin
					vid_r <= 8'h00;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
			end
			else if (in_hex) begin
				if (hex_on) begin
					vid_r <= 8'hff;
					vid_g <= 8'hff;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h10;
					vid_g <= 8'h10;
					vid_b <= 8'h30;
				end
			end
			else begin
				vid_r <= 8'h08;
				vid_g <= 8'h08;
				vid_b <= 8'h08;
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_diag_rom (
	clk,
	clk_cpu,
	ce_pix,
	clk_snd,
	rst,
	rst_pon,
	inputs,
	ioctl_download,
	ioctl_wr,
	ioctl_addr,
	ioctl_dout,
	ioctl_be,
	ioctl_wait,
	snd_dl_wr,
	snd_dl_addr,
	snd_dl_data,
	SDRAM_DQ,
	SDRAM_A,
	SDRAM_BA,
	SDRAM_DQML,
	SDRAM_DQMH,
	SDRAM_nCS,
	SDRAM_nRAS,
	SDRAM_nCAS,
	SDRAM_nWE,
	SDRAM_CKE,
	vid_r,
	vid_g,
	vid_b,
	hsync,
	vsync,
	hblank,
	vblank,
	de,
	audio_l,
	audio_r,
	pc_dbg,
	illegal_dbg,
	dbg_core_rst,
	dbg_sdram_ready,
	dbg_unp_done,
	dbg_cpu_req,
	dbg_mem_ack,
	dbg_int1,
	dbg_vblank_irq,
	dbg_derailed,
	dbg_culprit_pc,
	dbg_derail_pc,
	dbg_culprit_instr
);
	reg _sv2v_0;
	parameter ROM_HEX = "";
	parameter signed [31:0] H_ACT = 410;
	parameter signed [31:0] H_FP = 6;
	parameter signed [31:0] H_SYNC = 40;
	parameter signed [31:0] H_BP = 50;
	parameter signed [31:0] V_ACT = 256;
	parameter signed [31:0] V_FP = 13;
	parameter signed [31:0] V_SYNC = 8;
	parameter signed [31:0] V_BP = 12;
	parameter [24:0] ROMW_BASE = 25'h00c0000;
	parameter [24:0] ROM_WORDS = 25'h0020000;
	input wire clk;
	input wire clk_cpu;
	input wire ce_pix;
	input wire clk_snd;
	input wire rst;
	input wire rst_pon;
	input wire [63:0] inputs;
	input wire ioctl_download;
	input wire ioctl_wr;
	input wire [24:0] ioctl_addr;
	input wire [15:0] ioctl_dout;
	input wire [1:0] ioctl_be;
	output wire ioctl_wait;
	input wire snd_dl_wr;
	input wire [17:0] snd_dl_addr;
	input wire [7:0] snd_dl_data;
	inout wire [15:0] SDRAM_DQ;
	output wire [12:0] SDRAM_A;
	output wire [1:0] SDRAM_BA;
	output wire SDRAM_DQML;
	output wire SDRAM_DQMH;
	output wire SDRAM_nCS;
	output wire SDRAM_nRAS;
	output wire SDRAM_nCAS;
	output wire SDRAM_nWE;
	output wire SDRAM_CKE;
	output reg [7:0] vid_r;
	output reg [7:0] vid_g;
	output reg [7:0] vid_b;
	output reg hsync;
	output reg vsync;
	output reg hblank;
	output reg vblank;
	output reg de;
	output wire signed [15:0] audio_l;
	output wire signed [15:0] audio_r;
	output wire [31:0] pc_dbg;
	output wire illegal_dbg;
	output wire dbg_core_rst;
	output wire dbg_sdram_ready;
	output wire dbg_unp_done;
	output wire dbg_cpu_req;
	output wire dbg_mem_ack;
	output wire dbg_int1;
	output wire dbg_vblank_irq;
	output wire dbg_derailed;
	output wire [31:0] dbg_culprit_pc;
	output wire [31:0] dbg_derail_pc;
	output wire [15:0] dbg_culprit_instr;
	assign audio_l = 16'sd0;
	assign audio_r = 16'sd0;
	assign illegal_dbg = 1'b0;
	assign dbg_core_rst = 0;
	assign dbg_sdram_ready = 0;
	assign dbg_unp_done = 0;
	assign dbg_cpu_req = 0;
	assign dbg_mem_ack = 0;
	assign dbg_int1 = 0;
	assign dbg_vblank_irq = 0;
	assign dbg_derailed = 0;
	assign dbg_culprit_pc = 0;
	assign dbg_derail_pc = 0;
	assign dbg_culprit_instr = 0;
	reg [24:0] ctl_addr;
	reg [15:0] ctl_din;
	wire [15:0] ctl_dout;
	reg [1:0] ctl_wtbt;
	reg ctl_rd;
	reg ctl_we;
	wire ctl_ready;
	sdram_stock u_sdram(
		.init(rst),
		.clk(clk),
		.addr(ctl_addr),
		.din(ctl_din),
		.wtbt(ctl_wtbt),
		.we(ctl_we),
		.rd(ctl_rd),
		.dout(ctl_dout),
		.ready(ctl_ready),
		.SDRAM_DQ(SDRAM_DQ),
		.SDRAM_A(SDRAM_A),
		.SDRAM_BA(SDRAM_BA),
		.SDRAM_DQML(SDRAM_DQML),
		.SDRAM_DQMH(SDRAM_DQMH),
		.SDRAM_nCS(SDRAM_nCS),
		.SDRAM_nRAS(SDRAM_nRAS),
		.SDRAM_nCAS(SDRAM_nCAS),
		.SDRAM_nWE(SDRAM_nWE),
		.SDRAM_CKE(SDRAM_CKE)
	);
	localparam signed [31:0] IOL_AW = 9;
	localparam signed [31:0] IOL_HWM = 256;
	reg [42:0] iol_fifo [0:511];
	reg [IOL_AW:0] iol_wp;
	reg [IOL_AW:0] iol_rp;
	wire [IOL_AW:0] iol_occ = iol_wp - iol_rp;
	wire iol_full = iol_occ == 512;
	wire iol_empty = iol_wp == iol_rp;
	reg iol_hold;
	reg [24:0] iol_addr_r;
	reg [15:0] iol_din_r;
	reg [1:0] iol_be_r;
	reg wr_done;
	always @(posedge clk)
		if (rst) begin
			iol_wp <= 1'sb0;
			iol_rp <= 1'sb0;
			iol_hold <= 1'b0;
		end
		else begin
			if (ioctl_wr && !iol_full) begin
				iol_fifo[iol_wp[8:0]] <= {ioctl_addr, ioctl_dout, ioctl_be};
				iol_wp <= iol_wp + 1'b1;
			end
			if (iol_hold && wr_done)
				iol_hold <= 1'b0;
			if ((!iol_hold || (iol_hold && wr_done)) && !iol_empty) begin
				{iol_addr_r, iol_din_r, iol_be_r} <= iol_fifo[iol_rp[8:0]];
				iol_hold <= 1'b1;
				iol_rp <= iol_rp + 1'b1;
			end
		end
	assign ioctl_wait = iol_occ >= IOL_HWM[IOL_AW:0];
	reg [2:0] st;
	reg [24:0] ridx;
	reg [31:0] nonzero;
	reg [31:0] zero;
	reg settle;
	reg dl_seen;
	reg dl_q;
	always @(posedge clk)
		if (rst) begin
			st <= 3'd0;
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			ctl_addr <= 25'd0;
			ctl_din <= 16'd0;
			ctl_wtbt <= 2'b11;
			wr_done <= 1'b0;
			ridx <= 25'd0;
			nonzero <= 32'd0;
			zero <= 32'd0;
			settle <= 1'b0;
			dl_seen <= 1'b0;
			dl_q <= 1'b0;
		end
		else begin
			ctl_rd <= 1'b0;
			ctl_we <= 1'b0;
			wr_done <= 1'b0;
			dl_q <= ioctl_download;
			if (ioctl_download)
				dl_seen <= 1'b1;
			case (st)
				3'd0:
					if (ctl_ready)
						st <= 3'd1;
				3'd1:
					if (iol_hold && ctl_ready) begin
						ctl_addr <= {iol_addr_r[23:0], 1'b0};
						ctl_din <= iol_din_r;
						ctl_wtbt <= iol_be_r;
						ctl_we <= 1'b1;
						settle <= 1'b1;
						st <= 3'd2;
					end
					else if (((dl_seen && (dl_q == 1'b0)) && iol_empty) && !iol_hold) begin
						ridx <= 25'd0;
						nonzero <= 32'd0;
						zero <= 32'd0;
						st <= 3'd3;
					end
				3'd2:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready) begin
						wr_done <= 1'b1;
						st <= 3'd1;
					end
				3'd3:
					if (ctl_ready) begin
						ctl_addr <= {ROMW_BASE[23:0] + ridx[23:0], 1'b0};
						ctl_rd <= 1'b1;
						settle <= 1'b1;
						st <= 3'd4;
					end
				3'd4:
					if (settle)
						settle <= 1'b0;
					else if (ctl_ready) begin
						if (ctl_dout != 16'h0000)
							nonzero <= nonzero + 32'd1;
						else
							zero <= zero + 32'd1;
						if (ridx == (ROM_WORDS - 1))
							st <= (nonzero >= (ROM_WORDS >> 2) ? 3'd5 : 3'd6);
						else begin
							ridx <= ridx + 25'd1;
							st <= 3'd3;
						end
					end
				3'd5: st <= 3'd5;
				3'd6: st <= 3'd6;
				default: st <= 3'd0;
			endcase
		end
	assign pc_dbg = {2'd0, st, nonzero[24:0]};
	localparam signed [31:0] H_TOTAL = ((H_ACT + H_FP) + H_SYNC) + H_BP;
	localparam signed [31:0] V_TOTAL = ((V_ACT + V_FP) + V_SYNC) + V_BP;
	reg [11:0] hc;
	reg [11:0] vc;
	reg [23:0] frame;
	always @(posedge clk)
		if (rst) begin
			hc <= 0;
			vc <= 0;
			frame <= 0;
		end
		else if (ce_pix) begin
			if (hc == (H_TOTAL - 1)) begin
				hc <= 0;
				if (vc == (V_TOTAL - 1)) begin
					vc <= 0;
					frame <= frame + 24'd1;
				end
				else
					vc <= vc + 12'd1;
			end
			else
				hc <= hc + 12'd1;
		end
	wire s0_de = (hc < H_ACT) && (vc < V_ACT);
	wire s0_hb = hc >= H_ACT;
	wire s0_vb = vc >= V_ACT;
	wire s0_hs = (hc >= (H_ACT + H_FP)) && (hc < ((H_ACT + H_FP) + H_SYNC));
	wire s0_vs = (vc >= (V_ACT + V_FP)) && (vc < ((V_ACT + V_FP) + V_SYNC));
	reg [7:0] br;
	reg [7:0] bg;
	reg [7:0] bb;
	always @(*) begin
		if (_sv2v_0)
			;
		case (st)
			3'd0: begin
				br = 8'h00;
				bg = 8'h00;
				bb = 8'hc0;
			end
			3'd5: begin
				br = 8'h00;
				bg = 8'hc0;
				bb = 8'h00;
			end
			3'd6: begin
				br = 8'hc0;
				bg = 8'h00;
				bb = 8'h00;
			end
			default: begin
				br = 8'h80;
				bg = 8'h80;
				bb = 8'h00;
			end
		endcase
	end
	localparam signed [31:0] E = H_ACT / 8;
	reg [7:0] cbr;
	reg [7:0] cbg;
	reg [7:0] cbb;
	wire [2:0] bar = (hc < E ? 3'd0 : (hc < (2 * E) ? 3'd1 : (hc < (3 * E) ? 3'd2 : (hc < (4 * E) ? 3'd3 : (hc < (5 * E) ? 3'd4 : (hc < (6 * E) ? 3'd5 : (hc < (7 * E) ? 3'd6 : 3'd7)))))));
	always @(*) begin
		if (_sv2v_0)
			;
		case (bar)
			3'd0: {cbr, cbg, cbb} = 24'hffffff;
			3'd1: {cbr, cbg, cbb} = 24'hffff00;
			3'd2: {cbr, cbg, cbb} = 24'h00ffff;
			3'd3: {cbr, cbg, cbb} = 24'h00ff00;
			3'd4: {cbr, cbg, cbb} = 24'hff00ff;
			3'd5: {cbr, cbg, cbb} = 24'hff0000;
			3'd6: {cbr, cbg, cbb} = 24'h0000ff;
			default: {cbr, cbg, cbb} = 24'h000000;
		endcase
	end
	wire [5:0] zlog = (zero[31] ? 6'd32 : (zero[24] ? 6'd25 : (zero[20] ? 6'd21 : (zero[16] ? 6'd17 : (zero[14] ? 6'd15 : (zero[12] ? 6'd13 : (zero[10] ? 6'd11 : (zero[8] ? 6'd9 : (zero[4] ? 6'd5 : (zero[0] ? 6'd1 : 6'd0))))))))));
	wire [15:0] zbar = (H_ACT * zlog) >> 5;
	wire in_bars = vc < (V_ACT / 8);
	wire in_zbar = vc >= (V_ACT - (V_ACT / 8));
	wire live_col = hc == frame[8:0];
	always @(posedge clk)
		if (ce_pix) begin
			de <= s0_de;
			hsync <= s0_hs;
			vsync <= s0_vs;
			hblank <= s0_hb;
			vblank <= s0_vb;
			if (!s0_de) begin
				vid_r <= 0;
				vid_g <= 0;
				vid_b <= 0;
			end
			else if (in_bars) begin
				vid_r <= cbr;
				vid_g <= cbg;
				vid_b <= cbb;
			end
			else if (live_col) begin
				vid_r <= 8'hff;
				vid_g <= 8'hff;
				vid_b <= 8'hff;
			end
			else if (in_zbar) begin
				if ({4'd0, hc} < zbar) begin
					vid_r <= 8'hff;
					vid_g <= 8'h00;
					vid_b <= 8'h00;
				end
				else begin
					vid_r <= 8'h20;
					vid_g <= 8'h20;
					vid_b <= 8'h20;
				end
			end
			else begin
				vid_r <= br;
				vid_g <= bg;
				vid_b <= bb;
			end
		end
	initial _sv2v_0 = 0;
endmodule
`default_nettype wire
`default_nettype none
module smashtv_snd_rom (
	clk,
	addr,
	data,
	wrclk,
	we,
	waddr,
	wdata
);
	parameter HEX = "build/snd_u4.hex";
	input wire clk;
	input wire [15:0] addr;
	output reg [7:0] data;
	input wire wrclk;
	input wire we;
	input wire [15:0] waddr;
	input wire [7:0] wdata;
	(* ramstyle = "no_rw_check" *) reg [7:0] mem [0:65535];
	always @(posedge wrclk)
		if (we)
			mem[waddr] <= wdata;
	always @(posedge clk) data <= mem[addr];
endmodule
`default_nettype wire
`default_nettype none
`default_nettype wire
`default_nettype none
module narc_sound_bank (
	bank,
	cpu_addr,
	rom_offset,
	rom_sel,
	upper_sel
);
	input wire [3:0] bank;
	input wire [15:0] cpu_addr;
	output wire [19:0] rom_offset;
	output wire rom_sel;
	output wire upper_sel;
	wire in_banked = (cpu_addr >= 16'h4000) && (cpu_addr <= 16'hbfff);
	wire in_upper = cpu_addr >= 16'hc000;
	assign rom_sel = in_banked | in_upper;
	assign upper_sel = in_upper;
	wire [19:0] bank_off = (({19'd0, bank[0]} << 15) + ({19'd0, bank[3]} << 16)) + ({18'd0, bank[2:1]} << 17);
	wire [19:0] banked_offset = (20'h10000 + bank_off) + ({4'd0, cpu_addr} - 20'h04000);
	wire [19:0] upper_offset = {4'd0, cpu_addr} + (20'h8c000 - 20'h0c000);
	assign rom_offset = (in_upper ? upper_offset : banked_offset);
endmodule
`default_nettype wire
`default_nettype none
module narc_sound_latch (
	clk,
	rst,
	reset_in,
	ext_wr,
	ext_wdata,
	master_rd_cmd,
	latch_o,
	master_wr_cmd2,
	cmd2_wdata,
	slave_rd_cmd2,
	latch2_o,
	master_wr_tb,
	tb_wdata,
	master_sync_w,
	slave_sync_w,
	sync_clr_mask,
	sync_clr,
	talkback_rd,
	master_nmi,
	master_irq,
	slave_firq,
	sound_int_state,
	cpu_reset
);
	input wire clk;
	input wire rst;
	input wire reset_in;
	input wire ext_wr;
	input wire [15:0] ext_wdata;
	input wire master_rd_cmd;
	output wire [7:0] latch_o;
	input wire master_wr_cmd2;
	input wire [7:0] cmd2_wdata;
	input wire slave_rd_cmd2;
	output wire [7:0] latch2_o;
	input wire master_wr_tb;
	input wire [7:0] tb_wdata;
	input wire master_sync_w;
	input wire slave_sync_w;
	input wire [7:0] sync_clr_mask;
	input wire sync_clr;
	output wire [15:0] talkback_rd;
	output wire master_nmi;
	output wire master_irq;
	output wire slave_firq;
	output wire sound_int_state;
	output wire cpu_reset;
	reg [7:0] r_latch;
	reg [7:0] r_latch2;
	reg [7:0] r_talkback;
	reg [7:0] r_audio_sync;
	reg r_int_state;
	reg r_nmi;
	reg r_irq;
	reg r_firq;
	assign cpu_reset = reset_in;
	always @(posedge clk)
		if (rst) begin
			r_latch <= 8'h00;
			r_latch2 <= 8'h00;
			r_talkback <= 8'h00;
			r_audio_sync <= 8'h00;
			r_int_state <= 1'b0;
			r_nmi <= 1'b0;
			r_irq <= 1'b0;
			r_firq <= 1'b0;
		end
		else if (reset_in) begin
			r_int_state <= 1'b0;
			r_nmi <= 1'b0;
			r_irq <= 1'b0;
			r_firq <= 1'b0;
		end
		else begin
			if (ext_wr) begin
				r_latch <= ext_wdata[7:0];
				r_nmi <= ~ext_wdata[8];
				if (ext_wdata[9] == 1'b0) begin
					r_irq <= 1'b1;
					r_int_state <= 1'b1;
				end
			end
			if (master_rd_cmd) begin
				r_irq <= 1'b0;
				r_int_state <= 1'b0;
			end
			if (master_wr_cmd2) begin
				r_latch2 <= cmd2_wdata;
				r_firq <= 1'b1;
			end
			if (slave_rd_cmd2)
				r_firq <= 1'b0;
			if (master_wr_tb)
				r_talkback <= tb_wdata;
			r_audio_sync <= ((r_audio_sync & ~(sync_clr ? sync_clr_mask : 8'h00)) | (master_sync_w ? 8'h01 : 8'h00)) | (slave_sync_w ? 8'h02 : 8'h00);
		end
	assign latch_o = r_latch;
	assign latch2_o = r_latch2;
	assign talkback_rd = {r_audio_sync, r_talkback};
	assign master_nmi = r_nmi;
	assign master_irq = r_irq;
	assign slave_firq = r_firq;
	assign sound_int_state = r_int_state;
endmodule
`default_nettype wire
`default_nettype none
module narc_6809_clock_en (
	clk,
	rst,
	rom_ready,
	cen_e,
	cen_q,
	stall_clks
);
	parameter integer CLK_HZ = 96000000;
	parameter integer CPU_HZ = 2000000;
	input wire clk;
	input wire rst;
	input wire rom_ready;
	output reg cen_e;
	output reg cen_q;
	output reg [31:0] stall_clks;
	localparam integer PERIOD = CLK_HZ / CPU_HZ;
	localparam integer Q_PHASE = (PERIOD * 2) / 3;
	localparam integer PH_W = (PERIOD <= 2 ? 1 : $clog2(PERIOD));
	localparam [PH_W - 1:0] E_AT = PERIOD - 1;
	localparam [PH_W - 1:0] Q_AT = Q_PHASE - 1;
	reg [PH_W - 1:0] phase;
	wire e_due = phase == E_AT;
	wire q_due = phase == Q_AT;
	always @(posedge clk)
		if (rst) begin
			phase <= {PH_W {1'b0}};
			cen_e <= 1'b0;
			cen_q <= 1'b0;
			stall_clks <= 32'd0;
		end
		else begin
			cen_e <= 1'b0;
			cen_q <= 1'b0;
			if (e_due && !rom_ready)
				stall_clks <= stall_clks + 32'd1;
			else begin
				if (q_due)
					cen_q <= 1'b1;
				if (e_due) begin
					phase <= {PH_W {1'b0}};
					cen_e <= 1'b1;
				end
				else
					phase <= phase + {{PH_W - 1 {1'b0}}, 1'b1};
			end
		end
endmodule
`default_nettype wire
`default_nettype none
module narc_ym_clock_en (
	clk,
	rst,
	cen_fm,
	cen_fm_p1,
	sound_rst
);
	parameter integer CLK_HZ = 96000000;
	parameter integer YM_HZ = 3579545;
	parameter integer ACC_W = $clog2(CLK_HZ);
	input wire clk;
	input wire rst;
	output reg cen_fm;
	output reg cen_fm_p1;
	output reg sound_rst;
	localparam integer RESET_P1_PULSES = 32;
	localparam integer RESET_CNT_W = 6;
	reg [ACC_W - 1:0] phase;
	reg half_phase;
	reg rst_d;
	reg [RESET_CNT_W - 1:0] reset_p1_count;
	localparam integer EFFECTIVE_YM_HZ = YM_HZ;
	wire [ACC_W:0] phase_sum = {1'b0, phase} + EFFECTIVE_YM_HZ;
	initial begin
		phase = 1'sb0;
		half_phase = 1'b0;
		rst_d = 1'b1;
		cen_fm = 1'b0;
		cen_fm_p1 = 1'b0;
		sound_rst = 1'b1;
		reset_p1_count = 1'sb0;
	end
	always @(posedge clk) begin
		rst_d <= rst;
		cen_fm <= 1'b0;
		cen_fm_p1 <= 1'b0;
		if (rst && !rst_d) begin
			phase <= 1'sb0;
			half_phase <= 1'b0;
		end
		else if (phase_sum >= CLK_HZ) begin
			phase <= phase_sum - CLK_HZ;
			cen_fm <= 1'b1;
			cen_fm_p1 <= half_phase;
			half_phase <= ~half_phase;
		end
		else
			phase <= phase_sum[ACC_W - 1:0];
		if (rst) begin
			sound_rst <= 1'b1;
			reset_p1_count <= 1'sb0;
		end
		else begin
			if ((sound_rst && cen_fm_p1) && (reset_p1_count < RESET_P1_PULSES))
				reset_p1_count <= reset_p1_count + 1'b1;
			if (rst)
				sound_rst <= 1'b1;
			else if ((sound_rst && cen_fm_p1) && (reset_p1_count >= (RESET_P1_PULSES - 1)))
				sound_rst <= 1'b0;
		end
	end
endmodule
`default_nettype wire
`default_nettype none
module narc_audio_mix (
	clk,
	rst,
	ym_l,
	ym_r,
	dac1_u,
	dac2_u,
	cvsd_u,
	audio_l,
	audio_r
);
	input wire clk;
	input wire rst;
	input wire signed [15:0] ym_l;
	input wire signed [15:0] ym_r;
	input wire [7:0] dac1_u;
	input wire [7:0] dac2_u;
	input wire [15:0] cvsd_u;
	output reg signed [15:0] audio_l;
	output reg signed [15:0] audio_r;
	reg signed [24:0] cvsd_dc;
	wire signed [16:0] cvsd_x = $signed({1'b0, cvsd_u});
	always @(posedge clk)
		if (rst)
			cvsd_dc <= 25'sd0;
		else
			cvsd_dc <= cvsd_dc + (($signed({cvsd_x, 8'd0}) - cvsd_dc) >>> 18);
	wire signed [17:0] cvsd_ac = $signed({cvsd_x[16], cvsd_x}) - $signed(cvsd_dc[24:8]);
	wire signed [15:0] cvsd_s = (cvsd_ac > 18'sd32767 ? 16'sd32767 : (cvsd_ac < -18'sd32768 ? -16'sd32768 : cvsd_ac[15:0]));
	wire signed [16:0] dac1_s = ($signed({1'b0, dac1_u}) - 17'sd128) <<< 8;
	wire signed [16:0] dac2_s = ($signed({1'b0, dac2_u}) - 17'sd128) <<< 8;
	wire signed [16:0] ym_mono = $signed({ym_l[15], ym_l}) + $signed({ym_r[15], ym_r});
	reg signed [16:0] ym_mono_q;
	reg signed [16:0] dac1_s_q;
	reg signed [16:0] dac2_s_q;
	reg signed [15:0] cvsd_s_q;
	wire signed [31:0] ym_term_d = ($signed(ym_mono_q) * 32'sd26) >>> 8;
	wire signed [31:0] dac1_term_d = ($signed(dac1_s_q) * 32'sd64) >>> 8;
	wire signed [31:0] dac2_term_d = ($signed(dac2_s_q) * 32'sd64) >>> 8;
	wire signed [31:0] cvsd_term_d = ($signed(cvsd_s_q) * 32'sd154) >>> 8;
	reg signed [31:0] ym_term_q;
	reg signed [31:0] dac1_term_q;
	reg signed [31:0] dac2_term_q;
	reg signed [31:0] cvsd_term_q;
	reg signed [31:0] music_sum_q;
	reg signed [31:0] dac_sum_q;
	reg signed [31:0] mix_q;
	always @(posedge clk)
		if (rst) begin
			ym_mono_q <= 17'sd0;
			dac1_s_q <= 17'sd0;
			dac2_s_q <= 17'sd0;
			cvsd_s_q <= 16'sd0;
			ym_term_q <= 32'sd0;
			dac1_term_q <= 32'sd0;
			dac2_term_q <= 32'sd0;
			cvsd_term_q <= 32'sd0;
			music_sum_q <= 32'sd0;
			dac_sum_q <= 32'sd0;
			mix_q <= 32'sd0;
			audio_l <= 16'sd0;
			audio_r <= 16'sd0;
		end
		else begin
			ym_mono_q <= ym_mono;
			dac1_s_q <= dac1_s;
			dac2_s_q <= dac2_s;
			cvsd_s_q <= cvsd_s;
			ym_term_q <= ym_term_d;
			dac1_term_q <= dac1_term_d;
			dac2_term_q <= dac2_term_d;
			cvsd_term_q <= cvsd_term_d;
			music_sum_q <= ym_term_q + cvsd_term_q;
			dac_sum_q <= dac1_term_q + dac2_term_q;
			mix_q <= music_sum_q + dac_sum_q;
			audio_l <= (mix_q > 32'sd32767 ? 16'sd32767 : (mix_q < -32'sd32768 ? -16'sd32768 : mix_q[15:0]));
			audio_r <= (mix_q > 32'sd32767 ? 16'sd32767 : (mix_q < -32'sd32768 ? -16'sd32768 : mix_q[15:0]));
		end
endmodule
`default_nettype wire
`default_nettype none
module narc_sound_board (
	clk,
	rst_pon,
	cen_e,
	cen_q,
	cen_fm,
	cen_fm_p1,
	ext_wr,
	ext_wdata,
	reset_in,
	talkback_rd,
	sound_int_state,
	mst_rom_offset,
	mst_rom_read,
	mst_rom_data,
	slv_rom_offset,
	slv_rom_read,
	slv_rom_data,
	ym_left,
	ym_right,
	dac1_level,
	dac2_level,
	dac1_sample,
	dac2_sample,
	cvsd_sample
);
	parameter signed [31:0] SYNC_ONESHOT_CYCLES = 32'd6480000;
	input wire clk;
	input wire rst_pon;
	input wire cen_e;
	input wire cen_q;
	input wire cen_fm;
	input wire cen_fm_p1;
	input wire ext_wr;
	input wire [15:0] ext_wdata;
	input wire reset_in;
	output wire [15:0] talkback_rd;
	output wire sound_int_state;
	output wire [19:0] mst_rom_offset;
	output wire mst_rom_read;
	input wire [7:0] mst_rom_data;
	output wire [19:0] slv_rom_offset;
	output wire slv_rom_read;
	input wire [7:0] slv_rom_data;
	output wire signed [15:0] ym_left;
	output wire signed [15:0] ym_right;
	output wire [7:0] dac1_level;
	output wire [7:0] dac2_level;
	output wire signed [15:0] dac1_sample;
	output wire signed [15:0] dac2_sample;
	output wire [15:0] cvsd_sample;
	wire [7:0] latch_o;
	wire [7:0] latch2_o;
	wire master_nmi;
	wire master_irq;
	wire slave_firq;
	wire cpu_reset;
	wire m_rd_cmd;
	wire m_wr_cmd2;
	wire [7:0] m_dout;
	wire s_rd_cmd2;
	wire m_wr_tb;
	wire m_sync_w;
	wire s_sync_w;
	reg [31:0] os_m;
	reg [31:0] os_s;
	always @(posedge clk)
		if (rst_pon) begin
			os_m <= 32'd0;
			os_s <= 32'd0;
		end
		else begin
			if (m_sync_w)
				os_m <= SYNC_ONESHOT_CYCLES;
			else if (os_m != 0)
				os_m <= os_m - 32'd1;
			if (s_sync_w)
				os_s <= SYNC_ONESHOT_CYCLES;
			else if (os_s != 0)
				os_s <= os_s - 32'd1;
		end
	wire clr_m = os_m == 32'd1;
	wire clr_s = os_s == 32'd1;
	wire sync_clr = clr_m | clr_s;
	wire [7:0] sync_clr_mask = (clr_m ? 8'h01 : 8'h00) | (clr_s ? 8'h02 : 8'h00);
	narc_sound_latch u_latch(
		.clk(clk),
		.rst(rst_pon),
		.reset_in(reset_in),
		.ext_wr(ext_wr),
		.ext_wdata(ext_wdata),
		.master_rd_cmd(m_rd_cmd),
		.latch_o(latch_o),
		.master_wr_cmd2(m_wr_cmd2),
		.cmd2_wdata(m_dout),
		.slave_rd_cmd2(s_rd_cmd2),
		.latch2_o(latch2_o),
		.master_wr_tb(m_wr_tb),
		.tb_wdata(m_dout),
		.master_sync_w(m_sync_w),
		.slave_sync_w(s_sync_w),
		.sync_clr_mask(sync_clr_mask),
		.sync_clr(sync_clr),
		.talkback_rd(talkback_rd),
		.master_nmi(master_nmi),
		.master_irq(master_irq),
		.slave_firq(slave_firq),
		.sound_int_state(sound_int_state),
		.cpu_reset(cpu_reset)
	);
	wire [15:0] m_addr;
	wire m_wr;
	wire m_rd;
	wire [3:0] m_iosel = m_addr[13:10];
	reg [7:0] m_io_rdata;
	wire ym_hit = m_iosel == 4'd8;
	wire [7:0] ym_dout;
	wire ym_irq_n;
	(* preserve, dont_merge *) reg ym_rst_local = 1'b1;
	always @(posedge clk) ym_rst_local <= rst_pon;
	jt51 u_ym(
		.rst(ym_rst_local),
		.clk(clk),
		.cen(cen_fm),
		.cen_p1(cen_fm_p1),
		.cs_n(~ym_hit),
		.wr_n(~(m_wr & ym_hit)),
		.a0(m_addr[0]),
		.din(m_dout),
		.dout(ym_dout),
		.ct1(),
		.ct2(),
		.irq_n(ym_irq_n),
		.sample(),
		.left(),
		.right(),
		.xleft(ym_left),
		.xright(ym_right)
	);
	assign m_wr_tb = m_wr & (m_iosel == 4'd10);
	assign m_wr_cmd2 = m_wr & (m_iosel == 4'd11);
	wire dac1_wr = m_wr & (m_iosel == 4'd12);
	assign m_rd_cmd = m_rd & (m_iosel == 4'd13);
	assign m_sync_w = m_wr & (m_iosel == 4'd15);
	wire [7:0] ym_rd = ym_dout;
	wire master_firq_n = ym_irq_n;
	always @(*)
		case (m_iosel)
			4'd8: m_io_rdata = ym_rd;
			4'd13: m_io_rdata = latch_o;
			default: m_io_rdata = 8'h00;
		endcase
	narc_ad7224 u_dac1(
		.clk(clk),
		.rst(rst_pon),
		.wr(dac1_wr),
		.din(m_dout),
		.level(dac1_level),
		.sample(dac1_sample)
	);
	narc_snd_cpu #(
		.HIDDEN_RAM(1),
		.HIDDEN_LO(16'hcdff),
		.HIDDEN_HI(16'hce29)
	) u_master(
		.clk(clk),
		.cen_e(cen_e),
		.cen_q(cen_q),
		.cpu_rst(cpu_reset),
		.n_irq(~master_irq),
		.n_firq(master_firq_n),
		.n_nmi(~master_nmi),
		.rom_data(mst_rom_data),
		.rom_offset(mst_rom_offset),
		.rom_read(mst_rom_read),
		.io_rdata(m_io_rdata),
		.addr(m_addr),
		.dout(m_dout),
		.io_wr(m_wr),
		.io_rd(m_rd)
	);
	wire [15:0] s_addr;
	wire s_wr;
	wire s_rd;
	wire [3:0] s_iosel = s_addr[13:10];
	wire [7:0] s_dout;
	reg [7:0] s_io_rdata;
	wire cvsd_clk_set = s_wr & (s_iosel == 4'd8);
	wire cvsd_clk_clr = s_wr & (s_iosel == 4'd9);
	wire dac2_wr = s_wr & (s_iosel == 4'd12);
	assign s_rd_cmd2 = s_rd & (s_iosel == 4'd13);
	assign s_sync_w = s_wr & (s_iosel == 4'd15);
	always @(*)
		case (s_iosel)
			4'd13: s_io_rdata = latch2_o;
			default: s_io_rdata = 8'h00;
		endcase
	narc_ad7224 u_dac2(
		.clk(clk),
		.rst(rst_pon),
		.wr(dac2_wr),
		.din(s_dout),
		.level(dac2_level),
		.sample(dac2_sample)
	);
	reg r_cvsd_clk;
	reg r_cvsd_data;
	always @(posedge clk)
		if (rst_pon) begin
			r_cvsd_clk <= 1'b0;
			r_cvsd_data <= 1'b0;
		end
		else begin
			if (cvsd_clk_set)
				r_cvsd_clk <= 1'b1;
			if (cvsd_clk_clr) begin
				r_cvsd_clk <= 1'b0;
				r_cvsd_data <= s_dout[0];
			end
		end
	hc55564 u_cvsd(
		.clk(clk),
		.cen(r_cvsd_clk),
		.rst(rst_pon),
		.bit_in(r_cvsd_data),
		.sample_out(cvsd_sample)
	);
	narc_snd_cpu #(.HIDDEN_RAM(0)) u_slave(
		.clk(clk),
		.cen_e(cen_e),
		.cen_q(cen_q),
		.cpu_rst(cpu_reset),
		.n_irq(1'b1),
		.n_firq(~slave_firq),
		.n_nmi(1'b1),
		.rom_data(slv_rom_data),
		.rom_offset(slv_rom_offset),
		.rom_read(slv_rom_read),
		.io_rdata(s_io_rdata),
		.addr(s_addr),
		.dout(s_dout),
		.io_wr(s_wr),
		.io_rd(s_rd)
	);
endmodule
module narc_snd_cpu (
	clk,
	cen_e,
	cen_q,
	cpu_rst,
	n_irq,
	n_firq,
	n_nmi,
	rom_data,
	rom_offset,
	rom_read,
	io_rdata,
	addr,
	dout,
	io_wr,
	io_rd
);
	parameter [0:0] HIDDEN_RAM = 0;
	parameter [15:0] HIDDEN_LO = 16'hcdff;
	parameter [15:0] HIDDEN_HI = 16'hce29;
	input wire clk;
	input wire cen_e;
	input wire cen_q;
	input wire cpu_rst;
	input wire n_irq;
	input wire n_firq;
	input wire n_nmi;
	input wire [7:0] rom_data;
	output wire [19:0] rom_offset;
	output wire rom_read;
	input wire [7:0] io_rdata;
	output wire [15:0] addr;
	output wire [7:0] dout;
	output wire io_wr;
	output wire io_rd;
	wire rnw;
	wire avma;
	wire [7:0] di;
	mc6809is u_cpu(
		.CLK(clk),
		.fallE_en(cen_e),
		.fallQ_en(cen_q),
		.OP(di),
		.D(di),
		.DOut(dout),
		.ADDR(addr),
		.RnW(rnw),
		.BS(),
		.BA(),
		.nIRQ(n_irq),
		.nFIRQ(n_firq),
		.nNMI(n_nmi),
		.AVMA(avma),
		.BUSY(),
		.LIC(),
		.nHALT(1'b1),
		.nRESET(~cpu_rst),
		.nDMABREQ(1'b1),
		.RegData()
	);
	wire in_ram = addr[15:13] == 3'b000;
	wire in_io = addr[15:13] == 3'b001;
	wire in_rom = (addr[15] == 1'b1) || ((addr[15:14] == 2'b01) && addr[14]);
	wire in_romall = addr >= 16'h4000;
	wire in_hidden = (HIDDEN_RAM && (addr >= HIDDEN_LO)) && (addr <= HIDDEN_HI);
	wire rom_read_live = (rnw & in_romall) & ~in_hidden;
	wire wr_stb = cen_e & ~rnw;
	wire rd_stb = cen_e & rnw;
	assign io_wr = wr_stb & in_io;
	assign io_rd = rd_stb & in_io;
	reg [3:0] bank;
	wire bank_wr = io_wr & (addr[13:10] == 4'd14);
	always @(posedge clk)
		if (cpu_rst)
			bank <= 4'd0;
		else if (bank_wr)
			bank <= dout[3:0];
	reg [15:0] bus_addr_q;
	reg [3:0] bsel_q;
	reg rom_read_q;
	always @(posedge clk)
		if (cpu_rst) begin
			bus_addr_q <= 16'd0;
			bsel_q <= 4'd0;
			rom_read_q <= 1'b0;
		end
		else begin
			bus_addr_q <= addr;
			bsel_q <= bank;
			rom_read_q <= rom_read_live;
		end
	assign rom_read = rom_read_q;
	narc_sound_bank u_bank(
		.bank(bsel_q),
		.cpu_addr(bus_addr_q),
		.rom_offset(rom_offset),
		.rom_sel(),
		.upper_sel()
	);
	reg [7:0] ram [0:8191];
	reg [7:0] ram_q;
	always @(posedge clk) begin
		if (wr_stb & in_ram)
			ram[addr[12:0]] <= dout;
		ram_q <= ram[addr[12:0]];
	end
	localparam signed [31:0] HID_N = 43;
	reg [7:0] hid [0:42];
	wire [15:0] hid_idx = addr - HIDDEN_LO;
	always @(posedge clk)
		if ((HIDDEN_RAM && wr_stb) && in_hidden)
			hid[hid_idx[5:0]] <= dout;
	wire [7:0] hid_q = hid[hid_idx[5:0]];
	assign di = (~rnw ? dout : (in_ram ? ram_q : (in_hidden ? hid_q : (in_romall ? rom_data : io_rdata))));
endmodule
module narc_ad7224 (
	clk,
	rst,
	wr,
	din,
	level,
	sample
);
	input wire clk;
	input wire rst;
	input wire wr;
	input wire [7:0] din;
	output wire [7:0] level;
	output wire signed [15:0] sample;
	reg [7:0] r;
	always @(posedge clk)
		if (rst)
			r <= 8'h00;
		else if (wr)
			r <= din;
	assign level = r;
	assign sample = $signed({~r[7], r[6:0], 8'h00});
endmodule
`default_nettype wire
