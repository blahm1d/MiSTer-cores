NARC - v22 erase row
RBF SHA-256: 40d52e01e5ee955520125302d8938bee080630829534cb3e56f0161908c59fd5

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: narc-8730cec
For Wolf Unit use WOLF_MASTER=1,CRT_ADJUST=1,USE_DDR3_GFX=1,USE_DDR3_VRAM=1.
The compiled binary's validation status is recorded in the feed catalog.
