# Plain-Tcl unit test for narc_frontier_policy.tcl. No project or timing
# netlist is opened. Pass --mutant-blend to restore the former broad Blend
# exception; the normal assertions must then fail.

source [file join [file dirname [info script]] narc_frontier_policy.tcl]

if {[llength $argv] == 1 && [lindex $argv 0] eq "--mutant-blend"} {
  rename is_allowed_hq2x_residual is_allowed_hq2x_residual_production
  proc is_allowed_hq2x_residual {from_name to_name} {
    if {[string first "|Hq2x:" $from_name] < 0
        || [string first "|Hq2x:" $to_name] < 0} {
      return 0
    }
    return [expr {[string first "|Blend:blender|" $from_name] >= 0
                  && [string first "|Blend:blender|" $to_name] >= 0}]
  }
}

set errors 0

proc expect_false {label actual} {
  if {$actual} {
    puts stderr "FAIL $label: expected reject, got accept"
    incr ::errors
  }
}

proc expect_true {label actual} {
  if {!$actual} {
    puts stderr "FAIL $label: expected accept, got reject"
    incr ::errors
  }
}

set hq "emu|arcade_video|video_mixer|scandoubler:sd|Hq2x:Hq2x"
expect_false "Hq2x Blend df_rule-to-i30" \
  [is_allowed_hq2x_residual \
    "$hq|Blend:blender|df_rule\[0\]" "$hq|Blend:blender|i30\[7\]"]
expect_false "Hq2x pattern formation" \
  [is_allowed_hq2x_residual "$hq|Curr2\[0\]" "$hq|nextpatt\[0\]"]
expect_false "arbitrary Hq2x path" \
  [is_allowed_hq2x_residual "$hq|foo\[0\]" "$hq|bar\[0\]"]
expect_false "non-Hq2x path" \
  [is_allowed_hq2x_residual "emu|cpu|a\[0\]" "emu|cpu|b\[0\]"]

set ascal_from "emu|arcade_video|ascal:ascal|o_hacc\[17\]"
set ascal_div  "emu|arcade_video|ascal:ascal|o_div\[0\]"
set ascal_dir  "emu|arcade_video|ascal:ascal|o_dir\[0\]"
expect_true "ascal Slow -40C o_div" \
  [is_accepted_vendored_ascal_cold_corner $ascal_from $ascal_div "Slow 1100mV -40C"]
expect_true "ascal Slow 0C o_dir" \
  [is_accepted_vendored_ascal_cold_corner $ascal_from $ascal_dir "Slow 1100mV 0C"]
expect_false "ascal hot 85C" \
  [is_accepted_vendored_ascal_cold_corner $ascal_from $ascal_div "Slow 1100mV 85C"]
expect_false "ascal hot 100C" \
  [is_accepted_vendored_ascal_cold_corner $ascal_from $ascal_div "Slow 1100mV 100C"]
expect_false "ascal wrong launch endpoint" \
  [is_accepted_vendored_ascal_cold_corner \
    "emu|arcade_video|ascal:ascal|other\[0\]" $ascal_div "Slow 1100mV -40C"]
expect_false "ascal wrong latch endpoint" \
  [is_accepted_vendored_ascal_cold_corner \
    $ascal_from "emu|arcade_video|ascal:ascal|other\[0\]" "Slow 1100mV -40C"]
expect_false "ascal outside hierarchy" \
  [is_accepted_vendored_ascal_cold_corner \
    "emu|other|o_hacc\[0\]" "emu|other|o_div\[0\]" "Slow 1100mV -40C"]

if {$errors != 0} {
  puts stderr "RESULT: FAIL -- narc frontier policy errors=$errors"
  exit 1
}
puts "RESULT: PASS -- Hq2x negatives reject; ascal acceptance is endpoint- and corner-bounded"
