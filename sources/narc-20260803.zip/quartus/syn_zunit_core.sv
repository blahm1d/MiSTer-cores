// syn_zunit_core.sv — Phase-5 fit-risk harness (WORKER: hw_fit measurement).
// Measures the Z-UNIT datapath BRAM/M10K/DSP footprint: zunit_memsys
// (zunit_mem + zunit_dma) + zunit_video (8bpp palette M10K).
//
// The TMS34010 core is DELIBERATELY OMITTED: it is identical in both units
// (shared rtl/tms34010) so it cancels in the fit DELTA, and instantiating it in a
// closed core<->memsys loop let Quartus A&S constant-prune the CPU AND the memsys
// RAMs (harness artifact — first iteration reported only the video palette). Here
// the memsys CPU memory interface is exposed to top pins so the ram/pal/cmos read
// muxes reach an observable output and the RAMs are retained/inferred honestly.
//
// Resource-estimate harness only, NOT the emu. Under -DSYNTHESIS the memsys
// auto-defines USE_SDRAM_VRAM + USE_HW_RAM + ZM_EXT_RD (no USE_DDR3_VRAM).
`default_nettype none
module syn_zunit_core (
  input  logic        clk,
  input  logic        rst,
  // CPU-side memory interface (driven from pins so the memsys RAMs are observable)
  input  logic        mem_req,
  input  logic        mem_we,
  input  logic [31:0] mem_addr,
  input  logic  [5:0] mem_size,
  input  logic [31:0] mem_wdata,
  output logic [31:0] mem_rdata,
  output logic        mem_ack,
  input  logic [63:0] inputs,
  input  logic  [7:0] src_data,
  output logic        src_req,
  output logic [23:0] src_addr,
  input  logic        src_ack,
  output logic  [7:0] snd_select,
  output logic        snd_trig,
  output logic        snd_reset,
  output logic        int1,
  output logic        blit_busy,
  input  logic        scan_req,
  input  logic [17:0] scan_addr,
  output logic [15:0] scan_data,
  output logic        scan_ack,
  output logic [24:0] vsd_addr,
  output logic [15:0] vsd_din,
  output logic  [1:0] vsd_be,
  output logic        vsd_rd,
  output logic        vsd_wr,
  input  logic [15:0] vsd_dout,
  input  logic        vsd_ack,
  output logic        cpu_gfx_rd,
  output logic [23:0] cpu_gfx_raddr,
  input  logic [15:0] cpu_gfx_rdata,
  input  logic        cpu_gfx_rack,
  output logic        rgb_valid,
  output logic  [7:0] vid_r,
  output logic  [7:0] vid_g,
  output logic  [7:0] vid_b,
  input  logic        pix_valid,
  input  logic [15:0] vram_word
);
  logic        palv_we_a, palv_we_b;
  logic [12:0] palv_aa, palv_ba;
  logic [15:0] palv_awd, palv_bwd;
  logic        dbg_dma_we;
  logic  [3:0] dbg_dma_addr;
  logic [15:0] dbg_dma_wdata;

  zunit_memsys u_sys (
    .clk(clk), .rst(rst),
    .mem_req(mem_req), .mem_we(mem_we), .mem_addr(mem_addr), .mem_size(mem_size),
    .mem_wdata(mem_wdata), .mem_rdata(mem_rdata), .mem_ack(mem_ack),
    .src_req(src_req), .src_addr(src_addr), .src_data(src_data), .src_ack(src_ack),
    .inputs(inputs), .int1(int1),
    .snd_select(snd_select), .snd_trig(snd_trig), .snd_reset(snd_reset),
    .erase_start(1'b0), .erase_row0(9'd0), .erase_lines(10'd0), .erase_busy(),
    .blit_busy(blit_busy),
    .dbg_dma_we(dbg_dma_we), .dbg_dma_addr(dbg_dma_addr), .dbg_dma_wdata(dbg_dma_wdata),
    .cpu_gfx_rd(cpu_gfx_rd), .cpu_gfx_raddr(cpu_gfx_raddr),
    .cpu_gfx_rdata(cpu_gfx_rdata), .cpu_gfx_rack(cpu_gfx_rack),
    .scan_req(scan_req), .scan_addr(scan_addr), .scan_data(scan_data), .scan_ack(scan_ack),
    .vsd_addr(vsd_addr), .vsd_din(vsd_din), .vsd_be(vsd_be), .vsd_rd(vsd_rd), .vsd_wr(vsd_wr),
    .vsd_dout(vsd_dout), .vsd_ack(vsd_ack),
    .palv_we_a(palv_we_a), .palv_aa(palv_aa), .palv_awd(palv_awd),
    .palv_we_b(palv_we_b), .palv_ba(palv_ba), .palv_bwd(palv_bwd));

  zunit_video u_vid (
    .clk(clk),
    .pal_we(palv_we_a), .pal_waddr(palv_aa), .pal_wdata(palv_awd),
    .pix_valid(pix_valid), .vram_word(vram_word),
    .rgb_valid(rgb_valid), .r(vid_r), .g(vid_g), .b(vid_b));
endmodule
`default_nettype wire
