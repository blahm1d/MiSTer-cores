# Read-only full-path report for the three non-Hq2x cones exposed by the
# fail-closed v7c frontier audit. This is diagnostic evidence, not a constraint.
project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist

set aq_regs [get_registers {
  *zunit_top:zunit_top|zunit_memsys:u_sys|zunit_mem:u_mem|a_q*
}]
set hwin_taps [get_registers {
  *zunit_top:zunit_top|zunit_memsys:u_sys|zunit_mem:u_mem|hwin_q*
  *zunit_top:zunit_top|zunit_memsys:u_sys|zunit_mem:u_mem|palv_we_a*
}]
set dsrc_sources [get_registers {
  *zunit_top:zunit_top|zunit_memsys:u_sys|zunit_dma:u_dma|px*
  *stv_vram_ddr_top:u_vram_sdram|vram_sdram_top:u_acc|er_row*
}]
set dsrc_taps [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|dsrcwt_data*
}]
set shadow_select [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|a_start
  *stv_vram_ddr_top:u_vram_sdram|d_wr
  *stv_vram_ddr_top:u_vram_sdram|d_is_burst
}]
set shadow_lookup [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|shw_v_q
}]

puts "===== ADDRESS GEOMETRY TO RAM/PALETTE PIPE ====="
report_timing -setup -from $aq_regs -to $hwin_taps -npaths 1 -detail full_path -stdout
puts "===== DMA/AUTOERASE TO SOURCE-CACHE WRITE-THROUGH ====="
report_timing -setup -from $dsrc_sources -to $dsrc_taps -npaths 2 -detail full_path -stdout
puts "===== SHADOW LOOKUP SELECT ====="
report_timing -setup -from $shadow_select -to $shadow_lookup -npaths 1 -detail full_path -stdout

project_close
