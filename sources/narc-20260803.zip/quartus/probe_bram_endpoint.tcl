# probe_bram_endpoint.tcl -- one-off MECHANISM probe, not a gate.
#
# QUESTION (raised by the Wolf-unit session, and correctly refused as folklore):
# is an M10K data-input endpoint materially harder to close than an ordinary
# fabric flop on this device, and is the failing cone ROUTING-dominated or
# CELL-dominated?
#   - routing-dominated => the mux is being dragged to a PINNED BRAM location,
#     so a pipeline stage helps because it decouples placement.
#   - cell-dominated    => the stage just moves the problem, i.e. a repeat of the
#     v7k failure where registering a term moved the arithmetic instead of
#     removing it.
# This runs STA against the EXISTING fitted netlist. No fit is performed.
project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist -model slow -temperature 100 -voltage 1100
read_sdc
update_timing_netlist

puts "=========== A: worst paths ENDING ON THE M10K DATA INPUT ==========="
report_timing -setup -npaths 2 -detail full_path -stdout \
  -to [get_pins -compatibility_mode *rc_rtl_0*porta_datain*]

puts "=========== B: worst paths ENDING ON ORDINARY FABRIC FLOPS ==========="
puts "=== (same fit, same corner, same clock -- the control comparison) ==="
report_timing -setup -npaths 2 -detail full_path -stdout \
  -to [get_registers *stv_vram_ddr_top*rb_data*]

puts "=========== C: global worst, for scale ==========="
report_timing -setup -npaths 1 -detail full_path -stdout

project_close
