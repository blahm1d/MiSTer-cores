#!/usr/bin/env bash
# build_sv2v.sh — Phase 6: down-convert all SystemVerilog to Quartus-17-friendly
# plain Verilog via sv2v, then Quartus synthesizes the .v output.
#
# WHY: Quartus Prime 17.0 Lite (the MiSTer-pinned version for Cyclone V) has a weak
# SystemVerilog front-end — it rejects size-casts `N'(...)`, header package-imports,
# and other constructs the vendored birdybro TMS34010 core + the Y-unit wrapper use
# (Questa/Icarus accept them). sv2v (github.com/zachjs/sv2v) resolves packages,
# params, and casts into Verilog-2005 that Quartus swallows cleanly — so the
# vendored core stays PRISTINE and we don't hand-patch casts. `-DSYNTHESIS` reuses
# the `ifndef SYNTHESIS` guard so the sim-only $readmemh/array-init loops are skipped.
#
# Usage:  SV2V=/path/to/sv2v.exe ./build_sv2v.sh   (default sv2v in /c/tools/sv2v)
set -e
# A non-login Git Bash launched from PowerShell inherits a Windows-first PATH.
# Keep the production generator independently runnable, not only via build_hw.
export PATH="/usr/local/bin:/usr/bin:/bin:$PATH"
SV2V="${SV2V:-/c/tools/sv2v/sv2v-Windows/sv2v.exe}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/build_syn/smashtv_core.v"
mkdir -p "$ROOT/build_syn"

# SV set in dependency order: packages FIRST, then core, wrapper, sound-side SV.
SV=( "$ROOT/rtl/pkg/yunit_pkg.sv" "$ROOT/rtl/zunit/zunit_pkg.sv" "$ROOT/rtl/tms34010/rtl/tms34010_pkg.sv" )
while IFS= read -r f; do SV+=("$f"); done \
  < <(find "$ROOT/rtl/tms34010/rtl" -name '*.sv' ! -name 'tms34010_pkg.sv' | sort)
SV+=( "$ROOT/rtl/zunit/narc_fb_beat_fifo.sv" \
      "$ROOT/rtl/yunit/yunit_mem.sv" "$ROOT/rtl/yunit/yunit_dma.sv" \
      "$ROOT/rtl/yunit/vram_sdram.sv" "$ROOT/rtl/yunit/vram_sdram_top.sv" \
      "$ROOT/rtl/yunit/vram_sdram_scanout.sv" \
      "$ROOT/rtl/sdram/stv_vram_ddr_agent.sv" "$ROOT/rtl/sdram/stv_vram_ddr_top.sv" \
      "$ROOT/rtl/yunit/yunit_memsys.sv" \
      "$ROOT/rtl/yunit/yunit_video.sv" "$ROOT/rtl/yunit/yunit_scanline.sv" \
      "$ROOT/rtl/yunit/yunit_video_top.sv" "$ROOT/rtl/yunit/yunit_palram.sv" \
      "$ROOT/rtl/sdram/yunit_sdram_arb.sv" "$ROOT/rtl/sdram/sdram_stock.sv" \
      "$ROOT/rtl/sdram/sdram_stock_shipped.sv" "$ROOT/rtl/sdram/yunit_sdram_adapter.sv" \
      "$ROOT/rtl/sdram/yunit_src_cache.sv" \
      "$ROOT/rtl/yunit/yunit_gfx_unpack.sv" \
      "$ROOT/rtl/yunit/yunit_mem_cdc.sv" "$ROOT/rtl/yunit/yunit_top.sv" \
      "$ROOT/rtl/zunit/zunit_download.sv" "$ROOT/rtl/zunit/zunit_iol_audit.sv" \
      "$ROOT/rtl/zunit/zunit_boot_readback_audit.sv" \
      "$ROOT/rtl/zunit/zunit_rom_chksum_audit.sv" \
      "$ROOT/rtl/zunit/zunit_snd_rom.sv" \
      "$ROOT/rtl/zunit/zunit_mem.sv" "$ROOT/rtl/zunit/zunit_dma.sv" \
      "$ROOT/rtl/zunit/zunit_memsys.sv" \
      "$ROOT/rtl/zunit/narc_talkback_merge.sv" \
      "$ROOT/rtl/zunit/narc_pal_wr_queue.sv" \
      "$ROOT/rtl/zunit/zunit_video.sv" "$ROOT/rtl/zunit/zunit_video_top.sv" "$ROOT/rtl/zunit/zunit_top.sv" \
      "$ROOT/rtl/diag/smashtv_diag_top.sv" "$ROOT/rtl/diag/smashtv_diag2_overlay.sv" \
      "$ROOT/rtl/diag/smashtv_diag_rom.sv" \
      "$ROOT/rtl/sound/smashtv_snd_rom.sv" )
# NET-NEW dual-6809 NARC sound board (SV closure only; pkg BEFORE the modules).
# jt51 (Verilog), mc6809is (Verilog) and hc55564 (VHDL) are NOT sv2v'd — they are
# added to the Quartus project directly (fit_zunit.qsf / files.qip), so sv2v leaves
# their instantiations as black-box passthroughs (same flow as the donor CVSD board).
SV+=( "$ROOT/rtl/sound/narc_sound_pkg.sv" \
      "$ROOT/rtl/sound/narc_sound_bank.sv" \
      "$ROOT/rtl/sound/narc_sound_latch.sv" \
      "$ROOT/rtl/sound/narc_6809_clock_en.sv" \
      "$ROOT/rtl/sound/narc_ym_clock_en.sv" \
      "$ROOT/rtl/sound/narc_audio_mix.sv" \
      "$ROOT/rtl/sound/narc_sound_board.sv" )
# emu.sv (Arcade-SmashTV.sv) is Quartus-native SV (NOT sv2v'd): it instantiates
# zunit_top from this blob + sys/ modules by name; listed directly in files.qip.

echo "sv2v: ${#SV[@]} SV files -> $OUT ${SV2V_EXTRA:+(extra: $SV2V_EXTRA)}"
"$SV2V" -DSYNTHESIS ${SV2V_EXTRA:-} "${SV[@]}" > "$OUT"
echo "  $(wc -l < "$OUT") lines; size-casts remaining: $(grep -cE "[0-9A-Za-z_]+'\(" "$OUT")"

# Production-top route gate: SYNTHESIS always enables ZT_SDRAM_CHASSIS for
# program/GFX/sound. A former conditional-priority bug therefore selected the
# old SDRAM scan cache even with USE_DDR3_VRAM, while tying the real DDR3
# subsystem's scan request to zero. Direct module-level DDR3 scan tests could
# not see that top-level disconnect. Inspect the exact sv2v product that
# Quartus will consume and refuse a DDR3 build unless (a) live video reaches
# DDR3 and (b) the freed SDRAM burst port serves NARC's blitter source cache.
case " ${SV2V_EXTRA:-} " in
  *" -DUSE_DDR3_VRAM "*)
    grep -Fq "assign mem_scan_req = video_scan_req;" "$OUT"
    grep -Fq "assign mem_scan_addr = video_scan_addr;" "$OUT"
    grep -Fq "assign video_scan_data = mem_scan_data;" "$OUT"
    grep -Fq "assign video_scan_ack = mem_scan_ack;" "$OUT"
    grep -Fq "u_narc_src_cache" "$OUT"
    grep -Fq ".src_rd(1'b0)" "$OUT"
    grep -Fq ".GFX_BYTES(zunit_pkg_SDRAM_GFX_WORDS << 1)" "$OUT"
    grep -Fq "module narc_ym_clock_en" "$OUT"
    grep -Fq "localparam integer EFFECTIVE_YM_HZ = YM_HZ;" "$OUT"
    grep -Fq ".YM_HZ(zunit_pkg_SND_YM2151_HZ)" "$OUT"
    grep -Fq "localparam integer RESET_P1_PULSES = 32;" "$OUT"
    grep -Fq ".sound_rst(snd_board_rst)" "$OUT"
    grep -Fq "ym_rst_local <= rst_pon;" "$OUT"
    grep -Fq ".rst(ym_rst_local)" "$OUT"
    # NARC-only DDR and DMA controls proven by the physical high-score replay.
    # The shared stv_vram_ddr_top default must remain OFF; only zunit_mem opts in.
    # P0046 POST-DRAIN SETTLE -- the cabinet-confirmed sound fix. core_rst must hold the core
    # until a read has COMPLETED through the memory path after the download drain, not merely
    # until the FIFO is empty. Production releasing early is what made the sound ROM read back
    # FFFF on the cabinet (v13) while the byte-identical image with the extra hold played sound
    # (v8b). Config-independent on purpose: every cut must carry the term, and the PRODRESET arm
    # below additionally pins its own settle SOURCE. Without this the production path had no
    # guard at all on the one change that fixed sound.
    # Every cut must hold release until a READ HAS COMPLETED through the memory path after the
    # drain -- but each does it by a different mechanism, so pin per cut rather than pinning one
    # literal everywhere (which fails plain DIAG_BOOT, as measured):
    #   production  -> boot_settle_busy, fed by u_boot_settle (bs_valid)
    #   PRODRESET   -> boot_settle_busy, fed by the sound readback (dbg_rb_valid)
    #   DIAG_BOOT   -> ~dbg_rb_valid directly; it already held this way and is what proved the
    #                  behaviour on the cabinet in v8b
    case " ${SV2V_EXTRA:-} " in
      *" -DDIAG_SOUND_PRODRESET "*) grep -Fq "| boot_settle_busy;" "$OUT" ;;
      *" -DDIAG_BOOT "*)            grep -Fq "| ~dbg_rb_valid;"    "$OUT" ;;
      *)                            grep -Fq "| boot_settle_busy;" "$OUT" ;;
    esac
    grep -Fq "parameter [0:0] D_SHADOW_RMW_BYPASS = 1'b0;" "$OUT"
    grep -Fq ".D_SHADOW_RMW_BYPASS(1'b1)" "$OUT"
    grep -Fq "assign d_shadow_bypass_en = D_SHADOW_RMW_BYPASS;" "$OUT"
    # BEAM-LOCKED ERASE ROW RANGE.  The C erase engine's goal range used to be the donor
    # Y-unit's 256 displayed rows, hard-coded as a bit-8 test.  NARC's raster is 512x400, so
    # the bottom 144 rows were never autoerased on the cabinet.  Pin all four properties:
    #   1. the SHARED default stays at the donor's 256 (no donor/sibling behavior change)
    #   2. exactly ONE instantiation opts in, and it opts in to the RASTER constant --
    #      not a second hard-coded literal that could drift away from the video geometry
    #   3. the range is a magnitude compare against ER_LAST, not the old bit-8 test
    #   4. the sim-only MUT_BEAMERASE_DONOR_ROWS mutant has NOT leaked into the build
    #      (it would rewrite ER_ROWS to a literal 256 and silently restore the defect)
    grep -Fq "parameter signed [31:0] ERASE_ROWS = 256;" "$OUT"
    test "$(grep -Fc ".ERASE_ROWS(zunit_pkg_SCR_VIS_H)" "$OUT")" -eq 1
    test "$(grep -Fc ".ERASE_ROWS(" "$OUT")" -eq 1
    if grep -Fq "localparam signed [31:0] ER_ROWS = 256;" "$OUT"; then
      echo "ERROR: the sim-only beam-erase donor-cap MUTANT leaked into the production blob" >&2
      exit 1
    fi
    grep -Fq "localparam signed [31:0] ER_ROWS = ERASE_ROWS;" "$OUT"
    grep -Fq "localparam [8:0] ER_LAST = ER_ROWS - 1;" "$OUT"
    # P0040: the erase window is BASE-RELATIVE and VISIBLE-ONLY. This guard used to
    # pin the pre-P0040 absolute-anchored form; that form is the cabinet defect that
    # erased the HUD during vblank, so pinning it would now pin the bug. Pin the new
    # contract instead -- all three properties, so a partial revert cannot slip past:
    #   * !er_blank        -> never erase during blanking (midyunit_v.cpp:554 is
    #                         reachable only from scanline_update)
    #   * trig_rel vs base -> the window follows the display base, incl. the -1 case
    #   * trig_nr < 510    -> the gospel row bound (midyunit_v.cpp:538)
    grep -Fq "wire goal_accept = (((row_changed && !trig_wrap) && !er_blank) && ((trig_rel <= ER_LAST) || (trig_rel == 9'h1ff))) && (trig_nr < 9'd510);" "$OUT"
    # P0040b: the base is REGISTERED locally (er_base_q) before the compare -- the
    # long cross-hierarchy disp_base route terminates at a flop, not at logic.
    # Pin the registered form; the unregistered one cost two fits to slow/100C.
    grep -Fq "wire [8:0] trig_rel = trig_nr - er_base_q;" "$OUT"
    grep -Fq "er_base_q <= er_base;" "$OUT"
    # P0045: a real DIRQ2 handler writes AUTOERAS after the current scanline's
    # prefetch edge. Replaying the one retained goal on enable rise closes the
    # exact boundary row that retained fresh missile pixels on the v11 cabinet.
    grep -Fq "reg erase_en_q;" "$OUT"
    grep -Fq "erase_en_q <= erase_en;" "$OUT"
    grep -Fq "if ((erase_en && !erase_en_q) && er_goal_v)" "$OUT"
    if grep -Fq "if ((row_changed && !trig_wrap) && (trig_nr <= ER_LAST)) begin" "$OUT"; then
      echo "ERROR: the pre-P0040 ABSOLUTE-anchored erase window is back -- this is the" >&2
      echo "       defect that erased the NARC HUD during vblank (see P0040)." >&2
      exit 1
    fi
    if grep -Fq "!trig_nr[8]" "$OUT"; then
      echo "ERROR: the C erase goal latch still uses the donor's hard-coded 256-row bit-8 test" >&2
      exit 1
    fi
    case " ${SV2V_EXTRA:-} " in
      *" -DDIAG_SOUND_PRODRESET "*)
        # The cabinet sound image must retain the production reset expression.
        # Its two-read sound-vector audit is read-only and deliberately does NOT
        # participate in core_rst; it must be present, while the full sweep stays out.
        #
        # RE-PINNED 2026-08-03 for P0046. The expression gained `| boot_settle_busy` -- the
        # post-drain settle that holds the core until a read has COMPLETED through the memory
        # path, which is the cabinet-confirmed sound fix. Production and PRODRESET were changed
        # TOGETHER and both now emit this identical string (verified by diffing the two sv2v
        # products before re-pinning), so the property this guard exists for -- PRODRESET
        # mirrors production -- is preserved, not weakened. Only the literal moved.
        #
        # This guard did its job: it refused the v17 slot at prebuild rather than after a fit.
        grep -Fq "wire core_rst = (((rst | ~sdram_ready) | ioctl_download) | dl_drain_busy) | boot_settle_busy;" "$OUT"
        # And pin the settle itself, so a future edit cannot quietly drop the term while
        # leaving the rest of the expression intact. NOTE the PRODRESET form differs from
        # production's: this cut already has a post-drain readback (u_snd_rb_audit) and reuses
        # its valid, where production instantiates u_boot_settle and uses bs_valid. Same
        # property -- release waits for a COMPLETED read -- different source. Pinning
        # production's literal here was my first attempt and this guard correctly refused it.
        grep -Fq "assign boot_settle_busy = ~(dbg_rb_valid | boot_settle_to);" "$OUT"
        grep -Fq "u_snd_rb_audit(" "$OUT"
        grep -Fq ".VEC_LO_ADDR(SND_MST_VEC_WORD)" "$OUT"
        grep -Fq ".VEC_HI_ADDR(SND_MST_VEC_WORD)" "$OUT"
        grep -Fq "wire audit_iol_rd = snd_rb_iol_rd;" "$OUT"
        grep -Fq "snd_rb_raw_data[15:0] == dbg_snd_land_data" "$OUT"
        grep -Fq "snd_rb_raw_data[31:16] == dbg_snd_land_data" "$OUT"
        grep -Fq "snd_rb_raw_data[31:16] == snd_rb_raw_data[15:0]" "$OUT"
        grep -Fq "dbg_snd_req_count" "$OUT"
        grep -Fq "dbg_snd_ack_count" "$OUT"
        grep -Fq "dbg_snd_wd_rearms" "$OUT"
        grep -Fq "dbg_snd_cmd_count" "$OUT"
        grep -Fq "dbg_snd_audio_changes" "$OUT"
        if grep -Fq "u_snd_sweep(" "$OUT"; then
          echo "ERROR: sound-vector diagnostic unexpectedly includes the full sweep" >&2
          exit 1
        fi
        ;;
    esac
    # The raw-pixel FIFO is a NARC-only throughput repair.  Its default must
    # remain off for every donor/sibling use, and exactly one production
    # instantiation (zunit_mem) may opt in.  Each C transaction fences new
    # ingress while draining older pixels so continuous DMA cannot starve
    # raster autoerase.
    grep -Fq "parameter [0:0] D_WRITE_FIFO = 1'b0;" "$OUT"
    # Production must opt in exactly once. Commit 57f9ba7's v7p FIFO-off
    # measurement was invalid: its high-score bench still hard-coded DWF=1.
    # The parameterised, assembly-faithful per-blit gate proves DWF=0 misses
    # every 4*w*h process budget, while DWF=1 passes all 15 blits.
    test "$(grep -Fc ".D_WRITE_FIFO(1'b1)" "$OUT")" -eq 1
    grep -Fq "wire fbq_c_park = D_WRITE_FIFO && c_start;" "$OUT"
    # v7j T1: fb_ack is no longer driven from a combinational fbq_ingress_ready.
    # That wire dragged fbq_wptr/fbq_rptr/fbq_rptr_q and fbq_head across the module
    # boundary into zunit_dma's col_i/tx/o_ptr incrementers (~370 failing paths in the
    # v7h frontier). It is replaced by a small ingress SKID with a REGISTERED ready.
    # Pin the three properties that matter, so this stays a real check rather than
    # being dropped because the old spelling vanished:
    #  (a) the blitter's ready is the REGISTERED skid ready, not a live FIFO predicate;
    #  (b) the FIFO's accept semantics are BYTE-FOR-BYTE unchanged -- fbq_room must
    #      still be the full-turnover `!fbq_full || fbq_pop`. Registering THAT instead
    #      would cap occupancy one short of full-pop-push and silently retire the
    #      "max=64/64 full-pop-push>=1" coverage the pipeline gate asserts;
    #  (c) the skid actually sits in front of the FIFO (push gated on fb_we && fb_ack).
    grep -Fq "skd_ingress_ready = skd_room_q && (D_BEAT_FIFO ? !fbq_b_park : (!a_claim && !fbq_b_park) && !fbq_c_park);" "$OUT"
    grep -Fq "wire fbq_room = !fbq_full || fbq_pop;" "$OUT"
    grep -Fq "assign skd_push = (D_WRITE_FIFO && pipe_fb_we) && skd_ingress_ready;" "$OUT"
    grep -Fq "wire fb_fill_park = (D_WRITE_FIFO ? fb_fill_park_fifo : b_fill_lock);" "$OUT"
    # v7u frontier repair: the fully resolved BSNOOP refill beat must cross a
    # register before the row-cache BRAM write-data input. Keep the cache
    # unpublished through the final commit and reject any production product
    # that restores the measured rb_base -> merge -> rc[] direct cone.
    grep -Fq "reg [63:0] bfill_pipe_data;" "$OUT"
    grep -Fq "bfill_pipe_data <= bfill_merged;" "$OUT"
    grep -Fq "rc[bfill_pipe_col] <= bfill_pipe_data;" "$OUT"
    grep -Fq "bts <= B_COMMIT;" "$OUT"
    grep -Fq "if (!bfill_pipe_v) begin" "$OUT"
    # The B refill snoop must consume its preserved local mirror of rb_base.
    # The live rb_base register is physically rooted in the D combiner; using
    # it here recreated the measured cross-block setup failure.  Require both
    # mirror update sites and reject any return of the direct subtraction.
    grep -Fq "(* preserve *) reg [15:0] bsn_rb_base_q;" "$OUT"
    # RE-PINNED for P0049 (v21 timing). The PROPERTY this guard protects -- the B refill snoop
    # consumes its PRESERVED LOCAL MIRROR of rb_base, never the live register rooted in the D
    # combiner -- is UNCHANGED: bsn_rb_base_q is still the operand. What moved is the OTHER
    # operand: the beat tag now comes from bfill_bt_rb_q, a dedicated duplicate of bfill_bt_q
    # loaded from the same sources under the same conditions with zero skew. That is the SAME
    # repair pattern this guard exists to enforce, applied to the second operand, and it is
    # policed at run time by a $fatal that fires if the duplicate ever diverges.
    grep -Fq "wire [15:0] bsn_rboff = bfill_bt_rb - bsn_rb_base_q;" "$OUT"
    # Both mirrors must EXIST and be loaded, or the split silently collapses back to one flop.
    grep -Fq "wire [15:0] bfill_bt_rb = bfill_bt_rb_q;" "$OUT"
    test "$(grep -Fc "bsn_rb_base_q <= wc_beat;" "$OUT")" -eq 1
    test "$(grep -Fc "bsn_rb_base_q <= df_beat;" "$OUT")" -eq 1
    if grep -Fq "wire [15:0] bsn_rboff = bfill_bt - rb_base;" "$OUT"; then
      echo "ERROR: the direct rb_base-to-BSNOOP timing path remains" >&2
      exit 1
    fi
    if grep -Fq "rc[fillbeat[6:0]] <= bfill_merged;" "$OUT"; then
      echo "ERROR: the v7u direct BSNOOP merge-to-row-cache timing cone remains" >&2
      exit 1
    fi
    # v7j T1: an A claim waits for the skid/raw FIFO. The generic owner still
    # carries the retired compact-journal branch for donor experiments, but
    # NARC production must hard-select it OFF after the v7y cabinet reject.
    grep -Fq "wire d_ingress_park = (D_WRITE_FIFO ? a_claim && all_fb_drained : a_claim);" "$OUT"
    grep -Fq "wire fbq_drained = fbq_empty && skd_empty;" "$OUT"
    grep -Fq "d_fb_ack = (D_WRITE_FIFO ? accept : d_fb_ack_q);" "$OUT"
    grep -Fq "if (D_WRITE_FIFO) begin : g_fbq_busy" "$OUT"
    grep -Fq "else begin : g_legacy_busy" "$OUT"
    grep -Fq "assign d_busy = ((dst != D_IDLE) || (wc_mask != 4'd0)) || (rb_cnt != 4'd0);" "$OUT"
    # v7y RETIRED: the compact framebuffer journal passed final-memory tests
    # while acknowledging pixels not yet visible to scanout. The cabinet then
    # showed a malformed fourth entry, crash, vertical smear, and silence.
    # Keep the shared default and generic branch available, but require the one
    # NARC production instantiation to select OFF and forbid any opt-in.
    grep -Fq "module narc_fb_beat_fifo (" "$OUT"
    grep -Fq "parameter [0:0] D_BEAT_FIFO = 1'b0;" "$OUT"
    test "$(grep -Fc ".D_BEAT_FIFO(1'b1)" "$OUT")" -eq 0
    test "$(grep -Fc ".D_BEAT_FIFO(1'b0)" "$OUT")" -eq 1
    grep -Fq "reg [83:0] qmem [0:DEPTH - 1];" "$OUT"
    grep -Fq "wire in_take = (in_we && in_allow) && ((!acc_valid || in_same) || !q_full);" "$OUT"
    grep -Fq "reg acc_flush_pending;" "$OUT"
    grep -Fq "wire beat_in_allow = (!a_claim && !srt_claim) && !fbq_c_park;" "$OUT"
    grep -Fq "wire all_fb_drained = fbq_drained && !beat_pending;" "$OUT"
    grep -Fq "else if ((a_start && !d_busy) && !beat_pending) begin" "$OUT"
    grep -Fq "else if ((c_start && !srt_claim) && (!D_WRITE_FIFO || (!d_busy && !beat_pending))) begin" "$OUT"
    # v7z candidate: NARC uses one external raw SRT command per TMS34010
    # to/from-shift-register instruction. The DDR owner copies all 1024 raw
    # uint16 entries (pixel + palette byte) as sixteen 16-beat bursts. Donor
    # cores retain the local serial implementation through EXTERNAL_SRT=0.
    grep -Fq "parameter [0:0] EXTERNAL_SRT = 1'b0;" "$OUT"
    test "$(grep -Fc ".EXTERNAL_SRT(1'b1)" "$OUT")" -eq 1
    grep -Fq "output reg mem_srt;" "$OUT"
    grep -Fq "reg [63:0] srt_mem [0:255];" "$OUT"
    grep -Fq "localparam [7:0] SRT_CHUNK = 8'd16;" "$OUT"
    grep -Fq "assign srt_claim = srt_busy || (req && srt_i);" "$OUT"
    grep -Fq "srt_mem[srt_beat + srt_rcv] <= e_rdata;" "$OUT"
    grep -Fq "e_burstlen <= srt_chunk_len;" "$OUT"
    grep -Fq "assign srt_store_atomic = srt_busy && srt_store_q;" "$OUT"
    grep -Fq "assign srt_invalidate_evt = srt_done && srt_store_q;" "$OUT"
    test "$(grep -Fc "if (!req || !srt_i)" "$OUT")" -eq 2
    test "$(grep -Fc "if ((req && srt_i) && srt_armed) begin" "$OUT")" -eq 2
    grep -Fq "if (srt_store_atomic) begin" "$OUT"
    # sv2v expands the E-lane eligibility expression in both the atomic-store
    # arm and the ordinary raw-load arm. Require both grants explicitly.
    test "$(grep -Fc "else if (((((e_start && !d_busy) && !beat_pending) && (ats == A_IDLE)) && !a_start) && !wb_v) begin" "$OUT")" -ge 1
    test "$(grep -Fc "if (((((e_start && !d_busy) && !beat_pending) && (ats == A_IDLE)) && !a_start) && !wb_v) begin" "$OUT")" -ge 2
    grep -Fq "if (er_pending) begin" "$OUT"
    grep -Fq "wire [63:0] a_read_beat = ((D_WRITE_FIFO && shw_en) && shw_base_hit ? shw_base : a_rdata);" "$OUT"
    # The fitted v7b database exposed a real BRAM-output/tag-compare -> L2
    # command-register path.  Require the registered, epoch-qualified response
    # boundary in the exact product and forbid direct merge use of raw shw_q.
    grep -Fq "shw_rsp_data_q <= shw_q[63:0];" "$OUT"
    grep -Fq "shw_rsp_cand_q <= shw_cand_q;" "$OUT"
    grep -Fq "shw_rsp_epoch_q <= shw_read_epoch_q;" "$OUT"
    grep -Fq "wire shw_rsp_fresh = shw_rsp_epoch_q == shw_epoch;" "$OUT"
    grep -Fq "d_wdata <= d_lane_merge(shw_rsp_data_q, df_data, df_mask);" "$OUT"
    # v7g failed because shw_valid synthesized as a 2,048:1 FF-vector lookup.
    # NARC now carries validity in the synchronous shadow M10K with a re-POR
    # generation tag; the FIFO-off generate branch retains donor behavior.
    grep -Fq "reg [77:0] shw_mem [0:2047];" "$OUT"
    grep -Fq "reg [7:0] shw_generation = 8'd0;" "$OUT"
    grep -Fq "if (!D_WRITE_FIFO) begin : g_shw_legacy_valid" "$OUT"
    grep -Fq "if (D_WRITE_FIFO) begin : g_shw_generation_valid" "$OUT"
    grep -Fq "shw_mem[{pub_ret_last[11:7], pub_ret_last[5:0]}] <= {shw_generation, 1'b1" "$OUT"
    grep -Fq "shw_mem[{shw_wa[11:7], shw_wa[5:0]}] <= {shw_generation, 1'b1" "$OUT"
    grep -Fq "shw_q[77:70] == shw_generation" "$OUT"
    grep -Fq "localparam [2:0] L_ISSUE = 3'd1;" "$OUT"
    test "$(grep -Fc "ls <= L_ISSUE;" "$OUT")" -ge 4
    # The v7c/v7d full-frontier fits exposed formerly hidden cones. Require
    # registered RAM/palette geometry, an unconditional low-fanout D source-
    # cache data copy, and an A/D shadow selector independent of all write modes.
    grep -Fq "hsel_q <= hsel;" "$OUT"
    grep -Fq "hidx_q[j] <= hidx[j];" "$OUT"
    # v7h: hval_q is no longer a plain copy of a combinational hval.  It is now
    # computed from the REGISTERED hsel_q/hoff_q against the region bound, which
    # both keeps the geometry registered (the v7c/v7d cone) and adds end-of-
    # region masking (gated by tb_yunit_hwram).  The old
    # `hval_q[j] <= hval[j];` guard was left behind by that change and silently
    # failed the whole production build.  Require the new structure instead --
    # registered offset plus all three region bounds -- so this stays a real
    # check on registered geometry rather than being dropped.
    grep -Fq "hoff_q <= widx[15:0];" "$OUT"
    grep -Fq "2'd0: hval_q[j] <= ({12'd0, hoff_q} + j[27:0]) < RAMW;" "$OUT"
    grep -Fq "2'd1: hval_q[j] <= ({12'd0, hoff_q} + j[27:0]) < PALW;" "$OUT"
    grep -Fq "2'd2: hval_q[j] <= ({12'd0, hoff_q} + j[27:0]) < CMOSW;" "$OUT"
    grep -Fq "dsrcwt_data_next = d_wdata;" "$OUT"
    grep -Fq "dsrcwt_data_next = wc_data;" "$OUT"
    grep -Fq "dsrcwt_data <= dsrcwt_data_next;" "$OUT"
    grep -Fq "wire [15:0] shw_cand = (a_start ? a_addr[15:0] : d_addr[15:0]);" "$OUT"
    grep -Fq "wire dma_done_ok = pace_cnt <= 26'd4;" "$OUT"
    grep -Fq "pace_arm <= state == 3'd2;" "$OUT"
    grep -Fq "reg abort_r;" "$OUT"
    grep -Fq "reg pend_trig;" "$OUT"
    grep -Fq "3'd1: state_n = 3'd2;" "$OUT"
    grep -Fq "assign fb_flush = state == 3'd6;" "$OUT"
    # Sound must stall E/Q only for a real MC6809E ROM read and cache the full
    # SDRAM word. FM remains on its independent exact-rate accumulator.
    # v7m: REPOINTED, NOT DELETED (this repo has been bitten twice by stale grep guards --
    # hval_q and fbq_ingress_ready -- that silently killed builds after a rename).
    # The original single check was:
    #     assign rom_read = (rnw & in_romall) & ~in_hidden;
    # v7m moved that expression into rom_read_live and registered it, so the one-liner no
    # longer exists. Three checks replace it, which is STRICTLY STRONGER than the one:
    #   1. the qualifier is unchanged and is still the PRODUCTION form -- notably NOT
    #      AVMA-gated (MUT_SND_USE_AVMA is the mutant and must never reach a build)
    #   2. rom_read is driven by the v7m capture stage
    #   3. bank is captured ALONGSIDE the address -- mandatory, because bank is written on
    #      the same cen_e edge the address changes, so a build where only addr got delayed
    #      would emit a one-clock new-bank/old-address offset
    grep -Fq "wire rom_read_live = (rnw & in_romall) & ~in_hidden;" "$OUT"
    grep -Fq "assign rom_read = rom_read_q;" "$OUT"
    grep -Fq "bsel_q <= bank;" "$OUT"
    grep -Fq "assign ready = (~demand0 | live0) & (~demand1 | live1);" "$OUT"
    grep -Fq "cur_dat[lane_q] <= snd_data;" "$OUT"
    grep -Fq "cand_valid[0] <= sampled_read0 & stable0;" "$OUT"
    grep -Fq "wire need0 = cand_valid[0] & ~cache_match0;" "$OUT"
    grep -Fq ".mst_read(mst_rom_read)" "$OUT"
    grep -Fq ".slv_read(slv_rom_read)" "$OUT"
    grep -Fq "module narc_6809_clock_en (" "$OUT"
    grep -Fq ".CPU_HZ(zunit_pkg_SND_6809_E_HZ)" "$OUT"
    grep -Fq "if (e_due && !rom_ready)" "$OUT"
    grep -Fq 'ym_mono_q <= ym_mono;' "$OUT"
    grep -Fq 'cvsd_s_q <= cvsd_s;' "$OUT"
    grep -Fq 'wire signed [31:0] ym_term_d = ($signed(ym_mono_q) * 32'\''sd26) >>> 8;' "$OUT"
    grep -Fq 'wire signed [31:0] cvsd_term_d = ($signed(cvsd_s_q) * 32'\''sd154) >>> 8;' "$OUT"
    if grep -Fq "u_narc_scan_cache" "$OUT"; then
      echo "ERROR: DDR3 production blob still contains the obsolete NARC SDRAM scan cache" >&2
      exit 1
    fi
    if grep -Fq "assign scan_brd_req = 1'b0;" "$OUT"; then
      echo "ERROR: DDR3 production blob parks the burst port needed by the NARC source cache" >&2
      exit 1
    fi
    if grep -Fq "wire settled0" "$OUT"; then
      echo "ERROR: sound fetch FSM still has the timing-rejected live 6809 request path" >&2
      exit 1
    fi
    if grep -Fq "d_lane_merge(shw_q[63:0]" "$OUT"; then
      echo "ERROR: DDR shadow merge still consumes the timing-rejected raw BRAM response" >&2
      exit 1
    fi
    if grep -Fq "shw_clear_active" "$OUT"; then
      echo "ERROR: DDR shadow still contains the abandoned boot-time clear stall" >&2
      exit 1
    fi
    if [[ "$(grep -Fc "dsrcwt_data <=" "$OUT")" -ne 2 ]]; then
      echo "ERROR: source-cache data copy is not the reset plus one unconditional next-data load" >&2
      exit 1
    fi
    if grep -Fq "wire [63:0] dsrcwt_data = dwt_data;" "$OUT"; then
      echo "ERROR: source-cache data aliases the timing-rejected high-fanout scanout data register" >&2
      exit 1
    fi
    if grep -Fq "(a_start && !a_wr)" "$OUT"; then
      echo "ERROR: shadow lookup selector still depends on the timing-rejected A write flag" >&2
      exit 1
    fi
    if grep -Fq "wire [15:0] shw_cand = (d_shadow_lookup" "$OUT"; then
      echo "ERROR: shadow lookup selector still depends on D write/burst mode" >&2
      exit 1
    fi
    echo "  DDR3 production route: video_scan <-> mem_scan; SDRAM burst -> NARC source cache"
    echo "  NARC controls: DDR shadow bypass + paced/refire DMA + qualified word-cached sound ROM"
    ;;
esac

# ---------------------------------------------------------------------------
# WHY THERE IS NO ELABORATION CHECK ON THE sv2v OUTPUT HERE (tried, MEASURED VACUOUS, removed).
# Y-unit's advice was right in principle -- sv2v is a translator, not an elaborator -- but
# elaborating the OUTPUT does not close the hole. Two reasons, both measured 2026-08-03:
#   1. The blob deliberately excludes the VHDL sound board and jt51/mc6809is/hc55564, so a bare
#      iverilog run always fails on "Unknown module type" and its exit code carries no signal.
#   2. Narrowing the check to "Unable to bind / syntax error" then FAILS ITS OWN MUTATION TEST:
#      deleting `logic [15:0] bfill_bt_rb_q;` still gave rc=0, because sv2v emits Verilog that
#      permits IMPLICIT NETS -- the deleted declaration silently becomes a wire.
# The real catch on 2026-08-03 came from iverilog compiling the SYSTEMVERILOG SOURCE, where
# `default_nettype none` makes an undeclared identifier an error. That is what the sim gates
# already do (sim/run_beamerase.sh compiles stv_vram_ddr_top.sv directly), so the coverage
# exists -- it just is not here, and pretending otherwise with a check that cannot fail would
# be worse than the gap.
# ---------------------------------------------------------------------------
echo "Quartus reads build_syn/smashtv_core.v (Verilog) + the VHDL sound board + jt51/mc6809/pia (Verilog/VHDL)."
