// syn_sound_core.sv — Phase-5 fit-risk harness (WORKER: hw_fit measurement).
// Measures the NET-NEW dual-6809 NARC sound board (narc_sound_board) M10K/DSP
// footprint against the binding CSEBA6 M10K budget (donor full core at ~93%).
//
// Blocks measured: 2x mc6809is (master cpu0 + slave cpu1) + full jt51 (YM2151,
// vendored, instantiated AS-IS — NOT the JT51_ONLYTIMERS timing shim) + 2x
// narc_ad7224 DAC + narc_sound_latch + 2x narc_sound_bank + per-cpu 8KB program
// RAM (2x = 16KB BRAM) + master 43-byte hidden RAM overlay.
//
// EXTERNALIZED (NOT BRAM — reflects logic/RAM only, honest D1 accounting):
//   * hc55564 CVSD decoder is BLACKBOXED (rtl/sound/sim/hc55564_stub.v, VHDL core
//     not synthesized here — no CVSD logic/RAM in this number).
//   * 384KB sound ROM stays OFF-chip: mst_rom_offset/mst_rom_data +
//     slv_rom_offset/slv_rom_data are top-level pins (the deferred D1 SDRAM/DDR3
//     home). NO $readmemh — ROMs are NOT inferred to BRAM (would inflate the
//     number and misrepresent D1).
//
// Every narc_sound_board port is driven from / exposed to top pins so the program
// RAMs, hidden RAM, bank regs, latch, DACs, and jt51 all reach an observable
// output and are retained/inferred honestly by Quartus A&S (same anti-prune
// discipline as syn_zunit_core.sv). Resource-estimate harness only, NOT the emu.
`default_nettype none
module syn_sound_core (
  input  logic        clk,
  input  logic        rst_pon,
  input  logic        cen_e,
  input  logic        cen_q,
  input  logic        cen_fm,
  input  logic        cen_fm_p1,
  input  logic        ext_wr,
  input  logic [15:0] ext_wdata,
  input  logic        reset_in,
  output logic [15:0] talkback_rd,
  output logic        sound_int_state,
  // sound ROM read ports held EXTERNAL (D1 home; NOT BRAM)
  output logic [19:0] mst_rom_offset,
  input  logic  [7:0] mst_rom_data,
  output logic [19:0] slv_rom_offset,
  input  logic  [7:0] slv_rom_data,
  // audio outputs
  output logic signed [15:0] ym_left,
  output logic signed [15:0] ym_right,
  output logic  [7:0]        dac1_level,
  output logic  [7:0]        dac2_level,
  output logic signed [15:0] dac1_sample,
  output logic signed [15:0] dac2_sample,
  output logic signed [15:0] cvsd_sample
);
  narc_sound_board u_snd (
    .clk            (clk),
    .rst_pon        (rst_pon),
    .cen_e          (cen_e),
    .cen_q          (cen_q),
    .cen_fm         (cen_fm),
    .cen_fm_p1      (cen_fm_p1),
    .ext_wr         (ext_wr),
    .ext_wdata      (ext_wdata),
    .reset_in       (reset_in),
    .talkback_rd    (talkback_rd),
    .sound_int_state(sound_int_state),
    .mst_rom_offset (mst_rom_offset),
    .mst_rom_data   (mst_rom_data),
    .slv_rom_offset (slv_rom_offset),
    .slv_rom_data   (slv_rom_data),
    .ym_left        (ym_left),
    .ym_right       (ym_right),
    .dac1_level     (dac1_level),
    .dac2_level     (dac2_level),
    .dac1_sample    (dac1_sample),
    .dac2_sample    (dac2_sample),
    .cvsd_sample    (cvsd_sample)
  );
endmodule
`default_nettype wire
