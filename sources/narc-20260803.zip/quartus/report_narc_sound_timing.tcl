# Post-fit audit for the NARC dual-6809 sound-ROM/deadline and audio-mixer paths.
#
# The first v7 fit exposed a real one-cycle path from mc6809is address-next
# logic into zunit_snd_rom's request latch.  Production now has explicit
# input -> candidate -> request register boundaries.  The v7a fit then exposed
# a separate cvsd_dc -> clamp -> x154 -> cvsd_term_q path, so production also
# has explicit normalization -> coefficient -> pair-sum -> mix -> output
# boundaries.  Require every collection to exist and report each boundary
# separately so a renamed/optimized-away guard cannot silently turn this audit
# green.
project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist -model slow -temperature -40 -voltage 1100
read_sdc
update_timing_netlist

proc require_nonempty {label coll} {
  set n [get_collection_size $coll]
  puts "NARC_SOUND_COLLECTION $label $n"
  if {$n == 0} {
    error "NARC sound timing collection is empty: $label"
  }
}

proc audit_boundary {label from_coll to_coll} {
  set paths [get_timing_paths -setup -from $from_coll -to $to_coll -npaths 25]
  set n [get_collection_size $paths]
  if {$n == 0} {
    error "NARC sound timing boundary has no paths: $label"
  }

  set worst 1.0e9
  foreach_in_collection path $paths {
    set slack [get_path_info -slack $path]
    if {$slack < $worst} {
      set worst $slack
    }
  }
  puts "NARC_SOUND_BOUNDARY $label paths=$n worst_setup=$worst"
  report_timing -setup -from $from_coll -to $to_coll -npaths 25 -detail summary -stdout
  if {$worst <= 0.0} {
    error "NARC sound timing boundary violated: $label worst_setup=$worst"
  }
}

# Use the same post-fit instance form proven by sdram.sdc.  The TimeQuest node
# name omits the intermediate entity labels here (`...|u_snd|u_master|u_cpu|...`),
# even though report_timing's verbose "From Node" line prints them.
set cpu_regs [get_registers {*u_snd|u_master|u_cpu|* *u_snd|u_slave|u_cpu|*}]
set input_regs [get_registers {*zunit_snd_rom:u_snd_rom|off_r1* *zunit_snd_rom:u_snd_rom|off_r2* *zunit_snd_rom:u_snd_rom|read_r1* *zunit_snd_rom:u_snd_rom|read_r2*}]
# v7m bus-address capture stage in narc_snd_cpu (both 6809s). Deliberately named to
# match NONE of sdram.sdc:149 $snd_regs (*bank*, *hid*, *ram_rtl_0*): these load every
# clk_sys and are NOT cen-gated, so they must be analysed single-cycle and must not
# inherit that -setup 8 relax.
set cachestate_regs [get_registers {*zunit_snd_rom:u_snd_rom|cur_word* *zunit_snd_rom:u_snd_rom|cur_val* *zunit_snd_rom:u_snd_rom|cur_dat* *zunit_snd_rom:u_snd_rom|cur_byte*}]
set buscapture_regs [get_registers {*u_snd|*u_master|bus_addr_q* *u_snd|*u_slave|bus_addr_q* *u_snd|*u_master|bsel_q* *u_snd|*u_slave|bsel_q* *u_snd|*u_master|rom_read_q* *u_snd|*u_slave|rom_read_q*}]
set candidate_regs [get_registers {*zunit_snd_rom:u_snd_rom|cand_off* *zunit_snd_rom:u_snd_rom|cand_valid*}]
set request_regs [get_registers {*zunit_snd_rom:u_snd_rom|off_q* *zunit_snd_rom:u_snd_rom|lane_q* *zunit_snd_rom:u_snd_rom|busy*}]
set deadline_regs [get_registers {*narc_6809_clock_en:u_6809_clock_en|phase* *narc_6809_clock_en:u_6809_clock_en|cen_e* *narc_6809_clock_en:u_6809_clock_en|cen_q*}]
set mixer_source_regs [get_registers {*u_snd|* *narc_audio_mix:u_audio_mix|cvsd_dc*}]
set mixer_norm_regs [get_registers {*narc_audio_mix:u_audio_mix|ym_mono_q* *narc_audio_mix:u_audio_mix|dac1_s_q* *narc_audio_mix:u_audio_mix|dac2_s_q* *narc_audio_mix:u_audio_mix|cvsd_s_q*}]
set mixer_term_regs [get_registers {*narc_audio_mix:u_audio_mix|ym_term_q* *narc_audio_mix:u_audio_mix|dac1_term_q* *narc_audio_mix:u_audio_mix|dac2_term_q* *narc_audio_mix:u_audio_mix|cvsd_term_q*}]
set mixer_pair_regs [get_registers {*narc_audio_mix:u_audio_mix|music_sum_q* *narc_audio_mix:u_audio_mix|dac_sum_q*}]
set mixer_mix_regs [get_registers {*narc_audio_mix:u_audio_mix|mix_q*}]
set mixer_output_regs [get_registers {*narc_audio_mix:u_audio_mix|audio_l* *narc_audio_mix:u_audio_mix|audio_r*}]
set ym_reset_regs [get_registers {*narc_sound_board:u_snd|ym_rst_local* *u_snd|ym_rst_local*}]
set jt51_regs [get_registers {*u_snd|u_ym|*}]

require_nonempty cpu_regs $cpu_regs
require_nonempty input_regs $input_regs
require_nonempty request_regs $request_regs
require_nonempty deadline_regs $deadline_regs
require_nonempty ym_reset_regs $ym_reset_regs
require_nonempty jt51_regs $jt51_regs

# Exercise the two boundaries that also exist in the quarantined v7 fit before
# requiring the v7a-only candidate stage.  This lets the rejected database prove
# both the Tcl/API plumbing and the intended fail-closed empty-candidate result.
# v7m: the 6809 bus address is now CAPTURED in narc_snd_cpu (bus_addr_q/bsel_q/
# rom_read_q) before narc_sound_bank, so NO u_cpu register reaches off_r1*
# combinationally any more and the old one-hop "6809_to_input" would fail with the
# zero-paths error at :27-29 -- RED for the wrong reason.
# It is replaced by BOTH halves of the same physical route, which is strictly MORE
# coverage than the single boundary it replaces, not less:
#   6809_to_buscapture   u_cpu -> bus_addr_q   <- THIS carries the real cone (the
#                        ~9.881 ns mc6809is addr_nxt decode that was failing at
#                        -0.119). Auditing only the second half would time a trivial
#                        path and silently stop watching the dangerous one.
#   buscapture_to_input  bus_addr_q -> off_r1  <- the decode LUT + the global route
# Both must exist and both must be positive.
require_nonempty buscapture_regs $buscapture_regs
require_nonempty cachestate_regs $cachestate_regs
audit_boundary "6809_to_buscapture"  $cpu_regs        $buscapture_regs
audit_boundary "buscapture_to_input" $buscapture_regs $input_regs
# v7m: SAME consequence as 6809_to_input, which I anticipated for that boundary and MISSED for this
# one -- the v7m capture stage also breaks the combinational path from u_cpu to the deadline
# generator, because narc_6809_clock_en is fed by snd_rom_ready (zunit_top.sv:791,817) which now
# launches from the registered offset rather than the raw 6809 address. The audit correctly failed
# CLOSED with "boundary has no paths" rather than passing vacuously.
# Replaced by the real remaining feeders. Coverage is preserved, not reduced: cpu_regs ->
# buscapture_regs is already audited above, and these two carry the rest of the same physical route.
audit_boundary "buscapture_to_deadline" $buscapture_regs $deadline_regs
# NOT input_regs: MEASURED "boundary has no paths" -- off_r1/off_r2 do NOT reach the deadline
# generator. That was my second guess at a collection in a row and it was wrong; the gate caught it
# by failing closed. The ACTUAL second feeder, read out of the RTL instead of guessed:
#   ready = (~demand0|live0) & (~demand1|live1)   zunit_snd_rom.sv:168
#   live0/live1 depend on cur_val[] and cur_word[] (:94-97, :144-153)
# which are in NO other collection in this file, so this closes a genuine hole rather than
# re-auditing something already covered.
audit_boundary "cachestate_to_deadline" $cachestate_regs $deadline_regs
audit_boundary "jt51_local_reset_to_state" $ym_reset_regs $jt51_regs

require_nonempty candidate_regs $candidate_regs
audit_boundary "input_to_candidate" $input_regs $candidate_regs
audit_boundary "candidate_to_request" $candidate_regs $request_regs

require_nonempty mixer_source_regs $mixer_source_regs
require_nonempty mixer_norm_regs $mixer_norm_regs
require_nonempty mixer_term_regs $mixer_term_regs
require_nonempty mixer_pair_regs $mixer_pair_regs
require_nonempty mixer_mix_regs $mixer_mix_regs
require_nonempty mixer_output_regs $mixer_output_regs

audit_boundary "mixer_source_to_normalized" $mixer_source_regs $mixer_norm_regs
audit_boundary "mixer_normalized_to_term" $mixer_norm_regs $mixer_term_regs
audit_boundary "mixer_term_to_pair_sum" $mixer_term_regs $mixer_pair_regs
audit_boundary "mixer_pair_sum_to_mix" $mixer_pair_regs $mixer_mix_regs
audit_boundary "mixer_mix_to_output" $mixer_mix_regs $mixer_output_regs

project_close
