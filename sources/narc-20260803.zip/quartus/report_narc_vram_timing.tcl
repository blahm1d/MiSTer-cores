# Post-fit audit for NARC's DDR3 shadow lookup, registered scanout refill,
# and L2 command boundaries.
#
# The v7b fit exposed a real path from the shadow M10K output/tag compare into
# tst_addr/tst_burstcnt, worst -0.428 ns.  Production now registers a complete,
# epoch-qualified lookup response before either the local merge or the L2 grant
# cone.  Fail closed if that stage is absent/optimized away or either side has
# nonpositive setup slack.
project_open Arcade-SmashTV -revision Arcade-SmashTV
create_timing_netlist -model slow -temperature -40 -voltage 1100
read_sdc
update_timing_netlist

set any_failed 0

proc require_nonempty {label coll} {
  global any_failed
  set n [get_collection_size $coll]
  puts "NARC_VRAM_COLLECTION $label $n"
  if {$n == 0} {
    puts "NARC_VRAM_REJECT empty_collection=$label"
    set any_failed 1
  }
}

proc audit_to {label to_coll} {
  global any_failed
  set paths [get_timing_paths -setup -to $to_coll -npaths 25]
  set n [get_collection_size $paths]
  if {$n == 0} {
    puts "NARC_VRAM_REJECT no_paths=$label"
    set any_failed 1
    return
  }
  set worst 1.0e9
  foreach_in_collection path $paths {
    set slack [get_path_info -slack $path]
    if {$slack < $worst} {
      set worst $slack
    }
  }
  puts "NARC_VRAM_BOUNDARY $label paths=$n worst_setup=$worst"
  report_timing -setup -to $to_coll -npaths 25 -detail summary -stdout
  if {$worst <= 0.0} {
    puts "NARC_VRAM_REJECT boundary=$label worst_setup=$worst"
    set any_failed 1
  }
}

proc audit_boundary {label from_coll to_coll} {
  global any_failed
  set paths [get_timing_paths -setup -from $from_coll -to $to_coll -npaths 25]
  set n [get_collection_size $paths]
  if {$n == 0} {
    puts "NARC_VRAM_REJECT no_paths=$label"
    set any_failed 1
    return
  }
  set worst 1.0e9
  foreach_in_collection path $paths {
    set slack [get_path_info -slack $path]
    if {$slack < $worst} {
      set worst $slack
    }
  }
  puts "NARC_VRAM_BOUNDARY $label paths=$n worst_setup=$worst"
  report_timing -setup -from $from_coll -to $to_coll -npaths 25 -detail summary -stdout
  if {$worst <= 0.0} {
    puts "NARC_VRAM_REJECT boundary=$label worst_setup=$worst"
    set any_failed 1
  }
}

set response_regs [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|shw_rsp_data_q*
  *stv_vram_ddr_top:u_vram_sdram|shw_rsp_cand_q*
  *stv_vram_ddr_top:u_vram_sdram|shw_rsp_hit_q*
  *stv_vram_ddr_top:u_vram_sdram|shw_rsp_epoch_q*
}]
set agent_regs [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|tst_addr*
  *stv_vram_ddr_top:u_vram_sdram|tst_burstcnt*
  *stv_vram_ddr_top:u_vram_sdram|tst_rd_req*
  *stv_vram_ddr_top:u_vram_sdram|tst_wr_req*
}]
set selection_regs [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|l_gnt*
  *stv_vram_ddr_top:u_vram_sdram|ls*
  *stv_vram_ddr_top:u_vram_sdram|l_proof*
  *stv_vram_ddr_top:u_vram_sdram|pub_page*
}]
set merge_regs [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|shw_base*
  *stv_vram_ddr_top:u_vram_sdram|shw_base_hit*
  *stv_vram_ddr_top:u_vram_sdram|d_wdata*
}]
set lookup_regs [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|shw_q*
  *stv_vram_ddr_top:u_vram_sdram|shw_cand_q*
  *stv_vram_ddr_top:u_vram_sdram|shw_read_epoch_q*
  *stv_vram_ddr_top:u_vram_sdram|shw_generation*
}]
set row_cache_data_regs [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|altsyncram:rc_rtl_0|*porta_datain_reg*
}]
set bfill_pipe_data_regs [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|bfill_pipe_data*
}]
set geometry_regs [get_registers {
  *zunit_mem:u_mem|hsel_q*
  *zunit_mem:u_mem|hidx_q*
  *zunit_mem:u_mem|hoff_q*
  *zunit_mem:u_mem|hval_q*
}]
set field_taps [get_registers {
  *zunit_mem:u_mem|hwin_q*
  *zunit_mem:u_mem|palv_we_a*
  *zunit_mem:u_mem|palv_we_b*
}]
set source_wt_regs [get_registers {
  *stv_vram_ddr_top:u_vram_sdram|dwt_data*
  *stv_vram_ddr_top:u_vram_sdram|dsrcwt_data*
  *stv_vram_ddr_top:u_vram_sdram|dsrcwt_req*
  *stv_vram_ddr_top:u_vram_sdram|dsrcwt_idx*
}]

require_nonempty response_regs $response_regs
require_nonempty selection_regs $selection_regs
require_nonempty agent_regs $agent_regs
require_nonempty merge_regs $merge_regs
require_nonempty lookup_regs $lookup_regs
require_nonempty row_cache_data_regs $row_cache_data_regs
require_nonempty bfill_pipe_data_regs $bfill_pipe_data_regs
require_nonempty geometry_regs $geometry_regs
require_nonempty field_taps $field_taps
require_nonempty source_wt_regs $source_wt_regs

audit_to "shadow_candidate_to_lookup" $lookup_regs
audit_to "shadow_read_to_response" $response_regs
# v7u split the measured rb_base -> snoop merge -> row-cache BRAM data path
# with bfill_pipe_data. Audit BOTH halves. Keeping only the former broad
# audit_to on the BRAM endpoint would time the trivial second half and silently
# stop watching the merge cone that actually failed at slow 85C/100C.
audit_to "snoop_merge_to_refill_pipeline" $bfill_pipe_data_regs
audit_boundary "refill_pipeline_to_row_cache_data" $bfill_pipe_data_regs $row_cache_data_regs
audit_boundary "response_to_selection" $response_regs $selection_regs
audit_to "selection_and_payload_to_agent_command" $agent_regs
audit_boundary "response_to_merge" $response_regs $merge_regs
audit_to "address_to_registered_ram_geometry" $geometry_regs
audit_boundary "registered_geometry_to_field_outputs" $geometry_regs $field_taps
audit_to "source_cache_write_through_capture" $source_wt_regs

project_close
if {$any_failed} {
  error "NARC VRAM timing audit failed one or more boundaries"
}
