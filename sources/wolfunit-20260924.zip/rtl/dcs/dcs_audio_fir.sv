// dcs_audio_fir.sv -- DCS 31.25 kHz -> x16 (500 kHz) polyphase FIR reconstruction.
//
// Drop-in for dcs_audio_interp (same ports).  Every DCS core outputs 31.25 kHz PCM into MiSTer's
// asynchronous 48 kHz sink; a raw hold or a linear ramp leaves the spectral images of that stream,
// which the sink aliases into 12-20 kHz (the reported MK2 "hiss": +21 dB above MAME 0.289 over
// 15.6 kHz, measured on the 9/18 core after MiSTer's default filter).  This module low-passes the
// x16-oversampled stream (256-tap Kaiser prototype, cutoff 15 kHz, ~80 dB stopband >= 20 kHz;
// tools/gen_dcs_audio_fir.py) so the sink samples an already band-limited signal, then ramps
// between phases (first-order hold) so the asynchronous latch does not re-alias the staircase.
//
//   y[16n + k] = sat16( (sum_{j=0..15} h[k + 16 j] * x[n - j] + 2^15) >>> 16 ),  k = 0..15
//   out        = 16-step ramp y[m-1] -> y[m]  (stage 6)
//
// TIMING/AREA (built to close; see header of the gate): one LUT coefficient ROM (registered read),
// one 18x16 multiplier with registered inputs/output (DSP), a registered 16:1 history mux, a
// separate accumulate stage, and separate round/saturate/output registers.  16 MACs per sub-step
// against >= 160 clocks available, so throughput is never at risk.  Sub-step cadence is measured
// from the sample strobe exactly like dcs_audio_interp (no clock constant to get wrong).
(* altera_attribute = "-name AUTO_ROM_RECOGNITION OFF" *)   // coefficient table stays LUT logic
module dcs_audio_fir #(
    parameter int STEPS_LOG2 = 4                     // 16 phases (must match the coefficient table)
)(
    input  wire               clk,
    input  wire               rst,
    input  wire signed [15:0] sample_in,
    input  wire               sample_ce,             // 31.25 kHz DAC slot strobe
    output wire signed [15:0] audio_out
);
    // ---- BEGIN GENERATED COEFFICIENT ROM (tools/gen_dcs_audio_fir.py) -- do not edit ----
    // 16 phases x 16 taps, FS_UP 500000 Hz, FC 15000 Hz, Kaiser beta 8.0, Q16 signed 18-bit.
    function automatic logic signed [17:0] dcs_fir_coef(input logic [7:0] i);
        case (i)
            8'd0: dcs_fir_coef = -18'sd5;
            8'd1: dcs_fir_coef = -18'sd8;
            8'd2: dcs_fir_coef = -18'sd10;
            8'd3: dcs_fir_coef = -18'sd12;
            8'd4: dcs_fir_coef = -18'sd14;
            8'd5: dcs_fir_coef = -18'sd15;
            8'd6: dcs_fir_coef = -18'sd16;
            8'd7: dcs_fir_coef = -18'sd15;
            8'd8: dcs_fir_coef = -18'sd14;
            8'd9: dcs_fir_coef = -18'sd10;
            8'd10: dcs_fir_coef = -18'sd6;
            8'd11: dcs_fir_coef = 18'sd1;
            8'd12: dcs_fir_coef = 18'sd10;
            8'd13: dcs_fir_coef = 18'sd20;
            8'd14: dcs_fir_coef = 18'sd32;
            8'd15: dcs_fir_coef = 18'sd45;
            8'd16: dcs_fir_coef = 18'sd59;
            8'd17: dcs_fir_coef = 18'sd73;
            8'd18: dcs_fir_coef = 18'sd86;
            8'd19: dcs_fir_coef = 18'sd97;
            8'd20: dcs_fir_coef = 18'sd105;
            8'd21: dcs_fir_coef = 18'sd110;
            8'd22: dcs_fir_coef = 18'sd111;
            8'd23: dcs_fir_coef = 18'sd105;
            8'd24: dcs_fir_coef = 18'sd94;
            8'd25: dcs_fir_coef = 18'sd76;
            8'd26: dcs_fir_coef = 18'sd51;
            8'd27: dcs_fir_coef = 18'sd19;
            8'd28: dcs_fir_coef = -18'sd20;
            8'd29: dcs_fir_coef = -18'sd65;
            8'd30: dcs_fir_coef = -18'sd114;
            8'd31: dcs_fir_coef = -18'sd166;
            8'd32: dcs_fir_coef = -18'sd219;
            8'd33: dcs_fir_coef = -18'sd270;
            8'd34: dcs_fir_coef = -18'sd317;
            8'd35: dcs_fir_coef = -18'sd358;
            8'd36: dcs_fir_coef = -18'sd388;
            8'd37: dcs_fir_coef = -18'sd406;
            8'd38: dcs_fir_coef = -18'sd409;
            8'd39: dcs_fir_coef = -18'sd394;
            8'd40: dcs_fir_coef = -18'sd360;
            8'd41: dcs_fir_coef = -18'sd305;
            8'd42: dcs_fir_coef = -18'sd230;
            8'd43: dcs_fir_coef = -18'sd134;
            8'd44: dcs_fir_coef = -18'sd21;
            8'd45: dcs_fir_coef = 18'sd109;
            8'd46: dcs_fir_coef = 18'sd251;
            8'd47: dcs_fir_coef = 18'sd400;
            8'd48: dcs_fir_coef = 18'sd551;
            8'd49: dcs_fir_coef = 18'sd698;
            8'd50: dcs_fir_coef = 18'sd833;
            8'd51: dcs_fir_coef = 18'sd950;
            8'd52: dcs_fir_coef = 18'sd1042;
            8'd53: dcs_fir_coef = 18'sd1101;
            8'd54: dcs_fir_coef = 18'sd1122;
            8'd55: dcs_fir_coef = 18'sd1098;
            8'd56: dcs_fir_coef = 18'sd1027;
            8'd57: dcs_fir_coef = 18'sd907;
            8'd58: dcs_fir_coef = 18'sd735;
            8'd59: dcs_fir_coef = 18'sd515;
            8'd60: dcs_fir_coef = 18'sd250;
            8'd61: dcs_fir_coef = -18'sd53;
            8'd62: dcs_fir_coef = -18'sd386;
            8'd63: dcs_fir_coef = -18'sd739;
            8'd64: dcs_fir_coef = -18'sd1099;
            8'd65: dcs_fir_coef = -18'sd1452;
            8'd66: dcs_fir_coef = -18'sd1783;
            8'd67: dcs_fir_coef = -18'sd2076;
            8'd68: dcs_fir_coef = -18'sd2315;
            8'd69: dcs_fir_coef = -18'sd2486;
            8'd70: dcs_fir_coef = -18'sd2574;
            8'd71: dcs_fir_coef = -18'sd2569;
            8'd72: dcs_fir_coef = -18'sd2462;
            8'd73: dcs_fir_coef = -18'sd2246;
            8'd74: dcs_fir_coef = -18'sd1922;
            8'd75: dcs_fir_coef = -18'sd1490;
            8'd76: dcs_fir_coef = -18'sd958;
            8'd77: dcs_fir_coef = -18'sd338;
            8'd78: dcs_fir_coef = 18'sd353;
            8'd79: dcs_fir_coef = 18'sd1096;
            8'd80: dcs_fir_coef = 18'sd1863;
            8'd81: dcs_fir_coef = 18'sd2631;
            8'd82: dcs_fir_coef = 18'sd3366;
            8'd83: dcs_fir_coef = 18'sd4037;
            8'd84: dcs_fir_coef = 18'sd4613;
            8'd85: dcs_fir_coef = 18'sd5061;
            8'd86: dcs_fir_coef = 18'sd5353;
            8'd87: dcs_fir_coef = 18'sd5464;
            8'd88: dcs_fir_coef = 18'sd5370;
            8'd89: dcs_fir_coef = 18'sd5059;
            8'd90: dcs_fir_coef = 18'sd4523;
            8'd91: dcs_fir_coef = 18'sd3760;
            8'd92: dcs_fir_coef = 18'sd2779;
            8'd93: dcs_fir_coef = 18'sd1597;
            8'd94: dcs_fir_coef = 18'sd241;
            8'd95: dcs_fir_coef = -18'sd1256;
            8'd96: dcs_fir_coef = -18'sd2848;
            8'd97: dcs_fir_coef = -18'sd4484;
            8'd98: dcs_fir_coef = -18'sd6108;
            8'd99: dcs_fir_coef = -18'sd7659;
            8'd100: dcs_fir_coef = -18'sd9069;
            8'd101: dcs_fir_coef = -18'sd10273;
            8'd102: dcs_fir_coef = -18'sd11204;
            8'd103: dcs_fir_coef = -18'sd11797;
            8'd104: dcs_fir_coef = -18'sd11998;
            8'd105: dcs_fir_coef = -18'sd11753;
            8'd106: dcs_fir_coef = -18'sd11019;
            8'd107: dcs_fir_coef = -18'sd9768;
            8'd108: dcs_fir_coef = -18'sd7979;
            8'd109: dcs_fir_coef = -18'sd5646;
            8'd110: dcs_fir_coef = -18'sd2780;
            8'd111: dcs_fir_coef = 18'sd597;
            8'd112: dcs_fir_coef = 18'sd4443;
            8'd113: dcs_fir_coef = 18'sd8707;
            8'd114: dcs_fir_coef = 18'sd13324;
            8'd115: dcs_fir_coef = 18'sd18213;
            8'd116: dcs_fir_coef = 18'sd23283;
            8'd117: dcs_fir_coef = 18'sd28441;
            8'd118: dcs_fir_coef = 18'sd33581;
            8'd119: dcs_fir_coef = 18'sd38599;
            8'd120: dcs_fir_coef = 18'sd43388;
            8'd121: dcs_fir_coef = 18'sd47844;
            8'd122: dcs_fir_coef = 18'sd51871;
            8'd123: dcs_fir_coef = 18'sd55376;
            8'd124: dcs_fir_coef = 18'sd58283;
            8'd125: dcs_fir_coef = 18'sd60521;
            8'd126: dcs_fir_coef = 18'sd62044;
            8'd127: dcs_fir_coef = 18'sd62814;
            8'd128: dcs_fir_coef = 18'sd62814;
            8'd129: dcs_fir_coef = 18'sd62044;
            8'd130: dcs_fir_coef = 18'sd60521;
            8'd131: dcs_fir_coef = 18'sd58283;
            8'd132: dcs_fir_coef = 18'sd55376;
            8'd133: dcs_fir_coef = 18'sd51871;
            8'd134: dcs_fir_coef = 18'sd47844;
            8'd135: dcs_fir_coef = 18'sd43388;
            8'd136: dcs_fir_coef = 18'sd38599;
            8'd137: dcs_fir_coef = 18'sd33581;
            8'd138: dcs_fir_coef = 18'sd28441;
            8'd139: dcs_fir_coef = 18'sd23283;
            8'd140: dcs_fir_coef = 18'sd18213;
            8'd141: dcs_fir_coef = 18'sd13324;
            8'd142: dcs_fir_coef = 18'sd8707;
            8'd143: dcs_fir_coef = 18'sd4443;
            8'd144: dcs_fir_coef = 18'sd597;
            8'd145: dcs_fir_coef = -18'sd2780;
            8'd146: dcs_fir_coef = -18'sd5646;
            8'd147: dcs_fir_coef = -18'sd7979;
            8'd148: dcs_fir_coef = -18'sd9768;
            8'd149: dcs_fir_coef = -18'sd11019;
            8'd150: dcs_fir_coef = -18'sd11753;
            8'd151: dcs_fir_coef = -18'sd11998;
            8'd152: dcs_fir_coef = -18'sd11797;
            8'd153: dcs_fir_coef = -18'sd11204;
            8'd154: dcs_fir_coef = -18'sd10273;
            8'd155: dcs_fir_coef = -18'sd9069;
            8'd156: dcs_fir_coef = -18'sd7659;
            8'd157: dcs_fir_coef = -18'sd6108;
            8'd158: dcs_fir_coef = -18'sd4484;
            8'd159: dcs_fir_coef = -18'sd2848;
            8'd160: dcs_fir_coef = -18'sd1256;
            8'd161: dcs_fir_coef = 18'sd241;
            8'd162: dcs_fir_coef = 18'sd1597;
            8'd163: dcs_fir_coef = 18'sd2779;
            8'd164: dcs_fir_coef = 18'sd3760;
            8'd165: dcs_fir_coef = 18'sd4523;
            8'd166: dcs_fir_coef = 18'sd5059;
            8'd167: dcs_fir_coef = 18'sd5370;
            8'd168: dcs_fir_coef = 18'sd5464;
            8'd169: dcs_fir_coef = 18'sd5353;
            8'd170: dcs_fir_coef = 18'sd5061;
            8'd171: dcs_fir_coef = 18'sd4613;
            8'd172: dcs_fir_coef = 18'sd4037;
            8'd173: dcs_fir_coef = 18'sd3366;
            8'd174: dcs_fir_coef = 18'sd2631;
            8'd175: dcs_fir_coef = 18'sd1863;
            8'd176: dcs_fir_coef = 18'sd1096;
            8'd177: dcs_fir_coef = 18'sd353;
            8'd178: dcs_fir_coef = -18'sd338;
            8'd179: dcs_fir_coef = -18'sd958;
            8'd180: dcs_fir_coef = -18'sd1490;
            8'd181: dcs_fir_coef = -18'sd1922;
            8'd182: dcs_fir_coef = -18'sd2246;
            8'd183: dcs_fir_coef = -18'sd2462;
            8'd184: dcs_fir_coef = -18'sd2569;
            8'd185: dcs_fir_coef = -18'sd2574;
            8'd186: dcs_fir_coef = -18'sd2486;
            8'd187: dcs_fir_coef = -18'sd2315;
            8'd188: dcs_fir_coef = -18'sd2076;
            8'd189: dcs_fir_coef = -18'sd1783;
            8'd190: dcs_fir_coef = -18'sd1452;
            8'd191: dcs_fir_coef = -18'sd1099;
            8'd192: dcs_fir_coef = -18'sd739;
            8'd193: dcs_fir_coef = -18'sd386;
            8'd194: dcs_fir_coef = -18'sd53;
            8'd195: dcs_fir_coef = 18'sd250;
            8'd196: dcs_fir_coef = 18'sd515;
            8'd197: dcs_fir_coef = 18'sd735;
            8'd198: dcs_fir_coef = 18'sd907;
            8'd199: dcs_fir_coef = 18'sd1027;
            8'd200: dcs_fir_coef = 18'sd1098;
            8'd201: dcs_fir_coef = 18'sd1122;
            8'd202: dcs_fir_coef = 18'sd1101;
            8'd203: dcs_fir_coef = 18'sd1042;
            8'd204: dcs_fir_coef = 18'sd950;
            8'd205: dcs_fir_coef = 18'sd833;
            8'd206: dcs_fir_coef = 18'sd698;
            8'd207: dcs_fir_coef = 18'sd551;
            8'd208: dcs_fir_coef = 18'sd400;
            8'd209: dcs_fir_coef = 18'sd251;
            8'd210: dcs_fir_coef = 18'sd109;
            8'd211: dcs_fir_coef = -18'sd21;
            8'd212: dcs_fir_coef = -18'sd134;
            8'd213: dcs_fir_coef = -18'sd230;
            8'd214: dcs_fir_coef = -18'sd305;
            8'd215: dcs_fir_coef = -18'sd360;
            8'd216: dcs_fir_coef = -18'sd394;
            8'd217: dcs_fir_coef = -18'sd409;
            8'd218: dcs_fir_coef = -18'sd406;
            8'd219: dcs_fir_coef = -18'sd388;
            8'd220: dcs_fir_coef = -18'sd358;
            8'd221: dcs_fir_coef = -18'sd317;
            8'd222: dcs_fir_coef = -18'sd270;
            8'd223: dcs_fir_coef = -18'sd219;
            8'd224: dcs_fir_coef = -18'sd166;
            8'd225: dcs_fir_coef = -18'sd114;
            8'd226: dcs_fir_coef = -18'sd65;
            8'd227: dcs_fir_coef = -18'sd20;
            8'd228: dcs_fir_coef = 18'sd19;
            8'd229: dcs_fir_coef = 18'sd51;
            8'd230: dcs_fir_coef = 18'sd76;
            8'd231: dcs_fir_coef = 18'sd94;
            8'd232: dcs_fir_coef = 18'sd105;
            8'd233: dcs_fir_coef = 18'sd111;
            8'd234: dcs_fir_coef = 18'sd110;
            8'd235: dcs_fir_coef = 18'sd105;
            8'd236: dcs_fir_coef = 18'sd97;
            8'd237: dcs_fir_coef = 18'sd86;
            8'd238: dcs_fir_coef = 18'sd73;
            8'd239: dcs_fir_coef = 18'sd59;
            8'd240: dcs_fir_coef = 18'sd45;
            8'd241: dcs_fir_coef = 18'sd32;
            8'd242: dcs_fir_coef = 18'sd20;
            8'd243: dcs_fir_coef = 18'sd10;
            8'd244: dcs_fir_coef = 18'sd1;
            8'd245: dcs_fir_coef = -18'sd6;
            8'd246: dcs_fir_coef = -18'sd10;
            8'd247: dcs_fir_coef = -18'sd14;
            8'd248: dcs_fir_coef = -18'sd15;
            8'd249: dcs_fir_coef = -18'sd16;
            8'd250: dcs_fir_coef = -18'sd15;
            8'd251: dcs_fir_coef = -18'sd14;
            8'd252: dcs_fir_coef = -18'sd12;
            8'd253: dcs_fir_coef = -18'sd10;
            8'd254: dcs_fir_coef = -18'sd8;
            8'd255: dcs_fir_coef = -18'sd5;
            default: dcs_fir_coef = 18'sd0;
        endcase
    endfunction
    // ---- END GENERATED COEFFICIENT ROM ----
    localparam int L    = 1 << STEPS_LOG2;           // phases
    localparam int TAPS = 16;

    // ---- sample history (x[n] .. x[n-15]) -------------------------------------------------
    logic signed [15:0] hist [0:TAPS-1];
    // ---- sub-step cadence (as dcs_audio_interp) --------------------------------------------
    logic [15:0] period_cnt = '0, period = '0, sub_cnt = '0;
    logic [STEPS_LOG2-1:0] k = '0;                   // phase of the NEXT sub-step to compute
    logic        steps_left = 1'b0;                  // sub-steps remain for the current sample
    wire  [15:0] sub_period = period >> STEPS_LOG2;
    // ---- MAC sequencer ---------------------------------------------------------------------
    logic        busy = 1'b0;
    logic [3:0]  j = '0;                             // tap index issued this cycle
    logic [STEPS_LOG2-1:0] kk = '0;                  // phase being computed
    logic        s1_v = 1'b0, s2_v = 1'b0;          // pipeline valids
    logic        s1_last = 1'b0, s2_last = 1'b0;
    // stage 1: coefficient ROM (registered read) kept in LOGIC, not M10K -- see the module-level
    // AUTO_ROM_RECOGNITION OFF.  An inferred altsyncram ROM reports "Don't care" mixed-port
    // read-during-write, which the T-unit assemble gate (rightly) refuses for any inferred RAM.
    // Measured dead ends: romstyle on the output register is ignored; romstyle on an initialised
    // array elaborates as an unwritten RAM (Warning 10030 x3, rejected by the build scan).
    logic signed [17:0] coef_q;
    logic signed [15:0] hist_q;                      // stage 1: history mux (registered)
    logic signed [33:0] prod_q;                      // stage 2: DSP product (registered)
    logic signed [37:0] acc = '0;                    // stage 3: accumulator
    logic signed [37:0] acc_done = '0;               // stage 4: completed sum
    logic               done_v = 1'b0;
    logic signed [21:0] y_round = '0;                // stage 5: rounded, pre-saturation
    logic               round_v = 1'b0;
    logic signed [15:0] audio_q = '0;

    wire start = !busy && steps_left && (sub_cnt >= sub_period);

    always_ff @(posedge clk) begin
        if (rst) begin
            period_cnt <= '0; period <= '0; sub_cnt <= '0; k <= '0; steps_left <= 1'b0;
            busy <= 1'b0; j <= '0; kk <= '0;
            for (int i = 0; i < TAPS; i++) hist[i] <= '0;
        end else begin
            if (!(&period_cnt)) period_cnt <= period_cnt + 1'b1;
            if (sample_ce) begin
                period     <= period_cnt;
                period_cnt <= '0;
                for (int i = TAPS-1; i > 0; i--) hist[i] <= hist[i-1];
                hist[0]    <= sample_in;
                k          <= '0;
                steps_left <= 1'b1;
                sub_cnt    <= '1;                        // phase 0 is due at once
            end else begin
                // The counter runs THROUGH the MAC (it must not stretch the step spacing):
                // phase k issues ~k*sub_period after the strobe, so phase 15 completes
                // ~sub_period-20 clocks before the next strobe shifts the history.
                if (start)           sub_cnt <= 16'd1;
                else if (!(&sub_cnt)) sub_cnt <= sub_cnt + 1'b1;
                if (start) begin
                    busy <= 1'b1; j <= '0; kk <= k;
                    k <= k + 1'b1;
                    if (&k) steps_left <= 1'b0;          // phase L-1 issued: sample complete
                end
            end
            if (busy) begin
                j <= j + 1'b1;
                if (&j) busy <= 1'b0;                    // 16 taps issued
            end
        end
    end

    // stage 1: registered coefficient ROM read + registered history mux (tap j, phase kk)
    always_ff @(posedge clk) begin
        coef_q  <= dcs_fir_coef({j, kk});             // index = kk + 16*j
        hist_q  <= hist[j];
        s1_v    <= busy && !rst;
        s1_last <= busy && (&j);
    end
    // stage 2: DSP multiply (registered inputs above, registered product here)
    always_ff @(posedge clk) begin
        prod_q  <= coef_q * hist_q;
        s2_v    <= s1_v;
        s2_last <= s1_last;
    end
    // stage 3: accumulate; the first product of a phase restarts the sum
    logic s2_first = 1'b1;
    always_ff @(posedge clk) begin
        if (rst) begin acc <= '0; s2_first <= 1'b1; done_v <= 1'b0; end
        else begin
            done_v <= 1'b0;
            if (s2_v) begin
                acc <= (s2_first ? 38'sd0 : acc) + {{4{prod_q[33]}}, prod_q};
                s2_first <= s2_last;
                if (s2_last) begin
                    acc_done <= (s2_first ? 38'sd0 : acc) + {{4{prod_q[33]}}, prod_q};
                    done_v   <= 1'b1;
                end
            end
        end
    end
    // stage 4: round to Q0 (separate register: keeps the 38-bit add out of the saturate path)
    always_ff @(posedge clk) begin
        round_v <= done_v && !rst;
        if (done_v) y_round <= 22'((acc_done + 38'sd32768) >>> 16);
    end
    // stage 5: saturate into the REGISTERED output (the sink samples AUDIO asynchronously)
    always_ff @(posedge clk) begin
        if (rst) audio_q <= '0;
        else if (round_v)
            audio_q <= (y_round >  22'sd32767) ?  16'sd32767 :
                       (y_round < -22'sd32768) ?  16'sh8000  : y_round[15:0];
    end
    // stage 6: first-order hold between FIR phases (16 steps spread over each phase).
    // The sink latches AUDIO at arbitrary instants; a 500 kHz STAIRCASE latched that way still
    // aliases (-52 dB on MK2 track 0046 vs -75 dB for an ideal resample); ramping each phase
    // step in 16 increments brings it to -72 dB (tools/run_dcs_audio_fir_gate.py).  Exact:
    //   out[r] = (16*w_prev + r*(w - w_prev)) >>> 4, r = 1..16, so r = 16 lands ON w.
    // The 16 ticks are Bresenham-spaced over sub_period, so the ramp always ends before the next word.
    logic               ph_v = 1'b0;                 // audio_q took a new FIR word last clock
    logic signed [15:0] w_prev = '0;
    logic signed [16:0] delta = '0;
    logic signed [20:0] ramp_acc = '0;               // Q4
    logic [4:0]         r_left = '0;
    logic [16:0]        tick_frac = '0;
    logic               ramp_v = 1'b0;               // ramp output advanced (bench strobe)
    always_ff @(posedge clk) begin
        if (rst) begin
            ph_v <= 1'b0; w_prev <= '0; delta <= '0; ramp_acc <= '0; r_left <= '0; tick_frac <= '0;
            ramp_v <= 1'b0;
        end else begin
            ph_v   <= round_v;
            ramp_v <= 1'b0;
            if (ph_v) begin                          // new target: restart the ramp from w_prev
                delta    <= audio_q - w_prev;        // registered 17-bit difference
                w_prev   <= audio_q;
                ramp_acc <= 21'($signed({w_prev, 4'b0})); // exactly the previous target (ramp completed)
                r_left   <= 5'd16;
                tick_frac <= 17'd16;
            end else if (r_left != 0) begin
                // Bresenham: tick i lands at ceil(i*sub_period/16)-1 clocks after the word, so the
                // 16 steps span the whole phase and the last lands one clock before the next word.
                if (tick_frac + 17'd16 >= {1'b0, sub_period}) begin
                    tick_frac <= tick_frac + 17'd16 - {1'b0, sub_period};
                    ramp_acc  <= ramp_acc + delta;
                    r_left    <= r_left - 1'b1;
                    ramp_v    <= 1'b1;
                end else tick_frac <= tick_frac + 17'd16;
            end
        end
    end
    assign audio_out = ramp_acc[19:4];
endmodule
