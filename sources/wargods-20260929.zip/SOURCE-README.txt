War Gods (V Unit) - r16
RBF SHA-256: f3f2e6421179a3e8e8d27f93271800880b819ce5f4d8e7ca7a1b2a0ac66bb5ac

This archive contains the selected integration source and build support files.
Use Quartus 17.0 Lite for the DE10-Nano / Cyclone V target. See the project
QSF/QIP files and build scripts for the source list and conversion steps.
Third-party files retain their individual copyright and license notices.
No game ROMs, personal settings, fitted databases or game traces are included.
ROMs are loaded by MiSTer at runtime; ROM-driven simulations need local game data.

Source identity: source
The compiled binary's validation status is recorded in the feed catalog.
