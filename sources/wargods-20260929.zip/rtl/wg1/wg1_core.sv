`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// wg1_core.sv -- War Gods (Midway V-unit plus, MAME wargods / midvplus) master core: the C31 + V-unit renderer +
// memory tier, with the three net-new War Gods blocks socketed onto it. FORK of bandwidth/gm1/rtl/gm1_core.sv
// (md5 in rtl/FORKED_FROM.md5); the DDR mux / adapter / framebuffer-presentation / loader / SDRAM plumbing is the
// proven gm1 structure. Deltas vs gm1_core (all audited, DESIGN-RULES.md s4):
//   * ENGINE = wg1_engine (exposes the C1 slave bus slv_* and the control_w DCS-run bit); wg1_sdram; wg1_loader.
//   * The Cruis'n DCS 2K subsystem (cusa_dcs_subsystem) is REPLACED by wg1_dcs2 (ADSP-2115 stereo, 2 MB DDR3 DRAM,
//     host mailbox); its C5 memory port is the DCS DDR mux client. dcs2 boot ROM u2 arrives on ioctl index 2.
//   * The I/O ASIC (wg1_ioasic + its PIC) sits on the 0x990000 slave socket; the IDE task file (wg1_ide) on the
//     0x9a0000 socket, its disk backed by the hps_io sd_* block device (VDNUM slot). The I/O ASIC drives the DCS2
//     host mailbox (C2) and the DCS reset.
//   * DELETED Cruis'n-only pieces: the wheel/pedal ADC, gm1_wheel_motor, gm1_rumble, gm1_cmos_shadow (War Gods NVRAM
//     lives in the I/O ASIC PIC; its save/restore is wg1_pic_nvio, 2026-09-27), the game-select byte, the status mirror and HDMI status screen. The
//     control-signal ports for those are gone.
//   * wg1-r14: gm1_dedither is BACK (shared as-is from bandwidth/gm1/rtl, gate bandwidth/gm1/dither/check_dedither.py),
//     at the donor's point: directly on the gm1_fb_present stream, before vga_*; dither_mode = OSD O67 (wg1_emu.sv).
//   * 2026-09-24: a wg1-specific status mirror (wg1_status_mirror.sv, 4th DDR client) is back ONLY under the macro
//     WG1_DIAG_MIRROR (cabinet diagnostic build); without it the core is the 3-client design unchanged.
//   * DCS reset combine (gospel): BOTH control_w bit 1 (midvunit.cpp:238 m_dcs->reset_w(BIT(control,1))) and the I/O
//     ASIC SOUNDCTL bit 0 (midwayic.cpp:1194 m_dcs->reset_w(newreg&1)) drive the same reset_w level; modelled here as
//     last-writer-wins. Cold power-on holds the DSP in reset until the game writes run. FLAG: main session to ratify.
//   P0019 single clock + clock-enable and P0022 power-on capture reset are kept from the donor (por gates the loader,
//   the DDR mux/adapter, wg1_dcs2's por; the CPU/video run on the game reset).
module wg1_core #(
    parameter [31:0] REGION_BASE      = 32'h38000000,   // V-unit framebuffer / texture / palette region in DDR3
    parameter [31:0] DCS_MEM_BASE     = 32'h39000000,   // wg1_dcs2 C5 window (3 MiB): sample DRAM + PM/DM SRAM + boot ROM
    parameter integer WIDTH=512, HEIGHT=400, H_TOTAL=666, V_TOTAL=432,
    parameter integer H_SYNC_START=526, H_SYNC_END=551, V_SYNC_START=401, V_SYNC_END=404,
    parameter integer PIXEL_DIVIDER=3,
    parameter integer MIRROR_PERIOD    = 5_000_000      // WG1_DIAG_MIRROR builds: status block every 100 ms at 50 MHz
) (
    input  wire        clk,
    input  wire        por,               // power-on (P0022 capture domain)
    input  wire        core_reset,        // OSD/main reset: resets the GAME (see game reset block); capture path stays on por

    // ROM delivery (MRA): index 1 = u41 boot image (wg1_loader -> SDRAM), index 2 = u2 DCS boot ROM (wg1_dcs2 loader)
    input  wire        ioctl_download,
    input  wire        ioctl_wr,
    input  wire [26:0] ioctl_addr,
    input  wire [15:0] ioctl_dout,
    input  wire [15:0] ioctl_index,
    output wire        ioctl_wait,
    // PIC NVRAM save/restore (MRA <nvram index="4" size="256"/>; ioasic/rtl/wg1_pic2.sv wg1_pic_nvio)
    input  wire        ioctl_upload,
    output wire [15:0] ioctl_din,
    output wire        nvram_upload_req,

    input  wire [64:0] mister_rtc,        // hps_io RTC -> I/O ASIC PIC clock

    input  wire        DDRAM_BUSY,
    input  wire        DDRAM_DOUT_READY,
    input  wire [63:0] DDRAM_DOUT,
    output wire [28:0] DDRAM_ADDR,
    output wire [7:0]  DDRAM_BURSTCNT,
    output wire [7:0]  DDRAM_BE,
    output wire [63:0] DDRAM_DIN,
    output wire        DDRAM_RD,
    output wire        DDRAM_WE,

    inout  wire [15:0] SDRAM_DQ,
    output wire [12:0] SDRAM_A,
    output wire [1:0]  SDRAM_BA,
    output wire        SDRAM_DQML, SDRAM_DQMH,
    output wire        SDRAM_nCS, SDRAM_nCAS, SDRAM_nRAS, SDRAM_nWE, SDRAM_CKE,

    // IDE disk over hps_io sd_* block device (VDNUM slot 0, WIDE=1)
    output wire [31:0] sd_lba,
    output wire        sd_rd, sd_wr,
    input  wire        sd_ack,
    input  wire [7:0]  sd_buff_addr,
    input  wire [15:0] sd_buff_dout,
    output wire [15:0] sd_buff_din,
    input  wire        sd_buff_wr,
    input  wire        img_mounted, img_readonly,
    input  wire [63:0] img_size,

    // controls (active-high "pressed"; the I/O ASIC packs them into MAME's active-low port words)
    input  wire [15:0] dips,              // wargods DIPS switch word (MAME default 0xffff)
    input  wire [3:0]  coin,              // coin 1..4
    input  wire [3:0]  start,             // start 1..4
    input  wire        tilt, test_sw, service1, vol_down, vol_up, bill,
    input  wire [9:0]  p1, p2,            // {b6,b5,b4,b3,b2,b1,right,left,down,up}
    input  wire [1:0]  dither_mode,       // r14: 0 MAME, 1 Soft, 2 Dark, 3 Raw (gm1_dedither.sv)

    output wire signed [15:0] audio_l, audio_r,
    output wire        audio_ce,

    output wire        vga_ce, vga_de, vga_hs, vga_vs,
    output wire [7:0]  vga_r, vga_g, vga_b,
    output wire        fault,

    // observability (simulation)
    output wire        loader_done,
    output wire        dcs_rom_loaded,
    output wire        game_running,
    output wire [63:0] instructions,
    output wire [23:0] cpu_pc,
    output wire [31:0] presented_frames,
    output wire [23:0] boot_pc_o
);
    // ================= ROM capture: maindata (u41) -> SDRAM =================
    wire        md_wait, md_seen, md_closed, md_size_ok;
    wire        l_req, l_ack;
    wire [24:0] l_baddr;
    wire [31:0] l_wdata, md_words, md_crc, md_dropped;
    wire [23:0] boot_pc;
    assign boot_pc_o = boot_pc;

    wg1_loader u_loader (
        .clk(clk), .por(por), .core_reset(core_reset),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index), .ioctl_dout(ioctl_dout),
        .ioctl_wait(md_wait),
        .l_req(l_req), .l_baddr(l_baddr), .l_wdata(l_wdata), .l_ack(l_ack),
        .done(loader_done), .boot_pc(boot_pc), .words_loaded(md_words), .stream_crc(md_crc),
        .dropped_halfwords(md_dropped), .stream_seen(md_seen), .stream_closed(md_closed), .size_ok(md_size_ok),
        .reset_during_download(),
        .seed_words(), .seed_dropped(), .seed_complete()   // War Gods sends no CMOS seed (NVRAM is in the PIC)
    );

    wire        sd_req, sd_we, sd_burst, sdram_ack, sd_map_fault;
    wire [23:0] sd_addr;
    wire [31:0] sd_wdata, sd_rdata;
    wg1_sdram u_sdram (
        .clk(clk), .por(por), .loader_owns(!loader_done),
        .l_req(l_req), .l_baddr(l_baddr), .l_wdata(l_wdata), .l_ack(l_ack),
        .sd_req(sd_req), .sd_we(sd_we), .sd_burst(sd_burst), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sdram_ack), .sd_rdata(sd_rdata), .map_fault(sd_map_fault),
        .SDRAM_DQ(SDRAM_DQ), .SDRAM_A(SDRAM_A), .SDRAM_BA(SDRAM_BA), .SDRAM_DQML(SDRAM_DQML), .SDRAM_DQMH(SDRAM_DQMH),
        .SDRAM_nCS(SDRAM_nCS), .SDRAM_nCAS(SDRAM_nCAS), .SDRAM_nRAS(SDRAM_nRAS), .SDRAM_nWE(SDRAM_nWE), .SDRAM_CKE(SDRAM_CKE)
    );

    // ================= game reset and configuration (P0022; both ROM captures must land) =================
    reg  game_reset, initializing;
    wire engine_configured;
    wire all_configured = engine_configured;
    // 2026-09-24 (cabinet: "Reset doesn't work"): the OSD / MiSTer reset now resets the GAME (CPU, board, I/O ASIC,
    // IDE task file, DCS2) -- 2-FF synced and stretched to 2^16 clocks (1.3 ms). The ROM capture / loader / SDRAM path
    // stays on por only (P0022), so a reset never re-downloads or disturbs the loaded ROMs or the mounted disk.
    (* altera_attribute="-name SYNCHRONIZER_IDENTIFICATION FORCED_IF_ASYNCHRONOUS" *)
    reg  [1:0]  ureset_sync = 2'b00;
    reg  [15:0] ureset_hold = 16'd0;
    always @(posedge clk) begin
        ureset_sync <= {ureset_sync[0], core_reset};
        if (por) ureset_hold <= 16'd0;
        else if (ureset_sync[1]) ureset_hold <= 16'hFFFF;
        else if (ureset_hold != 16'd0) ureset_hold <= ureset_hold - 16'd1;
    end
    wire user_reset = ureset_sync[1] || (ureset_hold != 16'd0);
    always @(posedge clk) begin
        if (por) begin
            game_reset <= 1'b1; initializing <= 1'b1;
        end else begin
            game_reset <= !(loader_done && dcs_rom_loaded) || user_reset;
            if (game_reset) initializing <= 1'b1;
            else if (all_configured) initializing <= 1'b0;
        end
    end
    wire config_valid = initializing && !game_reset;
    wire config_safe  = initializing;
    assign game_running = !game_reset && !initializing;

    // ================= DDR mux + adapter (3 clients; 4 with the WG1_DIAG_MIRROR status mirror) =================
`ifdef WG1_DIAG_MIRROR
`ifndef WG1_NO_C2_REC
    // + the C2 event recorder (rtl/wg1_c2_rec.sv) as a 5th, non-urgent client
    localparam integer CLIENTS = 5;
    localparam integer ENGINE = 0, SCAN = 1, DCS = 2, MIRROR = 3, C2REC = 4;
    localparam [CLIENTS-1:0] URGENT = 5'b00110;
`else
    localparam integer CLIENTS = 4;
    localparam integer ENGINE = 0, SCAN = 1, DCS = 2, MIRROR = 3;
    localparam [CLIENTS-1:0] URGENT = 4'b0110;                        // SCAN + DCS urgent; the mirror is not
`endif
`else
    localparam integer CLIENTS = 3;
    localparam integer ENGINE = 0, SCAN = 1, DCS = 2;
    localparam [CLIENTS-1:0] URGENT = 3'b110;                         // SCAN + DCS urgent
`endif
    wire [CLIENTS-1:0]    cr, cw, cv, ce_re, cwait;
    wire [CLIENTS*32-1:0] ca;
    wire [CLIENTS*64-1:0] cd, rd;
    wire [CLIENTS*8-1:0]  cb;
    wire [CLIENTS*4-1:0]  cc;
    wire        ar, aw, awaitrequest, avalid, aerror;
    wire [31:0] aa;
    wire [63:0] ad, ard;
    wire [7:0]  ab;
    wire [3:0]  ac;
    wire [2:0]  mux_fault, adapter_fault;
    wire [9:0]  mux_info;

`ifndef WG1_DDR_SERIAL
    // 2026-09-26 speed: the pipelined DDRAM share (rtl/wg1_ddr_port.sv) -- up to 8 read bursts outstanding, one command
    // per clock, posted writes. WG1_DDR_SERIAL (simulation A/B only) rebuilds the one-transaction mux + adapter pair.
    assign ar = 1'b0; assign aw = 1'b0; assign aa = 32'd0; assign ad = 64'd0; assign ab = 8'd0; assign ac = 4'd0;
    assign awaitrequest = 1'b1; assign avalid = 1'b0; assign ard = 64'd0; assign aerror = 1'b0;
    assign adapter_fault = 3'd0;
    wire [4:0] ddr_reads_in_flight;
    wg1_ddr_port #(.CLIENTS(CLIENTS), .DEPTH(8)) shared_mux (
        .clk(clk), .cold_reset(por),
        .client_read(cr), .client_write(cw), .client_urgent(URGENT),
        .client_address(ca), .client_writedata(cd), .client_byteenable(cb), .client_burstcount(cc),
        .client_waitrequest(cwait), .client_readdatavalid(cv), .client_read_error(ce_re), .client_readdata(rd),
        .DDRAM_BUSY(DDRAM_BUSY), .DDRAM_DOUT_READY(DDRAM_DOUT_READY), .DDRAM_DOUT(DDRAM_DOUT),
        .DDRAM_ADDR(DDRAM_ADDR), .DDRAM_BURSTCNT(DDRAM_BURSTCNT), .DDRAM_DIN(DDRAM_DIN), .DDRAM_BE(DDRAM_BE),
        .DDRAM_RD(DDRAM_RD), .DDRAM_WE(DDRAM_WE),
        .fault_code(mux_fault), .fault_info(mux_info), .reads_in_flight(ddr_reads_in_flight));
`else
    avalon_shared_mux #(.CLIENTS(CLIENTS)) shared_mux (
        .clk(clk), .cold_reset(por), .quiesce_request(1'b0), .quiesced(),
        .client_read(cr), .client_write(cw), .client_urgent(URGENT),
        .client_address(ca), .client_writedata(cd), .client_byteenable(cb), .client_burstcount(cc),
        .client_waitrequest(cwait), .client_readdatavalid(cv), .client_read_error(ce_re), .client_readdata(rd),
        .avm_read(ar), .avm_write(aw), .avm_address(aa), .avm_writedata(ad), .avm_byteenable(ab), .avm_burstcount(ac),
        .avm_waitrequest(awaitrequest), .avm_readdatavalid(avalid), .avm_readdata(ard), .avm_read_error(aerror),
        .fault_code(mux_fault), .fault_info(mux_info));
    mister_ddram_adapter ddram_adapter (
        .clk(clk), .reset(por), .quiesce_request(1'b0), .backend_quiesced(),
        .avm_read(ar), .avm_write(aw), .avm_address(aa), .avm_writedata(ad), .avm_byteenable(ab), .avm_burstcount(ac),
        .avm_waitrequest(awaitrequest), .avm_readdatavalid(avalid), .avm_readdata(ard), .avm_read_error(aerror),
        .DDRAM_BUSY(DDRAM_BUSY), .DDRAM_DOUT_READY(DDRAM_DOUT_READY), .DDRAM_DOUT(DDRAM_DOUT),
        .DDRAM_ADDR(DDRAM_ADDR), .DDRAM_BURSTCNT(DDRAM_BURSTCNT), .DDRAM_DIN(DDRAM_DIN), .DDRAM_BE(DDRAM_BE),
        .DDRAM_RD(DDRAM_RD), .DDRAM_WE(DDRAM_WE), .fault_code(adapter_fault));
`endif

    // ================= engine (C31, memory tier, V-unit, slave bus) =================
    wire        ctl_dcs_run, ctl_dcs_strobe;
    wire [63:0] guest_tick;
    wire        engine_halted, ext_unmapped_seen, int0_seen, game_display_page;
    wire [7:0]  memory_fault, vunit_fault, cpu_fault;
    wire [14:0] present_pal_addr;
    wire [15:0] present_pal_word;
    wire [95:0] render_diag;
    wire [255:0] perf_diag;
    wire [31:0] xf1_copies;
    wire        protect_page, protected_page;

    // ---- C1 slave bus + C2 mailbox wires ----
    wire        slv_valid, slv_write, slv_sync, slv_guest_ce;
    wire [23:0] slv_addr;
    wire [31:0] slv_wdata;
    wire        io_hit, io_ready, io_wait;   wire [31:0] io_rdata;
    wire        ide_hit, ide_ready, ide_wait; wire [31:0] ide_rdata;

    wg1_engine engine (
        .clk(clk), .reset(game_reset), .por(por), .guest_run_enable(game_running), .boot_pc(boot_pc),
        .sd_req(sd_req), .sd_we(sd_we), .sd_burst(sd_burst), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sdram_ack), .sd_rdata(sd_rdata),
        .slv_valid(slv_valid), .slv_write(slv_write), .slv_sync(slv_sync), .slv_guest_ce(slv_guest_ce),
        .slv_addr(slv_addr), .slv_wdata(slv_wdata),
        .io_hit(io_hit), .io_ready(io_ready), .io_wait(io_wait), .io_rdata(io_rdata),
        .ide_hit(ide_hit), .ide_ready(ide_ready), .ide_wait(ide_wait), .ide_rdata(ide_rdata),
        .ctl_dcs_run(ctl_dcs_run), .ctl_dcs_strobe(ctl_dcs_strobe),
        .config_valid(config_valid), .config_ready(),
        .config_fb_base(REGION_BASE + 32'h00100000), .config_texture_base(REGION_BASE + 32'h00200000),
        .config_palette_base(REGION_BASE + 32'h00600000),
        .backend_quiesced(config_safe), .backend_reset_request(), .memory_configured(engine_configured),
        .avm_read(cr[ENGINE]), .avm_write(cw[ENGINE]), .avm_address(ca[ENGINE*32+:32]), .avm_writedata(cd[ENGINE*64+:64]),
        .avm_byteenable(cb[ENGINE*8+:8]), .avm_burstcount(cc[ENGINE*4+:4]),
        .avm_waitrequest(cwait[ENGINE]), .avm_readdatavalid(cv[ENGINE]), .avm_readdata(rd[ENGINE*64+:64]),
        .avm_read_error(ce_re[ENGINE]),
        .protect_page(protect_page), .protected_page(protected_page),
        .present_pal_addr(present_pal_addr), .present_pal_word(present_pal_word), .native_frames(presented_frames),
        .halted(engine_halted), .memory_fault(memory_fault), .memory_fault_address(),
        .vunit_fault(vunit_fault), .cpu_fault(cpu_fault), .cpu_pc(cpu_pc), .instructions(instructions),
        .guest_tick(guest_tick), .ext_unmapped_seen(ext_unmapped_seen), .int0_seen(int0_seen),
        .display_page(game_display_page), .render_diag(render_diag), .perf_diag(perf_diag), .xf1_copies(xf1_copies)
    );

    // ================= I/O ASIC (0x990000-0x99000f) + its DCS2 host mailbox (C2) =================
    wire        dcs_reset_io, dcs_data_we, dcs_ack_we, dcs_data_rd, dcs_fifo_rd, dcs_fifo_reset_w;
    wire [15:0] dcs_data_w, dcs_fifo_q, dcs_fifo_status;
    wire [15:0] dcs_data_r, dcs_data2_r, dcs_control;
    wire        dcs_output_full, dcs_input_empty;

    wire        nv_dl_we, nv_written, nv_ul_active;     // PIC NVRAM save/restore (wg1_pic_nvio below)
    wire [6:0]  nv_dl_word, nv_ul_word;
    wire [15:0] nv_dl_data, nv_ul_data;
    wg1_ioasic u_ioasic (
        .clk(clk), .reset(game_reset),
        .bus_valid(slv_valid), .bus_write(slv_write), .bus_sync(slv_sync),
        .bus_addr(slv_addr), .bus_wdata(slv_wdata),
        .hit(io_hit), .ready(io_ready), .rdata(io_rdata), .guest_wait(io_wait),
        .dips(dips), .coin(coin), .start(start),
        .tilt(tilt), .test_sw(test_sw), .service1(service1), .vol_down(vol_down), .vol_up(vol_up), .bill(bill),
        .p1(p1), .p2(p2), .mister_rtc(mister_rtc),
        .dcs_reset(dcs_reset_io), .dcs_data_we(dcs_data_we), .dcs_data_w(dcs_data_w),
        .dcs_ack_we(dcs_ack_we), .dcs_data_rd(dcs_data_rd),
        .fifo_rd(dcs_fifo_rd), .fifo_reset_w(dcs_fifo_reset_w), .fifo_q(dcs_fifo_q), .fifo_status(dcs_fifo_status),
        .dcs_data_r(dcs_data_r), .dcs_data2_r(dcs_data2_r), .dcs_control(dcs_control),
        .dcs_output_full(dcs_output_full), .dcs_input_empty(dcs_input_empty),
        .irq(),
        .nv_dl_we(nv_dl_we), .nv_dl_word(nv_dl_word), .nv_dl_data(nv_dl_data),
        .nv_ul_word(nv_ul_word), .nv_ul_data(nv_ul_data), .nv_written(nv_written)
    );

    // PIC NVRAM save/restore over hps_io (index 4; the loader's inherited CMOS seed index 3 is left unused). On por,
    // never the game reset (P0022): the MRA restore stream arrives before the ROM streams, while the game is held.
    // (nets declared above the I/O ASIC instance)
    wg1_pic_nvio #(.INDEX(8'd4)) u_pic_nvio (
        .clk(clk), .por(por),
        .ioctl_download(ioctl_download), .ioctl_upload(ioctl_upload), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index),
        .ioctl_addr(ioctl_addr), .ioctl_dout(ioctl_dout),
        .nv_dl_we(nv_dl_we), .nv_dl_word(nv_dl_word), .nv_dl_data(nv_dl_data),
        .nv_ul_word(nv_ul_word), .ul_active(nv_ul_active), .nv_written(nv_written), .upload_req(nvram_upload_req));
    assign ioctl_din = nv_ul_active ? nv_ul_data : 16'h0000;

    // DCS reset combine (see header): last-writer-wins across control_w bit 1 (ctl_dcs_run/strobe) and the I/O ASIC
    // SOUNDCTL bit 0 (dcs_reset_io level). Init = 1 (run): MAME machine_reset ends with reset_w(1) and the I/O ASIC
    // resets SOUNDCTL bit 0 = 1 (device_start :768, run_q<=1), so the DSP is running entering the game. The DSP's own
    // machine-reset pulse is modelled by wg1_dcs2's `reset` (game_reset) input; this level is the ongoing host reset.
    reg  dcs_run_lvl, io_rst_q;
    always @(posedge clk) begin
        if (por) begin dcs_run_lvl <= 1'b1; io_rst_q <= 1'b1; end
        else begin
            io_rst_q <= dcs_reset_io;
            if (ctl_dcs_strobe)              dcs_run_lvl <= ctl_dcs_run;
            else if (dcs_reset_io != io_rst_q) dcs_run_lvl <= dcs_reset_io;
        end
    end

    // ================= IDE task file (0x9a0000-0x9a0007) over the hps_io block device =================
`ifdef WG1_DIAG_MIRROR
    wire [2:0] ide_dbg;                                  // {hold_fault, late, err} (wg1_ide.sv)
`endif
    wg1_ide u_ide (
        .clk(clk), .reset(game_reset), .guest_ce(slv_guest_ce),
        .bus_valid(slv_valid), .bus_write(slv_write), .bus_sync(slv_sync),
        .bus_addr(slv_addr), .bus_wdata(slv_wdata),
        .hit(ide_hit), .ready(ide_ready), .rdata(ide_rdata), .guest_wait(ide_wait),
        .sd_lba(sd_lba), .sd_rd(sd_rd), .sd_wr(sd_wr), .sd_ack(sd_ack),
        .sd_buff_addr(sd_buff_addr), .sd_buff_dout(sd_buff_dout), .sd_buff_din(sd_buff_din), .sd_buff_wr(sd_buff_wr),
        .img_mounted(img_mounted), .img_readonly(img_readonly), .img_size(img_size)
`ifdef WG1_DIAG_MIRROR
        , .dbg_ide(ide_dbg)                              // observe-only -> status mirror block B word 44/46
`endif
    );

    // ================= DCS2 / ADSP-2115 sound board =================
    wire dcs_unimpl, dcs_ioctl_wait, dsp_retire;
    wire [13:0] dsp_pc;
    wire [31:0] dac_underruns;
    wire [31:0] dcs_bytes, dcs_crc;
`ifdef WG1_DIAG_MIRROR
    wire [111:0] dcs_dbg_mirror;
`endif
`ifdef WG1_DIAG_MIRROR
    wire [4:0]   dcs_dbg_rst;
    wire [36:0]  dcs_dbg_dramw;
`endif
    wg1_dcs2 #(.MEM_BASE(DCS_MEM_BASE), .ROM_INDEX(8'd2)) u_dcs2 (
        .clk(clk), .por(por), .reset(game_reset),
        .dcs_reset(dcs_run_lvl), .dcs_data_we(dcs_data_we), .dcs_data_w(dcs_data_w),
        .dcs_ack_we(dcs_ack_we), .dcs_data_rd(dcs_data_rd),
        .dcs_data_r(dcs_data_r), .dcs_data2_r(dcs_data2_r), .dcs_control(dcs_control),
        .dcs_output_full(dcs_output_full), .dcs_input_empty(dcs_input_empty),
        .fifo_rd(dcs_fifo_rd), .fifo_reset_w(dcs_fifo_reset_w), .fifo_q(dcs_fifo_q), .fifo_status(dcs_fifo_status),
        .ioctl_download(ioctl_download), .ioctl_wr(ioctl_wr), .ioctl_index(ioctl_index), .ioctl_dout(ioctl_dout),
        .ioctl_wait(dcs_ioctl_wait),
        .m_read(cr[DCS]), .m_write(cw[DCS]), .m_address(ca[DCS*32+:32]), .m_writedata(cd[DCS*64+:64]),
        .m_byteenable(cb[DCS*8+:8]), .m_waitrequest(cwait[DCS]), .m_readdatavalid(cv[DCS]), .m_readdata(rd[DCS*64+:64]),
        .audio_l(audio_l), .audio_r(audio_r), .audio_ce(audio_ce),
        .rom_loaded(dcs_rom_loaded), .rom_bytes(dcs_bytes), .rom_crc(dcs_crc), .rom_reset_during_download(),
        .dac_underruns(dac_underruns), .dsp_pc(dsp_pc), .cfg_unsupported(dcs_unimpl),
        .gate_mode(1'b0), .dsp_hold(1'b0), .inj_tick(1'b0), .inj_sport0(1'b0), .inj_timer(1'b0),
        .inj_irq2_up(1'b0), .inj_irq2_dn(1'b0),
        .dbg_insn_start(), .dbg_retire(dsp_retire), .dbg_regs(), .dbg_irq_state(), .dbg_boot_busy(),
        .dbg_at_boundary(), .dbg_dm_we(), .dbg_dm_addr(), .dbg_dm_wdata()
`ifdef WG1_DIAG_MIRROR
        , .dbg_mirror(dcs_dbg_mirror)                    // observe-only taps -> status mirror block B
`endif
`ifdef WG1_DIAG_MIRROR
        , .dbg_rst(dcs_dbg_rst), .dbg_dramw(dcs_dbg_dramw) // observe-only -> C2 event recorder
`endif
    );
    assign cc[DCS*4+:4] = 4'd1;                          // C5 is single-beat
    assign ioctl_wait = md_wait || dcs_ioctl_wait;

    // ================= framebuffer presentation (physical video) =================
    wire        pres_ce, pres_de, pres_hs, pres_vs;
    wire [7:0]  pres_r, pres_g, pres_b;
    wire [7:0]  presentation_fault;
    wire        presentation_halted = presentation_fault != 8'd0;
    gm1_fb_present #(.WIDTH(WIDTH), .HEIGHT(HEIGHT), .H_TOTAL(H_TOTAL), .V_TOTAL(V_TOTAL),
        .H_SYNC_START(H_SYNC_START), .H_SYNC_END(H_SYNC_END), .V_SYNC_START(V_SYNC_START), .V_SYNC_END(V_SYNC_END),
        .PIXEL_DIVIDER(PIXEL_DIVIDER), .BURST_BEATS(8)) presentation (
        .clk(clk), .reset(game_reset), .enable(game_running),
        .fb_base(REGION_BASE + 32'h00100000), .display_page(game_display_page),
        .protect_page(protect_page), .protected_page(protected_page),
        .pal_addr(present_pal_addr), .pal_word(present_pal_word),
        .scan_read(cr[SCAN]), .scan_address(ca[SCAN*32+:32]), .scan_byteenable(cb[SCAN*8+:8]), .scan_burstcount(cc[SCAN*4+:4]),
        .scan_waitrequest(cwait[SCAN]), .scan_readdatavalid(cv[SCAN]), .scan_readdata(rd[SCAN*64+:64]), .scan_read_error(ce_re[SCAN]),
        .video_ce(pres_ce), .video_de(pres_de), .video_hsync(pres_hs), .video_vsync(pres_vs),
        .video_r(pres_r), .video_g(pres_g), .video_b(pres_b),
        .underrun_pixels(), .physical_frames(), .scan_fault(presentation_fault));
    assign cw[SCAN] = 1'b0; assign cd[SCAN*64+:64] = 64'd0;
    // r14: smart de-dither of the 50% black mesh panels, exactly as gm1_core (gm1_dedither.sv, gate
    // bandwidth/gm1/dither/check_dedither.py). Output = presentation stream delayed two ce; RAW = pixel-exact.
    // PIXEL_DIVIDER=3 keeps ce >= 3 clocks apart, which the module's registered previous-line read relies on.
    assign vga_ce = pres_ce;
    gm1_dedither u_dedither (.clk(clk), .ce(pres_ce), .mode(dither_mode),
        .de_i(pres_de), .hs_i(pres_hs), .vs_i(pres_vs), .r_i(pres_r), .g_i(pres_g), .b_i(pres_b),
        .de_o(vga_de), .hs_o(vga_hs), .vs_o(vga_vs), .r_o(vga_r), .g_o(vga_g), .b_o(vga_b));

`ifdef WG1_DIAG_MIRROR
    // ================= cabinet diagnostic: status block -> DDR3 0x38700000 (wg1_status_mirror.sv header) =================
    // Read on the MiSTer with tools/diag/wg1_diag.sh (busybox devmem). BASE audit: fb/texture/palette end at 0x3861FFFF,
    // DCS2 C5 starts at 0x39000000 -- the 192-byte block collides with neither.
    wire dsp_running = dcs_run_lvl && dcs_rom_loaded && !game_reset;
    wg1_status_mirror #(.BASE(REGION_BASE + 32'h00700000), .PERIOD(MIRROR_PERIOD)) status_mirror (
        .clk(clk), .por(por), .enable(1'b1),
        .instructions(instructions), .guest_tick(guest_tick),
        .retire_pc(perf_diag[87:64]), .cpu_pc(cpu_pc),
        .c31_st(perf_diag[255:224]), .c31_ie(perf_diag[223:192]), .c31_if(perf_diag[191:160]), .c31_iof(perf_diag[159:128]),
        .int0_count(perf_diag[127:96]), .presented_frames(presented_frames), .xf1_copies(xf1_copies),
        .flags({game_running, loader_done, dcs_rom_loaded, int0_seen, fault, ext_unmapped_seen, engine_halted,
                io_wait || ide_wait}),
        .faults({cpu_fault, memory_fault, vunit_fault, mux_fault, adapter_fault, sd_map_fault, dcs_unimpl}),
        .md_words(md_words),
        .bus_valid(slv_valid), .bus_write(slv_write), .bus_sync(slv_sync), .bus_addr(slv_addr), .bus_wdata(slv_wdata),
        .ide_hit(ide_hit), .ide_ready(ide_ready), .ide_wait(ide_wait), .ide_rdata(ide_rdata[15:0]),
        .io_hit(io_hit), .io_ready(io_ready), .io_rdata(io_rdata[15:0]),
        .sd_lba(sd_lba), .sd_rd(sd_rd), .sd_wr(sd_wr), .sd_ack(sd_ack), .sd_buff_wr(sd_buff_wr),
        .img_mounted(img_mounted), .img_readonly(img_readonly), .img_size(img_size),
        .dcs_run(dcs_run_lvl), .dcs_reset_io(dcs_reset_io), .dcs_output_full(dcs_output_full),
        .dcs_input_empty(dcs_input_empty), .dcs_rom_loaded(dcs_rom_loaded), .dcs_cfg_unsupported(dcs_unimpl),
        .dsp_running(dsp_running),
        .dcs_data_we(dcs_data_we), .dcs_data_rd(dcs_data_rd), .dcs_ack_we(dcs_ack_we), .dsp_retire(dsp_retire),
        .dsp_pc(dsp_pc), .dcs_control(dcs_control), .dcs_data_r(dcs_data_r), .dac_underruns(dac_underruns),
        .dcs_data_w(dcs_data_w), .dcs_dbg(dcs_dbg_mirror),
        .eng_wait((cr[ENGINE] || cw[ENGINE]) && cwait[ENGINE]), .dcs_wait((cr[DCS] || cw[DCS]) && cwait[DCS]),
        .poly_commit(perf_diag[1]), .rbusy(perf_diag[0]), .display_page(game_display_page),
        .ide_hold_fault(ide_dbg[2]), .ide_late(ide_dbg[1]), .ide_err(ide_dbg[0]), .adj_we(perf_diag[34]), .adj_wd(perf_diag[33:2]),
        .write(cw[MIRROR]), .address(ca[MIRROR*32+:32]), .writedata(cd[MIRROR*64+:64]),
        .byteenable(cb[MIRROR*8+:8]), .burstcount(cc[MIRROR*4+:4]), .waitrequest(cwait[MIRROR]));
    assign cr[MIRROR] = 1'b0;
`ifndef WG1_NO_C2_REC
    // ================= cabinet diagnostic: C2 event ring -> DDR3 0x39400000 (header 0x393FF000, 32 MB to 0x3B3FFFFF), wg1_c2_rec.sv =========
    // BASE audit: DCS2 C5 ends at 0x392FFFFF, the status mirror sits at 0x38700000 -> no collision. Reader
    // diag/wg1_c2_dump.sh, decoder/replay diag/c2_ring_decode.py -> tests/vs_ladder.
    wg1_c2_rec c2_rec (
        .clk(clk), .por(por),
        .bus_valid(slv_valid), .bus_write(slv_write), .bus_sync(slv_sync), .bus_addr(slv_addr), .bus_wdata(slv_wdata),
        .io_hit(io_hit), .io_ready(io_ready),
        .ctl_strobe(ctl_dcs_strobe), .ctl_run(ctl_dcs_run), .dcs_reset_io(dcs_reset_io), .dcs_run_lvl(dcs_run_lvl),
        .dcs_data_we(dcs_data_we), .dcs_ack_we(dcs_ack_we), .dcs_data_rd(dcs_data_rd),
        .dcs_data_w(dcs_data_w), .dcs_data_r(dcs_data_r),
        .dsp_retire(dsp_retire), .dsp_pc(dsp_pc), .dcs_dbg(dcs_dbg_mirror),
        .eng_rst(dcs_dbg_rst[4]), .rst_why(dcs_dbg_rst[3:0]), .dramw(dcs_dbg_dramw),
        .write(cw[C2REC]), .address(ca[C2REC*32+:32]), .writedata(cd[C2REC*64+:64]),
        .byteenable(cb[C2REC*8+:8]), .burstcount(cc[C2REC*4+:4]), .waitrequest(cwait[C2REC]));
    assign cr[C2REC] = 1'b0;
`endif
`endif

    assign fault = (mux_fault != 3'd0) || (adapter_fault != 3'd0) || (cpu_fault != 8'd0) || ext_unmapped_seen ||
                   engine_halted || (memory_fault != 8'd0) || (vunit_fault != 8'd0) || presentation_halted ||
                   sd_map_fault || dcs_unimpl;
endmodule
`default_nettype wire
