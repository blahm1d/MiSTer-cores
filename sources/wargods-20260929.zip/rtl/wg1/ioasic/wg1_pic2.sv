// wg1_pic2.sv -- Midway serial PIC 2 (security serial number, clock, 256-byte NVRAM) behind the War Gods I/O ASIC.
// Transcribed from MAME 0.289 williams/midwayic.cpp: status_r :418-437, read :440-459, write :462-632,
// nvram_default :634-637. midway_ioasic_device IS-A midway_serial_pic2_device (:702-703); PICOUT/PICIN reach it
// through the ASIC (:1092-1093, :1222-1228).
// FORK (wg1 War Gods core, 2026-09-24) of D:/deck/fpga/cruisinusa/bandwidth/gm1/rtl/gm1_pic2.sv
// (md5 b573c40c82cdd411d8369e6c802faf71; itself a fork of zeus/zeus1/rtl/board/zk4_pic2.sv). Changes:
//   * NVRAM power-on contents = init_wargods' default (midvunit.cpp:2244-2257): 0xFF everywhere except
//     0x0e/0x2e=0x67, 0x0f/0x2f=0x32, 0x10/0x30=0x0a, 0x11/0x31=0x00, 0x12/0x32=0xaf, 0x17/0x37=0xd8, 0x18/0x38=0xe7
//     (MAME applies it when no nvram file exists: device_nvram_interface -> nvram_default :634-637).
//   * serial bytes stay the runtime input `ser` (generate_serial_data is computed in wg1_ioasic.sv).
// Time: the latch's data-ready flag expires 1 ms after a write (:472, :427); a written clock is parroted back for
// 500 ms (:559-560). Both measured in clk periods of CLK_HZ.
// Interface: pic_wr (one clk, PICOUT write, byte), pic_rd (one clk, PICIN read: returns {status, data} and applies
// status_r's side effect), rtc the clock bytes in MAME's shape (BCD sec, min, hour, weekday+1, mday, month+1,
// year-1900-yearoffs).
// NVRAM persistence (2026-09-27): MAME saves m_nvram[0x100] raw as nvram/wargods/ioasic (device_nvram_interface,
// nvram_read/nvram_write :639-649); the real board keeps it across power-off. Measured on MAME 0.289
// (H:/temp/wargods/nvram): War Gods writes 0x0e = master volume (Volume Up/Down), 0x11 = credits (each coin),
// 0x12 = check byte (0x0e^0x0f^0x10^0x11^0x12 = 0xF0), 0x09-0x0d = a clock-derived record every ~45 s, each mirrored
// at +0x20; a restored file is used by the next boot (volume and credits carry over). MiSTer path: the MRA
// <nvram index="4" size="256"/> restore stream (nv_dl_*) and the hps_io upload (nv_ul_*), one 16-bit ioctl word =
// bytes {2k+1, 2k} (file order, little-endian). Storage is BYTE-WIDE only (even/odd banks, full-word writes of each
// bank; never a part-select into a wider RAM -- the T/Wolf WIDTH_BYTEENA=1 lesson), plus a save copy with the same
// writes so the upload never shares the game's read port. The restore path is not gated by rst (the game reset):
// the stream lands whatever the CPU is doing (P0022).
module wg1_pic2 #(
  parameter int          CLK_HZ = 50_000_000
) (
  input  logic        clk, rst,
  input  logic [127:0] ser,                                   // generate_serial_data bytes, byte i at [8*i +: 8]
  input  logic        pic_wr, input logic [7:0] pic_wdata,
  input  logic        pic_rd, output logic [15:0] pic_rdata,   // {7'b0, status, data} (ioasic PICIN, :1093)
  input  logic [7:0]  rtc0, rtc1, rtc2, rtc3, rtc4, rtc5, rtc6,
  // NVRAM restore / save (see header)
  input  logic        nv_dl_we,                               // one clk: restore word k = {byte 2k+1, byte 2k}
  input  logic [6:0]  nv_dl_word,
  input  logic [15:0] nv_dl_data,
  input  logic [6:0]  nv_ul_word,                             // save read: word index
  output logic [15:0] nv_ul_data,                             // registered (1 clk): {byte 2k+1, byte 2k}
  output logic        nv_written                              // one clk: the game wrote an NVRAM byte (cmd 5)
);
  // ---------------- state ----------------
  localparam int MS = CLK_HZ / 1000;
  logic [11:0] latch;
  logic [$clog2(MS+1)-1:0] l_age; logic l_expired;                // clocks since the last write, saturating at 1 ms
  logic [7:0]  st;
  logic [4:0]  idx, tot;
  logic [7:0]  buffer [16];
  logic [7:0]  time_buf [7]; logic [2:0] tidx;
  logic        tjw; logic [$clog2(500*MS+1)-1:0] tjw_cnt;          // time_just_written, 500 ms
  logic [7:0]  nv_addr;
  logic [7:0]  rtc [7];
  assign rtc[0] = rtc0; assign rtc[1] = rtc1; assign rtc[2] = rtc2; assign rtc[3] = rtc3;
  assign rtc[4] = rtc4; assign rtc[5] = rtc5; assign rtc[6] = rtc6;
  // NVRAM: 256 x 8 as two byte-wide banks (even / odd address), each 128 x 8 with one write port and a registered
  // read (M10K / MLAB shape); sv_* = the save copy (same writes, read only by the upload). Power-on = init_wargods
  // default (MAME nvram_default :634-637 when no file exists; the MRA restore overwrites it when one does).
  logic        nv_we; logic [7:0] nv_wa, nv_wd, nv_ra, nv_q;
  logic [7:0]  nv_e [128], nv_o [128], sv_e [128], sv_o [128];
  // byte a lives in bank a[0] at index a[7:1]
  initial begin
    for (int i = 0; i < 128; i++) begin                          // memset(default_nvram, 0xff) midvunit.cpp:2247
      nv_e[i] = 8'hFF; nv_o[i] = 8'hFF; sv_e[i] = 8'hFF; sv_o[i] = 8'hFF;
    end
    for (int m = 0; m < 32; m += 16) begin                       // 0x0e..0x18 and the +0x20 mirrors, :2248-2254
      nv_e[m + 7]  = 8'h67; sv_e[m + 7]  = 8'h67;                // 0x0e / 0x2e
      nv_o[m + 7]  = 8'h32; sv_o[m + 7]  = 8'h32;                // 0x0f / 0x2f
      nv_e[m + 8]  = 8'h0a; sv_e[m + 8]  = 8'h0a;                // 0x10 / 0x30
      nv_o[m + 8]  = 8'h00; sv_o[m + 8]  = 8'h00;                // 0x11 / 0x31
      nv_e[m + 9]  = 8'haf; sv_e[m + 9]  = 8'haf;                // 0x12 / 0x32
      nv_o[m + 11] = 8'hd8; sv_o[m + 11] = 8'hd8;                // 0x17 / 0x37
      nv_e[m + 12] = 8'he7; sv_e[m + 12] = 8'he7;                // 0x18 / 0x38
    end
  end
  // write arbitration: a game write (one clk, from a C31 PICOUT store) wins its clock; a restore word waits in
  // dl_pend for the next free clock (ioctl_wr pulses are >= 3 clocks apart, game writes never back-to-back)
  logic        dl_pend = 1'b0; logic [6:0] dl_w; logic [15:0] dl_d;
  always_ff @(posedge clk) begin
    if (nv_dl_we) begin dl_pend <= 1'b1; dl_w <= nv_dl_word; dl_d <= nv_dl_data; end
    else if (!nv_we) dl_pend <= 1'b0;
  end
  wire         do_dl = dl_pend && !nv_we;
  wire         we_e  = (nv_we && !nv_wa[0]) || do_dl;
  wire         we_o  = (nv_we &&  nv_wa[0]) || do_dl;
  wire  [6:0]  wa_b  = nv_we ? nv_wa[7:1] : dl_w;
  wire  [7:0]  wd_e  = nv_we ? nv_wd : dl_d[7:0];
  wire  [7:0]  wd_o  = nv_we ? nv_wd : dl_d[15:8];
  logic [7:0]  q_e, q_o, sq_e, sq_o; logic ra0;
  always_ff @(posedge clk) begin
    if (we_e) begin nv_e[wa_b] <= wd_e; sv_e[wa_b] <= wd_e; end
    if (we_o) begin nv_o[wa_b] <= wd_o; sv_o[wa_b] <= wd_o; end
    q_e <= nv_e[nv_ra[7:1]]; q_o <= nv_o[nv_ra[7:1]]; ra0 <= nv_ra[0];
    sq_e <= sv_e[nv_ul_word]; sq_o <= sv_o[nv_ul_word];
  end
  assign nv_q       = ra0 ? q_o : q_e;
  assign nv_ul_data = {sq_o, sq_e};
  assign nv_written = nv_we;
  logic        nv_fill, nv_fill2;                                 // read command: address registered, RAM read, then buffer[0]
  // the low nibble written at step 0x35 (the 0x45 step ORs the high nibble onto it, :589 / :595)
  logic [3:0]  nv_lo;
  always_ff @(posedge clk) if (pic_wr && pic_wdata[4] && st == 8'h35) nv_lo <= pic_wdata[3:0];

  assign l_expired = l_age == ($clog2(MS+1))'(MS);
  // read (:440-459) and status_r (:418-437): PICIN = read() | status_r() << 8; read() sees the latch BEFORE
  // status_r's side effect (operands evaluated left to right; checked against MAME's log by the device gate)
  always_comb begin
    logic [7:0] d;
    if (latch[11:8] != 4'd0) d = latch[7:0];
    else if (idx < tot)      d = 8'hFF;
    else                     d = 8'h00;
    pic_rdata = {7'd0, latch[11:8] != 4'd0, d};
  end

  always_ff @(posedge clk)
    if (rst) begin
      latch <= '0; l_age <= '0; st <= '0; idx <= '0; tot <= '0; tidx <= '0; tjw <= 1'b0; tjw_cnt <= '0;
      nv_addr <= '0; nv_we <= 1'b0; nv_fill <= 1'b0; nv_fill2 <= 1'b0; nv_wa <= '0; nv_wd <= '0; nv_ra <= '0;
      for (int i = 0; i < 16; i++) buffer[i] <= 8'h00;
      for (int i = 0; i < 7; i++) time_buf[i] <= 8'h00;
    end else begin
      nv_we <= 1'b0;
      if (!l_expired) l_age <= l_age + 1'b1;
      if (tjw) begin if (tjw_cnt == '0) tjw <= 1'b0; else tjw_cnt <= tjw_cnt - 1'b1; end
      nv_fill2 <= nv_fill; nv_fill <= 1'b0;
      if (nv_fill2) buffer[0] <= nv_q;                           // nv_ra set at the command edge, nv_q one edge later
      if (pic_rd) begin                                          // status_r side effect
        if (latch[11:8] != 4'd0) begin
          if (l_expired) latch <= {4'd0, latch[7:0]};
          else latch <= latch - 12'h100;
        end
      end
      if (pic_wr) begin : wr
        logic [11:0] nl; logic [3:0] cmd;
        nl = {4'h4, 4'h8, pic_wdata[3:0]};                      // (data & 0x00f) | 0x480
        latch <= nl; l_age <= '0;
        cmd = (st != 8'd0) ? st[3:0] : nl[3:0];
        if (pic_wdata[4]) begin
          case (cmd)
            4'd0: if (idx < tot) begin latch <= {4'h4, buffer[idx[3:0]]}; idx <= idx + 1'b1; end
            4'd1: if (idx < tot) begin latch <= {4'h4, buffer[idx[3:0]]}; idx <= idx + 1'b1; end
                  else begin for (int i = 0; i < 16; i++) buffer[i] <= ser[8*i +: 8]; tot <= 5'd16; idx <= '0; end
            4'd3: begin
                    idx <= '0; tot <= 5'd7;
                    for (int i = 0; i < 7; i++) buffer[i] <= tjw ? time_buf[i] : rtc[i];
                  end
            4'd4: if (st == 8'h00) begin st <= 8'h14; tidx <= '0; end
                  else if (st == 8'h14) begin time_buf[tidx] <= {4'd0, nl[3:0]}; st <= 8'h24; end
                  else if (st == 8'h24) begin
                    time_buf[tidx] <= time_buf[tidx] | {nl[3:0], 4'd0};
                    if (tidx + 1'b1 < 3'd7) begin tidx <= tidx + 1'b1; st <= 8'h14; end
                    else begin tidx <= tidx + 1'b1; tjw <= 1'b1; tjw_cnt <= ($clog2(500*MS+1))'(500 * MS); st <= 8'h00; end
                  end
            4'd5: if (st == 8'h00) st <= 8'h15;
                  else if (st == 8'h15) begin nv_addr <= {4'd0, nl[3:0]}; st <= 8'h25; end
                  else if (st == 8'h25) begin nv_addr <= nv_addr | {nl[3:0], 4'd0}; st <= 8'h35; end
                  else if (st == 8'h35) begin nv_we <= 1'b1; nv_wa <= nv_addr; nv_wd <= {4'd0, nl[3:0]}; st <= 8'h45; end
                  else if (st == 8'h45) begin nv_we <= 1'b1; nv_wa <= nv_addr; nv_wd <= {nl[3:0], nv_lo}; st <= 8'h00; end
            4'd6: if (st == 8'h00) st <= 8'h16;
                  else if (st == 8'h16) begin nv_addr <= {4'd0, nl[3:0]}; st <= 8'h26; end
                  else if (st == 8'h26) begin
                    st <= 8'h00; tot <= 5'd1; idx <= '0;
                    nv_ra <= nv_addr | {nl[3:0], 4'd0}; nv_fill <= 1'b1;   // buffer[0] = nvram[addr] next clk
                  end
            4'd8: latch <= {4'h4, ~{4'd0, cmd}};
            default: ;
          endcase
        end
      end
    end
endmodule

// wg1_pic_nvio -- MiSTer hps_io side of the PIC NVRAM save/restore (the upload-request half follows
// cruisinusa/bandwidth/gm1/rtl/gm1_cmos_shadow.sv, cabinet-proven).
//   restore: Main_MiSTer support/arcade/mra_loader.cpp arcade_nvm_load() sends config/nvram/<mra name>.nvm on the MRA
//     <nvram> index when the file exists (FIO download, WIDE=1: ioctl_addr = byte address stepping by 2,
//     ioctl_dout = {byte a+1, byte a}); nothing is sent when it does not (the power-on default stays).
//   save: arcade_nvm_save() (OSD opened with a pending request, menu.cpp MENU_SAVE_CHECK, or OSD "Save settings")
//     uploads nvram_size bytes on the same index; hps_io samples ioctl_din for the current ioctl_addr at each
//     FIO_FILE_TX_DAT strobe (>= 3 clocks after the address moved; the save copy answers in 1).
//   request: a game NVRAM write, then QUIET clocks without one -> one upload_req pulse (hps_io latches the edge and
//     reports it to Main's UIO_CHK_UPLOAD poll; Main saves the next time the OSD opens).
// Everything here runs on the power-on reset (P0022), never the game reset.
module wg1_pic_nvio #(
  parameter logic [7:0]  INDEX = 8'd4,
  parameter logic [31:0] QUIET = 32'd100_000_000                  // 2 s at 50 MHz
) (
  input  logic        clk, por,
  input  logic        ioctl_download, ioctl_upload, ioctl_wr,
  input  logic [15:0] ioctl_index,
  input  logic [26:0] ioctl_addr,
  input  logic [15:0] ioctl_dout,
  output logic        nv_dl_we,
  output logic [6:0]  nv_dl_word,
  output logic [15:0] nv_dl_data,
  output logic [6:0]  nv_ul_word,
  output logic        ul_active,                                   // an upload on INDEX is running (ioctl_din mux)
  input  logic        nv_written,
  output logic        upload_req
);
  wire mine = (ioctl_index[7:0] == INDEX);
  assign nv_dl_we   = ioctl_download && ioctl_wr && mine && (ioctl_addr[26:8] == 19'd0);
  assign nv_dl_word = ioctl_addr[7:1];
  assign nv_dl_data = ioctl_dout;
  assign nv_ul_word = ioctl_addr[7:1];
  assign ul_active  = ioctl_upload && mine;
  logic [31:0] quiet_cnt; logic armed;
  always_ff @(posedge clk)
    if (por) begin quiet_cnt <= '0; armed <= 1'b0; upload_req <= 1'b0; end
    else begin
      upload_req <= 1'b0;
      if (nv_written) begin armed <= 1'b1; quiet_cnt <= '0; end
      else if (armed) begin
        if (quiet_cnt == QUIET) begin armed <= 1'b0; upload_req <= 1'b1; end
        else quiet_cnt <= quiet_cnt + 32'd1;
      end
    end
endmodule
