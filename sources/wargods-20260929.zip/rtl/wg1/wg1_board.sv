`timescale 1ns/1ps
`default_nettype none
// SPDX-License-Identifier: BSD-3-Clause
// wg1_board.sv -- the War Gods (Midway V-unit plus, MAME midvplus) main board in fabric. FORK of
// bandwidth/gm1/rtl/gm1_board.sv (md5 in rtl/FORKED_FROM.md5): same TMS320C31 (c31_core), guest-time gate, V-unit video
// board; the memory tier is the wg1 fork (rtl/mem: 0xc00000-0xcfffff RAM, no CMOS at 0x9c0000).
// midvplus map (MAME 0.289 williams/midvunit.cpp:716-737) vs gm1:
//   0x990000-0x99000f  Midway I/O ASIC            -> exported slave port S_IO   (block wg1/ioasic, CONTRACTS C1)
//   0x994000           control_w (DCS reset bit 1, watchdog bit 3; :236-243) -> c31_peripherals, as gm1
//   0x995020           cmos_protect_w            -> the memory tier's is_cmosprot, as gm1
//   0x9a0000-0x9a0007  ATA cs0, umask32(0x0000ffff) -> exported slave port S_IDE (block wg1/ide, CONTRACTS C1)
//   0x9c0000-0x9c7fff  palette (moved from 0x9e0000) -> remapped onto vunit_board's palette decode (no shared-RTL change)
//   0x9d0000-0x9d000f  midvplus_misc (:587-645)  -> inline below: reads 0 -> 0xb580, 2 -> 0xf3ff, others the stored word
//                                                   (3 = loopback); writes store (0 bit 4 = watchdog pet, not modelled)
//   REMOVED (steering cabinet): 0x991030/0x991060/0x992000 inputs, 0x993000 ADC (INT3 source), 0x995000 wheel board,
//   0x997000 comm link, 0x9a0000 DCS latch, 0x9e0000 palette. No INT3 source remains (MAME midvplus wires no I/O-ASIC
//   IRQ), so irq_int3 = 0 and the guest gate's extra event bound is "none".
// M1b: the C31 XF1 falling-edge 0x20000-word fastram -> main RAM copy (midvunit.cpp:648-657) = wg1_xf1_copy, a bus
// master in front of the memory tier; measured once per cold boot at 26.571 s (gospel/xf1/xf1_report.md).
// Boot as gm1: one load_en pulse loads PC = boot_pc (u41 word 0) with a zero register state.
module wg1_board #(
    parameter integer VUNIT_QUEUE_DEPTH = 270,
    parameter integer WIDTH = 512,
    parameter integer HEIGHT = 400,
    parameter integer PRIVATE_TEXTURE_SERVICE = 2,
    parameter integer REGISTER_VIEW = 0,
    parameter integer RENDER_HOLDS_GUEST = 0,
    parameter integer GUEST_REAL_TIME = 1,
    parameter integer NUM_MAIN_PAGES = 128,
    parameter integer NUM_ROM_PAGES = 32,   // the 0xc00000 RAM cache (fork: writable; 32 pages 4-way, speed step 4)
    parameter integer NOW_BITS = 48
) (
    input  wire         clk,
    input  wire         reset,
    input  wire         por,              // power-on (wg1_xf1_copy's lastval)
    input  wire         run_enable,
    input  wire         bus_run_enable,
    input  wire [23:0]  boot_pc,

    // board SDRAM, C31 word space (wg1_sdram)
    output wire         sd_req,
    output wire         sd_we,
    output wire         sd_burst,
    output wire [23:0]  sd_addr,
    output wire [31:0]  sd_wdata,
    input  wire         sd_ack,
    input  wire [31:0]  sd_rdata,

    // renderer and CPU-memory ports (as gm1_board)
    output wire         fb_valid,
    input  wire         fb_ready,
    output wire [18:0]  fb_addr,
    output wire [15:0]  fb_data,
    output wire         fb_pair,
    output wire [15:0]  fb_data_hi,
    output wire         guest_fb_offer,
    output wire         guest_tex_offer,
    output wire         tex_req_valid,
    input  wire         tex_req_ready,
    output wire [21:0]  tex_req_addr,
    output wire         tex_req_prefetch,
    input  wire         tex_rsp_valid,
    output wire         tex_rsp_ready,
    input  wire [7:0]   tex_rsp_data,
    output wire         tex_req_pair,
    output wire [2:0]   tex_req_off2,
    input  wire [7:0]   tex_rsp_data2,
    output wire [3:0]   tex_req_tag,
    input  wire [3:0]   tex_rsp_tag,
    output wire         cpu_mem_req_valid,
    input  wire         cpu_mem_req_ready,
    output wire         cpu_mem_req_write,
    output wire [1:0]   cpu_mem_req_region,
    output wire [21:0]  cpu_mem_req_addr,
    output wire [31:0]  cpu_mem_req_wdata,
    output wire [3:0]   cpu_mem_req_be,
    input  wire         cpu_mem_rsp_valid,
    output wire         cpu_mem_rsp_ready,
    input  wire [31:0]  cpu_mem_rsp_rdata,
    output wire [9:0]   raster_x,
    output wire [8:0]   raster_y,
    output wire         raster_de, hsync, vsync, csync, pixel_event, frame_event,
    output wire         irq_int0,
    output wire [31:0]  palette_epoch,
    output wire         source_restart,
    output wire         display_page, write_page, queue_nonempty, renderer_busy, queue_full,
    output wire         guest_memory_wait,
    output wire [7:0]   vunit_fault,
    output wire [63:0]  guest_tick,

    // CONTRACTS C1: the shared C31 external-bus request for the exported slaves, and their responses
    output wire         slv_valid, slv_write, slv_sync,
    output wire         slv_guest_ce,     // guest H1 tick (wg1_ide's MAME-time status)
    output wire [23:0]  slv_addr,
    output wire [31:0]  slv_wdata,
    input  wire         io_hit,  io_ready,  io_wait,     // wg1_ioasic (0x990000-0x99000f)
    input  wire [31:0]  io_rdata,
    input  wire         ide_hit, ide_ready, ide_wait,    // wg1_ide    (0x9a0000-0x9a0007)
    input  wire [31:0]  ide_rdata,

    // control_w (0x994000) bit 1: DCS run (the I/O ASIC SOUNDCTL bit 0 is the other reset source; combined in wg1_core)
    output wire         ctl_dcs_run,
    output wire         ctl_dcs_strobe,

    // status
    output wire [7:0]   cpu_fault,
    output wire [23:0]  cpu_pc,
    output reg  [63:0]  instructions,
    output reg          ext_unmapped_seen,
    output reg          int0_seen,
    output wire [95:0]  render_diag,
    output wire [255:0] perf_diag,
    output wire [31:0]  xf1_copies
);
    // ================= C31 core =================
    wire        c_read_ahead; wire [23:0] c_read_ahead_addr;
    wire        c_bus_valid, c_bus_write;
    wire [2:0]  c_bus_kind;
    wire [23:0] c_bus_addr;
    wire [31:0] c_bus_wdata;
    wire        c_bus_ready;
    wire [31:0] c_bus_rdata;
    wire        retire, retire_fault, core_guest_step;
    wire [23:0] retire_pc;
    wire [31:0] retire_cyc;
    wire        core_ce;
    wire        core_at_sample;
    wire [15:0] core_sample_cyc;
    wire        core_fuse_allow;
    wire        c_f_valid, c_f_accept, c_f_rsp_valid;
    wire [23:0] c_f_addr;
    wire [31:0] c_f_rdata;
    wire [32*36-1:0] core_snap_state;
    reg reset_q;
    always @(posedge clk) reset_q <= reset;
    wire boot_load = reset_q && !reset;
    wire irq_int3 = 1'b0;                               // midvplus: no INT3 source (see header)
`ifdef WG1_SEED
    // SIMULATION ONLY (tests/run_wg1_seed.py, DESIGN-RULES.md s9 seed-near-target): the bench drives these by hierarchical
    // reference. seed_mode: the power-on boot load starts at seed_pc1 (the bench's preamble) instead of u41's vector;
    // seed_kick: a second load of the MAME register state seed_state at seed_pc2. Never defined in a build.
    reg              seed_mode = 1'b0, seed_kick = 1'b0;
    reg [23:0]       seed_pc1 = 24'd0, seed_pc2 = 24'd0;
    reg [32*36-1:0]  seed_state = {32*36{1'b0}};
    wire             core_load_en = boot_load || seed_kick;
    wire [23:0]      core_load_pc = seed_kick ? seed_pc2 : (seed_mode ? seed_pc1 : boot_pc);
    wire [32*36-1:0] core_load_state = seed_kick ? seed_state : {32*36{1'b0}};
`else
    wire             core_load_en = boot_load;
    wire [23:0]      core_load_pc = boot_pc;
    wire [32*36-1:0] core_load_state = {32*36{1'b0}};
`endif

    c31_core u_core (
        .clk(clk), .rst(reset), .ce(core_ce),
        .read_ahead_valid(c_read_ahead), .read_ahead_addr(c_read_ahead_addr),
        .bus_valid(c_bus_valid), .bus_kind(c_bus_kind), .bus_write(c_bus_write),
        .bus_addr(c_bus_addr), .bus_wdata(c_bus_wdata), .bus_ready(c_bus_ready), .bus_rdata(c_bus_rdata),
        .retire(retire), .retire_pc(retire_pc), .retire_cyc(retire_cyc), .retire_fault(retire_fault),
        .guest_step(core_guest_step), .at_sample(core_at_sample),
        .sample_now(), .sample_cyc(core_sample_cyc), .fuse_allow(core_fuse_allow),
        .f_valid(c_f_valid), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
        .irq_level({7'd0, irq_int3, 2'b00, irq_int0}), .fault_code(cpu_fault),
        .load_en(core_load_en), .load_pc(core_load_pc), .load_state(core_load_state),
        .snap_pc(cpu_pc), .snap_state(core_snap_state)
    );

    // ================= XF1 RAM copy (wg1_xf1_copy) =================
    wire        x_hold, x_busy, x_valid, x_write, m_bus_ready;
    wire [23:0] x_addr; wire [31:0] x_wdata;
    assign c_bus_ready = m_bus_ready && !x_busy;          // the core sees no reply while the engine owns the port
    wg1_xf1_copy u_xf1 (.clk(clk), .reset(reset), .por(por), .iof(core_snap_state[32*32 +: 32]),
        .core_bus_idle(!c_bus_valid), .hold(x_hold), .busy(x_busy),
        .m_valid(x_valid), .m_write(x_write), .m_addr(x_addr), .m_wdata(x_wdata), .m_ready(m_bus_ready && x_busy),
        .m_rdata(c_bus_rdata), .copies(xf1_copies));

    // ================= memory tier (wg1 fork, rtl/mem) =================
    wire        ext_valid, ext_write;
    wire [23:0] ext_addr;
    wire [31:0] ext_wdata;
    wire        ext_ready;
    wire [31:0] ext_rdata;
    wire        guest_pause;
    c31_memory_fp #(.READ_OVERLAP(0), .NUM_MAIN_PAGES(NUM_MAIN_PAGES), .NUM_ROM_PAGES(NUM_ROM_PAGES)) u_mem (
        .clk(clk), .ce(1'b1), .rst(reset),
        .read_ahead_valid(c_read_ahead && core_ce && !x_busy), .read_ahead_addr(c_read_ahead_addr),
        .bus_valid(x_busy ? x_valid : c_bus_valid), .bus_write(x_busy ? x_write : c_bus_write),
        .bus_fetch(!x_busy && c_bus_kind == 3'd0),
        .bus_addr(x_busy ? x_addr : c_bus_addr), .bus_wdata(x_busy ? x_wdata : c_bus_wdata),
        .bus_ready(m_bus_ready), .bus_rdata(c_bus_rdata), .guest_pause(guest_pause),
        .f_valid(c_f_valid && !x_busy), .f_addr(c_f_addr), .f_accept(c_f_accept), .f_rsp_valid(c_f_rsp_valid), .f_rdata(c_f_rdata),
        .sd_req(sd_req), .sd_burst(sd_burst), .sd_we(sd_we), .sd_addr(sd_addr), .sd_wdata(sd_wdata),
        .sd_ack(sd_ack), .sd_rdata(sd_rdata),
        .ext_valid(ext_valid), .ext_write(ext_write), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
        .ext_ready(ext_ready), .ext_rdata(ext_rdata),
        .nvram_protected(),
        .stat_main_hits(), .stat_main_misses(), .stat_rom_hits(), .stat_rom_misses(), .stat_pause_clocks(),
        .stat_fetch_accepts(), .stat_fetch_rejects(), .stat_fetch_stale()
    );

    // ================= ext sub-decode (midvplus_map) =================
    wire is_pal   = (ext_addr >= 24'h9c0000 && ext_addr <= 24'h9c7fff);
    wire [23:0] v_addr = is_pal ? (ext_addr + 24'h020000) : ext_addr;   // palette onto vunit's 0x9e0000 decode
    wire is_vunit = (ext_addr == 24'h600000 && ext_write) ||
                    (ext_addr >= 24'h900000 && ext_addr <= 24'h97ffff) ||
                    (ext_addr >= 24'ha00000 && ext_addr <= 24'hbfffff) ||
                    is_pal ||
                    (ext_addr >= 24'h980020 && ext_addr <= 24'h98002b && (ext_write || ext_addr == 24'h980020)) ||
                    ext_addr == 24'h980000 || ext_addr == 24'h980040 || ext_addr == 24'h980041 ||
                    ext_addr == 24'h980080 || ext_addr == 24'h980082 || ext_addr == 24'h980083;
    wire is_periph = ext_addr == 24'h808020 || ext_addr == 24'h808024 || ext_addr == 24'h808028 ||
                     ext_addr == 24'h808030 || ext_addr == 24'h808034 || ext_addr == 24'h808038 ||
                     ext_addr == 24'h808064 || ext_addr == 24'h994000;
    wire is_misc  = (ext_addr >= 24'h9d0000 && ext_addr <= 24'h9d000f);
    // 0x980081: War Gods writes it during POST (measured, M4 boot instr 1,132,527, STI at 0x28eb). MAME has no
    // write handler there (midvunit.cpp:726 0x980080 noprw, :728 0x980082-3 read-only), so the write is dropped;
    // a benign no-op sink here keeps it off ext_unmapped_seen (the whole-boot PC-diff matched with or without it).
    wire is_vpad  = (ext_addr == 24'h980081);

    // CONTRACTS C1 exported request (the slaves decode their own window and answer io_hit / ide_hit)
    // slv_sync is assigned after the I/O ASIC wait-state counter (ext response mux section)
    assign slv_valid = ext_valid; assign slv_write = ext_write;
    assign slv_addr = ext_addr;   assign slv_wdata = ext_wdata; assign slv_guest_ce = guest_tick_en;

    // ================= guest time =================
    wire               vunit_mem_wait, guest_calc_wait;
    wire               slave_wait = io_wait || ide_wait;
    wire               render_hold = (RENDER_HOLDS_GUEST != 0) && guest_calc_wait;
    wire               guest_tick_en;
    wire [NOW_BITS-1:0] now;
    wire [15:0]        h1_owed;
    wire               ext_sync;
    wire [23:0] int0_event_lb;
    wire [23:0] int3_event_lb = 24'hffffff;            // no INT3 source
`ifdef GM1_SERIAL_GUEST_GATE
    localparam integer GUEST_HORIZON = 0;
`else
    localparam integer GUEST_HORIZON = 1;
`endif
    c31_guest_gate #(.NOW_BITS(NOW_BITS), .HORIZON(GUEST_HORIZON), .EXTRA_EVENT(1), .REAL_TIME(GUEST_REAL_TIME)) u_gate (
        .clk(clk), .rst(reset), .retire(retire), .retire_cyc(retire_cyc[15:0]), .at_sample(core_at_sample),
        .sample_cyc(core_sample_cyc), .fuse_allow(core_fuse_allow),
        .event_lb(int0_event_lb), .event_lb_extra(int3_event_lb), .step_allow(run_enable && !vunit_mem_wait && !slave_wait && !x_hold),
        .render_stall(render_hold),
        .core_ce(core_ce), .ext_sync(ext_sync), .guest_tick_en(guest_tick_en), .now(now), .h1_owed(h1_owed)
    );
    assign guest_tick = {{(64-NOW_BITS){1'b0}}, now};

    wire guest_video_ce;
    cusa_video_ce u_video_ratio (.clk(clk), .reset(reset), .guest_step(guest_tick_en), .video_ce(guest_video_ce));

    // ================= V-unit video board =================
    wire [7:0]  render_attr;
    wire        vb_ready;
    wire [31:0] vb_rdata;
    wire        vb_bus_ce = ext_valid && is_vunit && bus_run_enable && !render_hold && ext_sync;
    // CRT_SETUP (0x980020) bit 15: War Gods POST writes 0x8590 (u41 0x28F2-0x28FE: 0x590 | 0x8000). vunit_raster treats
    // bit 15 as a pixel divide-by-two (a prototype interpretation, rtl/vunit/README.md), which halves the raster and
    // INT0 to 34.53 ms. MAME ignores it: video_control_w (midvunit_v.cpp:438-460) uses only data & 0x1ff of offset 0
    // (the INT0 scanline) and the frame is always regs[6] x regs[11] at MIDVUNIT_VIDEO_CLOCK/2 (midvunit.h:65,
    // midvunit_v.cpp:459) -- measured 17.2628 ms per INT0 in MAME 0.289 with 0x8590 written. wg1 therefore drops bit 15
    // on the way to the raster (wg1-local; Cruis'n keeps the shared interpretation). Gate: tests/run_wg1_int0_gate.py.
    wire        crt_setup_w = ext_write && (ext_addr == 24'h980020);
    wire [31:0] v_wdata = crt_setup_w ? {ext_wdata[31:16], 1'b0, ext_wdata[14:0]} : ext_wdata;
    vunit_board #(.QUEUE_DEPTH(VUNIT_QUEUE_DEPTH), .WIDTH(WIDTH), .HEIGHT(HEIGHT),
                  .PRIVATE_TEXTURE_SERVICE(PRIVATE_TEXTURE_SERVICE), .FACTORED_CAPTURE_WAIT(0),
                  .REGISTER_VIEW(REGISTER_VIEW),
                  // r16: MAME's poly wait on video RAM read/write and texture RAM write (midvunit_v.cpp:477-499, :517-523).
                  // With REGISTER_VIEW 1 the 0x980082 busy bit reads 0 (MAME), so without it the boot POST "V+ DMA ASIC"
                  // test (u41 0x2CEA) read the polygon's pixels ~90 clk after the commit, before the renderer drew them:
                  // pixel 0 = 0x0000 -> Error E2. Gate: tests/run_wg1_post_gate.py (mutant nowait).
                  .MAME_POLY_WAIT(1)) u_video (
        .clk(clk), .reset(reset), .guest_ce(guest_tick_en), .video_ce(guest_video_ce), .bus_ce(vb_bus_ce),
        .capture_wait_intent(1'b0),
        .req_valid(ext_valid && is_vunit), .req_ready(vb_ready), .req_write(ext_write),
        .req_addr(v_addr), .req_wdata(v_wdata), .req_rdata(vb_rdata),
        .fb_valid(fb_valid), .fb_ready(fb_ready), .fb_addr(fb_addr), .fb_data(fb_data),
        .fb_pair(fb_pair), .fb_data_hi(fb_data_hi),
        .tex_req_valid(tex_req_valid), .tex_req_ready(tex_req_ready), .tex_req_addr(tex_req_addr),
        .tex_req_prefetch(tex_req_prefetch), .tex_rsp_valid(tex_rsp_valid), .tex_rsp_ready(tex_rsp_ready),
        .tex_rsp_data(tex_rsp_data), .tex_req_pair(tex_req_pair), .tex_req_off2(tex_req_off2),
        .tex_rsp_data2(tex_rsp_data2), .tex_req_tag(tex_req_tag), .tex_rsp_tag(tex_rsp_tag),
        .cpu_mem_req_valid(cpu_mem_req_valid), .cpu_mem_req_ready(cpu_mem_req_ready),
        .cpu_mem_req_write(cpu_mem_req_write), .cpu_mem_req_region(cpu_mem_req_region),
        .cpu_mem_req_addr(cpu_mem_req_addr), .cpu_mem_req_wdata(cpu_mem_req_wdata),
        .cpu_mem_req_be(cpu_mem_req_be), .cpu_mem_rsp_valid(cpu_mem_rsp_valid),
        .cpu_mem_rsp_ready(cpu_mem_rsp_ready), .cpu_mem_rsp_rdata(cpu_mem_rsp_rdata),
        .display_page(display_page), .write_page(write_page), .queue_nonempty(queue_nonempty),
        .renderer_busy(renderer_busy), .queue_full(queue_full),
        .guest_memory_wait(vunit_mem_wait), .guest_calculation_wait(guest_calc_wait),
        .guest_fb_offer(guest_fb_offer), .guest_tex_offer(guest_tex_offer),
        .fault_sticky(vunit_fault),
        .raster_x(raster_x), .raster_y(raster_y), .raster_de(raster_de),
        .hsync(hsync), .vsync(vsync), .csync(csync), .pixel_event(pixel_event),
        .frame_event(frame_event), .irq_int0(irq_int0), .palette_epoch(palette_epoch),
        .source_restart(source_restart), .render_attr(render_attr), .int0_event_lb(int0_event_lb)
    );
    assign guest_memory_wait = vunit_mem_wait || slave_wait;

    // ================= midvplus_misc (0x9d0000-0x9d000f, midvunit.cpp:587-645) =================
    reg  [31:0] misc [0:15];
    wire [3:0]  misc_off = ext_addr[3:0];
    wire        misc_acc = ext_valid && is_misc && ext_sync;
    wire [31:0] misc_rdata = (misc_off == 4'd0) ? 32'h0000b580 : (misc_off == 4'd2) ? 32'h0000f3ff : misc[misc_off];
    integer mi;
    initial for (mi = 0; mi < 16; mi = mi + 1) misc[mi] = 32'd0;
    always @(posedge clk) if (misc_acc && ext_write) misc[misc_off] <= ext_wdata;

    // ================= peripherals (timers, bus control, control_w DCS run) =================
    wire        p_ready;
    wire [31:0] p_rdata;
    wire [31:0] bus_control;       // 0x808064 as the game programmed it (I/O ASIC wait states, below)
    c31_peripherals #(.NOW_BITS(NOW_BITS)) u_periph (
        .clk(clk), .ce(1'b1), .rst(reset),
        .bus_valid(ext_valid && is_periph && ext_sync), .bus_write(ext_write), .bus_addr(ext_addr), .bus_wdata(ext_wdata),
        .bus_ready(p_ready), .bus_rdata(p_rdata),
        .now(now),
        .dcs_data(), .dcs_data_valid(), .dcs_data_tick(),
        .dcs_reset(ctl_dcs_run), .dcs_reset_strobe(ctl_dcs_strobe), .dcs_reset_tick(),
        .wheel_motor(), .wheel_lamps(), .wheel_sound_bus(),
        .bus_control(bus_control)
    );

    // ================= C31 primary-bus software wait states on the I/O ASIC window (wg1 2026-09-25) =================
    // The C31 inserts WTCNT wait states (one H1 = 2 clk each at CLKIN 50 MHz) on every primary-bus access when the
    // primary bus control register 0x808064 selects the internal wait counter: SWW (bits 4:3) = 01 (count only) or 11
    // (count AND external RDY -> at least WTCNT); WTCNT = bits 7:5 (TMS320C3x User's Guide, primary bus control
    // register; reset 0x10F8 = SWW 11 / WTCNT 7, c31_peripherals.sv:176). War Gods writes 0x04E8 at PC 0x00004D
    // (u41 boot, H:/temp/wargods/m0/boot_3m.tr line 13): SWW 01, WTCNT 7 -> 7 wait states. MAME's TMS320C31 models no
    // wait states (midvunit.cpp:307 stores the register only), so its host can answer the DCS2 within 5 DSP cycles
    // of a SOUNDIN read; the real board cannot (>= 5 I/O ASIC accesses between the DSP's reply and the host's next
    // SOUNDOUT, CFF1-CFF6 + D01E-D022 -> >= 35 H1 = 22.4 DSP cycles). That window matters: the War Gods DCS2
    // program restores its IRQ2 vector (PM[4], 0x33EF) 10 instructions after an IRQ1 reply post (0x31E5); a
    // host word landing earlier is swallowed by the RTI stub and the sound board deadlocks (cabinet r7, VS ladder).
    // Modelled only on the I/O ASIC window (the DCS2 host port); guest time keeps running during the wait
    // (REAL_TIME guest gate), exactly as the wait states cost real time on the board. Logic: wg1_c31_iows.sv.
    wire        io_ws_done;
    wg1_c31_iows u_iows (.clk(clk), .reset(reset), .bus_control(bus_control), .ext_valid(ext_valid), .io_hit(io_hit),
                         .ext_sync(ext_sync), .ext_ready(ext_ready), .io_ws_done(io_ws_done));
    // an I/O ASIC access is offered to the slaves (C1 accept = side effects, the diag mirror's io_acc) only after its
    // wait states; other windows see ext_sync unchanged
    assign slv_sync = ext_sync && (!io_hit || io_ws_done);

    // ================= ext response mux =================
    assign ext_ready = ext_sync && (io_hit   ? io_ready && io_ws_done :
                                    ide_hit  ? ide_ready :
                                    is_misc  ? 1'b1      :
                                    is_vunit ? vb_ready  :
                                    is_periph ? p_ready  :
                                    is_vpad  ? 1'b1      :   // benign no-op sink (0x980081)
                                    ext_valid);   // unmapped: complete at once with 0 (flagged)
    assign ext_rdata = io_hit   ? io_rdata  :
                       ide_hit  ? ide_rdata :
                       is_misc  ? misc_rdata :
                       is_vunit ? vb_rdata  :
                       is_periph ? p_rdata  : 32'd0;

    // ================= render-budget counters (as gm1) =================
    reg [31:0] t_cpu, t_stall, t_setup, t_texel, t_fb, t_memblk;
    wire       cpu_held = !core_ce;
    always @(posedge clk) begin
        if (reset) begin
            t_cpu <= 32'd0; t_stall <= 32'd0; t_setup <= 32'd0; t_texel <= 32'd0; t_fb <= 32'd0; t_memblk <= 32'd0;
        end else begin
            if (core_ce) t_cpu <= t_cpu + 32'd1;
            if (cpu_held && guest_calc_wait) begin
                t_stall <= t_stall + 32'd1;
                if (render_attr[7])                                        t_setup <= t_setup + 32'd1;
                else if (render_attr[5:0] == 6'd41 || render_attr[5:0] == 6'd42) t_texel <= t_texel + 32'd1;
                else if (render_attr[5:0] == 6'd43)                        t_fb    <= t_fb + 32'd1;
            end
            if (cpu_held && !guest_calc_wait && (vunit_mem_wait || slave_wait)) t_memblk <= t_memblk + 32'd1;
        end
    end
    assign render_diag = {t_cpu[31:16], t_stall[31:16], t_setup[31:16], t_texel[31:16], t_fb[31:16], t_memblk[31:16]};
    // 2026-09-25 speed diag (mirror block B words 45/46): a POLYGON COMMIT = a completed C31 read of 0x980083 (MAME
    // dma_trigger_r offset 1 -> process_dma_queue, midvunit_v.cpp:388-401), and the renderer-occupied level (busy or
    // records queued). Raw levels; wg1_status_mirror counts them. (Replaces the unused 64-bit p_rbusy counter.)
    wire poly_commit = ext_valid && ext_ready && !ext_write && (ext_addr == 24'h980083);
    wire rbusy_lvl   = renderer_busy || queue_nonempty;
    // 2026-09-24 cabinet diag (wg1_status_mirror, WG1_DIAG_MIRROR builds): the spare perf_diag bits carry the C31
    // retire PC, INT0 assertion count and ST/IE/IF/IOF. Observation only; unused (pruned) in a release build.
    reg [31:0] int0_count; reg irq_int0_q;
    always @(posedge clk) begin
        if (reset) begin int0_count <= 32'd0; irq_int0_q <= 1'b0; end
        else begin irq_int0_q <= irq_int0; if (irq_int0 && !irq_int0_q) int0_count <= int0_count + 32'd1; end
    end
    // 2026-09-25 disk-read diag: a completed write to C31 RAM word 0x00445C (War Gods ADJS "Attract Mode Sounds", the
    // aud_adj_read buffer word 0x7D at 0x43DF + 0x7D; MAME 0.289 reads 0 = OFF from the shipped disk) -- raw pulse +
    // data at the memory tier's input (core or XF1 copy engine), counted/latched by wg1_status_mirror.
    wire [23:0] adj_a  = x_busy ? x_addr : c_bus_addr;
    wire        adj_we = (x_busy ? (x_valid && x_write) : (c_bus_valid && c_bus_write)) && m_bus_ready &&
                         (adj_a == 24'h00445c);
    wire [31:0] adj_wd = x_busy ? x_wdata : c_bus_wdata;
    assign perf_diag = {core_snap_state[29*32 +: 32], core_snap_state[30*32 +: 32],    // ST, IE
                        core_snap_state[31*32 +: 32], core_snap_state[32*32 +: 32],    // IF, IOF
                        int0_count, 8'd0, retire_pc, 29'd0, adj_we, adj_wd, poly_commit, rbusy_lvl};

    always @(posedge clk) begin
        if (reset) begin
            instructions <= 64'd0; ext_unmapped_seen <= 1'b0; int0_seen <= 1'b0;
        end else begin
            if (retire) instructions <= instructions + 64'd1;
            if (ext_valid && !(io_hit || ide_hit || is_misc || is_vunit || is_periph || is_vpad)) ext_unmapped_seen <= 1'b1;
            if (irq_int0) int0_seen <= 1'b1;
        end
    end
endmodule
`default_nettype wire
