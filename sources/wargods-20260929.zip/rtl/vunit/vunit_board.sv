// SPDX-License-Identifier: BSD-3-Clause
// Register/memory/raster wrapper; physical framebuffer/texture/palette are external.
module vunit_board #(
    parameter integer QUEUE_DEPTH=270,
    parameter integer WIDTH=512,
    parameter integer HEIGHT=400,
    parameter integer IRQ_PULSE_GUEST_STEPS=1,
    parameter integer PRIVATE_TEXTURE_SERVICE=0,
    parameter integer FACTORED_CAPTURE_WAIT=0,
    parameter integer REGISTER_VIEW=0,
    // MAME_POLY_WAIT: 1 = a CPU video RAM read or write, or a texture RAM write, is held until every triggered polygon
    // has been drawn (queue empty, renderer idle; the renderer's busy covers its framebuffer writes until the memory
    // side accepted them). MAME: videoram_r / videoram_w / textureram_w call m_poly->wait() first
    // (midvunit_v.cpp:477-499, :517-523); textureram_r and paletteram_w do not. 0 = no wait (default; bit-for-bit the
    // previous behaviour for every existing user). The wait only drops req_ready (a real-time stall, like the full-queue
    // commit stall in vunit_core); it does not stop guest time, so a guest_ce-stepped dequeue cannot deadlock on it.
    parameter integer MAME_POLY_WAIT=0
) (
    input wire clk, reset, guest_ce, video_ce, bus_ce,
    input wire req_valid, req_write,
    input wire capture_wait_intent,
    input wire [23:0] req_addr,
    input wire [31:0] req_wdata,
    output wire req_ready,
    output wire [31:0] req_rdata,
    output wire fb_valid,
    input wire fb_ready,
    output wire [18:0] fb_addr,
    output wire [15:0] fb_data,
    output wire fb_pair,
    output wire [15:0] fb_data_hi,
    output wire tex_req_valid,
    input wire tex_req_ready,
    output wire [21:0] tex_req_addr,
    output wire tex_req_prefetch,
    input wire tex_rsp_valid,
    output wire tex_rsp_ready,
    input wire [7:0] tex_rsp_data,
    output wire tex_req_pair,
    output wire [2:0] tex_req_off2,
    input wire [7:0] tex_rsp_data2,
    output wire [3:0] tex_req_tag,
    input wire [3:0] tex_rsp_tag,
    output wire cpu_mem_req_valid,
    input wire cpu_mem_req_ready,
    output wire cpu_mem_req_write,
    output wire [1:0] cpu_mem_req_region,
    output wire [21:0] cpu_mem_req_addr,
    output wire [31:0] cpu_mem_req_wdata,
    output wire [3:0] cpu_mem_req_be,
    input wire cpu_mem_rsp_valid,
    output wire cpu_mem_rsp_ready,
    input wire [31:0] cpu_mem_rsp_rdata,
    output wire display_page, write_page, queue_nonempty, renderer_busy, queue_full,
    output wire guest_memory_wait,
    output wire guest_calculation_wait,
    output wire guest_fb_offer,guest_tex_offer,
    output wire [7:0] fault_sticky,
    output wire [9:0] raster_x,
    output wire [8:0] raster_y,
    output wire raster_de, hsync, vsync, csync, pixel_event, frame_event, irq_int0,
    output reg [31:0] palette_epoch,
    output reg source_restart,
    // Observation only: the renderer's wait attribution (vunit_flat_raster render_attr). Leave unconnected if unused.
    output wire [7:0] render_attr,
    // Stage 2: lower bound on guest ticks until the next INT0 edge (vunit_raster). Leave unconnected if unused.
    output wire [23:0] int0_event_lb
);
    wire memory_address = ((req_addr >= 24'h900000) && (req_addr <= 24'h97ffff)) ||
                          ((req_addr >= 24'ha00000) && (req_addr <= 24'hbfffff)) ||
                          ((req_addr >= 24'h9e0000) && (req_addr <= 24'h9e7fff));
    wire memory_busy;
    wire memory_route = memory_busy || memory_address;
    wire poly_wait_address = ((req_addr >= 24'h900000) && (req_addr <= 24'h97ffff)) ||
                             (req_write && (req_addr >= 24'ha00000) && (req_addr <= 24'hbfffff));
    // not yet captured by vunit_cpu_memory (a captured access has already passed the wait)
    wire poly_wait = (MAME_POLY_WAIT != 0) && !memory_busy && poly_wait_address && (queue_nonempty || renderer_busy);
    wire crt_address = !memory_route &&
        ((req_write && (req_addr >= 24'h980020) && (req_addr <= 24'h98002b)) ||
         (!req_write && (req_addr == 24'h980020)));
    wire core_ready, memory_ready;
    wire [31:0] core_rdata, memory_rdata;
    wire core_wait, memory_wait;
    wire [7:0] core_fault;
    wire raster_fault;
    wire core_valid = req_valid && !memory_route && !crt_address;
    assign req_ready = memory_route ? memory_ready : crt_address ? (bus_ce && !reset) : core_ready;
    assign req_rdata = memory_route ? memory_rdata : crt_address ? {23'b0,raster_y} : core_rdata;
    assign guest_memory_wait = core_wait || memory_wait;
    assign fault_sticky = core_fault | {raster_fault,7'b0};
    wire transaction_done = req_valid && req_ready;
    reg crt_reset_previous;
    wire control_write = transaction_done && req_write && (req_addr == 24'h980080);
    wire crt_counter_reset = control_write && crt_reset_previous && !req_wdata[0];

    vunit_core #(.QUEUE_DEPTH(QUEUE_DEPTH),.WIDTH(WIDTH),.HEIGHT(HEIGHT),
        .PRIVATE_TEXTURE_SERVICE(PRIVATE_TEXTURE_SERVICE),.REGISTER_VIEW(REGISTER_VIEW)) graphics (
        .clk(clk),.reset(reset),.guest_ce(guest_ce),.bus_ce(bus_ce),
        .req_valid(core_valid),.req_ready(core_ready),.req_write(req_write),
        .req_addr(req_addr),.req_wdata(req_wdata),.req_rdata(core_rdata),
        .fb_valid(fb_valid),.fb_ready(fb_ready),.fb_addr(fb_addr),.fb_data(fb_data),.fb_pair(fb_pair),.fb_data_hi(fb_data_hi),
        .tex_req_valid(tex_req_valid),.tex_req_ready(tex_req_ready),.tex_req_addr(tex_req_addr),.tex_req_prefetch(tex_req_prefetch),
        .tex_rsp_valid(tex_rsp_valid),.tex_rsp_ready(tex_rsp_ready),.tex_rsp_data(tex_rsp_data),
        .tex_req_pair(tex_req_pair),.tex_req_off2(tex_req_off2),.tex_rsp_data2(tex_rsp_data2),
        .tex_req_tag(tex_req_tag),.tex_rsp_tag(tex_rsp_tag),
        .display_page(display_page),.write_page(write_page),.queue_nonempty(queue_nonempty),
        .renderer_busy(renderer_busy),.queue_full(queue_full),.guest_memory_wait(core_wait),.fault_sticky(core_fault),
        .guest_calculation_wait(guest_calculation_wait),
        .guest_fb_offer(guest_fb_offer),.guest_tex_offer(guest_tex_offer),
        .render_attr(render_attr)
    );
    vunit_cpu_memory #(.FACTORED_CAPTURE_WAIT(FACTORED_CAPTURE_WAIT)) cpu_memory (
        .clk(clk),.reset(reset),.bus_ce(bus_ce),
        .capture_wait_intent(capture_wait_intent),
        .req_valid(req_valid && memory_route && !poly_wait),.req_ready(memory_ready),.req_write(req_write),
        .req_addr(req_addr),.req_wdata(req_wdata),.req_rdata(memory_rdata),
        .mem_req_valid(cpu_mem_req_valid),.mem_req_ready(cpu_mem_req_ready),
        .mem_req_write(cpu_mem_req_write),.mem_req_region(cpu_mem_req_region),
        .mem_req_addr(cpu_mem_req_addr),.mem_req_wdata(cpu_mem_req_wdata),.mem_req_be(cpu_mem_req_be),
        .mem_rsp_valid(cpu_mem_rsp_valid),.mem_rsp_ready(cpu_mem_rsp_ready),.mem_rsp_rdata(cpu_mem_rsp_rdata),
        .busy(memory_busy),.guest_memory_wait(memory_wait)
    );
    vunit_raster #(.IRQ_PULSE_GUEST_STEPS(IRQ_PULSE_GUEST_STEPS)) raster (
        .clk(clk),.reset(reset),.guest_ce(guest_ce),.video_ce(video_ce),.counter_reset(crt_counter_reset),
        .wr_valid(transaction_done && crt_address && req_write),.wr_index(req_addr[3:0]),.wr_data(req_wdata[15:0]),
        .raster_x(raster_x),.raster_y(raster_y),.raster_de(raster_de),
        .hsync(hsync),.vsync(vsync),.csync(csync),.pixel_event(pixel_event),.frame_event(frame_event),
        .irq_int0(irq_int0),.int0_event_lb(int0_event_lb),.fault_sticky(raster_fault)
    );
    always @(posedge clk) begin
        if (reset) begin crt_reset_previous <= 0; palette_epoch <= 0; source_restart<=0; end
        else begin
            source_restart<=crt_counter_reset || (transaction_done && crt_address && req_write);
            if (control_write) crt_reset_previous <= req_wdata[0];
            if (transaction_done && memory_route && cpu_mem_req_write && (cpu_mem_req_region == 2))
                palette_epoch <= palette_epoch + 1'b1;
        end
    end
endmodule
