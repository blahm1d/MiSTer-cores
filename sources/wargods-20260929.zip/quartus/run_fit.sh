#!/usr/bin/env bash
# wg1 single-ticket Quartus chain (runs INSIDE the shared FIFO ticket, cwd = the prepared snapshot's quartus dir).
# Pinned Quartus 17.0: map -> fit -> sta (multicorner) -> STA verdict -> asm -> RBF. The main session's strict
# per-corner audit (bandwidth/wg1/review/sta_audit_wg1.py) is the sign-off authority. Mirrors gm1/quartus/run_fit.sh.
set -Eeuo pipefail
export MSYS2_ARG_CONV_EXCL="*"
HERE="$(cd "$(dirname "$0")" && pwd)"
QBIN=/c/intelFPGA_lite/17.0/quartus/bin64
REV=wg1
cd "$HERE"
echo "The next controlled worker in this ticket is the pinned Quartus executable."
"$QBIN/quartus_map.exe" $REV
"$QBIN/quartus_fit.exe" $REV
"$QBIN/quartus_sta.exe" $REV
"$QBIN/quartus_sta.exe" -t sdram_io_report.tcl
"$QBIN/quartus_sta.exe" -t timing_paths.tcl
STA=output_files/$REV.sta.rpt
if [ ! -f "$STA" ]; then echo "STA report missing"; exit 3; fi
if grep -qi "Timing requirements not met" "$STA"; then
  echo "STA_VERDICT=REQUIREMENTS_NOT_MET" | tee output_files/sta_verdict.txt
else
  echo "STA_VERDICT=NO_UNMET_REQUIREMENT_MESSAGE" | tee output_files/sta_verdict.txt
fi
# Frozen audit is the fail-closed assembly gate; a successful STA exit alone is insufficient.
# r16: this build is authorized without a timing waiver; a blocked gate stops before assembly.
/c/Python314/python.exe "$(cygpath -am "$HERE/assembly_gate_wg1.py")" "$(cygpath -am "$HERE")"
"$QBIN/quartus_asm.exe" $REV
ls -l output_files/$REV.rbf && echo "RBF: $HERE/output_files/$REV.rbf"
