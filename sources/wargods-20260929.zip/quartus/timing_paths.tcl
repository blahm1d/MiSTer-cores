# wg1 endpoint evidence (advisory diagnostic; the strict sign-off is sta_audit_wg1.py). Forked from
# bandwidth/gm1/quartus/timing_paths.tcl. Per-block worst-path dumps use module-name wildcards and SKIP a block
# whose collection is empty (post_message WARNING) rather than error -- a missing/renamed instance must never abort
# the fit ticket before quartus_asm. Adds a dcs (dcs2_engine) block and points sdram at wg1_sdram.
set here [file dirname [file normalize [info script]]]
set out [file join $here output_files timing_paths]
file mkdir $out
project_open [file join $here wg1] -revision wg1
create_timing_netlist
read_sdc
update_timing_netlist
foreach_in_collection op [get_available_operating_conditions] {
    set corner [get_operating_conditions_info $op -display_name]
    if {![string match "*Slow*" $corner]} { continue }
    set_operating_conditions $op
    update_timing_netlist
    set tag [string map {" " "_"} $corner]
    report_timing -setup -npaths 32 -nworst 1 -detail full_path -file [file join $out paths_$tag.txt] -panel_name "paths_$tag"
    foreach {block pattern} {
        cpu {*|c31_core:*|*}
        cache {*|c31_memory_fp:*|*}
        texture {*|vunit_memory_arbiter:*|*}
        raster {*|vunit_flat_raster:*|*}
        shared_ddr {*|wg1_ddr_port:shared_mux|*}
        sdram {*|wg1_sdram:*|*}
        dcs {*|dcs2_engine:*|*}
    } {
        set targets [get_registers -nowarn $pattern]
        if {[get_collection_size $targets] == 0} {
            post_message -type warning "wg1: empty timing-path block $block ($pattern) -- skipped"
            continue
        }
        report_timing -setup -to $targets -npaths 8 -nworst 1 -detail full_path -file [file join $out paths_${tag}_${block}.txt] -panel_name "paths_${tag}_${block}"
    }
    array unset worst
    array unset count
    array unset launch
    set paths [get_timing_paths -setup -npaths 200000 -nworst 1 -less_than_slack 2.5]
    foreach_in_collection p $paths {
        set slack [get_path_info $p -slack]
        set to [get_node_info -name [get_path_info $p -to]]
        regsub -all {\[[0-9]+\]} $to {[]} to
        regsub -all {~DUPLICATE} $to {} to
        if {![info exists worst($to)] || $slack < $worst($to)} {
            set worst($to) $slack
            set launch($to) [get_node_info -name [get_path_info $p -from]]
        }
        if {![info exists count($to)]} { set count($to) 0 }
        incr count($to)
    }
    set rows {}
    foreach k [array names worst] { lappend rows [list $worst($k) $count($k) $k $launch($k)] }
    set fh [open [file join $out endpoints_$tag.txt] w]
    puts $fh "corner=$corner endpoints_below_2.5ns=[get_collection_size $paths]"
    foreach r [lsort -real -index 0 $rows] {
        puts $fh [format "%8.3f n=%-6d %s <- %s" [lindex $r 0] [lindex $r 1] [lindex $r 2] [lindex $r 3]]
    }
    close $fh
}
project_close
puts "WG1_TIMING_PATH_REPORT_DONE"
